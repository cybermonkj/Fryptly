<div class="metabox-holder indeed">
	<div class="stuffbox-ism">
					<div class="ism-top-message"><b>"Share Point"</b> - is a special Social Icon Display anywhere on the Page in a fancy way and offer a special way for sharing your page.</div>
				</div>
	<div class="stuffbox-ism">
		<h3>
			<label style="font-size:16px;">
				AddOn Status
			</label>
		</h3>
		<div class="inside">
			<div class="submit" style="float:left; width:80%;">
				This AddOn is not installed into your system. To use this section you need to install and activate the "Social Share Point" AddOn.
			</div>
			<div class="submit" style="float:left; width:20%; text-align:center;">
			</div>
			<div class="clear"></div>
		</div>
	</div>
		
</div>
</div>