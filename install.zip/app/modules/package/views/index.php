
<div class="min-height-200px post activity-follow-setting module-setting">
  <div class="row clearfix">
    <div class="col-xl-4 col-lg-6 col-md-4 col-sm-12 mb-30 ">
      <div class="border-radius-4 box-shadow bg-white account-list">
        <h5 class="mb-20 pl-3 pt-20">
          <a class="btn-outline-primary" href="<?=cn("$module/add/")?>" data-toggle="tooltip" data-placement="top" title="<?=lang("Add")?>"><span><i class="nav-icon fa feather icon-plus-circle"></i></span ></a> <?=lang("package")?>
        </h5>
        <?php if(!empty($packages)){
          foreach ($packages as $key => $row) {
        ?>
        <a href="<?=cn($module.'/'.$row->ids)?>">
          <div class="item <?php echo (segment(2) == $row->ids) ? 'active' : ''?>" id="tr_<?=$row->ids?>" data-ids="<?=$row->ids?>">
            <span class="title"> <i class="fa feather icon-archive" aria-hidden="true"></i> <?=$row->name?> </span>
            <?php
              if ($row->type == 2) {
            ?>
            <div class="option"> <span >
              <span data-href="<?=cn("$module/ajax_delete/$row->ids")?>" class="btnDeletePackage">
                <i class="fa feather icon-trash-2"></i> 
              </span>
            </div>
          <?php }?>
          </div>
        </a>
        <?php }}?>
      </div>
    </div>
    <div class="col-lg-6 col-md-4 col-sm-12 mb-30 activity-content result-content">
      <?php
        $data = array(
          "package"     => $package,
        );
        $this->load->view('content', $data);
      ?>
    </div>
  </div>
</div>
