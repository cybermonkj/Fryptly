<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class auth extends MX_Controller {
	public $module;
	public $module_icon;
	public $module_name;
	public $module_title;
	public $tb_users;
	public $tb_package;

	public function __construct(){
		parent::__construct();
		$this->module_icon  = 'ion-person-add';
		$this->module_name  = 'Manage Users';
		$this->module_title = 'Manage Users';
		$this->tb_users     = USERS;
		$this->tb_package   = PACKAGE;

		$this->module = get_class($this);
		$this->load->model(get_class($this).'_model', 'model');
	}

	public function index(){
		if(!get_Role()){
			get_layout('404');
		}
		$packages = $this->model->fetch('*', PACKAGE);
		$data = array(
			"module"      => $this->module,
			"module_icon" => $this->module_icon,
			"module_name" => $this->module_name,
			"users"       => $this->model->getUsers(),
			'packages'    => $packages,
		);
		$this->template->title($this->module_title);
		$this->template->build('index', $data);
	}


	public function login(){
		if(session('uid')){
			redirect(cn('twitter'));
		}
		$data = array();
		$this->template->set_layout('oauth');
		$this->template->build('login', $data);
	}

	public function logout(){
		if(session('uid')){
			unset_session('langCurrent');
			delete_cookie("purchase_code_status");
			unset_session('uid');
		}
		redirect(cn());
	}

	public function signup(){
		$data = array();
		$this->template->set_layout('oauth');
		$this->template->build('register', $data);
	}

	public function forgot_password(){
		$data = array();
		$this->template->set_layout('oauth');
		$this->template->build('forgot_password', $data);
	}

	public function reset_password(){
		/*----------  check users exists  ----------*/
		$reset_key = segment(3);
		$user = $this->model->get("id, ids, email", $this->tb_users, "reset_key = '{$reset_key}'");
		if (!empty($user)) {
			// redirect to change password page
			$data = array(
				"reset_key" => $reset_key,
			);
			$this->template->set_layout("oauth");
			$this->template->build("change_password", $data);
		}else{
			redirect(cn("auth/login"));
		}
		
	}

	public function activation($activation_key = ""){
		$user = $this->model->get("id, username, timezone, email, activation_key", $this->tb_users, "activation_key = '".$activation_key."'");
		if(!empty($user)){
			$this->db->update($this->tb_users, ['status' => 1, 'activation_key' => 1], ['id' => $user->id]);
			/*----------  Check is send welcome email or not  ----------*/
			if (getOption("is_welcome_email", '')) {
				$merge_fields = [
					'{{username}}'      => $user->username,
					'{{user_email}}'    => $user->email,
					'{{user_timezone}}' => $user->timezone,
				];
				$mail_template = [
					'subject'      => getOption("email_welcome_email_subject", ""),
					'message'      => getOption("email_welcome_email_content", ""),
					'merge_fields' => $merge_fields,
				];
				$check_send_email_issue = $this->model->send_mail_template($mail_template, $user->email, []);
				if($check_send_email_issue){
					ms(array(
						"status" => "error",
						"message" => $check_send_email_issue,
					));
				}
			}

			/*----------  Send email notificaltion for Admin  ----------*/
			if (getOption("is_new_user_email", '')) {
				$merge_fields = [
					'{{username}}'      => $user->username,
					'{{user_email}}'    => $user->email,
					'{{user_timezone}}' => $user->timezone,
				];
				$mail_template = [
					'subject'      => getOption("email_new_registration_subject"),
					'message'      => getOption("email_new_registration_content"),
					'merge_fields' => $merge_fields,
				];

				$email = $this->model->get("email", $this->tb_users, ['admin' => 1])->email;
				if ($email) {
					$check_send_email_issue = $this->model->send_mail_template($mail_template, $email, []);
					if($check_send_email_issue){
						ms(array(
							"status" => "error",
							"message" => $check_send_email_issue,
						));
					}
				}
			}
			$this->template->set_layout('oauth');
			$this->template->build('activation_success');
			
		}else{
			redirect(cn("auth/login"));
		}
	}

	public function ajax_forgot_password(){
		$email = post("email");

		if($email == ""){
			ms(array(
				"status"  => "error",
				"message" => lang("Email_is_required")
			));
		}

		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		  	ms(array(
				"status"  => "error",
				"message" => lang("Invalid_email_format")
			));
		}

		if (isset($_POST['g-recaptcha-response']) && getOption("enable_goolge_recapcha", '')  &&  getOption('google_capcha_site_key') != "" && getOption('google_capcha_secret_key') != "") {
			$resp = $this->recaptcha->setExpectedHostname($_SERVER['SERVER_NAME'])
                      ->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);
            if (!$resp->isSuccess()) {
            	ms(array(
					'status'  => 'error',
					'message' => lang("please_verify_recaptcha"),
				));
            }
		}

		$user = $this->model->get("*", USERS, "email = '{$email}'");
		if(!empty($user)){

			$merge_fields = [
				'{{username}}'               => $user->username, 
				'{{recovery_password_link}}' => cn("auth/reset_password/".$user->reset_key)
			];

			$mail_template = [
				'subject'      => getOption("email_password_recovery_subject", ""),
				'message'      => getOption("email_password_recovery_content", ""),
				'merge_fields' => $merge_fields,
			];
			$email_error = $this->model->send_mail_template($mail_template, $email, []);

			if($email_error){
				ms(array(
					"status"  => "error",
					"message" => $email_error
				));
			}

			ms(array(
				"status"  => "success",
				"message" => lang("we_have_send_you_a_link_to_reset_password_and_get_back_into_your_account_please_check_your_email"),
			));
		}else{
			ms(array(
				"status" => "error",
				"message" => lang("the_account_does_not_exists")
			));
		}
	}

	public function ajax_reset_password($reset_key = ""){
		$user = $this->model->get("id, ids, email", $this->tb_users, ['reset_key' => $reset_key]);
		$password           = post('password');
		$re_password        = post('re_password');

		if($password == '' || $re_password == ''){
			ms(array(
				'status'  => 'error',
				'message' => lang("please_fill_in_the_required_fields"),
			));
		}

		if($password != ''){
			if(strlen($password) < 6){
				ms(array(
					'status'  => 'error',
					'message' => lang("Password_must_be_at_least_6_characters_long"),
				));
			}

			if($re_password != $password){
				ms(array(
					'status'  => 'error',
					'message' => lang("Password_must_be_at_least_6_characters_long"),
				));
			}
		}

		if (!empty($user)) {
			$data = array(
				"password"  => md5($password),
				"reset_key" => generateRandomString(32),
				"changed"	=> NOW,
			);

			$this->db->update($this->tb_users, $data, "id = '".$user->id."'");
			if ($this->db->affected_rows() > 0) {
				ms(array(
					"status"   => "success",
					"message"  => lang("your_password_has_been_successfully_changed"),
				));
			}else{
				ms(array(
					"status"  => "Failed",
					"message" => lang("There_was_an_error_processing_your_request_Please_try_again_later")
				));
			}
		}else{
			ms(array(
				"status"  => "error",
				"message" => lang("There_was_an_error_processing_your_request_Please_try_again_later")
			));
		}
	}

	public function ajax_login(){
		$remember    = post("remember");
		$email       = post('email');
		$password    = post('password');
		if($email == ''){
			ms(array(
				'status'  => 'error',
				'message' => lang('Email_is_required'),
			));
		}

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
	      	ms(array(
				'status'  => 'error',
				'message' => lang('Invalid_email_format'),
			));
	    }	

		if($password == ''){
			ms(array(
				'status'  => 'error',
				'message' => lang('Password_is_required'),
			));

		}

		$checkUser = $this->model->get('id, status, email, password', $this->tb_users, "email ='{$email}'");

		if(empty($checkUser)){
			ms(array(
				'status'  => 'error',
				'message' => lang('The_email_address_you_entered_does_not_match_any_account'),
			));
		}

		if($remember){
			set_cookie("cookie_email", encrypt_encode(post("email")), 1209600);
			set_cookie("cookie_pass", encrypt_encode(post("password")), 1209600);
		}else{
			delete_cookie("cookie_email");
			delete_cookie("cookie_pass");
		}

		if($checkUser->status != 1){
			ms(array(
				'status'  => 'error',
				'message' => lang('Your_account_is_not_activated'),
			));
		}

		if($checkUser->password != md5($password)){
			ms(array(
				'status'  => 'error',
				'message' => lang('The_password_is_incorrect'),
			));
		}
		$this->db->update($this->tb_users, ['reset_key' => generateRandomString(32)], ['id' => $checkUser->id]);
		set_session('uid', $checkUser->id);
		ms(array(
			'status'  => 'success',
			'message' => lang('Login_successfully'),
		));
	}

	public function ajax_register(){
		$username    = post('username');
		$email       = post('email');
		$password    = post('password');
		$re_password = post('re_password');
		$timezone    = post('timezone');

		if($username == ''){
			ms(array(
				'status'  => 'error',
				'message' => lang('Username_is_required'),
			));
		}

		if($email == ''){
			ms(array(
				'status'  => 'error',
				'message' => lang('Email_is_required'),
			));
		}

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
	      	ms(array(
				'status'  => 'error',
				'message' => lang('Invalid_email_format'),
			));
	    }	

		if($password == ''){
			ms(array(
				'status'  => 'error',
				'message' => lang('Password_is_required'),
			));
		}

		if(strlen($password) < 6){
			ms(array(
				'status'  => 'error',
				'message' => lang('Password_must_be_at_least_6_characters_long'),
			));
		}

		if($re_password!= $password){
			ms(array(
				'status'  => 'error',
				'message' => lang('Password_does_not_match_the_confirm_password'),
			));
		}

		$checkUser = $this->model->get('email,ids,username',USERS,"email='{$email}'");
		if(!empty($checkUser)){
			ms(array(
				'status'  => 'error',
				'message' => lang('An_account_for_the_specified_email_address_already_exists_Try_another_email_address'),
			));
		}

		// if not
		$default_package = $this->model->get('*', $this->tb_package, ['id' => 1]);

		$data = array(
			"ids"             => ids(),
			"reset_key"       => generateRandomString(32),
			"activation_key"  => generateRandomString(32),
			"admin"           => 0,
			"username"        => $username,
			"package_id"      => ($default_package && isset($default_package->id)) ? $default_package->id : '0',
			"email"           => $email,
			"password"        => md5($password),
			"status"          => getOption('is_verification_new_account') ? 0 : 1,
			"timezone"        => $timezone,
			"created"         => NOW,
			"changed"         => NOW,
		);
		$trial_days = ($default_package && isset($default_package->day)) ? $default_package->day : 3;
		$data['expired_date']   = date("Y-m-d H-i-s", strtotime('+'.$trial_days.' days'));
		if($this->db->insert(USERS, $data)){
			$uid = $this->db->insert_id();
			if (getOption('is_verification_new_account')) {

				$merge_fields = [
					'{{username}}'         => $data['username'],
					'{{user_email}}'       => $data['email'],
					'{{user_timezone}}'    => $data['timezone'],
					'{{activation_link}}'  => cn('auth/activation/').$data['activation_key'],
				];

				$mail_template = [
					'subject'      => getOption("verification_email_subject", ""),
					'message'      => getOption("verification_email_content", ""),
					'merge_fields' => $merge_fields,
				];
				$check_send_email_issue = $this->model->send_mail_template($mail_template, $email, []);
				if($check_send_email_issue){
					ms(array(
						"status" => "error",
						"message" => $check_send_email_issue,
					));
				}

				ms(array(
					"status"  => "success",
					"message" => lang('thank_you_for_signing_up_please_check_your_email_to_complete_the_account_verification_process')
				));

			}else{
				set_session('uid', $uid);
				/*----------  Check is send welcome email or not  ----------*/
				if (getOption("is_welcome_email", '')) {
					$merge_fields = [
						'{{username}}'      => $data['username'],
						'{{user_email}}'    => $data['email'],
						'{{user_timezone}}' => $data['timezone'],
					];
					$mail_template = [
						'subject'      => getOption("email_welcome_email_subject", ""),
						'message'      => getOption("email_welcome_email_content", ""),
						'merge_fields' => $merge_fields,
					];
					$check_send_email_issue = $this->model->send_mail_template($mail_template, $email, []);
					if($check_send_email_issue){
						ms(array(
							"status" => "error",
							"message" => $check_send_email_issue,
						));
					}
				}

				/*----------  Send email notificaltion for Admin  ----------*/
				if (getOption("is_new_user_email", '')) {
					$merge_fields = [
						'{{username}}'      => $data['username'],
						'{{user_email}}'    => $data['email'],
						'{{user_timezone}}' => $data['timezone'],
					];
					$mail_template = [
						'subject'      => getOption("email_new_registration_subject"),
						'message'      => getOption("email_new_registration_content"),
						'merge_fields' => $merge_fields,
					];

					$email = $this->model->get("email", $this->tb_users, ['admin' => 1])->email;
					if ($email) {
						$check_send_email_issue = $this->model->send_mail_template($mail_template, $email, []);
						if($check_send_email_issue){
							ms(array(
								"status" => "error",
								"message" => $check_send_email_issue,
							));
						}
					}
				}

				ms(array(
					'status'  => 'success',
					'message' => lang('You_have_been_successfully_registered_and_logged_in'),
				));
			}
		}
	}

}