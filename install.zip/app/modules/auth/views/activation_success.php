
<div class="limiter">
  <div class="container-login100">
    <div class="wrap-login100 p-l-50 p-r-50 p-t-72 p-b-50">
      <span class="login100-form-title">
        <a href="<?=cn()?>" class="website_brand_logo">
          <img src="<?=getOption('website_brand_logo', BASE.'assets/images/logo.png')?>">
        </a>
      </span>

      <div class="content text-center p-b-50">
        <h3 class="text-pink p-b-10"><?=lang('congratulations_your_registration_is_now_complete')?></h3>
        <p><?=lang('congratulations_desc')?></p>
      </div>

      <div class="wrap-login100-form-btn">
        <div class="login100-form-bgbtn"></div>
        <a href="<?php echo cn('auth/login');?>" class="login100-form-btn">
          <?=lang('Sign_In')?>
        </a>
      </div>
    </div>
    <div class="login100-more" style="background-image: url('<?=BASE?>assets/images/bg-01.jpg');background-size: auto;background-repeat: no-repeat;background-position: center left;"></div>
  </div>
</div>