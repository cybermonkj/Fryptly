
<?php

  if (isset($_COOKIE["cookie_email"])) {
    $cookie_email = encrypt_decode($_COOKIE["cookie_email"]);
  }

  if (isset($_COOKIE["cookie_pass"])) {
    $cookie_pass = encrypt_decode($_COOKIE["cookie_pass"]);
  }

?>

<div class="limiter">
  <div class="container-login100">
    <div class="wrap-login100 p-l-50 p-r-50 p-t-72 p-b-50">

      <form class="login100-form validate-form" action="<?=cn('auth/ajax_login')?>" method="POST">
        <span class="login100-form-title">
          <a href="<?=cn()?>" class="website_brand_logo">
            <img src="<?=getOption('website_brand_logo', BASE.'assets/images/logo.png')?>">
          </a>
        </span>

        <div class="wrap-input100 validate-input" data-validate = "<?=lang("Invalid_email_format")?>">
          <input class="input100" type="text" name="email" placeholder="<?=lang('Email')?>" value="<?=(isset($cookie_email) && $cookie_email != "") ? $cookie_email : ""?>">
          <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate = "<?=lang("Password_is_required")?>">
          <input class="input100" type="password" name="password" placeholder="<?=lang('Password')?>" value="<?=(isset($cookie_pass) && $cookie_pass != "") ? $cookie_pass : ""?>">
          <span class="focus-input100"></span>
        </div>
        

        <div class="flex-sb-m w-full p-t-3 p-b-32">
    			<div class="contact100-form-checkbox">
    				<input class="input-checkbox100" id="ckb1" type="checkbox" name="remember" <?=(isset($cookie_email) && $cookie_email != "") ? "checked" : ""?>>
    				<label class="label-checkbox100" for="ckb1">
    					<?=lang("remember_me")?>
    				</label>
    			</div>

    			<div>
    				<a href="<?=cn('auth/forgot_password')?>" class="txt1">
    					<?=lang("forgot_password")?>
    				</a>
    			</div>
    		</div>

        <div class="container-login100-form-btn">
          <div class="wrap-login100-form-btn">
            <div class="login100-form-bgbtn"></div>
            <a href="javascript:void(0)" class="btnUserLogin login100-form-btn">
              <?=lang('Sign_In')?>
            </a>
          </div>

          <a href="<?=cn('auth/signup')?>" class="dis-block txt3 hov1 p-r-30 p-t-10 p-b-10 p-l-30">
            <?=lang('Register')?>
            <i class="fa fa-long-arrow-right m-l-5"></i>
          </a>
        </div>
      </form>
    </div>
    <div class="login100-more" style="background-image: url('<?=BASE?>assets/images/bg-01.jpg');background-size: auto;background-repeat: no-repeat;background-position: center left;"></div>
  </div>
</div>