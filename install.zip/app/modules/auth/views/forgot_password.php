
<?php

  if (isset($_COOKIE["cookie_email"])) {
    $cookie_email = encrypt_decode($_COOKIE["cookie_email"]);
  }

  if (isset($_COOKIE["cookie_pass"])) {
    $cookie_pass = encrypt_decode($_COOKIE["cookie_pass"]);
  }

?>

<div class="limiter">
  <div class="container-login100">
    <div class="wrap-login100 p-l-50 p-r-50 p-t-72 p-b-50">

      <form class="login100-form validate-form" action="<?=cn('auth/ajax_forgot_password')?>" method="POST">
        <span class="login100-form-title">
          <a href="<?=cn()?>" class="website_brand_logo">
            <img src="<?=getOption('website_brand_logo', BASE.'assets/images/logo.png')?>">
          </a>
        </span>
		
    		<div class="text-center p-b-30">
    			<p class="text-muted desc"><?=lang("enter_your_registration_email_address_to_receive_password_reset_instructions")?></p>
    		</div>

        <div class="wrap-input100 validate-input" data-validate = "<?=lang("Invalid_email_format")?>">
          <input class="input100" type="text" name="email" placeholder="<?=lang('Email')?>" value="<?=(isset($cookie_email) && $cookie_email != "") ? $cookie_email : ""?>">
          <span class="focus-input100"></span>
        </div>

        <div class="container-login100-form-btn">
          <div class="wrap-login100-form-btn">
            <div class="login100-form-bgbtn"></div>
            <a href="javascript:void(0)" class="btnUserLogin login100-form-btn">
              <?=lang('Submit')?>
            </a>
          </div>

          <a href="<?=cn('auth/signup')?>" class="dis-block txt3 hov1 p-r-30 p-t-10 p-b-10 p-l-30">
            <?=lang('Register')?>
            <i class="fa fa-long-arrow-right m-l-5"></i>
          </a>
        </div>
      </form>
    </div>
    <div class="login100-more" style="background-image: url('<?=BASE?>assets/images/bg-01.jpg');background-size: auto;background-repeat: no-repeat;background-position: center left;"></div>
  </div>
</div>