<form class="actionForm" action="<?=cn('settings/ajax_update')?>" method="POST" data-redirect="<?php echo get_current_url(); ?>">
  <div class="card">
    <div class="card-header">
      <h5 class="title">Default Settings</h5>
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-12">
          <div class="item">
            <h6 class="text-blue mb-3"><i class="fa feather icon-link"></i> <?=lang("history_logs")?></h6>
            <label class="small-text"><?=lang("clear_the_job_history_log_affer_x_days")?></label>
            <div class="row">
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <select class="form-control" name="default_save_logs">
                    <?php
                      for ($i=1; $i <= 30; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('default_save_logs', 5)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>
            </div>
          </div>
          
          <div class="row">

            <div class="col-md-4">
              <h6 class="text-blue"><i class="fa feather icon-link"></i> Disable Langding Page</h6>
              <div class="custom-controls-stacked mb-3">
                <label class="custom-control custom-checkbox">
                  <input type="hidden" name="disable_langding_page" value="0">
                  <input type="checkbox" class="custom-control-input" name="disable_langding_page" value="1" <?=(getOption('disable_langding_page', 0) == 1)? "checked" : ''?>>
                  <span class="custom-control-label"> Active</span>
                </label>
              </div> 
            </div>

            <div class="col-md-4">
              <h6 class="text-blue"><i class="fa feather icon-link"></i> Disable Register Option</h6>
              <div class="custom-controls-stacked mb-3">
                <label class="custom-control custom-checkbox">
                  <input type="hidden" name="disable_register" value="0">
                  <input type="checkbox" class="custom-control-input" name="disable_register" value="1" <?=(getOption('disable_register', 0) == 1)? "checked" : ''?>>
                  <span class="custom-control-label"> Active</span>
                </label>
              </div> 
            </div>

          </div>

          <div class="item">
            <h6 class="text-blue mb-3"><i class="fa feather icon-link"></i> <?=lang("default_speed")?></h6>
            <label class="pb-10"><?=lang("follow_speed_requests_hour")?></label>
            <div class="row">
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('auto')?></label>
                  <select class="form-control" name="follow_speed_auto">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('follow_speed_auto', 5)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('slow')?></label>
                  <select class="form-control" name="follow_speed_slow">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('follow_speed_slow', 3)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('medium')?></label>
                  <select class="form-control" name="follow_speed_medium">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('follow_speed_medium', 4)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('fast')?></label>
                  <select class="form-control" name="follow_speed_fast">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('follow_speed_fast', 8)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>
            </div>

            <label class="pb-10"><?=lang("unfollow_speed_requests_hour")?></label>
            <div class="row">
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('auto')?></label>
                  <select class="form-control" name="unfollow_speed_auto">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('unfollow_speed_auto', 5)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('slow')?></label>
                  <select class="form-control" name="unfollow_speed_slow">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('unfollow_speed_slow', 3)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('medium')?></label>
                  <select class="form-control" name="unfollow_speed_medium">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('unfollow_speed_medium', 4)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('fast')?></label>
                  <select class="form-control" name="unfollow_speed_fast">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('unfollow_speed_fast', 8)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>
            </div>
            
            <label class="pb-10"><?=lang("like_speed_requests_hour")?></label>
            <div class="row">
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('auto')?></label>
                  <select class="form-control" name="like_speed_auto">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('like_speed_auto', 5)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('slow')?></label>
                  <select class="form-control" name="like_speed_slow">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('like_speed_slow', 3)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('medium')?></label>
                  <select class="form-control" name="like_speed_medium">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('like_speed_medium', 4)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('fast')?></label>
                  <select class="form-control" name="like_speed_fast">
                    <?php
                      for ($i=1; $i <= 20; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('like_speed_fast', 8)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>
            </div>

            <label class="pb-10"><?=lang("reweet_speed_requests_day")?></label>
            <div class="row">
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('auto')?></label>
                  <select class="form-control" name="reweet_speed_auto">
                    <?php
                      for ($i=1; $i <= 10; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('reweet_speed_auto', 2)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('slow')?></label>
                  <select class="form-control" name="reweet_speed_slow">
                    <?php
                      for ($i=1; $i <= 10; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('reweet_speed_slow', 1)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('medium')?></label>
                  <select class="form-control" name="reweet_speed_medium">
                    <?php
                      for ($i=1; $i <= 10; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('reweet_speed_medium', 2)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('fast')?></label>
                  <select class="form-control" name="reweet_speed_fast">
                    <?php
                      for ($i=1; $i <= 10; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('reweet_speed_fast', 3)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>
            </div>

            <label class="pb-10"><?=lang("direct_messages_speed_requests_hour")?></label>
            <div class="row">
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('auto')?></label>
                  <select class="form-control" name="direct_messages_speed_auto">
                    <?php
                      for ($i=1; $i <= 10; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('direct_messages_speed_auto', 2)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('slow')?></label>
                  <select class="form-control" name="direct_messages_speed_slow">
                    <?php
                      for ($i=1; $i <= 10; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('direct_messages_speed_slow', 1)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('medium')?></label>
                  <select class="form-control" name="direct_messages_speed_medium">
                    <?php
                      for ($i=1; $i <= 10; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('direct_messages_speed_medium', 2)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>                      
              <div class="ol-xl-2 col-lg-2 col-md-2 col-sm-4">
                <div class="form-group">
                  <label class="small-text"><?=lang('fast')?></label>
                  <select class="form-control" name="direct_messages_speed_fast">
                    <?php
                      for ($i=1; $i <= 10; $i++) { 
                    ?>
                    <option value="<?=$i?>" <?=getOption('direct_messages_speed_fast', 3)==$i?"selected":""?>><?=$i?></option>
                    <?php }?>
                  </select>
                </div>
              </div>
            </div>

          </div>
          <div class="col-md-8">
            <p class="font-14 pt-10 text-light-orange"><strong><?=lang('Note')?></strong> <?=lang("to_avoid_being_rate_limited_requests_from_twitter_api_recommend_you_should_set_up_in_the_normal_speed_dont_use_auto_module_in_the_high_speed_and_dont_use_this_script_for_spamming")?></p>
          </div>
          
          <div class="col-md-3">
            <button type="submit" class="btn btn-primary btn-lg btn-block"><?=lang('Save')?></button>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>

    </div>
  </div>
</form>
