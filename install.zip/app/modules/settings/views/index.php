  
  <style>
    .settings ul.list-unstyled li > a:hover{
      color: #b66dff;
    } 

    .settings ul.list-unstyled li > a.active{
      background: linear-gradient(to right, #da8cff, #9a55ff);
      -webkit-box-shadow: 0 0 10px 1px rgba(115,103,240,.7);
      box-shadow: 0 0 10px 1px rgba(115,103,240,.7);
      color: white;
    }

  </style>
  <div class="min-height-200px settings">
    <div class="row">
      <div class="col-md-2 mb-4">
        <div class="item mt-2">

          <h6 class="title"><?php echo lang("general_settings"); ?></h6>
          <ul class="list-unstyled list-group list-group-transparent mt-1">

            <li><a href="<?php echo cn(); ?>settings/website_settings" class="list-group-item list-group-item-action <?php echo (segment(2) == 'website_settings') ? 'active' : ''; ?>"><?php echo lang("website_setting"); ?></a></li>

            <li><a href="<?php echo cn(); ?>settings/default_settings" class="list-group-item list-group-item-action <?php echo (segment(2) == 'default_settings') ? 'active' : ''; ?>"> <?=lang("default_settings")?></a></li>

            <li><a href="<?php echo cn(); ?>settings/other" class="list-group-item list-group-item-action <?php echo (segment(2) == 'other') ? 'active' : ''; ?>"><?php echo lang("other"); ?></a></li>

          </ul>

          <h6 class="title mt-2"><?php echo lang("Email"); ?></h6>
          <ul class="list-unstyled list-group list-group-transparent mt-1">

            <li><a href="<?php echo cn(); ?>settings/email_smtp" class="list-group-item list-group-item-action <?php echo (segment(2) == 'email_smtp') ? 'active' : ''; ?>">SMTP</a></li>

            <li><a href="<?php echo cn(); ?>settings/email_template" class="list-group-item list-group-item-action <?php echo (segment(2) == 'email_template') ? 'active' : ''; ?>"> <?php echo lang("email_template"); ?></a></li>

          </ul>

          <h6 class="title mt-3"><?php echo lang("integrations"); ?></h6>
          <ul class="list-unstyled list-group list-group-transparent mt-1">

            <li><a href="<?php echo cn(); ?>settings/twitter" class="list-group-item list-group-item-action <?php echo (segment(2) == 'twitter') ? 'active' : ''; ?>"><?php echo lang("twitter_integration"); ?></a></li>
            <?php
              if (table_exists(TRANSACTION_LOGS)) {
            ?>
            <li><a href="<?php echo cn(); ?>settings/payments" class="list-group-item list-group-item-action <?php echo (segment(2) == 'payments') ? 'active' : ''; ?>"><?php echo lang("payments_integration"); ?></a></li>
            <?php } ?>
          </ul>

          <h6 class="title mt-3">About</h6>
          <ul class="list-unstyled list-group list-group-transparent mt-1">
            <li><a href="<?php echo cn(); ?>settings/module" class="list-group-item list-group-item-action <?php echo (segment(2) == 'module') ? 'active' : ''; ?>"><?php echo lang("check_for_updates"); ?></a></li>
          </ul>
        </div>
      </div>

      <div class="col-md-10">
        <?php
          $data = array(
            "module" => "settings",
          );
          $this->load->view($tab, $data);
        ?>
      </div>      
    </div>
  </div>
