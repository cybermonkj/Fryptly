<form class="actionForm" action="<?=cn('settings/ajax_update')?>" method="POST" data-redirect="<?php echo get_current_url(); ?>">
  <div class="card">
    <div class="card-header">
      <h5 class="title">Twitter Integration</h5>
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label class="weight-500"><?=lang('Consumer_key')?></label>
            <input class="form-control" name="twitter_consumer_key" value="<?=getOption('twitter_consumer_key','')?>" type="text" >
          </div>
          
          <div class="form-group">
            <label class="weight-500"><?=lang('Secret_key')?></label>
            <input class="form-control" name="twitter_secret_key" value="<?=getOption('twitter_secret_key','')?>" type="text" >
          </div>
          
          <div class="row">
            <div class="col-md-6">
              <button type="submit" class="btn btn-primary btn-lg btn-block"><?=lang('Save')?></button>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>

    </div>
  </div>
</form>
