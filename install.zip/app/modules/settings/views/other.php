<form class="actionForm" action="<?=cn('settings/ajax_update')?>" method="POST" data-redirect="<?php echo get_current_url(); ?>">
  <div class="card">
    <div class="card-header">
      <h5 class="title"><?php echo lang('Other'); ?></h5>
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <h6 class="text-blue mb-3"><i class="fa feather icon-link"></i> <?=lang("enable_https")?></h6>
          <div class="form-group">
            <div class="custom-control custom-checkbox mb-5">
              <input type="hidden" name="enable_https" value="0">
              <input type="checkbox" class="custom-control-input enable_schedule" id="customCheck1" name="enable_https" <?=(getOption("enable_https", 0) == 1) ? "checked" : ""?> value="1">
              <label class="custom-control-label" for="customCheck1"><?=lang("Active")?></label>
            </div>
            <small class="text-danger"><strong><?=lang("note")?></strong> <?=lang("note_please_make_sure_the_ssl_certificate_has_the_active_status_in_your_hosting_before__you_activate")?></small>
          </div>

          <h6 class="text-blue mb-3"><i class="fa feather icon-link"></i> <?=lang("social_media_links")?></h6>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("Facebook")?></label>
                <input class="form-control" name="social_facebook_link" value="<?=getOption('social_facebook_link',"https://www.facebook.com/")?>">
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("Instagram")?></label>
                <input class="form-control" name="social_instagram_link" value="<?=getOption('social_instagram_link',"https://www.instagram.com/")?>">
              </div> 
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("Twitter")?></label>
                <input class="form-control" name="social_twitter_link" value="<?=getOption('social_twitter_link',"https://twitter.com/")?>">
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label">Youtube</label>
                <input class="form-control" name="social_youtube_link" value="<?=getOption('social_youtube_link',"https://youtube.com/")?>">
              </div>
            </div>

          </div>
          
          <h6 class="text-blue mb-3"><i class="fa feather icon-link"></i> <?=lang("contact_informations")?></h6>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("Tel")?></label>
                <input class="form-control" name="contact_tel" value="<?=getOption('contact_tel',"+12345678")?>">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("Email")?></label>
                <input class="form-control" name="contact_email" value="<?=getOption('contact_email',"do-not-reply@tweetpost.com")?>">
              </div> 
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("working_hour")?></label>
                <input class="form-control" name="contact_work_hour" value="<?=getOption('contact_work_hour',"Mon - Sat 09 am - 10 pm")?>">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <button type="submit" class="btn btn-primary btn-lg btn-block"><?=lang('Save')?></button>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>

    </div>
  </div>
</form>
