<div class="card">
  <div class="card-header">
    <h5 class="title">Check for Updates</h5>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-md-12">
        <table class="plugins-table">
          <tbody class="js-loadmore-content">
            <?php
              foreach ($scripts as $key => $row) {
                $version = $row->version;
                $purchase_exist = false;
                $check_upgrade  = false;

                foreach ($purchase_code_lists as $key => $purchase_code_item) {
                  if ($row->app_id == $purchase_code_item->pid) {
                    $purchase_exist = true;
                    $version = $purchase_code_item->version;
                    if (version_compare($row->version, $purchase_code_item->version, '>')) {
                      $check_upgrade = true;
                      $purchase_code = $purchase_code_item->purchase_code;
                    }
                  }
                }
            ?>
            <tr class="pd-50">
              <td class="pd-20">
                <a href="<?php echo $row->link; ?>" target="_blank">
                  <img src="<?php echo $row->thumbnail; ?>" alt="Twiiter Post" style="width: 300px;">
                </a>
              </td>
              <td class="pd-20">
                <div class="table-big-text mb-5">
                  <a href="<?php echo $row->link; ?>" target="_blank">
                    <h4><?php echo $row->name; ?></h4>
                  </a>
                </div>
                Version <?php echo $version; ?> | By <a href="<?php echo $row->link; ?>" target="_blank" class="text-blue">TweetPost Team</a>
                <div>
                  <?php
                    if (!$purchase_exist) {
                      echo '<a href="'.$row->link.'" target="_blank" class="btn btn-primary text-white">Buy Now</a>';
                    }else{
                      if ($check_upgrade) {
                        $url = cn($module."/module/ajax_upgrade_module/".$purchase_code);
                        echo '<a href="'.$url.'" class="btn btn-danger text-white ajaxUpgradeVersion"><i class="fe fe-arrow-up"></i>Upgrade to Ver'.$row->version.'</a>';
                      }else{
                        echo '<span class="btn btn-dark text-white">Purchased</span>';
                      }
                    }
                  ?>
                </div>
              </td>
            </tr>   
            <?php }?>
          </tbody>
        </table>
        <div class="clearfix"></div>
      </div>
    </div>

  </div>
</div>
