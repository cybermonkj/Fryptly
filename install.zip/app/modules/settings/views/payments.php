<form class="actionForm" action="<?=cn('settings/ajax_update')?>" method="POST" data-redirect="<?php echo get_current_url(); ?>">
  <div class="card">
    <div class="card-header">
      <h5 class="title">Payments Gateway</h5>
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <h6 class="text-blue mb-3"><i class="fa feather icon-link"></i> <?=lang("currency_setting")?></h6>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label class="form-label"><?=lang("currency_code")?></label>
                <small><?=lang("the_paypal_payments_only_supports_these_currencies")?></small>
                <select  name="currency_code" class="form-control square">
                  <?php 
                    $currency_codes = currency_codes();
                    if(!empty($currency_codes)){
                      foreach ($currency_codes as $key => $row) {
                  ?>
                  <option value="<?=$key?>" <?=(getOption("currency_code", "USD") == $key)? 'selected': ''?>> <?=$key." - ".$row?></option>
                  <?php }}else{?>
                  <option value="USD" selected> USD - United States dollar</option>
                  <?php }?>
                </select>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("currency_decimal_places")?></label>
                <select  name="currency_decimal" class="form-control square">
                  <option value="0" <?=(getOption('currency_decimal',"2") == 0)? 'selected': ''?>> 0</option>
                  <option value="1" <?=(getOption('currency_decimal',"2") == 1)? 'selected': ''?>> 0.0</option>
                  <option value="2" <?=(getOption('currency_decimal',"2") == 2)? 'selected': ''?>> 0.00</option>
                </select>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("currency_symbol")?></label>
                <input class="form-control" name="currency_symbol" value="<?=getOption('currency_symbol',"$")?>">
              </div>
            </div>
          </div>
          <h6 class="text-blue mb-3"><i class="fa feather icon-link"></i> <?=lang("Environment")?></h6>
          <div class="form-group">
            <select  name="payment_environment" class="form-control square">
              <option value="sandbox" <?=(getOption("payment_environment", "sandbox") == 'sandbox')? 'selected': ''?>><?=lang("sandbox_test")?></option>
              <option value="live" <?=(getOption("payment_environment", "sandbox") == 'live')? 'selected': ''?>><?=lang("Live")?></option>
            </select>
          </div>

          <h6 class="text-blue mb-3"><i class="fa feather icon-link"></i> <?=lang("Paypal")?></h6>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label class="form-label"><?=lang("paypal_client_id")?></label>
                <input class="form-control" name="paypal_client_id" value="<?=getOption('paypal_client_id',"")?>">
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label class="form-label"><?=lang("paypal_client_secret")?></label>
                <input class="form-control" name="paypal_client_secret" value="<?=getOption('paypal_client_secret',"")?>">
              </div>
            </div>
          </div>
          <h6 class="text-blue mb-3"><i class="fa feather icon-link"></i> <?=lang("Stripe")?></h6>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label class="form-label"><?=lang("publishable_key")?></label>
                <input class="form-control" name="stripe_publishable_key" value="<?=getOption('stripe_publishable_key',"")?>">
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label class="form-label"><?=lang("secret_key")?></label>
                <input class="form-control" name="stripe_secret_key" value="<?=getOption('stripe_secret_key',"")?>">
              </div>
            </div>
          </div>
          
          <div class="row">
            <div class="col-md-6">
              <button type="submit" class="btn btn-primary btn-lg btn-block"><?=lang('Save')?></button>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>

    </div>
  </div>
</form>
