<form class="actionForm" action="<?=cn('settings/ajax_update')?>" method="POST" data-redirect="<?php echo get_current_url(); ?>">
  <div class="card">
    <div class="card-header">
      <h5 class="title"><?php echo lang("email_settings"); ?></h5>
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <div class="form-label weight-600"><?=lang("email_notifications")?></div>

          <div class="custom-controls-stacked">
            <label class="custom-control custom-checkbox">
              <input type="hidden" name="is_verification_new_account" value="0">
              <input type="checkbox" class="custom-control-input" name="is_verification_new_account" value="1" <?=(getOption('is_verification_new_account', 0) == 1)? "checked" : ''?>>
              <span class="custom-control-label"> <?=lang("email_verification_for_new_customer_accounts_preventing_spam_account")?></span>
            </label>
          </div>  
           
          <div class="custom-controls-stacked">
            <label class="custom-control custom-checkbox">
              <input type="hidden" name="is_welcome_email" value="0">
              <input type="checkbox" class="custom-control-input" name="is_welcome_email" value="1" <?=(getOption('is_welcome_email',"") == 1)? "checked" : ''?>>
              <span class="custom-control-label"><?=lang("new_user_welcome_email")?></span>
            </label>
          </div>     

          <div class="custom-controls-stacked">
            <label class="custom-control custom-checkbox">
              <input type="hidden" name="is_new_user_email" value="0">
              <input type="checkbox" class="custom-control-input" name="is_new_user_email" value="1" <?=(getOption('is_new_user_email',"") == 1)? "checked" : ''?>>
              <span class="custom-control-label"><?=lang("new_user_notification_email")?> <small><?=lang("receive_notification_when_a_new_user_registers_to_the_site")?></small></span>
            </label>
          </div>

          <div class="custom-controls-stacked">
            <label class="custom-control custom-checkbox">
              <input type="hidden" name="is_payment_notice_email" value="0">
              <input type="checkbox" class="custom-control-input" name="is_payment_notice_email" value="1" <?=(getOption('is_payment_notice_email',"") == 1)? "checked" : ''?>>
              <span class="custom-control-label"><?=lang("payment_notification_email")?></span>
            </label>
          </div>

          <div class="form-group">
            <label class="form-label"><?=lang("From")?></label>
            <input class="form-control" name="email_from" value="<?=getOption('email_from',"tweetpost@tweetpost.com")?>">
          </div>  

          <div class="form-group">
            <label class="form-label"><?=lang("your_name")?></label>
            <input class="form-control" name="email_name" value="<?=getOption('email_name',"TweetPost")?>">
          </div>

          <div class="form-group">
            <label class="weight-600"><?=lang("email_protocol")?></label>
            <div class="custom-control custom-radio mb-5">
              <input type="radio" id="customRadio1" name="email_protocol_type" value="php_mail" class="custom-control-input" <?=(getOption('email_protocol_type',"php_mail") == 'php_mail')? "checked" : ''?>>
              <label class="custom-control-label" for="customRadio1"><?=lang("php_mail_function")?></label>
            </div>
            <div class="custom-control custom-radio mb-5">
              <input type="radio" id="customRadio2" name="email_protocol_type" value="smtp" class="custom-control-input" <?=(getOption('email_protocol_type',"php_mail") == 'smtp')? "checked" : ''?>>
              <label class="custom-control-label" for="customRadio2"><?=lang("SMTP")?> <small class="text-muted">(<?=lang("sometime_email_is_going_into__recipients_spam_folders_if_php_mail_function_is_enabled")?>)</small></label>
            </div>
          </div>

          <div class="row smtp-configure  <?=(getOption('email_protocol_type', "php_mail") == 'smtp') ? "" : 'd-none'?>">
            <div class="col-md-12">
              <div class="form-group">
                <label class="form-label"><?=lang("smtp_server")?></label>
                <input class="form-control" name="smtp_server" value="<?=getOption('smtp_server',"")?>">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("smtp_port")?> <small>(25, 465, 587, 2525)</small></label>
                <select  name="smtp_port" class="form-control square">
                  <option value="25" <?=(getOption('smtp_port',"") == '25')? "selected" : ''?>>25</option>
                  <option value="465" <?=(getOption('smtp_port',"") == '465')? "selected" : ''?> >465</option>
                  <option value="587" <?=(getOption('smtp_port',"") == '587')? "selected" : ''?> >587</option>
                  <option value="2525" <?=(getOption('smtp_port',"") == '2525')? "selected" : ''?> >2525</option>
                </select>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("smtp_encryption")?></label>
                <select  name="smtp_encryption" class="form-control square">
                  <option value="none" <?=(getOption('smtp_encryption',"") == 'none')? "selected" : ''?>>None</option>
                  <option value="ssl" <?=(getOption('smtp_encryption',"") == 'ssl')? "selected" : ''?> >SSL</option>
                  <option value="tls" <?=(getOption('smtp_encryption',"") == 'tls')? "selected" : ''?> >TLS</option>
                </select>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("smtp_username")?></label>
                <input class="form-control" name="smtp_username" value="<?=getOption('smtp_username',"")?>">
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label"><?=lang("smtp_password")?></label>
                <input class="form-control" name="smtp_password" value="<?=getOption('smtp_password',"")?>">
              </div>
            </div>

          </div>
          <div class="row">
            <div class="col-md-6">
              <button type="submit" class="btn btn-primary btn-lg btn-block"><?=lang('Save')?></button>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>

    </div>
  </div>
</form>

<script type="text/javascript">
  // Check post type
  $(document).on("change","input[type=radio][name=email_protocol_type]", function(){
    _that = $(this);
    _type = _that.val();
    if(_type == 'smtp'){
      $('.smtp-configure').removeClass('d-none');
    }else{
      $('.smtp-configure').addClass('d-none');
    }
  });
</script>