<form class="actionForm" action="<?=cn('settings/ajax_update')?>" method="POST" data-redirect="<?php echo get_current_url(); ?>">
  <div class="card">
    <div class="card-header">
      <h5 class="title"><?php echo lang('website_setting'); ?></h5>
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-8">
          <div class="form-group">
            <label class="weight-500"><?=lang('Website_title')?></label>
            <input class="form-control" name="website_title" value="<?=getOption('website_title','')?>" type="text" >
          </div>

          <div class="form-group">
            <label class="form-label"><?php echo lang("website_name"); ?></label>
            <input class="form-control" name="website_name" value="<?=getOption('website_name',"TweetPost")?>">
          </div>

          <div class="form-group">
            <label class="weight-500"><?=lang('Website_description')?></label>
            <input class="form-control" name="website_description" value="<?=getOption('website_description','')?>" type="text">
          </div>

          <div class="form-group">
            <label class="weight-500"><?=lang('Website_keykords')?></label>
            <input class="form-control" name="website_keyword" value="<?=getOption('website_keyword','')?>" type="text" >
          </div>

          <div class="form-group">
            <label class="weight-500"><?=lang('Website_Favicon')?></label>
            <div class="input-group">
              <input name="website_favicon" type="text" class="form-control" value="<?=getOption('website_favicon','')?>">
              <span class="input-group-btn">
                  <a href="javascript:void(0)" class="btn  button-item fileinput-button" style="border-radius: 0px; color: white; background: #3e99ff; padding: 13px 16px; " data-toggle="tooltip" data-placement="bottom" title="Upload">
                    <i class="fa fa-folder-open"></i>
                    <input class="settings_fileupload" type="file" name="files[]" multiple>
                  </a>
              </span>
            </div>
          </div>

          <div class="form-group">
            <label class="weight-500"><?=lang('Website_logo')?></label>
            <div class="input-group">
              <input name="website_brand_logo" type="text" class="form-control" value="<?=getOption('website_brand_logo', BASE.'assets/images/logo.png')?>">
              <span class="input-group-btn">
                  <a href="javascript:void(0)" class="btn  button-item fileinput-button" style="border-radius: 0px; color: white; background: #3e99ff; padding: 13px 16px;" data-toggle="tooltip" data-placement="bottom" title="Upload">
                    <i class="fa fa-folder-open"></i>
                    <input class="settings_fileupload" id="" type="file" name="files[]" multiple>
                  </a>
              </span>
            </div>
          </div>

          <div class="form-group">
            <label class="weight-500"><?=lang('Website_brand_logo')?></label>
            <div class="input-group">
              <input name="website_brand_logo_white" type="text" class="form-control" value="<?=getOption("website_brand_logo_white", BASE.'assets/images/logo-white.png')?>">
              <span class="input-group-btn">
                  <a href="javascript:void(0)" class="btn  button-item fileinput-button" style="border-radius: 0px; color: white; background: #3e99ff; padding: 13px 16px;" data-toggle="tooltip" data-placement="bottom" title="Upload">
                    <i class="fa fa-folder-open"></i>
                    <input class="settings_fileupload" id="" type="file" name="files[]" multiple>
                  </a>
              </span>
            </div>
          </div>
`
          <h6 class="text-blue mb-3"><i class="fa fa-link"></i> CopyRight Info</h6>
          <div class="form-group">
            <label class="form-label"><?php echo lang('Content');?></label>
            <input class="form-control" name="copyright_info" value="<?=getOption('copyright_info',"&copy; 2020 - TweetPost")?>">
          </div>
          
          <div class="row">
            <div class="col-md-6">
              <button type="submit" class="btn btn-primary btn-lg btn-block"><?=lang('Save')?></button>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>

    </div>
  </div>
</form>
