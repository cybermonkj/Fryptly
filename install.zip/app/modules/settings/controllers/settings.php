<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class settings extends MX_Controller {
	public $module;
	public $module_icon;
	public $module_name;
	public $module_title;
	public function __construct(){
		parent::__construct();
		$this->module_icon  = 'fa fa-cogs';
		$this->module_name  = 'Settings';
		$this->module = get_class($this);
		$this->load->model(get_class($this).'_model', 'model');
	}

	public function index($tab = ""){
		$path              = APPPATH.'./modules/settings/views/';
		$path_integrations = APPPATH.'./modules/settings/views/integrations/';
		$tabs = array_merge(get_name_of_files_in_dir($path, ['.php']), get_name_of_files_in_dir($path_integrations, ['.php']));
		unset($tabs[array_search('index', $tabs, true)]);
		update_options_status();
		if ($tab == "") {
			$tab = "website_settings";
			redirect(cn('settings/website_settings'));
		}

		if ($tab == 'ajax_update') {
			$this->ajax_update();
		}
		
		if (!in_array($tab, $tabs)) {
			redirect(cn('settings'));
		}

		if ($tab == "module") {
			$data = array(
				"module"    => get_class($this),
				"tab"       => $tab,
			);
			require 'module.php';
			$module = new module();
			$module->get_index($data);
		}else{
			$data = array(
				"module"          => get_class($this),
				"tab"             => $tab,
			);
			$this->template->build('index', $data);
		}

	}


	public function ajax_update(){
		$data = $this->input->post();

		if(is_array($data)){
			foreach ($data as $key => $value) {

				if(in_array($key, ['embed_javascript', 'embed_head_javascript', 'manual_payment_content'])){
					$value = htmlspecialchars(@$_POST[$key], ENT_QUOTES);
				}	

				if ($key == 'coinpayments_acceptance') {
					$value = json_encode($value);
				}
				
				if ($key == 'freekassa_acceptance') {
					$value = json_encode($value);
				}

				if ($key == 'new_currecry_rate') {
					$value = (double)$value;
					if ($value <= 0 ) {
						$value = 1;
					}
				}
				updateOption($key, $value);
			}
		}

		ms(array(
        	"status"  => "success",
        	"message" => lang('Update_successfully')
        ));
		
	}
}