<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-16 14:19:08 --> Config Class Initialized
INFO - 2019-12-16 14:19:08 --> Hooks Class Initialized
DEBUG - 2019-12-16 14:19:08 --> UTF-8 Support Enabled
INFO - 2019-12-16 14:19:08 --> Utf8 Class Initialized
INFO - 2019-12-16 14:19:08 --> URI Class Initialized
DEBUG - 2019-12-16 14:19:08 --> No URI present. Default controller set.
INFO - 2019-12-16 14:19:08 --> Router Class Initialized
INFO - 2019-12-16 14:19:08 --> Output Class Initialized
INFO - 2019-12-16 14:19:08 --> Security Class Initialized
DEBUG - 2019-12-16 14:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-16 14:19:08 --> CSRF cookie sent
INFO - 2019-12-16 14:19:08 --> Input Class Initialized
INFO - 2019-12-16 14:19:08 --> Language Class Initialized
INFO - 2019-12-16 14:19:08 --> Language Class Initialized
INFO - 2019-12-16 14:19:08 --> Config Class Initialized
INFO - 2019-12-16 14:19:08 --> Loader Class Initialized
INFO - 2019-12-16 14:19:09 --> Helper loaded: url_helper
INFO - 2019-12-16 14:19:09 --> Helper loaded: common_helper
INFO - 2019-12-16 14:19:09 --> Helper loaded: language_helper
INFO - 2019-12-16 14:19:09 --> Helper loaded: cookie_helper
INFO - 2019-12-16 14:19:09 --> Helper loaded: email_helper
INFO - 2019-12-16 14:19:09 --> Helper loaded: file_manager_helper
INFO - 2019-12-16 14:19:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-16 14:19:09 --> Parser Class Initialized
INFO - 2019-12-16 14:19:09 --> User Agent Class Initialized
INFO - 2019-12-16 14:19:09 --> Model Class Initialized
INFO - 2019-12-16 14:19:09 --> Database Driver Class Initialized
INFO - 2019-12-16 14:19:09 --> Model Class Initialized
DEBUG - 2019-12-16 14:19:09 --> Template Class Initialized
INFO - 2019-12-16 14:19:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-16 14:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-16 14:19:10 --> Pagination Class Initialized
DEBUG - 2019-12-16 14:19:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-16 14:19:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-16 14:19:10 --> Encryption Class Initialized
DEBUG - 2019-12-16 14:19:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-16 14:19:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-16 14:19:10 --> Controller Class Initialized
DEBUG - 2019-12-16 14:19:10 --> pergo MX_Controller Initialized
DEBUG - 2019-12-16 14:19:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-16 14:19:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-16 14:19:10 --> Model Class Initialized
INFO - 2019-12-16 14:19:10 --> Helper loaded: inflector_helper
DEBUG - 2019-12-16 14:19:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-16 14:19:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-16 14:19:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-16 14:19:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-16 14:19:11 --> Final output sent to browser
DEBUG - 2019-12-16 14:19:11 --> Total execution time: 3.5712
