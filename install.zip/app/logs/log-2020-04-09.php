<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-09 14:48:07 --> Config Class Initialized
INFO - 2020-04-09 14:48:07 --> Hooks Class Initialized
DEBUG - 2020-04-09 14:48:07 --> UTF-8 Support Enabled
INFO - 2020-04-09 14:48:07 --> Utf8 Class Initialized
INFO - 2020-04-09 14:48:08 --> URI Class Initialized
DEBUG - 2020-04-09 14:48:08 --> No URI present. Default controller set.
INFO - 2020-04-09 14:48:08 --> Router Class Initialized
INFO - 2020-04-09 14:48:08 --> Output Class Initialized
INFO - 2020-04-09 14:48:08 --> Security Class Initialized
DEBUG - 2020-04-09 14:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-09 14:48:08 --> CSRF cookie sent
INFO - 2020-04-09 14:48:08 --> Input Class Initialized
INFO - 2020-04-09 14:48:08 --> Language Class Initialized
INFO - 2020-04-09 14:48:08 --> Language Class Initialized
INFO - 2020-04-09 14:48:08 --> Config Class Initialized
INFO - 2020-04-09 14:48:08 --> Loader Class Initialized
INFO - 2020-04-09 14:48:08 --> Helper loaded: url_helper
INFO - 2020-04-09 14:48:08 --> Helper loaded: file_helper
INFO - 2020-04-09 14:48:08 --> Helper loaded: cookie_helper
INFO - 2020-04-09 14:48:08 --> Helper loaded: common_helper
INFO - 2020-04-09 14:48:08 --> Helper loaded: language_helper
INFO - 2020-04-09 14:48:08 --> Helper loaded: email_helper
INFO - 2020-04-09 14:48:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-09 14:48:08 --> Database Driver Class Initialized
INFO - 2020-04-09 14:48:08 --> Parser Class Initialized
INFO - 2020-04-09 14:48:08 --> User Agent Class Initialized
INFO - 2020-04-09 14:48:08 --> Model Class Initialized
INFO - 2020-04-09 14:48:08 --> Model Class Initialized
DEBUG - 2020-04-09 14:48:08 --> Template Class Initialized
INFO - 2020-04-09 14:48:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-09 14:48:08 --> Email Class Initialized
INFO - 2020-04-09 14:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-09 14:48:09 --> Pagination Class Initialized
DEBUG - 2020-04-09 14:48:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-09 14:48:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-09 14:48:09 --> Encryption Class Initialized
INFO - 2020-04-09 14:48:09 --> Controller Class Initialized
DEBUG - 2020-04-09 14:48:09 --> home MX_Controller Initialized
INFO - 2020-04-09 14:48:09 --> Helper loaded: inflector_helper
DEBUG - 2020-04-09 14:48:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-09 14:48:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-09 14:48:09 --> Final output sent to browser
DEBUG - 2020-04-09 14:48:09 --> Total execution time: 1.5380
INFO - 2020-04-09 14:48:16 --> Config Class Initialized
INFO - 2020-04-09 14:48:16 --> Hooks Class Initialized
DEBUG - 2020-04-09 14:48:16 --> UTF-8 Support Enabled
INFO - 2020-04-09 14:48:16 --> Utf8 Class Initialized
INFO - 2020-04-09 14:48:16 --> URI Class Initialized
INFO - 2020-04-09 14:48:16 --> Router Class Initialized
INFO - 2020-04-09 14:48:16 --> Output Class Initialized
INFO - 2020-04-09 14:48:16 --> Security Class Initialized
DEBUG - 2020-04-09 14:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-09 14:48:16 --> CSRF cookie sent
INFO - 2020-04-09 14:48:16 --> Input Class Initialized
INFO - 2020-04-09 14:48:16 --> Language Class Initialized
INFO - 2020-04-09 14:48:16 --> Language Class Initialized
INFO - 2020-04-09 14:48:16 --> Config Class Initialized
INFO - 2020-04-09 14:48:16 --> Loader Class Initialized
INFO - 2020-04-09 14:48:16 --> Helper loaded: url_helper
INFO - 2020-04-09 14:48:16 --> Helper loaded: file_helper
INFO - 2020-04-09 14:48:16 --> Helper loaded: cookie_helper
INFO - 2020-04-09 14:48:16 --> Helper loaded: common_helper
INFO - 2020-04-09 14:48:16 --> Helper loaded: language_helper
INFO - 2020-04-09 14:48:16 --> Helper loaded: email_helper
INFO - 2020-04-09 14:48:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-09 14:48:16 --> Database Driver Class Initialized
INFO - 2020-04-09 14:48:17 --> Parser Class Initialized
INFO - 2020-04-09 14:48:17 --> User Agent Class Initialized
INFO - 2020-04-09 14:48:17 --> Model Class Initialized
INFO - 2020-04-09 14:48:17 --> Model Class Initialized
DEBUG - 2020-04-09 14:48:17 --> Template Class Initialized
INFO - 2020-04-09 14:48:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-09 14:48:17 --> Email Class Initialized
INFO - 2020-04-09 14:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-09 14:48:17 --> Pagination Class Initialized
DEBUG - 2020-04-09 14:48:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-09 14:48:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-09 14:48:17 --> Encryption Class Initialized
INFO - 2020-04-09 14:48:17 --> Controller Class Initialized
DEBUG - 2020-04-09 14:48:17 --> auth MX_Controller Initialized
INFO - 2020-04-09 14:48:17 --> Helper loaded: inflector_helper
DEBUG - 2020-04-09 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-09 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-09 14:48:17 --> Final output sent to browser
DEBUG - 2020-04-09 14:48:17 --> Total execution time: 0.8716
INFO - 2020-04-09 14:48:19 --> Config Class Initialized
INFO - 2020-04-09 14:48:19 --> Hooks Class Initialized
DEBUG - 2020-04-09 14:48:19 --> UTF-8 Support Enabled
INFO - 2020-04-09 14:48:19 --> Utf8 Class Initialized
INFO - 2020-04-09 14:48:19 --> URI Class Initialized
INFO - 2020-04-09 14:48:19 --> Router Class Initialized
INFO - 2020-04-09 14:48:19 --> Output Class Initialized
INFO - 2020-04-09 14:48:19 --> Security Class Initialized
DEBUG - 2020-04-09 14:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-09 14:48:19 --> CSRF cookie sent
INFO - 2020-04-09 14:48:19 --> CSRF token verified
INFO - 2020-04-09 14:48:19 --> Input Class Initialized
INFO - 2020-04-09 14:48:19 --> Language Class Initialized
INFO - 2020-04-09 14:48:19 --> Language Class Initialized
INFO - 2020-04-09 14:48:19 --> Config Class Initialized
INFO - 2020-04-09 14:48:19 --> Loader Class Initialized
INFO - 2020-04-09 14:48:19 --> Helper loaded: url_helper
INFO - 2020-04-09 14:48:19 --> Helper loaded: file_helper
INFO - 2020-04-09 14:48:19 --> Helper loaded: cookie_helper
INFO - 2020-04-09 14:48:19 --> Helper loaded: common_helper
INFO - 2020-04-09 14:48:19 --> Helper loaded: language_helper
INFO - 2020-04-09 14:48:19 --> Helper loaded: email_helper
INFO - 2020-04-09 14:48:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-09 14:48:19 --> Database Driver Class Initialized
INFO - 2020-04-09 14:48:19 --> Parser Class Initialized
INFO - 2020-04-09 14:48:19 --> User Agent Class Initialized
INFO - 2020-04-09 14:48:19 --> Model Class Initialized
INFO - 2020-04-09 14:48:19 --> Model Class Initialized
DEBUG - 2020-04-09 14:48:19 --> Template Class Initialized
INFO - 2020-04-09 14:48:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-09 14:48:19 --> Email Class Initialized
INFO - 2020-04-09 14:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-09 14:48:19 --> Pagination Class Initialized
DEBUG - 2020-04-09 14:48:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-09 14:48:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-09 14:48:19 --> Encryption Class Initialized
INFO - 2020-04-09 14:48:19 --> Controller Class Initialized
DEBUG - 2020-04-09 14:48:19 --> auth MX_Controller Initialized
INFO - 2020-04-09 14:48:22 --> Config Class Initialized
INFO - 2020-04-09 14:48:22 --> Hooks Class Initialized
DEBUG - 2020-04-09 14:48:22 --> UTF-8 Support Enabled
INFO - 2020-04-09 14:48:22 --> Utf8 Class Initialized
INFO - 2020-04-09 14:48:22 --> URI Class Initialized
INFO - 2020-04-09 14:48:22 --> Router Class Initialized
INFO - 2020-04-09 14:48:22 --> Output Class Initialized
INFO - 2020-04-09 14:48:22 --> Security Class Initialized
DEBUG - 2020-04-09 14:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-09 14:48:22 --> CSRF cookie sent
INFO - 2020-04-09 14:48:22 --> Input Class Initialized
INFO - 2020-04-09 14:48:22 --> Language Class Initialized
INFO - 2020-04-09 14:48:22 --> Language Class Initialized
INFO - 2020-04-09 14:48:22 --> Config Class Initialized
INFO - 2020-04-09 14:48:22 --> Loader Class Initialized
INFO - 2020-04-09 14:48:22 --> Helper loaded: url_helper
INFO - 2020-04-09 14:48:22 --> Helper loaded: file_helper
INFO - 2020-04-09 14:48:22 --> Helper loaded: cookie_helper
INFO - 2020-04-09 14:48:22 --> Helper loaded: common_helper
INFO - 2020-04-09 14:48:22 --> Helper loaded: language_helper
INFO - 2020-04-09 14:48:22 --> Helper loaded: email_helper
INFO - 2020-04-09 14:48:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-09 14:48:22 --> Database Driver Class Initialized
INFO - 2020-04-09 14:48:22 --> Parser Class Initialized
INFO - 2020-04-09 14:48:22 --> User Agent Class Initialized
INFO - 2020-04-09 14:48:22 --> Model Class Initialized
INFO - 2020-04-09 14:48:22 --> Model Class Initialized
DEBUG - 2020-04-09 14:48:22 --> Template Class Initialized
INFO - 2020-04-09 14:48:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-09 14:48:22 --> Email Class Initialized
INFO - 2020-04-09 14:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-09 14:48:22 --> Pagination Class Initialized
DEBUG - 2020-04-09 14:48:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-09 14:48:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-09 14:48:22 --> Encryption Class Initialized
INFO - 2020-04-09 14:48:22 --> Controller Class Initialized
DEBUG - 2020-04-09 14:48:22 --> dashboard MX_Controller Initialized
INFO - 2020-04-09 14:48:22 --> Model Class Initialized
DEBUG - 2020-04-09 14:48:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-09 14:48:22 --> Model Class Initialized
INFO - 2020-04-09 14:48:22 --> Helper loaded: inflector_helper
DEBUG - 2020-04-09 14:48:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-09 14:48:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-09 14:48:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-09 14:48:23 --> blocks MX_Controller Initialized
DEBUG - 2020-04-09 14:48:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-09 14:48:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-09 14:48:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-09 14:48:26 --> Final output sent to browser
DEBUG - 2020-04-09 14:48:26 --> Total execution time: 3.6550
INFO - 2020-04-09 16:03:02 --> Config Class Initialized
INFO - 2020-04-09 16:03:02 --> Hooks Class Initialized
DEBUG - 2020-04-09 16:03:02 --> UTF-8 Support Enabled
INFO - 2020-04-09 16:03:02 --> Utf8 Class Initialized
INFO - 2020-04-09 16:03:02 --> URI Class Initialized
DEBUG - 2020-04-09 16:03:02 --> No URI present. Default controller set.
INFO - 2020-04-09 16:03:02 --> Router Class Initialized
INFO - 2020-04-09 16:03:02 --> Output Class Initialized
INFO - 2020-04-09 16:03:02 --> Security Class Initialized
DEBUG - 2020-04-09 16:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-09 16:03:02 --> CSRF cookie sent
INFO - 2020-04-09 16:03:02 --> Input Class Initialized
INFO - 2020-04-09 16:03:02 --> Language Class Initialized
INFO - 2020-04-09 16:03:03 --> Language Class Initialized
INFO - 2020-04-09 16:03:03 --> Config Class Initialized
INFO - 2020-04-09 16:03:03 --> Loader Class Initialized
INFO - 2020-04-09 16:03:03 --> Helper loaded: url_helper
INFO - 2020-04-09 16:03:03 --> Helper loaded: file_helper
INFO - 2020-04-09 16:03:03 --> Helper loaded: cookie_helper
INFO - 2020-04-09 16:03:03 --> Helper loaded: common_helper
INFO - 2020-04-09 16:03:03 --> Helper loaded: language_helper
INFO - 2020-04-09 16:03:03 --> Helper loaded: email_helper
INFO - 2020-04-09 16:03:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-09 16:03:03 --> Database Driver Class Initialized
ERROR - 2020-04-09 16:03:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\projects\tuyen\twitter\code\app\core\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-04-09 16:03:07 --> Unable to connect to the database
INFO - 2020-04-09 16:03:07 --> Language file loaded: language/english/db_lang.php
INFO - 2020-04-09 16:03:17 --> Config Class Initialized
INFO - 2020-04-09 16:03:17 --> Hooks Class Initialized
DEBUG - 2020-04-09 16:03:17 --> UTF-8 Support Enabled
INFO - 2020-04-09 16:03:17 --> Utf8 Class Initialized
INFO - 2020-04-09 16:03:17 --> URI Class Initialized
DEBUG - 2020-04-09 16:03:17 --> No URI present. Default controller set.
INFO - 2020-04-09 16:03:17 --> Router Class Initialized
INFO - 2020-04-09 16:03:17 --> Output Class Initialized
INFO - 2020-04-09 16:03:17 --> Security Class Initialized
DEBUG - 2020-04-09 16:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-09 16:03:17 --> CSRF cookie sent
INFO - 2020-04-09 16:03:17 --> Input Class Initialized
INFO - 2020-04-09 16:03:17 --> Language Class Initialized
INFO - 2020-04-09 16:03:17 --> Language Class Initialized
INFO - 2020-04-09 16:03:17 --> Config Class Initialized
INFO - 2020-04-09 16:03:17 --> Loader Class Initialized
INFO - 2020-04-09 16:03:17 --> Helper loaded: url_helper
INFO - 2020-04-09 16:03:17 --> Helper loaded: file_helper
INFO - 2020-04-09 16:03:17 --> Helper loaded: cookie_helper
INFO - 2020-04-09 16:03:17 --> Helper loaded: common_helper
INFO - 2020-04-09 16:03:17 --> Helper loaded: language_helper
INFO - 2020-04-09 16:03:17 --> Helper loaded: email_helper
INFO - 2020-04-09 16:03:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-09 16:03:17 --> Database Driver Class Initialized
INFO - 2020-04-09 16:03:17 --> Parser Class Initialized
INFO - 2020-04-09 16:03:18 --> User Agent Class Initialized
INFO - 2020-04-09 16:03:18 --> Model Class Initialized
INFO - 2020-04-09 16:03:18 --> Model Class Initialized
DEBUG - 2020-04-09 16:03:18 --> Template Class Initialized
INFO - 2020-04-09 16:03:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-09 16:03:18 --> Email Class Initialized
INFO - 2020-04-09 16:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-09 16:03:18 --> Pagination Class Initialized
DEBUG - 2020-04-09 16:03:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-09 16:03:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-09 16:03:18 --> Encryption Class Initialized
INFO - 2020-04-09 16:03:18 --> Controller Class Initialized
DEBUG - 2020-04-09 16:03:18 --> home MX_Controller Initialized
INFO - 2020-04-09 16:03:18 --> Model Class Initialized
INFO - 2020-04-09 16:03:18 --> Config Class Initialized
INFO - 2020-04-09 16:03:18 --> Hooks Class Initialized
DEBUG - 2020-04-09 16:03:18 --> UTF-8 Support Enabled
INFO - 2020-04-09 16:03:18 --> Utf8 Class Initialized
INFO - 2020-04-09 16:03:18 --> URI Class Initialized
INFO - 2020-04-09 16:03:18 --> Router Class Initialized
INFO - 2020-04-09 16:03:18 --> Output Class Initialized
INFO - 2020-04-09 16:03:18 --> Security Class Initialized
DEBUG - 2020-04-09 16:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-09 16:03:18 --> CSRF cookie sent
INFO - 2020-04-09 16:03:18 --> Input Class Initialized
INFO - 2020-04-09 16:03:18 --> Language Class Initialized
INFO - 2020-04-09 16:03:18 --> Language Class Initialized
INFO - 2020-04-09 16:03:18 --> Config Class Initialized
INFO - 2020-04-09 16:03:18 --> Loader Class Initialized
INFO - 2020-04-09 16:03:18 --> Helper loaded: url_helper
INFO - 2020-04-09 16:03:18 --> Helper loaded: file_helper
INFO - 2020-04-09 16:03:18 --> Helper loaded: cookie_helper
INFO - 2020-04-09 16:03:18 --> Helper loaded: common_helper
INFO - 2020-04-09 16:03:18 --> Helper loaded: language_helper
INFO - 2020-04-09 16:03:18 --> Helper loaded: email_helper
INFO - 2020-04-09 16:03:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-09 16:03:18 --> Database Driver Class Initialized
INFO - 2020-04-09 16:03:18 --> Parser Class Initialized
INFO - 2020-04-09 16:03:18 --> User Agent Class Initialized
INFO - 2020-04-09 16:03:18 --> Model Class Initialized
INFO - 2020-04-09 16:03:18 --> Model Class Initialized
DEBUG - 2020-04-09 16:03:18 --> Template Class Initialized
INFO - 2020-04-09 16:03:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-09 16:03:18 --> Email Class Initialized
INFO - 2020-04-09 16:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-09 16:03:18 --> Pagination Class Initialized
DEBUG - 2020-04-09 16:03:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-09 16:03:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-09 16:03:18 --> Encryption Class Initialized
INFO - 2020-04-09 16:03:18 --> Controller Class Initialized
DEBUG - 2020-04-09 16:03:18 --> twitter MX_Controller Initialized
INFO - 2020-04-09 16:03:18 --> Model Class Initialized
DEBUG - 2020-04-09 16:03:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-09 16:03:19 --> Model Class Initialized
DEBUG - 2020-04-09 16:03:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-09 16:03:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-09 16:03:19 --> blocks MX_Controller Initialized
DEBUG - 2020-04-09 16:03:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-09 16:03:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-09 16:03:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-09 16:03:20 --> Final output sent to browser
DEBUG - 2020-04-09 16:03:20 --> Total execution time: 2.1498
