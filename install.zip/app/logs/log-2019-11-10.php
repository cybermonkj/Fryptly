<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-10 11:29:47 --> Config Class Initialized
INFO - 2019-11-10 11:29:47 --> Hooks Class Initialized
DEBUG - 2019-11-10 11:29:47 --> UTF-8 Support Enabled
INFO - 2019-11-10 11:29:47 --> Utf8 Class Initialized
INFO - 2019-11-10 11:29:47 --> URI Class Initialized
INFO - 2019-11-10 11:29:47 --> Router Class Initialized
INFO - 2019-11-10 11:29:47 --> Output Class Initialized
INFO - 2019-11-10 11:29:47 --> Security Class Initialized
DEBUG - 2019-11-10 11:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-10 11:29:47 --> CSRF cookie sent
INFO - 2019-11-10 11:29:47 --> Input Class Initialized
INFO - 2019-11-10 11:29:47 --> Language Class Initialized
INFO - 2019-11-10 11:29:47 --> Language Class Initialized
INFO - 2019-11-10 11:29:47 --> Config Class Initialized
INFO - 2019-11-10 11:29:47 --> Loader Class Initialized
INFO - 2019-11-10 11:29:47 --> Helper loaded: url_helper
INFO - 2019-11-10 11:29:47 --> Helper loaded: common_helper
INFO - 2019-11-10 11:29:47 --> Helper loaded: language_helper
INFO - 2019-11-10 11:29:47 --> Helper loaded: cookie_helper
INFO - 2019-11-10 11:29:48 --> Helper loaded: email_helper
INFO - 2019-11-10 11:29:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-10 11:29:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-10 11:29:48 --> Parser Class Initialized
INFO - 2019-11-10 11:29:48 --> User Agent Class Initialized
INFO - 2019-11-10 11:29:48 --> Model Class Initialized
INFO - 2019-11-10 11:29:48 --> Database Driver Class Initialized
INFO - 2019-11-10 11:29:48 --> Model Class Initialized
DEBUG - 2019-11-10 11:29:48 --> Template Class Initialized
INFO - 2019-11-10 11:29:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-10 11:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-10 11:29:48 --> Pagination Class Initialized
DEBUG - 2019-11-10 11:29:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-10 11:29:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-10 11:29:48 --> Encryption Class Initialized
INFO - 2019-11-10 11:29:48 --> Controller Class Initialized
DEBUG - 2019-11-10 11:29:48 --> auth MX_Controller Initialized
DEBUG - 2019-11-10 11:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-10 11:29:48 --> Model Class Initialized
DEBUG - 2019-11-10 11:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-10 11:29:48 --> Helper loaded: inflector_helper
DEBUG - 2019-11-10 11:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-10 11:29:48 --> pergo MX_Controller Initialized
DEBUG - 2019-11-10 11:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-10 11:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-10 11:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-10 11:29:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-10 11:29:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-10 11:29:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-10 11:29:49 --> Final output sent to browser
DEBUG - 2019-11-10 11:29:49 --> Total execution time: 1.8047
INFO - 2019-11-10 11:30:18 --> Config Class Initialized
INFO - 2019-11-10 11:30:18 --> Hooks Class Initialized
DEBUG - 2019-11-10 11:30:18 --> UTF-8 Support Enabled
INFO - 2019-11-10 11:30:18 --> Utf8 Class Initialized
INFO - 2019-11-10 11:30:18 --> URI Class Initialized
INFO - 2019-11-10 11:30:18 --> Router Class Initialized
INFO - 2019-11-10 11:30:18 --> Output Class Initialized
INFO - 2019-11-10 11:30:19 --> Security Class Initialized
DEBUG - 2019-11-10 11:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-10 11:30:19 --> CSRF cookie sent
INFO - 2019-11-10 11:30:19 --> CSRF token verified
INFO - 2019-11-10 11:30:19 --> Input Class Initialized
INFO - 2019-11-10 11:30:19 --> Language Class Initialized
INFO - 2019-11-10 11:30:19 --> Language Class Initialized
INFO - 2019-11-10 11:30:19 --> Config Class Initialized
INFO - 2019-11-10 11:30:19 --> Loader Class Initialized
INFO - 2019-11-10 11:30:19 --> Helper loaded: url_helper
INFO - 2019-11-10 11:30:19 --> Helper loaded: common_helper
INFO - 2019-11-10 11:30:19 --> Helper loaded: language_helper
INFO - 2019-11-10 11:30:19 --> Helper loaded: cookie_helper
INFO - 2019-11-10 11:30:19 --> Helper loaded: email_helper
INFO - 2019-11-10 11:30:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-10 11:30:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-10 11:30:19 --> Parser Class Initialized
INFO - 2019-11-10 11:30:19 --> User Agent Class Initialized
INFO - 2019-11-10 11:30:19 --> Model Class Initialized
INFO - 2019-11-10 11:30:19 --> Database Driver Class Initialized
INFO - 2019-11-10 11:30:19 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:19 --> Template Class Initialized
INFO - 2019-11-10 11:30:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-10 11:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-10 11:30:19 --> Pagination Class Initialized
DEBUG - 2019-11-10 11:30:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-10 11:30:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-10 11:30:19 --> Encryption Class Initialized
INFO - 2019-11-10 11:30:19 --> Controller Class Initialized
DEBUG - 2019-11-10 11:30:19 --> auth MX_Controller Initialized
DEBUG - 2019-11-10 11:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-10 11:30:19 --> Model Class Initialized
INFO - 2019-11-10 11:30:23 --> Config Class Initialized
INFO - 2019-11-10 11:30:23 --> Hooks Class Initialized
DEBUG - 2019-11-10 11:30:23 --> UTF-8 Support Enabled
INFO - 2019-11-10 11:30:24 --> Utf8 Class Initialized
INFO - 2019-11-10 11:30:24 --> URI Class Initialized
INFO - 2019-11-10 11:30:24 --> Router Class Initialized
INFO - 2019-11-10 11:30:24 --> Output Class Initialized
INFO - 2019-11-10 11:30:24 --> Security Class Initialized
DEBUG - 2019-11-10 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-10 11:30:24 --> CSRF cookie sent
INFO - 2019-11-10 11:30:24 --> Input Class Initialized
INFO - 2019-11-10 11:30:24 --> Language Class Initialized
INFO - 2019-11-10 11:30:24 --> Language Class Initialized
INFO - 2019-11-10 11:30:24 --> Config Class Initialized
INFO - 2019-11-10 11:30:24 --> Loader Class Initialized
INFO - 2019-11-10 11:30:24 --> Helper loaded: url_helper
INFO - 2019-11-10 11:30:24 --> Helper loaded: common_helper
INFO - 2019-11-10 11:30:24 --> Helper loaded: language_helper
INFO - 2019-11-10 11:30:24 --> Helper loaded: cookie_helper
INFO - 2019-11-10 11:30:24 --> Helper loaded: email_helper
INFO - 2019-11-10 11:30:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-10 11:30:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-10 11:30:24 --> Parser Class Initialized
INFO - 2019-11-10 11:30:24 --> User Agent Class Initialized
INFO - 2019-11-10 11:30:24 --> Model Class Initialized
INFO - 2019-11-10 11:30:24 --> Database Driver Class Initialized
INFO - 2019-11-10 11:30:24 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:24 --> Template Class Initialized
INFO - 2019-11-10 11:30:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-10 11:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-10 11:30:24 --> Pagination Class Initialized
DEBUG - 2019-11-10 11:30:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-10 11:30:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-10 11:30:24 --> Encryption Class Initialized
INFO - 2019-11-10 11:30:24 --> Controller Class Initialized
DEBUG - 2019-11-10 11:30:24 --> statistics MX_Controller Initialized
DEBUG - 2019-11-10 11:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-10 11:30:24 --> Model Class Initialized
ERROR - 2019-11-10 11:30:24 --> Could not find the language line "Pending"
ERROR - 2019-11-10 11:30:24 --> Could not find the language line "Pending"
INFO - 2019-11-10 11:30:24 --> Helper loaded: inflector_helper
ERROR - 2019-11-10 11:30:24 --> Could not find the language line "total_orders"
ERROR - 2019-11-10 11:30:24 --> Could not find the language line "total_orders"
ERROR - 2019-11-10 11:30:24 --> Could not find the language line "Pending"
DEBUG - 2019-11-10 11:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-10 11:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-10 11:30:24 --> blocks MX_Controller Initialized
DEBUG - 2019-11-10 11:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-10 11:30:24 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-10 11:30:24 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-10 11:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-10 11:30:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-10 11:30:25 --> Final output sent to browser
DEBUG - 2019-11-10 11:30:25 --> Total execution time: 1.0546
INFO - 2019-11-10 11:30:33 --> Config Class Initialized
INFO - 2019-11-10 11:30:33 --> Hooks Class Initialized
DEBUG - 2019-11-10 11:30:33 --> UTF-8 Support Enabled
INFO - 2019-11-10 11:30:33 --> Utf8 Class Initialized
INFO - 2019-11-10 11:30:33 --> URI Class Initialized
INFO - 2019-11-10 11:30:33 --> Router Class Initialized
INFO - 2019-11-10 11:30:33 --> Output Class Initialized
INFO - 2019-11-10 11:30:33 --> Security Class Initialized
DEBUG - 2019-11-10 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-10 11:30:33 --> CSRF cookie sent
INFO - 2019-11-10 11:30:33 --> Input Class Initialized
INFO - 2019-11-10 11:30:33 --> Language Class Initialized
INFO - 2019-11-10 11:30:33 --> Language Class Initialized
INFO - 2019-11-10 11:30:33 --> Config Class Initialized
INFO - 2019-11-10 11:30:33 --> Loader Class Initialized
INFO - 2019-11-10 11:30:33 --> Helper loaded: url_helper
INFO - 2019-11-10 11:30:33 --> Helper loaded: common_helper
INFO - 2019-11-10 11:30:33 --> Helper loaded: language_helper
INFO - 2019-11-10 11:30:33 --> Helper loaded: cookie_helper
INFO - 2019-11-10 11:30:33 --> Helper loaded: email_helper
INFO - 2019-11-10 11:30:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-10 11:30:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-10 11:30:33 --> Parser Class Initialized
INFO - 2019-11-10 11:30:33 --> User Agent Class Initialized
INFO - 2019-11-10 11:30:33 --> Model Class Initialized
INFO - 2019-11-10 11:30:33 --> Database Driver Class Initialized
INFO - 2019-11-10 11:30:33 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:33 --> Template Class Initialized
INFO - 2019-11-10 11:30:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-10 11:30:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-10 11:30:33 --> Pagination Class Initialized
DEBUG - 2019-11-10 11:30:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-10 11:30:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-10 11:30:33 --> Encryption Class Initialized
INFO - 2019-11-10 11:30:33 --> Controller Class Initialized
DEBUG - 2019-11-10 11:30:33 --> order MX_Controller Initialized
DEBUG - 2019-11-10 11:30:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-10 11:30:33 --> Model Class Initialized
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "order_id"
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "order_id"
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "order_basic_details"
INFO - 2019-11-10 11:30:33 --> Helper loaded: inflector_helper
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "Awaiting"
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "Pending"
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "Pending"
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "Pending"
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "Pending"
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "Pending"
ERROR - 2019-11-10 11:30:33 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-10 11:30:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-10 11:30:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-10 11:30:33 --> blocks MX_Controller Initialized
DEBUG - 2019-11-10 11:30:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-10 11:30:33 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-10 11:30:33 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-10 11:30:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-10 11:30:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-10 11:30:34 --> Final output sent to browser
DEBUG - 2019-11-10 11:30:34 --> Total execution time: 1.0390
INFO - 2019-11-10 11:30:36 --> Config Class Initialized
INFO - 2019-11-10 11:30:36 --> Hooks Class Initialized
DEBUG - 2019-11-10 11:30:36 --> UTF-8 Support Enabled
INFO - 2019-11-10 11:30:36 --> Utf8 Class Initialized
INFO - 2019-11-10 11:30:36 --> URI Class Initialized
INFO - 2019-11-10 11:30:36 --> Router Class Initialized
INFO - 2019-11-10 11:30:36 --> Output Class Initialized
INFO - 2019-11-10 11:30:36 --> Security Class Initialized
DEBUG - 2019-11-10 11:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-10 11:30:36 --> CSRF cookie sent
INFO - 2019-11-10 11:30:36 --> Input Class Initialized
INFO - 2019-11-10 11:30:36 --> Language Class Initialized
INFO - 2019-11-10 11:30:36 --> Language Class Initialized
INFO - 2019-11-10 11:30:36 --> Config Class Initialized
INFO - 2019-11-10 11:30:36 --> Loader Class Initialized
INFO - 2019-11-10 11:30:36 --> Helper loaded: url_helper
INFO - 2019-11-10 11:30:36 --> Helper loaded: common_helper
INFO - 2019-11-10 11:30:36 --> Helper loaded: language_helper
INFO - 2019-11-10 11:30:36 --> Helper loaded: cookie_helper
INFO - 2019-11-10 11:30:36 --> Helper loaded: email_helper
INFO - 2019-11-10 11:30:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-10 11:30:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-10 11:30:36 --> Parser Class Initialized
INFO - 2019-11-10 11:30:36 --> User Agent Class Initialized
INFO - 2019-11-10 11:30:36 --> Model Class Initialized
INFO - 2019-11-10 11:30:36 --> Database Driver Class Initialized
INFO - 2019-11-10 11:30:36 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:36 --> Template Class Initialized
INFO - 2019-11-10 11:30:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-10 11:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-10 11:30:36 --> Pagination Class Initialized
DEBUG - 2019-11-10 11:30:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-10 11:30:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-10 11:30:36 --> Encryption Class Initialized
INFO - 2019-11-10 11:30:36 --> Controller Class Initialized
DEBUG - 2019-11-10 11:30:36 --> transactions MX_Controller Initialized
DEBUG - 2019-11-10 11:30:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-10 11:30:36 --> Model Class Initialized
ERROR - 2019-11-10 11:30:36 --> Could not find the language line "order_id"
INFO - 2019-11-10 11:30:36 --> Helper loaded: inflector_helper
DEBUG - 2019-11-10 11:30:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-10 11:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-10 11:30:37 --> blocks MX_Controller Initialized
DEBUG - 2019-11-10 11:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-10 11:30:37 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-10 11:30:37 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-10 11:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-10 11:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-10 11:30:37 --> Final output sent to browser
DEBUG - 2019-11-10 11:30:37 --> Total execution time: 0.8676
INFO - 2019-11-10 11:30:40 --> Config Class Initialized
INFO - 2019-11-10 11:30:40 --> Hooks Class Initialized
DEBUG - 2019-11-10 11:30:40 --> UTF-8 Support Enabled
INFO - 2019-11-10 11:30:40 --> Utf8 Class Initialized
INFO - 2019-11-10 11:30:40 --> URI Class Initialized
INFO - 2019-11-10 11:30:40 --> Router Class Initialized
INFO - 2019-11-10 11:30:40 --> Output Class Initialized
INFO - 2019-11-10 11:30:40 --> Security Class Initialized
DEBUG - 2019-11-10 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-10 11:30:40 --> CSRF cookie sent
INFO - 2019-11-10 11:30:40 --> Input Class Initialized
INFO - 2019-11-10 11:30:40 --> Language Class Initialized
INFO - 2019-11-10 11:30:40 --> Language Class Initialized
INFO - 2019-11-10 11:30:40 --> Config Class Initialized
INFO - 2019-11-10 11:30:40 --> Loader Class Initialized
INFO - 2019-11-10 11:30:40 --> Helper loaded: url_helper
INFO - 2019-11-10 11:30:40 --> Helper loaded: common_helper
INFO - 2019-11-10 11:30:40 --> Helper loaded: language_helper
INFO - 2019-11-10 11:30:40 --> Helper loaded: cookie_helper
INFO - 2019-11-10 11:30:40 --> Helper loaded: email_helper
INFO - 2019-11-10 11:30:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-10 11:30:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-10 11:30:40 --> Parser Class Initialized
INFO - 2019-11-10 11:30:40 --> User Agent Class Initialized
INFO - 2019-11-10 11:30:40 --> Model Class Initialized
INFO - 2019-11-10 11:30:40 --> Database Driver Class Initialized
INFO - 2019-11-10 11:30:40 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:40 --> Template Class Initialized
INFO - 2019-11-10 11:30:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-10 11:30:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-10 11:30:40 --> Pagination Class Initialized
DEBUG - 2019-11-10 11:30:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-10 11:30:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-10 11:30:40 --> Encryption Class Initialized
INFO - 2019-11-10 11:30:40 --> Controller Class Initialized
DEBUG - 2019-11-10 11:30:40 --> transactions MX_Controller Initialized
DEBUG - 2019-11-10 11:30:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-10 11:30:40 --> Model Class Initialized
ERROR - 2019-11-10 11:30:40 --> Could not find the language line "order_id"
INFO - 2019-11-10 11:30:41 --> Helper loaded: inflector_helper
DEBUG - 2019-11-10 11:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-10 11:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-10 11:30:41 --> blocks MX_Controller Initialized
DEBUG - 2019-11-10 11:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-10 11:30:41 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-10 11:30:41 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-10 11:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-10 11:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-10 11:30:41 --> Final output sent to browser
DEBUG - 2019-11-10 11:30:41 --> Total execution time: 0.7348
INFO - 2019-11-10 11:30:43 --> Config Class Initialized
INFO - 2019-11-10 11:30:43 --> Hooks Class Initialized
DEBUG - 2019-11-10 11:30:43 --> UTF-8 Support Enabled
INFO - 2019-11-10 11:30:43 --> Utf8 Class Initialized
INFO - 2019-11-10 11:30:43 --> URI Class Initialized
INFO - 2019-11-10 11:30:43 --> Router Class Initialized
INFO - 2019-11-10 11:30:43 --> Output Class Initialized
INFO - 2019-11-10 11:30:43 --> Security Class Initialized
DEBUG - 2019-11-10 11:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-10 11:30:43 --> CSRF cookie sent
INFO - 2019-11-10 11:30:43 --> Input Class Initialized
INFO - 2019-11-10 11:30:43 --> Language Class Initialized
INFO - 2019-11-10 11:30:43 --> Language Class Initialized
INFO - 2019-11-10 11:30:43 --> Config Class Initialized
INFO - 2019-11-10 11:30:43 --> Loader Class Initialized
INFO - 2019-11-10 11:30:43 --> Helper loaded: url_helper
INFO - 2019-11-10 11:30:43 --> Helper loaded: common_helper
INFO - 2019-11-10 11:30:43 --> Helper loaded: language_helper
INFO - 2019-11-10 11:30:43 --> Helper loaded: cookie_helper
INFO - 2019-11-10 11:30:43 --> Helper loaded: email_helper
INFO - 2019-11-10 11:30:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-10 11:30:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-10 11:30:43 --> Parser Class Initialized
INFO - 2019-11-10 11:30:43 --> User Agent Class Initialized
INFO - 2019-11-10 11:30:43 --> Model Class Initialized
INFO - 2019-11-10 11:30:44 --> Database Driver Class Initialized
INFO - 2019-11-10 11:30:44 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:44 --> Template Class Initialized
INFO - 2019-11-10 11:30:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-10 11:30:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-10 11:30:44 --> Pagination Class Initialized
DEBUG - 2019-11-10 11:30:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-10 11:30:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-10 11:30:44 --> Encryption Class Initialized
INFO - 2019-11-10 11:30:44 --> Controller Class Initialized
DEBUG - 2019-11-10 11:30:44 --> transactions MX_Controller Initialized
DEBUG - 2019-11-10 11:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-10 11:30:44 --> Model Class Initialized
ERROR - 2019-11-10 11:30:44 --> Could not find the language line "order_id"
INFO - 2019-11-10 11:30:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-10 11:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-10 11:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-10 11:30:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-10 11:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-10 11:30:44 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-10 11:30:44 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-10 11:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-10 11:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-10 11:30:44 --> Final output sent to browser
DEBUG - 2019-11-10 11:30:44 --> Total execution time: 0.7224
INFO - 2019-11-10 11:30:47 --> Config Class Initialized
INFO - 2019-11-10 11:30:47 --> Hooks Class Initialized
DEBUG - 2019-11-10 11:30:47 --> UTF-8 Support Enabled
INFO - 2019-11-10 11:30:47 --> Utf8 Class Initialized
INFO - 2019-11-10 11:30:47 --> URI Class Initialized
INFO - 2019-11-10 11:30:47 --> Router Class Initialized
INFO - 2019-11-10 11:30:47 --> Output Class Initialized
INFO - 2019-11-10 11:30:47 --> Security Class Initialized
DEBUG - 2019-11-10 11:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-10 11:30:47 --> CSRF cookie sent
INFO - 2019-11-10 11:30:47 --> Input Class Initialized
INFO - 2019-11-10 11:30:47 --> Language Class Initialized
INFO - 2019-11-10 11:30:47 --> Language Class Initialized
INFO - 2019-11-10 11:30:47 --> Config Class Initialized
INFO - 2019-11-10 11:30:47 --> Loader Class Initialized
INFO - 2019-11-10 11:30:47 --> Helper loaded: url_helper
INFO - 2019-11-10 11:30:47 --> Helper loaded: common_helper
INFO - 2019-11-10 11:30:47 --> Helper loaded: language_helper
INFO - 2019-11-10 11:30:47 --> Helper loaded: cookie_helper
INFO - 2019-11-10 11:30:47 --> Helper loaded: email_helper
INFO - 2019-11-10 11:30:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-10 11:30:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-10 11:30:47 --> Parser Class Initialized
INFO - 2019-11-10 11:30:47 --> User Agent Class Initialized
INFO - 2019-11-10 11:30:47 --> Model Class Initialized
INFO - 2019-11-10 11:30:47 --> Database Driver Class Initialized
INFO - 2019-11-10 11:30:47 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:47 --> Template Class Initialized
INFO - 2019-11-10 11:30:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-10 11:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-10 11:30:47 --> Pagination Class Initialized
DEBUG - 2019-11-10 11:30:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-10 11:30:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-10 11:30:47 --> Encryption Class Initialized
INFO - 2019-11-10 11:30:47 --> Controller Class Initialized
DEBUG - 2019-11-10 11:30:47 --> transactions MX_Controller Initialized
DEBUG - 2019-11-10 11:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-10 11:30:47 --> Model Class Initialized
ERROR - 2019-11-10 11:30:47 --> Could not find the language line "order_id"
INFO - 2019-11-10 11:30:47 --> Helper loaded: inflector_helper
DEBUG - 2019-11-10 11:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-10 11:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-10 11:30:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-10 11:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-10 11:30:47 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-10 11:30:47 --> Model Class Initialized
DEBUG - 2019-11-10 11:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-10 11:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-10 11:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-10 11:30:47 --> Final output sent to browser
DEBUG - 2019-11-10 11:30:47 --> Total execution time: 0.7236
