<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-26 17:08:25 --> Config Class Initialized
INFO - 2020-03-26 17:08:25 --> Hooks Class Initialized
DEBUG - 2020-03-26 17:08:25 --> UTF-8 Support Enabled
INFO - 2020-03-26 17:08:25 --> Utf8 Class Initialized
INFO - 2020-03-26 17:08:25 --> URI Class Initialized
DEBUG - 2020-03-26 17:08:25 --> No URI present. Default controller set.
INFO - 2020-03-26 17:08:25 --> Router Class Initialized
INFO - 2020-03-26 17:08:25 --> Output Class Initialized
INFO - 2020-03-26 17:08:25 --> Security Class Initialized
DEBUG - 2020-03-26 17:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-26 17:08:25 --> CSRF cookie sent
INFO - 2020-03-26 17:08:25 --> Input Class Initialized
INFO - 2020-03-26 17:08:25 --> Language Class Initialized
INFO - 2020-03-26 17:08:25 --> Language Class Initialized
INFO - 2020-03-26 17:08:25 --> Config Class Initialized
INFO - 2020-03-26 17:08:25 --> Loader Class Initialized
INFO - 2020-03-26 17:08:26 --> Helper loaded: url_helper
INFO - 2020-03-26 17:08:26 --> Helper loaded: common_helper
INFO - 2020-03-26 17:08:26 --> Helper loaded: language_helper
INFO - 2020-03-26 17:08:26 --> Helper loaded: cookie_helper
INFO - 2020-03-26 17:08:26 --> Helper loaded: email_helper
INFO - 2020-03-26 17:08:26 --> Helper loaded: file_manager_helper
INFO - 2020-03-26 17:08:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-26 17:08:26 --> Parser Class Initialized
INFO - 2020-03-26 17:08:26 --> User Agent Class Initialized
INFO - 2020-03-26 17:08:26 --> Model Class Initialized
INFO - 2020-03-26 17:08:26 --> Database Driver Class Initialized
INFO - 2020-03-26 17:08:26 --> Model Class Initialized
DEBUG - 2020-03-26 17:08:26 --> Template Class Initialized
INFO - 2020-03-26 17:08:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-26 17:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-26 17:08:26 --> Pagination Class Initialized
DEBUG - 2020-03-26 17:08:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-26 17:08:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-26 17:08:26 --> Encryption Class Initialized
DEBUG - 2020-03-26 17:08:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-26 17:08:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-26 17:08:26 --> Controller Class Initialized
DEBUG - 2020-03-26 17:08:26 --> pergo MX_Controller Initialized
DEBUG - 2020-03-26 17:08:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-26 17:08:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-26 17:08:26 --> Model Class Initialized
INFO - 2020-03-26 17:08:26 --> Helper loaded: inflector_helper
DEBUG - 2020-03-26 17:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-26 17:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-26 17:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-26 17:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-26 17:08:27 --> Final output sent to browser
DEBUG - 2020-03-26 17:08:27 --> Total execution time: 2.1545
