<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-23 15:14:52 --> Config Class Initialized
INFO - 2020-02-23 15:14:52 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:14:52 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:14:52 --> Utf8 Class Initialized
INFO - 2020-02-23 15:14:52 --> URI Class Initialized
DEBUG - 2020-02-23 15:14:52 --> No URI present. Default controller set.
INFO - 2020-02-23 15:14:52 --> Router Class Initialized
INFO - 2020-02-23 15:14:52 --> Output Class Initialized
INFO - 2020-02-23 15:14:52 --> Security Class Initialized
DEBUG - 2020-02-23 15:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:14:52 --> CSRF cookie sent
INFO - 2020-02-23 15:14:52 --> Input Class Initialized
INFO - 2020-02-23 15:14:52 --> Language Class Initialized
INFO - 2020-02-23 15:14:53 --> Language Class Initialized
INFO - 2020-02-23 15:14:53 --> Config Class Initialized
INFO - 2020-02-23 15:14:53 --> Loader Class Initialized
INFO - 2020-02-23 15:14:53 --> Helper loaded: url_helper
INFO - 2020-02-23 15:14:53 --> Helper loaded: common_helper
INFO - 2020-02-23 15:14:53 --> Helper loaded: language_helper
INFO - 2020-02-23 15:14:53 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:14:53 --> Helper loaded: email_helper
INFO - 2020-02-23 15:14:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:14:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:14:53 --> Parser Class Initialized
INFO - 2020-02-23 15:14:53 --> User Agent Class Initialized
INFO - 2020-02-23 15:14:53 --> Model Class Initialized
INFO - 2020-02-23 15:14:53 --> Database Driver Class Initialized
INFO - 2020-02-23 15:14:53 --> Model Class Initialized
DEBUG - 2020-02-23 15:14:53 --> Template Class Initialized
INFO - 2020-02-23 15:14:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:14:53 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:14:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:14:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:14:53 --> Encryption Class Initialized
DEBUG - 2020-02-23 15:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-23 15:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-02-23 15:14:53 --> Controller Class Initialized
DEBUG - 2020-02-23 15:14:53 --> pergo MX_Controller Initialized
DEBUG - 2020-02-23 15:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-23 15:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-02-23 15:14:53 --> Model Class Initialized
INFO - 2020-02-23 15:14:53 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:14:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-02-23 15:14:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-02-23 15:14:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-02-23 15:14:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-02-23 15:14:54 --> Final output sent to browser
DEBUG - 2020-02-23 15:14:54 --> Total execution time: 1.8066
INFO - 2020-02-23 15:14:59 --> Config Class Initialized
INFO - 2020-02-23 15:14:59 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:14:59 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:14:59 --> Utf8 Class Initialized
INFO - 2020-02-23 15:14:59 --> URI Class Initialized
INFO - 2020-02-23 15:14:59 --> Router Class Initialized
INFO - 2020-02-23 15:14:59 --> Output Class Initialized
INFO - 2020-02-23 15:14:59 --> Security Class Initialized
DEBUG - 2020-02-23 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:14:59 --> CSRF cookie sent
INFO - 2020-02-23 15:14:59 --> Input Class Initialized
INFO - 2020-02-23 15:14:59 --> Language Class Initialized
INFO - 2020-02-23 15:14:59 --> Language Class Initialized
INFO - 2020-02-23 15:14:59 --> Config Class Initialized
INFO - 2020-02-23 15:14:59 --> Loader Class Initialized
INFO - 2020-02-23 15:14:59 --> Helper loaded: url_helper
INFO - 2020-02-23 15:14:59 --> Helper loaded: common_helper
INFO - 2020-02-23 15:14:59 --> Helper loaded: language_helper
INFO - 2020-02-23 15:14:59 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:14:59 --> Helper loaded: email_helper
INFO - 2020-02-23 15:14:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:14:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:14:59 --> Parser Class Initialized
INFO - 2020-02-23 15:14:59 --> User Agent Class Initialized
INFO - 2020-02-23 15:14:59 --> Model Class Initialized
INFO - 2020-02-23 15:14:59 --> Database Driver Class Initialized
INFO - 2020-02-23 15:14:59 --> Model Class Initialized
DEBUG - 2020-02-23 15:14:59 --> Template Class Initialized
INFO - 2020-02-23 15:14:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:14:59 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:14:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:14:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:14:59 --> Encryption Class Initialized
INFO - 2020-02-23 15:14:59 --> Controller Class Initialized
DEBUG - 2020-02-23 15:14:59 --> package MX_Controller Initialized
DEBUG - 2020-02-23 15:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-23 15:14:59 --> Model Class Initialized
INFO - 2020-02-23 15:14:59 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:14:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:14:59 --> Model Class Initialized
DEBUG - 2020-02-23 15:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:14:59 --> Model Class Initialized
DEBUG - 2020-02-23 15:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-23 15:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-23 15:15:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-23 15:15:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-23 15:15:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-23 15:15:00 --> Final output sent to browser
DEBUG - 2020-02-23 15:15:00 --> Total execution time: 0.9443
INFO - 2020-02-23 15:15:21 --> Config Class Initialized
INFO - 2020-02-23 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:15:21 --> Utf8 Class Initialized
INFO - 2020-02-23 15:15:21 --> URI Class Initialized
INFO - 2020-02-23 15:15:21 --> Router Class Initialized
INFO - 2020-02-23 15:15:21 --> Output Class Initialized
INFO - 2020-02-23 15:15:21 --> Security Class Initialized
DEBUG - 2020-02-23 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:15:21 --> CSRF cookie sent
INFO - 2020-02-23 15:15:21 --> Input Class Initialized
INFO - 2020-02-23 15:15:21 --> Language Class Initialized
INFO - 2020-02-23 15:15:21 --> Language Class Initialized
INFO - 2020-02-23 15:15:21 --> Config Class Initialized
INFO - 2020-02-23 15:15:21 --> Loader Class Initialized
INFO - 2020-02-23 15:15:22 --> Helper loaded: url_helper
INFO - 2020-02-23 15:15:22 --> Helper loaded: common_helper
INFO - 2020-02-23 15:15:22 --> Helper loaded: language_helper
INFO - 2020-02-23 15:15:22 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:15:22 --> Helper loaded: email_helper
INFO - 2020-02-23 15:15:22 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:15:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:15:22 --> Parser Class Initialized
INFO - 2020-02-23 15:15:22 --> User Agent Class Initialized
INFO - 2020-02-23 15:15:22 --> Model Class Initialized
INFO - 2020-02-23 15:15:22 --> Database Driver Class Initialized
INFO - 2020-02-23 15:15:22 --> Model Class Initialized
DEBUG - 2020-02-23 15:15:22 --> Template Class Initialized
INFO - 2020-02-23 15:15:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:15:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:15:22 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:15:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:15:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:15:22 --> Encryption Class Initialized
INFO - 2020-02-23 15:15:22 --> Controller Class Initialized
DEBUG - 2020-02-23 15:15:22 --> client MX_Controller Initialized
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/models/client_model.php
INFO - 2020-02-23 15:15:22 --> Model Class Initialized
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/models/faqs_model.php
INFO - 2020-02-23 15:15:22 --> Model Class Initialized
INFO - 2020-02-23 15:15:22 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:15:22 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:15:22 --> Model Class Initialized
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:15:22 --> Model Class Initialized
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/faq/index.php
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-23 15:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-23 15:15:22 --> Final output sent to browser
DEBUG - 2020-02-23 15:15:22 --> Total execution time: 0.7810
INFO - 2020-02-23 15:16:30 --> Config Class Initialized
INFO - 2020-02-23 15:16:30 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:16:30 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:16:30 --> Utf8 Class Initialized
INFO - 2020-02-23 15:16:31 --> URI Class Initialized
INFO - 2020-02-23 15:16:31 --> Router Class Initialized
INFO - 2020-02-23 15:16:31 --> Output Class Initialized
INFO - 2020-02-23 15:16:31 --> Security Class Initialized
DEBUG - 2020-02-23 15:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:16:31 --> CSRF cookie sent
INFO - 2020-02-23 15:16:31 --> Input Class Initialized
INFO - 2020-02-23 15:16:31 --> Language Class Initialized
INFO - 2020-02-23 15:16:31 --> Language Class Initialized
INFO - 2020-02-23 15:16:31 --> Config Class Initialized
INFO - 2020-02-23 15:16:31 --> Loader Class Initialized
INFO - 2020-02-23 15:16:31 --> Helper loaded: url_helper
INFO - 2020-02-23 15:16:31 --> Helper loaded: common_helper
INFO - 2020-02-23 15:16:31 --> Helper loaded: language_helper
INFO - 2020-02-23 15:16:31 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:16:31 --> Helper loaded: email_helper
INFO - 2020-02-23 15:16:31 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:16:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:16:31 --> Parser Class Initialized
INFO - 2020-02-23 15:16:31 --> User Agent Class Initialized
INFO - 2020-02-23 15:16:31 --> Model Class Initialized
INFO - 2020-02-23 15:16:31 --> Database Driver Class Initialized
INFO - 2020-02-23 15:16:31 --> Model Class Initialized
DEBUG - 2020-02-23 15:16:31 --> Template Class Initialized
INFO - 2020-02-23 15:16:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:16:31 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:16:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:16:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:16:31 --> Encryption Class Initialized
INFO - 2020-02-23 15:16:31 --> Controller Class Initialized
DEBUG - 2020-02-23 15:16:31 --> auth MX_Controller Initialized
DEBUG - 2020-02-23 15:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-02-23 15:16:31 --> Model Class Initialized
DEBUG - 2020-02-23 15:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-02-23 15:16:31 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-02-23 15:16:31 --> pergo MX_Controller Initialized
DEBUG - 2020-02-23 15:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-23 15:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-02-23 15:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-02-23 15:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-02-23 15:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-02-23 15:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-02-23 15:16:31 --> Final output sent to browser
DEBUG - 2020-02-23 15:16:31 --> Total execution time: 0.5451
INFO - 2020-02-23 15:16:36 --> Config Class Initialized
INFO - 2020-02-23 15:16:36 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:16:36 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:16:36 --> Utf8 Class Initialized
INFO - 2020-02-23 15:16:36 --> URI Class Initialized
INFO - 2020-02-23 15:16:36 --> Router Class Initialized
INFO - 2020-02-23 15:16:36 --> Output Class Initialized
INFO - 2020-02-23 15:16:36 --> Security Class Initialized
DEBUG - 2020-02-23 15:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:16:36 --> CSRF cookie sent
INFO - 2020-02-23 15:16:36 --> CSRF token verified
INFO - 2020-02-23 15:16:36 --> Input Class Initialized
INFO - 2020-02-23 15:16:36 --> Language Class Initialized
INFO - 2020-02-23 15:16:36 --> Language Class Initialized
INFO - 2020-02-23 15:16:36 --> Config Class Initialized
INFO - 2020-02-23 15:16:36 --> Loader Class Initialized
INFO - 2020-02-23 15:16:36 --> Helper loaded: url_helper
INFO - 2020-02-23 15:16:36 --> Helper loaded: common_helper
INFO - 2020-02-23 15:16:36 --> Helper loaded: language_helper
INFO - 2020-02-23 15:16:36 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:16:36 --> Helper loaded: email_helper
INFO - 2020-02-23 15:16:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:16:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:16:37 --> Parser Class Initialized
INFO - 2020-02-23 15:16:37 --> User Agent Class Initialized
INFO - 2020-02-23 15:16:37 --> Model Class Initialized
INFO - 2020-02-23 15:16:37 --> Database Driver Class Initialized
INFO - 2020-02-23 15:16:37 --> Model Class Initialized
DEBUG - 2020-02-23 15:16:37 --> Template Class Initialized
INFO - 2020-02-23 15:16:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:16:37 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:16:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:16:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:16:37 --> Encryption Class Initialized
INFO - 2020-02-23 15:16:37 --> Controller Class Initialized
DEBUG - 2020-02-23 15:16:37 --> auth MX_Controller Initialized
DEBUG - 2020-02-23 15:16:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-02-23 15:16:37 --> Model Class Initialized
INFO - 2020-02-23 15:16:45 --> Config Class Initialized
INFO - 2020-02-23 15:16:45 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:16:45 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:16:45 --> Utf8 Class Initialized
INFO - 2020-02-23 15:16:45 --> URI Class Initialized
INFO - 2020-02-23 15:16:45 --> Router Class Initialized
INFO - 2020-02-23 15:16:45 --> Output Class Initialized
INFO - 2020-02-23 15:16:45 --> Security Class Initialized
DEBUG - 2020-02-23 15:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:16:45 --> CSRF cookie sent
INFO - 2020-02-23 15:16:45 --> CSRF token verified
INFO - 2020-02-23 15:16:45 --> Input Class Initialized
INFO - 2020-02-23 15:16:45 --> Language Class Initialized
INFO - 2020-02-23 15:16:45 --> Language Class Initialized
INFO - 2020-02-23 15:16:45 --> Config Class Initialized
INFO - 2020-02-23 15:16:45 --> Loader Class Initialized
INFO - 2020-02-23 15:16:45 --> Helper loaded: url_helper
INFO - 2020-02-23 15:16:45 --> Helper loaded: common_helper
INFO - 2020-02-23 15:16:45 --> Helper loaded: language_helper
INFO - 2020-02-23 15:16:45 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:16:45 --> Helper loaded: email_helper
INFO - 2020-02-23 15:16:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:16:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:16:45 --> Parser Class Initialized
INFO - 2020-02-23 15:16:45 --> User Agent Class Initialized
INFO - 2020-02-23 15:16:45 --> Model Class Initialized
INFO - 2020-02-23 15:16:45 --> Database Driver Class Initialized
INFO - 2020-02-23 15:16:45 --> Model Class Initialized
DEBUG - 2020-02-23 15:16:45 --> Template Class Initialized
INFO - 2020-02-23 15:16:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:16:45 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:16:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:16:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:16:45 --> Encryption Class Initialized
INFO - 2020-02-23 15:16:45 --> Controller Class Initialized
DEBUG - 2020-02-23 15:16:45 --> auth MX_Controller Initialized
DEBUG - 2020-02-23 15:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-02-23 15:16:46 --> Model Class Initialized
INFO - 2020-02-23 15:16:54 --> Config Class Initialized
INFO - 2020-02-23 15:16:54 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:16:54 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:16:54 --> Utf8 Class Initialized
INFO - 2020-02-23 15:16:54 --> URI Class Initialized
INFO - 2020-02-23 15:16:54 --> Router Class Initialized
INFO - 2020-02-23 15:16:54 --> Output Class Initialized
INFO - 2020-02-23 15:16:54 --> Security Class Initialized
DEBUG - 2020-02-23 15:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:16:54 --> CSRF cookie sent
INFO - 2020-02-23 15:16:54 --> CSRF token verified
INFO - 2020-02-23 15:16:54 --> Input Class Initialized
INFO - 2020-02-23 15:16:54 --> Language Class Initialized
INFO - 2020-02-23 15:16:54 --> Language Class Initialized
INFO - 2020-02-23 15:16:54 --> Config Class Initialized
INFO - 2020-02-23 15:16:54 --> Loader Class Initialized
INFO - 2020-02-23 15:16:54 --> Helper loaded: url_helper
INFO - 2020-02-23 15:16:54 --> Helper loaded: common_helper
INFO - 2020-02-23 15:16:54 --> Helper loaded: language_helper
INFO - 2020-02-23 15:16:54 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:16:54 --> Helper loaded: email_helper
INFO - 2020-02-23 15:16:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:16:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:16:54 --> Parser Class Initialized
INFO - 2020-02-23 15:16:54 --> User Agent Class Initialized
INFO - 2020-02-23 15:16:54 --> Model Class Initialized
INFO - 2020-02-23 15:16:54 --> Database Driver Class Initialized
INFO - 2020-02-23 15:16:54 --> Model Class Initialized
DEBUG - 2020-02-23 15:16:54 --> Template Class Initialized
INFO - 2020-02-23 15:16:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:16:54 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:16:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:16:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:16:54 --> Encryption Class Initialized
INFO - 2020-02-23 15:16:54 --> Controller Class Initialized
DEBUG - 2020-02-23 15:16:54 --> auth MX_Controller Initialized
DEBUG - 2020-02-23 15:16:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-02-23 15:16:55 --> Model Class Initialized
INFO - 2020-02-23 15:16:59 --> Config Class Initialized
INFO - 2020-02-23 15:16:59 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:16:59 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:16:59 --> Utf8 Class Initialized
INFO - 2020-02-23 15:16:59 --> URI Class Initialized
INFO - 2020-02-23 15:16:59 --> Router Class Initialized
INFO - 2020-02-23 15:16:59 --> Output Class Initialized
INFO - 2020-02-23 15:16:59 --> Security Class Initialized
DEBUG - 2020-02-23 15:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:16:59 --> CSRF cookie sent
INFO - 2020-02-23 15:16:59 --> Input Class Initialized
INFO - 2020-02-23 15:16:59 --> Language Class Initialized
INFO - 2020-02-23 15:16:59 --> Language Class Initialized
INFO - 2020-02-23 15:16:59 --> Config Class Initialized
INFO - 2020-02-23 15:16:59 --> Loader Class Initialized
INFO - 2020-02-23 15:16:59 --> Helper loaded: url_helper
INFO - 2020-02-23 15:16:59 --> Helper loaded: common_helper
INFO - 2020-02-23 15:16:59 --> Helper loaded: language_helper
INFO - 2020-02-23 15:16:59 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:16:59 --> Helper loaded: email_helper
INFO - 2020-02-23 15:16:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:16:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:16:59 --> Parser Class Initialized
INFO - 2020-02-23 15:16:59 --> User Agent Class Initialized
INFO - 2020-02-23 15:16:59 --> Model Class Initialized
INFO - 2020-02-23 15:16:59 --> Database Driver Class Initialized
INFO - 2020-02-23 15:16:59 --> Model Class Initialized
DEBUG - 2020-02-23 15:16:59 --> Template Class Initialized
INFO - 2020-02-23 15:16:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:16:59 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:16:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:16:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:16:59 --> Encryption Class Initialized
INFO - 2020-02-23 15:16:59 --> Controller Class Initialized
DEBUG - 2020-02-23 15:16:59 --> statistics MX_Controller Initialized
DEBUG - 2020-02-23 15:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-02-23 15:17:00 --> Model Class Initialized
ERROR - 2020-02-23 15:17:00 --> Could not find the language line "Pending"
ERROR - 2020-02-23 15:17:00 --> Could not find the language line "Pending"
INFO - 2020-02-23 15:17:00 --> Helper loaded: inflector_helper
ERROR - 2020-02-23 15:17:00 --> Could not find the language line "total_orders"
ERROR - 2020-02-23 15:17:00 --> Could not find the language line "total_orders"
ERROR - 2020-02-23 15:17:00 --> Could not find the language line "Pending"
DEBUG - 2020-02-23 15:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-02-23 15:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:17:00 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:17:00 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:00 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:17:00 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:00 --> Total execution time: 0.8864
INFO - 2020-02-23 15:17:06 --> Config Class Initialized
INFO - 2020-02-23 15:17:06 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:06 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:06 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:06 --> URI Class Initialized
INFO - 2020-02-23 15:17:06 --> Router Class Initialized
INFO - 2020-02-23 15:17:06 --> Output Class Initialized
INFO - 2020-02-23 15:17:06 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:06 --> CSRF cookie sent
INFO - 2020-02-23 15:17:06 --> Input Class Initialized
INFO - 2020-02-23 15:17:06 --> Language Class Initialized
INFO - 2020-02-23 15:17:06 --> Language Class Initialized
INFO - 2020-02-23 15:17:06 --> Config Class Initialized
INFO - 2020-02-23 15:17:06 --> Loader Class Initialized
INFO - 2020-02-23 15:17:06 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:06 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:06 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:06 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:06 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:06 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:06 --> Parser Class Initialized
INFO - 2020-02-23 15:17:06 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:06 --> Model Class Initialized
INFO - 2020-02-23 15:17:06 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:06 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:06 --> Template Class Initialized
INFO - 2020-02-23 15:17:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:06 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:07 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:07 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:07 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
ERROR - 2020-02-23 15:17:07 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:07 --> Helper loaded: inflector_helper
ERROR - 2020-02-23 15:17:07 --> Could not find the language line "Delele"
DEBUG - 2020-02-23 15:17:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-23 15:17:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:17:07 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:17:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:07 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:17:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:17:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:17:07 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:07 --> Total execution time: 0.6300
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:07 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:07 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:07 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:07 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:07 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:07 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:07 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:07 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:07 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:07 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:07 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:07 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:07 --> URI Class Initialized
INFO - 2020-02-23 15:17:07 --> URI Class Initialized
INFO - 2020-02-23 15:17:07 --> URI Class Initialized
INFO - 2020-02-23 15:17:07 --> URI Class Initialized
INFO - 2020-02-23 15:17:07 --> URI Class Initialized
INFO - 2020-02-23 15:17:07 --> URI Class Initialized
INFO - 2020-02-23 15:17:07 --> Router Class Initialized
INFO - 2020-02-23 15:17:07 --> Router Class Initialized
INFO - 2020-02-23 15:17:07 --> Router Class Initialized
INFO - 2020-02-23 15:17:07 --> Router Class Initialized
INFO - 2020-02-23 15:17:07 --> Router Class Initialized
INFO - 2020-02-23 15:17:07 --> Router Class Initialized
INFO - 2020-02-23 15:17:07 --> Output Class Initialized
INFO - 2020-02-23 15:17:07 --> Output Class Initialized
INFO - 2020-02-23 15:17:07 --> Output Class Initialized
INFO - 2020-02-23 15:17:07 --> Output Class Initialized
INFO - 2020-02-23 15:17:07 --> Output Class Initialized
INFO - 2020-02-23 15:17:07 --> Output Class Initialized
INFO - 2020-02-23 15:17:07 --> Security Class Initialized
INFO - 2020-02-23 15:17:07 --> Security Class Initialized
INFO - 2020-02-23 15:17:07 --> Security Class Initialized
INFO - 2020-02-23 15:17:07 --> Security Class Initialized
INFO - 2020-02-23 15:17:07 --> Security Class Initialized
INFO - 2020-02-23 15:17:07 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:07 --> CSRF cookie sent
INFO - 2020-02-23 15:17:07 --> CSRF cookie sent
INFO - 2020-02-23 15:17:07 --> CSRF cookie sent
INFO - 2020-02-23 15:17:07 --> CSRF cookie sent
INFO - 2020-02-23 15:17:07 --> CSRF cookie sent
INFO - 2020-02-23 15:17:07 --> CSRF cookie sent
INFO - 2020-02-23 15:17:07 --> CSRF token verified
INFO - 2020-02-23 15:17:07 --> CSRF token verified
INFO - 2020-02-23 15:17:07 --> CSRF token verified
INFO - 2020-02-23 15:17:07 --> CSRF token verified
INFO - 2020-02-23 15:17:07 --> CSRF token verified
INFO - 2020-02-23 15:17:07 --> CSRF token verified
INFO - 2020-02-23 15:17:07 --> Input Class Initialized
INFO - 2020-02-23 15:17:07 --> Input Class Initialized
INFO - 2020-02-23 15:17:07 --> Input Class Initialized
INFO - 2020-02-23 15:17:07 --> Input Class Initialized
INFO - 2020-02-23 15:17:07 --> Input Class Initialized
INFO - 2020-02-23 15:17:07 --> Input Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Language Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Config Class Initialized
INFO - 2020-02-23 15:17:07 --> Loader Class Initialized
INFO - 2020-02-23 15:17:07 --> Loader Class Initialized
INFO - 2020-02-23 15:17:07 --> Loader Class Initialized
INFO - 2020-02-23 15:17:07 --> Loader Class Initialized
INFO - 2020-02-23 15:17:07 --> Loader Class Initialized
INFO - 2020-02-23 15:17:07 --> Loader Class Initialized
INFO - 2020-02-23 15:17:07 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:07 --> Parser Class Initialized
INFO - 2020-02-23 15:17:07 --> Parser Class Initialized
INFO - 2020-02-23 15:17:07 --> Parser Class Initialized
INFO - 2020-02-23 15:17:07 --> Parser Class Initialized
INFO - 2020-02-23 15:17:07 --> Parser Class Initialized
INFO - 2020-02-23 15:17:07 --> Parser Class Initialized
INFO - 2020-02-23 15:17:07 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:07 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:07 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:07 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:07 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:07 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:07 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:07 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:07 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:07 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:07 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
INFO - 2020-02-23 15:17:07 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:07 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:07 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:07 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:07 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:07 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:07 --> Template Class Initialized
INFO - 2020-02-23 15:17:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:07 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:07 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:07 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:07 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:08 --> Model Class Initialized
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:08 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:08 --> Total execution time: 0.5313
INFO - 2020-02-23 15:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:08 --> Config Class Initialized
INFO - 2020-02-23 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:08 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:08 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-02-23 15:17:08 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:08 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:08 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:08 --> URI Class Initialized
INFO - 2020-02-23 15:17:08 --> Controller Class Initialized
INFO - 2020-02-23 15:17:08 --> Router Class Initialized
DEBUG - 2020-02-23 15:17:08 --> category MX_Controller Initialized
INFO - 2020-02-23 15:17:08 --> Output Class Initialized
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:08 --> Security Class Initialized
INFO - 2020-02-23 15:17:08 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:08 --> CSRF cookie sent
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:08 --> CSRF token verified
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
INFO - 2020-02-23 15:17:08 --> Input Class Initialized
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:08 --> Final output sent to browser
INFO - 2020-02-23 15:17:08 --> Language Class Initialized
DEBUG - 2020-02-23 15:17:08 --> Total execution time: 0.6688
INFO - 2020-02-23 15:17:08 --> Language Class Initialized
INFO - 2020-02-23 15:17:08 --> Config Class Initialized
INFO - 2020-02-23 15:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:08 --> Loader Class Initialized
INFO - 2020-02-23 15:17:08 --> Pagination Class Initialized
INFO - 2020-02-23 15:17:08 --> Helper loaded: url_helper
DEBUG - 2020-02-23 15:17:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:08 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:08 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:08 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:08 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:08 --> Controller Class Initialized
INFO - 2020-02-23 15:17:08 --> Helper loaded: email_helper
DEBUG - 2020-02-23 15:17:08 --> category MX_Controller Initialized
INFO - 2020-02-23 15:17:08 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:08 --> Model Class Initialized
INFO - 2020-02-23 15:17:08 --> Parser Class Initialized
INFO - 2020-02-23 15:17:08 --> User Agent Class Initialized
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:08 --> Model Class Initialized
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
INFO - 2020-02-23 15:17:08 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:08 --> Model Class Initialized
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:08 --> Template Class Initialized
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:08 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:08 --> Total execution time: 0.8552
INFO - 2020-02-23 15:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:08 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:08 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:08 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:08 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:08 --> Model Class Initialized
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:08 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:08 --> Total execution time: 1.0085
INFO - 2020-02-23 15:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:08 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:08 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:08 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:08 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:08 --> Model Class Initialized
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:08 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:08 --> Total execution time: 1.1429
INFO - 2020-02-23 15:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:08 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:08 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:08 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:08 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:08 --> Model Class Initialized
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:08 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:08 --> Total execution time: 1.3194
INFO - 2020-02-23 15:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:08 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:08 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:08 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:08 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:08 --> Model Class Initialized
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:08 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:09 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:09 --> Total execution time: 0.9147
INFO - 2020-02-23 15:17:12 --> Config Class Initialized
INFO - 2020-02-23 15:17:12 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:12 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:12 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:12 --> URI Class Initialized
INFO - 2020-02-23 15:17:12 --> Router Class Initialized
INFO - 2020-02-23 15:17:12 --> Output Class Initialized
INFO - 2020-02-23 15:17:12 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:12 --> CSRF cookie sent
INFO - 2020-02-23 15:17:12 --> Input Class Initialized
INFO - 2020-02-23 15:17:12 --> Language Class Initialized
INFO - 2020-02-23 15:17:12 --> Language Class Initialized
INFO - 2020-02-23 15:17:12 --> Config Class Initialized
INFO - 2020-02-23 15:17:12 --> Loader Class Initialized
INFO - 2020-02-23 15:17:12 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:12 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:12 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:12 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:12 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:12 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:12 --> Parser Class Initialized
INFO - 2020-02-23 15:17:12 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:12 --> Model Class Initialized
INFO - 2020-02-23 15:17:12 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:12 --> Template Class Initialized
INFO - 2020-02-23 15:17:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:12 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:12 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:12 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:12 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:12 --> Model Class Initialized
ERROR - 2020-02-23 15:17:12 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:12 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:17:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:17:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:17:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:17:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:17:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:17:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:17:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:17:13 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:13 --> Total execution time: 0.7726
INFO - 2020-02-23 15:17:15 --> Config Class Initialized
INFO - 2020-02-23 15:17:15 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:15 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:15 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:15 --> URI Class Initialized
INFO - 2020-02-23 15:17:15 --> Router Class Initialized
INFO - 2020-02-23 15:17:15 --> Output Class Initialized
INFO - 2020-02-23 15:17:15 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:15 --> CSRF cookie sent
INFO - 2020-02-23 15:17:15 --> Input Class Initialized
INFO - 2020-02-23 15:17:15 --> Language Class Initialized
INFO - 2020-02-23 15:17:15 --> Language Class Initialized
INFO - 2020-02-23 15:17:15 --> Config Class Initialized
INFO - 2020-02-23 15:17:15 --> Loader Class Initialized
INFO - 2020-02-23 15:17:15 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:15 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:15 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:15 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:15 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:15 --> Parser Class Initialized
INFO - 2020-02-23 15:17:15 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:15 --> Model Class Initialized
INFO - 2020-02-23 15:17:15 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:15 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:15 --> Template Class Initialized
INFO - 2020-02-23 15:17:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:15 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:15 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:15 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:15 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:16 --> Model Class Initialized
ERROR - 2020-02-23 15:17:16 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:16 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:17:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:17:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:17:16 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:17:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:17:16 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:16 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:16 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:17:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:17:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:17:16 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:16 --> Total execution time: 0.8645
INFO - 2020-02-23 15:17:17 --> Config Class Initialized
INFO - 2020-02-23 15:17:17 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:17 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:17 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:17 --> URI Class Initialized
INFO - 2020-02-23 15:17:17 --> Router Class Initialized
INFO - 2020-02-23 15:17:17 --> Output Class Initialized
INFO - 2020-02-23 15:17:17 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:17 --> CSRF cookie sent
INFO - 2020-02-23 15:17:17 --> Input Class Initialized
INFO - 2020-02-23 15:17:17 --> Language Class Initialized
INFO - 2020-02-23 15:17:17 --> Language Class Initialized
INFO - 2020-02-23 15:17:17 --> Config Class Initialized
INFO - 2020-02-23 15:17:17 --> Loader Class Initialized
INFO - 2020-02-23 15:17:17 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:17 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:17 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:17 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:17 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:17 --> Parser Class Initialized
INFO - 2020-02-23 15:17:17 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:17 --> Model Class Initialized
INFO - 2020-02-23 15:17:17 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:17 --> Template Class Initialized
INFO - 2020-02-23 15:17:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:17 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:17 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:17 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:17 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:17 --> Model Class Initialized
ERROR - 2020-02-23 15:17:17 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:17:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:17:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:17:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:17:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:17:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:17:18 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:18 --> Total execution time: 0.5879
INFO - 2020-02-23 15:17:19 --> Config Class Initialized
INFO - 2020-02-23 15:17:19 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:19 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:19 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:19 --> URI Class Initialized
INFO - 2020-02-23 15:17:19 --> Router Class Initialized
INFO - 2020-02-23 15:17:19 --> Output Class Initialized
INFO - 2020-02-23 15:17:19 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:19 --> CSRF cookie sent
INFO - 2020-02-23 15:17:19 --> Input Class Initialized
INFO - 2020-02-23 15:17:19 --> Language Class Initialized
INFO - 2020-02-23 15:17:19 --> Language Class Initialized
INFO - 2020-02-23 15:17:19 --> Config Class Initialized
INFO - 2020-02-23 15:17:19 --> Loader Class Initialized
INFO - 2020-02-23 15:17:19 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:19 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:19 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:19 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:19 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:19 --> Parser Class Initialized
INFO - 2020-02-23 15:17:19 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:19 --> Model Class Initialized
INFO - 2020-02-23 15:17:19 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:19 --> Template Class Initialized
INFO - 2020-02-23 15:17:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:19 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:19 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:19 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:19 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:19 --> Model Class Initialized
ERROR - 2020-02-23 15:17:19 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:19 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:17:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:17:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:17:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:17:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:17:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:19 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:17:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:17:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:17:19 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:19 --> Total execution time: 0.6233
INFO - 2020-02-23 15:17:21 --> Config Class Initialized
INFO - 2020-02-23 15:17:21 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:21 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:21 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:21 --> URI Class Initialized
INFO - 2020-02-23 15:17:21 --> Router Class Initialized
INFO - 2020-02-23 15:17:21 --> Output Class Initialized
INFO - 2020-02-23 15:17:21 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:21 --> CSRF cookie sent
INFO - 2020-02-23 15:17:21 --> Input Class Initialized
INFO - 2020-02-23 15:17:21 --> Language Class Initialized
INFO - 2020-02-23 15:17:21 --> Language Class Initialized
INFO - 2020-02-23 15:17:21 --> Config Class Initialized
INFO - 2020-02-23 15:17:21 --> Loader Class Initialized
INFO - 2020-02-23 15:17:21 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:21 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:21 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:21 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:21 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:21 --> Parser Class Initialized
INFO - 2020-02-23 15:17:21 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:21 --> Model Class Initialized
INFO - 2020-02-23 15:17:21 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:21 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:21 --> Template Class Initialized
INFO - 2020-02-23 15:17:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:22 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:22 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:22 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:22 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:22 --> Model Class Initialized
ERROR - 2020-02-23 15:17:22 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:22 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:17:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:17:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:17:22 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:17:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:17:22 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:22 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:22 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:17:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:17:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:17:22 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:22 --> Total execution time: 0.6993
INFO - 2020-02-23 15:17:23 --> Config Class Initialized
INFO - 2020-02-23 15:17:23 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:23 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:23 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:23 --> URI Class Initialized
INFO - 2020-02-23 15:17:23 --> Router Class Initialized
INFO - 2020-02-23 15:17:23 --> Output Class Initialized
INFO - 2020-02-23 15:17:23 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:23 --> CSRF cookie sent
INFO - 2020-02-23 15:17:23 --> Input Class Initialized
INFO - 2020-02-23 15:17:23 --> Language Class Initialized
INFO - 2020-02-23 15:17:23 --> Language Class Initialized
INFO - 2020-02-23 15:17:23 --> Config Class Initialized
INFO - 2020-02-23 15:17:23 --> Loader Class Initialized
INFO - 2020-02-23 15:17:23 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:23 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:23 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:23 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:23 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:23 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:23 --> Parser Class Initialized
INFO - 2020-02-23 15:17:23 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:23 --> Model Class Initialized
INFO - 2020-02-23 15:17:23 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:23 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:23 --> Template Class Initialized
INFO - 2020-02-23 15:17:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:23 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:23 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:23 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:23 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:23 --> Model Class Initialized
ERROR - 2020-02-23 15:17:23 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:23 --> Helper loaded: inflector_helper
ERROR - 2020-02-23 15:17:23 --> Could not find the language line "Delele"
DEBUG - 2020-02-23 15:17:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-23 15:17:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:17:23 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:17:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:17:23 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:23 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:23 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:17:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:17:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:17:23 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:23 --> Total execution time: 0.6156
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:24 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:24 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:24 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:24 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:24 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:17:24 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:24 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:24 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:24 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:24 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:24 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:24 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:24 --> URI Class Initialized
INFO - 2020-02-23 15:17:24 --> URI Class Initialized
INFO - 2020-02-23 15:17:24 --> URI Class Initialized
INFO - 2020-02-23 15:17:24 --> URI Class Initialized
INFO - 2020-02-23 15:17:24 --> URI Class Initialized
INFO - 2020-02-23 15:17:24 --> URI Class Initialized
INFO - 2020-02-23 15:17:24 --> Router Class Initialized
INFO - 2020-02-23 15:17:24 --> Router Class Initialized
INFO - 2020-02-23 15:17:24 --> Router Class Initialized
INFO - 2020-02-23 15:17:24 --> Router Class Initialized
INFO - 2020-02-23 15:17:24 --> Router Class Initialized
INFO - 2020-02-23 15:17:24 --> Router Class Initialized
INFO - 2020-02-23 15:17:24 --> Output Class Initialized
INFO - 2020-02-23 15:17:24 --> Output Class Initialized
INFO - 2020-02-23 15:17:24 --> Output Class Initialized
INFO - 2020-02-23 15:17:24 --> Output Class Initialized
INFO - 2020-02-23 15:17:24 --> Output Class Initialized
INFO - 2020-02-23 15:17:24 --> Output Class Initialized
INFO - 2020-02-23 15:17:24 --> Security Class Initialized
INFO - 2020-02-23 15:17:24 --> Security Class Initialized
INFO - 2020-02-23 15:17:24 --> Security Class Initialized
INFO - 2020-02-23 15:17:24 --> Security Class Initialized
INFO - 2020-02-23 15:17:24 --> Security Class Initialized
INFO - 2020-02-23 15:17:24 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:24 --> CSRF cookie sent
INFO - 2020-02-23 15:17:24 --> CSRF cookie sent
INFO - 2020-02-23 15:17:24 --> CSRF cookie sent
INFO - 2020-02-23 15:17:24 --> CSRF cookie sent
INFO - 2020-02-23 15:17:24 --> CSRF cookie sent
INFO - 2020-02-23 15:17:24 --> CSRF cookie sent
INFO - 2020-02-23 15:17:24 --> CSRF token verified
INFO - 2020-02-23 15:17:24 --> CSRF token verified
INFO - 2020-02-23 15:17:24 --> CSRF token verified
INFO - 2020-02-23 15:17:24 --> CSRF token verified
INFO - 2020-02-23 15:17:24 --> CSRF token verified
INFO - 2020-02-23 15:17:24 --> CSRF token verified
INFO - 2020-02-23 15:17:24 --> Input Class Initialized
INFO - 2020-02-23 15:17:24 --> Input Class Initialized
INFO - 2020-02-23 15:17:24 --> Input Class Initialized
INFO - 2020-02-23 15:17:24 --> Input Class Initialized
INFO - 2020-02-23 15:17:24 --> Input Class Initialized
INFO - 2020-02-23 15:17:24 --> Input Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Loader Class Initialized
INFO - 2020-02-23 15:17:24 --> Loader Class Initialized
INFO - 2020-02-23 15:17:24 --> Loader Class Initialized
INFO - 2020-02-23 15:17:24 --> Loader Class Initialized
INFO - 2020-02-23 15:17:24 --> Loader Class Initialized
INFO - 2020-02-23 15:17:24 --> Loader Class Initialized
INFO - 2020-02-23 15:17:24 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:24 --> Parser Class Initialized
INFO - 2020-02-23 15:17:24 --> Parser Class Initialized
INFO - 2020-02-23 15:17:24 --> Parser Class Initialized
INFO - 2020-02-23 15:17:24 --> Parser Class Initialized
INFO - 2020-02-23 15:17:24 --> Parser Class Initialized
INFO - 2020-02-23 15:17:24 --> Parser Class Initialized
INFO - 2020-02-23 15:17:24 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:24 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:24 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:24 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:24 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:24 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:24 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:24 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:24 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:24 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:24 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Template Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Template Class Initialized
INFO - 2020-02-23 15:17:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:24 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:24 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:24 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:24 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:24 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:24 --> Total execution time: 0.5676
INFO - 2020-02-23 15:17:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
INFO - 2020-02-23 15:17:24 --> Hooks Class Initialized
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:24 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:24 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:24 --> Utf8 Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:24 --> URI Class Initialized
INFO - 2020-02-23 15:17:24 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:24 --> Router Class Initialized
INFO - 2020-02-23 15:17:24 --> Controller Class Initialized
INFO - 2020-02-23 15:17:24 --> Output Class Initialized
DEBUG - 2020-02-23 15:17:24 --> category MX_Controller Initialized
INFO - 2020-02-23 15:17:24 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
DEBUG - 2020-02-23 15:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:24 --> CSRF cookie sent
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
INFO - 2020-02-23 15:17:24 --> CSRF token verified
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:24 --> Input Class Initialized
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "View"
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "View"
INFO - 2020-02-23 15:17:24 --> Language Class Initialized
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "View"
INFO - 2020-02-23 15:17:24 --> Config Class Initialized
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "View"
INFO - 2020-02-23 15:17:24 --> Loader Class Initialized
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "View"
INFO - 2020-02-23 15:17:24 --> Helper loaded: url_helper
DEBUG - 2020-02-23 15:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:24 --> Final output sent to browser
INFO - 2020-02-23 15:17:24 --> Helper loaded: common_helper
DEBUG - 2020-02-23 15:17:24 --> Total execution time: 0.7876
INFO - 2020-02-23 15:17:24 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:24 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:24 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:24 --> Pagination Class Initialized
INFO - 2020-02-23 15:17:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:24 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-23 15:17:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:24 --> Parser Class Initialized
INFO - 2020-02-23 15:17:24 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:24 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:24 --> Controller Class Initialized
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:24 --> category MX_Controller Initialized
INFO - 2020-02-23 15:17:24 --> Database Driver Class Initialized
DEBUG - 2020-02-23 15:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:24 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:24 --> Template Class Initialized
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:24 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:25 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:25 --> Total execution time: 0.9543
INFO - 2020-02-23 15:17:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:25 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:25 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:25 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:25 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:25 --> Model Class Initialized
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:25 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:25 --> Total execution time: 1.0983
INFO - 2020-02-23 15:17:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:25 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:25 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:25 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:25 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:25 --> Model Class Initialized
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "View"
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:25 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:25 --> Total execution time: 1.2770
INFO - 2020-02-23 15:17:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:25 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:25 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:25 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:25 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:25 --> Model Class Initialized
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:25 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:25 --> Total execution time: 1.4361
INFO - 2020-02-23 15:17:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:25 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:25 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:25 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:25 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:25 --> Model Class Initialized
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:17:25 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:17:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:17:25 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:25 --> Total execution time: 1.0259
INFO - 2020-02-23 15:17:26 --> Config Class Initialized
INFO - 2020-02-23 15:17:26 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:17:26 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:17:26 --> Utf8 Class Initialized
INFO - 2020-02-23 15:17:26 --> URI Class Initialized
INFO - 2020-02-23 15:17:26 --> Router Class Initialized
INFO - 2020-02-23 15:17:26 --> Output Class Initialized
INFO - 2020-02-23 15:17:26 --> Security Class Initialized
DEBUG - 2020-02-23 15:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:17:26 --> CSRF cookie sent
INFO - 2020-02-23 15:17:26 --> Input Class Initialized
INFO - 2020-02-23 15:17:26 --> Language Class Initialized
INFO - 2020-02-23 15:17:26 --> Language Class Initialized
INFO - 2020-02-23 15:17:26 --> Config Class Initialized
INFO - 2020-02-23 15:17:26 --> Loader Class Initialized
INFO - 2020-02-23 15:17:26 --> Helper loaded: url_helper
INFO - 2020-02-23 15:17:26 --> Helper loaded: common_helper
INFO - 2020-02-23 15:17:26 --> Helper loaded: language_helper
INFO - 2020-02-23 15:17:26 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:17:26 --> Helper loaded: email_helper
INFO - 2020-02-23 15:17:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:17:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:17:26 --> Parser Class Initialized
INFO - 2020-02-23 15:17:26 --> User Agent Class Initialized
INFO - 2020-02-23 15:17:26 --> Model Class Initialized
INFO - 2020-02-23 15:17:27 --> Database Driver Class Initialized
INFO - 2020-02-23 15:17:27 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:27 --> Template Class Initialized
INFO - 2020-02-23 15:17:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:17:27 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:17:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:17:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:17:27 --> Encryption Class Initialized
INFO - 2020-02-23 15:17:27 --> Controller Class Initialized
DEBUG - 2020-02-23 15:17:27 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:17:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:27 --> Model Class Initialized
ERROR - 2020-02-23 15:17:27 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:17:27 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:17:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:17:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:17:27 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:17:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:17:27 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:27 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:17:27 --> Model Class Initialized
DEBUG - 2020-02-23 15:17:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:17:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:17:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:17:27 --> Final output sent to browser
DEBUG - 2020-02-23 15:17:27 --> Total execution time: 0.8032
INFO - 2020-02-23 15:19:56 --> Config Class Initialized
INFO - 2020-02-23 15:19:56 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:19:56 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:19:56 --> Utf8 Class Initialized
INFO - 2020-02-23 15:19:56 --> URI Class Initialized
INFO - 2020-02-23 15:19:56 --> Router Class Initialized
INFO - 2020-02-23 15:19:56 --> Output Class Initialized
INFO - 2020-02-23 15:19:56 --> Security Class Initialized
DEBUG - 2020-02-23 15:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:19:56 --> CSRF cookie sent
INFO - 2020-02-23 15:19:56 --> Input Class Initialized
INFO - 2020-02-23 15:19:56 --> Language Class Initialized
INFO - 2020-02-23 15:19:56 --> Language Class Initialized
INFO - 2020-02-23 15:19:56 --> Config Class Initialized
INFO - 2020-02-23 15:19:56 --> Loader Class Initialized
INFO - 2020-02-23 15:19:56 --> Helper loaded: url_helper
INFO - 2020-02-23 15:19:56 --> Helper loaded: common_helper
INFO - 2020-02-23 15:19:56 --> Helper loaded: language_helper
INFO - 2020-02-23 15:19:56 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:19:56 --> Helper loaded: email_helper
INFO - 2020-02-23 15:19:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:19:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:19:56 --> Parser Class Initialized
INFO - 2020-02-23 15:19:56 --> User Agent Class Initialized
INFO - 2020-02-23 15:19:56 --> Model Class Initialized
INFO - 2020-02-23 15:19:56 --> Database Driver Class Initialized
INFO - 2020-02-23 15:19:56 --> Model Class Initialized
DEBUG - 2020-02-23 15:19:56 --> Template Class Initialized
INFO - 2020-02-23 15:19:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:19:56 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:19:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:19:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:19:56 --> Encryption Class Initialized
INFO - 2020-02-23 15:19:56 --> Controller Class Initialized
DEBUG - 2020-02-23 15:19:56 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:19:56 --> Model Class Initialized
ERROR - 2020-02-23 15:19:56 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:19:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:19:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:19:56 --> Model Class Initialized
DEBUG - 2020-02-23 15:19:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:19:56 --> Model Class Initialized
DEBUG - 2020-02-23 15:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:19:56 --> Final output sent to browser
DEBUG - 2020-02-23 15:19:56 --> Total execution time: 0.7265
INFO - 2020-02-23 15:21:16 --> Config Class Initialized
INFO - 2020-02-23 15:21:16 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:21:16 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:16 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:16 --> URI Class Initialized
INFO - 2020-02-23 15:21:16 --> Router Class Initialized
INFO - 2020-02-23 15:21:16 --> Output Class Initialized
INFO - 2020-02-23 15:21:16 --> Security Class Initialized
DEBUG - 2020-02-23 15:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:21:16 --> CSRF cookie sent
INFO - 2020-02-23 15:21:16 --> Input Class Initialized
INFO - 2020-02-23 15:21:16 --> Language Class Initialized
INFO - 2020-02-23 15:21:17 --> Language Class Initialized
INFO - 2020-02-23 15:21:17 --> Config Class Initialized
INFO - 2020-02-23 15:21:17 --> Loader Class Initialized
INFO - 2020-02-23 15:21:17 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:17 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:17 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:17 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:17 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:17 --> Parser Class Initialized
INFO - 2020-02-23 15:21:17 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:17 --> Model Class Initialized
INFO - 2020-02-23 15:21:17 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:17 --> Template Class Initialized
INFO - 2020-02-23 15:21:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:17 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:17 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:17 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:17 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:17 --> Model Class Initialized
ERROR - 2020-02-23 15:21:17 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:21:17 --> Helper loaded: inflector_helper
ERROR - 2020-02-23 15:21:17 --> Could not find the language line "Delele"
DEBUG - 2020-02-23 15:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-23 15:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:21:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:21:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:21:17 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:17 --> Total execution time: 0.7205
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-23 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-23 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-23 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-23 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-23 15:21:18 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:18 --> Utf8 Class Initialized
DEBUG - 2020-02-23 15:21:18 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:18 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:18 --> URI Class Initialized
INFO - 2020-02-23 15:21:18 --> URI Class Initialized
INFO - 2020-02-23 15:21:18 --> URI Class Initialized
INFO - 2020-02-23 15:21:18 --> URI Class Initialized
INFO - 2020-02-23 15:21:18 --> URI Class Initialized
INFO - 2020-02-23 15:21:18 --> URI Class Initialized
INFO - 2020-02-23 15:21:18 --> Router Class Initialized
INFO - 2020-02-23 15:21:18 --> Router Class Initialized
INFO - 2020-02-23 15:21:18 --> Router Class Initialized
INFO - 2020-02-23 15:21:18 --> Router Class Initialized
INFO - 2020-02-23 15:21:18 --> Router Class Initialized
INFO - 2020-02-23 15:21:18 --> Output Class Initialized
INFO - 2020-02-23 15:21:18 --> Output Class Initialized
INFO - 2020-02-23 15:21:18 --> Output Class Initialized
INFO - 2020-02-23 15:21:18 --> Output Class Initialized
INFO - 2020-02-23 15:21:18 --> Output Class Initialized
INFO - 2020-02-23 15:21:18 --> Router Class Initialized
INFO - 2020-02-23 15:21:18 --> Security Class Initialized
INFO - 2020-02-23 15:21:18 --> Security Class Initialized
INFO - 2020-02-23 15:21:18 --> Security Class Initialized
INFO - 2020-02-23 15:21:18 --> Security Class Initialized
INFO - 2020-02-23 15:21:18 --> Security Class Initialized
INFO - 2020-02-23 15:21:18 --> Output Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:21:18 --> Security Class Initialized
INFO - 2020-02-23 15:21:18 --> CSRF cookie sent
INFO - 2020-02-23 15:21:18 --> CSRF cookie sent
INFO - 2020-02-23 15:21:18 --> CSRF cookie sent
INFO - 2020-02-23 15:21:18 --> CSRF cookie sent
INFO - 2020-02-23 15:21:18 --> CSRF cookie sent
DEBUG - 2020-02-23 15:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:21:18 --> CSRF token verified
INFO - 2020-02-23 15:21:18 --> CSRF token verified
INFO - 2020-02-23 15:21:18 --> CSRF cookie sent
INFO - 2020-02-23 15:21:18 --> CSRF token verified
INFO - 2020-02-23 15:21:18 --> CSRF token verified
INFO - 2020-02-23 15:21:18 --> CSRF token verified
INFO - 2020-02-23 15:21:18 --> Input Class Initialized
INFO - 2020-02-23 15:21:18 --> Input Class Initialized
INFO - 2020-02-23 15:21:18 --> Input Class Initialized
INFO - 2020-02-23 15:21:18 --> Input Class Initialized
INFO - 2020-02-23 15:21:18 --> CSRF token verified
INFO - 2020-02-23 15:21:18 --> Input Class Initialized
INFO - 2020-02-23 15:21:18 --> Input Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Language Class Initialized
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Loader Class Initialized
INFO - 2020-02-23 15:21:18 --> Loader Class Initialized
INFO - 2020-02-23 15:21:18 --> Loader Class Initialized
INFO - 2020-02-23 15:21:18 --> Loader Class Initialized
INFO - 2020-02-23 15:21:18 --> Loader Class Initialized
INFO - 2020-02-23 15:21:18 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:18 --> Loader Class Initialized
INFO - 2020-02-23 15:21:18 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:18 --> Parser Class Initialized
INFO - 2020-02-23 15:21:18 --> Parser Class Initialized
INFO - 2020-02-23 15:21:18 --> Parser Class Initialized
INFO - 2020-02-23 15:21:18 --> Parser Class Initialized
INFO - 2020-02-23 15:21:18 --> Parser Class Initialized
INFO - 2020-02-23 15:21:18 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:18 --> Parser Class Initialized
INFO - 2020-02-23 15:21:18 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:18 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:18 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:18 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:18 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:18 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:18 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:18 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Template Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Template Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Template Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Template Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Template Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Template Class Initialized
INFO - 2020-02-23 15:21:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:18 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:18 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:18 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:18 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
ERROR - 2020-02-23 15:21:18 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:21:18 --> Could not find the language line "View"
ERROR - 2020-02-23 15:21:18 --> Could not find the language line "View"
ERROR - 2020-02-23 15:21:18 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:21:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:21:18 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:18 --> Total execution time: 0.6777
INFO - 2020-02-23 15:21:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:18 --> Config Class Initialized
INFO - 2020-02-23 15:21:18 --> Hooks Class Initialized
INFO - 2020-02-23 15:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:18 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:18 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:18 --> Utf8 Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:18 --> URI Class Initialized
INFO - 2020-02-23 15:21:18 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:18 --> Router Class Initialized
INFO - 2020-02-23 15:21:18 --> Controller Class Initialized
INFO - 2020-02-23 15:21:18 --> Output Class Initialized
DEBUG - 2020-02-23 15:21:18 --> category MX_Controller Initialized
INFO - 2020-02-23 15:21:18 --> Security Class Initialized
DEBUG - 2020-02-23 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-23 15:21:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:18 --> CSRF cookie sent
INFO - 2020-02-23 15:21:18 --> Model Class Initialized
INFO - 2020-02-23 15:21:18 --> CSRF token verified
ERROR - 2020-02-23 15:21:18 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:21:18 --> Input Class Initialized
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
INFO - 2020-02-23 15:21:19 --> Language Class Initialized
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
INFO - 2020-02-23 15:21:19 --> Language Class Initialized
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
INFO - 2020-02-23 15:21:19 --> Config Class Initialized
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
INFO - 2020-02-23 15:21:19 --> Loader Class Initialized
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
INFO - 2020-02-23 15:21:19 --> Helper loaded: url_helper
DEBUG - 2020-02-23 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:21:19 --> Final output sent to browser
INFO - 2020-02-23 15:21:19 --> Helper loaded: common_helper
DEBUG - 2020-02-23 15:21:19 --> Total execution time: 0.9594
INFO - 2020-02-23 15:21:19 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:19 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:19 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:19 --> Pagination Class Initialized
INFO - 2020-02-23 15:21:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:19 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-23 15:21:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:19 --> Parser Class Initialized
INFO - 2020-02-23 15:21:19 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:19 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:19 --> Controller Class Initialized
INFO - 2020-02-23 15:21:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:19 --> category MX_Controller Initialized
INFO - 2020-02-23 15:21:19 --> Database Driver Class Initialized
DEBUG - 2020-02-23 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:19 --> Model Class Initialized
INFO - 2020-02-23 15:21:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:19 --> Template Class Initialized
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:21:19 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:19 --> Total execution time: 1.1684
INFO - 2020-02-23 15:21:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:19 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:19 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:19 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:19 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:19 --> Model Class Initialized
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:21:19 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:19 --> Total execution time: 1.4403
INFO - 2020-02-23 15:21:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:19 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:19 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:19 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:19 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:19 --> Model Class Initialized
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:21:19 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:19 --> Total execution time: 1.6488
INFO - 2020-02-23 15:21:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:19 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:19 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:19 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:19 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:19 --> Model Class Initialized
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:21:19 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:21:19 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:19 --> Total execution time: 1.8174
INFO - 2020-02-23 15:21:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:20 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:20 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:20 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:20 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:20 --> Model Class Initialized
ERROR - 2020-02-23 15:21:20 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:21:20 --> Could not find the language line "View"
DEBUG - 2020-02-23 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-23 15:21:20 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:20 --> Total execution time: 1.2873
INFO - 2020-02-23 15:21:20 --> Config Class Initialized
INFO - 2020-02-23 15:21:20 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:21:20 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:20 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:20 --> URI Class Initialized
INFO - 2020-02-23 15:21:20 --> Router Class Initialized
INFO - 2020-02-23 15:21:20 --> Output Class Initialized
INFO - 2020-02-23 15:21:20 --> Security Class Initialized
DEBUG - 2020-02-23 15:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:21:20 --> CSRF cookie sent
INFO - 2020-02-23 15:21:20 --> Input Class Initialized
INFO - 2020-02-23 15:21:20 --> Language Class Initialized
INFO - 2020-02-23 15:21:20 --> Language Class Initialized
INFO - 2020-02-23 15:21:20 --> Config Class Initialized
INFO - 2020-02-23 15:21:20 --> Loader Class Initialized
INFO - 2020-02-23 15:21:20 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:20 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:20 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:20 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:20 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:20 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:20 --> Parser Class Initialized
INFO - 2020-02-23 15:21:20 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:20 --> Model Class Initialized
INFO - 2020-02-23 15:21:20 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:20 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:20 --> Template Class Initialized
INFO - 2020-02-23 15:21:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:20 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:20 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:20 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:20 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:20 --> Model Class Initialized
ERROR - 2020-02-23 15:21:20 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:21:20 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:21:20 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:21:20 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:20 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:20 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:21:20 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:20 --> Total execution time: 0.6898
INFO - 2020-02-23 15:21:45 --> Config Class Initialized
INFO - 2020-02-23 15:21:45 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:21:45 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:45 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:45 --> URI Class Initialized
INFO - 2020-02-23 15:21:45 --> Router Class Initialized
INFO - 2020-02-23 15:21:45 --> Output Class Initialized
INFO - 2020-02-23 15:21:45 --> Security Class Initialized
DEBUG - 2020-02-23 15:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:21:45 --> CSRF cookie sent
INFO - 2020-02-23 15:21:45 --> Input Class Initialized
INFO - 2020-02-23 15:21:45 --> Language Class Initialized
INFO - 2020-02-23 15:21:45 --> Language Class Initialized
INFO - 2020-02-23 15:21:45 --> Config Class Initialized
INFO - 2020-02-23 15:21:45 --> Loader Class Initialized
INFO - 2020-02-23 15:21:45 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:45 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:45 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:45 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:45 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:46 --> Parser Class Initialized
INFO - 2020-02-23 15:21:46 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:46 --> Model Class Initialized
INFO - 2020-02-23 15:21:46 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:46 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:46 --> Template Class Initialized
INFO - 2020-02-23 15:21:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:46 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:46 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:46 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:46 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:46 --> Model Class Initialized
ERROR - 2020-02-23 15:21:46 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:21:46 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:21:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:21:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:21:46 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:21:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:21:46 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:46 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:46 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:21:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:21:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:21:46 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:46 --> Total execution time: 0.7216
INFO - 2020-02-23 15:21:48 --> Config Class Initialized
INFO - 2020-02-23 15:21:48 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:21:48 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:48 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:48 --> URI Class Initialized
INFO - 2020-02-23 15:21:48 --> Router Class Initialized
INFO - 2020-02-23 15:21:48 --> Output Class Initialized
INFO - 2020-02-23 15:21:48 --> Security Class Initialized
DEBUG - 2020-02-23 15:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:21:48 --> CSRF cookie sent
INFO - 2020-02-23 15:21:48 --> Input Class Initialized
INFO - 2020-02-23 15:21:48 --> Language Class Initialized
INFO - 2020-02-23 15:21:48 --> Language Class Initialized
INFO - 2020-02-23 15:21:48 --> Config Class Initialized
INFO - 2020-02-23 15:21:48 --> Loader Class Initialized
INFO - 2020-02-23 15:21:48 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:48 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:48 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:48 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:48 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:48 --> Parser Class Initialized
INFO - 2020-02-23 15:21:48 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:48 --> Model Class Initialized
INFO - 2020-02-23 15:21:48 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:48 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:48 --> Template Class Initialized
INFO - 2020-02-23 15:21:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:48 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:48 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:49 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:49 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:49 --> Model Class Initialized
ERROR - 2020-02-23 15:21:49 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:21:49 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:21:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:21:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:21:49 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:21:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:21:49 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:49 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:49 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:21:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:21:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:21:49 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:49 --> Total execution time: 0.7379
INFO - 2020-02-23 15:21:54 --> Config Class Initialized
INFO - 2020-02-23 15:21:54 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:21:54 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:54 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:54 --> URI Class Initialized
INFO - 2020-02-23 15:21:54 --> Router Class Initialized
INFO - 2020-02-23 15:21:54 --> Output Class Initialized
INFO - 2020-02-23 15:21:54 --> Security Class Initialized
DEBUG - 2020-02-23 15:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:21:54 --> CSRF cookie sent
INFO - 2020-02-23 15:21:54 --> Input Class Initialized
INFO - 2020-02-23 15:21:54 --> Language Class Initialized
INFO - 2020-02-23 15:21:54 --> Language Class Initialized
INFO - 2020-02-23 15:21:54 --> Config Class Initialized
INFO - 2020-02-23 15:21:54 --> Loader Class Initialized
INFO - 2020-02-23 15:21:54 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:54 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:54 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:54 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:54 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:54 --> Parser Class Initialized
INFO - 2020-02-23 15:21:54 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:55 --> Model Class Initialized
INFO - 2020-02-23 15:21:55 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:55 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:55 --> Template Class Initialized
INFO - 2020-02-23 15:21:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:55 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:55 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:55 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:55 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:55 --> Model Class Initialized
ERROR - 2020-02-23 15:21:55 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:21:55 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:21:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:21:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:21:55 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:21:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:21:55 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:55 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:55 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:21:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:21:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:21:55 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:55 --> Total execution time: 0.6556
INFO - 2020-02-23 15:21:57 --> Config Class Initialized
INFO - 2020-02-23 15:21:57 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:21:57 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:57 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:57 --> URI Class Initialized
INFO - 2020-02-23 15:21:57 --> Router Class Initialized
INFO - 2020-02-23 15:21:57 --> Output Class Initialized
INFO - 2020-02-23 15:21:57 --> Security Class Initialized
DEBUG - 2020-02-23 15:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:21:57 --> CSRF cookie sent
INFO - 2020-02-23 15:21:57 --> Input Class Initialized
INFO - 2020-02-23 15:21:57 --> Language Class Initialized
INFO - 2020-02-23 15:21:57 --> Language Class Initialized
INFO - 2020-02-23 15:21:57 --> Config Class Initialized
INFO - 2020-02-23 15:21:57 --> Loader Class Initialized
INFO - 2020-02-23 15:21:57 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:57 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:57 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:57 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:57 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:57 --> Parser Class Initialized
INFO - 2020-02-23 15:21:57 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:57 --> Model Class Initialized
INFO - 2020-02-23 15:21:57 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:57 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:57 --> Template Class Initialized
INFO - 2020-02-23 15:21:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:57 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:57 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:57 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:57 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:57 --> Model Class Initialized
ERROR - 2020-02-23 15:21:57 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:21:57 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:21:57 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:21:57 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:57 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:57 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:21:57 --> Final output sent to browser
DEBUG - 2020-02-23 15:21:57 --> Total execution time: 0.7473
INFO - 2020-02-23 15:21:59 --> Config Class Initialized
INFO - 2020-02-23 15:21:59 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:21:59 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:21:59 --> Utf8 Class Initialized
INFO - 2020-02-23 15:21:59 --> URI Class Initialized
INFO - 2020-02-23 15:21:59 --> Router Class Initialized
INFO - 2020-02-23 15:21:59 --> Output Class Initialized
INFO - 2020-02-23 15:21:59 --> Security Class Initialized
DEBUG - 2020-02-23 15:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:21:59 --> CSRF cookie sent
INFO - 2020-02-23 15:21:59 --> Input Class Initialized
INFO - 2020-02-23 15:21:59 --> Language Class Initialized
INFO - 2020-02-23 15:21:59 --> Language Class Initialized
INFO - 2020-02-23 15:21:59 --> Config Class Initialized
INFO - 2020-02-23 15:21:59 --> Loader Class Initialized
INFO - 2020-02-23 15:21:59 --> Helper loaded: url_helper
INFO - 2020-02-23 15:21:59 --> Helper loaded: common_helper
INFO - 2020-02-23 15:21:59 --> Helper loaded: language_helper
INFO - 2020-02-23 15:21:59 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:21:59 --> Helper loaded: email_helper
INFO - 2020-02-23 15:21:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:21:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:21:59 --> Parser Class Initialized
INFO - 2020-02-23 15:21:59 --> User Agent Class Initialized
INFO - 2020-02-23 15:21:59 --> Model Class Initialized
INFO - 2020-02-23 15:21:59 --> Database Driver Class Initialized
INFO - 2020-02-23 15:21:59 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:59 --> Template Class Initialized
INFO - 2020-02-23 15:21:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:21:59 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:21:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:21:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:21:59 --> Encryption Class Initialized
INFO - 2020-02-23 15:21:59 --> Controller Class Initialized
DEBUG - 2020-02-23 15:21:59 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:59 --> Model Class Initialized
ERROR - 2020-02-23 15:21:59 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:21:59 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:21:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:21:59 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:59 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:21:59 --> Model Class Initialized
DEBUG - 2020-02-23 15:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:22:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:22:00 --> Final output sent to browser
DEBUG - 2020-02-23 15:22:00 --> Total execution time: 0.7977
INFO - 2020-02-23 15:22:00 --> Config Class Initialized
INFO - 2020-02-23 15:22:00 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:22:00 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:22:01 --> Utf8 Class Initialized
INFO - 2020-02-23 15:22:01 --> URI Class Initialized
INFO - 2020-02-23 15:22:01 --> Router Class Initialized
INFO - 2020-02-23 15:22:01 --> Output Class Initialized
INFO - 2020-02-23 15:22:01 --> Security Class Initialized
DEBUG - 2020-02-23 15:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:22:01 --> CSRF cookie sent
INFO - 2020-02-23 15:22:01 --> Input Class Initialized
INFO - 2020-02-23 15:22:01 --> Language Class Initialized
INFO - 2020-02-23 15:22:01 --> Language Class Initialized
INFO - 2020-02-23 15:22:01 --> Config Class Initialized
INFO - 2020-02-23 15:22:01 --> Loader Class Initialized
INFO - 2020-02-23 15:22:01 --> Helper loaded: url_helper
INFO - 2020-02-23 15:22:01 --> Helper loaded: common_helper
INFO - 2020-02-23 15:22:01 --> Helper loaded: language_helper
INFO - 2020-02-23 15:22:01 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:22:01 --> Helper loaded: email_helper
INFO - 2020-02-23 15:22:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:22:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:22:01 --> Parser Class Initialized
INFO - 2020-02-23 15:22:01 --> User Agent Class Initialized
INFO - 2020-02-23 15:22:01 --> Model Class Initialized
INFO - 2020-02-23 15:22:01 --> Database Driver Class Initialized
INFO - 2020-02-23 15:22:01 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:01 --> Template Class Initialized
INFO - 2020-02-23 15:22:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:22:01 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:22:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:22:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:22:01 --> Encryption Class Initialized
INFO - 2020-02-23 15:22:01 --> Controller Class Initialized
DEBUG - 2020-02-23 15:22:01 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:01 --> Model Class Initialized
ERROR - 2020-02-23 15:22:01 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:22:01 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:22:01 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:22:01 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:01 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:01 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:22:01 --> Final output sent to browser
DEBUG - 2020-02-23 15:22:01 --> Total execution time: 0.8256
INFO - 2020-02-23 15:22:03 --> Config Class Initialized
INFO - 2020-02-23 15:22:03 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:22:03 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:22:03 --> Utf8 Class Initialized
INFO - 2020-02-23 15:22:03 --> URI Class Initialized
INFO - 2020-02-23 15:22:03 --> Router Class Initialized
INFO - 2020-02-23 15:22:03 --> Output Class Initialized
INFO - 2020-02-23 15:22:03 --> Security Class Initialized
DEBUG - 2020-02-23 15:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:22:03 --> CSRF cookie sent
INFO - 2020-02-23 15:22:03 --> Input Class Initialized
INFO - 2020-02-23 15:22:03 --> Language Class Initialized
INFO - 2020-02-23 15:22:03 --> Language Class Initialized
INFO - 2020-02-23 15:22:03 --> Config Class Initialized
INFO - 2020-02-23 15:22:03 --> Loader Class Initialized
INFO - 2020-02-23 15:22:03 --> Helper loaded: url_helper
INFO - 2020-02-23 15:22:03 --> Helper loaded: common_helper
INFO - 2020-02-23 15:22:03 --> Helper loaded: language_helper
INFO - 2020-02-23 15:22:03 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:22:03 --> Helper loaded: email_helper
INFO - 2020-02-23 15:22:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:22:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:22:03 --> Parser Class Initialized
INFO - 2020-02-23 15:22:03 --> User Agent Class Initialized
INFO - 2020-02-23 15:22:03 --> Model Class Initialized
INFO - 2020-02-23 15:22:03 --> Database Driver Class Initialized
INFO - 2020-02-23 15:22:03 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:03 --> Template Class Initialized
INFO - 2020-02-23 15:22:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:22:03 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:22:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:22:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:22:03 --> Encryption Class Initialized
INFO - 2020-02-23 15:22:03 --> Controller Class Initialized
DEBUG - 2020-02-23 15:22:03 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:22:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:03 --> Model Class Initialized
ERROR - 2020-02-23 15:22:03 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:22:03 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:22:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:22:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:22:03 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:22:04 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:04 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:04 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:22:04 --> Final output sent to browser
DEBUG - 2020-02-23 15:22:04 --> Total execution time: 0.8198
INFO - 2020-02-23 15:22:05 --> Config Class Initialized
INFO - 2020-02-23 15:22:05 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:22:05 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:22:05 --> Utf8 Class Initialized
INFO - 2020-02-23 15:22:05 --> URI Class Initialized
INFO - 2020-02-23 15:22:05 --> Router Class Initialized
INFO - 2020-02-23 15:22:05 --> Output Class Initialized
INFO - 2020-02-23 15:22:05 --> Security Class Initialized
DEBUG - 2020-02-23 15:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:22:05 --> CSRF cookie sent
INFO - 2020-02-23 15:22:05 --> Input Class Initialized
INFO - 2020-02-23 15:22:05 --> Language Class Initialized
INFO - 2020-02-23 15:22:05 --> Language Class Initialized
INFO - 2020-02-23 15:22:05 --> Config Class Initialized
INFO - 2020-02-23 15:22:05 --> Loader Class Initialized
INFO - 2020-02-23 15:22:05 --> Helper loaded: url_helper
INFO - 2020-02-23 15:22:05 --> Helper loaded: common_helper
INFO - 2020-02-23 15:22:05 --> Helper loaded: language_helper
INFO - 2020-02-23 15:22:05 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:22:05 --> Helper loaded: email_helper
INFO - 2020-02-23 15:22:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:22:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:22:05 --> Parser Class Initialized
INFO - 2020-02-23 15:22:05 --> User Agent Class Initialized
INFO - 2020-02-23 15:22:05 --> Model Class Initialized
INFO - 2020-02-23 15:22:05 --> Database Driver Class Initialized
INFO - 2020-02-23 15:22:05 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:05 --> Template Class Initialized
INFO - 2020-02-23 15:22:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:22:05 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:22:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:22:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:22:05 --> Encryption Class Initialized
INFO - 2020-02-23 15:22:05 --> Controller Class Initialized
DEBUG - 2020-02-23 15:22:05 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:05 --> Model Class Initialized
ERROR - 2020-02-23 15:22:05 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:22:05 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:22:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:22:05 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:05 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:22:06 --> Final output sent to browser
DEBUG - 2020-02-23 15:22:06 --> Total execution time: 0.8732
INFO - 2020-02-23 15:22:10 --> Config Class Initialized
INFO - 2020-02-23 15:22:10 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:22:10 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:22:10 --> Utf8 Class Initialized
INFO - 2020-02-23 15:22:10 --> URI Class Initialized
INFO - 2020-02-23 15:22:10 --> Router Class Initialized
INFO - 2020-02-23 15:22:10 --> Output Class Initialized
INFO - 2020-02-23 15:22:10 --> Security Class Initialized
DEBUG - 2020-02-23 15:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:22:10 --> CSRF cookie sent
INFO - 2020-02-23 15:22:10 --> Input Class Initialized
INFO - 2020-02-23 15:22:10 --> Language Class Initialized
INFO - 2020-02-23 15:22:10 --> Language Class Initialized
INFO - 2020-02-23 15:22:10 --> Config Class Initialized
INFO - 2020-02-23 15:22:10 --> Loader Class Initialized
INFO - 2020-02-23 15:22:10 --> Helper loaded: url_helper
INFO - 2020-02-23 15:22:10 --> Helper loaded: common_helper
INFO - 2020-02-23 15:22:10 --> Helper loaded: language_helper
INFO - 2020-02-23 15:22:10 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:22:10 --> Helper loaded: email_helper
INFO - 2020-02-23 15:22:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:22:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:22:10 --> Parser Class Initialized
INFO - 2020-02-23 15:22:10 --> User Agent Class Initialized
INFO - 2020-02-23 15:22:10 --> Model Class Initialized
INFO - 2020-02-23 15:22:10 --> Database Driver Class Initialized
INFO - 2020-02-23 15:22:10 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:10 --> Template Class Initialized
INFO - 2020-02-23 15:22:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:22:10 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:22:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:22:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:22:10 --> Encryption Class Initialized
INFO - 2020-02-23 15:22:10 --> Controller Class Initialized
DEBUG - 2020-02-23 15:22:10 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:22:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:10 --> Model Class Initialized
ERROR - 2020-02-23 15:22:10 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:22:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:22:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:22:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:22:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:22:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:22:10 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:10 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:22:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:22:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:22:10 --> Final output sent to browser
DEBUG - 2020-02-23 15:22:10 --> Total execution time: 0.6775
INFO - 2020-02-23 15:22:12 --> Config Class Initialized
INFO - 2020-02-23 15:22:12 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:22:12 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:22:12 --> Utf8 Class Initialized
INFO - 2020-02-23 15:22:12 --> URI Class Initialized
INFO - 2020-02-23 15:22:12 --> Router Class Initialized
INFO - 2020-02-23 15:22:12 --> Output Class Initialized
INFO - 2020-02-23 15:22:12 --> Security Class Initialized
DEBUG - 2020-02-23 15:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:22:12 --> CSRF cookie sent
INFO - 2020-02-23 15:22:12 --> Input Class Initialized
INFO - 2020-02-23 15:22:12 --> Language Class Initialized
INFO - 2020-02-23 15:22:12 --> Language Class Initialized
INFO - 2020-02-23 15:22:12 --> Config Class Initialized
INFO - 2020-02-23 15:22:12 --> Loader Class Initialized
INFO - 2020-02-23 15:22:12 --> Helper loaded: url_helper
INFO - 2020-02-23 15:22:12 --> Helper loaded: common_helper
INFO - 2020-02-23 15:22:12 --> Helper loaded: language_helper
INFO - 2020-02-23 15:22:12 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:22:12 --> Helper loaded: email_helper
INFO - 2020-02-23 15:22:12 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:22:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:22:12 --> Parser Class Initialized
INFO - 2020-02-23 15:22:12 --> User Agent Class Initialized
INFO - 2020-02-23 15:22:12 --> Model Class Initialized
INFO - 2020-02-23 15:22:12 --> Database Driver Class Initialized
INFO - 2020-02-23 15:22:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:12 --> Template Class Initialized
INFO - 2020-02-23 15:22:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:22:12 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:22:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:22:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:22:12 --> Encryption Class Initialized
INFO - 2020-02-23 15:22:12 --> Controller Class Initialized
DEBUG - 2020-02-23 15:22:12 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:22:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:12 --> Model Class Initialized
ERROR - 2020-02-23 15:22:12 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:22:12 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:22:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:22:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:22:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:22:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:22:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:22:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:22:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:22:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:22:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:22:12 --> Final output sent to browser
DEBUG - 2020-02-23 15:22:12 --> Total execution time: 0.8251
INFO - 2020-02-23 15:23:16 --> Config Class Initialized
INFO - 2020-02-23 15:23:16 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:16 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:16 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:16 --> URI Class Initialized
INFO - 2020-02-23 15:23:16 --> Router Class Initialized
INFO - 2020-02-23 15:23:16 --> Output Class Initialized
INFO - 2020-02-23 15:23:16 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:16 --> CSRF cookie sent
INFO - 2020-02-23 15:23:16 --> Input Class Initialized
INFO - 2020-02-23 15:23:16 --> Language Class Initialized
INFO - 2020-02-23 15:23:17 --> Language Class Initialized
INFO - 2020-02-23 15:23:17 --> Config Class Initialized
INFO - 2020-02-23 15:23:17 --> Loader Class Initialized
INFO - 2020-02-23 15:23:17 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:17 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:17 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:17 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:17 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:17 --> Parser Class Initialized
INFO - 2020-02-23 15:23:17 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:17 --> Model Class Initialized
INFO - 2020-02-23 15:23:17 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:17 --> Template Class Initialized
INFO - 2020-02-23 15:23:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:17 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:17 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:17 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:17 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:17 --> Model Class Initialized
ERROR - 2020-02-23 15:23:17 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:17 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:17 --> Total execution time: 0.8419
INFO - 2020-02-23 15:23:19 --> Config Class Initialized
INFO - 2020-02-23 15:23:19 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:19 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:19 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:19 --> URI Class Initialized
INFO - 2020-02-23 15:23:19 --> Router Class Initialized
INFO - 2020-02-23 15:23:19 --> Output Class Initialized
INFO - 2020-02-23 15:23:19 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:19 --> CSRF cookie sent
INFO - 2020-02-23 15:23:19 --> Input Class Initialized
INFO - 2020-02-23 15:23:19 --> Language Class Initialized
INFO - 2020-02-23 15:23:19 --> Language Class Initialized
INFO - 2020-02-23 15:23:19 --> Config Class Initialized
INFO - 2020-02-23 15:23:19 --> Loader Class Initialized
INFO - 2020-02-23 15:23:19 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:19 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:19 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:19 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:19 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:19 --> Parser Class Initialized
INFO - 2020-02-23 15:23:19 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:19 --> Model Class Initialized
INFO - 2020-02-23 15:23:19 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:19 --> Template Class Initialized
INFO - 2020-02-23 15:23:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:19 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:19 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:19 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:19 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:19 --> Model Class Initialized
ERROR - 2020-02-23 15:23:19 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:19 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:19 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:20 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:20 --> Total execution time: 0.7916
INFO - 2020-02-23 15:23:21 --> Config Class Initialized
INFO - 2020-02-23 15:23:21 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:21 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:21 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:21 --> URI Class Initialized
INFO - 2020-02-23 15:23:21 --> Router Class Initialized
INFO - 2020-02-23 15:23:21 --> Output Class Initialized
INFO - 2020-02-23 15:23:21 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:21 --> CSRF cookie sent
INFO - 2020-02-23 15:23:21 --> Input Class Initialized
INFO - 2020-02-23 15:23:21 --> Language Class Initialized
INFO - 2020-02-23 15:23:21 --> Language Class Initialized
INFO - 2020-02-23 15:23:21 --> Config Class Initialized
INFO - 2020-02-23 15:23:21 --> Loader Class Initialized
INFO - 2020-02-23 15:23:21 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:21 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:21 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:21 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:21 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:21 --> Parser Class Initialized
INFO - 2020-02-23 15:23:21 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:21 --> Model Class Initialized
INFO - 2020-02-23 15:23:21 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:21 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:21 --> Template Class Initialized
INFO - 2020-02-23 15:23:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:21 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:21 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:21 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:21 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:21 --> Model Class Initialized
ERROR - 2020-02-23 15:23:21 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:21 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:21 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:22 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:22 --> Total execution time: 0.8520
INFO - 2020-02-23 15:23:23 --> Config Class Initialized
INFO - 2020-02-23 15:23:23 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:23 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:23 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:23 --> URI Class Initialized
INFO - 2020-02-23 15:23:23 --> Router Class Initialized
INFO - 2020-02-23 15:23:23 --> Output Class Initialized
INFO - 2020-02-23 15:23:23 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:23 --> CSRF cookie sent
INFO - 2020-02-23 15:23:23 --> Input Class Initialized
INFO - 2020-02-23 15:23:23 --> Language Class Initialized
INFO - 2020-02-23 15:23:23 --> Language Class Initialized
INFO - 2020-02-23 15:23:23 --> Config Class Initialized
INFO - 2020-02-23 15:23:23 --> Loader Class Initialized
INFO - 2020-02-23 15:23:23 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:23 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:23 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:23 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:23 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:23 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:23 --> Parser Class Initialized
INFO - 2020-02-23 15:23:23 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:23 --> Model Class Initialized
INFO - 2020-02-23 15:23:23 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:23 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:23 --> Template Class Initialized
INFO - 2020-02-23 15:23:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:23 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:23 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:23 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:23 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:23 --> Model Class Initialized
ERROR - 2020-02-23 15:23:23 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:23 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:23 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:23 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:23 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:23 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:24 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:24 --> Total execution time: 0.8331
INFO - 2020-02-23 15:23:25 --> Config Class Initialized
INFO - 2020-02-23 15:23:25 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:25 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:25 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:25 --> URI Class Initialized
INFO - 2020-02-23 15:23:25 --> Router Class Initialized
INFO - 2020-02-23 15:23:25 --> Output Class Initialized
INFO - 2020-02-23 15:23:25 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:25 --> CSRF cookie sent
INFO - 2020-02-23 15:23:25 --> Input Class Initialized
INFO - 2020-02-23 15:23:25 --> Language Class Initialized
INFO - 2020-02-23 15:23:25 --> Language Class Initialized
INFO - 2020-02-23 15:23:25 --> Config Class Initialized
INFO - 2020-02-23 15:23:25 --> Loader Class Initialized
INFO - 2020-02-23 15:23:25 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:25 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:25 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:25 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:25 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:25 --> Parser Class Initialized
INFO - 2020-02-23 15:23:25 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:25 --> Model Class Initialized
INFO - 2020-02-23 15:23:25 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:25 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:25 --> Template Class Initialized
INFO - 2020-02-23 15:23:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:25 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:25 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:25 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:25 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:25 --> Model Class Initialized
ERROR - 2020-02-23 15:23:25 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:25 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:25 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:25 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:25 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:25 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:26 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:26 --> Total execution time: 0.8429
INFO - 2020-02-23 15:23:28 --> Config Class Initialized
INFO - 2020-02-23 15:23:28 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:28 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:28 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:28 --> URI Class Initialized
INFO - 2020-02-23 15:23:28 --> Router Class Initialized
INFO - 2020-02-23 15:23:28 --> Output Class Initialized
INFO - 2020-02-23 15:23:28 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:28 --> CSRF cookie sent
INFO - 2020-02-23 15:23:28 --> Input Class Initialized
INFO - 2020-02-23 15:23:28 --> Language Class Initialized
INFO - 2020-02-23 15:23:28 --> Language Class Initialized
INFO - 2020-02-23 15:23:28 --> Config Class Initialized
INFO - 2020-02-23 15:23:28 --> Loader Class Initialized
INFO - 2020-02-23 15:23:28 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:28 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:28 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:28 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:28 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:28 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:28 --> Parser Class Initialized
INFO - 2020-02-23 15:23:28 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:28 --> Model Class Initialized
INFO - 2020-02-23 15:23:28 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:28 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:28 --> Template Class Initialized
INFO - 2020-02-23 15:23:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:28 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:28 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:28 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:28 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:28 --> Model Class Initialized
ERROR - 2020-02-23 15:23:28 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:28 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:28 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:28 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:28 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:28 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:29 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:29 --> Total execution time: 0.7101
INFO - 2020-02-23 15:23:30 --> Config Class Initialized
INFO - 2020-02-23 15:23:30 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:30 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:30 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:30 --> URI Class Initialized
INFO - 2020-02-23 15:23:30 --> Router Class Initialized
INFO - 2020-02-23 15:23:30 --> Output Class Initialized
INFO - 2020-02-23 15:23:30 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:30 --> CSRF cookie sent
INFO - 2020-02-23 15:23:30 --> Input Class Initialized
INFO - 2020-02-23 15:23:30 --> Language Class Initialized
INFO - 2020-02-23 15:23:30 --> Language Class Initialized
INFO - 2020-02-23 15:23:31 --> Config Class Initialized
INFO - 2020-02-23 15:23:31 --> Loader Class Initialized
INFO - 2020-02-23 15:23:31 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:31 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:31 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:31 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:31 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:31 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:31 --> Parser Class Initialized
INFO - 2020-02-23 15:23:31 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:31 --> Model Class Initialized
INFO - 2020-02-23 15:23:31 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:31 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:31 --> Template Class Initialized
INFO - 2020-02-23 15:23:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:31 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:31 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:31 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:31 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:31 --> Model Class Initialized
ERROR - 2020-02-23 15:23:31 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:31 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:31 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:31 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:31 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:31 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:31 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:31 --> Total execution time: 0.7667
INFO - 2020-02-23 15:23:53 --> Config Class Initialized
INFO - 2020-02-23 15:23:53 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:53 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:53 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:53 --> URI Class Initialized
INFO - 2020-02-23 15:23:53 --> Router Class Initialized
INFO - 2020-02-23 15:23:53 --> Output Class Initialized
INFO - 2020-02-23 15:23:53 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:53 --> CSRF cookie sent
INFO - 2020-02-23 15:23:53 --> Input Class Initialized
INFO - 2020-02-23 15:23:53 --> Language Class Initialized
INFO - 2020-02-23 15:23:53 --> Language Class Initialized
INFO - 2020-02-23 15:23:53 --> Config Class Initialized
INFO - 2020-02-23 15:23:53 --> Loader Class Initialized
INFO - 2020-02-23 15:23:53 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:53 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:53 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:53 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:53 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:54 --> Parser Class Initialized
INFO - 2020-02-23 15:23:54 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:54 --> Model Class Initialized
INFO - 2020-02-23 15:23:54 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:54 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:54 --> Template Class Initialized
INFO - 2020-02-23 15:23:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:54 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:54 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:54 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:54 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:54 --> Model Class Initialized
ERROR - 2020-02-23 15:23:54 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:54 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:54 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:54 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:54 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:54 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:54 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:54 --> Total execution time: 0.7338
INFO - 2020-02-23 15:23:56 --> Config Class Initialized
INFO - 2020-02-23 15:23:56 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:56 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:56 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:56 --> URI Class Initialized
INFO - 2020-02-23 15:23:56 --> Router Class Initialized
INFO - 2020-02-23 15:23:56 --> Output Class Initialized
INFO - 2020-02-23 15:23:56 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:56 --> CSRF cookie sent
INFO - 2020-02-23 15:23:56 --> Input Class Initialized
INFO - 2020-02-23 15:23:56 --> Language Class Initialized
INFO - 2020-02-23 15:23:56 --> Language Class Initialized
INFO - 2020-02-23 15:23:56 --> Config Class Initialized
INFO - 2020-02-23 15:23:56 --> Loader Class Initialized
INFO - 2020-02-23 15:23:56 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:56 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:56 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:56 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:56 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:56 --> Parser Class Initialized
INFO - 2020-02-23 15:23:56 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:56 --> Model Class Initialized
INFO - 2020-02-23 15:23:56 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:56 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:56 --> Template Class Initialized
INFO - 2020-02-23 15:23:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:56 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:56 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:56 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:56 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:56 --> Model Class Initialized
ERROR - 2020-02-23 15:23:56 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:56 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:56 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:57 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:57 --> Total execution time: 0.9520
INFO - 2020-02-23 15:23:58 --> Config Class Initialized
INFO - 2020-02-23 15:23:58 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:23:58 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:23:58 --> Utf8 Class Initialized
INFO - 2020-02-23 15:23:58 --> URI Class Initialized
INFO - 2020-02-23 15:23:58 --> Router Class Initialized
INFO - 2020-02-23 15:23:58 --> Output Class Initialized
INFO - 2020-02-23 15:23:58 --> Security Class Initialized
DEBUG - 2020-02-23 15:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:23:58 --> CSRF cookie sent
INFO - 2020-02-23 15:23:58 --> Input Class Initialized
INFO - 2020-02-23 15:23:58 --> Language Class Initialized
INFO - 2020-02-23 15:23:58 --> Language Class Initialized
INFO - 2020-02-23 15:23:58 --> Config Class Initialized
INFO - 2020-02-23 15:23:58 --> Loader Class Initialized
INFO - 2020-02-23 15:23:58 --> Helper loaded: url_helper
INFO - 2020-02-23 15:23:58 --> Helper loaded: common_helper
INFO - 2020-02-23 15:23:58 --> Helper loaded: language_helper
INFO - 2020-02-23 15:23:58 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:23:58 --> Helper loaded: email_helper
INFO - 2020-02-23 15:23:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:23:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:23:58 --> Parser Class Initialized
INFO - 2020-02-23 15:23:58 --> User Agent Class Initialized
INFO - 2020-02-23 15:23:58 --> Model Class Initialized
INFO - 2020-02-23 15:23:58 --> Database Driver Class Initialized
INFO - 2020-02-23 15:23:58 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:58 --> Template Class Initialized
INFO - 2020-02-23 15:23:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:23:58 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:23:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:23:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:23:58 --> Encryption Class Initialized
INFO - 2020-02-23 15:23:58 --> Controller Class Initialized
DEBUG - 2020-02-23 15:23:58 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:58 --> Model Class Initialized
ERROR - 2020-02-23 15:23:58 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:23:58 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:23:58 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:23:58 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:58 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:23:58 --> Model Class Initialized
DEBUG - 2020-02-23 15:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:23:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:23:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:23:59 --> Final output sent to browser
DEBUG - 2020-02-23 15:23:59 --> Total execution time: 0.8967
INFO - 2020-02-23 15:24:00 --> Config Class Initialized
INFO - 2020-02-23 15:24:00 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:24:00 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:24:00 --> Utf8 Class Initialized
INFO - 2020-02-23 15:24:00 --> URI Class Initialized
INFO - 2020-02-23 15:24:00 --> Router Class Initialized
INFO - 2020-02-23 15:24:00 --> Output Class Initialized
INFO - 2020-02-23 15:24:00 --> Security Class Initialized
DEBUG - 2020-02-23 15:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:24:00 --> CSRF cookie sent
INFO - 2020-02-23 15:24:00 --> Input Class Initialized
INFO - 2020-02-23 15:24:00 --> Language Class Initialized
INFO - 2020-02-23 15:24:00 --> Language Class Initialized
INFO - 2020-02-23 15:24:00 --> Config Class Initialized
INFO - 2020-02-23 15:24:00 --> Loader Class Initialized
INFO - 2020-02-23 15:24:00 --> Helper loaded: url_helper
INFO - 2020-02-23 15:24:00 --> Helper loaded: common_helper
INFO - 2020-02-23 15:24:00 --> Helper loaded: language_helper
INFO - 2020-02-23 15:24:00 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:24:00 --> Helper loaded: email_helper
INFO - 2020-02-23 15:24:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:24:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:24:00 --> Parser Class Initialized
INFO - 2020-02-23 15:24:00 --> User Agent Class Initialized
INFO - 2020-02-23 15:24:00 --> Model Class Initialized
INFO - 2020-02-23 15:24:00 --> Database Driver Class Initialized
INFO - 2020-02-23 15:24:00 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:00 --> Template Class Initialized
INFO - 2020-02-23 15:24:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:24:00 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:24:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:24:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:24:00 --> Encryption Class Initialized
INFO - 2020-02-23 15:24:00 --> Controller Class Initialized
DEBUG - 2020-02-23 15:24:00 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:24:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:00 --> Model Class Initialized
ERROR - 2020-02-23 15:24:00 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:24:00 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:24:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:24:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:24:00 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:24:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:24:00 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:00 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:00 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:24:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:24:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:24:01 --> Final output sent to browser
DEBUG - 2020-02-23 15:24:01 --> Total execution time: 0.8409
INFO - 2020-02-23 15:24:04 --> Config Class Initialized
INFO - 2020-02-23 15:24:04 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:24:04 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:24:04 --> Utf8 Class Initialized
INFO - 2020-02-23 15:24:04 --> URI Class Initialized
INFO - 2020-02-23 15:24:04 --> Router Class Initialized
INFO - 2020-02-23 15:24:04 --> Output Class Initialized
INFO - 2020-02-23 15:24:04 --> Security Class Initialized
DEBUG - 2020-02-23 15:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:24:04 --> CSRF cookie sent
INFO - 2020-02-23 15:24:04 --> Input Class Initialized
INFO - 2020-02-23 15:24:04 --> Language Class Initialized
INFO - 2020-02-23 15:24:04 --> Language Class Initialized
INFO - 2020-02-23 15:24:04 --> Config Class Initialized
INFO - 2020-02-23 15:24:04 --> Loader Class Initialized
INFO - 2020-02-23 15:24:04 --> Helper loaded: url_helper
INFO - 2020-02-23 15:24:04 --> Helper loaded: common_helper
INFO - 2020-02-23 15:24:04 --> Helper loaded: language_helper
INFO - 2020-02-23 15:24:04 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:24:04 --> Helper loaded: email_helper
INFO - 2020-02-23 15:24:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:24:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:24:04 --> Parser Class Initialized
INFO - 2020-02-23 15:24:04 --> User Agent Class Initialized
INFO - 2020-02-23 15:24:04 --> Model Class Initialized
INFO - 2020-02-23 15:24:04 --> Database Driver Class Initialized
INFO - 2020-02-23 15:24:04 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:04 --> Template Class Initialized
INFO - 2020-02-23 15:24:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:24:04 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:24:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:24:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:24:05 --> Encryption Class Initialized
INFO - 2020-02-23 15:24:05 --> Controller Class Initialized
DEBUG - 2020-02-23 15:24:05 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:24:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:05 --> Model Class Initialized
ERROR - 2020-02-23 15:24:05 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:24:05 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:24:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:24:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:24:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:24:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:24:05 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:05 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:24:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:24:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:24:05 --> Final output sent to browser
DEBUG - 2020-02-23 15:24:05 --> Total execution time: 0.7230
INFO - 2020-02-23 15:24:08 --> Config Class Initialized
INFO - 2020-02-23 15:24:08 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:24:08 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:24:08 --> Utf8 Class Initialized
INFO - 2020-02-23 15:24:08 --> URI Class Initialized
INFO - 2020-02-23 15:24:08 --> Router Class Initialized
INFO - 2020-02-23 15:24:08 --> Output Class Initialized
INFO - 2020-02-23 15:24:08 --> Security Class Initialized
DEBUG - 2020-02-23 15:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:24:08 --> CSRF cookie sent
INFO - 2020-02-23 15:24:08 --> Input Class Initialized
INFO - 2020-02-23 15:24:08 --> Language Class Initialized
INFO - 2020-02-23 15:24:08 --> Language Class Initialized
INFO - 2020-02-23 15:24:08 --> Config Class Initialized
INFO - 2020-02-23 15:24:08 --> Loader Class Initialized
INFO - 2020-02-23 15:24:08 --> Helper loaded: url_helper
INFO - 2020-02-23 15:24:08 --> Helper loaded: common_helper
INFO - 2020-02-23 15:24:08 --> Helper loaded: language_helper
INFO - 2020-02-23 15:24:08 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:24:08 --> Helper loaded: email_helper
INFO - 2020-02-23 15:24:08 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:24:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:24:09 --> Parser Class Initialized
INFO - 2020-02-23 15:24:09 --> User Agent Class Initialized
INFO - 2020-02-23 15:24:09 --> Model Class Initialized
INFO - 2020-02-23 15:24:09 --> Database Driver Class Initialized
INFO - 2020-02-23 15:24:09 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:09 --> Template Class Initialized
INFO - 2020-02-23 15:24:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:24:09 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:24:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:24:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:24:09 --> Encryption Class Initialized
INFO - 2020-02-23 15:24:09 --> Controller Class Initialized
DEBUG - 2020-02-23 15:24:09 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:24:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:09 --> Model Class Initialized
ERROR - 2020-02-23 15:24:09 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:24:09 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:24:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:24:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:24:09 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:24:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:24:09 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:09 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:09 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:24:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:24:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:24:09 --> Final output sent to browser
DEBUG - 2020-02-23 15:24:09 --> Total execution time: 0.7744
INFO - 2020-02-23 15:24:10 --> Config Class Initialized
INFO - 2020-02-23 15:24:10 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:24:10 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:24:10 --> Utf8 Class Initialized
INFO - 2020-02-23 15:24:10 --> URI Class Initialized
INFO - 2020-02-23 15:24:10 --> Router Class Initialized
INFO - 2020-02-23 15:24:10 --> Output Class Initialized
INFO - 2020-02-23 15:24:10 --> Security Class Initialized
DEBUG - 2020-02-23 15:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:24:10 --> CSRF cookie sent
INFO - 2020-02-23 15:24:10 --> Input Class Initialized
INFO - 2020-02-23 15:24:10 --> Language Class Initialized
INFO - 2020-02-23 15:24:10 --> Language Class Initialized
INFO - 2020-02-23 15:24:10 --> Config Class Initialized
INFO - 2020-02-23 15:24:10 --> Loader Class Initialized
INFO - 2020-02-23 15:24:10 --> Helper loaded: url_helper
INFO - 2020-02-23 15:24:10 --> Helper loaded: common_helper
INFO - 2020-02-23 15:24:10 --> Helper loaded: language_helper
INFO - 2020-02-23 15:24:10 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:24:10 --> Helper loaded: email_helper
INFO - 2020-02-23 15:24:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:24:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:24:10 --> Parser Class Initialized
INFO - 2020-02-23 15:24:10 --> User Agent Class Initialized
INFO - 2020-02-23 15:24:10 --> Model Class Initialized
INFO - 2020-02-23 15:24:10 --> Database Driver Class Initialized
INFO - 2020-02-23 15:24:10 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:10 --> Template Class Initialized
INFO - 2020-02-23 15:24:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:24:10 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:24:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:24:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:24:10 --> Encryption Class Initialized
INFO - 2020-02-23 15:24:10 --> Controller Class Initialized
DEBUG - 2020-02-23 15:24:10 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:24:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:10 --> Model Class Initialized
ERROR - 2020-02-23 15:24:10 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:24:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:24:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:24:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:24:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:24:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:24:10 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:10 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:24:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:24:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:24:11 --> Final output sent to browser
DEBUG - 2020-02-23 15:24:11 --> Total execution time: 0.7470
INFO - 2020-02-23 15:24:12 --> Config Class Initialized
INFO - 2020-02-23 15:24:12 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:24:12 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:24:12 --> Utf8 Class Initialized
INFO - 2020-02-23 15:24:12 --> URI Class Initialized
INFO - 2020-02-23 15:24:12 --> Router Class Initialized
INFO - 2020-02-23 15:24:12 --> Output Class Initialized
INFO - 2020-02-23 15:24:12 --> Security Class Initialized
DEBUG - 2020-02-23 15:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:24:12 --> CSRF cookie sent
INFO - 2020-02-23 15:24:12 --> Input Class Initialized
INFO - 2020-02-23 15:24:12 --> Language Class Initialized
INFO - 2020-02-23 15:24:12 --> Language Class Initialized
INFO - 2020-02-23 15:24:12 --> Config Class Initialized
INFO - 2020-02-23 15:24:12 --> Loader Class Initialized
INFO - 2020-02-23 15:24:12 --> Helper loaded: url_helper
INFO - 2020-02-23 15:24:12 --> Helper loaded: common_helper
INFO - 2020-02-23 15:24:12 --> Helper loaded: language_helper
INFO - 2020-02-23 15:24:12 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:24:12 --> Helper loaded: email_helper
INFO - 2020-02-23 15:24:12 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:24:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:24:12 --> Parser Class Initialized
INFO - 2020-02-23 15:24:12 --> User Agent Class Initialized
INFO - 2020-02-23 15:24:12 --> Model Class Initialized
INFO - 2020-02-23 15:24:12 --> Database Driver Class Initialized
INFO - 2020-02-23 15:24:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:12 --> Template Class Initialized
INFO - 2020-02-23 15:24:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:24:12 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:24:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:24:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:24:12 --> Encryption Class Initialized
INFO - 2020-02-23 15:24:12 --> Controller Class Initialized
DEBUG - 2020-02-23 15:24:12 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:24:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:12 --> Model Class Initialized
ERROR - 2020-02-23 15:24:12 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:24:12 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:24:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:24:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:24:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:24:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:24:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:24:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:24:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:24:12 --> Final output sent to browser
DEBUG - 2020-02-23 15:24:12 --> Total execution time: 0.7250
INFO - 2020-02-23 15:24:13 --> Config Class Initialized
INFO - 2020-02-23 15:24:13 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:24:13 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:24:13 --> Utf8 Class Initialized
INFO - 2020-02-23 15:24:13 --> URI Class Initialized
INFO - 2020-02-23 15:24:13 --> Router Class Initialized
INFO - 2020-02-23 15:24:13 --> Output Class Initialized
INFO - 2020-02-23 15:24:13 --> Security Class Initialized
DEBUG - 2020-02-23 15:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:24:13 --> CSRF cookie sent
INFO - 2020-02-23 15:24:13 --> Input Class Initialized
INFO - 2020-02-23 15:24:13 --> Language Class Initialized
INFO - 2020-02-23 15:24:13 --> Language Class Initialized
INFO - 2020-02-23 15:24:13 --> Config Class Initialized
INFO - 2020-02-23 15:24:13 --> Loader Class Initialized
INFO - 2020-02-23 15:24:13 --> Helper loaded: url_helper
INFO - 2020-02-23 15:24:13 --> Helper loaded: common_helper
INFO - 2020-02-23 15:24:13 --> Helper loaded: language_helper
INFO - 2020-02-23 15:24:13 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:24:13 --> Helper loaded: email_helper
INFO - 2020-02-23 15:24:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:24:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:24:14 --> Parser Class Initialized
INFO - 2020-02-23 15:24:14 --> User Agent Class Initialized
INFO - 2020-02-23 15:24:14 --> Model Class Initialized
INFO - 2020-02-23 15:24:14 --> Database Driver Class Initialized
INFO - 2020-02-23 15:24:14 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:14 --> Template Class Initialized
INFO - 2020-02-23 15:24:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:24:14 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:24:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:24:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:24:14 --> Encryption Class Initialized
INFO - 2020-02-23 15:24:14 --> Controller Class Initialized
DEBUG - 2020-02-23 15:24:14 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:14 --> Model Class Initialized
ERROR - 2020-02-23 15:24:14 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:24:14 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:24:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:24:14 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:14 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:24:14 --> Final output sent to browser
DEBUG - 2020-02-23 15:24:14 --> Total execution time: 0.7558
INFO - 2020-02-23 15:24:15 --> Config Class Initialized
INFO - 2020-02-23 15:24:15 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:24:15 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:24:15 --> Utf8 Class Initialized
INFO - 2020-02-23 15:24:15 --> URI Class Initialized
INFO - 2020-02-23 15:24:15 --> Router Class Initialized
INFO - 2020-02-23 15:24:15 --> Output Class Initialized
INFO - 2020-02-23 15:24:15 --> Security Class Initialized
DEBUG - 2020-02-23 15:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:24:15 --> CSRF cookie sent
INFO - 2020-02-23 15:24:15 --> Input Class Initialized
INFO - 2020-02-23 15:24:15 --> Language Class Initialized
INFO - 2020-02-23 15:24:15 --> Language Class Initialized
INFO - 2020-02-23 15:24:15 --> Config Class Initialized
INFO - 2020-02-23 15:24:15 --> Loader Class Initialized
INFO - 2020-02-23 15:24:15 --> Helper loaded: url_helper
INFO - 2020-02-23 15:24:15 --> Helper loaded: common_helper
INFO - 2020-02-23 15:24:15 --> Helper loaded: language_helper
INFO - 2020-02-23 15:24:15 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:24:15 --> Helper loaded: email_helper
INFO - 2020-02-23 15:24:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:24:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:24:15 --> Parser Class Initialized
INFO - 2020-02-23 15:24:15 --> User Agent Class Initialized
INFO - 2020-02-23 15:24:15 --> Model Class Initialized
INFO - 2020-02-23 15:24:15 --> Database Driver Class Initialized
INFO - 2020-02-23 15:24:15 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:15 --> Template Class Initialized
INFO - 2020-02-23 15:24:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:24:15 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:24:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:24:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:24:15 --> Encryption Class Initialized
INFO - 2020-02-23 15:24:15 --> Controller Class Initialized
DEBUG - 2020-02-23 15:24:15 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:24:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:15 --> Model Class Initialized
ERROR - 2020-02-23 15:24:15 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:24:15 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:24:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:24:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:24:15 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:24:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:24:15 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:15 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:15 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:24:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:24:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:24:15 --> Final output sent to browser
DEBUG - 2020-02-23 15:24:15 --> Total execution time: 0.7490
INFO - 2020-02-23 15:24:17 --> Config Class Initialized
INFO - 2020-02-23 15:24:17 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:24:17 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:24:17 --> Utf8 Class Initialized
INFO - 2020-02-23 15:24:17 --> URI Class Initialized
INFO - 2020-02-23 15:24:17 --> Router Class Initialized
INFO - 2020-02-23 15:24:17 --> Output Class Initialized
INFO - 2020-02-23 15:24:17 --> Security Class Initialized
DEBUG - 2020-02-23 15:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:24:17 --> CSRF cookie sent
INFO - 2020-02-23 15:24:17 --> Input Class Initialized
INFO - 2020-02-23 15:24:17 --> Language Class Initialized
INFO - 2020-02-23 15:24:17 --> Language Class Initialized
INFO - 2020-02-23 15:24:17 --> Config Class Initialized
INFO - 2020-02-23 15:24:17 --> Loader Class Initialized
INFO - 2020-02-23 15:24:17 --> Helper loaded: url_helper
INFO - 2020-02-23 15:24:17 --> Helper loaded: common_helper
INFO - 2020-02-23 15:24:17 --> Helper loaded: language_helper
INFO - 2020-02-23 15:24:17 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:24:17 --> Helper loaded: email_helper
INFO - 2020-02-23 15:24:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:24:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:24:17 --> Parser Class Initialized
INFO - 2020-02-23 15:24:17 --> User Agent Class Initialized
INFO - 2020-02-23 15:24:17 --> Model Class Initialized
INFO - 2020-02-23 15:24:17 --> Database Driver Class Initialized
INFO - 2020-02-23 15:24:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:17 --> Template Class Initialized
INFO - 2020-02-23 15:24:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:24:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:24:17 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:24:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:24:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:24:17 --> Encryption Class Initialized
INFO - 2020-02-23 15:24:17 --> Controller Class Initialized
DEBUG - 2020-02-23 15:24:17 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:24:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:17 --> Model Class Initialized
ERROR - 2020-02-23 15:24:17 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:24:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:24:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:24:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:24:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:24:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:24:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:24:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:24:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:24:18 --> Final output sent to browser
DEBUG - 2020-02-23 15:24:18 --> Total execution time: 0.7627
INFO - 2020-02-23 15:24:18 --> Config Class Initialized
INFO - 2020-02-23 15:24:18 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:24:18 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:24:18 --> Utf8 Class Initialized
INFO - 2020-02-23 15:24:18 --> URI Class Initialized
INFO - 2020-02-23 15:24:18 --> Router Class Initialized
INFO - 2020-02-23 15:24:18 --> Output Class Initialized
INFO - 2020-02-23 15:24:18 --> Security Class Initialized
DEBUG - 2020-02-23 15:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:24:18 --> CSRF cookie sent
INFO - 2020-02-23 15:24:18 --> Input Class Initialized
INFO - 2020-02-23 15:24:18 --> Language Class Initialized
INFO - 2020-02-23 15:24:19 --> Language Class Initialized
INFO - 2020-02-23 15:24:19 --> Config Class Initialized
INFO - 2020-02-23 15:24:19 --> Loader Class Initialized
INFO - 2020-02-23 15:24:19 --> Helper loaded: url_helper
INFO - 2020-02-23 15:24:19 --> Helper loaded: common_helper
INFO - 2020-02-23 15:24:19 --> Helper loaded: language_helper
INFO - 2020-02-23 15:24:19 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:24:19 --> Helper loaded: email_helper
INFO - 2020-02-23 15:24:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:24:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:24:19 --> Parser Class Initialized
INFO - 2020-02-23 15:24:19 --> User Agent Class Initialized
INFO - 2020-02-23 15:24:19 --> Model Class Initialized
INFO - 2020-02-23 15:24:19 --> Database Driver Class Initialized
INFO - 2020-02-23 15:24:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:19 --> Template Class Initialized
INFO - 2020-02-23 15:24:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:24:19 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:24:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:24:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:24:19 --> Encryption Class Initialized
INFO - 2020-02-23 15:24:19 --> Controller Class Initialized
DEBUG - 2020-02-23 15:24:19 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:24:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:19 --> Model Class Initialized
ERROR - 2020-02-23 15:24:19 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:24:19 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:24:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:24:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:24:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:24:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:24:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:19 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:24:19 --> Model Class Initialized
DEBUG - 2020-02-23 15:24:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:24:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:24:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:24:19 --> Final output sent to browser
DEBUG - 2020-02-23 15:24:19 --> Total execution time: 0.7356
INFO - 2020-02-23 15:28:56 --> Config Class Initialized
INFO - 2020-02-23 15:28:56 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:28:56 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:28:56 --> Utf8 Class Initialized
INFO - 2020-02-23 15:28:56 --> URI Class Initialized
INFO - 2020-02-23 15:28:56 --> Router Class Initialized
INFO - 2020-02-23 15:28:56 --> Output Class Initialized
INFO - 2020-02-23 15:28:56 --> Security Class Initialized
DEBUG - 2020-02-23 15:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:28:56 --> CSRF cookie sent
INFO - 2020-02-23 15:28:56 --> CSRF token verified
INFO - 2020-02-23 15:28:56 --> Input Class Initialized
INFO - 2020-02-23 15:28:56 --> Language Class Initialized
INFO - 2020-02-23 15:28:56 --> Language Class Initialized
INFO - 2020-02-23 15:28:56 --> Config Class Initialized
INFO - 2020-02-23 15:28:56 --> Loader Class Initialized
INFO - 2020-02-23 15:28:56 --> Helper loaded: url_helper
INFO - 2020-02-23 15:28:56 --> Helper loaded: common_helper
INFO - 2020-02-23 15:28:57 --> Helper loaded: language_helper
INFO - 2020-02-23 15:28:57 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:28:57 --> Helper loaded: email_helper
INFO - 2020-02-23 15:28:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:28:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:28:57 --> Parser Class Initialized
INFO - 2020-02-23 15:28:57 --> User Agent Class Initialized
INFO - 2020-02-23 15:28:57 --> Model Class Initialized
INFO - 2020-02-23 15:28:57 --> Database Driver Class Initialized
INFO - 2020-02-23 15:28:57 --> Model Class Initialized
DEBUG - 2020-02-23 15:28:57 --> Template Class Initialized
INFO - 2020-02-23 15:28:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:28:57 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:28:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:28:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:28:57 --> Encryption Class Initialized
INFO - 2020-02-23 15:28:57 --> Controller Class Initialized
DEBUG - 2020-02-23 15:28:57 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:28:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:28:57 --> Model Class Initialized
ERROR - 2020-02-23 15:28:57 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:31:05 --> Config Class Initialized
INFO - 2020-02-23 15:31:05 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:31:05 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:31:05 --> Utf8 Class Initialized
INFO - 2020-02-23 15:31:05 --> URI Class Initialized
INFO - 2020-02-23 15:31:05 --> Router Class Initialized
INFO - 2020-02-23 15:31:05 --> Output Class Initialized
INFO - 2020-02-23 15:31:05 --> Security Class Initialized
DEBUG - 2020-02-23 15:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:31:05 --> CSRF cookie sent
INFO - 2020-02-23 15:31:05 --> CSRF token verified
INFO - 2020-02-23 15:31:05 --> Input Class Initialized
INFO - 2020-02-23 15:31:05 --> Language Class Initialized
INFO - 2020-02-23 15:31:05 --> Language Class Initialized
INFO - 2020-02-23 15:31:05 --> Config Class Initialized
INFO - 2020-02-23 15:31:05 --> Loader Class Initialized
INFO - 2020-02-23 15:31:05 --> Helper loaded: url_helper
INFO - 2020-02-23 15:31:05 --> Helper loaded: common_helper
INFO - 2020-02-23 15:31:05 --> Helper loaded: language_helper
INFO - 2020-02-23 15:31:05 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:31:05 --> Helper loaded: email_helper
INFO - 2020-02-23 15:31:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:31:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:31:05 --> Parser Class Initialized
INFO - 2020-02-23 15:31:05 --> User Agent Class Initialized
INFO - 2020-02-23 15:31:05 --> Model Class Initialized
INFO - 2020-02-23 15:31:05 --> Database Driver Class Initialized
INFO - 2020-02-23 15:31:05 --> Model Class Initialized
DEBUG - 2020-02-23 15:31:05 --> Template Class Initialized
INFO - 2020-02-23 15:31:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:31:05 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:31:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:31:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:31:05 --> Encryption Class Initialized
INFO - 2020-02-23 15:31:05 --> Controller Class Initialized
DEBUG - 2020-02-23 15:31:05 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:31:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:31:05 --> Model Class Initialized
ERROR - 2020-02-23 15:31:05 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:31:11 --> Config Class Initialized
INFO - 2020-02-23 15:31:11 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:31:11 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:31:11 --> Utf8 Class Initialized
INFO - 2020-02-23 15:31:12 --> URI Class Initialized
INFO - 2020-02-23 15:31:12 --> Router Class Initialized
INFO - 2020-02-23 15:31:12 --> Output Class Initialized
INFO - 2020-02-23 15:31:12 --> Security Class Initialized
DEBUG - 2020-02-23 15:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:31:12 --> CSRF cookie sent
INFO - 2020-02-23 15:31:12 --> Input Class Initialized
INFO - 2020-02-23 15:31:12 --> Language Class Initialized
INFO - 2020-02-23 15:31:12 --> Language Class Initialized
INFO - 2020-02-23 15:31:12 --> Config Class Initialized
INFO - 2020-02-23 15:31:12 --> Loader Class Initialized
INFO - 2020-02-23 15:31:12 --> Helper loaded: url_helper
INFO - 2020-02-23 15:31:12 --> Helper loaded: common_helper
INFO - 2020-02-23 15:31:12 --> Helper loaded: language_helper
INFO - 2020-02-23 15:31:12 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:31:12 --> Helper loaded: email_helper
INFO - 2020-02-23 15:31:12 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:31:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:31:12 --> Parser Class Initialized
INFO - 2020-02-23 15:31:12 --> User Agent Class Initialized
INFO - 2020-02-23 15:31:12 --> Model Class Initialized
INFO - 2020-02-23 15:31:12 --> Database Driver Class Initialized
INFO - 2020-02-23 15:31:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:31:12 --> Template Class Initialized
INFO - 2020-02-23 15:31:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:31:12 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:31:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:31:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:31:12 --> Encryption Class Initialized
INFO - 2020-02-23 15:31:12 --> Controller Class Initialized
DEBUG - 2020-02-23 15:31:12 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:31:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:31:12 --> Model Class Initialized
ERROR - 2020-02-23 15:31:12 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:31:12 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:31:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:31:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:31:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:31:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:31:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:31:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:31:12 --> Model Class Initialized
DEBUG - 2020-02-23 15:31:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:31:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:31:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:31:12 --> Final output sent to browser
DEBUG - 2020-02-23 15:31:12 --> Total execution time: 0.8772
INFO - 2020-02-23 15:31:15 --> Config Class Initialized
INFO - 2020-02-23 15:31:15 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:31:15 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:31:15 --> Utf8 Class Initialized
INFO - 2020-02-23 15:31:15 --> URI Class Initialized
INFO - 2020-02-23 15:31:15 --> Router Class Initialized
INFO - 2020-02-23 15:31:15 --> Output Class Initialized
INFO - 2020-02-23 15:31:15 --> Security Class Initialized
DEBUG - 2020-02-23 15:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:31:15 --> CSRF cookie sent
INFO - 2020-02-23 15:31:15 --> CSRF token verified
INFO - 2020-02-23 15:31:15 --> Input Class Initialized
INFO - 2020-02-23 15:31:15 --> Language Class Initialized
INFO - 2020-02-23 15:31:15 --> Language Class Initialized
INFO - 2020-02-23 15:31:15 --> Config Class Initialized
INFO - 2020-02-23 15:31:15 --> Loader Class Initialized
INFO - 2020-02-23 15:31:16 --> Helper loaded: url_helper
INFO - 2020-02-23 15:31:16 --> Helper loaded: common_helper
INFO - 2020-02-23 15:31:16 --> Helper loaded: language_helper
INFO - 2020-02-23 15:31:16 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:31:16 --> Helper loaded: email_helper
INFO - 2020-02-23 15:31:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:31:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:31:16 --> Parser Class Initialized
INFO - 2020-02-23 15:31:16 --> User Agent Class Initialized
INFO - 2020-02-23 15:31:16 --> Model Class Initialized
INFO - 2020-02-23 15:31:16 --> Database Driver Class Initialized
INFO - 2020-02-23 15:31:16 --> Model Class Initialized
DEBUG - 2020-02-23 15:31:16 --> Template Class Initialized
INFO - 2020-02-23 15:31:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:31:16 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:31:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:31:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:31:16 --> Encryption Class Initialized
INFO - 2020-02-23 15:31:16 --> Controller Class Initialized
DEBUG - 2020-02-23 15:31:16 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:31:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:31:16 --> Model Class Initialized
ERROR - 2020-02-23 15:31:16 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:39:50 --> Config Class Initialized
INFO - 2020-02-23 15:39:50 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:39:50 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:39:50 --> Utf8 Class Initialized
INFO - 2020-02-23 15:39:50 --> URI Class Initialized
INFO - 2020-02-23 15:39:50 --> Router Class Initialized
INFO - 2020-02-23 15:39:50 --> Output Class Initialized
INFO - 2020-02-23 15:39:50 --> Security Class Initialized
DEBUG - 2020-02-23 15:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:39:50 --> CSRF cookie sent
INFO - 2020-02-23 15:39:50 --> CSRF token verified
INFO - 2020-02-23 15:39:50 --> Input Class Initialized
INFO - 2020-02-23 15:39:50 --> Language Class Initialized
INFO - 2020-02-23 15:39:50 --> Language Class Initialized
INFO - 2020-02-23 15:39:50 --> Config Class Initialized
INFO - 2020-02-23 15:39:50 --> Loader Class Initialized
INFO - 2020-02-23 15:39:50 --> Helper loaded: url_helper
INFO - 2020-02-23 15:39:50 --> Helper loaded: common_helper
INFO - 2020-02-23 15:39:50 --> Helper loaded: language_helper
INFO - 2020-02-23 15:39:50 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:39:50 --> Helper loaded: email_helper
INFO - 2020-02-23 15:39:50 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:39:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:39:50 --> Parser Class Initialized
INFO - 2020-02-23 15:39:50 --> User Agent Class Initialized
INFO - 2020-02-23 15:39:50 --> Model Class Initialized
INFO - 2020-02-23 15:39:50 --> Database Driver Class Initialized
INFO - 2020-02-23 15:39:50 --> Model Class Initialized
DEBUG - 2020-02-23 15:39:50 --> Template Class Initialized
INFO - 2020-02-23 15:39:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:39:50 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:39:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:39:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:39:50 --> Encryption Class Initialized
INFO - 2020-02-23 15:39:50 --> Controller Class Initialized
DEBUG - 2020-02-23 15:39:50 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:39:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:39:50 --> Model Class Initialized
ERROR - 2020-02-23 15:39:50 --> Could not find the language line "Sorting"
ERROR - 2020-02-23 15:39:51 --> Severity: Notice --> Undefined variable: lang_code D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\controllers\category.php 155
INFO - 2020-02-23 15:40:37 --> Config Class Initialized
INFO - 2020-02-23 15:40:37 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:40:38 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:40:38 --> Utf8 Class Initialized
INFO - 2020-02-23 15:40:38 --> URI Class Initialized
INFO - 2020-02-23 15:40:38 --> Router Class Initialized
INFO - 2020-02-23 15:40:38 --> Output Class Initialized
INFO - 2020-02-23 15:40:38 --> Security Class Initialized
DEBUG - 2020-02-23 15:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:40:38 --> CSRF cookie sent
INFO - 2020-02-23 15:40:38 --> CSRF token verified
INFO - 2020-02-23 15:40:38 --> Input Class Initialized
INFO - 2020-02-23 15:40:38 --> Language Class Initialized
INFO - 2020-02-23 15:40:38 --> Language Class Initialized
INFO - 2020-02-23 15:40:38 --> Config Class Initialized
INFO - 2020-02-23 15:40:38 --> Loader Class Initialized
INFO - 2020-02-23 15:40:38 --> Helper loaded: url_helper
INFO - 2020-02-23 15:40:38 --> Helper loaded: common_helper
INFO - 2020-02-23 15:40:38 --> Helper loaded: language_helper
INFO - 2020-02-23 15:40:38 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:40:38 --> Helper loaded: email_helper
INFO - 2020-02-23 15:40:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:40:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:40:38 --> Parser Class Initialized
INFO - 2020-02-23 15:40:38 --> User Agent Class Initialized
INFO - 2020-02-23 15:40:38 --> Model Class Initialized
INFO - 2020-02-23 15:40:38 --> Database Driver Class Initialized
INFO - 2020-02-23 15:40:38 --> Model Class Initialized
DEBUG - 2020-02-23 15:40:38 --> Template Class Initialized
INFO - 2020-02-23 15:40:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:40:38 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:40:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:40:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:40:38 --> Encryption Class Initialized
INFO - 2020-02-23 15:40:38 --> Controller Class Initialized
DEBUG - 2020-02-23 15:40:38 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:40:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:40:38 --> Model Class Initialized
ERROR - 2020-02-23 15:40:38 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:40:48 --> Config Class Initialized
INFO - 2020-02-23 15:40:48 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:40:48 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:40:48 --> Utf8 Class Initialized
INFO - 2020-02-23 15:40:48 --> URI Class Initialized
INFO - 2020-02-23 15:40:48 --> Router Class Initialized
INFO - 2020-02-23 15:40:48 --> Output Class Initialized
INFO - 2020-02-23 15:40:48 --> Security Class Initialized
DEBUG - 2020-02-23 15:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:40:48 --> CSRF cookie sent
INFO - 2020-02-23 15:40:48 --> Input Class Initialized
INFO - 2020-02-23 15:40:48 --> Language Class Initialized
INFO - 2020-02-23 15:40:48 --> Language Class Initialized
INFO - 2020-02-23 15:40:48 --> Config Class Initialized
INFO - 2020-02-23 15:40:48 --> Loader Class Initialized
INFO - 2020-02-23 15:40:48 --> Helper loaded: url_helper
INFO - 2020-02-23 15:40:48 --> Helper loaded: common_helper
INFO - 2020-02-23 15:40:48 --> Helper loaded: language_helper
INFO - 2020-02-23 15:40:48 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:40:48 --> Helper loaded: email_helper
INFO - 2020-02-23 15:40:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:40:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:40:48 --> Parser Class Initialized
INFO - 2020-02-23 15:40:48 --> User Agent Class Initialized
INFO - 2020-02-23 15:40:48 --> Model Class Initialized
INFO - 2020-02-23 15:40:48 --> Database Driver Class Initialized
INFO - 2020-02-23 15:40:48 --> Model Class Initialized
DEBUG - 2020-02-23 15:40:48 --> Template Class Initialized
INFO - 2020-02-23 15:40:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:40:48 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:40:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:40:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:40:48 --> Encryption Class Initialized
INFO - 2020-02-23 15:40:48 --> Controller Class Initialized
DEBUG - 2020-02-23 15:40:48 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:40:48 --> Model Class Initialized
ERROR - 2020-02-23 15:40:48 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:40:48 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:40:48 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:40:48 --> Model Class Initialized
DEBUG - 2020-02-23 15:40:48 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:40:48 --> Model Class Initialized
DEBUG - 2020-02-23 15:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:40:48 --> Final output sent to browser
DEBUG - 2020-02-23 15:40:48 --> Total execution time: 0.8515
INFO - 2020-02-23 15:40:51 --> Config Class Initialized
INFO - 2020-02-23 15:40:51 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:40:51 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:40:51 --> Utf8 Class Initialized
INFO - 2020-02-23 15:40:51 --> URI Class Initialized
INFO - 2020-02-23 15:40:51 --> Router Class Initialized
INFO - 2020-02-23 15:40:51 --> Output Class Initialized
INFO - 2020-02-23 15:40:51 --> Security Class Initialized
DEBUG - 2020-02-23 15:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:40:51 --> CSRF cookie sent
INFO - 2020-02-23 15:40:51 --> CSRF token verified
INFO - 2020-02-23 15:40:51 --> Input Class Initialized
INFO - 2020-02-23 15:40:52 --> Language Class Initialized
INFO - 2020-02-23 15:40:52 --> Language Class Initialized
INFO - 2020-02-23 15:40:52 --> Config Class Initialized
INFO - 2020-02-23 15:40:52 --> Loader Class Initialized
INFO - 2020-02-23 15:40:52 --> Helper loaded: url_helper
INFO - 2020-02-23 15:40:52 --> Helper loaded: common_helper
INFO - 2020-02-23 15:40:52 --> Helper loaded: language_helper
INFO - 2020-02-23 15:40:52 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:40:52 --> Helper loaded: email_helper
INFO - 2020-02-23 15:40:52 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:40:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:40:52 --> Parser Class Initialized
INFO - 2020-02-23 15:40:52 --> User Agent Class Initialized
INFO - 2020-02-23 15:40:52 --> Model Class Initialized
INFO - 2020-02-23 15:40:52 --> Database Driver Class Initialized
INFO - 2020-02-23 15:40:52 --> Model Class Initialized
DEBUG - 2020-02-23 15:40:52 --> Template Class Initialized
INFO - 2020-02-23 15:40:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:40:52 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:40:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:40:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:40:52 --> Encryption Class Initialized
INFO - 2020-02-23 15:40:52 --> Controller Class Initialized
DEBUG - 2020-02-23 15:40:52 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:40:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:40:52 --> Model Class Initialized
ERROR - 2020-02-23 15:40:52 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:46:16 --> Config Class Initialized
INFO - 2020-02-23 15:46:16 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:46:16 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:46:16 --> Utf8 Class Initialized
INFO - 2020-02-23 15:46:16 --> URI Class Initialized
INFO - 2020-02-23 15:46:16 --> Router Class Initialized
INFO - 2020-02-23 15:46:16 --> Output Class Initialized
INFO - 2020-02-23 15:46:16 --> Security Class Initialized
DEBUG - 2020-02-23 15:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:46:16 --> CSRF cookie sent
INFO - 2020-02-23 15:46:16 --> Input Class Initialized
INFO - 2020-02-23 15:46:16 --> Language Class Initialized
INFO - 2020-02-23 15:46:16 --> Language Class Initialized
INFO - 2020-02-23 15:46:16 --> Config Class Initialized
INFO - 2020-02-23 15:46:16 --> Loader Class Initialized
INFO - 2020-02-23 15:46:16 --> Helper loaded: url_helper
INFO - 2020-02-23 15:46:16 --> Helper loaded: common_helper
INFO - 2020-02-23 15:46:16 --> Helper loaded: language_helper
INFO - 2020-02-23 15:46:16 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:46:16 --> Helper loaded: email_helper
INFO - 2020-02-23 15:46:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:46:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:46:16 --> Parser Class Initialized
INFO - 2020-02-23 15:46:16 --> User Agent Class Initialized
INFO - 2020-02-23 15:46:16 --> Model Class Initialized
INFO - 2020-02-23 15:46:16 --> Database Driver Class Initialized
INFO - 2020-02-23 15:46:16 --> Model Class Initialized
DEBUG - 2020-02-23 15:46:16 --> Template Class Initialized
INFO - 2020-02-23 15:46:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:46:16 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:46:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:46:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:46:16 --> Encryption Class Initialized
INFO - 2020-02-23 15:46:16 --> Controller Class Initialized
DEBUG - 2020-02-23 15:46:16 --> package MX_Controller Initialized
DEBUG - 2020-02-23 15:46:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-23 15:46:16 --> Model Class Initialized
INFO - 2020-02-23 15:46:16 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:46:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:46:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:46:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:46:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:46:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:46:17 --> Model Class Initialized
DEBUG - 2020-02-23 15:46:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-23 15:46:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-23 15:46:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-23 15:46:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-23 15:46:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-23 15:46:17 --> Final output sent to browser
DEBUG - 2020-02-23 15:46:17 --> Total execution time: 0.8443
INFO - 2020-02-23 15:48:15 --> Config Class Initialized
INFO - 2020-02-23 15:48:15 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:48:15 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:48:15 --> Utf8 Class Initialized
INFO - 2020-02-23 15:48:15 --> URI Class Initialized
INFO - 2020-02-23 15:48:15 --> Router Class Initialized
INFO - 2020-02-23 15:48:15 --> Output Class Initialized
INFO - 2020-02-23 15:48:15 --> Security Class Initialized
DEBUG - 2020-02-23 15:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:48:15 --> CSRF cookie sent
INFO - 2020-02-23 15:48:15 --> CSRF token verified
INFO - 2020-02-23 15:48:15 --> Input Class Initialized
INFO - 2020-02-23 15:48:15 --> Language Class Initialized
INFO - 2020-02-23 15:48:15 --> Language Class Initialized
INFO - 2020-02-23 15:48:15 --> Config Class Initialized
INFO - 2020-02-23 15:48:15 --> Loader Class Initialized
INFO - 2020-02-23 15:48:15 --> Helper loaded: url_helper
INFO - 2020-02-23 15:48:15 --> Helper loaded: common_helper
INFO - 2020-02-23 15:48:15 --> Helper loaded: language_helper
INFO - 2020-02-23 15:48:15 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:48:15 --> Helper loaded: email_helper
INFO - 2020-02-23 15:48:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:48:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:48:15 --> Parser Class Initialized
INFO - 2020-02-23 15:48:15 --> User Agent Class Initialized
INFO - 2020-02-23 15:48:15 --> Model Class Initialized
INFO - 2020-02-23 15:48:15 --> Database Driver Class Initialized
INFO - 2020-02-23 15:48:15 --> Model Class Initialized
DEBUG - 2020-02-23 15:48:15 --> Template Class Initialized
INFO - 2020-02-23 15:48:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:48:15 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:48:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:48:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:48:15 --> Encryption Class Initialized
INFO - 2020-02-23 15:48:15 --> Controller Class Initialized
DEBUG - 2020-02-23 15:48:15 --> checkout MX_Controller Initialized
DEBUG - 2020-02-23 15:48:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-02-23 15:48:15 --> Model Class Initialized
INFO - 2020-02-23 15:48:15 --> Helper loaded: inflector_helper
ERROR - 2020-02-23 15:48:15 --> Could not find the language line "shopier"
DEBUG - 2020-02-23 15:48:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-02-23 15:48:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:48:15 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:48:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:48:15 --> Model Class Initialized
DEBUG - 2020-02-23 15:48:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:48:15 --> Model Class Initialized
DEBUG - 2020-02-23 15:48:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-23 15:48:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-23 15:48:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-23 15:48:15 --> Final output sent to browser
DEBUG - 2020-02-23 15:48:15 --> Total execution time: 0.9081
INFO - 2020-02-23 15:51:14 --> Config Class Initialized
INFO - 2020-02-23 15:51:14 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:51:14 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:51:14 --> Utf8 Class Initialized
INFO - 2020-02-23 15:51:14 --> URI Class Initialized
INFO - 2020-02-23 15:51:14 --> Router Class Initialized
INFO - 2020-02-23 15:51:15 --> Output Class Initialized
INFO - 2020-02-23 15:51:15 --> Security Class Initialized
DEBUG - 2020-02-23 15:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:51:15 --> CSRF cookie sent
INFO - 2020-02-23 15:51:15 --> CSRF token verified
INFO - 2020-02-23 15:51:15 --> Input Class Initialized
INFO - 2020-02-23 15:51:15 --> Language Class Initialized
INFO - 2020-02-23 15:51:15 --> Language Class Initialized
INFO - 2020-02-23 15:51:15 --> Config Class Initialized
INFO - 2020-02-23 15:51:15 --> Loader Class Initialized
INFO - 2020-02-23 15:51:15 --> Helper loaded: url_helper
INFO - 2020-02-23 15:51:15 --> Helper loaded: common_helper
INFO - 2020-02-23 15:51:15 --> Helper loaded: language_helper
INFO - 2020-02-23 15:51:15 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:51:15 --> Helper loaded: email_helper
INFO - 2020-02-23 15:51:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:51:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:51:15 --> Parser Class Initialized
INFO - 2020-02-23 15:51:15 --> User Agent Class Initialized
INFO - 2020-02-23 15:51:15 --> Model Class Initialized
INFO - 2020-02-23 15:51:15 --> Database Driver Class Initialized
INFO - 2020-02-23 15:51:15 --> Model Class Initialized
DEBUG - 2020-02-23 15:51:15 --> Template Class Initialized
INFO - 2020-02-23 15:51:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:51:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:51:15 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:51:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:51:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:51:15 --> Encryption Class Initialized
INFO - 2020-02-23 15:51:15 --> Controller Class Initialized
DEBUG - 2020-02-23 15:51:15 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:51:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:51:15 --> Model Class Initialized
ERROR - 2020-02-23 15:51:15 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:51:24 --> Config Class Initialized
INFO - 2020-02-23 15:51:24 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:51:24 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:51:24 --> Utf8 Class Initialized
INFO - 2020-02-23 15:51:24 --> URI Class Initialized
INFO - 2020-02-23 15:51:24 --> Router Class Initialized
INFO - 2020-02-23 15:51:24 --> Output Class Initialized
INFO - 2020-02-23 15:51:24 --> Security Class Initialized
DEBUG - 2020-02-23 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:51:24 --> CSRF cookie sent
INFO - 2020-02-23 15:51:24 --> CSRF token verified
INFO - 2020-02-23 15:51:24 --> Input Class Initialized
INFO - 2020-02-23 15:51:24 --> Language Class Initialized
INFO - 2020-02-23 15:51:24 --> Language Class Initialized
INFO - 2020-02-23 15:51:24 --> Config Class Initialized
INFO - 2020-02-23 15:51:24 --> Loader Class Initialized
INFO - 2020-02-23 15:51:24 --> Helper loaded: url_helper
INFO - 2020-02-23 15:51:24 --> Helper loaded: common_helper
INFO - 2020-02-23 15:51:24 --> Helper loaded: language_helper
INFO - 2020-02-23 15:51:24 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:51:24 --> Helper loaded: email_helper
INFO - 2020-02-23 15:51:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:51:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:51:24 --> Parser Class Initialized
INFO - 2020-02-23 15:51:24 --> User Agent Class Initialized
INFO - 2020-02-23 15:51:24 --> Model Class Initialized
INFO - 2020-02-23 15:51:24 --> Database Driver Class Initialized
INFO - 2020-02-23 15:51:25 --> Model Class Initialized
DEBUG - 2020-02-23 15:51:25 --> Template Class Initialized
INFO - 2020-02-23 15:51:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:51:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:51:25 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:51:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:51:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:51:25 --> Encryption Class Initialized
INFO - 2020-02-23 15:51:25 --> Controller Class Initialized
DEBUG - 2020-02-23 15:51:25 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:51:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:51:25 --> Model Class Initialized
ERROR - 2020-02-23 15:51:25 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:52:24 --> Config Class Initialized
INFO - 2020-02-23 15:52:24 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:52:24 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:52:24 --> Utf8 Class Initialized
INFO - 2020-02-23 15:52:24 --> URI Class Initialized
INFO - 2020-02-23 15:52:24 --> Router Class Initialized
INFO - 2020-02-23 15:52:24 --> Output Class Initialized
INFO - 2020-02-23 15:52:24 --> Security Class Initialized
DEBUG - 2020-02-23 15:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:52:24 --> CSRF cookie sent
INFO - 2020-02-23 15:52:24 --> CSRF token verified
INFO - 2020-02-23 15:52:24 --> Input Class Initialized
INFO - 2020-02-23 15:52:24 --> Language Class Initialized
INFO - 2020-02-23 15:52:24 --> Language Class Initialized
INFO - 2020-02-23 15:52:24 --> Config Class Initialized
INFO - 2020-02-23 15:52:24 --> Loader Class Initialized
INFO - 2020-02-23 15:52:24 --> Helper loaded: url_helper
INFO - 2020-02-23 15:52:24 --> Helper loaded: common_helper
INFO - 2020-02-23 15:52:24 --> Helper loaded: language_helper
INFO - 2020-02-23 15:52:24 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:52:24 --> Helper loaded: email_helper
INFO - 2020-02-23 15:52:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:52:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:52:24 --> Parser Class Initialized
INFO - 2020-02-23 15:52:24 --> User Agent Class Initialized
INFO - 2020-02-23 15:52:24 --> Model Class Initialized
INFO - 2020-02-23 15:52:24 --> Database Driver Class Initialized
INFO - 2020-02-23 15:52:24 --> Model Class Initialized
DEBUG - 2020-02-23 15:52:24 --> Template Class Initialized
INFO - 2020-02-23 15:52:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:52:24 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:52:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:52:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:52:25 --> Encryption Class Initialized
INFO - 2020-02-23 15:52:25 --> Controller Class Initialized
DEBUG - 2020-02-23 15:52:25 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:52:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:52:25 --> Model Class Initialized
ERROR - 2020-02-23 15:52:25 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:52:40 --> Config Class Initialized
INFO - 2020-02-23 15:52:40 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:52:40 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:52:40 --> Utf8 Class Initialized
INFO - 2020-02-23 15:52:40 --> URI Class Initialized
INFO - 2020-02-23 15:52:40 --> Router Class Initialized
INFO - 2020-02-23 15:52:40 --> Output Class Initialized
INFO - 2020-02-23 15:52:40 --> Security Class Initialized
DEBUG - 2020-02-23 15:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:52:40 --> CSRF cookie sent
INFO - 2020-02-23 15:52:40 --> CSRF token verified
INFO - 2020-02-23 15:52:40 --> Input Class Initialized
INFO - 2020-02-23 15:52:40 --> Language Class Initialized
INFO - 2020-02-23 15:52:40 --> Language Class Initialized
INFO - 2020-02-23 15:52:40 --> Config Class Initialized
INFO - 2020-02-23 15:52:40 --> Loader Class Initialized
INFO - 2020-02-23 15:52:40 --> Helper loaded: url_helper
INFO - 2020-02-23 15:52:40 --> Helper loaded: common_helper
INFO - 2020-02-23 15:52:40 --> Helper loaded: language_helper
INFO - 2020-02-23 15:52:40 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:52:40 --> Helper loaded: email_helper
INFO - 2020-02-23 15:52:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:52:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:52:40 --> Parser Class Initialized
INFO - 2020-02-23 15:52:40 --> User Agent Class Initialized
INFO - 2020-02-23 15:52:40 --> Model Class Initialized
INFO - 2020-02-23 15:52:40 --> Database Driver Class Initialized
INFO - 2020-02-23 15:52:40 --> Model Class Initialized
DEBUG - 2020-02-23 15:52:40 --> Template Class Initialized
INFO - 2020-02-23 15:52:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:52:40 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:52:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:52:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:52:40 --> Encryption Class Initialized
INFO - 2020-02-23 15:52:40 --> Controller Class Initialized
DEBUG - 2020-02-23 15:52:40 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:52:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:52:40 --> Model Class Initialized
ERROR - 2020-02-23 15:52:40 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:53:13 --> Config Class Initialized
INFO - 2020-02-23 15:53:13 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:53:13 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:53:13 --> Utf8 Class Initialized
INFO - 2020-02-23 15:53:13 --> URI Class Initialized
INFO - 2020-02-23 15:53:13 --> Router Class Initialized
INFO - 2020-02-23 15:53:13 --> Output Class Initialized
INFO - 2020-02-23 15:53:13 --> Security Class Initialized
DEBUG - 2020-02-23 15:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:53:14 --> CSRF cookie sent
INFO - 2020-02-23 15:53:14 --> Input Class Initialized
INFO - 2020-02-23 15:53:14 --> Language Class Initialized
INFO - 2020-02-23 15:53:14 --> Language Class Initialized
INFO - 2020-02-23 15:53:14 --> Config Class Initialized
INFO - 2020-02-23 15:53:14 --> Loader Class Initialized
INFO - 2020-02-23 15:53:14 --> Helper loaded: url_helper
INFO - 2020-02-23 15:53:14 --> Helper loaded: common_helper
INFO - 2020-02-23 15:53:14 --> Helper loaded: language_helper
INFO - 2020-02-23 15:53:14 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:53:14 --> Helper loaded: email_helper
INFO - 2020-02-23 15:53:14 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:53:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:53:14 --> Parser Class Initialized
INFO - 2020-02-23 15:53:14 --> User Agent Class Initialized
INFO - 2020-02-23 15:53:14 --> Model Class Initialized
INFO - 2020-02-23 15:53:14 --> Database Driver Class Initialized
INFO - 2020-02-23 15:53:14 --> Model Class Initialized
DEBUG - 2020-02-23 15:53:14 --> Template Class Initialized
INFO - 2020-02-23 15:53:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:53:14 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:53:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:53:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:53:14 --> Encryption Class Initialized
INFO - 2020-02-23 15:53:14 --> Controller Class Initialized
DEBUG - 2020-02-23 15:53:14 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:53:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:53:14 --> Model Class Initialized
ERROR - 2020-02-23 15:53:14 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:53:14 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:53:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:53:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:53:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:53:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:53:14 --> Model Class Initialized
DEBUG - 2020-02-23 15:53:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:53:14 --> Model Class Initialized
DEBUG - 2020-02-23 15:53:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:53:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:53:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:53:14 --> Final output sent to browser
DEBUG - 2020-02-23 15:53:14 --> Total execution time: 0.8840
INFO - 2020-02-23 15:53:18 --> Config Class Initialized
INFO - 2020-02-23 15:53:18 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:53:18 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:53:18 --> Utf8 Class Initialized
INFO - 2020-02-23 15:53:18 --> URI Class Initialized
INFO - 2020-02-23 15:53:18 --> Router Class Initialized
INFO - 2020-02-23 15:53:18 --> Output Class Initialized
INFO - 2020-02-23 15:53:18 --> Security Class Initialized
DEBUG - 2020-02-23 15:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:53:18 --> CSRF cookie sent
INFO - 2020-02-23 15:53:18 --> CSRF token verified
INFO - 2020-02-23 15:53:18 --> Input Class Initialized
INFO - 2020-02-23 15:53:18 --> Language Class Initialized
INFO - 2020-02-23 15:53:18 --> Language Class Initialized
INFO - 2020-02-23 15:53:18 --> Config Class Initialized
INFO - 2020-02-23 15:53:18 --> Loader Class Initialized
INFO - 2020-02-23 15:53:18 --> Helper loaded: url_helper
INFO - 2020-02-23 15:53:18 --> Helper loaded: common_helper
INFO - 2020-02-23 15:53:18 --> Helper loaded: language_helper
INFO - 2020-02-23 15:53:18 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:53:18 --> Helper loaded: email_helper
INFO - 2020-02-23 15:53:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:53:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:53:18 --> Parser Class Initialized
INFO - 2020-02-23 15:53:18 --> User Agent Class Initialized
INFO - 2020-02-23 15:53:18 --> Model Class Initialized
INFO - 2020-02-23 15:53:18 --> Database Driver Class Initialized
INFO - 2020-02-23 15:53:18 --> Model Class Initialized
DEBUG - 2020-02-23 15:53:18 --> Template Class Initialized
INFO - 2020-02-23 15:53:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:53:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:53:18 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:53:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:53:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:53:18 --> Encryption Class Initialized
INFO - 2020-02-23 15:53:18 --> Controller Class Initialized
DEBUG - 2020-02-23 15:53:18 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:53:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:53:19 --> Model Class Initialized
ERROR - 2020-02-23 15:53:19 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:53:40 --> Config Class Initialized
INFO - 2020-02-23 15:53:40 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:53:40 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:53:40 --> Utf8 Class Initialized
INFO - 2020-02-23 15:53:40 --> URI Class Initialized
INFO - 2020-02-23 15:53:40 --> Router Class Initialized
INFO - 2020-02-23 15:53:40 --> Output Class Initialized
INFO - 2020-02-23 15:53:40 --> Security Class Initialized
DEBUG - 2020-02-23 15:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:53:40 --> CSRF cookie sent
INFO - 2020-02-23 15:53:40 --> CSRF token verified
INFO - 2020-02-23 15:53:40 --> Input Class Initialized
INFO - 2020-02-23 15:53:40 --> Language Class Initialized
ERROR - 2020-02-23 15:53:40 --> Severity: error --> Exception: syntax error, unexpected '$faqs' (T_VARIABLE) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\controllers\category.php 94
INFO - 2020-02-23 15:53:49 --> Config Class Initialized
INFO - 2020-02-23 15:53:49 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:53:49 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:53:49 --> Utf8 Class Initialized
INFO - 2020-02-23 15:53:49 --> URI Class Initialized
INFO - 2020-02-23 15:53:49 --> Router Class Initialized
INFO - 2020-02-23 15:53:49 --> Output Class Initialized
INFO - 2020-02-23 15:53:49 --> Security Class Initialized
DEBUG - 2020-02-23 15:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:53:49 --> CSRF cookie sent
INFO - 2020-02-23 15:53:49 --> Input Class Initialized
INFO - 2020-02-23 15:53:49 --> Language Class Initialized
INFO - 2020-02-23 15:53:49 --> Language Class Initialized
INFO - 2020-02-23 15:53:49 --> Config Class Initialized
INFO - 2020-02-23 15:53:49 --> Loader Class Initialized
INFO - 2020-02-23 15:53:49 --> Helper loaded: url_helper
INFO - 2020-02-23 15:53:49 --> Helper loaded: common_helper
INFO - 2020-02-23 15:53:49 --> Helper loaded: language_helper
INFO - 2020-02-23 15:53:49 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:53:49 --> Helper loaded: email_helper
INFO - 2020-02-23 15:53:49 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:53:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:53:49 --> Parser Class Initialized
INFO - 2020-02-23 15:53:49 --> User Agent Class Initialized
INFO - 2020-02-23 15:53:49 --> Model Class Initialized
INFO - 2020-02-23 15:53:49 --> Database Driver Class Initialized
INFO - 2020-02-23 15:53:49 --> Model Class Initialized
DEBUG - 2020-02-23 15:53:49 --> Template Class Initialized
INFO - 2020-02-23 15:53:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:53:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:53:49 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:53:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:53:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:53:50 --> Encryption Class Initialized
INFO - 2020-02-23 15:53:50 --> Controller Class Initialized
DEBUG - 2020-02-23 15:53:50 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:53:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:53:50 --> Model Class Initialized
ERROR - 2020-02-23 15:53:50 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:53:50 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:53:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:53:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:53:50 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:53:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:53:50 --> Model Class Initialized
DEBUG - 2020-02-23 15:53:50 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:53:50 --> Model Class Initialized
DEBUG - 2020-02-23 15:53:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:53:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:53:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:53:50 --> Final output sent to browser
DEBUG - 2020-02-23 15:53:50 --> Total execution time: 0.9549
INFO - 2020-02-23 15:53:52 --> Config Class Initialized
INFO - 2020-02-23 15:53:52 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:53:52 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:53:52 --> Utf8 Class Initialized
INFO - 2020-02-23 15:53:52 --> URI Class Initialized
INFO - 2020-02-23 15:53:52 --> Router Class Initialized
INFO - 2020-02-23 15:53:52 --> Output Class Initialized
INFO - 2020-02-23 15:53:52 --> Security Class Initialized
DEBUG - 2020-02-23 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:53:52 --> CSRF cookie sent
INFO - 2020-02-23 15:53:52 --> CSRF token verified
INFO - 2020-02-23 15:53:52 --> Input Class Initialized
INFO - 2020-02-23 15:53:52 --> Language Class Initialized
INFO - 2020-02-23 15:53:52 --> Language Class Initialized
INFO - 2020-02-23 15:53:52 --> Config Class Initialized
INFO - 2020-02-23 15:53:52 --> Loader Class Initialized
INFO - 2020-02-23 15:53:52 --> Helper loaded: url_helper
INFO - 2020-02-23 15:53:52 --> Helper loaded: common_helper
INFO - 2020-02-23 15:53:52 --> Helper loaded: language_helper
INFO - 2020-02-23 15:53:52 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:53:52 --> Helper loaded: email_helper
INFO - 2020-02-23 15:53:52 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:53:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:53:52 --> Parser Class Initialized
INFO - 2020-02-23 15:53:52 --> User Agent Class Initialized
INFO - 2020-02-23 15:53:52 --> Model Class Initialized
INFO - 2020-02-23 15:53:52 --> Database Driver Class Initialized
INFO - 2020-02-23 15:53:53 --> Model Class Initialized
DEBUG - 2020-02-23 15:53:53 --> Template Class Initialized
INFO - 2020-02-23 15:53:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:53:53 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:53:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:53:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:53:53 --> Encryption Class Initialized
INFO - 2020-02-23 15:53:53 --> Controller Class Initialized
DEBUG - 2020-02-23 15:53:53 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:53:53 --> Model Class Initialized
ERROR - 2020-02-23 15:53:53 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:55:30 --> Config Class Initialized
INFO - 2020-02-23 15:55:30 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:55:30 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:55:30 --> Utf8 Class Initialized
INFO - 2020-02-23 15:55:30 --> URI Class Initialized
INFO - 2020-02-23 15:55:30 --> Router Class Initialized
INFO - 2020-02-23 15:55:30 --> Output Class Initialized
INFO - 2020-02-23 15:55:30 --> Security Class Initialized
DEBUG - 2020-02-23 15:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:55:30 --> CSRF cookie sent
INFO - 2020-02-23 15:55:30 --> Input Class Initialized
INFO - 2020-02-23 15:55:30 --> Language Class Initialized
INFO - 2020-02-23 15:55:30 --> Language Class Initialized
INFO - 2020-02-23 15:55:30 --> Config Class Initialized
INFO - 2020-02-23 15:55:30 --> Loader Class Initialized
INFO - 2020-02-23 15:55:30 --> Helper loaded: url_helper
INFO - 2020-02-23 15:55:30 --> Helper loaded: common_helper
INFO - 2020-02-23 15:55:30 --> Helper loaded: language_helper
INFO - 2020-02-23 15:55:30 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:55:30 --> Helper loaded: email_helper
INFO - 2020-02-23 15:55:30 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:55:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:55:30 --> Parser Class Initialized
INFO - 2020-02-23 15:55:30 --> User Agent Class Initialized
INFO - 2020-02-23 15:55:30 --> Model Class Initialized
INFO - 2020-02-23 15:55:30 --> Database Driver Class Initialized
INFO - 2020-02-23 15:55:30 --> Model Class Initialized
DEBUG - 2020-02-23 15:55:30 --> Template Class Initialized
INFO - 2020-02-23 15:55:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:55:30 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:55:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:55:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:55:30 --> Encryption Class Initialized
INFO - 2020-02-23 15:55:30 --> Controller Class Initialized
DEBUG - 2020-02-23 15:55:30 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:55:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:55:30 --> Model Class Initialized
ERROR - 2020-02-23 15:55:30 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:55:30 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:55:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:55:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:55:30 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:55:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:55:30 --> Model Class Initialized
DEBUG - 2020-02-23 15:55:30 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:55:30 --> Model Class Initialized
DEBUG - 2020-02-23 15:55:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:55:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:55:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:55:30 --> Final output sent to browser
DEBUG - 2020-02-23 15:55:30 --> Total execution time: 0.8558
INFO - 2020-02-23 15:56:16 --> Config Class Initialized
INFO - 2020-02-23 15:56:16 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:56:16 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:56:16 --> Utf8 Class Initialized
INFO - 2020-02-23 15:56:16 --> URI Class Initialized
INFO - 2020-02-23 15:56:16 --> Router Class Initialized
INFO - 2020-02-23 15:56:16 --> Output Class Initialized
INFO - 2020-02-23 15:56:16 --> Security Class Initialized
DEBUG - 2020-02-23 15:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:56:16 --> CSRF cookie sent
INFO - 2020-02-23 15:56:16 --> Input Class Initialized
INFO - 2020-02-23 15:56:16 --> Language Class Initialized
INFO - 2020-02-23 15:56:16 --> Language Class Initialized
INFO - 2020-02-23 15:56:16 --> Config Class Initialized
INFO - 2020-02-23 15:56:16 --> Loader Class Initialized
INFO - 2020-02-23 15:56:16 --> Helper loaded: url_helper
INFO - 2020-02-23 15:56:16 --> Helper loaded: common_helper
INFO - 2020-02-23 15:56:16 --> Helper loaded: language_helper
INFO - 2020-02-23 15:56:16 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:56:16 --> Helper loaded: email_helper
INFO - 2020-02-23 15:56:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:56:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:56:16 --> Parser Class Initialized
INFO - 2020-02-23 15:56:16 --> User Agent Class Initialized
INFO - 2020-02-23 15:56:16 --> Model Class Initialized
INFO - 2020-02-23 15:56:16 --> Database Driver Class Initialized
INFO - 2020-02-23 15:56:16 --> Model Class Initialized
DEBUG - 2020-02-23 15:56:16 --> Template Class Initialized
INFO - 2020-02-23 15:56:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:56:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:56:16 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:56:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:56:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:56:16 --> Encryption Class Initialized
INFO - 2020-02-23 15:56:16 --> Controller Class Initialized
DEBUG - 2020-02-23 15:56:16 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:56:16 --> Model Class Initialized
ERROR - 2020-02-23 15:56:16 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:56:16 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:56:16 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:56:16 --> Model Class Initialized
DEBUG - 2020-02-23 15:56:16 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:56:16 --> Model Class Initialized
DEBUG - 2020-02-23 15:56:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:56:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:56:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:56:17 --> Final output sent to browser
DEBUG - 2020-02-23 15:56:17 --> Total execution time: 0.7915
INFO - 2020-02-23 15:58:25 --> Config Class Initialized
INFO - 2020-02-23 15:58:25 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:58:25 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:58:25 --> Utf8 Class Initialized
INFO - 2020-02-23 15:58:25 --> URI Class Initialized
INFO - 2020-02-23 15:58:25 --> Router Class Initialized
INFO - 2020-02-23 15:58:25 --> Output Class Initialized
INFO - 2020-02-23 15:58:25 --> Security Class Initialized
DEBUG - 2020-02-23 15:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:58:25 --> CSRF cookie sent
INFO - 2020-02-23 15:58:25 --> Input Class Initialized
INFO - 2020-02-23 15:58:25 --> Language Class Initialized
INFO - 2020-02-23 15:58:26 --> Language Class Initialized
INFO - 2020-02-23 15:58:26 --> Config Class Initialized
INFO - 2020-02-23 15:58:26 --> Loader Class Initialized
INFO - 2020-02-23 15:58:26 --> Helper loaded: url_helper
INFO - 2020-02-23 15:58:26 --> Helper loaded: common_helper
INFO - 2020-02-23 15:58:26 --> Helper loaded: language_helper
INFO - 2020-02-23 15:58:26 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:58:26 --> Helper loaded: email_helper
INFO - 2020-02-23 15:58:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:58:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:58:26 --> Parser Class Initialized
INFO - 2020-02-23 15:58:26 --> User Agent Class Initialized
INFO - 2020-02-23 15:58:26 --> Model Class Initialized
INFO - 2020-02-23 15:58:26 --> Database Driver Class Initialized
INFO - 2020-02-23 15:58:26 --> Model Class Initialized
DEBUG - 2020-02-23 15:58:26 --> Template Class Initialized
INFO - 2020-02-23 15:58:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:58:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:58:26 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:58:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:58:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:58:26 --> Encryption Class Initialized
INFO - 2020-02-23 15:58:26 --> Controller Class Initialized
DEBUG - 2020-02-23 15:58:26 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:58:26 --> Model Class Initialized
ERROR - 2020-02-23 15:58:26 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:58:26 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:58:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:58:26 --> Model Class Initialized
DEBUG - 2020-02-23 15:58:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:58:26 --> Model Class Initialized
DEBUG - 2020-02-23 15:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:58:26 --> Final output sent to browser
DEBUG - 2020-02-23 15:58:26 --> Total execution time: 0.8611
INFO - 2020-02-23 15:58:38 --> Config Class Initialized
INFO - 2020-02-23 15:58:38 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:58:38 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:58:38 --> Utf8 Class Initialized
INFO - 2020-02-23 15:58:38 --> URI Class Initialized
INFO - 2020-02-23 15:58:38 --> Router Class Initialized
INFO - 2020-02-23 15:58:38 --> Output Class Initialized
INFO - 2020-02-23 15:58:38 --> Security Class Initialized
DEBUG - 2020-02-23 15:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:58:38 --> CSRF cookie sent
INFO - 2020-02-23 15:58:38 --> Input Class Initialized
INFO - 2020-02-23 15:58:38 --> Language Class Initialized
INFO - 2020-02-23 15:58:38 --> Language Class Initialized
INFO - 2020-02-23 15:58:38 --> Config Class Initialized
INFO - 2020-02-23 15:58:38 --> Loader Class Initialized
INFO - 2020-02-23 15:58:38 --> Helper loaded: url_helper
INFO - 2020-02-23 15:58:38 --> Helper loaded: common_helper
INFO - 2020-02-23 15:58:38 --> Helper loaded: language_helper
INFO - 2020-02-23 15:58:38 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:58:38 --> Helper loaded: email_helper
INFO - 2020-02-23 15:58:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:58:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:58:38 --> Parser Class Initialized
INFO - 2020-02-23 15:58:38 --> User Agent Class Initialized
INFO - 2020-02-23 15:58:38 --> Model Class Initialized
INFO - 2020-02-23 15:58:38 --> Database Driver Class Initialized
INFO - 2020-02-23 15:58:38 --> Model Class Initialized
DEBUG - 2020-02-23 15:58:38 --> Template Class Initialized
INFO - 2020-02-23 15:58:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:58:38 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:58:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:58:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:58:38 --> Encryption Class Initialized
INFO - 2020-02-23 15:58:38 --> Controller Class Initialized
DEBUG - 2020-02-23 15:58:38 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:58:38 --> Model Class Initialized
ERROR - 2020-02-23 15:58:38 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:58:38 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:58:38 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:58:39 --> Model Class Initialized
DEBUG - 2020-02-23 15:58:39 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:58:39 --> Model Class Initialized
DEBUG - 2020-02-23 15:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:58:39 --> Final output sent to browser
DEBUG - 2020-02-23 15:58:39 --> Total execution time: 0.8988
INFO - 2020-02-23 15:58:46 --> Config Class Initialized
INFO - 2020-02-23 15:58:46 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:58:46 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:58:46 --> Utf8 Class Initialized
INFO - 2020-02-23 15:58:46 --> URI Class Initialized
INFO - 2020-02-23 15:58:46 --> Router Class Initialized
INFO - 2020-02-23 15:58:46 --> Output Class Initialized
INFO - 2020-02-23 15:58:46 --> Security Class Initialized
DEBUG - 2020-02-23 15:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:58:46 --> CSRF cookie sent
INFO - 2020-02-23 15:58:46 --> Input Class Initialized
INFO - 2020-02-23 15:58:46 --> Language Class Initialized
INFO - 2020-02-23 15:58:46 --> Language Class Initialized
INFO - 2020-02-23 15:58:46 --> Config Class Initialized
INFO - 2020-02-23 15:58:46 --> Loader Class Initialized
INFO - 2020-02-23 15:58:46 --> Helper loaded: url_helper
INFO - 2020-02-23 15:58:46 --> Helper loaded: common_helper
INFO - 2020-02-23 15:58:46 --> Helper loaded: language_helper
INFO - 2020-02-23 15:58:46 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:58:46 --> Helper loaded: email_helper
INFO - 2020-02-23 15:58:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:58:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:58:46 --> Parser Class Initialized
INFO - 2020-02-23 15:58:46 --> User Agent Class Initialized
INFO - 2020-02-23 15:58:46 --> Model Class Initialized
INFO - 2020-02-23 15:58:46 --> Database Driver Class Initialized
INFO - 2020-02-23 15:58:46 --> Model Class Initialized
DEBUG - 2020-02-23 15:58:46 --> Template Class Initialized
INFO - 2020-02-23 15:58:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:58:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:58:46 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:58:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:58:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:58:46 --> Encryption Class Initialized
INFO - 2020-02-23 15:58:46 --> Controller Class Initialized
DEBUG - 2020-02-23 15:58:46 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:58:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:58:46 --> Model Class Initialized
ERROR - 2020-02-23 15:58:46 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:58:46 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:58:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:58:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:58:46 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:58:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:58:46 --> Model Class Initialized
DEBUG - 2020-02-23 15:58:46 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:58:46 --> Model Class Initialized
DEBUG - 2020-02-23 15:58:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:58:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:58:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:58:46 --> Final output sent to browser
DEBUG - 2020-02-23 15:58:47 --> Total execution time: 0.8898
INFO - 2020-02-23 15:59:25 --> Config Class Initialized
INFO - 2020-02-23 15:59:25 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:59:25 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:59:25 --> Utf8 Class Initialized
INFO - 2020-02-23 15:59:25 --> URI Class Initialized
INFO - 2020-02-23 15:59:25 --> Router Class Initialized
INFO - 2020-02-23 15:59:25 --> Output Class Initialized
INFO - 2020-02-23 15:59:25 --> Security Class Initialized
DEBUG - 2020-02-23 15:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:59:25 --> CSRF cookie sent
INFO - 2020-02-23 15:59:25 --> Input Class Initialized
INFO - 2020-02-23 15:59:25 --> Language Class Initialized
INFO - 2020-02-23 15:59:25 --> Language Class Initialized
INFO - 2020-02-23 15:59:25 --> Config Class Initialized
INFO - 2020-02-23 15:59:25 --> Loader Class Initialized
INFO - 2020-02-23 15:59:25 --> Helper loaded: url_helper
INFO - 2020-02-23 15:59:25 --> Helper loaded: common_helper
INFO - 2020-02-23 15:59:25 --> Helper loaded: language_helper
INFO - 2020-02-23 15:59:25 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:59:25 --> Helper loaded: email_helper
INFO - 2020-02-23 15:59:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:59:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:59:25 --> Parser Class Initialized
INFO - 2020-02-23 15:59:25 --> User Agent Class Initialized
INFO - 2020-02-23 15:59:25 --> Model Class Initialized
INFO - 2020-02-23 15:59:25 --> Database Driver Class Initialized
INFO - 2020-02-23 15:59:25 --> Model Class Initialized
DEBUG - 2020-02-23 15:59:25 --> Template Class Initialized
INFO - 2020-02-23 15:59:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 15:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 15:59:25 --> Pagination Class Initialized
DEBUG - 2020-02-23 15:59:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 15:59:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 15:59:25 --> Encryption Class Initialized
INFO - 2020-02-23 15:59:25 --> Controller Class Initialized
DEBUG - 2020-02-23 15:59:25 --> category MX_Controller Initialized
DEBUG - 2020-02-23 15:59:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:59:25 --> Model Class Initialized
ERROR - 2020-02-23 15:59:25 --> Could not find the language line "Sorting"
INFO - 2020-02-23 15:59:25 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 15:59:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 15:59:26 --> Model Class Initialized
DEBUG - 2020-02-23 15:59:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 15:59:26 --> Model Class Initialized
DEBUG - 2020-02-23 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 15:59:26 --> Final output sent to browser
DEBUG - 2020-02-23 15:59:26 --> Total execution time: 0.7940
INFO - 2020-02-23 15:59:59 --> Config Class Initialized
INFO - 2020-02-23 15:59:59 --> Hooks Class Initialized
DEBUG - 2020-02-23 15:59:59 --> UTF-8 Support Enabled
INFO - 2020-02-23 15:59:59 --> Utf8 Class Initialized
INFO - 2020-02-23 15:59:59 --> URI Class Initialized
INFO - 2020-02-23 15:59:59 --> Router Class Initialized
INFO - 2020-02-23 15:59:59 --> Output Class Initialized
INFO - 2020-02-23 15:59:59 --> Security Class Initialized
DEBUG - 2020-02-23 15:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 15:59:59 --> CSRF cookie sent
INFO - 2020-02-23 15:59:59 --> Input Class Initialized
INFO - 2020-02-23 15:59:59 --> Language Class Initialized
INFO - 2020-02-23 15:59:59 --> Language Class Initialized
INFO - 2020-02-23 15:59:59 --> Config Class Initialized
INFO - 2020-02-23 15:59:59 --> Loader Class Initialized
INFO - 2020-02-23 15:59:59 --> Helper loaded: url_helper
INFO - 2020-02-23 15:59:59 --> Helper loaded: common_helper
INFO - 2020-02-23 15:59:59 --> Helper loaded: language_helper
INFO - 2020-02-23 15:59:59 --> Helper loaded: cookie_helper
INFO - 2020-02-23 15:59:59 --> Helper loaded: email_helper
INFO - 2020-02-23 15:59:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 15:59:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 15:59:59 --> Parser Class Initialized
INFO - 2020-02-23 16:00:00 --> User Agent Class Initialized
INFO - 2020-02-23 16:00:00 --> Model Class Initialized
INFO - 2020-02-23 16:00:00 --> Database Driver Class Initialized
INFO - 2020-02-23 16:00:00 --> Model Class Initialized
DEBUG - 2020-02-23 16:00:00 --> Template Class Initialized
INFO - 2020-02-23 16:00:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 16:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 16:00:00 --> Pagination Class Initialized
DEBUG - 2020-02-23 16:00:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 16:00:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 16:00:00 --> Encryption Class Initialized
INFO - 2020-02-23 16:00:00 --> Controller Class Initialized
DEBUG - 2020-02-23 16:00:00 --> category MX_Controller Initialized
DEBUG - 2020-02-23 16:00:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 16:00:00 --> Model Class Initialized
ERROR - 2020-02-23 16:00:00 --> Could not find the language line "Sorting"
INFO - 2020-02-23 16:00:00 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 16:00:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 16:00:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 16:00:00 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 16:00:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 16:00:00 --> Model Class Initialized
DEBUG - 2020-02-23 16:00:00 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 16:00:00 --> Model Class Initialized
DEBUG - 2020-02-23 16:00:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 16:00:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 16:00:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 16:00:00 --> Final output sent to browser
DEBUG - 2020-02-23 16:00:00 --> Total execution time: 0.8942
INFO - 2020-02-23 16:02:54 --> Config Class Initialized
INFO - 2020-02-23 16:02:54 --> Hooks Class Initialized
DEBUG - 2020-02-23 16:02:54 --> UTF-8 Support Enabled
INFO - 2020-02-23 16:02:54 --> Utf8 Class Initialized
INFO - 2020-02-23 16:02:54 --> URI Class Initialized
INFO - 2020-02-23 16:02:54 --> Router Class Initialized
INFO - 2020-02-23 16:02:54 --> Output Class Initialized
INFO - 2020-02-23 16:02:54 --> Security Class Initialized
DEBUG - 2020-02-23 16:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-23 16:02:54 --> CSRF cookie sent
INFO - 2020-02-23 16:02:54 --> Input Class Initialized
INFO - 2020-02-23 16:02:54 --> Language Class Initialized
INFO - 2020-02-23 16:02:54 --> Language Class Initialized
INFO - 2020-02-23 16:02:54 --> Config Class Initialized
INFO - 2020-02-23 16:02:54 --> Loader Class Initialized
INFO - 2020-02-23 16:02:54 --> Helper loaded: url_helper
INFO - 2020-02-23 16:02:54 --> Helper loaded: common_helper
INFO - 2020-02-23 16:02:54 --> Helper loaded: language_helper
INFO - 2020-02-23 16:02:54 --> Helper loaded: cookie_helper
INFO - 2020-02-23 16:02:54 --> Helper loaded: email_helper
INFO - 2020-02-23 16:02:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-23 16:02:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-23 16:02:54 --> Parser Class Initialized
INFO - 2020-02-23 16:02:54 --> User Agent Class Initialized
INFO - 2020-02-23 16:02:54 --> Model Class Initialized
INFO - 2020-02-23 16:02:54 --> Database Driver Class Initialized
INFO - 2020-02-23 16:02:54 --> Model Class Initialized
DEBUG - 2020-02-23 16:02:54 --> Template Class Initialized
INFO - 2020-02-23 16:02:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-23 16:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-23 16:02:54 --> Pagination Class Initialized
DEBUG - 2020-02-23 16:02:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-23 16:02:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-23 16:02:54 --> Encryption Class Initialized
INFO - 2020-02-23 16:02:54 --> Controller Class Initialized
DEBUG - 2020-02-23 16:02:54 --> category MX_Controller Initialized
DEBUG - 2020-02-23 16:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 16:02:54 --> Model Class Initialized
ERROR - 2020-02-23 16:02:54 --> Could not find the language line "Sorting"
INFO - 2020-02-23 16:02:54 --> Helper loaded: inflector_helper
DEBUG - 2020-02-23 16:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-23 16:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-23 16:02:54 --> blocks MX_Controller Initialized
DEBUG - 2020-02-23 16:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-23 16:02:54 --> Model Class Initialized
DEBUG - 2020-02-23 16:02:55 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-23 16:02:55 --> Model Class Initialized
DEBUG - 2020-02-23 16:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-23 16:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-23 16:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-23 16:02:55 --> Final output sent to browser
DEBUG - 2020-02-23 16:02:55 --> Total execution time: 0.9121
