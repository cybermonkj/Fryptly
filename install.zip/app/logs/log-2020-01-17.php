<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-17 22:10:29 --> Config Class Initialized
INFO - 2020-01-17 22:10:29 --> Hooks Class Initialized
DEBUG - 2020-01-17 22:10:29 --> UTF-8 Support Enabled
INFO - 2020-01-17 22:10:29 --> Utf8 Class Initialized
INFO - 2020-01-17 22:10:29 --> URI Class Initialized
DEBUG - 2020-01-17 22:10:29 --> No URI present. Default controller set.
INFO - 2020-01-17 22:10:29 --> Router Class Initialized
INFO - 2020-01-17 22:10:29 --> Output Class Initialized
INFO - 2020-01-17 22:10:29 --> Security Class Initialized
DEBUG - 2020-01-17 22:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-17 22:10:29 --> CSRF cookie sent
INFO - 2020-01-17 22:10:29 --> Input Class Initialized
INFO - 2020-01-17 22:10:29 --> Language Class Initialized
INFO - 2020-01-17 22:10:29 --> Language Class Initialized
INFO - 2020-01-17 22:10:29 --> Config Class Initialized
INFO - 2020-01-17 22:10:29 --> Loader Class Initialized
INFO - 2020-01-17 22:10:29 --> Helper loaded: url_helper
INFO - 2020-01-17 22:10:29 --> Helper loaded: common_helper
INFO - 2020-01-17 22:10:29 --> Helper loaded: language_helper
INFO - 2020-01-17 22:10:29 --> Helper loaded: cookie_helper
INFO - 2020-01-17 22:10:29 --> Helper loaded: email_helper
INFO - 2020-01-17 22:10:29 --> Helper loaded: file_manager_helper
INFO - 2020-01-17 22:10:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-17 22:10:29 --> Parser Class Initialized
INFO - 2020-01-17 22:10:29 --> User Agent Class Initialized
INFO - 2020-01-17 22:10:29 --> Model Class Initialized
INFO - 2020-01-17 22:10:29 --> Database Driver Class Initialized
INFO - 2020-01-17 22:10:29 --> Model Class Initialized
DEBUG - 2020-01-17 22:10:30 --> Template Class Initialized
INFO - 2020-01-17 22:10:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-17 22:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-17 22:10:30 --> Pagination Class Initialized
DEBUG - 2020-01-17 22:10:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-17 22:10:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-17 22:10:30 --> Encryption Class Initialized
DEBUG - 2020-01-17 22:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-17 22:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-17 22:10:30 --> Controller Class Initialized
DEBUG - 2020-01-17 22:10:30 --> pergo MX_Controller Initialized
DEBUG - 2020-01-17 22:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-17 22:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-17 22:10:30 --> Model Class Initialized
INFO - 2020-01-17 22:10:30 --> Helper loaded: inflector_helper
DEBUG - 2020-01-17 22:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-17 22:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-17 22:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-17 22:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-17 22:10:31 --> Final output sent to browser
DEBUG - 2020-01-17 22:10:31 --> Total execution time: 1.9765
INFO - 2020-01-17 22:10:41 --> Config Class Initialized
INFO - 2020-01-17 22:10:41 --> Hooks Class Initialized
DEBUG - 2020-01-17 22:10:41 --> UTF-8 Support Enabled
INFO - 2020-01-17 22:10:41 --> Utf8 Class Initialized
INFO - 2020-01-17 22:10:41 --> URI Class Initialized
INFO - 2020-01-17 22:10:41 --> Router Class Initialized
INFO - 2020-01-17 22:10:41 --> Output Class Initialized
INFO - 2020-01-17 22:10:41 --> Security Class Initialized
DEBUG - 2020-01-17 22:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-17 22:10:41 --> CSRF cookie sent
INFO - 2020-01-17 22:10:41 --> Input Class Initialized
INFO - 2020-01-17 22:10:41 --> Language Class Initialized
INFO - 2020-01-17 22:10:41 --> Language Class Initialized
INFO - 2020-01-17 22:10:41 --> Config Class Initialized
INFO - 2020-01-17 22:10:41 --> Loader Class Initialized
INFO - 2020-01-17 22:10:41 --> Helper loaded: url_helper
INFO - 2020-01-17 22:10:41 --> Helper loaded: common_helper
INFO - 2020-01-17 22:10:41 --> Helper loaded: language_helper
INFO - 2020-01-17 22:10:41 --> Helper loaded: cookie_helper
INFO - 2020-01-17 22:10:41 --> Helper loaded: email_helper
INFO - 2020-01-17 22:10:41 --> Helper loaded: file_manager_helper
INFO - 2020-01-17 22:10:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-17 22:10:41 --> Parser Class Initialized
INFO - 2020-01-17 22:10:41 --> User Agent Class Initialized
INFO - 2020-01-17 22:10:41 --> Model Class Initialized
INFO - 2020-01-17 22:10:41 --> Database Driver Class Initialized
INFO - 2020-01-17 22:10:41 --> Model Class Initialized
DEBUG - 2020-01-17 22:10:41 --> Template Class Initialized
INFO - 2020-01-17 22:10:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-17 22:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-17 22:10:41 --> Pagination Class Initialized
DEBUG - 2020-01-17 22:10:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-17 22:10:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-17 22:10:41 --> Encryption Class Initialized
INFO - 2020-01-17 22:10:41 --> Controller Class Initialized
DEBUG - 2020-01-17 22:10:41 --> auth MX_Controller Initialized
DEBUG - 2020-01-17 22:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-01-17 22:10:41 --> Model Class Initialized
DEBUG - 2020-01-17 22:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-17 22:10:41 --> Helper loaded: inflector_helper
DEBUG - 2020-01-17 22:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-01-17 22:10:41 --> pergo MX_Controller Initialized
DEBUG - 2020-01-17 22:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-17 22:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-01-17 22:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-17 22:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-17 22:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-01-17 22:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-17 22:10:41 --> Final output sent to browser
DEBUG - 2020-01-17 22:10:41 --> Total execution time: 0.5898
INFO - 2020-01-17 22:10:43 --> Config Class Initialized
INFO - 2020-01-17 22:10:43 --> Hooks Class Initialized
DEBUG - 2020-01-17 22:10:43 --> UTF-8 Support Enabled
INFO - 2020-01-17 22:10:43 --> Utf8 Class Initialized
INFO - 2020-01-17 22:10:43 --> URI Class Initialized
INFO - 2020-01-17 22:10:43 --> Router Class Initialized
INFO - 2020-01-17 22:10:43 --> Output Class Initialized
INFO - 2020-01-17 22:10:43 --> Security Class Initialized
DEBUG - 2020-01-17 22:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-17 22:10:43 --> CSRF cookie sent
INFO - 2020-01-17 22:10:43 --> CSRF token verified
INFO - 2020-01-17 22:10:43 --> Input Class Initialized
INFO - 2020-01-17 22:10:43 --> Language Class Initialized
INFO - 2020-01-17 22:10:43 --> Language Class Initialized
INFO - 2020-01-17 22:10:43 --> Config Class Initialized
INFO - 2020-01-17 22:10:43 --> Loader Class Initialized
INFO - 2020-01-17 22:10:43 --> Helper loaded: url_helper
INFO - 2020-01-17 22:10:43 --> Helper loaded: common_helper
INFO - 2020-01-17 22:10:43 --> Helper loaded: language_helper
INFO - 2020-01-17 22:10:43 --> Helper loaded: cookie_helper
INFO - 2020-01-17 22:10:43 --> Helper loaded: email_helper
INFO - 2020-01-17 22:10:43 --> Helper loaded: file_manager_helper
INFO - 2020-01-17 22:10:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-17 22:10:43 --> Parser Class Initialized
INFO - 2020-01-17 22:10:43 --> User Agent Class Initialized
INFO - 2020-01-17 22:10:43 --> Model Class Initialized
INFO - 2020-01-17 22:10:43 --> Database Driver Class Initialized
INFO - 2020-01-17 22:10:43 --> Model Class Initialized
DEBUG - 2020-01-17 22:10:43 --> Template Class Initialized
INFO - 2020-01-17 22:10:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-17 22:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-17 22:10:43 --> Pagination Class Initialized
DEBUG - 2020-01-17 22:10:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-17 22:10:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-17 22:10:43 --> Encryption Class Initialized
INFO - 2020-01-17 22:10:43 --> Controller Class Initialized
DEBUG - 2020-01-17 22:10:44 --> auth MX_Controller Initialized
DEBUG - 2020-01-17 22:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-01-17 22:10:44 --> Model Class Initialized
INFO - 2020-01-17 22:10:49 --> Config Class Initialized
INFO - 2020-01-17 22:10:49 --> Hooks Class Initialized
DEBUG - 2020-01-17 22:10:49 --> UTF-8 Support Enabled
INFO - 2020-01-17 22:10:49 --> Utf8 Class Initialized
INFO - 2020-01-17 22:10:49 --> URI Class Initialized
INFO - 2020-01-17 22:10:49 --> Router Class Initialized
INFO - 2020-01-17 22:10:49 --> Output Class Initialized
INFO - 2020-01-17 22:10:49 --> Security Class Initialized
DEBUG - 2020-01-17 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-17 22:10:49 --> CSRF cookie sent
INFO - 2020-01-17 22:10:49 --> Input Class Initialized
INFO - 2020-01-17 22:10:49 --> Language Class Initialized
INFO - 2020-01-17 22:10:49 --> Language Class Initialized
INFO - 2020-01-17 22:10:49 --> Config Class Initialized
INFO - 2020-01-17 22:10:49 --> Loader Class Initialized
INFO - 2020-01-17 22:10:49 --> Helper loaded: url_helper
INFO - 2020-01-17 22:10:49 --> Helper loaded: common_helper
INFO - 2020-01-17 22:10:49 --> Helper loaded: language_helper
INFO - 2020-01-17 22:10:49 --> Helper loaded: cookie_helper
INFO - 2020-01-17 22:10:49 --> Helper loaded: email_helper
INFO - 2020-01-17 22:10:49 --> Helper loaded: file_manager_helper
INFO - 2020-01-17 22:10:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-17 22:10:49 --> Parser Class Initialized
INFO - 2020-01-17 22:10:49 --> User Agent Class Initialized
INFO - 2020-01-17 22:10:49 --> Model Class Initialized
INFO - 2020-01-17 22:10:49 --> Database Driver Class Initialized
INFO - 2020-01-17 22:10:49 --> Model Class Initialized
DEBUG - 2020-01-17 22:10:49 --> Template Class Initialized
INFO - 2020-01-17 22:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-17 22:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-17 22:10:49 --> Pagination Class Initialized
DEBUG - 2020-01-17 22:10:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-17 22:10:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-17 22:10:49 --> Encryption Class Initialized
INFO - 2020-01-17 22:10:49 --> Controller Class Initialized
DEBUG - 2020-01-17 22:10:49 --> statistics MX_Controller Initialized
DEBUG - 2020-01-17 22:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-01-17 22:10:49 --> Model Class Initialized
ERROR - 2020-01-17 22:10:49 --> Could not find the language line "Pending"
ERROR - 2020-01-17 22:10:49 --> Could not find the language line "Pending"
INFO - 2020-01-17 22:10:49 --> Helper loaded: inflector_helper
ERROR - 2020-01-17 22:10:49 --> Could not find the language line "total_orders"
ERROR - 2020-01-17 22:10:49 --> Could not find the language line "total_orders"
ERROR - 2020-01-17 22:10:49 --> Could not find the language line "Pending"
DEBUG - 2020-01-17 22:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-01-17 22:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-01-17 22:10:49 --> blocks MX_Controller Initialized
DEBUG - 2020-01-17 22:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-01-17 22:10:49 --> Model Class Initialized
DEBUG - 2020-01-17 22:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-01-17 22:10:50 --> Model Class Initialized
DEBUG - 2020-01-17 22:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-01-17 22:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-01-17 22:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-01-17 22:10:50 --> Final output sent to browser
DEBUG - 2020-01-17 22:10:50 --> Total execution time: 1.0924
INFO - 2020-01-17 22:11:40 --> Config Class Initialized
INFO - 2020-01-17 22:11:40 --> Hooks Class Initialized
DEBUG - 2020-01-17 22:11:40 --> UTF-8 Support Enabled
INFO - 2020-01-17 22:11:40 --> Utf8 Class Initialized
INFO - 2020-01-17 22:11:40 --> URI Class Initialized
INFO - 2020-01-17 22:11:40 --> Router Class Initialized
INFO - 2020-01-17 22:11:40 --> Output Class Initialized
INFO - 2020-01-17 22:11:40 --> Security Class Initialized
DEBUG - 2020-01-17 22:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-17 22:11:40 --> CSRF cookie sent
INFO - 2020-01-17 22:11:40 --> Input Class Initialized
INFO - 2020-01-17 22:11:40 --> Language Class Initialized
INFO - 2020-01-17 22:11:40 --> Language Class Initialized
INFO - 2020-01-17 22:11:40 --> Config Class Initialized
INFO - 2020-01-17 22:11:40 --> Loader Class Initialized
INFO - 2020-01-17 22:11:40 --> Helper loaded: url_helper
INFO - 2020-01-17 22:11:40 --> Helper loaded: common_helper
INFO - 2020-01-17 22:11:40 --> Helper loaded: language_helper
INFO - 2020-01-17 22:11:40 --> Helper loaded: cookie_helper
INFO - 2020-01-17 22:11:40 --> Helper loaded: email_helper
INFO - 2020-01-17 22:11:40 --> Helper loaded: file_manager_helper
INFO - 2020-01-17 22:11:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-17 22:11:40 --> Parser Class Initialized
INFO - 2020-01-17 22:11:40 --> User Agent Class Initialized
INFO - 2020-01-17 22:11:40 --> Model Class Initialized
INFO - 2020-01-17 22:11:40 --> Database Driver Class Initialized
INFO - 2020-01-17 22:11:40 --> Model Class Initialized
DEBUG - 2020-01-17 22:11:40 --> Template Class Initialized
INFO - 2020-01-17 22:11:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-17 22:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-17 22:11:40 --> Pagination Class Initialized
DEBUG - 2020-01-17 22:11:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-17 22:11:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-17 22:11:40 --> Encryption Class Initialized
INFO - 2020-01-17 22:11:40 --> Controller Class Initialized
DEBUG - 2020-01-17 22:11:40 --> setting MX_Controller Initialized
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-01-17 22:11:40 --> Model Class Initialized
INFO - 2020-01-17 22:11:40 --> Helper loaded: inflector_helper
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-01-17 22:11:40 --> blocks MX_Controller Initialized
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-01-17 22:11:40 --> Model Class Initialized
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-01-17 22:11:40 --> Model Class Initialized
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-01-17 22:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-01-17 22:11:41 --> Final output sent to browser
DEBUG - 2020-01-17 22:11:41 --> Total execution time: 0.8158
INFO - 2020-01-17 22:11:43 --> Config Class Initialized
INFO - 2020-01-17 22:11:43 --> Hooks Class Initialized
DEBUG - 2020-01-17 22:11:43 --> UTF-8 Support Enabled
INFO - 2020-01-17 22:11:43 --> Utf8 Class Initialized
INFO - 2020-01-17 22:11:43 --> URI Class Initialized
INFO - 2020-01-17 22:11:43 --> Router Class Initialized
INFO - 2020-01-17 22:11:43 --> Output Class Initialized
INFO - 2020-01-17 22:11:43 --> Security Class Initialized
DEBUG - 2020-01-17 22:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-17 22:11:43 --> CSRF cookie sent
INFO - 2020-01-17 22:11:43 --> Input Class Initialized
INFO - 2020-01-17 22:11:43 --> Language Class Initialized
INFO - 2020-01-17 22:11:43 --> Language Class Initialized
INFO - 2020-01-17 22:11:43 --> Config Class Initialized
INFO - 2020-01-17 22:11:43 --> Loader Class Initialized
INFO - 2020-01-17 22:11:43 --> Helper loaded: url_helper
INFO - 2020-01-17 22:11:43 --> Helper loaded: common_helper
INFO - 2020-01-17 22:11:43 --> Helper loaded: language_helper
INFO - 2020-01-17 22:11:43 --> Helper loaded: cookie_helper
INFO - 2020-01-17 22:11:43 --> Helper loaded: email_helper
INFO - 2020-01-17 22:11:43 --> Helper loaded: file_manager_helper
INFO - 2020-01-17 22:11:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-17 22:11:43 --> Parser Class Initialized
INFO - 2020-01-17 22:11:43 --> User Agent Class Initialized
INFO - 2020-01-17 22:11:43 --> Model Class Initialized
INFO - 2020-01-17 22:11:43 --> Database Driver Class Initialized
INFO - 2020-01-17 22:11:43 --> Model Class Initialized
DEBUG - 2020-01-17 22:11:43 --> Template Class Initialized
INFO - 2020-01-17 22:11:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-17 22:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-17 22:11:43 --> Pagination Class Initialized
DEBUG - 2020-01-17 22:11:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-17 22:11:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-17 22:11:43 --> Encryption Class Initialized
INFO - 2020-01-17 22:11:43 --> Controller Class Initialized
DEBUG - 2020-01-17 22:11:43 --> setting MX_Controller Initialized
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-01-17 22:11:43 --> Model Class Initialized
INFO - 2020-01-17 22:11:43 --> Helper loaded: inflector_helper
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-01-17 22:11:43 --> blocks MX_Controller Initialized
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-01-17 22:11:43 --> Model Class Initialized
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-01-17 22:11:43 --> Model Class Initialized
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-01-17 22:11:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-01-17 22:11:43 --> Final output sent to browser
DEBUG - 2020-01-17 22:11:43 --> Total execution time: 0.6133
INFO - 2020-01-17 22:18:08 --> Config Class Initialized
INFO - 2020-01-17 22:18:08 --> Hooks Class Initialized
DEBUG - 2020-01-17 22:18:08 --> UTF-8 Support Enabled
INFO - 2020-01-17 22:18:08 --> Utf8 Class Initialized
INFO - 2020-01-17 22:18:08 --> URI Class Initialized
INFO - 2020-01-17 22:18:08 --> Router Class Initialized
INFO - 2020-01-17 22:18:08 --> Output Class Initialized
INFO - 2020-01-17 22:18:08 --> Security Class Initialized
DEBUG - 2020-01-17 22:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-17 22:18:08 --> CSRF cookie sent
INFO - 2020-01-17 22:18:08 --> Input Class Initialized
INFO - 2020-01-17 22:18:08 --> Language Class Initialized
INFO - 2020-01-17 22:18:08 --> Language Class Initialized
INFO - 2020-01-17 22:18:08 --> Config Class Initialized
INFO - 2020-01-17 22:18:08 --> Loader Class Initialized
INFO - 2020-01-17 22:18:08 --> Helper loaded: url_helper
INFO - 2020-01-17 22:18:08 --> Helper loaded: common_helper
INFO - 2020-01-17 22:18:08 --> Helper loaded: language_helper
INFO - 2020-01-17 22:18:08 --> Helper loaded: cookie_helper
INFO - 2020-01-17 22:18:08 --> Helper loaded: email_helper
INFO - 2020-01-17 22:18:08 --> Helper loaded: file_manager_helper
INFO - 2020-01-17 22:18:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-17 22:18:08 --> Parser Class Initialized
INFO - 2020-01-17 22:18:08 --> User Agent Class Initialized
INFO - 2020-01-17 22:18:08 --> Model Class Initialized
INFO - 2020-01-17 22:18:08 --> Database Driver Class Initialized
INFO - 2020-01-17 22:18:08 --> Model Class Initialized
DEBUG - 2020-01-17 22:18:08 --> Template Class Initialized
INFO - 2020-01-17 22:18:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-17 22:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-17 22:18:08 --> Pagination Class Initialized
DEBUG - 2020-01-17 22:18:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-17 22:18:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-17 22:18:08 --> Encryption Class Initialized
INFO - 2020-01-17 22:18:08 --> Controller Class Initialized
DEBUG - 2020-01-17 22:18:08 --> setting MX_Controller Initialized
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-01-17 22:18:08 --> Model Class Initialized
INFO - 2020-01-17 22:18:08 --> Helper loaded: inflector_helper
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/freekassa.php
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-01-17 22:18:08 --> blocks MX_Controller Initialized
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-01-17 22:18:08 --> Model Class Initialized
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-01-17 22:18:08 --> Model Class Initialized
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-01-17 22:18:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-01-17 22:18:08 --> Final output sent to browser
DEBUG - 2020-01-17 22:18:08 --> Total execution time: 0.6106
