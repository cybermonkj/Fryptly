<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-26 15:29:08 --> Config Class Initialized
INFO - 2019-11-26 15:29:08 --> Hooks Class Initialized
DEBUG - 2019-11-26 15:29:08 --> UTF-8 Support Enabled
INFO - 2019-11-26 15:29:08 --> Utf8 Class Initialized
INFO - 2019-11-26 15:29:08 --> URI Class Initialized
DEBUG - 2019-11-26 15:29:08 --> No URI present. Default controller set.
INFO - 2019-11-26 15:29:08 --> Router Class Initialized
INFO - 2019-11-26 15:29:08 --> Output Class Initialized
INFO - 2019-11-26 15:29:08 --> Security Class Initialized
DEBUG - 2019-11-26 15:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-26 15:29:08 --> CSRF cookie sent
INFO - 2019-11-26 15:29:08 --> Input Class Initialized
INFO - 2019-11-26 15:29:08 --> Language Class Initialized
INFO - 2019-11-26 15:29:09 --> Language Class Initialized
INFO - 2019-11-26 15:29:09 --> Config Class Initialized
INFO - 2019-11-26 15:29:09 --> Loader Class Initialized
INFO - 2019-11-26 15:29:09 --> Helper loaded: url_helper
INFO - 2019-11-26 15:29:09 --> Helper loaded: common_helper
INFO - 2019-11-26 15:29:09 --> Helper loaded: language_helper
INFO - 2019-11-26 15:29:09 --> Helper loaded: cookie_helper
INFO - 2019-11-26 15:29:09 --> Helper loaded: email_helper
INFO - 2019-11-26 15:29:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-26 15:29:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-26 15:29:09 --> Parser Class Initialized
INFO - 2019-11-26 15:29:09 --> User Agent Class Initialized
INFO - 2019-11-26 15:29:09 --> Model Class Initialized
INFO - 2019-11-26 15:29:09 --> Database Driver Class Initialized
INFO - 2019-11-26 15:29:09 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:09 --> Template Class Initialized
INFO - 2019-11-26 15:29:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-26 15:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-26 15:29:09 --> Pagination Class Initialized
DEBUG - 2019-11-26 15:29:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-26 15:29:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-26 15:29:09 --> Encryption Class Initialized
DEBUG - 2019-11-26 15:29:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-26 15:29:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-26 15:29:09 --> Controller Class Initialized
DEBUG - 2019-11-26 15:29:09 --> pergo MX_Controller Initialized
DEBUG - 2019-11-26 15:29:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-26 15:29:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-26 15:29:09 --> Model Class Initialized
INFO - 2019-11-26 15:29:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-26 15:29:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-26 15:29:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-26 15:29:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-26 15:29:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-26 15:29:10 --> Final output sent to browser
DEBUG - 2019-11-26 15:29:10 --> Total execution time: 1.6933
INFO - 2019-11-26 15:29:15 --> Config Class Initialized
INFO - 2019-11-26 15:29:15 --> Hooks Class Initialized
DEBUG - 2019-11-26 15:29:15 --> UTF-8 Support Enabled
INFO - 2019-11-26 15:29:15 --> Utf8 Class Initialized
INFO - 2019-11-26 15:29:15 --> URI Class Initialized
INFO - 2019-11-26 15:29:15 --> Router Class Initialized
INFO - 2019-11-26 15:29:15 --> Output Class Initialized
INFO - 2019-11-26 15:29:15 --> Security Class Initialized
DEBUG - 2019-11-26 15:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-26 15:29:15 --> CSRF cookie sent
INFO - 2019-11-26 15:29:15 --> Input Class Initialized
INFO - 2019-11-26 15:29:16 --> Language Class Initialized
INFO - 2019-11-26 15:29:16 --> Language Class Initialized
INFO - 2019-11-26 15:29:16 --> Config Class Initialized
INFO - 2019-11-26 15:29:16 --> Loader Class Initialized
INFO - 2019-11-26 15:29:16 --> Helper loaded: url_helper
INFO - 2019-11-26 15:29:16 --> Helper loaded: common_helper
INFO - 2019-11-26 15:29:16 --> Helper loaded: language_helper
INFO - 2019-11-26 15:29:16 --> Helper loaded: cookie_helper
INFO - 2019-11-26 15:29:16 --> Helper loaded: email_helper
INFO - 2019-11-26 15:29:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-26 15:29:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-26 15:29:16 --> Parser Class Initialized
INFO - 2019-11-26 15:29:16 --> User Agent Class Initialized
INFO - 2019-11-26 15:29:16 --> Model Class Initialized
INFO - 2019-11-26 15:29:16 --> Database Driver Class Initialized
INFO - 2019-11-26 15:29:16 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:16 --> Template Class Initialized
INFO - 2019-11-26 15:29:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-26 15:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-26 15:29:16 --> Pagination Class Initialized
DEBUG - 2019-11-26 15:29:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-26 15:29:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-26 15:29:16 --> Encryption Class Initialized
INFO - 2019-11-26 15:29:16 --> Controller Class Initialized
DEBUG - 2019-11-26 15:29:16 --> auth MX_Controller Initialized
DEBUG - 2019-11-26 15:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-26 15:29:16 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-26 15:29:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-26 15:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-26 15:29:16 --> pergo MX_Controller Initialized
DEBUG - 2019-11-26 15:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-26 15:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-26 15:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-26 15:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-26 15:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-26 15:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-26 15:29:16 --> Final output sent to browser
DEBUG - 2019-11-26 15:29:16 --> Total execution time: 0.7026
INFO - 2019-11-26 15:29:18 --> Config Class Initialized
INFO - 2019-11-26 15:29:18 --> Hooks Class Initialized
DEBUG - 2019-11-26 15:29:18 --> UTF-8 Support Enabled
INFO - 2019-11-26 15:29:18 --> Utf8 Class Initialized
INFO - 2019-11-26 15:29:18 --> URI Class Initialized
INFO - 2019-11-26 15:29:18 --> Router Class Initialized
INFO - 2019-11-26 15:29:18 --> Output Class Initialized
INFO - 2019-11-26 15:29:18 --> Security Class Initialized
DEBUG - 2019-11-26 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-26 15:29:18 --> CSRF cookie sent
INFO - 2019-11-26 15:29:18 --> CSRF token verified
INFO - 2019-11-26 15:29:18 --> Input Class Initialized
INFO - 2019-11-26 15:29:18 --> Language Class Initialized
INFO - 2019-11-26 15:29:18 --> Language Class Initialized
INFO - 2019-11-26 15:29:18 --> Config Class Initialized
INFO - 2019-11-26 15:29:18 --> Loader Class Initialized
INFO - 2019-11-26 15:29:18 --> Helper loaded: url_helper
INFO - 2019-11-26 15:29:18 --> Helper loaded: common_helper
INFO - 2019-11-26 15:29:18 --> Helper loaded: language_helper
INFO - 2019-11-26 15:29:18 --> Helper loaded: cookie_helper
INFO - 2019-11-26 15:29:18 --> Helper loaded: email_helper
INFO - 2019-11-26 15:29:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-26 15:29:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-26 15:29:18 --> Parser Class Initialized
INFO - 2019-11-26 15:29:18 --> User Agent Class Initialized
INFO - 2019-11-26 15:29:18 --> Model Class Initialized
INFO - 2019-11-26 15:29:18 --> Database Driver Class Initialized
INFO - 2019-11-26 15:29:18 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:18 --> Template Class Initialized
INFO - 2019-11-26 15:29:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-26 15:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-26 15:29:18 --> Pagination Class Initialized
DEBUG - 2019-11-26 15:29:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-26 15:29:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-26 15:29:19 --> Encryption Class Initialized
INFO - 2019-11-26 15:29:19 --> Controller Class Initialized
DEBUG - 2019-11-26 15:29:19 --> auth MX_Controller Initialized
DEBUG - 2019-11-26 15:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-26 15:29:19 --> Model Class Initialized
INFO - 2019-11-26 15:29:24 --> Config Class Initialized
INFO - 2019-11-26 15:29:24 --> Hooks Class Initialized
DEBUG - 2019-11-26 15:29:24 --> UTF-8 Support Enabled
INFO - 2019-11-26 15:29:24 --> Utf8 Class Initialized
INFO - 2019-11-26 15:29:25 --> URI Class Initialized
INFO - 2019-11-26 15:29:25 --> Router Class Initialized
INFO - 2019-11-26 15:29:25 --> Output Class Initialized
INFO - 2019-11-26 15:29:25 --> Security Class Initialized
DEBUG - 2019-11-26 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-26 15:29:25 --> CSRF cookie sent
INFO - 2019-11-26 15:29:25 --> Input Class Initialized
INFO - 2019-11-26 15:29:25 --> Language Class Initialized
INFO - 2019-11-26 15:29:25 --> Language Class Initialized
INFO - 2019-11-26 15:29:25 --> Config Class Initialized
INFO - 2019-11-26 15:29:25 --> Loader Class Initialized
INFO - 2019-11-26 15:29:25 --> Helper loaded: url_helper
INFO - 2019-11-26 15:29:25 --> Helper loaded: common_helper
INFO - 2019-11-26 15:29:25 --> Helper loaded: language_helper
INFO - 2019-11-26 15:29:25 --> Helper loaded: cookie_helper
INFO - 2019-11-26 15:29:25 --> Helper loaded: email_helper
INFO - 2019-11-26 15:29:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-26 15:29:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-26 15:29:25 --> Parser Class Initialized
INFO - 2019-11-26 15:29:25 --> User Agent Class Initialized
INFO - 2019-11-26 15:29:25 --> Model Class Initialized
INFO - 2019-11-26 15:29:25 --> Database Driver Class Initialized
INFO - 2019-11-26 15:29:25 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:25 --> Template Class Initialized
INFO - 2019-11-26 15:29:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-26 15:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-26 15:29:25 --> Pagination Class Initialized
DEBUG - 2019-11-26 15:29:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-26 15:29:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-26 15:29:25 --> Encryption Class Initialized
INFO - 2019-11-26 15:29:25 --> Controller Class Initialized
DEBUG - 2019-11-26 15:29:25 --> statistics MX_Controller Initialized
DEBUG - 2019-11-26 15:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-26 15:29:25 --> Model Class Initialized
ERROR - 2019-11-26 15:29:25 --> Could not find the language line "Pending"
ERROR - 2019-11-26 15:29:25 --> Could not find the language line "Pending"
INFO - 2019-11-26 15:29:25 --> Helper loaded: inflector_helper
ERROR - 2019-11-26 15:29:25 --> Could not find the language line "total_orders"
ERROR - 2019-11-26 15:29:25 --> Could not find the language line "total_orders"
ERROR - 2019-11-26 15:29:25 --> Could not find the language line "Pending"
DEBUG - 2019-11-26 15:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-26 15:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-26 15:29:25 --> blocks MX_Controller Initialized
DEBUG - 2019-11-26 15:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-26 15:29:25 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-26 15:29:25 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-26 15:29:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-26 15:29:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-26 15:29:26 --> Final output sent to browser
DEBUG - 2019-11-26 15:29:26 --> Total execution time: 1.1176
INFO - 2019-11-26 15:29:35 --> Config Class Initialized
INFO - 2019-11-26 15:29:35 --> Hooks Class Initialized
DEBUG - 2019-11-26 15:29:35 --> UTF-8 Support Enabled
INFO - 2019-11-26 15:29:35 --> Utf8 Class Initialized
INFO - 2019-11-26 15:29:35 --> URI Class Initialized
INFO - 2019-11-26 15:29:35 --> Router Class Initialized
INFO - 2019-11-26 15:29:35 --> Output Class Initialized
INFO - 2019-11-26 15:29:35 --> Security Class Initialized
DEBUG - 2019-11-26 15:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-26 15:29:35 --> CSRF cookie sent
INFO - 2019-11-26 15:29:35 --> Input Class Initialized
INFO - 2019-11-26 15:29:35 --> Language Class Initialized
INFO - 2019-11-26 15:29:35 --> Language Class Initialized
INFO - 2019-11-26 15:29:35 --> Config Class Initialized
INFO - 2019-11-26 15:29:35 --> Loader Class Initialized
INFO - 2019-11-26 15:29:35 --> Helper loaded: url_helper
INFO - 2019-11-26 15:29:35 --> Helper loaded: common_helper
INFO - 2019-11-26 15:29:35 --> Helper loaded: language_helper
INFO - 2019-11-26 15:29:35 --> Helper loaded: cookie_helper
INFO - 2019-11-26 15:29:35 --> Helper loaded: email_helper
INFO - 2019-11-26 15:29:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-26 15:29:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-26 15:29:35 --> Parser Class Initialized
INFO - 2019-11-26 15:29:35 --> User Agent Class Initialized
INFO - 2019-11-26 15:29:35 --> Model Class Initialized
INFO - 2019-11-26 15:29:35 --> Database Driver Class Initialized
INFO - 2019-11-26 15:29:35 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:35 --> Template Class Initialized
INFO - 2019-11-26 15:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-26 15:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-26 15:29:35 --> Pagination Class Initialized
DEBUG - 2019-11-26 15:29:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-26 15:29:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-26 15:29:35 --> Encryption Class Initialized
INFO - 2019-11-26 15:29:35 --> Controller Class Initialized
DEBUG - 2019-11-26 15:29:35 --> setting MX_Controller Initialized
DEBUG - 2019-11-26 15:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-26 15:29:35 --> Model Class Initialized
INFO - 2019-11-26 15:29:35 --> Helper loaded: inflector_helper
DEBUG - 2019-11-26 15:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-26 15:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-26 15:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-26 15:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-26 15:29:36 --> blocks MX_Controller Initialized
DEBUG - 2019-11-26 15:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-26 15:29:36 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-26 15:29:36 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-26 15:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-26 15:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-26 15:29:36 --> Final output sent to browser
DEBUG - 2019-11-26 15:29:36 --> Total execution time: 0.8078
INFO - 2019-11-26 15:29:39 --> Config Class Initialized
INFO - 2019-11-26 15:29:39 --> Hooks Class Initialized
DEBUG - 2019-11-26 15:29:39 --> UTF-8 Support Enabled
INFO - 2019-11-26 15:29:39 --> Utf8 Class Initialized
INFO - 2019-11-26 15:29:39 --> URI Class Initialized
INFO - 2019-11-26 15:29:39 --> Router Class Initialized
INFO - 2019-11-26 15:29:39 --> Output Class Initialized
INFO - 2019-11-26 15:29:39 --> Security Class Initialized
DEBUG - 2019-11-26 15:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-26 15:29:39 --> CSRF cookie sent
INFO - 2019-11-26 15:29:39 --> Input Class Initialized
INFO - 2019-11-26 15:29:39 --> Language Class Initialized
INFO - 2019-11-26 15:29:39 --> Language Class Initialized
INFO - 2019-11-26 15:29:39 --> Config Class Initialized
INFO - 2019-11-26 15:29:39 --> Loader Class Initialized
INFO - 2019-11-26 15:29:40 --> Helper loaded: url_helper
INFO - 2019-11-26 15:29:40 --> Helper loaded: common_helper
INFO - 2019-11-26 15:29:40 --> Helper loaded: language_helper
INFO - 2019-11-26 15:29:40 --> Helper loaded: cookie_helper
INFO - 2019-11-26 15:29:40 --> Helper loaded: email_helper
INFO - 2019-11-26 15:29:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-26 15:29:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-26 15:29:40 --> Parser Class Initialized
INFO - 2019-11-26 15:29:40 --> User Agent Class Initialized
INFO - 2019-11-26 15:29:40 --> Model Class Initialized
INFO - 2019-11-26 15:29:40 --> Database Driver Class Initialized
INFO - 2019-11-26 15:29:40 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:40 --> Template Class Initialized
INFO - 2019-11-26 15:29:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-26 15:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-26 15:29:40 --> Pagination Class Initialized
DEBUG - 2019-11-26 15:29:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-26 15:29:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-26 15:29:40 --> Encryption Class Initialized
INFO - 2019-11-26 15:29:40 --> Controller Class Initialized
DEBUG - 2019-11-26 15:29:40 --> setting MX_Controller Initialized
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-26 15:29:40 --> Model Class Initialized
INFO - 2019-11-26 15:29:40 --> Helper loaded: inflector_helper
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinbase.php
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-26 15:29:40 --> blocks MX_Controller Initialized
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-26 15:29:40 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-26 15:29:40 --> Model Class Initialized
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-26 15:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-26 15:29:40 --> Final output sent to browser
DEBUG - 2019-11-26 15:29:40 --> Total execution time: 0.6232
INFO - 2019-11-26 15:53:52 --> Config Class Initialized
INFO - 2019-11-26 15:53:52 --> Hooks Class Initialized
DEBUG - 2019-11-26 15:53:52 --> UTF-8 Support Enabled
INFO - 2019-11-26 15:53:52 --> Utf8 Class Initialized
INFO - 2019-11-26 15:53:52 --> URI Class Initialized
INFO - 2019-11-26 15:53:52 --> Router Class Initialized
INFO - 2019-11-26 15:53:52 --> Output Class Initialized
INFO - 2019-11-26 15:53:52 --> Security Class Initialized
DEBUG - 2019-11-26 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-26 15:53:52 --> CSRF cookie sent
INFO - 2019-11-26 15:53:52 --> Input Class Initialized
INFO - 2019-11-26 15:53:52 --> Language Class Initialized
INFO - 2019-11-26 15:53:52 --> Language Class Initialized
INFO - 2019-11-26 15:53:52 --> Config Class Initialized
INFO - 2019-11-26 15:53:52 --> Loader Class Initialized
INFO - 2019-11-26 15:53:52 --> Helper loaded: url_helper
INFO - 2019-11-26 15:53:52 --> Helper loaded: common_helper
INFO - 2019-11-26 15:53:52 --> Helper loaded: language_helper
INFO - 2019-11-26 15:53:52 --> Helper loaded: cookie_helper
INFO - 2019-11-26 15:53:52 --> Helper loaded: email_helper
INFO - 2019-11-26 15:53:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-26 15:53:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-26 15:53:52 --> Parser Class Initialized
INFO - 2019-11-26 15:53:52 --> User Agent Class Initialized
INFO - 2019-11-26 15:53:52 --> Model Class Initialized
INFO - 2019-11-26 15:53:52 --> Database Driver Class Initialized
INFO - 2019-11-26 15:53:52 --> Model Class Initialized
DEBUG - 2019-11-26 15:53:52 --> Template Class Initialized
INFO - 2019-11-26 15:53:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-26 15:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-26 15:53:52 --> Pagination Class Initialized
DEBUG - 2019-11-26 15:53:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-26 15:53:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-26 15:53:52 --> Encryption Class Initialized
INFO - 2019-11-26 15:53:52 --> Controller Class Initialized
DEBUG - 2019-11-26 15:53:52 --> users MX_Controller Initialized
DEBUG - 2019-11-26 15:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/users/models/users_model.php
INFO - 2019-11-26 15:53:52 --> Model Class Initialized
ERROR - 2019-11-26 15:53:52 --> Could not find the language line "Last_Order"
INFO - 2019-11-26 15:53:52 --> Helper loaded: inflector_helper
DEBUG - 2019-11-26 15:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/users/views/index.php
DEBUG - 2019-11-26 15:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-26 15:53:52 --> blocks MX_Controller Initialized
DEBUG - 2019-11-26 15:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-26 15:53:52 --> Model Class Initialized
DEBUG - 2019-11-26 15:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-26 15:53:52 --> Model Class Initialized
DEBUG - 2019-11-26 15:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-26 15:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-26 15:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-26 15:53:53 --> Final output sent to browser
DEBUG - 2019-11-26 15:53:53 --> Total execution time: 0.6982
