<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-01 14:08:15 --> Config Class Initialized
INFO - 2020-04-01 14:08:15 --> Hooks Class Initialized
DEBUG - 2020-04-01 14:08:15 --> UTF-8 Support Enabled
INFO - 2020-04-01 14:08:15 --> Utf8 Class Initialized
INFO - 2020-04-01 14:08:15 --> URI Class Initialized
DEBUG - 2020-04-01 14:08:15 --> No URI present. Default controller set.
INFO - 2020-04-01 14:08:15 --> Router Class Initialized
INFO - 2020-04-01 14:08:15 --> Output Class Initialized
INFO - 2020-04-01 14:08:15 --> Security Class Initialized
DEBUG - 2020-04-01 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-01 14:08:15 --> CSRF cookie sent
INFO - 2020-04-01 14:08:15 --> Input Class Initialized
INFO - 2020-04-01 14:08:15 --> Language Class Initialized
INFO - 2020-04-01 14:08:15 --> Language Class Initialized
INFO - 2020-04-01 14:08:15 --> Config Class Initialized
INFO - 2020-04-01 14:08:15 --> Loader Class Initialized
INFO - 2020-04-01 14:08:15 --> Helper loaded: url_helper
INFO - 2020-04-01 14:08:15 --> Helper loaded: common_helper
INFO - 2020-04-01 14:08:15 --> Helper loaded: language_helper
INFO - 2020-04-01 14:08:15 --> Helper loaded: cookie_helper
INFO - 2020-04-01 14:08:15 --> Helper loaded: email_helper
INFO - 2020-04-01 14:08:15 --> Helper loaded: file_manager_helper
INFO - 2020-04-01 14:08:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-01 14:08:15 --> Parser Class Initialized
INFO - 2020-04-01 14:08:16 --> User Agent Class Initialized
INFO - 2020-04-01 14:08:16 --> Model Class Initialized
INFO - 2020-04-01 14:08:16 --> Database Driver Class Initialized
INFO - 2020-04-01 14:08:16 --> Model Class Initialized
DEBUG - 2020-04-01 14:08:16 --> Template Class Initialized
INFO - 2020-04-01 14:08:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-01 14:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-01 14:08:16 --> Pagination Class Initialized
DEBUG - 2020-04-01 14:08:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-01 14:08:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-01 14:08:16 --> Encryption Class Initialized
DEBUG - 2020-04-01 14:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-04-01 14:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-04-01 14:08:16 --> Controller Class Initialized
DEBUG - 2020-04-01 14:08:16 --> pergo MX_Controller Initialized
DEBUG - 2020-04-01 14:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-04-01 14:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-04-01 14:08:16 --> Model Class Initialized
INFO - 2020-04-01 14:08:16 --> Helper loaded: inflector_helper
DEBUG - 2020-04-01 14:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-04-01 14:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-04-01 14:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-04-01 14:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-04-01 14:08:16 --> Final output sent to browser
DEBUG - 2020-04-01 14:08:16 --> Total execution time: 1.6973
