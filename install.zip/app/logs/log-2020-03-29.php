<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-29 10:16:01 --> Config Class Initialized
INFO - 2020-03-29 10:16:01 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:16:01 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:16:01 --> Utf8 Class Initialized
INFO - 2020-03-29 10:16:01 --> URI Class Initialized
DEBUG - 2020-03-29 10:16:01 --> No URI present. Default controller set.
INFO - 2020-03-29 10:16:01 --> Router Class Initialized
INFO - 2020-03-29 10:16:01 --> Output Class Initialized
INFO - 2020-03-29 10:16:01 --> Security Class Initialized
DEBUG - 2020-03-29 10:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:16:01 --> CSRF cookie sent
INFO - 2020-03-29 10:16:01 --> Input Class Initialized
INFO - 2020-03-29 10:16:01 --> Language Class Initialized
INFO - 2020-03-29 10:16:02 --> Language Class Initialized
INFO - 2020-03-29 10:16:02 --> Config Class Initialized
INFO - 2020-03-29 10:16:02 --> Loader Class Initialized
INFO - 2020-03-29 10:16:02 --> Helper loaded: url_helper
INFO - 2020-03-29 10:16:02 --> Helper loaded: common_helper
INFO - 2020-03-29 10:16:02 --> Helper loaded: language_helper
INFO - 2020-03-29 10:16:02 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:16:02 --> Helper loaded: email_helper
INFO - 2020-03-29 10:16:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:16:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:16:02 --> Parser Class Initialized
INFO - 2020-03-29 10:16:02 --> User Agent Class Initialized
INFO - 2020-03-29 10:16:02 --> Model Class Initialized
INFO - 2020-03-29 10:16:02 --> Database Driver Class Initialized
INFO - 2020-03-29 10:16:02 --> Model Class Initialized
DEBUG - 2020-03-29 10:16:02 --> Template Class Initialized
INFO - 2020-03-29 10:16:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:16:02 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:16:02 --> Encryption Class Initialized
DEBUG - 2020-03-29 10:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-29 10:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-29 10:16:02 --> Controller Class Initialized
DEBUG - 2020-03-29 10:16:02 --> pergo MX_Controller Initialized
DEBUG - 2020-03-29 10:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-29 10:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-29 10:16:02 --> Model Class Initialized
INFO - 2020-03-29 10:16:02 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-29 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-29 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-29 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-29 10:16:03 --> Final output sent to browser
DEBUG - 2020-03-29 10:16:03 --> Total execution time: 1.8510
INFO - 2020-03-29 10:16:07 --> Config Class Initialized
INFO - 2020-03-29 10:16:07 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:16:07 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:16:07 --> Utf8 Class Initialized
INFO - 2020-03-29 10:16:07 --> URI Class Initialized
INFO - 2020-03-29 10:16:07 --> Router Class Initialized
INFO - 2020-03-29 10:16:07 --> Output Class Initialized
INFO - 2020-03-29 10:16:07 --> Security Class Initialized
DEBUG - 2020-03-29 10:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:16:07 --> CSRF cookie sent
INFO - 2020-03-29 10:16:07 --> Input Class Initialized
INFO - 2020-03-29 10:16:07 --> Language Class Initialized
INFO - 2020-03-29 10:16:07 --> Language Class Initialized
INFO - 2020-03-29 10:16:07 --> Config Class Initialized
INFO - 2020-03-29 10:16:07 --> Loader Class Initialized
INFO - 2020-03-29 10:16:07 --> Helper loaded: url_helper
INFO - 2020-03-29 10:16:07 --> Helper loaded: common_helper
INFO - 2020-03-29 10:16:07 --> Helper loaded: language_helper
INFO - 2020-03-29 10:16:07 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:16:07 --> Helper loaded: email_helper
INFO - 2020-03-29 10:16:07 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:16:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:16:07 --> Parser Class Initialized
INFO - 2020-03-29 10:16:07 --> User Agent Class Initialized
INFO - 2020-03-29 10:16:07 --> Model Class Initialized
INFO - 2020-03-29 10:16:07 --> Database Driver Class Initialized
INFO - 2020-03-29 10:16:07 --> Model Class Initialized
DEBUG - 2020-03-29 10:16:07 --> Template Class Initialized
INFO - 2020-03-29 10:16:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:16:07 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:16:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:16:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:16:07 --> Encryption Class Initialized
INFO - 2020-03-29 10:16:07 --> Controller Class Initialized
DEBUG - 2020-03-29 10:16:07 --> auth MX_Controller Initialized
DEBUG - 2020-03-29 10:16:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-29 10:16:07 --> Model Class Initialized
DEBUG - 2020-03-29 10:16:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-29 10:16:07 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:16:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-29 10:16:07 --> pergo MX_Controller Initialized
DEBUG - 2020-03-29 10:16:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-29 10:16:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-29 10:16:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-29 10:16:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-29 10:16:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-29 10:16:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-29 10:16:07 --> Final output sent to browser
DEBUG - 2020-03-29 10:16:07 --> Total execution time: 0.5895
INFO - 2020-03-29 10:17:21 --> Config Class Initialized
INFO - 2020-03-29 10:17:21 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:17:21 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:17:21 --> Utf8 Class Initialized
INFO - 2020-03-29 10:17:21 --> URI Class Initialized
INFO - 2020-03-29 10:17:21 --> Router Class Initialized
INFO - 2020-03-29 10:17:21 --> Output Class Initialized
INFO - 2020-03-29 10:17:21 --> Security Class Initialized
DEBUG - 2020-03-29 10:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:17:21 --> CSRF cookie sent
INFO - 2020-03-29 10:17:21 --> CSRF token verified
INFO - 2020-03-29 10:17:21 --> Input Class Initialized
INFO - 2020-03-29 10:17:21 --> Language Class Initialized
INFO - 2020-03-29 10:17:21 --> Language Class Initialized
INFO - 2020-03-29 10:17:21 --> Config Class Initialized
INFO - 2020-03-29 10:17:21 --> Loader Class Initialized
INFO - 2020-03-29 10:17:21 --> Helper loaded: url_helper
INFO - 2020-03-29 10:17:21 --> Helper loaded: common_helper
INFO - 2020-03-29 10:17:21 --> Helper loaded: language_helper
INFO - 2020-03-29 10:17:21 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:17:21 --> Helper loaded: email_helper
INFO - 2020-03-29 10:17:21 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:17:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:17:21 --> Parser Class Initialized
INFO - 2020-03-29 10:17:21 --> User Agent Class Initialized
INFO - 2020-03-29 10:17:21 --> Model Class Initialized
INFO - 2020-03-29 10:17:21 --> Database Driver Class Initialized
INFO - 2020-03-29 10:17:21 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:21 --> Template Class Initialized
INFO - 2020-03-29 10:17:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:17:21 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:17:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:17:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:17:21 --> Encryption Class Initialized
INFO - 2020-03-29 10:17:21 --> Controller Class Initialized
DEBUG - 2020-03-29 10:17:21 --> auth MX_Controller Initialized
DEBUG - 2020-03-29 10:17:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-29 10:17:21 --> Model Class Initialized
INFO - 2020-03-29 10:17:28 --> Config Class Initialized
INFO - 2020-03-29 10:17:28 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:17:28 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:17:28 --> Utf8 Class Initialized
INFO - 2020-03-29 10:17:28 --> URI Class Initialized
INFO - 2020-03-29 10:17:28 --> Router Class Initialized
INFO - 2020-03-29 10:17:28 --> Output Class Initialized
INFO - 2020-03-29 10:17:28 --> Security Class Initialized
DEBUG - 2020-03-29 10:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:17:28 --> CSRF cookie sent
INFO - 2020-03-29 10:17:28 --> CSRF token verified
INFO - 2020-03-29 10:17:29 --> Input Class Initialized
INFO - 2020-03-29 10:17:29 --> Language Class Initialized
INFO - 2020-03-29 10:17:29 --> Language Class Initialized
INFO - 2020-03-29 10:17:29 --> Config Class Initialized
INFO - 2020-03-29 10:17:29 --> Loader Class Initialized
INFO - 2020-03-29 10:17:29 --> Helper loaded: url_helper
INFO - 2020-03-29 10:17:29 --> Helper loaded: common_helper
INFO - 2020-03-29 10:17:29 --> Helper loaded: language_helper
INFO - 2020-03-29 10:17:29 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:17:29 --> Helper loaded: email_helper
INFO - 2020-03-29 10:17:29 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:17:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:17:29 --> Parser Class Initialized
INFO - 2020-03-29 10:17:29 --> User Agent Class Initialized
INFO - 2020-03-29 10:17:29 --> Model Class Initialized
INFO - 2020-03-29 10:17:29 --> Database Driver Class Initialized
INFO - 2020-03-29 10:17:29 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:29 --> Template Class Initialized
INFO - 2020-03-29 10:17:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:17:29 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:17:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:17:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:17:29 --> Encryption Class Initialized
INFO - 2020-03-29 10:17:29 --> Controller Class Initialized
DEBUG - 2020-03-29 10:17:29 --> auth MX_Controller Initialized
DEBUG - 2020-03-29 10:17:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-29 10:17:29 --> Model Class Initialized
INFO - 2020-03-29 10:17:33 --> Config Class Initialized
INFO - 2020-03-29 10:17:33 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:17:33 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:17:33 --> Utf8 Class Initialized
INFO - 2020-03-29 10:17:33 --> URI Class Initialized
INFO - 2020-03-29 10:17:33 --> Router Class Initialized
INFO - 2020-03-29 10:17:33 --> Output Class Initialized
INFO - 2020-03-29 10:17:33 --> Security Class Initialized
DEBUG - 2020-03-29 10:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:17:33 --> CSRF cookie sent
INFO - 2020-03-29 10:17:33 --> Input Class Initialized
INFO - 2020-03-29 10:17:33 --> Language Class Initialized
INFO - 2020-03-29 10:17:34 --> Language Class Initialized
INFO - 2020-03-29 10:17:34 --> Config Class Initialized
INFO - 2020-03-29 10:17:34 --> Loader Class Initialized
INFO - 2020-03-29 10:17:34 --> Helper loaded: url_helper
INFO - 2020-03-29 10:17:34 --> Helper loaded: common_helper
INFO - 2020-03-29 10:17:34 --> Helper loaded: language_helper
INFO - 2020-03-29 10:17:34 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:17:34 --> Helper loaded: email_helper
INFO - 2020-03-29 10:17:34 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:17:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:17:34 --> Parser Class Initialized
INFO - 2020-03-29 10:17:34 --> User Agent Class Initialized
INFO - 2020-03-29 10:17:34 --> Model Class Initialized
INFO - 2020-03-29 10:17:34 --> Database Driver Class Initialized
INFO - 2020-03-29 10:17:34 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:34 --> Template Class Initialized
INFO - 2020-03-29 10:17:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:17:34 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:17:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:17:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:17:34 --> Encryption Class Initialized
INFO - 2020-03-29 10:17:34 --> Controller Class Initialized
DEBUG - 2020-03-29 10:17:34 --> statistics MX_Controller Initialized
DEBUG - 2020-03-29 10:17:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-29 10:17:34 --> Model Class Initialized
ERROR - 2020-03-29 10:17:34 --> Could not find the language line "Pending"
ERROR - 2020-03-29 10:17:34 --> Could not find the language line "Pending"
INFO - 2020-03-29 10:17:34 --> Helper loaded: inflector_helper
ERROR - 2020-03-29 10:17:34 --> Could not find the language line "total_orders"
ERROR - 2020-03-29 10:17:34 --> Could not find the language line "total_orders"
ERROR - 2020-03-29 10:17:34 --> Could not find the language line "Pending"
DEBUG - 2020-03-29 10:17:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-29 10:17:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-29 10:17:34 --> blocks MX_Controller Initialized
DEBUG - 2020-03-29 10:17:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-29 10:17:34 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-29 10:17:34 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-29 10:17:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-29 10:17:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-29 10:17:34 --> Final output sent to browser
DEBUG - 2020-03-29 10:17:34 --> Total execution time: 0.9626
INFO - 2020-03-29 10:17:40 --> Config Class Initialized
INFO - 2020-03-29 10:17:40 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:17:40 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:17:40 --> Utf8 Class Initialized
INFO - 2020-03-29 10:17:40 --> URI Class Initialized
INFO - 2020-03-29 10:17:40 --> Router Class Initialized
INFO - 2020-03-29 10:17:40 --> Output Class Initialized
INFO - 2020-03-29 10:17:40 --> Security Class Initialized
DEBUG - 2020-03-29 10:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:17:40 --> CSRF cookie sent
INFO - 2020-03-29 10:17:40 --> Input Class Initialized
INFO - 2020-03-29 10:17:40 --> Language Class Initialized
INFO - 2020-03-29 10:17:40 --> Language Class Initialized
INFO - 2020-03-29 10:17:40 --> Config Class Initialized
INFO - 2020-03-29 10:17:40 --> Loader Class Initialized
INFO - 2020-03-29 10:17:40 --> Helper loaded: url_helper
INFO - 2020-03-29 10:17:40 --> Helper loaded: common_helper
INFO - 2020-03-29 10:17:40 --> Helper loaded: language_helper
INFO - 2020-03-29 10:17:40 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:17:40 --> Helper loaded: email_helper
INFO - 2020-03-29 10:17:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:17:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:17:40 --> Parser Class Initialized
INFO - 2020-03-29 10:17:40 --> User Agent Class Initialized
INFO - 2020-03-29 10:17:40 --> Model Class Initialized
INFO - 2020-03-29 10:17:40 --> Database Driver Class Initialized
INFO - 2020-03-29 10:17:40 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:40 --> Template Class Initialized
INFO - 2020-03-29 10:17:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:17:40 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:17:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:17:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:17:41 --> Encryption Class Initialized
INFO - 2020-03-29 10:17:41 --> Controller Class Initialized
DEBUG - 2020-03-29 10:17:41 --> setting MX_Controller Initialized
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-29 10:17:41 --> Model Class Initialized
INFO - 2020-03-29 10:17:41 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-29 10:17:41 --> blocks MX_Controller Initialized
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-29 10:17:41 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-29 10:17:41 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-29 10:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-29 10:17:41 --> Final output sent to browser
DEBUG - 2020-03-29 10:17:41 --> Total execution time: 0.7109
INFO - 2020-03-29 10:17:44 --> Config Class Initialized
INFO - 2020-03-29 10:17:44 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:17:44 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:17:44 --> Utf8 Class Initialized
INFO - 2020-03-29 10:17:44 --> URI Class Initialized
INFO - 2020-03-29 10:17:44 --> Router Class Initialized
INFO - 2020-03-29 10:17:44 --> Output Class Initialized
INFO - 2020-03-29 10:17:44 --> Security Class Initialized
DEBUG - 2020-03-29 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:17:44 --> CSRF cookie sent
INFO - 2020-03-29 10:17:44 --> Input Class Initialized
INFO - 2020-03-29 10:17:44 --> Language Class Initialized
INFO - 2020-03-29 10:17:44 --> Language Class Initialized
INFO - 2020-03-29 10:17:44 --> Config Class Initialized
INFO - 2020-03-29 10:17:44 --> Loader Class Initialized
INFO - 2020-03-29 10:17:44 --> Helper loaded: url_helper
INFO - 2020-03-29 10:17:44 --> Helper loaded: common_helper
INFO - 2020-03-29 10:17:44 --> Helper loaded: language_helper
INFO - 2020-03-29 10:17:44 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:17:44 --> Helper loaded: email_helper
INFO - 2020-03-29 10:17:44 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:17:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:17:44 --> Parser Class Initialized
INFO - 2020-03-29 10:17:44 --> User Agent Class Initialized
INFO - 2020-03-29 10:17:44 --> Model Class Initialized
INFO - 2020-03-29 10:17:44 --> Database Driver Class Initialized
INFO - 2020-03-29 10:17:44 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:44 --> Template Class Initialized
INFO - 2020-03-29 10:17:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:17:44 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:17:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:17:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:17:44 --> Encryption Class Initialized
INFO - 2020-03-29 10:17:44 --> Controller Class Initialized
DEBUG - 2020-03-29 10:17:44 --> setting MX_Controller Initialized
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-29 10:17:44 --> Model Class Initialized
INFO - 2020-03-29 10:17:44 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-29 10:17:44 --> blocks MX_Controller Initialized
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-29 10:17:44 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-29 10:17:44 --> Model Class Initialized
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-29 10:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-29 10:17:44 --> Final output sent to browser
DEBUG - 2020-03-29 10:17:44 --> Total execution time: 0.6098
INFO - 2020-03-29 10:22:35 --> Config Class Initialized
INFO - 2020-03-29 10:22:35 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:22:35 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:22:35 --> Utf8 Class Initialized
INFO - 2020-03-29 10:22:35 --> URI Class Initialized
INFO - 2020-03-29 10:22:35 --> Router Class Initialized
INFO - 2020-03-29 10:22:35 --> Output Class Initialized
INFO - 2020-03-29 10:22:35 --> Security Class Initialized
DEBUG - 2020-03-29 10:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:22:35 --> CSRF cookie sent
INFO - 2020-03-29 10:22:35 --> Input Class Initialized
INFO - 2020-03-29 10:22:35 --> Language Class Initialized
INFO - 2020-03-29 10:22:35 --> Language Class Initialized
INFO - 2020-03-29 10:22:35 --> Config Class Initialized
INFO - 2020-03-29 10:22:35 --> Loader Class Initialized
INFO - 2020-03-29 10:22:35 --> Helper loaded: url_helper
INFO - 2020-03-29 10:22:35 --> Helper loaded: common_helper
INFO - 2020-03-29 10:22:35 --> Helper loaded: language_helper
INFO - 2020-03-29 10:22:35 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:22:35 --> Helper loaded: email_helper
INFO - 2020-03-29 10:22:35 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:22:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:22:35 --> Parser Class Initialized
INFO - 2020-03-29 10:22:35 --> User Agent Class Initialized
INFO - 2020-03-29 10:22:35 --> Model Class Initialized
INFO - 2020-03-29 10:22:35 --> Database Driver Class Initialized
INFO - 2020-03-29 10:22:35 --> Model Class Initialized
DEBUG - 2020-03-29 10:22:35 --> Template Class Initialized
INFO - 2020-03-29 10:22:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:22:35 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:22:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:22:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:22:35 --> Encryption Class Initialized
INFO - 2020-03-29 10:22:36 --> Controller Class Initialized
DEBUG - 2020-03-29 10:22:36 --> setting MX_Controller Initialized
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-29 10:22:36 --> Model Class Initialized
INFO - 2020-03-29 10:22:36 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-29 10:22:36 --> blocks MX_Controller Initialized
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-29 10:22:36 --> Model Class Initialized
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-29 10:22:36 --> Model Class Initialized
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-29 10:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-29 10:22:36 --> Final output sent to browser
DEBUG - 2020-03-29 10:22:36 --> Total execution time: 0.6639
INFO - 2020-03-29 10:22:53 --> Config Class Initialized
INFO - 2020-03-29 10:22:53 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:22:53 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:22:53 --> Utf8 Class Initialized
INFO - 2020-03-29 10:22:53 --> URI Class Initialized
INFO - 2020-03-29 10:22:53 --> Router Class Initialized
INFO - 2020-03-29 10:22:53 --> Output Class Initialized
INFO - 2020-03-29 10:22:53 --> Security Class Initialized
DEBUG - 2020-03-29 10:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:22:53 --> CSRF cookie sent
INFO - 2020-03-29 10:22:53 --> Input Class Initialized
INFO - 2020-03-29 10:22:53 --> Language Class Initialized
INFO - 2020-03-29 10:22:53 --> Language Class Initialized
INFO - 2020-03-29 10:22:53 --> Config Class Initialized
INFO - 2020-03-29 10:22:53 --> Loader Class Initialized
INFO - 2020-03-29 10:22:53 --> Helper loaded: url_helper
INFO - 2020-03-29 10:22:53 --> Helper loaded: common_helper
INFO - 2020-03-29 10:22:53 --> Helper loaded: language_helper
INFO - 2020-03-29 10:22:53 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:22:53 --> Helper loaded: email_helper
INFO - 2020-03-29 10:22:53 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:22:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:22:53 --> Parser Class Initialized
INFO - 2020-03-29 10:22:53 --> User Agent Class Initialized
INFO - 2020-03-29 10:22:53 --> Model Class Initialized
INFO - 2020-03-29 10:22:53 --> Database Driver Class Initialized
INFO - 2020-03-29 10:22:53 --> Model Class Initialized
DEBUG - 2020-03-29 10:22:53 --> Template Class Initialized
INFO - 2020-03-29 10:22:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:22:53 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:22:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:22:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:22:53 --> Encryption Class Initialized
INFO - 2020-03-29 10:22:53 --> Controller Class Initialized
DEBUG - 2020-03-29 10:22:53 --> setting MX_Controller Initialized
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-29 10:22:53 --> Model Class Initialized
INFO - 2020-03-29 10:22:53 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-29 10:22:53 --> blocks MX_Controller Initialized
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-29 10:22:53 --> Model Class Initialized
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-29 10:22:53 --> Model Class Initialized
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-29 10:22:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-29 10:22:53 --> Final output sent to browser
DEBUG - 2020-03-29 10:22:53 --> Total execution time: 0.6751
INFO - 2020-03-29 10:23:17 --> Config Class Initialized
INFO - 2020-03-29 10:23:17 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:23:17 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:23:17 --> Utf8 Class Initialized
INFO - 2020-03-29 10:23:17 --> URI Class Initialized
INFO - 2020-03-29 10:23:17 --> Router Class Initialized
INFO - 2020-03-29 10:23:17 --> Output Class Initialized
INFO - 2020-03-29 10:23:17 --> Security Class Initialized
DEBUG - 2020-03-29 10:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:23:17 --> CSRF cookie sent
INFO - 2020-03-29 10:23:17 --> Input Class Initialized
INFO - 2020-03-29 10:23:17 --> Language Class Initialized
INFO - 2020-03-29 10:23:18 --> Language Class Initialized
INFO - 2020-03-29 10:23:18 --> Config Class Initialized
INFO - 2020-03-29 10:23:18 --> Loader Class Initialized
INFO - 2020-03-29 10:23:18 --> Helper loaded: url_helper
INFO - 2020-03-29 10:23:18 --> Helper loaded: common_helper
INFO - 2020-03-29 10:23:18 --> Helper loaded: language_helper
INFO - 2020-03-29 10:23:18 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:23:18 --> Helper loaded: email_helper
INFO - 2020-03-29 10:23:18 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:23:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:23:18 --> Parser Class Initialized
INFO - 2020-03-29 10:23:18 --> User Agent Class Initialized
INFO - 2020-03-29 10:23:18 --> Model Class Initialized
INFO - 2020-03-29 10:23:18 --> Database Driver Class Initialized
INFO - 2020-03-29 10:23:18 --> Model Class Initialized
DEBUG - 2020-03-29 10:23:18 --> Template Class Initialized
INFO - 2020-03-29 10:23:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:23:18 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:23:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:23:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:23:18 --> Encryption Class Initialized
INFO - 2020-03-29 10:23:18 --> Controller Class Initialized
DEBUG - 2020-03-29 10:23:18 --> setting MX_Controller Initialized
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-29 10:23:18 --> Model Class Initialized
INFO - 2020-03-29 10:23:18 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-29 10:23:18 --> blocks MX_Controller Initialized
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-29 10:23:18 --> Model Class Initialized
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-29 10:23:18 --> Model Class Initialized
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-29 10:23:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-29 10:23:18 --> Final output sent to browser
DEBUG - 2020-03-29 10:23:18 --> Total execution time: 0.6859
INFO - 2020-03-29 10:23:35 --> Config Class Initialized
INFO - 2020-03-29 10:23:35 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:23:35 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:23:35 --> Utf8 Class Initialized
INFO - 2020-03-29 10:23:35 --> URI Class Initialized
INFO - 2020-03-29 10:23:35 --> Router Class Initialized
INFO - 2020-03-29 10:23:35 --> Output Class Initialized
INFO - 2020-03-29 10:23:35 --> Security Class Initialized
DEBUG - 2020-03-29 10:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:23:35 --> CSRF cookie sent
INFO - 2020-03-29 10:23:35 --> Input Class Initialized
INFO - 2020-03-29 10:23:35 --> Language Class Initialized
INFO - 2020-03-29 10:23:35 --> Language Class Initialized
INFO - 2020-03-29 10:23:35 --> Config Class Initialized
INFO - 2020-03-29 10:23:35 --> Loader Class Initialized
INFO - 2020-03-29 10:23:35 --> Helper loaded: url_helper
INFO - 2020-03-29 10:23:35 --> Helper loaded: common_helper
INFO - 2020-03-29 10:23:35 --> Helper loaded: language_helper
INFO - 2020-03-29 10:23:35 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:23:35 --> Helper loaded: email_helper
INFO - 2020-03-29 10:23:35 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:23:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:23:35 --> Parser Class Initialized
INFO - 2020-03-29 10:23:35 --> User Agent Class Initialized
INFO - 2020-03-29 10:23:35 --> Model Class Initialized
INFO - 2020-03-29 10:23:35 --> Database Driver Class Initialized
INFO - 2020-03-29 10:23:35 --> Model Class Initialized
DEBUG - 2020-03-29 10:23:35 --> Template Class Initialized
INFO - 2020-03-29 10:23:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:23:35 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:23:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:23:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:23:35 --> Encryption Class Initialized
INFO - 2020-03-29 10:23:35 --> Controller Class Initialized
DEBUG - 2020-03-29 10:23:35 --> setting MX_Controller Initialized
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-29 10:23:35 --> Model Class Initialized
INFO - 2020-03-29 10:23:35 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-29 10:23:35 --> blocks MX_Controller Initialized
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-29 10:23:35 --> Model Class Initialized
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-29 10:23:35 --> Model Class Initialized
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-29 10:23:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-29 10:23:35 --> Final output sent to browser
DEBUG - 2020-03-29 10:23:35 --> Total execution time: 0.6721
INFO - 2020-03-29 10:23:57 --> Config Class Initialized
INFO - 2020-03-29 10:23:57 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:23:57 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:23:57 --> Utf8 Class Initialized
INFO - 2020-03-29 10:23:57 --> URI Class Initialized
INFO - 2020-03-29 10:23:57 --> Router Class Initialized
INFO - 2020-03-29 10:23:57 --> Output Class Initialized
INFO - 2020-03-29 10:23:57 --> Security Class Initialized
DEBUG - 2020-03-29 10:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:23:57 --> CSRF cookie sent
INFO - 2020-03-29 10:23:57 --> Input Class Initialized
INFO - 2020-03-29 10:23:57 --> Language Class Initialized
INFO - 2020-03-29 10:23:57 --> Language Class Initialized
INFO - 2020-03-29 10:23:57 --> Config Class Initialized
INFO - 2020-03-29 10:23:57 --> Loader Class Initialized
INFO - 2020-03-29 10:23:57 --> Helper loaded: url_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: common_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: language_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: email_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:23:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:23:57 --> Parser Class Initialized
INFO - 2020-03-29 10:23:57 --> User Agent Class Initialized
DEBUG - 2020-03-29 10:23:57 --> Template Class Initialized
INFO - 2020-03-29 10:23:57 --> Database Driver Class Initialized
INFO - 2020-03-29 10:23:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:23:57 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:23:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:23:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:23:57 --> Encryption Class Initialized
INFO - 2020-03-29 10:23:57 --> Controller Class Initialized
DEBUG - 2020-03-29 10:23:57 --> custom_page MX_Controller Initialized
ERROR - 2020-03-29 10:23:57 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-29 10:23:57 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-29 10:23:57 --> Config Class Initialized
INFO - 2020-03-29 10:23:57 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:23:57 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:23:57 --> Utf8 Class Initialized
INFO - 2020-03-29 10:23:57 --> URI Class Initialized
DEBUG - 2020-03-29 10:23:57 --> No URI present. Default controller set.
INFO - 2020-03-29 10:23:57 --> Router Class Initialized
INFO - 2020-03-29 10:23:57 --> Output Class Initialized
INFO - 2020-03-29 10:23:57 --> Security Class Initialized
DEBUG - 2020-03-29 10:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:23:57 --> CSRF cookie sent
INFO - 2020-03-29 10:23:57 --> Input Class Initialized
INFO - 2020-03-29 10:23:57 --> Language Class Initialized
INFO - 2020-03-29 10:23:57 --> Language Class Initialized
INFO - 2020-03-29 10:23:57 --> Config Class Initialized
INFO - 2020-03-29 10:23:57 --> Loader Class Initialized
INFO - 2020-03-29 10:23:57 --> Helper loaded: url_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: common_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: language_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: email_helper
INFO - 2020-03-29 10:23:57 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:23:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:23:57 --> Parser Class Initialized
INFO - 2020-03-29 10:23:58 --> User Agent Class Initialized
INFO - 2020-03-29 10:23:58 --> Model Class Initialized
INFO - 2020-03-29 10:23:58 --> Database Driver Class Initialized
INFO - 2020-03-29 10:23:58 --> Model Class Initialized
DEBUG - 2020-03-29 10:23:58 --> Template Class Initialized
INFO - 2020-03-29 10:23:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:23:58 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:23:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:23:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:23:58 --> Encryption Class Initialized
DEBUG - 2020-03-29 10:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-29 10:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-29 10:23:58 --> Controller Class Initialized
DEBUG - 2020-03-29 10:23:58 --> pergo MX_Controller Initialized
DEBUG - 2020-03-29 10:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-29 10:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-29 10:23:58 --> Model Class Initialized
INFO - 2020-03-29 10:23:58 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-29 10:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-29 10:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-29 10:23:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-29 10:23:58 --> Final output sent to browser
DEBUG - 2020-03-29 10:23:58 --> Total execution time: 0.6240
INFO - 2020-03-29 10:24:34 --> Config Class Initialized
INFO - 2020-03-29 10:24:34 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:24:34 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:24:34 --> Utf8 Class Initialized
INFO - 2020-03-29 10:24:34 --> URI Class Initialized
INFO - 2020-03-29 10:24:34 --> Router Class Initialized
INFO - 2020-03-29 10:24:34 --> Output Class Initialized
INFO - 2020-03-29 10:24:34 --> Security Class Initialized
DEBUG - 2020-03-29 10:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:24:34 --> CSRF cookie sent
INFO - 2020-03-29 10:24:34 --> Input Class Initialized
INFO - 2020-03-29 10:24:34 --> Language Class Initialized
INFO - 2020-03-29 10:24:34 --> Language Class Initialized
INFO - 2020-03-29 10:24:34 --> Config Class Initialized
INFO - 2020-03-29 10:24:34 --> Loader Class Initialized
INFO - 2020-03-29 10:24:34 --> Helper loaded: url_helper
INFO - 2020-03-29 10:24:34 --> Helper loaded: common_helper
INFO - 2020-03-29 10:24:34 --> Helper loaded: language_helper
INFO - 2020-03-29 10:24:34 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:24:34 --> Helper loaded: email_helper
INFO - 2020-03-29 10:24:34 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:24:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:24:35 --> Parser Class Initialized
INFO - 2020-03-29 10:24:35 --> User Agent Class Initialized
INFO - 2020-03-29 10:24:35 --> Model Class Initialized
INFO - 2020-03-29 10:24:35 --> Database Driver Class Initialized
INFO - 2020-03-29 10:24:35 --> Model Class Initialized
DEBUG - 2020-03-29 10:24:35 --> Template Class Initialized
INFO - 2020-03-29 10:24:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:24:35 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:24:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:24:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:24:35 --> Encryption Class Initialized
INFO - 2020-03-29 10:24:35 --> Controller Class Initialized
DEBUG - 2020-03-29 10:24:35 --> setting MX_Controller Initialized
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-29 10:24:35 --> Model Class Initialized
INFO - 2020-03-29 10:24:35 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-29 10:24:35 --> blocks MX_Controller Initialized
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-29 10:24:35 --> Model Class Initialized
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-29 10:24:35 --> Model Class Initialized
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-29 10:24:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-29 10:24:35 --> Final output sent to browser
DEBUG - 2020-03-29 10:24:35 --> Total execution time: 0.6863
INFO - 2020-03-29 10:24:41 --> Config Class Initialized
INFO - 2020-03-29 10:24:41 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:24:42 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:24:42 --> Utf8 Class Initialized
INFO - 2020-03-29 10:24:42 --> URI Class Initialized
INFO - 2020-03-29 10:24:42 --> Router Class Initialized
INFO - 2020-03-29 10:24:42 --> Output Class Initialized
INFO - 2020-03-29 10:24:42 --> Security Class Initialized
DEBUG - 2020-03-29 10:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:24:42 --> CSRF cookie sent
INFO - 2020-03-29 10:24:42 --> Input Class Initialized
INFO - 2020-03-29 10:24:42 --> Language Class Initialized
INFO - 2020-03-29 10:24:42 --> Language Class Initialized
INFO - 2020-03-29 10:24:42 --> Config Class Initialized
INFO - 2020-03-29 10:24:42 --> Loader Class Initialized
INFO - 2020-03-29 10:24:42 --> Helper loaded: url_helper
INFO - 2020-03-29 10:24:42 --> Helper loaded: common_helper
INFO - 2020-03-29 10:24:42 --> Helper loaded: language_helper
INFO - 2020-03-29 10:24:42 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:24:42 --> Helper loaded: email_helper
INFO - 2020-03-29 10:24:42 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:24:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:24:42 --> Parser Class Initialized
INFO - 2020-03-29 10:24:42 --> User Agent Class Initialized
DEBUG - 2020-03-29 10:24:42 --> Template Class Initialized
INFO - 2020-03-29 10:24:42 --> Database Driver Class Initialized
INFO - 2020-03-29 10:24:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:24:42 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:24:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:24:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:24:42 --> Encryption Class Initialized
INFO - 2020-03-29 10:24:42 --> Controller Class Initialized
DEBUG - 2020-03-29 10:24:42 --> payop MX_Controller Initialized
INFO - 2020-03-29 10:24:42 --> Model Class Initialized
INFO - 2020-03-29 10:24:42 --> Model Class Initialized
INFO - 2020-03-29 10:24:42 --> Model Class Initialized
INFO - 2020-03-29 10:24:42 --> Final output sent to browser
DEBUG - 2020-03-29 10:24:42 --> Total execution time: 0.4106
ERROR - 2020-03-29 10:24:42 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-29 10:24:42 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-29 10:25:05 --> Config Class Initialized
INFO - 2020-03-29 10:25:05 --> Hooks Class Initialized
DEBUG - 2020-03-29 10:25:05 --> UTF-8 Support Enabled
INFO - 2020-03-29 10:25:05 --> Utf8 Class Initialized
INFO - 2020-03-29 10:25:05 --> URI Class Initialized
INFO - 2020-03-29 10:25:05 --> Router Class Initialized
INFO - 2020-03-29 10:25:05 --> Output Class Initialized
INFO - 2020-03-29 10:25:05 --> Security Class Initialized
DEBUG - 2020-03-29 10:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-29 10:25:05 --> CSRF cookie sent
INFO - 2020-03-29 10:25:05 --> Input Class Initialized
INFO - 2020-03-29 10:25:05 --> Language Class Initialized
INFO - 2020-03-29 10:25:05 --> Language Class Initialized
INFO - 2020-03-29 10:25:05 --> Config Class Initialized
INFO - 2020-03-29 10:25:05 --> Loader Class Initialized
INFO - 2020-03-29 10:25:05 --> Helper loaded: url_helper
INFO - 2020-03-29 10:25:05 --> Helper loaded: common_helper
INFO - 2020-03-29 10:25:05 --> Helper loaded: language_helper
INFO - 2020-03-29 10:25:05 --> Helper loaded: cookie_helper
INFO - 2020-03-29 10:25:05 --> Helper loaded: email_helper
INFO - 2020-03-29 10:25:05 --> Helper loaded: file_manager_helper
INFO - 2020-03-29 10:25:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-29 10:25:05 --> Parser Class Initialized
INFO - 2020-03-29 10:25:05 --> User Agent Class Initialized
INFO - 2020-03-29 10:25:05 --> Model Class Initialized
INFO - 2020-03-29 10:25:05 --> Database Driver Class Initialized
INFO - 2020-03-29 10:25:05 --> Model Class Initialized
DEBUG - 2020-03-29 10:25:05 --> Template Class Initialized
INFO - 2020-03-29 10:25:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-29 10:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-29 10:25:05 --> Pagination Class Initialized
DEBUG - 2020-03-29 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-29 10:25:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-29 10:25:05 --> Encryption Class Initialized
INFO - 2020-03-29 10:25:05 --> Controller Class Initialized
DEBUG - 2020-03-29 10:25:05 --> setting MX_Controller Initialized
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-29 10:25:05 --> Model Class Initialized
INFO - 2020-03-29 10:25:05 --> Helper loaded: inflector_helper
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-29 10:25:05 --> blocks MX_Controller Initialized
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-29 10:25:05 --> Model Class Initialized
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-29 10:25:05 --> Model Class Initialized
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-29 10:25:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-29 10:25:05 --> Final output sent to browser
DEBUG - 2020-03-29 10:25:05 --> Total execution time: 0.7024
