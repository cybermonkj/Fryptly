<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-16 10:36:41 --> Config Class Initialized
INFO - 2019-11-16 10:36:41 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:36:41 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:36:41 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:41 --> URI Class Initialized
DEBUG - 2019-11-16 10:36:41 --> No URI present. Default controller set.
INFO - 2019-11-16 10:36:41 --> Router Class Initialized
INFO - 2019-11-16 10:36:41 --> Output Class Initialized
INFO - 2019-11-16 10:36:41 --> Security Class Initialized
DEBUG - 2019-11-16 10:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:36:41 --> CSRF cookie sent
INFO - 2019-11-16 10:36:41 --> Input Class Initialized
INFO - 2019-11-16 10:36:41 --> Language Class Initialized
INFO - 2019-11-16 10:36:41 --> Language Class Initialized
INFO - 2019-11-16 10:36:41 --> Config Class Initialized
INFO - 2019-11-16 10:36:41 --> Loader Class Initialized
INFO - 2019-11-16 10:36:41 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:41 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:41 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:41 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:41 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:41 --> Parser Class Initialized
INFO - 2019-11-16 10:36:41 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:41 --> Model Class Initialized
INFO - 2019-11-16 10:36:41 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:41 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:41 --> Template Class Initialized
INFO - 2019-11-16 10:36:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:41 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:36:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:41 --> Encryption Class Initialized
DEBUG - 2019-11-16 10:36:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-16 10:36:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-16 10:36:41 --> Controller Class Initialized
DEBUG - 2019-11-16 10:36:41 --> pergo MX_Controller Initialized
DEBUG - 2019-11-16 10:36:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-16 10:36:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-16 10:36:41 --> Model Class Initialized
INFO - 2019-11-16 10:36:41 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 10:36:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-16 10:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-16 10:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-16 10:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-16 10:36:42 --> Final output sent to browser
DEBUG - 2019-11-16 10:36:42 --> Total execution time: 1.1071
INFO - 2019-11-16 10:36:45 --> Config Class Initialized
INFO - 2019-11-16 10:36:45 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:36:45 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:36:45 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:45 --> URI Class Initialized
INFO - 2019-11-16 10:36:45 --> Router Class Initialized
INFO - 2019-11-16 10:36:45 --> Output Class Initialized
INFO - 2019-11-16 10:36:45 --> Security Class Initialized
DEBUG - 2019-11-16 10:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:36:45 --> CSRF cookie sent
INFO - 2019-11-16 10:36:45 --> Input Class Initialized
INFO - 2019-11-16 10:36:45 --> Language Class Initialized
INFO - 2019-11-16 10:36:45 --> Language Class Initialized
INFO - 2019-11-16 10:36:45 --> Config Class Initialized
INFO - 2019-11-16 10:36:45 --> Loader Class Initialized
INFO - 2019-11-16 10:36:45 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:45 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:45 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:45 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:45 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:45 --> Parser Class Initialized
INFO - 2019-11-16 10:36:45 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:45 --> Model Class Initialized
INFO - 2019-11-16 10:36:45 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:45 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:45 --> Template Class Initialized
INFO - 2019-11-16 10:36:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:45 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:36:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:45 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:45 --> Controller Class Initialized
DEBUG - 2019-11-16 10:36:45 --> auth MX_Controller Initialized
DEBUG - 2019-11-16 10:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-16 10:36:45 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-16 10:36:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 10:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-16 10:36:45 --> pergo MX_Controller Initialized
DEBUG - 2019-11-16 10:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-16 10:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-16 10:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-16 10:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-16 10:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-16 10:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-16 10:36:45 --> Final output sent to browser
DEBUG - 2019-11-16 10:36:45 --> Total execution time: 0.7124
INFO - 2019-11-16 10:36:47 --> Config Class Initialized
INFO - 2019-11-16 10:36:47 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:36:47 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:36:47 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:47 --> URI Class Initialized
INFO - 2019-11-16 10:36:47 --> Router Class Initialized
INFO - 2019-11-16 10:36:47 --> Output Class Initialized
INFO - 2019-11-16 10:36:47 --> Security Class Initialized
DEBUG - 2019-11-16 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:36:47 --> CSRF cookie sent
INFO - 2019-11-16 10:36:47 --> CSRF token verified
INFO - 2019-11-16 10:36:47 --> Input Class Initialized
INFO - 2019-11-16 10:36:47 --> Language Class Initialized
INFO - 2019-11-16 10:36:47 --> Language Class Initialized
INFO - 2019-11-16 10:36:47 --> Config Class Initialized
INFO - 2019-11-16 10:36:47 --> Loader Class Initialized
INFO - 2019-11-16 10:36:47 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:47 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:47 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:47 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:47 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:47 --> Parser Class Initialized
INFO - 2019-11-16 10:36:47 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:47 --> Model Class Initialized
INFO - 2019-11-16 10:36:47 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:47 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:47 --> Template Class Initialized
INFO - 2019-11-16 10:36:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:47 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:36:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:47 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:47 --> Controller Class Initialized
DEBUG - 2019-11-16 10:36:47 --> auth MX_Controller Initialized
DEBUG - 2019-11-16 10:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-16 10:36:47 --> Model Class Initialized
INFO - 2019-11-16 10:36:52 --> Config Class Initialized
INFO - 2019-11-16 10:36:52 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:36:52 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:36:52 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:52 --> URI Class Initialized
INFO - 2019-11-16 10:36:52 --> Router Class Initialized
INFO - 2019-11-16 10:36:52 --> Output Class Initialized
INFO - 2019-11-16 10:36:52 --> Security Class Initialized
DEBUG - 2019-11-16 10:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:36:52 --> CSRF cookie sent
INFO - 2019-11-16 10:36:52 --> Input Class Initialized
INFO - 2019-11-16 10:36:52 --> Language Class Initialized
INFO - 2019-11-16 10:36:52 --> Language Class Initialized
INFO - 2019-11-16 10:36:52 --> Config Class Initialized
INFO - 2019-11-16 10:36:52 --> Loader Class Initialized
INFO - 2019-11-16 10:36:52 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:52 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:52 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:52 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:52 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:52 --> Parser Class Initialized
INFO - 2019-11-16 10:36:52 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:52 --> Model Class Initialized
INFO - 2019-11-16 10:36:52 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:52 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:52 --> Template Class Initialized
INFO - 2019-11-16 10:36:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:52 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:36:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:52 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:52 --> Controller Class Initialized
DEBUG - 2019-11-16 10:36:52 --> statistics MX_Controller Initialized
DEBUG - 2019-11-16 10:36:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-16 10:36:52 --> Model Class Initialized
ERROR - 2019-11-16 10:36:53 --> Could not find the language line "Pending"
ERROR - 2019-11-16 10:36:53 --> Could not find the language line "Pending"
INFO - 2019-11-16 10:36:53 --> Helper loaded: inflector_helper
ERROR - 2019-11-16 10:36:53 --> Could not find the language line "total_orders"
ERROR - 2019-11-16 10:36:53 --> Could not find the language line "total_orders"
ERROR - 2019-11-16 10:36:53 --> Could not find the language line "Pending"
DEBUG - 2019-11-16 10:36:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-16 10:36:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 10:36:53 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 10:36:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:36:53 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 10:36:53 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 10:36:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 10:36:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 10:36:53 --> Final output sent to browser
DEBUG - 2019-11-16 10:36:53 --> Total execution time: 0.8779
INFO - 2019-11-16 10:36:57 --> Config Class Initialized
INFO - 2019-11-16 10:36:57 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:36:57 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:36:57 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:57 --> URI Class Initialized
INFO - 2019-11-16 10:36:57 --> Router Class Initialized
INFO - 2019-11-16 10:36:57 --> Output Class Initialized
INFO - 2019-11-16 10:36:57 --> Security Class Initialized
DEBUG - 2019-11-16 10:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:36:57 --> CSRF cookie sent
INFO - 2019-11-16 10:36:57 --> Input Class Initialized
INFO - 2019-11-16 10:36:57 --> Language Class Initialized
INFO - 2019-11-16 10:36:57 --> Language Class Initialized
INFO - 2019-11-16 10:36:57 --> Config Class Initialized
INFO - 2019-11-16 10:36:57 --> Loader Class Initialized
INFO - 2019-11-16 10:36:57 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:57 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:57 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:57 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:57 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:57 --> Parser Class Initialized
INFO - 2019-11-16 10:36:57 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:57 --> Model Class Initialized
INFO - 2019-11-16 10:36:57 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:57 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:57 --> Template Class Initialized
INFO - 2019-11-16 10:36:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:57 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:36:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:57 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:57 --> Controller Class Initialized
DEBUG - 2019-11-16 10:36:57 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:36:57 --> Model Class Initialized
INFO - 2019-11-16 10:36:57 --> Helper loaded: inflector_helper
ERROR - 2019-11-16 10:36:58 --> Could not find the language line "Delele"
DEBUG - 2019-11-16 10:36:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2019-11-16 10:36:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 10:36:58 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 10:36:58 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 10:36:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 10:36:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 10:36:58 --> Final output sent to browser
DEBUG - 2019-11-16 10:36:58 --> Total execution time: 0.7736
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Hooks Class Initialized
INFO - 2019-11-16 10:36:58 --> Hooks Class Initialized
INFO - 2019-11-16 10:36:58 --> Hooks Class Initialized
INFO - 2019-11-16 10:36:58 --> Hooks Class Initialized
INFO - 2019-11-16 10:36:58 --> Hooks Class Initialized
INFO - 2019-11-16 10:36:58 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:36:58 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:36:58 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:58 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:58 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:58 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:58 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:58 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:58 --> URI Class Initialized
INFO - 2019-11-16 10:36:58 --> URI Class Initialized
INFO - 2019-11-16 10:36:58 --> URI Class Initialized
INFO - 2019-11-16 10:36:58 --> URI Class Initialized
INFO - 2019-11-16 10:36:58 --> URI Class Initialized
INFO - 2019-11-16 10:36:58 --> URI Class Initialized
INFO - 2019-11-16 10:36:58 --> Router Class Initialized
INFO - 2019-11-16 10:36:58 --> Router Class Initialized
INFO - 2019-11-16 10:36:58 --> Router Class Initialized
INFO - 2019-11-16 10:36:58 --> Router Class Initialized
INFO - 2019-11-16 10:36:58 --> Router Class Initialized
INFO - 2019-11-16 10:36:58 --> Router Class Initialized
INFO - 2019-11-16 10:36:58 --> Output Class Initialized
INFO - 2019-11-16 10:36:58 --> Output Class Initialized
INFO - 2019-11-16 10:36:58 --> Output Class Initialized
INFO - 2019-11-16 10:36:58 --> Output Class Initialized
INFO - 2019-11-16 10:36:58 --> Output Class Initialized
INFO - 2019-11-16 10:36:58 --> Output Class Initialized
INFO - 2019-11-16 10:36:58 --> Security Class Initialized
INFO - 2019-11-16 10:36:58 --> Security Class Initialized
INFO - 2019-11-16 10:36:58 --> Security Class Initialized
INFO - 2019-11-16 10:36:58 --> Security Class Initialized
INFO - 2019-11-16 10:36:58 --> Security Class Initialized
INFO - 2019-11-16 10:36:58 --> Security Class Initialized
DEBUG - 2019-11-16 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:36:58 --> CSRF cookie sent
INFO - 2019-11-16 10:36:58 --> CSRF cookie sent
INFO - 2019-11-16 10:36:58 --> CSRF cookie sent
INFO - 2019-11-16 10:36:58 --> CSRF cookie sent
INFO - 2019-11-16 10:36:58 --> CSRF cookie sent
INFO - 2019-11-16 10:36:58 --> CSRF cookie sent
INFO - 2019-11-16 10:36:58 --> CSRF token verified
INFO - 2019-11-16 10:36:58 --> CSRF token verified
INFO - 2019-11-16 10:36:58 --> CSRF token verified
INFO - 2019-11-16 10:36:58 --> CSRF token verified
INFO - 2019-11-16 10:36:58 --> CSRF token verified
INFO - 2019-11-16 10:36:58 --> CSRF token verified
INFO - 2019-11-16 10:36:58 --> Input Class Initialized
INFO - 2019-11-16 10:36:58 --> Input Class Initialized
INFO - 2019-11-16 10:36:58 --> Input Class Initialized
INFO - 2019-11-16 10:36:58 --> Input Class Initialized
INFO - 2019-11-16 10:36:58 --> Input Class Initialized
INFO - 2019-11-16 10:36:58 --> Input Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Language Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Config Class Initialized
INFO - 2019-11-16 10:36:58 --> Loader Class Initialized
INFO - 2019-11-16 10:36:58 --> Loader Class Initialized
INFO - 2019-11-16 10:36:58 --> Loader Class Initialized
INFO - 2019-11-16 10:36:58 --> Loader Class Initialized
INFO - 2019-11-16 10:36:58 --> Loader Class Initialized
INFO - 2019-11-16 10:36:58 --> Loader Class Initialized
INFO - 2019-11-16 10:36:58 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:58 --> Parser Class Initialized
INFO - 2019-11-16 10:36:58 --> Parser Class Initialized
INFO - 2019-11-16 10:36:58 --> Parser Class Initialized
INFO - 2019-11-16 10:36:58 --> Parser Class Initialized
INFO - 2019-11-16 10:36:58 --> Parser Class Initialized
INFO - 2019-11-16 10:36:58 --> Parser Class Initialized
INFO - 2019-11-16 10:36:58 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:58 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:58 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:58 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:58 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:58 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:58 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:58 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:58 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:58 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:58 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:58 --> Template Class Initialized
DEBUG - 2019-11-16 10:36:58 --> Template Class Initialized
DEBUG - 2019-11-16 10:36:58 --> Template Class Initialized
DEBUG - 2019-11-16 10:36:58 --> Template Class Initialized
DEBUG - 2019-11-16 10:36:58 --> Template Class Initialized
DEBUG - 2019-11-16 10:36:58 --> Template Class Initialized
INFO - 2019-11-16 10:36:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:58 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:36:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:58 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:58 --> Controller Class Initialized
DEBUG - 2019-11-16 10:36:58 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:36:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:36:58 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:36:58 --> Final output sent to browser
DEBUG - 2019-11-16 10:36:58 --> Total execution time: 0.5771
INFO - 2019-11-16 10:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:59 --> Config Class Initialized
INFO - 2019-11-16 10:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:59 --> Pagination Class Initialized
INFO - 2019-11-16 10:36:59 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-16 10:36:59 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:36:59 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:59 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:59 --> URI Class Initialized
INFO - 2019-11-16 10:36:59 --> Controller Class Initialized
INFO - 2019-11-16 10:36:59 --> Router Class Initialized
DEBUG - 2019-11-16 10:36:59 --> services MX_Controller Initialized
INFO - 2019-11-16 10:36:59 --> Output Class Initialized
INFO - 2019-11-16 10:36:59 --> Security Class Initialized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:36:59 --> CSRF cookie sent
INFO - 2019-11-16 10:36:59 --> CSRF token verified
INFO - 2019-11-16 10:36:59 --> Input Class Initialized
INFO - 2019-11-16 10:36:59 --> Language Class Initialized
INFO - 2019-11-16 10:36:59 --> Language Class Initialized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:36:59 --> Config Class Initialized
INFO - 2019-11-16 10:36:59 --> Final output sent to browser
DEBUG - 2019-11-16 10:36:59 --> Total execution time: 0.7702
INFO - 2019-11-16 10:36:59 --> Loader Class Initialized
INFO - 2019-11-16 10:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:59 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:59 --> Config Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:59 --> Pagination Class Initialized
INFO - 2019-11-16 10:36:59 --> Hooks Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:59 --> Helper loaded: cookie_helper
DEBUG - 2019-11-16 10:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-16 10:36:59 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:36:59 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:59 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:59 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:59 --> URI Class Initialized
INFO - 2019-11-16 10:36:59 --> Controller Class Initialized
INFO - 2019-11-16 10:36:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:36:59 --> Router Class Initialized
DEBUG - 2019-11-16 10:36:59 --> services MX_Controller Initialized
INFO - 2019-11-16 10:36:59 --> Output Class Initialized
INFO - 2019-11-16 10:36:59 --> Parser Class Initialized
INFO - 2019-11-16 10:36:59 --> Security Class Initialized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:36:59 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
INFO - 2019-11-16 10:36:59 --> CSRF cookie sent
INFO - 2019-11-16 10:36:59 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:59 --> CSRF token verified
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
INFO - 2019-11-16 10:36:59 --> Input Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Template Class Initialized
INFO - 2019-11-16 10:36:59 --> Language Class Initialized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:36:59 --> Final output sent to browser
INFO - 2019-11-16 10:36:59 --> Language Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Total execution time: 0.9412
INFO - 2019-11-16 10:36:59 --> Config Class Initialized
INFO - 2019-11-16 10:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:59 --> Loader Class Initialized
INFO - 2019-11-16 10:36:59 --> Config Class Initialized
INFO - 2019-11-16 10:36:59 --> Hooks Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:59 --> Pagination Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: common_helper
DEBUG - 2019-11-16 10:36:59 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:36:59 --> Utf8 Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: language_helper
DEBUG - 2019-11-16 10:36:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:59 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:36:59 --> URI Class Initialized
INFO - 2019-11-16 10:36:59 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:59 --> Router Class Initialized
INFO - 2019-11-16 10:36:59 --> Controller Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:59 --> Output Class Initialized
DEBUG - 2019-11-16 10:36:59 --> services MX_Controller Initialized
INFO - 2019-11-16 10:36:59 --> Security Class Initialized
INFO - 2019-11-16 10:36:59 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-16 10:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:36:59 --> Parser Class Initialized
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
INFO - 2019-11-16 10:36:59 --> CSRF cookie sent
INFO - 2019-11-16 10:36:59 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:59 --> CSRF token verified
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
INFO - 2019-11-16 10:36:59 --> Input Class Initialized
INFO - 2019-11-16 10:36:59 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:59 --> Language Class Initialized
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Template Class Initialized
INFO - 2019-11-16 10:36:59 --> Language Class Initialized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:36:59 --> Final output sent to browser
INFO - 2019-11-16 10:36:59 --> Config Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Total execution time: 1.1248
INFO - 2019-11-16 10:36:59 --> Loader Class Initialized
INFO - 2019-11-16 10:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:59 --> Helper loaded: url_helper
INFO - 2019-11-16 10:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:59 --> Helper loaded: common_helper
INFO - 2019-11-16 10:36:59 --> Pagination Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: language_helper
INFO - 2019-11-16 10:36:59 --> Helper loaded: cookie_helper
DEBUG - 2019-11-16 10:36:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:59 --> Helper loaded: email_helper
INFO - 2019-11-16 10:36:59 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:36:59 --> Controller Class Initialized
INFO - 2019-11-16 10:36:59 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-16 10:36:59 --> services MX_Controller Initialized
INFO - 2019-11-16 10:36:59 --> Parser Class Initialized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:36:59 --> User Agent Class Initialized
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
INFO - 2019-11-16 10:36:59 --> Database Driver Class Initialized
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Template Class Initialized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:36:59 --> Final output sent to browser
DEBUG - 2019-11-16 10:36:59 --> Total execution time: 1.2950
INFO - 2019-11-16 10:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:59 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:59 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:59 --> Controller Class Initialized
DEBUG - 2019-11-16 10:36:59 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:36:59 --> Model Class Initialized
DEBUG - 2019-11-16 10:36:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:36:59 --> Final output sent to browser
DEBUG - 2019-11-16 10:36:59 --> Total execution time: 1.4973
INFO - 2019-11-16 10:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:36:59 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:36:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:36:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:36:59 --> Encryption Class Initialized
INFO - 2019-11-16 10:36:59 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:00 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:00 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:00 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:00 --> Total execution time: 1.0664
INFO - 2019-11-16 10:37:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:00 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:00 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:00 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:00 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:00 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:00 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:00 --> Total execution time: 1.0185
INFO - 2019-11-16 10:37:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:00 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:00 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:00 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:00 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:00 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:00 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:00 --> Total execution time: 1.0462
INFO - 2019-11-16 10:37:01 --> Config Class Initialized
INFO - 2019-11-16 10:37:01 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:37:01 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:37:01 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:01 --> URI Class Initialized
INFO - 2019-11-16 10:37:01 --> Router Class Initialized
INFO - 2019-11-16 10:37:01 --> Output Class Initialized
INFO - 2019-11-16 10:37:01 --> Security Class Initialized
DEBUG - 2019-11-16 10:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:37:01 --> CSRF cookie sent
INFO - 2019-11-16 10:37:01 --> Input Class Initialized
INFO - 2019-11-16 10:37:01 --> Language Class Initialized
INFO - 2019-11-16 10:37:01 --> Language Class Initialized
INFO - 2019-11-16 10:37:01 --> Config Class Initialized
INFO - 2019-11-16 10:37:01 --> Loader Class Initialized
INFO - 2019-11-16 10:37:01 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:01 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:01 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:01 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:01 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:01 --> Parser Class Initialized
INFO - 2019-11-16 10:37:01 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:02 --> Model Class Initialized
INFO - 2019-11-16 10:37:02 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:02 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:02 --> Template Class Initialized
INFO - 2019-11-16 10:37:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:02 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:02 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:02 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:02 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:02 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/update.php
INFO - 2019-11-16 10:37:02 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:02 --> Total execution time: 0.5741
INFO - 2019-11-16 10:37:06 --> Config Class Initialized
INFO - 2019-11-16 10:37:06 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:37:06 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:37:06 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:06 --> URI Class Initialized
INFO - 2019-11-16 10:37:06 --> Router Class Initialized
INFO - 2019-11-16 10:37:06 --> Output Class Initialized
INFO - 2019-11-16 10:37:06 --> Security Class Initialized
DEBUG - 2019-11-16 10:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:37:06 --> CSRF cookie sent
INFO - 2019-11-16 10:37:06 --> Input Class Initialized
INFO - 2019-11-16 10:37:06 --> Language Class Initialized
INFO - 2019-11-16 10:37:06 --> Language Class Initialized
INFO - 2019-11-16 10:37:06 --> Config Class Initialized
INFO - 2019-11-16 10:37:06 --> Loader Class Initialized
INFO - 2019-11-16 10:37:06 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:07 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:07 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:07 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:07 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:07 --> Parser Class Initialized
INFO - 2019-11-16 10:37:07 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:07 --> Model Class Initialized
INFO - 2019-11-16 10:37:07 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:07 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:07 --> Template Class Initialized
INFO - 2019-11-16 10:37:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:07 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:07 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:07 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:07 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:07 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/update.php
INFO - 2019-11-16 10:37:07 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:07 --> Total execution time: 0.9181
INFO - 2019-11-16 10:37:07 --> Config Class Initialized
INFO - 2019-11-16 10:37:07 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:37:07 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:37:07 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:07 --> URI Class Initialized
INFO - 2019-11-16 10:37:07 --> Router Class Initialized
INFO - 2019-11-16 10:37:07 --> Output Class Initialized
INFO - 2019-11-16 10:37:07 --> Security Class Initialized
DEBUG - 2019-11-16 10:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:37:07 --> CSRF cookie sent
INFO - 2019-11-16 10:37:07 --> Input Class Initialized
INFO - 2019-11-16 10:37:07 --> Language Class Initialized
INFO - 2019-11-16 10:37:07 --> Language Class Initialized
INFO - 2019-11-16 10:37:07 --> Config Class Initialized
INFO - 2019-11-16 10:37:07 --> Loader Class Initialized
INFO - 2019-11-16 10:37:07 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:07 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:08 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:08 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:08 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:08 --> Parser Class Initialized
INFO - 2019-11-16 10:37:08 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:08 --> Model Class Initialized
INFO - 2019-11-16 10:37:08 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:08 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:08 --> Template Class Initialized
INFO - 2019-11-16 10:37:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:08 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:08 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:08 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:08 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:08 --> Model Class Initialized
INFO - 2019-11-16 10:37:08 --> Helper loaded: inflector_helper
ERROR - 2019-11-16 10:37:08 --> Could not find the language line "Delele"
DEBUG - 2019-11-16 10:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2019-11-16 10:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 10:37:08 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 10:37:08 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:08 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 10:37:08 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 10:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 10:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 10:37:08 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:08 --> Total execution time: 1.2793
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Hooks Class Initialized
INFO - 2019-11-16 10:37:09 --> Hooks Class Initialized
INFO - 2019-11-16 10:37:09 --> Hooks Class Initialized
INFO - 2019-11-16 10:37:09 --> Hooks Class Initialized
INFO - 2019-11-16 10:37:09 --> Hooks Class Initialized
INFO - 2019-11-16 10:37:09 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 10:37:09 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:37:09 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:09 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:09 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:09 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:09 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:09 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:09 --> URI Class Initialized
INFO - 2019-11-16 10:37:09 --> URI Class Initialized
INFO - 2019-11-16 10:37:09 --> URI Class Initialized
INFO - 2019-11-16 10:37:09 --> URI Class Initialized
INFO - 2019-11-16 10:37:09 --> URI Class Initialized
INFO - 2019-11-16 10:37:09 --> URI Class Initialized
INFO - 2019-11-16 10:37:09 --> Router Class Initialized
INFO - 2019-11-16 10:37:09 --> Router Class Initialized
INFO - 2019-11-16 10:37:09 --> Router Class Initialized
INFO - 2019-11-16 10:37:09 --> Router Class Initialized
INFO - 2019-11-16 10:37:09 --> Router Class Initialized
INFO - 2019-11-16 10:37:09 --> Router Class Initialized
INFO - 2019-11-16 10:37:09 --> Output Class Initialized
INFO - 2019-11-16 10:37:09 --> Output Class Initialized
INFO - 2019-11-16 10:37:09 --> Output Class Initialized
INFO - 2019-11-16 10:37:09 --> Output Class Initialized
INFO - 2019-11-16 10:37:09 --> Output Class Initialized
INFO - 2019-11-16 10:37:09 --> Output Class Initialized
INFO - 2019-11-16 10:37:09 --> Security Class Initialized
INFO - 2019-11-16 10:37:09 --> Security Class Initialized
INFO - 2019-11-16 10:37:09 --> Security Class Initialized
INFO - 2019-11-16 10:37:09 --> Security Class Initialized
INFO - 2019-11-16 10:37:09 --> Security Class Initialized
INFO - 2019-11-16 10:37:09 --> Security Class Initialized
DEBUG - 2019-11-16 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:37:09 --> CSRF cookie sent
INFO - 2019-11-16 10:37:09 --> CSRF cookie sent
INFO - 2019-11-16 10:37:09 --> CSRF cookie sent
INFO - 2019-11-16 10:37:09 --> CSRF cookie sent
INFO - 2019-11-16 10:37:09 --> CSRF cookie sent
INFO - 2019-11-16 10:37:09 --> CSRF cookie sent
INFO - 2019-11-16 10:37:09 --> CSRF token verified
INFO - 2019-11-16 10:37:09 --> CSRF token verified
INFO - 2019-11-16 10:37:09 --> CSRF token verified
INFO - 2019-11-16 10:37:09 --> CSRF token verified
INFO - 2019-11-16 10:37:09 --> CSRF token verified
INFO - 2019-11-16 10:37:09 --> CSRF token verified
INFO - 2019-11-16 10:37:09 --> Input Class Initialized
INFO - 2019-11-16 10:37:09 --> Input Class Initialized
INFO - 2019-11-16 10:37:09 --> Input Class Initialized
INFO - 2019-11-16 10:37:09 --> Input Class Initialized
INFO - 2019-11-16 10:37:09 --> Input Class Initialized
INFO - 2019-11-16 10:37:09 --> Input Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Language Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Config Class Initialized
INFO - 2019-11-16 10:37:09 --> Loader Class Initialized
INFO - 2019-11-16 10:37:09 --> Loader Class Initialized
INFO - 2019-11-16 10:37:09 --> Loader Class Initialized
INFO - 2019-11-16 10:37:09 --> Loader Class Initialized
INFO - 2019-11-16 10:37:09 --> Loader Class Initialized
INFO - 2019-11-16 10:37:09 --> Loader Class Initialized
INFO - 2019-11-16 10:37:09 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:09 --> Parser Class Initialized
INFO - 2019-11-16 10:37:09 --> Parser Class Initialized
INFO - 2019-11-16 10:37:09 --> Parser Class Initialized
INFO - 2019-11-16 10:37:09 --> Parser Class Initialized
INFO - 2019-11-16 10:37:09 --> Parser Class Initialized
INFO - 2019-11-16 10:37:09 --> Parser Class Initialized
INFO - 2019-11-16 10:37:09 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:09 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:09 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:09 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:09 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:09 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:09 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:09 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:09 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:09 --> Template Class Initialized
INFO - 2019-11-16 10:37:09 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:09 --> Template Class Initialized
DEBUG - 2019-11-16 10:37:09 --> Template Class Initialized
DEBUG - 2019-11-16 10:37:09 --> Template Class Initialized
DEBUG - 2019-11-16 10:37:09 --> Template Class Initialized
DEBUG - 2019-11-16 10:37:09 --> Template Class Initialized
INFO - 2019-11-16 10:37:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:09 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:09 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:09 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:09 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:10 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:10 --> Total execution time: 0.7259
INFO - 2019-11-16 10:37:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:10 --> Config Class Initialized
INFO - 2019-11-16 10:37:10 --> Hooks Class Initialized
INFO - 2019-11-16 10:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:10 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:10 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:37:10 --> Utf8 Class Initialized
DEBUG - 2019-11-16 10:37:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:10 --> URI Class Initialized
INFO - 2019-11-16 10:37:10 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:10 --> Router Class Initialized
INFO - 2019-11-16 10:37:10 --> Controller Class Initialized
INFO - 2019-11-16 10:37:10 --> Output Class Initialized
DEBUG - 2019-11-16 10:37:10 --> services MX_Controller Initialized
INFO - 2019-11-16 10:37:10 --> Security Class Initialized
DEBUG - 2019-11-16 10:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:37:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
INFO - 2019-11-16 10:37:10 --> CSRF cookie sent
INFO - 2019-11-16 10:37:10 --> CSRF token verified
INFO - 2019-11-16 10:37:10 --> Input Class Initialized
INFO - 2019-11-16 10:37:10 --> Language Class Initialized
DEBUG - 2019-11-16 10:37:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:10 --> Language Class Initialized
INFO - 2019-11-16 10:37:10 --> Config Class Initialized
INFO - 2019-11-16 10:37:10 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:10 --> Total execution time: 0.9796
INFO - 2019-11-16 10:37:10 --> Loader Class Initialized
INFO - 2019-11-16 10:37:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:10 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:10 --> Config Class Initialized
INFO - 2019-11-16 10:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:10 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:10 --> Pagination Class Initialized
INFO - 2019-11-16 10:37:10 --> Hooks Class Initialized
INFO - 2019-11-16 10:37:10 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:10 --> Helper loaded: cookie_helper
DEBUG - 2019-11-16 10:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-16 10:37:10 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:37:10 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:10 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:10 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:10 --> URI Class Initialized
INFO - 2019-11-16 10:37:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:10 --> Controller Class Initialized
INFO - 2019-11-16 10:37:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:10 --> Router Class Initialized
DEBUG - 2019-11-16 10:37:10 --> services MX_Controller Initialized
INFO - 2019-11-16 10:37:10 --> Output Class Initialized
INFO - 2019-11-16 10:37:10 --> Parser Class Initialized
INFO - 2019-11-16 10:37:10 --> Security Class Initialized
DEBUG - 2019-11-16 10:37:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:10 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
INFO - 2019-11-16 10:37:10 --> CSRF cookie sent
INFO - 2019-11-16 10:37:10 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:10 --> CSRF token verified
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
INFO - 2019-11-16 10:37:10 --> Input Class Initialized
DEBUG - 2019-11-16 10:37:10 --> Template Class Initialized
INFO - 2019-11-16 10:37:10 --> Language Class Initialized
INFO - 2019-11-16 10:37:10 --> Language Class Initialized
DEBUG - 2019-11-16 10:37:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:10 --> Config Class Initialized
INFO - 2019-11-16 10:37:10 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:10 --> Total execution time: 1.2310
INFO - 2019-11-16 10:37:10 --> Loader Class Initialized
INFO - 2019-11-16 10:37:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:10 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:10 --> Config Class Initialized
INFO - 2019-11-16 10:37:10 --> Hooks Class Initialized
INFO - 2019-11-16 10:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:10 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:10 --> Pagination Class Initialized
INFO - 2019-11-16 10:37:10 --> Helper loaded: language_helper
DEBUG - 2019-11-16 10:37:10 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:37:10 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:10 --> Helper loaded: cookie_helper
DEBUG - 2019-11-16 10:37:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:10 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:10 --> URI Class Initialized
INFO - 2019-11-16 10:37:10 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:10 --> Router Class Initialized
INFO - 2019-11-16 10:37:10 --> Controller Class Initialized
INFO - 2019-11-16 10:37:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:10 --> Output Class Initialized
DEBUG - 2019-11-16 10:37:10 --> services MX_Controller Initialized
INFO - 2019-11-16 10:37:10 --> Security Class Initialized
INFO - 2019-11-16 10:37:10 --> Parser Class Initialized
DEBUG - 2019-11-16 10:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 10:37:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:10 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:10 --> CSRF cookie sent
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
INFO - 2019-11-16 10:37:10 --> CSRF token verified
INFO - 2019-11-16 10:37:10 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:10 --> Input Class Initialized
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
INFO - 2019-11-16 10:37:10 --> Language Class Initialized
DEBUG - 2019-11-16 10:37:10 --> Template Class Initialized
INFO - 2019-11-16 10:37:10 --> Language Class Initialized
DEBUG - 2019-11-16 10:37:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:10 --> Config Class Initialized
INFO - 2019-11-16 10:37:10 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:10 --> Total execution time: 1.4645
INFO - 2019-11-16 10:37:10 --> Loader Class Initialized
INFO - 2019-11-16 10:37:10 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:10 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:10 --> Pagination Class Initialized
INFO - 2019-11-16 10:37:10 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:10 --> Helper loaded: cookie_helper
DEBUG - 2019-11-16 10:37:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:10 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:10 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:10 --> Controller Class Initialized
INFO - 2019-11-16 10:37:10 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-16 10:37:10 --> services MX_Controller Initialized
INFO - 2019-11-16 10:37:10 --> Parser Class Initialized
DEBUG - 2019-11-16 10:37:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:10 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
INFO - 2019-11-16 10:37:10 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:10 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:10 --> Template Class Initialized
DEBUG - 2019-11-16 10:37:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:11 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:11 --> Total execution time: 1.6467
INFO - 2019-11-16 10:37:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:11 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:11 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:11 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:11 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:11 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:11 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:11 --> Total execution time: 1.8855
INFO - 2019-11-16 10:37:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:11 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:11 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:11 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:11 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:11 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:11 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:11 --> Total execution time: 1.3173
INFO - 2019-11-16 10:37:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:11 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:11 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:11 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:11 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:11 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:11 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:11 --> Total execution time: 1.2766
INFO - 2019-11-16 10:37:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:11 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:11 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:11 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:11 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:11 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-16 10:37:11 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:11 --> Total execution time: 1.2431
INFO - 2019-11-16 10:37:12 --> Config Class Initialized
INFO - 2019-11-16 10:37:12 --> Hooks Class Initialized
DEBUG - 2019-11-16 10:37:12 --> UTF-8 Support Enabled
INFO - 2019-11-16 10:37:12 --> Utf8 Class Initialized
INFO - 2019-11-16 10:37:12 --> URI Class Initialized
INFO - 2019-11-16 10:37:12 --> Router Class Initialized
INFO - 2019-11-16 10:37:12 --> Output Class Initialized
INFO - 2019-11-16 10:37:12 --> Security Class Initialized
DEBUG - 2019-11-16 10:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 10:37:12 --> CSRF cookie sent
INFO - 2019-11-16 10:37:12 --> Input Class Initialized
INFO - 2019-11-16 10:37:12 --> Language Class Initialized
INFO - 2019-11-16 10:37:12 --> Language Class Initialized
INFO - 2019-11-16 10:37:12 --> Config Class Initialized
INFO - 2019-11-16 10:37:12 --> Loader Class Initialized
INFO - 2019-11-16 10:37:12 --> Helper loaded: url_helper
INFO - 2019-11-16 10:37:12 --> Helper loaded: common_helper
INFO - 2019-11-16 10:37:12 --> Helper loaded: language_helper
INFO - 2019-11-16 10:37:12 --> Helper loaded: cookie_helper
INFO - 2019-11-16 10:37:12 --> Helper loaded: email_helper
INFO - 2019-11-16 10:37:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 10:37:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 10:37:12 --> Parser Class Initialized
INFO - 2019-11-16 10:37:13 --> User Agent Class Initialized
INFO - 2019-11-16 10:37:13 --> Model Class Initialized
INFO - 2019-11-16 10:37:13 --> Database Driver Class Initialized
INFO - 2019-11-16 10:37:13 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:13 --> Template Class Initialized
INFO - 2019-11-16 10:37:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 10:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 10:37:13 --> Pagination Class Initialized
DEBUG - 2019-11-16 10:37:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 10:37:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 10:37:13 --> Encryption Class Initialized
INFO - 2019-11-16 10:37:13 --> Controller Class Initialized
DEBUG - 2019-11-16 10:37:13 --> services MX_Controller Initialized
DEBUG - 2019-11-16 10:37:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 10:37:13 --> Model Class Initialized
DEBUG - 2019-11-16 10:37:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/update.php
INFO - 2019-11-16 10:37:13 --> Final output sent to browser
DEBUG - 2019-11-16 10:37:13 --> Total execution time: 0.5213
INFO - 2019-11-16 16:39:43 --> Config Class Initialized
INFO - 2019-11-16 16:39:43 --> Hooks Class Initialized
DEBUG - 2019-11-16 16:39:43 --> UTF-8 Support Enabled
INFO - 2019-11-16 16:39:43 --> Utf8 Class Initialized
INFO - 2019-11-16 16:39:43 --> URI Class Initialized
INFO - 2019-11-16 16:39:43 --> Router Class Initialized
INFO - 2019-11-16 16:39:43 --> Output Class Initialized
INFO - 2019-11-16 16:39:43 --> Security Class Initialized
DEBUG - 2019-11-16 16:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 16:39:43 --> CSRF cookie sent
INFO - 2019-11-16 16:39:43 --> Input Class Initialized
INFO - 2019-11-16 16:39:43 --> Language Class Initialized
INFO - 2019-11-16 16:39:43 --> Language Class Initialized
INFO - 2019-11-16 16:39:43 --> Config Class Initialized
INFO - 2019-11-16 16:39:43 --> Loader Class Initialized
INFO - 2019-11-16 16:39:43 --> Helper loaded: url_helper
INFO - 2019-11-16 16:39:43 --> Helper loaded: common_helper
INFO - 2019-11-16 16:39:43 --> Helper loaded: language_helper
INFO - 2019-11-16 16:39:43 --> Helper loaded: cookie_helper
INFO - 2019-11-16 16:39:43 --> Helper loaded: email_helper
INFO - 2019-11-16 16:39:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 16:39:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 16:39:44 --> Parser Class Initialized
INFO - 2019-11-16 16:39:44 --> User Agent Class Initialized
INFO - 2019-11-16 16:39:44 --> Model Class Initialized
INFO - 2019-11-16 16:39:44 --> Database Driver Class Initialized
INFO - 2019-11-16 16:39:44 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:44 --> Template Class Initialized
INFO - 2019-11-16 16:39:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 16:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 16:39:44 --> Pagination Class Initialized
DEBUG - 2019-11-16 16:39:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 16:39:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 16:39:44 --> Encryption Class Initialized
INFO - 2019-11-16 16:39:44 --> Controller Class Initialized
DEBUG - 2019-11-16 16:39:44 --> auth MX_Controller Initialized
DEBUG - 2019-11-16 16:39:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-16 16:39:44 --> Model Class Initialized
INFO - 2019-11-16 16:39:44 --> Config Class Initialized
INFO - 2019-11-16 16:39:44 --> Hooks Class Initialized
DEBUG - 2019-11-16 16:39:44 --> UTF-8 Support Enabled
INFO - 2019-11-16 16:39:44 --> Utf8 Class Initialized
INFO - 2019-11-16 16:39:44 --> URI Class Initialized
INFO - 2019-11-16 16:39:44 --> Router Class Initialized
INFO - 2019-11-16 16:39:44 --> Output Class Initialized
INFO - 2019-11-16 16:39:44 --> Security Class Initialized
DEBUG - 2019-11-16 16:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 16:39:44 --> CSRF cookie sent
INFO - 2019-11-16 16:39:44 --> Input Class Initialized
INFO - 2019-11-16 16:39:44 --> Language Class Initialized
INFO - 2019-11-16 16:39:44 --> Language Class Initialized
INFO - 2019-11-16 16:39:44 --> Config Class Initialized
INFO - 2019-11-16 16:39:44 --> Loader Class Initialized
INFO - 2019-11-16 16:39:44 --> Helper loaded: url_helper
INFO - 2019-11-16 16:39:44 --> Helper loaded: common_helper
INFO - 2019-11-16 16:39:44 --> Helper loaded: language_helper
INFO - 2019-11-16 16:39:44 --> Helper loaded: cookie_helper
INFO - 2019-11-16 16:39:44 --> Helper loaded: email_helper
INFO - 2019-11-16 16:39:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 16:39:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 16:39:44 --> Parser Class Initialized
INFO - 2019-11-16 16:39:44 --> User Agent Class Initialized
INFO - 2019-11-16 16:39:44 --> Model Class Initialized
INFO - 2019-11-16 16:39:44 --> Database Driver Class Initialized
INFO - 2019-11-16 16:39:45 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:45 --> Template Class Initialized
INFO - 2019-11-16 16:39:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 16:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 16:39:45 --> Pagination Class Initialized
DEBUG - 2019-11-16 16:39:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 16:39:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 16:39:45 --> Encryption Class Initialized
INFO - 2019-11-16 16:39:45 --> Controller Class Initialized
DEBUG - 2019-11-16 16:39:45 --> statistics MX_Controller Initialized
DEBUG - 2019-11-16 16:39:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-16 16:39:45 --> Model Class Initialized
ERROR - 2019-11-16 16:39:45 --> Could not find the language line "Pending"
ERROR - 2019-11-16 16:39:45 --> Could not find the language line "Pending"
INFO - 2019-11-16 16:39:45 --> Helper loaded: inflector_helper
ERROR - 2019-11-16 16:39:45 --> Could not find the language line "total_orders"
ERROR - 2019-11-16 16:39:45 --> Could not find the language line "total_orders"
ERROR - 2019-11-16 16:39:45 --> Could not find the language line "Pending"
DEBUG - 2019-11-16 16:39:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-16 16:39:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 16:39:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 16:39:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 16:39:45 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 16:39:45 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 16:39:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 16:39:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 16:39:45 --> Final output sent to browser
DEBUG - 2019-11-16 16:39:45 --> Total execution time: 1.0669
INFO - 2019-11-16 16:39:48 --> Config Class Initialized
INFO - 2019-11-16 16:39:48 --> Hooks Class Initialized
DEBUG - 2019-11-16 16:39:48 --> UTF-8 Support Enabled
INFO - 2019-11-16 16:39:48 --> Utf8 Class Initialized
INFO - 2019-11-16 16:39:48 --> URI Class Initialized
INFO - 2019-11-16 16:39:48 --> Router Class Initialized
INFO - 2019-11-16 16:39:48 --> Output Class Initialized
INFO - 2019-11-16 16:39:48 --> Security Class Initialized
DEBUG - 2019-11-16 16:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 16:39:48 --> CSRF cookie sent
INFO - 2019-11-16 16:39:48 --> Input Class Initialized
INFO - 2019-11-16 16:39:48 --> Language Class Initialized
INFO - 2019-11-16 16:39:48 --> Language Class Initialized
INFO - 2019-11-16 16:39:48 --> Config Class Initialized
INFO - 2019-11-16 16:39:48 --> Loader Class Initialized
INFO - 2019-11-16 16:39:48 --> Helper loaded: url_helper
INFO - 2019-11-16 16:39:48 --> Helper loaded: common_helper
INFO - 2019-11-16 16:39:48 --> Helper loaded: language_helper
INFO - 2019-11-16 16:39:48 --> Helper loaded: cookie_helper
INFO - 2019-11-16 16:39:48 --> Helper loaded: email_helper
INFO - 2019-11-16 16:39:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 16:39:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 16:39:48 --> Parser Class Initialized
INFO - 2019-11-16 16:39:48 --> User Agent Class Initialized
INFO - 2019-11-16 16:39:48 --> Model Class Initialized
INFO - 2019-11-16 16:39:48 --> Database Driver Class Initialized
INFO - 2019-11-16 16:39:48 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:48 --> Template Class Initialized
INFO - 2019-11-16 16:39:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 16:39:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 16:39:48 --> Pagination Class Initialized
DEBUG - 2019-11-16 16:39:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 16:39:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 16:39:48 --> Encryption Class Initialized
INFO - 2019-11-16 16:39:48 --> Controller Class Initialized
DEBUG - 2019-11-16 16:39:48 --> setting MX_Controller Initialized
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-16 16:39:48 --> Model Class Initialized
INFO - 2019-11-16 16:39:48 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 16:39:48 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 16:39:48 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 16:39:48 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 16:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 16:39:48 --> Final output sent to browser
DEBUG - 2019-11-16 16:39:48 --> Total execution time: 0.7189
INFO - 2019-11-16 16:39:51 --> Config Class Initialized
INFO - 2019-11-16 16:39:51 --> Hooks Class Initialized
DEBUG - 2019-11-16 16:39:51 --> UTF-8 Support Enabled
INFO - 2019-11-16 16:39:51 --> Utf8 Class Initialized
INFO - 2019-11-16 16:39:51 --> URI Class Initialized
INFO - 2019-11-16 16:39:51 --> Router Class Initialized
INFO - 2019-11-16 16:39:51 --> Output Class Initialized
INFO - 2019-11-16 16:39:51 --> Security Class Initialized
DEBUG - 2019-11-16 16:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 16:39:51 --> CSRF cookie sent
INFO - 2019-11-16 16:39:51 --> Input Class Initialized
INFO - 2019-11-16 16:39:51 --> Language Class Initialized
INFO - 2019-11-16 16:39:51 --> Language Class Initialized
INFO - 2019-11-16 16:39:51 --> Config Class Initialized
INFO - 2019-11-16 16:39:51 --> Loader Class Initialized
INFO - 2019-11-16 16:39:51 --> Helper loaded: url_helper
INFO - 2019-11-16 16:39:51 --> Helper loaded: common_helper
INFO - 2019-11-16 16:39:51 --> Helper loaded: language_helper
INFO - 2019-11-16 16:39:51 --> Helper loaded: cookie_helper
INFO - 2019-11-16 16:39:51 --> Helper loaded: email_helper
INFO - 2019-11-16 16:39:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 16:39:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 16:39:51 --> Parser Class Initialized
INFO - 2019-11-16 16:39:51 --> User Agent Class Initialized
INFO - 2019-11-16 16:39:51 --> Model Class Initialized
INFO - 2019-11-16 16:39:51 --> Database Driver Class Initialized
INFO - 2019-11-16 16:39:51 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:51 --> Template Class Initialized
INFO - 2019-11-16 16:39:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 16:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 16:39:51 --> Pagination Class Initialized
DEBUG - 2019-11-16 16:39:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 16:39:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 16:39:51 --> Encryption Class Initialized
INFO - 2019-11-16 16:39:51 --> Controller Class Initialized
DEBUG - 2019-11-16 16:39:51 --> setting MX_Controller Initialized
DEBUG - 2019-11-16 16:39:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-16 16:39:51 --> Model Class Initialized
INFO - 2019-11-16 16:39:51 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 16:39:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-16 16:39:52 --> Could not find the language line "coinpayments_integration"
ERROR - 2019-11-16 16:39:52 --> Could not find the language line "coin_acceptance_settings"
ERROR - 2019-11-16 16:39:52 --> Could not find the language line "make_sure_the_list_of_coins_have_the_enabled_status_in"
DEBUG - 2019-11-16 16:39:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinpayments.php
DEBUG - 2019-11-16 16:39:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-16 16:39:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 16:39:52 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 16:39:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 16:39:52 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 16:39:52 --> Model Class Initialized
DEBUG - 2019-11-16 16:39:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 16:39:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 16:39:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 16:39:52 --> Final output sent to browser
DEBUG - 2019-11-16 16:39:52 --> Total execution time: 0.9390
INFO - 2019-11-16 22:52:09 --> Config Class Initialized
INFO - 2019-11-16 22:52:09 --> Hooks Class Initialized
DEBUG - 2019-11-16 22:52:09 --> UTF-8 Support Enabled
INFO - 2019-11-16 22:52:09 --> Utf8 Class Initialized
INFO - 2019-11-16 22:52:09 --> URI Class Initialized
DEBUG - 2019-11-16 22:52:09 --> No URI present. Default controller set.
INFO - 2019-11-16 22:52:09 --> Router Class Initialized
INFO - 2019-11-16 22:52:09 --> Output Class Initialized
INFO - 2019-11-16 22:52:09 --> Security Class Initialized
DEBUG - 2019-11-16 22:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 22:52:09 --> CSRF cookie sent
INFO - 2019-11-16 22:52:09 --> Input Class Initialized
INFO - 2019-11-16 22:52:09 --> Language Class Initialized
INFO - 2019-11-16 22:52:09 --> Language Class Initialized
INFO - 2019-11-16 22:52:09 --> Config Class Initialized
INFO - 2019-11-16 22:52:09 --> Loader Class Initialized
INFO - 2019-11-16 22:52:10 --> Helper loaded: url_helper
INFO - 2019-11-16 22:52:10 --> Helper loaded: common_helper
INFO - 2019-11-16 22:52:10 --> Helper loaded: language_helper
INFO - 2019-11-16 22:52:10 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:52:10 --> Helper loaded: email_helper
INFO - 2019-11-16 22:52:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:52:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:52:10 --> Parser Class Initialized
INFO - 2019-11-16 22:52:10 --> User Agent Class Initialized
INFO - 2019-11-16 22:52:10 --> Model Class Initialized
INFO - 2019-11-16 22:52:10 --> Database Driver Class Initialized
INFO - 2019-11-16 22:52:10 --> Model Class Initialized
DEBUG - 2019-11-16 22:52:10 --> Template Class Initialized
INFO - 2019-11-16 22:52:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:52:10 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:52:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:52:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:52:10 --> Encryption Class Initialized
DEBUG - 2019-11-16 22:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-16 22:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-16 22:52:10 --> Controller Class Initialized
DEBUG - 2019-11-16 22:52:10 --> pergo MX_Controller Initialized
DEBUG - 2019-11-16 22:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-16 22:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-16 22:52:10 --> Model Class Initialized
INFO - 2019-11-16 22:52:10 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 22:52:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-16 22:52:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-16 22:52:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-16 22:52:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-16 22:52:11 --> Final output sent to browser
DEBUG - 2019-11-16 22:52:11 --> Total execution time: 1.9051
INFO - 2019-11-16 22:53:26 --> Config Class Initialized
INFO - 2019-11-16 22:53:26 --> Hooks Class Initialized
DEBUG - 2019-11-16 22:53:26 --> UTF-8 Support Enabled
INFO - 2019-11-16 22:53:26 --> Utf8 Class Initialized
INFO - 2019-11-16 22:53:26 --> URI Class Initialized
INFO - 2019-11-16 22:53:26 --> Router Class Initialized
INFO - 2019-11-16 22:53:26 --> Output Class Initialized
INFO - 2019-11-16 22:53:26 --> Security Class Initialized
DEBUG - 2019-11-16 22:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 22:53:26 --> CSRF cookie sent
INFO - 2019-11-16 22:53:26 --> Input Class Initialized
INFO - 2019-11-16 22:53:26 --> Language Class Initialized
INFO - 2019-11-16 22:53:26 --> Language Class Initialized
INFO - 2019-11-16 22:53:26 --> Config Class Initialized
INFO - 2019-11-16 22:53:26 --> Loader Class Initialized
INFO - 2019-11-16 22:53:26 --> Helper loaded: url_helper
INFO - 2019-11-16 22:53:26 --> Helper loaded: common_helper
INFO - 2019-11-16 22:53:26 --> Helper loaded: language_helper
INFO - 2019-11-16 22:53:26 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:53:26 --> Helper loaded: email_helper
INFO - 2019-11-16 22:53:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:53:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:53:26 --> Parser Class Initialized
INFO - 2019-11-16 22:53:26 --> User Agent Class Initialized
INFO - 2019-11-16 22:53:26 --> Model Class Initialized
INFO - 2019-11-16 22:53:26 --> Database Driver Class Initialized
INFO - 2019-11-16 22:53:26 --> Model Class Initialized
DEBUG - 2019-11-16 22:53:26 --> Template Class Initialized
INFO - 2019-11-16 22:53:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:53:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:53:26 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:53:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:53:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:53:26 --> Encryption Class Initialized
INFO - 2019-11-16 22:53:26 --> Controller Class Initialized
DEBUG - 2019-11-16 22:53:26 --> auth MX_Controller Initialized
DEBUG - 2019-11-16 22:53:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-16 22:53:26 --> Model Class Initialized
DEBUG - 2019-11-16 22:53:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-16 22:53:26 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 22:53:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-16 22:53:26 --> pergo MX_Controller Initialized
DEBUG - 2019-11-16 22:53:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-16 22:53:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-16 22:53:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-16 22:53:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-16 22:53:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-16 22:53:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-16 22:53:26 --> Final output sent to browser
DEBUG - 2019-11-16 22:53:27 --> Total execution time: 0.7205
INFO - 2019-11-16 22:54:39 --> Config Class Initialized
INFO - 2019-11-16 22:54:39 --> Hooks Class Initialized
DEBUG - 2019-11-16 22:54:39 --> UTF-8 Support Enabled
INFO - 2019-11-16 22:54:39 --> Utf8 Class Initialized
INFO - 2019-11-16 22:54:39 --> URI Class Initialized
INFO - 2019-11-16 22:54:39 --> Router Class Initialized
INFO - 2019-11-16 22:54:39 --> Output Class Initialized
INFO - 2019-11-16 22:54:39 --> Security Class Initialized
DEBUG - 2019-11-16 22:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 22:54:39 --> CSRF cookie sent
INFO - 2019-11-16 22:54:39 --> CSRF token verified
INFO - 2019-11-16 22:54:39 --> Input Class Initialized
INFO - 2019-11-16 22:54:40 --> Language Class Initialized
INFO - 2019-11-16 22:54:40 --> Language Class Initialized
INFO - 2019-11-16 22:54:40 --> Config Class Initialized
INFO - 2019-11-16 22:54:40 --> Loader Class Initialized
INFO - 2019-11-16 22:54:40 --> Helper loaded: url_helper
INFO - 2019-11-16 22:54:40 --> Helper loaded: common_helper
INFO - 2019-11-16 22:54:40 --> Helper loaded: language_helper
INFO - 2019-11-16 22:54:40 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:54:40 --> Helper loaded: email_helper
INFO - 2019-11-16 22:54:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:54:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:54:40 --> Parser Class Initialized
INFO - 2019-11-16 22:54:40 --> User Agent Class Initialized
INFO - 2019-11-16 22:54:40 --> Model Class Initialized
INFO - 2019-11-16 22:54:40 --> Database Driver Class Initialized
INFO - 2019-11-16 22:54:40 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:40 --> Template Class Initialized
INFO - 2019-11-16 22:54:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:54:40 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:54:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:54:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:54:40 --> Encryption Class Initialized
INFO - 2019-11-16 22:54:40 --> Controller Class Initialized
DEBUG - 2019-11-16 22:54:40 --> auth MX_Controller Initialized
DEBUG - 2019-11-16 22:54:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-16 22:54:40 --> Model Class Initialized
INFO - 2019-11-16 22:54:44 --> Config Class Initialized
INFO - 2019-11-16 22:54:44 --> Hooks Class Initialized
DEBUG - 2019-11-16 22:54:44 --> UTF-8 Support Enabled
INFO - 2019-11-16 22:54:44 --> Utf8 Class Initialized
INFO - 2019-11-16 22:54:45 --> URI Class Initialized
INFO - 2019-11-16 22:54:45 --> Router Class Initialized
INFO - 2019-11-16 22:54:45 --> Output Class Initialized
INFO - 2019-11-16 22:54:45 --> Security Class Initialized
DEBUG - 2019-11-16 22:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 22:54:45 --> CSRF cookie sent
INFO - 2019-11-16 22:54:45 --> Input Class Initialized
INFO - 2019-11-16 22:54:45 --> Language Class Initialized
INFO - 2019-11-16 22:54:45 --> Language Class Initialized
INFO - 2019-11-16 22:54:45 --> Config Class Initialized
INFO - 2019-11-16 22:54:45 --> Loader Class Initialized
INFO - 2019-11-16 22:54:45 --> Helper loaded: url_helper
INFO - 2019-11-16 22:54:45 --> Helper loaded: common_helper
INFO - 2019-11-16 22:54:45 --> Helper loaded: language_helper
INFO - 2019-11-16 22:54:45 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:54:45 --> Helper loaded: email_helper
INFO - 2019-11-16 22:54:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:54:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:54:45 --> Parser Class Initialized
INFO - 2019-11-16 22:54:45 --> User Agent Class Initialized
INFO - 2019-11-16 22:54:45 --> Model Class Initialized
INFO - 2019-11-16 22:54:45 --> Database Driver Class Initialized
INFO - 2019-11-16 22:54:45 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:45 --> Template Class Initialized
INFO - 2019-11-16 22:54:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:54:45 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:54:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:54:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:54:45 --> Encryption Class Initialized
INFO - 2019-11-16 22:54:45 --> Controller Class Initialized
DEBUG - 2019-11-16 22:54:45 --> statistics MX_Controller Initialized
DEBUG - 2019-11-16 22:54:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-16 22:54:45 --> Model Class Initialized
ERROR - 2019-11-16 22:54:45 --> Could not find the language line "Pending"
ERROR - 2019-11-16 22:54:45 --> Could not find the language line "Pending"
INFO - 2019-11-16 22:54:45 --> Helper loaded: inflector_helper
ERROR - 2019-11-16 22:54:45 --> Could not find the language line "total_orders"
ERROR - 2019-11-16 22:54:45 --> Could not find the language line "total_orders"
ERROR - 2019-11-16 22:54:45 --> Could not find the language line "Pending"
DEBUG - 2019-11-16 22:54:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-16 22:54:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 22:54:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 22:54:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 22:54:45 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 22:54:45 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 22:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 22:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 22:54:46 --> Final output sent to browser
DEBUG - 2019-11-16 22:54:46 --> Total execution time: 1.1543
INFO - 2019-11-16 22:54:49 --> Config Class Initialized
INFO - 2019-11-16 22:54:49 --> Hooks Class Initialized
DEBUG - 2019-11-16 22:54:49 --> UTF-8 Support Enabled
INFO - 2019-11-16 22:54:49 --> Utf8 Class Initialized
INFO - 2019-11-16 22:54:49 --> URI Class Initialized
INFO - 2019-11-16 22:54:49 --> Router Class Initialized
INFO - 2019-11-16 22:54:49 --> Output Class Initialized
INFO - 2019-11-16 22:54:49 --> Security Class Initialized
DEBUG - 2019-11-16 22:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 22:54:49 --> CSRF cookie sent
INFO - 2019-11-16 22:54:49 --> Input Class Initialized
INFO - 2019-11-16 22:54:49 --> Language Class Initialized
INFO - 2019-11-16 22:54:49 --> Language Class Initialized
INFO - 2019-11-16 22:54:49 --> Config Class Initialized
INFO - 2019-11-16 22:54:49 --> Loader Class Initialized
INFO - 2019-11-16 22:54:49 --> Helper loaded: url_helper
INFO - 2019-11-16 22:54:49 --> Helper loaded: common_helper
INFO - 2019-11-16 22:54:49 --> Helper loaded: language_helper
INFO - 2019-11-16 22:54:49 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:54:49 --> Helper loaded: email_helper
INFO - 2019-11-16 22:54:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:54:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:54:49 --> Parser Class Initialized
INFO - 2019-11-16 22:54:49 --> User Agent Class Initialized
INFO - 2019-11-16 22:54:49 --> Model Class Initialized
INFO - 2019-11-16 22:54:49 --> Database Driver Class Initialized
INFO - 2019-11-16 22:54:49 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:49 --> Template Class Initialized
INFO - 2019-11-16 22:54:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:54:49 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:54:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:54:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:54:49 --> Encryption Class Initialized
INFO - 2019-11-16 22:54:49 --> Controller Class Initialized
DEBUG - 2019-11-16 22:54:49 --> setting MX_Controller Initialized
DEBUG - 2019-11-16 22:54:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-16 22:54:49 --> Model Class Initialized
INFO - 2019-11-16 22:54:49 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 22:54:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-16 22:54:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-16 22:54:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-16 22:54:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 22:54:50 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 22:54:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 22:54:50 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 22:54:50 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 22:54:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 22:54:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 22:54:50 --> Final output sent to browser
DEBUG - 2019-11-16 22:54:50 --> Total execution time: 0.9398
INFO - 2019-11-16 22:54:53 --> Config Class Initialized
INFO - 2019-11-16 22:54:53 --> Hooks Class Initialized
DEBUG - 2019-11-16 22:54:53 --> UTF-8 Support Enabled
INFO - 2019-11-16 22:54:53 --> Utf8 Class Initialized
INFO - 2019-11-16 22:54:53 --> URI Class Initialized
INFO - 2019-11-16 22:54:53 --> Router Class Initialized
INFO - 2019-11-16 22:54:53 --> Output Class Initialized
INFO - 2019-11-16 22:54:53 --> Security Class Initialized
DEBUG - 2019-11-16 22:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 22:54:53 --> CSRF cookie sent
INFO - 2019-11-16 22:54:53 --> Input Class Initialized
INFO - 2019-11-16 22:54:53 --> Language Class Initialized
INFO - 2019-11-16 22:54:53 --> Language Class Initialized
INFO - 2019-11-16 22:54:53 --> Config Class Initialized
INFO - 2019-11-16 22:54:53 --> Loader Class Initialized
INFO - 2019-11-16 22:54:53 --> Helper loaded: url_helper
INFO - 2019-11-16 22:54:53 --> Helper loaded: common_helper
INFO - 2019-11-16 22:54:53 --> Helper loaded: language_helper
INFO - 2019-11-16 22:54:53 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:54:53 --> Helper loaded: email_helper
INFO - 2019-11-16 22:54:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:54:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:54:53 --> Parser Class Initialized
INFO - 2019-11-16 22:54:53 --> User Agent Class Initialized
INFO - 2019-11-16 22:54:53 --> Model Class Initialized
INFO - 2019-11-16 22:54:53 --> Database Driver Class Initialized
INFO - 2019-11-16 22:54:53 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:53 --> Template Class Initialized
INFO - 2019-11-16 22:54:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:54:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:54:53 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:54:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:54:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:54:53 --> Encryption Class Initialized
INFO - 2019-11-16 22:54:53 --> Controller Class Initialized
DEBUG - 2019-11-16 22:54:53 --> setting MX_Controller Initialized
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-16 22:54:53 --> Model Class Initialized
INFO - 2019-11-16 22:54:53 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-16 22:54:53 --> Could not find the language line "currency_rate"
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paystack.php
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 22:54:53 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 22:54:53 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 22:54:53 --> Model Class Initialized
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 22:54:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 22:54:54 --> Final output sent to browser
DEBUG - 2019-11-16 22:54:54 --> Total execution time: 0.8273
INFO - 2019-11-16 22:59:36 --> Config Class Initialized
INFO - 2019-11-16 22:59:36 --> Hooks Class Initialized
DEBUG - 2019-11-16 22:59:36 --> UTF-8 Support Enabled
INFO - 2019-11-16 22:59:36 --> Utf8 Class Initialized
INFO - 2019-11-16 22:59:36 --> URI Class Initialized
INFO - 2019-11-16 22:59:36 --> Router Class Initialized
INFO - 2019-11-16 22:59:36 --> Output Class Initialized
INFO - 2019-11-16 22:59:36 --> Security Class Initialized
DEBUG - 2019-11-16 22:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 22:59:36 --> CSRF cookie sent
INFO - 2019-11-16 22:59:36 --> CSRF token verified
INFO - 2019-11-16 22:59:36 --> Input Class Initialized
INFO - 2019-11-16 22:59:36 --> Language Class Initialized
INFO - 2019-11-16 22:59:36 --> Language Class Initialized
INFO - 2019-11-16 22:59:36 --> Config Class Initialized
INFO - 2019-11-16 22:59:36 --> Loader Class Initialized
INFO - 2019-11-16 22:59:36 --> Helper loaded: url_helper
INFO - 2019-11-16 22:59:36 --> Helper loaded: common_helper
INFO - 2019-11-16 22:59:36 --> Helper loaded: language_helper
INFO - 2019-11-16 22:59:36 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:59:36 --> Helper loaded: email_helper
INFO - 2019-11-16 22:59:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:59:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:59:36 --> Parser Class Initialized
INFO - 2019-11-16 22:59:36 --> User Agent Class Initialized
INFO - 2019-11-16 22:59:36 --> Model Class Initialized
INFO - 2019-11-16 22:59:36 --> Database Driver Class Initialized
INFO - 2019-11-16 22:59:36 --> Model Class Initialized
DEBUG - 2019-11-16 22:59:36 --> Template Class Initialized
INFO - 2019-11-16 22:59:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:59:36 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:59:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:59:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:59:36 --> Encryption Class Initialized
INFO - 2019-11-16 22:59:36 --> Controller Class Initialized
DEBUG - 2019-11-16 22:59:36 --> setting MX_Controller Initialized
DEBUG - 2019-11-16 22:59:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-16 22:59:36 --> Model Class Initialized
INFO - 2019-11-16 22:59:42 --> Config Class Initialized
INFO - 2019-11-16 22:59:42 --> Config Class Initialized
INFO - 2019-11-16 22:59:42 --> Hooks Class Initialized
INFO - 2019-11-16 22:59:42 --> Hooks Class Initialized
DEBUG - 2019-11-16 22:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-16 22:59:42 --> UTF-8 Support Enabled
INFO - 2019-11-16 22:59:42 --> Utf8 Class Initialized
INFO - 2019-11-16 22:59:42 --> Utf8 Class Initialized
INFO - 2019-11-16 22:59:42 --> URI Class Initialized
INFO - 2019-11-16 22:59:42 --> URI Class Initialized
INFO - 2019-11-16 22:59:42 --> Router Class Initialized
INFO - 2019-11-16 22:59:42 --> Router Class Initialized
INFO - 2019-11-16 22:59:42 --> Output Class Initialized
INFO - 2019-11-16 22:59:42 --> Output Class Initialized
INFO - 2019-11-16 22:59:42 --> Security Class Initialized
INFO - 2019-11-16 22:59:42 --> Security Class Initialized
DEBUG - 2019-11-16 22:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-16 22:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 22:59:42 --> CSRF cookie sent
INFO - 2019-11-16 22:59:42 --> CSRF cookie sent
INFO - 2019-11-16 22:59:42 --> Input Class Initialized
INFO - 2019-11-16 22:59:42 --> Input Class Initialized
INFO - 2019-11-16 22:59:42 --> Language Class Initialized
INFO - 2019-11-16 22:59:42 --> Language Class Initialized
INFO - 2019-11-16 22:59:42 --> Language Class Initialized
INFO - 2019-11-16 22:59:42 --> Language Class Initialized
INFO - 2019-11-16 22:59:42 --> Config Class Initialized
INFO - 2019-11-16 22:59:42 --> Config Class Initialized
INFO - 2019-11-16 22:59:42 --> Loader Class Initialized
INFO - 2019-11-16 22:59:42 --> Loader Class Initialized
INFO - 2019-11-16 22:59:42 --> Helper loaded: url_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: url_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: common_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: common_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: language_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: language_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: email_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: email_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:59:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:59:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:59:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:59:42 --> Parser Class Initialized
INFO - 2019-11-16 22:59:42 --> Parser Class Initialized
INFO - 2019-11-16 22:59:42 --> User Agent Class Initialized
INFO - 2019-11-16 22:59:42 --> User Agent Class Initialized
INFO - 2019-11-16 22:59:42 --> Model Class Initialized
INFO - 2019-11-16 22:59:42 --> Model Class Initialized
INFO - 2019-11-16 22:59:42 --> Database Driver Class Initialized
INFO - 2019-11-16 22:59:42 --> Database Driver Class Initialized
INFO - 2019-11-16 22:59:42 --> Model Class Initialized
INFO - 2019-11-16 22:59:42 --> Model Class Initialized
DEBUG - 2019-11-16 22:59:42 --> Template Class Initialized
DEBUG - 2019-11-16 22:59:42 --> Template Class Initialized
INFO - 2019-11-16 22:59:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:59:42 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:59:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:59:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:59:42 --> Encryption Class Initialized
INFO - 2019-11-16 22:59:42 --> Controller Class Initialized
DEBUG - 2019-11-16 22:59:42 --> package MX_Controller Initialized
DEBUG - 2019-11-16 22:59:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-16 22:59:42 --> Model Class Initialized
INFO - 2019-11-16 22:59:42 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 22:59:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 22:59:42 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 22:59:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 22:59:42 --> Model Class Initialized
DEBUG - 2019-11-16 22:59:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 22:59:42 --> Model Class Initialized
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-16 22:59:43 --> Final output sent to browser
DEBUG - 2019-11-16 22:59:43 --> Total execution time: 1.4922
INFO - 2019-11-16 22:59:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:59:43 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:59:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:59:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:59:43 --> Encryption Class Initialized
INFO - 2019-11-16 22:59:43 --> Controller Class Initialized
DEBUG - 2019-11-16 22:59:43 --> setting MX_Controller Initialized
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-16 22:59:43 --> Model Class Initialized
INFO - 2019-11-16 22:59:43 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 22:59:43 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 22:59:43 --> Model Class Initialized
DEBUG - 2019-11-16 22:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 22:59:43 --> Model Class Initialized
DEBUG - 2019-11-16 22:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 22:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 22:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 22:59:44 --> Final output sent to browser
DEBUG - 2019-11-16 22:59:44 --> Total execution time: 2.0852
INFO - 2019-11-16 22:59:48 --> Config Class Initialized
INFO - 2019-11-16 22:59:48 --> Hooks Class Initialized
DEBUG - 2019-11-16 22:59:48 --> UTF-8 Support Enabled
INFO - 2019-11-16 22:59:48 --> Utf8 Class Initialized
INFO - 2019-11-16 22:59:48 --> URI Class Initialized
INFO - 2019-11-16 22:59:48 --> Router Class Initialized
INFO - 2019-11-16 22:59:48 --> Output Class Initialized
INFO - 2019-11-16 22:59:48 --> Security Class Initialized
DEBUG - 2019-11-16 22:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 22:59:48 --> CSRF cookie sent
INFO - 2019-11-16 22:59:48 --> CSRF token verified
INFO - 2019-11-16 22:59:48 --> Input Class Initialized
INFO - 2019-11-16 22:59:48 --> Language Class Initialized
INFO - 2019-11-16 22:59:48 --> Language Class Initialized
INFO - 2019-11-16 22:59:48 --> Config Class Initialized
INFO - 2019-11-16 22:59:49 --> Loader Class Initialized
INFO - 2019-11-16 22:59:49 --> Helper loaded: url_helper
INFO - 2019-11-16 22:59:49 --> Helper loaded: common_helper
INFO - 2019-11-16 22:59:49 --> Helper loaded: language_helper
INFO - 2019-11-16 22:59:49 --> Helper loaded: cookie_helper
INFO - 2019-11-16 22:59:49 --> Helper loaded: email_helper
INFO - 2019-11-16 22:59:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 22:59:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 22:59:49 --> Parser Class Initialized
INFO - 2019-11-16 22:59:49 --> User Agent Class Initialized
INFO - 2019-11-16 22:59:49 --> Model Class Initialized
INFO - 2019-11-16 22:59:49 --> Database Driver Class Initialized
INFO - 2019-11-16 22:59:49 --> Model Class Initialized
DEBUG - 2019-11-16 22:59:49 --> Template Class Initialized
INFO - 2019-11-16 22:59:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 22:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 22:59:49 --> Pagination Class Initialized
DEBUG - 2019-11-16 22:59:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 22:59:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 22:59:49 --> Encryption Class Initialized
INFO - 2019-11-16 22:59:49 --> Controller Class Initialized
DEBUG - 2019-11-16 22:59:49 --> checkout MX_Controller Initialized
DEBUG - 2019-11-16 22:59:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-16 22:59:49 --> Model Class Initialized
INFO - 2019-11-16 22:59:49 --> Helper loaded: inflector_helper
ERROR - 2019-11-16 22:59:49 --> Could not find the language line "shopier"
DEBUG - 2019-11-16 22:59:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-16 22:59:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 22:59:49 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 22:59:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 22:59:49 --> Model Class Initialized
DEBUG - 2019-11-16 22:59:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 22:59:49 --> Model Class Initialized
DEBUG - 2019-11-16 22:59:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-16 22:59:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-16 22:59:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-16 22:59:49 --> Final output sent to browser
DEBUG - 2019-11-16 22:59:50 --> Total execution time: 1.2679
INFO - 2019-11-16 23:00:03 --> Config Class Initialized
INFO - 2019-11-16 23:00:03 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:00:03 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:00:03 --> Utf8 Class Initialized
INFO - 2019-11-16 23:00:03 --> URI Class Initialized
INFO - 2019-11-16 23:00:03 --> Router Class Initialized
INFO - 2019-11-16 23:00:03 --> Output Class Initialized
INFO - 2019-11-16 23:00:03 --> Security Class Initialized
DEBUG - 2019-11-16 23:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:00:03 --> CSRF cookie sent
INFO - 2019-11-16 23:00:03 --> CSRF token verified
INFO - 2019-11-16 23:00:03 --> Input Class Initialized
INFO - 2019-11-16 23:00:03 --> Language Class Initialized
INFO - 2019-11-16 23:00:03 --> Language Class Initialized
INFO - 2019-11-16 23:00:03 --> Config Class Initialized
INFO - 2019-11-16 23:00:03 --> Loader Class Initialized
INFO - 2019-11-16 23:00:03 --> Helper loaded: url_helper
INFO - 2019-11-16 23:00:03 --> Helper loaded: common_helper
INFO - 2019-11-16 23:00:03 --> Helper loaded: language_helper
INFO - 2019-11-16 23:00:03 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:00:03 --> Helper loaded: email_helper
INFO - 2019-11-16 23:00:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:00:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:00:03 --> Parser Class Initialized
INFO - 2019-11-16 23:00:03 --> User Agent Class Initialized
INFO - 2019-11-16 23:00:03 --> Model Class Initialized
INFO - 2019-11-16 23:00:03 --> Database Driver Class Initialized
INFO - 2019-11-16 23:00:03 --> Model Class Initialized
DEBUG - 2019-11-16 23:00:03 --> Template Class Initialized
INFO - 2019-11-16 23:00:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:00:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:00:03 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:00:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:00:03 --> Encryption Class Initialized
INFO - 2019-11-16 23:00:03 --> Controller Class Initialized
DEBUG - 2019-11-16 23:00:03 --> checkout MX_Controller Initialized
DEBUG - 2019-11-16 23:00:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-16 23:00:04 --> Model Class Initialized
INFO - 2019-11-16 23:00:04 --> Helper loaded: inflector_helper
ERROR - 2019-11-16 23:00:04 --> Could not find the language line "shopier"
DEBUG - 2019-11-16 23:00:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-16 23:00:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 23:00:04 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 23:00:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 23:00:04 --> Model Class Initialized
DEBUG - 2019-11-16 23:00:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 23:00:04 --> Model Class Initialized
DEBUG - 2019-11-16 23:00:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-16 23:00:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-16 23:00:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-16 23:00:04 --> Final output sent to browser
DEBUG - 2019-11-16 23:00:04 --> Total execution time: 0.8126
INFO - 2019-11-16 23:00:18 --> Config Class Initialized
INFO - 2019-11-16 23:00:18 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:00:18 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:00:18 --> Utf8 Class Initialized
INFO - 2019-11-16 23:00:18 --> URI Class Initialized
INFO - 2019-11-16 23:00:18 --> Router Class Initialized
INFO - 2019-11-16 23:00:18 --> Output Class Initialized
INFO - 2019-11-16 23:00:18 --> Security Class Initialized
DEBUG - 2019-11-16 23:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:00:18 --> CSRF cookie sent
INFO - 2019-11-16 23:00:18 --> CSRF token verified
INFO - 2019-11-16 23:00:18 --> Input Class Initialized
INFO - 2019-11-16 23:00:18 --> Language Class Initialized
INFO - 2019-11-16 23:00:18 --> Language Class Initialized
INFO - 2019-11-16 23:00:18 --> Config Class Initialized
INFO - 2019-11-16 23:00:18 --> Loader Class Initialized
INFO - 2019-11-16 23:00:18 --> Helper loaded: url_helper
INFO - 2019-11-16 23:00:18 --> Helper loaded: common_helper
INFO - 2019-11-16 23:00:18 --> Helper loaded: language_helper
INFO - 2019-11-16 23:00:18 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:00:18 --> Helper loaded: email_helper
INFO - 2019-11-16 23:00:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:00:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:00:18 --> Parser Class Initialized
INFO - 2019-11-16 23:00:18 --> User Agent Class Initialized
INFO - 2019-11-16 23:00:18 --> Model Class Initialized
INFO - 2019-11-16 23:00:18 --> Database Driver Class Initialized
INFO - 2019-11-16 23:00:18 --> Model Class Initialized
DEBUG - 2019-11-16 23:00:18 --> Template Class Initialized
INFO - 2019-11-16 23:00:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:00:19 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:00:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:00:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:00:19 --> Encryption Class Initialized
INFO - 2019-11-16 23:00:19 --> Controller Class Initialized
DEBUG - 2019-11-16 23:00:19 --> checkout MX_Controller Initialized
DEBUG - 2019-11-16 23:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-16 23:00:19 --> Model Class Initialized
DEBUG - 2019-11-16 23:00:19 --> paystack MX_Controller Initialized
DEBUG - 2019-11-16 23:00:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paystack/index.php
INFO - 2019-11-16 23:00:21 --> Final output sent to browser
DEBUG - 2019-11-16 23:00:21 --> Total execution time: 2.9262
INFO - 2019-11-16 23:01:09 --> Config Class Initialized
INFO - 2019-11-16 23:01:09 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:01:09 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:01:09 --> Utf8 Class Initialized
INFO - 2019-11-16 23:01:09 --> URI Class Initialized
INFO - 2019-11-16 23:01:09 --> Router Class Initialized
INFO - 2019-11-16 23:01:09 --> Output Class Initialized
INFO - 2019-11-16 23:01:09 --> Security Class Initialized
DEBUG - 2019-11-16 23:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:01:09 --> Input Class Initialized
INFO - 2019-11-16 23:01:09 --> Language Class Initialized
INFO - 2019-11-16 23:01:09 --> Language Class Initialized
INFO - 2019-11-16 23:01:09 --> Config Class Initialized
INFO - 2019-11-16 23:01:09 --> Loader Class Initialized
INFO - 2019-11-16 23:01:09 --> Helper loaded: url_helper
INFO - 2019-11-16 23:01:09 --> Helper loaded: common_helper
INFO - 2019-11-16 23:01:09 --> Helper loaded: language_helper
INFO - 2019-11-16 23:01:09 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:01:09 --> Helper loaded: email_helper
INFO - 2019-11-16 23:01:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:01:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:01:09 --> Parser Class Initialized
INFO - 2019-11-16 23:01:09 --> User Agent Class Initialized
INFO - 2019-11-16 23:01:09 --> Model Class Initialized
INFO - 2019-11-16 23:01:09 --> Database Driver Class Initialized
INFO - 2019-11-16 23:01:09 --> Model Class Initialized
DEBUG - 2019-11-16 23:01:09 --> Template Class Initialized
INFO - 2019-11-16 23:01:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:01:09 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:01:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:01:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:01:09 --> Encryption Class Initialized
INFO - 2019-11-16 23:01:09 --> Controller Class Initialized
DEBUG - 2019-11-16 23:01:09 --> paystack MX_Controller Initialized
INFO - 2019-11-16 23:01:09 --> Model Class Initialized
DEBUG - 2019-11-16 23:01:10 --> orders MX_Controller Initialized
INFO - 2019-11-16 23:01:10 --> Config Class Initialized
INFO - 2019-11-16 23:01:10 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:01:10 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:01:10 --> Utf8 Class Initialized
INFO - 2019-11-16 23:01:10 --> URI Class Initialized
INFO - 2019-11-16 23:01:10 --> Router Class Initialized
INFO - 2019-11-16 23:01:10 --> Output Class Initialized
INFO - 2019-11-16 23:01:10 --> Security Class Initialized
DEBUG - 2019-11-16 23:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:01:10 --> CSRF cookie sent
INFO - 2019-11-16 23:01:10 --> Input Class Initialized
INFO - 2019-11-16 23:01:10 --> Language Class Initialized
INFO - 2019-11-16 23:01:10 --> Language Class Initialized
INFO - 2019-11-16 23:01:10 --> Config Class Initialized
INFO - 2019-11-16 23:01:10 --> Loader Class Initialized
INFO - 2019-11-16 23:01:10 --> Helper loaded: url_helper
INFO - 2019-11-16 23:01:10 --> Helper loaded: common_helper
INFO - 2019-11-16 23:01:10 --> Helper loaded: language_helper
INFO - 2019-11-16 23:01:10 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:01:10 --> Helper loaded: email_helper
INFO - 2019-11-16 23:01:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:01:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:01:10 --> Parser Class Initialized
INFO - 2019-11-16 23:01:10 --> User Agent Class Initialized
INFO - 2019-11-16 23:01:10 --> Model Class Initialized
INFO - 2019-11-16 23:01:10 --> Database Driver Class Initialized
INFO - 2019-11-16 23:01:10 --> Model Class Initialized
DEBUG - 2019-11-16 23:01:10 --> Template Class Initialized
INFO - 2019-11-16 23:01:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:01:10 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:01:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:01:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:01:10 --> Encryption Class Initialized
INFO - 2019-11-16 23:01:10 --> Controller Class Initialized
DEBUG - 2019-11-16 23:01:10 --> checkout MX_Controller Initialized
DEBUG - 2019-11-16 23:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-16 23:01:10 --> Model Class Initialized
INFO - 2019-11-16 23:01:10 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 23:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-16 23:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 23:01:10 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 23:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 23:01:10 --> Model Class Initialized
DEBUG - 2019-11-16 23:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 23:01:10 --> Model Class Initialized
DEBUG - 2019-11-16 23:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-16 23:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-16 23:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-16 23:01:10 --> Final output sent to browser
DEBUG - 2019-11-16 23:01:10 --> Total execution time: 0.7709
INFO - 2019-11-16 23:01:23 --> Config Class Initialized
INFO - 2019-11-16 23:01:23 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:01:23 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:01:23 --> Utf8 Class Initialized
INFO - 2019-11-16 23:01:23 --> URI Class Initialized
INFO - 2019-11-16 23:01:23 --> Router Class Initialized
INFO - 2019-11-16 23:01:23 --> Output Class Initialized
INFO - 2019-11-16 23:01:23 --> Security Class Initialized
DEBUG - 2019-11-16 23:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:01:23 --> CSRF cookie sent
INFO - 2019-11-16 23:01:23 --> Input Class Initialized
INFO - 2019-11-16 23:01:23 --> Language Class Initialized
INFO - 2019-11-16 23:01:23 --> Language Class Initialized
INFO - 2019-11-16 23:01:23 --> Config Class Initialized
INFO - 2019-11-16 23:01:23 --> Loader Class Initialized
INFO - 2019-11-16 23:01:23 --> Helper loaded: url_helper
INFO - 2019-11-16 23:01:23 --> Helper loaded: common_helper
INFO - 2019-11-16 23:01:23 --> Helper loaded: language_helper
INFO - 2019-11-16 23:01:23 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:01:23 --> Helper loaded: email_helper
INFO - 2019-11-16 23:01:23 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:01:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:01:23 --> Parser Class Initialized
INFO - 2019-11-16 23:01:23 --> User Agent Class Initialized
INFO - 2019-11-16 23:01:23 --> Model Class Initialized
INFO - 2019-11-16 23:01:23 --> Database Driver Class Initialized
INFO - 2019-11-16 23:01:23 --> Model Class Initialized
DEBUG - 2019-11-16 23:01:23 --> Template Class Initialized
INFO - 2019-11-16 23:01:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:01:23 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:01:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:01:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:01:23 --> Encryption Class Initialized
INFO - 2019-11-16 23:01:23 --> Controller Class Initialized
DEBUG - 2019-11-16 23:01:23 --> transactions MX_Controller Initialized
DEBUG - 2019-11-16 23:01:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-16 23:01:23 --> Model Class Initialized
ERROR - 2019-11-16 23:01:23 --> Could not find the language line "order_id"
INFO - 2019-11-16 23:01:23 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 23:01:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-16 23:01:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 23:01:23 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 23:01:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 23:01:23 --> Model Class Initialized
DEBUG - 2019-11-16 23:01:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 23:01:23 --> Model Class Initialized
DEBUG - 2019-11-16 23:01:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 23:01:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 23:01:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 23:01:23 --> Final output sent to browser
DEBUG - 2019-11-16 23:01:23 --> Total execution time: 0.8686
INFO - 2019-11-16 23:03:05 --> Config Class Initialized
INFO - 2019-11-16 23:03:05 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:03:05 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:03:05 --> Utf8 Class Initialized
INFO - 2019-11-16 23:03:05 --> URI Class Initialized
INFO - 2019-11-16 23:03:05 --> Router Class Initialized
INFO - 2019-11-16 23:03:05 --> Output Class Initialized
INFO - 2019-11-16 23:03:05 --> Security Class Initialized
DEBUG - 2019-11-16 23:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:03:05 --> CSRF cookie sent
INFO - 2019-11-16 23:03:05 --> Input Class Initialized
INFO - 2019-11-16 23:03:05 --> Language Class Initialized
INFO - 2019-11-16 23:03:05 --> Language Class Initialized
INFO - 2019-11-16 23:03:05 --> Config Class Initialized
INFO - 2019-11-16 23:03:05 --> Loader Class Initialized
INFO - 2019-11-16 23:03:05 --> Helper loaded: url_helper
INFO - 2019-11-16 23:03:05 --> Helper loaded: common_helper
INFO - 2019-11-16 23:03:05 --> Helper loaded: language_helper
INFO - 2019-11-16 23:03:05 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:03:05 --> Helper loaded: email_helper
INFO - 2019-11-16 23:03:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:03:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:03:05 --> Parser Class Initialized
INFO - 2019-11-16 23:03:05 --> User Agent Class Initialized
INFO - 2019-11-16 23:03:05 --> Model Class Initialized
INFO - 2019-11-16 23:03:05 --> Database Driver Class Initialized
INFO - 2019-11-16 23:03:05 --> Model Class Initialized
DEBUG - 2019-11-16 23:03:05 --> Template Class Initialized
INFO - 2019-11-16 23:03:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:03:05 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:03:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:03:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:03:05 --> Encryption Class Initialized
INFO - 2019-11-16 23:03:05 --> Controller Class Initialized
DEBUG - 2019-11-16 23:03:05 --> transactions MX_Controller Initialized
DEBUG - 2019-11-16 23:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-16 23:03:05 --> Model Class Initialized
ERROR - 2019-11-16 23:03:05 --> Could not find the language line "order_id"
INFO - 2019-11-16 23:03:05 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 23:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-16 23:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 23:03:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 23:03:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 23:03:06 --> Model Class Initialized
DEBUG - 2019-11-16 23:03:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 23:03:06 --> Model Class Initialized
DEBUG - 2019-11-16 23:03:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 23:03:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 23:03:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 23:03:06 --> Final output sent to browser
DEBUG - 2019-11-16 23:03:06 --> Total execution time: 0.8786
INFO - 2019-11-16 23:04:13 --> Config Class Initialized
INFO - 2019-11-16 23:04:14 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:04:14 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:04:14 --> Utf8 Class Initialized
INFO - 2019-11-16 23:04:14 --> URI Class Initialized
INFO - 2019-11-16 23:04:14 --> Router Class Initialized
INFO - 2019-11-16 23:04:14 --> Output Class Initialized
INFO - 2019-11-16 23:04:14 --> Security Class Initialized
DEBUG - 2019-11-16 23:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:04:14 --> CSRF cookie sent
INFO - 2019-11-16 23:04:14 --> Input Class Initialized
INFO - 2019-11-16 23:04:14 --> Language Class Initialized
INFO - 2019-11-16 23:04:14 --> Language Class Initialized
INFO - 2019-11-16 23:04:14 --> Config Class Initialized
INFO - 2019-11-16 23:04:14 --> Loader Class Initialized
INFO - 2019-11-16 23:04:14 --> Helper loaded: url_helper
INFO - 2019-11-16 23:04:14 --> Helper loaded: common_helper
INFO - 2019-11-16 23:04:14 --> Helper loaded: language_helper
INFO - 2019-11-16 23:04:14 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:04:14 --> Helper loaded: email_helper
INFO - 2019-11-16 23:04:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:04:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:04:14 --> Parser Class Initialized
INFO - 2019-11-16 23:04:14 --> User Agent Class Initialized
INFO - 2019-11-16 23:04:14 --> Model Class Initialized
INFO - 2019-11-16 23:04:14 --> Database Driver Class Initialized
INFO - 2019-11-16 23:04:14 --> Model Class Initialized
DEBUG - 2019-11-16 23:04:14 --> Template Class Initialized
INFO - 2019-11-16 23:04:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:04:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:04:14 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:04:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:04:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:04:14 --> Encryption Class Initialized
INFO - 2019-11-16 23:04:14 --> Controller Class Initialized
DEBUG - 2019-11-16 23:04:14 --> package MX_Controller Initialized
DEBUG - 2019-11-16 23:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-16 23:04:14 --> Model Class Initialized
INFO - 2019-11-16 23:04:14 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 23:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 23:04:14 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 23:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 23:04:14 --> Model Class Initialized
DEBUG - 2019-11-16 23:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 23:04:14 --> Model Class Initialized
DEBUG - 2019-11-16 23:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-16 23:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-16 23:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-16 23:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-16 23:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-16 23:04:14 --> Final output sent to browser
DEBUG - 2019-11-16 23:04:14 --> Total execution time: 0.8441
INFO - 2019-11-16 23:04:17 --> Config Class Initialized
INFO - 2019-11-16 23:04:17 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:04:17 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:04:17 --> Utf8 Class Initialized
INFO - 2019-11-16 23:04:17 --> URI Class Initialized
INFO - 2019-11-16 23:04:17 --> Router Class Initialized
INFO - 2019-11-16 23:04:17 --> Output Class Initialized
INFO - 2019-11-16 23:04:17 --> Security Class Initialized
DEBUG - 2019-11-16 23:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:04:17 --> CSRF cookie sent
INFO - 2019-11-16 23:04:17 --> CSRF token verified
INFO - 2019-11-16 23:04:17 --> Input Class Initialized
INFO - 2019-11-16 23:04:17 --> Language Class Initialized
INFO - 2019-11-16 23:04:17 --> Language Class Initialized
INFO - 2019-11-16 23:04:17 --> Config Class Initialized
INFO - 2019-11-16 23:04:17 --> Loader Class Initialized
INFO - 2019-11-16 23:04:17 --> Helper loaded: url_helper
INFO - 2019-11-16 23:04:17 --> Helper loaded: common_helper
INFO - 2019-11-16 23:04:17 --> Helper loaded: language_helper
INFO - 2019-11-16 23:04:17 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:04:17 --> Helper loaded: email_helper
INFO - 2019-11-16 23:04:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:04:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:04:17 --> Parser Class Initialized
INFO - 2019-11-16 23:04:17 --> User Agent Class Initialized
INFO - 2019-11-16 23:04:17 --> Model Class Initialized
INFO - 2019-11-16 23:04:18 --> Database Driver Class Initialized
INFO - 2019-11-16 23:04:18 --> Model Class Initialized
DEBUG - 2019-11-16 23:04:18 --> Template Class Initialized
INFO - 2019-11-16 23:04:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:04:18 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:04:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:04:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:04:18 --> Encryption Class Initialized
INFO - 2019-11-16 23:04:18 --> Controller Class Initialized
DEBUG - 2019-11-16 23:04:18 --> checkout MX_Controller Initialized
DEBUG - 2019-11-16 23:04:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-16 23:04:18 --> Model Class Initialized
INFO - 2019-11-16 23:04:18 --> Helper loaded: inflector_helper
ERROR - 2019-11-16 23:04:18 --> Could not find the language line "shopier"
DEBUG - 2019-11-16 23:04:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-16 23:04:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 23:04:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 23:04:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 23:04:18 --> Model Class Initialized
DEBUG - 2019-11-16 23:04:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 23:04:18 --> Model Class Initialized
DEBUG - 2019-11-16 23:04:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-16 23:04:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-16 23:04:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-16 23:04:18 --> Final output sent to browser
DEBUG - 2019-11-16 23:04:18 --> Total execution time: 0.9119
INFO - 2019-11-16 23:04:26 --> Config Class Initialized
INFO - 2019-11-16 23:04:26 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:04:26 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:04:26 --> Utf8 Class Initialized
INFO - 2019-11-16 23:04:26 --> URI Class Initialized
INFO - 2019-11-16 23:04:26 --> Router Class Initialized
INFO - 2019-11-16 23:04:26 --> Output Class Initialized
INFO - 2019-11-16 23:04:26 --> Security Class Initialized
DEBUG - 2019-11-16 23:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:04:26 --> CSRF cookie sent
INFO - 2019-11-16 23:04:26 --> CSRF token verified
INFO - 2019-11-16 23:04:26 --> Input Class Initialized
INFO - 2019-11-16 23:04:26 --> Language Class Initialized
INFO - 2019-11-16 23:04:26 --> Language Class Initialized
INFO - 2019-11-16 23:04:26 --> Config Class Initialized
INFO - 2019-11-16 23:04:26 --> Loader Class Initialized
INFO - 2019-11-16 23:04:26 --> Helper loaded: url_helper
INFO - 2019-11-16 23:04:26 --> Helper loaded: common_helper
INFO - 2019-11-16 23:04:26 --> Helper loaded: language_helper
INFO - 2019-11-16 23:04:26 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:04:26 --> Helper loaded: email_helper
INFO - 2019-11-16 23:04:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:04:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:04:26 --> Parser Class Initialized
INFO - 2019-11-16 23:04:26 --> User Agent Class Initialized
INFO - 2019-11-16 23:04:26 --> Model Class Initialized
INFO - 2019-11-16 23:04:26 --> Database Driver Class Initialized
INFO - 2019-11-16 23:04:26 --> Model Class Initialized
DEBUG - 2019-11-16 23:04:26 --> Template Class Initialized
INFO - 2019-11-16 23:04:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:04:26 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:04:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:04:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:04:26 --> Encryption Class Initialized
INFO - 2019-11-16 23:04:26 --> Controller Class Initialized
DEBUG - 2019-11-16 23:04:26 --> checkout MX_Controller Initialized
DEBUG - 2019-11-16 23:04:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-16 23:04:26 --> Model Class Initialized
DEBUG - 2019-11-16 23:04:26 --> paystack MX_Controller Initialized
DEBUG - 2019-11-16 23:04:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paystack/index.php
INFO - 2019-11-16 23:04:27 --> Final output sent to browser
DEBUG - 2019-11-16 23:04:27 --> Total execution time: 1.8246
INFO - 2019-11-16 23:04:46 --> Config Class Initialized
INFO - 2019-11-16 23:04:46 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:04:46 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:04:46 --> Utf8 Class Initialized
INFO - 2019-11-16 23:04:46 --> URI Class Initialized
INFO - 2019-11-16 23:04:46 --> Router Class Initialized
INFO - 2019-11-16 23:04:46 --> Output Class Initialized
INFO - 2019-11-16 23:04:46 --> Security Class Initialized
DEBUG - 2019-11-16 23:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:04:46 --> Input Class Initialized
INFO - 2019-11-16 23:04:46 --> Language Class Initialized
INFO - 2019-11-16 23:04:46 --> Language Class Initialized
INFO - 2019-11-16 23:04:46 --> Config Class Initialized
INFO - 2019-11-16 23:04:46 --> Loader Class Initialized
INFO - 2019-11-16 23:04:46 --> Helper loaded: url_helper
INFO - 2019-11-16 23:04:46 --> Helper loaded: common_helper
INFO - 2019-11-16 23:04:46 --> Helper loaded: language_helper
INFO - 2019-11-16 23:04:46 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:04:46 --> Helper loaded: email_helper
INFO - 2019-11-16 23:04:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:04:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:04:46 --> Parser Class Initialized
INFO - 2019-11-16 23:04:46 --> User Agent Class Initialized
INFO - 2019-11-16 23:04:46 --> Model Class Initialized
INFO - 2019-11-16 23:04:46 --> Database Driver Class Initialized
INFO - 2019-11-16 23:04:46 --> Model Class Initialized
DEBUG - 2019-11-16 23:04:46 --> Template Class Initialized
INFO - 2019-11-16 23:04:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:04:46 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:04:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:04:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:04:47 --> Encryption Class Initialized
INFO - 2019-11-16 23:04:47 --> Controller Class Initialized
DEBUG - 2019-11-16 23:04:47 --> paystack MX_Controller Initialized
INFO - 2019-11-16 23:04:47 --> Model Class Initialized
INFO - 2019-11-16 23:05:39 --> Config Class Initialized
INFO - 2019-11-16 23:05:39 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:05:39 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:05:39 --> Utf8 Class Initialized
INFO - 2019-11-16 23:05:39 --> URI Class Initialized
INFO - 2019-11-16 23:05:40 --> Router Class Initialized
INFO - 2019-11-16 23:05:40 --> Output Class Initialized
INFO - 2019-11-16 23:05:40 --> Security Class Initialized
DEBUG - 2019-11-16 23:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:05:40 --> Input Class Initialized
INFO - 2019-11-16 23:05:40 --> Language Class Initialized
INFO - 2019-11-16 23:05:40 --> Language Class Initialized
INFO - 2019-11-16 23:05:40 --> Config Class Initialized
INFO - 2019-11-16 23:05:40 --> Loader Class Initialized
INFO - 2019-11-16 23:05:40 --> Helper loaded: url_helper
INFO - 2019-11-16 23:05:40 --> Helper loaded: common_helper
INFO - 2019-11-16 23:05:40 --> Helper loaded: language_helper
INFO - 2019-11-16 23:05:40 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:05:40 --> Helper loaded: email_helper
INFO - 2019-11-16 23:05:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:05:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:05:40 --> Parser Class Initialized
INFO - 2019-11-16 23:05:40 --> User Agent Class Initialized
INFO - 2019-11-16 23:05:40 --> Model Class Initialized
INFO - 2019-11-16 23:05:40 --> Database Driver Class Initialized
INFO - 2019-11-16 23:05:40 --> Model Class Initialized
DEBUG - 2019-11-16 23:05:40 --> Template Class Initialized
INFO - 2019-11-16 23:05:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:05:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:05:40 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:05:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:05:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:05:40 --> Encryption Class Initialized
INFO - 2019-11-16 23:05:40 --> Controller Class Initialized
DEBUG - 2019-11-16 23:05:40 --> paystack MX_Controller Initialized
INFO - 2019-11-16 23:05:40 --> Model Class Initialized
DEBUG - 2019-11-16 23:05:41 --> orders MX_Controller Initialized
INFO - 2019-11-16 23:05:41 --> Config Class Initialized
INFO - 2019-11-16 23:05:41 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:05:41 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:05:41 --> Utf8 Class Initialized
INFO - 2019-11-16 23:05:41 --> URI Class Initialized
INFO - 2019-11-16 23:05:41 --> Router Class Initialized
INFO - 2019-11-16 23:05:41 --> Output Class Initialized
INFO - 2019-11-16 23:05:41 --> Security Class Initialized
DEBUG - 2019-11-16 23:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:05:41 --> CSRF cookie sent
INFO - 2019-11-16 23:05:41 --> Input Class Initialized
INFO - 2019-11-16 23:05:41 --> Language Class Initialized
INFO - 2019-11-16 23:05:41 --> Language Class Initialized
INFO - 2019-11-16 23:05:41 --> Config Class Initialized
INFO - 2019-11-16 23:05:41 --> Loader Class Initialized
INFO - 2019-11-16 23:05:41 --> Helper loaded: url_helper
INFO - 2019-11-16 23:05:41 --> Helper loaded: common_helper
INFO - 2019-11-16 23:05:41 --> Helper loaded: language_helper
INFO - 2019-11-16 23:05:41 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:05:41 --> Helper loaded: email_helper
INFO - 2019-11-16 23:05:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:05:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:05:42 --> Parser Class Initialized
INFO - 2019-11-16 23:05:42 --> User Agent Class Initialized
INFO - 2019-11-16 23:05:42 --> Model Class Initialized
INFO - 2019-11-16 23:05:42 --> Database Driver Class Initialized
INFO - 2019-11-16 23:05:42 --> Model Class Initialized
DEBUG - 2019-11-16 23:05:42 --> Template Class Initialized
INFO - 2019-11-16 23:05:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:05:42 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:05:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:05:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:05:42 --> Encryption Class Initialized
INFO - 2019-11-16 23:05:42 --> Controller Class Initialized
DEBUG - 2019-11-16 23:05:42 --> checkout MX_Controller Initialized
DEBUG - 2019-11-16 23:05:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-16 23:05:42 --> Model Class Initialized
INFO - 2019-11-16 23:05:42 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 23:05:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-16 23:05:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 23:05:42 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 23:05:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 23:05:42 --> Model Class Initialized
DEBUG - 2019-11-16 23:05:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 23:05:42 --> Model Class Initialized
DEBUG - 2019-11-16 23:05:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-16 23:05:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-16 23:05:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-16 23:05:42 --> Final output sent to browser
DEBUG - 2019-11-16 23:05:42 --> Total execution time: 0.8329
INFO - 2019-11-16 23:05:46 --> Config Class Initialized
INFO - 2019-11-16 23:05:46 --> Hooks Class Initialized
DEBUG - 2019-11-16 23:05:46 --> UTF-8 Support Enabled
INFO - 2019-11-16 23:05:46 --> Utf8 Class Initialized
INFO - 2019-11-16 23:05:46 --> URI Class Initialized
INFO - 2019-11-16 23:05:46 --> Router Class Initialized
INFO - 2019-11-16 23:05:46 --> Output Class Initialized
INFO - 2019-11-16 23:05:46 --> Security Class Initialized
DEBUG - 2019-11-16 23:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-16 23:05:46 --> CSRF cookie sent
INFO - 2019-11-16 23:05:46 --> Input Class Initialized
INFO - 2019-11-16 23:05:46 --> Language Class Initialized
INFO - 2019-11-16 23:05:46 --> Language Class Initialized
INFO - 2019-11-16 23:05:46 --> Config Class Initialized
INFO - 2019-11-16 23:05:46 --> Loader Class Initialized
INFO - 2019-11-16 23:05:46 --> Helper loaded: url_helper
INFO - 2019-11-16 23:05:46 --> Helper loaded: common_helper
INFO - 2019-11-16 23:05:46 --> Helper loaded: language_helper
INFO - 2019-11-16 23:05:46 --> Helper loaded: cookie_helper
INFO - 2019-11-16 23:05:46 --> Helper loaded: email_helper
INFO - 2019-11-16 23:05:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-16 23:05:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-16 23:05:46 --> Parser Class Initialized
INFO - 2019-11-16 23:05:46 --> User Agent Class Initialized
INFO - 2019-11-16 23:05:46 --> Model Class Initialized
INFO - 2019-11-16 23:05:46 --> Database Driver Class Initialized
INFO - 2019-11-16 23:05:46 --> Model Class Initialized
DEBUG - 2019-11-16 23:05:46 --> Template Class Initialized
INFO - 2019-11-16 23:05:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-16 23:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-16 23:05:46 --> Pagination Class Initialized
DEBUG - 2019-11-16 23:05:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-16 23:05:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-16 23:05:46 --> Encryption Class Initialized
INFO - 2019-11-16 23:05:46 --> Controller Class Initialized
DEBUG - 2019-11-16 23:05:46 --> transactions MX_Controller Initialized
DEBUG - 2019-11-16 23:05:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-16 23:05:46 --> Model Class Initialized
ERROR - 2019-11-16 23:05:46 --> Could not find the language line "order_id"
INFO - 2019-11-16 23:05:46 --> Helper loaded: inflector_helper
DEBUG - 2019-11-16 23:05:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-16 23:05:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-16 23:05:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-16 23:05:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-16 23:05:47 --> Model Class Initialized
DEBUG - 2019-11-16 23:05:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-16 23:05:47 --> Model Class Initialized
DEBUG - 2019-11-16 23:05:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-16 23:05:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-16 23:05:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-16 23:05:47 --> Final output sent to browser
DEBUG - 2019-11-16 23:05:47 --> Total execution time: 0.9885
