<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-07 15:48:50 --> Config Class Initialized
INFO - 2019-12-07 15:48:50 --> Hooks Class Initialized
DEBUG - 2019-12-07 15:48:50 --> UTF-8 Support Enabled
INFO - 2019-12-07 15:48:50 --> Utf8 Class Initialized
INFO - 2019-12-07 15:48:50 --> URI Class Initialized
DEBUG - 2019-12-07 15:48:50 --> No URI present. Default controller set.
INFO - 2019-12-07 15:48:50 --> Router Class Initialized
INFO - 2019-12-07 15:48:50 --> Output Class Initialized
INFO - 2019-12-07 15:48:50 --> Security Class Initialized
DEBUG - 2019-12-07 15:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 15:48:50 --> CSRF cookie sent
INFO - 2019-12-07 15:48:50 --> Input Class Initialized
INFO - 2019-12-07 15:48:50 --> Language Class Initialized
INFO - 2019-12-07 15:48:50 --> Language Class Initialized
INFO - 2019-12-07 15:48:50 --> Config Class Initialized
INFO - 2019-12-07 15:48:50 --> Loader Class Initialized
INFO - 2019-12-07 15:48:50 --> Helper loaded: url_helper
INFO - 2019-12-07 15:48:50 --> Helper loaded: common_helper
INFO - 2019-12-07 15:48:50 --> Helper loaded: language_helper
INFO - 2019-12-07 15:48:50 --> Helper loaded: cookie_helper
INFO - 2019-12-07 15:48:50 --> Helper loaded: email_helper
INFO - 2019-12-07 15:48:50 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 15:48:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 15:48:50 --> Parser Class Initialized
INFO - 2019-12-07 15:48:50 --> User Agent Class Initialized
INFO - 2019-12-07 15:48:50 --> Model Class Initialized
INFO - 2019-12-07 15:48:51 --> Database Driver Class Initialized
INFO - 2019-12-07 15:48:51 --> Model Class Initialized
DEBUG - 2019-12-07 15:48:51 --> Template Class Initialized
INFO - 2019-12-07 15:48:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 15:48:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 15:48:51 --> Pagination Class Initialized
DEBUG - 2019-12-07 15:48:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 15:48:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 15:48:51 --> Encryption Class Initialized
DEBUG - 2019-12-07 15:48:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-07 15:48:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-07 15:48:51 --> Controller Class Initialized
DEBUG - 2019-12-07 15:48:51 --> pergo MX_Controller Initialized
DEBUG - 2019-12-07 15:48:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-07 15:48:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-07 15:48:51 --> Model Class Initialized
INFO - 2019-12-07 15:48:51 --> Helper loaded: inflector_helper
DEBUG - 2019-12-07 15:48:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-07 15:48:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-07 15:48:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-07 15:48:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-07 15:48:51 --> Final output sent to browser
DEBUG - 2019-12-07 15:48:51 --> Total execution time: 1.8494
INFO - 2019-12-07 15:49:00 --> Config Class Initialized
INFO - 2019-12-07 15:49:00 --> Hooks Class Initialized
DEBUG - 2019-12-07 15:49:01 --> UTF-8 Support Enabled
INFO - 2019-12-07 15:49:01 --> Utf8 Class Initialized
INFO - 2019-12-07 15:49:01 --> URI Class Initialized
INFO - 2019-12-07 15:49:01 --> Router Class Initialized
INFO - 2019-12-07 15:49:01 --> Output Class Initialized
INFO - 2019-12-07 15:49:01 --> Security Class Initialized
DEBUG - 2019-12-07 15:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 15:49:01 --> CSRF cookie sent
INFO - 2019-12-07 15:49:01 --> Input Class Initialized
INFO - 2019-12-07 15:49:01 --> Language Class Initialized
INFO - 2019-12-07 15:49:01 --> Language Class Initialized
INFO - 2019-12-07 15:49:01 --> Config Class Initialized
INFO - 2019-12-07 15:49:01 --> Loader Class Initialized
INFO - 2019-12-07 15:49:01 --> Helper loaded: url_helper
INFO - 2019-12-07 15:49:01 --> Helper loaded: common_helper
INFO - 2019-12-07 15:49:01 --> Helper loaded: language_helper
INFO - 2019-12-07 15:49:01 --> Helper loaded: cookie_helper
INFO - 2019-12-07 15:49:01 --> Helper loaded: email_helper
INFO - 2019-12-07 15:49:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 15:49:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 15:49:01 --> Parser Class Initialized
INFO - 2019-12-07 15:49:01 --> User Agent Class Initialized
INFO - 2019-12-07 15:49:01 --> Model Class Initialized
INFO - 2019-12-07 15:49:01 --> Database Driver Class Initialized
INFO - 2019-12-07 15:49:01 --> Model Class Initialized
DEBUG - 2019-12-07 15:49:01 --> Template Class Initialized
INFO - 2019-12-07 15:49:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 15:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 15:49:01 --> Pagination Class Initialized
DEBUG - 2019-12-07 15:49:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 15:49:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 15:49:01 --> Encryption Class Initialized
INFO - 2019-12-07 15:49:01 --> Controller Class Initialized
DEBUG - 2019-12-07 15:49:01 --> auth MX_Controller Initialized
DEBUG - 2019-12-07 15:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-07 15:49:01 --> Model Class Initialized
DEBUG - 2019-12-07 15:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-07 15:49:01 --> Helper loaded: inflector_helper
DEBUG - 2019-12-07 15:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-12-07 15:49:01 --> pergo MX_Controller Initialized
DEBUG - 2019-12-07 15:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-07 15:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-12-07 15:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-07 15:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-07 15:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-12-07 15:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-07 15:49:01 --> Final output sent to browser
DEBUG - 2019-12-07 15:49:01 --> Total execution time: 0.9183
INFO - 2019-12-07 15:49:04 --> Config Class Initialized
INFO - 2019-12-07 15:49:04 --> Hooks Class Initialized
DEBUG - 2019-12-07 15:49:04 --> UTF-8 Support Enabled
INFO - 2019-12-07 15:49:04 --> Utf8 Class Initialized
INFO - 2019-12-07 15:49:04 --> URI Class Initialized
INFO - 2019-12-07 15:49:04 --> Router Class Initialized
INFO - 2019-12-07 15:49:04 --> Output Class Initialized
INFO - 2019-12-07 15:49:04 --> Security Class Initialized
DEBUG - 2019-12-07 15:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 15:49:04 --> CSRF cookie sent
INFO - 2019-12-07 15:49:04 --> CSRF token verified
INFO - 2019-12-07 15:49:04 --> Input Class Initialized
INFO - 2019-12-07 15:49:04 --> Language Class Initialized
INFO - 2019-12-07 15:49:04 --> Language Class Initialized
INFO - 2019-12-07 15:49:04 --> Config Class Initialized
INFO - 2019-12-07 15:49:04 --> Loader Class Initialized
INFO - 2019-12-07 15:49:04 --> Helper loaded: url_helper
INFO - 2019-12-07 15:49:04 --> Helper loaded: common_helper
INFO - 2019-12-07 15:49:04 --> Helper loaded: language_helper
INFO - 2019-12-07 15:49:04 --> Helper loaded: cookie_helper
INFO - 2019-12-07 15:49:04 --> Helper loaded: email_helper
INFO - 2019-12-07 15:49:04 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 15:49:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 15:49:04 --> Parser Class Initialized
INFO - 2019-12-07 15:49:04 --> User Agent Class Initialized
INFO - 2019-12-07 15:49:04 --> Model Class Initialized
INFO - 2019-12-07 15:49:04 --> Database Driver Class Initialized
INFO - 2019-12-07 15:49:04 --> Model Class Initialized
DEBUG - 2019-12-07 15:49:04 --> Template Class Initialized
INFO - 2019-12-07 15:49:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 15:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 15:49:04 --> Pagination Class Initialized
DEBUG - 2019-12-07 15:49:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 15:49:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 15:49:04 --> Encryption Class Initialized
INFO - 2019-12-07 15:49:04 --> Controller Class Initialized
DEBUG - 2019-12-07 15:49:04 --> auth MX_Controller Initialized
DEBUG - 2019-12-07 15:49:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-07 15:49:04 --> Model Class Initialized
INFO - 2019-12-07 15:49:09 --> Config Class Initialized
INFO - 2019-12-07 15:49:09 --> Hooks Class Initialized
DEBUG - 2019-12-07 15:49:09 --> UTF-8 Support Enabled
INFO - 2019-12-07 15:49:09 --> Utf8 Class Initialized
INFO - 2019-12-07 15:49:09 --> URI Class Initialized
INFO - 2019-12-07 15:49:09 --> Router Class Initialized
INFO - 2019-12-07 15:49:09 --> Output Class Initialized
INFO - 2019-12-07 15:49:09 --> Security Class Initialized
DEBUG - 2019-12-07 15:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 15:49:09 --> CSRF cookie sent
INFO - 2019-12-07 15:49:09 --> Input Class Initialized
INFO - 2019-12-07 15:49:09 --> Language Class Initialized
INFO - 2019-12-07 15:49:09 --> Language Class Initialized
INFO - 2019-12-07 15:49:09 --> Config Class Initialized
INFO - 2019-12-07 15:49:09 --> Loader Class Initialized
INFO - 2019-12-07 15:49:09 --> Helper loaded: url_helper
INFO - 2019-12-07 15:49:09 --> Helper loaded: common_helper
INFO - 2019-12-07 15:49:09 --> Helper loaded: language_helper
INFO - 2019-12-07 15:49:09 --> Helper loaded: cookie_helper
INFO - 2019-12-07 15:49:09 --> Helper loaded: email_helper
INFO - 2019-12-07 15:49:09 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 15:49:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 15:49:09 --> Parser Class Initialized
INFO - 2019-12-07 15:49:09 --> User Agent Class Initialized
INFO - 2019-12-07 15:49:09 --> Model Class Initialized
INFO - 2019-12-07 15:49:09 --> Database Driver Class Initialized
INFO - 2019-12-07 15:49:09 --> Model Class Initialized
DEBUG - 2019-12-07 15:49:09 --> Template Class Initialized
INFO - 2019-12-07 15:49:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 15:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 15:49:10 --> Pagination Class Initialized
DEBUG - 2019-12-07 15:49:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 15:49:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 15:49:10 --> Encryption Class Initialized
INFO - 2019-12-07 15:49:10 --> Controller Class Initialized
DEBUG - 2019-12-07 15:49:10 --> statistics MX_Controller Initialized
DEBUG - 2019-12-07 15:49:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-07 15:49:10 --> Model Class Initialized
ERROR - 2019-12-07 15:49:10 --> Could not find the language line "Pending"
ERROR - 2019-12-07 15:49:10 --> Could not find the language line "Pending"
INFO - 2019-12-07 15:49:10 --> Helper loaded: inflector_helper
ERROR - 2019-12-07 15:49:10 --> Could not find the language line "total_orders"
ERROR - 2019-12-07 15:49:10 --> Could not find the language line "total_orders"
ERROR - 2019-12-07 15:49:10 --> Could not find the language line "Pending"
DEBUG - 2019-12-07 15:49:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-12-07 15:49:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-07 15:49:10 --> blocks MX_Controller Initialized
DEBUG - 2019-12-07 15:49:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-07 15:49:10 --> Model Class Initialized
DEBUG - 2019-12-07 15:49:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-07 15:49:10 --> Model Class Initialized
DEBUG - 2019-12-07 15:49:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-07 15:49:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-07 15:49:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-07 15:49:10 --> Final output sent to browser
DEBUG - 2019-12-07 15:49:10 --> Total execution time: 1.2363
INFO - 2019-12-07 15:49:57 --> Config Class Initialized
INFO - 2019-12-07 15:49:57 --> Hooks Class Initialized
DEBUG - 2019-12-07 15:49:57 --> UTF-8 Support Enabled
INFO - 2019-12-07 15:49:57 --> Utf8 Class Initialized
INFO - 2019-12-07 15:49:57 --> URI Class Initialized
INFO - 2019-12-07 15:49:57 --> Router Class Initialized
INFO - 2019-12-07 15:49:57 --> Output Class Initialized
INFO - 2019-12-07 15:49:57 --> Security Class Initialized
DEBUG - 2019-12-07 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 15:49:57 --> CSRF cookie sent
INFO - 2019-12-07 15:49:57 --> Input Class Initialized
INFO - 2019-12-07 15:49:57 --> Language Class Initialized
INFO - 2019-12-07 15:49:57 --> Language Class Initialized
INFO - 2019-12-07 15:49:57 --> Config Class Initialized
INFO - 2019-12-07 15:49:57 --> Loader Class Initialized
INFO - 2019-12-07 15:49:57 --> Helper loaded: url_helper
INFO - 2019-12-07 15:49:57 --> Helper loaded: common_helper
INFO - 2019-12-07 15:49:57 --> Helper loaded: language_helper
INFO - 2019-12-07 15:49:57 --> Helper loaded: cookie_helper
INFO - 2019-12-07 15:49:57 --> Helper loaded: email_helper
INFO - 2019-12-07 15:49:57 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 15:49:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 15:49:57 --> Parser Class Initialized
INFO - 2019-12-07 15:49:57 --> User Agent Class Initialized
INFO - 2019-12-07 15:49:57 --> Model Class Initialized
INFO - 2019-12-07 15:49:57 --> Database Driver Class Initialized
INFO - 2019-12-07 15:49:57 --> Model Class Initialized
DEBUG - 2019-12-07 15:49:57 --> Template Class Initialized
INFO - 2019-12-07 15:49:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 15:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 15:49:57 --> Pagination Class Initialized
DEBUG - 2019-12-07 15:49:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 15:49:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 15:49:57 --> Encryption Class Initialized
INFO - 2019-12-07 15:49:57 --> Controller Class Initialized
DEBUG - 2019-12-07 15:49:57 --> setting MX_Controller Initialized
DEBUG - 2019-12-07 15:49:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-07 15:49:57 --> Model Class Initialized
INFO - 2019-12-07 15:49:57 --> Helper loaded: inflector_helper
DEBUG - 2019-12-07 15:49:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-07 15:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-12-07 15:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-07 15:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-07 15:49:58 --> blocks MX_Controller Initialized
DEBUG - 2019-12-07 15:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-07 15:49:58 --> Model Class Initialized
DEBUG - 2019-12-07 15:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-07 15:49:58 --> Model Class Initialized
DEBUG - 2019-12-07 15:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-07 15:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-07 15:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-07 15:49:58 --> Final output sent to browser
DEBUG - 2019-12-07 15:49:58 --> Total execution time: 0.8470
INFO - 2019-12-07 15:50:01 --> Config Class Initialized
INFO - 2019-12-07 15:50:01 --> Hooks Class Initialized
DEBUG - 2019-12-07 15:50:01 --> UTF-8 Support Enabled
INFO - 2019-12-07 15:50:01 --> Utf8 Class Initialized
INFO - 2019-12-07 15:50:01 --> URI Class Initialized
INFO - 2019-12-07 15:50:01 --> Router Class Initialized
INFO - 2019-12-07 15:50:01 --> Output Class Initialized
INFO - 2019-12-07 15:50:01 --> Security Class Initialized
DEBUG - 2019-12-07 15:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 15:50:01 --> CSRF cookie sent
INFO - 2019-12-07 15:50:01 --> Input Class Initialized
INFO - 2019-12-07 15:50:01 --> Language Class Initialized
INFO - 2019-12-07 15:50:01 --> Language Class Initialized
INFO - 2019-12-07 15:50:01 --> Config Class Initialized
INFO - 2019-12-07 15:50:01 --> Loader Class Initialized
INFO - 2019-12-07 15:50:01 --> Helper loaded: url_helper
INFO - 2019-12-07 15:50:01 --> Helper loaded: common_helper
INFO - 2019-12-07 15:50:01 --> Helper loaded: language_helper
INFO - 2019-12-07 15:50:01 --> Helper loaded: cookie_helper
INFO - 2019-12-07 15:50:01 --> Helper loaded: email_helper
INFO - 2019-12-07 15:50:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 15:50:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 15:50:01 --> Parser Class Initialized
INFO - 2019-12-07 15:50:01 --> User Agent Class Initialized
INFO - 2019-12-07 15:50:01 --> Model Class Initialized
INFO - 2019-12-07 15:50:01 --> Database Driver Class Initialized
INFO - 2019-12-07 15:50:01 --> Model Class Initialized
DEBUG - 2019-12-07 15:50:01 --> Template Class Initialized
INFO - 2019-12-07 15:50:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 15:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 15:50:01 --> Pagination Class Initialized
DEBUG - 2019-12-07 15:50:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 15:50:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 15:50:01 --> Encryption Class Initialized
INFO - 2019-12-07 15:50:01 --> Controller Class Initialized
DEBUG - 2019-12-07 15:50:01 --> setting MX_Controller Initialized
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-07 15:50:02 --> Model Class Initialized
INFO - 2019-12-07 15:50:02 --> Helper loaded: inflector_helper
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-07 15:50:02 --> blocks MX_Controller Initialized
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-07 15:50:02 --> Model Class Initialized
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-07 15:50:02 --> Model Class Initialized
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-07 15:50:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-07 15:50:02 --> Final output sent to browser
DEBUG - 2019-12-07 15:50:02 --> Total execution time: 0.7261
INFO - 2019-12-07 22:55:13 --> Config Class Initialized
INFO - 2019-12-07 22:55:13 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:55:13 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:55:13 --> Utf8 Class Initialized
INFO - 2019-12-07 22:55:13 --> URI Class Initialized
DEBUG - 2019-12-07 22:55:13 --> No URI present. Default controller set.
INFO - 2019-12-07 22:55:13 --> Router Class Initialized
INFO - 2019-12-07 22:55:13 --> Output Class Initialized
INFO - 2019-12-07 22:55:13 --> Security Class Initialized
DEBUG - 2019-12-07 22:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:55:14 --> CSRF cookie sent
INFO - 2019-12-07 22:55:14 --> Input Class Initialized
INFO - 2019-12-07 22:55:14 --> Language Class Initialized
INFO - 2019-12-07 22:55:14 --> Language Class Initialized
INFO - 2019-12-07 22:55:14 --> Config Class Initialized
INFO - 2019-12-07 22:55:14 --> Loader Class Initialized
INFO - 2019-12-07 22:55:14 --> Helper loaded: url_helper
INFO - 2019-12-07 22:55:14 --> Helper loaded: common_helper
INFO - 2019-12-07 22:55:14 --> Helper loaded: language_helper
INFO - 2019-12-07 22:55:14 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:55:14 --> Helper loaded: email_helper
INFO - 2019-12-07 22:55:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:55:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:55:14 --> Parser Class Initialized
INFO - 2019-12-07 22:55:14 --> User Agent Class Initialized
INFO - 2019-12-07 22:55:14 --> Model Class Initialized
INFO - 2019-12-07 22:55:14 --> Database Driver Class Initialized
INFO - 2019-12-07 22:55:14 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:14 --> Template Class Initialized
INFO - 2019-12-07 22:55:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:55:14 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:55:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:55:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:55:14 --> Encryption Class Initialized
DEBUG - 2019-12-07 22:55:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-07 22:55:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-07 22:55:14 --> Controller Class Initialized
DEBUG - 2019-12-07 22:55:14 --> pergo MX_Controller Initialized
DEBUG - 2019-12-07 22:55:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-07 22:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-07 22:55:15 --> Model Class Initialized
INFO - 2019-12-07 22:55:15 --> Helper loaded: inflector_helper
DEBUG - 2019-12-07 22:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-07 22:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-07 22:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-07 22:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-07 22:55:15 --> Final output sent to browser
DEBUG - 2019-12-07 22:55:15 --> Total execution time: 1.8835
INFO - 2019-12-07 22:55:19 --> Config Class Initialized
INFO - 2019-12-07 22:55:19 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:55:19 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:55:19 --> Utf8 Class Initialized
INFO - 2019-12-07 22:55:19 --> URI Class Initialized
INFO - 2019-12-07 22:55:19 --> Router Class Initialized
INFO - 2019-12-07 22:55:19 --> Output Class Initialized
INFO - 2019-12-07 22:55:19 --> Security Class Initialized
DEBUG - 2019-12-07 22:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:55:19 --> CSRF cookie sent
INFO - 2019-12-07 22:55:19 --> Input Class Initialized
INFO - 2019-12-07 22:55:19 --> Language Class Initialized
INFO - 2019-12-07 22:55:19 --> Language Class Initialized
INFO - 2019-12-07 22:55:19 --> Config Class Initialized
INFO - 2019-12-07 22:55:19 --> Loader Class Initialized
INFO - 2019-12-07 22:55:19 --> Helper loaded: url_helper
INFO - 2019-12-07 22:55:19 --> Helper loaded: common_helper
INFO - 2019-12-07 22:55:19 --> Helper loaded: language_helper
INFO - 2019-12-07 22:55:19 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:55:19 --> Helper loaded: email_helper
INFO - 2019-12-07 22:55:19 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:55:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:55:19 --> Parser Class Initialized
INFO - 2019-12-07 22:55:19 --> User Agent Class Initialized
INFO - 2019-12-07 22:55:19 --> Model Class Initialized
INFO - 2019-12-07 22:55:19 --> Database Driver Class Initialized
INFO - 2019-12-07 22:55:19 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:19 --> Template Class Initialized
INFO - 2019-12-07 22:55:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:55:19 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:55:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:55:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:55:19 --> Encryption Class Initialized
INFO - 2019-12-07 22:55:19 --> Controller Class Initialized
DEBUG - 2019-12-07 22:55:19 --> auth MX_Controller Initialized
DEBUG - 2019-12-07 22:55:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-07 22:55:19 --> Model Class Initialized
INFO - 2019-12-07 22:55:19 --> Config Class Initialized
INFO - 2019-12-07 22:55:19 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:55:19 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:55:19 --> Utf8 Class Initialized
INFO - 2019-12-07 22:55:19 --> URI Class Initialized
INFO - 2019-12-07 22:55:19 --> Router Class Initialized
INFO - 2019-12-07 22:55:19 --> Output Class Initialized
INFO - 2019-12-07 22:55:19 --> Security Class Initialized
DEBUG - 2019-12-07 22:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:55:19 --> CSRF cookie sent
INFO - 2019-12-07 22:55:19 --> Input Class Initialized
INFO - 2019-12-07 22:55:19 --> Language Class Initialized
INFO - 2019-12-07 22:55:19 --> Language Class Initialized
INFO - 2019-12-07 22:55:19 --> Config Class Initialized
INFO - 2019-12-07 22:55:19 --> Loader Class Initialized
INFO - 2019-12-07 22:55:19 --> Helper loaded: url_helper
INFO - 2019-12-07 22:55:19 --> Helper loaded: common_helper
INFO - 2019-12-07 22:55:19 --> Helper loaded: language_helper
INFO - 2019-12-07 22:55:19 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:55:19 --> Helper loaded: email_helper
INFO - 2019-12-07 22:55:20 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:55:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:55:20 --> Parser Class Initialized
INFO - 2019-12-07 22:55:20 --> User Agent Class Initialized
INFO - 2019-12-07 22:55:20 --> Config Class Initialized
INFO - 2019-12-07 22:55:20 --> Model Class Initialized
INFO - 2019-12-07 22:55:20 --> Hooks Class Initialized
INFO - 2019-12-07 22:55:20 --> Database Driver Class Initialized
INFO - 2019-12-07 22:55:20 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:20 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:55:20 --> Utf8 Class Initialized
DEBUG - 2019-12-07 22:55:20 --> Template Class Initialized
INFO - 2019-12-07 22:55:20 --> URI Class Initialized
INFO - 2019-12-07 22:55:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:55:20 --> Router Class Initialized
INFO - 2019-12-07 22:55:20 --> Pagination Class Initialized
INFO - 2019-12-07 22:55:20 --> Output Class Initialized
INFO - 2019-12-07 22:55:20 --> Security Class Initialized
DEBUG - 2019-12-07 22:55:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:55:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2019-12-07 22:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:55:20 --> CSRF cookie sent
INFO - 2019-12-07 22:55:20 --> Encryption Class Initialized
INFO - 2019-12-07 22:55:20 --> Input Class Initialized
INFO - 2019-12-07 22:55:20 --> Controller Class Initialized
DEBUG - 2019-12-07 22:55:20 --> statistics MX_Controller Initialized
INFO - 2019-12-07 22:55:20 --> Language Class Initialized
INFO - 2019-12-07 22:55:20 --> Language Class Initialized
INFO - 2019-12-07 22:55:20 --> Config Class Initialized
DEBUG - 2019-12-07 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-07 22:55:20 --> Model Class Initialized
INFO - 2019-12-07 22:55:20 --> Loader Class Initialized
INFO - 2019-12-07 22:55:20 --> Helper loaded: url_helper
INFO - 2019-12-07 22:55:20 --> Helper loaded: common_helper
INFO - 2019-12-07 22:55:20 --> Helper loaded: language_helper
INFO - 2019-12-07 22:55:20 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:55:20 --> Helper loaded: email_helper
INFO - 2019-12-07 22:55:20 --> Helper loaded: file_manager_helper
ERROR - 2019-12-07 22:55:20 --> Could not find the language line "Pending"
INFO - 2019-12-07 22:55:20 --> Language file loaded: language/english/common_lang.php
ERROR - 2019-12-07 22:55:20 --> Could not find the language line "Pending"
INFO - 2019-12-07 22:55:20 --> Parser Class Initialized
INFO - 2019-12-07 22:55:20 --> Helper loaded: inflector_helper
INFO - 2019-12-07 22:55:20 --> User Agent Class Initialized
INFO - 2019-12-07 22:55:20 --> Model Class Initialized
INFO - 2019-12-07 22:55:20 --> Database Driver Class Initialized
INFO - 2019-12-07 22:55:20 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:20 --> Template Class Initialized
ERROR - 2019-12-07 22:55:20 --> Could not find the language line "total_orders"
ERROR - 2019-12-07 22:55:20 --> Could not find the language line "total_orders"
ERROR - 2019-12-07 22:55:20 --> Could not find the language line "Pending"
DEBUG - 2019-12-07 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-12-07 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-07 22:55:20 --> blocks MX_Controller Initialized
DEBUG - 2019-12-07 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-07 22:55:20 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-07 22:55:20 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-07 22:55:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-07 22:55:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-07 22:55:21 --> Final output sent to browser
DEBUG - 2019-12-07 22:55:21 --> Total execution time: 1.3849
INFO - 2019-12-07 22:55:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:55:21 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:55:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:55:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:55:21 --> Encryption Class Initialized
INFO - 2019-12-07 22:55:21 --> Controller Class Initialized
DEBUG - 2019-12-07 22:55:21 --> auth MX_Controller Initialized
DEBUG - 2019-12-07 22:55:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-07 22:55:21 --> Model Class Initialized
INFO - 2019-12-07 22:55:24 --> Config Class Initialized
INFO - 2019-12-07 22:55:24 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:55:24 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:55:24 --> Utf8 Class Initialized
INFO - 2019-12-07 22:55:24 --> URI Class Initialized
INFO - 2019-12-07 22:55:24 --> Router Class Initialized
INFO - 2019-12-07 22:55:24 --> Output Class Initialized
INFO - 2019-12-07 22:55:24 --> Security Class Initialized
DEBUG - 2019-12-07 22:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:55:24 --> CSRF cookie sent
INFO - 2019-12-07 22:55:24 --> Input Class Initialized
INFO - 2019-12-07 22:55:24 --> Language Class Initialized
INFO - 2019-12-07 22:55:24 --> Language Class Initialized
INFO - 2019-12-07 22:55:24 --> Config Class Initialized
INFO - 2019-12-07 22:55:24 --> Loader Class Initialized
INFO - 2019-12-07 22:55:24 --> Helper loaded: url_helper
INFO - 2019-12-07 22:55:24 --> Helper loaded: common_helper
INFO - 2019-12-07 22:55:24 --> Helper loaded: language_helper
INFO - 2019-12-07 22:55:24 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:55:24 --> Helper loaded: email_helper
INFO - 2019-12-07 22:55:24 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:55:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:55:24 --> Parser Class Initialized
INFO - 2019-12-07 22:55:24 --> User Agent Class Initialized
INFO - 2019-12-07 22:55:24 --> Model Class Initialized
INFO - 2019-12-07 22:55:24 --> Database Driver Class Initialized
INFO - 2019-12-07 22:55:24 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:24 --> Template Class Initialized
INFO - 2019-12-07 22:55:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:55:25 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:55:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:55:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:55:25 --> Encryption Class Initialized
INFO - 2019-12-07 22:55:25 --> Controller Class Initialized
DEBUG - 2019-12-07 22:55:25 --> transactions MX_Controller Initialized
DEBUG - 2019-12-07 22:55:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-07 22:55:25 --> Model Class Initialized
ERROR - 2019-12-07 22:55:25 --> Could not find the language line "order_id"
INFO - 2019-12-07 22:55:25 --> Helper loaded: inflector_helper
DEBUG - 2019-12-07 22:55:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-07 22:55:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-07 22:55:25 --> blocks MX_Controller Initialized
DEBUG - 2019-12-07 22:55:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-07 22:55:25 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-07 22:55:25 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-07 22:55:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-07 22:55:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-07 22:55:25 --> Final output sent to browser
DEBUG - 2019-12-07 22:55:25 --> Total execution time: 0.9351
INFO - 2019-12-07 22:55:32 --> Config Class Initialized
INFO - 2019-12-07 22:55:32 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:55:32 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:55:32 --> Utf8 Class Initialized
INFO - 2019-12-07 22:55:32 --> URI Class Initialized
INFO - 2019-12-07 22:55:32 --> Router Class Initialized
INFO - 2019-12-07 22:55:32 --> Output Class Initialized
INFO - 2019-12-07 22:55:32 --> Security Class Initialized
DEBUG - 2019-12-07 22:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:55:32 --> CSRF cookie sent
INFO - 2019-12-07 22:55:32 --> CSRF token verified
INFO - 2019-12-07 22:55:32 --> Input Class Initialized
INFO - 2019-12-07 22:55:32 --> Language Class Initialized
INFO - 2019-12-07 22:55:32 --> Language Class Initialized
INFO - 2019-12-07 22:55:33 --> Config Class Initialized
INFO - 2019-12-07 22:55:33 --> Loader Class Initialized
INFO - 2019-12-07 22:55:33 --> Helper loaded: url_helper
INFO - 2019-12-07 22:55:33 --> Helper loaded: common_helper
INFO - 2019-12-07 22:55:33 --> Helper loaded: language_helper
INFO - 2019-12-07 22:55:33 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:55:33 --> Helper loaded: email_helper
INFO - 2019-12-07 22:55:33 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:55:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:55:33 --> Parser Class Initialized
INFO - 2019-12-07 22:55:33 --> User Agent Class Initialized
INFO - 2019-12-07 22:55:33 --> Model Class Initialized
INFO - 2019-12-07 22:55:33 --> Database Driver Class Initialized
INFO - 2019-12-07 22:55:33 --> Model Class Initialized
DEBUG - 2019-12-07 22:55:33 --> Template Class Initialized
INFO - 2019-12-07 22:55:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:55:33 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:55:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:55:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:55:33 --> Encryption Class Initialized
INFO - 2019-12-07 22:55:33 --> Controller Class Initialized
DEBUG - 2019-12-07 22:55:33 --> transactions MX_Controller Initialized
DEBUG - 2019-12-07 22:55:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-07 22:55:33 --> Model Class Initialized
ERROR - 2019-12-07 22:55:33 --> Could not find the language line "order_id"
INFO - 2019-12-07 22:57:08 --> Config Class Initialized
INFO - 2019-12-07 22:57:08 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:57:08 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:57:08 --> Utf8 Class Initialized
INFO - 2019-12-07 22:57:08 --> URI Class Initialized
INFO - 2019-12-07 22:57:08 --> Router Class Initialized
INFO - 2019-12-07 22:57:08 --> Output Class Initialized
INFO - 2019-12-07 22:57:08 --> Security Class Initialized
DEBUG - 2019-12-07 22:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:57:08 --> CSRF cookie sent
INFO - 2019-12-07 22:57:08 --> Input Class Initialized
INFO - 2019-12-07 22:57:08 --> Language Class Initialized
INFO - 2019-12-07 22:57:08 --> Language Class Initialized
INFO - 2019-12-07 22:57:08 --> Config Class Initialized
INFO - 2019-12-07 22:57:08 --> Loader Class Initialized
INFO - 2019-12-07 22:57:08 --> Helper loaded: url_helper
INFO - 2019-12-07 22:57:08 --> Helper loaded: common_helper
INFO - 2019-12-07 22:57:08 --> Helper loaded: language_helper
INFO - 2019-12-07 22:57:08 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:57:08 --> Helper loaded: email_helper
INFO - 2019-12-07 22:57:08 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:57:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:57:08 --> Parser Class Initialized
INFO - 2019-12-07 22:57:08 --> User Agent Class Initialized
INFO - 2019-12-07 22:57:08 --> Model Class Initialized
INFO - 2019-12-07 22:57:08 --> Database Driver Class Initialized
INFO - 2019-12-07 22:57:09 --> Model Class Initialized
DEBUG - 2019-12-07 22:57:09 --> Template Class Initialized
INFO - 2019-12-07 22:57:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:57:09 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:57:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:57:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:57:09 --> Encryption Class Initialized
INFO - 2019-12-07 22:57:09 --> Controller Class Initialized
DEBUG - 2019-12-07 22:57:09 --> transactions MX_Controller Initialized
DEBUG - 2019-12-07 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-07 22:57:09 --> Model Class Initialized
ERROR - 2019-12-07 22:57:09 --> Could not find the language line "order_id"
INFO - 2019-12-07 22:57:09 --> Helper loaded: inflector_helper
DEBUG - 2019-12-07 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-07 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-07 22:57:09 --> blocks MX_Controller Initialized
DEBUG - 2019-12-07 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-07 22:57:09 --> Model Class Initialized
DEBUG - 2019-12-07 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-07 22:57:09 --> Model Class Initialized
DEBUG - 2019-12-07 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-07 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-07 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-07 22:57:09 --> Final output sent to browser
DEBUG - 2019-12-07 22:57:09 --> Total execution time: 0.7023
INFO - 2019-12-07 22:57:13 --> Config Class Initialized
INFO - 2019-12-07 22:57:13 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:57:13 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:57:13 --> Utf8 Class Initialized
INFO - 2019-12-07 22:57:13 --> URI Class Initialized
INFO - 2019-12-07 22:57:13 --> Router Class Initialized
INFO - 2019-12-07 22:57:13 --> Output Class Initialized
INFO - 2019-12-07 22:57:13 --> Security Class Initialized
DEBUG - 2019-12-07 22:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:57:13 --> CSRF cookie sent
INFO - 2019-12-07 22:57:13 --> CSRF token verified
INFO - 2019-12-07 22:57:13 --> Input Class Initialized
INFO - 2019-12-07 22:57:13 --> Language Class Initialized
INFO - 2019-12-07 22:57:13 --> Language Class Initialized
INFO - 2019-12-07 22:57:13 --> Config Class Initialized
INFO - 2019-12-07 22:57:13 --> Loader Class Initialized
INFO - 2019-12-07 22:57:13 --> Helper loaded: url_helper
INFO - 2019-12-07 22:57:13 --> Helper loaded: common_helper
INFO - 2019-12-07 22:57:13 --> Helper loaded: language_helper
INFO - 2019-12-07 22:57:13 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:57:13 --> Helper loaded: email_helper
INFO - 2019-12-07 22:57:13 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:57:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:57:13 --> Parser Class Initialized
INFO - 2019-12-07 22:57:13 --> User Agent Class Initialized
INFO - 2019-12-07 22:57:13 --> Model Class Initialized
INFO - 2019-12-07 22:57:13 --> Database Driver Class Initialized
INFO - 2019-12-07 22:57:13 --> Model Class Initialized
DEBUG - 2019-12-07 22:57:13 --> Template Class Initialized
INFO - 2019-12-07 22:57:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:57:13 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:57:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:57:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:57:13 --> Encryption Class Initialized
INFO - 2019-12-07 22:57:13 --> Controller Class Initialized
DEBUG - 2019-12-07 22:57:13 --> transactions MX_Controller Initialized
DEBUG - 2019-12-07 22:57:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-07 22:57:13 --> Model Class Initialized
ERROR - 2019-12-07 22:57:13 --> Could not find the language line "order_id"
INFO - 2019-12-07 22:59:25 --> Config Class Initialized
INFO - 2019-12-07 22:59:25 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:59:25 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:59:25 --> Utf8 Class Initialized
INFO - 2019-12-07 22:59:25 --> URI Class Initialized
INFO - 2019-12-07 22:59:25 --> Router Class Initialized
INFO - 2019-12-07 22:59:25 --> Output Class Initialized
INFO - 2019-12-07 22:59:25 --> Security Class Initialized
DEBUG - 2019-12-07 22:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:59:25 --> CSRF cookie sent
INFO - 2019-12-07 22:59:25 --> Input Class Initialized
INFO - 2019-12-07 22:59:25 --> Language Class Initialized
INFO - 2019-12-07 22:59:25 --> Language Class Initialized
INFO - 2019-12-07 22:59:25 --> Config Class Initialized
INFO - 2019-12-07 22:59:25 --> Loader Class Initialized
INFO - 2019-12-07 22:59:25 --> Helper loaded: url_helper
INFO - 2019-12-07 22:59:25 --> Helper loaded: common_helper
INFO - 2019-12-07 22:59:25 --> Helper loaded: language_helper
INFO - 2019-12-07 22:59:25 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:59:25 --> Helper loaded: email_helper
INFO - 2019-12-07 22:59:25 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:59:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:59:25 --> Parser Class Initialized
INFO - 2019-12-07 22:59:25 --> User Agent Class Initialized
DEBUG - 2019-12-07 22:59:25 --> Template Class Initialized
INFO - 2019-12-07 22:59:25 --> Database Driver Class Initialized
INFO - 2019-12-07 22:59:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:59:25 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:59:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:59:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:59:25 --> Encryption Class Initialized
INFO - 2019-12-07 22:59:25 --> Controller Class Initialized
DEBUG - 2019-12-07 22:59:25 --> custom_page MX_Controller Initialized
ERROR - 2019-12-07 22:59:25 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-07 22:59:25 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-07 22:59:25 --> Config Class Initialized
INFO - 2019-12-07 22:59:25 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:59:25 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:59:25 --> Utf8 Class Initialized
INFO - 2019-12-07 22:59:25 --> URI Class Initialized
DEBUG - 2019-12-07 22:59:25 --> No URI present. Default controller set.
INFO - 2019-12-07 22:59:25 --> Router Class Initialized
INFO - 2019-12-07 22:59:25 --> Output Class Initialized
INFO - 2019-12-07 22:59:25 --> Security Class Initialized
DEBUG - 2019-12-07 22:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:59:25 --> CSRF cookie sent
INFO - 2019-12-07 22:59:25 --> Input Class Initialized
INFO - 2019-12-07 22:59:25 --> Language Class Initialized
INFO - 2019-12-07 22:59:25 --> Language Class Initialized
INFO - 2019-12-07 22:59:25 --> Config Class Initialized
INFO - 2019-12-07 22:59:25 --> Loader Class Initialized
INFO - 2019-12-07 22:59:25 --> Helper loaded: url_helper
INFO - 2019-12-07 22:59:25 --> Helper loaded: common_helper
INFO - 2019-12-07 22:59:25 --> Helper loaded: language_helper
INFO - 2019-12-07 22:59:25 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:59:26 --> Helper loaded: email_helper
INFO - 2019-12-07 22:59:26 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:59:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:59:26 --> Parser Class Initialized
INFO - 2019-12-07 22:59:26 --> User Agent Class Initialized
INFO - 2019-12-07 22:59:26 --> Model Class Initialized
INFO - 2019-12-07 22:59:26 --> Database Driver Class Initialized
INFO - 2019-12-07 22:59:26 --> Model Class Initialized
DEBUG - 2019-12-07 22:59:26 --> Template Class Initialized
INFO - 2019-12-07 22:59:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:59:26 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:59:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:59:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:59:26 --> Encryption Class Initialized
DEBUG - 2019-12-07 22:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-07 22:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-07 22:59:26 --> Controller Class Initialized
DEBUG - 2019-12-07 22:59:26 --> pergo MX_Controller Initialized
DEBUG - 2019-12-07 22:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-07 22:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-07 22:59:26 --> Model Class Initialized
INFO - 2019-12-07 22:59:26 --> Helper loaded: inflector_helper
DEBUG - 2019-12-07 22:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-07 22:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-07 22:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-07 22:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-07 22:59:26 --> Final output sent to browser
DEBUG - 2019-12-07 22:59:26 --> Total execution time: 0.6513
INFO - 2019-12-07 22:59:41 --> Config Class Initialized
INFO - 2019-12-07 22:59:41 --> Hooks Class Initialized
DEBUG - 2019-12-07 22:59:41 --> UTF-8 Support Enabled
INFO - 2019-12-07 22:59:41 --> Utf8 Class Initialized
INFO - 2019-12-07 22:59:41 --> URI Class Initialized
INFO - 2019-12-07 22:59:41 --> Router Class Initialized
INFO - 2019-12-07 22:59:41 --> Output Class Initialized
INFO - 2019-12-07 22:59:41 --> Security Class Initialized
DEBUG - 2019-12-07 22:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-07 22:59:41 --> CSRF cookie sent
INFO - 2019-12-07 22:59:41 --> Input Class Initialized
INFO - 2019-12-07 22:59:41 --> Language Class Initialized
INFO - 2019-12-07 22:59:42 --> Language Class Initialized
INFO - 2019-12-07 22:59:42 --> Config Class Initialized
INFO - 2019-12-07 22:59:42 --> Loader Class Initialized
INFO - 2019-12-07 22:59:42 --> Helper loaded: url_helper
INFO - 2019-12-07 22:59:42 --> Helper loaded: common_helper
INFO - 2019-12-07 22:59:42 --> Helper loaded: language_helper
INFO - 2019-12-07 22:59:42 --> Helper loaded: cookie_helper
INFO - 2019-12-07 22:59:42 --> Helper loaded: email_helper
INFO - 2019-12-07 22:59:42 --> Helper loaded: file_manager_helper
INFO - 2019-12-07 22:59:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-07 22:59:42 --> Parser Class Initialized
INFO - 2019-12-07 22:59:42 --> User Agent Class Initialized
DEBUG - 2019-12-07 22:59:42 --> Template Class Initialized
INFO - 2019-12-07 22:59:42 --> Database Driver Class Initialized
INFO - 2019-12-07 22:59:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-07 22:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-07 22:59:42 --> Pagination Class Initialized
DEBUG - 2019-12-07 22:59:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-07 22:59:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-07 22:59:42 --> Encryption Class Initialized
INFO - 2019-12-07 22:59:42 --> Controller Class Initialized
DEBUG - 2019-12-07 22:59:42 --> payop MX_Controller Initialized
INFO - 2019-12-07 22:59:42 --> Model Class Initialized
INFO - 2019-12-07 22:59:42 --> Model Class Initialized
INFO - 2019-12-07 22:59:42 --> Model Class Initialized
ERROR - 2019-12-07 22:59:43 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-07 22:59:43 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
