<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-24 15:55:25 --> Config Class Initialized
INFO - 2020-02-24 15:55:25 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:55:25 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:55:25 --> Utf8 Class Initialized
INFO - 2020-02-24 15:55:25 --> URI Class Initialized
DEBUG - 2020-02-24 15:55:26 --> No URI present. Default controller set.
INFO - 2020-02-24 15:55:26 --> Router Class Initialized
INFO - 2020-02-24 15:55:26 --> Output Class Initialized
INFO - 2020-02-24 15:55:26 --> Security Class Initialized
DEBUG - 2020-02-24 15:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:55:26 --> CSRF cookie sent
INFO - 2020-02-24 15:55:26 --> Input Class Initialized
INFO - 2020-02-24 15:55:26 --> Language Class Initialized
INFO - 2020-02-24 15:55:26 --> Language Class Initialized
INFO - 2020-02-24 15:55:26 --> Config Class Initialized
INFO - 2020-02-24 15:55:26 --> Loader Class Initialized
INFO - 2020-02-24 15:55:26 --> Helper loaded: url_helper
INFO - 2020-02-24 15:55:26 --> Helper loaded: common_helper
INFO - 2020-02-24 15:55:26 --> Helper loaded: language_helper
INFO - 2020-02-24 15:55:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:55:26 --> Helper loaded: email_helper
INFO - 2020-02-24 15:55:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:55:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:55:26 --> Parser Class Initialized
INFO - 2020-02-24 15:55:26 --> User Agent Class Initialized
INFO - 2020-02-24 15:55:26 --> Model Class Initialized
INFO - 2020-02-24 15:55:26 --> Database Driver Class Initialized
INFO - 2020-02-24 15:55:26 --> Model Class Initialized
DEBUG - 2020-02-24 15:55:26 --> Template Class Initialized
INFO - 2020-02-24 15:55:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:55:27 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:55:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:55:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:55:27 --> Encryption Class Initialized
DEBUG - 2020-02-24 15:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-24 15:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-02-24 15:55:27 --> Controller Class Initialized
DEBUG - 2020-02-24 15:55:27 --> pergo MX_Controller Initialized
DEBUG - 2020-02-24 15:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-24 15:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-02-24 15:55:27 --> Model Class Initialized
INFO - 2020-02-24 15:55:27 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 15:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-02-24 15:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-02-24 15:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-02-24 15:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-02-24 15:55:27 --> Final output sent to browser
DEBUG - 2020-02-24 15:55:27 --> Total execution time: 2.1034
INFO - 2020-02-24 15:55:31 --> Config Class Initialized
INFO - 2020-02-24 15:55:31 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:55:31 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:55:31 --> Utf8 Class Initialized
INFO - 2020-02-24 15:55:31 --> URI Class Initialized
INFO - 2020-02-24 15:55:31 --> Router Class Initialized
INFO - 2020-02-24 15:55:31 --> Output Class Initialized
INFO - 2020-02-24 15:55:31 --> Security Class Initialized
DEBUG - 2020-02-24 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:55:31 --> CSRF cookie sent
INFO - 2020-02-24 15:55:31 --> Input Class Initialized
INFO - 2020-02-24 15:55:31 --> Language Class Initialized
INFO - 2020-02-24 15:55:31 --> Language Class Initialized
INFO - 2020-02-24 15:55:31 --> Config Class Initialized
INFO - 2020-02-24 15:55:31 --> Loader Class Initialized
INFO - 2020-02-24 15:55:31 --> Helper loaded: url_helper
INFO - 2020-02-24 15:55:31 --> Helper loaded: common_helper
INFO - 2020-02-24 15:55:31 --> Helper loaded: language_helper
INFO - 2020-02-24 15:55:31 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:55:31 --> Helper loaded: email_helper
INFO - 2020-02-24 15:55:31 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:55:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:55:31 --> Parser Class Initialized
INFO - 2020-02-24 15:55:31 --> User Agent Class Initialized
INFO - 2020-02-24 15:55:31 --> Model Class Initialized
INFO - 2020-02-24 15:55:31 --> Database Driver Class Initialized
INFO - 2020-02-24 15:55:31 --> Model Class Initialized
DEBUG - 2020-02-24 15:55:31 --> Template Class Initialized
INFO - 2020-02-24 15:55:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:55:31 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:55:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:55:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:55:31 --> Encryption Class Initialized
INFO - 2020-02-24 15:55:31 --> Controller Class Initialized
DEBUG - 2020-02-24 15:55:31 --> package MX_Controller Initialized
DEBUG - 2020-02-24 15:55:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-24 15:55:31 --> Model Class Initialized
INFO - 2020-02-24 15:55:31 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 15:55:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 15:55:31 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 15:55:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 15:55:32 --> Model Class Initialized
DEBUG - 2020-02-24 15:55:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:55:32 --> Model Class Initialized
DEBUG - 2020-02-24 15:55:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-24 15:55:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-24 15:55:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-24 15:55:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-24 15:55:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-24 15:55:32 --> Final output sent to browser
DEBUG - 2020-02-24 15:55:32 --> Total execution time: 1.1779
INFO - 2020-02-24 15:56:14 --> Config Class Initialized
INFO - 2020-02-24 15:56:14 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:56:14 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:56:14 --> Utf8 Class Initialized
INFO - 2020-02-24 15:56:14 --> URI Class Initialized
INFO - 2020-02-24 15:56:14 --> Router Class Initialized
INFO - 2020-02-24 15:56:14 --> Output Class Initialized
INFO - 2020-02-24 15:56:14 --> Security Class Initialized
DEBUG - 2020-02-24 15:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:56:14 --> CSRF cookie sent
INFO - 2020-02-24 15:56:14 --> Input Class Initialized
INFO - 2020-02-24 15:56:14 --> Language Class Initialized
INFO - 2020-02-24 15:56:14 --> Language Class Initialized
INFO - 2020-02-24 15:56:14 --> Config Class Initialized
INFO - 2020-02-24 15:56:14 --> Loader Class Initialized
INFO - 2020-02-24 15:56:14 --> Helper loaded: url_helper
INFO - 2020-02-24 15:56:14 --> Helper loaded: common_helper
INFO - 2020-02-24 15:56:14 --> Helper loaded: language_helper
INFO - 2020-02-24 15:56:14 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:56:14 --> Helper loaded: email_helper
INFO - 2020-02-24 15:56:14 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:56:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:56:14 --> Parser Class Initialized
INFO - 2020-02-24 15:56:14 --> User Agent Class Initialized
INFO - 2020-02-24 15:56:14 --> Model Class Initialized
INFO - 2020-02-24 15:56:14 --> Database Driver Class Initialized
INFO - 2020-02-24 15:56:14 --> Model Class Initialized
DEBUG - 2020-02-24 15:56:14 --> Template Class Initialized
INFO - 2020-02-24 15:56:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:56:14 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:56:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:56:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:56:14 --> Encryption Class Initialized
INFO - 2020-02-24 15:56:14 --> Controller Class Initialized
DEBUG - 2020-02-24 15:56:14 --> category MX_Controller Initialized
INFO - 2020-02-24 15:56:14 --> Config Class Initialized
INFO - 2020-02-24 15:56:15 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:56:15 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:56:15 --> Utf8 Class Initialized
INFO - 2020-02-24 15:56:15 --> URI Class Initialized
DEBUG - 2020-02-24 15:56:15 --> No URI present. Default controller set.
INFO - 2020-02-24 15:56:15 --> Router Class Initialized
INFO - 2020-02-24 15:56:15 --> Output Class Initialized
INFO - 2020-02-24 15:56:15 --> Security Class Initialized
DEBUG - 2020-02-24 15:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:56:15 --> CSRF cookie sent
INFO - 2020-02-24 15:56:15 --> Input Class Initialized
INFO - 2020-02-24 15:56:15 --> Language Class Initialized
INFO - 2020-02-24 15:56:15 --> Language Class Initialized
INFO - 2020-02-24 15:56:15 --> Config Class Initialized
INFO - 2020-02-24 15:56:15 --> Loader Class Initialized
INFO - 2020-02-24 15:56:15 --> Helper loaded: url_helper
INFO - 2020-02-24 15:56:15 --> Helper loaded: common_helper
INFO - 2020-02-24 15:56:15 --> Helper loaded: language_helper
INFO - 2020-02-24 15:56:15 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:56:15 --> Helper loaded: email_helper
INFO - 2020-02-24 15:56:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:56:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:56:15 --> Parser Class Initialized
INFO - 2020-02-24 15:56:15 --> User Agent Class Initialized
INFO - 2020-02-24 15:56:15 --> Model Class Initialized
INFO - 2020-02-24 15:56:15 --> Database Driver Class Initialized
INFO - 2020-02-24 15:56:15 --> Model Class Initialized
DEBUG - 2020-02-24 15:56:15 --> Template Class Initialized
INFO - 2020-02-24 15:56:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:56:15 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:56:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:56:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:56:15 --> Encryption Class Initialized
DEBUG - 2020-02-24 15:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-24 15:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-02-24 15:56:15 --> Controller Class Initialized
DEBUG - 2020-02-24 15:56:15 --> pergo MX_Controller Initialized
DEBUG - 2020-02-24 15:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-24 15:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-02-24 15:56:15 --> Model Class Initialized
INFO - 2020-02-24 15:56:15 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 15:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-02-24 15:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-02-24 15:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-02-24 15:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-02-24 15:56:15 --> Final output sent to browser
DEBUG - 2020-02-24 15:56:15 --> Total execution time: 0.5930
INFO - 2020-02-24 15:56:19 --> Config Class Initialized
INFO - 2020-02-24 15:56:19 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:56:19 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:56:19 --> Utf8 Class Initialized
INFO - 2020-02-24 15:56:19 --> URI Class Initialized
INFO - 2020-02-24 15:56:19 --> Router Class Initialized
INFO - 2020-02-24 15:56:19 --> Output Class Initialized
INFO - 2020-02-24 15:56:19 --> Security Class Initialized
DEBUG - 2020-02-24 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:56:19 --> CSRF cookie sent
INFO - 2020-02-24 15:56:19 --> Input Class Initialized
INFO - 2020-02-24 15:56:19 --> Language Class Initialized
INFO - 2020-02-24 15:56:19 --> Language Class Initialized
INFO - 2020-02-24 15:56:19 --> Config Class Initialized
INFO - 2020-02-24 15:56:19 --> Loader Class Initialized
INFO - 2020-02-24 15:56:19 --> Helper loaded: url_helper
INFO - 2020-02-24 15:56:20 --> Helper loaded: common_helper
INFO - 2020-02-24 15:56:20 --> Helper loaded: language_helper
INFO - 2020-02-24 15:56:20 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:56:20 --> Helper loaded: email_helper
INFO - 2020-02-24 15:56:20 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:56:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:56:20 --> Parser Class Initialized
INFO - 2020-02-24 15:56:20 --> User Agent Class Initialized
INFO - 2020-02-24 15:56:20 --> Model Class Initialized
INFO - 2020-02-24 15:56:20 --> Database Driver Class Initialized
INFO - 2020-02-24 15:56:20 --> Model Class Initialized
DEBUG - 2020-02-24 15:56:20 --> Template Class Initialized
INFO - 2020-02-24 15:56:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:56:20 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:56:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:56:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:56:20 --> Encryption Class Initialized
INFO - 2020-02-24 15:56:20 --> Controller Class Initialized
DEBUG - 2020-02-24 15:56:20 --> auth MX_Controller Initialized
DEBUG - 2020-02-24 15:56:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-02-24 15:56:20 --> Model Class Initialized
DEBUG - 2020-02-24 15:56:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-02-24 15:56:20 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 15:56:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-02-24 15:56:20 --> pergo MX_Controller Initialized
DEBUG - 2020-02-24 15:56:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-24 15:56:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-02-24 15:56:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-02-24 15:56:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-02-24 15:56:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-02-24 15:56:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-02-24 15:56:20 --> Final output sent to browser
DEBUG - 2020-02-24 15:56:20 --> Total execution time: 0.6172
INFO - 2020-02-24 15:56:22 --> Config Class Initialized
INFO - 2020-02-24 15:56:22 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:56:22 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:56:22 --> Utf8 Class Initialized
INFO - 2020-02-24 15:56:22 --> URI Class Initialized
INFO - 2020-02-24 15:56:22 --> Router Class Initialized
INFO - 2020-02-24 15:56:22 --> Output Class Initialized
INFO - 2020-02-24 15:56:22 --> Security Class Initialized
DEBUG - 2020-02-24 15:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:56:22 --> CSRF cookie sent
INFO - 2020-02-24 15:56:22 --> CSRF token verified
INFO - 2020-02-24 15:56:22 --> Input Class Initialized
INFO - 2020-02-24 15:56:22 --> Language Class Initialized
INFO - 2020-02-24 15:56:22 --> Language Class Initialized
INFO - 2020-02-24 15:56:22 --> Config Class Initialized
INFO - 2020-02-24 15:56:22 --> Loader Class Initialized
INFO - 2020-02-24 15:56:22 --> Helper loaded: url_helper
INFO - 2020-02-24 15:56:22 --> Helper loaded: common_helper
INFO - 2020-02-24 15:56:22 --> Helper loaded: language_helper
INFO - 2020-02-24 15:56:22 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:56:22 --> Helper loaded: email_helper
INFO - 2020-02-24 15:56:22 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:56:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:56:22 --> Parser Class Initialized
INFO - 2020-02-24 15:56:22 --> User Agent Class Initialized
INFO - 2020-02-24 15:56:22 --> Model Class Initialized
INFO - 2020-02-24 15:56:22 --> Database Driver Class Initialized
INFO - 2020-02-24 15:56:22 --> Model Class Initialized
DEBUG - 2020-02-24 15:56:22 --> Template Class Initialized
INFO - 2020-02-24 15:56:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:56:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:56:22 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:56:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:56:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:56:22 --> Encryption Class Initialized
INFO - 2020-02-24 15:56:22 --> Controller Class Initialized
DEBUG - 2020-02-24 15:56:22 --> auth MX_Controller Initialized
DEBUG - 2020-02-24 15:56:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-02-24 15:56:22 --> Model Class Initialized
INFO - 2020-02-24 15:56:27 --> Config Class Initialized
INFO - 2020-02-24 15:56:27 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:56:27 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:56:27 --> Utf8 Class Initialized
INFO - 2020-02-24 15:56:27 --> URI Class Initialized
INFO - 2020-02-24 15:56:27 --> Router Class Initialized
INFO - 2020-02-24 15:56:27 --> Output Class Initialized
INFO - 2020-02-24 15:56:27 --> Security Class Initialized
DEBUG - 2020-02-24 15:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:56:27 --> CSRF cookie sent
INFO - 2020-02-24 15:56:27 --> Input Class Initialized
INFO - 2020-02-24 15:56:27 --> Language Class Initialized
INFO - 2020-02-24 15:56:27 --> Language Class Initialized
INFO - 2020-02-24 15:56:27 --> Config Class Initialized
INFO - 2020-02-24 15:56:27 --> Loader Class Initialized
INFO - 2020-02-24 15:56:27 --> Helper loaded: url_helper
INFO - 2020-02-24 15:56:27 --> Helper loaded: common_helper
INFO - 2020-02-24 15:56:27 --> Helper loaded: language_helper
INFO - 2020-02-24 15:56:27 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:56:27 --> Helper loaded: email_helper
INFO - 2020-02-24 15:56:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:56:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:56:27 --> Parser Class Initialized
INFO - 2020-02-24 15:56:27 --> User Agent Class Initialized
INFO - 2020-02-24 15:56:27 --> Model Class Initialized
INFO - 2020-02-24 15:56:27 --> Database Driver Class Initialized
INFO - 2020-02-24 15:56:27 --> Model Class Initialized
DEBUG - 2020-02-24 15:56:27 --> Template Class Initialized
INFO - 2020-02-24 15:56:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:56:27 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:56:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:56:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:56:27 --> Encryption Class Initialized
INFO - 2020-02-24 15:56:27 --> Controller Class Initialized
DEBUG - 2020-02-24 15:56:27 --> statistics MX_Controller Initialized
DEBUG - 2020-02-24 15:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-02-24 15:56:27 --> Model Class Initialized
ERROR - 2020-02-24 15:56:27 --> Could not find the language line "Pending"
ERROR - 2020-02-24 15:56:27 --> Could not find the language line "Pending"
INFO - 2020-02-24 15:56:27 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 15:56:27 --> Could not find the language line "total_orders"
ERROR - 2020-02-24 15:56:27 --> Could not find the language line "total_orders"
ERROR - 2020-02-24 15:56:27 --> Could not find the language line "Pending"
DEBUG - 2020-02-24 15:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-02-24 15:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 15:56:27 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 15:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 15:56:27 --> Model Class Initialized
DEBUG - 2020-02-24 15:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:56:27 --> Model Class Initialized
DEBUG - 2020-02-24 15:56:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 15:56:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 15:56:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 15:56:28 --> Final output sent to browser
DEBUG - 2020-02-24 15:56:28 --> Total execution time: 1.0243
INFO - 2020-02-24 15:58:00 --> Config Class Initialized
INFO - 2020-02-24 15:58:00 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:58:00 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:58:00 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:00 --> URI Class Initialized
INFO - 2020-02-24 15:58:00 --> Router Class Initialized
INFO - 2020-02-24 15:58:00 --> Output Class Initialized
INFO - 2020-02-24 15:58:00 --> Security Class Initialized
DEBUG - 2020-02-24 15:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:58:00 --> CSRF cookie sent
INFO - 2020-02-24 15:58:00 --> Input Class Initialized
INFO - 2020-02-24 15:58:00 --> Language Class Initialized
INFO - 2020-02-24 15:58:00 --> Language Class Initialized
INFO - 2020-02-24 15:58:00 --> Config Class Initialized
INFO - 2020-02-24 15:58:00 --> Loader Class Initialized
INFO - 2020-02-24 15:58:00 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:00 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:00 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:00 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:00 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:00 --> Parser Class Initialized
INFO - 2020-02-24 15:58:00 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:00 --> Model Class Initialized
INFO - 2020-02-24 15:58:00 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:00 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:00 --> Template Class Initialized
INFO - 2020-02-24 15:58:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:00 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:58:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:00 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:00 --> Controller Class Initialized
DEBUG - 2020-02-24 15:58:00 --> category MX_Controller Initialized
DEBUG - 2020-02-24 15:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:00 --> Model Class Initialized
ERROR - 2020-02-24 15:58:00 --> Could not find the language line "Sorting"
INFO - 2020-02-24 15:58:00 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 15:58:01 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 15:58:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 15:58:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 15:58:01 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 15:58:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 15:58:01 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:01 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:01 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 15:58:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 15:58:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 15:58:01 --> Final output sent to browser
DEBUG - 2020-02-24 15:58:01 --> Total execution time: 0.7609
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Hooks Class Initialized
INFO - 2020-02-24 15:58:01 --> Hooks Class Initialized
INFO - 2020-02-24 15:58:01 --> Hooks Class Initialized
INFO - 2020-02-24 15:58:01 --> Hooks Class Initialized
INFO - 2020-02-24 15:58:01 --> Hooks Class Initialized
INFO - 2020-02-24 15:58:01 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 15:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 15:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 15:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 15:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 15:58:01 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:58:01 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:01 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:01 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:01 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:01 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:01 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:01 --> URI Class Initialized
INFO - 2020-02-24 15:58:01 --> URI Class Initialized
INFO - 2020-02-24 15:58:01 --> URI Class Initialized
INFO - 2020-02-24 15:58:01 --> URI Class Initialized
INFO - 2020-02-24 15:58:01 --> URI Class Initialized
INFO - 2020-02-24 15:58:01 --> URI Class Initialized
INFO - 2020-02-24 15:58:01 --> Router Class Initialized
INFO - 2020-02-24 15:58:01 --> Router Class Initialized
INFO - 2020-02-24 15:58:01 --> Router Class Initialized
INFO - 2020-02-24 15:58:01 --> Router Class Initialized
INFO - 2020-02-24 15:58:01 --> Router Class Initialized
INFO - 2020-02-24 15:58:01 --> Router Class Initialized
INFO - 2020-02-24 15:58:01 --> Output Class Initialized
INFO - 2020-02-24 15:58:01 --> Output Class Initialized
INFO - 2020-02-24 15:58:01 --> Output Class Initialized
INFO - 2020-02-24 15:58:01 --> Output Class Initialized
INFO - 2020-02-24 15:58:01 --> Output Class Initialized
INFO - 2020-02-24 15:58:01 --> Output Class Initialized
INFO - 2020-02-24 15:58:01 --> Security Class Initialized
INFO - 2020-02-24 15:58:01 --> Security Class Initialized
INFO - 2020-02-24 15:58:01 --> Security Class Initialized
INFO - 2020-02-24 15:58:01 --> Security Class Initialized
INFO - 2020-02-24 15:58:01 --> Security Class Initialized
INFO - 2020-02-24 15:58:01 --> Security Class Initialized
DEBUG - 2020-02-24 15:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 15:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 15:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 15:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 15:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:58:01 --> CSRF cookie sent
INFO - 2020-02-24 15:58:01 --> CSRF cookie sent
INFO - 2020-02-24 15:58:01 --> CSRF cookie sent
INFO - 2020-02-24 15:58:01 --> CSRF cookie sent
INFO - 2020-02-24 15:58:01 --> CSRF cookie sent
INFO - 2020-02-24 15:58:01 --> CSRF cookie sent
INFO - 2020-02-24 15:58:01 --> CSRF token verified
INFO - 2020-02-24 15:58:01 --> CSRF token verified
INFO - 2020-02-24 15:58:01 --> CSRF token verified
INFO - 2020-02-24 15:58:01 --> CSRF token verified
INFO - 2020-02-24 15:58:01 --> CSRF token verified
INFO - 2020-02-24 15:58:01 --> CSRF token verified
INFO - 2020-02-24 15:58:01 --> Input Class Initialized
INFO - 2020-02-24 15:58:01 --> Input Class Initialized
INFO - 2020-02-24 15:58:01 --> Input Class Initialized
INFO - 2020-02-24 15:58:01 --> Input Class Initialized
INFO - 2020-02-24 15:58:01 --> Input Class Initialized
INFO - 2020-02-24 15:58:01 --> Input Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Language Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Config Class Initialized
INFO - 2020-02-24 15:58:01 --> Loader Class Initialized
INFO - 2020-02-24 15:58:01 --> Loader Class Initialized
INFO - 2020-02-24 15:58:01 --> Loader Class Initialized
INFO - 2020-02-24 15:58:01 --> Loader Class Initialized
INFO - 2020-02-24 15:58:01 --> Loader Class Initialized
INFO - 2020-02-24 15:58:01 --> Loader Class Initialized
INFO - 2020-02-24 15:58:01 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:01 --> Parser Class Initialized
INFO - 2020-02-24 15:58:01 --> Parser Class Initialized
INFO - 2020-02-24 15:58:01 --> Parser Class Initialized
INFO - 2020-02-24 15:58:01 --> Parser Class Initialized
INFO - 2020-02-24 15:58:01 --> Parser Class Initialized
INFO - 2020-02-24 15:58:01 --> Parser Class Initialized
INFO - 2020-02-24 15:58:01 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:01 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:01 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:01 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:01 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:01 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:01 --> Model Class Initialized
INFO - 2020-02-24 15:58:01 --> Model Class Initialized
INFO - 2020-02-24 15:58:01 --> Model Class Initialized
INFO - 2020-02-24 15:58:01 --> Model Class Initialized
INFO - 2020-02-24 15:58:01 --> Model Class Initialized
INFO - 2020-02-24 15:58:01 --> Model Class Initialized
INFO - 2020-02-24 15:58:01 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:01 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:01 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:01 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:01 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:01 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Template Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Template Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Template Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Template Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Template Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Template Class Initialized
INFO - 2020-02-24 15:58:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:02 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:02 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:02 --> Controller Class Initialized
DEBUG - 2020-02-24 15:58:02 --> category MX_Controller Initialized
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 15:58:02 --> Final output sent to browser
DEBUG - 2020-02-24 15:58:02 --> Total execution time: 0.6235
INFO - 2020-02-24 15:58:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:02 --> Config Class Initialized
INFO - 2020-02-24 15:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:02 --> Pagination Class Initialized
INFO - 2020-02-24 15:58:02 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-02-24 15:58:02 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:58:02 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:02 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:02 --> URI Class Initialized
INFO - 2020-02-24 15:58:02 --> Controller Class Initialized
INFO - 2020-02-24 15:58:02 --> Router Class Initialized
DEBUG - 2020-02-24 15:58:02 --> category MX_Controller Initialized
INFO - 2020-02-24 15:58:02 --> Output Class Initialized
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:02 --> Security Class Initialized
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:58:02 --> CSRF cookie sent
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "Sorting"
INFO - 2020-02-24 15:58:02 --> CSRF token verified
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
INFO - 2020-02-24 15:58:02 --> Input Class Initialized
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 15:58:02 --> Final output sent to browser
INFO - 2020-02-24 15:58:02 --> Language Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Total execution time: 0.7858
INFO - 2020-02-24 15:58:02 --> Language Class Initialized
INFO - 2020-02-24 15:58:02 --> Config Class Initialized
INFO - 2020-02-24 15:58:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:02 --> Loader Class Initialized
INFO - 2020-02-24 15:58:02 --> Pagination Class Initialized
INFO - 2020-02-24 15:58:02 --> Helper loaded: url_helper
DEBUG - 2020-02-24 15:58:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:02 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:02 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:02 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:02 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:02 --> Controller Class Initialized
INFO - 2020-02-24 15:58:02 --> Helper loaded: email_helper
DEBUG - 2020-02-24 15:58:02 --> category MX_Controller Initialized
INFO - 2020-02-24 15:58:02 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
INFO - 2020-02-24 15:58:02 --> Parser Class Initialized
INFO - 2020-02-24 15:58:02 --> User Agent Class Initialized
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "Sorting"
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
INFO - 2020-02-24 15:58:02 --> Database Driver Class Initialized
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Template Class Initialized
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 15:58:02 --> Final output sent to browser
DEBUG - 2020-02-24 15:58:02 --> Total execution time: 0.9976
INFO - 2020-02-24 15:58:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:02 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:02 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:02 --> Controller Class Initialized
DEBUG - 2020-02-24 15:58:02 --> category MX_Controller Initialized
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 15:58:02 --> Final output sent to browser
DEBUG - 2020-02-24 15:58:02 --> Total execution time: 1.1862
INFO - 2020-02-24 15:58:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:02 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:58:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:02 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:02 --> Controller Class Initialized
DEBUG - 2020-02-24 15:58:02 --> category MX_Controller Initialized
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:02 --> Model Class Initialized
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 15:58:02 --> Could not find the language line "View"
DEBUG - 2020-02-24 15:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 15:58:02 --> Final output sent to browser
DEBUG - 2020-02-24 15:58:03 --> Total execution time: 1.3553
INFO - 2020-02-24 15:58:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:03 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:58:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:03 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:03 --> Controller Class Initialized
DEBUG - 2020-02-24 15:58:03 --> category MX_Controller Initialized
DEBUG - 2020-02-24 15:58:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:03 --> Model Class Initialized
ERROR - 2020-02-24 15:58:03 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 15:58:03 --> Could not find the language line "View"
DEBUG - 2020-02-24 15:58:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 15:58:03 --> Final output sent to browser
DEBUG - 2020-02-24 15:58:03 --> Total execution time: 1.5353
INFO - 2020-02-24 15:58:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:03 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:58:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:03 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:03 --> Controller Class Initialized
DEBUG - 2020-02-24 15:58:03 --> category MX_Controller Initialized
DEBUG - 2020-02-24 15:58:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:03 --> Model Class Initialized
ERROR - 2020-02-24 15:58:03 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 15:58:03 --> Could not find the language line "View"
DEBUG - 2020-02-24 15:58:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 15:58:03 --> Final output sent to browser
DEBUG - 2020-02-24 15:58:03 --> Total execution time: 1.0642
INFO - 2020-02-24 15:58:04 --> Config Class Initialized
INFO - 2020-02-24 15:58:04 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:58:04 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:58:04 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:04 --> URI Class Initialized
INFO - 2020-02-24 15:58:04 --> Router Class Initialized
INFO - 2020-02-24 15:58:04 --> Output Class Initialized
INFO - 2020-02-24 15:58:04 --> Security Class Initialized
DEBUG - 2020-02-24 15:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:58:04 --> CSRF cookie sent
INFO - 2020-02-24 15:58:04 --> Input Class Initialized
INFO - 2020-02-24 15:58:04 --> Language Class Initialized
INFO - 2020-02-24 15:58:04 --> Language Class Initialized
INFO - 2020-02-24 15:58:04 --> Config Class Initialized
INFO - 2020-02-24 15:58:04 --> Loader Class Initialized
INFO - 2020-02-24 15:58:04 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:04 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:04 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:04 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:04 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:04 --> Parser Class Initialized
INFO - 2020-02-24 15:58:04 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:04 --> Model Class Initialized
INFO - 2020-02-24 15:58:04 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:04 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:04 --> Template Class Initialized
INFO - 2020-02-24 15:58:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:04 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:58:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:04 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:04 --> Controller Class Initialized
DEBUG - 2020-02-24 15:58:04 --> category MX_Controller Initialized
DEBUG - 2020-02-24 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:04 --> Model Class Initialized
ERROR - 2020-02-24 15:58:04 --> Could not find the language line "Sorting"
INFO - 2020-02-24 15:58:04 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 15:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 15:58:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 15:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 15:58:05 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:05 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 15:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 15:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 15:58:05 --> Final output sent to browser
DEBUG - 2020-02-24 15:58:05 --> Total execution time: 0.8577
INFO - 2020-02-24 15:58:14 --> Config Class Initialized
INFO - 2020-02-24 15:58:14 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:58:14 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:58:14 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:14 --> URI Class Initialized
INFO - 2020-02-24 15:58:14 --> Router Class Initialized
INFO - 2020-02-24 15:58:14 --> Output Class Initialized
INFO - 2020-02-24 15:58:14 --> Security Class Initialized
DEBUG - 2020-02-24 15:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:58:14 --> CSRF cookie sent
INFO - 2020-02-24 15:58:14 --> CSRF token verified
INFO - 2020-02-24 15:58:14 --> Input Class Initialized
INFO - 2020-02-24 15:58:14 --> Language Class Initialized
INFO - 2020-02-24 15:58:14 --> Language Class Initialized
INFO - 2020-02-24 15:58:14 --> Config Class Initialized
INFO - 2020-02-24 15:58:14 --> Loader Class Initialized
INFO - 2020-02-24 15:58:14 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:14 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:14 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:14 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:14 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:14 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:14 --> Parser Class Initialized
INFO - 2020-02-24 15:58:14 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:14 --> Model Class Initialized
INFO - 2020-02-24 15:58:14 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:14 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:14 --> Template Class Initialized
INFO - 2020-02-24 15:58:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:14 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:58:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:14 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:14 --> Controller Class Initialized
DEBUG - 2020-02-24 15:58:14 --> category MX_Controller Initialized
DEBUG - 2020-02-24 15:58:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:14 --> Model Class Initialized
ERROR - 2020-02-24 15:58:14 --> Could not find the language line "Sorting"
INFO - 2020-02-24 15:58:50 --> Config Class Initialized
INFO - 2020-02-24 15:58:50 --> Hooks Class Initialized
DEBUG - 2020-02-24 15:58:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 15:58:50 --> Utf8 Class Initialized
INFO - 2020-02-24 15:58:50 --> URI Class Initialized
INFO - 2020-02-24 15:58:50 --> Router Class Initialized
INFO - 2020-02-24 15:58:50 --> Output Class Initialized
INFO - 2020-02-24 15:58:50 --> Security Class Initialized
DEBUG - 2020-02-24 15:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 15:58:50 --> CSRF cookie sent
INFO - 2020-02-24 15:58:50 --> CSRF token verified
INFO - 2020-02-24 15:58:50 --> Input Class Initialized
INFO - 2020-02-24 15:58:50 --> Language Class Initialized
INFO - 2020-02-24 15:58:50 --> Language Class Initialized
INFO - 2020-02-24 15:58:50 --> Config Class Initialized
INFO - 2020-02-24 15:58:50 --> Loader Class Initialized
INFO - 2020-02-24 15:58:50 --> Helper loaded: url_helper
INFO - 2020-02-24 15:58:50 --> Helper loaded: common_helper
INFO - 2020-02-24 15:58:50 --> Helper loaded: language_helper
INFO - 2020-02-24 15:58:50 --> Helper loaded: cookie_helper
INFO - 2020-02-24 15:58:50 --> Helper loaded: email_helper
INFO - 2020-02-24 15:58:50 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 15:58:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 15:58:50 --> Parser Class Initialized
INFO - 2020-02-24 15:58:50 --> User Agent Class Initialized
INFO - 2020-02-24 15:58:50 --> Model Class Initialized
INFO - 2020-02-24 15:58:50 --> Database Driver Class Initialized
INFO - 2020-02-24 15:58:50 --> Model Class Initialized
DEBUG - 2020-02-24 15:58:50 --> Template Class Initialized
INFO - 2020-02-24 15:58:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 15:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 15:58:50 --> Pagination Class Initialized
DEBUG - 2020-02-24 15:58:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 15:58:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 15:58:50 --> Encryption Class Initialized
INFO - 2020-02-24 15:58:50 --> Controller Class Initialized
DEBUG - 2020-02-24 15:58:50 --> category MX_Controller Initialized
DEBUG - 2020-02-24 15:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 15:58:50 --> Model Class Initialized
ERROR - 2020-02-24 15:58:50 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:01:49 --> Config Class Initialized
INFO - 2020-02-24 16:01:49 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:01:49 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:01:49 --> Utf8 Class Initialized
INFO - 2020-02-24 16:01:49 --> URI Class Initialized
INFO - 2020-02-24 16:01:49 --> Router Class Initialized
INFO - 2020-02-24 16:01:49 --> Output Class Initialized
INFO - 2020-02-24 16:01:49 --> Security Class Initialized
DEBUG - 2020-02-24 16:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:01:49 --> CSRF cookie sent
INFO - 2020-02-24 16:01:49 --> Input Class Initialized
INFO - 2020-02-24 16:01:49 --> Language Class Initialized
INFO - 2020-02-24 16:01:49 --> Language Class Initialized
INFO - 2020-02-24 16:01:49 --> Config Class Initialized
INFO - 2020-02-24 16:01:49 --> Loader Class Initialized
INFO - 2020-02-24 16:01:49 --> Helper loaded: url_helper
INFO - 2020-02-24 16:01:49 --> Helper loaded: common_helper
INFO - 2020-02-24 16:01:49 --> Helper loaded: language_helper
INFO - 2020-02-24 16:01:49 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:01:49 --> Helper loaded: email_helper
INFO - 2020-02-24 16:01:49 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:01:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:01:49 --> Parser Class Initialized
INFO - 2020-02-24 16:01:49 --> User Agent Class Initialized
INFO - 2020-02-24 16:01:49 --> Model Class Initialized
INFO - 2020-02-24 16:01:49 --> Database Driver Class Initialized
INFO - 2020-02-24 16:01:49 --> Model Class Initialized
DEBUG - 2020-02-24 16:01:49 --> Template Class Initialized
INFO - 2020-02-24 16:01:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:01:49 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:01:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:01:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:01:49 --> Encryption Class Initialized
INFO - 2020-02-24 16:01:49 --> Controller Class Initialized
DEBUG - 2020-02-24 16:01:49 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:01:49 --> Model Class Initialized
ERROR - 2020-02-24 16:01:49 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:01:49 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:01:49 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:01:49 --> Model Class Initialized
DEBUG - 2020-02-24 16:01:49 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:01:49 --> Model Class Initialized
DEBUG - 2020-02-24 16:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:01:50 --> Final output sent to browser
DEBUG - 2020-02-24 16:01:50 --> Total execution time: 0.7876
INFO - 2020-02-24 16:02:40 --> Config Class Initialized
INFO - 2020-02-24 16:02:40 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:02:40 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:02:40 --> Utf8 Class Initialized
INFO - 2020-02-24 16:02:40 --> URI Class Initialized
INFO - 2020-02-24 16:02:40 --> Router Class Initialized
INFO - 2020-02-24 16:02:40 --> Output Class Initialized
INFO - 2020-02-24 16:02:40 --> Security Class Initialized
DEBUG - 2020-02-24 16:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:02:40 --> CSRF cookie sent
INFO - 2020-02-24 16:02:40 --> Input Class Initialized
INFO - 2020-02-24 16:02:40 --> Language Class Initialized
INFO - 2020-02-24 16:02:40 --> Language Class Initialized
INFO - 2020-02-24 16:02:40 --> Config Class Initialized
INFO - 2020-02-24 16:02:40 --> Loader Class Initialized
INFO - 2020-02-24 16:02:40 --> Helper loaded: url_helper
INFO - 2020-02-24 16:02:40 --> Helper loaded: common_helper
INFO - 2020-02-24 16:02:40 --> Helper loaded: language_helper
INFO - 2020-02-24 16:02:40 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:02:40 --> Helper loaded: email_helper
INFO - 2020-02-24 16:02:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:02:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:02:40 --> Parser Class Initialized
INFO - 2020-02-24 16:02:40 --> User Agent Class Initialized
INFO - 2020-02-24 16:02:40 --> Model Class Initialized
INFO - 2020-02-24 16:02:40 --> Database Driver Class Initialized
INFO - 2020-02-24 16:02:40 --> Model Class Initialized
DEBUG - 2020-02-24 16:02:40 --> Template Class Initialized
INFO - 2020-02-24 16:02:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:02:40 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:02:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:02:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:02:40 --> Encryption Class Initialized
INFO - 2020-02-24 16:02:40 --> Controller Class Initialized
DEBUG - 2020-02-24 16:02:40 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:02:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:02:40 --> Model Class Initialized
ERROR - 2020-02-24 16:02:40 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:02:40 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:02:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:02:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:02:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:02:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:02:40 --> Model Class Initialized
DEBUG - 2020-02-24 16:02:40 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:02:40 --> Model Class Initialized
DEBUG - 2020-02-24 16:02:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:02:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:02:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:02:41 --> Final output sent to browser
DEBUG - 2020-02-24 16:02:41 --> Total execution time: 0.7280
INFO - 2020-02-24 16:03:14 --> Config Class Initialized
INFO - 2020-02-24 16:03:14 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:03:14 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:03:14 --> Utf8 Class Initialized
INFO - 2020-02-24 16:03:14 --> URI Class Initialized
INFO - 2020-02-24 16:03:14 --> Router Class Initialized
INFO - 2020-02-24 16:03:14 --> Output Class Initialized
INFO - 2020-02-24 16:03:14 --> Security Class Initialized
DEBUG - 2020-02-24 16:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:03:14 --> CSRF cookie sent
INFO - 2020-02-24 16:03:14 --> Input Class Initialized
INFO - 2020-02-24 16:03:14 --> Language Class Initialized
INFO - 2020-02-24 16:03:14 --> Language Class Initialized
INFO - 2020-02-24 16:03:14 --> Config Class Initialized
INFO - 2020-02-24 16:03:14 --> Loader Class Initialized
INFO - 2020-02-24 16:03:14 --> Helper loaded: url_helper
INFO - 2020-02-24 16:03:14 --> Helper loaded: common_helper
INFO - 2020-02-24 16:03:14 --> Helper loaded: language_helper
INFO - 2020-02-24 16:03:14 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:03:14 --> Helper loaded: email_helper
INFO - 2020-02-24 16:03:14 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:03:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:03:14 --> Parser Class Initialized
INFO - 2020-02-24 16:03:14 --> User Agent Class Initialized
INFO - 2020-02-24 16:03:14 --> Model Class Initialized
INFO - 2020-02-24 16:03:14 --> Database Driver Class Initialized
INFO - 2020-02-24 16:03:14 --> Model Class Initialized
DEBUG - 2020-02-24 16:03:14 --> Template Class Initialized
INFO - 2020-02-24 16:03:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:03:14 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:03:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:03:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:03:14 --> Encryption Class Initialized
INFO - 2020-02-24 16:03:14 --> Controller Class Initialized
DEBUG - 2020-02-24 16:03:14 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:03:14 --> Model Class Initialized
ERROR - 2020-02-24 16:03:14 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:03:14 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:03:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:03:14 --> Model Class Initialized
DEBUG - 2020-02-24 16:03:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:03:14 --> Model Class Initialized
DEBUG - 2020-02-24 16:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:03:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:03:15 --> Final output sent to browser
DEBUG - 2020-02-24 16:03:15 --> Total execution time: 0.7372
INFO - 2020-02-24 16:03:42 --> Config Class Initialized
INFO - 2020-02-24 16:03:42 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:03:42 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:03:42 --> Utf8 Class Initialized
INFO - 2020-02-24 16:03:42 --> URI Class Initialized
INFO - 2020-02-24 16:03:42 --> Router Class Initialized
INFO - 2020-02-24 16:03:42 --> Output Class Initialized
INFO - 2020-02-24 16:03:42 --> Security Class Initialized
DEBUG - 2020-02-24 16:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:03:42 --> CSRF cookie sent
INFO - 2020-02-24 16:03:42 --> Input Class Initialized
INFO - 2020-02-24 16:03:42 --> Language Class Initialized
INFO - 2020-02-24 16:03:42 --> Language Class Initialized
INFO - 2020-02-24 16:03:42 --> Config Class Initialized
INFO - 2020-02-24 16:03:42 --> Loader Class Initialized
INFO - 2020-02-24 16:03:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:03:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:03:42 --> Helper loaded: language_helper
INFO - 2020-02-24 16:03:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:03:42 --> Helper loaded: email_helper
INFO - 2020-02-24 16:03:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:03:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:03:42 --> Parser Class Initialized
INFO - 2020-02-24 16:03:42 --> User Agent Class Initialized
INFO - 2020-02-24 16:03:42 --> Model Class Initialized
INFO - 2020-02-24 16:03:42 --> Database Driver Class Initialized
INFO - 2020-02-24 16:03:42 --> Model Class Initialized
DEBUG - 2020-02-24 16:03:42 --> Template Class Initialized
INFO - 2020-02-24 16:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:03:42 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:03:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:03:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:03:42 --> Encryption Class Initialized
INFO - 2020-02-24 16:03:42 --> Controller Class Initialized
DEBUG - 2020-02-24 16:03:42 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:03:42 --> Model Class Initialized
ERROR - 2020-02-24 16:03:42 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:03:42 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:03:42 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:03:42 --> Model Class Initialized
DEBUG - 2020-02-24 16:03:42 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:03:42 --> Model Class Initialized
DEBUG - 2020-02-24 16:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:03:42 --> Final output sent to browser
DEBUG - 2020-02-24 16:03:42 --> Total execution time: 0.6855
INFO - 2020-02-24 16:05:16 --> Config Class Initialized
INFO - 2020-02-24 16:05:16 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:05:16 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:05:16 --> Utf8 Class Initialized
INFO - 2020-02-24 16:05:16 --> URI Class Initialized
INFO - 2020-02-24 16:05:16 --> Router Class Initialized
INFO - 2020-02-24 16:05:16 --> Output Class Initialized
INFO - 2020-02-24 16:05:16 --> Security Class Initialized
DEBUG - 2020-02-24 16:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:05:16 --> CSRF cookie sent
INFO - 2020-02-24 16:05:16 --> Input Class Initialized
INFO - 2020-02-24 16:05:16 --> Language Class Initialized
INFO - 2020-02-24 16:05:16 --> Language Class Initialized
INFO - 2020-02-24 16:05:16 --> Config Class Initialized
INFO - 2020-02-24 16:05:16 --> Loader Class Initialized
INFO - 2020-02-24 16:05:16 --> Helper loaded: url_helper
INFO - 2020-02-24 16:05:16 --> Helper loaded: common_helper
INFO - 2020-02-24 16:05:16 --> Helper loaded: language_helper
INFO - 2020-02-24 16:05:16 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:05:16 --> Helper loaded: email_helper
INFO - 2020-02-24 16:05:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:05:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:05:16 --> Parser Class Initialized
INFO - 2020-02-24 16:05:16 --> User Agent Class Initialized
INFO - 2020-02-24 16:05:16 --> Model Class Initialized
INFO - 2020-02-24 16:05:16 --> Database Driver Class Initialized
INFO - 2020-02-24 16:05:16 --> Model Class Initialized
DEBUG - 2020-02-24 16:05:16 --> Template Class Initialized
INFO - 2020-02-24 16:05:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:05:16 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:05:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:05:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:05:16 --> Encryption Class Initialized
INFO - 2020-02-24 16:05:16 --> Controller Class Initialized
DEBUG - 2020-02-24 16:05:16 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:05:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:05:16 --> Model Class Initialized
ERROR - 2020-02-24 16:05:16 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:05:16 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:05:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:05:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:05:16 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:05:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:05:16 --> Model Class Initialized
DEBUG - 2020-02-24 16:05:16 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:05:16 --> Model Class Initialized
DEBUG - 2020-02-24 16:05:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:05:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:05:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:05:17 --> Final output sent to browser
DEBUG - 2020-02-24 16:05:17 --> Total execution time: 0.6601
INFO - 2020-02-24 16:05:32 --> Config Class Initialized
INFO - 2020-02-24 16:05:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:05:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:05:32 --> Utf8 Class Initialized
INFO - 2020-02-24 16:05:32 --> URI Class Initialized
INFO - 2020-02-24 16:05:32 --> Router Class Initialized
INFO - 2020-02-24 16:05:32 --> Output Class Initialized
INFO - 2020-02-24 16:05:32 --> Security Class Initialized
DEBUG - 2020-02-24 16:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:05:32 --> CSRF cookie sent
INFO - 2020-02-24 16:05:32 --> Input Class Initialized
INFO - 2020-02-24 16:05:32 --> Language Class Initialized
INFO - 2020-02-24 16:05:32 --> Language Class Initialized
INFO - 2020-02-24 16:05:33 --> Config Class Initialized
INFO - 2020-02-24 16:05:33 --> Loader Class Initialized
INFO - 2020-02-24 16:05:33 --> Helper loaded: url_helper
INFO - 2020-02-24 16:05:33 --> Helper loaded: common_helper
INFO - 2020-02-24 16:05:33 --> Helper loaded: language_helper
INFO - 2020-02-24 16:05:33 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:05:33 --> Helper loaded: email_helper
INFO - 2020-02-24 16:05:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:05:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:05:33 --> Parser Class Initialized
INFO - 2020-02-24 16:05:33 --> User Agent Class Initialized
INFO - 2020-02-24 16:05:33 --> Model Class Initialized
INFO - 2020-02-24 16:05:33 --> Database Driver Class Initialized
INFO - 2020-02-24 16:05:33 --> Model Class Initialized
DEBUG - 2020-02-24 16:05:33 --> Template Class Initialized
INFO - 2020-02-24 16:05:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:05:33 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:05:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:05:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:05:33 --> Encryption Class Initialized
INFO - 2020-02-24 16:05:33 --> Controller Class Initialized
DEBUG - 2020-02-24 16:05:33 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:05:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:05:33 --> Model Class Initialized
ERROR - 2020-02-24 16:05:33 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:05:33 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:05:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:05:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:05:33 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:05:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:05:33 --> Model Class Initialized
DEBUG - 2020-02-24 16:05:33 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:05:33 --> Model Class Initialized
DEBUG - 2020-02-24 16:05:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:05:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:05:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:05:33 --> Final output sent to browser
DEBUG - 2020-02-24 16:05:33 --> Total execution time: 0.7532
INFO - 2020-02-24 16:06:33 --> Config Class Initialized
INFO - 2020-02-24 16:06:33 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:06:33 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:06:33 --> Utf8 Class Initialized
INFO - 2020-02-24 16:06:33 --> URI Class Initialized
INFO - 2020-02-24 16:06:33 --> Router Class Initialized
INFO - 2020-02-24 16:06:33 --> Output Class Initialized
INFO - 2020-02-24 16:06:33 --> Security Class Initialized
DEBUG - 2020-02-24 16:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:06:33 --> CSRF cookie sent
INFO - 2020-02-24 16:06:33 --> Input Class Initialized
INFO - 2020-02-24 16:06:33 --> Language Class Initialized
INFO - 2020-02-24 16:06:33 --> Language Class Initialized
INFO - 2020-02-24 16:06:33 --> Config Class Initialized
INFO - 2020-02-24 16:06:33 --> Loader Class Initialized
INFO - 2020-02-24 16:06:33 --> Helper loaded: url_helper
INFO - 2020-02-24 16:06:33 --> Helper loaded: common_helper
INFO - 2020-02-24 16:06:33 --> Helper loaded: language_helper
INFO - 2020-02-24 16:06:33 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:06:33 --> Helper loaded: email_helper
INFO - 2020-02-24 16:06:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:06:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:06:33 --> Parser Class Initialized
INFO - 2020-02-24 16:06:33 --> User Agent Class Initialized
INFO - 2020-02-24 16:06:33 --> Model Class Initialized
INFO - 2020-02-24 16:06:33 --> Database Driver Class Initialized
INFO - 2020-02-24 16:06:33 --> Model Class Initialized
DEBUG - 2020-02-24 16:06:33 --> Template Class Initialized
INFO - 2020-02-24 16:06:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:06:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:06:33 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:06:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:06:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:06:33 --> Encryption Class Initialized
INFO - 2020-02-24 16:06:33 --> Controller Class Initialized
DEBUG - 2020-02-24 16:06:33 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:06:33 --> Model Class Initialized
ERROR - 2020-02-24 16:06:33 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:06:33 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:06:33 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:06:34 --> Model Class Initialized
DEBUG - 2020-02-24 16:06:34 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:06:34 --> Model Class Initialized
DEBUG - 2020-02-24 16:06:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:06:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:06:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:06:34 --> Final output sent to browser
DEBUG - 2020-02-24 16:06:34 --> Total execution time: 0.6814
INFO - 2020-02-24 16:06:45 --> Config Class Initialized
INFO - 2020-02-24 16:06:45 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:06:45 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:06:45 --> Utf8 Class Initialized
INFO - 2020-02-24 16:06:45 --> URI Class Initialized
INFO - 2020-02-24 16:06:45 --> Router Class Initialized
INFO - 2020-02-24 16:06:45 --> Output Class Initialized
INFO - 2020-02-24 16:06:45 --> Security Class Initialized
DEBUG - 2020-02-24 16:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:06:46 --> CSRF cookie sent
INFO - 2020-02-24 16:06:46 --> CSRF token verified
INFO - 2020-02-24 16:06:46 --> Input Class Initialized
INFO - 2020-02-24 16:06:46 --> Language Class Initialized
INFO - 2020-02-24 16:06:46 --> Language Class Initialized
INFO - 2020-02-24 16:06:46 --> Config Class Initialized
INFO - 2020-02-24 16:06:46 --> Loader Class Initialized
INFO - 2020-02-24 16:06:46 --> Helper loaded: url_helper
INFO - 2020-02-24 16:06:46 --> Helper loaded: common_helper
INFO - 2020-02-24 16:06:46 --> Helper loaded: language_helper
INFO - 2020-02-24 16:06:46 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:06:46 --> Helper loaded: email_helper
INFO - 2020-02-24 16:06:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:06:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:06:46 --> Parser Class Initialized
INFO - 2020-02-24 16:06:46 --> User Agent Class Initialized
INFO - 2020-02-24 16:06:46 --> Model Class Initialized
INFO - 2020-02-24 16:06:46 --> Database Driver Class Initialized
INFO - 2020-02-24 16:06:46 --> Model Class Initialized
DEBUG - 2020-02-24 16:06:46 --> Template Class Initialized
INFO - 2020-02-24 16:06:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:06:46 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:06:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:06:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:06:46 --> Encryption Class Initialized
INFO - 2020-02-24 16:06:46 --> Controller Class Initialized
DEBUG - 2020-02-24 16:06:46 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:06:46 --> Model Class Initialized
ERROR - 2020-02-24 16:06:46 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:06:50 --> Config Class Initialized
INFO - 2020-02-24 16:06:50 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:06:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:06:50 --> Utf8 Class Initialized
INFO - 2020-02-24 16:06:51 --> URI Class Initialized
INFO - 2020-02-24 16:06:51 --> Router Class Initialized
INFO - 2020-02-24 16:06:51 --> Output Class Initialized
INFO - 2020-02-24 16:06:51 --> Security Class Initialized
DEBUG - 2020-02-24 16:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:06:51 --> CSRF cookie sent
INFO - 2020-02-24 16:06:51 --> Input Class Initialized
INFO - 2020-02-24 16:06:51 --> Language Class Initialized
INFO - 2020-02-24 16:06:51 --> Language Class Initialized
INFO - 2020-02-24 16:06:51 --> Config Class Initialized
INFO - 2020-02-24 16:06:51 --> Loader Class Initialized
INFO - 2020-02-24 16:06:51 --> Helper loaded: url_helper
INFO - 2020-02-24 16:06:51 --> Helper loaded: common_helper
INFO - 2020-02-24 16:06:51 --> Helper loaded: language_helper
INFO - 2020-02-24 16:06:51 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:06:51 --> Helper loaded: email_helper
INFO - 2020-02-24 16:06:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:06:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:06:51 --> Parser Class Initialized
INFO - 2020-02-24 16:06:51 --> User Agent Class Initialized
INFO - 2020-02-24 16:06:51 --> Model Class Initialized
INFO - 2020-02-24 16:06:51 --> Database Driver Class Initialized
INFO - 2020-02-24 16:06:51 --> Model Class Initialized
DEBUG - 2020-02-24 16:06:51 --> Template Class Initialized
INFO - 2020-02-24 16:06:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:06:51 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:06:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:06:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:06:51 --> Encryption Class Initialized
INFO - 2020-02-24 16:06:51 --> Controller Class Initialized
DEBUG - 2020-02-24 16:06:51 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:06:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:06:51 --> Model Class Initialized
ERROR - 2020-02-24 16:06:51 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:06:51 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:06:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:06:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:06:51 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:06:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:06:51 --> Model Class Initialized
DEBUG - 2020-02-24 16:06:51 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:06:51 --> Model Class Initialized
DEBUG - 2020-02-24 16:06:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:06:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:06:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:06:51 --> Final output sent to browser
DEBUG - 2020-02-24 16:06:51 --> Total execution time: 0.6969
INFO - 2020-02-24 16:13:31 --> Config Class Initialized
INFO - 2020-02-24 16:13:31 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:13:31 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:13:31 --> Utf8 Class Initialized
INFO - 2020-02-24 16:13:31 --> URI Class Initialized
INFO - 2020-02-24 16:13:31 --> Router Class Initialized
INFO - 2020-02-24 16:13:31 --> Output Class Initialized
INFO - 2020-02-24 16:13:31 --> Security Class Initialized
DEBUG - 2020-02-24 16:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:13:31 --> CSRF cookie sent
INFO - 2020-02-24 16:13:31 --> Input Class Initialized
INFO - 2020-02-24 16:13:31 --> Language Class Initialized
INFO - 2020-02-24 16:13:31 --> Language Class Initialized
INFO - 2020-02-24 16:13:31 --> Config Class Initialized
INFO - 2020-02-24 16:13:31 --> Loader Class Initialized
INFO - 2020-02-24 16:13:31 --> Helper loaded: url_helper
INFO - 2020-02-24 16:13:31 --> Helper loaded: common_helper
INFO - 2020-02-24 16:13:31 --> Helper loaded: language_helper
INFO - 2020-02-24 16:13:31 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:13:31 --> Helper loaded: email_helper
INFO - 2020-02-24 16:13:31 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:13:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:13:32 --> Parser Class Initialized
INFO - 2020-02-24 16:13:32 --> User Agent Class Initialized
INFO - 2020-02-24 16:13:32 --> Model Class Initialized
INFO - 2020-02-24 16:13:32 --> Database Driver Class Initialized
INFO - 2020-02-24 16:13:32 --> Model Class Initialized
DEBUG - 2020-02-24 16:13:32 --> Template Class Initialized
INFO - 2020-02-24 16:13:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:13:32 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:13:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:13:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:13:32 --> Encryption Class Initialized
INFO - 2020-02-24 16:13:32 --> Controller Class Initialized
DEBUG - 2020-02-24 16:13:32 --> client MX_Controller Initialized
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/models/client_model.php
INFO - 2020-02-24 16:13:32 --> Model Class Initialized
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/models/faqs_model.php
INFO - 2020-02-24 16:13:32 --> Model Class Initialized
INFO - 2020-02-24 16:13:32 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:13:32 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:13:32 --> Model Class Initialized
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:13:32 --> Model Class Initialized
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/faq/index.php
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-24 16:13:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-24 16:13:32 --> Final output sent to browser
DEBUG - 2020-02-24 16:13:32 --> Total execution time: 0.9215
INFO - 2020-02-24 16:17:41 --> Config Class Initialized
INFO - 2020-02-24 16:17:41 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:17:41 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:17:41 --> Utf8 Class Initialized
INFO - 2020-02-24 16:17:41 --> URI Class Initialized
INFO - 2020-02-24 16:17:41 --> Router Class Initialized
INFO - 2020-02-24 16:17:41 --> Output Class Initialized
INFO - 2020-02-24 16:17:41 --> Security Class Initialized
DEBUG - 2020-02-24 16:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:17:41 --> CSRF cookie sent
INFO - 2020-02-24 16:17:41 --> CSRF token verified
INFO - 2020-02-24 16:17:41 --> Input Class Initialized
INFO - 2020-02-24 16:17:41 --> Language Class Initialized
INFO - 2020-02-24 16:17:41 --> Language Class Initialized
INFO - 2020-02-24 16:17:41 --> Config Class Initialized
INFO - 2020-02-24 16:17:41 --> Loader Class Initialized
INFO - 2020-02-24 16:17:41 --> Helper loaded: url_helper
INFO - 2020-02-24 16:17:41 --> Helper loaded: common_helper
INFO - 2020-02-24 16:17:41 --> Helper loaded: language_helper
INFO - 2020-02-24 16:17:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:17:41 --> Helper loaded: email_helper
INFO - 2020-02-24 16:17:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:17:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:17:41 --> Parser Class Initialized
INFO - 2020-02-24 16:17:41 --> User Agent Class Initialized
INFO - 2020-02-24 16:17:41 --> Model Class Initialized
INFO - 2020-02-24 16:17:41 --> Database Driver Class Initialized
INFO - 2020-02-24 16:17:41 --> Model Class Initialized
DEBUG - 2020-02-24 16:17:41 --> Template Class Initialized
INFO - 2020-02-24 16:17:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:17:41 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:17:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:17:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:17:41 --> Encryption Class Initialized
INFO - 2020-02-24 16:17:41 --> Controller Class Initialized
DEBUG - 2020-02-24 16:17:41 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:17:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:17:42 --> Model Class Initialized
ERROR - 2020-02-24 16:17:42 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:17:47 --> Config Class Initialized
INFO - 2020-02-24 16:17:47 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:17:47 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:17:47 --> Utf8 Class Initialized
INFO - 2020-02-24 16:17:47 --> URI Class Initialized
INFO - 2020-02-24 16:17:47 --> Router Class Initialized
INFO - 2020-02-24 16:17:47 --> Output Class Initialized
INFO - 2020-02-24 16:17:47 --> Security Class Initialized
DEBUG - 2020-02-24 16:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:17:47 --> CSRF cookie sent
INFO - 2020-02-24 16:17:47 --> Input Class Initialized
INFO - 2020-02-24 16:17:47 --> Language Class Initialized
INFO - 2020-02-24 16:17:47 --> Language Class Initialized
INFO - 2020-02-24 16:17:47 --> Config Class Initialized
INFO - 2020-02-24 16:17:47 --> Loader Class Initialized
INFO - 2020-02-24 16:17:47 --> Helper loaded: url_helper
INFO - 2020-02-24 16:17:47 --> Helper loaded: common_helper
INFO - 2020-02-24 16:17:47 --> Helper loaded: language_helper
INFO - 2020-02-24 16:17:47 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:17:47 --> Helper loaded: email_helper
INFO - 2020-02-24 16:17:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:17:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:17:48 --> Parser Class Initialized
INFO - 2020-02-24 16:17:48 --> User Agent Class Initialized
INFO - 2020-02-24 16:17:48 --> Model Class Initialized
INFO - 2020-02-24 16:17:48 --> Database Driver Class Initialized
INFO - 2020-02-24 16:17:48 --> Model Class Initialized
DEBUG - 2020-02-24 16:17:48 --> Template Class Initialized
INFO - 2020-02-24 16:17:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:17:48 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:17:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:17:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:17:48 --> Encryption Class Initialized
INFO - 2020-02-24 16:17:48 --> Controller Class Initialized
DEBUG - 2020-02-24 16:17:48 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:17:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:17:48 --> Model Class Initialized
ERROR - 2020-02-24 16:17:48 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:17:48 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:17:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:17:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:17:48 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:17:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:17:48 --> Model Class Initialized
DEBUG - 2020-02-24 16:17:48 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:17:48 --> Model Class Initialized
DEBUG - 2020-02-24 16:17:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:17:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:17:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:17:48 --> Final output sent to browser
DEBUG - 2020-02-24 16:17:48 --> Total execution time: 0.6906
INFO - 2020-02-24 16:20:23 --> Config Class Initialized
INFO - 2020-02-24 16:20:24 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:20:24 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:20:24 --> Utf8 Class Initialized
INFO - 2020-02-24 16:20:24 --> URI Class Initialized
INFO - 2020-02-24 16:20:24 --> Router Class Initialized
INFO - 2020-02-24 16:20:24 --> Output Class Initialized
INFO - 2020-02-24 16:20:24 --> Security Class Initialized
DEBUG - 2020-02-24 16:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:20:24 --> CSRF cookie sent
INFO - 2020-02-24 16:20:24 --> Input Class Initialized
INFO - 2020-02-24 16:20:24 --> Language Class Initialized
INFO - 2020-02-24 16:20:24 --> Language Class Initialized
INFO - 2020-02-24 16:20:24 --> Config Class Initialized
INFO - 2020-02-24 16:20:24 --> Loader Class Initialized
INFO - 2020-02-24 16:20:24 --> Helper loaded: url_helper
INFO - 2020-02-24 16:20:24 --> Helper loaded: common_helper
INFO - 2020-02-24 16:20:24 --> Helper loaded: language_helper
INFO - 2020-02-24 16:20:24 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:20:24 --> Helper loaded: email_helper
INFO - 2020-02-24 16:20:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:20:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:20:24 --> Parser Class Initialized
INFO - 2020-02-24 16:20:24 --> User Agent Class Initialized
INFO - 2020-02-24 16:20:24 --> Model Class Initialized
INFO - 2020-02-24 16:20:24 --> Database Driver Class Initialized
INFO - 2020-02-24 16:20:24 --> Model Class Initialized
DEBUG - 2020-02-24 16:20:24 --> Template Class Initialized
INFO - 2020-02-24 16:20:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:20:24 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:20:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:20:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:20:24 --> Encryption Class Initialized
INFO - 2020-02-24 16:20:24 --> Controller Class Initialized
DEBUG - 2020-02-24 16:20:24 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:20:24 --> Model Class Initialized
ERROR - 2020-02-24 16:20:24 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:20:24 --> Helper loaded: inflector_helper
INFO - 2020-02-24 16:23:32 --> Config Class Initialized
INFO - 2020-02-24 16:23:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:23:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:23:32 --> Utf8 Class Initialized
INFO - 2020-02-24 16:23:32 --> URI Class Initialized
INFO - 2020-02-24 16:23:32 --> Router Class Initialized
INFO - 2020-02-24 16:23:32 --> Output Class Initialized
INFO - 2020-02-24 16:23:32 --> Security Class Initialized
DEBUG - 2020-02-24 16:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:23:32 --> CSRF cookie sent
INFO - 2020-02-24 16:23:33 --> Input Class Initialized
INFO - 2020-02-24 16:23:33 --> Language Class Initialized
INFO - 2020-02-24 16:23:33 --> Language Class Initialized
INFO - 2020-02-24 16:23:33 --> Config Class Initialized
INFO - 2020-02-24 16:23:33 --> Loader Class Initialized
INFO - 2020-02-24 16:23:33 --> Helper loaded: url_helper
INFO - 2020-02-24 16:23:33 --> Helper loaded: common_helper
INFO - 2020-02-24 16:23:33 --> Helper loaded: language_helper
INFO - 2020-02-24 16:23:33 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:23:33 --> Helper loaded: email_helper
INFO - 2020-02-24 16:23:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:23:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:23:33 --> Parser Class Initialized
INFO - 2020-02-24 16:23:33 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:33 --> Model Class Initialized
INFO - 2020-02-24 16:23:33 --> Database Driver Class Initialized
INFO - 2020-02-24 16:23:33 --> Model Class Initialized
DEBUG - 2020-02-24 16:23:33 --> Template Class Initialized
INFO - 2020-02-24 16:23:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:33 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:23:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:23:33 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:33 --> Controller Class Initialized
DEBUG - 2020-02-24 16:23:33 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:23:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:33 --> Model Class Initialized
ERROR - 2020-02-24 16:23:33 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:23:33 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:23:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:23:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:23:33 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:23:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:23:33 --> Model Class Initialized
DEBUG - 2020-02-24 16:23:33 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:33 --> Model Class Initialized
DEBUG - 2020-02-24 16:23:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:23:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:23:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:23:33 --> Final output sent to browser
DEBUG - 2020-02-24 16:23:33 --> Total execution time: 0.8085
INFO - 2020-02-24 16:23:40 --> Config Class Initialized
INFO - 2020-02-24 16:23:40 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:23:40 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:23:40 --> Utf8 Class Initialized
INFO - 2020-02-24 16:23:40 --> URI Class Initialized
INFO - 2020-02-24 16:23:40 --> Router Class Initialized
INFO - 2020-02-24 16:23:40 --> Output Class Initialized
INFO - 2020-02-24 16:23:40 --> Security Class Initialized
DEBUG - 2020-02-24 16:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:23:40 --> CSRF cookie sent
INFO - 2020-02-24 16:23:40 --> Input Class Initialized
INFO - 2020-02-24 16:23:40 --> Language Class Initialized
INFO - 2020-02-24 16:23:40 --> Language Class Initialized
INFO - 2020-02-24 16:23:40 --> Config Class Initialized
INFO - 2020-02-24 16:23:40 --> Loader Class Initialized
INFO - 2020-02-24 16:23:40 --> Helper loaded: url_helper
INFO - 2020-02-24 16:23:41 --> Helper loaded: common_helper
INFO - 2020-02-24 16:23:41 --> Helper loaded: language_helper
INFO - 2020-02-24 16:23:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:23:41 --> Helper loaded: email_helper
INFO - 2020-02-24 16:23:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:23:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:23:41 --> Parser Class Initialized
INFO - 2020-02-24 16:23:41 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:41 --> Model Class Initialized
INFO - 2020-02-24 16:23:41 --> Database Driver Class Initialized
INFO - 2020-02-24 16:23:41 --> Model Class Initialized
DEBUG - 2020-02-24 16:23:41 --> Template Class Initialized
INFO - 2020-02-24 16:23:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:41 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:23:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:23:41 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:41 --> Controller Class Initialized
DEBUG - 2020-02-24 16:23:41 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:23:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:41 --> Model Class Initialized
ERROR - 2020-02-24 16:23:41 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:23:41 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 16:23:41 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 16:23:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 16:23:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:23:41 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:23:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:23:41 --> Model Class Initialized
DEBUG - 2020-02-24 16:23:41 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:41 --> Model Class Initialized
DEBUG - 2020-02-24 16:23:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:23:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:23:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:23:41 --> Final output sent to browser
DEBUG - 2020-02-24 16:23:41 --> Total execution time: 0.8040
INFO - 2020-02-24 16:23:41 --> Config Class Initialized
INFO - 2020-02-24 16:23:41 --> Config Class Initialized
INFO - 2020-02-24 16:23:41 --> Config Class Initialized
INFO - 2020-02-24 16:23:41 --> Config Class Initialized
INFO - 2020-02-24 16:23:41 --> Config Class Initialized
INFO - 2020-02-24 16:23:41 --> Config Class Initialized
INFO - 2020-02-24 16:23:41 --> Hooks Class Initialized
INFO - 2020-02-24 16:23:41 --> Hooks Class Initialized
INFO - 2020-02-24 16:23:41 --> Hooks Class Initialized
INFO - 2020-02-24 16:23:41 --> Hooks Class Initialized
INFO - 2020-02-24 16:23:41 --> Hooks Class Initialized
INFO - 2020-02-24 16:23:41 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:23:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 16:23:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 16:23:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 16:23:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 16:23:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 16:23:41 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:23:41 --> Utf8 Class Initialized
INFO - 2020-02-24 16:23:41 --> Utf8 Class Initialized
INFO - 2020-02-24 16:23:41 --> Utf8 Class Initialized
INFO - 2020-02-24 16:23:41 --> Utf8 Class Initialized
INFO - 2020-02-24 16:23:41 --> Utf8 Class Initialized
INFO - 2020-02-24 16:23:41 --> Utf8 Class Initialized
INFO - 2020-02-24 16:23:41 --> URI Class Initialized
INFO - 2020-02-24 16:23:41 --> URI Class Initialized
INFO - 2020-02-24 16:23:41 --> URI Class Initialized
INFO - 2020-02-24 16:23:41 --> URI Class Initialized
INFO - 2020-02-24 16:23:41 --> URI Class Initialized
INFO - 2020-02-24 16:23:41 --> URI Class Initialized
INFO - 2020-02-24 16:23:41 --> Router Class Initialized
INFO - 2020-02-24 16:23:41 --> Router Class Initialized
INFO - 2020-02-24 16:23:41 --> Router Class Initialized
INFO - 2020-02-24 16:23:41 --> Router Class Initialized
INFO - 2020-02-24 16:23:41 --> Router Class Initialized
INFO - 2020-02-24 16:23:41 --> Router Class Initialized
INFO - 2020-02-24 16:23:41 --> Output Class Initialized
INFO - 2020-02-24 16:23:41 --> Output Class Initialized
INFO - 2020-02-24 16:23:41 --> Output Class Initialized
INFO - 2020-02-24 16:23:41 --> Output Class Initialized
INFO - 2020-02-24 16:23:41 --> Output Class Initialized
INFO - 2020-02-24 16:23:41 --> Output Class Initialized
INFO - 2020-02-24 16:23:41 --> Security Class Initialized
INFO - 2020-02-24 16:23:41 --> Security Class Initialized
INFO - 2020-02-24 16:23:41 --> Security Class Initialized
INFO - 2020-02-24 16:23:41 --> Security Class Initialized
INFO - 2020-02-24 16:23:41 --> Security Class Initialized
INFO - 2020-02-24 16:23:41 --> Security Class Initialized
DEBUG - 2020-02-24 16:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:23:41 --> CSRF cookie sent
INFO - 2020-02-24 16:23:41 --> CSRF cookie sent
INFO - 2020-02-24 16:23:41 --> CSRF cookie sent
INFO - 2020-02-24 16:23:41 --> CSRF cookie sent
INFO - 2020-02-24 16:23:41 --> CSRF cookie sent
INFO - 2020-02-24 16:23:41 --> CSRF cookie sent
INFO - 2020-02-24 16:23:41 --> CSRF token verified
INFO - 2020-02-24 16:23:41 --> CSRF token verified
INFO - 2020-02-24 16:23:41 --> CSRF token verified
INFO - 2020-02-24 16:23:41 --> CSRF token verified
INFO - 2020-02-24 16:23:41 --> CSRF token verified
INFO - 2020-02-24 16:23:41 --> CSRF token verified
INFO - 2020-02-24 16:23:41 --> Input Class Initialized
INFO - 2020-02-24 16:23:41 --> Input Class Initialized
INFO - 2020-02-24 16:23:41 --> Input Class Initialized
INFO - 2020-02-24 16:23:41 --> Input Class Initialized
INFO - 2020-02-24 16:23:41 --> Input Class Initialized
INFO - 2020-02-24 16:23:41 --> Input Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Config Class Initialized
INFO - 2020-02-24 16:23:42 --> Config Class Initialized
INFO - 2020-02-24 16:23:42 --> Config Class Initialized
INFO - 2020-02-24 16:23:42 --> Config Class Initialized
INFO - 2020-02-24 16:23:42 --> Config Class Initialized
INFO - 2020-02-24 16:23:42 --> Config Class Initialized
INFO - 2020-02-24 16:23:42 --> Loader Class Initialized
INFO - 2020-02-24 16:23:42 --> Loader Class Initialized
INFO - 2020-02-24 16:23:42 --> Loader Class Initialized
INFO - 2020-02-24 16:23:42 --> Loader Class Initialized
INFO - 2020-02-24 16:23:42 --> Loader Class Initialized
INFO - 2020-02-24 16:23:42 --> Loader Class Initialized
INFO - 2020-02-24 16:23:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: language_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: language_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: language_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: language_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: language_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: language_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: email_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: email_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: email_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: email_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: email_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: email_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:23:42 --> Parser Class Initialized
INFO - 2020-02-24 16:23:42 --> Parser Class Initialized
INFO - 2020-02-24 16:23:42 --> Parser Class Initialized
INFO - 2020-02-24 16:23:42 --> Parser Class Initialized
INFO - 2020-02-24 16:23:42 --> Parser Class Initialized
INFO - 2020-02-24 16:23:42 --> Parser Class Initialized
INFO - 2020-02-24 16:23:42 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:42 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:42 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:42 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:42 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:42 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Database Driver Class Initialized
INFO - 2020-02-24 16:23:42 --> Database Driver Class Initialized
INFO - 2020-02-24 16:23:42 --> Database Driver Class Initialized
INFO - 2020-02-24 16:23:42 --> Database Driver Class Initialized
INFO - 2020-02-24 16:23:42 --> Database Driver Class Initialized
INFO - 2020-02-24 16:23:42 --> Database Driver Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Template Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Template Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Template Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Template Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Template Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Template Class Initialized
INFO - 2020-02-24 16:23:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:42 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:23:42 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:42 --> Controller Class Initialized
DEBUG - 2020-02-24 16:23:42 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "View"
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "View"
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:23:42 --> Final output sent to browser
DEBUG - 2020-02-24 16:23:42 --> Total execution time: 0.6658
INFO - 2020-02-24 16:23:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:42 --> Config Class Initialized
INFO - 2020-02-24 16:23:42 --> Hooks Class Initialized
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:42 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:23:42 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:23:42 --> Utf8 Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:23:42 --> URI Class Initialized
INFO - 2020-02-24 16:23:42 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:42 --> Router Class Initialized
INFO - 2020-02-24 16:23:42 --> Controller Class Initialized
INFO - 2020-02-24 16:23:42 --> Output Class Initialized
DEBUG - 2020-02-24 16:23:42 --> category MX_Controller Initialized
INFO - 2020-02-24 16:23:42 --> Security Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> CSRF cookie sent
INFO - 2020-02-24 16:23:42 --> CSRF token verified
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:23:42 --> Input Class Initialized
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "View"
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
DEBUG - 2020-02-24 16:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:23:42 --> Final output sent to browser
INFO - 2020-02-24 16:23:42 --> Language Class Initialized
INFO - 2020-02-24 16:23:42 --> Config Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Total execution time: 0.8425
INFO - 2020-02-24 16:23:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:42 --> Loader Class Initialized
INFO - 2020-02-24 16:23:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:42 --> Pagination Class Initialized
INFO - 2020-02-24 16:23:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:23:42 --> Helper loaded: language_helper
DEBUG - 2020-02-24 16:23:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:23:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:23:42 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:42 --> Helper loaded: email_helper
INFO - 2020-02-24 16:23:42 --> Controller Class Initialized
INFO - 2020-02-24 16:23:42 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-24 16:23:42 --> category MX_Controller Initialized
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 16:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:42 --> Parser Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:23:42 --> Database Driver Class Initialized
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
INFO - 2020-02-24 16:23:42 --> Final output sent to browser
DEBUG - 2020-02-24 16:23:42 --> Template Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Total execution time: 1.0157
INFO - 2020-02-24 16:23:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:42 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:23:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:23:42 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:42 --> Controller Class Initialized
DEBUG - 2020-02-24 16:23:42 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:42 --> Model Class Initialized
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:23:42 --> Config Class Initialized
ERROR - 2020-02-24 16:23:42 --> Could not find the language line "View"
INFO - 2020-02-24 16:23:42 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:23:43 --> Final output sent to browser
DEBUG - 2020-02-24 16:23:43 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:23:43 --> Utf8 Class Initialized
DEBUG - 2020-02-24 16:23:43 --> Total execution time: 1.2022
INFO - 2020-02-24 16:23:43 --> URI Class Initialized
INFO - 2020-02-24 16:23:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:43 --> Router Class Initialized
INFO - 2020-02-24 16:23:43 --> Pagination Class Initialized
INFO - 2020-02-24 16:23:43 --> Output Class Initialized
INFO - 2020-02-24 16:23:43 --> Security Class Initialized
DEBUG - 2020-02-24 16:23:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-02-24 16:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:23:43 --> CSRF cookie sent
INFO - 2020-02-24 16:23:43 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:43 --> Input Class Initialized
INFO - 2020-02-24 16:23:43 --> Controller Class Initialized
DEBUG - 2020-02-24 16:23:43 --> category MX_Controller Initialized
INFO - 2020-02-24 16:23:43 --> Language Class Initialized
DEBUG - 2020-02-24 16:23:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:43 --> Language Class Initialized
INFO - 2020-02-24 16:23:43 --> Model Class Initialized
INFO - 2020-02-24 16:23:43 --> Config Class Initialized
INFO - 2020-02-24 16:23:43 --> Loader Class Initialized
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:23:43 --> Helper loaded: url_helper
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "View"
INFO - 2020-02-24 16:23:43 --> Helper loaded: common_helper
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "View"
INFO - 2020-02-24 16:23:43 --> Helper loaded: language_helper
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "View"
INFO - 2020-02-24 16:23:43 --> Helper loaded: cookie_helper
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "View"
INFO - 2020-02-24 16:23:43 --> Helper loaded: email_helper
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "View"
INFO - 2020-02-24 16:23:43 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-24 16:23:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:23:43 --> Final output sent to browser
INFO - 2020-02-24 16:23:43 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 16:23:43 --> Total execution time: 1.4602
INFO - 2020-02-24 16:23:43 --> Parser Class Initialized
INFO - 2020-02-24 16:23:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:43 --> User Agent Class Initialized
INFO - 2020-02-24 16:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:43 --> Model Class Initialized
INFO - 2020-02-24 16:23:43 --> Pagination Class Initialized
INFO - 2020-02-24 16:23:43 --> Database Driver Class Initialized
DEBUG - 2020-02-24 16:23:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:43 --> Model Class Initialized
INFO - 2020-02-24 16:23:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-02-24 16:23:43 --> Template Class Initialized
INFO - 2020-02-24 16:23:43 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:43 --> Controller Class Initialized
DEBUG - 2020-02-24 16:23:43 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:23:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:43 --> Model Class Initialized
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "View"
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "View"
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:23:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:23:43 --> Final output sent to browser
DEBUG - 2020-02-24 16:23:43 --> Total execution time: 1.7167
INFO - 2020-02-24 16:23:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:43 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:23:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:23:43 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:43 --> Controller Class Initialized
DEBUG - 2020-02-24 16:23:43 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:23:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:43 --> Model Class Initialized
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:23:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:23:43 --> Final output sent to browser
DEBUG - 2020-02-24 16:23:43 --> Total execution time: 1.2215
INFO - 2020-02-24 16:23:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:23:43 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:23:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:23:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:23:43 --> Encryption Class Initialized
INFO - 2020-02-24 16:23:43 --> Controller Class Initialized
DEBUG - 2020-02-24 16:23:43 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:23:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:43 --> Model Class Initialized
ERROR - 2020-02-24 16:23:43 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:23:43 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:23:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-24 16:23:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:23:43 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:23:44 --> Model Class Initialized
DEBUG - 2020-02-24 16:23:44 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:23:44 --> Model Class Initialized
DEBUG - 2020-02-24 16:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:23:44 --> Final output sent to browser
DEBUG - 2020-02-24 16:23:44 --> Total execution time: 1.1646
INFO - 2020-02-24 16:26:41 --> Config Class Initialized
INFO - 2020-02-24 16:26:41 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:26:41 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:26:41 --> Utf8 Class Initialized
INFO - 2020-02-24 16:26:41 --> URI Class Initialized
INFO - 2020-02-24 16:26:41 --> Router Class Initialized
INFO - 2020-02-24 16:26:41 --> Output Class Initialized
INFO - 2020-02-24 16:26:41 --> Security Class Initialized
DEBUG - 2020-02-24 16:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:26:41 --> CSRF cookie sent
INFO - 2020-02-24 16:26:41 --> Input Class Initialized
INFO - 2020-02-24 16:26:41 --> Language Class Initialized
INFO - 2020-02-24 16:26:41 --> Language Class Initialized
INFO - 2020-02-24 16:26:41 --> Config Class Initialized
INFO - 2020-02-24 16:26:41 --> Loader Class Initialized
INFO - 2020-02-24 16:26:41 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:41 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:41 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:41 --> Helper loaded: email_helper
INFO - 2020-02-24 16:26:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:41 --> Parser Class Initialized
INFO - 2020-02-24 16:26:41 --> User Agent Class Initialized
INFO - 2020-02-24 16:26:41 --> Model Class Initialized
INFO - 2020-02-24 16:26:41 --> Database Driver Class Initialized
INFO - 2020-02-24 16:26:41 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:42 --> Template Class Initialized
INFO - 2020-02-24 16:26:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:42 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:26:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:42 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:42 --> Controller Class Initialized
DEBUG - 2020-02-24 16:26:42 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:26:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:42 --> Model Class Initialized
ERROR - 2020-02-24 16:26:42 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:26:42 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 16:26:42 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 16:26:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 16:26:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:26:42 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:26:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:26:42 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:42 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:42 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:26:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:26:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:26:42 --> Final output sent to browser
DEBUG - 2020-02-24 16:26:42 --> Total execution time: 0.8184
INFO - 2020-02-24 16:26:51 --> Config Class Initialized
INFO - 2020-02-24 16:26:51 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:26:51 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:26:51 --> Utf8 Class Initialized
INFO - 2020-02-24 16:26:51 --> URI Class Initialized
INFO - 2020-02-24 16:26:51 --> Router Class Initialized
INFO - 2020-02-24 16:26:51 --> Output Class Initialized
INFO - 2020-02-24 16:26:51 --> Security Class Initialized
DEBUG - 2020-02-24 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:26:51 --> CSRF cookie sent
INFO - 2020-02-24 16:26:51 --> Input Class Initialized
INFO - 2020-02-24 16:26:51 --> Language Class Initialized
INFO - 2020-02-24 16:26:51 --> Language Class Initialized
INFO - 2020-02-24 16:26:51 --> Config Class Initialized
INFO - 2020-02-24 16:26:51 --> Loader Class Initialized
INFO - 2020-02-24 16:26:51 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:51 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:51 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:51 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:51 --> Helper loaded: email_helper
INFO - 2020-02-24 16:26:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:51 --> Parser Class Initialized
INFO - 2020-02-24 16:26:51 --> User Agent Class Initialized
INFO - 2020-02-24 16:26:51 --> Model Class Initialized
INFO - 2020-02-24 16:26:51 --> Database Driver Class Initialized
INFO - 2020-02-24 16:26:51 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:51 --> Template Class Initialized
INFO - 2020-02-24 16:26:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:51 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:26:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:51 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:51 --> Controller Class Initialized
DEBUG - 2020-02-24 16:26:51 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:26:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:51 --> Model Class Initialized
ERROR - 2020-02-24 16:26:52 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:26:52 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 16:26:52 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 16:26:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 16:26:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:26:52 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:26:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:26:52 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:52 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:52 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:26:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:26:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:26:52 --> Final output sent to browser
DEBUG - 2020-02-24 16:26:52 --> Total execution time: 0.8750
INFO - 2020-02-24 16:26:52 --> Config Class Initialized
INFO - 2020-02-24 16:26:52 --> Config Class Initialized
INFO - 2020-02-24 16:26:52 --> Config Class Initialized
INFO - 2020-02-24 16:26:52 --> Config Class Initialized
INFO - 2020-02-24 16:26:52 --> Config Class Initialized
INFO - 2020-02-24 16:26:52 --> Hooks Class Initialized
INFO - 2020-02-24 16:26:52 --> Hooks Class Initialized
INFO - 2020-02-24 16:26:52 --> Hooks Class Initialized
INFO - 2020-02-24 16:26:52 --> Hooks Class Initialized
INFO - 2020-02-24 16:26:52 --> Hooks Class Initialized
INFO - 2020-02-24 16:26:52 --> Config Class Initialized
INFO - 2020-02-24 16:26:52 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 16:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 16:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 16:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 16:26:52 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:26:52 --> Utf8 Class Initialized
INFO - 2020-02-24 16:26:52 --> Utf8 Class Initialized
INFO - 2020-02-24 16:26:52 --> Utf8 Class Initialized
INFO - 2020-02-24 16:26:52 --> Utf8 Class Initialized
INFO - 2020-02-24 16:26:52 --> Utf8 Class Initialized
DEBUG - 2020-02-24 16:26:52 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:26:52 --> Utf8 Class Initialized
INFO - 2020-02-24 16:26:52 --> URI Class Initialized
INFO - 2020-02-24 16:26:52 --> URI Class Initialized
INFO - 2020-02-24 16:26:52 --> URI Class Initialized
INFO - 2020-02-24 16:26:52 --> URI Class Initialized
INFO - 2020-02-24 16:26:52 --> URI Class Initialized
INFO - 2020-02-24 16:26:53 --> URI Class Initialized
INFO - 2020-02-24 16:26:53 --> Router Class Initialized
INFO - 2020-02-24 16:26:53 --> Router Class Initialized
INFO - 2020-02-24 16:26:53 --> Router Class Initialized
INFO - 2020-02-24 16:26:53 --> Router Class Initialized
INFO - 2020-02-24 16:26:53 --> Router Class Initialized
INFO - 2020-02-24 16:26:53 --> Output Class Initialized
INFO - 2020-02-24 16:26:53 --> Output Class Initialized
INFO - 2020-02-24 16:26:53 --> Output Class Initialized
INFO - 2020-02-24 16:26:53 --> Output Class Initialized
INFO - 2020-02-24 16:26:53 --> Output Class Initialized
INFO - 2020-02-24 16:26:53 --> Router Class Initialized
INFO - 2020-02-24 16:26:53 --> Security Class Initialized
INFO - 2020-02-24 16:26:53 --> Security Class Initialized
INFO - 2020-02-24 16:26:53 --> Output Class Initialized
INFO - 2020-02-24 16:26:53 --> Security Class Initialized
INFO - 2020-02-24 16:26:53 --> Security Class Initialized
INFO - 2020-02-24 16:26:53 --> Security Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:26:53 --> Security Class Initialized
INFO - 2020-02-24 16:26:53 --> CSRF cookie sent
INFO - 2020-02-24 16:26:53 --> CSRF cookie sent
INFO - 2020-02-24 16:26:53 --> CSRF cookie sent
INFO - 2020-02-24 16:26:53 --> CSRF cookie sent
INFO - 2020-02-24 16:26:53 --> CSRF cookie sent
DEBUG - 2020-02-24 16:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:26:53 --> CSRF token verified
INFO - 2020-02-24 16:26:53 --> CSRF token verified
INFO - 2020-02-24 16:26:53 --> CSRF cookie sent
INFO - 2020-02-24 16:26:53 --> CSRF token verified
INFO - 2020-02-24 16:26:53 --> CSRF token verified
INFO - 2020-02-24 16:26:53 --> CSRF token verified
INFO - 2020-02-24 16:26:53 --> Input Class Initialized
INFO - 2020-02-24 16:26:53 --> CSRF token verified
INFO - 2020-02-24 16:26:53 --> Input Class Initialized
INFO - 2020-02-24 16:26:53 --> Input Class Initialized
INFO - 2020-02-24 16:26:53 --> Input Class Initialized
INFO - 2020-02-24 16:26:53 --> Input Class Initialized
INFO - 2020-02-24 16:26:53 --> Input Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Config Class Initialized
INFO - 2020-02-24 16:26:53 --> Config Class Initialized
INFO - 2020-02-24 16:26:53 --> Config Class Initialized
INFO - 2020-02-24 16:26:53 --> Config Class Initialized
INFO - 2020-02-24 16:26:53 --> Config Class Initialized
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
INFO - 2020-02-24 16:26:53 --> Config Class Initialized
INFO - 2020-02-24 16:26:53 --> Loader Class Initialized
INFO - 2020-02-24 16:26:53 --> Loader Class Initialized
INFO - 2020-02-24 16:26:53 --> Loader Class Initialized
INFO - 2020-02-24 16:26:53 --> Loader Class Initialized
INFO - 2020-02-24 16:26:53 --> Loader Class Initialized
INFO - 2020-02-24 16:26:53 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:53 --> Loader Class Initialized
INFO - 2020-02-24 16:26:53 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: email_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: email_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: email_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: email_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: email_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: email_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:53 --> Parser Class Initialized
INFO - 2020-02-24 16:26:53 --> Parser Class Initialized
INFO - 2020-02-24 16:26:53 --> Parser Class Initialized
INFO - 2020-02-24 16:26:53 --> Parser Class Initialized
INFO - 2020-02-24 16:26:53 --> Parser Class Initialized
INFO - 2020-02-24 16:26:53 --> User Agent Class Initialized
INFO - 2020-02-24 16:26:53 --> Parser Class Initialized
INFO - 2020-02-24 16:26:53 --> User Agent Class Initialized
INFO - 2020-02-24 16:26:53 --> User Agent Class Initialized
INFO - 2020-02-24 16:26:53 --> User Agent Class Initialized
INFO - 2020-02-24 16:26:53 --> User Agent Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> User Agent Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Database Driver Class Initialized
INFO - 2020-02-24 16:26:53 --> Database Driver Class Initialized
INFO - 2020-02-24 16:26:53 --> Database Driver Class Initialized
INFO - 2020-02-24 16:26:53 --> Database Driver Class Initialized
INFO - 2020-02-24 16:26:53 --> Database Driver Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> Database Driver Class Initialized
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Template Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Template Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Template Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Template Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Template Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Template Class Initialized
INFO - 2020-02-24 16:26:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:53 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:53 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:53 --> Controller Class Initialized
DEBUG - 2020-02-24 16:26:53 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:26:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "View"
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "View"
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "View"
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "View"
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:26:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:26:53 --> Final output sent to browser
DEBUG - 2020-02-24 16:26:53 --> Total execution time: 0.8297
INFO - 2020-02-24 16:26:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:53 --> Config Class Initialized
INFO - 2020-02-24 16:26:53 --> Hooks Class Initialized
INFO - 2020-02-24 16:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:53 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:26:53 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:26:53 --> Utf8 Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:53 --> URI Class Initialized
INFO - 2020-02-24 16:26:53 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:53 --> Router Class Initialized
INFO - 2020-02-24 16:26:53 --> Controller Class Initialized
INFO - 2020-02-24 16:26:53 --> Output Class Initialized
DEBUG - 2020-02-24 16:26:53 --> category MX_Controller Initialized
INFO - 2020-02-24 16:26:53 --> Security Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 16:26:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:53 --> Model Class Initialized
INFO - 2020-02-24 16:26:53 --> CSRF cookie sent
INFO - 2020-02-24 16:26:53 --> CSRF token verified
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:26:53 --> Input Class Initialized
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "View"
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "View"
INFO - 2020-02-24 16:26:53 --> Language Class Initialized
ERROR - 2020-02-24 16:26:53 --> Could not find the language line "View"
INFO - 2020-02-24 16:26:53 --> Config Class Initialized
DEBUG - 2020-02-24 16:26:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:26:53 --> Final output sent to browser
INFO - 2020-02-24 16:26:53 --> Loader Class Initialized
DEBUG - 2020-02-24 16:26:53 --> Total execution time: 1.0666
INFO - 2020-02-24 16:26:53 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:53 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:53 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:54 --> Pagination Class Initialized
INFO - 2020-02-24 16:26:54 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:54 --> Helper loaded: email_helper
DEBUG - 2020-02-24 16:26:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:54 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:54 --> Controller Class Initialized
INFO - 2020-02-24 16:26:54 --> Parser Class Initialized
DEBUG - 2020-02-24 16:26:54 --> category MX_Controller Initialized
INFO - 2020-02-24 16:26:54 --> User Agent Class Initialized
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:54 --> Model Class Initialized
INFO - 2020-02-24 16:26:54 --> Model Class Initialized
INFO - 2020-02-24 16:26:54 --> Database Driver Class Initialized
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:26:54 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:54 --> Template Class Initialized
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:26:54 --> Final output sent to browser
DEBUG - 2020-02-24 16:26:54 --> Total execution time: 1.2677
INFO - 2020-02-24 16:26:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:54 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:26:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:54 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:54 --> Controller Class Initialized
DEBUG - 2020-02-24 16:26:54 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:54 --> Model Class Initialized
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "View"
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "View"
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:26:54 --> Final output sent to browser
DEBUG - 2020-02-24 16:26:54 --> Total execution time: 1.4993
INFO - 2020-02-24 16:26:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:54 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:26:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:54 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:54 --> Controller Class Initialized
DEBUG - 2020-02-24 16:26:54 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:54 --> Model Class Initialized
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:26:54 --> Final output sent to browser
DEBUG - 2020-02-24 16:26:54 --> Total execution time: 1.7118
INFO - 2020-02-24 16:26:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:54 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:26:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:54 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:54 --> Controller Class Initialized
DEBUG - 2020-02-24 16:26:54 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:54 --> Model Class Initialized
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:26:54 --> Final output sent to browser
DEBUG - 2020-02-24 16:26:54 --> Total execution time: 1.8901
INFO - 2020-02-24 16:26:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:54 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:26:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:54 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:54 --> Controller Class Initialized
DEBUG - 2020-02-24 16:26:54 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:54 --> Model Class Initialized
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 16:26:54 --> Could not find the language line "View"
DEBUG - 2020-02-24 16:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 16:26:55 --> Final output sent to browser
DEBUG - 2020-02-24 16:26:55 --> Total execution time: 1.2784
INFO - 2020-02-24 16:26:56 --> Config Class Initialized
INFO - 2020-02-24 16:26:56 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:26:56 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:26:56 --> Utf8 Class Initialized
INFO - 2020-02-24 16:26:56 --> URI Class Initialized
INFO - 2020-02-24 16:26:56 --> Router Class Initialized
INFO - 2020-02-24 16:26:56 --> Output Class Initialized
INFO - 2020-02-24 16:26:56 --> Security Class Initialized
DEBUG - 2020-02-24 16:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:26:56 --> CSRF cookie sent
INFO - 2020-02-24 16:26:57 --> Input Class Initialized
INFO - 2020-02-24 16:26:57 --> Language Class Initialized
INFO - 2020-02-24 16:26:57 --> Language Class Initialized
INFO - 2020-02-24 16:26:57 --> Config Class Initialized
INFO - 2020-02-24 16:26:57 --> Loader Class Initialized
INFO - 2020-02-24 16:26:57 --> Helper loaded: url_helper
INFO - 2020-02-24 16:26:57 --> Helper loaded: common_helper
INFO - 2020-02-24 16:26:57 --> Helper loaded: language_helper
INFO - 2020-02-24 16:26:57 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:26:57 --> Helper loaded: email_helper
INFO - 2020-02-24 16:26:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:26:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:26:57 --> Parser Class Initialized
INFO - 2020-02-24 16:26:57 --> User Agent Class Initialized
INFO - 2020-02-24 16:26:57 --> Model Class Initialized
INFO - 2020-02-24 16:26:57 --> Database Driver Class Initialized
INFO - 2020-02-24 16:26:57 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:57 --> Template Class Initialized
INFO - 2020-02-24 16:26:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:26:57 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:26:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:26:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:26:57 --> Encryption Class Initialized
INFO - 2020-02-24 16:26:57 --> Controller Class Initialized
DEBUG - 2020-02-24 16:26:57 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:26:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:57 --> Model Class Initialized
ERROR - 2020-02-24 16:26:57 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:26:57 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:26:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:26:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:26:57 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:26:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:26:57 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:57 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:26:57 --> Model Class Initialized
DEBUG - 2020-02-24 16:26:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:26:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:26:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:26:57 --> Final output sent to browser
DEBUG - 2020-02-24 16:26:57 --> Total execution time: 1.0238
INFO - 2020-02-24 16:27:22 --> Config Class Initialized
INFO - 2020-02-24 16:27:22 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:27:22 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:27:22 --> Utf8 Class Initialized
INFO - 2020-02-24 16:27:22 --> URI Class Initialized
INFO - 2020-02-24 16:27:22 --> Router Class Initialized
INFO - 2020-02-24 16:27:22 --> Output Class Initialized
INFO - 2020-02-24 16:27:22 --> Security Class Initialized
DEBUG - 2020-02-24 16:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:27:22 --> CSRF cookie sent
INFO - 2020-02-24 16:27:22 --> Input Class Initialized
INFO - 2020-02-24 16:27:22 --> Language Class Initialized
INFO - 2020-02-24 16:27:22 --> Language Class Initialized
INFO - 2020-02-24 16:27:22 --> Config Class Initialized
INFO - 2020-02-24 16:27:22 --> Loader Class Initialized
INFO - 2020-02-24 16:27:22 --> Helper loaded: url_helper
INFO - 2020-02-24 16:27:22 --> Helper loaded: common_helper
INFO - 2020-02-24 16:27:22 --> Helper loaded: language_helper
INFO - 2020-02-24 16:27:22 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:27:22 --> Helper loaded: email_helper
INFO - 2020-02-24 16:27:22 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:27:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:27:22 --> Parser Class Initialized
INFO - 2020-02-24 16:27:22 --> User Agent Class Initialized
INFO - 2020-02-24 16:27:22 --> Model Class Initialized
INFO - 2020-02-24 16:27:22 --> Database Driver Class Initialized
INFO - 2020-02-24 16:27:22 --> Model Class Initialized
DEBUG - 2020-02-24 16:27:22 --> Template Class Initialized
INFO - 2020-02-24 16:27:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:27:23 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:27:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:27:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:27:23 --> Encryption Class Initialized
INFO - 2020-02-24 16:27:23 --> Controller Class Initialized
DEBUG - 2020-02-24 16:27:23 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:27:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:27:23 --> Model Class Initialized
ERROR - 2020-02-24 16:27:23 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:27:23 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:27:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:27:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:27:23 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:27:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:27:23 --> Model Class Initialized
DEBUG - 2020-02-24 16:27:23 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:27:23 --> Model Class Initialized
DEBUG - 2020-02-24 16:27:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:27:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:27:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:27:23 --> Final output sent to browser
DEBUG - 2020-02-24 16:27:23 --> Total execution time: 0.8100
INFO - 2020-02-24 16:29:32 --> Config Class Initialized
INFO - 2020-02-24 16:29:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:29:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:29:32 --> Utf8 Class Initialized
INFO - 2020-02-24 16:29:32 --> URI Class Initialized
INFO - 2020-02-24 16:29:32 --> Router Class Initialized
INFO - 2020-02-24 16:29:32 --> Output Class Initialized
INFO - 2020-02-24 16:29:32 --> Security Class Initialized
DEBUG - 2020-02-24 16:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:29:32 --> CSRF cookie sent
INFO - 2020-02-24 16:29:32 --> Input Class Initialized
INFO - 2020-02-24 16:29:32 --> Language Class Initialized
INFO - 2020-02-24 16:29:32 --> Language Class Initialized
INFO - 2020-02-24 16:29:32 --> Config Class Initialized
INFO - 2020-02-24 16:29:32 --> Loader Class Initialized
INFO - 2020-02-24 16:29:32 --> Helper loaded: url_helper
INFO - 2020-02-24 16:29:32 --> Helper loaded: common_helper
INFO - 2020-02-24 16:29:32 --> Helper loaded: language_helper
INFO - 2020-02-24 16:29:32 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:29:32 --> Helper loaded: email_helper
INFO - 2020-02-24 16:29:32 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:29:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:29:32 --> Parser Class Initialized
INFO - 2020-02-24 16:29:32 --> User Agent Class Initialized
INFO - 2020-02-24 16:29:32 --> Model Class Initialized
INFO - 2020-02-24 16:29:32 --> Database Driver Class Initialized
INFO - 2020-02-24 16:29:32 --> Model Class Initialized
DEBUG - 2020-02-24 16:29:32 --> Template Class Initialized
INFO - 2020-02-24 16:29:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:29:32 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:29:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:29:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:29:32 --> Encryption Class Initialized
INFO - 2020-02-24 16:29:32 --> Controller Class Initialized
DEBUG - 2020-02-24 16:29:32 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:29:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:29:32 --> Model Class Initialized
ERROR - 2020-02-24 16:29:32 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:29:32 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:29:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:29:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:29:32 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:29:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:29:32 --> Model Class Initialized
DEBUG - 2020-02-24 16:29:32 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:29:32 --> Model Class Initialized
DEBUG - 2020-02-24 16:29:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:29:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:29:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:29:32 --> Final output sent to browser
DEBUG - 2020-02-24 16:29:32 --> Total execution time: 0.8620
INFO - 2020-02-24 16:30:15 --> Config Class Initialized
INFO - 2020-02-24 16:30:15 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:30:15 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:30:15 --> Utf8 Class Initialized
INFO - 2020-02-24 16:30:15 --> URI Class Initialized
INFO - 2020-02-24 16:30:15 --> Router Class Initialized
INFO - 2020-02-24 16:30:15 --> Output Class Initialized
INFO - 2020-02-24 16:30:15 --> Security Class Initialized
DEBUG - 2020-02-24 16:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:30:15 --> CSRF cookie sent
INFO - 2020-02-24 16:30:15 --> Input Class Initialized
INFO - 2020-02-24 16:30:15 --> Language Class Initialized
INFO - 2020-02-24 16:30:15 --> Language Class Initialized
INFO - 2020-02-24 16:30:15 --> Config Class Initialized
INFO - 2020-02-24 16:30:15 --> Loader Class Initialized
INFO - 2020-02-24 16:30:15 --> Helper loaded: url_helper
INFO - 2020-02-24 16:30:15 --> Helper loaded: common_helper
INFO - 2020-02-24 16:30:15 --> Helper loaded: language_helper
INFO - 2020-02-24 16:30:15 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:30:15 --> Helper loaded: email_helper
INFO - 2020-02-24 16:30:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:30:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:30:15 --> Parser Class Initialized
INFO - 2020-02-24 16:30:15 --> User Agent Class Initialized
INFO - 2020-02-24 16:30:15 --> Model Class Initialized
INFO - 2020-02-24 16:30:15 --> Database Driver Class Initialized
INFO - 2020-02-24 16:30:15 --> Model Class Initialized
DEBUG - 2020-02-24 16:30:15 --> Template Class Initialized
INFO - 2020-02-24 16:30:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:30:15 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:30:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:30:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:30:15 --> Encryption Class Initialized
INFO - 2020-02-24 16:30:15 --> Controller Class Initialized
DEBUG - 2020-02-24 16:30:15 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:30:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:30:15 --> Model Class Initialized
ERROR - 2020-02-24 16:30:15 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:30:15 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:30:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:30:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:30:15 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:30:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:30:15 --> Model Class Initialized
DEBUG - 2020-02-24 16:30:15 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:30:15 --> Model Class Initialized
DEBUG - 2020-02-24 16:30:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:30:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:30:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:30:15 --> Final output sent to browser
DEBUG - 2020-02-24 16:30:15 --> Total execution time: 0.7473
INFO - 2020-02-24 16:30:43 --> Config Class Initialized
INFO - 2020-02-24 16:30:43 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:30:43 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:30:43 --> Utf8 Class Initialized
INFO - 2020-02-24 16:30:43 --> URI Class Initialized
INFO - 2020-02-24 16:30:43 --> Router Class Initialized
INFO - 2020-02-24 16:30:43 --> Output Class Initialized
INFO - 2020-02-24 16:30:43 --> Security Class Initialized
DEBUG - 2020-02-24 16:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:30:43 --> CSRF cookie sent
INFO - 2020-02-24 16:30:43 --> Input Class Initialized
INFO - 2020-02-24 16:30:43 --> Language Class Initialized
INFO - 2020-02-24 16:30:43 --> Language Class Initialized
INFO - 2020-02-24 16:30:43 --> Config Class Initialized
INFO - 2020-02-24 16:30:43 --> Loader Class Initialized
INFO - 2020-02-24 16:30:43 --> Helper loaded: url_helper
INFO - 2020-02-24 16:30:43 --> Helper loaded: common_helper
INFO - 2020-02-24 16:30:43 --> Helper loaded: language_helper
INFO - 2020-02-24 16:30:43 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:30:43 --> Helper loaded: email_helper
INFO - 2020-02-24 16:30:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:30:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:30:43 --> Parser Class Initialized
INFO - 2020-02-24 16:30:43 --> User Agent Class Initialized
INFO - 2020-02-24 16:30:43 --> Model Class Initialized
INFO - 2020-02-24 16:30:43 --> Database Driver Class Initialized
INFO - 2020-02-24 16:30:43 --> Model Class Initialized
DEBUG - 2020-02-24 16:30:43 --> Template Class Initialized
INFO - 2020-02-24 16:30:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:30:43 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:30:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:30:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:30:43 --> Encryption Class Initialized
INFO - 2020-02-24 16:30:43 --> Controller Class Initialized
DEBUG - 2020-02-24 16:30:43 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:30:44 --> Model Class Initialized
ERROR - 2020-02-24 16:30:44 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:30:44 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:30:44 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:30:44 --> Model Class Initialized
DEBUG - 2020-02-24 16:30:44 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:30:44 --> Model Class Initialized
DEBUG - 2020-02-24 16:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:30:44 --> Final output sent to browser
DEBUG - 2020-02-24 16:30:44 --> Total execution time: 0.7878
INFO - 2020-02-24 16:31:06 --> Config Class Initialized
INFO - 2020-02-24 16:31:06 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:31:06 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:31:06 --> Utf8 Class Initialized
INFO - 2020-02-24 16:31:06 --> URI Class Initialized
INFO - 2020-02-24 16:31:06 --> Router Class Initialized
INFO - 2020-02-24 16:31:06 --> Output Class Initialized
INFO - 2020-02-24 16:31:06 --> Security Class Initialized
DEBUG - 2020-02-24 16:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:31:06 --> CSRF cookie sent
INFO - 2020-02-24 16:31:06 --> Input Class Initialized
INFO - 2020-02-24 16:31:06 --> Language Class Initialized
INFO - 2020-02-24 16:31:06 --> Language Class Initialized
INFO - 2020-02-24 16:31:06 --> Config Class Initialized
INFO - 2020-02-24 16:31:06 --> Loader Class Initialized
INFO - 2020-02-24 16:31:06 --> Helper loaded: url_helper
INFO - 2020-02-24 16:31:06 --> Helper loaded: common_helper
INFO - 2020-02-24 16:31:06 --> Helper loaded: language_helper
INFO - 2020-02-24 16:31:06 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:31:06 --> Helper loaded: email_helper
INFO - 2020-02-24 16:31:06 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:31:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:31:06 --> Parser Class Initialized
INFO - 2020-02-24 16:31:06 --> User Agent Class Initialized
INFO - 2020-02-24 16:31:06 --> Model Class Initialized
INFO - 2020-02-24 16:31:06 --> Database Driver Class Initialized
INFO - 2020-02-24 16:31:06 --> Model Class Initialized
DEBUG - 2020-02-24 16:31:06 --> Template Class Initialized
INFO - 2020-02-24 16:31:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:31:06 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:31:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:31:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:31:06 --> Encryption Class Initialized
INFO - 2020-02-24 16:31:06 --> Controller Class Initialized
DEBUG - 2020-02-24 16:31:06 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:31:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:31:06 --> Model Class Initialized
ERROR - 2020-02-24 16:31:06 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:31:06 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:31:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:31:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:31:06 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:31:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:31:06 --> Model Class Initialized
DEBUG - 2020-02-24 16:31:06 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:31:06 --> Model Class Initialized
DEBUG - 2020-02-24 16:31:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:31:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:31:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:31:07 --> Final output sent to browser
DEBUG - 2020-02-24 16:31:07 --> Total execution time: 0.7356
INFO - 2020-02-24 16:34:30 --> Config Class Initialized
INFO - 2020-02-24 16:34:30 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:34:30 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:34:30 --> Utf8 Class Initialized
INFO - 2020-02-24 16:34:30 --> URI Class Initialized
INFO - 2020-02-24 16:34:30 --> Router Class Initialized
INFO - 2020-02-24 16:34:30 --> Output Class Initialized
INFO - 2020-02-24 16:34:30 --> Security Class Initialized
DEBUG - 2020-02-24 16:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:34:30 --> CSRF cookie sent
INFO - 2020-02-24 16:34:30 --> Input Class Initialized
INFO - 2020-02-24 16:34:30 --> Language Class Initialized
INFO - 2020-02-24 16:34:30 --> Language Class Initialized
INFO - 2020-02-24 16:34:30 --> Config Class Initialized
INFO - 2020-02-24 16:34:30 --> Loader Class Initialized
INFO - 2020-02-24 16:34:30 --> Helper loaded: url_helper
INFO - 2020-02-24 16:34:30 --> Helper loaded: common_helper
INFO - 2020-02-24 16:34:30 --> Helper loaded: language_helper
INFO - 2020-02-24 16:34:30 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:34:30 --> Helper loaded: email_helper
INFO - 2020-02-24 16:34:30 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:34:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:34:30 --> Parser Class Initialized
INFO - 2020-02-24 16:34:30 --> User Agent Class Initialized
INFO - 2020-02-24 16:34:30 --> Model Class Initialized
INFO - 2020-02-24 16:34:30 --> Database Driver Class Initialized
INFO - 2020-02-24 16:34:30 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:30 --> Template Class Initialized
INFO - 2020-02-24 16:34:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:34:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:34:30 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:34:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:34:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:34:30 --> Encryption Class Initialized
INFO - 2020-02-24 16:34:30 --> Controller Class Initialized
DEBUG - 2020-02-24 16:34:30 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:34:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:34:30 --> Model Class Initialized
ERROR - 2020-02-24 16:34:30 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:34:30 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:34:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:34:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:34:30 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:34:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:34:30 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:30 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:34:30 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:34:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:34:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:34:30 --> Final output sent to browser
DEBUG - 2020-02-24 16:34:31 --> Total execution time: 0.7802
INFO - 2020-02-24 16:34:41 --> Config Class Initialized
INFO - 2020-02-24 16:34:42 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:34:42 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:34:42 --> Utf8 Class Initialized
INFO - 2020-02-24 16:34:42 --> URI Class Initialized
INFO - 2020-02-24 16:34:42 --> Router Class Initialized
INFO - 2020-02-24 16:34:42 --> Output Class Initialized
INFO - 2020-02-24 16:34:42 --> Security Class Initialized
DEBUG - 2020-02-24 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:34:42 --> CSRF cookie sent
INFO - 2020-02-24 16:34:42 --> Input Class Initialized
INFO - 2020-02-24 16:34:42 --> Language Class Initialized
INFO - 2020-02-24 16:34:42 --> Language Class Initialized
INFO - 2020-02-24 16:34:42 --> Config Class Initialized
INFO - 2020-02-24 16:34:42 --> Loader Class Initialized
INFO - 2020-02-24 16:34:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:34:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:34:42 --> Helper loaded: language_helper
INFO - 2020-02-24 16:34:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:34:42 --> Helper loaded: email_helper
INFO - 2020-02-24 16:34:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:34:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:34:42 --> Parser Class Initialized
INFO - 2020-02-24 16:34:42 --> User Agent Class Initialized
INFO - 2020-02-24 16:34:42 --> Model Class Initialized
INFO - 2020-02-24 16:34:42 --> Database Driver Class Initialized
INFO - 2020-02-24 16:34:42 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:42 --> Template Class Initialized
INFO - 2020-02-24 16:34:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:34:42 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:34:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:34:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:34:42 --> Encryption Class Initialized
INFO - 2020-02-24 16:34:42 --> Controller Class Initialized
DEBUG - 2020-02-24 16:34:42 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:34:42 --> Model Class Initialized
ERROR - 2020-02-24 16:34:42 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:34:42 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:34:42 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:34:42 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:42 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:34:42 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:34:42 --> Final output sent to browser
DEBUG - 2020-02-24 16:34:42 --> Total execution time: 0.7896
INFO - 2020-02-24 16:34:52 --> Config Class Initialized
INFO - 2020-02-24 16:34:52 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:34:52 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:34:52 --> Utf8 Class Initialized
INFO - 2020-02-24 16:34:52 --> URI Class Initialized
INFO - 2020-02-24 16:34:52 --> Router Class Initialized
INFO - 2020-02-24 16:34:52 --> Output Class Initialized
INFO - 2020-02-24 16:34:52 --> Security Class Initialized
DEBUG - 2020-02-24 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:34:52 --> CSRF cookie sent
INFO - 2020-02-24 16:34:52 --> CSRF token verified
INFO - 2020-02-24 16:34:52 --> Input Class Initialized
INFO - 2020-02-24 16:34:52 --> Language Class Initialized
INFO - 2020-02-24 16:34:52 --> Language Class Initialized
INFO - 2020-02-24 16:34:53 --> Config Class Initialized
INFO - 2020-02-24 16:34:53 --> Loader Class Initialized
INFO - 2020-02-24 16:34:53 --> Helper loaded: url_helper
INFO - 2020-02-24 16:34:53 --> Helper loaded: common_helper
INFO - 2020-02-24 16:34:53 --> Helper loaded: language_helper
INFO - 2020-02-24 16:34:53 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:34:53 --> Helper loaded: email_helper
INFO - 2020-02-24 16:34:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:34:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:34:53 --> Parser Class Initialized
INFO - 2020-02-24 16:34:53 --> User Agent Class Initialized
INFO - 2020-02-24 16:34:53 --> Model Class Initialized
INFO - 2020-02-24 16:34:53 --> Database Driver Class Initialized
INFO - 2020-02-24 16:34:53 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:53 --> Template Class Initialized
INFO - 2020-02-24 16:34:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:34:53 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:34:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:34:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:34:53 --> Encryption Class Initialized
INFO - 2020-02-24 16:34:53 --> Controller Class Initialized
DEBUG - 2020-02-24 16:34:53 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:34:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:34:53 --> Model Class Initialized
ERROR - 2020-02-24 16:34:53 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:34:57 --> Config Class Initialized
INFO - 2020-02-24 16:34:57 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:34:57 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:34:57 --> Utf8 Class Initialized
INFO - 2020-02-24 16:34:57 --> URI Class Initialized
INFO - 2020-02-24 16:34:58 --> Router Class Initialized
INFO - 2020-02-24 16:34:58 --> Output Class Initialized
INFO - 2020-02-24 16:34:58 --> Security Class Initialized
DEBUG - 2020-02-24 16:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:34:58 --> CSRF cookie sent
INFO - 2020-02-24 16:34:58 --> Input Class Initialized
INFO - 2020-02-24 16:34:58 --> Language Class Initialized
INFO - 2020-02-24 16:34:58 --> Language Class Initialized
INFO - 2020-02-24 16:34:58 --> Config Class Initialized
INFO - 2020-02-24 16:34:58 --> Loader Class Initialized
INFO - 2020-02-24 16:34:58 --> Helper loaded: url_helper
INFO - 2020-02-24 16:34:58 --> Helper loaded: common_helper
INFO - 2020-02-24 16:34:58 --> Helper loaded: language_helper
INFO - 2020-02-24 16:34:58 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:34:58 --> Helper loaded: email_helper
INFO - 2020-02-24 16:34:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:34:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:34:58 --> Parser Class Initialized
INFO - 2020-02-24 16:34:58 --> User Agent Class Initialized
INFO - 2020-02-24 16:34:58 --> Model Class Initialized
INFO - 2020-02-24 16:34:58 --> Database Driver Class Initialized
INFO - 2020-02-24 16:34:58 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:58 --> Template Class Initialized
INFO - 2020-02-24 16:34:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:34:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:34:58 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:34:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:34:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:34:58 --> Encryption Class Initialized
INFO - 2020-02-24 16:34:58 --> Controller Class Initialized
DEBUG - 2020-02-24 16:34:58 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:34:58 --> Model Class Initialized
ERROR - 2020-02-24 16:34:58 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:34:58 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:34:58 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:34:58 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:58 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:34:58 --> Model Class Initialized
DEBUG - 2020-02-24 16:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:34:58 --> Final output sent to browser
DEBUG - 2020-02-24 16:34:58 --> Total execution time: 0.7513
INFO - 2020-02-24 16:35:42 --> Config Class Initialized
INFO - 2020-02-24 16:35:42 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:35:42 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:35:42 --> Utf8 Class Initialized
INFO - 2020-02-24 16:35:42 --> URI Class Initialized
INFO - 2020-02-24 16:35:42 --> Router Class Initialized
INFO - 2020-02-24 16:35:42 --> Output Class Initialized
INFO - 2020-02-24 16:35:42 --> Security Class Initialized
DEBUG - 2020-02-24 16:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:35:42 --> CSRF cookie sent
INFO - 2020-02-24 16:35:42 --> CSRF token verified
INFO - 2020-02-24 16:35:42 --> Input Class Initialized
INFO - 2020-02-24 16:35:42 --> Language Class Initialized
INFO - 2020-02-24 16:35:42 --> Language Class Initialized
INFO - 2020-02-24 16:35:42 --> Config Class Initialized
INFO - 2020-02-24 16:35:42 --> Loader Class Initialized
INFO - 2020-02-24 16:35:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:35:43 --> Helper loaded: common_helper
INFO - 2020-02-24 16:35:43 --> Helper loaded: language_helper
INFO - 2020-02-24 16:35:43 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:35:43 --> Helper loaded: email_helper
INFO - 2020-02-24 16:35:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:35:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:35:43 --> Parser Class Initialized
INFO - 2020-02-24 16:35:43 --> User Agent Class Initialized
INFO - 2020-02-24 16:35:43 --> Model Class Initialized
INFO - 2020-02-24 16:35:43 --> Database Driver Class Initialized
INFO - 2020-02-24 16:35:43 --> Model Class Initialized
DEBUG - 2020-02-24 16:35:43 --> Template Class Initialized
INFO - 2020-02-24 16:35:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:35:43 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:35:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:35:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:35:43 --> Encryption Class Initialized
INFO - 2020-02-24 16:35:43 --> Controller Class Initialized
DEBUG - 2020-02-24 16:35:43 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:35:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:35:43 --> Model Class Initialized
ERROR - 2020-02-24 16:35:43 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:35:47 --> Config Class Initialized
INFO - 2020-02-24 16:35:47 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:35:47 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:35:47 --> Utf8 Class Initialized
INFO - 2020-02-24 16:35:47 --> URI Class Initialized
INFO - 2020-02-24 16:35:47 --> Router Class Initialized
INFO - 2020-02-24 16:35:47 --> Output Class Initialized
INFO - 2020-02-24 16:35:48 --> Security Class Initialized
DEBUG - 2020-02-24 16:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:35:48 --> CSRF cookie sent
INFO - 2020-02-24 16:35:48 --> Input Class Initialized
INFO - 2020-02-24 16:35:48 --> Language Class Initialized
INFO - 2020-02-24 16:35:48 --> Language Class Initialized
INFO - 2020-02-24 16:35:48 --> Config Class Initialized
INFO - 2020-02-24 16:35:48 --> Loader Class Initialized
INFO - 2020-02-24 16:35:48 --> Helper loaded: url_helper
INFO - 2020-02-24 16:35:48 --> Helper loaded: common_helper
INFO - 2020-02-24 16:35:48 --> Helper loaded: language_helper
INFO - 2020-02-24 16:35:48 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:35:48 --> Helper loaded: email_helper
INFO - 2020-02-24 16:35:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:35:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:35:48 --> Parser Class Initialized
INFO - 2020-02-24 16:35:48 --> User Agent Class Initialized
INFO - 2020-02-24 16:35:48 --> Model Class Initialized
INFO - 2020-02-24 16:35:48 --> Database Driver Class Initialized
INFO - 2020-02-24 16:35:48 --> Model Class Initialized
DEBUG - 2020-02-24 16:35:48 --> Template Class Initialized
INFO - 2020-02-24 16:35:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:35:48 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:35:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:35:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:35:48 --> Encryption Class Initialized
INFO - 2020-02-24 16:35:48 --> Controller Class Initialized
DEBUG - 2020-02-24 16:35:48 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:35:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:35:48 --> Model Class Initialized
ERROR - 2020-02-24 16:35:48 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:35:48 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:35:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:35:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:35:48 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:35:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:35:48 --> Model Class Initialized
DEBUG - 2020-02-24 16:35:48 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:35:48 --> Model Class Initialized
DEBUG - 2020-02-24 16:35:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:35:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:35:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:35:48 --> Final output sent to browser
DEBUG - 2020-02-24 16:35:48 --> Total execution time: 0.8665
INFO - 2020-02-24 16:48:56 --> Config Class Initialized
INFO - 2020-02-24 16:48:56 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:48:56 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:48:56 --> Utf8 Class Initialized
INFO - 2020-02-24 16:48:56 --> URI Class Initialized
INFO - 2020-02-24 16:48:56 --> Router Class Initialized
INFO - 2020-02-24 16:48:56 --> Output Class Initialized
INFO - 2020-02-24 16:48:56 --> Security Class Initialized
DEBUG - 2020-02-24 16:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:48:56 --> CSRF cookie sent
INFO - 2020-02-24 16:48:56 --> Input Class Initialized
INFO - 2020-02-24 16:48:56 --> Language Class Initialized
INFO - 2020-02-24 16:48:56 --> Language Class Initialized
INFO - 2020-02-24 16:48:56 --> Config Class Initialized
INFO - 2020-02-24 16:48:56 --> Loader Class Initialized
INFO - 2020-02-24 16:48:56 --> Helper loaded: url_helper
INFO - 2020-02-24 16:48:56 --> Helper loaded: common_helper
INFO - 2020-02-24 16:48:56 --> Helper loaded: language_helper
INFO - 2020-02-24 16:48:56 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:48:56 --> Helper loaded: email_helper
INFO - 2020-02-24 16:48:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:48:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:48:56 --> Parser Class Initialized
INFO - 2020-02-24 16:48:56 --> User Agent Class Initialized
INFO - 2020-02-24 16:48:56 --> Model Class Initialized
INFO - 2020-02-24 16:48:56 --> Database Driver Class Initialized
INFO - 2020-02-24 16:48:56 --> Model Class Initialized
DEBUG - 2020-02-24 16:48:56 --> Template Class Initialized
INFO - 2020-02-24 16:48:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:48:56 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:48:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:48:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:48:56 --> Encryption Class Initialized
INFO - 2020-02-24 16:48:56 --> Controller Class Initialized
DEBUG - 2020-02-24 16:48:56 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:48:56 --> Model Class Initialized
ERROR - 2020-02-24 16:48:56 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:48:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:48:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:48:56 --> Model Class Initialized
DEBUG - 2020-02-24 16:48:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:48:57 --> Model Class Initialized
DEBUG - 2020-02-24 16:48:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:48:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:48:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:48:57 --> Final output sent to browser
DEBUG - 2020-02-24 16:48:57 --> Total execution time: 0.8163
INFO - 2020-02-24 16:48:58 --> Config Class Initialized
INFO - 2020-02-24 16:48:58 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:48:58 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:48:58 --> Utf8 Class Initialized
INFO - 2020-02-24 16:48:58 --> URI Class Initialized
INFO - 2020-02-24 16:48:58 --> Router Class Initialized
INFO - 2020-02-24 16:48:58 --> Output Class Initialized
INFO - 2020-02-24 16:48:58 --> Security Class Initialized
DEBUG - 2020-02-24 16:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:48:58 --> CSRF cookie sent
INFO - 2020-02-24 16:48:58 --> Input Class Initialized
INFO - 2020-02-24 16:48:59 --> Language Class Initialized
INFO - 2020-02-24 16:48:59 --> Language Class Initialized
INFO - 2020-02-24 16:48:59 --> Config Class Initialized
INFO - 2020-02-24 16:48:59 --> Loader Class Initialized
INFO - 2020-02-24 16:48:59 --> Helper loaded: url_helper
INFO - 2020-02-24 16:48:59 --> Helper loaded: common_helper
INFO - 2020-02-24 16:48:59 --> Helper loaded: language_helper
INFO - 2020-02-24 16:48:59 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:48:59 --> Helper loaded: email_helper
INFO - 2020-02-24 16:48:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:48:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:48:59 --> Parser Class Initialized
INFO - 2020-02-24 16:48:59 --> User Agent Class Initialized
INFO - 2020-02-24 16:48:59 --> Model Class Initialized
INFO - 2020-02-24 16:48:59 --> Database Driver Class Initialized
INFO - 2020-02-24 16:48:59 --> Model Class Initialized
DEBUG - 2020-02-24 16:48:59 --> Template Class Initialized
INFO - 2020-02-24 16:48:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:48:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:48:59 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:48:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:48:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:48:59 --> Encryption Class Initialized
INFO - 2020-02-24 16:48:59 --> Controller Class Initialized
DEBUG - 2020-02-24 16:48:59 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:48:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:48:59 --> Model Class Initialized
ERROR - 2020-02-24 16:48:59 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:48:59 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:48:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:48:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:48:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:48:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:48:59 --> Model Class Initialized
DEBUG - 2020-02-24 16:48:59 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:48:59 --> Model Class Initialized
DEBUG - 2020-02-24 16:48:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:48:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:48:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:48:59 --> Final output sent to browser
DEBUG - 2020-02-24 16:48:59 --> Total execution time: 0.8125
INFO - 2020-02-24 16:51:16 --> Config Class Initialized
INFO - 2020-02-24 16:51:16 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:51:16 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:51:16 --> Utf8 Class Initialized
INFO - 2020-02-24 16:51:16 --> URI Class Initialized
INFO - 2020-02-24 16:51:16 --> Router Class Initialized
INFO - 2020-02-24 16:51:16 --> Output Class Initialized
INFO - 2020-02-24 16:51:16 --> Security Class Initialized
DEBUG - 2020-02-24 16:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:51:16 --> CSRF cookie sent
INFO - 2020-02-24 16:51:16 --> CSRF token verified
INFO - 2020-02-24 16:51:16 --> Input Class Initialized
INFO - 2020-02-24 16:51:16 --> Language Class Initialized
INFO - 2020-02-24 16:51:16 --> Language Class Initialized
INFO - 2020-02-24 16:51:16 --> Config Class Initialized
INFO - 2020-02-24 16:51:16 --> Loader Class Initialized
INFO - 2020-02-24 16:51:16 --> Helper loaded: url_helper
INFO - 2020-02-24 16:51:16 --> Helper loaded: common_helper
INFO - 2020-02-24 16:51:16 --> Helper loaded: language_helper
INFO - 2020-02-24 16:51:16 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:51:16 --> Helper loaded: email_helper
INFO - 2020-02-24 16:51:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:51:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:51:16 --> Parser Class Initialized
INFO - 2020-02-24 16:51:16 --> User Agent Class Initialized
INFO - 2020-02-24 16:51:16 --> Model Class Initialized
INFO - 2020-02-24 16:51:16 --> Database Driver Class Initialized
INFO - 2020-02-24 16:51:16 --> Model Class Initialized
DEBUG - 2020-02-24 16:51:16 --> Template Class Initialized
INFO - 2020-02-24 16:51:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:51:16 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:51:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:51:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:51:16 --> Encryption Class Initialized
INFO - 2020-02-24 16:51:16 --> Controller Class Initialized
DEBUG - 2020-02-24 16:51:16 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:51:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:51:16 --> Model Class Initialized
ERROR - 2020-02-24 16:51:16 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:52:35 --> Config Class Initialized
INFO - 2020-02-24 16:52:35 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:52:35 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:52:35 --> Utf8 Class Initialized
INFO - 2020-02-24 16:52:35 --> URI Class Initialized
INFO - 2020-02-24 16:52:35 --> Router Class Initialized
INFO - 2020-02-24 16:52:35 --> Output Class Initialized
INFO - 2020-02-24 16:52:35 --> Security Class Initialized
DEBUG - 2020-02-24 16:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:52:35 --> CSRF cookie sent
INFO - 2020-02-24 16:52:35 --> CSRF token verified
INFO - 2020-02-24 16:52:35 --> Input Class Initialized
INFO - 2020-02-24 16:52:35 --> Language Class Initialized
INFO - 2020-02-24 16:52:35 --> Language Class Initialized
INFO - 2020-02-24 16:52:35 --> Config Class Initialized
INFO - 2020-02-24 16:52:35 --> Loader Class Initialized
INFO - 2020-02-24 16:52:35 --> Helper loaded: url_helper
INFO - 2020-02-24 16:52:35 --> Helper loaded: common_helper
INFO - 2020-02-24 16:52:35 --> Helper loaded: language_helper
INFO - 2020-02-24 16:52:35 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:52:35 --> Helper loaded: email_helper
INFO - 2020-02-24 16:52:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:52:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:52:35 --> Parser Class Initialized
INFO - 2020-02-24 16:52:35 --> User Agent Class Initialized
INFO - 2020-02-24 16:52:35 --> Model Class Initialized
INFO - 2020-02-24 16:52:35 --> Database Driver Class Initialized
INFO - 2020-02-24 16:52:35 --> Model Class Initialized
DEBUG - 2020-02-24 16:52:35 --> Template Class Initialized
INFO - 2020-02-24 16:52:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:52:35 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:52:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:52:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:52:35 --> Encryption Class Initialized
INFO - 2020-02-24 16:52:35 --> Controller Class Initialized
DEBUG - 2020-02-24 16:52:35 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:52:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:52:35 --> Model Class Initialized
ERROR - 2020-02-24 16:52:35 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:53:50 --> Config Class Initialized
INFO - 2020-02-24 16:53:50 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:53:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:53:50 --> Utf8 Class Initialized
INFO - 2020-02-24 16:53:50 --> URI Class Initialized
INFO - 2020-02-24 16:53:50 --> Router Class Initialized
INFO - 2020-02-24 16:53:50 --> Output Class Initialized
INFO - 2020-02-24 16:53:50 --> Security Class Initialized
DEBUG - 2020-02-24 16:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:53:50 --> CSRF cookie sent
INFO - 2020-02-24 16:53:50 --> CSRF token verified
INFO - 2020-02-24 16:53:51 --> Input Class Initialized
INFO - 2020-02-24 16:53:51 --> Language Class Initialized
INFO - 2020-02-24 16:53:51 --> Language Class Initialized
INFO - 2020-02-24 16:53:51 --> Config Class Initialized
INFO - 2020-02-24 16:53:51 --> Loader Class Initialized
INFO - 2020-02-24 16:53:51 --> Helper loaded: url_helper
INFO - 2020-02-24 16:53:51 --> Helper loaded: common_helper
INFO - 2020-02-24 16:53:51 --> Helper loaded: language_helper
INFO - 2020-02-24 16:53:51 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:53:51 --> Helper loaded: email_helper
INFO - 2020-02-24 16:53:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:53:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:53:51 --> Parser Class Initialized
INFO - 2020-02-24 16:53:51 --> User Agent Class Initialized
INFO - 2020-02-24 16:53:51 --> Model Class Initialized
INFO - 2020-02-24 16:53:51 --> Database Driver Class Initialized
INFO - 2020-02-24 16:53:51 --> Model Class Initialized
DEBUG - 2020-02-24 16:53:51 --> Template Class Initialized
INFO - 2020-02-24 16:53:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:53:51 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:53:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:53:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:53:51 --> Encryption Class Initialized
INFO - 2020-02-24 16:53:51 --> Controller Class Initialized
DEBUG - 2020-02-24 16:53:51 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:53:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:53:51 --> Model Class Initialized
ERROR - 2020-02-24 16:53:51 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:53:55 --> Config Class Initialized
INFO - 2020-02-24 16:53:55 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:53:55 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:53:56 --> Utf8 Class Initialized
INFO - 2020-02-24 16:53:56 --> URI Class Initialized
INFO - 2020-02-24 16:53:56 --> Router Class Initialized
INFO - 2020-02-24 16:53:56 --> Output Class Initialized
INFO - 2020-02-24 16:53:56 --> Security Class Initialized
DEBUG - 2020-02-24 16:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:53:56 --> CSRF cookie sent
INFO - 2020-02-24 16:53:56 --> Input Class Initialized
INFO - 2020-02-24 16:53:56 --> Language Class Initialized
INFO - 2020-02-24 16:53:56 --> Language Class Initialized
INFO - 2020-02-24 16:53:56 --> Config Class Initialized
INFO - 2020-02-24 16:53:56 --> Loader Class Initialized
INFO - 2020-02-24 16:53:56 --> Helper loaded: url_helper
INFO - 2020-02-24 16:53:56 --> Helper loaded: common_helper
INFO - 2020-02-24 16:53:56 --> Helper loaded: language_helper
INFO - 2020-02-24 16:53:56 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:53:56 --> Helper loaded: email_helper
INFO - 2020-02-24 16:53:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:53:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:53:56 --> Parser Class Initialized
INFO - 2020-02-24 16:53:56 --> User Agent Class Initialized
INFO - 2020-02-24 16:53:56 --> Model Class Initialized
INFO - 2020-02-24 16:53:56 --> Database Driver Class Initialized
INFO - 2020-02-24 16:53:56 --> Model Class Initialized
DEBUG - 2020-02-24 16:53:56 --> Template Class Initialized
INFO - 2020-02-24 16:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:53:56 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:53:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:53:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:53:56 --> Encryption Class Initialized
INFO - 2020-02-24 16:53:56 --> Controller Class Initialized
DEBUG - 2020-02-24 16:53:56 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:53:56 --> Model Class Initialized
ERROR - 2020-02-24 16:53:56 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:53:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:53:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:53:56 --> Model Class Initialized
DEBUG - 2020-02-24 16:53:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:53:56 --> Model Class Initialized
DEBUG - 2020-02-24 16:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:53:56 --> Final output sent to browser
DEBUG - 2020-02-24 16:53:56 --> Total execution time: 0.8202
INFO - 2020-02-24 16:54:03 --> Config Class Initialized
INFO - 2020-02-24 16:54:03 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:54:03 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:54:03 --> Utf8 Class Initialized
INFO - 2020-02-24 16:54:03 --> URI Class Initialized
INFO - 2020-02-24 16:54:03 --> Router Class Initialized
INFO - 2020-02-24 16:54:03 --> Output Class Initialized
INFO - 2020-02-24 16:54:03 --> Security Class Initialized
DEBUG - 2020-02-24 16:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:54:03 --> CSRF cookie sent
INFO - 2020-02-24 16:54:03 --> Input Class Initialized
INFO - 2020-02-24 16:54:03 --> Language Class Initialized
INFO - 2020-02-24 16:54:03 --> Language Class Initialized
INFO - 2020-02-24 16:54:03 --> Config Class Initialized
INFO - 2020-02-24 16:54:03 --> Loader Class Initialized
INFO - 2020-02-24 16:54:03 --> Helper loaded: url_helper
INFO - 2020-02-24 16:54:03 --> Helper loaded: common_helper
INFO - 2020-02-24 16:54:03 --> Helper loaded: language_helper
INFO - 2020-02-24 16:54:03 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:54:03 --> Helper loaded: email_helper
INFO - 2020-02-24 16:54:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:54:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:54:03 --> Parser Class Initialized
INFO - 2020-02-24 16:54:03 --> User Agent Class Initialized
INFO - 2020-02-24 16:54:03 --> Model Class Initialized
INFO - 2020-02-24 16:54:04 --> Database Driver Class Initialized
INFO - 2020-02-24 16:54:04 --> Model Class Initialized
DEBUG - 2020-02-24 16:54:04 --> Template Class Initialized
INFO - 2020-02-24 16:54:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:54:04 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:54:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:54:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:54:04 --> Encryption Class Initialized
INFO - 2020-02-24 16:54:04 --> Controller Class Initialized
DEBUG - 2020-02-24 16:54:04 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:54:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:54:04 --> Model Class Initialized
ERROR - 2020-02-24 16:54:04 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:54:04 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:54:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:54:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:54:04 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:54:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:54:04 --> Model Class Initialized
DEBUG - 2020-02-24 16:54:04 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:54:04 --> Model Class Initialized
DEBUG - 2020-02-24 16:54:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:54:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:54:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:54:04 --> Final output sent to browser
DEBUG - 2020-02-24 16:54:04 --> Total execution time: 0.8942
INFO - 2020-02-24 16:55:21 --> Config Class Initialized
INFO - 2020-02-24 16:55:21 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:55:21 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:55:21 --> Utf8 Class Initialized
INFO - 2020-02-24 16:55:21 --> URI Class Initialized
INFO - 2020-02-24 16:55:21 --> Router Class Initialized
INFO - 2020-02-24 16:55:21 --> Output Class Initialized
INFO - 2020-02-24 16:55:21 --> Security Class Initialized
DEBUG - 2020-02-24 16:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:55:21 --> CSRF cookie sent
INFO - 2020-02-24 16:55:21 --> Input Class Initialized
INFO - 2020-02-24 16:55:21 --> Language Class Initialized
INFO - 2020-02-24 16:55:21 --> Language Class Initialized
INFO - 2020-02-24 16:55:21 --> Config Class Initialized
INFO - 2020-02-24 16:55:21 --> Loader Class Initialized
INFO - 2020-02-24 16:55:21 --> Helper loaded: url_helper
INFO - 2020-02-24 16:55:21 --> Helper loaded: common_helper
INFO - 2020-02-24 16:55:21 --> Helper loaded: language_helper
INFO - 2020-02-24 16:55:21 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:55:21 --> Helper loaded: email_helper
INFO - 2020-02-24 16:55:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:55:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:55:21 --> Parser Class Initialized
INFO - 2020-02-24 16:55:21 --> User Agent Class Initialized
INFO - 2020-02-24 16:55:21 --> Model Class Initialized
INFO - 2020-02-24 16:55:21 --> Database Driver Class Initialized
INFO - 2020-02-24 16:55:21 --> Model Class Initialized
DEBUG - 2020-02-24 16:55:21 --> Template Class Initialized
INFO - 2020-02-24 16:55:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:55:21 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:55:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:55:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:55:21 --> Encryption Class Initialized
INFO - 2020-02-24 16:55:21 --> Controller Class Initialized
DEBUG - 2020-02-24 16:55:21 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:55:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:55:21 --> Model Class Initialized
ERROR - 2020-02-24 16:55:21 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:55:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:55:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:55:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:55:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:55:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:55:21 --> Model Class Initialized
DEBUG - 2020-02-24 16:55:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:55:21 --> Model Class Initialized
DEBUG - 2020-02-24 16:55:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:55:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:55:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:55:22 --> Final output sent to browser
DEBUG - 2020-02-24 16:55:22 --> Total execution time: 0.8266
INFO - 2020-02-24 16:55:40 --> Config Class Initialized
INFO - 2020-02-24 16:55:40 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:55:40 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:55:40 --> Utf8 Class Initialized
INFO - 2020-02-24 16:55:40 --> URI Class Initialized
INFO - 2020-02-24 16:55:40 --> Router Class Initialized
INFO - 2020-02-24 16:55:40 --> Output Class Initialized
INFO - 2020-02-24 16:55:40 --> Security Class Initialized
DEBUG - 2020-02-24 16:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:55:40 --> CSRF cookie sent
INFO - 2020-02-24 16:55:40 --> Input Class Initialized
INFO - 2020-02-24 16:55:40 --> Language Class Initialized
INFO - 2020-02-24 16:55:40 --> Language Class Initialized
INFO - 2020-02-24 16:55:40 --> Config Class Initialized
INFO - 2020-02-24 16:55:40 --> Loader Class Initialized
INFO - 2020-02-24 16:55:40 --> Helper loaded: url_helper
INFO - 2020-02-24 16:55:40 --> Helper loaded: common_helper
INFO - 2020-02-24 16:55:40 --> Helper loaded: language_helper
INFO - 2020-02-24 16:55:40 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:55:40 --> Helper loaded: email_helper
INFO - 2020-02-24 16:55:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:55:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:55:40 --> Parser Class Initialized
INFO - 2020-02-24 16:55:40 --> User Agent Class Initialized
INFO - 2020-02-24 16:55:40 --> Model Class Initialized
INFO - 2020-02-24 16:55:40 --> Database Driver Class Initialized
INFO - 2020-02-24 16:55:40 --> Model Class Initialized
DEBUG - 2020-02-24 16:55:40 --> Template Class Initialized
INFO - 2020-02-24 16:55:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:55:41 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:55:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:55:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:55:41 --> Encryption Class Initialized
INFO - 2020-02-24 16:55:41 --> Controller Class Initialized
DEBUG - 2020-02-24 16:55:41 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:55:41 --> Model Class Initialized
ERROR - 2020-02-24 16:55:41 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:56:02 --> Config Class Initialized
INFO - 2020-02-24 16:56:02 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:56:02 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:56:02 --> Utf8 Class Initialized
INFO - 2020-02-24 16:56:02 --> URI Class Initialized
INFO - 2020-02-24 16:56:02 --> Router Class Initialized
INFO - 2020-02-24 16:56:02 --> Output Class Initialized
INFO - 2020-02-24 16:56:02 --> Security Class Initialized
DEBUG - 2020-02-24 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:56:03 --> CSRF cookie sent
INFO - 2020-02-24 16:56:03 --> Input Class Initialized
INFO - 2020-02-24 16:56:03 --> Language Class Initialized
INFO - 2020-02-24 16:56:03 --> Language Class Initialized
INFO - 2020-02-24 16:56:03 --> Config Class Initialized
INFO - 2020-02-24 16:56:03 --> Loader Class Initialized
INFO - 2020-02-24 16:56:03 --> Helper loaded: url_helper
INFO - 2020-02-24 16:56:03 --> Helper loaded: common_helper
INFO - 2020-02-24 16:56:03 --> Helper loaded: language_helper
INFO - 2020-02-24 16:56:03 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:56:03 --> Helper loaded: email_helper
INFO - 2020-02-24 16:56:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:56:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:56:03 --> Parser Class Initialized
INFO - 2020-02-24 16:56:03 --> User Agent Class Initialized
INFO - 2020-02-24 16:56:03 --> Model Class Initialized
INFO - 2020-02-24 16:56:03 --> Database Driver Class Initialized
INFO - 2020-02-24 16:56:03 --> Model Class Initialized
DEBUG - 2020-02-24 16:56:03 --> Template Class Initialized
INFO - 2020-02-24 16:56:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:56:03 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:56:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:56:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:56:03 --> Encryption Class Initialized
INFO - 2020-02-24 16:56:03 --> Controller Class Initialized
DEBUG - 2020-02-24 16:56:03 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:56:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:56:03 --> Model Class Initialized
ERROR - 2020-02-24 16:56:03 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:56:20 --> Config Class Initialized
INFO - 2020-02-24 16:56:20 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:56:20 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:56:20 --> Utf8 Class Initialized
INFO - 2020-02-24 16:56:20 --> URI Class Initialized
INFO - 2020-02-24 16:56:20 --> Router Class Initialized
INFO - 2020-02-24 16:56:20 --> Output Class Initialized
INFO - 2020-02-24 16:56:20 --> Security Class Initialized
DEBUG - 2020-02-24 16:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:56:20 --> CSRF cookie sent
INFO - 2020-02-24 16:56:20 --> Input Class Initialized
INFO - 2020-02-24 16:56:20 --> Language Class Initialized
INFO - 2020-02-24 16:56:20 --> Language Class Initialized
INFO - 2020-02-24 16:56:20 --> Config Class Initialized
INFO - 2020-02-24 16:56:20 --> Loader Class Initialized
INFO - 2020-02-24 16:56:20 --> Helper loaded: url_helper
INFO - 2020-02-24 16:56:20 --> Helper loaded: common_helper
INFO - 2020-02-24 16:56:20 --> Helper loaded: language_helper
INFO - 2020-02-24 16:56:20 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:56:21 --> Helper loaded: email_helper
INFO - 2020-02-24 16:56:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:56:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:56:21 --> Parser Class Initialized
INFO - 2020-02-24 16:56:21 --> User Agent Class Initialized
INFO - 2020-02-24 16:56:21 --> Model Class Initialized
INFO - 2020-02-24 16:56:21 --> Database Driver Class Initialized
INFO - 2020-02-24 16:56:21 --> Model Class Initialized
DEBUG - 2020-02-24 16:56:21 --> Template Class Initialized
INFO - 2020-02-24 16:56:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:56:21 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:56:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:56:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:56:21 --> Encryption Class Initialized
INFO - 2020-02-24 16:56:21 --> Controller Class Initialized
DEBUG - 2020-02-24 16:56:21 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:56:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:56:21 --> Model Class Initialized
ERROR - 2020-02-24 16:56:21 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:56:42 --> Config Class Initialized
INFO - 2020-02-24 16:56:42 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:56:42 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:56:42 --> Utf8 Class Initialized
INFO - 2020-02-24 16:56:42 --> URI Class Initialized
INFO - 2020-02-24 16:56:42 --> Router Class Initialized
INFO - 2020-02-24 16:56:42 --> Output Class Initialized
INFO - 2020-02-24 16:56:42 --> Security Class Initialized
DEBUG - 2020-02-24 16:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:56:42 --> CSRF cookie sent
INFO - 2020-02-24 16:56:42 --> Input Class Initialized
INFO - 2020-02-24 16:56:42 --> Language Class Initialized
INFO - 2020-02-24 16:56:42 --> Language Class Initialized
INFO - 2020-02-24 16:56:42 --> Config Class Initialized
INFO - 2020-02-24 16:56:42 --> Loader Class Initialized
INFO - 2020-02-24 16:56:42 --> Helper loaded: url_helper
INFO - 2020-02-24 16:56:42 --> Helper loaded: common_helper
INFO - 2020-02-24 16:56:42 --> Helper loaded: language_helper
INFO - 2020-02-24 16:56:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:56:43 --> Helper loaded: email_helper
INFO - 2020-02-24 16:56:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:56:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:56:43 --> Parser Class Initialized
INFO - 2020-02-24 16:56:43 --> User Agent Class Initialized
INFO - 2020-02-24 16:56:43 --> Model Class Initialized
INFO - 2020-02-24 16:56:43 --> Database Driver Class Initialized
INFO - 2020-02-24 16:56:43 --> Model Class Initialized
DEBUG - 2020-02-24 16:56:43 --> Template Class Initialized
INFO - 2020-02-24 16:56:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:56:43 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:56:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:56:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:56:43 --> Encryption Class Initialized
INFO - 2020-02-24 16:56:43 --> Controller Class Initialized
DEBUG - 2020-02-24 16:56:43 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:56:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:56:43 --> Model Class Initialized
ERROR - 2020-02-24 16:56:43 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:57:25 --> Config Class Initialized
INFO - 2020-02-24 16:57:25 --> Hooks Class Initialized
DEBUG - 2020-02-24 16:57:25 --> UTF-8 Support Enabled
INFO - 2020-02-24 16:57:25 --> Utf8 Class Initialized
INFO - 2020-02-24 16:57:25 --> URI Class Initialized
INFO - 2020-02-24 16:57:25 --> Router Class Initialized
INFO - 2020-02-24 16:57:25 --> Output Class Initialized
INFO - 2020-02-24 16:57:25 --> Security Class Initialized
DEBUG - 2020-02-24 16:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 16:57:25 --> CSRF cookie sent
INFO - 2020-02-24 16:57:25 --> Input Class Initialized
INFO - 2020-02-24 16:57:25 --> Language Class Initialized
INFO - 2020-02-24 16:57:25 --> Language Class Initialized
INFO - 2020-02-24 16:57:25 --> Config Class Initialized
INFO - 2020-02-24 16:57:25 --> Loader Class Initialized
INFO - 2020-02-24 16:57:25 --> Helper loaded: url_helper
INFO - 2020-02-24 16:57:25 --> Helper loaded: common_helper
INFO - 2020-02-24 16:57:25 --> Helper loaded: language_helper
INFO - 2020-02-24 16:57:25 --> Helper loaded: cookie_helper
INFO - 2020-02-24 16:57:25 --> Helper loaded: email_helper
INFO - 2020-02-24 16:57:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 16:57:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 16:57:26 --> Parser Class Initialized
INFO - 2020-02-24 16:57:26 --> User Agent Class Initialized
INFO - 2020-02-24 16:57:26 --> Model Class Initialized
INFO - 2020-02-24 16:57:26 --> Database Driver Class Initialized
INFO - 2020-02-24 16:57:26 --> Model Class Initialized
DEBUG - 2020-02-24 16:57:26 --> Template Class Initialized
INFO - 2020-02-24 16:57:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 16:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 16:57:26 --> Pagination Class Initialized
DEBUG - 2020-02-24 16:57:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 16:57:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 16:57:26 --> Encryption Class Initialized
INFO - 2020-02-24 16:57:26 --> Controller Class Initialized
DEBUG - 2020-02-24 16:57:26 --> category MX_Controller Initialized
DEBUG - 2020-02-24 16:57:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:57:26 --> Model Class Initialized
ERROR - 2020-02-24 16:57:26 --> Could not find the language line "Sorting"
INFO - 2020-02-24 16:57:26 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 16:57:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 16:57:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 16:57:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 16:57:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 16:57:26 --> Model Class Initialized
DEBUG - 2020-02-24 16:57:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 16:57:26 --> Model Class Initialized
DEBUG - 2020-02-24 16:57:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 16:57:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 16:57:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 16:57:26 --> Final output sent to browser
DEBUG - 2020-02-24 16:57:26 --> Total execution time: 0.8679
INFO - 2020-02-24 17:09:34 --> Config Class Initialized
INFO - 2020-02-24 17:09:34 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:09:34 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:09:34 --> Utf8 Class Initialized
INFO - 2020-02-24 17:09:34 --> URI Class Initialized
INFO - 2020-02-24 17:09:34 --> Router Class Initialized
INFO - 2020-02-24 17:09:34 --> Output Class Initialized
INFO - 2020-02-24 17:09:34 --> Security Class Initialized
DEBUG - 2020-02-24 17:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:09:34 --> CSRF cookie sent
INFO - 2020-02-24 17:09:34 --> CSRF token verified
INFO - 2020-02-24 17:09:35 --> Input Class Initialized
INFO - 2020-02-24 17:09:35 --> Language Class Initialized
INFO - 2020-02-24 17:09:35 --> Language Class Initialized
INFO - 2020-02-24 17:09:35 --> Config Class Initialized
INFO - 2020-02-24 17:09:35 --> Loader Class Initialized
INFO - 2020-02-24 17:09:35 --> Helper loaded: url_helper
INFO - 2020-02-24 17:09:35 --> Helper loaded: common_helper
INFO - 2020-02-24 17:09:35 --> Helper loaded: language_helper
INFO - 2020-02-24 17:09:35 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:09:35 --> Helper loaded: email_helper
INFO - 2020-02-24 17:09:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:09:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:09:35 --> Parser Class Initialized
INFO - 2020-02-24 17:09:35 --> User Agent Class Initialized
INFO - 2020-02-24 17:09:35 --> Model Class Initialized
INFO - 2020-02-24 17:09:35 --> Database Driver Class Initialized
INFO - 2020-02-24 17:09:35 --> Model Class Initialized
DEBUG - 2020-02-24 17:09:35 --> Template Class Initialized
INFO - 2020-02-24 17:09:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:09:35 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:09:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:09:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:09:35 --> Encryption Class Initialized
INFO - 2020-02-24 17:09:35 --> Controller Class Initialized
DEBUG - 2020-02-24 17:09:35 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:09:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:09:35 --> Model Class Initialized
ERROR - 2020-02-24 17:09:35 --> Could not find the language line "Sorting"
INFO - 2020-02-24 17:09:39 --> Config Class Initialized
INFO - 2020-02-24 17:09:40 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:09:40 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:09:40 --> Utf8 Class Initialized
INFO - 2020-02-24 17:09:40 --> URI Class Initialized
INFO - 2020-02-24 17:09:40 --> Router Class Initialized
INFO - 2020-02-24 17:09:40 --> Output Class Initialized
INFO - 2020-02-24 17:09:40 --> Security Class Initialized
DEBUG - 2020-02-24 17:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:09:40 --> CSRF cookie sent
INFO - 2020-02-24 17:09:40 --> Input Class Initialized
INFO - 2020-02-24 17:09:40 --> Language Class Initialized
INFO - 2020-02-24 17:09:40 --> Language Class Initialized
INFO - 2020-02-24 17:09:40 --> Config Class Initialized
INFO - 2020-02-24 17:09:40 --> Loader Class Initialized
INFO - 2020-02-24 17:09:40 --> Helper loaded: url_helper
INFO - 2020-02-24 17:09:40 --> Helper loaded: common_helper
INFO - 2020-02-24 17:09:40 --> Helper loaded: language_helper
INFO - 2020-02-24 17:09:40 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:09:40 --> Helper loaded: email_helper
INFO - 2020-02-24 17:09:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:09:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:09:40 --> Parser Class Initialized
INFO - 2020-02-24 17:09:40 --> User Agent Class Initialized
INFO - 2020-02-24 17:09:40 --> Model Class Initialized
INFO - 2020-02-24 17:09:40 --> Database Driver Class Initialized
INFO - 2020-02-24 17:09:40 --> Model Class Initialized
DEBUG - 2020-02-24 17:09:40 --> Template Class Initialized
INFO - 2020-02-24 17:09:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:09:40 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:09:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:09:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:09:40 --> Encryption Class Initialized
INFO - 2020-02-24 17:09:40 --> Controller Class Initialized
DEBUG - 2020-02-24 17:09:40 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:09:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:09:40 --> Model Class Initialized
ERROR - 2020-02-24 17:09:40 --> Could not find the language line "Sorting"
INFO - 2020-02-24 17:09:40 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 17:09:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 17:09:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 17:09:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 17:09:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 17:09:40 --> Model Class Initialized
DEBUG - 2020-02-24 17:09:40 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:09:40 --> Model Class Initialized
DEBUG - 2020-02-24 17:09:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 17:09:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 17:09:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 17:09:40 --> Final output sent to browser
DEBUG - 2020-02-24 17:09:40 --> Total execution time: 0.8320
INFO - 2020-02-24 17:10:20 --> Config Class Initialized
INFO - 2020-02-24 17:10:20 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:10:20 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:10:20 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:20 --> URI Class Initialized
INFO - 2020-02-24 17:10:20 --> Router Class Initialized
INFO - 2020-02-24 17:10:21 --> Output Class Initialized
INFO - 2020-02-24 17:10:21 --> Security Class Initialized
DEBUG - 2020-02-24 17:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:10:21 --> CSRF cookie sent
INFO - 2020-02-24 17:10:21 --> Input Class Initialized
INFO - 2020-02-24 17:10:21 --> Language Class Initialized
INFO - 2020-02-24 17:10:21 --> Language Class Initialized
INFO - 2020-02-24 17:10:21 --> Config Class Initialized
INFO - 2020-02-24 17:10:21 --> Loader Class Initialized
INFO - 2020-02-24 17:10:21 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:21 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:21 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:21 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:21 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:21 --> Parser Class Initialized
INFO - 2020-02-24 17:10:21 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:21 --> Model Class Initialized
INFO - 2020-02-24 17:10:21 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:21 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:21 --> Template Class Initialized
INFO - 2020-02-24 17:10:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:21 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:21 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:21 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:21 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:21 --> Model Class Initialized
ERROR - 2020-02-24 17:10:21 --> Could not find the language line "Sorting"
INFO - 2020-02-24 17:10:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 17:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 17:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 17:10:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 17:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 17:10:21 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:21 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 17:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 17:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 17:10:21 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:21 --> Total execution time: 0.8081
INFO - 2020-02-24 17:10:24 --> Config Class Initialized
INFO - 2020-02-24 17:10:24 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:10:24 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:10:24 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:24 --> URI Class Initialized
INFO - 2020-02-24 17:10:24 --> Router Class Initialized
INFO - 2020-02-24 17:10:24 --> Output Class Initialized
INFO - 2020-02-24 17:10:24 --> Security Class Initialized
DEBUG - 2020-02-24 17:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:10:24 --> CSRF cookie sent
INFO - 2020-02-24 17:10:25 --> Input Class Initialized
INFO - 2020-02-24 17:10:25 --> Language Class Initialized
INFO - 2020-02-24 17:10:25 --> Language Class Initialized
INFO - 2020-02-24 17:10:25 --> Config Class Initialized
INFO - 2020-02-24 17:10:25 --> Loader Class Initialized
INFO - 2020-02-24 17:10:25 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:25 --> Parser Class Initialized
INFO - 2020-02-24 17:10:25 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:25 --> Model Class Initialized
INFO - 2020-02-24 17:10:25 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:25 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:25 --> Template Class Initialized
INFO - 2020-02-24 17:10:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:25 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:25 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:25 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:25 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:25 --> Model Class Initialized
ERROR - 2020-02-24 17:10:25 --> Could not find the language line "Sorting"
INFO - 2020-02-24 17:10:25 --> Config Class Initialized
INFO - 2020-02-24 17:10:25 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:10:25 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:10:25 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:25 --> URI Class Initialized
INFO - 2020-02-24 17:10:25 --> Router Class Initialized
INFO - 2020-02-24 17:10:25 --> Output Class Initialized
INFO - 2020-02-24 17:10:25 --> Security Class Initialized
DEBUG - 2020-02-24 17:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:10:25 --> CSRF cookie sent
INFO - 2020-02-24 17:10:25 --> Input Class Initialized
INFO - 2020-02-24 17:10:25 --> Language Class Initialized
INFO - 2020-02-24 17:10:25 --> Language Class Initialized
INFO - 2020-02-24 17:10:25 --> Config Class Initialized
INFO - 2020-02-24 17:10:25 --> Loader Class Initialized
INFO - 2020-02-24 17:10:25 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:25 --> Parser Class Initialized
INFO - 2020-02-24 17:10:25 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:25 --> Model Class Initialized
INFO - 2020-02-24 17:10:25 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:25 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:25 --> Template Class Initialized
INFO - 2020-02-24 17:10:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:25 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:25 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:25 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:25 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:25 --> Model Class Initialized
ERROR - 2020-02-24 17:10:25 --> Could not find the language line "Sorting"
INFO - 2020-02-24 17:10:25 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 17:10:26 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 17:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 17:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 17:10:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 17:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 17:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 17:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 17:10:26 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:26 --> Total execution time: 0.7917
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:26 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:26 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:26 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:26 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:26 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:10:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:26 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:26 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:10:26 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:26 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:26 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:26 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:26 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:26 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:26 --> URI Class Initialized
INFO - 2020-02-24 17:10:26 --> URI Class Initialized
INFO - 2020-02-24 17:10:26 --> URI Class Initialized
INFO - 2020-02-24 17:10:26 --> URI Class Initialized
INFO - 2020-02-24 17:10:26 --> URI Class Initialized
INFO - 2020-02-24 17:10:26 --> URI Class Initialized
INFO - 2020-02-24 17:10:26 --> Router Class Initialized
INFO - 2020-02-24 17:10:26 --> Router Class Initialized
INFO - 2020-02-24 17:10:26 --> Router Class Initialized
INFO - 2020-02-24 17:10:26 --> Router Class Initialized
INFO - 2020-02-24 17:10:26 --> Router Class Initialized
INFO - 2020-02-24 17:10:26 --> Router Class Initialized
INFO - 2020-02-24 17:10:26 --> Output Class Initialized
INFO - 2020-02-24 17:10:26 --> Output Class Initialized
INFO - 2020-02-24 17:10:26 --> Output Class Initialized
INFO - 2020-02-24 17:10:26 --> Output Class Initialized
INFO - 2020-02-24 17:10:26 --> Output Class Initialized
INFO - 2020-02-24 17:10:26 --> Output Class Initialized
INFO - 2020-02-24 17:10:26 --> Security Class Initialized
INFO - 2020-02-24 17:10:26 --> Security Class Initialized
INFO - 2020-02-24 17:10:26 --> Security Class Initialized
INFO - 2020-02-24 17:10:26 --> Security Class Initialized
INFO - 2020-02-24 17:10:26 --> Security Class Initialized
INFO - 2020-02-24 17:10:26 --> Security Class Initialized
DEBUG - 2020-02-24 17:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:10:26 --> CSRF cookie sent
INFO - 2020-02-24 17:10:26 --> CSRF cookie sent
INFO - 2020-02-24 17:10:26 --> CSRF cookie sent
INFO - 2020-02-24 17:10:26 --> CSRF cookie sent
INFO - 2020-02-24 17:10:26 --> CSRF cookie sent
INFO - 2020-02-24 17:10:26 --> CSRF cookie sent
INFO - 2020-02-24 17:10:26 --> CSRF token verified
INFO - 2020-02-24 17:10:26 --> CSRF token verified
INFO - 2020-02-24 17:10:26 --> CSRF token verified
INFO - 2020-02-24 17:10:26 --> CSRF token verified
INFO - 2020-02-24 17:10:26 --> CSRF token verified
INFO - 2020-02-24 17:10:26 --> CSRF token verified
INFO - 2020-02-24 17:10:26 --> Input Class Initialized
INFO - 2020-02-24 17:10:26 --> Input Class Initialized
INFO - 2020-02-24 17:10:26 --> Input Class Initialized
INFO - 2020-02-24 17:10:26 --> Input Class Initialized
INFO - 2020-02-24 17:10:26 --> Input Class Initialized
INFO - 2020-02-24 17:10:26 --> Input Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Language Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Config Class Initialized
INFO - 2020-02-24 17:10:26 --> Loader Class Initialized
INFO - 2020-02-24 17:10:26 --> Loader Class Initialized
INFO - 2020-02-24 17:10:26 --> Loader Class Initialized
INFO - 2020-02-24 17:10:26 --> Loader Class Initialized
INFO - 2020-02-24 17:10:26 --> Loader Class Initialized
INFO - 2020-02-24 17:10:26 --> Loader Class Initialized
INFO - 2020-02-24 17:10:26 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:26 --> Parser Class Initialized
INFO - 2020-02-24 17:10:26 --> Parser Class Initialized
INFO - 2020-02-24 17:10:26 --> Parser Class Initialized
INFO - 2020-02-24 17:10:26 --> Parser Class Initialized
INFO - 2020-02-24 17:10:26 --> Parser Class Initialized
INFO - 2020-02-24 17:10:26 --> Parser Class Initialized
INFO - 2020-02-24 17:10:26 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:26 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:26 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:26 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:26 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:26 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:26 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:26 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:26 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:26 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:26 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
INFO - 2020-02-24 17:10:26 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:26 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:26 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:26 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:26 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:26 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:26 --> Template Class Initialized
INFO - 2020-02-24 17:10:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:27 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:27 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:27 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:27 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:27 --> Model Class Initialized
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:27 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:27 --> Total execution time: 0.7121
INFO - 2020-02-24 17:10:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:27 --> Config Class Initialized
INFO - 2020-02-24 17:10:27 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:27 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:27 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:10:27 --> Utf8 Class Initialized
DEBUG - 2020-02-24 17:10:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:27 --> URI Class Initialized
INFO - 2020-02-24 17:10:27 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:27 --> Router Class Initialized
INFO - 2020-02-24 17:10:27 --> Controller Class Initialized
INFO - 2020-02-24 17:10:27 --> Output Class Initialized
DEBUG - 2020-02-24 17:10:27 --> category MX_Controller Initialized
INFO - 2020-02-24 17:10:27 --> Security Class Initialized
DEBUG - 2020-02-24 17:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:27 --> Model Class Initialized
INFO - 2020-02-24 17:10:27 --> CSRF cookie sent
INFO - 2020-02-24 17:10:27 --> CSRF token verified
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "Sorting"
INFO - 2020-02-24 17:10:27 --> Input Class Initialized
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "View"
INFO - 2020-02-24 17:10:27 --> Language Class Initialized
DEBUG - 2020-02-24 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:27 --> Final output sent to browser
INFO - 2020-02-24 17:10:27 --> Language Class Initialized
INFO - 2020-02-24 17:10:27 --> Config Class Initialized
DEBUG - 2020-02-24 17:10:27 --> Total execution time: 0.8992
INFO - 2020-02-24 17:10:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:27 --> Loader Class Initialized
INFO - 2020-02-24 17:10:27 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:27 --> Pagination Class Initialized
INFO - 2020-02-24 17:10:27 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:27 --> Helper loaded: language_helper
DEBUG - 2020-02-24 17:10:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:27 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:27 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:27 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:27 --> Controller Class Initialized
INFO - 2020-02-24 17:10:27 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-24 17:10:27 --> category MX_Controller Initialized
INFO - 2020-02-24 17:10:27 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:27 --> Parser Class Initialized
INFO - 2020-02-24 17:10:27 --> Model Class Initialized
INFO - 2020-02-24 17:10:27 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:27 --> Model Class Initialized
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "Sorting"
INFO - 2020-02-24 17:10:27 --> Database Driver Class Initialized
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:27 --> Model Class Initialized
INFO - 2020-02-24 17:10:27 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:27 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:27 --> Total execution time: 1.1066
INFO - 2020-02-24 17:10:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:27 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:27 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:27 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:27 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:27 --> Model Class Initialized
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:27 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:27 --> Total execution time: 1.3028
INFO - 2020-02-24 17:10:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:27 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:27 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:27 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:27 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:27 --> Model Class Initialized
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:27 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:28 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:28 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:28 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:28 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:28 --> Total execution time: 1.6240
INFO - 2020-02-24 17:10:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:28 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:28 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:28 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:28 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:28 --> Model Class Initialized
ERROR - 2020-02-24 17:10:28 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:28 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:28 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:28 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:28 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:28 --> Total execution time: 1.8992
INFO - 2020-02-24 17:10:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:28 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:28 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:28 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:28 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:28 --> Model Class Initialized
ERROR - 2020-02-24 17:10:28 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:28 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:28 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:28 --> Total execution time: 1.3648
INFO - 2020-02-24 17:10:34 --> Config Class Initialized
INFO - 2020-02-24 17:10:34 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:10:34 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:10:34 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:34 --> URI Class Initialized
INFO - 2020-02-24 17:10:34 --> Router Class Initialized
INFO - 2020-02-24 17:10:34 --> Output Class Initialized
INFO - 2020-02-24 17:10:34 --> Security Class Initialized
DEBUG - 2020-02-24 17:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:10:34 --> CSRF cookie sent
INFO - 2020-02-24 17:10:34 --> Input Class Initialized
INFO - 2020-02-24 17:10:34 --> Language Class Initialized
INFO - 2020-02-24 17:10:34 --> Language Class Initialized
INFO - 2020-02-24 17:10:34 --> Config Class Initialized
INFO - 2020-02-24 17:10:34 --> Loader Class Initialized
INFO - 2020-02-24 17:10:34 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:34 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:34 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:34 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:34 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:34 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:34 --> Parser Class Initialized
INFO - 2020-02-24 17:10:34 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:34 --> Model Class Initialized
INFO - 2020-02-24 17:10:35 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:35 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:35 --> Template Class Initialized
INFO - 2020-02-24 17:10:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:35 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:35 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:35 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:35 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:35 --> Model Class Initialized
ERROR - 2020-02-24 17:10:35 --> Could not find the language line "Sorting"
INFO - 2020-02-24 17:10:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 17:10:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 17:10:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 17:10:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 17:10:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 17:10:35 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:35 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:35 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 17:10:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 17:10:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 17:10:35 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:35 --> Total execution time: 1.2475
INFO - 2020-02-24 17:10:37 --> Config Class Initialized
INFO - 2020-02-24 17:10:37 --> Config Class Initialized
INFO - 2020-02-24 17:10:37 --> Config Class Initialized
INFO - 2020-02-24 17:10:37 --> Config Class Initialized
INFO - 2020-02-24 17:10:38 --> Config Class Initialized
INFO - 2020-02-24 17:10:38 --> Config Class Initialized
INFO - 2020-02-24 17:10:38 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:38 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:38 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:38 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:38 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:38 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:10:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 17:10:38 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:10:38 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:38 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:38 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:38 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:38 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:38 --> Utf8 Class Initialized
INFO - 2020-02-24 17:10:38 --> URI Class Initialized
INFO - 2020-02-24 17:10:38 --> URI Class Initialized
INFO - 2020-02-24 17:10:38 --> URI Class Initialized
INFO - 2020-02-24 17:10:38 --> URI Class Initialized
INFO - 2020-02-24 17:10:38 --> URI Class Initialized
INFO - 2020-02-24 17:10:38 --> URI Class Initialized
INFO - 2020-02-24 17:10:38 --> Router Class Initialized
INFO - 2020-02-24 17:10:38 --> Router Class Initialized
INFO - 2020-02-24 17:10:38 --> Router Class Initialized
INFO - 2020-02-24 17:10:38 --> Router Class Initialized
INFO - 2020-02-24 17:10:38 --> Router Class Initialized
INFO - 2020-02-24 17:10:38 --> Router Class Initialized
INFO - 2020-02-24 17:10:38 --> Output Class Initialized
INFO - 2020-02-24 17:10:38 --> Output Class Initialized
INFO - 2020-02-24 17:10:38 --> Output Class Initialized
INFO - 2020-02-24 17:10:38 --> Output Class Initialized
INFO - 2020-02-24 17:10:38 --> Output Class Initialized
INFO - 2020-02-24 17:10:38 --> Output Class Initialized
INFO - 2020-02-24 17:10:38 --> Security Class Initialized
INFO - 2020-02-24 17:10:38 --> Security Class Initialized
INFO - 2020-02-24 17:10:38 --> Security Class Initialized
INFO - 2020-02-24 17:10:38 --> Security Class Initialized
INFO - 2020-02-24 17:10:38 --> Security Class Initialized
INFO - 2020-02-24 17:10:38 --> Security Class Initialized
DEBUG - 2020-02-24 17:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 17:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:10:38 --> CSRF cookie sent
INFO - 2020-02-24 17:10:38 --> CSRF cookie sent
INFO - 2020-02-24 17:10:38 --> CSRF cookie sent
INFO - 2020-02-24 17:10:38 --> CSRF cookie sent
INFO - 2020-02-24 17:10:38 --> CSRF cookie sent
INFO - 2020-02-24 17:10:38 --> CSRF cookie sent
INFO - 2020-02-24 17:10:38 --> CSRF token verified
INFO - 2020-02-24 17:10:38 --> CSRF token verified
INFO - 2020-02-24 17:10:38 --> CSRF token verified
INFO - 2020-02-24 17:10:38 --> CSRF token verified
INFO - 2020-02-24 17:10:38 --> CSRF token verified
INFO - 2020-02-24 17:10:38 --> CSRF token verified
INFO - 2020-02-24 17:10:38 --> Input Class Initialized
INFO - 2020-02-24 17:10:38 --> Input Class Initialized
INFO - 2020-02-24 17:10:38 --> Input Class Initialized
INFO - 2020-02-24 17:10:38 --> Input Class Initialized
INFO - 2020-02-24 17:10:38 --> Input Class Initialized
INFO - 2020-02-24 17:10:38 --> Input Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Language Class Initialized
INFO - 2020-02-24 17:10:38 --> Config Class Initialized
INFO - 2020-02-24 17:10:38 --> Config Class Initialized
INFO - 2020-02-24 17:10:38 --> Config Class Initialized
INFO - 2020-02-24 17:10:38 --> Config Class Initialized
INFO - 2020-02-24 17:10:38 --> Config Class Initialized
INFO - 2020-02-24 17:10:38 --> Config Class Initialized
INFO - 2020-02-24 17:10:38 --> Loader Class Initialized
INFO - 2020-02-24 17:10:38 --> Loader Class Initialized
INFO - 2020-02-24 17:10:38 --> Loader Class Initialized
INFO - 2020-02-24 17:10:38 --> Loader Class Initialized
INFO - 2020-02-24 17:10:38 --> Loader Class Initialized
INFO - 2020-02-24 17:10:38 --> Loader Class Initialized
INFO - 2020-02-24 17:10:38 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: url_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: language_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:10:38 --> Parser Class Initialized
INFO - 2020-02-24 17:10:38 --> Parser Class Initialized
INFO - 2020-02-24 17:10:38 --> Parser Class Initialized
INFO - 2020-02-24 17:10:38 --> Parser Class Initialized
INFO - 2020-02-24 17:10:38 --> Parser Class Initialized
INFO - 2020-02-24 17:10:38 --> Parser Class Initialized
INFO - 2020-02-24 17:10:38 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:38 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:38 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:38 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:38 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:38 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:38 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:38 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:38 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:38 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:38 --> Database Driver Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
INFO - 2020-02-24 17:10:38 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:38 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:38 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:38 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:38 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:38 --> Template Class Initialized
DEBUG - 2020-02-24 17:10:38 --> Template Class Initialized
INFO - 2020-02-24 17:10:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:38 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:38 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:38 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:38 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:39 --> Model Class Initialized
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:39 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:39 --> Total execution time: 1.0934
INFO - 2020-02-24 17:10:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:39 --> Config Class Initialized
INFO - 2020-02-24 17:10:39 --> Hooks Class Initialized
INFO - 2020-02-24 17:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:39 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:39 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:10:39 --> Utf8 Class Initialized
DEBUG - 2020-02-24 17:10:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:39 --> URI Class Initialized
INFO - 2020-02-24 17:10:39 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:39 --> Router Class Initialized
INFO - 2020-02-24 17:10:39 --> Controller Class Initialized
INFO - 2020-02-24 17:10:39 --> Output Class Initialized
DEBUG - 2020-02-24 17:10:39 --> category MX_Controller Initialized
INFO - 2020-02-24 17:10:39 --> Security Class Initialized
DEBUG - 2020-02-24 17:10:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
DEBUG - 2020-02-24 17:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:10:39 --> Model Class Initialized
INFO - 2020-02-24 17:10:39 --> CSRF cookie sent
INFO - 2020-02-24 17:10:39 --> CSRF token verified
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "Sorting"
INFO - 2020-02-24 17:10:39 --> Input Class Initialized
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "View"
INFO - 2020-02-24 17:10:39 --> Language Class Initialized
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "View"
INFO - 2020-02-24 17:10:39 --> Language Class Initialized
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "View"
INFO - 2020-02-24 17:10:39 --> Config Class Initialized
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "View"
INFO - 2020-02-24 17:10:39 --> Loader Class Initialized
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "View"
INFO - 2020-02-24 17:10:39 --> Helper loaded: url_helper
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:39 --> Helper loaded: common_helper
INFO - 2020-02-24 17:10:39 --> Final output sent to browser
INFO - 2020-02-24 17:10:39 --> Helper loaded: language_helper
DEBUG - 2020-02-24 17:10:39 --> Total execution time: 1.4787
INFO - 2020-02-24 17:10:39 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:10:39 --> Helper loaded: email_helper
INFO - 2020-02-24 17:10:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:39 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:39 --> Pagination Class Initialized
INFO - 2020-02-24 17:10:39 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 17:10:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:39 --> Parser Class Initialized
INFO - 2020-02-24 17:10:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:39 --> User Agent Class Initialized
INFO - 2020-02-24 17:10:39 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:39 --> Model Class Initialized
INFO - 2020-02-24 17:10:39 --> Controller Class Initialized
INFO - 2020-02-24 17:10:39 --> Database Driver Class Initialized
DEBUG - 2020-02-24 17:10:39 --> category MX_Controller Initialized
INFO - 2020-02-24 17:10:39 --> Model Class Initialized
DEBUG - 2020-02-24 17:10:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
DEBUG - 2020-02-24 17:10:39 --> Template Class Initialized
INFO - 2020-02-24 17:10:39 --> Model Class Initialized
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:39 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:39 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:39 --> Total execution time: 1.8086
INFO - 2020-02-24 17:10:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:39 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:39 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:39 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:40 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:40 --> Model Class Initialized
ERROR - 2020-02-24 17:10:40 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:40 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:40 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:40 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:40 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:40 --> Total execution time: 2.1961
INFO - 2020-02-24 17:10:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:40 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:40 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:40 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:40 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:40 --> Model Class Initialized
ERROR - 2020-02-24 17:10:40 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:40 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:40 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:40 --> Total execution time: 2.7158
INFO - 2020-02-24 17:10:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:40 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:40 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:40 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:40 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:40 --> Model Class Initialized
ERROR - 2020-02-24 17:10:40 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:40 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:40 --> Could not find the language line "View"
ERROR - 2020-02-24 17:10:41 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:41 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:41 --> Total execution time: 3.0589
INFO - 2020-02-24 17:10:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:10:41 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:10:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:10:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:10:41 --> Encryption Class Initialized
INFO - 2020-02-24 17:10:41 --> Controller Class Initialized
DEBUG - 2020-02-24 17:10:41 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:10:41 --> Model Class Initialized
ERROR - 2020-02-24 17:10:41 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:10:41 --> Could not find the language line "View"
DEBUG - 2020-02-24 17:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 17:10:41 --> Final output sent to browser
DEBUG - 2020-02-24 17:10:41 --> Total execution time: 2.1673
INFO - 2020-02-24 17:59:36 --> Config Class Initialized
INFO - 2020-02-24 17:59:36 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:36 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:36 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:36 --> URI Class Initialized
INFO - 2020-02-24 17:59:37 --> Router Class Initialized
INFO - 2020-02-24 17:59:37 --> Output Class Initialized
INFO - 2020-02-24 17:59:37 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:37 --> CSRF cookie sent
INFO - 2020-02-24 17:59:37 --> Input Class Initialized
INFO - 2020-02-24 17:59:37 --> Language Class Initialized
INFO - 2020-02-24 17:59:37 --> Language Class Initialized
INFO - 2020-02-24 17:59:37 --> Config Class Initialized
INFO - 2020-02-24 17:59:37 --> Loader Class Initialized
INFO - 2020-02-24 17:59:37 --> Helper loaded: url_helper
INFO - 2020-02-24 17:59:37 --> Helper loaded: common_helper
INFO - 2020-02-24 17:59:37 --> Helper loaded: language_helper
INFO - 2020-02-24 17:59:37 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:59:37 --> Helper loaded: email_helper
INFO - 2020-02-24 17:59:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:59:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:59:37 --> Parser Class Initialized
INFO - 2020-02-24 17:59:37 --> User Agent Class Initialized
INFO - 2020-02-24 17:59:37 --> Model Class Initialized
INFO - 2020-02-24 17:59:37 --> Database Driver Class Initialized
INFO - 2020-02-24 17:59:37 --> Model Class Initialized
DEBUG - 2020-02-24 17:59:37 --> Template Class Initialized
INFO - 2020-02-24 17:59:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:59:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:59:37 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:59:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:59:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:59:37 --> Encryption Class Initialized
INFO - 2020-02-24 17:59:37 --> Controller Class Initialized
DEBUG - 2020-02-24 17:59:37 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:59:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:59:37 --> Model Class Initialized
ERROR - 2020-02-24 17:59:37 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:59:37 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 22
ERROR - 2020-02-24 17:59:37 --> Query error: Unknown table 'tuyen_smmstore.s' - Invalid query: SELECT `s`.*, `sn`.`name` as `social_network_name`, `sn`.`id` as `main_sn_id`
FROM `categories` `c`
LEFT JOIN `social_network_categories` `sn` ON `sn`.`id` = `c`.`sncate_id`
WHERE `c`.`sncate_id` IS NULL
INFO - 2020-02-24 17:59:37 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-24 17:59:41 --> Config Class Initialized
INFO - 2020-02-24 17:59:41 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:41 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:41 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:41 --> URI Class Initialized
INFO - 2020-02-24 17:59:41 --> Router Class Initialized
INFO - 2020-02-24 17:59:41 --> Output Class Initialized
INFO - 2020-02-24 17:59:41 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:41 --> CSRF cookie sent
INFO - 2020-02-24 17:59:41 --> Input Class Initialized
INFO - 2020-02-24 17:59:41 --> Language Class Initialized
INFO - 2020-02-24 17:59:41 --> Language Class Initialized
INFO - 2020-02-24 17:59:41 --> Config Class Initialized
INFO - 2020-02-24 17:59:41 --> Loader Class Initialized
INFO - 2020-02-24 17:59:41 --> Helper loaded: url_helper
INFO - 2020-02-24 17:59:41 --> Helper loaded: common_helper
INFO - 2020-02-24 17:59:41 --> Helper loaded: language_helper
INFO - 2020-02-24 17:59:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:59:41 --> Helper loaded: email_helper
INFO - 2020-02-24 17:59:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:59:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:59:41 --> Parser Class Initialized
INFO - 2020-02-24 17:59:41 --> User Agent Class Initialized
INFO - 2020-02-24 17:59:41 --> Model Class Initialized
INFO - 2020-02-24 17:59:41 --> Database Driver Class Initialized
INFO - 2020-02-24 17:59:41 --> Model Class Initialized
DEBUG - 2020-02-24 17:59:41 --> Template Class Initialized
INFO - 2020-02-24 17:59:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:59:41 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:59:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:59:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:59:41 --> Encryption Class Initialized
INFO - 2020-02-24 17:59:41 --> Controller Class Initialized
DEBUG - 2020-02-24 17:59:41 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:59:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:59:42 --> Model Class Initialized
ERROR - 2020-02-24 17:59:42 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:59:42 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 22
ERROR - 2020-02-24 17:59:42 --> Query error: Unknown table 'tuyen_smmstore.s' - Invalid query: SELECT `s`.*, `sn`.`name` as `social_network_name`, `sn`.`id` as `main_sn_id`
FROM `categories` `c`
LEFT JOIN `social_network_categories` `sn` ON `sn`.`id` = `c`.`sncate_id`
WHERE `c`.`sncate_id` IS NULL
INFO - 2020-02-24 17:59:42 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-24 17:59:58 --> Config Class Initialized
INFO - 2020-02-24 17:59:58 --> Hooks Class Initialized
DEBUG - 2020-02-24 17:59:58 --> UTF-8 Support Enabled
INFO - 2020-02-24 17:59:58 --> Utf8 Class Initialized
INFO - 2020-02-24 17:59:58 --> URI Class Initialized
INFO - 2020-02-24 17:59:58 --> Router Class Initialized
INFO - 2020-02-24 17:59:58 --> Output Class Initialized
INFO - 2020-02-24 17:59:58 --> Security Class Initialized
DEBUG - 2020-02-24 17:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 17:59:58 --> CSRF cookie sent
INFO - 2020-02-24 17:59:58 --> Input Class Initialized
INFO - 2020-02-24 17:59:58 --> Language Class Initialized
INFO - 2020-02-24 17:59:58 --> Language Class Initialized
INFO - 2020-02-24 17:59:58 --> Config Class Initialized
INFO - 2020-02-24 17:59:58 --> Loader Class Initialized
INFO - 2020-02-24 17:59:58 --> Helper loaded: url_helper
INFO - 2020-02-24 17:59:58 --> Helper loaded: common_helper
INFO - 2020-02-24 17:59:58 --> Helper loaded: language_helper
INFO - 2020-02-24 17:59:58 --> Helper loaded: cookie_helper
INFO - 2020-02-24 17:59:58 --> Helper loaded: email_helper
INFO - 2020-02-24 17:59:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 17:59:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 17:59:58 --> Parser Class Initialized
INFO - 2020-02-24 17:59:58 --> User Agent Class Initialized
INFO - 2020-02-24 17:59:58 --> Model Class Initialized
INFO - 2020-02-24 17:59:58 --> Database Driver Class Initialized
INFO - 2020-02-24 17:59:58 --> Model Class Initialized
DEBUG - 2020-02-24 17:59:58 --> Template Class Initialized
INFO - 2020-02-24 17:59:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 17:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 17:59:58 --> Pagination Class Initialized
DEBUG - 2020-02-24 17:59:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 17:59:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 17:59:58 --> Encryption Class Initialized
INFO - 2020-02-24 17:59:58 --> Controller Class Initialized
DEBUG - 2020-02-24 17:59:58 --> category MX_Controller Initialized
DEBUG - 2020-02-24 17:59:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 17:59:58 --> Model Class Initialized
ERROR - 2020-02-24 17:59:58 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 17:59:58 --> Query error: Unknown table 'tuyen_smmstore.s' - Invalid query: SELECT `s`.*, `sn`.`name` as `social_network_name`, `sn`.`id` as `main_sn_id`
FROM `categories` `c`
LEFT JOIN `social_network_categories` `sn` ON `sn`.`id` = `c`.`sncate_id`
INFO - 2020-02-24 17:59:58 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-24 18:00:18 --> Config Class Initialized
INFO - 2020-02-24 18:00:18 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:00:18 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:00:18 --> Utf8 Class Initialized
INFO - 2020-02-24 18:00:18 --> URI Class Initialized
INFO - 2020-02-24 18:00:18 --> Router Class Initialized
INFO - 2020-02-24 18:00:18 --> Output Class Initialized
INFO - 2020-02-24 18:00:18 --> Security Class Initialized
DEBUG - 2020-02-24 18:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:00:18 --> CSRF cookie sent
INFO - 2020-02-24 18:00:18 --> Input Class Initialized
INFO - 2020-02-24 18:00:18 --> Language Class Initialized
INFO - 2020-02-24 18:00:18 --> Language Class Initialized
INFO - 2020-02-24 18:00:18 --> Config Class Initialized
INFO - 2020-02-24 18:00:18 --> Loader Class Initialized
INFO - 2020-02-24 18:00:18 --> Helper loaded: url_helper
INFO - 2020-02-24 18:00:18 --> Helper loaded: common_helper
INFO - 2020-02-24 18:00:18 --> Helper loaded: language_helper
INFO - 2020-02-24 18:00:18 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:00:18 --> Helper loaded: email_helper
INFO - 2020-02-24 18:00:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:00:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:00:18 --> Parser Class Initialized
INFO - 2020-02-24 18:00:18 --> User Agent Class Initialized
INFO - 2020-02-24 18:00:18 --> Model Class Initialized
INFO - 2020-02-24 18:00:18 --> Database Driver Class Initialized
INFO - 2020-02-24 18:00:18 --> Model Class Initialized
DEBUG - 2020-02-24 18:00:18 --> Template Class Initialized
INFO - 2020-02-24 18:00:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:00:18 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:00:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:00:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:00:18 --> Encryption Class Initialized
INFO - 2020-02-24 18:00:18 --> Controller Class Initialized
DEBUG - 2020-02-24 18:00:18 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:00:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:00:18 --> Model Class Initialized
ERROR - 2020-02-24 18:00:18 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 18:00:18 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:18 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:18 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:18 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:18 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:18 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:18 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:18 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:18 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:19 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:19 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:19 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:19 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:19 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:19 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
ERROR - 2020-02-24 18:00:19 --> Severity: Notice --> Undefined index: sn_group_name D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 27
INFO - 2020-02-24 18:00:35 --> Config Class Initialized
INFO - 2020-02-24 18:00:35 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:00:35 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:00:35 --> Utf8 Class Initialized
INFO - 2020-02-24 18:00:35 --> URI Class Initialized
INFO - 2020-02-24 18:00:35 --> Router Class Initialized
INFO - 2020-02-24 18:00:35 --> Output Class Initialized
INFO - 2020-02-24 18:00:35 --> Security Class Initialized
DEBUG - 2020-02-24 18:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:00:35 --> CSRF cookie sent
INFO - 2020-02-24 18:00:35 --> Input Class Initialized
INFO - 2020-02-24 18:00:35 --> Language Class Initialized
INFO - 2020-02-24 18:00:35 --> Language Class Initialized
INFO - 2020-02-24 18:00:35 --> Config Class Initialized
INFO - 2020-02-24 18:00:35 --> Loader Class Initialized
INFO - 2020-02-24 18:00:35 --> Helper loaded: url_helper
INFO - 2020-02-24 18:00:35 --> Helper loaded: common_helper
INFO - 2020-02-24 18:00:35 --> Helper loaded: language_helper
INFO - 2020-02-24 18:00:35 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:00:35 --> Helper loaded: email_helper
INFO - 2020-02-24 18:00:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:00:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:00:35 --> Parser Class Initialized
INFO - 2020-02-24 18:00:35 --> User Agent Class Initialized
INFO - 2020-02-24 18:00:35 --> Model Class Initialized
INFO - 2020-02-24 18:00:35 --> Database Driver Class Initialized
INFO - 2020-02-24 18:00:35 --> Model Class Initialized
DEBUG - 2020-02-24 18:00:35 --> Template Class Initialized
INFO - 2020-02-24 18:00:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:00:36 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:00:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:00:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:00:36 --> Encryption Class Initialized
INFO - 2020-02-24 18:00:36 --> Controller Class Initialized
DEBUG - 2020-02-24 18:00:36 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:00:36 --> Model Class Initialized
ERROR - 2020-02-24 18:00:36 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:01:40 --> Config Class Initialized
INFO - 2020-02-24 18:01:40 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:01:40 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:01:40 --> Utf8 Class Initialized
INFO - 2020-02-24 18:01:40 --> URI Class Initialized
INFO - 2020-02-24 18:01:40 --> Router Class Initialized
INFO - 2020-02-24 18:01:40 --> Output Class Initialized
INFO - 2020-02-24 18:01:40 --> Security Class Initialized
DEBUG - 2020-02-24 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:01:40 --> CSRF cookie sent
INFO - 2020-02-24 18:01:40 --> Input Class Initialized
INFO - 2020-02-24 18:01:40 --> Language Class Initialized
INFO - 2020-02-24 18:01:40 --> Language Class Initialized
INFO - 2020-02-24 18:01:40 --> Config Class Initialized
INFO - 2020-02-24 18:01:40 --> Loader Class Initialized
INFO - 2020-02-24 18:01:40 --> Helper loaded: url_helper
INFO - 2020-02-24 18:01:40 --> Helper loaded: common_helper
INFO - 2020-02-24 18:01:40 --> Helper loaded: language_helper
INFO - 2020-02-24 18:01:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:01:41 --> Helper loaded: email_helper
INFO - 2020-02-24 18:01:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:01:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:01:41 --> Parser Class Initialized
INFO - 2020-02-24 18:01:41 --> User Agent Class Initialized
INFO - 2020-02-24 18:01:41 --> Model Class Initialized
INFO - 2020-02-24 18:01:41 --> Database Driver Class Initialized
INFO - 2020-02-24 18:01:41 --> Model Class Initialized
DEBUG - 2020-02-24 18:01:41 --> Template Class Initialized
INFO - 2020-02-24 18:01:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:01:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:01:41 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:01:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:01:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:01:41 --> Encryption Class Initialized
INFO - 2020-02-24 18:01:41 --> Controller Class Initialized
DEBUG - 2020-02-24 18:01:41 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:01:41 --> Model Class Initialized
ERROR - 2020-02-24 18:01:41 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:01:51 --> Config Class Initialized
INFO - 2020-02-24 18:01:51 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:01:51 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:01:51 --> Utf8 Class Initialized
INFO - 2020-02-24 18:01:51 --> URI Class Initialized
INFO - 2020-02-24 18:01:51 --> Router Class Initialized
INFO - 2020-02-24 18:01:51 --> Output Class Initialized
INFO - 2020-02-24 18:01:51 --> Security Class Initialized
DEBUG - 2020-02-24 18:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:01:51 --> CSRF cookie sent
INFO - 2020-02-24 18:01:51 --> Input Class Initialized
INFO - 2020-02-24 18:01:51 --> Language Class Initialized
INFO - 2020-02-24 18:01:51 --> Language Class Initialized
INFO - 2020-02-24 18:01:51 --> Config Class Initialized
INFO - 2020-02-24 18:01:51 --> Loader Class Initialized
INFO - 2020-02-24 18:01:51 --> Helper loaded: url_helper
INFO - 2020-02-24 18:01:51 --> Helper loaded: common_helper
INFO - 2020-02-24 18:01:51 --> Helper loaded: language_helper
INFO - 2020-02-24 18:01:51 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:01:51 --> Helper loaded: email_helper
INFO - 2020-02-24 18:01:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:01:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:01:51 --> Parser Class Initialized
INFO - 2020-02-24 18:01:51 --> User Agent Class Initialized
INFO - 2020-02-24 18:01:51 --> Model Class Initialized
INFO - 2020-02-24 18:01:51 --> Database Driver Class Initialized
INFO - 2020-02-24 18:01:51 --> Model Class Initialized
DEBUG - 2020-02-24 18:01:51 --> Template Class Initialized
INFO - 2020-02-24 18:01:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:01:51 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:01:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:01:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:01:51 --> Encryption Class Initialized
INFO - 2020-02-24 18:01:51 --> Controller Class Initialized
DEBUG - 2020-02-24 18:01:51 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:01:51 --> Model Class Initialized
ERROR - 2020-02-24 18:01:51 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:03:42 --> Config Class Initialized
INFO - 2020-02-24 18:03:42 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:03:42 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:03:42 --> Utf8 Class Initialized
INFO - 2020-02-24 18:03:42 --> URI Class Initialized
INFO - 2020-02-24 18:03:42 --> Router Class Initialized
INFO - 2020-02-24 18:03:42 --> Output Class Initialized
INFO - 2020-02-24 18:03:42 --> Security Class Initialized
DEBUG - 2020-02-24 18:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:03:42 --> CSRF cookie sent
INFO - 2020-02-24 18:03:42 --> Input Class Initialized
INFO - 2020-02-24 18:03:42 --> Language Class Initialized
INFO - 2020-02-24 18:03:42 --> Language Class Initialized
INFO - 2020-02-24 18:03:42 --> Config Class Initialized
INFO - 2020-02-24 18:03:42 --> Loader Class Initialized
INFO - 2020-02-24 18:03:42 --> Helper loaded: url_helper
INFO - 2020-02-24 18:03:42 --> Helper loaded: common_helper
INFO - 2020-02-24 18:03:42 --> Helper loaded: language_helper
INFO - 2020-02-24 18:03:42 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:03:42 --> Helper loaded: email_helper
INFO - 2020-02-24 18:03:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:03:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:03:42 --> Parser Class Initialized
INFO - 2020-02-24 18:03:42 --> User Agent Class Initialized
INFO - 2020-02-24 18:03:42 --> Model Class Initialized
INFO - 2020-02-24 18:03:42 --> Database Driver Class Initialized
INFO - 2020-02-24 18:03:42 --> Model Class Initialized
DEBUG - 2020-02-24 18:03:42 --> Template Class Initialized
INFO - 2020-02-24 18:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:03:42 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:03:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:03:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:03:42 --> Encryption Class Initialized
INFO - 2020-02-24 18:03:42 --> Controller Class Initialized
DEBUG - 2020-02-24 18:03:42 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:03:42 --> Model Class Initialized
ERROR - 2020-02-24 18:03:42 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:03:42 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:03:42 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:03:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 53
ERROR - 2020-02-24 18:03:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 53
ERROR - 2020-02-24 18:03:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 53
ERROR - 2020-02-24 18:03:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 53
ERROR - 2020-02-24 18:03:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 53
ERROR - 2020-02-24 18:03:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 53
ERROR - 2020-02-24 18:03:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 53
DEBUG - 2020-02-24 18:03:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:03:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:03:43 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:03:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:03:43 --> Model Class Initialized
DEBUG - 2020-02-24 18:03:43 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:03:43 --> Model Class Initialized
DEBUG - 2020-02-24 18:03:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:03:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:03:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:03:43 --> Final output sent to browser
DEBUG - 2020-02-24 18:03:43 --> Total execution time: 1.0479
INFO - 2020-02-24 18:04:09 --> Config Class Initialized
INFO - 2020-02-24 18:04:09 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:04:09 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:04:09 --> Utf8 Class Initialized
INFO - 2020-02-24 18:04:09 --> URI Class Initialized
INFO - 2020-02-24 18:04:09 --> Router Class Initialized
INFO - 2020-02-24 18:04:09 --> Output Class Initialized
INFO - 2020-02-24 18:04:09 --> Security Class Initialized
DEBUG - 2020-02-24 18:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:04:09 --> CSRF cookie sent
INFO - 2020-02-24 18:04:09 --> Input Class Initialized
INFO - 2020-02-24 18:04:09 --> Language Class Initialized
INFO - 2020-02-24 18:04:09 --> Language Class Initialized
INFO - 2020-02-24 18:04:09 --> Config Class Initialized
INFO - 2020-02-24 18:04:09 --> Loader Class Initialized
INFO - 2020-02-24 18:04:09 --> Helper loaded: url_helper
INFO - 2020-02-24 18:04:09 --> Helper loaded: common_helper
INFO - 2020-02-24 18:04:09 --> Helper loaded: language_helper
INFO - 2020-02-24 18:04:09 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:04:09 --> Helper loaded: email_helper
INFO - 2020-02-24 18:04:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:04:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:04:09 --> Parser Class Initialized
INFO - 2020-02-24 18:04:09 --> User Agent Class Initialized
INFO - 2020-02-24 18:04:09 --> Model Class Initialized
INFO - 2020-02-24 18:04:09 --> Database Driver Class Initialized
INFO - 2020-02-24 18:04:10 --> Model Class Initialized
DEBUG - 2020-02-24 18:04:10 --> Template Class Initialized
INFO - 2020-02-24 18:04:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:04:10 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:04:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:04:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:04:10 --> Encryption Class Initialized
INFO - 2020-02-24 18:04:10 --> Controller Class Initialized
DEBUG - 2020-02-24 18:04:10 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:04:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:04:10 --> Model Class Initialized
ERROR - 2020-02-24 18:04:10 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:04:10 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:04:10 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 57
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 57
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 57
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 57
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 57
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 57
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 57
ERROR - 2020-02-24 18:04:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
DEBUG - 2020-02-24 18:04:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:04:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:04:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:04:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:04:10 --> Model Class Initialized
DEBUG - 2020-02-24 18:04:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:04:10 --> Model Class Initialized
DEBUG - 2020-02-24 18:04:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:04:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:04:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:04:10 --> Final output sent to browser
DEBUG - 2020-02-24 18:04:10 --> Total execution time: 1.1776
INFO - 2020-02-24 18:04:46 --> Config Class Initialized
INFO - 2020-02-24 18:04:46 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:04:46 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:04:46 --> Utf8 Class Initialized
INFO - 2020-02-24 18:04:46 --> URI Class Initialized
INFO - 2020-02-24 18:04:46 --> Router Class Initialized
INFO - 2020-02-24 18:04:46 --> Output Class Initialized
INFO - 2020-02-24 18:04:46 --> Security Class Initialized
DEBUG - 2020-02-24 18:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:04:46 --> CSRF cookie sent
INFO - 2020-02-24 18:04:46 --> Input Class Initialized
INFO - 2020-02-24 18:04:46 --> Language Class Initialized
INFO - 2020-02-24 18:04:46 --> Language Class Initialized
INFO - 2020-02-24 18:04:46 --> Config Class Initialized
INFO - 2020-02-24 18:04:46 --> Loader Class Initialized
INFO - 2020-02-24 18:04:46 --> Helper loaded: url_helper
INFO - 2020-02-24 18:04:46 --> Helper loaded: common_helper
INFO - 2020-02-24 18:04:46 --> Helper loaded: language_helper
INFO - 2020-02-24 18:04:46 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:04:46 --> Helper loaded: email_helper
INFO - 2020-02-24 18:04:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:04:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:04:46 --> Parser Class Initialized
INFO - 2020-02-24 18:04:46 --> User Agent Class Initialized
INFO - 2020-02-24 18:04:46 --> Model Class Initialized
INFO - 2020-02-24 18:04:46 --> Database Driver Class Initialized
INFO - 2020-02-24 18:04:46 --> Model Class Initialized
DEBUG - 2020-02-24 18:04:46 --> Template Class Initialized
INFO - 2020-02-24 18:04:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:04:46 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:04:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:04:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:04:46 --> Encryption Class Initialized
INFO - 2020-02-24 18:04:46 --> Controller Class Initialized
DEBUG - 2020-02-24 18:04:46 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:04:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:04:46 --> Model Class Initialized
ERROR - 2020-02-24 18:04:46 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:04:46 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:04:46 --> Could not find the language line "Delele"
INFO - 2020-02-24 18:05:10 --> Config Class Initialized
INFO - 2020-02-24 18:05:10 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:05:10 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:05:10 --> Utf8 Class Initialized
INFO - 2020-02-24 18:05:10 --> URI Class Initialized
INFO - 2020-02-24 18:05:10 --> Router Class Initialized
INFO - 2020-02-24 18:05:10 --> Output Class Initialized
INFO - 2020-02-24 18:05:10 --> Security Class Initialized
DEBUG - 2020-02-24 18:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:05:10 --> CSRF cookie sent
INFO - 2020-02-24 18:05:10 --> Input Class Initialized
INFO - 2020-02-24 18:05:10 --> Language Class Initialized
INFO - 2020-02-24 18:05:10 --> Language Class Initialized
INFO - 2020-02-24 18:05:10 --> Config Class Initialized
INFO - 2020-02-24 18:05:10 --> Loader Class Initialized
INFO - 2020-02-24 18:05:10 --> Helper loaded: url_helper
INFO - 2020-02-24 18:05:10 --> Helper loaded: common_helper
INFO - 2020-02-24 18:05:10 --> Helper loaded: language_helper
INFO - 2020-02-24 18:05:10 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:05:10 --> Helper loaded: email_helper
INFO - 2020-02-24 18:05:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:05:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:05:10 --> Parser Class Initialized
INFO - 2020-02-24 18:05:10 --> User Agent Class Initialized
INFO - 2020-02-24 18:05:10 --> Model Class Initialized
INFO - 2020-02-24 18:05:10 --> Database Driver Class Initialized
INFO - 2020-02-24 18:05:10 --> Model Class Initialized
DEBUG - 2020-02-24 18:05:10 --> Template Class Initialized
INFO - 2020-02-24 18:05:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:05:10 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:05:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:05:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:05:10 --> Encryption Class Initialized
INFO - 2020-02-24 18:05:10 --> Controller Class Initialized
DEBUG - 2020-02-24 18:05:10 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:05:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:05:10 --> Model Class Initialized
ERROR - 2020-02-24 18:05:10 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:05:10 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:05:10 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:05:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:05:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:05:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:05:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:05:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:05:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
ERROR - 2020-02-24 18:05:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 64
DEBUG - 2020-02-24 18:05:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:05:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:05:11 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:05:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:05:11 --> Model Class Initialized
DEBUG - 2020-02-24 18:05:11 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:05:11 --> Model Class Initialized
DEBUG - 2020-02-24 18:05:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:05:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:05:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:05:11 --> Final output sent to browser
DEBUG - 2020-02-24 18:05:11 --> Total execution time: 1.0690
INFO - 2020-02-24 18:09:58 --> Config Class Initialized
INFO - 2020-02-24 18:09:58 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:09:58 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:09:58 --> Utf8 Class Initialized
INFO - 2020-02-24 18:09:58 --> URI Class Initialized
INFO - 2020-02-24 18:09:58 --> Router Class Initialized
INFO - 2020-02-24 18:09:59 --> Output Class Initialized
INFO - 2020-02-24 18:09:59 --> Security Class Initialized
DEBUG - 2020-02-24 18:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:09:59 --> CSRF cookie sent
INFO - 2020-02-24 18:09:59 --> Input Class Initialized
INFO - 2020-02-24 18:09:59 --> Language Class Initialized
INFO - 2020-02-24 18:09:59 --> Language Class Initialized
INFO - 2020-02-24 18:09:59 --> Config Class Initialized
INFO - 2020-02-24 18:09:59 --> Loader Class Initialized
INFO - 2020-02-24 18:09:59 --> Helper loaded: url_helper
INFO - 2020-02-24 18:09:59 --> Helper loaded: common_helper
INFO - 2020-02-24 18:09:59 --> Helper loaded: language_helper
INFO - 2020-02-24 18:09:59 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:09:59 --> Helper loaded: email_helper
INFO - 2020-02-24 18:09:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:09:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:09:59 --> Parser Class Initialized
INFO - 2020-02-24 18:09:59 --> User Agent Class Initialized
INFO - 2020-02-24 18:09:59 --> Model Class Initialized
INFO - 2020-02-24 18:09:59 --> Database Driver Class Initialized
INFO - 2020-02-24 18:09:59 --> Model Class Initialized
DEBUG - 2020-02-24 18:09:59 --> Template Class Initialized
INFO - 2020-02-24 18:09:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:09:59 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:09:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:09:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:09:59 --> Encryption Class Initialized
INFO - 2020-02-24 18:09:59 --> Controller Class Initialized
DEBUG - 2020-02-24 18:09:59 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:09:59 --> Model Class Initialized
ERROR - 2020-02-24 18:09:59 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:09:59 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:09:59 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:09:59 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 69
ERROR - 2020-02-24 18:09:59 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 70
ERROR - 2020-02-24 18:09:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 70
INFO - 2020-02-24 18:10:11 --> Config Class Initialized
INFO - 2020-02-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:10:11 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:10:12 --> Utf8 Class Initialized
INFO - 2020-02-24 18:10:12 --> URI Class Initialized
INFO - 2020-02-24 18:10:12 --> Router Class Initialized
INFO - 2020-02-24 18:10:12 --> Output Class Initialized
INFO - 2020-02-24 18:10:12 --> Security Class Initialized
DEBUG - 2020-02-24 18:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:10:12 --> CSRF cookie sent
INFO - 2020-02-24 18:10:12 --> Input Class Initialized
INFO - 2020-02-24 18:10:12 --> Language Class Initialized
INFO - 2020-02-24 18:10:12 --> Language Class Initialized
INFO - 2020-02-24 18:10:12 --> Config Class Initialized
INFO - 2020-02-24 18:10:12 --> Loader Class Initialized
INFO - 2020-02-24 18:10:12 --> Helper loaded: url_helper
INFO - 2020-02-24 18:10:12 --> Helper loaded: common_helper
INFO - 2020-02-24 18:10:12 --> Helper loaded: language_helper
INFO - 2020-02-24 18:10:12 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:10:12 --> Helper loaded: email_helper
INFO - 2020-02-24 18:10:12 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:10:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:10:12 --> Parser Class Initialized
INFO - 2020-02-24 18:10:12 --> User Agent Class Initialized
INFO - 2020-02-24 18:10:12 --> Model Class Initialized
INFO - 2020-02-24 18:10:12 --> Database Driver Class Initialized
INFO - 2020-02-24 18:10:12 --> Model Class Initialized
DEBUG - 2020-02-24 18:10:12 --> Template Class Initialized
INFO - 2020-02-24 18:10:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:10:12 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:10:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:10:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:10:12 --> Encryption Class Initialized
INFO - 2020-02-24 18:10:12 --> Controller Class Initialized
DEBUG - 2020-02-24 18:10:12 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:10:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:10:12 --> Model Class Initialized
ERROR - 2020-02-24 18:10:12 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:10:12 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:10:12 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:10:12 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 70
ERROR - 2020-02-24 18:10:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 70
INFO - 2020-02-24 18:10:23 --> Config Class Initialized
INFO - 2020-02-24 18:10:23 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:10:23 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:10:23 --> Utf8 Class Initialized
INFO - 2020-02-24 18:10:23 --> URI Class Initialized
INFO - 2020-02-24 18:10:23 --> Router Class Initialized
INFO - 2020-02-24 18:10:23 --> Output Class Initialized
INFO - 2020-02-24 18:10:23 --> Security Class Initialized
DEBUG - 2020-02-24 18:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:10:23 --> CSRF cookie sent
INFO - 2020-02-24 18:10:23 --> Input Class Initialized
INFO - 2020-02-24 18:10:23 --> Language Class Initialized
INFO - 2020-02-24 18:10:23 --> Language Class Initialized
INFO - 2020-02-24 18:10:23 --> Config Class Initialized
INFO - 2020-02-24 18:10:23 --> Loader Class Initialized
INFO - 2020-02-24 18:10:23 --> Helper loaded: url_helper
INFO - 2020-02-24 18:10:23 --> Helper loaded: common_helper
INFO - 2020-02-24 18:10:23 --> Helper loaded: language_helper
INFO - 2020-02-24 18:10:23 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:10:23 --> Helper loaded: email_helper
INFO - 2020-02-24 18:10:23 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:10:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:10:23 --> Parser Class Initialized
INFO - 2020-02-24 18:10:23 --> User Agent Class Initialized
INFO - 2020-02-24 18:10:23 --> Model Class Initialized
INFO - 2020-02-24 18:10:23 --> Database Driver Class Initialized
INFO - 2020-02-24 18:10:23 --> Model Class Initialized
DEBUG - 2020-02-24 18:10:23 --> Template Class Initialized
INFO - 2020-02-24 18:10:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:10:23 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:10:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:10:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:10:23 --> Encryption Class Initialized
INFO - 2020-02-24 18:10:23 --> Controller Class Initialized
DEBUG - 2020-02-24 18:10:23 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:10:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:10:23 --> Model Class Initialized
ERROR - 2020-02-24 18:10:23 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:10:23 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:10:23 --> Could not find the language line "Delele"
INFO - 2020-02-24 18:10:51 --> Config Class Initialized
INFO - 2020-02-24 18:10:51 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:10:51 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:10:51 --> Utf8 Class Initialized
INFO - 2020-02-24 18:10:51 --> URI Class Initialized
INFO - 2020-02-24 18:10:51 --> Router Class Initialized
INFO - 2020-02-24 18:10:51 --> Output Class Initialized
INFO - 2020-02-24 18:10:51 --> Security Class Initialized
DEBUG - 2020-02-24 18:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:10:51 --> CSRF cookie sent
INFO - 2020-02-24 18:10:51 --> Input Class Initialized
INFO - 2020-02-24 18:10:51 --> Language Class Initialized
INFO - 2020-02-24 18:10:51 --> Language Class Initialized
INFO - 2020-02-24 18:10:51 --> Config Class Initialized
INFO - 2020-02-24 18:10:51 --> Loader Class Initialized
INFO - 2020-02-24 18:10:51 --> Helper loaded: url_helper
INFO - 2020-02-24 18:10:51 --> Helper loaded: common_helper
INFO - 2020-02-24 18:10:51 --> Helper loaded: language_helper
INFO - 2020-02-24 18:10:51 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:10:51 --> Helper loaded: email_helper
INFO - 2020-02-24 18:10:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:10:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:10:51 --> Parser Class Initialized
INFO - 2020-02-24 18:10:51 --> User Agent Class Initialized
INFO - 2020-02-24 18:10:51 --> Model Class Initialized
INFO - 2020-02-24 18:10:51 --> Database Driver Class Initialized
INFO - 2020-02-24 18:10:52 --> Model Class Initialized
DEBUG - 2020-02-24 18:10:52 --> Template Class Initialized
INFO - 2020-02-24 18:10:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:10:52 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:10:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:10:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:10:52 --> Encryption Class Initialized
INFO - 2020-02-24 18:10:52 --> Controller Class Initialized
DEBUG - 2020-02-24 18:10:52 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:10:52 --> Model Class Initialized
ERROR - 2020-02-24 18:10:52 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:10:52 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:10:52 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:10:52 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:10:52 --> Model Class Initialized
DEBUG - 2020-02-24 18:10:52 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:10:52 --> Model Class Initialized
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:10:52 --> Final output sent to browser
DEBUG - 2020-02-24 18:10:52 --> Total execution time: 1.0112
INFO - 2020-02-24 18:11:17 --> Config Class Initialized
INFO - 2020-02-24 18:11:17 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:11:17 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:11:17 --> Utf8 Class Initialized
INFO - 2020-02-24 18:11:17 --> URI Class Initialized
INFO - 2020-02-24 18:11:17 --> Router Class Initialized
INFO - 2020-02-24 18:11:17 --> Output Class Initialized
INFO - 2020-02-24 18:11:17 --> Security Class Initialized
DEBUG - 2020-02-24 18:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:11:17 --> CSRF cookie sent
INFO - 2020-02-24 18:11:17 --> Input Class Initialized
INFO - 2020-02-24 18:11:17 --> Language Class Initialized
INFO - 2020-02-24 18:11:17 --> Language Class Initialized
INFO - 2020-02-24 18:11:17 --> Config Class Initialized
INFO - 2020-02-24 18:11:17 --> Loader Class Initialized
INFO - 2020-02-24 18:11:17 --> Helper loaded: url_helper
INFO - 2020-02-24 18:11:17 --> Helper loaded: common_helper
INFO - 2020-02-24 18:11:17 --> Helper loaded: language_helper
INFO - 2020-02-24 18:11:17 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:11:17 --> Helper loaded: email_helper
INFO - 2020-02-24 18:11:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:11:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:11:17 --> Parser Class Initialized
INFO - 2020-02-24 18:11:17 --> User Agent Class Initialized
INFO - 2020-02-24 18:11:17 --> Model Class Initialized
INFO - 2020-02-24 18:11:17 --> Database Driver Class Initialized
INFO - 2020-02-24 18:11:17 --> Model Class Initialized
DEBUG - 2020-02-24 18:11:17 --> Template Class Initialized
INFO - 2020-02-24 18:11:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:11:17 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:11:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:11:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:11:17 --> Encryption Class Initialized
INFO - 2020-02-24 18:11:17 --> Controller Class Initialized
DEBUG - 2020-02-24 18:11:17 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:11:17 --> Model Class Initialized
ERROR - 2020-02-24 18:11:17 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:11:17 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:11:17 --> Could not find the language line "Delele"
INFO - 2020-02-24 18:11:55 --> Config Class Initialized
INFO - 2020-02-24 18:11:55 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:11:55 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:11:55 --> Utf8 Class Initialized
INFO - 2020-02-24 18:11:55 --> URI Class Initialized
INFO - 2020-02-24 18:11:55 --> Router Class Initialized
INFO - 2020-02-24 18:11:56 --> Output Class Initialized
INFO - 2020-02-24 18:11:56 --> Security Class Initialized
DEBUG - 2020-02-24 18:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:11:56 --> CSRF cookie sent
INFO - 2020-02-24 18:11:56 --> Input Class Initialized
INFO - 2020-02-24 18:11:56 --> Language Class Initialized
INFO - 2020-02-24 18:11:56 --> Language Class Initialized
INFO - 2020-02-24 18:11:56 --> Config Class Initialized
INFO - 2020-02-24 18:11:56 --> Loader Class Initialized
INFO - 2020-02-24 18:11:56 --> Helper loaded: url_helper
INFO - 2020-02-24 18:11:56 --> Helper loaded: common_helper
INFO - 2020-02-24 18:11:56 --> Helper loaded: language_helper
INFO - 2020-02-24 18:11:56 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:11:56 --> Helper loaded: email_helper
INFO - 2020-02-24 18:11:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:11:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:11:56 --> Parser Class Initialized
INFO - 2020-02-24 18:11:56 --> User Agent Class Initialized
INFO - 2020-02-24 18:11:56 --> Model Class Initialized
INFO - 2020-02-24 18:11:56 --> Database Driver Class Initialized
INFO - 2020-02-24 18:11:56 --> Model Class Initialized
DEBUG - 2020-02-24 18:11:56 --> Template Class Initialized
INFO - 2020-02-24 18:11:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:11:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:11:56 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:11:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:11:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:11:56 --> Encryption Class Initialized
INFO - 2020-02-24 18:11:56 --> Controller Class Initialized
DEBUG - 2020-02-24 18:11:56 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:11:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:11:56 --> Model Class Initialized
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:11:56 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:11:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:11:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:11:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:56 --> Could not find the language line "View"
ERROR - 2020-02-24 18:11:56 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:57 --> Could not find the language line "View"
ERROR - 2020-02-24 18:11:57 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:57 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:11:57 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:57 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:11:57 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:57 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:11:57 --> Severity: Notice --> Undefined property: stdClass::$sort D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\ajax\load_services_by_cate.php 51
ERROR - 2020-02-24 18:11:57 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:11:57 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:11:57 --> Model Class Initialized
DEBUG - 2020-02-24 18:11:57 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:11:57 --> Model Class Initialized
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:11:57 --> Final output sent to browser
DEBUG - 2020-02-24 18:11:57 --> Total execution time: 1.5298
INFO - 2020-02-24 18:12:15 --> Config Class Initialized
INFO - 2020-02-24 18:12:15 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:12:15 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:12:15 --> Utf8 Class Initialized
INFO - 2020-02-24 18:12:15 --> URI Class Initialized
INFO - 2020-02-24 18:12:15 --> Router Class Initialized
INFO - 2020-02-24 18:12:15 --> Output Class Initialized
INFO - 2020-02-24 18:12:15 --> Security Class Initialized
DEBUG - 2020-02-24 18:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:12:15 --> CSRF cookie sent
INFO - 2020-02-24 18:12:15 --> Input Class Initialized
INFO - 2020-02-24 18:12:15 --> Language Class Initialized
INFO - 2020-02-24 18:12:15 --> Language Class Initialized
INFO - 2020-02-24 18:12:15 --> Config Class Initialized
INFO - 2020-02-24 18:12:15 --> Loader Class Initialized
INFO - 2020-02-24 18:12:15 --> Helper loaded: url_helper
INFO - 2020-02-24 18:12:15 --> Helper loaded: common_helper
INFO - 2020-02-24 18:12:16 --> Helper loaded: language_helper
INFO - 2020-02-24 18:12:16 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:12:16 --> Helper loaded: email_helper
INFO - 2020-02-24 18:12:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:12:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:12:16 --> Parser Class Initialized
INFO - 2020-02-24 18:12:16 --> User Agent Class Initialized
INFO - 2020-02-24 18:12:16 --> Model Class Initialized
INFO - 2020-02-24 18:12:16 --> Database Driver Class Initialized
INFO - 2020-02-24 18:12:16 --> Model Class Initialized
DEBUG - 2020-02-24 18:12:16 --> Template Class Initialized
INFO - 2020-02-24 18:12:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:12:16 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:12:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:12:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:12:16 --> Encryption Class Initialized
INFO - 2020-02-24 18:12:16 --> Controller Class Initialized
DEBUG - 2020-02-24 18:12:16 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:12:16 --> Model Class Initialized
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:12:16 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:16 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:12:16 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:12:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:12:16 --> Model Class Initialized
DEBUG - 2020-02-24 18:12:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:12:17 --> Model Class Initialized
DEBUG - 2020-02-24 18:12:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:12:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:12:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:12:17 --> Final output sent to browser
DEBUG - 2020-02-24 18:12:17 --> Total execution time: 1.4672
INFO - 2020-02-24 18:12:26 --> Config Class Initialized
INFO - 2020-02-24 18:12:26 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:12:26 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:12:26 --> Utf8 Class Initialized
INFO - 2020-02-24 18:12:26 --> URI Class Initialized
INFO - 2020-02-24 18:12:26 --> Router Class Initialized
INFO - 2020-02-24 18:12:26 --> Output Class Initialized
INFO - 2020-02-24 18:12:26 --> Security Class Initialized
DEBUG - 2020-02-24 18:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:12:26 --> CSRF cookie sent
INFO - 2020-02-24 18:12:26 --> Input Class Initialized
INFO - 2020-02-24 18:12:26 --> Language Class Initialized
INFO - 2020-02-24 18:12:26 --> Language Class Initialized
INFO - 2020-02-24 18:12:26 --> Config Class Initialized
INFO - 2020-02-24 18:12:26 --> Loader Class Initialized
INFO - 2020-02-24 18:12:26 --> Helper loaded: url_helper
INFO - 2020-02-24 18:12:26 --> Helper loaded: common_helper
INFO - 2020-02-24 18:12:26 --> Helper loaded: language_helper
INFO - 2020-02-24 18:12:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:12:26 --> Helper loaded: email_helper
INFO - 2020-02-24 18:12:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:12:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:12:26 --> Parser Class Initialized
INFO - 2020-02-24 18:12:26 --> User Agent Class Initialized
INFO - 2020-02-24 18:12:26 --> Model Class Initialized
INFO - 2020-02-24 18:12:26 --> Database Driver Class Initialized
INFO - 2020-02-24 18:12:26 --> Model Class Initialized
DEBUG - 2020-02-24 18:12:26 --> Template Class Initialized
INFO - 2020-02-24 18:12:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:12:26 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:12:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:12:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:12:26 --> Encryption Class Initialized
INFO - 2020-02-24 18:12:26 --> Controller Class Initialized
DEBUG - 2020-02-24 18:12:26 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:12:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:12:26 --> Model Class Initialized
ERROR - 2020-02-24 18:12:26 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:12:26 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:12:26 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:12:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:27 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:12:27 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:12:27 --> Model Class Initialized
DEBUG - 2020-02-24 18:12:27 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:12:27 --> Model Class Initialized
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:12:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:12:27 --> Final output sent to browser
DEBUG - 2020-02-24 18:12:27 --> Total execution time: 1.5501
INFO - 2020-02-24 18:12:50 --> Config Class Initialized
INFO - 2020-02-24 18:12:50 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:12:50 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:12:50 --> Utf8 Class Initialized
INFO - 2020-02-24 18:12:50 --> URI Class Initialized
INFO - 2020-02-24 18:12:50 --> Router Class Initialized
INFO - 2020-02-24 18:12:50 --> Output Class Initialized
INFO - 2020-02-24 18:12:50 --> Security Class Initialized
DEBUG - 2020-02-24 18:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:12:50 --> CSRF cookie sent
INFO - 2020-02-24 18:12:50 --> Input Class Initialized
INFO - 2020-02-24 18:12:50 --> Language Class Initialized
INFO - 2020-02-24 18:12:50 --> Language Class Initialized
INFO - 2020-02-24 18:12:50 --> Config Class Initialized
INFO - 2020-02-24 18:12:50 --> Loader Class Initialized
INFO - 2020-02-24 18:12:50 --> Helper loaded: url_helper
INFO - 2020-02-24 18:12:50 --> Helper loaded: common_helper
INFO - 2020-02-24 18:12:50 --> Helper loaded: language_helper
INFO - 2020-02-24 18:12:50 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:12:50 --> Helper loaded: email_helper
INFO - 2020-02-24 18:12:50 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:12:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:12:50 --> Parser Class Initialized
INFO - 2020-02-24 18:12:50 --> User Agent Class Initialized
INFO - 2020-02-24 18:12:50 --> Model Class Initialized
INFO - 2020-02-24 18:12:50 --> Database Driver Class Initialized
INFO - 2020-02-24 18:12:50 --> Model Class Initialized
DEBUG - 2020-02-24 18:12:50 --> Template Class Initialized
INFO - 2020-02-24 18:12:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:12:50 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:12:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:12:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:12:50 --> Encryption Class Initialized
INFO - 2020-02-24 18:12:50 --> Controller Class Initialized
DEBUG - 2020-02-24 18:12:51 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:12:51 --> Model Class Initialized
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:12:51 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:12:51 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:12:51 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:12:51 --> Model Class Initialized
DEBUG - 2020-02-24 18:12:51 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:12:51 --> Model Class Initialized
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:12:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:12:51 --> Final output sent to browser
DEBUG - 2020-02-24 18:12:51 --> Total execution time: 1.4739
INFO - 2020-02-24 18:13:09 --> Config Class Initialized
INFO - 2020-02-24 18:13:09 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:13:09 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:13:09 --> Utf8 Class Initialized
INFO - 2020-02-24 18:13:09 --> URI Class Initialized
INFO - 2020-02-24 18:13:09 --> Router Class Initialized
INFO - 2020-02-24 18:13:09 --> Output Class Initialized
INFO - 2020-02-24 18:13:09 --> Security Class Initialized
DEBUG - 2020-02-24 18:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:13:09 --> CSRF cookie sent
INFO - 2020-02-24 18:13:09 --> Input Class Initialized
INFO - 2020-02-24 18:13:09 --> Language Class Initialized
INFO - 2020-02-24 18:13:09 --> Language Class Initialized
INFO - 2020-02-24 18:13:09 --> Config Class Initialized
INFO - 2020-02-24 18:13:09 --> Loader Class Initialized
INFO - 2020-02-24 18:13:09 --> Helper loaded: url_helper
INFO - 2020-02-24 18:13:09 --> Helper loaded: common_helper
INFO - 2020-02-24 18:13:09 --> Helper loaded: language_helper
INFO - 2020-02-24 18:13:09 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:13:09 --> Helper loaded: email_helper
INFO - 2020-02-24 18:13:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:13:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:13:10 --> Parser Class Initialized
INFO - 2020-02-24 18:13:10 --> User Agent Class Initialized
INFO - 2020-02-24 18:13:10 --> Model Class Initialized
INFO - 2020-02-24 18:13:10 --> Database Driver Class Initialized
INFO - 2020-02-24 18:13:10 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:10 --> Template Class Initialized
INFO - 2020-02-24 18:13:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:13:10 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:13:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:13:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:13:10 --> Encryption Class Initialized
INFO - 2020-02-24 18:13:10 --> Controller Class Initialized
DEBUG - 2020-02-24 18:13:10 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:13:10 --> Model Class Initialized
ERROR - 2020-02-24 18:13:10 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:13:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 18:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 18:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:13:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:13:10 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:13:10 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:13:10 --> Final output sent to browser
DEBUG - 2020-02-24 18:13:10 --> Total execution time: 1.0027
INFO - 2020-02-24 18:13:12 --> Config Class Initialized
INFO - 2020-02-24 18:13:12 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:13:12 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:13:12 --> Utf8 Class Initialized
INFO - 2020-02-24 18:13:12 --> URI Class Initialized
INFO - 2020-02-24 18:13:12 --> Router Class Initialized
INFO - 2020-02-24 18:13:12 --> Output Class Initialized
INFO - 2020-02-24 18:13:12 --> Security Class Initialized
DEBUG - 2020-02-24 18:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:13:12 --> CSRF cookie sent
INFO - 2020-02-24 18:13:12 --> Input Class Initialized
INFO - 2020-02-24 18:13:12 --> Language Class Initialized
INFO - 2020-02-24 18:13:12 --> Language Class Initialized
INFO - 2020-02-24 18:13:12 --> Config Class Initialized
INFO - 2020-02-24 18:13:12 --> Loader Class Initialized
INFO - 2020-02-24 18:13:12 --> Helper loaded: url_helper
INFO - 2020-02-24 18:13:12 --> Helper loaded: common_helper
INFO - 2020-02-24 18:13:12 --> Helper loaded: language_helper
INFO - 2020-02-24 18:13:12 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:13:12 --> Helper loaded: email_helper
INFO - 2020-02-24 18:13:12 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:13:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:13:12 --> Parser Class Initialized
INFO - 2020-02-24 18:13:12 --> User Agent Class Initialized
INFO - 2020-02-24 18:13:12 --> Model Class Initialized
INFO - 2020-02-24 18:13:12 --> Database Driver Class Initialized
INFO - 2020-02-24 18:13:12 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:12 --> Template Class Initialized
INFO - 2020-02-24 18:13:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:13:12 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:13:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:13:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:13:12 --> Encryption Class Initialized
INFO - 2020-02-24 18:13:12 --> Controller Class Initialized
DEBUG - 2020-02-24 18:13:12 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:13:12 --> Model Class Initialized
ERROR - 2020-02-24 18:13:12 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:13:12 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 18:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 18:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:13:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:13:12 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:13:12 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:13:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:13:13 --> Final output sent to browser
DEBUG - 2020-02-24 18:13:13 --> Total execution time: 0.9524
INFO - 2020-02-24 18:13:14 --> Config Class Initialized
INFO - 2020-02-24 18:13:14 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:13:14 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:13:14 --> Utf8 Class Initialized
INFO - 2020-02-24 18:13:14 --> URI Class Initialized
INFO - 2020-02-24 18:13:14 --> Router Class Initialized
INFO - 2020-02-24 18:13:14 --> Output Class Initialized
INFO - 2020-02-24 18:13:14 --> Security Class Initialized
DEBUG - 2020-02-24 18:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:13:14 --> CSRF cookie sent
INFO - 2020-02-24 18:13:14 --> Input Class Initialized
INFO - 2020-02-24 18:13:14 --> Language Class Initialized
INFO - 2020-02-24 18:13:14 --> Language Class Initialized
INFO - 2020-02-24 18:13:14 --> Config Class Initialized
INFO - 2020-02-24 18:13:14 --> Loader Class Initialized
INFO - 2020-02-24 18:13:14 --> Helper loaded: url_helper
INFO - 2020-02-24 18:13:14 --> Helper loaded: common_helper
INFO - 2020-02-24 18:13:14 --> Helper loaded: language_helper
INFO - 2020-02-24 18:13:14 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:13:14 --> Helper loaded: email_helper
INFO - 2020-02-24 18:13:14 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:13:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:13:14 --> Parser Class Initialized
INFO - 2020-02-24 18:13:14 --> User Agent Class Initialized
INFO - 2020-02-24 18:13:14 --> Model Class Initialized
INFO - 2020-02-24 18:13:14 --> Database Driver Class Initialized
INFO - 2020-02-24 18:13:14 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:14 --> Template Class Initialized
INFO - 2020-02-24 18:13:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:13:14 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:13:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:13:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:13:14 --> Encryption Class Initialized
INFO - 2020-02-24 18:13:14 --> Controller Class Initialized
DEBUG - 2020-02-24 18:13:14 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:13:14 --> Model Class Initialized
ERROR - 2020-02-24 18:13:14 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:13:14 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 18:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 18:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:13:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:13:14 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:13:14 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:13:15 --> Final output sent to browser
DEBUG - 2020-02-24 18:13:15 --> Total execution time: 0.9595
INFO - 2020-02-24 18:13:15 --> Config Class Initialized
INFO - 2020-02-24 18:13:15 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:13:15 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:13:15 --> Utf8 Class Initialized
INFO - 2020-02-24 18:13:15 --> URI Class Initialized
INFO - 2020-02-24 18:13:15 --> Router Class Initialized
INFO - 2020-02-24 18:13:15 --> Output Class Initialized
INFO - 2020-02-24 18:13:15 --> Security Class Initialized
DEBUG - 2020-02-24 18:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:13:15 --> CSRF cookie sent
INFO - 2020-02-24 18:13:15 --> Input Class Initialized
INFO - 2020-02-24 18:13:15 --> Language Class Initialized
INFO - 2020-02-24 18:13:15 --> Language Class Initialized
INFO - 2020-02-24 18:13:15 --> Config Class Initialized
INFO - 2020-02-24 18:13:15 --> Loader Class Initialized
INFO - 2020-02-24 18:13:15 --> Helper loaded: url_helper
INFO - 2020-02-24 18:13:16 --> Helper loaded: common_helper
INFO - 2020-02-24 18:13:16 --> Helper loaded: language_helper
INFO - 2020-02-24 18:13:16 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:13:16 --> Helper loaded: email_helper
INFO - 2020-02-24 18:13:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:13:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:13:16 --> Parser Class Initialized
INFO - 2020-02-24 18:13:16 --> User Agent Class Initialized
INFO - 2020-02-24 18:13:16 --> Model Class Initialized
INFO - 2020-02-24 18:13:16 --> Database Driver Class Initialized
INFO - 2020-02-24 18:13:16 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:16 --> Template Class Initialized
INFO - 2020-02-24 18:13:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:13:16 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:13:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:13:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:13:16 --> Encryption Class Initialized
INFO - 2020-02-24 18:13:16 --> Controller Class Initialized
DEBUG - 2020-02-24 18:13:16 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:13:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:13:16 --> Model Class Initialized
ERROR - 2020-02-24 18:13:16 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:13:16 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 18:13:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 18:13:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:13:16 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:13:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:13:16 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:16 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:13:16 --> Model Class Initialized
DEBUG - 2020-02-24 18:13:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:13:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:13:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:13:16 --> Final output sent to browser
DEBUG - 2020-02-24 18:13:16 --> Total execution time: 0.9095
INFO - 2020-02-24 18:15:02 --> Config Class Initialized
INFO - 2020-02-24 18:15:02 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:15:02 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:15:02 --> Utf8 Class Initialized
INFO - 2020-02-24 18:15:02 --> URI Class Initialized
INFO - 2020-02-24 18:15:02 --> Router Class Initialized
INFO - 2020-02-24 18:15:02 --> Output Class Initialized
INFO - 2020-02-24 18:15:02 --> Security Class Initialized
DEBUG - 2020-02-24 18:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:15:02 --> CSRF cookie sent
INFO - 2020-02-24 18:15:02 --> Input Class Initialized
INFO - 2020-02-24 18:15:02 --> Language Class Initialized
INFO - 2020-02-24 18:15:03 --> Language Class Initialized
INFO - 2020-02-24 18:15:03 --> Config Class Initialized
INFO - 2020-02-24 18:15:03 --> Loader Class Initialized
INFO - 2020-02-24 18:15:03 --> Helper loaded: url_helper
INFO - 2020-02-24 18:15:03 --> Helper loaded: common_helper
INFO - 2020-02-24 18:15:03 --> Helper loaded: language_helper
INFO - 2020-02-24 18:15:03 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:15:03 --> Helper loaded: email_helper
INFO - 2020-02-24 18:15:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:15:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:15:03 --> Parser Class Initialized
INFO - 2020-02-24 18:15:03 --> User Agent Class Initialized
INFO - 2020-02-24 18:15:03 --> Model Class Initialized
INFO - 2020-02-24 18:15:03 --> Database Driver Class Initialized
INFO - 2020-02-24 18:15:03 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:03 --> Template Class Initialized
INFO - 2020-02-24 18:15:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:15:03 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:15:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:15:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:15:03 --> Encryption Class Initialized
INFO - 2020-02-24 18:15:03 --> Controller Class Initialized
DEBUG - 2020-02-24 18:15:03 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:15:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:15:03 --> Model Class Initialized
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:15:03 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:03 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:15:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:15:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:15:04 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:15:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:15:04 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:04 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:15:04 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:15:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:15:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:15:04 --> Final output sent to browser
DEBUG - 2020-02-24 18:15:04 --> Total execution time: 1.4915
INFO - 2020-02-24 18:15:11 --> Config Class Initialized
INFO - 2020-02-24 18:15:11 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:15:12 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:15:12 --> Utf8 Class Initialized
INFO - 2020-02-24 18:15:12 --> URI Class Initialized
INFO - 2020-02-24 18:15:12 --> Router Class Initialized
INFO - 2020-02-24 18:15:12 --> Output Class Initialized
INFO - 2020-02-24 18:15:12 --> Security Class Initialized
DEBUG - 2020-02-24 18:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:15:12 --> CSRF cookie sent
INFO - 2020-02-24 18:15:12 --> CSRF token verified
INFO - 2020-02-24 18:15:12 --> Input Class Initialized
INFO - 2020-02-24 18:15:12 --> Language Class Initialized
INFO - 2020-02-24 18:15:12 --> Language Class Initialized
INFO - 2020-02-24 18:15:12 --> Config Class Initialized
INFO - 2020-02-24 18:15:12 --> Loader Class Initialized
INFO - 2020-02-24 18:15:12 --> Helper loaded: url_helper
INFO - 2020-02-24 18:15:12 --> Helper loaded: common_helper
INFO - 2020-02-24 18:15:12 --> Helper loaded: language_helper
INFO - 2020-02-24 18:15:12 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:15:12 --> Helper loaded: email_helper
INFO - 2020-02-24 18:15:12 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:15:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:15:12 --> Parser Class Initialized
INFO - 2020-02-24 18:15:12 --> User Agent Class Initialized
INFO - 2020-02-24 18:15:12 --> Model Class Initialized
INFO - 2020-02-24 18:15:12 --> Database Driver Class Initialized
INFO - 2020-02-24 18:15:12 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:12 --> Template Class Initialized
INFO - 2020-02-24 18:15:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:15:12 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:15:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:15:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:15:12 --> Encryption Class Initialized
INFO - 2020-02-24 18:15:12 --> Controller Class Initialized
DEBUG - 2020-02-24 18:15:12 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:15:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:15:12 --> Model Class Initialized
ERROR - 2020-02-24 18:15:12 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 18:15:12 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:12 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/search.php
INFO - 2020-02-24 18:15:12 --> Final output sent to browser
DEBUG - 2020-02-24 18:15:12 --> Total execution time: 0.7794
INFO - 2020-02-24 18:15:16 --> Config Class Initialized
INFO - 2020-02-24 18:15:16 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:15:16 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:15:16 --> Utf8 Class Initialized
INFO - 2020-02-24 18:15:16 --> URI Class Initialized
INFO - 2020-02-24 18:15:16 --> Router Class Initialized
INFO - 2020-02-24 18:15:16 --> Output Class Initialized
INFO - 2020-02-24 18:15:16 --> Security Class Initialized
DEBUG - 2020-02-24 18:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:15:16 --> CSRF cookie sent
INFO - 2020-02-24 18:15:16 --> Input Class Initialized
INFO - 2020-02-24 18:15:17 --> Language Class Initialized
INFO - 2020-02-24 18:15:17 --> Language Class Initialized
INFO - 2020-02-24 18:15:17 --> Config Class Initialized
INFO - 2020-02-24 18:15:17 --> Loader Class Initialized
INFO - 2020-02-24 18:15:17 --> Helper loaded: url_helper
INFO - 2020-02-24 18:15:17 --> Helper loaded: common_helper
INFO - 2020-02-24 18:15:17 --> Helper loaded: language_helper
INFO - 2020-02-24 18:15:17 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:15:17 --> Helper loaded: email_helper
INFO - 2020-02-24 18:15:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:15:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:15:17 --> Parser Class Initialized
INFO - 2020-02-24 18:15:17 --> User Agent Class Initialized
INFO - 2020-02-24 18:15:17 --> Model Class Initialized
INFO - 2020-02-24 18:15:17 --> Database Driver Class Initialized
INFO - 2020-02-24 18:15:17 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:17 --> Template Class Initialized
INFO - 2020-02-24 18:15:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:15:17 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:15:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:15:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:15:17 --> Encryption Class Initialized
INFO - 2020-02-24 18:15:17 --> Controller Class Initialized
DEBUG - 2020-02-24 18:15:17 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:15:17 --> Model Class Initialized
ERROR - 2020-02-24 18:15:17 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:15:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 18:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 18:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:15:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:15:17 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:15:17 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:15:17 --> Final output sent to browser
DEBUG - 2020-02-24 18:15:17 --> Total execution time: 0.9782
INFO - 2020-02-24 18:15:21 --> Config Class Initialized
INFO - 2020-02-24 18:15:21 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:15:21 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:15:21 --> Utf8 Class Initialized
INFO - 2020-02-24 18:15:21 --> URI Class Initialized
INFO - 2020-02-24 18:15:21 --> Router Class Initialized
INFO - 2020-02-24 18:15:21 --> Output Class Initialized
INFO - 2020-02-24 18:15:21 --> Security Class Initialized
DEBUG - 2020-02-24 18:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:15:21 --> CSRF cookie sent
INFO - 2020-02-24 18:15:21 --> Input Class Initialized
INFO - 2020-02-24 18:15:21 --> Language Class Initialized
INFO - 2020-02-24 18:15:21 --> Language Class Initialized
INFO - 2020-02-24 18:15:21 --> Config Class Initialized
INFO - 2020-02-24 18:15:21 --> Loader Class Initialized
INFO - 2020-02-24 18:15:21 --> Helper loaded: url_helper
INFO - 2020-02-24 18:15:21 --> Helper loaded: common_helper
INFO - 2020-02-24 18:15:21 --> Helper loaded: language_helper
INFO - 2020-02-24 18:15:21 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:15:21 --> Helper loaded: email_helper
INFO - 2020-02-24 18:15:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:15:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:15:21 --> Parser Class Initialized
INFO - 2020-02-24 18:15:21 --> User Agent Class Initialized
INFO - 2020-02-24 18:15:21 --> Model Class Initialized
INFO - 2020-02-24 18:15:21 --> Database Driver Class Initialized
INFO - 2020-02-24 18:15:21 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:21 --> Template Class Initialized
INFO - 2020-02-24 18:15:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:15:21 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:15:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:15:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:15:21 --> Encryption Class Initialized
INFO - 2020-02-24 18:15:21 --> Controller Class Initialized
DEBUG - 2020-02-24 18:15:21 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:15:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:15:22 --> Model Class Initialized
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:15:22 --> Config Class Initialized
INFO - 2020-02-24 18:15:22 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:15:22 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:15:22 --> Utf8 Class Initialized
INFO - 2020-02-24 18:15:22 --> URI Class Initialized
INFO - 2020-02-24 18:15:22 --> Router Class Initialized
INFO - 2020-02-24 18:15:22 --> Output Class Initialized
INFO - 2020-02-24 18:15:22 --> Security Class Initialized
DEBUG - 2020-02-24 18:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:15:22 --> CSRF cookie sent
INFO - 2020-02-24 18:15:22 --> Input Class Initialized
INFO - 2020-02-24 18:15:22 --> Language Class Initialized
INFO - 2020-02-24 18:15:22 --> Language Class Initialized
INFO - 2020-02-24 18:15:22 --> Config Class Initialized
INFO - 2020-02-24 18:15:22 --> Loader Class Initialized
INFO - 2020-02-24 18:15:22 --> Helper loaded: url_helper
INFO - 2020-02-24 18:15:22 --> Helper loaded: common_helper
INFO - 2020-02-24 18:15:22 --> Helper loaded: language_helper
INFO - 2020-02-24 18:15:22 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:15:22 --> Helper loaded: email_helper
INFO - 2020-02-24 18:15:22 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:15:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:15:22 --> Parser Class Initialized
INFO - 2020-02-24 18:15:22 --> User Agent Class Initialized
INFO - 2020-02-24 18:15:22 --> Model Class Initialized
INFO - 2020-02-24 18:15:22 --> Database Driver Class Initialized
INFO - 2020-02-24 18:15:22 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:22 --> Template Class Initialized
INFO - 2020-02-24 18:15:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:15:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:15:22 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:15:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:15:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:15:22 --> Encryption Class Initialized
INFO - 2020-02-24 18:15:22 --> Controller Class Initialized
DEBUG - 2020-02-24 18:15:22 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:15:22 --> Model Class Initialized
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:15:22 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:22 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:23 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:23 --> Could not find the language line "View"
ERROR - 2020-02-24 18:15:23 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:23 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:23 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:15:23 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:15:23 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:15:23 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:23 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:15:23 --> Model Class Initialized
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:15:23 --> Final output sent to browser
DEBUG - 2020-02-24 18:15:23 --> Total execution time: 1.3568
INFO - 2020-02-24 18:16:19 --> Config Class Initialized
INFO - 2020-02-24 18:16:19 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:16:19 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:16:19 --> Utf8 Class Initialized
INFO - 2020-02-24 18:16:19 --> URI Class Initialized
INFO - 2020-02-24 18:16:19 --> Router Class Initialized
INFO - 2020-02-24 18:16:19 --> Output Class Initialized
INFO - 2020-02-24 18:16:19 --> Security Class Initialized
DEBUG - 2020-02-24 18:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:16:19 --> CSRF cookie sent
INFO - 2020-02-24 18:16:19 --> Input Class Initialized
INFO - 2020-02-24 18:16:19 --> Language Class Initialized
INFO - 2020-02-24 18:16:19 --> Language Class Initialized
INFO - 2020-02-24 18:16:19 --> Config Class Initialized
INFO - 2020-02-24 18:16:19 --> Loader Class Initialized
INFO - 2020-02-24 18:16:19 --> Helper loaded: url_helper
INFO - 2020-02-24 18:16:19 --> Helper loaded: common_helper
INFO - 2020-02-24 18:16:19 --> Helper loaded: language_helper
INFO - 2020-02-24 18:16:19 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:16:19 --> Helper loaded: email_helper
INFO - 2020-02-24 18:16:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:16:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:16:19 --> Parser Class Initialized
INFO - 2020-02-24 18:16:19 --> User Agent Class Initialized
INFO - 2020-02-24 18:16:19 --> Model Class Initialized
INFO - 2020-02-24 18:16:19 --> Database Driver Class Initialized
INFO - 2020-02-24 18:16:19 --> Model Class Initialized
DEBUG - 2020-02-24 18:16:19 --> Template Class Initialized
INFO - 2020-02-24 18:16:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:16:19 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:16:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:16:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:16:19 --> Encryption Class Initialized
INFO - 2020-02-24 18:16:20 --> Controller Class Initialized
DEBUG - 2020-02-24 18:16:20 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:16:20 --> Model Class Initialized
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:16:20 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:20 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:16:20 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:16:20 --> Model Class Initialized
DEBUG - 2020-02-24 18:16:20 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:16:20 --> Model Class Initialized
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:16:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:16:20 --> Final output sent to browser
DEBUG - 2020-02-24 18:16:20 --> Total execution time: 1.4612
INFO - 2020-02-24 18:16:25 --> Config Class Initialized
INFO - 2020-02-24 18:16:25 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:16:25 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:16:25 --> Utf8 Class Initialized
INFO - 2020-02-24 18:16:25 --> URI Class Initialized
INFO - 2020-02-24 18:16:25 --> Router Class Initialized
INFO - 2020-02-24 18:16:25 --> Output Class Initialized
INFO - 2020-02-24 18:16:25 --> Security Class Initialized
DEBUG - 2020-02-24 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:16:25 --> CSRF cookie sent
INFO - 2020-02-24 18:16:25 --> Input Class Initialized
INFO - 2020-02-24 18:16:25 --> Language Class Initialized
INFO - 2020-02-24 18:16:25 --> Language Class Initialized
INFO - 2020-02-24 18:16:25 --> Config Class Initialized
INFO - 2020-02-24 18:16:25 --> Loader Class Initialized
INFO - 2020-02-24 18:16:25 --> Helper loaded: url_helper
INFO - 2020-02-24 18:16:25 --> Helper loaded: common_helper
INFO - 2020-02-24 18:16:25 --> Helper loaded: language_helper
INFO - 2020-02-24 18:16:25 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:16:25 --> Helper loaded: email_helper
INFO - 2020-02-24 18:16:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:16:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:16:25 --> Parser Class Initialized
INFO - 2020-02-24 18:16:25 --> User Agent Class Initialized
INFO - 2020-02-24 18:16:25 --> Model Class Initialized
INFO - 2020-02-24 18:16:25 --> Database Driver Class Initialized
INFO - 2020-02-24 18:16:25 --> Model Class Initialized
DEBUG - 2020-02-24 18:16:25 --> Template Class Initialized
INFO - 2020-02-24 18:16:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:16:25 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:16:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:16:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:16:25 --> Encryption Class Initialized
INFO - 2020-02-24 18:16:25 --> Controller Class Initialized
DEBUG - 2020-02-24 18:16:25 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:16:26 --> Model Class Initialized
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:16:26 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 18:16:26 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:16:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:16:26 --> Model Class Initialized
DEBUG - 2020-02-24 18:16:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:16:26 --> Model Class Initialized
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:16:26 --> Final output sent to browser
DEBUG - 2020-02-24 18:16:26 --> Total execution time: 1.4312
INFO - 2020-02-24 18:16:44 --> Config Class Initialized
INFO - 2020-02-24 18:16:44 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:16:44 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:16:44 --> Utf8 Class Initialized
INFO - 2020-02-24 18:16:44 --> URI Class Initialized
INFO - 2020-02-24 18:16:44 --> Router Class Initialized
INFO - 2020-02-24 18:16:44 --> Output Class Initialized
INFO - 2020-02-24 18:16:44 --> Security Class Initialized
DEBUG - 2020-02-24 18:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:16:45 --> CSRF cookie sent
INFO - 2020-02-24 18:16:45 --> Input Class Initialized
INFO - 2020-02-24 18:16:45 --> Language Class Initialized
INFO - 2020-02-24 18:16:45 --> Language Class Initialized
INFO - 2020-02-24 18:16:45 --> Config Class Initialized
INFO - 2020-02-24 18:16:45 --> Loader Class Initialized
INFO - 2020-02-24 18:16:45 --> Helper loaded: url_helper
INFO - 2020-02-24 18:16:45 --> Helper loaded: common_helper
INFO - 2020-02-24 18:16:45 --> Helper loaded: language_helper
INFO - 2020-02-24 18:16:45 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:16:45 --> Helper loaded: email_helper
INFO - 2020-02-24 18:16:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:16:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:16:45 --> Parser Class Initialized
INFO - 2020-02-24 18:16:45 --> User Agent Class Initialized
INFO - 2020-02-24 18:16:45 --> Model Class Initialized
INFO - 2020-02-24 18:16:45 --> Database Driver Class Initialized
INFO - 2020-02-24 18:16:45 --> Model Class Initialized
DEBUG - 2020-02-24 18:16:45 --> Template Class Initialized
INFO - 2020-02-24 18:16:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:16:45 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:16:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:16:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:16:45 --> Encryption Class Initialized
INFO - 2020-02-24 18:16:45 --> Controller Class Initialized
DEBUG - 2020-02-24 18:16:45 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:16:45 --> Model Class Initialized
ERROR - 2020-02-24 18:16:45 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:16:45 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:16:45 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:16:45 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:16:45 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:16:45 --> Model Class Initialized
DEBUG - 2020-02-24 18:16:45 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:16:45 --> Model Class Initialized
DEBUG - 2020-02-24 18:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:16:45 --> Final output sent to browser
DEBUG - 2020-02-24 18:16:45 --> Total execution time: 1.0447
INFO - 2020-02-24 18:17:07 --> Config Class Initialized
INFO - 2020-02-24 18:17:07 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:17:07 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:17:07 --> Utf8 Class Initialized
INFO - 2020-02-24 18:17:07 --> URI Class Initialized
INFO - 2020-02-24 18:17:07 --> Router Class Initialized
INFO - 2020-02-24 18:17:07 --> Output Class Initialized
INFO - 2020-02-24 18:17:08 --> Security Class Initialized
DEBUG - 2020-02-24 18:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:17:08 --> CSRF cookie sent
INFO - 2020-02-24 18:17:08 --> Input Class Initialized
INFO - 2020-02-24 18:17:08 --> Language Class Initialized
INFO - 2020-02-24 18:17:08 --> Language Class Initialized
INFO - 2020-02-24 18:17:08 --> Config Class Initialized
INFO - 2020-02-24 18:17:08 --> Loader Class Initialized
INFO - 2020-02-24 18:17:08 --> Helper loaded: url_helper
INFO - 2020-02-24 18:17:08 --> Helper loaded: common_helper
INFO - 2020-02-24 18:17:08 --> Helper loaded: language_helper
INFO - 2020-02-24 18:17:08 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:17:08 --> Helper loaded: email_helper
INFO - 2020-02-24 18:17:08 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:17:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:17:08 --> Parser Class Initialized
INFO - 2020-02-24 18:17:08 --> User Agent Class Initialized
INFO - 2020-02-24 18:17:08 --> Model Class Initialized
INFO - 2020-02-24 18:17:08 --> Database Driver Class Initialized
INFO - 2020-02-24 18:17:08 --> Model Class Initialized
DEBUG - 2020-02-24 18:17:08 --> Template Class Initialized
INFO - 2020-02-24 18:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:17:08 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:17:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:17:08 --> Encryption Class Initialized
INFO - 2020-02-24 18:17:08 --> Controller Class Initialized
DEBUG - 2020-02-24 18:17:08 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:17:08 --> Model Class Initialized
ERROR - 2020-02-24 18:17:08 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:17:08 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:17:08 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:17:08 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:17:08 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:17:08 --> Model Class Initialized
DEBUG - 2020-02-24 18:17:08 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:17:08 --> Model Class Initialized
DEBUG - 2020-02-24 18:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:17:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:17:08 --> Final output sent to browser
DEBUG - 2020-02-24 18:17:08 --> Total execution time: 1.0727
INFO - 2020-02-24 18:18:06 --> Config Class Initialized
INFO - 2020-02-24 18:18:06 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:18:06 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:18:06 --> Utf8 Class Initialized
INFO - 2020-02-24 18:18:06 --> URI Class Initialized
INFO - 2020-02-24 18:18:06 --> Router Class Initialized
INFO - 2020-02-24 18:18:06 --> Output Class Initialized
INFO - 2020-02-24 18:18:06 --> Security Class Initialized
DEBUG - 2020-02-24 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:18:07 --> CSRF cookie sent
INFO - 2020-02-24 18:18:07 --> Input Class Initialized
INFO - 2020-02-24 18:18:07 --> Language Class Initialized
INFO - 2020-02-24 18:18:07 --> Language Class Initialized
INFO - 2020-02-24 18:18:07 --> Config Class Initialized
INFO - 2020-02-24 18:18:07 --> Loader Class Initialized
INFO - 2020-02-24 18:18:07 --> Helper loaded: url_helper
INFO - 2020-02-24 18:18:07 --> Helper loaded: common_helper
INFO - 2020-02-24 18:18:07 --> Helper loaded: language_helper
INFO - 2020-02-24 18:18:07 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:18:07 --> Helper loaded: email_helper
INFO - 2020-02-24 18:18:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:18:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:18:07 --> Parser Class Initialized
INFO - 2020-02-24 18:18:07 --> User Agent Class Initialized
INFO - 2020-02-24 18:18:07 --> Model Class Initialized
INFO - 2020-02-24 18:18:07 --> Database Driver Class Initialized
INFO - 2020-02-24 18:18:07 --> Model Class Initialized
DEBUG - 2020-02-24 18:18:07 --> Template Class Initialized
INFO - 2020-02-24 18:18:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:18:07 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:18:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:18:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:18:07 --> Encryption Class Initialized
INFO - 2020-02-24 18:18:07 --> Controller Class Initialized
DEBUG - 2020-02-24 18:18:07 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:18:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:18:07 --> Model Class Initialized
ERROR - 2020-02-24 18:18:07 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:18:07 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:18:07 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 18:18:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:18:07 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:18:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:18:07 --> Model Class Initialized
DEBUG - 2020-02-24 18:18:07 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:18:07 --> Model Class Initialized
DEBUG - 2020-02-24 18:18:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/empty_data.php
DEBUG - 2020-02-24 18:18:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:18:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:18:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:18:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:18:07 --> Final output sent to browser
DEBUG - 2020-02-24 18:18:07 --> Total execution time: 1.0226
INFO - 2020-02-24 18:18:57 --> Config Class Initialized
INFO - 2020-02-24 18:18:57 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:18:57 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:18:57 --> Utf8 Class Initialized
INFO - 2020-02-24 18:18:57 --> URI Class Initialized
INFO - 2020-02-24 18:18:57 --> Router Class Initialized
INFO - 2020-02-24 18:18:57 --> Output Class Initialized
INFO - 2020-02-24 18:18:57 --> Security Class Initialized
DEBUG - 2020-02-24 18:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:18:58 --> CSRF cookie sent
INFO - 2020-02-24 18:18:58 --> Input Class Initialized
INFO - 2020-02-24 18:18:58 --> Language Class Initialized
INFO - 2020-02-24 18:18:58 --> Language Class Initialized
INFO - 2020-02-24 18:18:58 --> Config Class Initialized
INFO - 2020-02-24 18:18:58 --> Loader Class Initialized
INFO - 2020-02-24 18:18:58 --> Helper loaded: url_helper
INFO - 2020-02-24 18:18:58 --> Helper loaded: common_helper
INFO - 2020-02-24 18:18:58 --> Helper loaded: language_helper
INFO - 2020-02-24 18:18:58 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:18:58 --> Helper loaded: email_helper
INFO - 2020-02-24 18:18:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:18:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:18:58 --> Parser Class Initialized
INFO - 2020-02-24 18:18:58 --> User Agent Class Initialized
INFO - 2020-02-24 18:18:58 --> Model Class Initialized
INFO - 2020-02-24 18:18:58 --> Database Driver Class Initialized
INFO - 2020-02-24 18:18:58 --> Model Class Initialized
DEBUG - 2020-02-24 18:18:58 --> Template Class Initialized
INFO - 2020-02-24 18:18:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:18:58 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:18:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:18:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:18:58 --> Encryption Class Initialized
INFO - 2020-02-24 18:18:58 --> Controller Class Initialized
DEBUG - 2020-02-24 18:18:58 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:18:58 --> Model Class Initialized
ERROR - 2020-02-24 18:18:58 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:18:58 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:18:58 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 18:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:18:58 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:18:58 --> Model Class Initialized
DEBUG - 2020-02-24 18:18:58 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:18:58 --> Model Class Initialized
DEBUG - 2020-02-24 18:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/empty_data.php
DEBUG - 2020-02-24 18:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:18:58 --> Final output sent to browser
DEBUG - 2020-02-24 18:18:58 --> Total execution time: 0.9809
INFO - 2020-02-24 18:19:08 --> Config Class Initialized
INFO - 2020-02-24 18:19:08 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:19:08 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:19:08 --> Utf8 Class Initialized
INFO - 2020-02-24 18:19:08 --> URI Class Initialized
INFO - 2020-02-24 18:19:08 --> Router Class Initialized
INFO - 2020-02-24 18:19:08 --> Output Class Initialized
INFO - 2020-02-24 18:19:08 --> Security Class Initialized
DEBUG - 2020-02-24 18:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:19:08 --> CSRF cookie sent
INFO - 2020-02-24 18:19:08 --> Input Class Initialized
INFO - 2020-02-24 18:19:08 --> Language Class Initialized
INFO - 2020-02-24 18:19:08 --> Language Class Initialized
INFO - 2020-02-24 18:19:08 --> Config Class Initialized
INFO - 2020-02-24 18:19:08 --> Loader Class Initialized
INFO - 2020-02-24 18:19:08 --> Helper loaded: url_helper
INFO - 2020-02-24 18:19:08 --> Helper loaded: common_helper
INFO - 2020-02-24 18:19:08 --> Helper loaded: language_helper
INFO - 2020-02-24 18:19:08 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:19:08 --> Helper loaded: email_helper
INFO - 2020-02-24 18:19:08 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:19:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:19:08 --> Parser Class Initialized
INFO - 2020-02-24 18:19:08 --> User Agent Class Initialized
INFO - 2020-02-24 18:19:08 --> Model Class Initialized
INFO - 2020-02-24 18:19:08 --> Database Driver Class Initialized
INFO - 2020-02-24 18:19:08 --> Model Class Initialized
DEBUG - 2020-02-24 18:19:08 --> Template Class Initialized
INFO - 2020-02-24 18:19:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:19:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:19:08 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:19:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:19:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:19:08 --> Encryption Class Initialized
INFO - 2020-02-24 18:19:08 --> Controller Class Initialized
DEBUG - 2020-02-24 18:19:08 --> category MX_Controller Initialized
ERROR - 2020-02-24 18:19:09 --> Severity: error --> Exception: syntax error, unexpected ')' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\models\category_model.php 21
INFO - 2020-02-24 18:19:19 --> Config Class Initialized
INFO - 2020-02-24 18:19:19 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:19:19 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:19:19 --> Utf8 Class Initialized
INFO - 2020-02-24 18:19:19 --> URI Class Initialized
INFO - 2020-02-24 18:19:19 --> Router Class Initialized
INFO - 2020-02-24 18:19:19 --> Output Class Initialized
INFO - 2020-02-24 18:19:19 --> Security Class Initialized
DEBUG - 2020-02-24 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:19:19 --> CSRF cookie sent
INFO - 2020-02-24 18:19:19 --> Input Class Initialized
INFO - 2020-02-24 18:19:19 --> Language Class Initialized
INFO - 2020-02-24 18:19:19 --> Language Class Initialized
INFO - 2020-02-24 18:19:19 --> Config Class Initialized
INFO - 2020-02-24 18:19:19 --> Loader Class Initialized
INFO - 2020-02-24 18:19:19 --> Helper loaded: url_helper
INFO - 2020-02-24 18:19:19 --> Helper loaded: common_helper
INFO - 2020-02-24 18:19:19 --> Helper loaded: language_helper
INFO - 2020-02-24 18:19:19 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:19:19 --> Helper loaded: email_helper
INFO - 2020-02-24 18:19:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:19:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:19:19 --> Parser Class Initialized
INFO - 2020-02-24 18:19:19 --> User Agent Class Initialized
INFO - 2020-02-24 18:19:19 --> Model Class Initialized
INFO - 2020-02-24 18:19:19 --> Database Driver Class Initialized
INFO - 2020-02-24 18:19:19 --> Model Class Initialized
DEBUG - 2020-02-24 18:19:19 --> Template Class Initialized
INFO - 2020-02-24 18:19:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:19:20 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:19:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:19:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:19:20 --> Encryption Class Initialized
INFO - 2020-02-24 18:19:20 --> Controller Class Initialized
DEBUG - 2020-02-24 18:19:20 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:19:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:19:20 --> Model Class Initialized
ERROR - 2020-02-24 18:19:20 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:19:20 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:19:20 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 18:19:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:19:20 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:19:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:19:20 --> Model Class Initialized
DEBUG - 2020-02-24 18:19:20 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:19:20 --> Model Class Initialized
DEBUG - 2020-02-24 18:19:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/empty_data.php
DEBUG - 2020-02-24 18:19:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:19:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:19:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:19:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:19:20 --> Final output sent to browser
DEBUG - 2020-02-24 18:19:20 --> Total execution time: 1.1016
INFO - 2020-02-24 18:19:40 --> Config Class Initialized
INFO - 2020-02-24 18:19:40 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:19:40 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:19:40 --> Utf8 Class Initialized
INFO - 2020-02-24 18:19:40 --> URI Class Initialized
INFO - 2020-02-24 18:19:40 --> Router Class Initialized
INFO - 2020-02-24 18:19:40 --> Output Class Initialized
INFO - 2020-02-24 18:19:40 --> Security Class Initialized
DEBUG - 2020-02-24 18:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:19:40 --> CSRF cookie sent
INFO - 2020-02-24 18:19:40 --> Input Class Initialized
INFO - 2020-02-24 18:19:40 --> Language Class Initialized
INFO - 2020-02-24 18:19:40 --> Language Class Initialized
INFO - 2020-02-24 18:19:40 --> Config Class Initialized
INFO - 2020-02-24 18:19:40 --> Loader Class Initialized
INFO - 2020-02-24 18:19:40 --> Helper loaded: url_helper
INFO - 2020-02-24 18:19:40 --> Helper loaded: common_helper
INFO - 2020-02-24 18:19:40 --> Helper loaded: language_helper
INFO - 2020-02-24 18:19:40 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:19:40 --> Helper loaded: email_helper
INFO - 2020-02-24 18:19:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:19:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:19:40 --> Parser Class Initialized
INFO - 2020-02-24 18:19:40 --> User Agent Class Initialized
INFO - 2020-02-24 18:19:40 --> Model Class Initialized
INFO - 2020-02-24 18:19:40 --> Database Driver Class Initialized
INFO - 2020-02-24 18:19:40 --> Model Class Initialized
DEBUG - 2020-02-24 18:19:41 --> Template Class Initialized
INFO - 2020-02-24 18:19:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:19:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:19:41 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:19:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:19:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:19:41 --> Encryption Class Initialized
INFO - 2020-02-24 18:19:41 --> Controller Class Initialized
DEBUG - 2020-02-24 18:19:41 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:19:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:19:41 --> Model Class Initialized
ERROR - 2020-02-24 18:19:41 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:19:41 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:19:41 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:19:41 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:19:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:19:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:19:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:19:41 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:19:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:19:41 --> Model Class Initialized
DEBUG - 2020-02-24 18:19:41 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:19:41 --> Model Class Initialized
DEBUG - 2020-02-24 18:19:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:19:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:19:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:19:41 --> Final output sent to browser
DEBUG - 2020-02-24 18:19:41 --> Total execution time: 1.0977
INFO - 2020-02-24 18:20:25 --> Config Class Initialized
INFO - 2020-02-24 18:20:25 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:20:25 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:20:25 --> Utf8 Class Initialized
INFO - 2020-02-24 18:20:25 --> URI Class Initialized
INFO - 2020-02-24 18:20:25 --> Router Class Initialized
INFO - 2020-02-24 18:20:25 --> Output Class Initialized
INFO - 2020-02-24 18:20:25 --> Security Class Initialized
DEBUG - 2020-02-24 18:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:20:25 --> CSRF cookie sent
INFO - 2020-02-24 18:20:25 --> Input Class Initialized
INFO - 2020-02-24 18:20:25 --> Language Class Initialized
INFO - 2020-02-24 18:20:25 --> Language Class Initialized
INFO - 2020-02-24 18:20:25 --> Config Class Initialized
INFO - 2020-02-24 18:20:25 --> Loader Class Initialized
INFO - 2020-02-24 18:20:25 --> Helper loaded: url_helper
INFO - 2020-02-24 18:20:25 --> Helper loaded: common_helper
INFO - 2020-02-24 18:20:25 --> Helper loaded: language_helper
INFO - 2020-02-24 18:20:25 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:20:25 --> Helper loaded: email_helper
INFO - 2020-02-24 18:20:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:20:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:20:25 --> Parser Class Initialized
INFO - 2020-02-24 18:20:25 --> User Agent Class Initialized
INFO - 2020-02-24 18:20:25 --> Model Class Initialized
INFO - 2020-02-24 18:20:25 --> Database Driver Class Initialized
INFO - 2020-02-24 18:20:25 --> Model Class Initialized
DEBUG - 2020-02-24 18:20:25 --> Template Class Initialized
INFO - 2020-02-24 18:20:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:20:26 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:20:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:20:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:20:26 --> Encryption Class Initialized
INFO - 2020-02-24 18:20:26 --> Controller Class Initialized
DEBUG - 2020-02-24 18:20:26 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:20:26 --> Model Class Initialized
ERROR - 2020-02-24 18:20:26 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:20:26 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 18:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-24 18:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:20:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:20:26 --> Model Class Initialized
DEBUG - 2020-02-24 18:20:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:20:26 --> Model Class Initialized
DEBUG - 2020-02-24 18:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:20:26 --> Final output sent to browser
DEBUG - 2020-02-24 18:20:26 --> Total execution time: 0.9872
INFO - 2020-02-24 18:20:45 --> Config Class Initialized
INFO - 2020-02-24 18:20:45 --> Hooks Class Initialized
DEBUG - 2020-02-24 18:20:45 --> UTF-8 Support Enabled
INFO - 2020-02-24 18:20:45 --> Utf8 Class Initialized
INFO - 2020-02-24 18:20:45 --> URI Class Initialized
INFO - 2020-02-24 18:20:45 --> Router Class Initialized
INFO - 2020-02-24 18:20:45 --> Output Class Initialized
INFO - 2020-02-24 18:20:45 --> Security Class Initialized
DEBUG - 2020-02-24 18:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 18:20:45 --> CSRF cookie sent
INFO - 2020-02-24 18:20:45 --> Input Class Initialized
INFO - 2020-02-24 18:20:45 --> Language Class Initialized
INFO - 2020-02-24 18:20:45 --> Language Class Initialized
INFO - 2020-02-24 18:20:45 --> Config Class Initialized
INFO - 2020-02-24 18:20:45 --> Loader Class Initialized
INFO - 2020-02-24 18:20:45 --> Helper loaded: url_helper
INFO - 2020-02-24 18:20:45 --> Helper loaded: common_helper
INFO - 2020-02-24 18:20:45 --> Helper loaded: language_helper
INFO - 2020-02-24 18:20:45 --> Helper loaded: cookie_helper
INFO - 2020-02-24 18:20:45 --> Helper loaded: email_helper
INFO - 2020-02-24 18:20:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 18:20:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 18:20:45 --> Parser Class Initialized
INFO - 2020-02-24 18:20:45 --> User Agent Class Initialized
INFO - 2020-02-24 18:20:45 --> Model Class Initialized
INFO - 2020-02-24 18:20:45 --> Database Driver Class Initialized
INFO - 2020-02-24 18:20:45 --> Model Class Initialized
DEBUG - 2020-02-24 18:20:45 --> Template Class Initialized
INFO - 2020-02-24 18:20:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 18:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 18:20:45 --> Pagination Class Initialized
DEBUG - 2020-02-24 18:20:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 18:20:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 18:20:45 --> Encryption Class Initialized
INFO - 2020-02-24 18:20:45 --> Controller Class Initialized
DEBUG - 2020-02-24 18:20:45 --> category MX_Controller Initialized
DEBUG - 2020-02-24 18:20:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:20:45 --> Model Class Initialized
ERROR - 2020-02-24 18:20:45 --> Could not find the language line "Sorting"
INFO - 2020-02-24 18:20:45 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 18:20:45 --> Could not find the language line "Delele"
ERROR - 2020-02-24 18:20:45 --> Could not find the language line "View"
DEBUG - 2020-02-24 18:20:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 18:20:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 18:20:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 18:20:45 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 18:20:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 18:20:46 --> Model Class Initialized
DEBUG - 2020-02-24 18:20:46 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 18:20:46 --> Model Class Initialized
DEBUG - 2020-02-24 18:20:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 18:20:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 18:20:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 18:20:46 --> Final output sent to browser
DEBUG - 2020-02-24 18:20:46 --> Total execution time: 1.0607
INFO - 2020-02-24 22:36:25 --> Config Class Initialized
INFO - 2020-02-24 22:36:25 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:36:25 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:25 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:25 --> URI Class Initialized
DEBUG - 2020-02-24 22:36:26 --> No URI present. Default controller set.
INFO - 2020-02-24 22:36:26 --> Router Class Initialized
INFO - 2020-02-24 22:36:26 --> Output Class Initialized
INFO - 2020-02-24 22:36:26 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:36:26 --> CSRF cookie sent
INFO - 2020-02-24 22:36:26 --> Input Class Initialized
INFO - 2020-02-24 22:36:26 --> Language Class Initialized
INFO - 2020-02-24 22:36:26 --> Language Class Initialized
INFO - 2020-02-24 22:36:26 --> Config Class Initialized
INFO - 2020-02-24 22:36:26 --> Loader Class Initialized
INFO - 2020-02-24 22:36:26 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:26 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:26 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:26 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:26 --> Parser Class Initialized
INFO - 2020-02-24 22:36:26 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:26 --> Model Class Initialized
INFO - 2020-02-24 22:36:26 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:27 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:27 --> Template Class Initialized
INFO - 2020-02-24 22:36:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:27 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:27 --> Encryption Class Initialized
DEBUG - 2020-02-24 22:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-24 22:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-02-24 22:36:27 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:27 --> pergo MX_Controller Initialized
DEBUG - 2020-02-24 22:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-24 22:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-02-24 22:36:27 --> Model Class Initialized
INFO - 2020-02-24 22:36:28 --> Helper loaded: inflector_helper
DEBUG - 2020-02-24 22:36:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-02-24 22:36:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-02-24 22:36:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-02-24 22:36:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-02-24 22:36:28 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:28 --> Total execution time: 2.7322
INFO - 2020-02-24 22:36:32 --> Config Class Initialized
INFO - 2020-02-24 22:36:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:36:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:32 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:32 --> URI Class Initialized
INFO - 2020-02-24 22:36:32 --> Router Class Initialized
INFO - 2020-02-24 22:36:32 --> Output Class Initialized
INFO - 2020-02-24 22:36:32 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:36:32 --> CSRF cookie sent
INFO - 2020-02-24 22:36:32 --> Input Class Initialized
INFO - 2020-02-24 22:36:32 --> Language Class Initialized
INFO - 2020-02-24 22:36:33 --> Language Class Initialized
INFO - 2020-02-24 22:36:33 --> Config Class Initialized
INFO - 2020-02-24 22:36:33 --> Loader Class Initialized
INFO - 2020-02-24 22:36:33 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:33 --> Parser Class Initialized
INFO - 2020-02-24 22:36:33 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:33 --> Model Class Initialized
INFO - 2020-02-24 22:36:33 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:33 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:33 --> Template Class Initialized
INFO - 2020-02-24 22:36:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:33 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:33 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:33 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:33 --> auth MX_Controller Initialized
DEBUG - 2020-02-24 22:36:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-02-24 22:36:33 --> Model Class Initialized
INFO - 2020-02-24 22:36:33 --> Config Class Initialized
INFO - 2020-02-24 22:36:33 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:36:33 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:33 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:33 --> URI Class Initialized
INFO - 2020-02-24 22:36:33 --> Router Class Initialized
INFO - 2020-02-24 22:36:33 --> Output Class Initialized
INFO - 2020-02-24 22:36:33 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:36:33 --> CSRF cookie sent
INFO - 2020-02-24 22:36:33 --> Input Class Initialized
INFO - 2020-02-24 22:36:33 --> Language Class Initialized
INFO - 2020-02-24 22:36:33 --> Language Class Initialized
INFO - 2020-02-24 22:36:33 --> Config Class Initialized
INFO - 2020-02-24 22:36:33 --> Loader Class Initialized
INFO - 2020-02-24 22:36:33 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:33 --> Parser Class Initialized
INFO - 2020-02-24 22:36:33 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:33 --> Model Class Initialized
INFO - 2020-02-24 22:36:33 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:33 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:34 --> Template Class Initialized
INFO - 2020-02-24 22:36:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:34 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:34 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:34 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:34 --> statistics MX_Controller Initialized
DEBUG - 2020-02-24 22:36:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-02-24 22:36:34 --> Model Class Initialized
ERROR - 2020-02-24 22:36:34 --> Could not find the language line "Pending"
ERROR - 2020-02-24 22:36:34 --> Could not find the language line "Pending"
INFO - 2020-02-24 22:36:34 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:36:34 --> Could not find the language line "total_orders"
ERROR - 2020-02-24 22:36:34 --> Could not find the language line "total_orders"
ERROR - 2020-02-24 22:36:34 --> Could not find the language line "Pending"
DEBUG - 2020-02-24 22:36:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-02-24 22:36:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:36:34 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:36:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:34 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:36:34 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:36:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:36:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:36:34 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:34 --> Total execution time: 1.3615
INFO - 2020-02-24 22:36:39 --> Config Class Initialized
INFO - 2020-02-24 22:36:39 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:36:39 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:39 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:39 --> URI Class Initialized
INFO - 2020-02-24 22:36:39 --> Router Class Initialized
INFO - 2020-02-24 22:36:39 --> Output Class Initialized
INFO - 2020-02-24 22:36:39 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:36:39 --> CSRF cookie sent
INFO - 2020-02-24 22:36:39 --> Input Class Initialized
INFO - 2020-02-24 22:36:39 --> Language Class Initialized
INFO - 2020-02-24 22:36:39 --> Language Class Initialized
INFO - 2020-02-24 22:36:39 --> Config Class Initialized
INFO - 2020-02-24 22:36:39 --> Loader Class Initialized
INFO - 2020-02-24 22:36:39 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:39 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:39 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:39 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:39 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:39 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:39 --> Parser Class Initialized
INFO - 2020-02-24 22:36:40 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:40 --> Model Class Initialized
INFO - 2020-02-24 22:36:40 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:40 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:40 --> Template Class Initialized
INFO - 2020-02-24 22:36:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:40 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:40 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:40 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:40 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:36:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:40 --> Model Class Initialized
INFO - 2020-02-24 22:36:40 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:36:40 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 22:36:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2020-02-24 22:36:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:36:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:36:40 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:40 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:36:40 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:36:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:36:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:36:41 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:41 --> Total execution time: 1.6005
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:41 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:41 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:41 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:41 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:41 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:36:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:36:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:36:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:36:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:36:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:36:41 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:41 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:41 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:41 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:41 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:41 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:41 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:41 --> URI Class Initialized
INFO - 2020-02-24 22:36:41 --> URI Class Initialized
INFO - 2020-02-24 22:36:41 --> URI Class Initialized
INFO - 2020-02-24 22:36:41 --> URI Class Initialized
INFO - 2020-02-24 22:36:41 --> URI Class Initialized
INFO - 2020-02-24 22:36:41 --> URI Class Initialized
INFO - 2020-02-24 22:36:41 --> Router Class Initialized
INFO - 2020-02-24 22:36:41 --> Router Class Initialized
INFO - 2020-02-24 22:36:41 --> Router Class Initialized
INFO - 2020-02-24 22:36:41 --> Router Class Initialized
INFO - 2020-02-24 22:36:41 --> Router Class Initialized
INFO - 2020-02-24 22:36:41 --> Router Class Initialized
INFO - 2020-02-24 22:36:41 --> Output Class Initialized
INFO - 2020-02-24 22:36:41 --> Output Class Initialized
INFO - 2020-02-24 22:36:41 --> Output Class Initialized
INFO - 2020-02-24 22:36:41 --> Output Class Initialized
INFO - 2020-02-24 22:36:41 --> Output Class Initialized
INFO - 2020-02-24 22:36:41 --> Output Class Initialized
INFO - 2020-02-24 22:36:41 --> Security Class Initialized
INFO - 2020-02-24 22:36:41 --> Security Class Initialized
INFO - 2020-02-24 22:36:41 --> Security Class Initialized
INFO - 2020-02-24 22:36:41 --> Security Class Initialized
INFO - 2020-02-24 22:36:41 --> Security Class Initialized
INFO - 2020-02-24 22:36:41 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:36:41 --> CSRF cookie sent
INFO - 2020-02-24 22:36:41 --> CSRF cookie sent
INFO - 2020-02-24 22:36:41 --> CSRF cookie sent
INFO - 2020-02-24 22:36:41 --> CSRF cookie sent
INFO - 2020-02-24 22:36:41 --> CSRF cookie sent
INFO - 2020-02-24 22:36:41 --> CSRF cookie sent
INFO - 2020-02-24 22:36:41 --> CSRF token verified
INFO - 2020-02-24 22:36:41 --> CSRF token verified
INFO - 2020-02-24 22:36:41 --> CSRF token verified
INFO - 2020-02-24 22:36:41 --> CSRF token verified
INFO - 2020-02-24 22:36:41 --> CSRF token verified
INFO - 2020-02-24 22:36:41 --> CSRF token verified
INFO - 2020-02-24 22:36:41 --> Input Class Initialized
INFO - 2020-02-24 22:36:41 --> Input Class Initialized
INFO - 2020-02-24 22:36:41 --> Input Class Initialized
INFO - 2020-02-24 22:36:41 --> Input Class Initialized
INFO - 2020-02-24 22:36:41 --> Input Class Initialized
INFO - 2020-02-24 22:36:41 --> Input Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Language Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Config Class Initialized
INFO - 2020-02-24 22:36:41 --> Loader Class Initialized
INFO - 2020-02-24 22:36:41 --> Loader Class Initialized
INFO - 2020-02-24 22:36:41 --> Loader Class Initialized
INFO - 2020-02-24 22:36:41 --> Loader Class Initialized
INFO - 2020-02-24 22:36:41 --> Loader Class Initialized
INFO - 2020-02-24 22:36:41 --> Loader Class Initialized
INFO - 2020-02-24 22:36:41 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:42 --> Parser Class Initialized
INFO - 2020-02-24 22:36:42 --> Parser Class Initialized
INFO - 2020-02-24 22:36:42 --> Parser Class Initialized
INFO - 2020-02-24 22:36:42 --> Parser Class Initialized
INFO - 2020-02-24 22:36:42 --> Parser Class Initialized
INFO - 2020-02-24 22:36:42 --> Parser Class Initialized
INFO - 2020-02-24 22:36:42 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:42 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:42 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:42 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:42 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:42 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:42 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:42 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:42 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:42 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:42 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:42 --> Template Class Initialized
DEBUG - 2020-02-24 22:36:42 --> Template Class Initialized
DEBUG - 2020-02-24 22:36:42 --> Template Class Initialized
DEBUG - 2020-02-24 22:36:42 --> Template Class Initialized
DEBUG - 2020-02-24 22:36:42 --> Template Class Initialized
DEBUG - 2020-02-24 22:36:42 --> Template Class Initialized
INFO - 2020-02-24 22:36:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:42 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:42 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:42 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:42 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:42 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:42 --> Total execution time: 1.2525
INFO - 2020-02-24 22:36:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:42 --> Config Class Initialized
INFO - 2020-02-24 22:36:42 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:42 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:42 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:42 --> Utf8 Class Initialized
DEBUG - 2020-02-24 22:36:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:42 --> URI Class Initialized
INFO - 2020-02-24 22:36:42 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:42 --> Router Class Initialized
INFO - 2020-02-24 22:36:42 --> Controller Class Initialized
INFO - 2020-02-24 22:36:42 --> Output Class Initialized
DEBUG - 2020-02-24 22:36:42 --> services MX_Controller Initialized
INFO - 2020-02-24 22:36:42 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
DEBUG - 2020-02-24 22:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:36:42 --> CSRF cookie sent
INFO - 2020-02-24 22:36:42 --> Model Class Initialized
INFO - 2020-02-24 22:36:42 --> Input Class Initialized
INFO - 2020-02-24 22:36:42 --> Language Class Initialized
DEBUG - 2020-02-24 22:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:42 --> Final output sent to browser
INFO - 2020-02-24 22:36:42 --> Language Class Initialized
DEBUG - 2020-02-24 22:36:42 --> Total execution time: 1.5765
INFO - 2020-02-24 22:36:42 --> Config Class Initialized
INFO - 2020-02-24 22:36:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:43 --> Loader Class Initialized
INFO - 2020-02-24 22:36:43 --> Config Class Initialized
INFO - 2020-02-24 22:36:43 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:43 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:43 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:43 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:43 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: language_helper
DEBUG - 2020-02-24 22:36:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:43 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:43 --> URI Class Initialized
INFO - 2020-02-24 22:36:43 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:43 --> Router Class Initialized
INFO - 2020-02-24 22:36:43 --> Controller Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:43 --> Output Class Initialized
DEBUG - 2020-02-24 22:36:43 --> services MX_Controller Initialized
INFO - 2020-02-24 22:36:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:43 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:43 --> Parser Class Initialized
INFO - 2020-02-24 22:36:43 --> Model Class Initialized
INFO - 2020-02-24 22:36:43 --> CSRF cookie sent
INFO - 2020-02-24 22:36:43 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:43 --> CSRF token verified
INFO - 2020-02-24 22:36:43 --> Model Class Initialized
INFO - 2020-02-24 22:36:43 --> Input Class Initialized
INFO - 2020-02-24 22:36:43 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:43 --> Language Class Initialized
INFO - 2020-02-24 22:36:43 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:43 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:43 --> Template Class Initialized
INFO - 2020-02-24 22:36:43 --> Language Class Initialized
INFO - 2020-02-24 22:36:43 --> Config Class Initialized
DEBUG - 2020-02-24 22:36:43 --> Total execution time: 1.9420
INFO - 2020-02-24 22:36:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:43 --> Loader Class Initialized
INFO - 2020-02-24 22:36:43 --> Config Class Initialized
INFO - 2020-02-24 22:36:43 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:43 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:43 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:43 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:43 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: language_helper
DEBUG - 2020-02-24 22:36:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:43 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:43 --> URI Class Initialized
INFO - 2020-02-24 22:36:43 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:43 --> Router Class Initialized
INFO - 2020-02-24 22:36:43 --> Controller Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:43 --> Output Class Initialized
DEBUG - 2020-02-24 22:36:43 --> services MX_Controller Initialized
INFO - 2020-02-24 22:36:43 --> Security Class Initialized
INFO - 2020-02-24 22:36:43 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 22:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:43 --> Parser Class Initialized
INFO - 2020-02-24 22:36:43 --> Model Class Initialized
INFO - 2020-02-24 22:36:43 --> CSRF cookie sent
INFO - 2020-02-24 22:36:43 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:43 --> CSRF token verified
INFO - 2020-02-24 22:36:43 --> Model Class Initialized
INFO - 2020-02-24 22:36:43 --> Input Class Initialized
INFO - 2020-02-24 22:36:43 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:43 --> Language Class Initialized
DEBUG - 2020-02-24 22:36:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:43 --> Model Class Initialized
INFO - 2020-02-24 22:36:43 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:43 --> Template Class Initialized
INFO - 2020-02-24 22:36:43 --> Language Class Initialized
INFO - 2020-02-24 22:36:43 --> Config Class Initialized
DEBUG - 2020-02-24 22:36:43 --> Total execution time: 2.3271
INFO - 2020-02-24 22:36:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:43 --> Loader Class Initialized
INFO - 2020-02-24 22:36:43 --> Config Class Initialized
INFO - 2020-02-24 22:36:43 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:43 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:43 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:43 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:43 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: language_helper
DEBUG - 2020-02-24 22:36:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:43 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:43 --> URI Class Initialized
INFO - 2020-02-24 22:36:43 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:43 --> Router Class Initialized
INFO - 2020-02-24 22:36:43 --> Controller Class Initialized
INFO - 2020-02-24 22:36:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:43 --> Output Class Initialized
DEBUG - 2020-02-24 22:36:43 --> services MX_Controller Initialized
INFO - 2020-02-24 22:36:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:43 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:43 --> Parser Class Initialized
INFO - 2020-02-24 22:36:43 --> Model Class Initialized
INFO - 2020-02-24 22:36:43 --> CSRF cookie sent
INFO - 2020-02-24 22:36:43 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:43 --> CSRF token verified
INFO - 2020-02-24 22:36:43 --> Model Class Initialized
INFO - 2020-02-24 22:36:44 --> Input Class Initialized
INFO - 2020-02-24 22:36:44 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:44 --> Language Class Initialized
INFO - 2020-02-24 22:36:44 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:44 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:44 --> Template Class Initialized
INFO - 2020-02-24 22:36:44 --> Language Class Initialized
DEBUG - 2020-02-24 22:36:44 --> Total execution time: 2.6759
INFO - 2020-02-24 22:36:44 --> Config Class Initialized
INFO - 2020-02-24 22:36:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:44 --> Loader Class Initialized
INFO - 2020-02-24 22:36:44 --> Config Class Initialized
INFO - 2020-02-24 22:36:44 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:44 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:44 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:44 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:44 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: language_helper
DEBUG - 2020-02-24 22:36:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:44 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:44 --> URI Class Initialized
INFO - 2020-02-24 22:36:44 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:44 --> Router Class Initialized
INFO - 2020-02-24 22:36:44 --> Controller Class Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:44 --> Output Class Initialized
DEBUG - 2020-02-24 22:36:44 --> services MX_Controller Initialized
INFO - 2020-02-24 22:36:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:44 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:44 --> Parser Class Initialized
INFO - 2020-02-24 22:36:44 --> Model Class Initialized
INFO - 2020-02-24 22:36:44 --> CSRF cookie sent
INFO - 2020-02-24 22:36:44 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:44 --> CSRF token verified
INFO - 2020-02-24 22:36:44 --> Model Class Initialized
INFO - 2020-02-24 22:36:44 --> Input Class Initialized
INFO - 2020-02-24 22:36:44 --> Database Driver Class Initialized
DEBUG - 2020-02-24 22:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:44 --> Final output sent to browser
INFO - 2020-02-24 22:36:44 --> Language Class Initialized
INFO - 2020-02-24 22:36:44 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:44 --> Total execution time: 3.1872
DEBUG - 2020-02-24 22:36:44 --> Template Class Initialized
INFO - 2020-02-24 22:36:44 --> Language Class Initialized
INFO - 2020-02-24 22:36:44 --> Config Class Initialized
INFO - 2020-02-24 22:36:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:44 --> Config Class Initialized
INFO - 2020-02-24 22:36:44 --> Hooks Class Initialized
INFO - 2020-02-24 22:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:44 --> Loader Class Initialized
INFO - 2020-02-24 22:36:44 --> Pagination Class Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: url_helper
DEBUG - 2020-02-24 22:36:44 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:44 --> Utf8 Class Initialized
DEBUG - 2020-02-24 22:36:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:44 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:44 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:44 --> URI Class Initialized
INFO - 2020-02-24 22:36:44 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:44 --> Router Class Initialized
INFO - 2020-02-24 22:36:44 --> Controller Class Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:44 --> Output Class Initialized
DEBUG - 2020-02-24 22:36:44 --> category MX_Controller Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:44 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
DEBUG - 2020-02-24 22:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:36:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:44 --> CSRF cookie sent
INFO - 2020-02-24 22:36:44 --> Model Class Initialized
INFO - 2020-02-24 22:36:44 --> Parser Class Initialized
INFO - 2020-02-24 22:36:44 --> CSRF token verified
INFO - 2020-02-24 22:36:44 --> User Agent Class Initialized
ERROR - 2020-02-24 22:36:44 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:36:44 --> Input Class Initialized
INFO - 2020-02-24 22:36:44 --> Model Class Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: inflector_helper
INFO - 2020-02-24 22:36:44 --> Language Class Initialized
INFO - 2020-02-24 22:36:44 --> Database Driver Class Initialized
ERROR - 2020-02-24 22:36:44 --> Could not find the language line "Delele"
INFO - 2020-02-24 22:36:44 --> Model Class Initialized
INFO - 2020-02-24 22:36:44 --> Language Class Initialized
ERROR - 2020-02-24 22:36:44 --> Could not find the language line "View"
INFO - 2020-02-24 22:36:44 --> Config Class Initialized
DEBUG - 2020-02-24 22:36:44 --> Template Class Initialized
DEBUG - 2020-02-24 22:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
INFO - 2020-02-24 22:36:44 --> Loader Class Initialized
INFO - 2020-02-24 22:36:44 --> Helper loaded: url_helper
DEBUG - 2020-02-24 22:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:36:45 --> blocks MX_Controller Initialized
INFO - 2020-02-24 22:36:45 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:45 --> Helper loaded: language_helper
DEBUG - 2020-02-24 22:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:45 --> Model Class Initialized
INFO - 2020-02-24 22:36:45 --> Helper loaded: cookie_helper
DEBUG - 2020-02-24 22:36:45 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:36:45 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:45 --> Model Class Initialized
INFO - 2020-02-24 22:36:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:45 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 22:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
INFO - 2020-02-24 22:36:45 --> Parser Class Initialized
INFO - 2020-02-24 22:36:45 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:45 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:36:45 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:45 --> Final output sent to browser
INFO - 2020-02-24 22:36:45 --> Model Class Initialized
INFO - 2020-02-24 22:36:45 --> Config Class Initialized
INFO - 2020-02-24 22:36:45 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:36:45 --> Total execution time: 2.5903
DEBUG - 2020-02-24 22:36:45 --> Template Class Initialized
INFO - 2020-02-24 22:36:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-02-24 22:36:45 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:45 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:45 --> Pagination Class Initialized
INFO - 2020-02-24 22:36:45 --> URI Class Initialized
DEBUG - 2020-02-24 22:36:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:45 --> Router Class Initialized
INFO - 2020-02-24 22:36:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:45 --> Output Class Initialized
INFO - 2020-02-24 22:36:45 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:45 --> Security Class Initialized
INFO - 2020-02-24 22:36:45 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:36:45 --> services MX_Controller Initialized
INFO - 2020-02-24 22:36:45 --> CSRF cookie sent
INFO - 2020-02-24 22:36:45 --> CSRF token verified
DEBUG - 2020-02-24 22:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:45 --> Model Class Initialized
INFO - 2020-02-24 22:36:45 --> Input Class Initialized
INFO - 2020-02-24 22:36:45 --> Language Class Initialized
INFO - 2020-02-24 22:36:45 --> Language Class Initialized
INFO - 2020-02-24 22:36:45 --> Config Class Initialized
DEBUG - 2020-02-24 22:36:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:45 --> Final output sent to browser
INFO - 2020-02-24 22:36:45 --> Loader Class Initialized
DEBUG - 2020-02-24 22:36:45 --> Total execution time: 2.9349
INFO - 2020-02-24 22:36:45 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:46 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:46 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:46 --> Pagination Class Initialized
INFO - 2020-02-24 22:36:46 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:46 --> Helper loaded: email_helper
DEBUG - 2020-02-24 22:36:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:46 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:46 --> Controller Class Initialized
INFO - 2020-02-24 22:36:46 --> Parser Class Initialized
DEBUG - 2020-02-24 22:36:46 --> services MX_Controller Initialized
INFO - 2020-02-24 22:36:46 --> User Agent Class Initialized
DEBUG - 2020-02-24 22:36:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:46 --> Model Class Initialized
INFO - 2020-02-24 22:36:46 --> Model Class Initialized
INFO - 2020-02-24 22:36:46 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:46 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:46 --> Template Class Initialized
DEBUG - 2020-02-24 22:36:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:46 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:46 --> Total execution time: 2.8817
INFO - 2020-02-24 22:36:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:46 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:46 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:46 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:46 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:36:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:46 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:46 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:46 --> Total execution time: 2.7712
INFO - 2020-02-24 22:36:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:46 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:46 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:46 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:46 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:36:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:46 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:46 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:46 --> Total execution time: 2.6720
INFO - 2020-02-24 22:36:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:46 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:46 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:46 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:46 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:36:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:46 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:47 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:47 --> Total execution time: 2.3906
INFO - 2020-02-24 22:36:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:47 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:47 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:47 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:47 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:47 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:36:47 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:47 --> Total execution time: 1.9379
INFO - 2020-02-24 22:36:47 --> Config Class Initialized
INFO - 2020-02-24 22:36:47 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:36:47 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:47 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:47 --> URI Class Initialized
INFO - 2020-02-24 22:36:47 --> Router Class Initialized
INFO - 2020-02-24 22:36:47 --> Output Class Initialized
INFO - 2020-02-24 22:36:47 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:36:47 --> CSRF cookie sent
INFO - 2020-02-24 22:36:47 --> CSRF token verified
INFO - 2020-02-24 22:36:47 --> Input Class Initialized
INFO - 2020-02-24 22:36:47 --> Language Class Initialized
INFO - 2020-02-24 22:36:47 --> Language Class Initialized
INFO - 2020-02-24 22:36:47 --> Config Class Initialized
INFO - 2020-02-24 22:36:48 --> Loader Class Initialized
INFO - 2020-02-24 22:36:48 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:48 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:48 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:48 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:48 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:48 --> Parser Class Initialized
INFO - 2020-02-24 22:36:48 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:48 --> Model Class Initialized
INFO - 2020-02-24 22:36:48 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:48 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:48 --> Template Class Initialized
INFO - 2020-02-24 22:36:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:48 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:48 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:48 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:48 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:36:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:36:48 --> Model Class Initialized
ERROR - 2020-02-24 22:36:48 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 22:36:48 --> Could not find the language line "View"
ERROR - 2020-02-24 22:36:48 --> Could not find the language line "View"
ERROR - 2020-02-24 22:36:48 --> Could not find the language line "View"
ERROR - 2020-02-24 22:36:48 --> Could not find the language line "View"
ERROR - 2020-02-24 22:36:48 --> Could not find the language line "View"
ERROR - 2020-02-24 22:36:48 --> Could not find the language line "View"
DEBUG - 2020-02-24 22:36:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/search.php
INFO - 2020-02-24 22:36:48 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:48 --> Total execution time: 0.9057
INFO - 2020-02-24 22:36:53 --> Config Class Initialized
INFO - 2020-02-24 22:36:53 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:36:53 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:36:53 --> Utf8 Class Initialized
INFO - 2020-02-24 22:36:53 --> URI Class Initialized
INFO - 2020-02-24 22:36:53 --> Router Class Initialized
INFO - 2020-02-24 22:36:53 --> Output Class Initialized
INFO - 2020-02-24 22:36:53 --> Security Class Initialized
DEBUG - 2020-02-24 22:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:36:53 --> CSRF cookie sent
INFO - 2020-02-24 22:36:53 --> Input Class Initialized
INFO - 2020-02-24 22:36:53 --> Language Class Initialized
INFO - 2020-02-24 22:36:53 --> Language Class Initialized
INFO - 2020-02-24 22:36:53 --> Config Class Initialized
INFO - 2020-02-24 22:36:53 --> Loader Class Initialized
INFO - 2020-02-24 22:36:53 --> Helper loaded: url_helper
INFO - 2020-02-24 22:36:53 --> Helper loaded: common_helper
INFO - 2020-02-24 22:36:53 --> Helper loaded: language_helper
INFO - 2020-02-24 22:36:53 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:36:53 --> Helper loaded: email_helper
INFO - 2020-02-24 22:36:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:36:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:36:53 --> Parser Class Initialized
INFO - 2020-02-24 22:36:53 --> User Agent Class Initialized
INFO - 2020-02-24 22:36:53 --> Model Class Initialized
INFO - 2020-02-24 22:36:53 --> Database Driver Class Initialized
INFO - 2020-02-24 22:36:53 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:53 --> Template Class Initialized
INFO - 2020-02-24 22:36:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:36:53 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:36:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:36:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:36:54 --> Encryption Class Initialized
INFO - 2020-02-24 22:36:54 --> Controller Class Initialized
DEBUG - 2020-02-24 22:36:54 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:36:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:36:54 --> Model Class Initialized
ERROR - 2020-02-24 22:36:54 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:36:54 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:36:54 --> Could not find the language line "Delele"
ERROR - 2020-02-24 22:36:54 --> Could not find the language line "View"
DEBUG - 2020-02-24 22:36:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:36:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 22:36:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:36:54 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:36:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:36:54 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:54 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:36:54 --> Model Class Initialized
DEBUG - 2020-02-24 22:36:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:36:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:36:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:36:54 --> Final output sent to browser
DEBUG - 2020-02-24 22:36:54 --> Total execution time: 1.4912
INFO - 2020-02-24 22:37:03 --> Config Class Initialized
INFO - 2020-02-24 22:37:03 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:37:03 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:37:04 --> Utf8 Class Initialized
INFO - 2020-02-24 22:37:04 --> URI Class Initialized
INFO - 2020-02-24 22:37:04 --> Router Class Initialized
INFO - 2020-02-24 22:37:04 --> Output Class Initialized
INFO - 2020-02-24 22:37:04 --> Security Class Initialized
DEBUG - 2020-02-24 22:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:37:04 --> CSRF cookie sent
INFO - 2020-02-24 22:37:04 --> CSRF token verified
INFO - 2020-02-24 22:37:04 --> Input Class Initialized
INFO - 2020-02-24 22:37:04 --> Language Class Initialized
INFO - 2020-02-24 22:37:04 --> Language Class Initialized
INFO - 2020-02-24 22:37:04 --> Config Class Initialized
INFO - 2020-02-24 22:37:04 --> Loader Class Initialized
INFO - 2020-02-24 22:37:04 --> Helper loaded: url_helper
INFO - 2020-02-24 22:37:04 --> Helper loaded: common_helper
INFO - 2020-02-24 22:37:04 --> Helper loaded: language_helper
INFO - 2020-02-24 22:37:04 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:37:04 --> Helper loaded: email_helper
INFO - 2020-02-24 22:37:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:37:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:37:04 --> Parser Class Initialized
INFO - 2020-02-24 22:37:04 --> User Agent Class Initialized
INFO - 2020-02-24 22:37:04 --> Model Class Initialized
INFO - 2020-02-24 22:37:04 --> Database Driver Class Initialized
INFO - 2020-02-24 22:37:04 --> Model Class Initialized
DEBUG - 2020-02-24 22:37:04 --> Template Class Initialized
INFO - 2020-02-24 22:37:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:37:04 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:37:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:37:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:37:04 --> Encryption Class Initialized
INFO - 2020-02-24 22:37:04 --> Controller Class Initialized
DEBUG - 2020-02-24 22:37:04 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:37:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:37:04 --> Model Class Initialized
ERROR - 2020-02-24 22:37:04 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 22:37:04 --> Could not find the language line "View"
ERROR - 2020-02-24 22:37:04 --> Could not find the language line "View"
ERROR - 2020-02-24 22:37:04 --> Could not find the language line "View"
ERROR - 2020-02-24 22:37:04 --> Could not find the language line "View"
ERROR - 2020-02-24 22:37:04 --> Could not find the language line "View"
ERROR - 2020-02-24 22:37:04 --> Could not find the language line "View"
DEBUG - 2020-02-24 22:37:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/search.php
INFO - 2020-02-24 22:37:04 --> Final output sent to browser
DEBUG - 2020-02-24 22:37:04 --> Total execution time: 0.8900
INFO - 2020-02-24 22:38:22 --> Config Class Initialized
INFO - 2020-02-24 22:38:22 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:38:22 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:38:22 --> Utf8 Class Initialized
INFO - 2020-02-24 22:38:22 --> URI Class Initialized
INFO - 2020-02-24 22:38:22 --> Router Class Initialized
INFO - 2020-02-24 22:38:22 --> Output Class Initialized
INFO - 2020-02-24 22:38:22 --> Security Class Initialized
DEBUG - 2020-02-24 22:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:38:22 --> CSRF cookie sent
INFO - 2020-02-24 22:38:22 --> Input Class Initialized
INFO - 2020-02-24 22:38:22 --> Language Class Initialized
INFO - 2020-02-24 22:38:22 --> Language Class Initialized
INFO - 2020-02-24 22:38:22 --> Config Class Initialized
INFO - 2020-02-24 22:38:22 --> Loader Class Initialized
INFO - 2020-02-24 22:38:22 --> Helper loaded: url_helper
INFO - 2020-02-24 22:38:22 --> Helper loaded: common_helper
INFO - 2020-02-24 22:38:22 --> Helper loaded: language_helper
INFO - 2020-02-24 22:38:22 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:38:22 --> Helper loaded: email_helper
INFO - 2020-02-24 22:38:22 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:38:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:38:22 --> Parser Class Initialized
INFO - 2020-02-24 22:38:22 --> User Agent Class Initialized
INFO - 2020-02-24 22:38:22 --> Model Class Initialized
INFO - 2020-02-24 22:38:22 --> Database Driver Class Initialized
INFO - 2020-02-24 22:38:22 --> Model Class Initialized
DEBUG - 2020-02-24 22:38:22 --> Template Class Initialized
INFO - 2020-02-24 22:38:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:38:22 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:38:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:38:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:38:22 --> Encryption Class Initialized
INFO - 2020-02-24 22:38:22 --> Controller Class Initialized
DEBUG - 2020-02-24 22:38:22 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:38:22 --> Model Class Initialized
ERROR - 2020-02-24 22:38:22 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:38:22 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:38:23 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\index.php 29
INFO - 2020-02-24 22:38:47 --> Config Class Initialized
INFO - 2020-02-24 22:38:47 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:38:48 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:38:48 --> Utf8 Class Initialized
INFO - 2020-02-24 22:38:48 --> URI Class Initialized
INFO - 2020-02-24 22:38:48 --> Router Class Initialized
INFO - 2020-02-24 22:38:48 --> Output Class Initialized
INFO - 2020-02-24 22:38:48 --> Security Class Initialized
DEBUG - 2020-02-24 22:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:38:48 --> CSRF cookie sent
INFO - 2020-02-24 22:38:48 --> Input Class Initialized
INFO - 2020-02-24 22:38:48 --> Language Class Initialized
INFO - 2020-02-24 22:38:48 --> Language Class Initialized
INFO - 2020-02-24 22:38:48 --> Config Class Initialized
INFO - 2020-02-24 22:38:48 --> Loader Class Initialized
INFO - 2020-02-24 22:38:48 --> Helper loaded: url_helper
INFO - 2020-02-24 22:38:48 --> Helper loaded: common_helper
INFO - 2020-02-24 22:38:48 --> Helper loaded: language_helper
INFO - 2020-02-24 22:38:48 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:38:48 --> Helper loaded: email_helper
INFO - 2020-02-24 22:38:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:38:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:38:48 --> Parser Class Initialized
INFO - 2020-02-24 22:38:48 --> User Agent Class Initialized
INFO - 2020-02-24 22:38:48 --> Model Class Initialized
INFO - 2020-02-24 22:38:48 --> Database Driver Class Initialized
INFO - 2020-02-24 22:38:48 --> Model Class Initialized
DEBUG - 2020-02-24 22:38:48 --> Template Class Initialized
INFO - 2020-02-24 22:38:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:38:48 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:38:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:38:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:38:48 --> Encryption Class Initialized
INFO - 2020-02-24 22:38:48 --> Controller Class Initialized
DEBUG - 2020-02-24 22:38:48 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:38:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:38:48 --> Model Class Initialized
ERROR - 2020-02-24 22:38:48 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:38:48 --> Helper loaded: inflector_helper
INFO - 2020-02-24 22:39:04 --> Config Class Initialized
INFO - 2020-02-24 22:39:04 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:39:04 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:39:04 --> Utf8 Class Initialized
INFO - 2020-02-24 22:39:04 --> URI Class Initialized
INFO - 2020-02-24 22:39:04 --> Router Class Initialized
INFO - 2020-02-24 22:39:04 --> Output Class Initialized
INFO - 2020-02-24 22:39:04 --> Security Class Initialized
DEBUG - 2020-02-24 22:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:39:04 --> CSRF cookie sent
INFO - 2020-02-24 22:39:04 --> Input Class Initialized
INFO - 2020-02-24 22:39:04 --> Language Class Initialized
INFO - 2020-02-24 22:39:04 --> Language Class Initialized
INFO - 2020-02-24 22:39:04 --> Config Class Initialized
INFO - 2020-02-24 22:39:04 --> Loader Class Initialized
INFO - 2020-02-24 22:39:04 --> Helper loaded: url_helper
INFO - 2020-02-24 22:39:04 --> Helper loaded: common_helper
INFO - 2020-02-24 22:39:04 --> Helper loaded: language_helper
INFO - 2020-02-24 22:39:04 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:39:04 --> Helper loaded: email_helper
INFO - 2020-02-24 22:39:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:39:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:39:05 --> Parser Class Initialized
INFO - 2020-02-24 22:39:05 --> User Agent Class Initialized
INFO - 2020-02-24 22:39:05 --> Model Class Initialized
INFO - 2020-02-24 22:39:05 --> Database Driver Class Initialized
INFO - 2020-02-24 22:39:05 --> Model Class Initialized
DEBUG - 2020-02-24 22:39:05 --> Template Class Initialized
INFO - 2020-02-24 22:39:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:39:05 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:39:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:39:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:39:05 --> Encryption Class Initialized
INFO - 2020-02-24 22:39:05 --> Controller Class Initialized
DEBUG - 2020-02-24 22:39:05 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:39:05 --> Model Class Initialized
ERROR - 2020-02-24 22:39:05 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:39:05 --> Helper loaded: inflector_helper
INFO - 2020-02-24 22:39:53 --> Config Class Initialized
INFO - 2020-02-24 22:39:53 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:39:53 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:39:53 --> Utf8 Class Initialized
INFO - 2020-02-24 22:39:53 --> URI Class Initialized
INFO - 2020-02-24 22:39:53 --> Router Class Initialized
INFO - 2020-02-24 22:39:53 --> Output Class Initialized
INFO - 2020-02-24 22:39:53 --> Security Class Initialized
DEBUG - 2020-02-24 22:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:39:53 --> CSRF cookie sent
INFO - 2020-02-24 22:39:53 --> Input Class Initialized
INFO - 2020-02-24 22:39:53 --> Language Class Initialized
INFO - 2020-02-24 22:39:53 --> Language Class Initialized
INFO - 2020-02-24 22:39:53 --> Config Class Initialized
INFO - 2020-02-24 22:39:53 --> Loader Class Initialized
INFO - 2020-02-24 22:39:53 --> Helper loaded: url_helper
INFO - 2020-02-24 22:39:53 --> Helper loaded: common_helper
INFO - 2020-02-24 22:39:53 --> Helper loaded: language_helper
INFO - 2020-02-24 22:39:53 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:39:53 --> Helper loaded: email_helper
INFO - 2020-02-24 22:39:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:39:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:39:53 --> Parser Class Initialized
INFO - 2020-02-24 22:39:54 --> User Agent Class Initialized
INFO - 2020-02-24 22:39:54 --> Model Class Initialized
INFO - 2020-02-24 22:39:54 --> Database Driver Class Initialized
INFO - 2020-02-24 22:39:54 --> Model Class Initialized
DEBUG - 2020-02-24 22:39:54 --> Template Class Initialized
INFO - 2020-02-24 22:39:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:39:54 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:39:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:39:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:39:54 --> Encryption Class Initialized
INFO - 2020-02-24 22:39:54 --> Controller Class Initialized
DEBUG - 2020-02-24 22:39:54 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:39:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:39:54 --> Model Class Initialized
ERROR - 2020-02-24 22:39:54 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:39:54 --> Helper loaded: inflector_helper
INFO - 2020-02-24 22:40:16 --> Config Class Initialized
INFO - 2020-02-24 22:40:16 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:40:16 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:40:16 --> Utf8 Class Initialized
INFO - 2020-02-24 22:40:16 --> URI Class Initialized
INFO - 2020-02-24 22:40:16 --> Router Class Initialized
INFO - 2020-02-24 22:40:16 --> Output Class Initialized
INFO - 2020-02-24 22:40:16 --> Security Class Initialized
DEBUG - 2020-02-24 22:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:40:16 --> CSRF cookie sent
INFO - 2020-02-24 22:40:16 --> Input Class Initialized
INFO - 2020-02-24 22:40:16 --> Language Class Initialized
INFO - 2020-02-24 22:40:16 --> Language Class Initialized
INFO - 2020-02-24 22:40:16 --> Config Class Initialized
INFO - 2020-02-24 22:40:16 --> Loader Class Initialized
INFO - 2020-02-24 22:40:16 --> Helper loaded: url_helper
INFO - 2020-02-24 22:40:16 --> Helper loaded: common_helper
INFO - 2020-02-24 22:40:16 --> Helper loaded: language_helper
INFO - 2020-02-24 22:40:16 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:40:16 --> Helper loaded: email_helper
INFO - 2020-02-24 22:40:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:40:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:40:16 --> Parser Class Initialized
INFO - 2020-02-24 22:40:16 --> User Agent Class Initialized
INFO - 2020-02-24 22:40:16 --> Model Class Initialized
INFO - 2020-02-24 22:40:16 --> Database Driver Class Initialized
INFO - 2020-02-24 22:40:16 --> Model Class Initialized
DEBUG - 2020-02-24 22:40:16 --> Template Class Initialized
INFO - 2020-02-24 22:40:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:40:16 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:40:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:40:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:40:16 --> Encryption Class Initialized
INFO - 2020-02-24 22:40:16 --> Controller Class Initialized
DEBUG - 2020-02-24 22:40:16 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:40:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:40:17 --> Model Class Initialized
ERROR - 2020-02-24 22:40:17 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:40:17 --> Helper loaded: inflector_helper
INFO - 2020-02-24 22:40:47 --> Config Class Initialized
INFO - 2020-02-24 22:40:47 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:40:47 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:40:47 --> Utf8 Class Initialized
INFO - 2020-02-24 22:40:48 --> URI Class Initialized
INFO - 2020-02-24 22:40:48 --> Router Class Initialized
INFO - 2020-02-24 22:40:48 --> Output Class Initialized
INFO - 2020-02-24 22:40:48 --> Security Class Initialized
DEBUG - 2020-02-24 22:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:40:48 --> CSRF cookie sent
INFO - 2020-02-24 22:40:48 --> Input Class Initialized
INFO - 2020-02-24 22:40:48 --> Language Class Initialized
INFO - 2020-02-24 22:40:48 --> Language Class Initialized
INFO - 2020-02-24 22:40:48 --> Config Class Initialized
INFO - 2020-02-24 22:40:48 --> Loader Class Initialized
INFO - 2020-02-24 22:40:48 --> Helper loaded: url_helper
INFO - 2020-02-24 22:40:48 --> Helper loaded: common_helper
INFO - 2020-02-24 22:40:48 --> Helper loaded: language_helper
INFO - 2020-02-24 22:40:48 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:40:48 --> Helper loaded: email_helper
INFO - 2020-02-24 22:40:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:40:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:40:48 --> Parser Class Initialized
INFO - 2020-02-24 22:40:48 --> User Agent Class Initialized
INFO - 2020-02-24 22:40:48 --> Model Class Initialized
INFO - 2020-02-24 22:40:48 --> Database Driver Class Initialized
INFO - 2020-02-24 22:40:48 --> Model Class Initialized
DEBUG - 2020-02-24 22:40:48 --> Template Class Initialized
INFO - 2020-02-24 22:40:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:40:48 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:40:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:40:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:40:48 --> Encryption Class Initialized
INFO - 2020-02-24 22:40:48 --> Controller Class Initialized
DEBUG - 2020-02-24 22:40:48 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:40:48 --> Model Class Initialized
ERROR - 2020-02-24 22:40:48 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:40:48 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:40:48 --> Could not find the language line "Delele"
ERROR - 2020-02-24 22:40:48 --> Could not find the language line "View"
DEBUG - 2020-02-24 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:40:48 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:40:48 --> Model Class Initialized
DEBUG - 2020-02-24 22:40:48 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:40:48 --> Model Class Initialized
DEBUG - 2020-02-24 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:40:49 --> Final output sent to browser
DEBUG - 2020-02-24 22:40:49 --> Total execution time: 1.1148
INFO - 2020-02-24 22:40:55 --> Config Class Initialized
INFO - 2020-02-24 22:40:55 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:40:55 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:40:55 --> Utf8 Class Initialized
INFO - 2020-02-24 22:40:55 --> URI Class Initialized
INFO - 2020-02-24 22:40:55 --> Router Class Initialized
INFO - 2020-02-24 22:40:55 --> Output Class Initialized
INFO - 2020-02-24 22:40:55 --> Security Class Initialized
DEBUG - 2020-02-24 22:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:40:55 --> CSRF cookie sent
INFO - 2020-02-24 22:40:55 --> CSRF token verified
INFO - 2020-02-24 22:40:55 --> Input Class Initialized
INFO - 2020-02-24 22:40:55 --> Language Class Initialized
INFO - 2020-02-24 22:40:55 --> Language Class Initialized
INFO - 2020-02-24 22:40:55 --> Config Class Initialized
INFO - 2020-02-24 22:40:55 --> Loader Class Initialized
INFO - 2020-02-24 22:40:55 --> Helper loaded: url_helper
INFO - 2020-02-24 22:40:55 --> Helper loaded: common_helper
INFO - 2020-02-24 22:40:55 --> Helper loaded: language_helper
INFO - 2020-02-24 22:40:55 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:40:55 --> Helper loaded: email_helper
INFO - 2020-02-24 22:40:55 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:40:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:40:55 --> Parser Class Initialized
INFO - 2020-02-24 22:40:55 --> User Agent Class Initialized
INFO - 2020-02-24 22:40:55 --> Model Class Initialized
INFO - 2020-02-24 22:40:55 --> Database Driver Class Initialized
INFO - 2020-02-24 22:40:55 --> Model Class Initialized
DEBUG - 2020-02-24 22:40:56 --> Template Class Initialized
INFO - 2020-02-24 22:40:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:40:56 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:40:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:40:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:40:56 --> Encryption Class Initialized
INFO - 2020-02-24 22:40:56 --> Controller Class Initialized
DEBUG - 2020-02-24 22:40:56 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:40:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:40:56 --> Model Class Initialized
ERROR - 2020-02-24 22:40:56 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 22:40:56 --> Could not find the language line "View"
ERROR - 2020-02-24 22:40:56 --> Could not find the language line "View"
ERROR - 2020-02-24 22:40:56 --> Could not find the language line "View"
ERROR - 2020-02-24 22:40:56 --> Could not find the language line "View"
ERROR - 2020-02-24 22:40:56 --> Could not find the language line "View"
ERROR - 2020-02-24 22:40:56 --> Could not find the language line "View"
DEBUG - 2020-02-24 22:40:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/search.php
INFO - 2020-02-24 22:40:56 --> Final output sent to browser
DEBUG - 2020-02-24 22:40:56 --> Total execution time: 0.9861
INFO - 2020-02-24 22:42:07 --> Config Class Initialized
INFO - 2020-02-24 22:42:07 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:42:07 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:42:07 --> Utf8 Class Initialized
INFO - 2020-02-24 22:42:07 --> URI Class Initialized
INFO - 2020-02-24 22:42:07 --> Router Class Initialized
INFO - 2020-02-24 22:42:07 --> Output Class Initialized
INFO - 2020-02-24 22:42:07 --> Security Class Initialized
DEBUG - 2020-02-24 22:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:42:07 --> CSRF cookie sent
INFO - 2020-02-24 22:42:07 --> Input Class Initialized
INFO - 2020-02-24 22:42:07 --> Language Class Initialized
INFO - 2020-02-24 22:42:07 --> Language Class Initialized
INFO - 2020-02-24 22:42:07 --> Config Class Initialized
INFO - 2020-02-24 22:42:07 --> Loader Class Initialized
INFO - 2020-02-24 22:42:07 --> Helper loaded: url_helper
INFO - 2020-02-24 22:42:07 --> Helper loaded: common_helper
INFO - 2020-02-24 22:42:07 --> Helper loaded: language_helper
INFO - 2020-02-24 22:42:07 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:42:07 --> Helper loaded: email_helper
INFO - 2020-02-24 22:42:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:42:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:42:08 --> Parser Class Initialized
INFO - 2020-02-24 22:42:08 --> User Agent Class Initialized
INFO - 2020-02-24 22:42:08 --> Model Class Initialized
INFO - 2020-02-24 22:42:08 --> Database Driver Class Initialized
INFO - 2020-02-24 22:42:08 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:08 --> Template Class Initialized
INFO - 2020-02-24 22:42:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:42:08 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:42:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:42:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:42:08 --> Encryption Class Initialized
INFO - 2020-02-24 22:42:08 --> Controller Class Initialized
DEBUG - 2020-02-24 22:42:08 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:42:08 --> Model Class Initialized
ERROR - 2020-02-24 22:42:08 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:42:08 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:42:08 --> Could not find the language line "Delele"
ERROR - 2020-02-24 22:42:08 --> Could not find the language line "View"
DEBUG - 2020-02-24 22:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 22:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:42:08 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:42:08 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:08 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:42:08 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:42:08 --> Final output sent to browser
DEBUG - 2020-02-24 22:42:08 --> Total execution time: 1.1096
INFO - 2020-02-24 22:42:10 --> Config Class Initialized
INFO - 2020-02-24 22:42:10 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:42:10 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:42:10 --> Utf8 Class Initialized
INFO - 2020-02-24 22:42:10 --> URI Class Initialized
INFO - 2020-02-24 22:42:10 --> Router Class Initialized
INFO - 2020-02-24 22:42:10 --> Output Class Initialized
INFO - 2020-02-24 22:42:10 --> Security Class Initialized
DEBUG - 2020-02-24 22:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:42:10 --> CSRF cookie sent
INFO - 2020-02-24 22:42:10 --> CSRF token verified
INFO - 2020-02-24 22:42:10 --> Input Class Initialized
INFO - 2020-02-24 22:42:10 --> Language Class Initialized
INFO - 2020-02-24 22:42:10 --> Language Class Initialized
INFO - 2020-02-24 22:42:10 --> Config Class Initialized
INFO - 2020-02-24 22:42:10 --> Loader Class Initialized
INFO - 2020-02-24 22:42:10 --> Helper loaded: url_helper
INFO - 2020-02-24 22:42:10 --> Helper loaded: common_helper
INFO - 2020-02-24 22:42:10 --> Helper loaded: language_helper
INFO - 2020-02-24 22:42:10 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:42:10 --> Helper loaded: email_helper
INFO - 2020-02-24 22:42:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:42:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:42:10 --> Parser Class Initialized
INFO - 2020-02-24 22:42:10 --> User Agent Class Initialized
INFO - 2020-02-24 22:42:10 --> Model Class Initialized
INFO - 2020-02-24 22:42:10 --> Database Driver Class Initialized
INFO - 2020-02-24 22:42:10 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:10 --> Template Class Initialized
INFO - 2020-02-24 22:42:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:42:10 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:42:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:42:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:42:11 --> Encryption Class Initialized
INFO - 2020-02-24 22:42:11 --> Controller Class Initialized
DEBUG - 2020-02-24 22:42:11 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:42:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:42:11 --> Model Class Initialized
ERROR - 2020-02-24 22:42:11 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 22:42:11 --> Could not find the language line "View"
ERROR - 2020-02-24 22:42:11 --> Could not find the language line "View"
ERROR - 2020-02-24 22:42:11 --> Could not find the language line "View"
ERROR - 2020-02-24 22:42:11 --> Could not find the language line "View"
ERROR - 2020-02-24 22:42:11 --> Could not find the language line "View"
ERROR - 2020-02-24 22:42:11 --> Could not find the language line "View"
DEBUG - 2020-02-24 22:42:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/search.php
INFO - 2020-02-24 22:42:11 --> Final output sent to browser
DEBUG - 2020-02-24 22:42:11 --> Total execution time: 0.9424
INFO - 2020-02-24 22:42:26 --> Config Class Initialized
INFO - 2020-02-24 22:42:26 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:42:26 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:42:26 --> Utf8 Class Initialized
INFO - 2020-02-24 22:42:26 --> URI Class Initialized
INFO - 2020-02-24 22:42:26 --> Router Class Initialized
INFO - 2020-02-24 22:42:26 --> Output Class Initialized
INFO - 2020-02-24 22:42:26 --> Security Class Initialized
DEBUG - 2020-02-24 22:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:42:26 --> CSRF cookie sent
INFO - 2020-02-24 22:42:26 --> CSRF token verified
INFO - 2020-02-24 22:42:26 --> Input Class Initialized
INFO - 2020-02-24 22:42:26 --> Language Class Initialized
INFO - 2020-02-24 22:42:26 --> Language Class Initialized
INFO - 2020-02-24 22:42:26 --> Config Class Initialized
INFO - 2020-02-24 22:42:26 --> Loader Class Initialized
INFO - 2020-02-24 22:42:26 --> Helper loaded: url_helper
INFO - 2020-02-24 22:42:26 --> Helper loaded: common_helper
INFO - 2020-02-24 22:42:26 --> Helper loaded: language_helper
INFO - 2020-02-24 22:42:26 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:42:27 --> Helper loaded: email_helper
INFO - 2020-02-24 22:42:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:42:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:42:27 --> Parser Class Initialized
INFO - 2020-02-24 22:42:27 --> User Agent Class Initialized
INFO - 2020-02-24 22:42:27 --> Model Class Initialized
INFO - 2020-02-24 22:42:27 --> Database Driver Class Initialized
INFO - 2020-02-24 22:42:27 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:27 --> Template Class Initialized
INFO - 2020-02-24 22:42:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:42:27 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:42:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:42:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:42:27 --> Encryption Class Initialized
INFO - 2020-02-24 22:42:27 --> Controller Class Initialized
DEBUG - 2020-02-24 22:42:27 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:42:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:42:27 --> Model Class Initialized
ERROR - 2020-02-24 22:42:27 --> Could not find the language line "Sorting"
DEBUG - 2020-02-24 22:42:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:42:27 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:42:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:42:27 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:27 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:42:27 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/empty_data.php
DEBUG - 2020-02-24 22:42:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/search.php
INFO - 2020-02-24 22:42:27 --> Final output sent to browser
DEBUG - 2020-02-24 22:42:27 --> Total execution time: 0.8935
INFO - 2020-02-24 22:42:29 --> Config Class Initialized
INFO - 2020-02-24 22:42:29 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:42:29 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:42:29 --> Utf8 Class Initialized
INFO - 2020-02-24 22:42:29 --> URI Class Initialized
INFO - 2020-02-24 22:42:29 --> Router Class Initialized
INFO - 2020-02-24 22:42:29 --> Output Class Initialized
INFO - 2020-02-24 22:42:29 --> Security Class Initialized
DEBUG - 2020-02-24 22:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:42:29 --> CSRF cookie sent
INFO - 2020-02-24 22:42:29 --> CSRF token verified
INFO - 2020-02-24 22:42:29 --> Input Class Initialized
INFO - 2020-02-24 22:42:29 --> Language Class Initialized
INFO - 2020-02-24 22:42:29 --> Language Class Initialized
INFO - 2020-02-24 22:42:29 --> Config Class Initialized
INFO - 2020-02-24 22:42:29 --> Loader Class Initialized
INFO - 2020-02-24 22:42:29 --> Helper loaded: url_helper
INFO - 2020-02-24 22:42:29 --> Helper loaded: common_helper
INFO - 2020-02-24 22:42:29 --> Helper loaded: language_helper
INFO - 2020-02-24 22:42:29 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:42:29 --> Helper loaded: email_helper
INFO - 2020-02-24 22:42:29 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:42:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:42:29 --> Parser Class Initialized
INFO - 2020-02-24 22:42:29 --> User Agent Class Initialized
INFO - 2020-02-24 22:42:29 --> Model Class Initialized
INFO - 2020-02-24 22:42:29 --> Database Driver Class Initialized
INFO - 2020-02-24 22:42:29 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:29 --> Template Class Initialized
INFO - 2020-02-24 22:42:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:42:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:42:29 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:42:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:42:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:42:29 --> Encryption Class Initialized
INFO - 2020-02-24 22:42:29 --> Controller Class Initialized
DEBUG - 2020-02-24 22:42:30 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:42:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:42:30 --> Model Class Initialized
ERROR - 2020-02-24 22:42:30 --> Could not find the language line "Sorting"
ERROR - 2020-02-24 22:42:30 --> Could not find the language line "View"
DEBUG - 2020-02-24 22:42:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/search.php
INFO - 2020-02-24 22:42:30 --> Final output sent to browser
DEBUG - 2020-02-24 22:42:30 --> Total execution time: 0.7891
INFO - 2020-02-24 22:42:32 --> Config Class Initialized
INFO - 2020-02-24 22:42:32 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:42:32 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:42:32 --> Utf8 Class Initialized
INFO - 2020-02-24 22:42:32 --> URI Class Initialized
INFO - 2020-02-24 22:42:32 --> Router Class Initialized
INFO - 2020-02-24 22:42:32 --> Output Class Initialized
INFO - 2020-02-24 22:42:32 --> Security Class Initialized
DEBUG - 2020-02-24 22:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:42:32 --> CSRF cookie sent
INFO - 2020-02-24 22:42:32 --> Input Class Initialized
INFO - 2020-02-24 22:42:32 --> Language Class Initialized
INFO - 2020-02-24 22:42:32 --> Language Class Initialized
INFO - 2020-02-24 22:42:32 --> Config Class Initialized
INFO - 2020-02-24 22:42:32 --> Loader Class Initialized
INFO - 2020-02-24 22:42:32 --> Helper loaded: url_helper
INFO - 2020-02-24 22:42:32 --> Helper loaded: common_helper
INFO - 2020-02-24 22:42:32 --> Helper loaded: language_helper
INFO - 2020-02-24 22:42:32 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:42:32 --> Helper loaded: email_helper
INFO - 2020-02-24 22:42:32 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:42:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:42:33 --> Parser Class Initialized
INFO - 2020-02-24 22:42:33 --> User Agent Class Initialized
INFO - 2020-02-24 22:42:33 --> Model Class Initialized
INFO - 2020-02-24 22:42:33 --> Database Driver Class Initialized
INFO - 2020-02-24 22:42:33 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:33 --> Template Class Initialized
INFO - 2020-02-24 22:42:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:42:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:42:33 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:42:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:42:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:42:33 --> Encryption Class Initialized
INFO - 2020-02-24 22:42:33 --> Controller Class Initialized
DEBUG - 2020-02-24 22:42:33 --> category MX_Controller Initialized
DEBUG - 2020-02-24 22:42:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:42:33 --> Model Class Initialized
ERROR - 2020-02-24 22:42:33 --> Could not find the language line "Sorting"
INFO - 2020-02-24 22:42:33 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:42:33 --> Could not find the language line "Delele"
ERROR - 2020-02-24 22:42:33 --> Could not find the language line "View"
DEBUG - 2020-02-24 22:42:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:42:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-24 22:42:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:42:33 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:42:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:42:33 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:33 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:42:33 --> Model Class Initialized
DEBUG - 2020-02-24 22:42:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:42:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:42:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:42:33 --> Final output sent to browser
DEBUG - 2020-02-24 22:42:33 --> Total execution time: 1.1486
INFO - 2020-02-24 22:43:55 --> Config Class Initialized
INFO - 2020-02-24 22:43:56 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:43:56 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:43:56 --> Utf8 Class Initialized
INFO - 2020-02-24 22:43:56 --> URI Class Initialized
INFO - 2020-02-24 22:43:56 --> Router Class Initialized
INFO - 2020-02-24 22:43:56 --> Output Class Initialized
INFO - 2020-02-24 22:43:56 --> Security Class Initialized
DEBUG - 2020-02-24 22:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:43:56 --> CSRF cookie sent
INFO - 2020-02-24 22:43:56 --> Input Class Initialized
INFO - 2020-02-24 22:43:56 --> Language Class Initialized
INFO - 2020-02-24 22:43:56 --> Language Class Initialized
INFO - 2020-02-24 22:43:56 --> Config Class Initialized
INFO - 2020-02-24 22:43:56 --> Loader Class Initialized
INFO - 2020-02-24 22:43:56 --> Helper loaded: url_helper
INFO - 2020-02-24 22:43:56 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:56 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:56 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:56 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:43:56 --> Parser Class Initialized
INFO - 2020-02-24 22:43:56 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:56 --> Model Class Initialized
INFO - 2020-02-24 22:43:56 --> Database Driver Class Initialized
INFO - 2020-02-24 22:43:56 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:56 --> Template Class Initialized
INFO - 2020-02-24 22:43:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:43:56 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:43:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:43:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:43:56 --> Encryption Class Initialized
INFO - 2020-02-24 22:43:56 --> Controller Class Initialized
DEBUG - 2020-02-24 22:43:56 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:43:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:43:56 --> Model Class Initialized
INFO - 2020-02-24 22:43:56 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:43:56 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 22:43:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2020-02-24 22:43:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:43:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:43:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:43:56 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:43:56 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:43:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:43:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:43:57 --> Final output sent to browser
DEBUG - 2020-02-24 22:43:57 --> Total execution time: 1.0753
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:57 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:57 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:57 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:57 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:57 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-02-24 22:43:57 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:43:57 --> Utf8 Class Initialized
INFO - 2020-02-24 22:43:57 --> Utf8 Class Initialized
INFO - 2020-02-24 22:43:57 --> Utf8 Class Initialized
INFO - 2020-02-24 22:43:57 --> Utf8 Class Initialized
INFO - 2020-02-24 22:43:57 --> Utf8 Class Initialized
INFO - 2020-02-24 22:43:57 --> Utf8 Class Initialized
INFO - 2020-02-24 22:43:57 --> URI Class Initialized
INFO - 2020-02-24 22:43:57 --> URI Class Initialized
INFO - 2020-02-24 22:43:57 --> URI Class Initialized
INFO - 2020-02-24 22:43:57 --> URI Class Initialized
INFO - 2020-02-24 22:43:57 --> URI Class Initialized
INFO - 2020-02-24 22:43:57 --> URI Class Initialized
INFO - 2020-02-24 22:43:57 --> Router Class Initialized
INFO - 2020-02-24 22:43:57 --> Router Class Initialized
INFO - 2020-02-24 22:43:57 --> Router Class Initialized
INFO - 2020-02-24 22:43:57 --> Router Class Initialized
INFO - 2020-02-24 22:43:57 --> Router Class Initialized
INFO - 2020-02-24 22:43:57 --> Router Class Initialized
INFO - 2020-02-24 22:43:57 --> Output Class Initialized
INFO - 2020-02-24 22:43:57 --> Output Class Initialized
INFO - 2020-02-24 22:43:57 --> Output Class Initialized
INFO - 2020-02-24 22:43:57 --> Output Class Initialized
INFO - 2020-02-24 22:43:57 --> Output Class Initialized
INFO - 2020-02-24 22:43:57 --> Output Class Initialized
INFO - 2020-02-24 22:43:57 --> Security Class Initialized
INFO - 2020-02-24 22:43:57 --> Security Class Initialized
INFO - 2020-02-24 22:43:57 --> Security Class Initialized
INFO - 2020-02-24 22:43:57 --> Security Class Initialized
INFO - 2020-02-24 22:43:57 --> Security Class Initialized
INFO - 2020-02-24 22:43:57 --> Security Class Initialized
DEBUG - 2020-02-24 22:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:43:57 --> CSRF cookie sent
INFO - 2020-02-24 22:43:57 --> CSRF cookie sent
INFO - 2020-02-24 22:43:57 --> CSRF cookie sent
INFO - 2020-02-24 22:43:57 --> CSRF cookie sent
INFO - 2020-02-24 22:43:57 --> CSRF cookie sent
INFO - 2020-02-24 22:43:57 --> CSRF cookie sent
INFO - 2020-02-24 22:43:57 --> CSRF token verified
INFO - 2020-02-24 22:43:57 --> CSRF token verified
INFO - 2020-02-24 22:43:57 --> CSRF token verified
INFO - 2020-02-24 22:43:57 --> CSRF token verified
INFO - 2020-02-24 22:43:57 --> CSRF token verified
INFO - 2020-02-24 22:43:57 --> CSRF token verified
INFO - 2020-02-24 22:43:57 --> Input Class Initialized
INFO - 2020-02-24 22:43:57 --> Input Class Initialized
INFO - 2020-02-24 22:43:57 --> Input Class Initialized
INFO - 2020-02-24 22:43:57 --> Input Class Initialized
INFO - 2020-02-24 22:43:57 --> Input Class Initialized
INFO - 2020-02-24 22:43:57 --> Input Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Language Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Config Class Initialized
INFO - 2020-02-24 22:43:57 --> Loader Class Initialized
INFO - 2020-02-24 22:43:57 --> Loader Class Initialized
INFO - 2020-02-24 22:43:57 --> Loader Class Initialized
INFO - 2020-02-24 22:43:57 --> Loader Class Initialized
INFO - 2020-02-24 22:43:57 --> Loader Class Initialized
INFO - 2020-02-24 22:43:57 --> Loader Class Initialized
INFO - 2020-02-24 22:43:57 --> Helper loaded: url_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: url_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: url_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: url_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: url_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: url_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:43:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:43:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:43:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:43:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:43:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:43:57 --> Parser Class Initialized
INFO - 2020-02-24 22:43:57 --> Parser Class Initialized
INFO - 2020-02-24 22:43:57 --> Parser Class Initialized
INFO - 2020-02-24 22:43:57 --> Parser Class Initialized
INFO - 2020-02-24 22:43:57 --> Parser Class Initialized
INFO - 2020-02-24 22:43:57 --> Parser Class Initialized
INFO - 2020-02-24 22:43:57 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:57 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:57 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:57 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:57 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:57 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Database Driver Class Initialized
INFO - 2020-02-24 22:43:57 --> Database Driver Class Initialized
INFO - 2020-02-24 22:43:57 --> Database Driver Class Initialized
INFO - 2020-02-24 22:43:57 --> Database Driver Class Initialized
INFO - 2020-02-24 22:43:57 --> Database Driver Class Initialized
INFO - 2020-02-24 22:43:57 --> Database Driver Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
INFO - 2020-02-24 22:43:57 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:57 --> Template Class Initialized
DEBUG - 2020-02-24 22:43:57 --> Template Class Initialized
DEBUG - 2020-02-24 22:43:57 --> Template Class Initialized
DEBUG - 2020-02-24 22:43:57 --> Template Class Initialized
DEBUG - 2020-02-24 22:43:57 --> Template Class Initialized
DEBUG - 2020-02-24 22:43:57 --> Template Class Initialized
INFO - 2020-02-24 22:43:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:43:58 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:43:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:43:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:43:58 --> Encryption Class Initialized
INFO - 2020-02-24 22:43:58 --> Controller Class Initialized
DEBUG - 2020-02-24 22:43:58 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:43:58 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:43:58 --> Final output sent to browser
DEBUG - 2020-02-24 22:43:58 --> Total execution time: 0.8954
INFO - 2020-02-24 22:43:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:43:58 --> Config Class Initialized
INFO - 2020-02-24 22:43:58 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:43:58 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:43:58 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:43:58 --> Utf8 Class Initialized
DEBUG - 2020-02-24 22:43:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:43:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:43:58 --> URI Class Initialized
INFO - 2020-02-24 22:43:58 --> Encryption Class Initialized
INFO - 2020-02-24 22:43:58 --> Router Class Initialized
INFO - 2020-02-24 22:43:58 --> Controller Class Initialized
INFO - 2020-02-24 22:43:58 --> Output Class Initialized
DEBUG - 2020-02-24 22:43:58 --> services MX_Controller Initialized
INFO - 2020-02-24 22:43:58 --> Security Class Initialized
DEBUG - 2020-02-24 22:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:43:58 --> Model Class Initialized
INFO - 2020-02-24 22:43:58 --> CSRF cookie sent
INFO - 2020-02-24 22:43:58 --> CSRF token verified
INFO - 2020-02-24 22:43:58 --> Input Class Initialized
DEBUG - 2020-02-24 22:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:43:58 --> Final output sent to browser
INFO - 2020-02-24 22:43:58 --> Language Class Initialized
DEBUG - 2020-02-24 22:43:58 --> Total execution time: 1.1627
INFO - 2020-02-24 22:43:58 --> Language Class Initialized
INFO - 2020-02-24 22:43:58 --> Config Class Initialized
INFO - 2020-02-24 22:43:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:43:58 --> Config Class Initialized
INFO - 2020-02-24 22:43:58 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:43:58 --> Loader Class Initialized
INFO - 2020-02-24 22:43:58 --> Pagination Class Initialized
INFO - 2020-02-24 22:43:58 --> Helper loaded: url_helper
DEBUG - 2020-02-24 22:43:58 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:43:58 --> Utf8 Class Initialized
DEBUG - 2020-02-24 22:43:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:43:58 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:43:58 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:58 --> URI Class Initialized
INFO - 2020-02-24 22:43:58 --> Encryption Class Initialized
INFO - 2020-02-24 22:43:58 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:58 --> Router Class Initialized
INFO - 2020-02-24 22:43:58 --> Controller Class Initialized
INFO - 2020-02-24 22:43:58 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:58 --> Output Class Initialized
DEBUG - 2020-02-24 22:43:58 --> services MX_Controller Initialized
INFO - 2020-02-24 22:43:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:58 --> Security Class Initialized
INFO - 2020-02-24 22:43:58 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 22:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
DEBUG - 2020-02-24 22:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:43:58 --> Model Class Initialized
INFO - 2020-02-24 22:43:58 --> CSRF cookie sent
INFO - 2020-02-24 22:43:58 --> Parser Class Initialized
INFO - 2020-02-24 22:43:58 --> CSRF token verified
INFO - 2020-02-24 22:43:58 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:58 --> Input Class Initialized
INFO - 2020-02-24 22:43:58 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:43:58 --> Final output sent to browser
INFO - 2020-02-24 22:43:58 --> Language Class Initialized
INFO - 2020-02-24 22:43:58 --> Database Driver Class Initialized
DEBUG - 2020-02-24 22:43:58 --> Total execution time: 1.4513
INFO - 2020-02-24 22:43:58 --> Language Class Initialized
INFO - 2020-02-24 22:43:58 --> Model Class Initialized
INFO - 2020-02-24 22:43:58 --> Config Class Initialized
INFO - 2020-02-24 22:43:58 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-02-24 22:43:58 --> Template Class Initialized
INFO - 2020-02-24 22:43:58 --> Config Class Initialized
INFO - 2020-02-24 22:43:58 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:43:58 --> Loader Class Initialized
INFO - 2020-02-24 22:43:58 --> Pagination Class Initialized
INFO - 2020-02-24 22:43:58 --> Helper loaded: url_helper
DEBUG - 2020-02-24 22:43:58 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:43:58 --> Utf8 Class Initialized
DEBUG - 2020-02-24 22:43:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:43:58 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:43:58 --> URI Class Initialized
INFO - 2020-02-24 22:43:58 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:58 --> Encryption Class Initialized
INFO - 2020-02-24 22:43:58 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:58 --> Router Class Initialized
INFO - 2020-02-24 22:43:58 --> Controller Class Initialized
INFO - 2020-02-24 22:43:58 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:58 --> Output Class Initialized
DEBUG - 2020-02-24 22:43:58 --> services MX_Controller Initialized
INFO - 2020-02-24 22:43:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:58 --> Security Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:43:59 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 22:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
INFO - 2020-02-24 22:43:59 --> CSRF cookie sent
INFO - 2020-02-24 22:43:59 --> Parser Class Initialized
INFO - 2020-02-24 22:43:59 --> CSRF token verified
INFO - 2020-02-24 22:43:59 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:59 --> Input Class Initialized
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:43:59 --> Final output sent to browser
INFO - 2020-02-24 22:43:59 --> Language Class Initialized
INFO - 2020-02-24 22:43:59 --> Database Driver Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Total execution time: 1.7294
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
INFO - 2020-02-24 22:43:59 --> Language Class Initialized
INFO - 2020-02-24 22:43:59 --> Config Class Initialized
INFO - 2020-02-24 22:43:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-02-24 22:43:59 --> Template Class Initialized
INFO - 2020-02-24 22:43:59 --> Config Class Initialized
INFO - 2020-02-24 22:43:59 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:43:59 --> Loader Class Initialized
INFO - 2020-02-24 22:43:59 --> Pagination Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: url_helper
DEBUG - 2020-02-24 22:43:59 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:43:59 --> Utf8 Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:43:59 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:43:59 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:59 --> URI Class Initialized
INFO - 2020-02-24 22:43:59 --> Encryption Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:59 --> Router Class Initialized
INFO - 2020-02-24 22:43:59 --> Controller Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:59 --> Output Class Initialized
DEBUG - 2020-02-24 22:43:59 --> services MX_Controller Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:59 --> Security Class Initialized
INFO - 2020-02-24 22:43:59 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 22:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-24 22:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:43:59 --> CSRF cookie sent
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
INFO - 2020-02-24 22:43:59 --> Parser Class Initialized
INFO - 2020-02-24 22:43:59 --> CSRF token verified
INFO - 2020-02-24 22:43:59 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:59 --> Input Class Initialized
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:43:59 --> Final output sent to browser
INFO - 2020-02-24 22:43:59 --> Language Class Initialized
INFO - 2020-02-24 22:43:59 --> Database Driver Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Total execution time: 2.0271
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
INFO - 2020-02-24 22:43:59 --> Language Class Initialized
INFO - 2020-02-24 22:43:59 --> Config Class Initialized
INFO - 2020-02-24 22:43:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-02-24 22:43:59 --> Template Class Initialized
INFO - 2020-02-24 22:43:59 --> Config Class Initialized
INFO - 2020-02-24 22:43:59 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:43:59 --> Loader Class Initialized
INFO - 2020-02-24 22:43:59 --> Pagination Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: url_helper
DEBUG - 2020-02-24 22:43:59 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:43:59 --> Utf8 Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:43:59 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:43:59 --> URI Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:59 --> Encryption Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:59 --> Router Class Initialized
INFO - 2020-02-24 22:43:59 --> Controller Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:59 --> Output Class Initialized
DEBUG - 2020-02-24 22:43:59 --> services MX_Controller Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:59 --> Security Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:43:59 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 22:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
INFO - 2020-02-24 22:43:59 --> CSRF cookie sent
INFO - 2020-02-24 22:43:59 --> Parser Class Initialized
INFO - 2020-02-24 22:43:59 --> CSRF token verified
INFO - 2020-02-24 22:43:59 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:59 --> Input Class Initialized
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:43:59 --> Final output sent to browser
INFO - 2020-02-24 22:43:59 --> Language Class Initialized
INFO - 2020-02-24 22:43:59 --> Database Driver Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Total execution time: 2.3144
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
INFO - 2020-02-24 22:43:59 --> Language Class Initialized
INFO - 2020-02-24 22:43:59 --> Config Class Initialized
INFO - 2020-02-24 22:43:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-02-24 22:43:59 --> Template Class Initialized
INFO - 2020-02-24 22:43:59 --> Config Class Initialized
INFO - 2020-02-24 22:43:59 --> Hooks Class Initialized
INFO - 2020-02-24 22:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:43:59 --> Loader Class Initialized
INFO - 2020-02-24 22:43:59 --> Pagination Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: url_helper
DEBUG - 2020-02-24 22:43:59 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:43:59 --> Utf8 Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:43:59 --> Helper loaded: common_helper
INFO - 2020-02-24 22:43:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:43:59 --> URI Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: language_helper
INFO - 2020-02-24 22:43:59 --> Encryption Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:43:59 --> Router Class Initialized
INFO - 2020-02-24 22:43:59 --> Controller Class Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: email_helper
INFO - 2020-02-24 22:43:59 --> Output Class Initialized
DEBUG - 2020-02-24 22:43:59 --> services MX_Controller Initialized
INFO - 2020-02-24 22:43:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:43:59 --> Security Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:43:59 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 22:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:43:59 --> CSRF cookie sent
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
INFO - 2020-02-24 22:43:59 --> Parser Class Initialized
INFO - 2020-02-24 22:43:59 --> CSRF token verified
INFO - 2020-02-24 22:43:59 --> User Agent Class Initialized
INFO - 2020-02-24 22:43:59 --> Input Class Initialized
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
DEBUG - 2020-02-24 22:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:43:59 --> Final output sent to browser
INFO - 2020-02-24 22:43:59 --> Language Class Initialized
INFO - 2020-02-24 22:43:59 --> Database Driver Class Initialized
DEBUG - 2020-02-24 22:43:59 --> Total execution time: 1.6639
INFO - 2020-02-24 22:43:59 --> Language Class Initialized
INFO - 2020-02-24 22:43:59 --> Model Class Initialized
INFO - 2020-02-24 22:43:59 --> Config Class Initialized
INFO - 2020-02-24 22:43:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-02-24 22:43:59 --> Template Class Initialized
INFO - 2020-02-24 22:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:44:00 --> Loader Class Initialized
INFO - 2020-02-24 22:44:00 --> Pagination Class Initialized
INFO - 2020-02-24 22:44:00 --> Helper loaded: url_helper
DEBUG - 2020-02-24 22:44:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:44:00 --> Helper loaded: common_helper
INFO - 2020-02-24 22:44:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:44:00 --> Helper loaded: language_helper
INFO - 2020-02-24 22:44:00 --> Encryption Class Initialized
INFO - 2020-02-24 22:44:00 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:44:00 --> Controller Class Initialized
INFO - 2020-02-24 22:44:00 --> Helper loaded: email_helper
DEBUG - 2020-02-24 22:44:00 --> services MX_Controller Initialized
INFO - 2020-02-24 22:44:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:44:00 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-24 22:44:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:44:00 --> Model Class Initialized
INFO - 2020-02-24 22:44:00 --> Parser Class Initialized
INFO - 2020-02-24 22:44:00 --> User Agent Class Initialized
INFO - 2020-02-24 22:44:00 --> Model Class Initialized
DEBUG - 2020-02-24 22:44:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:44:00 --> Final output sent to browser
INFO - 2020-02-24 22:44:00 --> Database Driver Class Initialized
DEBUG - 2020-02-24 22:44:00 --> Total execution time: 1.6673
INFO - 2020-02-24 22:44:00 --> Model Class Initialized
INFO - 2020-02-24 22:44:00 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-02-24 22:44:00 --> Template Class Initialized
INFO - 2020-02-24 22:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:44:00 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:44:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:44:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:44:00 --> Encryption Class Initialized
INFO - 2020-02-24 22:44:00 --> Controller Class Initialized
DEBUG - 2020-02-24 22:44:00 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:44:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:44:00 --> Model Class Initialized
DEBUG - 2020-02-24 22:44:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:44:00 --> Final output sent to browser
DEBUG - 2020-02-24 22:44:00 --> Total execution time: 1.7114
INFO - 2020-02-24 22:44:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:44:00 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:44:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:44:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:44:00 --> Encryption Class Initialized
INFO - 2020-02-24 22:44:00 --> Controller Class Initialized
DEBUG - 2020-02-24 22:44:00 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:44:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:44:00 --> Model Class Initialized
DEBUG - 2020-02-24 22:44:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:44:00 --> Final output sent to browser
DEBUG - 2020-02-24 22:44:00 --> Total execution time: 1.6750
INFO - 2020-02-24 22:44:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:44:00 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:44:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:44:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:44:00 --> Encryption Class Initialized
INFO - 2020-02-24 22:44:00 --> Controller Class Initialized
DEBUG - 2020-02-24 22:44:01 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:44:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:44:01 --> Model Class Initialized
DEBUG - 2020-02-24 22:44:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:44:01 --> Final output sent to browser
DEBUG - 2020-02-24 22:44:01 --> Total execution time: 1.6518
INFO - 2020-02-24 22:44:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:44:01 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:44:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:44:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:44:01 --> Encryption Class Initialized
INFO - 2020-02-24 22:44:01 --> Controller Class Initialized
DEBUG - 2020-02-24 22:44:01 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:44:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:44:01 --> Model Class Initialized
DEBUG - 2020-02-24 22:44:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2020-02-24 22:44:01 --> Final output sent to browser
DEBUG - 2020-02-24 22:44:01 --> Total execution time: 1.5881
INFO - 2020-02-24 22:44:03 --> Config Class Initialized
INFO - 2020-02-24 22:44:04 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:44:04 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:44:04 --> Utf8 Class Initialized
INFO - 2020-02-24 22:44:04 --> URI Class Initialized
INFO - 2020-02-24 22:44:04 --> Router Class Initialized
INFO - 2020-02-24 22:44:04 --> Output Class Initialized
INFO - 2020-02-24 22:44:04 --> Security Class Initialized
DEBUG - 2020-02-24 22:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:44:04 --> CSRF cookie sent
INFO - 2020-02-24 22:44:04 --> Input Class Initialized
INFO - 2020-02-24 22:44:04 --> Language Class Initialized
INFO - 2020-02-24 22:44:04 --> Language Class Initialized
INFO - 2020-02-24 22:44:04 --> Config Class Initialized
INFO - 2020-02-24 22:44:04 --> Loader Class Initialized
INFO - 2020-02-24 22:44:04 --> Helper loaded: url_helper
INFO - 2020-02-24 22:44:04 --> Helper loaded: common_helper
INFO - 2020-02-24 22:44:04 --> Helper loaded: language_helper
INFO - 2020-02-24 22:44:04 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:44:04 --> Helper loaded: email_helper
INFO - 2020-02-24 22:44:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:44:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:44:04 --> Parser Class Initialized
INFO - 2020-02-24 22:44:04 --> User Agent Class Initialized
INFO - 2020-02-24 22:44:04 --> Model Class Initialized
INFO - 2020-02-24 22:44:04 --> Database Driver Class Initialized
INFO - 2020-02-24 22:44:04 --> Model Class Initialized
DEBUG - 2020-02-24 22:44:04 --> Template Class Initialized
INFO - 2020-02-24 22:44:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:44:04 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:44:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:44:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:44:04 --> Encryption Class Initialized
INFO - 2020-02-24 22:44:04 --> Controller Class Initialized
DEBUG - 2020-02-24 22:44:04 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:44:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:44:04 --> Model Class Initialized
DEBUG - 2020-02-24 22:44:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/update.php
INFO - 2020-02-24 22:44:05 --> Final output sent to browser
DEBUG - 2020-02-24 22:44:05 --> Total execution time: 1.0885
INFO - 2020-02-24 22:44:11 --> Config Class Initialized
INFO - 2020-02-24 22:44:11 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:44:11 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:44:11 --> Utf8 Class Initialized
INFO - 2020-02-24 22:44:11 --> URI Class Initialized
INFO - 2020-02-24 22:44:11 --> Router Class Initialized
INFO - 2020-02-24 22:44:11 --> Output Class Initialized
INFO - 2020-02-24 22:44:11 --> Security Class Initialized
DEBUG - 2020-02-24 22:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:44:11 --> CSRF cookie sent
INFO - 2020-02-24 22:44:11 --> Input Class Initialized
INFO - 2020-02-24 22:44:11 --> Language Class Initialized
INFO - 2020-02-24 22:44:11 --> Language Class Initialized
INFO - 2020-02-24 22:44:11 --> Config Class Initialized
INFO - 2020-02-24 22:44:11 --> Loader Class Initialized
INFO - 2020-02-24 22:44:11 --> Helper loaded: url_helper
INFO - 2020-02-24 22:44:11 --> Helper loaded: common_helper
INFO - 2020-02-24 22:44:11 --> Helper loaded: language_helper
INFO - 2020-02-24 22:44:11 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:44:11 --> Helper loaded: email_helper
INFO - 2020-02-24 22:44:11 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:44:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:44:11 --> Parser Class Initialized
INFO - 2020-02-24 22:44:11 --> User Agent Class Initialized
INFO - 2020-02-24 22:44:11 --> Model Class Initialized
INFO - 2020-02-24 22:44:11 --> Database Driver Class Initialized
INFO - 2020-02-24 22:44:11 --> Model Class Initialized
DEBUG - 2020-02-24 22:44:11 --> Template Class Initialized
INFO - 2020-02-24 22:44:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:44:11 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:44:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:44:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:44:11 --> Encryption Class Initialized
INFO - 2020-02-24 22:44:11 --> Controller Class Initialized
DEBUG - 2020-02-24 22:44:11 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:44:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:44:11 --> Model Class Initialized
DEBUG - 2020-02-24 22:44:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/update.php
INFO - 2020-02-24 22:44:11 --> Final output sent to browser
DEBUG - 2020-02-24 22:44:11 --> Total execution time: 0.7058
INFO - 2020-02-24 22:48:45 --> Config Class Initialized
INFO - 2020-02-24 22:48:45 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:48:45 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:48:45 --> Utf8 Class Initialized
INFO - 2020-02-24 22:48:45 --> URI Class Initialized
INFO - 2020-02-24 22:48:45 --> Router Class Initialized
INFO - 2020-02-24 22:48:45 --> Output Class Initialized
INFO - 2020-02-24 22:48:45 --> Security Class Initialized
DEBUG - 2020-02-24 22:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:48:45 --> CSRF cookie sent
INFO - 2020-02-24 22:48:45 --> Input Class Initialized
INFO - 2020-02-24 22:48:45 --> Language Class Initialized
INFO - 2020-02-24 22:48:45 --> Language Class Initialized
INFO - 2020-02-24 22:48:46 --> Config Class Initialized
INFO - 2020-02-24 22:48:46 --> Loader Class Initialized
INFO - 2020-02-24 22:48:46 --> Helper loaded: url_helper
INFO - 2020-02-24 22:48:46 --> Helper loaded: common_helper
INFO - 2020-02-24 22:48:46 --> Helper loaded: language_helper
INFO - 2020-02-24 22:48:46 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:48:46 --> Helper loaded: email_helper
INFO - 2020-02-24 22:48:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:48:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:48:46 --> Parser Class Initialized
INFO - 2020-02-24 22:48:46 --> User Agent Class Initialized
INFO - 2020-02-24 22:48:46 --> Model Class Initialized
INFO - 2020-02-24 22:48:46 --> Database Driver Class Initialized
INFO - 2020-02-24 22:48:46 --> Model Class Initialized
DEBUG - 2020-02-24 22:48:46 --> Template Class Initialized
INFO - 2020-02-24 22:48:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:48:46 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:48:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:48:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:48:46 --> Encryption Class Initialized
INFO - 2020-02-24 22:48:46 --> Controller Class Initialized
DEBUG - 2020-02-24 22:48:46 --> services MX_Controller Initialized
ERROR - 2020-02-24 22:48:46 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\services\models\services_model.php 45
INFO - 2020-02-24 22:49:07 --> Config Class Initialized
INFO - 2020-02-24 22:49:07 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:49:07 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:49:07 --> Utf8 Class Initialized
INFO - 2020-02-24 22:49:07 --> URI Class Initialized
INFO - 2020-02-24 22:49:07 --> Router Class Initialized
INFO - 2020-02-24 22:49:07 --> Output Class Initialized
INFO - 2020-02-24 22:49:07 --> Security Class Initialized
DEBUG - 2020-02-24 22:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:49:07 --> CSRF cookie sent
INFO - 2020-02-24 22:49:07 --> Input Class Initialized
INFO - 2020-02-24 22:49:07 --> Language Class Initialized
INFO - 2020-02-24 22:49:07 --> Language Class Initialized
INFO - 2020-02-24 22:49:07 --> Config Class Initialized
INFO - 2020-02-24 22:49:07 --> Loader Class Initialized
INFO - 2020-02-24 22:49:07 --> Helper loaded: url_helper
INFO - 2020-02-24 22:49:07 --> Helper loaded: common_helper
INFO - 2020-02-24 22:49:07 --> Helper loaded: language_helper
INFO - 2020-02-24 22:49:07 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:49:07 --> Helper loaded: email_helper
INFO - 2020-02-24 22:49:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:49:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:49:07 --> Parser Class Initialized
INFO - 2020-02-24 22:49:07 --> User Agent Class Initialized
INFO - 2020-02-24 22:49:07 --> Model Class Initialized
INFO - 2020-02-24 22:49:07 --> Database Driver Class Initialized
INFO - 2020-02-24 22:49:07 --> Model Class Initialized
DEBUG - 2020-02-24 22:49:07 --> Template Class Initialized
INFO - 2020-02-24 22:49:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:49:07 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:49:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:49:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:49:07 --> Encryption Class Initialized
INFO - 2020-02-24 22:49:07 --> Controller Class Initialized
DEBUG - 2020-02-24 22:49:07 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:49:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:49:07 --> Model Class Initialized
INFO - 2020-02-24 22:53:30 --> Config Class Initialized
INFO - 2020-02-24 22:53:30 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:53:30 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:53:30 --> Utf8 Class Initialized
INFO - 2020-02-24 22:53:30 --> URI Class Initialized
INFO - 2020-02-24 22:53:30 --> Router Class Initialized
INFO - 2020-02-24 22:53:30 --> Output Class Initialized
INFO - 2020-02-24 22:53:30 --> Security Class Initialized
DEBUG - 2020-02-24 22:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:53:30 --> CSRF cookie sent
INFO - 2020-02-24 22:53:30 --> Input Class Initialized
INFO - 2020-02-24 22:53:30 --> Language Class Initialized
INFO - 2020-02-24 22:53:30 --> Language Class Initialized
INFO - 2020-02-24 22:53:31 --> Config Class Initialized
INFO - 2020-02-24 22:53:31 --> Loader Class Initialized
INFO - 2020-02-24 22:53:31 --> Helper loaded: url_helper
INFO - 2020-02-24 22:53:31 --> Helper loaded: common_helper
INFO - 2020-02-24 22:53:31 --> Helper loaded: language_helper
INFO - 2020-02-24 22:53:31 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:53:31 --> Helper loaded: email_helper
INFO - 2020-02-24 22:53:31 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:53:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:53:31 --> Parser Class Initialized
INFO - 2020-02-24 22:53:31 --> User Agent Class Initialized
INFO - 2020-02-24 22:53:31 --> Model Class Initialized
INFO - 2020-02-24 22:53:31 --> Database Driver Class Initialized
INFO - 2020-02-24 22:53:31 --> Model Class Initialized
DEBUG - 2020-02-24 22:53:31 --> Template Class Initialized
INFO - 2020-02-24 22:53:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:53:31 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:53:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:53:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:53:31 --> Encryption Class Initialized
INFO - 2020-02-24 22:53:31 --> Controller Class Initialized
DEBUG - 2020-02-24 22:53:31 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:53:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:53:31 --> Model Class Initialized
INFO - 2020-02-24 22:53:31 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:53:31 --> Could not find the language line "Delele"
ERROR - 2020-02-24 22:53:31 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:31 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:31 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:31 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:31 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:31 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:31 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:31 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:32 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:32 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:32 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
ERROR - 2020-02-24 22:53:32 --> Severity: Notice --> Undefined property: CI::$columns D:\xampp\htdocs\projects\tuyen\smm_store\code\app\third_party\MX\Loader.php 304
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:53:32 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:53:32 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:53:32 --> Model Class Initialized
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:53:32 --> Model Class Initialized
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:53:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:53:32 --> Final output sent to browser
DEBUG - 2020-02-24 22:53:32 --> Total execution time: 1.7777
INFO - 2020-02-24 22:54:04 --> Config Class Initialized
INFO - 2020-02-24 22:54:04 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:54:04 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:54:04 --> Utf8 Class Initialized
INFO - 2020-02-24 22:54:04 --> URI Class Initialized
INFO - 2020-02-24 22:54:04 --> Router Class Initialized
INFO - 2020-02-24 22:54:04 --> Output Class Initialized
INFO - 2020-02-24 22:54:04 --> Security Class Initialized
DEBUG - 2020-02-24 22:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:54:04 --> CSRF cookie sent
INFO - 2020-02-24 22:54:04 --> Input Class Initialized
INFO - 2020-02-24 22:54:04 --> Language Class Initialized
INFO - 2020-02-24 22:54:04 --> Language Class Initialized
INFO - 2020-02-24 22:54:04 --> Config Class Initialized
INFO - 2020-02-24 22:54:04 --> Loader Class Initialized
INFO - 2020-02-24 22:54:04 --> Helper loaded: url_helper
INFO - 2020-02-24 22:54:04 --> Helper loaded: common_helper
INFO - 2020-02-24 22:54:04 --> Helper loaded: language_helper
INFO - 2020-02-24 22:54:04 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:54:04 --> Helper loaded: email_helper
INFO - 2020-02-24 22:54:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:54:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:54:04 --> Parser Class Initialized
INFO - 2020-02-24 22:54:05 --> User Agent Class Initialized
INFO - 2020-02-24 22:54:05 --> Model Class Initialized
INFO - 2020-02-24 22:54:05 --> Database Driver Class Initialized
INFO - 2020-02-24 22:54:05 --> Model Class Initialized
DEBUG - 2020-02-24 22:54:05 --> Template Class Initialized
INFO - 2020-02-24 22:54:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:54:05 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:54:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:54:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:54:05 --> Encryption Class Initialized
INFO - 2020-02-24 22:54:05 --> Controller Class Initialized
DEBUG - 2020-02-24 22:54:05 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:54:05 --> Model Class Initialized
INFO - 2020-02-24 22:54:05 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:54:05 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:54:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:54:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:54:05 --> Model Class Initialized
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:54:05 --> Model Class Initialized
DEBUG - 2020-02-24 22:54:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:54:06 --> Final output sent to browser
DEBUG - 2020-02-24 22:54:06 --> Total execution time: 1.5803
INFO - 2020-02-24 22:56:34 --> Config Class Initialized
INFO - 2020-02-24 22:56:34 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:56:34 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:56:34 --> Utf8 Class Initialized
INFO - 2020-02-24 22:56:34 --> URI Class Initialized
INFO - 2020-02-24 22:56:34 --> Router Class Initialized
INFO - 2020-02-24 22:56:34 --> Output Class Initialized
INFO - 2020-02-24 22:56:34 --> Security Class Initialized
DEBUG - 2020-02-24 22:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:56:34 --> CSRF cookie sent
INFO - 2020-02-24 22:56:34 --> Input Class Initialized
INFO - 2020-02-24 22:56:34 --> Language Class Initialized
INFO - 2020-02-24 22:56:35 --> Language Class Initialized
INFO - 2020-02-24 22:56:35 --> Config Class Initialized
INFO - 2020-02-24 22:56:35 --> Loader Class Initialized
INFO - 2020-02-24 22:56:35 --> Helper loaded: url_helper
INFO - 2020-02-24 22:56:35 --> Helper loaded: common_helper
INFO - 2020-02-24 22:56:35 --> Helper loaded: language_helper
INFO - 2020-02-24 22:56:35 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:56:35 --> Helper loaded: email_helper
INFO - 2020-02-24 22:56:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:56:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:56:35 --> Parser Class Initialized
INFO - 2020-02-24 22:56:35 --> User Agent Class Initialized
INFO - 2020-02-24 22:56:35 --> Model Class Initialized
INFO - 2020-02-24 22:56:35 --> Database Driver Class Initialized
INFO - 2020-02-24 22:56:35 --> Model Class Initialized
DEBUG - 2020-02-24 22:56:35 --> Template Class Initialized
INFO - 2020-02-24 22:56:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:56:35 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:56:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:56:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:56:35 --> Encryption Class Initialized
INFO - 2020-02-24 22:56:35 --> Controller Class Initialized
DEBUG - 2020-02-24 22:56:35 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:56:35 --> Model Class Initialized
INFO - 2020-02-24 22:56:35 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:56:35 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 22:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2020-02-24 22:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:56:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:56:35 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:56:35 --> Model Class Initialized
DEBUG - 2020-02-24 22:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:56:35 --> Model Class Initialized
DEBUG - 2020-02-24 22:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:56:35 --> Final output sent to browser
DEBUG - 2020-02-24 22:56:35 --> Total execution time: 1.2123
INFO - 2020-02-24 22:56:51 --> Config Class Initialized
INFO - 2020-02-24 22:56:51 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:56:51 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:56:51 --> Utf8 Class Initialized
INFO - 2020-02-24 22:56:51 --> URI Class Initialized
INFO - 2020-02-24 22:56:51 --> Router Class Initialized
INFO - 2020-02-24 22:56:51 --> Output Class Initialized
INFO - 2020-02-24 22:56:51 --> Security Class Initialized
DEBUG - 2020-02-24 22:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:56:51 --> CSRF cookie sent
INFO - 2020-02-24 22:56:51 --> Input Class Initialized
INFO - 2020-02-24 22:56:51 --> Language Class Initialized
INFO - 2020-02-24 22:56:51 --> Language Class Initialized
INFO - 2020-02-24 22:56:51 --> Config Class Initialized
INFO - 2020-02-24 22:56:51 --> Loader Class Initialized
INFO - 2020-02-24 22:56:52 --> Helper loaded: url_helper
INFO - 2020-02-24 22:56:52 --> Helper loaded: common_helper
INFO - 2020-02-24 22:56:52 --> Helper loaded: language_helper
INFO - 2020-02-24 22:56:52 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:56:52 --> Helper loaded: email_helper
INFO - 2020-02-24 22:56:52 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:56:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:56:52 --> Parser Class Initialized
INFO - 2020-02-24 22:56:52 --> User Agent Class Initialized
INFO - 2020-02-24 22:56:52 --> Model Class Initialized
INFO - 2020-02-24 22:56:52 --> Database Driver Class Initialized
INFO - 2020-02-24 22:56:52 --> Model Class Initialized
DEBUG - 2020-02-24 22:56:52 --> Template Class Initialized
INFO - 2020-02-24 22:56:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:56:52 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:56:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:56:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:56:52 --> Encryption Class Initialized
INFO - 2020-02-24 22:56:52 --> Controller Class Initialized
DEBUG - 2020-02-24 22:56:52 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:56:52 --> Model Class Initialized
INFO - 2020-02-24 22:56:52 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:56:52 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\services\views\index.php 82
INFO - 2020-02-24 22:57:03 --> Config Class Initialized
INFO - 2020-02-24 22:57:03 --> Hooks Class Initialized
DEBUG - 2020-02-24 22:57:03 --> UTF-8 Support Enabled
INFO - 2020-02-24 22:57:03 --> Utf8 Class Initialized
INFO - 2020-02-24 22:57:03 --> URI Class Initialized
INFO - 2020-02-24 22:57:03 --> Router Class Initialized
INFO - 2020-02-24 22:57:03 --> Output Class Initialized
INFO - 2020-02-24 22:57:03 --> Security Class Initialized
DEBUG - 2020-02-24 22:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-24 22:57:04 --> CSRF cookie sent
INFO - 2020-02-24 22:57:04 --> Input Class Initialized
INFO - 2020-02-24 22:57:04 --> Language Class Initialized
INFO - 2020-02-24 22:57:04 --> Language Class Initialized
INFO - 2020-02-24 22:57:04 --> Config Class Initialized
INFO - 2020-02-24 22:57:04 --> Loader Class Initialized
INFO - 2020-02-24 22:57:04 --> Helper loaded: url_helper
INFO - 2020-02-24 22:57:04 --> Helper loaded: common_helper
INFO - 2020-02-24 22:57:04 --> Helper loaded: language_helper
INFO - 2020-02-24 22:57:04 --> Helper loaded: cookie_helper
INFO - 2020-02-24 22:57:04 --> Helper loaded: email_helper
INFO - 2020-02-24 22:57:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-24 22:57:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-24 22:57:04 --> Parser Class Initialized
INFO - 2020-02-24 22:57:04 --> User Agent Class Initialized
INFO - 2020-02-24 22:57:04 --> Model Class Initialized
INFO - 2020-02-24 22:57:04 --> Database Driver Class Initialized
INFO - 2020-02-24 22:57:04 --> Model Class Initialized
DEBUG - 2020-02-24 22:57:04 --> Template Class Initialized
INFO - 2020-02-24 22:57:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-24 22:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-24 22:57:04 --> Pagination Class Initialized
DEBUG - 2020-02-24 22:57:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-24 22:57:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-24 22:57:04 --> Encryption Class Initialized
INFO - 2020-02-24 22:57:04 --> Controller Class Initialized
DEBUG - 2020-02-24 22:57:04 --> services MX_Controller Initialized
DEBUG - 2020-02-24 22:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:57:04 --> Model Class Initialized
INFO - 2020-02-24 22:57:04 --> Helper loaded: inflector_helper
ERROR - 2020-02-24 22:57:04 --> Could not find the language line "Delele"
DEBUG - 2020-02-24 22:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-24 22:57:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-24 22:57:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-24 22:57:05 --> Model Class Initialized
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-24 22:57:05 --> Model Class Initialized
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-24 22:57:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-24 22:57:05 --> Final output sent to browser
DEBUG - 2020-02-24 22:57:05 --> Total execution time: 1.6493
