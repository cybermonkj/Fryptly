<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-18 16:14:34 --> Config Class Initialized
INFO - 2020-01-18 16:14:34 --> Hooks Class Initialized
DEBUG - 2020-01-18 16:14:34 --> UTF-8 Support Enabled
INFO - 2020-01-18 16:14:34 --> Utf8 Class Initialized
INFO - 2020-01-18 16:14:34 --> URI Class Initialized
DEBUG - 2020-01-18 16:14:34 --> No URI present. Default controller set.
INFO - 2020-01-18 16:14:34 --> Router Class Initialized
INFO - 2020-01-18 16:14:35 --> Output Class Initialized
INFO - 2020-01-18 16:14:35 --> Security Class Initialized
DEBUG - 2020-01-18 16:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-18 16:14:35 --> CSRF cookie sent
INFO - 2020-01-18 16:14:35 --> Input Class Initialized
INFO - 2020-01-18 16:14:35 --> Language Class Initialized
INFO - 2020-01-18 16:14:35 --> Language Class Initialized
INFO - 2020-01-18 16:14:35 --> Config Class Initialized
INFO - 2020-01-18 16:14:35 --> Loader Class Initialized
INFO - 2020-01-18 16:14:35 --> Helper loaded: url_helper
INFO - 2020-01-18 16:14:35 --> Helper loaded: common_helper
INFO - 2020-01-18 16:14:35 --> Helper loaded: language_helper
INFO - 2020-01-18 16:14:35 --> Helper loaded: cookie_helper
INFO - 2020-01-18 16:14:35 --> Helper loaded: email_helper
INFO - 2020-01-18 16:14:35 --> Helper loaded: file_manager_helper
INFO - 2020-01-18 16:14:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-18 16:14:35 --> Parser Class Initialized
INFO - 2020-01-18 16:14:35 --> User Agent Class Initialized
INFO - 2020-01-18 16:14:35 --> Model Class Initialized
INFO - 2020-01-18 16:14:35 --> Database Driver Class Initialized
INFO - 2020-01-18 16:14:35 --> Model Class Initialized
DEBUG - 2020-01-18 16:14:35 --> Template Class Initialized
INFO - 2020-01-18 16:14:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-18 16:14:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-18 16:14:36 --> Pagination Class Initialized
DEBUG - 2020-01-18 16:14:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-18 16:14:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-18 16:14:36 --> Encryption Class Initialized
DEBUG - 2020-01-18 16:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-18 16:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-18 16:14:36 --> Controller Class Initialized
DEBUG - 2020-01-18 16:14:36 --> pergo MX_Controller Initialized
DEBUG - 2020-01-18 16:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-18 16:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-18 16:14:36 --> Model Class Initialized
INFO - 2020-01-18 16:14:36 --> Helper loaded: inflector_helper
DEBUG - 2020-01-18 16:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-18 16:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-18 16:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-18 16:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-18 16:14:36 --> Final output sent to browser
DEBUG - 2020-01-18 16:14:37 --> Total execution time: 2.2914
INFO - 2020-01-18 16:14:44 --> Config Class Initialized
INFO - 2020-01-18 16:14:44 --> Hooks Class Initialized
DEBUG - 2020-01-18 16:14:44 --> UTF-8 Support Enabled
INFO - 2020-01-18 16:14:44 --> Utf8 Class Initialized
INFO - 2020-01-18 16:14:44 --> URI Class Initialized
INFO - 2020-01-18 16:14:44 --> Router Class Initialized
INFO - 2020-01-18 16:14:44 --> Output Class Initialized
INFO - 2020-01-18 16:14:44 --> Security Class Initialized
DEBUG - 2020-01-18 16:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-18 16:14:44 --> CSRF cookie sent
INFO - 2020-01-18 16:14:44 --> Input Class Initialized
INFO - 2020-01-18 16:14:44 --> Language Class Initialized
INFO - 2020-01-18 16:14:44 --> Language Class Initialized
INFO - 2020-01-18 16:14:44 --> Config Class Initialized
INFO - 2020-01-18 16:14:44 --> Loader Class Initialized
INFO - 2020-01-18 16:14:44 --> Helper loaded: url_helper
INFO - 2020-01-18 16:14:44 --> Helper loaded: common_helper
INFO - 2020-01-18 16:14:44 --> Helper loaded: language_helper
INFO - 2020-01-18 16:14:44 --> Helper loaded: cookie_helper
INFO - 2020-01-18 16:14:44 --> Helper loaded: email_helper
INFO - 2020-01-18 16:14:44 --> Helper loaded: file_manager_helper
INFO - 2020-01-18 16:14:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-18 16:14:44 --> Parser Class Initialized
INFO - 2020-01-18 16:14:44 --> User Agent Class Initialized
INFO - 2020-01-18 16:14:44 --> Model Class Initialized
INFO - 2020-01-18 16:14:44 --> Database Driver Class Initialized
INFO - 2020-01-18 16:14:44 --> Model Class Initialized
DEBUG - 2020-01-18 16:14:44 --> Template Class Initialized
INFO - 2020-01-18 16:14:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-18 16:14:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-18 16:14:44 --> Pagination Class Initialized
DEBUG - 2020-01-18 16:14:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-18 16:14:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-18 16:14:44 --> Encryption Class Initialized
INFO - 2020-01-18 16:14:44 --> Controller Class Initialized
DEBUG - 2020-01-18 16:14:44 --> auth MX_Controller Initialized
DEBUG - 2020-01-18 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-01-18 16:14:44 --> Model Class Initialized
DEBUG - 2020-01-18 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-18 16:14:44 --> Helper loaded: inflector_helper
DEBUG - 2020-01-18 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-01-18 16:14:44 --> pergo MX_Controller Initialized
DEBUG - 2020-01-18 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-18 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-01-18 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-18 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-18 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-01-18 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-18 16:14:44 --> Final output sent to browser
DEBUG - 2020-01-18 16:14:44 --> Total execution time: 0.5954
INFO - 2020-01-18 16:14:46 --> Config Class Initialized
INFO - 2020-01-18 16:14:46 --> Hooks Class Initialized
DEBUG - 2020-01-18 16:14:46 --> UTF-8 Support Enabled
INFO - 2020-01-18 16:14:46 --> Utf8 Class Initialized
INFO - 2020-01-18 16:14:46 --> URI Class Initialized
INFO - 2020-01-18 16:14:46 --> Router Class Initialized
INFO - 2020-01-18 16:14:46 --> Output Class Initialized
INFO - 2020-01-18 16:14:46 --> Security Class Initialized
DEBUG - 2020-01-18 16:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-18 16:14:46 --> CSRF cookie sent
INFO - 2020-01-18 16:14:46 --> CSRF token verified
INFO - 2020-01-18 16:14:46 --> Input Class Initialized
INFO - 2020-01-18 16:14:46 --> Language Class Initialized
INFO - 2020-01-18 16:14:46 --> Language Class Initialized
INFO - 2020-01-18 16:14:46 --> Config Class Initialized
INFO - 2020-01-18 16:14:46 --> Loader Class Initialized
INFO - 2020-01-18 16:14:46 --> Helper loaded: url_helper
INFO - 2020-01-18 16:14:46 --> Helper loaded: common_helper
INFO - 2020-01-18 16:14:46 --> Helper loaded: language_helper
INFO - 2020-01-18 16:14:46 --> Helper loaded: cookie_helper
INFO - 2020-01-18 16:14:46 --> Helper loaded: email_helper
INFO - 2020-01-18 16:14:46 --> Helper loaded: file_manager_helper
INFO - 2020-01-18 16:14:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-18 16:14:46 --> Parser Class Initialized
INFO - 2020-01-18 16:14:46 --> User Agent Class Initialized
INFO - 2020-01-18 16:14:46 --> Model Class Initialized
INFO - 2020-01-18 16:14:46 --> Database Driver Class Initialized
INFO - 2020-01-18 16:14:46 --> Model Class Initialized
DEBUG - 2020-01-18 16:14:46 --> Template Class Initialized
INFO - 2020-01-18 16:14:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-18 16:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-18 16:14:46 --> Pagination Class Initialized
DEBUG - 2020-01-18 16:14:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-18 16:14:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-18 16:14:46 --> Encryption Class Initialized
INFO - 2020-01-18 16:14:46 --> Controller Class Initialized
DEBUG - 2020-01-18 16:14:46 --> auth MX_Controller Initialized
DEBUG - 2020-01-18 16:14:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-01-18 16:14:46 --> Model Class Initialized
INFO - 2020-01-18 16:14:52 --> Config Class Initialized
INFO - 2020-01-18 16:14:52 --> Hooks Class Initialized
DEBUG - 2020-01-18 16:14:52 --> UTF-8 Support Enabled
INFO - 2020-01-18 16:14:52 --> Utf8 Class Initialized
INFO - 2020-01-18 16:14:52 --> URI Class Initialized
INFO - 2020-01-18 16:14:52 --> Router Class Initialized
INFO - 2020-01-18 16:14:52 --> Output Class Initialized
INFO - 2020-01-18 16:14:52 --> Security Class Initialized
DEBUG - 2020-01-18 16:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-18 16:14:52 --> CSRF cookie sent
INFO - 2020-01-18 16:14:52 --> Input Class Initialized
INFO - 2020-01-18 16:14:52 --> Language Class Initialized
INFO - 2020-01-18 16:14:52 --> Language Class Initialized
INFO - 2020-01-18 16:14:52 --> Config Class Initialized
INFO - 2020-01-18 16:14:52 --> Loader Class Initialized
INFO - 2020-01-18 16:14:52 --> Helper loaded: url_helper
INFO - 2020-01-18 16:14:52 --> Helper loaded: common_helper
INFO - 2020-01-18 16:14:52 --> Helper loaded: language_helper
INFO - 2020-01-18 16:14:52 --> Helper loaded: cookie_helper
INFO - 2020-01-18 16:14:52 --> Helper loaded: email_helper
INFO - 2020-01-18 16:14:52 --> Helper loaded: file_manager_helper
INFO - 2020-01-18 16:14:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-18 16:14:52 --> Parser Class Initialized
INFO - 2020-01-18 16:14:52 --> User Agent Class Initialized
INFO - 2020-01-18 16:14:52 --> Model Class Initialized
INFO - 2020-01-18 16:14:52 --> Database Driver Class Initialized
INFO - 2020-01-18 16:14:52 --> Model Class Initialized
DEBUG - 2020-01-18 16:14:52 --> Template Class Initialized
INFO - 2020-01-18 16:14:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-18 16:14:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-18 16:14:52 --> Pagination Class Initialized
DEBUG - 2020-01-18 16:14:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-18 16:14:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-18 16:14:52 --> Encryption Class Initialized
INFO - 2020-01-18 16:14:52 --> Controller Class Initialized
DEBUG - 2020-01-18 16:14:52 --> statistics MX_Controller Initialized
DEBUG - 2020-01-18 16:14:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-01-18 16:14:53 --> Model Class Initialized
ERROR - 2020-01-18 16:14:53 --> Could not find the language line "Pending"
ERROR - 2020-01-18 16:14:53 --> Could not find the language line "Pending"
INFO - 2020-01-18 16:14:53 --> Helper loaded: inflector_helper
ERROR - 2020-01-18 16:14:53 --> Could not find the language line "total_orders"
ERROR - 2020-01-18 16:14:53 --> Could not find the language line "total_orders"
ERROR - 2020-01-18 16:14:53 --> Could not find the language line "Pending"
DEBUG - 2020-01-18 16:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-01-18 16:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-01-18 16:14:53 --> blocks MX_Controller Initialized
DEBUG - 2020-01-18 16:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-01-18 16:14:53 --> Model Class Initialized
DEBUG - 2020-01-18 16:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-01-18 16:14:53 --> Model Class Initialized
DEBUG - 2020-01-18 16:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-01-18 16:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-01-18 16:14:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-01-18 16:14:53 --> Final output sent to browser
DEBUG - 2020-01-18 16:14:53 --> Total execution time: 1.2467
INFO - 2020-01-18 16:15:16 --> Config Class Initialized
INFO - 2020-01-18 16:15:16 --> Hooks Class Initialized
DEBUG - 2020-01-18 16:15:16 --> UTF-8 Support Enabled
INFO - 2020-01-18 16:15:16 --> Utf8 Class Initialized
INFO - 2020-01-18 16:15:16 --> URI Class Initialized
INFO - 2020-01-18 16:15:16 --> Router Class Initialized
INFO - 2020-01-18 16:15:16 --> Output Class Initialized
INFO - 2020-01-18 16:15:16 --> Security Class Initialized
DEBUG - 2020-01-18 16:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-18 16:15:16 --> CSRF cookie sent
INFO - 2020-01-18 16:15:16 --> Input Class Initialized
INFO - 2020-01-18 16:15:16 --> Language Class Initialized
INFO - 2020-01-18 16:15:16 --> Language Class Initialized
INFO - 2020-01-18 16:15:16 --> Config Class Initialized
INFO - 2020-01-18 16:15:16 --> Loader Class Initialized
INFO - 2020-01-18 16:15:16 --> Helper loaded: url_helper
INFO - 2020-01-18 16:15:16 --> Helper loaded: common_helper
INFO - 2020-01-18 16:15:16 --> Helper loaded: language_helper
INFO - 2020-01-18 16:15:16 --> Helper loaded: cookie_helper
INFO - 2020-01-18 16:15:16 --> Helper loaded: email_helper
INFO - 2020-01-18 16:15:16 --> Helper loaded: file_manager_helper
INFO - 2020-01-18 16:15:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-18 16:15:16 --> Parser Class Initialized
INFO - 2020-01-18 16:15:16 --> User Agent Class Initialized
INFO - 2020-01-18 16:15:16 --> Model Class Initialized
INFO - 2020-01-18 16:15:16 --> Database Driver Class Initialized
INFO - 2020-01-18 16:15:16 --> Model Class Initialized
DEBUG - 2020-01-18 16:15:16 --> Template Class Initialized
INFO - 2020-01-18 16:15:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-18 16:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-18 16:15:17 --> Pagination Class Initialized
DEBUG - 2020-01-18 16:15:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-18 16:15:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-18 16:15:17 --> Encryption Class Initialized
INFO - 2020-01-18 16:15:17 --> Controller Class Initialized
DEBUG - 2020-01-18 16:15:17 --> setting MX_Controller Initialized
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-01-18 16:15:17 --> Model Class Initialized
INFO - 2020-01-18 16:15:17 --> Helper loaded: inflector_helper
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-01-18 16:15:17 --> blocks MX_Controller Initialized
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-01-18 16:15:17 --> Model Class Initialized
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-01-18 16:15:17 --> Model Class Initialized
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-01-18 16:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-01-18 16:15:17 --> Final output sent to browser
DEBUG - 2020-01-18 16:15:17 --> Total execution time: 0.8140
INFO - 2020-01-18 16:15:21 --> Config Class Initialized
INFO - 2020-01-18 16:15:21 --> Hooks Class Initialized
DEBUG - 2020-01-18 16:15:21 --> UTF-8 Support Enabled
INFO - 2020-01-18 16:15:21 --> Utf8 Class Initialized
INFO - 2020-01-18 16:15:21 --> URI Class Initialized
INFO - 2020-01-18 16:15:21 --> Router Class Initialized
INFO - 2020-01-18 16:15:21 --> Output Class Initialized
INFO - 2020-01-18 16:15:21 --> Security Class Initialized
DEBUG - 2020-01-18 16:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-18 16:15:21 --> CSRF cookie sent
INFO - 2020-01-18 16:15:21 --> Input Class Initialized
INFO - 2020-01-18 16:15:21 --> Language Class Initialized
INFO - 2020-01-18 16:15:21 --> Language Class Initialized
INFO - 2020-01-18 16:15:21 --> Config Class Initialized
INFO - 2020-01-18 16:15:21 --> Loader Class Initialized
INFO - 2020-01-18 16:15:21 --> Helper loaded: url_helper
INFO - 2020-01-18 16:15:21 --> Helper loaded: common_helper
INFO - 2020-01-18 16:15:21 --> Helper loaded: language_helper
INFO - 2020-01-18 16:15:22 --> Helper loaded: cookie_helper
INFO - 2020-01-18 16:15:22 --> Helper loaded: email_helper
INFO - 2020-01-18 16:15:22 --> Helper loaded: file_manager_helper
INFO - 2020-01-18 16:15:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-18 16:15:22 --> Parser Class Initialized
INFO - 2020-01-18 16:15:22 --> User Agent Class Initialized
INFO - 2020-01-18 16:15:22 --> Model Class Initialized
INFO - 2020-01-18 16:15:22 --> Database Driver Class Initialized
INFO - 2020-01-18 16:15:22 --> Model Class Initialized
DEBUG - 2020-01-18 16:15:22 --> Template Class Initialized
INFO - 2020-01-18 16:15:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-18 16:15:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-18 16:15:22 --> Pagination Class Initialized
DEBUG - 2020-01-18 16:15:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-18 16:15:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-18 16:15:22 --> Encryption Class Initialized
INFO - 2020-01-18 16:15:22 --> Controller Class Initialized
DEBUG - 2020-01-18 16:15:22 --> setting MX_Controller Initialized
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-01-18 16:15:22 --> Model Class Initialized
INFO - 2020-01-18 16:15:22 --> Helper loaded: inflector_helper
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2020-01-18 16:15:22 --> Could not find the language line "Shopier"
ERROR - 2020-01-18 16:15:22 --> Could not find the language line "shopier_api_key"
ERROR - 2020-01-18 16:15:22 --> Could not find the language line "shopier_api_secret"
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/shopier.php
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-01-18 16:15:22 --> blocks MX_Controller Initialized
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-01-18 16:15:22 --> Model Class Initialized
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-01-18 16:15:22 --> Model Class Initialized
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-01-18 16:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-01-18 16:15:22 --> Final output sent to browser
DEBUG - 2020-01-18 16:15:22 --> Total execution time: 0.7468
