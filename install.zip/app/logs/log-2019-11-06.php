<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-06 23:51:08 --> Config Class Initialized
INFO - 2019-11-06 23:51:08 --> Hooks Class Initialized
DEBUG - 2019-11-06 23:51:08 --> UTF-8 Support Enabled
INFO - 2019-11-06 23:51:08 --> Utf8 Class Initialized
INFO - 2019-11-06 23:51:08 --> URI Class Initialized
DEBUG - 2019-11-06 23:51:08 --> No URI present. Default controller set.
INFO - 2019-11-06 23:51:08 --> Router Class Initialized
INFO - 2019-11-06 23:51:08 --> Output Class Initialized
INFO - 2019-11-06 23:51:08 --> Security Class Initialized
DEBUG - 2019-11-06 23:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 23:51:08 --> CSRF cookie sent
INFO - 2019-11-06 23:51:08 --> Input Class Initialized
INFO - 2019-11-06 23:51:08 --> Language Class Initialized
INFO - 2019-11-06 23:51:09 --> Language Class Initialized
INFO - 2019-11-06 23:51:09 --> Config Class Initialized
INFO - 2019-11-06 23:51:09 --> Loader Class Initialized
INFO - 2019-11-06 23:51:09 --> Helper loaded: url_helper
INFO - 2019-11-06 23:51:09 --> Helper loaded: common_helper
INFO - 2019-11-06 23:51:09 --> Helper loaded: language_helper
INFO - 2019-11-06 23:51:09 --> Helper loaded: cookie_helper
INFO - 2019-11-06 23:51:09 --> Helper loaded: email_helper
INFO - 2019-11-06 23:51:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-06 23:51:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-06 23:51:09 --> Parser Class Initialized
INFO - 2019-11-06 23:51:09 --> User Agent Class Initialized
INFO - 2019-11-06 23:51:09 --> Model Class Initialized
INFO - 2019-11-06 23:51:09 --> Database Driver Class Initialized
INFO - 2019-11-06 23:51:09 --> Model Class Initialized
DEBUG - 2019-11-06 23:51:09 --> Template Class Initialized
INFO - 2019-11-06 23:51:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-06 23:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-06 23:51:09 --> Pagination Class Initialized
DEBUG - 2019-11-06 23:51:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-06 23:51:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-06 23:51:09 --> Encryption Class Initialized
DEBUG - 2019-11-06 23:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-06 23:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-06 23:51:09 --> Controller Class Initialized
DEBUG - 2019-11-06 23:51:09 --> pergo MX_Controller Initialized
DEBUG - 2019-11-06 23:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-06 23:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-06 23:51:09 --> Model Class Initialized
INFO - 2019-11-06 23:51:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-06 23:51:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-06 23:51:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-06 23:51:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-06 23:51:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-06 23:51:10 --> Final output sent to browser
DEBUG - 2019-11-06 23:51:10 --> Total execution time: 1.7487
INFO - 2019-11-06 23:51:20 --> Config Class Initialized
INFO - 2019-11-06 23:51:20 --> Hooks Class Initialized
DEBUG - 2019-11-06 23:51:20 --> UTF-8 Support Enabled
INFO - 2019-11-06 23:51:20 --> Utf8 Class Initialized
INFO - 2019-11-06 23:51:20 --> URI Class Initialized
INFO - 2019-11-06 23:51:20 --> Router Class Initialized
INFO - 2019-11-06 23:51:20 --> Output Class Initialized
INFO - 2019-11-06 23:51:20 --> Security Class Initialized
DEBUG - 2019-11-06 23:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 23:51:20 --> CSRF cookie sent
INFO - 2019-11-06 23:51:20 --> Input Class Initialized
INFO - 2019-11-06 23:51:20 --> Language Class Initialized
INFO - 2019-11-06 23:51:21 --> Language Class Initialized
INFO - 2019-11-06 23:51:21 --> Config Class Initialized
INFO - 2019-11-06 23:51:21 --> Loader Class Initialized
INFO - 2019-11-06 23:51:21 --> Helper loaded: url_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: common_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: language_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: cookie_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: email_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-06 23:51:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-06 23:51:21 --> Parser Class Initialized
INFO - 2019-11-06 23:51:21 --> User Agent Class Initialized
INFO - 2019-11-06 23:51:21 --> Model Class Initialized
INFO - 2019-11-06 23:51:21 --> Database Driver Class Initialized
INFO - 2019-11-06 23:51:21 --> Model Class Initialized
DEBUG - 2019-11-06 23:51:21 --> Template Class Initialized
INFO - 2019-11-06 23:51:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-06 23:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-06 23:51:21 --> Pagination Class Initialized
DEBUG - 2019-11-06 23:51:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-06 23:51:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-06 23:51:21 --> Encryption Class Initialized
INFO - 2019-11-06 23:51:21 --> Controller Class Initialized
DEBUG - 2019-11-06 23:51:21 --> mollie MX_Controller Initialized
INFO - 2019-11-06 23:51:21 --> Config Class Initialized
INFO - 2019-11-06 23:51:21 --> Hooks Class Initialized
DEBUG - 2019-11-06 23:51:21 --> UTF-8 Support Enabled
INFO - 2019-11-06 23:51:21 --> Utf8 Class Initialized
INFO - 2019-11-06 23:51:21 --> URI Class Initialized
DEBUG - 2019-11-06 23:51:21 --> No URI present. Default controller set.
INFO - 2019-11-06 23:51:21 --> Router Class Initialized
INFO - 2019-11-06 23:51:21 --> Output Class Initialized
INFO - 2019-11-06 23:51:21 --> Security Class Initialized
DEBUG - 2019-11-06 23:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 23:51:21 --> CSRF cookie sent
INFO - 2019-11-06 23:51:21 --> Input Class Initialized
INFO - 2019-11-06 23:51:21 --> Language Class Initialized
INFO - 2019-11-06 23:51:21 --> Language Class Initialized
INFO - 2019-11-06 23:51:21 --> Config Class Initialized
INFO - 2019-11-06 23:51:21 --> Loader Class Initialized
INFO - 2019-11-06 23:51:21 --> Helper loaded: url_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: common_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: language_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: cookie_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: email_helper
INFO - 2019-11-06 23:51:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-06 23:51:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-06 23:51:21 --> Parser Class Initialized
INFO - 2019-11-06 23:51:21 --> User Agent Class Initialized
INFO - 2019-11-06 23:51:21 --> Model Class Initialized
INFO - 2019-11-06 23:51:21 --> Database Driver Class Initialized
INFO - 2019-11-06 23:51:21 --> Model Class Initialized
DEBUG - 2019-11-06 23:51:21 --> Template Class Initialized
INFO - 2019-11-06 23:51:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-06 23:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-06 23:51:21 --> Pagination Class Initialized
DEBUG - 2019-11-06 23:51:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-06 23:51:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-06 23:51:21 --> Encryption Class Initialized
DEBUG - 2019-11-06 23:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-06 23:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-06 23:51:21 --> Controller Class Initialized
DEBUG - 2019-11-06 23:51:21 --> pergo MX_Controller Initialized
DEBUG - 2019-11-06 23:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-06 23:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-06 23:51:21 --> Model Class Initialized
INFO - 2019-11-06 23:51:21 --> Helper loaded: inflector_helper
DEBUG - 2019-11-06 23:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-06 23:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-06 23:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-06 23:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-06 23:51:21 --> Final output sent to browser
DEBUG - 2019-11-06 23:51:21 --> Total execution time: 0.6314
