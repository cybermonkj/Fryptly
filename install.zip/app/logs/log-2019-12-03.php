<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-03 21:46:07 --> Config Class Initialized
INFO - 2019-12-03 21:46:07 --> Hooks Class Initialized
DEBUG - 2019-12-03 21:46:07 --> UTF-8 Support Enabled
INFO - 2019-12-03 21:46:07 --> Utf8 Class Initialized
INFO - 2019-12-03 21:46:07 --> URI Class Initialized
DEBUG - 2019-12-03 21:46:07 --> No URI present. Default controller set.
INFO - 2019-12-03 21:46:07 --> Router Class Initialized
INFO - 2019-12-03 21:46:07 --> Output Class Initialized
INFO - 2019-12-03 21:46:07 --> Security Class Initialized
DEBUG - 2019-12-03 21:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 21:46:07 --> CSRF cookie sent
INFO - 2019-12-03 21:46:07 --> Input Class Initialized
INFO - 2019-12-03 21:46:07 --> Language Class Initialized
INFO - 2019-12-03 21:46:07 --> Language Class Initialized
INFO - 2019-12-03 21:46:07 --> Config Class Initialized
INFO - 2019-12-03 21:46:07 --> Loader Class Initialized
INFO - 2019-12-03 21:46:07 --> Helper loaded: url_helper
INFO - 2019-12-03 21:46:07 --> Helper loaded: common_helper
INFO - 2019-12-03 21:46:07 --> Helper loaded: language_helper
INFO - 2019-12-03 21:46:07 --> Helper loaded: cookie_helper
INFO - 2019-12-03 21:46:07 --> Helper loaded: email_helper
INFO - 2019-12-03 21:46:07 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 21:46:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 21:46:07 --> Parser Class Initialized
INFO - 2019-12-03 21:46:07 --> User Agent Class Initialized
INFO - 2019-12-03 21:46:07 --> Model Class Initialized
INFO - 2019-12-03 21:46:07 --> Database Driver Class Initialized
INFO - 2019-12-03 21:46:07 --> Model Class Initialized
DEBUG - 2019-12-03 21:46:07 --> Template Class Initialized
INFO - 2019-12-03 21:46:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 21:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 21:46:08 --> Pagination Class Initialized
DEBUG - 2019-12-03 21:46:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 21:46:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 21:46:08 --> Encryption Class Initialized
DEBUG - 2019-12-03 21:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-03 21:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-03 21:46:08 --> Controller Class Initialized
DEBUG - 2019-12-03 21:46:08 --> pergo MX_Controller Initialized
DEBUG - 2019-12-03 21:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-03 21:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-03 21:46:08 --> Model Class Initialized
INFO - 2019-12-03 21:46:08 --> Helper loaded: inflector_helper
DEBUG - 2019-12-03 21:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-03 21:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-03 21:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-03 21:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-03 21:46:08 --> Final output sent to browser
DEBUG - 2019-12-03 21:46:08 --> Total execution time: 1.8049
INFO - 2019-12-03 21:46:12 --> Config Class Initialized
INFO - 2019-12-03 21:46:12 --> Hooks Class Initialized
DEBUG - 2019-12-03 21:46:12 --> UTF-8 Support Enabled
INFO - 2019-12-03 21:46:12 --> Utf8 Class Initialized
INFO - 2019-12-03 21:46:12 --> URI Class Initialized
INFO - 2019-12-03 21:46:12 --> Router Class Initialized
INFO - 2019-12-03 21:46:12 --> Output Class Initialized
INFO - 2019-12-03 21:46:12 --> Security Class Initialized
DEBUG - 2019-12-03 21:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 21:46:12 --> CSRF cookie sent
INFO - 2019-12-03 21:46:12 --> Input Class Initialized
INFO - 2019-12-03 21:46:12 --> Language Class Initialized
INFO - 2019-12-03 21:46:12 --> Language Class Initialized
INFO - 2019-12-03 21:46:12 --> Config Class Initialized
INFO - 2019-12-03 21:46:12 --> Loader Class Initialized
INFO - 2019-12-03 21:46:12 --> Helper loaded: url_helper
INFO - 2019-12-03 21:46:12 --> Helper loaded: common_helper
INFO - 2019-12-03 21:46:12 --> Helper loaded: language_helper
INFO - 2019-12-03 21:46:12 --> Helper loaded: cookie_helper
INFO - 2019-12-03 21:46:12 --> Helper loaded: email_helper
INFO - 2019-12-03 21:46:12 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 21:46:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 21:46:12 --> Parser Class Initialized
INFO - 2019-12-03 21:46:12 --> User Agent Class Initialized
INFO - 2019-12-03 21:46:12 --> Model Class Initialized
INFO - 2019-12-03 21:46:12 --> Database Driver Class Initialized
INFO - 2019-12-03 21:46:13 --> Model Class Initialized
DEBUG - 2019-12-03 21:46:13 --> Template Class Initialized
INFO - 2019-12-03 21:46:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 21:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 21:46:13 --> Pagination Class Initialized
DEBUG - 2019-12-03 21:46:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 21:46:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 21:46:13 --> Encryption Class Initialized
INFO - 2019-12-03 21:46:13 --> Controller Class Initialized
DEBUG - 2019-12-03 21:46:13 --> package MX_Controller Initialized
DEBUG - 2019-12-03 21:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-03 21:46:13 --> Model Class Initialized
INFO - 2019-12-03 21:46:13 --> Helper loaded: inflector_helper
DEBUG - 2019-12-03 21:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-03 21:46:13 --> blocks MX_Controller Initialized
DEBUG - 2019-12-03 21:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-03 21:46:13 --> Model Class Initialized
DEBUG - 2019-12-03 21:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-03 21:46:13 --> Model Class Initialized
DEBUG - 2019-12-03 21:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-03 21:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-03 21:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-03 21:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-03 21:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-03 21:46:13 --> Final output sent to browser
DEBUG - 2019-12-03 21:46:13 --> Total execution time: 1.3432
INFO - 2019-12-03 21:46:17 --> Config Class Initialized
INFO - 2019-12-03 21:46:17 --> Hooks Class Initialized
DEBUG - 2019-12-03 21:46:17 --> UTF-8 Support Enabled
INFO - 2019-12-03 21:46:17 --> Utf8 Class Initialized
INFO - 2019-12-03 21:46:17 --> URI Class Initialized
INFO - 2019-12-03 21:46:17 --> Router Class Initialized
INFO - 2019-12-03 21:46:17 --> Output Class Initialized
INFO - 2019-12-03 21:46:17 --> Security Class Initialized
DEBUG - 2019-12-03 21:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 21:46:17 --> CSRF cookie sent
INFO - 2019-12-03 21:46:17 --> CSRF token verified
INFO - 2019-12-03 21:46:17 --> Input Class Initialized
INFO - 2019-12-03 21:46:17 --> Language Class Initialized
INFO - 2019-12-03 21:46:17 --> Language Class Initialized
INFO - 2019-12-03 21:46:17 --> Config Class Initialized
INFO - 2019-12-03 21:46:17 --> Loader Class Initialized
INFO - 2019-12-03 21:46:17 --> Helper loaded: url_helper
INFO - 2019-12-03 21:46:17 --> Helper loaded: common_helper
INFO - 2019-12-03 21:46:17 --> Helper loaded: language_helper
INFO - 2019-12-03 21:46:17 --> Helper loaded: cookie_helper
INFO - 2019-12-03 21:46:17 --> Helper loaded: email_helper
INFO - 2019-12-03 21:46:18 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 21:46:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 21:46:18 --> Parser Class Initialized
INFO - 2019-12-03 21:46:18 --> User Agent Class Initialized
INFO - 2019-12-03 21:46:18 --> Model Class Initialized
INFO - 2019-12-03 21:46:18 --> Database Driver Class Initialized
INFO - 2019-12-03 21:46:18 --> Model Class Initialized
DEBUG - 2019-12-03 21:46:18 --> Template Class Initialized
INFO - 2019-12-03 21:46:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 21:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 21:46:18 --> Pagination Class Initialized
DEBUG - 2019-12-03 21:46:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 21:46:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 21:46:18 --> Encryption Class Initialized
INFO - 2019-12-03 21:46:18 --> Controller Class Initialized
DEBUG - 2019-12-03 21:46:18 --> checkout MX_Controller Initialized
DEBUG - 2019-12-03 21:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-03 21:46:18 --> Model Class Initialized
INFO - 2019-12-03 21:46:18 --> Helper loaded: inflector_helper
ERROR - 2019-12-03 21:46:18 --> Could not find the language line "hesabe"
ERROR - 2019-12-03 21:46:18 --> Could not find the language line "payop"
ERROR - 2019-12-03 21:46:18 --> Could not find the language line "shopier"
DEBUG - 2019-12-03 21:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-03 21:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-03 21:46:18 --> blocks MX_Controller Initialized
DEBUG - 2019-12-03 21:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-03 21:46:18 --> Model Class Initialized
DEBUG - 2019-12-03 21:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-03 21:46:18 --> Model Class Initialized
DEBUG - 2019-12-03 21:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-03 21:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-03 21:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-03 21:46:18 --> Final output sent to browser
DEBUG - 2019-12-03 21:46:18 --> Total execution time: 0.7409
INFO - 2019-12-03 21:46:25 --> Config Class Initialized
INFO - 2019-12-03 21:46:25 --> Hooks Class Initialized
DEBUG - 2019-12-03 21:46:25 --> UTF-8 Support Enabled
INFO - 2019-12-03 21:46:25 --> Utf8 Class Initialized
INFO - 2019-12-03 21:46:25 --> URI Class Initialized
INFO - 2019-12-03 21:46:25 --> Router Class Initialized
INFO - 2019-12-03 21:46:25 --> Output Class Initialized
INFO - 2019-12-03 21:46:25 --> Security Class Initialized
DEBUG - 2019-12-03 21:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 21:46:25 --> CSRF cookie sent
INFO - 2019-12-03 21:46:25 --> CSRF token verified
INFO - 2019-12-03 21:46:25 --> Input Class Initialized
INFO - 2019-12-03 21:46:26 --> Language Class Initialized
INFO - 2019-12-03 21:46:26 --> Language Class Initialized
INFO - 2019-12-03 21:46:26 --> Config Class Initialized
INFO - 2019-12-03 21:46:26 --> Loader Class Initialized
INFO - 2019-12-03 21:46:26 --> Helper loaded: url_helper
INFO - 2019-12-03 21:46:26 --> Helper loaded: common_helper
INFO - 2019-12-03 21:46:26 --> Helper loaded: language_helper
INFO - 2019-12-03 21:46:26 --> Helper loaded: cookie_helper
INFO - 2019-12-03 21:46:26 --> Helper loaded: email_helper
INFO - 2019-12-03 21:46:26 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 21:46:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 21:46:26 --> Parser Class Initialized
INFO - 2019-12-03 21:46:26 --> User Agent Class Initialized
INFO - 2019-12-03 21:46:26 --> Model Class Initialized
INFO - 2019-12-03 21:46:26 --> Database Driver Class Initialized
INFO - 2019-12-03 21:46:26 --> Model Class Initialized
DEBUG - 2019-12-03 21:46:26 --> Template Class Initialized
INFO - 2019-12-03 21:46:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 21:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 21:46:26 --> Pagination Class Initialized
DEBUG - 2019-12-03 21:46:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 21:46:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 21:46:26 --> Encryption Class Initialized
INFO - 2019-12-03 21:46:26 --> Controller Class Initialized
DEBUG - 2019-12-03 21:46:26 --> checkout MX_Controller Initialized
DEBUG - 2019-12-03 21:46:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-03 21:46:26 --> Model Class Initialized
DEBUG - 2019-12-03 21:46:26 --> payop MX_Controller Initialized
INFO - 2019-12-03 21:59:56 --> Config Class Initialized
INFO - 2019-12-03 21:59:56 --> Hooks Class Initialized
DEBUG - 2019-12-03 21:59:56 --> UTF-8 Support Enabled
INFO - 2019-12-03 21:59:56 --> Utf8 Class Initialized
INFO - 2019-12-03 21:59:56 --> URI Class Initialized
INFO - 2019-12-03 21:59:56 --> Router Class Initialized
INFO - 2019-12-03 21:59:56 --> Output Class Initialized
INFO - 2019-12-03 21:59:56 --> Security Class Initialized
DEBUG - 2019-12-03 21:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 21:59:57 --> CSRF cookie sent
INFO - 2019-12-03 21:59:57 --> Input Class Initialized
INFO - 2019-12-03 21:59:57 --> Language Class Initialized
INFO - 2019-12-03 21:59:57 --> Language Class Initialized
INFO - 2019-12-03 21:59:57 --> Config Class Initialized
INFO - 2019-12-03 21:59:57 --> Loader Class Initialized
INFO - 2019-12-03 21:59:57 --> Helper loaded: url_helper
INFO - 2019-12-03 21:59:57 --> Helper loaded: common_helper
INFO - 2019-12-03 21:59:57 --> Helper loaded: language_helper
INFO - 2019-12-03 21:59:57 --> Helper loaded: cookie_helper
INFO - 2019-12-03 21:59:57 --> Helper loaded: email_helper
INFO - 2019-12-03 21:59:57 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 21:59:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 21:59:57 --> Parser Class Initialized
INFO - 2019-12-03 21:59:57 --> User Agent Class Initialized
INFO - 2019-12-03 21:59:57 --> Model Class Initialized
INFO - 2019-12-03 21:59:57 --> Database Driver Class Initialized
INFO - 2019-12-03 21:59:57 --> Model Class Initialized
DEBUG - 2019-12-03 21:59:57 --> Template Class Initialized
INFO - 2019-12-03 21:59:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 21:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 21:59:57 --> Pagination Class Initialized
DEBUG - 2019-12-03 21:59:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 21:59:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 21:59:57 --> Encryption Class Initialized
INFO - 2019-12-03 21:59:57 --> Controller Class Initialized
DEBUG - 2019-12-03 21:59:57 --> auth MX_Controller Initialized
DEBUG - 2019-12-03 21:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-03 21:59:57 --> Model Class Initialized
DEBUG - 2019-12-03 21:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-03 21:59:57 --> Helper loaded: inflector_helper
DEBUG - 2019-12-03 21:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-12-03 21:59:57 --> pergo MX_Controller Initialized
DEBUG - 2019-12-03 21:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-03 21:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-12-03 21:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-03 21:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-03 21:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-12-03 21:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-03 21:59:57 --> Final output sent to browser
DEBUG - 2019-12-03 21:59:57 --> Total execution time: 0.6541
INFO - 2019-12-03 22:00:00 --> Config Class Initialized
INFO - 2019-12-03 22:00:00 --> Hooks Class Initialized
DEBUG - 2019-12-03 22:00:00 --> UTF-8 Support Enabled
INFO - 2019-12-03 22:00:00 --> Utf8 Class Initialized
INFO - 2019-12-03 22:00:00 --> URI Class Initialized
INFO - 2019-12-03 22:00:00 --> Router Class Initialized
INFO - 2019-12-03 22:00:00 --> Output Class Initialized
INFO - 2019-12-03 22:00:00 --> Security Class Initialized
DEBUG - 2019-12-03 22:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 22:00:00 --> CSRF cookie sent
INFO - 2019-12-03 22:00:00 --> CSRF token verified
INFO - 2019-12-03 22:00:00 --> Input Class Initialized
INFO - 2019-12-03 22:00:00 --> Language Class Initialized
INFO - 2019-12-03 22:00:00 --> Language Class Initialized
INFO - 2019-12-03 22:00:00 --> Config Class Initialized
INFO - 2019-12-03 22:00:00 --> Loader Class Initialized
INFO - 2019-12-03 22:00:00 --> Helper loaded: url_helper
INFO - 2019-12-03 22:00:00 --> Helper loaded: common_helper
INFO - 2019-12-03 22:00:00 --> Helper loaded: language_helper
INFO - 2019-12-03 22:00:00 --> Helper loaded: cookie_helper
INFO - 2019-12-03 22:00:00 --> Helper loaded: email_helper
INFO - 2019-12-03 22:00:00 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 22:00:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 22:00:00 --> Parser Class Initialized
INFO - 2019-12-03 22:00:00 --> User Agent Class Initialized
INFO - 2019-12-03 22:00:00 --> Model Class Initialized
INFO - 2019-12-03 22:00:00 --> Database Driver Class Initialized
INFO - 2019-12-03 22:00:00 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:00 --> Template Class Initialized
INFO - 2019-12-03 22:00:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 22:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 22:00:00 --> Pagination Class Initialized
DEBUG - 2019-12-03 22:00:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 22:00:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 22:00:00 --> Encryption Class Initialized
INFO - 2019-12-03 22:00:00 --> Controller Class Initialized
DEBUG - 2019-12-03 22:00:00 --> auth MX_Controller Initialized
DEBUG - 2019-12-03 22:00:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-03 22:00:00 --> Model Class Initialized
INFO - 2019-12-03 22:00:05 --> Config Class Initialized
INFO - 2019-12-03 22:00:05 --> Hooks Class Initialized
DEBUG - 2019-12-03 22:00:05 --> UTF-8 Support Enabled
INFO - 2019-12-03 22:00:05 --> Utf8 Class Initialized
INFO - 2019-12-03 22:00:05 --> URI Class Initialized
INFO - 2019-12-03 22:00:05 --> Router Class Initialized
INFO - 2019-12-03 22:00:05 --> Output Class Initialized
INFO - 2019-12-03 22:00:05 --> Security Class Initialized
DEBUG - 2019-12-03 22:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 22:00:05 --> CSRF cookie sent
INFO - 2019-12-03 22:00:05 --> Input Class Initialized
INFO - 2019-12-03 22:00:05 --> Language Class Initialized
INFO - 2019-12-03 22:00:05 --> Language Class Initialized
INFO - 2019-12-03 22:00:05 --> Config Class Initialized
INFO - 2019-12-03 22:00:05 --> Loader Class Initialized
INFO - 2019-12-03 22:00:05 --> Helper loaded: url_helper
INFO - 2019-12-03 22:00:05 --> Helper loaded: common_helper
INFO - 2019-12-03 22:00:05 --> Helper loaded: language_helper
INFO - 2019-12-03 22:00:05 --> Helper loaded: cookie_helper
INFO - 2019-12-03 22:00:05 --> Helper loaded: email_helper
INFO - 2019-12-03 22:00:05 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 22:00:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 22:00:05 --> Parser Class Initialized
INFO - 2019-12-03 22:00:05 --> User Agent Class Initialized
INFO - 2019-12-03 22:00:05 --> Model Class Initialized
INFO - 2019-12-03 22:00:05 --> Database Driver Class Initialized
INFO - 2019-12-03 22:00:05 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:05 --> Template Class Initialized
INFO - 2019-12-03 22:00:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 22:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 22:00:05 --> Pagination Class Initialized
DEBUG - 2019-12-03 22:00:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 22:00:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 22:00:05 --> Encryption Class Initialized
INFO - 2019-12-03 22:00:05 --> Controller Class Initialized
DEBUG - 2019-12-03 22:00:05 --> statistics MX_Controller Initialized
DEBUG - 2019-12-03 22:00:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-03 22:00:05 --> Model Class Initialized
ERROR - 2019-12-03 22:00:05 --> Could not find the language line "Pending"
ERROR - 2019-12-03 22:00:05 --> Could not find the language line "Pending"
INFO - 2019-12-03 22:00:06 --> Helper loaded: inflector_helper
ERROR - 2019-12-03 22:00:06 --> Could not find the language line "total_orders"
ERROR - 2019-12-03 22:00:06 --> Could not find the language line "total_orders"
ERROR - 2019-12-03 22:00:06 --> Could not find the language line "Pending"
DEBUG - 2019-12-03 22:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-12-03 22:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-03 22:00:06 --> blocks MX_Controller Initialized
DEBUG - 2019-12-03 22:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-03 22:00:06 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-03 22:00:06 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-03 22:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-03 22:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-03 22:00:06 --> Final output sent to browser
DEBUG - 2019-12-03 22:00:06 --> Total execution time: 1.0551
INFO - 2019-12-03 22:00:16 --> Config Class Initialized
INFO - 2019-12-03 22:00:16 --> Hooks Class Initialized
DEBUG - 2019-12-03 22:00:16 --> UTF-8 Support Enabled
INFO - 2019-12-03 22:00:16 --> Utf8 Class Initialized
INFO - 2019-12-03 22:00:16 --> URI Class Initialized
INFO - 2019-12-03 22:00:16 --> Router Class Initialized
INFO - 2019-12-03 22:00:16 --> Output Class Initialized
INFO - 2019-12-03 22:00:16 --> Security Class Initialized
DEBUG - 2019-12-03 22:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 22:00:16 --> CSRF cookie sent
INFO - 2019-12-03 22:00:16 --> Input Class Initialized
INFO - 2019-12-03 22:00:16 --> Language Class Initialized
INFO - 2019-12-03 22:00:16 --> Language Class Initialized
INFO - 2019-12-03 22:00:16 --> Config Class Initialized
INFO - 2019-12-03 22:00:16 --> Loader Class Initialized
INFO - 2019-12-03 22:00:16 --> Helper loaded: url_helper
INFO - 2019-12-03 22:00:16 --> Helper loaded: common_helper
INFO - 2019-12-03 22:00:16 --> Helper loaded: language_helper
INFO - 2019-12-03 22:00:16 --> Helper loaded: cookie_helper
INFO - 2019-12-03 22:00:16 --> Helper loaded: email_helper
INFO - 2019-12-03 22:00:16 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 22:00:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 22:00:16 --> Parser Class Initialized
INFO - 2019-12-03 22:00:16 --> User Agent Class Initialized
INFO - 2019-12-03 22:00:16 --> Model Class Initialized
INFO - 2019-12-03 22:00:16 --> Database Driver Class Initialized
INFO - 2019-12-03 22:00:16 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:16 --> Template Class Initialized
INFO - 2019-12-03 22:00:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 22:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 22:00:16 --> Pagination Class Initialized
DEBUG - 2019-12-03 22:00:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 22:00:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 22:00:17 --> Encryption Class Initialized
INFO - 2019-12-03 22:00:17 --> Controller Class Initialized
DEBUG - 2019-12-03 22:00:17 --> setting MX_Controller Initialized
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-03 22:00:17 --> Model Class Initialized
INFO - 2019-12-03 22:00:17 --> Helper loaded: inflector_helper
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-03 22:00:17 --> blocks MX_Controller Initialized
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-03 22:00:17 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-03 22:00:17 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-03 22:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-03 22:00:17 --> Final output sent to browser
DEBUG - 2019-12-03 22:00:17 --> Total execution time: 0.8733
INFO - 2019-12-03 22:00:23 --> Config Class Initialized
INFO - 2019-12-03 22:00:23 --> Hooks Class Initialized
DEBUG - 2019-12-03 22:00:23 --> UTF-8 Support Enabled
INFO - 2019-12-03 22:00:23 --> Utf8 Class Initialized
INFO - 2019-12-03 22:00:23 --> URI Class Initialized
INFO - 2019-12-03 22:00:23 --> Router Class Initialized
INFO - 2019-12-03 22:00:23 --> Output Class Initialized
INFO - 2019-12-03 22:00:23 --> Security Class Initialized
DEBUG - 2019-12-03 22:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 22:00:23 --> CSRF cookie sent
INFO - 2019-12-03 22:00:23 --> Input Class Initialized
INFO - 2019-12-03 22:00:23 --> Language Class Initialized
INFO - 2019-12-03 22:00:23 --> Language Class Initialized
INFO - 2019-12-03 22:00:23 --> Config Class Initialized
INFO - 2019-12-03 22:00:23 --> Loader Class Initialized
INFO - 2019-12-03 22:00:23 --> Helper loaded: url_helper
INFO - 2019-12-03 22:00:23 --> Helper loaded: common_helper
INFO - 2019-12-03 22:00:23 --> Helper loaded: language_helper
INFO - 2019-12-03 22:00:23 --> Helper loaded: cookie_helper
INFO - 2019-12-03 22:00:23 --> Helper loaded: email_helper
INFO - 2019-12-03 22:00:23 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 22:00:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 22:00:23 --> Parser Class Initialized
INFO - 2019-12-03 22:00:23 --> User Agent Class Initialized
INFO - 2019-12-03 22:00:23 --> Model Class Initialized
INFO - 2019-12-03 22:00:23 --> Database Driver Class Initialized
INFO - 2019-12-03 22:00:23 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:23 --> Template Class Initialized
INFO - 2019-12-03 22:00:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 22:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 22:00:23 --> Pagination Class Initialized
DEBUG - 2019-12-03 22:00:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 22:00:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 22:00:23 --> Encryption Class Initialized
INFO - 2019-12-03 22:00:23 --> Controller Class Initialized
DEBUG - 2019-12-03 22:00:23 --> setting MX_Controller Initialized
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-03 22:00:23 --> Model Class Initialized
INFO - 2019-12-03 22:00:23 --> Helper loaded: inflector_helper
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-03 22:00:23 --> blocks MX_Controller Initialized
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-03 22:00:23 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-03 22:00:23 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-03 22:00:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-03 22:00:23 --> Final output sent to browser
DEBUG - 2019-12-03 22:00:23 --> Total execution time: 0.6579
INFO - 2019-12-03 22:00:45 --> Config Class Initialized
INFO - 2019-12-03 22:00:45 --> Hooks Class Initialized
DEBUG - 2019-12-03 22:00:45 --> UTF-8 Support Enabled
INFO - 2019-12-03 22:00:45 --> Utf8 Class Initialized
INFO - 2019-12-03 22:00:45 --> URI Class Initialized
INFO - 2019-12-03 22:00:45 --> Router Class Initialized
INFO - 2019-12-03 22:00:45 --> Output Class Initialized
INFO - 2019-12-03 22:00:45 --> Security Class Initialized
DEBUG - 2019-12-03 22:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 22:00:45 --> CSRF cookie sent
INFO - 2019-12-03 22:00:45 --> CSRF token verified
INFO - 2019-12-03 22:00:45 --> Input Class Initialized
INFO - 2019-12-03 22:00:45 --> Language Class Initialized
INFO - 2019-12-03 22:00:45 --> Language Class Initialized
INFO - 2019-12-03 22:00:45 --> Config Class Initialized
INFO - 2019-12-03 22:00:45 --> Loader Class Initialized
INFO - 2019-12-03 22:00:45 --> Helper loaded: url_helper
INFO - 2019-12-03 22:00:45 --> Helper loaded: common_helper
INFO - 2019-12-03 22:00:45 --> Helper loaded: language_helper
INFO - 2019-12-03 22:00:45 --> Helper loaded: cookie_helper
INFO - 2019-12-03 22:00:45 --> Helper loaded: email_helper
INFO - 2019-12-03 22:00:45 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 22:00:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 22:00:46 --> Parser Class Initialized
INFO - 2019-12-03 22:00:46 --> User Agent Class Initialized
INFO - 2019-12-03 22:00:46 --> Model Class Initialized
INFO - 2019-12-03 22:00:46 --> Database Driver Class Initialized
INFO - 2019-12-03 22:00:46 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:46 --> Template Class Initialized
INFO - 2019-12-03 22:00:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 22:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 22:00:46 --> Pagination Class Initialized
DEBUG - 2019-12-03 22:00:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 22:00:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 22:00:46 --> Encryption Class Initialized
INFO - 2019-12-03 22:00:46 --> Controller Class Initialized
DEBUG - 2019-12-03 22:00:46 --> setting MX_Controller Initialized
DEBUG - 2019-12-03 22:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-03 22:00:46 --> Model Class Initialized
INFO - 2019-12-03 22:00:50 --> Config Class Initialized
INFO - 2019-12-03 22:00:50 --> Hooks Class Initialized
DEBUG - 2019-12-03 22:00:50 --> UTF-8 Support Enabled
INFO - 2019-12-03 22:00:50 --> Utf8 Class Initialized
INFO - 2019-12-03 22:00:50 --> URI Class Initialized
INFO - 2019-12-03 22:00:50 --> Router Class Initialized
INFO - 2019-12-03 22:00:50 --> Output Class Initialized
INFO - 2019-12-03 22:00:50 --> Security Class Initialized
DEBUG - 2019-12-03 22:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 22:00:50 --> CSRF cookie sent
INFO - 2019-12-03 22:00:50 --> Input Class Initialized
INFO - 2019-12-03 22:00:50 --> Language Class Initialized
INFO - 2019-12-03 22:00:50 --> Language Class Initialized
INFO - 2019-12-03 22:00:50 --> Config Class Initialized
INFO - 2019-12-03 22:00:50 --> Loader Class Initialized
INFO - 2019-12-03 22:00:50 --> Helper loaded: url_helper
INFO - 2019-12-03 22:00:50 --> Helper loaded: common_helper
INFO - 2019-12-03 22:00:50 --> Helper loaded: language_helper
INFO - 2019-12-03 22:00:50 --> Helper loaded: cookie_helper
INFO - 2019-12-03 22:00:50 --> Helper loaded: email_helper
INFO - 2019-12-03 22:00:50 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 22:00:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 22:00:51 --> Parser Class Initialized
INFO - 2019-12-03 22:00:51 --> User Agent Class Initialized
INFO - 2019-12-03 22:00:51 --> Model Class Initialized
INFO - 2019-12-03 22:00:51 --> Database Driver Class Initialized
INFO - 2019-12-03 22:00:51 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:51 --> Template Class Initialized
INFO - 2019-12-03 22:00:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 22:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 22:00:51 --> Pagination Class Initialized
DEBUG - 2019-12-03 22:00:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 22:00:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 22:00:51 --> Encryption Class Initialized
INFO - 2019-12-03 22:00:51 --> Controller Class Initialized
DEBUG - 2019-12-03 22:00:51 --> setting MX_Controller Initialized
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-03 22:00:51 --> Model Class Initialized
INFO - 2019-12-03 22:00:51 --> Helper loaded: inflector_helper
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-03 22:00:51 --> blocks MX_Controller Initialized
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-03 22:00:51 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-03 22:00:51 --> Model Class Initialized
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-03 22:00:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-03 22:00:51 --> Final output sent to browser
DEBUG - 2019-12-03 22:00:51 --> Total execution time: 0.6861
INFO - 2019-12-03 22:02:04 --> Config Class Initialized
INFO - 2019-12-03 22:02:04 --> Hooks Class Initialized
DEBUG - 2019-12-03 22:02:04 --> UTF-8 Support Enabled
INFO - 2019-12-03 22:02:05 --> Utf8 Class Initialized
INFO - 2019-12-03 22:02:05 --> URI Class Initialized
INFO - 2019-12-03 22:02:05 --> Router Class Initialized
INFO - 2019-12-03 22:02:05 --> Output Class Initialized
INFO - 2019-12-03 22:02:05 --> Security Class Initialized
DEBUG - 2019-12-03 22:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 22:02:05 --> CSRF cookie sent
INFO - 2019-12-03 22:02:05 --> CSRF token verified
INFO - 2019-12-03 22:02:05 --> Input Class Initialized
INFO - 2019-12-03 22:02:05 --> Language Class Initialized
INFO - 2019-12-03 22:02:05 --> Language Class Initialized
INFO - 2019-12-03 22:02:05 --> Config Class Initialized
INFO - 2019-12-03 22:02:05 --> Loader Class Initialized
INFO - 2019-12-03 22:02:05 --> Helper loaded: url_helper
INFO - 2019-12-03 22:02:05 --> Helper loaded: common_helper
INFO - 2019-12-03 22:02:05 --> Helper loaded: language_helper
INFO - 2019-12-03 22:02:05 --> Helper loaded: cookie_helper
INFO - 2019-12-03 22:02:05 --> Helper loaded: email_helper
INFO - 2019-12-03 22:02:05 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 22:02:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 22:02:05 --> Parser Class Initialized
INFO - 2019-12-03 22:02:05 --> User Agent Class Initialized
INFO - 2019-12-03 22:02:05 --> Model Class Initialized
INFO - 2019-12-03 22:02:05 --> Database Driver Class Initialized
INFO - 2019-12-03 22:02:05 --> Model Class Initialized
DEBUG - 2019-12-03 22:02:05 --> Template Class Initialized
INFO - 2019-12-03 22:02:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 22:02:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 22:02:05 --> Pagination Class Initialized
DEBUG - 2019-12-03 22:02:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 22:02:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 22:02:05 --> Encryption Class Initialized
INFO - 2019-12-03 22:02:05 --> Controller Class Initialized
DEBUG - 2019-12-03 22:02:05 --> checkout MX_Controller Initialized
DEBUG - 2019-12-03 22:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-03 22:02:05 --> Model Class Initialized
INFO - 2019-12-03 22:02:05 --> Helper loaded: inflector_helper
ERROR - 2019-12-03 22:02:05 --> Could not find the language line "hesabe"
ERROR - 2019-12-03 22:02:05 --> Could not find the language line "payop"
ERROR - 2019-12-03 22:02:05 --> Could not find the language line "shopier"
DEBUG - 2019-12-03 22:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-03 22:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-03 22:02:05 --> blocks MX_Controller Initialized
DEBUG - 2019-12-03 22:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-03 22:02:05 --> Model Class Initialized
DEBUG - 2019-12-03 22:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-03 22:02:05 --> Model Class Initialized
DEBUG - 2019-12-03 22:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-03 22:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-03 22:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-03 22:02:05 --> Final output sent to browser
DEBUG - 2019-12-03 22:02:05 --> Total execution time: 0.7642
INFO - 2019-12-03 22:02:18 --> Config Class Initialized
INFO - 2019-12-03 22:02:18 --> Hooks Class Initialized
DEBUG - 2019-12-03 22:02:18 --> UTF-8 Support Enabled
INFO - 2019-12-03 22:02:18 --> Utf8 Class Initialized
INFO - 2019-12-03 22:02:18 --> URI Class Initialized
INFO - 2019-12-03 22:02:19 --> Router Class Initialized
INFO - 2019-12-03 22:02:19 --> Output Class Initialized
INFO - 2019-12-03 22:02:19 --> Security Class Initialized
DEBUG - 2019-12-03 22:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-03 22:02:19 --> CSRF cookie sent
INFO - 2019-12-03 22:02:19 --> CSRF token verified
INFO - 2019-12-03 22:02:19 --> Input Class Initialized
INFO - 2019-12-03 22:02:19 --> Language Class Initialized
INFO - 2019-12-03 22:02:19 --> Language Class Initialized
INFO - 2019-12-03 22:02:19 --> Config Class Initialized
INFO - 2019-12-03 22:02:19 --> Loader Class Initialized
INFO - 2019-12-03 22:02:19 --> Helper loaded: url_helper
INFO - 2019-12-03 22:02:19 --> Helper loaded: common_helper
INFO - 2019-12-03 22:02:19 --> Helper loaded: language_helper
INFO - 2019-12-03 22:02:19 --> Helper loaded: cookie_helper
INFO - 2019-12-03 22:02:19 --> Helper loaded: email_helper
INFO - 2019-12-03 22:02:19 --> Helper loaded: file_manager_helper
INFO - 2019-12-03 22:02:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-03 22:02:19 --> Parser Class Initialized
INFO - 2019-12-03 22:02:19 --> User Agent Class Initialized
INFO - 2019-12-03 22:02:19 --> Model Class Initialized
INFO - 2019-12-03 22:02:19 --> Database Driver Class Initialized
INFO - 2019-12-03 22:02:19 --> Model Class Initialized
DEBUG - 2019-12-03 22:02:19 --> Template Class Initialized
INFO - 2019-12-03 22:02:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-03 22:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-03 22:02:19 --> Pagination Class Initialized
DEBUG - 2019-12-03 22:02:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-03 22:02:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-03 22:02:19 --> Encryption Class Initialized
INFO - 2019-12-03 22:02:19 --> Controller Class Initialized
DEBUG - 2019-12-03 22:02:19 --> checkout MX_Controller Initialized
DEBUG - 2019-12-03 22:02:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-03 22:02:19 --> Model Class Initialized
DEBUG - 2019-12-03 22:02:19 --> payop MX_Controller Initialized
