<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-05 08:58:10 --> Config Class Initialized
INFO - 2019-12-05 08:58:10 --> Hooks Class Initialized
DEBUG - 2019-12-05 08:58:10 --> UTF-8 Support Enabled
INFO - 2019-12-05 08:58:10 --> Utf8 Class Initialized
INFO - 2019-12-05 08:58:10 --> URI Class Initialized
INFO - 2019-12-05 08:58:11 --> Router Class Initialized
INFO - 2019-12-05 08:58:11 --> Output Class Initialized
INFO - 2019-12-05 08:58:11 --> Security Class Initialized
DEBUG - 2019-12-05 08:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 08:58:11 --> CSRF cookie sent
INFO - 2019-12-05 08:58:11 --> Input Class Initialized
INFO - 2019-12-05 08:58:11 --> Language Class Initialized
INFO - 2019-12-05 08:58:11 --> Language Class Initialized
INFO - 2019-12-05 08:58:11 --> Config Class Initialized
INFO - 2019-12-05 08:58:11 --> Loader Class Initialized
INFO - 2019-12-05 08:58:11 --> Helper loaded: url_helper
INFO - 2019-12-05 08:58:11 --> Helper loaded: common_helper
INFO - 2019-12-05 08:58:11 --> Helper loaded: language_helper
INFO - 2019-12-05 08:58:11 --> Helper loaded: cookie_helper
INFO - 2019-12-05 08:58:11 --> Helper loaded: email_helper
INFO - 2019-12-05 08:58:11 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 08:58:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 08:58:11 --> Parser Class Initialized
INFO - 2019-12-05 08:58:11 --> User Agent Class Initialized
DEBUG - 2019-12-05 08:58:11 --> Template Class Initialized
INFO - 2019-12-05 08:58:11 --> Database Driver Class Initialized
INFO - 2019-12-05 08:58:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 08:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 08:58:11 --> Pagination Class Initialized
DEBUG - 2019-12-05 08:58:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 08:58:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 08:58:11 --> Encryption Class Initialized
INFO - 2019-12-05 08:58:11 --> Controller Class Initialized
DEBUG - 2019-12-05 08:58:11 --> payop MX_Controller Initialized
INFO - 2019-12-05 08:58:12 --> Model Class Initialized
INFO - 2019-12-05 08:58:12 --> Model Class Initialized
INFO - 2019-12-05 08:58:12 --> Model Class Initialized
ERROR - 2019-12-05 08:58:13 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-05 08:58:13 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-05 10:28:44 --> Config Class Initialized
INFO - 2019-12-05 10:28:44 --> Hooks Class Initialized
DEBUG - 2019-12-05 10:28:44 --> UTF-8 Support Enabled
INFO - 2019-12-05 10:28:44 --> Utf8 Class Initialized
INFO - 2019-12-05 10:28:44 --> URI Class Initialized
INFO - 2019-12-05 10:28:44 --> Router Class Initialized
INFO - 2019-12-05 10:28:44 --> Output Class Initialized
INFO - 2019-12-05 10:28:44 --> Security Class Initialized
DEBUG - 2019-12-05 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 10:28:44 --> CSRF cookie sent
INFO - 2019-12-05 10:28:44 --> Input Class Initialized
INFO - 2019-12-05 10:28:44 --> Language Class Initialized
INFO - 2019-12-05 10:28:44 --> Language Class Initialized
INFO - 2019-12-05 10:28:44 --> Config Class Initialized
INFO - 2019-12-05 10:28:44 --> Loader Class Initialized
INFO - 2019-12-05 10:28:44 --> Helper loaded: url_helper
INFO - 2019-12-05 10:28:44 --> Helper loaded: common_helper
INFO - 2019-12-05 10:28:44 --> Helper loaded: language_helper
INFO - 2019-12-05 10:28:44 --> Helper loaded: cookie_helper
INFO - 2019-12-05 10:28:44 --> Helper loaded: email_helper
INFO - 2019-12-05 10:28:44 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 10:28:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 10:28:44 --> Parser Class Initialized
INFO - 2019-12-05 10:28:44 --> User Agent Class Initialized
INFO - 2019-12-05 10:28:44 --> Model Class Initialized
INFO - 2019-12-05 10:28:44 --> Database Driver Class Initialized
INFO - 2019-12-05 10:28:44 --> Model Class Initialized
DEBUG - 2019-12-05 10:28:44 --> Template Class Initialized
INFO - 2019-12-05 10:28:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 10:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 10:28:44 --> Pagination Class Initialized
DEBUG - 2019-12-05 10:28:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 10:28:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 10:28:45 --> Encryption Class Initialized
INFO - 2019-12-05 10:28:45 --> Controller Class Initialized
DEBUG - 2019-12-05 10:28:45 --> transactions MX_Controller Initialized
DEBUG - 2019-12-05 10:28:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-05 10:28:46 --> Model Class Initialized
ERROR - 2019-12-05 10:28:46 --> Could not find the language line "order_id"
INFO - 2019-12-05 10:28:46 --> Helper loaded: inflector_helper
DEBUG - 2019-12-05 10:28:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-05 10:28:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-05 10:28:46 --> blocks MX_Controller Initialized
DEBUG - 2019-12-05 10:28:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-05 10:28:48 --> Model Class Initialized
DEBUG - 2019-12-05 10:28:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-05 10:28:48 --> Model Class Initialized
DEBUG - 2019-12-05 10:28:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-05 10:28:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-05 10:28:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-05 10:28:48 --> Final output sent to browser
DEBUG - 2019-12-05 10:28:48 --> Total execution time: 3.7325
INFO - 2019-12-05 10:35:00 --> Config Class Initialized
INFO - 2019-12-05 10:35:00 --> Hooks Class Initialized
DEBUG - 2019-12-05 10:35:00 --> UTF-8 Support Enabled
INFO - 2019-12-05 10:35:00 --> Utf8 Class Initialized
INFO - 2019-12-05 10:35:00 --> URI Class Initialized
INFO - 2019-12-05 10:35:00 --> Router Class Initialized
INFO - 2019-12-05 10:35:00 --> Output Class Initialized
INFO - 2019-12-05 10:35:00 --> Security Class Initialized
DEBUG - 2019-12-05 10:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 10:35:00 --> CSRF cookie sent
INFO - 2019-12-05 10:35:00 --> Input Class Initialized
INFO - 2019-12-05 10:35:00 --> Language Class Initialized
INFO - 2019-12-05 10:35:00 --> Language Class Initialized
INFO - 2019-12-05 10:35:00 --> Config Class Initialized
INFO - 2019-12-05 10:35:00 --> Loader Class Initialized
INFO - 2019-12-05 10:35:00 --> Helper loaded: url_helper
INFO - 2019-12-05 10:35:00 --> Helper loaded: common_helper
INFO - 2019-12-05 10:35:00 --> Helper loaded: language_helper
INFO - 2019-12-05 10:35:01 --> Helper loaded: cookie_helper
INFO - 2019-12-05 10:35:01 --> Helper loaded: email_helper
INFO - 2019-12-05 10:35:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 10:35:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 10:35:01 --> Parser Class Initialized
INFO - 2019-12-05 10:35:01 --> User Agent Class Initialized
DEBUG - 2019-12-05 10:35:01 --> Template Class Initialized
INFO - 2019-12-05 10:35:01 --> Database Driver Class Initialized
INFO - 2019-12-05 10:35:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 10:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 10:35:01 --> Pagination Class Initialized
DEBUG - 2019-12-05 10:35:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 10:35:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 10:35:01 --> Encryption Class Initialized
INFO - 2019-12-05 10:35:01 --> Controller Class Initialized
DEBUG - 2019-12-05 10:35:01 --> payop MX_Controller Initialized
INFO - 2019-12-05 10:35:01 --> Model Class Initialized
INFO - 2019-12-05 10:35:01 --> Model Class Initialized
INFO - 2019-12-05 10:35:01 --> Model Class Initialized
ERROR - 2019-12-05 10:35:01 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-05 10:35:01 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-05 10:42:10 --> Config Class Initialized
INFO - 2019-12-05 10:42:10 --> Hooks Class Initialized
DEBUG - 2019-12-05 10:42:10 --> UTF-8 Support Enabled
INFO - 2019-12-05 10:42:10 --> Utf8 Class Initialized
INFO - 2019-12-05 10:42:10 --> URI Class Initialized
INFO - 2019-12-05 10:42:10 --> Router Class Initialized
INFO - 2019-12-05 10:42:10 --> Output Class Initialized
INFO - 2019-12-05 10:42:10 --> Security Class Initialized
DEBUG - 2019-12-05 10:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 10:42:10 --> CSRF cookie sent
INFO - 2019-12-05 10:42:10 --> Input Class Initialized
INFO - 2019-12-05 10:42:10 --> Language Class Initialized
INFO - 2019-12-05 10:42:10 --> Language Class Initialized
INFO - 2019-12-05 10:42:10 --> Config Class Initialized
INFO - 2019-12-05 10:42:10 --> Loader Class Initialized
INFO - 2019-12-05 10:42:10 --> Helper loaded: url_helper
INFO - 2019-12-05 10:42:10 --> Helper loaded: common_helper
INFO - 2019-12-05 10:42:10 --> Helper loaded: language_helper
INFO - 2019-12-05 10:42:10 --> Helper loaded: cookie_helper
INFO - 2019-12-05 10:42:10 --> Helper loaded: email_helper
INFO - 2019-12-05 10:42:10 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 10:42:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 10:42:10 --> Parser Class Initialized
INFO - 2019-12-05 10:42:10 --> User Agent Class Initialized
DEBUG - 2019-12-05 10:42:10 --> Template Class Initialized
INFO - 2019-12-05 10:42:10 --> Database Driver Class Initialized
INFO - 2019-12-05 10:42:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 10:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 10:42:10 --> Pagination Class Initialized
DEBUG - 2019-12-05 10:42:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 10:42:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 10:42:10 --> Encryption Class Initialized
INFO - 2019-12-05 10:42:10 --> Controller Class Initialized
DEBUG - 2019-12-05 10:42:10 --> payop MX_Controller Initialized
INFO - 2019-12-05 10:42:10 --> Model Class Initialized
INFO - 2019-12-05 10:42:10 --> Model Class Initialized
INFO - 2019-12-05 10:42:10 --> Model Class Initialized
ERROR - 2019-12-05 10:42:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 194
INFO - 2019-12-05 10:42:11 --> Final output sent to browser
DEBUG - 2019-12-05 10:42:11 --> Total execution time: 1.7209
ERROR - 2019-12-05 10:42:11 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-05 10:42:11 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-05 10:45:01 --> Config Class Initialized
INFO - 2019-12-05 10:45:01 --> Hooks Class Initialized
DEBUG - 2019-12-05 10:45:01 --> UTF-8 Support Enabled
INFO - 2019-12-05 10:45:01 --> Utf8 Class Initialized
INFO - 2019-12-05 10:45:01 --> URI Class Initialized
INFO - 2019-12-05 10:45:01 --> Router Class Initialized
INFO - 2019-12-05 10:45:01 --> Output Class Initialized
INFO - 2019-12-05 10:45:01 --> Security Class Initialized
DEBUG - 2019-12-05 10:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 10:45:01 --> CSRF cookie sent
INFO - 2019-12-05 10:45:01 --> Input Class Initialized
INFO - 2019-12-05 10:45:01 --> Language Class Initialized
INFO - 2019-12-05 10:45:01 --> Language Class Initialized
INFO - 2019-12-05 10:45:01 --> Config Class Initialized
INFO - 2019-12-05 10:45:01 --> Loader Class Initialized
INFO - 2019-12-05 10:45:01 --> Helper loaded: url_helper
INFO - 2019-12-05 10:45:01 --> Helper loaded: common_helper
INFO - 2019-12-05 10:45:01 --> Helper loaded: language_helper
INFO - 2019-12-05 10:45:01 --> Helper loaded: cookie_helper
INFO - 2019-12-05 10:45:01 --> Helper loaded: email_helper
INFO - 2019-12-05 10:45:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 10:45:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 10:45:01 --> Parser Class Initialized
INFO - 2019-12-05 10:45:01 --> User Agent Class Initialized
DEBUG - 2019-12-05 10:45:01 --> Template Class Initialized
INFO - 2019-12-05 10:45:01 --> Database Driver Class Initialized
INFO - 2019-12-05 10:45:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 10:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 10:45:01 --> Pagination Class Initialized
DEBUG - 2019-12-05 10:45:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 10:45:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 10:45:01 --> Encryption Class Initialized
INFO - 2019-12-05 10:45:01 --> Controller Class Initialized
DEBUG - 2019-12-05 10:45:01 --> payop MX_Controller Initialized
INFO - 2019-12-05 10:45:01 --> Model Class Initialized
INFO - 2019-12-05 10:45:01 --> Model Class Initialized
INFO - 2019-12-05 10:45:01 --> Model Class Initialized
INFO - 2019-12-05 10:45:03 --> Final output sent to browser
DEBUG - 2019-12-05 10:45:03 --> Total execution time: 1.9894
ERROR - 2019-12-05 10:45:03 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-05 10:45:03 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-05 10:45:29 --> Config Class Initialized
INFO - 2019-12-05 10:45:29 --> Hooks Class Initialized
DEBUG - 2019-12-05 10:45:29 --> UTF-8 Support Enabled
INFO - 2019-12-05 10:45:29 --> Utf8 Class Initialized
INFO - 2019-12-05 10:45:29 --> URI Class Initialized
INFO - 2019-12-05 10:45:29 --> Router Class Initialized
INFO - 2019-12-05 10:45:30 --> Output Class Initialized
INFO - 2019-12-05 10:45:30 --> Security Class Initialized
DEBUG - 2019-12-05 10:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 10:45:30 --> CSRF cookie sent
INFO - 2019-12-05 10:45:30 --> Input Class Initialized
INFO - 2019-12-05 10:45:30 --> Language Class Initialized
INFO - 2019-12-05 10:45:30 --> Language Class Initialized
INFO - 2019-12-05 10:45:30 --> Config Class Initialized
INFO - 2019-12-05 10:45:30 --> Loader Class Initialized
INFO - 2019-12-05 10:45:30 --> Helper loaded: url_helper
INFO - 2019-12-05 10:45:30 --> Helper loaded: common_helper
INFO - 2019-12-05 10:45:30 --> Helper loaded: language_helper
INFO - 2019-12-05 10:45:30 --> Helper loaded: cookie_helper
INFO - 2019-12-05 10:45:30 --> Helper loaded: email_helper
INFO - 2019-12-05 10:45:30 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 10:45:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 10:45:30 --> Parser Class Initialized
INFO - 2019-12-05 10:45:30 --> User Agent Class Initialized
DEBUG - 2019-12-05 10:45:30 --> Template Class Initialized
INFO - 2019-12-05 10:45:30 --> Database Driver Class Initialized
INFO - 2019-12-05 10:45:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 10:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 10:45:30 --> Pagination Class Initialized
DEBUG - 2019-12-05 10:45:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 10:45:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 10:45:30 --> Encryption Class Initialized
INFO - 2019-12-05 10:45:30 --> Controller Class Initialized
DEBUG - 2019-12-05 10:45:30 --> payop MX_Controller Initialized
INFO - 2019-12-05 10:45:30 --> Model Class Initialized
INFO - 2019-12-05 10:45:30 --> Model Class Initialized
INFO - 2019-12-05 10:45:30 --> Model Class Initialized
ERROR - 2019-12-05 10:45:31 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-05 10:45:31 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-05 10:49:35 --> Config Class Initialized
INFO - 2019-12-05 10:49:35 --> Hooks Class Initialized
DEBUG - 2019-12-05 10:49:35 --> UTF-8 Support Enabled
INFO - 2019-12-05 10:49:35 --> Utf8 Class Initialized
INFO - 2019-12-05 10:49:35 --> URI Class Initialized
INFO - 2019-12-05 10:49:35 --> Router Class Initialized
INFO - 2019-12-05 10:49:35 --> Output Class Initialized
INFO - 2019-12-05 10:49:35 --> Security Class Initialized
DEBUG - 2019-12-05 10:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 10:49:35 --> CSRF cookie sent
INFO - 2019-12-05 10:49:35 --> Input Class Initialized
INFO - 2019-12-05 10:49:35 --> Language Class Initialized
INFO - 2019-12-05 10:49:35 --> Language Class Initialized
INFO - 2019-12-05 10:49:35 --> Config Class Initialized
INFO - 2019-12-05 10:49:35 --> Loader Class Initialized
INFO - 2019-12-05 10:49:35 --> Helper loaded: url_helper
INFO - 2019-12-05 10:49:35 --> Helper loaded: common_helper
INFO - 2019-12-05 10:49:35 --> Helper loaded: language_helper
INFO - 2019-12-05 10:49:35 --> Helper loaded: cookie_helper
INFO - 2019-12-05 10:49:35 --> Helper loaded: email_helper
INFO - 2019-12-05 10:49:35 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 10:49:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 10:49:35 --> Parser Class Initialized
INFO - 2019-12-05 10:49:35 --> User Agent Class Initialized
DEBUG - 2019-12-05 10:49:35 --> Template Class Initialized
INFO - 2019-12-05 10:49:35 --> Database Driver Class Initialized
INFO - 2019-12-05 10:49:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 10:49:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 10:49:35 --> Pagination Class Initialized
DEBUG - 2019-12-05 10:49:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 10:49:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 10:49:35 --> Encryption Class Initialized
INFO - 2019-12-05 10:49:35 --> Controller Class Initialized
DEBUG - 2019-12-05 10:49:35 --> payop MX_Controller Initialized
INFO - 2019-12-05 10:49:35 --> Model Class Initialized
INFO - 2019-12-05 10:49:35 --> Model Class Initialized
INFO - 2019-12-05 10:49:35 --> Model Class Initialized
ERROR - 2019-12-05 10:49:36 --> Severity: Notice --> Undefined variable: tx_status D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 205
ERROR - 2019-12-05 10:49:36 --> Severity: Notice --> Undefined variable: tx_status D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 205
INFO - 2019-12-05 10:49:36 --> Final output sent to browser
DEBUG - 2019-12-05 10:49:36 --> Total execution time: 1.5826
ERROR - 2019-12-05 10:49:36 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-05 10:49:36 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-05 10:50:05 --> Config Class Initialized
INFO - 2019-12-05 10:50:05 --> Hooks Class Initialized
DEBUG - 2019-12-05 10:50:05 --> UTF-8 Support Enabled
INFO - 2019-12-05 10:50:05 --> Utf8 Class Initialized
INFO - 2019-12-05 10:50:05 --> URI Class Initialized
INFO - 2019-12-05 10:50:05 --> Router Class Initialized
INFO - 2019-12-05 10:50:05 --> Output Class Initialized
INFO - 2019-12-05 10:50:05 --> Security Class Initialized
DEBUG - 2019-12-05 10:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 10:50:05 --> CSRF cookie sent
INFO - 2019-12-05 10:50:05 --> Input Class Initialized
INFO - 2019-12-05 10:50:05 --> Language Class Initialized
INFO - 2019-12-05 10:50:05 --> Language Class Initialized
INFO - 2019-12-05 10:50:05 --> Config Class Initialized
INFO - 2019-12-05 10:50:05 --> Loader Class Initialized
INFO - 2019-12-05 10:50:06 --> Helper loaded: url_helper
INFO - 2019-12-05 10:50:06 --> Helper loaded: common_helper
INFO - 2019-12-05 10:50:06 --> Helper loaded: language_helper
INFO - 2019-12-05 10:50:06 --> Helper loaded: cookie_helper
INFO - 2019-12-05 10:50:06 --> Helper loaded: email_helper
INFO - 2019-12-05 10:50:06 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 10:50:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 10:50:06 --> Parser Class Initialized
INFO - 2019-12-05 10:50:06 --> User Agent Class Initialized
DEBUG - 2019-12-05 10:50:06 --> Template Class Initialized
INFO - 2019-12-05 10:50:06 --> Database Driver Class Initialized
INFO - 2019-12-05 10:50:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 10:50:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 10:50:06 --> Pagination Class Initialized
DEBUG - 2019-12-05 10:50:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 10:50:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 10:50:06 --> Encryption Class Initialized
INFO - 2019-12-05 10:50:06 --> Controller Class Initialized
DEBUG - 2019-12-05 10:50:06 --> payop MX_Controller Initialized
INFO - 2019-12-05 10:50:06 --> Model Class Initialized
INFO - 2019-12-05 10:50:06 --> Model Class Initialized
INFO - 2019-12-05 10:50:06 --> Model Class Initialized
INFO - 2019-12-05 10:50:08 --> Final output sent to browser
DEBUG - 2019-12-05 10:50:08 --> Total execution time: 2.2114
ERROR - 2019-12-05 10:50:08 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-05 10:50:08 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-05 11:13:01 --> Config Class Initialized
INFO - 2019-12-05 11:13:01 --> Hooks Class Initialized
DEBUG - 2019-12-05 11:13:01 --> UTF-8 Support Enabled
INFO - 2019-12-05 11:13:01 --> Utf8 Class Initialized
INFO - 2019-12-05 11:13:01 --> URI Class Initialized
INFO - 2019-12-05 11:13:01 --> Router Class Initialized
INFO - 2019-12-05 11:13:01 --> Output Class Initialized
INFO - 2019-12-05 11:13:01 --> Security Class Initialized
DEBUG - 2019-12-05 11:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 11:13:01 --> CSRF cookie sent
INFO - 2019-12-05 11:13:01 --> Input Class Initialized
INFO - 2019-12-05 11:13:01 --> Language Class Initialized
INFO - 2019-12-05 11:13:01 --> Language Class Initialized
INFO - 2019-12-05 11:13:01 --> Config Class Initialized
INFO - 2019-12-05 11:13:01 --> Loader Class Initialized
INFO - 2019-12-05 11:13:01 --> Helper loaded: url_helper
INFO - 2019-12-05 11:13:01 --> Helper loaded: common_helper
INFO - 2019-12-05 11:13:01 --> Helper loaded: language_helper
INFO - 2019-12-05 11:13:02 --> Helper loaded: cookie_helper
INFO - 2019-12-05 11:13:02 --> Helper loaded: email_helper
INFO - 2019-12-05 11:13:02 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 11:13:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 11:13:02 --> Parser Class Initialized
INFO - 2019-12-05 11:13:02 --> User Agent Class Initialized
INFO - 2019-12-05 11:13:02 --> Model Class Initialized
INFO - 2019-12-05 11:13:02 --> Database Driver Class Initialized
INFO - 2019-12-05 11:13:02 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:02 --> Template Class Initialized
INFO - 2019-12-05 11:13:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 11:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 11:13:02 --> Pagination Class Initialized
DEBUG - 2019-12-05 11:13:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 11:13:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 11:13:02 --> Encryption Class Initialized
INFO - 2019-12-05 11:13:02 --> Controller Class Initialized
DEBUG - 2019-12-05 11:13:02 --> transactions MX_Controller Initialized
DEBUG - 2019-12-05 11:13:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-05 11:13:02 --> Model Class Initialized
ERROR - 2019-12-05 11:13:02 --> Could not find the language line "order_id"
INFO - 2019-12-05 11:13:02 --> Helper loaded: inflector_helper
DEBUG - 2019-12-05 11:13:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-05 11:13:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-05 11:13:02 --> blocks MX_Controller Initialized
DEBUG - 2019-12-05 11:13:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-05 11:13:02 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-05 11:13:02 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-05 11:13:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-05 11:13:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-05 11:13:02 --> Final output sent to browser
DEBUG - 2019-12-05 11:13:02 --> Total execution time: 0.7302
INFO - 2019-12-05 11:13:05 --> Config Class Initialized
INFO - 2019-12-05 11:13:05 --> Hooks Class Initialized
DEBUG - 2019-12-05 11:13:05 --> UTF-8 Support Enabled
INFO - 2019-12-05 11:13:05 --> Utf8 Class Initialized
INFO - 2019-12-05 11:13:05 --> URI Class Initialized
DEBUG - 2019-12-05 11:13:05 --> No URI present. Default controller set.
INFO - 2019-12-05 11:13:05 --> Router Class Initialized
INFO - 2019-12-05 11:13:05 --> Output Class Initialized
INFO - 2019-12-05 11:13:05 --> Security Class Initialized
DEBUG - 2019-12-05 11:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 11:13:05 --> CSRF cookie sent
INFO - 2019-12-05 11:13:05 --> Input Class Initialized
INFO - 2019-12-05 11:13:05 --> Language Class Initialized
INFO - 2019-12-05 11:13:05 --> Language Class Initialized
INFO - 2019-12-05 11:13:05 --> Config Class Initialized
INFO - 2019-12-05 11:13:05 --> Loader Class Initialized
INFO - 2019-12-05 11:13:05 --> Helper loaded: url_helper
INFO - 2019-12-05 11:13:05 --> Helper loaded: common_helper
INFO - 2019-12-05 11:13:05 --> Helper loaded: language_helper
INFO - 2019-12-05 11:13:05 --> Helper loaded: cookie_helper
INFO - 2019-12-05 11:13:05 --> Helper loaded: email_helper
INFO - 2019-12-05 11:13:05 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 11:13:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 11:13:05 --> Parser Class Initialized
INFO - 2019-12-05 11:13:05 --> User Agent Class Initialized
INFO - 2019-12-05 11:13:05 --> Model Class Initialized
INFO - 2019-12-05 11:13:05 --> Database Driver Class Initialized
INFO - 2019-12-05 11:13:05 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:05 --> Template Class Initialized
INFO - 2019-12-05 11:13:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 11:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 11:13:06 --> Pagination Class Initialized
DEBUG - 2019-12-05 11:13:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 11:13:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 11:13:06 --> Encryption Class Initialized
DEBUG - 2019-12-05 11:13:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-05 11:13:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-05 11:13:06 --> Controller Class Initialized
DEBUG - 2019-12-05 11:13:06 --> pergo MX_Controller Initialized
DEBUG - 2019-12-05 11:13:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-05 11:13:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-05 11:13:06 --> Model Class Initialized
INFO - 2019-12-05 11:13:06 --> Helper loaded: inflector_helper
DEBUG - 2019-12-05 11:13:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-05 11:13:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-05 11:13:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-05 11:13:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-05 11:13:06 --> Final output sent to browser
DEBUG - 2019-12-05 11:13:06 --> Total execution time: 0.9281
INFO - 2019-12-05 11:13:09 --> Config Class Initialized
INFO - 2019-12-05 11:13:09 --> Hooks Class Initialized
DEBUG - 2019-12-05 11:13:09 --> UTF-8 Support Enabled
INFO - 2019-12-05 11:13:09 --> Utf8 Class Initialized
INFO - 2019-12-05 11:13:10 --> URI Class Initialized
INFO - 2019-12-05 11:13:10 --> Router Class Initialized
INFO - 2019-12-05 11:13:10 --> Output Class Initialized
INFO - 2019-12-05 11:13:10 --> Security Class Initialized
DEBUG - 2019-12-05 11:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 11:13:10 --> CSRF cookie sent
INFO - 2019-12-05 11:13:10 --> Input Class Initialized
INFO - 2019-12-05 11:13:10 --> Language Class Initialized
INFO - 2019-12-05 11:13:10 --> Language Class Initialized
INFO - 2019-12-05 11:13:10 --> Config Class Initialized
INFO - 2019-12-05 11:13:10 --> Loader Class Initialized
INFO - 2019-12-05 11:13:10 --> Helper loaded: url_helper
INFO - 2019-12-05 11:13:10 --> Helper loaded: common_helper
INFO - 2019-12-05 11:13:10 --> Helper loaded: language_helper
INFO - 2019-12-05 11:13:10 --> Helper loaded: cookie_helper
INFO - 2019-12-05 11:13:10 --> Helper loaded: email_helper
INFO - 2019-12-05 11:13:10 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 11:13:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 11:13:10 --> Parser Class Initialized
INFO - 2019-12-05 11:13:10 --> User Agent Class Initialized
INFO - 2019-12-05 11:13:10 --> Model Class Initialized
INFO - 2019-12-05 11:13:10 --> Database Driver Class Initialized
INFO - 2019-12-05 11:13:10 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:10 --> Template Class Initialized
INFO - 2019-12-05 11:13:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 11:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 11:13:10 --> Pagination Class Initialized
DEBUG - 2019-12-05 11:13:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 11:13:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 11:13:10 --> Encryption Class Initialized
INFO - 2019-12-05 11:13:10 --> Controller Class Initialized
DEBUG - 2019-12-05 11:13:10 --> package MX_Controller Initialized
DEBUG - 2019-12-05 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-05 11:13:10 --> Model Class Initialized
INFO - 2019-12-05 11:13:10 --> Helper loaded: inflector_helper
DEBUG - 2019-12-05 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-05 11:13:10 --> blocks MX_Controller Initialized
DEBUG - 2019-12-05 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-05 11:13:10 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-05 11:13:10 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-05 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-05 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-05 11:13:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-05 11:13:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-05 11:13:11 --> Final output sent to browser
DEBUG - 2019-12-05 11:13:11 --> Total execution time: 1.1959
INFO - 2019-12-05 11:13:14 --> Config Class Initialized
INFO - 2019-12-05 11:13:14 --> Hooks Class Initialized
DEBUG - 2019-12-05 11:13:14 --> UTF-8 Support Enabled
INFO - 2019-12-05 11:13:14 --> Utf8 Class Initialized
INFO - 2019-12-05 11:13:14 --> URI Class Initialized
INFO - 2019-12-05 11:13:14 --> Router Class Initialized
INFO - 2019-12-05 11:13:14 --> Output Class Initialized
INFO - 2019-12-05 11:13:14 --> Security Class Initialized
DEBUG - 2019-12-05 11:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 11:13:14 --> CSRF cookie sent
INFO - 2019-12-05 11:13:14 --> CSRF token verified
INFO - 2019-12-05 11:13:14 --> Input Class Initialized
INFO - 2019-12-05 11:13:14 --> Language Class Initialized
INFO - 2019-12-05 11:13:14 --> Language Class Initialized
INFO - 2019-12-05 11:13:14 --> Config Class Initialized
INFO - 2019-12-05 11:13:14 --> Loader Class Initialized
INFO - 2019-12-05 11:13:14 --> Helper loaded: url_helper
INFO - 2019-12-05 11:13:14 --> Helper loaded: common_helper
INFO - 2019-12-05 11:13:14 --> Helper loaded: language_helper
INFO - 2019-12-05 11:13:14 --> Helper loaded: cookie_helper
INFO - 2019-12-05 11:13:14 --> Helper loaded: email_helper
INFO - 2019-12-05 11:13:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 11:13:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 11:13:14 --> Parser Class Initialized
INFO - 2019-12-05 11:13:14 --> User Agent Class Initialized
INFO - 2019-12-05 11:13:14 --> Model Class Initialized
INFO - 2019-12-05 11:13:14 --> Database Driver Class Initialized
INFO - 2019-12-05 11:13:14 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:14 --> Template Class Initialized
INFO - 2019-12-05 11:13:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 11:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 11:13:14 --> Pagination Class Initialized
DEBUG - 2019-12-05 11:13:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 11:13:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 11:13:14 --> Encryption Class Initialized
INFO - 2019-12-05 11:13:14 --> Controller Class Initialized
DEBUG - 2019-12-05 11:13:14 --> checkout MX_Controller Initialized
DEBUG - 2019-12-05 11:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-05 11:13:14 --> Model Class Initialized
INFO - 2019-12-05 11:13:14 --> Helper loaded: inflector_helper
ERROR - 2019-12-05 11:13:14 --> Could not find the language line "hesabe"
ERROR - 2019-12-05 11:13:14 --> Could not find the language line "payop"
ERROR - 2019-12-05 11:13:14 --> Could not find the language line "shopier"
DEBUG - 2019-12-05 11:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-05 11:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-05 11:13:14 --> blocks MX_Controller Initialized
DEBUG - 2019-12-05 11:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-05 11:13:14 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-05 11:13:14 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-05 11:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-05 11:13:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-05 11:13:14 --> Final output sent to browser
DEBUG - 2019-12-05 11:13:14 --> Total execution time: 0.7672
INFO - 2019-12-05 11:13:26 --> Config Class Initialized
INFO - 2019-12-05 11:13:26 --> Hooks Class Initialized
DEBUG - 2019-12-05 11:13:26 --> UTF-8 Support Enabled
INFO - 2019-12-05 11:13:26 --> Utf8 Class Initialized
INFO - 2019-12-05 11:13:26 --> URI Class Initialized
INFO - 2019-12-05 11:13:26 --> Router Class Initialized
INFO - 2019-12-05 11:13:26 --> Output Class Initialized
INFO - 2019-12-05 11:13:26 --> Security Class Initialized
DEBUG - 2019-12-05 11:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 11:13:26 --> CSRF cookie sent
INFO - 2019-12-05 11:13:26 --> CSRF token verified
INFO - 2019-12-05 11:13:26 --> Input Class Initialized
INFO - 2019-12-05 11:13:26 --> Language Class Initialized
INFO - 2019-12-05 11:13:26 --> Language Class Initialized
INFO - 2019-12-05 11:13:26 --> Config Class Initialized
INFO - 2019-12-05 11:13:26 --> Loader Class Initialized
INFO - 2019-12-05 11:13:26 --> Helper loaded: url_helper
INFO - 2019-12-05 11:13:26 --> Helper loaded: common_helper
INFO - 2019-12-05 11:13:26 --> Helper loaded: language_helper
INFO - 2019-12-05 11:13:26 --> Helper loaded: cookie_helper
INFO - 2019-12-05 11:13:26 --> Helper loaded: email_helper
INFO - 2019-12-05 11:13:26 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 11:13:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 11:13:26 --> Parser Class Initialized
INFO - 2019-12-05 11:13:26 --> User Agent Class Initialized
INFO - 2019-12-05 11:13:26 --> Model Class Initialized
INFO - 2019-12-05 11:13:26 --> Database Driver Class Initialized
INFO - 2019-12-05 11:13:26 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:26 --> Template Class Initialized
INFO - 2019-12-05 11:13:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 11:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 11:13:26 --> Pagination Class Initialized
DEBUG - 2019-12-05 11:13:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 11:13:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 11:13:26 --> Encryption Class Initialized
INFO - 2019-12-05 11:13:26 --> Controller Class Initialized
DEBUG - 2019-12-05 11:13:26 --> checkout MX_Controller Initialized
DEBUG - 2019-12-05 11:13:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-05 11:13:26 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:26 --> payop MX_Controller Initialized
DEBUG - 2019-12-05 11:13:27 --> orders MX_Controller Initialized
DEBUG - 2019-12-05 11:13:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payop/index.php
INFO - 2019-12-05 11:13:27 --> Final output sent to browser
DEBUG - 2019-12-05 11:13:27 --> Total execution time: 1.6741
INFO - 2019-12-05 11:13:48 --> Config Class Initialized
INFO - 2019-12-05 11:13:48 --> Hooks Class Initialized
DEBUG - 2019-12-05 11:13:48 --> UTF-8 Support Enabled
INFO - 2019-12-05 11:13:48 --> Utf8 Class Initialized
INFO - 2019-12-05 11:13:48 --> URI Class Initialized
INFO - 2019-12-05 11:13:48 --> Router Class Initialized
INFO - 2019-12-05 11:13:48 --> Output Class Initialized
INFO - 2019-12-05 11:13:48 --> Security Class Initialized
DEBUG - 2019-12-05 11:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-05 11:13:48 --> CSRF cookie sent
INFO - 2019-12-05 11:13:48 --> Input Class Initialized
INFO - 2019-12-05 11:13:48 --> Language Class Initialized
INFO - 2019-12-05 11:13:48 --> Language Class Initialized
INFO - 2019-12-05 11:13:48 --> Config Class Initialized
INFO - 2019-12-05 11:13:48 --> Loader Class Initialized
INFO - 2019-12-05 11:13:48 --> Helper loaded: url_helper
INFO - 2019-12-05 11:13:48 --> Helper loaded: common_helper
INFO - 2019-12-05 11:13:48 --> Helper loaded: language_helper
INFO - 2019-12-05 11:13:48 --> Helper loaded: cookie_helper
INFO - 2019-12-05 11:13:48 --> Helper loaded: email_helper
INFO - 2019-12-05 11:13:48 --> Helper loaded: file_manager_helper
INFO - 2019-12-05 11:13:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-05 11:13:48 --> Parser Class Initialized
INFO - 2019-12-05 11:13:48 --> User Agent Class Initialized
INFO - 2019-12-05 11:13:48 --> Model Class Initialized
INFO - 2019-12-05 11:13:48 --> Database Driver Class Initialized
INFO - 2019-12-05 11:13:48 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:48 --> Template Class Initialized
INFO - 2019-12-05 11:13:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-05 11:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-05 11:13:48 --> Pagination Class Initialized
DEBUG - 2019-12-05 11:13:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-05 11:13:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-05 11:13:48 --> Encryption Class Initialized
INFO - 2019-12-05 11:13:48 --> Controller Class Initialized
DEBUG - 2019-12-05 11:13:48 --> transactions MX_Controller Initialized
DEBUG - 2019-12-05 11:13:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-05 11:13:48 --> Model Class Initialized
ERROR - 2019-12-05 11:13:48 --> Could not find the language line "order_id"
INFO - 2019-12-05 11:13:48 --> Helper loaded: inflector_helper
DEBUG - 2019-12-05 11:13:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-05 11:13:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-05 11:13:48 --> blocks MX_Controller Initialized
DEBUG - 2019-12-05 11:13:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-05 11:13:48 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-05 11:13:48 --> Model Class Initialized
DEBUG - 2019-12-05 11:13:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-05 11:13:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-05 11:13:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-05 11:13:48 --> Final output sent to browser
DEBUG - 2019-12-05 11:13:48 --> Total execution time: 0.6991
