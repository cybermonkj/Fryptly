<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-07 00:00:29 --> Config Class Initialized
INFO - 2019-11-07 00:00:29 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:00:29 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:00:29 --> Utf8 Class Initialized
INFO - 2019-11-07 00:00:29 --> URI Class Initialized
INFO - 2019-11-07 00:00:29 --> Router Class Initialized
INFO - 2019-11-07 00:00:29 --> Output Class Initialized
INFO - 2019-11-07 00:00:29 --> Security Class Initialized
DEBUG - 2019-11-07 00:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:00:29 --> Input Class Initialized
INFO - 2019-11-07 00:00:29 --> Language Class Initialized
INFO - 2019-11-07 00:00:29 --> Language Class Initialized
INFO - 2019-11-07 00:00:29 --> Config Class Initialized
INFO - 2019-11-07 00:00:29 --> Loader Class Initialized
INFO - 2019-11-07 00:00:29 --> Helper loaded: url_helper
INFO - 2019-11-07 00:00:29 --> Helper loaded: common_helper
INFO - 2019-11-07 00:00:29 --> Helper loaded: language_helper
INFO - 2019-11-07 00:00:29 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:00:29 --> Helper loaded: email_helper
INFO - 2019-11-07 00:00:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:00:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:00:29 --> Parser Class Initialized
INFO - 2019-11-07 00:00:29 --> User Agent Class Initialized
INFO - 2019-11-07 00:00:29 --> Model Class Initialized
INFO - 2019-11-07 00:00:29 --> Database Driver Class Initialized
INFO - 2019-11-07 00:00:30 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:30 --> Template Class Initialized
INFO - 2019-11-07 00:00:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:00:30 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:00:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:00:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:00:30 --> Encryption Class Initialized
INFO - 2019-11-07 00:00:30 --> Controller Class Initialized
DEBUG - 2019-11-07 00:00:30 --> mollie MX_Controller Initialized
INFO - 2019-11-07 00:00:30 --> Config Class Initialized
INFO - 2019-11-07 00:00:30 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:00:30 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:00:30 --> Utf8 Class Initialized
INFO - 2019-11-07 00:00:30 --> URI Class Initialized
DEBUG - 2019-11-07 00:00:30 --> No URI present. Default controller set.
INFO - 2019-11-07 00:00:30 --> Router Class Initialized
INFO - 2019-11-07 00:00:30 --> Output Class Initialized
INFO - 2019-11-07 00:00:30 --> Security Class Initialized
DEBUG - 2019-11-07 00:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:00:30 --> CSRF cookie sent
INFO - 2019-11-07 00:00:30 --> Input Class Initialized
INFO - 2019-11-07 00:00:30 --> Language Class Initialized
INFO - 2019-11-07 00:00:30 --> Language Class Initialized
INFO - 2019-11-07 00:00:30 --> Config Class Initialized
INFO - 2019-11-07 00:00:30 --> Loader Class Initialized
INFO - 2019-11-07 00:00:30 --> Helper loaded: url_helper
INFO - 2019-11-07 00:00:30 --> Helper loaded: common_helper
INFO - 2019-11-07 00:00:30 --> Helper loaded: language_helper
INFO - 2019-11-07 00:00:30 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:00:30 --> Helper loaded: email_helper
INFO - 2019-11-07 00:00:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:00:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:00:30 --> Parser Class Initialized
INFO - 2019-11-07 00:00:30 --> User Agent Class Initialized
INFO - 2019-11-07 00:00:30 --> Model Class Initialized
INFO - 2019-11-07 00:00:30 --> Database Driver Class Initialized
INFO - 2019-11-07 00:00:30 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:31 --> Template Class Initialized
INFO - 2019-11-07 00:00:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:00:31 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:00:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:00:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:00:31 --> Encryption Class Initialized
DEBUG - 2019-11-07 00:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-07 00:00:31 --> Controller Class Initialized
DEBUG - 2019-11-07 00:00:31 --> pergo MX_Controller Initialized
DEBUG - 2019-11-07 00:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-07 00:00:31 --> Model Class Initialized
INFO - 2019-11-07 00:00:31 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-07 00:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-07 00:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-07 00:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-07 00:00:31 --> Final output sent to browser
DEBUG - 2019-11-07 00:00:31 --> Total execution time: 1.3966
INFO - 2019-11-07 00:00:40 --> Config Class Initialized
INFO - 2019-11-07 00:00:40 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:00:40 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:00:40 --> Utf8 Class Initialized
INFO - 2019-11-07 00:00:40 --> URI Class Initialized
INFO - 2019-11-07 00:00:40 --> Router Class Initialized
INFO - 2019-11-07 00:00:40 --> Output Class Initialized
INFO - 2019-11-07 00:00:40 --> Security Class Initialized
DEBUG - 2019-11-07 00:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:00:40 --> CSRF cookie sent
INFO - 2019-11-07 00:00:40 --> Input Class Initialized
INFO - 2019-11-07 00:00:40 --> Language Class Initialized
INFO - 2019-11-07 00:00:40 --> Language Class Initialized
INFO - 2019-11-07 00:00:40 --> Config Class Initialized
INFO - 2019-11-07 00:00:40 --> Loader Class Initialized
INFO - 2019-11-07 00:00:40 --> Helper loaded: url_helper
INFO - 2019-11-07 00:00:40 --> Helper loaded: common_helper
INFO - 2019-11-07 00:00:40 --> Helper loaded: language_helper
INFO - 2019-11-07 00:00:40 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:00:40 --> Helper loaded: email_helper
INFO - 2019-11-07 00:00:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:00:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:00:40 --> Parser Class Initialized
INFO - 2019-11-07 00:00:40 --> User Agent Class Initialized
INFO - 2019-11-07 00:00:40 --> Model Class Initialized
INFO - 2019-11-07 00:00:40 --> Database Driver Class Initialized
INFO - 2019-11-07 00:00:41 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:41 --> Template Class Initialized
INFO - 2019-11-07 00:00:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:00:41 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:00:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:00:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:00:41 --> Encryption Class Initialized
INFO - 2019-11-07 00:00:41 --> Controller Class Initialized
DEBUG - 2019-11-07 00:00:41 --> package MX_Controller Initialized
DEBUG - 2019-11-07 00:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-07 00:00:41 --> Model Class Initialized
INFO - 2019-11-07 00:00:41 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:00:41 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:00:41 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:00:41 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-07 00:00:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-07 00:00:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:00:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:00:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:00:42 --> Final output sent to browser
DEBUG - 2019-11-07 00:00:42 --> Total execution time: 2.7908
INFO - 2019-11-07 00:00:45 --> Config Class Initialized
INFO - 2019-11-07 00:00:45 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:00:45 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:00:45 --> Utf8 Class Initialized
INFO - 2019-11-07 00:00:46 --> URI Class Initialized
INFO - 2019-11-07 00:00:46 --> Router Class Initialized
INFO - 2019-11-07 00:00:46 --> Output Class Initialized
INFO - 2019-11-07 00:00:46 --> Security Class Initialized
DEBUG - 2019-11-07 00:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:00:46 --> CSRF cookie sent
INFO - 2019-11-07 00:00:46 --> CSRF token verified
INFO - 2019-11-07 00:00:46 --> Input Class Initialized
INFO - 2019-11-07 00:00:46 --> Language Class Initialized
INFO - 2019-11-07 00:00:46 --> Language Class Initialized
INFO - 2019-11-07 00:00:46 --> Config Class Initialized
INFO - 2019-11-07 00:00:46 --> Loader Class Initialized
INFO - 2019-11-07 00:00:46 --> Helper loaded: url_helper
INFO - 2019-11-07 00:00:46 --> Helper loaded: common_helper
INFO - 2019-11-07 00:00:46 --> Helper loaded: language_helper
INFO - 2019-11-07 00:00:46 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:00:46 --> Helper loaded: email_helper
INFO - 2019-11-07 00:00:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:00:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:00:46 --> Parser Class Initialized
INFO - 2019-11-07 00:00:46 --> User Agent Class Initialized
INFO - 2019-11-07 00:00:46 --> Model Class Initialized
INFO - 2019-11-07 00:00:46 --> Database Driver Class Initialized
INFO - 2019-11-07 00:00:46 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:46 --> Template Class Initialized
INFO - 2019-11-07 00:00:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:00:46 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:00:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:00:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:00:46 --> Encryption Class Initialized
INFO - 2019-11-07 00:00:46 --> Controller Class Initialized
DEBUG - 2019-11-07 00:00:46 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:00:46 --> Model Class Initialized
INFO - 2019-11-07 00:00:46 --> Helper loaded: inflector_helper
ERROR - 2019-11-07 00:00:46 --> Could not find the language line "dotpay"
ERROR - 2019-11-07 00:00:46 --> Could not find the language line "paytm"
DEBUG - 2019-11-07 00:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-07 00:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:00:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:00:47 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:00:47 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:00:47 --> Final output sent to browser
DEBUG - 2019-11-07 00:00:47 --> Total execution time: 1.4353
INFO - 2019-11-07 00:00:54 --> Config Class Initialized
INFO - 2019-11-07 00:00:54 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:00:54 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:00:54 --> Utf8 Class Initialized
INFO - 2019-11-07 00:00:54 --> URI Class Initialized
INFO - 2019-11-07 00:00:54 --> Router Class Initialized
INFO - 2019-11-07 00:00:54 --> Output Class Initialized
INFO - 2019-11-07 00:00:54 --> Security Class Initialized
DEBUG - 2019-11-07 00:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:00:54 --> CSRF cookie sent
INFO - 2019-11-07 00:00:54 --> CSRF token verified
INFO - 2019-11-07 00:00:54 --> Input Class Initialized
INFO - 2019-11-07 00:00:54 --> Language Class Initialized
INFO - 2019-11-07 00:00:54 --> Language Class Initialized
INFO - 2019-11-07 00:00:54 --> Config Class Initialized
INFO - 2019-11-07 00:00:54 --> Loader Class Initialized
INFO - 2019-11-07 00:00:54 --> Helper loaded: url_helper
INFO - 2019-11-07 00:00:54 --> Helper loaded: common_helper
INFO - 2019-11-07 00:00:54 --> Helper loaded: language_helper
INFO - 2019-11-07 00:00:54 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:00:54 --> Helper loaded: email_helper
INFO - 2019-11-07 00:00:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:00:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:00:55 --> Parser Class Initialized
INFO - 2019-11-07 00:00:55 --> User Agent Class Initialized
INFO - 2019-11-07 00:00:55 --> Model Class Initialized
INFO - 2019-11-07 00:00:55 --> Database Driver Class Initialized
INFO - 2019-11-07 00:00:55 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:55 --> Template Class Initialized
INFO - 2019-11-07 00:00:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:00:55 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:00:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:00:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:00:55 --> Encryption Class Initialized
INFO - 2019-11-07 00:00:55 --> Controller Class Initialized
DEBUG - 2019-11-07 00:00:55 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:00:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:00:55 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-07 00:00:55 --> Final output sent to browser
DEBUG - 2019-11-07 00:00:55 --> Total execution time: 0.8752
INFO - 2019-11-07 00:00:55 --> Config Class Initialized
INFO - 2019-11-07 00:00:55 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:00:55 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:00:55 --> Utf8 Class Initialized
INFO - 2019-11-07 00:00:55 --> URI Class Initialized
INFO - 2019-11-07 00:00:55 --> Router Class Initialized
INFO - 2019-11-07 00:00:55 --> Output Class Initialized
INFO - 2019-11-07 00:00:55 --> Security Class Initialized
DEBUG - 2019-11-07 00:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:00:55 --> Input Class Initialized
INFO - 2019-11-07 00:00:55 --> Language Class Initialized
INFO - 2019-11-07 00:00:55 --> Language Class Initialized
INFO - 2019-11-07 00:00:55 --> Config Class Initialized
INFO - 2019-11-07 00:00:55 --> Loader Class Initialized
INFO - 2019-11-07 00:00:55 --> Helper loaded: url_helper
INFO - 2019-11-07 00:00:55 --> Helper loaded: common_helper
INFO - 2019-11-07 00:00:55 --> Helper loaded: language_helper
INFO - 2019-11-07 00:00:55 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:00:55 --> Helper loaded: email_helper
INFO - 2019-11-07 00:00:55 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:00:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:00:55 --> Parser Class Initialized
INFO - 2019-11-07 00:00:55 --> User Agent Class Initialized
INFO - 2019-11-07 00:00:55 --> Model Class Initialized
INFO - 2019-11-07 00:00:56 --> Database Driver Class Initialized
INFO - 2019-11-07 00:00:56 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:56 --> Template Class Initialized
INFO - 2019-11-07 00:00:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:00:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:00:56 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:00:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:00:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:00:56 --> Encryption Class Initialized
INFO - 2019-11-07 00:00:56 --> Controller Class Initialized
DEBUG - 2019-11-07 00:00:56 --> mollie MX_Controller Initialized
INFO - 2019-11-07 00:00:56 --> Config Class Initialized
INFO - 2019-11-07 00:00:56 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:00:56 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:00:56 --> Utf8 Class Initialized
INFO - 2019-11-07 00:00:56 --> URI Class Initialized
DEBUG - 2019-11-07 00:00:56 --> No URI present. Default controller set.
INFO - 2019-11-07 00:00:56 --> Router Class Initialized
INFO - 2019-11-07 00:00:56 --> Output Class Initialized
INFO - 2019-11-07 00:00:56 --> Security Class Initialized
DEBUG - 2019-11-07 00:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:00:56 --> CSRF cookie sent
INFO - 2019-11-07 00:00:56 --> Input Class Initialized
INFO - 2019-11-07 00:00:56 --> Language Class Initialized
INFO - 2019-11-07 00:00:56 --> Language Class Initialized
INFO - 2019-11-07 00:00:56 --> Config Class Initialized
INFO - 2019-11-07 00:00:56 --> Loader Class Initialized
INFO - 2019-11-07 00:00:56 --> Helper loaded: url_helper
INFO - 2019-11-07 00:00:56 --> Helper loaded: common_helper
INFO - 2019-11-07 00:00:56 --> Helper loaded: language_helper
INFO - 2019-11-07 00:00:56 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:00:56 --> Helper loaded: email_helper
INFO - 2019-11-07 00:00:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:00:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:00:56 --> Parser Class Initialized
INFO - 2019-11-07 00:00:56 --> User Agent Class Initialized
INFO - 2019-11-07 00:00:56 --> Model Class Initialized
INFO - 2019-11-07 00:00:56 --> Database Driver Class Initialized
INFO - 2019-11-07 00:00:56 --> Model Class Initialized
DEBUG - 2019-11-07 00:00:56 --> Template Class Initialized
INFO - 2019-11-07 00:00:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:00:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:00:56 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:00:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:00:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:00:57 --> Encryption Class Initialized
DEBUG - 2019-11-07 00:00:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:00:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-07 00:00:57 --> Controller Class Initialized
DEBUG - 2019-11-07 00:00:57 --> pergo MX_Controller Initialized
DEBUG - 2019-11-07 00:00:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:00:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-07 00:00:57 --> Model Class Initialized
INFO - 2019-11-07 00:00:57 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:00:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-07 00:00:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-07 00:00:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-07 00:00:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-07 00:00:57 --> Final output sent to browser
DEBUG - 2019-11-07 00:00:57 --> Total execution time: 1.2270
INFO - 2019-11-07 00:01:14 --> Config Class Initialized
INFO - 2019-11-07 00:01:14 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:01:14 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:01:14 --> Utf8 Class Initialized
INFO - 2019-11-07 00:01:14 --> URI Class Initialized
INFO - 2019-11-07 00:01:14 --> Router Class Initialized
INFO - 2019-11-07 00:01:14 --> Output Class Initialized
INFO - 2019-11-07 00:01:14 --> Security Class Initialized
DEBUG - 2019-11-07 00:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:01:14 --> CSRF cookie sent
INFO - 2019-11-07 00:01:14 --> Input Class Initialized
INFO - 2019-11-07 00:01:14 --> Language Class Initialized
INFO - 2019-11-07 00:01:14 --> Language Class Initialized
INFO - 2019-11-07 00:01:15 --> Config Class Initialized
INFO - 2019-11-07 00:01:15 --> Loader Class Initialized
INFO - 2019-11-07 00:01:15 --> Helper loaded: url_helper
INFO - 2019-11-07 00:01:15 --> Helper loaded: common_helper
INFO - 2019-11-07 00:01:15 --> Helper loaded: language_helper
INFO - 2019-11-07 00:01:15 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:01:15 --> Helper loaded: email_helper
INFO - 2019-11-07 00:01:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:01:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:01:15 --> Parser Class Initialized
INFO - 2019-11-07 00:01:15 --> User Agent Class Initialized
INFO - 2019-11-07 00:01:15 --> Model Class Initialized
INFO - 2019-11-07 00:01:15 --> Database Driver Class Initialized
INFO - 2019-11-07 00:01:15 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:15 --> Template Class Initialized
INFO - 2019-11-07 00:01:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:01:15 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:01:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:01:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:01:15 --> Encryption Class Initialized
INFO - 2019-11-07 00:01:16 --> Controller Class Initialized
DEBUG - 2019-11-07 00:01:16 --> package MX_Controller Initialized
DEBUG - 2019-11-07 00:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-07 00:01:16 --> Model Class Initialized
INFO - 2019-11-07 00:01:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:01:16 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:01:16 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:01:16 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-07 00:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-07 00:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:01:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:01:17 --> Final output sent to browser
DEBUG - 2019-11-07 00:01:17 --> Total execution time: 2.6350
INFO - 2019-11-07 00:01:20 --> Config Class Initialized
INFO - 2019-11-07 00:01:20 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:01:20 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:01:20 --> Utf8 Class Initialized
INFO - 2019-11-07 00:01:20 --> URI Class Initialized
INFO - 2019-11-07 00:01:20 --> Router Class Initialized
INFO - 2019-11-07 00:01:20 --> Output Class Initialized
INFO - 2019-11-07 00:01:20 --> Security Class Initialized
DEBUG - 2019-11-07 00:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:01:20 --> CSRF cookie sent
INFO - 2019-11-07 00:01:20 --> CSRF token verified
INFO - 2019-11-07 00:01:20 --> Input Class Initialized
INFO - 2019-11-07 00:01:20 --> Language Class Initialized
INFO - 2019-11-07 00:01:20 --> Language Class Initialized
INFO - 2019-11-07 00:01:20 --> Config Class Initialized
INFO - 2019-11-07 00:01:20 --> Loader Class Initialized
INFO - 2019-11-07 00:01:20 --> Helper loaded: url_helper
INFO - 2019-11-07 00:01:20 --> Helper loaded: common_helper
INFO - 2019-11-07 00:01:20 --> Helper loaded: language_helper
INFO - 2019-11-07 00:01:20 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:01:20 --> Helper loaded: email_helper
INFO - 2019-11-07 00:01:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:01:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:01:20 --> Parser Class Initialized
INFO - 2019-11-07 00:01:20 --> User Agent Class Initialized
INFO - 2019-11-07 00:01:20 --> Model Class Initialized
INFO - 2019-11-07 00:01:20 --> Database Driver Class Initialized
INFO - 2019-11-07 00:01:20 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:20 --> Template Class Initialized
INFO - 2019-11-07 00:01:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:01:20 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:01:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:01:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:01:20 --> Encryption Class Initialized
INFO - 2019-11-07 00:01:20 --> Controller Class Initialized
DEBUG - 2019-11-07 00:01:20 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:01:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:01:20 --> Model Class Initialized
INFO - 2019-11-07 00:01:20 --> Helper loaded: inflector_helper
ERROR - 2019-11-07 00:01:21 --> Could not find the language line "dotpay"
ERROR - 2019-11-07 00:01:21 --> Could not find the language line "paytm"
DEBUG - 2019-11-07 00:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-07 00:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:01:21 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:01:21 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:01:21 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:01:21 --> Final output sent to browser
DEBUG - 2019-11-07 00:01:21 --> Total execution time: 1.4448
INFO - 2019-11-07 00:01:27 --> Config Class Initialized
INFO - 2019-11-07 00:01:27 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:01:27 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:01:27 --> Utf8 Class Initialized
INFO - 2019-11-07 00:01:28 --> URI Class Initialized
INFO - 2019-11-07 00:01:28 --> Router Class Initialized
INFO - 2019-11-07 00:01:28 --> Output Class Initialized
INFO - 2019-11-07 00:01:28 --> Security Class Initialized
DEBUG - 2019-11-07 00:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:01:28 --> CSRF cookie sent
INFO - 2019-11-07 00:01:28 --> CSRF token verified
INFO - 2019-11-07 00:01:28 --> Input Class Initialized
INFO - 2019-11-07 00:01:28 --> Language Class Initialized
INFO - 2019-11-07 00:01:28 --> Language Class Initialized
INFO - 2019-11-07 00:01:28 --> Config Class Initialized
INFO - 2019-11-07 00:01:28 --> Loader Class Initialized
INFO - 2019-11-07 00:01:28 --> Helper loaded: url_helper
INFO - 2019-11-07 00:01:28 --> Helper loaded: common_helper
INFO - 2019-11-07 00:01:28 --> Helper loaded: language_helper
INFO - 2019-11-07 00:01:28 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:01:28 --> Helper loaded: email_helper
INFO - 2019-11-07 00:01:28 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:01:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:01:28 --> Parser Class Initialized
INFO - 2019-11-07 00:01:28 --> User Agent Class Initialized
INFO - 2019-11-07 00:01:28 --> Model Class Initialized
INFO - 2019-11-07 00:01:28 --> Database Driver Class Initialized
INFO - 2019-11-07 00:01:28 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:28 --> Template Class Initialized
INFO - 2019-11-07 00:01:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:01:28 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:01:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:01:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:01:28 --> Encryption Class Initialized
INFO - 2019-11-07 00:01:28 --> Controller Class Initialized
DEBUG - 2019-11-07 00:01:28 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:01:28 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/index.php
INFO - 2019-11-07 00:01:28 --> Final output sent to browser
DEBUG - 2019-11-07 00:01:28 --> Total execution time: 1.0453
INFO - 2019-11-07 00:01:29 --> Config Class Initialized
INFO - 2019-11-07 00:01:29 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:01:29 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:01:29 --> Utf8 Class Initialized
INFO - 2019-11-07 00:01:29 --> URI Class Initialized
INFO - 2019-11-07 00:01:29 --> Router Class Initialized
INFO - 2019-11-07 00:01:29 --> Output Class Initialized
INFO - 2019-11-07 00:01:29 --> Security Class Initialized
DEBUG - 2019-11-07 00:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:01:29 --> Input Class Initialized
INFO - 2019-11-07 00:01:29 --> Language Class Initialized
INFO - 2019-11-07 00:01:29 --> Language Class Initialized
INFO - 2019-11-07 00:01:29 --> Config Class Initialized
INFO - 2019-11-07 00:01:29 --> Loader Class Initialized
INFO - 2019-11-07 00:01:29 --> Helper loaded: url_helper
INFO - 2019-11-07 00:01:29 --> Helper loaded: common_helper
INFO - 2019-11-07 00:01:29 --> Helper loaded: language_helper
INFO - 2019-11-07 00:01:29 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:01:29 --> Helper loaded: email_helper
INFO - 2019-11-07 00:01:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:01:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:01:29 --> Parser Class Initialized
INFO - 2019-11-07 00:01:29 --> User Agent Class Initialized
INFO - 2019-11-07 00:01:29 --> Model Class Initialized
INFO - 2019-11-07 00:01:29 --> Database Driver Class Initialized
INFO - 2019-11-07 00:01:29 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:29 --> Template Class Initialized
INFO - 2019-11-07 00:01:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:01:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:01:29 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:01:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:01:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:01:30 --> Encryption Class Initialized
INFO - 2019-11-07 00:01:30 --> Controller Class Initialized
DEBUG - 2019-11-07 00:01:30 --> cardinity MX_Controller Initialized
INFO - 2019-11-07 00:01:30 --> Config Class Initialized
INFO - 2019-11-07 00:01:30 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:01:30 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:01:30 --> Utf8 Class Initialized
INFO - 2019-11-07 00:01:30 --> URI Class Initialized
DEBUG - 2019-11-07 00:01:30 --> No URI present. Default controller set.
INFO - 2019-11-07 00:01:30 --> Router Class Initialized
INFO - 2019-11-07 00:01:30 --> Output Class Initialized
INFO - 2019-11-07 00:01:30 --> Security Class Initialized
DEBUG - 2019-11-07 00:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:01:30 --> CSRF cookie sent
INFO - 2019-11-07 00:01:30 --> Input Class Initialized
INFO - 2019-11-07 00:01:30 --> Language Class Initialized
INFO - 2019-11-07 00:01:30 --> Language Class Initialized
INFO - 2019-11-07 00:01:30 --> Config Class Initialized
INFO - 2019-11-07 00:01:30 --> Loader Class Initialized
INFO - 2019-11-07 00:01:30 --> Helper loaded: url_helper
INFO - 2019-11-07 00:01:30 --> Helper loaded: common_helper
INFO - 2019-11-07 00:01:30 --> Helper loaded: language_helper
INFO - 2019-11-07 00:01:30 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:01:30 --> Helper loaded: email_helper
INFO - 2019-11-07 00:01:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:01:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:01:30 --> Parser Class Initialized
INFO - 2019-11-07 00:01:30 --> User Agent Class Initialized
INFO - 2019-11-07 00:01:30 --> Model Class Initialized
INFO - 2019-11-07 00:01:30 --> Database Driver Class Initialized
INFO - 2019-11-07 00:01:31 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:31 --> Template Class Initialized
INFO - 2019-11-07 00:01:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:01:31 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:01:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:01:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:01:31 --> Encryption Class Initialized
DEBUG - 2019-11-07 00:01:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:01:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-07 00:01:31 --> Controller Class Initialized
DEBUG - 2019-11-07 00:01:31 --> pergo MX_Controller Initialized
DEBUG - 2019-11-07 00:01:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:01:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-07 00:01:31 --> Model Class Initialized
INFO - 2019-11-07 00:01:31 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:01:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-07 00:01:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-07 00:01:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-07 00:01:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-07 00:01:31 --> Final output sent to browser
DEBUG - 2019-11-07 00:01:31 --> Total execution time: 1.7779
INFO - 2019-11-07 00:01:56 --> Config Class Initialized
INFO - 2019-11-07 00:01:56 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:01:56 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:01:56 --> Utf8 Class Initialized
INFO - 2019-11-07 00:01:56 --> URI Class Initialized
INFO - 2019-11-07 00:01:56 --> Router Class Initialized
INFO - 2019-11-07 00:01:56 --> Output Class Initialized
INFO - 2019-11-07 00:01:56 --> Security Class Initialized
DEBUG - 2019-11-07 00:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:01:56 --> CSRF cookie sent
INFO - 2019-11-07 00:01:56 --> Input Class Initialized
INFO - 2019-11-07 00:01:56 --> Language Class Initialized
INFO - 2019-11-07 00:01:56 --> Language Class Initialized
INFO - 2019-11-07 00:01:56 --> Config Class Initialized
INFO - 2019-11-07 00:01:56 --> Loader Class Initialized
INFO - 2019-11-07 00:01:56 --> Helper loaded: url_helper
INFO - 2019-11-07 00:01:56 --> Helper loaded: common_helper
INFO - 2019-11-07 00:01:56 --> Helper loaded: language_helper
INFO - 2019-11-07 00:01:56 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:01:56 --> Helper loaded: email_helper
INFO - 2019-11-07 00:01:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:01:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:01:56 --> Parser Class Initialized
INFO - 2019-11-07 00:01:57 --> User Agent Class Initialized
INFO - 2019-11-07 00:01:57 --> Model Class Initialized
INFO - 2019-11-07 00:01:57 --> Database Driver Class Initialized
INFO - 2019-11-07 00:01:57 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:57 --> Template Class Initialized
INFO - 2019-11-07 00:01:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:01:57 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:01:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:01:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:01:57 --> Encryption Class Initialized
INFO - 2019-11-07 00:01:57 --> Controller Class Initialized
DEBUG - 2019-11-07 00:01:57 --> package MX_Controller Initialized
DEBUG - 2019-11-07 00:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-07 00:01:57 --> Model Class Initialized
INFO - 2019-11-07 00:01:57 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:01:57 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:01:57 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:01:57 --> Model Class Initialized
DEBUG - 2019-11-07 00:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-07 00:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-07 00:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:01:57 --> Final output sent to browser
DEBUG - 2019-11-07 00:01:57 --> Total execution time: 1.5527
INFO - 2019-11-07 00:02:04 --> Config Class Initialized
INFO - 2019-11-07 00:02:04 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:04 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:04 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:04 --> URI Class Initialized
INFO - 2019-11-07 00:02:04 --> Router Class Initialized
INFO - 2019-11-07 00:02:04 --> Output Class Initialized
INFO - 2019-11-07 00:02:04 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:04 --> CSRF cookie sent
INFO - 2019-11-07 00:02:04 --> Input Class Initialized
INFO - 2019-11-07 00:02:04 --> Language Class Initialized
INFO - 2019-11-07 00:02:04 --> Language Class Initialized
INFO - 2019-11-07 00:02:04 --> Config Class Initialized
INFO - 2019-11-07 00:02:04 --> Loader Class Initialized
INFO - 2019-11-07 00:02:04 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:04 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:04 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:04 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:04 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:05 --> Parser Class Initialized
INFO - 2019-11-07 00:02:05 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:05 --> Model Class Initialized
INFO - 2019-11-07 00:02:05 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:05 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:05 --> Template Class Initialized
INFO - 2019-11-07 00:02:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:05 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:05 --> Encryption Class Initialized
INFO - 2019-11-07 00:02:05 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:05 --> package MX_Controller Initialized
DEBUG - 2019-11-07 00:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-07 00:02:05 --> Model Class Initialized
INFO - 2019-11-07 00:02:05 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:02:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:02:05 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:02:05 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-07 00:02:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-07 00:02:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:02:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:02:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:02:06 --> Final output sent to browser
DEBUG - 2019-11-07 00:02:06 --> Total execution time: 1.8568
INFO - 2019-11-07 00:02:09 --> Config Class Initialized
INFO - 2019-11-07 00:02:09 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:09 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:09 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:10 --> URI Class Initialized
INFO - 2019-11-07 00:02:10 --> Router Class Initialized
INFO - 2019-11-07 00:02:10 --> Output Class Initialized
INFO - 2019-11-07 00:02:10 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:10 --> CSRF cookie sent
INFO - 2019-11-07 00:02:10 --> CSRF token verified
INFO - 2019-11-07 00:02:10 --> Input Class Initialized
INFO - 2019-11-07 00:02:10 --> Language Class Initialized
INFO - 2019-11-07 00:02:10 --> Language Class Initialized
INFO - 2019-11-07 00:02:10 --> Config Class Initialized
INFO - 2019-11-07 00:02:10 --> Loader Class Initialized
INFO - 2019-11-07 00:02:10 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:10 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:10 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:10 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:10 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:10 --> Parser Class Initialized
INFO - 2019-11-07 00:02:10 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:10 --> Model Class Initialized
INFO - 2019-11-07 00:02:10 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:10 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:10 --> Template Class Initialized
INFO - 2019-11-07 00:02:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:10 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:10 --> Encryption Class Initialized
INFO - 2019-11-07 00:02:10 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:10 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:02:10 --> Model Class Initialized
INFO - 2019-11-07 00:02:10 --> Helper loaded: inflector_helper
ERROR - 2019-11-07 00:02:11 --> Could not find the language line "dotpay"
ERROR - 2019-11-07 00:02:11 --> Could not find the language line "paytm"
DEBUG - 2019-11-07 00:02:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-07 00:02:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:02:11 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:02:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:02:11 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:02:11 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:02:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:02:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:02:11 --> Final output sent to browser
DEBUG - 2019-11-07 00:02:11 --> Total execution time: 1.6776
INFO - 2019-11-07 00:02:19 --> Config Class Initialized
INFO - 2019-11-07 00:02:19 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:19 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:19 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:19 --> URI Class Initialized
INFO - 2019-11-07 00:02:19 --> Router Class Initialized
INFO - 2019-11-07 00:02:19 --> Output Class Initialized
INFO - 2019-11-07 00:02:19 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:20 --> CSRF cookie sent
INFO - 2019-11-07 00:02:20 --> CSRF token verified
INFO - 2019-11-07 00:02:20 --> Input Class Initialized
INFO - 2019-11-07 00:02:20 --> Language Class Initialized
INFO - 2019-11-07 00:02:20 --> Language Class Initialized
INFO - 2019-11-07 00:02:20 --> Config Class Initialized
INFO - 2019-11-07 00:02:20 --> Loader Class Initialized
INFO - 2019-11-07 00:02:20 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:20 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:20 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:20 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:20 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:20 --> Parser Class Initialized
INFO - 2019-11-07 00:02:20 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:20 --> Model Class Initialized
INFO - 2019-11-07 00:02:20 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:20 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:20 --> Template Class Initialized
INFO - 2019-11-07 00:02:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:20 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:20 --> Encryption Class Initialized
INFO - 2019-11-07 00:02:20 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:20 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:02:20 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-07 00:02:20 --> Final output sent to browser
DEBUG - 2019-11-07 00:02:20 --> Total execution time: 0.9978
INFO - 2019-11-07 00:02:20 --> Config Class Initialized
INFO - 2019-11-07 00:02:20 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:20 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:20 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:20 --> URI Class Initialized
INFO - 2019-11-07 00:02:21 --> Router Class Initialized
INFO - 2019-11-07 00:02:21 --> Output Class Initialized
INFO - 2019-11-07 00:02:21 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:21 --> Input Class Initialized
INFO - 2019-11-07 00:02:21 --> Language Class Initialized
INFO - 2019-11-07 00:02:21 --> Language Class Initialized
INFO - 2019-11-07 00:02:21 --> Config Class Initialized
INFO - 2019-11-07 00:02:21 --> Loader Class Initialized
INFO - 2019-11-07 00:02:21 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:21 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:21 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:21 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:21 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:21 --> Parser Class Initialized
INFO - 2019-11-07 00:02:21 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:21 --> Model Class Initialized
INFO - 2019-11-07 00:02:21 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:21 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:21 --> Template Class Initialized
INFO - 2019-11-07 00:02:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:21 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:21 --> Encryption Class Initialized
INFO - 2019-11-07 00:02:21 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:21 --> paytm MX_Controller Initialized
INFO - 2019-11-07 00:02:22 --> Config Class Initialized
INFO - 2019-11-07 00:02:22 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:22 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:22 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:22 --> URI Class Initialized
DEBUG - 2019-11-07 00:02:22 --> No URI present. Default controller set.
INFO - 2019-11-07 00:02:22 --> Router Class Initialized
INFO - 2019-11-07 00:02:22 --> Output Class Initialized
INFO - 2019-11-07 00:02:22 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:22 --> CSRF cookie sent
INFO - 2019-11-07 00:02:22 --> Input Class Initialized
INFO - 2019-11-07 00:02:22 --> Language Class Initialized
INFO - 2019-11-07 00:02:22 --> Language Class Initialized
INFO - 2019-11-07 00:02:22 --> Config Class Initialized
INFO - 2019-11-07 00:02:22 --> Loader Class Initialized
INFO - 2019-11-07 00:02:22 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:22 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:22 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:22 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:22 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:22 --> Parser Class Initialized
INFO - 2019-11-07 00:02:22 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:22 --> Model Class Initialized
INFO - 2019-11-07 00:02:22 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:22 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:22 --> Template Class Initialized
INFO - 2019-11-07 00:02:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:23 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:23 --> Encryption Class Initialized
DEBUG - 2019-11-07 00:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-07 00:02:23 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:23 --> pergo MX_Controller Initialized
DEBUG - 2019-11-07 00:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-07 00:02:23 --> Model Class Initialized
INFO - 2019-11-07 00:02:23 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-07 00:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-07 00:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-07 00:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-07 00:02:23 --> Final output sent to browser
DEBUG - 2019-11-07 00:02:23 --> Total execution time: 1.7962
INFO - 2019-11-07 00:02:28 --> Config Class Initialized
INFO - 2019-11-07 00:02:28 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:28 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:28 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:28 --> URI Class Initialized
INFO - 2019-11-07 00:02:29 --> Router Class Initialized
INFO - 2019-11-07 00:02:29 --> Output Class Initialized
INFO - 2019-11-07 00:02:29 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:29 --> CSRF cookie sent
INFO - 2019-11-07 00:02:29 --> Input Class Initialized
INFO - 2019-11-07 00:02:29 --> Language Class Initialized
INFO - 2019-11-07 00:02:29 --> Language Class Initialized
INFO - 2019-11-07 00:02:29 --> Config Class Initialized
INFO - 2019-11-07 00:02:29 --> Loader Class Initialized
INFO - 2019-11-07 00:02:29 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:29 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:29 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:29 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:29 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:29 --> Parser Class Initialized
INFO - 2019-11-07 00:02:29 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:29 --> Model Class Initialized
INFO - 2019-11-07 00:02:29 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:29 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:29 --> Template Class Initialized
INFO - 2019-11-07 00:02:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:29 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:29 --> Encryption Class Initialized
INFO - 2019-11-07 00:02:29 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:29 --> package MX_Controller Initialized
DEBUG - 2019-11-07 00:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-07 00:02:29 --> Model Class Initialized
INFO - 2019-11-07 00:02:29 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:02:30 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:02:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:02:30 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:02:30 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-07 00:02:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-07 00:02:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:02:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:02:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:02:30 --> Final output sent to browser
DEBUG - 2019-11-07 00:02:30 --> Total execution time: 1.7421
INFO - 2019-11-07 00:02:34 --> Config Class Initialized
INFO - 2019-11-07 00:02:34 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:34 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:34 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:34 --> URI Class Initialized
INFO - 2019-11-07 00:02:34 --> Router Class Initialized
INFO - 2019-11-07 00:02:34 --> Output Class Initialized
INFO - 2019-11-07 00:02:34 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:34 --> CSRF cookie sent
INFO - 2019-11-07 00:02:34 --> CSRF token verified
INFO - 2019-11-07 00:02:34 --> Input Class Initialized
INFO - 2019-11-07 00:02:34 --> Language Class Initialized
INFO - 2019-11-07 00:02:34 --> Language Class Initialized
INFO - 2019-11-07 00:02:34 --> Config Class Initialized
INFO - 2019-11-07 00:02:34 --> Loader Class Initialized
INFO - 2019-11-07 00:02:34 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:34 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:34 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:34 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:34 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:34 --> Parser Class Initialized
INFO - 2019-11-07 00:02:34 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:34 --> Model Class Initialized
INFO - 2019-11-07 00:02:34 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:34 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:34 --> Template Class Initialized
INFO - 2019-11-07 00:02:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:34 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:35 --> Encryption Class Initialized
INFO - 2019-11-07 00:02:35 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:35 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:02:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:02:35 --> Model Class Initialized
INFO - 2019-11-07 00:02:35 --> Helper loaded: inflector_helper
ERROR - 2019-11-07 00:02:35 --> Could not find the language line "dotpay"
ERROR - 2019-11-07 00:02:35 --> Could not find the language line "paytm"
DEBUG - 2019-11-07 00:02:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-07 00:02:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:02:35 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:02:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:02:35 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:02:35 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:02:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:02:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:02:35 --> Final output sent to browser
DEBUG - 2019-11-07 00:02:35 --> Total execution time: 1.3525
INFO - 2019-11-07 00:02:43 --> Config Class Initialized
INFO - 2019-11-07 00:02:43 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:43 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:43 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:43 --> URI Class Initialized
INFO - 2019-11-07 00:02:43 --> Router Class Initialized
INFO - 2019-11-07 00:02:43 --> Output Class Initialized
INFO - 2019-11-07 00:02:43 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:43 --> CSRF cookie sent
INFO - 2019-11-07 00:02:43 --> CSRF token verified
INFO - 2019-11-07 00:02:43 --> Input Class Initialized
INFO - 2019-11-07 00:02:43 --> Language Class Initialized
INFO - 2019-11-07 00:02:43 --> Language Class Initialized
INFO - 2019-11-07 00:02:43 --> Config Class Initialized
INFO - 2019-11-07 00:02:43 --> Loader Class Initialized
INFO - 2019-11-07 00:02:43 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:43 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:43 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:43 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:43 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:44 --> Parser Class Initialized
INFO - 2019-11-07 00:02:44 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:44 --> Model Class Initialized
INFO - 2019-11-07 00:02:44 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:44 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:44 --> Template Class Initialized
INFO - 2019-11-07 00:02:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:44 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:44 --> Encryption Class Initialized
INFO - 2019-11-07 00:02:44 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:44 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:02:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:02:44 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinbase/index.php
INFO - 2019-11-07 00:02:44 --> Final output sent to browser
DEBUG - 2019-11-07 00:02:44 --> Total execution time: 0.9532
INFO - 2019-11-07 00:02:44 --> Config Class Initialized
INFO - 2019-11-07 00:02:44 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:44 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:44 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:44 --> URI Class Initialized
INFO - 2019-11-07 00:02:44 --> Router Class Initialized
INFO - 2019-11-07 00:02:44 --> Output Class Initialized
INFO - 2019-11-07 00:02:44 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:44 --> Input Class Initialized
INFO - 2019-11-07 00:02:44 --> Language Class Initialized
INFO - 2019-11-07 00:02:44 --> Language Class Initialized
INFO - 2019-11-07 00:02:44 --> Config Class Initialized
INFO - 2019-11-07 00:02:44 --> Loader Class Initialized
INFO - 2019-11-07 00:02:44 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:44 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:44 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:44 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:45 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:45 --> Parser Class Initialized
INFO - 2019-11-07 00:02:45 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:45 --> Model Class Initialized
INFO - 2019-11-07 00:02:45 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:45 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:45 --> Template Class Initialized
INFO - 2019-11-07 00:02:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:45 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:45 --> Encryption Class Initialized
INFO - 2019-11-07 00:02:45 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:45 --> coinbase MX_Controller Initialized
INFO - 2019-11-07 00:02:45 --> Config Class Initialized
INFO - 2019-11-07 00:02:45 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:45 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:45 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:45 --> URI Class Initialized
DEBUG - 2019-11-07 00:02:45 --> No URI present. Default controller set.
INFO - 2019-11-07 00:02:45 --> Router Class Initialized
INFO - 2019-11-07 00:02:45 --> Output Class Initialized
INFO - 2019-11-07 00:02:45 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:45 --> CSRF cookie sent
INFO - 2019-11-07 00:02:45 --> Input Class Initialized
INFO - 2019-11-07 00:02:45 --> Language Class Initialized
INFO - 2019-11-07 00:02:45 --> Language Class Initialized
INFO - 2019-11-07 00:02:45 --> Config Class Initialized
INFO - 2019-11-07 00:02:45 --> Loader Class Initialized
INFO - 2019-11-07 00:02:45 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:45 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:45 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:45 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:45 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:46 --> Parser Class Initialized
INFO - 2019-11-07 00:02:46 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:46 --> Model Class Initialized
INFO - 2019-11-07 00:02:46 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:46 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:46 --> Template Class Initialized
INFO - 2019-11-07 00:02:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:46 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:46 --> Encryption Class Initialized
DEBUG - 2019-11-07 00:02:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:02:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-07 00:02:46 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:46 --> pergo MX_Controller Initialized
DEBUG - 2019-11-07 00:02:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:02:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-07 00:02:46 --> Model Class Initialized
INFO - 2019-11-07 00:02:46 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:02:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-07 00:02:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-07 00:02:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-07 00:02:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-07 00:02:46 --> Final output sent to browser
DEBUG - 2019-11-07 00:02:46 --> Total execution time: 1.4244
INFO - 2019-11-07 00:02:52 --> Config Class Initialized
INFO - 2019-11-07 00:02:52 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:52 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:52 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:52 --> URI Class Initialized
INFO - 2019-11-07 00:02:52 --> Router Class Initialized
INFO - 2019-11-07 00:02:52 --> Output Class Initialized
INFO - 2019-11-07 00:02:52 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:52 --> CSRF cookie sent
INFO - 2019-11-07 00:02:52 --> Input Class Initialized
INFO - 2019-11-07 00:02:52 --> Language Class Initialized
INFO - 2019-11-07 00:02:52 --> Language Class Initialized
INFO - 2019-11-07 00:02:52 --> Config Class Initialized
INFO - 2019-11-07 00:02:52 --> Loader Class Initialized
INFO - 2019-11-07 00:02:52 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:53 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:53 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:53 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:53 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:53 --> Parser Class Initialized
INFO - 2019-11-07 00:02:53 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:53 --> Model Class Initialized
INFO - 2019-11-07 00:02:53 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:53 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:53 --> Template Class Initialized
INFO - 2019-11-07 00:02:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:53 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:02:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:02:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:02:53 --> Encryption Class Initialized
INFO - 2019-11-07 00:02:53 --> Controller Class Initialized
DEBUG - 2019-11-07 00:02:53 --> package MX_Controller Initialized
DEBUG - 2019-11-07 00:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-07 00:02:54 --> Model Class Initialized
INFO - 2019-11-07 00:02:54 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:02:54 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:02:54 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:02:54 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-07 00:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-07 00:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:02:55 --> Final output sent to browser
DEBUG - 2019-11-07 00:02:55 --> Total execution time: 3.0384
INFO - 2019-11-07 00:02:58 --> Config Class Initialized
INFO - 2019-11-07 00:02:58 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:02:58 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:02:58 --> Utf8 Class Initialized
INFO - 2019-11-07 00:02:58 --> URI Class Initialized
INFO - 2019-11-07 00:02:58 --> Router Class Initialized
INFO - 2019-11-07 00:02:58 --> Output Class Initialized
INFO - 2019-11-07 00:02:58 --> Security Class Initialized
DEBUG - 2019-11-07 00:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:02:58 --> CSRF cookie sent
INFO - 2019-11-07 00:02:58 --> CSRF token verified
INFO - 2019-11-07 00:02:59 --> Input Class Initialized
INFO - 2019-11-07 00:02:59 --> Language Class Initialized
INFO - 2019-11-07 00:02:59 --> Language Class Initialized
INFO - 2019-11-07 00:02:59 --> Config Class Initialized
INFO - 2019-11-07 00:02:59 --> Loader Class Initialized
INFO - 2019-11-07 00:02:59 --> Helper loaded: url_helper
INFO - 2019-11-07 00:02:59 --> Helper loaded: common_helper
INFO - 2019-11-07 00:02:59 --> Helper loaded: language_helper
INFO - 2019-11-07 00:02:59 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:02:59 --> Helper loaded: email_helper
INFO - 2019-11-07 00:02:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:02:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:02:59 --> Parser Class Initialized
INFO - 2019-11-07 00:02:59 --> User Agent Class Initialized
INFO - 2019-11-07 00:02:59 --> Model Class Initialized
INFO - 2019-11-07 00:02:59 --> Database Driver Class Initialized
INFO - 2019-11-07 00:02:59 --> Model Class Initialized
DEBUG - 2019-11-07 00:02:59 --> Template Class Initialized
INFO - 2019-11-07 00:02:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:02:59 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:03:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:03:00 --> Encryption Class Initialized
INFO - 2019-11-07 00:03:00 --> Controller Class Initialized
DEBUG - 2019-11-07 00:03:00 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:03:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:03:00 --> Model Class Initialized
INFO - 2019-11-07 00:03:00 --> Helper loaded: inflector_helper
ERROR - 2019-11-07 00:03:00 --> Could not find the language line "dotpay"
ERROR - 2019-11-07 00:03:00 --> Could not find the language line "paytm"
DEBUG - 2019-11-07 00:03:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-07 00:03:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:03:00 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:03:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:03:01 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:03:01 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:03:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:03:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:03:01 --> Final output sent to browser
DEBUG - 2019-11-07 00:03:01 --> Total execution time: 2.6822
INFO - 2019-11-07 00:03:09 --> Config Class Initialized
INFO - 2019-11-07 00:03:09 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:03:09 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:03:09 --> Utf8 Class Initialized
INFO - 2019-11-07 00:03:10 --> URI Class Initialized
INFO - 2019-11-07 00:03:10 --> Router Class Initialized
INFO - 2019-11-07 00:03:10 --> Output Class Initialized
INFO - 2019-11-07 00:03:10 --> Security Class Initialized
DEBUG - 2019-11-07 00:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:03:10 --> CSRF cookie sent
INFO - 2019-11-07 00:03:10 --> CSRF token verified
INFO - 2019-11-07 00:03:10 --> Input Class Initialized
INFO - 2019-11-07 00:03:10 --> Language Class Initialized
INFO - 2019-11-07 00:03:10 --> Language Class Initialized
INFO - 2019-11-07 00:03:10 --> Config Class Initialized
INFO - 2019-11-07 00:03:10 --> Loader Class Initialized
INFO - 2019-11-07 00:03:10 --> Helper loaded: url_helper
INFO - 2019-11-07 00:03:10 --> Helper loaded: common_helper
INFO - 2019-11-07 00:03:10 --> Helper loaded: language_helper
INFO - 2019-11-07 00:03:10 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:03:10 --> Helper loaded: email_helper
INFO - 2019-11-07 00:03:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:03:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:03:10 --> Parser Class Initialized
INFO - 2019-11-07 00:03:10 --> User Agent Class Initialized
INFO - 2019-11-07 00:03:10 --> Model Class Initialized
INFO - 2019-11-07 00:03:10 --> Database Driver Class Initialized
INFO - 2019-11-07 00:03:10 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:10 --> Template Class Initialized
INFO - 2019-11-07 00:03:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:03:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:03:10 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:03:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:03:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:03:10 --> Encryption Class Initialized
INFO - 2019-11-07 00:03:10 --> Controller Class Initialized
DEBUG - 2019-11-07 00:03:10 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:03:10 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-07 00:03:10 --> Final output sent to browser
DEBUG - 2019-11-07 00:03:10 --> Total execution time: 1.0468
INFO - 2019-11-07 00:03:11 --> Config Class Initialized
INFO - 2019-11-07 00:03:11 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:03:11 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:03:11 --> Utf8 Class Initialized
INFO - 2019-11-07 00:03:11 --> URI Class Initialized
INFO - 2019-11-07 00:03:11 --> Router Class Initialized
INFO - 2019-11-07 00:03:11 --> Output Class Initialized
INFO - 2019-11-07 00:03:11 --> Security Class Initialized
DEBUG - 2019-11-07 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:03:11 --> Input Class Initialized
INFO - 2019-11-07 00:03:11 --> Language Class Initialized
INFO - 2019-11-07 00:03:11 --> Language Class Initialized
INFO - 2019-11-07 00:03:11 --> Config Class Initialized
INFO - 2019-11-07 00:03:11 --> Loader Class Initialized
INFO - 2019-11-07 00:03:11 --> Helper loaded: url_helper
INFO - 2019-11-07 00:03:11 --> Helper loaded: common_helper
INFO - 2019-11-07 00:03:11 --> Helper loaded: language_helper
INFO - 2019-11-07 00:03:11 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:03:11 --> Helper loaded: email_helper
INFO - 2019-11-07 00:03:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:03:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:03:11 --> Parser Class Initialized
INFO - 2019-11-07 00:03:11 --> User Agent Class Initialized
INFO - 2019-11-07 00:03:11 --> Model Class Initialized
INFO - 2019-11-07 00:03:11 --> Database Driver Class Initialized
INFO - 2019-11-07 00:03:11 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:11 --> Template Class Initialized
INFO - 2019-11-07 00:03:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:03:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:03:11 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:03:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:03:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:03:12 --> Encryption Class Initialized
INFO - 2019-11-07 00:03:12 --> Controller Class Initialized
DEBUG - 2019-11-07 00:03:12 --> dotpay MX_Controller Initialized
INFO - 2019-11-07 00:03:12 --> Config Class Initialized
INFO - 2019-11-07 00:03:12 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:03:12 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:03:12 --> Utf8 Class Initialized
INFO - 2019-11-07 00:03:12 --> URI Class Initialized
DEBUG - 2019-11-07 00:03:12 --> No URI present. Default controller set.
INFO - 2019-11-07 00:03:12 --> Router Class Initialized
INFO - 2019-11-07 00:03:12 --> Output Class Initialized
INFO - 2019-11-07 00:03:12 --> Security Class Initialized
DEBUG - 2019-11-07 00:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:03:12 --> CSRF cookie sent
INFO - 2019-11-07 00:03:12 --> Input Class Initialized
INFO - 2019-11-07 00:03:12 --> Language Class Initialized
INFO - 2019-11-07 00:03:12 --> Language Class Initialized
INFO - 2019-11-07 00:03:12 --> Config Class Initialized
INFO - 2019-11-07 00:03:12 --> Loader Class Initialized
INFO - 2019-11-07 00:03:12 --> Helper loaded: url_helper
INFO - 2019-11-07 00:03:12 --> Helper loaded: common_helper
INFO - 2019-11-07 00:03:12 --> Helper loaded: language_helper
INFO - 2019-11-07 00:03:12 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:03:12 --> Helper loaded: email_helper
INFO - 2019-11-07 00:03:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:03:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:03:12 --> Parser Class Initialized
INFO - 2019-11-07 00:03:12 --> User Agent Class Initialized
INFO - 2019-11-07 00:03:12 --> Model Class Initialized
INFO - 2019-11-07 00:03:12 --> Database Driver Class Initialized
INFO - 2019-11-07 00:03:12 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:13 --> Template Class Initialized
INFO - 2019-11-07 00:03:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:03:13 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:03:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:03:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:03:13 --> Encryption Class Initialized
DEBUG - 2019-11-07 00:03:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:03:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-07 00:03:13 --> Controller Class Initialized
DEBUG - 2019-11-07 00:03:13 --> pergo MX_Controller Initialized
DEBUG - 2019-11-07 00:03:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:03:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-07 00:03:13 --> Model Class Initialized
INFO - 2019-11-07 00:03:13 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:03:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-07 00:03:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-07 00:03:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-07 00:03:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-07 00:03:13 --> Final output sent to browser
DEBUG - 2019-11-07 00:03:13 --> Total execution time: 1.5535
INFO - 2019-11-07 00:03:28 --> Config Class Initialized
INFO - 2019-11-07 00:03:28 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:03:28 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:03:29 --> Utf8 Class Initialized
INFO - 2019-11-07 00:03:29 --> URI Class Initialized
INFO - 2019-11-07 00:03:29 --> Router Class Initialized
INFO - 2019-11-07 00:03:29 --> Output Class Initialized
INFO - 2019-11-07 00:03:29 --> Security Class Initialized
DEBUG - 2019-11-07 00:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:03:29 --> CSRF cookie sent
INFO - 2019-11-07 00:03:29 --> Input Class Initialized
INFO - 2019-11-07 00:03:29 --> Language Class Initialized
INFO - 2019-11-07 00:03:29 --> Language Class Initialized
INFO - 2019-11-07 00:03:29 --> Config Class Initialized
INFO - 2019-11-07 00:03:29 --> Loader Class Initialized
INFO - 2019-11-07 00:03:29 --> Helper loaded: url_helper
INFO - 2019-11-07 00:03:29 --> Helper loaded: common_helper
INFO - 2019-11-07 00:03:29 --> Helper loaded: language_helper
INFO - 2019-11-07 00:03:29 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:03:29 --> Helper loaded: email_helper
INFO - 2019-11-07 00:03:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:03:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:03:29 --> Parser Class Initialized
INFO - 2019-11-07 00:03:29 --> User Agent Class Initialized
INFO - 2019-11-07 00:03:29 --> Model Class Initialized
INFO - 2019-11-07 00:03:29 --> Database Driver Class Initialized
INFO - 2019-11-07 00:03:29 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:29 --> Template Class Initialized
INFO - 2019-11-07 00:03:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:03:29 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:03:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:03:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:03:29 --> Encryption Class Initialized
INFO - 2019-11-07 00:03:29 --> Controller Class Initialized
DEBUG - 2019-11-07 00:03:29 --> package MX_Controller Initialized
DEBUG - 2019-11-07 00:03:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-07 00:03:29 --> Model Class Initialized
INFO - 2019-11-07 00:03:29 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:03:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:03:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:03:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:03:30 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:03:30 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-07 00:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-07 00:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:03:30 --> Final output sent to browser
DEBUG - 2019-11-07 00:03:30 --> Total execution time: 1.5218
INFO - 2019-11-07 00:03:33 --> Config Class Initialized
INFO - 2019-11-07 00:03:33 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:03:33 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:03:33 --> Utf8 Class Initialized
INFO - 2019-11-07 00:03:33 --> URI Class Initialized
INFO - 2019-11-07 00:03:33 --> Router Class Initialized
INFO - 2019-11-07 00:03:33 --> Output Class Initialized
INFO - 2019-11-07 00:03:33 --> Security Class Initialized
DEBUG - 2019-11-07 00:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:03:33 --> CSRF cookie sent
INFO - 2019-11-07 00:03:33 --> CSRF token verified
INFO - 2019-11-07 00:03:33 --> Input Class Initialized
INFO - 2019-11-07 00:03:33 --> Language Class Initialized
INFO - 2019-11-07 00:03:33 --> Language Class Initialized
INFO - 2019-11-07 00:03:33 --> Config Class Initialized
INFO - 2019-11-07 00:03:33 --> Loader Class Initialized
INFO - 2019-11-07 00:03:33 --> Helper loaded: url_helper
INFO - 2019-11-07 00:03:33 --> Helper loaded: common_helper
INFO - 2019-11-07 00:03:33 --> Helper loaded: language_helper
INFO - 2019-11-07 00:03:33 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:03:33 --> Helper loaded: email_helper
INFO - 2019-11-07 00:03:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:03:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:03:33 --> Parser Class Initialized
INFO - 2019-11-07 00:03:33 --> User Agent Class Initialized
INFO - 2019-11-07 00:03:33 --> Model Class Initialized
INFO - 2019-11-07 00:03:33 --> Database Driver Class Initialized
INFO - 2019-11-07 00:03:33 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:33 --> Template Class Initialized
INFO - 2019-11-07 00:03:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:03:33 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:03:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:03:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:03:34 --> Encryption Class Initialized
INFO - 2019-11-07 00:03:34 --> Controller Class Initialized
DEBUG - 2019-11-07 00:03:34 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:03:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:03:34 --> Model Class Initialized
INFO - 2019-11-07 00:03:34 --> Helper loaded: inflector_helper
ERROR - 2019-11-07 00:03:34 --> Could not find the language line "dotpay"
ERROR - 2019-11-07 00:03:34 --> Could not find the language line "paytm"
DEBUG - 2019-11-07 00:03:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-07 00:03:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:03:34 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:03:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:03:34 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:03:34 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:03:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:03:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:03:34 --> Final output sent to browser
DEBUG - 2019-11-07 00:03:34 --> Total execution time: 1.4192
INFO - 2019-11-07 00:03:42 --> Config Class Initialized
INFO - 2019-11-07 00:03:42 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:03:42 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:03:42 --> Utf8 Class Initialized
INFO - 2019-11-07 00:03:42 --> URI Class Initialized
INFO - 2019-11-07 00:03:42 --> Router Class Initialized
INFO - 2019-11-07 00:03:42 --> Output Class Initialized
INFO - 2019-11-07 00:03:42 --> Security Class Initialized
DEBUG - 2019-11-07 00:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:03:42 --> CSRF cookie sent
INFO - 2019-11-07 00:03:42 --> CSRF token verified
INFO - 2019-11-07 00:03:42 --> Input Class Initialized
INFO - 2019-11-07 00:03:42 --> Language Class Initialized
INFO - 2019-11-07 00:03:42 --> Language Class Initialized
INFO - 2019-11-07 00:03:42 --> Config Class Initialized
INFO - 2019-11-07 00:03:42 --> Loader Class Initialized
INFO - 2019-11-07 00:03:42 --> Helper loaded: url_helper
INFO - 2019-11-07 00:03:42 --> Helper loaded: common_helper
INFO - 2019-11-07 00:03:42 --> Helper loaded: language_helper
INFO - 2019-11-07 00:03:42 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:03:42 --> Helper loaded: email_helper
INFO - 2019-11-07 00:03:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:03:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:03:42 --> Parser Class Initialized
INFO - 2019-11-07 00:03:42 --> User Agent Class Initialized
INFO - 2019-11-07 00:03:42 --> Model Class Initialized
INFO - 2019-11-07 00:03:42 --> Database Driver Class Initialized
INFO - 2019-11-07 00:03:42 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:43 --> Template Class Initialized
INFO - 2019-11-07 00:03:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:03:43 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:03:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:03:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:03:43 --> Encryption Class Initialized
INFO - 2019-11-07 00:03:43 --> Controller Class Initialized
DEBUG - 2019-11-07 00:03:43 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:03:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:03:43 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paypal/index.php
INFO - 2019-11-07 00:03:43 --> Final output sent to browser
DEBUG - 2019-11-07 00:03:43 --> Total execution time: 0.9584
INFO - 2019-11-07 00:03:43 --> Config Class Initialized
INFO - 2019-11-07 00:03:43 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:03:43 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:03:43 --> Utf8 Class Initialized
INFO - 2019-11-07 00:03:43 --> URI Class Initialized
INFO - 2019-11-07 00:03:43 --> Router Class Initialized
INFO - 2019-11-07 00:03:43 --> Output Class Initialized
INFO - 2019-11-07 00:03:43 --> Security Class Initialized
DEBUG - 2019-11-07 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:03:43 --> Input Class Initialized
INFO - 2019-11-07 00:03:43 --> Language Class Initialized
INFO - 2019-11-07 00:03:43 --> Language Class Initialized
INFO - 2019-11-07 00:03:43 --> Config Class Initialized
INFO - 2019-11-07 00:03:43 --> Loader Class Initialized
INFO - 2019-11-07 00:03:43 --> Helper loaded: url_helper
INFO - 2019-11-07 00:03:43 --> Helper loaded: common_helper
INFO - 2019-11-07 00:03:43 --> Helper loaded: language_helper
INFO - 2019-11-07 00:03:43 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:03:43 --> Helper loaded: email_helper
INFO - 2019-11-07 00:03:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:03:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:03:43 --> Parser Class Initialized
INFO - 2019-11-07 00:03:43 --> User Agent Class Initialized
INFO - 2019-11-07 00:03:43 --> Model Class Initialized
INFO - 2019-11-07 00:03:44 --> Database Driver Class Initialized
INFO - 2019-11-07 00:03:44 --> Model Class Initialized
DEBUG - 2019-11-07 00:03:44 --> Template Class Initialized
INFO - 2019-11-07 00:03:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:03:44 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:03:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:03:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:03:44 --> Encryption Class Initialized
INFO - 2019-11-07 00:03:44 --> Controller Class Initialized
DEBUG - 2019-11-07 00:03:44 --> paypal MX_Controller Initialized
DEBUG - 2019-11-07 00:03:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
INFO - 2019-11-07 00:03:44 --> Model Class Initialized
INFO - 2019-11-07 00:04:17 --> Config Class Initialized
INFO - 2019-11-07 00:04:17 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:04:18 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:04:18 --> Utf8 Class Initialized
INFO - 2019-11-07 00:04:18 --> URI Class Initialized
INFO - 2019-11-07 00:04:18 --> Router Class Initialized
INFO - 2019-11-07 00:04:18 --> Output Class Initialized
INFO - 2019-11-07 00:04:18 --> Security Class Initialized
DEBUG - 2019-11-07 00:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:04:18 --> CSRF cookie sent
INFO - 2019-11-07 00:04:18 --> CSRF token verified
INFO - 2019-11-07 00:04:18 --> Input Class Initialized
INFO - 2019-11-07 00:04:18 --> Language Class Initialized
INFO - 2019-11-07 00:04:18 --> Language Class Initialized
INFO - 2019-11-07 00:04:18 --> Config Class Initialized
INFO - 2019-11-07 00:04:18 --> Loader Class Initialized
INFO - 2019-11-07 00:04:18 --> Helper loaded: url_helper
INFO - 2019-11-07 00:04:18 --> Helper loaded: common_helper
INFO - 2019-11-07 00:04:18 --> Helper loaded: language_helper
INFO - 2019-11-07 00:04:18 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:04:18 --> Helper loaded: email_helper
INFO - 2019-11-07 00:04:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:04:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:04:18 --> Parser Class Initialized
INFO - 2019-11-07 00:04:18 --> User Agent Class Initialized
INFO - 2019-11-07 00:04:18 --> Model Class Initialized
INFO - 2019-11-07 00:04:18 --> Database Driver Class Initialized
INFO - 2019-11-07 00:04:18 --> Model Class Initialized
DEBUG - 2019-11-07 00:04:18 --> Template Class Initialized
INFO - 2019-11-07 00:04:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:04:18 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:04:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:04:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:04:18 --> Encryption Class Initialized
INFO - 2019-11-07 00:04:18 --> Controller Class Initialized
DEBUG - 2019-11-07 00:04:18 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:04:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:04:18 --> Model Class Initialized
ERROR - 2019-11-07 00:04:18 --> Could not find the language line "Your_name"
DEBUG - 2019-11-07 00:04:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-07 00:04:19 --> Final output sent to browser
DEBUG - 2019-11-07 00:04:19 --> Total execution time: 1.0864
INFO - 2019-11-07 00:04:53 --> Config Class Initialized
INFO - 2019-11-07 00:04:53 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:04:53 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:04:53 --> Utf8 Class Initialized
INFO - 2019-11-07 00:04:53 --> URI Class Initialized
INFO - 2019-11-07 00:04:53 --> Router Class Initialized
INFO - 2019-11-07 00:04:53 --> Output Class Initialized
INFO - 2019-11-07 00:04:53 --> Security Class Initialized
DEBUG - 2019-11-07 00:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:04:53 --> Input Class Initialized
INFO - 2019-11-07 00:04:53 --> Language Class Initialized
INFO - 2019-11-07 00:04:53 --> Language Class Initialized
INFO - 2019-11-07 00:04:53 --> Config Class Initialized
INFO - 2019-11-07 00:04:53 --> Loader Class Initialized
INFO - 2019-11-07 00:04:53 --> Helper loaded: url_helper
INFO - 2019-11-07 00:04:53 --> Helper loaded: common_helper
INFO - 2019-11-07 00:04:53 --> Helper loaded: language_helper
INFO - 2019-11-07 00:04:53 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:04:53 --> Helper loaded: email_helper
INFO - 2019-11-07 00:04:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:04:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:04:53 --> Parser Class Initialized
INFO - 2019-11-07 00:04:53 --> User Agent Class Initialized
INFO - 2019-11-07 00:04:53 --> Model Class Initialized
INFO - 2019-11-07 00:04:53 --> Database Driver Class Initialized
INFO - 2019-11-07 00:04:53 --> Model Class Initialized
DEBUG - 2019-11-07 00:04:53 --> Template Class Initialized
INFO - 2019-11-07 00:04:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:04:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:04:53 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:04:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:04:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:04:53 --> Encryption Class Initialized
INFO - 2019-11-07 00:04:53 --> Controller Class Initialized
DEBUG - 2019-11-07 00:04:53 --> stripe MX_Controller Initialized
INFO - 2019-11-07 00:04:53 --> Config Class Initialized
INFO - 2019-11-07 00:04:53 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:04:53 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:04:53 --> Utf8 Class Initialized
INFO - 2019-11-07 00:04:53 --> URI Class Initialized
DEBUG - 2019-11-07 00:04:54 --> No URI present. Default controller set.
INFO - 2019-11-07 00:04:54 --> Router Class Initialized
INFO - 2019-11-07 00:04:54 --> Output Class Initialized
INFO - 2019-11-07 00:04:54 --> Security Class Initialized
DEBUG - 2019-11-07 00:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:04:54 --> CSRF cookie sent
INFO - 2019-11-07 00:04:54 --> Input Class Initialized
INFO - 2019-11-07 00:04:54 --> Language Class Initialized
INFO - 2019-11-07 00:04:54 --> Language Class Initialized
INFO - 2019-11-07 00:04:54 --> Config Class Initialized
INFO - 2019-11-07 00:04:54 --> Loader Class Initialized
INFO - 2019-11-07 00:04:54 --> Helper loaded: url_helper
INFO - 2019-11-07 00:04:54 --> Helper loaded: common_helper
INFO - 2019-11-07 00:04:54 --> Helper loaded: language_helper
INFO - 2019-11-07 00:04:54 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:04:54 --> Helper loaded: email_helper
INFO - 2019-11-07 00:04:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:04:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:04:54 --> Parser Class Initialized
INFO - 2019-11-07 00:04:54 --> User Agent Class Initialized
INFO - 2019-11-07 00:04:54 --> Model Class Initialized
INFO - 2019-11-07 00:04:54 --> Database Driver Class Initialized
INFO - 2019-11-07 00:04:54 --> Model Class Initialized
DEBUG - 2019-11-07 00:04:54 --> Template Class Initialized
INFO - 2019-11-07 00:04:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:04:54 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:04:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:04:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:04:54 --> Encryption Class Initialized
DEBUG - 2019-11-07 00:04:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:04:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-07 00:04:54 --> Controller Class Initialized
DEBUG - 2019-11-07 00:04:54 --> pergo MX_Controller Initialized
DEBUG - 2019-11-07 00:04:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:04:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-07 00:04:54 --> Model Class Initialized
INFO - 2019-11-07 00:04:54 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:04:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-07 00:04:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-07 00:04:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-07 00:04:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-07 00:04:55 --> Final output sent to browser
DEBUG - 2019-11-07 00:04:55 --> Total execution time: 1.2528
INFO - 2019-11-07 00:10:27 --> Config Class Initialized
INFO - 2019-11-07 00:10:27 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:10:27 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:10:27 --> Utf8 Class Initialized
INFO - 2019-11-07 00:10:27 --> URI Class Initialized
INFO - 2019-11-07 00:10:27 --> Router Class Initialized
INFO - 2019-11-07 00:10:27 --> Output Class Initialized
INFO - 2019-11-07 00:10:27 --> Security Class Initialized
DEBUG - 2019-11-07 00:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:10:27 --> Input Class Initialized
INFO - 2019-11-07 00:10:27 --> Language Class Initialized
INFO - 2019-11-07 00:10:27 --> Language Class Initialized
INFO - 2019-11-07 00:10:27 --> Config Class Initialized
INFO - 2019-11-07 00:10:27 --> Loader Class Initialized
INFO - 2019-11-07 00:10:27 --> Helper loaded: url_helper
INFO - 2019-11-07 00:10:28 --> Helper loaded: common_helper
INFO - 2019-11-07 00:10:28 --> Helper loaded: language_helper
INFO - 2019-11-07 00:10:28 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:10:28 --> Helper loaded: email_helper
INFO - 2019-11-07 00:10:28 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:10:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:10:28 --> Parser Class Initialized
INFO - 2019-11-07 00:10:28 --> User Agent Class Initialized
INFO - 2019-11-07 00:10:28 --> Model Class Initialized
INFO - 2019-11-07 00:10:28 --> Database Driver Class Initialized
INFO - 2019-11-07 00:10:28 --> Model Class Initialized
DEBUG - 2019-11-07 00:10:28 --> Template Class Initialized
INFO - 2019-11-07 00:10:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:10:28 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:10:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:10:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:10:28 --> Encryption Class Initialized
INFO - 2019-11-07 00:10:28 --> Controller Class Initialized
DEBUG - 2019-11-07 00:10:28 --> paypal MX_Controller Initialized
INFO - 2019-11-07 00:11:35 --> Config Class Initialized
INFO - 2019-11-07 00:11:35 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:11:35 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:11:35 --> Utf8 Class Initialized
INFO - 2019-11-07 00:11:35 --> URI Class Initialized
INFO - 2019-11-07 00:11:35 --> Router Class Initialized
INFO - 2019-11-07 00:11:35 --> Output Class Initialized
INFO - 2019-11-07 00:11:35 --> Security Class Initialized
DEBUG - 2019-11-07 00:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:11:36 --> Input Class Initialized
INFO - 2019-11-07 00:11:36 --> Language Class Initialized
INFO - 2019-11-07 00:11:36 --> Language Class Initialized
INFO - 2019-11-07 00:11:36 --> Config Class Initialized
INFO - 2019-11-07 00:11:36 --> Loader Class Initialized
INFO - 2019-11-07 00:11:36 --> Helper loaded: url_helper
INFO - 2019-11-07 00:11:36 --> Helper loaded: common_helper
INFO - 2019-11-07 00:11:36 --> Helper loaded: language_helper
INFO - 2019-11-07 00:11:36 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:11:36 --> Helper loaded: email_helper
INFO - 2019-11-07 00:11:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:11:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:11:36 --> Parser Class Initialized
INFO - 2019-11-07 00:11:36 --> User Agent Class Initialized
INFO - 2019-11-07 00:11:36 --> Model Class Initialized
INFO - 2019-11-07 00:11:36 --> Database Driver Class Initialized
INFO - 2019-11-07 00:11:36 --> Model Class Initialized
DEBUG - 2019-11-07 00:11:36 --> Template Class Initialized
INFO - 2019-11-07 00:11:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:11:36 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:11:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:11:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:11:36 --> Encryption Class Initialized
INFO - 2019-11-07 00:11:36 --> Controller Class Initialized
DEBUG - 2019-11-07 00:11:36 --> paypal MX_Controller Initialized
DEBUG - 2019-11-07 00:11:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
INFO - 2019-11-07 00:11:36 --> Model Class Initialized
INFO - 2019-11-07 00:11:36 --> Config Class Initialized
INFO - 2019-11-07 00:11:36 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:11:36 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:11:36 --> Utf8 Class Initialized
INFO - 2019-11-07 00:11:36 --> URI Class Initialized
INFO - 2019-11-07 00:11:36 --> Router Class Initialized
INFO - 2019-11-07 00:11:36 --> Output Class Initialized
INFO - 2019-11-07 00:11:36 --> Security Class Initialized
DEBUG - 2019-11-07 00:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:11:36 --> CSRF cookie sent
INFO - 2019-11-07 00:11:36 --> Input Class Initialized
INFO - 2019-11-07 00:11:37 --> Language Class Initialized
INFO - 2019-11-07 00:11:37 --> Language Class Initialized
INFO - 2019-11-07 00:11:37 --> Config Class Initialized
INFO - 2019-11-07 00:11:37 --> Loader Class Initialized
INFO - 2019-11-07 00:11:37 --> Helper loaded: url_helper
INFO - 2019-11-07 00:11:37 --> Helper loaded: common_helper
INFO - 2019-11-07 00:11:37 --> Helper loaded: language_helper
INFO - 2019-11-07 00:11:37 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:11:37 --> Helper loaded: email_helper
INFO - 2019-11-07 00:11:37 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:11:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:11:37 --> Parser Class Initialized
INFO - 2019-11-07 00:11:37 --> User Agent Class Initialized
INFO - 2019-11-07 00:11:37 --> Model Class Initialized
INFO - 2019-11-07 00:11:37 --> Database Driver Class Initialized
INFO - 2019-11-07 00:11:37 --> Model Class Initialized
DEBUG - 2019-11-07 00:11:37 --> Template Class Initialized
INFO - 2019-11-07 00:11:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:11:37 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:11:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:11:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:11:37 --> Encryption Class Initialized
INFO - 2019-11-07 00:11:37 --> Controller Class Initialized
DEBUG - 2019-11-07 00:11:37 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:11:37 --> Model Class Initialized
INFO - 2019-11-07 00:11:37 --> Config Class Initialized
INFO - 2019-11-07 00:11:37 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:11:37 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:11:37 --> Utf8 Class Initialized
INFO - 2019-11-07 00:11:37 --> URI Class Initialized
DEBUG - 2019-11-07 00:11:37 --> No URI present. Default controller set.
INFO - 2019-11-07 00:11:37 --> Router Class Initialized
INFO - 2019-11-07 00:11:37 --> Output Class Initialized
INFO - 2019-11-07 00:11:37 --> Security Class Initialized
DEBUG - 2019-11-07 00:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:11:37 --> CSRF cookie sent
INFO - 2019-11-07 00:11:37 --> Input Class Initialized
INFO - 2019-11-07 00:11:37 --> Language Class Initialized
INFO - 2019-11-07 00:11:37 --> Language Class Initialized
INFO - 2019-11-07 00:11:37 --> Config Class Initialized
INFO - 2019-11-07 00:11:37 --> Loader Class Initialized
INFO - 2019-11-07 00:11:38 --> Helper loaded: url_helper
INFO - 2019-11-07 00:11:38 --> Helper loaded: common_helper
INFO - 2019-11-07 00:11:38 --> Helper loaded: language_helper
INFO - 2019-11-07 00:11:38 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:11:38 --> Helper loaded: email_helper
INFO - 2019-11-07 00:11:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:11:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:11:38 --> Parser Class Initialized
INFO - 2019-11-07 00:11:38 --> User Agent Class Initialized
INFO - 2019-11-07 00:11:38 --> Model Class Initialized
INFO - 2019-11-07 00:11:38 --> Database Driver Class Initialized
INFO - 2019-11-07 00:11:38 --> Model Class Initialized
DEBUG - 2019-11-07 00:11:38 --> Template Class Initialized
INFO - 2019-11-07 00:11:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:11:38 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:11:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:11:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:11:38 --> Encryption Class Initialized
DEBUG - 2019-11-07 00:11:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:11:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-07 00:11:38 --> Controller Class Initialized
DEBUG - 2019-11-07 00:11:38 --> pergo MX_Controller Initialized
INFO - 2019-11-07 00:12:43 --> Config Class Initialized
INFO - 2019-11-07 00:12:43 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:12:43 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:12:43 --> Utf8 Class Initialized
INFO - 2019-11-07 00:12:43 --> URI Class Initialized
INFO - 2019-11-07 00:12:43 --> Router Class Initialized
INFO - 2019-11-07 00:12:43 --> Output Class Initialized
INFO - 2019-11-07 00:12:43 --> Security Class Initialized
DEBUG - 2019-11-07 00:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:12:43 --> Input Class Initialized
INFO - 2019-11-07 00:12:43 --> Language Class Initialized
INFO - 2019-11-07 00:12:43 --> Language Class Initialized
INFO - 2019-11-07 00:12:43 --> Config Class Initialized
INFO - 2019-11-07 00:12:43 --> Loader Class Initialized
INFO - 2019-11-07 00:12:43 --> Helper loaded: url_helper
INFO - 2019-11-07 00:12:43 --> Helper loaded: common_helper
INFO - 2019-11-07 00:12:43 --> Helper loaded: language_helper
INFO - 2019-11-07 00:12:43 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:12:43 --> Helper loaded: email_helper
INFO - 2019-11-07 00:12:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:12:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:12:44 --> Parser Class Initialized
INFO - 2019-11-07 00:12:44 --> User Agent Class Initialized
INFO - 2019-11-07 00:12:44 --> Model Class Initialized
INFO - 2019-11-07 00:12:44 --> Database Driver Class Initialized
INFO - 2019-11-07 00:12:44 --> Model Class Initialized
DEBUG - 2019-11-07 00:12:44 --> Template Class Initialized
INFO - 2019-11-07 00:12:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:12:44 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:12:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:12:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:12:44 --> Encryption Class Initialized
INFO - 2019-11-07 00:12:44 --> Controller Class Initialized
DEBUG - 2019-11-07 00:12:44 --> stripe MX_Controller Initialized
INFO - 2019-11-07 00:13:30 --> Config Class Initialized
INFO - 2019-11-07 00:13:30 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:13:30 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:13:30 --> Utf8 Class Initialized
INFO - 2019-11-07 00:13:30 --> URI Class Initialized
INFO - 2019-11-07 00:13:30 --> Router Class Initialized
INFO - 2019-11-07 00:13:30 --> Output Class Initialized
INFO - 2019-11-07 00:13:30 --> Security Class Initialized
DEBUG - 2019-11-07 00:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:13:30 --> Input Class Initialized
INFO - 2019-11-07 00:13:31 --> Language Class Initialized
INFO - 2019-11-07 00:13:31 --> Language Class Initialized
INFO - 2019-11-07 00:13:31 --> Config Class Initialized
INFO - 2019-11-07 00:13:31 --> Loader Class Initialized
INFO - 2019-11-07 00:13:31 --> Helper loaded: url_helper
INFO - 2019-11-07 00:13:31 --> Helper loaded: common_helper
INFO - 2019-11-07 00:13:31 --> Helper loaded: language_helper
INFO - 2019-11-07 00:13:31 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:13:31 --> Helper loaded: email_helper
INFO - 2019-11-07 00:13:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:13:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:13:31 --> Parser Class Initialized
INFO - 2019-11-07 00:13:31 --> User Agent Class Initialized
INFO - 2019-11-07 00:13:31 --> Model Class Initialized
INFO - 2019-11-07 00:13:31 --> Database Driver Class Initialized
INFO - 2019-11-07 00:13:31 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:31 --> Template Class Initialized
INFO - 2019-11-07 00:13:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:13:31 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:13:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:13:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:13:31 --> Encryption Class Initialized
INFO - 2019-11-07 00:13:31 --> Controller Class Initialized
DEBUG - 2019-11-07 00:13:31 --> stripe MX_Controller Initialized
DEBUG - 2019-11-07 00:13:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2019-11-07 00:13:34 --> Model Class Initialized
INFO - 2019-11-07 00:13:34 --> Config Class Initialized
INFO - 2019-11-07 00:13:34 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:13:34 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:13:34 --> Utf8 Class Initialized
INFO - 2019-11-07 00:13:34 --> URI Class Initialized
DEBUG - 2019-11-07 00:13:34 --> No URI present. Default controller set.
INFO - 2019-11-07 00:13:34 --> Router Class Initialized
INFO - 2019-11-07 00:13:34 --> Output Class Initialized
INFO - 2019-11-07 00:13:34 --> Security Class Initialized
DEBUG - 2019-11-07 00:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:13:34 --> CSRF cookie sent
INFO - 2019-11-07 00:13:34 --> Input Class Initialized
INFO - 2019-11-07 00:13:34 --> Language Class Initialized
INFO - 2019-11-07 00:13:34 --> Language Class Initialized
INFO - 2019-11-07 00:13:34 --> Config Class Initialized
INFO - 2019-11-07 00:13:34 --> Loader Class Initialized
INFO - 2019-11-07 00:13:34 --> Helper loaded: url_helper
INFO - 2019-11-07 00:13:34 --> Helper loaded: common_helper
INFO - 2019-11-07 00:13:34 --> Helper loaded: language_helper
INFO - 2019-11-07 00:13:34 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:13:34 --> Helper loaded: email_helper
INFO - 2019-11-07 00:13:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:13:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:13:34 --> Parser Class Initialized
INFO - 2019-11-07 00:13:34 --> User Agent Class Initialized
INFO - 2019-11-07 00:13:34 --> Model Class Initialized
INFO - 2019-11-07 00:13:34 --> Database Driver Class Initialized
INFO - 2019-11-07 00:13:35 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:35 --> Template Class Initialized
INFO - 2019-11-07 00:13:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:13:35 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:13:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:13:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:13:35 --> Encryption Class Initialized
DEBUG - 2019-11-07 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-07 00:13:35 --> Controller Class Initialized
DEBUG - 2019-11-07 00:13:35 --> pergo MX_Controller Initialized
DEBUG - 2019-11-07 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-07 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-07 00:13:35 --> Model Class Initialized
INFO - 2019-11-07 00:13:35 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-07 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-07 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-07 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-07 00:13:35 --> Final output sent to browser
DEBUG - 2019-11-07 00:13:35 --> Total execution time: 1.2738
INFO - 2019-11-07 00:13:42 --> Config Class Initialized
INFO - 2019-11-07 00:13:42 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:13:42 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:13:43 --> Utf8 Class Initialized
INFO - 2019-11-07 00:13:43 --> URI Class Initialized
INFO - 2019-11-07 00:13:43 --> Router Class Initialized
INFO - 2019-11-07 00:13:43 --> Output Class Initialized
INFO - 2019-11-07 00:13:43 --> Security Class Initialized
DEBUG - 2019-11-07 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:13:43 --> CSRF cookie sent
INFO - 2019-11-07 00:13:43 --> Input Class Initialized
INFO - 2019-11-07 00:13:43 --> Language Class Initialized
INFO - 2019-11-07 00:13:43 --> Language Class Initialized
INFO - 2019-11-07 00:13:43 --> Config Class Initialized
INFO - 2019-11-07 00:13:43 --> Loader Class Initialized
INFO - 2019-11-07 00:13:43 --> Helper loaded: url_helper
INFO - 2019-11-07 00:13:43 --> Helper loaded: common_helper
INFO - 2019-11-07 00:13:43 --> Helper loaded: language_helper
INFO - 2019-11-07 00:13:43 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:13:43 --> Helper loaded: email_helper
INFO - 2019-11-07 00:13:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:13:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:13:43 --> Parser Class Initialized
INFO - 2019-11-07 00:13:43 --> User Agent Class Initialized
INFO - 2019-11-07 00:13:43 --> Model Class Initialized
INFO - 2019-11-07 00:13:43 --> Database Driver Class Initialized
INFO - 2019-11-07 00:13:43 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:43 --> Template Class Initialized
INFO - 2019-11-07 00:13:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:13:43 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:13:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:13:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:13:44 --> Encryption Class Initialized
INFO - 2019-11-07 00:13:44 --> Controller Class Initialized
DEBUG - 2019-11-07 00:13:44 --> package MX_Controller Initialized
DEBUG - 2019-11-07 00:13:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-07 00:13:44 --> Model Class Initialized
INFO - 2019-11-07 00:13:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-07 00:13:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:13:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:13:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:13:44 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:13:44 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-07 00:13:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-07 00:13:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:13:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:13:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:13:44 --> Final output sent to browser
DEBUG - 2019-11-07 00:13:44 --> Total execution time: 2.0061
INFO - 2019-11-07 00:13:48 --> Config Class Initialized
INFO - 2019-11-07 00:13:48 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:13:48 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:13:48 --> Utf8 Class Initialized
INFO - 2019-11-07 00:13:48 --> URI Class Initialized
INFO - 2019-11-07 00:13:48 --> Router Class Initialized
INFO - 2019-11-07 00:13:48 --> Output Class Initialized
INFO - 2019-11-07 00:13:48 --> Security Class Initialized
DEBUG - 2019-11-07 00:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:13:48 --> CSRF cookie sent
INFO - 2019-11-07 00:13:48 --> CSRF token verified
INFO - 2019-11-07 00:13:48 --> Input Class Initialized
INFO - 2019-11-07 00:13:49 --> Language Class Initialized
INFO - 2019-11-07 00:13:49 --> Language Class Initialized
INFO - 2019-11-07 00:13:49 --> Config Class Initialized
INFO - 2019-11-07 00:13:49 --> Loader Class Initialized
INFO - 2019-11-07 00:13:49 --> Helper loaded: url_helper
INFO - 2019-11-07 00:13:49 --> Helper loaded: common_helper
INFO - 2019-11-07 00:13:49 --> Helper loaded: language_helper
INFO - 2019-11-07 00:13:49 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:13:49 --> Helper loaded: email_helper
INFO - 2019-11-07 00:13:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:13:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:13:49 --> Parser Class Initialized
INFO - 2019-11-07 00:13:49 --> User Agent Class Initialized
INFO - 2019-11-07 00:13:49 --> Model Class Initialized
INFO - 2019-11-07 00:13:49 --> Database Driver Class Initialized
INFO - 2019-11-07 00:13:49 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:49 --> Template Class Initialized
INFO - 2019-11-07 00:13:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:13:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:13:49 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:13:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:13:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:13:49 --> Encryption Class Initialized
INFO - 2019-11-07 00:13:49 --> Controller Class Initialized
DEBUG - 2019-11-07 00:13:49 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:13:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:13:49 --> Model Class Initialized
INFO - 2019-11-07 00:13:49 --> Helper loaded: inflector_helper
ERROR - 2019-11-07 00:13:49 --> Could not find the language line "dotpay"
ERROR - 2019-11-07 00:13:49 --> Could not find the language line "paytm"
DEBUG - 2019-11-07 00:13:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-07 00:13:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-07 00:13:50 --> blocks MX_Controller Initialized
DEBUG - 2019-11-07 00:13:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-07 00:13:50 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-07 00:13:50 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-07 00:13:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-07 00:13:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-07 00:13:50 --> Final output sent to browser
DEBUG - 2019-11-07 00:13:50 --> Total execution time: 1.6051
INFO - 2019-11-07 00:13:56 --> Config Class Initialized
INFO - 2019-11-07 00:13:56 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:13:56 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:13:56 --> Utf8 Class Initialized
INFO - 2019-11-07 00:13:57 --> URI Class Initialized
INFO - 2019-11-07 00:13:57 --> Router Class Initialized
INFO - 2019-11-07 00:13:57 --> Output Class Initialized
INFO - 2019-11-07 00:13:57 --> Security Class Initialized
DEBUG - 2019-11-07 00:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:13:57 --> CSRF cookie sent
INFO - 2019-11-07 00:13:57 --> CSRF token verified
INFO - 2019-11-07 00:13:57 --> Input Class Initialized
INFO - 2019-11-07 00:13:57 --> Language Class Initialized
INFO - 2019-11-07 00:13:57 --> Language Class Initialized
INFO - 2019-11-07 00:13:57 --> Config Class Initialized
INFO - 2019-11-07 00:13:57 --> Loader Class Initialized
INFO - 2019-11-07 00:13:57 --> Helper loaded: url_helper
INFO - 2019-11-07 00:13:57 --> Helper loaded: common_helper
INFO - 2019-11-07 00:13:57 --> Helper loaded: language_helper
INFO - 2019-11-07 00:13:57 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:13:57 --> Helper loaded: email_helper
INFO - 2019-11-07 00:13:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:13:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:13:57 --> Parser Class Initialized
INFO - 2019-11-07 00:13:57 --> User Agent Class Initialized
INFO - 2019-11-07 00:13:57 --> Model Class Initialized
INFO - 2019-11-07 00:13:57 --> Database Driver Class Initialized
INFO - 2019-11-07 00:13:57 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:57 --> Template Class Initialized
INFO - 2019-11-07 00:13:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:13:57 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:13:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:13:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:13:57 --> Encryption Class Initialized
INFO - 2019-11-07 00:13:57 --> Controller Class Initialized
DEBUG - 2019-11-07 00:13:57 --> checkout MX_Controller Initialized
DEBUG - 2019-11-07 00:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-07 00:13:57 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/index.php
INFO - 2019-11-07 00:13:57 --> Final output sent to browser
DEBUG - 2019-11-07 00:13:57 --> Total execution time: 1.0134
INFO - 2019-11-07 00:13:58 --> Config Class Initialized
INFO - 2019-11-07 00:13:58 --> Hooks Class Initialized
DEBUG - 2019-11-07 00:13:58 --> UTF-8 Support Enabled
INFO - 2019-11-07 00:13:58 --> Utf8 Class Initialized
INFO - 2019-11-07 00:13:58 --> URI Class Initialized
INFO - 2019-11-07 00:13:58 --> Router Class Initialized
INFO - 2019-11-07 00:13:58 --> Output Class Initialized
INFO - 2019-11-07 00:13:58 --> Security Class Initialized
DEBUG - 2019-11-07 00:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-07 00:13:58 --> Input Class Initialized
INFO - 2019-11-07 00:13:58 --> Language Class Initialized
INFO - 2019-11-07 00:13:58 --> Language Class Initialized
INFO - 2019-11-07 00:13:58 --> Config Class Initialized
INFO - 2019-11-07 00:13:58 --> Loader Class Initialized
INFO - 2019-11-07 00:13:58 --> Helper loaded: url_helper
INFO - 2019-11-07 00:13:58 --> Helper loaded: common_helper
INFO - 2019-11-07 00:13:58 --> Helper loaded: language_helper
INFO - 2019-11-07 00:13:58 --> Helper loaded: cookie_helper
INFO - 2019-11-07 00:13:58 --> Helper loaded: email_helper
INFO - 2019-11-07 00:13:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-07 00:13:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-07 00:13:58 --> Parser Class Initialized
INFO - 2019-11-07 00:13:58 --> User Agent Class Initialized
INFO - 2019-11-07 00:13:58 --> Model Class Initialized
INFO - 2019-11-07 00:13:58 --> Database Driver Class Initialized
INFO - 2019-11-07 00:13:58 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:58 --> Template Class Initialized
INFO - 2019-11-07 00:13:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-07 00:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-07 00:13:58 --> Pagination Class Initialized
DEBUG - 2019-11-07 00:13:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-07 00:13:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-07 00:13:58 --> Encryption Class Initialized
INFO - 2019-11-07 00:13:58 --> Controller Class Initialized
DEBUG - 2019-11-07 00:13:58 --> cardinity MX_Controller Initialized
INFO - 2019-11-07 00:13:59 --> Model Class Initialized
DEBUG - 2019-11-07 00:13:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/cardinity_form.php
INFO - 2019-11-07 00:13:59 --> Final output sent to browser
DEBUG - 2019-11-07 00:13:59 --> Total execution time: 1.0880
