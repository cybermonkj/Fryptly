<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-25 08:34:44 --> Config Class Initialized
INFO - 2020-02-25 08:34:44 --> Hooks Class Initialized
DEBUG - 2020-02-25 08:34:44 --> UTF-8 Support Enabled
INFO - 2020-02-25 08:34:44 --> Utf8 Class Initialized
INFO - 2020-02-25 08:34:44 --> URI Class Initialized
INFO - 2020-02-25 08:34:44 --> Router Class Initialized
INFO - 2020-02-25 08:34:44 --> Output Class Initialized
INFO - 2020-02-25 08:34:44 --> Security Class Initialized
DEBUG - 2020-02-25 08:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 08:34:44 --> CSRF cookie sent
INFO - 2020-02-25 08:34:44 --> Input Class Initialized
INFO - 2020-02-25 08:34:44 --> Language Class Initialized
INFO - 2020-02-25 08:34:45 --> Language Class Initialized
INFO - 2020-02-25 08:34:45 --> Config Class Initialized
INFO - 2020-02-25 08:34:45 --> Loader Class Initialized
INFO - 2020-02-25 08:34:45 --> Helper loaded: url_helper
INFO - 2020-02-25 08:34:45 --> Helper loaded: common_helper
INFO - 2020-02-25 08:34:45 --> Helper loaded: language_helper
INFO - 2020-02-25 08:34:45 --> Helper loaded: cookie_helper
INFO - 2020-02-25 08:34:45 --> Helper loaded: email_helper
INFO - 2020-02-25 08:34:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 08:34:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 08:34:45 --> Parser Class Initialized
INFO - 2020-02-25 08:34:45 --> User Agent Class Initialized
INFO - 2020-02-25 08:34:45 --> Model Class Initialized
INFO - 2020-02-25 08:34:45 --> Database Driver Class Initialized
INFO - 2020-02-25 08:34:45 --> Model Class Initialized
DEBUG - 2020-02-25 08:34:45 --> Template Class Initialized
INFO - 2020-02-25 08:34:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 08:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 08:34:45 --> Pagination Class Initialized
DEBUG - 2020-02-25 08:34:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 08:34:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 08:34:45 --> Encryption Class Initialized
INFO - 2020-02-25 08:34:45 --> Controller Class Initialized
DEBUG - 2020-02-25 08:34:45 --> services MX_Controller Initialized
DEBUG - 2020-02-25 08:34:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 08:34:45 --> Model Class Initialized
INFO - 2020-02-25 08:34:45 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 08:34:45 --> Could not find the language line "Delele"
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 08:34:46 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 08:34:46 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 08:34:46 --> Model Class Initialized
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 08:34:46 --> Model Class Initialized
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 08:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 08:34:46 --> Final output sent to browser
DEBUG - 2020-02-25 08:34:46 --> Total execution time: 2.2447
INFO - 2020-02-25 16:38:45 --> Config Class Initialized
INFO - 2020-02-25 16:38:45 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:38:46 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:38:46 --> Utf8 Class Initialized
INFO - 2020-02-25 16:38:46 --> URI Class Initialized
INFO - 2020-02-25 16:38:46 --> Router Class Initialized
INFO - 2020-02-25 16:38:46 --> Output Class Initialized
INFO - 2020-02-25 16:38:46 --> Security Class Initialized
DEBUG - 2020-02-25 16:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:38:46 --> CSRF cookie sent
INFO - 2020-02-25 16:38:46 --> Input Class Initialized
INFO - 2020-02-25 16:38:46 --> Language Class Initialized
INFO - 2020-02-25 16:38:46 --> Language Class Initialized
INFO - 2020-02-25 16:38:46 --> Config Class Initialized
INFO - 2020-02-25 16:38:46 --> Loader Class Initialized
INFO - 2020-02-25 16:38:46 --> Helper loaded: url_helper
INFO - 2020-02-25 16:38:46 --> Helper loaded: common_helper
INFO - 2020-02-25 16:38:46 --> Helper loaded: language_helper
INFO - 2020-02-25 16:38:46 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:38:46 --> Helper loaded: email_helper
INFO - 2020-02-25 16:38:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:38:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:38:46 --> Parser Class Initialized
INFO - 2020-02-25 16:38:46 --> User Agent Class Initialized
INFO - 2020-02-25 16:38:46 --> Model Class Initialized
INFO - 2020-02-25 16:38:46 --> Database Driver Class Initialized
INFO - 2020-02-25 16:38:46 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:46 --> Template Class Initialized
INFO - 2020-02-25 16:38:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:38:47 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:38:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:38:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:38:47 --> Encryption Class Initialized
INFO - 2020-02-25 16:38:47 --> Controller Class Initialized
DEBUG - 2020-02-25 16:38:47 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:38:47 --> Model Class Initialized
ERROR - 2020-02-25 16:38:47 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:38:47 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 16:38:47 --> Could not find the language line "Delele"
ERROR - 2020-02-25 16:38:47 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:38:47 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:38:47 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:47 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:38:47 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:38:47 --> Final output sent to browser
DEBUG - 2020-02-25 16:38:47 --> Total execution time: 1.7575
INFO - 2020-02-25 16:38:51 --> Config Class Initialized
INFO - 2020-02-25 16:38:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:38:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:38:51 --> Utf8 Class Initialized
INFO - 2020-02-25 16:38:51 --> URI Class Initialized
INFO - 2020-02-25 16:38:51 --> Router Class Initialized
INFO - 2020-02-25 16:38:51 --> Output Class Initialized
INFO - 2020-02-25 16:38:51 --> Security Class Initialized
DEBUG - 2020-02-25 16:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:38:51 --> CSRF cookie sent
INFO - 2020-02-25 16:38:51 --> Input Class Initialized
INFO - 2020-02-25 16:38:51 --> Language Class Initialized
INFO - 2020-02-25 16:38:51 --> Language Class Initialized
INFO - 2020-02-25 16:38:51 --> Config Class Initialized
INFO - 2020-02-25 16:38:51 --> Loader Class Initialized
INFO - 2020-02-25 16:38:51 --> Helper loaded: url_helper
INFO - 2020-02-25 16:38:51 --> Helper loaded: common_helper
INFO - 2020-02-25 16:38:51 --> Helper loaded: language_helper
INFO - 2020-02-25 16:38:52 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:38:52 --> Helper loaded: email_helper
INFO - 2020-02-25 16:38:52 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:38:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:38:52 --> Parser Class Initialized
INFO - 2020-02-25 16:38:52 --> User Agent Class Initialized
INFO - 2020-02-25 16:38:52 --> Model Class Initialized
INFO - 2020-02-25 16:38:52 --> Database Driver Class Initialized
INFO - 2020-02-25 16:38:52 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:52 --> Template Class Initialized
INFO - 2020-02-25 16:38:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:38:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:38:52 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:38:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:38:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:38:52 --> Encryption Class Initialized
INFO - 2020-02-25 16:38:52 --> Controller Class Initialized
DEBUG - 2020-02-25 16:38:52 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:38:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:38:52 --> Model Class Initialized
ERROR - 2020-02-25 16:38:52 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:38:52 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:38:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:38:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:38:52 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:38:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:38:52 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:52 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:38:52 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:38:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:38:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:38:52 --> Final output sent to browser
DEBUG - 2020-02-25 16:38:52 --> Total execution time: 0.6131
INFO - 2020-02-25 16:38:56 --> Config Class Initialized
INFO - 2020-02-25 16:38:56 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:38:56 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:38:56 --> Utf8 Class Initialized
INFO - 2020-02-25 16:38:56 --> URI Class Initialized
INFO - 2020-02-25 16:38:56 --> Router Class Initialized
INFO - 2020-02-25 16:38:56 --> Output Class Initialized
INFO - 2020-02-25 16:38:56 --> Security Class Initialized
DEBUG - 2020-02-25 16:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:38:56 --> CSRF cookie sent
INFO - 2020-02-25 16:38:56 --> Input Class Initialized
INFO - 2020-02-25 16:38:56 --> Language Class Initialized
INFO - 2020-02-25 16:38:56 --> Language Class Initialized
INFO - 2020-02-25 16:38:56 --> Config Class Initialized
INFO - 2020-02-25 16:38:56 --> Loader Class Initialized
INFO - 2020-02-25 16:38:56 --> Helper loaded: url_helper
INFO - 2020-02-25 16:38:56 --> Helper loaded: common_helper
INFO - 2020-02-25 16:38:56 --> Helper loaded: language_helper
INFO - 2020-02-25 16:38:56 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:38:56 --> Helper loaded: email_helper
INFO - 2020-02-25 16:38:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:38:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:38:56 --> Parser Class Initialized
INFO - 2020-02-25 16:38:56 --> User Agent Class Initialized
INFO - 2020-02-25 16:38:56 --> Model Class Initialized
INFO - 2020-02-25 16:38:56 --> Database Driver Class Initialized
INFO - 2020-02-25 16:38:56 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:56 --> Template Class Initialized
INFO - 2020-02-25 16:38:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:38:56 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:38:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:38:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:38:56 --> Encryption Class Initialized
INFO - 2020-02-25 16:38:56 --> Controller Class Initialized
DEBUG - 2020-02-25 16:38:56 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:38:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:38:56 --> Model Class Initialized
ERROR - 2020-02-25 16:38:56 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:38:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:38:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:38:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:38:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:38:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:38:56 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:38:56 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:38:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:38:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:38:56 --> Final output sent to browser
DEBUG - 2020-02-25 16:38:56 --> Total execution time: 0.6000
INFO - 2020-02-25 16:38:59 --> Config Class Initialized
INFO - 2020-02-25 16:38:59 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:38:59 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:38:59 --> Utf8 Class Initialized
INFO - 2020-02-25 16:38:59 --> URI Class Initialized
INFO - 2020-02-25 16:38:59 --> Router Class Initialized
INFO - 2020-02-25 16:38:59 --> Output Class Initialized
INFO - 2020-02-25 16:38:59 --> Security Class Initialized
DEBUG - 2020-02-25 16:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:38:59 --> CSRF cookie sent
INFO - 2020-02-25 16:38:59 --> Input Class Initialized
INFO - 2020-02-25 16:38:59 --> Language Class Initialized
INFO - 2020-02-25 16:38:59 --> Language Class Initialized
INFO - 2020-02-25 16:38:59 --> Config Class Initialized
INFO - 2020-02-25 16:38:59 --> Loader Class Initialized
INFO - 2020-02-25 16:38:59 --> Helper loaded: url_helper
INFO - 2020-02-25 16:38:59 --> Helper loaded: common_helper
INFO - 2020-02-25 16:38:59 --> Helper loaded: language_helper
INFO - 2020-02-25 16:38:59 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:38:59 --> Helper loaded: email_helper
INFO - 2020-02-25 16:38:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:38:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:38:59 --> Parser Class Initialized
INFO - 2020-02-25 16:38:59 --> User Agent Class Initialized
INFO - 2020-02-25 16:38:59 --> Model Class Initialized
INFO - 2020-02-25 16:38:59 --> Database Driver Class Initialized
INFO - 2020-02-25 16:38:59 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:59 --> Template Class Initialized
INFO - 2020-02-25 16:38:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:38:59 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:38:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:38:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:38:59 --> Encryption Class Initialized
INFO - 2020-02-25 16:38:59 --> Controller Class Initialized
DEBUG - 2020-02-25 16:38:59 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:38:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:38:59 --> Model Class Initialized
ERROR - 2020-02-25 16:38:59 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:38:59 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:38:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:38:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:38:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:38:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:38:59 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:59 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:38:59 --> Model Class Initialized
DEBUG - 2020-02-25 16:38:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:38:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:38:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:38:59 --> Final output sent to browser
DEBUG - 2020-02-25 16:38:59 --> Total execution time: 0.5597
INFO - 2020-02-25 16:39:00 --> Config Class Initialized
INFO - 2020-02-25 16:39:00 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:39:00 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:39:01 --> Utf8 Class Initialized
INFO - 2020-02-25 16:39:01 --> URI Class Initialized
INFO - 2020-02-25 16:39:01 --> Router Class Initialized
INFO - 2020-02-25 16:39:01 --> Output Class Initialized
INFO - 2020-02-25 16:39:01 --> Security Class Initialized
DEBUG - 2020-02-25 16:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:39:01 --> CSRF cookie sent
INFO - 2020-02-25 16:39:01 --> Input Class Initialized
INFO - 2020-02-25 16:39:01 --> Language Class Initialized
INFO - 2020-02-25 16:39:01 --> Language Class Initialized
INFO - 2020-02-25 16:39:01 --> Config Class Initialized
INFO - 2020-02-25 16:39:01 --> Loader Class Initialized
INFO - 2020-02-25 16:39:01 --> Helper loaded: url_helper
INFO - 2020-02-25 16:39:01 --> Helper loaded: common_helper
INFO - 2020-02-25 16:39:01 --> Helper loaded: language_helper
INFO - 2020-02-25 16:39:01 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:39:01 --> Helper loaded: email_helper
INFO - 2020-02-25 16:39:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:39:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:39:01 --> Parser Class Initialized
INFO - 2020-02-25 16:39:01 --> User Agent Class Initialized
INFO - 2020-02-25 16:39:01 --> Model Class Initialized
INFO - 2020-02-25 16:39:01 --> Database Driver Class Initialized
INFO - 2020-02-25 16:39:01 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:01 --> Template Class Initialized
INFO - 2020-02-25 16:39:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:39:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:39:01 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:39:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:39:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:39:01 --> Encryption Class Initialized
INFO - 2020-02-25 16:39:01 --> Controller Class Initialized
DEBUG - 2020-02-25 16:39:01 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:01 --> Model Class Initialized
ERROR - 2020-02-25 16:39:01 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:39:01 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:39:01 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:39:01 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:01 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:01 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:39:01 --> Final output sent to browser
DEBUG - 2020-02-25 16:39:01 --> Total execution time: 0.5764
INFO - 2020-02-25 16:39:09 --> Config Class Initialized
INFO - 2020-02-25 16:39:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:39:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:39:09 --> Utf8 Class Initialized
INFO - 2020-02-25 16:39:09 --> URI Class Initialized
INFO - 2020-02-25 16:39:09 --> Router Class Initialized
INFO - 2020-02-25 16:39:09 --> Output Class Initialized
INFO - 2020-02-25 16:39:09 --> Security Class Initialized
DEBUG - 2020-02-25 16:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:39:09 --> CSRF cookie sent
INFO - 2020-02-25 16:39:09 --> Input Class Initialized
INFO - 2020-02-25 16:39:09 --> Language Class Initialized
INFO - 2020-02-25 16:39:09 --> Language Class Initialized
INFO - 2020-02-25 16:39:09 --> Config Class Initialized
INFO - 2020-02-25 16:39:09 --> Loader Class Initialized
INFO - 2020-02-25 16:39:09 --> Helper loaded: url_helper
INFO - 2020-02-25 16:39:09 --> Helper loaded: common_helper
INFO - 2020-02-25 16:39:09 --> Helper loaded: language_helper
INFO - 2020-02-25 16:39:09 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:39:10 --> Helper loaded: email_helper
INFO - 2020-02-25 16:39:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:39:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:39:10 --> Parser Class Initialized
INFO - 2020-02-25 16:39:10 --> User Agent Class Initialized
INFO - 2020-02-25 16:39:10 --> Model Class Initialized
INFO - 2020-02-25 16:39:10 --> Database Driver Class Initialized
INFO - 2020-02-25 16:39:10 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:10 --> Template Class Initialized
INFO - 2020-02-25 16:39:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:39:10 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:39:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:39:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:39:10 --> Encryption Class Initialized
INFO - 2020-02-25 16:39:10 --> Controller Class Initialized
DEBUG - 2020-02-25 16:39:10 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:10 --> Model Class Initialized
ERROR - 2020-02-25 16:39:10 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:39:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:39:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:39:10 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:10 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:39:10 --> Final output sent to browser
DEBUG - 2020-02-25 16:39:10 --> Total execution time: 0.6261
INFO - 2020-02-25 16:39:11 --> Config Class Initialized
INFO - 2020-02-25 16:39:11 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:39:11 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:39:11 --> Utf8 Class Initialized
INFO - 2020-02-25 16:39:11 --> URI Class Initialized
INFO - 2020-02-25 16:39:11 --> Router Class Initialized
INFO - 2020-02-25 16:39:11 --> Output Class Initialized
INFO - 2020-02-25 16:39:11 --> Security Class Initialized
DEBUG - 2020-02-25 16:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:39:11 --> CSRF cookie sent
INFO - 2020-02-25 16:39:11 --> Input Class Initialized
INFO - 2020-02-25 16:39:11 --> Language Class Initialized
INFO - 2020-02-25 16:39:11 --> Language Class Initialized
INFO - 2020-02-25 16:39:11 --> Config Class Initialized
INFO - 2020-02-25 16:39:11 --> Loader Class Initialized
INFO - 2020-02-25 16:39:11 --> Helper loaded: url_helper
INFO - 2020-02-25 16:39:11 --> Helper loaded: common_helper
INFO - 2020-02-25 16:39:11 --> Helper loaded: language_helper
INFO - 2020-02-25 16:39:11 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:39:11 --> Helper loaded: email_helper
INFO - 2020-02-25 16:39:11 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:39:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:39:11 --> Parser Class Initialized
INFO - 2020-02-25 16:39:11 --> User Agent Class Initialized
INFO - 2020-02-25 16:39:11 --> Model Class Initialized
INFO - 2020-02-25 16:39:11 --> Database Driver Class Initialized
INFO - 2020-02-25 16:39:12 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:12 --> Template Class Initialized
INFO - 2020-02-25 16:39:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:39:12 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:39:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:39:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:39:12 --> Encryption Class Initialized
INFO - 2020-02-25 16:39:12 --> Controller Class Initialized
DEBUG - 2020-02-25 16:39:12 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:39:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:12 --> Model Class Initialized
ERROR - 2020-02-25 16:39:12 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:39:12 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:39:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:39:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:39:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:39:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:39:12 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:12 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:39:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:39:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:39:12 --> Final output sent to browser
DEBUG - 2020-02-25 16:39:12 --> Total execution time: 0.6034
INFO - 2020-02-25 16:39:13 --> Config Class Initialized
INFO - 2020-02-25 16:39:13 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:39:13 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:39:13 --> Utf8 Class Initialized
INFO - 2020-02-25 16:39:13 --> URI Class Initialized
INFO - 2020-02-25 16:39:13 --> Router Class Initialized
INFO - 2020-02-25 16:39:13 --> Output Class Initialized
INFO - 2020-02-25 16:39:13 --> Security Class Initialized
DEBUG - 2020-02-25 16:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:39:13 --> CSRF cookie sent
INFO - 2020-02-25 16:39:13 --> Input Class Initialized
INFO - 2020-02-25 16:39:13 --> Language Class Initialized
INFO - 2020-02-25 16:39:13 --> Language Class Initialized
INFO - 2020-02-25 16:39:13 --> Config Class Initialized
INFO - 2020-02-25 16:39:13 --> Loader Class Initialized
INFO - 2020-02-25 16:39:13 --> Helper loaded: url_helper
INFO - 2020-02-25 16:39:13 --> Helper loaded: common_helper
INFO - 2020-02-25 16:39:13 --> Helper loaded: language_helper
INFO - 2020-02-25 16:39:13 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:39:13 --> Helper loaded: email_helper
INFO - 2020-02-25 16:39:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:39:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:39:13 --> Parser Class Initialized
INFO - 2020-02-25 16:39:13 --> User Agent Class Initialized
INFO - 2020-02-25 16:39:13 --> Model Class Initialized
INFO - 2020-02-25 16:39:13 --> Database Driver Class Initialized
INFO - 2020-02-25 16:39:13 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:13 --> Template Class Initialized
INFO - 2020-02-25 16:39:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:39:13 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:39:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:39:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:39:13 --> Encryption Class Initialized
INFO - 2020-02-25 16:39:13 --> Controller Class Initialized
DEBUG - 2020-02-25 16:39:13 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:39:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:13 --> Model Class Initialized
ERROR - 2020-02-25 16:39:14 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:39:14 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:39:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:39:14 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:14 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:39:14 --> Final output sent to browser
DEBUG - 2020-02-25 16:39:14 --> Total execution time: 0.6118
INFO - 2020-02-25 16:39:15 --> Config Class Initialized
INFO - 2020-02-25 16:39:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:39:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:39:15 --> Utf8 Class Initialized
INFO - 2020-02-25 16:39:15 --> URI Class Initialized
INFO - 2020-02-25 16:39:15 --> Router Class Initialized
INFO - 2020-02-25 16:39:15 --> Output Class Initialized
INFO - 2020-02-25 16:39:15 --> Security Class Initialized
DEBUG - 2020-02-25 16:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:39:15 --> CSRF cookie sent
INFO - 2020-02-25 16:39:15 --> Input Class Initialized
INFO - 2020-02-25 16:39:15 --> Language Class Initialized
INFO - 2020-02-25 16:39:15 --> Language Class Initialized
INFO - 2020-02-25 16:39:15 --> Config Class Initialized
INFO - 2020-02-25 16:39:15 --> Loader Class Initialized
INFO - 2020-02-25 16:39:15 --> Helper loaded: url_helper
INFO - 2020-02-25 16:39:15 --> Helper loaded: common_helper
INFO - 2020-02-25 16:39:15 --> Helper loaded: language_helper
INFO - 2020-02-25 16:39:15 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:39:15 --> Helper loaded: email_helper
INFO - 2020-02-25 16:39:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:39:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:39:15 --> Parser Class Initialized
INFO - 2020-02-25 16:39:15 --> User Agent Class Initialized
INFO - 2020-02-25 16:39:15 --> Model Class Initialized
INFO - 2020-02-25 16:39:15 --> Database Driver Class Initialized
INFO - 2020-02-25 16:39:15 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:15 --> Template Class Initialized
INFO - 2020-02-25 16:39:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:39:15 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:39:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:39:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:39:15 --> Encryption Class Initialized
INFO - 2020-02-25 16:39:15 --> Controller Class Initialized
DEBUG - 2020-02-25 16:39:15 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:15 --> Model Class Initialized
ERROR - 2020-02-25 16:39:15 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:39:15 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:39:15 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:39:15 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:15 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:15 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:39:15 --> Final output sent to browser
DEBUG - 2020-02-25 16:39:15 --> Total execution time: 0.6104
INFO - 2020-02-25 16:39:17 --> Config Class Initialized
INFO - 2020-02-25 16:39:17 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:39:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:39:17 --> Utf8 Class Initialized
INFO - 2020-02-25 16:39:17 --> URI Class Initialized
INFO - 2020-02-25 16:39:17 --> Router Class Initialized
INFO - 2020-02-25 16:39:17 --> Output Class Initialized
INFO - 2020-02-25 16:39:17 --> Security Class Initialized
DEBUG - 2020-02-25 16:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:39:17 --> CSRF cookie sent
INFO - 2020-02-25 16:39:17 --> Input Class Initialized
INFO - 2020-02-25 16:39:17 --> Language Class Initialized
INFO - 2020-02-25 16:39:17 --> Language Class Initialized
INFO - 2020-02-25 16:39:17 --> Config Class Initialized
INFO - 2020-02-25 16:39:17 --> Loader Class Initialized
INFO - 2020-02-25 16:39:17 --> Helper loaded: url_helper
INFO - 2020-02-25 16:39:17 --> Helper loaded: common_helper
INFO - 2020-02-25 16:39:17 --> Helper loaded: language_helper
INFO - 2020-02-25 16:39:17 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:39:17 --> Helper loaded: email_helper
INFO - 2020-02-25 16:39:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:39:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:39:17 --> Parser Class Initialized
INFO - 2020-02-25 16:39:17 --> User Agent Class Initialized
INFO - 2020-02-25 16:39:17 --> Model Class Initialized
INFO - 2020-02-25 16:39:17 --> Database Driver Class Initialized
INFO - 2020-02-25 16:39:17 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:17 --> Template Class Initialized
INFO - 2020-02-25 16:39:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:39:17 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:39:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:39:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:39:17 --> Encryption Class Initialized
INFO - 2020-02-25 16:39:17 --> Controller Class Initialized
DEBUG - 2020-02-25 16:39:17 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:17 --> Model Class Initialized
ERROR - 2020-02-25 16:39:17 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:39:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:39:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:39:17 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:17 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:39:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:39:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:39:18 --> Final output sent to browser
DEBUG - 2020-02-25 16:39:18 --> Total execution time: 0.6305
INFO - 2020-02-25 16:39:19 --> Config Class Initialized
INFO - 2020-02-25 16:39:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:39:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:39:19 --> Utf8 Class Initialized
INFO - 2020-02-25 16:39:19 --> URI Class Initialized
INFO - 2020-02-25 16:39:19 --> Router Class Initialized
INFO - 2020-02-25 16:39:19 --> Output Class Initialized
INFO - 2020-02-25 16:39:19 --> Security Class Initialized
DEBUG - 2020-02-25 16:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:39:19 --> CSRF cookie sent
INFO - 2020-02-25 16:39:19 --> Input Class Initialized
INFO - 2020-02-25 16:39:19 --> Language Class Initialized
INFO - 2020-02-25 16:39:19 --> Language Class Initialized
INFO - 2020-02-25 16:39:19 --> Config Class Initialized
INFO - 2020-02-25 16:39:19 --> Loader Class Initialized
INFO - 2020-02-25 16:39:19 --> Helper loaded: url_helper
INFO - 2020-02-25 16:39:19 --> Helper loaded: common_helper
INFO - 2020-02-25 16:39:19 --> Helper loaded: language_helper
INFO - 2020-02-25 16:39:19 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:39:19 --> Helper loaded: email_helper
INFO - 2020-02-25 16:39:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:39:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:39:19 --> Parser Class Initialized
INFO - 2020-02-25 16:39:19 --> User Agent Class Initialized
INFO - 2020-02-25 16:39:19 --> Model Class Initialized
INFO - 2020-02-25 16:39:19 --> Database Driver Class Initialized
INFO - 2020-02-25 16:39:19 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:19 --> Template Class Initialized
INFO - 2020-02-25 16:39:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:39:19 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:39:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:39:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:39:19 --> Encryption Class Initialized
INFO - 2020-02-25 16:39:19 --> Controller Class Initialized
DEBUG - 2020-02-25 16:39:19 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:19 --> Model Class Initialized
ERROR - 2020-02-25 16:39:19 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:39:19 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:39:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:39:19 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:19 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:19 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:39:19 --> Final output sent to browser
DEBUG - 2020-02-25 16:39:19 --> Total execution time: 0.6025
INFO - 2020-02-25 16:39:21 --> Config Class Initialized
INFO - 2020-02-25 16:39:21 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:39:21 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:39:21 --> Utf8 Class Initialized
INFO - 2020-02-25 16:39:21 --> URI Class Initialized
INFO - 2020-02-25 16:39:21 --> Router Class Initialized
INFO - 2020-02-25 16:39:21 --> Output Class Initialized
INFO - 2020-02-25 16:39:21 --> Security Class Initialized
DEBUG - 2020-02-25 16:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:39:21 --> CSRF cookie sent
INFO - 2020-02-25 16:39:21 --> Input Class Initialized
INFO - 2020-02-25 16:39:21 --> Language Class Initialized
INFO - 2020-02-25 16:39:21 --> Language Class Initialized
INFO - 2020-02-25 16:39:21 --> Config Class Initialized
INFO - 2020-02-25 16:39:21 --> Loader Class Initialized
INFO - 2020-02-25 16:39:21 --> Helper loaded: url_helper
INFO - 2020-02-25 16:39:21 --> Helper loaded: common_helper
INFO - 2020-02-25 16:39:21 --> Helper loaded: language_helper
INFO - 2020-02-25 16:39:21 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:39:21 --> Helper loaded: email_helper
INFO - 2020-02-25 16:39:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:39:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:39:21 --> Parser Class Initialized
INFO - 2020-02-25 16:39:21 --> User Agent Class Initialized
INFO - 2020-02-25 16:39:21 --> Model Class Initialized
INFO - 2020-02-25 16:39:21 --> Database Driver Class Initialized
INFO - 2020-02-25 16:39:21 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:21 --> Template Class Initialized
INFO - 2020-02-25 16:39:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:39:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:39:21 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:39:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:39:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:39:21 --> Encryption Class Initialized
INFO - 2020-02-25 16:39:21 --> Controller Class Initialized
DEBUG - 2020-02-25 16:39:21 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:39:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:21 --> Model Class Initialized
ERROR - 2020-02-25 16:39:21 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:39:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:39:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:39:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:39:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:39:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:39:21 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:21 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:39:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:39:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:39:21 --> Final output sent to browser
DEBUG - 2020-02-25 16:39:21 --> Total execution time: 0.6000
INFO - 2020-02-25 16:39:23 --> Config Class Initialized
INFO - 2020-02-25 16:39:23 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:39:23 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:39:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:39:23 --> URI Class Initialized
INFO - 2020-02-25 16:39:23 --> Router Class Initialized
INFO - 2020-02-25 16:39:23 --> Output Class Initialized
INFO - 2020-02-25 16:39:23 --> Security Class Initialized
DEBUG - 2020-02-25 16:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:39:23 --> CSRF cookie sent
INFO - 2020-02-25 16:39:23 --> Input Class Initialized
INFO - 2020-02-25 16:39:23 --> Language Class Initialized
INFO - 2020-02-25 16:39:23 --> Language Class Initialized
INFO - 2020-02-25 16:39:23 --> Config Class Initialized
INFO - 2020-02-25 16:39:23 --> Loader Class Initialized
INFO - 2020-02-25 16:39:23 --> Helper loaded: url_helper
INFO - 2020-02-25 16:39:23 --> Helper loaded: common_helper
INFO - 2020-02-25 16:39:23 --> Helper loaded: language_helper
INFO - 2020-02-25 16:39:23 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:39:23 --> Helper loaded: email_helper
INFO - 2020-02-25 16:39:23 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:39:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:39:23 --> Parser Class Initialized
INFO - 2020-02-25 16:39:23 --> User Agent Class Initialized
INFO - 2020-02-25 16:39:23 --> Model Class Initialized
INFO - 2020-02-25 16:39:23 --> Database Driver Class Initialized
INFO - 2020-02-25 16:39:23 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:23 --> Template Class Initialized
INFO - 2020-02-25 16:39:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:39:23 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:39:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:39:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:39:23 --> Encryption Class Initialized
INFO - 2020-02-25 16:39:23 --> Controller Class Initialized
DEBUG - 2020-02-25 16:39:23 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:39:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:23 --> Model Class Initialized
ERROR - 2020-02-25 16:39:23 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:39:23 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:39:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:39:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:39:23 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:39:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:39:23 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:23 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:39:23 --> Model Class Initialized
DEBUG - 2020-02-25 16:39:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:39:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:39:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:39:23 --> Final output sent to browser
DEBUG - 2020-02-25 16:39:23 --> Total execution time: 0.6151
INFO - 2020-02-25 16:41:28 --> Config Class Initialized
INFO - 2020-02-25 16:41:28 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:41:28 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:41:28 --> Utf8 Class Initialized
INFO - 2020-02-25 16:41:28 --> URI Class Initialized
INFO - 2020-02-25 16:41:28 --> Router Class Initialized
INFO - 2020-02-25 16:41:28 --> Output Class Initialized
INFO - 2020-02-25 16:41:28 --> Security Class Initialized
DEBUG - 2020-02-25 16:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:41:28 --> CSRF cookie sent
INFO - 2020-02-25 16:41:28 --> Input Class Initialized
INFO - 2020-02-25 16:41:28 --> Language Class Initialized
INFO - 2020-02-25 16:41:28 --> Language Class Initialized
INFO - 2020-02-25 16:41:28 --> Config Class Initialized
INFO - 2020-02-25 16:41:28 --> Loader Class Initialized
INFO - 2020-02-25 16:41:28 --> Helper loaded: url_helper
INFO - 2020-02-25 16:41:28 --> Helper loaded: common_helper
INFO - 2020-02-25 16:41:28 --> Helper loaded: language_helper
INFO - 2020-02-25 16:41:28 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:41:28 --> Helper loaded: email_helper
INFO - 2020-02-25 16:41:28 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:41:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:41:28 --> Parser Class Initialized
INFO - 2020-02-25 16:41:28 --> User Agent Class Initialized
INFO - 2020-02-25 16:41:28 --> Model Class Initialized
INFO - 2020-02-25 16:41:28 --> Database Driver Class Initialized
INFO - 2020-02-25 16:41:28 --> Model Class Initialized
DEBUG - 2020-02-25 16:41:28 --> Template Class Initialized
INFO - 2020-02-25 16:41:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:41:28 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:41:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:41:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:41:29 --> Encryption Class Initialized
INFO - 2020-02-25 16:41:29 --> Controller Class Initialized
DEBUG - 2020-02-25 16:41:29 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:41:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:41:29 --> Model Class Initialized
ERROR - 2020-02-25 16:41:29 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:41:32 --> Config Class Initialized
INFO - 2020-02-25 16:41:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:41:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:41:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:41:32 --> URI Class Initialized
INFO - 2020-02-25 16:41:32 --> Router Class Initialized
INFO - 2020-02-25 16:41:32 --> Output Class Initialized
INFO - 2020-02-25 16:41:32 --> Security Class Initialized
DEBUG - 2020-02-25 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:41:32 --> CSRF cookie sent
INFO - 2020-02-25 16:41:32 --> Input Class Initialized
INFO - 2020-02-25 16:41:32 --> Language Class Initialized
INFO - 2020-02-25 16:41:32 --> Language Class Initialized
INFO - 2020-02-25 16:41:32 --> Config Class Initialized
INFO - 2020-02-25 16:41:32 --> Loader Class Initialized
INFO - 2020-02-25 16:41:32 --> Helper loaded: url_helper
INFO - 2020-02-25 16:41:32 --> Helper loaded: common_helper
INFO - 2020-02-25 16:41:32 --> Helper loaded: language_helper
INFO - 2020-02-25 16:41:32 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:41:32 --> Helper loaded: email_helper
INFO - 2020-02-25 16:41:32 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:41:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:41:32 --> Parser Class Initialized
INFO - 2020-02-25 16:41:32 --> User Agent Class Initialized
INFO - 2020-02-25 16:41:32 --> Model Class Initialized
INFO - 2020-02-25 16:41:32 --> Database Driver Class Initialized
INFO - 2020-02-25 16:41:32 --> Model Class Initialized
DEBUG - 2020-02-25 16:41:32 --> Template Class Initialized
INFO - 2020-02-25 16:41:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:41:32 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:41:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:41:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:41:32 --> Encryption Class Initialized
INFO - 2020-02-25 16:41:32 --> Controller Class Initialized
DEBUG - 2020-02-25 16:41:32 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:41:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:41:32 --> Model Class Initialized
ERROR - 2020-02-25 16:41:32 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:41:51 --> Config Class Initialized
INFO - 2020-02-25 16:41:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:41:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:41:51 --> Utf8 Class Initialized
INFO - 2020-02-25 16:41:51 --> URI Class Initialized
INFO - 2020-02-25 16:41:51 --> Router Class Initialized
INFO - 2020-02-25 16:41:52 --> Output Class Initialized
INFO - 2020-02-25 16:41:52 --> Security Class Initialized
DEBUG - 2020-02-25 16:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:41:52 --> CSRF cookie sent
INFO - 2020-02-25 16:41:52 --> Input Class Initialized
INFO - 2020-02-25 16:41:52 --> Language Class Initialized
INFO - 2020-02-25 16:41:52 --> Language Class Initialized
INFO - 2020-02-25 16:41:52 --> Config Class Initialized
INFO - 2020-02-25 16:41:52 --> Loader Class Initialized
INFO - 2020-02-25 16:41:52 --> Helper loaded: url_helper
INFO - 2020-02-25 16:41:52 --> Helper loaded: common_helper
INFO - 2020-02-25 16:41:52 --> Helper loaded: language_helper
INFO - 2020-02-25 16:41:52 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:41:52 --> Helper loaded: email_helper
INFO - 2020-02-25 16:41:52 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:41:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:41:52 --> Parser Class Initialized
INFO - 2020-02-25 16:41:52 --> User Agent Class Initialized
INFO - 2020-02-25 16:41:52 --> Model Class Initialized
INFO - 2020-02-25 16:41:52 --> Database Driver Class Initialized
INFO - 2020-02-25 16:41:52 --> Model Class Initialized
DEBUG - 2020-02-25 16:41:52 --> Template Class Initialized
INFO - 2020-02-25 16:41:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:41:52 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:41:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:41:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:41:52 --> Encryption Class Initialized
INFO - 2020-02-25 16:41:52 --> Controller Class Initialized
DEBUG - 2020-02-25 16:41:52 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:41:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:41:52 --> Model Class Initialized
ERROR - 2020-02-25 16:41:52 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:42:06 --> Config Class Initialized
INFO - 2020-02-25 16:42:06 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:42:06 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:42:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:42:06 --> URI Class Initialized
INFO - 2020-02-25 16:42:06 --> Router Class Initialized
INFO - 2020-02-25 16:42:06 --> Output Class Initialized
INFO - 2020-02-25 16:42:06 --> Security Class Initialized
DEBUG - 2020-02-25 16:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:42:06 --> CSRF cookie sent
INFO - 2020-02-25 16:42:06 --> Input Class Initialized
INFO - 2020-02-25 16:42:06 --> Language Class Initialized
INFO - 2020-02-25 16:42:06 --> Language Class Initialized
INFO - 2020-02-25 16:42:06 --> Config Class Initialized
INFO - 2020-02-25 16:42:06 --> Loader Class Initialized
INFO - 2020-02-25 16:42:06 --> Helper loaded: url_helper
INFO - 2020-02-25 16:42:06 --> Helper loaded: common_helper
INFO - 2020-02-25 16:42:06 --> Helper loaded: language_helper
INFO - 2020-02-25 16:42:06 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:42:06 --> Helper loaded: email_helper
INFO - 2020-02-25 16:42:06 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:42:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:42:06 --> Parser Class Initialized
INFO - 2020-02-25 16:42:06 --> User Agent Class Initialized
INFO - 2020-02-25 16:42:06 --> Model Class Initialized
INFO - 2020-02-25 16:42:06 --> Database Driver Class Initialized
INFO - 2020-02-25 16:42:06 --> Model Class Initialized
DEBUG - 2020-02-25 16:42:06 --> Template Class Initialized
INFO - 2020-02-25 16:42:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:42:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:42:06 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:42:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:42:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:42:06 --> Encryption Class Initialized
INFO - 2020-02-25 16:42:06 --> Controller Class Initialized
DEBUG - 2020-02-25 16:42:06 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:42:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:42:06 --> Model Class Initialized
ERROR - 2020-02-25 16:42:06 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:42:08 --> Config Class Initialized
INFO - 2020-02-25 16:42:08 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:42:08 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:42:08 --> Utf8 Class Initialized
INFO - 2020-02-25 16:42:08 --> URI Class Initialized
INFO - 2020-02-25 16:42:09 --> Router Class Initialized
INFO - 2020-02-25 16:42:09 --> Output Class Initialized
INFO - 2020-02-25 16:42:09 --> Security Class Initialized
DEBUG - 2020-02-25 16:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:42:09 --> CSRF cookie sent
INFO - 2020-02-25 16:42:09 --> Input Class Initialized
INFO - 2020-02-25 16:42:09 --> Language Class Initialized
INFO - 2020-02-25 16:42:09 --> Language Class Initialized
INFO - 2020-02-25 16:42:09 --> Config Class Initialized
INFO - 2020-02-25 16:42:09 --> Loader Class Initialized
INFO - 2020-02-25 16:42:09 --> Helper loaded: url_helper
INFO - 2020-02-25 16:42:09 --> Helper loaded: common_helper
INFO - 2020-02-25 16:42:09 --> Helper loaded: language_helper
INFO - 2020-02-25 16:42:09 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:42:09 --> Helper loaded: email_helper
INFO - 2020-02-25 16:42:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:42:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:42:09 --> Parser Class Initialized
INFO - 2020-02-25 16:42:09 --> User Agent Class Initialized
INFO - 2020-02-25 16:42:09 --> Model Class Initialized
INFO - 2020-02-25 16:42:09 --> Database Driver Class Initialized
INFO - 2020-02-25 16:42:09 --> Model Class Initialized
DEBUG - 2020-02-25 16:42:09 --> Template Class Initialized
INFO - 2020-02-25 16:42:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:42:09 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:42:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:42:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:42:09 --> Encryption Class Initialized
INFO - 2020-02-25 16:42:09 --> Controller Class Initialized
DEBUG - 2020-02-25 16:42:09 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:42:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:42:09 --> Model Class Initialized
ERROR - 2020-02-25 16:42:09 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:42:24 --> Config Class Initialized
INFO - 2020-02-25 16:42:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:42:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:42:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:42:24 --> URI Class Initialized
INFO - 2020-02-25 16:42:24 --> Router Class Initialized
INFO - 2020-02-25 16:42:24 --> Output Class Initialized
INFO - 2020-02-25 16:42:24 --> Security Class Initialized
DEBUG - 2020-02-25 16:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:42:25 --> CSRF cookie sent
INFO - 2020-02-25 16:42:25 --> Input Class Initialized
INFO - 2020-02-25 16:42:25 --> Language Class Initialized
INFO - 2020-02-25 16:42:25 --> Language Class Initialized
INFO - 2020-02-25 16:42:25 --> Config Class Initialized
INFO - 2020-02-25 16:42:25 --> Loader Class Initialized
INFO - 2020-02-25 16:42:25 --> Helper loaded: url_helper
INFO - 2020-02-25 16:42:25 --> Helper loaded: common_helper
INFO - 2020-02-25 16:42:25 --> Helper loaded: language_helper
INFO - 2020-02-25 16:42:25 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:42:25 --> Helper loaded: email_helper
INFO - 2020-02-25 16:42:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:42:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:42:25 --> Parser Class Initialized
INFO - 2020-02-25 16:42:25 --> User Agent Class Initialized
INFO - 2020-02-25 16:42:25 --> Model Class Initialized
INFO - 2020-02-25 16:42:25 --> Database Driver Class Initialized
INFO - 2020-02-25 16:42:25 --> Model Class Initialized
DEBUG - 2020-02-25 16:42:25 --> Template Class Initialized
INFO - 2020-02-25 16:42:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:42:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:42:25 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:42:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:42:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:42:25 --> Encryption Class Initialized
INFO - 2020-02-25 16:42:25 --> Controller Class Initialized
DEBUG - 2020-02-25 16:42:25 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:42:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:42:25 --> Model Class Initialized
ERROR - 2020-02-25 16:42:25 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:43:09 --> Config Class Initialized
INFO - 2020-02-25 16:43:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:09 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:09 --> URI Class Initialized
INFO - 2020-02-25 16:43:09 --> Router Class Initialized
INFO - 2020-02-25 16:43:09 --> Output Class Initialized
INFO - 2020-02-25 16:43:09 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:09 --> CSRF cookie sent
INFO - 2020-02-25 16:43:09 --> Input Class Initialized
INFO - 2020-02-25 16:43:09 --> Language Class Initialized
INFO - 2020-02-25 16:43:09 --> Language Class Initialized
INFO - 2020-02-25 16:43:09 --> Config Class Initialized
INFO - 2020-02-25 16:43:10 --> Loader Class Initialized
INFO - 2020-02-25 16:43:10 --> Helper loaded: url_helper
INFO - 2020-02-25 16:43:10 --> Helper loaded: common_helper
INFO - 2020-02-25 16:43:10 --> Helper loaded: language_helper
INFO - 2020-02-25 16:43:10 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:43:10 --> Helper loaded: email_helper
INFO - 2020-02-25 16:43:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:43:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:43:10 --> Parser Class Initialized
INFO - 2020-02-25 16:43:10 --> User Agent Class Initialized
INFO - 2020-02-25 16:43:10 --> Model Class Initialized
INFO - 2020-02-25 16:43:10 --> Database Driver Class Initialized
INFO - 2020-02-25 16:43:10 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:10 --> Template Class Initialized
INFO - 2020-02-25 16:43:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:43:10 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:43:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:43:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:43:10 --> Encryption Class Initialized
INFO - 2020-02-25 16:43:10 --> Controller Class Initialized
DEBUG - 2020-02-25 16:43:10 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:43:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:43:10 --> Model Class Initialized
ERROR - 2020-02-25 16:43:10 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:43:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:43:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:43:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:43:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:43:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:43:10 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:43:10 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:43:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:43:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:43:10 --> Final output sent to browser
DEBUG - 2020-02-25 16:43:10 --> Total execution time: 0.6714
INFO - 2020-02-25 16:43:42 --> Config Class Initialized
INFO - 2020-02-25 16:43:42 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:42 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:42 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:42 --> URI Class Initialized
INFO - 2020-02-25 16:43:42 --> Router Class Initialized
INFO - 2020-02-25 16:43:42 --> Output Class Initialized
INFO - 2020-02-25 16:43:42 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:42 --> CSRF cookie sent
INFO - 2020-02-25 16:43:42 --> Input Class Initialized
INFO - 2020-02-25 16:43:42 --> Language Class Initialized
INFO - 2020-02-25 16:43:42 --> Language Class Initialized
INFO - 2020-02-25 16:43:42 --> Config Class Initialized
INFO - 2020-02-25 16:43:42 --> Loader Class Initialized
INFO - 2020-02-25 16:43:42 --> Helper loaded: url_helper
INFO - 2020-02-25 16:43:42 --> Helper loaded: common_helper
INFO - 2020-02-25 16:43:42 --> Helper loaded: language_helper
INFO - 2020-02-25 16:43:42 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:43:42 --> Helper loaded: email_helper
INFO - 2020-02-25 16:43:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:43:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:43:42 --> Parser Class Initialized
INFO - 2020-02-25 16:43:42 --> User Agent Class Initialized
INFO - 2020-02-25 16:43:42 --> Model Class Initialized
INFO - 2020-02-25 16:43:42 --> Database Driver Class Initialized
INFO - 2020-02-25 16:43:42 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:42 --> Template Class Initialized
INFO - 2020-02-25 16:43:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:43:42 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:43:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:43:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:43:42 --> Encryption Class Initialized
INFO - 2020-02-25 16:43:42 --> Controller Class Initialized
DEBUG - 2020-02-25 16:43:42 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:43:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:43:42 --> Model Class Initialized
ERROR - 2020-02-25 16:43:42 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:43:42 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:43:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:43:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:43:42 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:43:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:43:42 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:42 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:43:42 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:43:43 --> Final output sent to browser
DEBUG - 2020-02-25 16:43:43 --> Total execution time: 0.6852
INFO - 2020-02-25 16:43:45 --> Config Class Initialized
INFO - 2020-02-25 16:43:45 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:45 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:45 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:45 --> URI Class Initialized
INFO - 2020-02-25 16:43:45 --> Router Class Initialized
INFO - 2020-02-25 16:43:45 --> Output Class Initialized
INFO - 2020-02-25 16:43:45 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:45 --> CSRF cookie sent
INFO - 2020-02-25 16:43:45 --> CSRF token verified
INFO - 2020-02-25 16:43:45 --> Input Class Initialized
INFO - 2020-02-25 16:43:45 --> Language Class Initialized
INFO - 2020-02-25 16:43:45 --> Language Class Initialized
INFO - 2020-02-25 16:43:45 --> Config Class Initialized
INFO - 2020-02-25 16:43:45 --> Loader Class Initialized
INFO - 2020-02-25 16:43:45 --> Helper loaded: url_helper
INFO - 2020-02-25 16:43:45 --> Helper loaded: common_helper
INFO - 2020-02-25 16:43:45 --> Helper loaded: language_helper
INFO - 2020-02-25 16:43:45 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:43:45 --> Helper loaded: email_helper
INFO - 2020-02-25 16:43:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:43:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:43:45 --> Parser Class Initialized
INFO - 2020-02-25 16:43:45 --> User Agent Class Initialized
INFO - 2020-02-25 16:43:45 --> Model Class Initialized
INFO - 2020-02-25 16:43:45 --> Database Driver Class Initialized
INFO - 2020-02-25 16:43:45 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:45 --> Template Class Initialized
INFO - 2020-02-25 16:43:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:43:45 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:43:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:43:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:43:45 --> Encryption Class Initialized
INFO - 2020-02-25 16:43:45 --> Controller Class Initialized
DEBUG - 2020-02-25 16:43:45 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:43:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:43:45 --> Model Class Initialized
ERROR - 2020-02-25 16:43:45 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:43:51 --> Config Class Initialized
INFO - 2020-02-25 16:43:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:51 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:51 --> URI Class Initialized
INFO - 2020-02-25 16:43:51 --> Router Class Initialized
INFO - 2020-02-25 16:43:51 --> Output Class Initialized
INFO - 2020-02-25 16:43:51 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:51 --> CSRF cookie sent
INFO - 2020-02-25 16:43:51 --> Input Class Initialized
INFO - 2020-02-25 16:43:51 --> Language Class Initialized
INFO - 2020-02-25 16:43:51 --> Language Class Initialized
INFO - 2020-02-25 16:43:51 --> Config Class Initialized
INFO - 2020-02-25 16:43:51 --> Loader Class Initialized
INFO - 2020-02-25 16:43:52 --> Helper loaded: url_helper
INFO - 2020-02-25 16:43:52 --> Helper loaded: common_helper
INFO - 2020-02-25 16:43:52 --> Helper loaded: language_helper
INFO - 2020-02-25 16:43:52 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:43:52 --> Helper loaded: email_helper
INFO - 2020-02-25 16:43:52 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:43:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:43:52 --> Parser Class Initialized
INFO - 2020-02-25 16:43:52 --> User Agent Class Initialized
INFO - 2020-02-25 16:43:52 --> Model Class Initialized
INFO - 2020-02-25 16:43:52 --> Database Driver Class Initialized
INFO - 2020-02-25 16:43:52 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Template Class Initialized
INFO - 2020-02-25 16:43:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:43:52 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:43:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:43:52 --> Encryption Class Initialized
INFO - 2020-02-25 16:43:52 --> Controller Class Initialized
DEBUG - 2020-02-25 16:43:52 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:43:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:43:52 --> Model Class Initialized
ERROR - 2020-02-25 16:43:52 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:43:52 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:43:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:43:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:43:52 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:43:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:43:52 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:52 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:43:52 --> Model Class Initialized
DEBUG - 2020-02-25 16:43:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:43:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:43:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:43:52 --> Final output sent to browser
DEBUG - 2020-02-25 16:43:52 --> Total execution time: 0.6758
INFO - 2020-02-25 16:45:09 --> Config Class Initialized
INFO - 2020-02-25 16:45:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:09 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:09 --> URI Class Initialized
INFO - 2020-02-25 16:45:09 --> Router Class Initialized
INFO - 2020-02-25 16:45:09 --> Output Class Initialized
INFO - 2020-02-25 16:45:09 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:09 --> CSRF cookie sent
INFO - 2020-02-25 16:45:09 --> Input Class Initialized
INFO - 2020-02-25 16:45:09 --> Language Class Initialized
INFO - 2020-02-25 16:45:09 --> Language Class Initialized
INFO - 2020-02-25 16:45:09 --> Config Class Initialized
INFO - 2020-02-25 16:45:09 --> Loader Class Initialized
INFO - 2020-02-25 16:45:09 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:09 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:09 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:09 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:09 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:09 --> Parser Class Initialized
INFO - 2020-02-25 16:45:09 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:09 --> Model Class Initialized
INFO - 2020-02-25 16:45:09 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:09 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:09 --> Template Class Initialized
INFO - 2020-02-25 16:45:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:09 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:09 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:09 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:09 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:09 --> Model Class Initialized
ERROR - 2020-02-25 16:45:09 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:09 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:45:09 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:45:09 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:09 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:09 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:45:09 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:09 --> Total execution time: 0.7605
INFO - 2020-02-25 16:45:13 --> Config Class Initialized
INFO - 2020-02-25 16:45:13 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:13 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:13 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:13 --> URI Class Initialized
INFO - 2020-02-25 16:45:13 --> Router Class Initialized
INFO - 2020-02-25 16:45:13 --> Output Class Initialized
INFO - 2020-02-25 16:45:13 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:13 --> CSRF cookie sent
INFO - 2020-02-25 16:45:13 --> CSRF token verified
INFO - 2020-02-25 16:45:13 --> Input Class Initialized
INFO - 2020-02-25 16:45:13 --> Language Class Initialized
INFO - 2020-02-25 16:45:13 --> Language Class Initialized
INFO - 2020-02-25 16:45:13 --> Config Class Initialized
INFO - 2020-02-25 16:45:13 --> Loader Class Initialized
INFO - 2020-02-25 16:45:13 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:13 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:13 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:13 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:13 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:13 --> Parser Class Initialized
INFO - 2020-02-25 16:45:13 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:13 --> Model Class Initialized
INFO - 2020-02-25 16:45:13 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:13 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:13 --> Template Class Initialized
INFO - 2020-02-25 16:45:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:13 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:13 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:13 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:13 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:14 --> Model Class Initialized
ERROR - 2020-02-25 16:45:14 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:18 --> Config Class Initialized
INFO - 2020-02-25 16:45:18 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:18 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:18 --> URI Class Initialized
INFO - 2020-02-25 16:45:18 --> Router Class Initialized
INFO - 2020-02-25 16:45:18 --> Output Class Initialized
INFO - 2020-02-25 16:45:18 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:18 --> CSRF cookie sent
INFO - 2020-02-25 16:45:18 --> Input Class Initialized
INFO - 2020-02-25 16:45:18 --> Language Class Initialized
INFO - 2020-02-25 16:45:18 --> Language Class Initialized
INFO - 2020-02-25 16:45:18 --> Config Class Initialized
INFO - 2020-02-25 16:45:18 --> Loader Class Initialized
INFO - 2020-02-25 16:45:18 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:18 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:18 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:18 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:18 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:18 --> Parser Class Initialized
INFO - 2020-02-25 16:45:18 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:18 --> Model Class Initialized
INFO - 2020-02-25 16:45:18 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:18 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:18 --> Template Class Initialized
INFO - 2020-02-25 16:45:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:19 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:19 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:19 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:19 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:19 --> Model Class Initialized
ERROR - 2020-02-25 16:45:19 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:19 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:45:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:45:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:45:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:45:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:45:19 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:19 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:19 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:45:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:45:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:45:19 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:19 --> Total execution time: 0.8409
INFO - 2020-02-25 16:45:25 --> Config Class Initialized
INFO - 2020-02-25 16:45:25 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:25 --> URI Class Initialized
INFO - 2020-02-25 16:45:25 --> Router Class Initialized
INFO - 2020-02-25 16:45:25 --> Output Class Initialized
INFO - 2020-02-25 16:45:25 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:25 --> CSRF cookie sent
INFO - 2020-02-25 16:45:25 --> Input Class Initialized
INFO - 2020-02-25 16:45:25 --> Language Class Initialized
INFO - 2020-02-25 16:45:25 --> Language Class Initialized
INFO - 2020-02-25 16:45:25 --> Config Class Initialized
INFO - 2020-02-25 16:45:25 --> Loader Class Initialized
INFO - 2020-02-25 16:45:25 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:25 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:25 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:25 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:25 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:25 --> Parser Class Initialized
INFO - 2020-02-25 16:45:25 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:25 --> Model Class Initialized
INFO - 2020-02-25 16:45:25 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:25 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:25 --> Template Class Initialized
INFO - 2020-02-25 16:45:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:25 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:25 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:25 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:25 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:25 --> Model Class Initialized
ERROR - 2020-02-25 16:45:25 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:25 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:45:25 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:45:25 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:25 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:25 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:45:25 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:25 --> Total execution time: 0.7931
INFO - 2020-02-25 16:45:26 --> Config Class Initialized
INFO - 2020-02-25 16:45:26 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:26 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:27 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:27 --> URI Class Initialized
INFO - 2020-02-25 16:45:27 --> Router Class Initialized
INFO - 2020-02-25 16:45:27 --> Output Class Initialized
INFO - 2020-02-25 16:45:27 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:27 --> CSRF cookie sent
INFO - 2020-02-25 16:45:27 --> Input Class Initialized
INFO - 2020-02-25 16:45:27 --> Language Class Initialized
INFO - 2020-02-25 16:45:27 --> Language Class Initialized
INFO - 2020-02-25 16:45:27 --> Config Class Initialized
INFO - 2020-02-25 16:45:27 --> Loader Class Initialized
INFO - 2020-02-25 16:45:27 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:27 --> Parser Class Initialized
INFO - 2020-02-25 16:45:27 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:27 --> Model Class Initialized
INFO - 2020-02-25 16:45:27 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:27 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:27 --> Template Class Initialized
INFO - 2020-02-25 16:45:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:27 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:27 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:27 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:27 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:27 --> Model Class Initialized
ERROR - 2020-02-25 16:45:27 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:27 --> Config Class Initialized
INFO - 2020-02-25 16:45:27 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:27 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:27 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:27 --> URI Class Initialized
INFO - 2020-02-25 16:45:27 --> Router Class Initialized
INFO - 2020-02-25 16:45:27 --> Output Class Initialized
INFO - 2020-02-25 16:45:27 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:27 --> CSRF cookie sent
INFO - 2020-02-25 16:45:27 --> Input Class Initialized
INFO - 2020-02-25 16:45:27 --> Language Class Initialized
INFO - 2020-02-25 16:45:27 --> Language Class Initialized
INFO - 2020-02-25 16:45:27 --> Config Class Initialized
INFO - 2020-02-25 16:45:27 --> Loader Class Initialized
INFO - 2020-02-25 16:45:27 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:27 --> Parser Class Initialized
INFO - 2020-02-25 16:45:27 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:27 --> Model Class Initialized
INFO - 2020-02-25 16:45:27 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:27 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:27 --> Template Class Initialized
INFO - 2020-02-25 16:45:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:27 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:27 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:27 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:27 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:27 --> Model Class Initialized
ERROR - 2020-02-25 16:45:27 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:27 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 16:45:27 --> Could not find the language line "Delele"
ERROR - 2020-02-25 16:45:27 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:45:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 16:45:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 16:45:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:45:28 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:45:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:45:28 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:28 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:28 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:45:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:45:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:45:28 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:28 --> Total execution time: 0.7021
INFO - 2020-02-25 16:45:30 --> Config Class Initialized
INFO - 2020-02-25 16:45:30 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:30 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:30 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:30 --> URI Class Initialized
INFO - 2020-02-25 16:45:30 --> Router Class Initialized
INFO - 2020-02-25 16:45:30 --> Output Class Initialized
INFO - 2020-02-25 16:45:30 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:30 --> CSRF cookie sent
INFO - 2020-02-25 16:45:30 --> Input Class Initialized
INFO - 2020-02-25 16:45:30 --> Language Class Initialized
INFO - 2020-02-25 16:45:30 --> Language Class Initialized
INFO - 2020-02-25 16:45:30 --> Config Class Initialized
INFO - 2020-02-25 16:45:30 --> Loader Class Initialized
INFO - 2020-02-25 16:45:30 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:30 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:30 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:30 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:30 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:30 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:30 --> Parser Class Initialized
INFO - 2020-02-25 16:45:30 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:30 --> Model Class Initialized
INFO - 2020-02-25 16:45:30 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:30 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:30 --> Template Class Initialized
INFO - 2020-02-25 16:45:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:30 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:30 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:30 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:30 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:30 --> Model Class Initialized
ERROR - 2020-02-25 16:45:30 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:30 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:45:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:45:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:45:30 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:45:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:45:30 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:30 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:30 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:45:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:45:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:45:30 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:30 --> Total execution time: 0.7115
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:36 --> CSRF cookie sent
INFO - 2020-02-25 16:45:36 --> CSRF token verified
INFO - 2020-02-25 16:45:36 --> Input Class Initialized
INFO - 2020-02-25 16:45:36 --> Language Class Initialized
INFO - 2020-02-25 16:45:36 --> Language Class Initialized
INFO - 2020-02-25 16:45:36 --> Config Class Initialized
INFO - 2020-02-25 16:45:36 --> Loader Class Initialized
INFO - 2020-02-25 16:45:36 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:36 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:36 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:36 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:36 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:36 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:36 --> Parser Class Initialized
INFO - 2020-02-25 16:45:36 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:36 --> Model Class Initialized
INFO - 2020-02-25 16:45:36 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:36 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:36 --> Template Class Initialized
INFO - 2020-02-25 16:45:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:36 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:36 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:36 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:36 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:36 --> Model Class Initialized
ERROR - 2020-02-25 16:45:36 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:41 --> Config Class Initialized
INFO - 2020-02-25 16:45:41 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:41 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:41 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:41 --> URI Class Initialized
INFO - 2020-02-25 16:45:41 --> Router Class Initialized
INFO - 2020-02-25 16:45:41 --> Output Class Initialized
INFO - 2020-02-25 16:45:41 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:41 --> CSRF cookie sent
INFO - 2020-02-25 16:45:41 --> Input Class Initialized
INFO - 2020-02-25 16:45:41 --> Language Class Initialized
INFO - 2020-02-25 16:45:41 --> Language Class Initialized
INFO - 2020-02-25 16:45:41 --> Config Class Initialized
INFO - 2020-02-25 16:45:41 --> Loader Class Initialized
INFO - 2020-02-25 16:45:41 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:41 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:41 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:41 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:41 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:41 --> Parser Class Initialized
INFO - 2020-02-25 16:45:41 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:41 --> Model Class Initialized
INFO - 2020-02-25 16:45:41 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:41 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:41 --> Template Class Initialized
INFO - 2020-02-25 16:45:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:41 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:41 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:41 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:41 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:41 --> Model Class Initialized
ERROR - 2020-02-25 16:45:41 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:41 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:45:41 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:45:42 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:42 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:42 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:45:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:45:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:45:42 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:42 --> Total execution time: 1.0685
INFO - 2020-02-25 16:45:56 --> Config Class Initialized
INFO - 2020-02-25 16:45:56 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:56 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:56 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:56 --> URI Class Initialized
INFO - 2020-02-25 16:45:56 --> Router Class Initialized
INFO - 2020-02-25 16:45:56 --> Output Class Initialized
INFO - 2020-02-25 16:45:56 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:56 --> CSRF cookie sent
INFO - 2020-02-25 16:45:56 --> Input Class Initialized
INFO - 2020-02-25 16:45:56 --> Language Class Initialized
INFO - 2020-02-25 16:45:56 --> Language Class Initialized
INFO - 2020-02-25 16:45:56 --> Config Class Initialized
INFO - 2020-02-25 16:45:56 --> Loader Class Initialized
INFO - 2020-02-25 16:45:56 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:56 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:56 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:56 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:56 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:56 --> Parser Class Initialized
INFO - 2020-02-25 16:45:56 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:56 --> Model Class Initialized
INFO - 2020-02-25 16:45:56 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:56 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:56 --> Template Class Initialized
INFO - 2020-02-25 16:45:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:56 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:56 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:56 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:56 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:56 --> Model Class Initialized
ERROR - 2020-02-25 16:45:56 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:45:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:45:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:45:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:45:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:45:56 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:56 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:45:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:45:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:45:56 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:56 --> Total execution time: 0.6885
INFO - 2020-02-25 16:45:58 --> Config Class Initialized
INFO - 2020-02-25 16:45:58 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:58 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:58 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:58 --> URI Class Initialized
INFO - 2020-02-25 16:45:58 --> Router Class Initialized
INFO - 2020-02-25 16:45:58 --> Output Class Initialized
INFO - 2020-02-25 16:45:58 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:58 --> CSRF cookie sent
INFO - 2020-02-25 16:45:58 --> Input Class Initialized
INFO - 2020-02-25 16:45:58 --> Language Class Initialized
INFO - 2020-02-25 16:45:58 --> Language Class Initialized
INFO - 2020-02-25 16:45:58 --> Config Class Initialized
INFO - 2020-02-25 16:45:58 --> Loader Class Initialized
INFO - 2020-02-25 16:45:58 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:58 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:58 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:58 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:58 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:58 --> Parser Class Initialized
INFO - 2020-02-25 16:45:58 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:58 --> Model Class Initialized
INFO - 2020-02-25 16:45:58 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:58 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:58 --> Template Class Initialized
INFO - 2020-02-25 16:45:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:58 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:58 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:58 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:58 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:58 --> Model Class Initialized
ERROR - 2020-02-25 16:45:58 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:58 --> Config Class Initialized
INFO - 2020-02-25 16:45:59 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:59 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:59 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:59 --> URI Class Initialized
INFO - 2020-02-25 16:45:59 --> Router Class Initialized
INFO - 2020-02-25 16:45:59 --> Output Class Initialized
INFO - 2020-02-25 16:45:59 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:59 --> CSRF cookie sent
INFO - 2020-02-25 16:45:59 --> Input Class Initialized
INFO - 2020-02-25 16:45:59 --> Language Class Initialized
INFO - 2020-02-25 16:45:59 --> Language Class Initialized
INFO - 2020-02-25 16:45:59 --> Config Class Initialized
INFO - 2020-02-25 16:45:59 --> Loader Class Initialized
INFO - 2020-02-25 16:45:59 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:59 --> Helper loaded: common_helper
INFO - 2020-02-25 16:45:59 --> Helper loaded: language_helper
INFO - 2020-02-25 16:45:59 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:45:59 --> Helper loaded: email_helper
INFO - 2020-02-25 16:45:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:45:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:45:59 --> Parser Class Initialized
INFO - 2020-02-25 16:45:59 --> User Agent Class Initialized
INFO - 2020-02-25 16:45:59 --> Model Class Initialized
INFO - 2020-02-25 16:45:59 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:59 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:59 --> Template Class Initialized
INFO - 2020-02-25 16:45:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:45:59 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:45:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:45:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:45:59 --> Encryption Class Initialized
INFO - 2020-02-25 16:45:59 --> Controller Class Initialized
DEBUG - 2020-02-25 16:45:59 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:59 --> Model Class Initialized
ERROR - 2020-02-25 16:45:59 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:45:59 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 16:45:59 --> Could not find the language line "Delele"
ERROR - 2020-02-25 16:45:59 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:45:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:45:59 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:59 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:45:59 --> Model Class Initialized
DEBUG - 2020-02-25 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:45:59 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:59 --> Total execution time: 0.7314
INFO - 2020-02-25 16:46:04 --> Config Class Initialized
INFO - 2020-02-25 16:46:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:04 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:04 --> URI Class Initialized
INFO - 2020-02-25 16:46:04 --> Router Class Initialized
INFO - 2020-02-25 16:46:04 --> Output Class Initialized
INFO - 2020-02-25 16:46:04 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:05 --> CSRF cookie sent
INFO - 2020-02-25 16:46:05 --> Input Class Initialized
INFO - 2020-02-25 16:46:05 --> Language Class Initialized
INFO - 2020-02-25 16:46:05 --> Language Class Initialized
INFO - 2020-02-25 16:46:05 --> Config Class Initialized
INFO - 2020-02-25 16:46:05 --> Loader Class Initialized
INFO - 2020-02-25 16:46:05 --> Helper loaded: url_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: common_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: language_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: email_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:46:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:46:05 --> Parser Class Initialized
INFO - 2020-02-25 16:46:05 --> User Agent Class Initialized
INFO - 2020-02-25 16:46:05 --> Model Class Initialized
INFO - 2020-02-25 16:46:05 --> Database Driver Class Initialized
INFO - 2020-02-25 16:46:05 --> Model Class Initialized
DEBUG - 2020-02-25 16:46:05 --> Template Class Initialized
INFO - 2020-02-25 16:46:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:46:05 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:46:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:46:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:46:05 --> Encryption Class Initialized
INFO - 2020-02-25 16:46:05 --> Controller Class Initialized
DEBUG - 2020-02-25 16:46:05 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:46:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:46:05 --> Model Class Initialized
ERROR - 2020-02-25 16:46:05 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:46:05 --> Config Class Initialized
INFO - 2020-02-25 16:46:05 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:05 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:05 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:05 --> URI Class Initialized
INFO - 2020-02-25 16:46:05 --> Router Class Initialized
INFO - 2020-02-25 16:46:05 --> Output Class Initialized
INFO - 2020-02-25 16:46:05 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:05 --> CSRF cookie sent
INFO - 2020-02-25 16:46:05 --> Input Class Initialized
INFO - 2020-02-25 16:46:05 --> Language Class Initialized
INFO - 2020-02-25 16:46:05 --> Language Class Initialized
INFO - 2020-02-25 16:46:05 --> Config Class Initialized
INFO - 2020-02-25 16:46:05 --> Loader Class Initialized
INFO - 2020-02-25 16:46:05 --> Helper loaded: url_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: common_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: language_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: email_helper
INFO - 2020-02-25 16:46:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:46:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:46:05 --> Parser Class Initialized
INFO - 2020-02-25 16:46:05 --> User Agent Class Initialized
INFO - 2020-02-25 16:46:05 --> Model Class Initialized
INFO - 2020-02-25 16:46:05 --> Database Driver Class Initialized
INFO - 2020-02-25 16:46:05 --> Model Class Initialized
DEBUG - 2020-02-25 16:46:05 --> Template Class Initialized
INFO - 2020-02-25 16:46:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:46:05 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:46:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:46:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:46:05 --> Encryption Class Initialized
INFO - 2020-02-25 16:46:05 --> Controller Class Initialized
DEBUG - 2020-02-25 16:46:05 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:46:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:46:06 --> Model Class Initialized
ERROR - 2020-02-25 16:46:06 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:46:06 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 16:46:06 --> Could not find the language line "Delele"
ERROR - 2020-02-25 16:46:06 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:46:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 16:46:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 16:46:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:46:06 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:46:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:46:06 --> Model Class Initialized
DEBUG - 2020-02-25 16:46:06 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:46:06 --> Model Class Initialized
DEBUG - 2020-02-25 16:46:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:46:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:46:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:46:06 --> Final output sent to browser
DEBUG - 2020-02-25 16:46:06 --> Total execution time: 0.8878
INFO - 2020-02-25 16:47:30 --> Config Class Initialized
INFO - 2020-02-25 16:47:30 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:30 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:30 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:30 --> URI Class Initialized
INFO - 2020-02-25 16:47:31 --> Router Class Initialized
INFO - 2020-02-25 16:47:31 --> Output Class Initialized
INFO - 2020-02-25 16:47:31 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:31 --> CSRF cookie sent
INFO - 2020-02-25 16:47:31 --> Input Class Initialized
INFO - 2020-02-25 16:47:31 --> Language Class Initialized
INFO - 2020-02-25 16:47:31 --> Language Class Initialized
INFO - 2020-02-25 16:47:31 --> Config Class Initialized
INFO - 2020-02-25 16:47:31 --> Loader Class Initialized
INFO - 2020-02-25 16:47:31 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:31 --> Helper loaded: common_helper
INFO - 2020-02-25 16:47:31 --> Helper loaded: language_helper
INFO - 2020-02-25 16:47:31 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:47:31 --> Helper loaded: email_helper
INFO - 2020-02-25 16:47:31 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:47:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:47:31 --> Parser Class Initialized
INFO - 2020-02-25 16:47:31 --> User Agent Class Initialized
INFO - 2020-02-25 16:47:31 --> Model Class Initialized
INFO - 2020-02-25 16:47:31 --> Database Driver Class Initialized
INFO - 2020-02-25 16:47:31 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:31 --> Template Class Initialized
INFO - 2020-02-25 16:47:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:47:31 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:47:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:47:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:47:31 --> Encryption Class Initialized
INFO - 2020-02-25 16:47:31 --> Controller Class Initialized
DEBUG - 2020-02-25 16:47:31 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:47:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:47:31 --> Model Class Initialized
ERROR - 2020-02-25 16:47:31 --> Could not find the language line "Sorting"
ERROR - 2020-02-25 16:47:31 --> Severity: Notice --> Undefined variable: lang_code D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\controllers\category.php 55
INFO - 2020-02-25 16:47:31 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:47:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:47:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:47:31 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:47:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:47:31 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:31 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:47:31 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:47:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:47:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:47:31 --> Final output sent to browser
DEBUG - 2020-02-25 16:47:31 --> Total execution time: 0.8225
INFO - 2020-02-25 16:47:55 --> Config Class Initialized
INFO - 2020-02-25 16:47:55 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:55 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:55 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:55 --> URI Class Initialized
INFO - 2020-02-25 16:47:55 --> Router Class Initialized
INFO - 2020-02-25 16:47:55 --> Output Class Initialized
INFO - 2020-02-25 16:47:55 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:55 --> CSRF cookie sent
INFO - 2020-02-25 16:47:55 --> Input Class Initialized
INFO - 2020-02-25 16:47:55 --> Language Class Initialized
INFO - 2020-02-25 16:47:55 --> Language Class Initialized
INFO - 2020-02-25 16:47:55 --> Config Class Initialized
INFO - 2020-02-25 16:47:55 --> Loader Class Initialized
INFO - 2020-02-25 16:47:55 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:55 --> Helper loaded: common_helper
INFO - 2020-02-25 16:47:55 --> Helper loaded: language_helper
INFO - 2020-02-25 16:47:55 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:47:55 --> Helper loaded: email_helper
INFO - 2020-02-25 16:47:55 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:47:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:47:55 --> Parser Class Initialized
INFO - 2020-02-25 16:47:55 --> User Agent Class Initialized
INFO - 2020-02-25 16:47:55 --> Model Class Initialized
INFO - 2020-02-25 16:47:55 --> Database Driver Class Initialized
INFO - 2020-02-25 16:47:55 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:55 --> Template Class Initialized
INFO - 2020-02-25 16:47:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:47:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:47:55 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:47:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:47:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:47:55 --> Encryption Class Initialized
INFO - 2020-02-25 16:47:55 --> Controller Class Initialized
DEBUG - 2020-02-25 16:47:55 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:47:55 --> Model Class Initialized
ERROR - 2020-02-25 16:47:55 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:47:55 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:47:55 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:47:55 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:55 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:47:55 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:47:55 --> Final output sent to browser
DEBUG - 2020-02-25 16:47:55 --> Total execution time: 0.7539
INFO - 2020-02-25 16:47:57 --> Config Class Initialized
INFO - 2020-02-25 16:47:57 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:57 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:57 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:57 --> URI Class Initialized
INFO - 2020-02-25 16:47:57 --> Router Class Initialized
INFO - 2020-02-25 16:47:57 --> Output Class Initialized
INFO - 2020-02-25 16:47:57 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:57 --> CSRF cookie sent
INFO - 2020-02-25 16:47:57 --> Input Class Initialized
INFO - 2020-02-25 16:47:57 --> Language Class Initialized
INFO - 2020-02-25 16:47:57 --> Language Class Initialized
INFO - 2020-02-25 16:47:57 --> Config Class Initialized
INFO - 2020-02-25 16:47:57 --> Loader Class Initialized
INFO - 2020-02-25 16:47:57 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:57 --> Helper loaded: common_helper
INFO - 2020-02-25 16:47:57 --> Helper loaded: language_helper
INFO - 2020-02-25 16:47:57 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:47:57 --> Helper loaded: email_helper
INFO - 2020-02-25 16:47:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:47:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:47:57 --> Parser Class Initialized
INFO - 2020-02-25 16:47:57 --> User Agent Class Initialized
INFO - 2020-02-25 16:47:57 --> Model Class Initialized
INFO - 2020-02-25 16:47:57 --> Database Driver Class Initialized
INFO - 2020-02-25 16:47:57 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:57 --> Template Class Initialized
INFO - 2020-02-25 16:47:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:47:57 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:47:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:47:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:47:57 --> Encryption Class Initialized
INFO - 2020-02-25 16:47:57 --> Controller Class Initialized
DEBUG - 2020-02-25 16:47:58 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:47:58 --> Model Class Initialized
ERROR - 2020-02-25 16:47:58 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:47:58 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:47:58 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:47:58 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:58 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:47:58 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:47:58 --> Final output sent to browser
DEBUG - 2020-02-25 16:47:58 --> Total execution time: 0.7143
INFO - 2020-02-25 16:47:59 --> Config Class Initialized
INFO - 2020-02-25 16:47:59 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:59 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:59 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:59 --> URI Class Initialized
INFO - 2020-02-25 16:47:59 --> Router Class Initialized
INFO - 2020-02-25 16:47:59 --> Output Class Initialized
INFO - 2020-02-25 16:47:59 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:59 --> CSRF cookie sent
INFO - 2020-02-25 16:47:59 --> Input Class Initialized
INFO - 2020-02-25 16:47:59 --> Language Class Initialized
INFO - 2020-02-25 16:47:59 --> Language Class Initialized
INFO - 2020-02-25 16:47:59 --> Config Class Initialized
INFO - 2020-02-25 16:47:59 --> Loader Class Initialized
INFO - 2020-02-25 16:47:59 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:59 --> Helper loaded: common_helper
INFO - 2020-02-25 16:47:59 --> Helper loaded: language_helper
INFO - 2020-02-25 16:47:59 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:47:59 --> Helper loaded: email_helper
INFO - 2020-02-25 16:47:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:47:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:47:59 --> Parser Class Initialized
INFO - 2020-02-25 16:47:59 --> User Agent Class Initialized
INFO - 2020-02-25 16:47:59 --> Model Class Initialized
INFO - 2020-02-25 16:47:59 --> Database Driver Class Initialized
INFO - 2020-02-25 16:47:59 --> Model Class Initialized
DEBUG - 2020-02-25 16:47:59 --> Template Class Initialized
INFO - 2020-02-25 16:47:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:47:59 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:47:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:47:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:47:59 --> Encryption Class Initialized
INFO - 2020-02-25 16:47:59 --> Controller Class Initialized
DEBUG - 2020-02-25 16:47:59 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:47:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:47:59 --> Model Class Initialized
ERROR - 2020-02-25 16:48:00 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:48:00 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:48:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:48:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:48:00 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:48:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:48:00 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:00 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:00 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:48:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:48:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:48:00 --> Final output sent to browser
DEBUG - 2020-02-25 16:48:00 --> Total execution time: 0.6953
INFO - 2020-02-25 16:48:01 --> Config Class Initialized
INFO - 2020-02-25 16:48:01 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:48:01 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:48:01 --> Utf8 Class Initialized
INFO - 2020-02-25 16:48:01 --> URI Class Initialized
INFO - 2020-02-25 16:48:01 --> Router Class Initialized
INFO - 2020-02-25 16:48:01 --> Output Class Initialized
INFO - 2020-02-25 16:48:01 --> Security Class Initialized
DEBUG - 2020-02-25 16:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:48:01 --> CSRF cookie sent
INFO - 2020-02-25 16:48:01 --> Input Class Initialized
INFO - 2020-02-25 16:48:01 --> Language Class Initialized
INFO - 2020-02-25 16:48:01 --> Language Class Initialized
INFO - 2020-02-25 16:48:01 --> Config Class Initialized
INFO - 2020-02-25 16:48:01 --> Loader Class Initialized
INFO - 2020-02-25 16:48:01 --> Helper loaded: url_helper
INFO - 2020-02-25 16:48:01 --> Helper loaded: common_helper
INFO - 2020-02-25 16:48:01 --> Helper loaded: language_helper
INFO - 2020-02-25 16:48:01 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:48:01 --> Helper loaded: email_helper
INFO - 2020-02-25 16:48:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:48:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:48:02 --> Parser Class Initialized
INFO - 2020-02-25 16:48:02 --> User Agent Class Initialized
INFO - 2020-02-25 16:48:02 --> Model Class Initialized
INFO - 2020-02-25 16:48:02 --> Database Driver Class Initialized
INFO - 2020-02-25 16:48:02 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:02 --> Template Class Initialized
INFO - 2020-02-25 16:48:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:48:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:48:02 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:48:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:48:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:48:02 --> Encryption Class Initialized
INFO - 2020-02-25 16:48:02 --> Controller Class Initialized
DEBUG - 2020-02-25 16:48:02 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:48:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:02 --> Model Class Initialized
ERROR - 2020-02-25 16:48:02 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:48:02 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:48:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:48:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:48:02 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:48:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:48:02 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:02 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:02 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:48:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:48:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:48:02 --> Final output sent to browser
DEBUG - 2020-02-25 16:48:02 --> Total execution time: 0.7283
INFO - 2020-02-25 16:48:03 --> Config Class Initialized
INFO - 2020-02-25 16:48:03 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:48:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:48:03 --> Utf8 Class Initialized
INFO - 2020-02-25 16:48:03 --> URI Class Initialized
INFO - 2020-02-25 16:48:03 --> Router Class Initialized
INFO - 2020-02-25 16:48:03 --> Output Class Initialized
INFO - 2020-02-25 16:48:03 --> Security Class Initialized
DEBUG - 2020-02-25 16:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:48:03 --> CSRF cookie sent
INFO - 2020-02-25 16:48:03 --> Input Class Initialized
INFO - 2020-02-25 16:48:03 --> Language Class Initialized
INFO - 2020-02-25 16:48:03 --> Language Class Initialized
INFO - 2020-02-25 16:48:03 --> Config Class Initialized
INFO - 2020-02-25 16:48:03 --> Loader Class Initialized
INFO - 2020-02-25 16:48:03 --> Helper loaded: url_helper
INFO - 2020-02-25 16:48:03 --> Helper loaded: common_helper
INFO - 2020-02-25 16:48:03 --> Helper loaded: language_helper
INFO - 2020-02-25 16:48:03 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:48:03 --> Helper loaded: email_helper
INFO - 2020-02-25 16:48:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:48:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:48:03 --> Parser Class Initialized
INFO - 2020-02-25 16:48:03 --> User Agent Class Initialized
INFO - 2020-02-25 16:48:03 --> Model Class Initialized
INFO - 2020-02-25 16:48:03 --> Database Driver Class Initialized
INFO - 2020-02-25 16:48:03 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:03 --> Template Class Initialized
INFO - 2020-02-25 16:48:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:48:03 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:48:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:48:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:48:03 --> Encryption Class Initialized
INFO - 2020-02-25 16:48:03 --> Controller Class Initialized
DEBUG - 2020-02-25 16:48:03 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:48:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:03 --> Model Class Initialized
ERROR - 2020-02-25 16:48:03 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:48:03 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:48:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:48:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:48:03 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:48:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:48:03 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:03 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:03 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:48:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:48:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:48:04 --> Final output sent to browser
DEBUG - 2020-02-25 16:48:04 --> Total execution time: 0.6856
INFO - 2020-02-25 16:48:12 --> Config Class Initialized
INFO - 2020-02-25 16:48:12 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:48:12 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:48:12 --> Utf8 Class Initialized
INFO - 2020-02-25 16:48:12 --> URI Class Initialized
INFO - 2020-02-25 16:48:12 --> Router Class Initialized
INFO - 2020-02-25 16:48:12 --> Output Class Initialized
INFO - 2020-02-25 16:48:12 --> Security Class Initialized
DEBUG - 2020-02-25 16:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:48:12 --> CSRF cookie sent
INFO - 2020-02-25 16:48:12 --> Input Class Initialized
INFO - 2020-02-25 16:48:12 --> Language Class Initialized
INFO - 2020-02-25 16:48:12 --> Language Class Initialized
INFO - 2020-02-25 16:48:12 --> Config Class Initialized
INFO - 2020-02-25 16:48:12 --> Loader Class Initialized
INFO - 2020-02-25 16:48:12 --> Helper loaded: url_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: common_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: language_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: email_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:48:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:48:13 --> Parser Class Initialized
INFO - 2020-02-25 16:48:13 --> User Agent Class Initialized
INFO - 2020-02-25 16:48:13 --> Model Class Initialized
INFO - 2020-02-25 16:48:13 --> Database Driver Class Initialized
INFO - 2020-02-25 16:48:13 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:13 --> Template Class Initialized
INFO - 2020-02-25 16:48:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:48:13 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:48:13 --> Encryption Class Initialized
INFO - 2020-02-25 16:48:13 --> Controller Class Initialized
DEBUG - 2020-02-25 16:48:13 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:48:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:13 --> Model Class Initialized
ERROR - 2020-02-25 16:48:13 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:48:13 --> Config Class Initialized
INFO - 2020-02-25 16:48:13 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:48:13 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:48:13 --> Utf8 Class Initialized
INFO - 2020-02-25 16:48:13 --> URI Class Initialized
INFO - 2020-02-25 16:48:13 --> Router Class Initialized
INFO - 2020-02-25 16:48:13 --> Output Class Initialized
INFO - 2020-02-25 16:48:13 --> Security Class Initialized
DEBUG - 2020-02-25 16:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:48:13 --> CSRF cookie sent
INFO - 2020-02-25 16:48:13 --> Input Class Initialized
INFO - 2020-02-25 16:48:13 --> Language Class Initialized
INFO - 2020-02-25 16:48:13 --> Language Class Initialized
INFO - 2020-02-25 16:48:13 --> Config Class Initialized
INFO - 2020-02-25 16:48:13 --> Loader Class Initialized
INFO - 2020-02-25 16:48:13 --> Helper loaded: url_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: common_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: language_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: email_helper
INFO - 2020-02-25 16:48:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:48:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:48:13 --> Parser Class Initialized
INFO - 2020-02-25 16:48:13 --> User Agent Class Initialized
INFO - 2020-02-25 16:48:13 --> Model Class Initialized
INFO - 2020-02-25 16:48:13 --> Database Driver Class Initialized
INFO - 2020-02-25 16:48:13 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:13 --> Template Class Initialized
INFO - 2020-02-25 16:48:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:48:13 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:48:13 --> Encryption Class Initialized
INFO - 2020-02-25 16:48:13 --> Controller Class Initialized
DEBUG - 2020-02-25 16:48:13 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:48:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:13 --> Model Class Initialized
ERROR - 2020-02-25 16:48:13 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:48:13 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 16:48:13 --> Could not find the language line "Delele"
ERROR - 2020-02-25 16:48:13 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:48:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 16:48:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 16:48:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:48:13 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:48:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:48:13 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:13 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:13 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:48:14 --> Final output sent to browser
DEBUG - 2020-02-25 16:48:14 --> Total execution time: 0.7577
INFO - 2020-02-25 16:48:16 --> Config Class Initialized
INFO - 2020-02-25 16:48:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:48:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:48:16 --> Utf8 Class Initialized
INFO - 2020-02-25 16:48:16 --> URI Class Initialized
INFO - 2020-02-25 16:48:16 --> Router Class Initialized
INFO - 2020-02-25 16:48:16 --> Output Class Initialized
INFO - 2020-02-25 16:48:16 --> Security Class Initialized
DEBUG - 2020-02-25 16:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:48:16 --> CSRF cookie sent
INFO - 2020-02-25 16:48:16 --> Input Class Initialized
INFO - 2020-02-25 16:48:16 --> Language Class Initialized
INFO - 2020-02-25 16:48:16 --> Language Class Initialized
INFO - 2020-02-25 16:48:16 --> Config Class Initialized
INFO - 2020-02-25 16:48:16 --> Loader Class Initialized
INFO - 2020-02-25 16:48:16 --> Helper loaded: url_helper
INFO - 2020-02-25 16:48:16 --> Helper loaded: common_helper
INFO - 2020-02-25 16:48:16 --> Helper loaded: language_helper
INFO - 2020-02-25 16:48:16 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:48:16 --> Helper loaded: email_helper
INFO - 2020-02-25 16:48:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:48:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:48:16 --> Parser Class Initialized
INFO - 2020-02-25 16:48:16 --> User Agent Class Initialized
INFO - 2020-02-25 16:48:16 --> Model Class Initialized
INFO - 2020-02-25 16:48:16 --> Database Driver Class Initialized
INFO - 2020-02-25 16:48:16 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:16 --> Template Class Initialized
INFO - 2020-02-25 16:48:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:48:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:48:16 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:48:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:48:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:48:17 --> Encryption Class Initialized
INFO - 2020-02-25 16:48:17 --> Controller Class Initialized
DEBUG - 2020-02-25 16:48:17 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:17 --> Model Class Initialized
ERROR - 2020-02-25 16:48:17 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:48:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:48:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:48:17 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:17 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:48:17 --> Final output sent to browser
DEBUG - 2020-02-25 16:48:17 --> Total execution time: 0.7157
INFO - 2020-02-25 16:48:19 --> Config Class Initialized
INFO - 2020-02-25 16:48:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:48:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:48:19 --> Utf8 Class Initialized
INFO - 2020-02-25 16:48:19 --> URI Class Initialized
INFO - 2020-02-25 16:48:19 --> Router Class Initialized
INFO - 2020-02-25 16:48:19 --> Output Class Initialized
INFO - 2020-02-25 16:48:19 --> Security Class Initialized
DEBUG - 2020-02-25 16:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:48:19 --> CSRF cookie sent
INFO - 2020-02-25 16:48:19 --> Input Class Initialized
INFO - 2020-02-25 16:48:19 --> Language Class Initialized
INFO - 2020-02-25 16:48:19 --> Language Class Initialized
INFO - 2020-02-25 16:48:19 --> Config Class Initialized
INFO - 2020-02-25 16:48:19 --> Loader Class Initialized
INFO - 2020-02-25 16:48:19 --> Helper loaded: url_helper
INFO - 2020-02-25 16:48:19 --> Helper loaded: common_helper
INFO - 2020-02-25 16:48:19 --> Helper loaded: language_helper
INFO - 2020-02-25 16:48:19 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:48:19 --> Helper loaded: email_helper
INFO - 2020-02-25 16:48:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:48:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:48:19 --> Parser Class Initialized
INFO - 2020-02-25 16:48:19 --> User Agent Class Initialized
INFO - 2020-02-25 16:48:19 --> Model Class Initialized
INFO - 2020-02-25 16:48:19 --> Database Driver Class Initialized
INFO - 2020-02-25 16:48:19 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:19 --> Template Class Initialized
INFO - 2020-02-25 16:48:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:48:20 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:48:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:48:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:48:20 --> Encryption Class Initialized
INFO - 2020-02-25 16:48:20 --> Controller Class Initialized
DEBUG - 2020-02-25 16:48:20 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:20 --> Model Class Initialized
ERROR - 2020-02-25 16:48:20 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:48:20 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:48:20 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:48:20 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:20 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:20 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:48:20 --> Final output sent to browser
DEBUG - 2020-02-25 16:48:20 --> Total execution time: 0.8376
INFO - 2020-02-25 16:48:23 --> Config Class Initialized
INFO - 2020-02-25 16:48:23 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:48:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:48:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:48:24 --> URI Class Initialized
INFO - 2020-02-25 16:48:24 --> Router Class Initialized
INFO - 2020-02-25 16:48:24 --> Output Class Initialized
INFO - 2020-02-25 16:48:24 --> Security Class Initialized
DEBUG - 2020-02-25 16:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:48:24 --> CSRF cookie sent
INFO - 2020-02-25 16:48:24 --> Input Class Initialized
INFO - 2020-02-25 16:48:24 --> Language Class Initialized
INFO - 2020-02-25 16:48:24 --> Language Class Initialized
INFO - 2020-02-25 16:48:24 --> Config Class Initialized
INFO - 2020-02-25 16:48:24 --> Loader Class Initialized
INFO - 2020-02-25 16:48:24 --> Helper loaded: url_helper
INFO - 2020-02-25 16:48:24 --> Helper loaded: common_helper
INFO - 2020-02-25 16:48:24 --> Helper loaded: language_helper
INFO - 2020-02-25 16:48:24 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:48:24 --> Helper loaded: email_helper
INFO - 2020-02-25 16:48:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:48:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:48:24 --> Parser Class Initialized
INFO - 2020-02-25 16:48:24 --> User Agent Class Initialized
INFO - 2020-02-25 16:48:24 --> Model Class Initialized
INFO - 2020-02-25 16:48:24 --> Database Driver Class Initialized
INFO - 2020-02-25 16:48:24 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:24 --> Template Class Initialized
INFO - 2020-02-25 16:48:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:48:24 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:48:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:48:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:48:24 --> Encryption Class Initialized
INFO - 2020-02-25 16:48:24 --> Controller Class Initialized
DEBUG - 2020-02-25 16:48:24 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:24 --> Model Class Initialized
ERROR - 2020-02-25 16:48:24 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:48:24 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:48:24 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:48:24 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:24 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:48:24 --> Model Class Initialized
DEBUG - 2020-02-25 16:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:48:24 --> Final output sent to browser
DEBUG - 2020-02-25 16:48:24 --> Total execution time: 0.8736
INFO - 2020-02-25 16:50:45 --> Config Class Initialized
INFO - 2020-02-25 16:50:45 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:45 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:45 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:45 --> URI Class Initialized
INFO - 2020-02-25 16:50:45 --> Router Class Initialized
INFO - 2020-02-25 16:50:45 --> Output Class Initialized
INFO - 2020-02-25 16:50:45 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:45 --> CSRF cookie sent
INFO - 2020-02-25 16:50:45 --> Input Class Initialized
INFO - 2020-02-25 16:50:45 --> Language Class Initialized
INFO - 2020-02-25 16:50:45 --> Language Class Initialized
INFO - 2020-02-25 16:50:45 --> Config Class Initialized
INFO - 2020-02-25 16:50:45 --> Loader Class Initialized
INFO - 2020-02-25 16:50:45 --> Helper loaded: url_helper
INFO - 2020-02-25 16:50:45 --> Helper loaded: common_helper
INFO - 2020-02-25 16:50:45 --> Helper loaded: language_helper
INFO - 2020-02-25 16:50:45 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:50:45 --> Helper loaded: email_helper
INFO - 2020-02-25 16:50:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:50:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:50:45 --> Parser Class Initialized
INFO - 2020-02-25 16:50:45 --> User Agent Class Initialized
INFO - 2020-02-25 16:50:45 --> Model Class Initialized
INFO - 2020-02-25 16:50:45 --> Database Driver Class Initialized
INFO - 2020-02-25 16:50:45 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:45 --> Template Class Initialized
INFO - 2020-02-25 16:50:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:50:45 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:50:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:50:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:50:45 --> Encryption Class Initialized
INFO - 2020-02-25 16:50:45 --> Controller Class Initialized
DEBUG - 2020-02-25 16:50:45 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:50:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:45 --> Model Class Initialized
ERROR - 2020-02-25 16:50:45 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:50:45 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:50:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:50:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:50:45 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:50:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:50:45 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:45 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:45 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:50:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:50:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:50:45 --> Final output sent to browser
DEBUG - 2020-02-25 16:50:45 --> Total execution time: 0.7424
INFO - 2020-02-25 16:50:47 --> Config Class Initialized
INFO - 2020-02-25 16:50:47 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:47 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:47 --> URI Class Initialized
INFO - 2020-02-25 16:50:47 --> Router Class Initialized
INFO - 2020-02-25 16:50:47 --> Output Class Initialized
INFO - 2020-02-25 16:50:47 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:48 --> CSRF cookie sent
INFO - 2020-02-25 16:50:48 --> Input Class Initialized
INFO - 2020-02-25 16:50:48 --> Language Class Initialized
INFO - 2020-02-25 16:50:48 --> Language Class Initialized
INFO - 2020-02-25 16:50:48 --> Config Class Initialized
INFO - 2020-02-25 16:50:48 --> Loader Class Initialized
INFO - 2020-02-25 16:50:48 --> Helper loaded: url_helper
INFO - 2020-02-25 16:50:48 --> Helper loaded: common_helper
INFO - 2020-02-25 16:50:48 --> Helper loaded: language_helper
INFO - 2020-02-25 16:50:48 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:50:48 --> Helper loaded: email_helper
INFO - 2020-02-25 16:50:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:50:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:50:48 --> Parser Class Initialized
INFO - 2020-02-25 16:50:48 --> User Agent Class Initialized
INFO - 2020-02-25 16:50:48 --> Model Class Initialized
INFO - 2020-02-25 16:50:48 --> Database Driver Class Initialized
INFO - 2020-02-25 16:50:48 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:48 --> Template Class Initialized
INFO - 2020-02-25 16:50:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:50:48 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:50:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:50:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:50:48 --> Encryption Class Initialized
INFO - 2020-02-25 16:50:48 --> Controller Class Initialized
DEBUG - 2020-02-25 16:50:48 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:48 --> Model Class Initialized
ERROR - 2020-02-25 16:50:48 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:50:48 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:50:48 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:50:48 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:48 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:48 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:50:48 --> Final output sent to browser
DEBUG - 2020-02-25 16:50:48 --> Total execution time: 0.7113
INFO - 2020-02-25 16:50:51 --> Config Class Initialized
INFO - 2020-02-25 16:50:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:51 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:51 --> URI Class Initialized
INFO - 2020-02-25 16:50:51 --> Router Class Initialized
INFO - 2020-02-25 16:50:51 --> Output Class Initialized
INFO - 2020-02-25 16:50:51 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:51 --> CSRF cookie sent
INFO - 2020-02-25 16:50:51 --> Input Class Initialized
INFO - 2020-02-25 16:50:51 --> Language Class Initialized
INFO - 2020-02-25 16:50:51 --> Language Class Initialized
INFO - 2020-02-25 16:50:51 --> Config Class Initialized
INFO - 2020-02-25 16:50:51 --> Loader Class Initialized
INFO - 2020-02-25 16:50:51 --> Helper loaded: url_helper
INFO - 2020-02-25 16:50:51 --> Helper loaded: common_helper
INFO - 2020-02-25 16:50:51 --> Helper loaded: language_helper
INFO - 2020-02-25 16:50:51 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:50:51 --> Helper loaded: email_helper
INFO - 2020-02-25 16:50:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:50:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:50:51 --> Parser Class Initialized
INFO - 2020-02-25 16:50:51 --> User Agent Class Initialized
INFO - 2020-02-25 16:50:51 --> Model Class Initialized
INFO - 2020-02-25 16:50:51 --> Database Driver Class Initialized
INFO - 2020-02-25 16:50:51 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:51 --> Template Class Initialized
INFO - 2020-02-25 16:50:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:50:51 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:50:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:50:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:50:51 --> Encryption Class Initialized
INFO - 2020-02-25 16:50:51 --> Controller Class Initialized
DEBUG - 2020-02-25 16:50:51 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:50:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:51 --> Model Class Initialized
ERROR - 2020-02-25 16:50:51 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:50:51 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:50:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:50:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:50:52 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:50:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:50:52 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:52 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:52 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:50:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:50:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:50:52 --> Final output sent to browser
DEBUG - 2020-02-25 16:50:52 --> Total execution time: 0.7234
INFO - 2020-02-25 16:50:55 --> Config Class Initialized
INFO - 2020-02-25 16:50:55 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:55 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:55 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:55 --> URI Class Initialized
INFO - 2020-02-25 16:50:55 --> Router Class Initialized
INFO - 2020-02-25 16:50:55 --> Output Class Initialized
INFO - 2020-02-25 16:50:55 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:55 --> CSRF cookie sent
INFO - 2020-02-25 16:50:55 --> Input Class Initialized
INFO - 2020-02-25 16:50:55 --> Language Class Initialized
INFO - 2020-02-25 16:50:55 --> Language Class Initialized
INFO - 2020-02-25 16:50:55 --> Config Class Initialized
INFO - 2020-02-25 16:50:55 --> Loader Class Initialized
INFO - 2020-02-25 16:50:55 --> Helper loaded: url_helper
INFO - 2020-02-25 16:50:55 --> Helper loaded: common_helper
INFO - 2020-02-25 16:50:55 --> Helper loaded: language_helper
INFO - 2020-02-25 16:50:55 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:50:55 --> Helper loaded: email_helper
INFO - 2020-02-25 16:50:55 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:50:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:50:55 --> Parser Class Initialized
INFO - 2020-02-25 16:50:55 --> User Agent Class Initialized
INFO - 2020-02-25 16:50:55 --> Model Class Initialized
INFO - 2020-02-25 16:50:55 --> Database Driver Class Initialized
INFO - 2020-02-25 16:50:55 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:55 --> Template Class Initialized
INFO - 2020-02-25 16:50:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:50:55 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:50:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:50:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:50:55 --> Encryption Class Initialized
INFO - 2020-02-25 16:50:55 --> Controller Class Initialized
DEBUG - 2020-02-25 16:50:55 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:50:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:55 --> Model Class Initialized
ERROR - 2020-02-25 16:50:55 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:50:55 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:50:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:50:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:50:55 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:50:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:50:55 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:55 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:55 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:50:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:50:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:50:55 --> Final output sent to browser
DEBUG - 2020-02-25 16:50:55 --> Total execution time: 0.7426
INFO - 2020-02-25 16:50:58 --> Config Class Initialized
INFO - 2020-02-25 16:50:58 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:58 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:58 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:58 --> URI Class Initialized
INFO - 2020-02-25 16:50:58 --> Router Class Initialized
INFO - 2020-02-25 16:50:58 --> Output Class Initialized
INFO - 2020-02-25 16:50:58 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:58 --> CSRF cookie sent
INFO - 2020-02-25 16:50:58 --> Input Class Initialized
INFO - 2020-02-25 16:50:58 --> Language Class Initialized
INFO - 2020-02-25 16:50:58 --> Language Class Initialized
INFO - 2020-02-25 16:50:58 --> Config Class Initialized
INFO - 2020-02-25 16:50:58 --> Loader Class Initialized
INFO - 2020-02-25 16:50:58 --> Helper loaded: url_helper
INFO - 2020-02-25 16:50:58 --> Helper loaded: common_helper
INFO - 2020-02-25 16:50:58 --> Helper loaded: language_helper
INFO - 2020-02-25 16:50:58 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:50:58 --> Helper loaded: email_helper
INFO - 2020-02-25 16:50:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:50:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:50:58 --> Parser Class Initialized
INFO - 2020-02-25 16:50:58 --> User Agent Class Initialized
INFO - 2020-02-25 16:50:58 --> Model Class Initialized
INFO - 2020-02-25 16:50:58 --> Database Driver Class Initialized
INFO - 2020-02-25 16:50:58 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:58 --> Template Class Initialized
INFO - 2020-02-25 16:50:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:50:58 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:50:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:50:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:50:58 --> Encryption Class Initialized
INFO - 2020-02-25 16:50:58 --> Controller Class Initialized
DEBUG - 2020-02-25 16:50:58 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:50:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:58 --> Model Class Initialized
ERROR - 2020-02-25 16:50:58 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:50:58 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:50:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:50:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:50:58 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:50:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:50:58 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:58 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:50:58 --> Model Class Initialized
DEBUG - 2020-02-25 16:50:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:50:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:50:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:50:58 --> Final output sent to browser
DEBUG - 2020-02-25 16:50:58 --> Total execution time: 0.7477
INFO - 2020-02-25 16:51:00 --> Config Class Initialized
INFO - 2020-02-25 16:51:00 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:00 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:00 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:00 --> URI Class Initialized
INFO - 2020-02-25 16:51:00 --> Router Class Initialized
INFO - 2020-02-25 16:51:00 --> Output Class Initialized
INFO - 2020-02-25 16:51:00 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:00 --> CSRF cookie sent
INFO - 2020-02-25 16:51:00 --> Input Class Initialized
INFO - 2020-02-25 16:51:00 --> Language Class Initialized
INFO - 2020-02-25 16:51:00 --> Language Class Initialized
INFO - 2020-02-25 16:51:00 --> Config Class Initialized
INFO - 2020-02-25 16:51:00 --> Loader Class Initialized
INFO - 2020-02-25 16:51:00 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:00 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:00 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:00 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:00 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:00 --> Parser Class Initialized
INFO - 2020-02-25 16:51:00 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:00 --> Model Class Initialized
INFO - 2020-02-25 16:51:00 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:00 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:00 --> Template Class Initialized
INFO - 2020-02-25 16:51:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:00 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:00 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:00 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:00 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:00 --> Model Class Initialized
ERROR - 2020-02-25 16:51:00 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:00 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:00 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:00 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:00 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:00 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:00 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:00 --> Total execution time: 0.7323
INFO - 2020-02-25 16:51:01 --> Config Class Initialized
INFO - 2020-02-25 16:51:01 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:02 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:02 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:02 --> URI Class Initialized
INFO - 2020-02-25 16:51:02 --> Router Class Initialized
INFO - 2020-02-25 16:51:02 --> Output Class Initialized
INFO - 2020-02-25 16:51:02 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:02 --> CSRF cookie sent
INFO - 2020-02-25 16:51:02 --> Input Class Initialized
INFO - 2020-02-25 16:51:02 --> Language Class Initialized
INFO - 2020-02-25 16:51:02 --> Language Class Initialized
INFO - 2020-02-25 16:51:02 --> Config Class Initialized
INFO - 2020-02-25 16:51:02 --> Loader Class Initialized
INFO - 2020-02-25 16:51:02 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:02 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:02 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:02 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:02 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:02 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:02 --> Parser Class Initialized
INFO - 2020-02-25 16:51:02 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:02 --> Model Class Initialized
INFO - 2020-02-25 16:51:02 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:02 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:02 --> Template Class Initialized
INFO - 2020-02-25 16:51:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:02 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:02 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:02 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:02 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:02 --> Model Class Initialized
ERROR - 2020-02-25 16:51:02 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:02 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:02 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:02 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:02 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:02 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:02 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:02 --> Total execution time: 0.7365
INFO - 2020-02-25 16:51:03 --> Config Class Initialized
INFO - 2020-02-25 16:51:03 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:03 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:03 --> URI Class Initialized
INFO - 2020-02-25 16:51:03 --> Router Class Initialized
INFO - 2020-02-25 16:51:03 --> Output Class Initialized
INFO - 2020-02-25 16:51:03 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:03 --> CSRF cookie sent
INFO - 2020-02-25 16:51:03 --> Input Class Initialized
INFO - 2020-02-25 16:51:03 --> Language Class Initialized
INFO - 2020-02-25 16:51:03 --> Language Class Initialized
INFO - 2020-02-25 16:51:03 --> Config Class Initialized
INFO - 2020-02-25 16:51:03 --> Loader Class Initialized
INFO - 2020-02-25 16:51:03 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:03 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:04 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:04 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:04 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:04 --> Parser Class Initialized
INFO - 2020-02-25 16:51:04 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:04 --> Model Class Initialized
INFO - 2020-02-25 16:51:04 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:04 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:04 --> Template Class Initialized
INFO - 2020-02-25 16:51:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:04 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:04 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:04 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:04 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:04 --> Model Class Initialized
ERROR - 2020-02-25 16:51:04 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:04 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:04 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:04 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:04 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:04 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:04 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:04 --> Total execution time: 0.7470
INFO - 2020-02-25 16:51:05 --> Config Class Initialized
INFO - 2020-02-25 16:51:05 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:05 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:05 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:05 --> URI Class Initialized
INFO - 2020-02-25 16:51:05 --> Router Class Initialized
INFO - 2020-02-25 16:51:05 --> Output Class Initialized
INFO - 2020-02-25 16:51:05 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:05 --> CSRF cookie sent
INFO - 2020-02-25 16:51:05 --> Input Class Initialized
INFO - 2020-02-25 16:51:05 --> Language Class Initialized
INFO - 2020-02-25 16:51:05 --> Language Class Initialized
INFO - 2020-02-25 16:51:05 --> Config Class Initialized
INFO - 2020-02-25 16:51:05 --> Loader Class Initialized
INFO - 2020-02-25 16:51:05 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:05 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:05 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:05 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:05 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:05 --> Parser Class Initialized
INFO - 2020-02-25 16:51:05 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:05 --> Model Class Initialized
INFO - 2020-02-25 16:51:05 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:05 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:05 --> Template Class Initialized
INFO - 2020-02-25 16:51:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:05 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:05 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:05 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:05 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:06 --> Model Class Initialized
ERROR - 2020-02-25 16:51:06 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:06 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:06 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:06 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:06 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:06 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:06 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:06 --> Total execution time: 0.7465
INFO - 2020-02-25 16:51:07 --> Config Class Initialized
INFO - 2020-02-25 16:51:07 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:07 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:07 --> URI Class Initialized
INFO - 2020-02-25 16:51:07 --> Router Class Initialized
INFO - 2020-02-25 16:51:07 --> Output Class Initialized
INFO - 2020-02-25 16:51:07 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:07 --> CSRF cookie sent
INFO - 2020-02-25 16:51:07 --> Input Class Initialized
INFO - 2020-02-25 16:51:07 --> Language Class Initialized
INFO - 2020-02-25 16:51:07 --> Language Class Initialized
INFO - 2020-02-25 16:51:07 --> Config Class Initialized
INFO - 2020-02-25 16:51:07 --> Loader Class Initialized
INFO - 2020-02-25 16:51:07 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:07 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:07 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:07 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:07 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:07 --> Parser Class Initialized
INFO - 2020-02-25 16:51:07 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:07 --> Model Class Initialized
INFO - 2020-02-25 16:51:07 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:07 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:07 --> Template Class Initialized
INFO - 2020-02-25 16:51:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:07 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:07 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:07 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:07 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:07 --> Model Class Initialized
ERROR - 2020-02-25 16:51:07 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:07 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:07 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:08 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:08 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:08 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:08 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:08 --> Total execution time: 0.7506
INFO - 2020-02-25 16:51:09 --> Config Class Initialized
INFO - 2020-02-25 16:51:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:09 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:09 --> URI Class Initialized
INFO - 2020-02-25 16:51:09 --> Router Class Initialized
INFO - 2020-02-25 16:51:09 --> Output Class Initialized
INFO - 2020-02-25 16:51:09 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:09 --> CSRF cookie sent
INFO - 2020-02-25 16:51:09 --> Input Class Initialized
INFO - 2020-02-25 16:51:09 --> Language Class Initialized
INFO - 2020-02-25 16:51:09 --> Language Class Initialized
INFO - 2020-02-25 16:51:09 --> Config Class Initialized
INFO - 2020-02-25 16:51:09 --> Loader Class Initialized
INFO - 2020-02-25 16:51:09 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:09 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:09 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:09 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:09 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:09 --> Parser Class Initialized
INFO - 2020-02-25 16:51:09 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:09 --> Model Class Initialized
INFO - 2020-02-25 16:51:09 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:09 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:09 --> Template Class Initialized
INFO - 2020-02-25 16:51:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:09 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:09 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:09 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:09 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:09 --> Model Class Initialized
ERROR - 2020-02-25 16:51:09 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:09 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:09 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:09 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:09 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:09 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:09 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:09 --> Total execution time: 0.7458
INFO - 2020-02-25 16:51:11 --> Config Class Initialized
INFO - 2020-02-25 16:51:11 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:11 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:11 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:11 --> URI Class Initialized
INFO - 2020-02-25 16:51:11 --> Router Class Initialized
INFO - 2020-02-25 16:51:11 --> Output Class Initialized
INFO - 2020-02-25 16:51:11 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:11 --> CSRF cookie sent
INFO - 2020-02-25 16:51:11 --> Input Class Initialized
INFO - 2020-02-25 16:51:11 --> Language Class Initialized
INFO - 2020-02-25 16:51:11 --> Language Class Initialized
INFO - 2020-02-25 16:51:11 --> Config Class Initialized
INFO - 2020-02-25 16:51:11 --> Loader Class Initialized
INFO - 2020-02-25 16:51:11 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:11 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:11 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:11 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:11 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:11 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:11 --> Parser Class Initialized
INFO - 2020-02-25 16:51:11 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:11 --> Model Class Initialized
INFO - 2020-02-25 16:51:11 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:11 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:11 --> Template Class Initialized
INFO - 2020-02-25 16:51:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:11 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:11 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:11 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:11 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:11 --> Model Class Initialized
ERROR - 2020-02-25 16:51:11 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:11 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:11 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:11 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:11 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:11 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:11 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:11 --> Total execution time: 0.7511
INFO - 2020-02-25 16:51:13 --> Config Class Initialized
INFO - 2020-02-25 16:51:13 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:13 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:13 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:13 --> URI Class Initialized
INFO - 2020-02-25 16:51:13 --> Router Class Initialized
INFO - 2020-02-25 16:51:13 --> Output Class Initialized
INFO - 2020-02-25 16:51:13 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:13 --> CSRF cookie sent
INFO - 2020-02-25 16:51:13 --> Input Class Initialized
INFO - 2020-02-25 16:51:13 --> Language Class Initialized
INFO - 2020-02-25 16:51:13 --> Language Class Initialized
INFO - 2020-02-25 16:51:13 --> Config Class Initialized
INFO - 2020-02-25 16:51:13 --> Loader Class Initialized
INFO - 2020-02-25 16:51:13 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:13 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:13 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:13 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:13 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:13 --> Parser Class Initialized
INFO - 2020-02-25 16:51:13 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:13 --> Model Class Initialized
INFO - 2020-02-25 16:51:13 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:13 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:13 --> Template Class Initialized
INFO - 2020-02-25 16:51:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:13 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:13 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:13 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:13 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:13 --> Model Class Initialized
ERROR - 2020-02-25 16:51:13 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:13 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:13 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:13 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:13 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:13 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:13 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:13 --> Total execution time: 0.7573
INFO - 2020-02-25 16:51:15 --> Config Class Initialized
INFO - 2020-02-25 16:51:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:15 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:15 --> URI Class Initialized
INFO - 2020-02-25 16:51:15 --> Router Class Initialized
INFO - 2020-02-25 16:51:15 --> Output Class Initialized
INFO - 2020-02-25 16:51:15 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:15 --> CSRF cookie sent
INFO - 2020-02-25 16:51:15 --> Input Class Initialized
INFO - 2020-02-25 16:51:15 --> Language Class Initialized
INFO - 2020-02-25 16:51:15 --> Language Class Initialized
INFO - 2020-02-25 16:51:15 --> Config Class Initialized
INFO - 2020-02-25 16:51:15 --> Loader Class Initialized
INFO - 2020-02-25 16:51:15 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:15 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:15 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:15 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:15 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:15 --> Parser Class Initialized
INFO - 2020-02-25 16:51:15 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:15 --> Model Class Initialized
INFO - 2020-02-25 16:51:15 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:15 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:15 --> Template Class Initialized
INFO - 2020-02-25 16:51:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:15 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:15 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:15 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:15 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:15 --> Model Class Initialized
ERROR - 2020-02-25 16:51:15 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:15 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:15 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:15 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:15 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:15 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:15 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:15 --> Total execution time: 0.7792
INFO - 2020-02-25 16:51:16 --> Config Class Initialized
INFO - 2020-02-25 16:51:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:16 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:16 --> URI Class Initialized
INFO - 2020-02-25 16:51:16 --> Router Class Initialized
INFO - 2020-02-25 16:51:16 --> Output Class Initialized
INFO - 2020-02-25 16:51:16 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:16 --> CSRF cookie sent
INFO - 2020-02-25 16:51:16 --> Input Class Initialized
INFO - 2020-02-25 16:51:16 --> Language Class Initialized
INFO - 2020-02-25 16:51:16 --> Language Class Initialized
INFO - 2020-02-25 16:51:16 --> Config Class Initialized
INFO - 2020-02-25 16:51:16 --> Loader Class Initialized
INFO - 2020-02-25 16:51:16 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:17 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:17 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:17 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:17 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:17 --> Parser Class Initialized
INFO - 2020-02-25 16:51:17 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:17 --> Model Class Initialized
INFO - 2020-02-25 16:51:17 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:17 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:17 --> Template Class Initialized
INFO - 2020-02-25 16:51:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:17 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:17 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:17 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:17 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:17 --> Model Class Initialized
ERROR - 2020-02-25 16:51:17 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:17 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:17 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:17 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:17 --> Total execution time: 0.8068
INFO - 2020-02-25 16:51:18 --> Config Class Initialized
INFO - 2020-02-25 16:51:18 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:18 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:18 --> URI Class Initialized
INFO - 2020-02-25 16:51:18 --> Router Class Initialized
INFO - 2020-02-25 16:51:18 --> Output Class Initialized
INFO - 2020-02-25 16:51:19 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:19 --> CSRF cookie sent
INFO - 2020-02-25 16:51:19 --> Input Class Initialized
INFO - 2020-02-25 16:51:19 --> Language Class Initialized
INFO - 2020-02-25 16:51:19 --> Language Class Initialized
INFO - 2020-02-25 16:51:19 --> Config Class Initialized
INFO - 2020-02-25 16:51:19 --> Loader Class Initialized
INFO - 2020-02-25 16:51:19 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:19 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:19 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:19 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:19 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:19 --> Parser Class Initialized
INFO - 2020-02-25 16:51:19 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:19 --> Model Class Initialized
INFO - 2020-02-25 16:51:19 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:19 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:19 --> Template Class Initialized
INFO - 2020-02-25 16:51:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:19 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:19 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:19 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:19 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:19 --> Model Class Initialized
ERROR - 2020-02-25 16:51:19 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:19 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:19 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:19 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:19 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:19 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:19 --> Total execution time: 0.7754
INFO - 2020-02-25 16:51:20 --> Config Class Initialized
INFO - 2020-02-25 16:51:20 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:51:20 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:51:20 --> Utf8 Class Initialized
INFO - 2020-02-25 16:51:20 --> URI Class Initialized
INFO - 2020-02-25 16:51:20 --> Router Class Initialized
INFO - 2020-02-25 16:51:20 --> Output Class Initialized
INFO - 2020-02-25 16:51:20 --> Security Class Initialized
DEBUG - 2020-02-25 16:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:51:20 --> CSRF cookie sent
INFO - 2020-02-25 16:51:20 --> Input Class Initialized
INFO - 2020-02-25 16:51:20 --> Language Class Initialized
INFO - 2020-02-25 16:51:20 --> Language Class Initialized
INFO - 2020-02-25 16:51:20 --> Config Class Initialized
INFO - 2020-02-25 16:51:20 --> Loader Class Initialized
INFO - 2020-02-25 16:51:21 --> Helper loaded: url_helper
INFO - 2020-02-25 16:51:21 --> Helper loaded: common_helper
INFO - 2020-02-25 16:51:21 --> Helper loaded: language_helper
INFO - 2020-02-25 16:51:21 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:51:21 --> Helper loaded: email_helper
INFO - 2020-02-25 16:51:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:51:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:51:21 --> Parser Class Initialized
INFO - 2020-02-25 16:51:21 --> User Agent Class Initialized
INFO - 2020-02-25 16:51:21 --> Model Class Initialized
INFO - 2020-02-25 16:51:21 --> Database Driver Class Initialized
INFO - 2020-02-25 16:51:21 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:21 --> Template Class Initialized
INFO - 2020-02-25 16:51:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:51:21 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:51:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:51:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:51:21 --> Encryption Class Initialized
INFO - 2020-02-25 16:51:21 --> Controller Class Initialized
DEBUG - 2020-02-25 16:51:21 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:21 --> Model Class Initialized
ERROR - 2020-02-25 16:51:21 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:51:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:51:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:51:21 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:51:21 --> Model Class Initialized
DEBUG - 2020-02-25 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:51:21 --> Final output sent to browser
DEBUG - 2020-02-25 16:51:21 --> Total execution time: 0.7647
INFO - 2020-02-25 16:58:35 --> Config Class Initialized
INFO - 2020-02-25 16:58:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:35 --> URI Class Initialized
INFO - 2020-02-25 16:58:35 --> Router Class Initialized
INFO - 2020-02-25 16:58:35 --> Output Class Initialized
INFO - 2020-02-25 16:58:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:35 --> CSRF cookie sent
INFO - 2020-02-25 16:58:35 --> Input Class Initialized
INFO - 2020-02-25 16:58:35 --> Language Class Initialized
INFO - 2020-02-25 16:58:35 --> Language Class Initialized
INFO - 2020-02-25 16:58:35 --> Config Class Initialized
INFO - 2020-02-25 16:58:35 --> Loader Class Initialized
INFO - 2020-02-25 16:58:35 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:35 --> Helper loaded: common_helper
INFO - 2020-02-25 16:58:35 --> Helper loaded: language_helper
INFO - 2020-02-25 16:58:35 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:58:35 --> Helper loaded: email_helper
INFO - 2020-02-25 16:58:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:58:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:58:35 --> Parser Class Initialized
INFO - 2020-02-25 16:58:35 --> User Agent Class Initialized
INFO - 2020-02-25 16:58:35 --> Model Class Initialized
INFO - 2020-02-25 16:58:35 --> Database Driver Class Initialized
INFO - 2020-02-25 16:58:35 --> Model Class Initialized
DEBUG - 2020-02-25 16:58:35 --> Template Class Initialized
INFO - 2020-02-25 16:58:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:58:35 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:58:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:58:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:58:35 --> Encryption Class Initialized
INFO - 2020-02-25 16:58:35 --> Controller Class Initialized
DEBUG - 2020-02-25 16:58:35 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:58:35 --> Model Class Initialized
ERROR - 2020-02-25 16:58:35 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:58:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:58:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:58:35 --> Model Class Initialized
DEBUG - 2020-02-25 16:58:35 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:58:35 --> Model Class Initialized
DEBUG - 2020-02-25 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:58:35 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:35 --> Total execution time: 0.7599
INFO - 2020-02-25 16:58:37 --> Config Class Initialized
INFO - 2020-02-25 16:58:37 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:37 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:37 --> URI Class Initialized
INFO - 2020-02-25 16:58:37 --> Router Class Initialized
INFO - 2020-02-25 16:58:37 --> Output Class Initialized
INFO - 2020-02-25 16:58:37 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:37 --> CSRF cookie sent
INFO - 2020-02-25 16:58:37 --> Input Class Initialized
INFO - 2020-02-25 16:58:37 --> Language Class Initialized
INFO - 2020-02-25 16:58:37 --> Language Class Initialized
INFO - 2020-02-25 16:58:37 --> Config Class Initialized
INFO - 2020-02-25 16:58:37 --> Loader Class Initialized
INFO - 2020-02-25 16:58:37 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:37 --> Helper loaded: common_helper
INFO - 2020-02-25 16:58:38 --> Helper loaded: language_helper
INFO - 2020-02-25 16:58:38 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:58:38 --> Helper loaded: email_helper
INFO - 2020-02-25 16:58:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:58:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:58:38 --> Parser Class Initialized
INFO - 2020-02-25 16:58:38 --> User Agent Class Initialized
INFO - 2020-02-25 16:58:38 --> Model Class Initialized
INFO - 2020-02-25 16:58:38 --> Database Driver Class Initialized
INFO - 2020-02-25 16:58:38 --> Model Class Initialized
DEBUG - 2020-02-25 16:58:38 --> Template Class Initialized
INFO - 2020-02-25 16:58:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:58:38 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:58:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:58:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:58:38 --> Encryption Class Initialized
INFO - 2020-02-25 16:58:38 --> Controller Class Initialized
DEBUG - 2020-02-25 16:58:38 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:58:38 --> Model Class Initialized
ERROR - 2020-02-25 16:58:38 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:58:38 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:58:38 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:58:38 --> Model Class Initialized
DEBUG - 2020-02-25 16:58:38 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:58:38 --> Model Class Initialized
DEBUG - 2020-02-25 16:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:58:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:58:38 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:38 --> Total execution time: 0.7617
INFO - 2020-02-25 16:59:33 --> Config Class Initialized
INFO - 2020-02-25 16:59:33 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:59:33 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:59:33 --> Utf8 Class Initialized
INFO - 2020-02-25 16:59:33 --> URI Class Initialized
INFO - 2020-02-25 16:59:33 --> Router Class Initialized
INFO - 2020-02-25 16:59:33 --> Output Class Initialized
INFO - 2020-02-25 16:59:33 --> Security Class Initialized
DEBUG - 2020-02-25 16:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:59:33 --> CSRF cookie sent
INFO - 2020-02-25 16:59:33 --> Input Class Initialized
INFO - 2020-02-25 16:59:33 --> Language Class Initialized
INFO - 2020-02-25 16:59:33 --> Language Class Initialized
INFO - 2020-02-25 16:59:33 --> Config Class Initialized
INFO - 2020-02-25 16:59:33 --> Loader Class Initialized
INFO - 2020-02-25 16:59:33 --> Helper loaded: url_helper
INFO - 2020-02-25 16:59:33 --> Helper loaded: common_helper
INFO - 2020-02-25 16:59:33 --> Helper loaded: language_helper
INFO - 2020-02-25 16:59:33 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:59:33 --> Helper loaded: email_helper
INFO - 2020-02-25 16:59:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:59:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:59:33 --> Parser Class Initialized
INFO - 2020-02-25 16:59:33 --> User Agent Class Initialized
INFO - 2020-02-25 16:59:33 --> Model Class Initialized
INFO - 2020-02-25 16:59:33 --> Database Driver Class Initialized
INFO - 2020-02-25 16:59:33 --> Model Class Initialized
DEBUG - 2020-02-25 16:59:33 --> Template Class Initialized
INFO - 2020-02-25 16:59:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:59:33 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:59:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:59:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:59:33 --> Encryption Class Initialized
INFO - 2020-02-25 16:59:33 --> Controller Class Initialized
DEBUG - 2020-02-25 16:59:33 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:59:33 --> Model Class Initialized
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:59:33 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "Delele"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 16:59:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:59:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 16:59:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 16:59:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 16:59:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 16:59:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:59:34 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:59:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:59:34 --> Model Class Initialized
DEBUG - 2020-02-25 16:59:34 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:59:34 --> Model Class Initialized
DEBUG - 2020-02-25 16:59:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:59:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:59:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:59:34 --> Final output sent to browser
DEBUG - 2020-02-25 16:59:34 --> Total execution time: 1.2379
INFO - 2020-02-25 16:59:38 --> Config Class Initialized
INFO - 2020-02-25 16:59:38 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:59:38 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:59:38 --> Utf8 Class Initialized
INFO - 2020-02-25 16:59:38 --> URI Class Initialized
INFO - 2020-02-25 16:59:38 --> Router Class Initialized
INFO - 2020-02-25 16:59:38 --> Output Class Initialized
INFO - 2020-02-25 16:59:38 --> Security Class Initialized
DEBUG - 2020-02-25 16:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:59:38 --> CSRF cookie sent
INFO - 2020-02-25 16:59:38 --> Input Class Initialized
INFO - 2020-02-25 16:59:38 --> Language Class Initialized
INFO - 2020-02-25 16:59:38 --> Language Class Initialized
INFO - 2020-02-25 16:59:38 --> Config Class Initialized
INFO - 2020-02-25 16:59:38 --> Loader Class Initialized
INFO - 2020-02-25 16:59:38 --> Helper loaded: url_helper
INFO - 2020-02-25 16:59:38 --> Helper loaded: common_helper
INFO - 2020-02-25 16:59:38 --> Helper loaded: language_helper
INFO - 2020-02-25 16:59:38 --> Helper loaded: cookie_helper
INFO - 2020-02-25 16:59:38 --> Helper loaded: email_helper
INFO - 2020-02-25 16:59:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 16:59:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 16:59:38 --> Parser Class Initialized
INFO - 2020-02-25 16:59:38 --> User Agent Class Initialized
INFO - 2020-02-25 16:59:38 --> Model Class Initialized
INFO - 2020-02-25 16:59:38 --> Database Driver Class Initialized
INFO - 2020-02-25 16:59:39 --> Model Class Initialized
DEBUG - 2020-02-25 16:59:39 --> Template Class Initialized
INFO - 2020-02-25 16:59:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 16:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:59:39 --> Pagination Class Initialized
DEBUG - 2020-02-25 16:59:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 16:59:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 16:59:39 --> Encryption Class Initialized
INFO - 2020-02-25 16:59:39 --> Controller Class Initialized
DEBUG - 2020-02-25 16:59:39 --> category MX_Controller Initialized
DEBUG - 2020-02-25 16:59:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:59:39 --> Model Class Initialized
ERROR - 2020-02-25 16:59:39 --> Could not find the language line "Sorting"
INFO - 2020-02-25 16:59:39 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 16:59:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 16:59:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 16:59:39 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 16:59:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 16:59:39 --> Model Class Initialized
DEBUG - 2020-02-25 16:59:39 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 16:59:39 --> Model Class Initialized
DEBUG - 2020-02-25 16:59:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 16:59:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 16:59:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 16:59:39 --> Final output sent to browser
DEBUG - 2020-02-25 16:59:39 --> Total execution time: 0.7697
INFO - 2020-02-25 17:00:08 --> Config Class Initialized
INFO - 2020-02-25 17:00:08 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:00:08 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:00:08 --> Utf8 Class Initialized
INFO - 2020-02-25 17:00:08 --> URI Class Initialized
INFO - 2020-02-25 17:00:08 --> Router Class Initialized
INFO - 2020-02-25 17:00:08 --> Output Class Initialized
INFO - 2020-02-25 17:00:08 --> Security Class Initialized
DEBUG - 2020-02-25 17:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:00:08 --> CSRF cookie sent
INFO - 2020-02-25 17:00:08 --> Input Class Initialized
INFO - 2020-02-25 17:00:08 --> Language Class Initialized
INFO - 2020-02-25 17:00:08 --> Language Class Initialized
INFO - 2020-02-25 17:00:08 --> Config Class Initialized
INFO - 2020-02-25 17:00:08 --> Loader Class Initialized
INFO - 2020-02-25 17:00:08 --> Helper loaded: url_helper
INFO - 2020-02-25 17:00:08 --> Helper loaded: common_helper
INFO - 2020-02-25 17:00:08 --> Helper loaded: language_helper
INFO - 2020-02-25 17:00:08 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:00:08 --> Helper loaded: email_helper
INFO - 2020-02-25 17:00:08 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:00:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:00:09 --> Parser Class Initialized
INFO - 2020-02-25 17:00:09 --> User Agent Class Initialized
INFO - 2020-02-25 17:00:09 --> Model Class Initialized
INFO - 2020-02-25 17:00:09 --> Database Driver Class Initialized
INFO - 2020-02-25 17:00:09 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:09 --> Template Class Initialized
INFO - 2020-02-25 17:00:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:00:09 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:00:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:00:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:00:09 --> Encryption Class Initialized
INFO - 2020-02-25 17:00:09 --> Controller Class Initialized
DEBUG - 2020-02-25 17:00:09 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:09 --> Model Class Initialized
ERROR - 2020-02-25 17:00:09 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:00:09 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:00:09 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:00:09 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:09 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:09 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:00:09 --> Final output sent to browser
DEBUG - 2020-02-25 17:00:09 --> Total execution time: 0.7815
INFO - 2020-02-25 17:00:24 --> Config Class Initialized
INFO - 2020-02-25 17:00:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:00:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:00:24 --> Utf8 Class Initialized
INFO - 2020-02-25 17:00:24 --> URI Class Initialized
INFO - 2020-02-25 17:00:24 --> Router Class Initialized
INFO - 2020-02-25 17:00:24 --> Output Class Initialized
INFO - 2020-02-25 17:00:24 --> Security Class Initialized
DEBUG - 2020-02-25 17:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:00:24 --> CSRF cookie sent
INFO - 2020-02-25 17:00:24 --> CSRF token verified
INFO - 2020-02-25 17:00:24 --> Input Class Initialized
INFO - 2020-02-25 17:00:24 --> Language Class Initialized
INFO - 2020-02-25 17:00:24 --> Language Class Initialized
INFO - 2020-02-25 17:00:24 --> Config Class Initialized
INFO - 2020-02-25 17:00:24 --> Loader Class Initialized
INFO - 2020-02-25 17:00:24 --> Helper loaded: url_helper
INFO - 2020-02-25 17:00:24 --> Helper loaded: common_helper
INFO - 2020-02-25 17:00:24 --> Helper loaded: language_helper
INFO - 2020-02-25 17:00:24 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:00:24 --> Helper loaded: email_helper
INFO - 2020-02-25 17:00:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:00:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:00:24 --> Parser Class Initialized
INFO - 2020-02-25 17:00:24 --> User Agent Class Initialized
INFO - 2020-02-25 17:00:24 --> Model Class Initialized
INFO - 2020-02-25 17:00:24 --> Database Driver Class Initialized
INFO - 2020-02-25 17:00:24 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:24 --> Template Class Initialized
INFO - 2020-02-25 17:00:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:00:24 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:00:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:00:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:00:24 --> Encryption Class Initialized
INFO - 2020-02-25 17:00:24 --> Controller Class Initialized
DEBUG - 2020-02-25 17:00:24 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:00:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:24 --> Model Class Initialized
ERROR - 2020-02-25 17:00:24 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:00:29 --> Config Class Initialized
INFO - 2020-02-25 17:00:29 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:00:29 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:00:29 --> Utf8 Class Initialized
INFO - 2020-02-25 17:00:29 --> URI Class Initialized
INFO - 2020-02-25 17:00:29 --> Router Class Initialized
INFO - 2020-02-25 17:00:29 --> Output Class Initialized
INFO - 2020-02-25 17:00:29 --> Security Class Initialized
DEBUG - 2020-02-25 17:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:00:29 --> CSRF cookie sent
INFO - 2020-02-25 17:00:29 --> Input Class Initialized
INFO - 2020-02-25 17:00:29 --> Language Class Initialized
INFO - 2020-02-25 17:00:29 --> Language Class Initialized
INFO - 2020-02-25 17:00:29 --> Config Class Initialized
INFO - 2020-02-25 17:00:29 --> Loader Class Initialized
INFO - 2020-02-25 17:00:29 --> Helper loaded: url_helper
INFO - 2020-02-25 17:00:29 --> Helper loaded: common_helper
INFO - 2020-02-25 17:00:29 --> Helper loaded: language_helper
INFO - 2020-02-25 17:00:29 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:00:29 --> Helper loaded: email_helper
INFO - 2020-02-25 17:00:29 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:00:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:00:29 --> Parser Class Initialized
INFO - 2020-02-25 17:00:29 --> User Agent Class Initialized
INFO - 2020-02-25 17:00:29 --> Model Class Initialized
INFO - 2020-02-25 17:00:29 --> Database Driver Class Initialized
INFO - 2020-02-25 17:00:29 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:29 --> Template Class Initialized
INFO - 2020-02-25 17:00:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:00:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:00:29 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:00:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:00:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:00:29 --> Encryption Class Initialized
INFO - 2020-02-25 17:00:29 --> Controller Class Initialized
DEBUG - 2020-02-25 17:00:29 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:00:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:29 --> Model Class Initialized
ERROR - 2020-02-25 17:00:29 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:00:29 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:00:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:00:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:00:29 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:00:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:00:29 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:29 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:29 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:00:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:00:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:00:30 --> Final output sent to browser
DEBUG - 2020-02-25 17:00:30 --> Total execution time: 0.8705
INFO - 2020-02-25 17:00:32 --> Config Class Initialized
INFO - 2020-02-25 17:00:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:00:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:00:32 --> Utf8 Class Initialized
INFO - 2020-02-25 17:00:32 --> URI Class Initialized
INFO - 2020-02-25 17:00:33 --> Router Class Initialized
INFO - 2020-02-25 17:00:33 --> Output Class Initialized
INFO - 2020-02-25 17:00:33 --> Security Class Initialized
DEBUG - 2020-02-25 17:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:00:33 --> CSRF cookie sent
INFO - 2020-02-25 17:00:33 --> Input Class Initialized
INFO - 2020-02-25 17:00:33 --> Language Class Initialized
INFO - 2020-02-25 17:00:33 --> Language Class Initialized
INFO - 2020-02-25 17:00:33 --> Config Class Initialized
INFO - 2020-02-25 17:00:33 --> Loader Class Initialized
INFO - 2020-02-25 17:00:33 --> Helper loaded: url_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: common_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: language_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: email_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:00:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:00:33 --> Parser Class Initialized
INFO - 2020-02-25 17:00:33 --> User Agent Class Initialized
INFO - 2020-02-25 17:00:33 --> Model Class Initialized
INFO - 2020-02-25 17:00:33 --> Database Driver Class Initialized
INFO - 2020-02-25 17:00:33 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:33 --> Template Class Initialized
INFO - 2020-02-25 17:00:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:00:33 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:00:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:00:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:00:33 --> Encryption Class Initialized
INFO - 2020-02-25 17:00:33 --> Controller Class Initialized
DEBUG - 2020-02-25 17:00:33 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:00:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:33 --> Model Class Initialized
ERROR - 2020-02-25 17:00:33 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:00:33 --> Config Class Initialized
INFO - 2020-02-25 17:00:33 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:00:33 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:00:33 --> Utf8 Class Initialized
INFO - 2020-02-25 17:00:33 --> URI Class Initialized
INFO - 2020-02-25 17:00:33 --> Router Class Initialized
INFO - 2020-02-25 17:00:33 --> Output Class Initialized
INFO - 2020-02-25 17:00:33 --> Security Class Initialized
DEBUG - 2020-02-25 17:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:00:33 --> CSRF cookie sent
INFO - 2020-02-25 17:00:33 --> Input Class Initialized
INFO - 2020-02-25 17:00:33 --> Language Class Initialized
INFO - 2020-02-25 17:00:33 --> Language Class Initialized
INFO - 2020-02-25 17:00:33 --> Config Class Initialized
INFO - 2020-02-25 17:00:33 --> Loader Class Initialized
INFO - 2020-02-25 17:00:33 --> Helper loaded: url_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: common_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: language_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: email_helper
INFO - 2020-02-25 17:00:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:00:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:00:33 --> Parser Class Initialized
INFO - 2020-02-25 17:00:33 --> User Agent Class Initialized
INFO - 2020-02-25 17:00:33 --> Model Class Initialized
INFO - 2020-02-25 17:00:33 --> Database Driver Class Initialized
INFO - 2020-02-25 17:00:33 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:33 --> Template Class Initialized
INFO - 2020-02-25 17:00:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:00:34 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:00:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:00:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:00:34 --> Encryption Class Initialized
INFO - 2020-02-25 17:00:34 --> Controller Class Initialized
DEBUG - 2020-02-25 17:00:34 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:34 --> Model Class Initialized
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:00:34 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:00:34 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:00:34 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:34 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:34 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:00:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:00:34 --> Final output sent to browser
DEBUG - 2020-02-25 17:00:34 --> Total execution time: 1.2311
INFO - 2020-02-25 17:00:39 --> Config Class Initialized
INFO - 2020-02-25 17:00:39 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:00:39 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:00:39 --> Utf8 Class Initialized
INFO - 2020-02-25 17:00:39 --> URI Class Initialized
INFO - 2020-02-25 17:00:39 --> Router Class Initialized
INFO - 2020-02-25 17:00:39 --> Output Class Initialized
INFO - 2020-02-25 17:00:39 --> Security Class Initialized
DEBUG - 2020-02-25 17:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:00:39 --> CSRF cookie sent
INFO - 2020-02-25 17:00:39 --> Input Class Initialized
INFO - 2020-02-25 17:00:39 --> Language Class Initialized
INFO - 2020-02-25 17:00:39 --> Language Class Initialized
INFO - 2020-02-25 17:00:39 --> Config Class Initialized
INFO - 2020-02-25 17:00:39 --> Loader Class Initialized
INFO - 2020-02-25 17:00:39 --> Helper loaded: url_helper
INFO - 2020-02-25 17:00:40 --> Helper loaded: common_helper
INFO - 2020-02-25 17:00:40 --> Helper loaded: language_helper
INFO - 2020-02-25 17:00:40 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:00:40 --> Helper loaded: email_helper
INFO - 2020-02-25 17:00:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:00:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:00:40 --> Parser Class Initialized
INFO - 2020-02-25 17:00:40 --> User Agent Class Initialized
INFO - 2020-02-25 17:00:40 --> Model Class Initialized
INFO - 2020-02-25 17:00:40 --> Database Driver Class Initialized
INFO - 2020-02-25 17:00:40 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:40 --> Template Class Initialized
INFO - 2020-02-25 17:00:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:00:40 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:00:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:00:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:00:40 --> Encryption Class Initialized
INFO - 2020-02-25 17:00:40 --> Controller Class Initialized
DEBUG - 2020-02-25 17:00:40 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:40 --> Model Class Initialized
ERROR - 2020-02-25 17:00:40 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:00:40 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:00:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:00:40 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:40 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:40 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:00:40 --> Final output sent to browser
DEBUG - 2020-02-25 17:00:40 --> Total execution time: 1.0435
INFO - 2020-02-25 17:00:42 --> Config Class Initialized
INFO - 2020-02-25 17:00:42 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:00:42 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:00:42 --> Utf8 Class Initialized
INFO - 2020-02-25 17:00:42 --> URI Class Initialized
INFO - 2020-02-25 17:00:42 --> Router Class Initialized
INFO - 2020-02-25 17:00:42 --> Output Class Initialized
INFO - 2020-02-25 17:00:42 --> Security Class Initialized
DEBUG - 2020-02-25 17:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:00:42 --> CSRF cookie sent
INFO - 2020-02-25 17:00:42 --> Input Class Initialized
INFO - 2020-02-25 17:00:43 --> Language Class Initialized
INFO - 2020-02-25 17:00:43 --> Language Class Initialized
INFO - 2020-02-25 17:00:43 --> Config Class Initialized
INFO - 2020-02-25 17:00:43 --> Loader Class Initialized
INFO - 2020-02-25 17:00:43 --> Helper loaded: url_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: common_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: language_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: email_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:00:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:00:43 --> Parser Class Initialized
INFO - 2020-02-25 17:00:43 --> User Agent Class Initialized
INFO - 2020-02-25 17:00:43 --> Model Class Initialized
INFO - 2020-02-25 17:00:43 --> Database Driver Class Initialized
INFO - 2020-02-25 17:00:43 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:43 --> Template Class Initialized
INFO - 2020-02-25 17:00:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:00:43 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:00:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:00:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:00:43 --> Encryption Class Initialized
INFO - 2020-02-25 17:00:43 --> Controller Class Initialized
DEBUG - 2020-02-25 17:00:43 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:43 --> Model Class Initialized
ERROR - 2020-02-25 17:00:43 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:00:43 --> Config Class Initialized
INFO - 2020-02-25 17:00:43 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:00:43 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:00:43 --> Utf8 Class Initialized
INFO - 2020-02-25 17:00:43 --> URI Class Initialized
INFO - 2020-02-25 17:00:43 --> Router Class Initialized
INFO - 2020-02-25 17:00:43 --> Output Class Initialized
INFO - 2020-02-25 17:00:43 --> Security Class Initialized
DEBUG - 2020-02-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:00:43 --> CSRF cookie sent
INFO - 2020-02-25 17:00:43 --> Input Class Initialized
INFO - 2020-02-25 17:00:43 --> Language Class Initialized
INFO - 2020-02-25 17:00:43 --> Language Class Initialized
INFO - 2020-02-25 17:00:43 --> Config Class Initialized
INFO - 2020-02-25 17:00:43 --> Loader Class Initialized
INFO - 2020-02-25 17:00:43 --> Helper loaded: url_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: common_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: language_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: email_helper
INFO - 2020-02-25 17:00:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:00:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:00:43 --> Parser Class Initialized
INFO - 2020-02-25 17:00:43 --> User Agent Class Initialized
INFO - 2020-02-25 17:00:43 --> Model Class Initialized
INFO - 2020-02-25 17:00:43 --> Database Driver Class Initialized
INFO - 2020-02-25 17:00:43 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:43 --> Template Class Initialized
INFO - 2020-02-25 17:00:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:00:44 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:00:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:00:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:00:44 --> Encryption Class Initialized
INFO - 2020-02-25 17:00:44 --> Controller Class Initialized
DEBUG - 2020-02-25 17:00:44 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:44 --> Model Class Initialized
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:00:44 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:00:44 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:00:44 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:00:44 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:44 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:44 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:00:44 --> Final output sent to browser
DEBUG - 2020-02-25 17:00:44 --> Total execution time: 1.3188
INFO - 2020-02-25 17:00:49 --> Config Class Initialized
INFO - 2020-02-25 17:00:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:00:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:00:49 --> Utf8 Class Initialized
INFO - 2020-02-25 17:00:49 --> URI Class Initialized
INFO - 2020-02-25 17:00:49 --> Router Class Initialized
INFO - 2020-02-25 17:00:49 --> Output Class Initialized
INFO - 2020-02-25 17:00:49 --> Security Class Initialized
DEBUG - 2020-02-25 17:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:00:49 --> CSRF cookie sent
INFO - 2020-02-25 17:00:49 --> Input Class Initialized
INFO - 2020-02-25 17:00:49 --> Language Class Initialized
INFO - 2020-02-25 17:00:49 --> Language Class Initialized
INFO - 2020-02-25 17:00:49 --> Config Class Initialized
INFO - 2020-02-25 17:00:49 --> Loader Class Initialized
INFO - 2020-02-25 17:00:49 --> Helper loaded: url_helper
INFO - 2020-02-25 17:00:49 --> Helper loaded: common_helper
INFO - 2020-02-25 17:00:49 --> Helper loaded: language_helper
INFO - 2020-02-25 17:00:49 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:00:49 --> Helper loaded: email_helper
INFO - 2020-02-25 17:00:49 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:00:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:00:49 --> Parser Class Initialized
INFO - 2020-02-25 17:00:49 --> User Agent Class Initialized
INFO - 2020-02-25 17:00:49 --> Model Class Initialized
INFO - 2020-02-25 17:00:49 --> Database Driver Class Initialized
INFO - 2020-02-25 17:00:49 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:49 --> Template Class Initialized
INFO - 2020-02-25 17:00:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:00:49 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:00:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:00:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:00:49 --> Encryption Class Initialized
INFO - 2020-02-25 17:00:49 --> Controller Class Initialized
DEBUG - 2020-02-25 17:00:49 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:49 --> Model Class Initialized
ERROR - 2020-02-25 17:00:49 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:00:49 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:00:49 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:00:49 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:49 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:00:49 --> Model Class Initialized
DEBUG - 2020-02-25 17:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:00:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:00:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:00:50 --> Final output sent to browser
DEBUG - 2020-02-25 17:00:50 --> Total execution time: 1.0295
INFO - 2020-02-25 17:01:43 --> Config Class Initialized
INFO - 2020-02-25 17:01:43 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:43 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:43 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:43 --> URI Class Initialized
INFO - 2020-02-25 17:01:43 --> Router Class Initialized
INFO - 2020-02-25 17:01:43 --> Output Class Initialized
INFO - 2020-02-25 17:01:43 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:44 --> CSRF cookie sent
INFO - 2020-02-25 17:01:44 --> Input Class Initialized
INFO - 2020-02-25 17:01:44 --> Language Class Initialized
INFO - 2020-02-25 17:01:44 --> Language Class Initialized
INFO - 2020-02-25 17:01:44 --> Config Class Initialized
INFO - 2020-02-25 17:01:44 --> Loader Class Initialized
INFO - 2020-02-25 17:01:44 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:44 --> Helper loaded: common_helper
INFO - 2020-02-25 17:01:44 --> Helper loaded: language_helper
INFO - 2020-02-25 17:01:44 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:01:44 --> Helper loaded: email_helper
INFO - 2020-02-25 17:01:44 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:01:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:01:44 --> Parser Class Initialized
INFO - 2020-02-25 17:01:44 --> User Agent Class Initialized
INFO - 2020-02-25 17:01:44 --> Model Class Initialized
INFO - 2020-02-25 17:01:44 --> Database Driver Class Initialized
INFO - 2020-02-25 17:01:44 --> Model Class Initialized
DEBUG - 2020-02-25 17:01:44 --> Template Class Initialized
INFO - 2020-02-25 17:01:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:01:44 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:01:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:01:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:01:44 --> Encryption Class Initialized
INFO - 2020-02-25 17:01:44 --> Controller Class Initialized
DEBUG - 2020-02-25 17:01:44 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:01:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:01:44 --> Model Class Initialized
ERROR - 2020-02-25 17:01:44 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:02:47 --> Config Class Initialized
INFO - 2020-02-25 17:02:47 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:47 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:47 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:47 --> URI Class Initialized
INFO - 2020-02-25 17:02:47 --> Router Class Initialized
INFO - 2020-02-25 17:02:47 --> Output Class Initialized
INFO - 2020-02-25 17:02:47 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:47 --> CSRF cookie sent
INFO - 2020-02-25 17:02:47 --> Input Class Initialized
INFO - 2020-02-25 17:02:47 --> Language Class Initialized
INFO - 2020-02-25 17:02:47 --> Language Class Initialized
INFO - 2020-02-25 17:02:47 --> Config Class Initialized
INFO - 2020-02-25 17:02:47 --> Loader Class Initialized
INFO - 2020-02-25 17:02:47 --> Helper loaded: url_helper
INFO - 2020-02-25 17:02:47 --> Helper loaded: common_helper
INFO - 2020-02-25 17:02:47 --> Helper loaded: language_helper
INFO - 2020-02-25 17:02:47 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:02:47 --> Helper loaded: email_helper
INFO - 2020-02-25 17:02:47 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:02:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:02:47 --> Parser Class Initialized
INFO - 2020-02-25 17:02:47 --> User Agent Class Initialized
INFO - 2020-02-25 17:02:47 --> Model Class Initialized
INFO - 2020-02-25 17:02:47 --> Database Driver Class Initialized
INFO - 2020-02-25 17:02:47 --> Model Class Initialized
DEBUG - 2020-02-25 17:02:47 --> Template Class Initialized
INFO - 2020-02-25 17:02:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:02:47 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:02:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:02:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:02:47 --> Encryption Class Initialized
INFO - 2020-02-25 17:02:47 --> Controller Class Initialized
DEBUG - 2020-02-25 17:02:47 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:02:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:02:47 --> Model Class Initialized
ERROR - 2020-02-25 17:02:47 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:03:09 --> Config Class Initialized
INFO - 2020-02-25 17:03:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:03:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:03:09 --> Utf8 Class Initialized
INFO - 2020-02-25 17:03:09 --> URI Class Initialized
INFO - 2020-02-25 17:03:09 --> Router Class Initialized
INFO - 2020-02-25 17:03:09 --> Output Class Initialized
INFO - 2020-02-25 17:03:09 --> Security Class Initialized
DEBUG - 2020-02-25 17:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:03:09 --> CSRF cookie sent
INFO - 2020-02-25 17:03:09 --> Input Class Initialized
INFO - 2020-02-25 17:03:09 --> Language Class Initialized
INFO - 2020-02-25 17:03:09 --> Language Class Initialized
INFO - 2020-02-25 17:03:09 --> Config Class Initialized
INFO - 2020-02-25 17:03:09 --> Loader Class Initialized
INFO - 2020-02-25 17:03:09 --> Helper loaded: url_helper
INFO - 2020-02-25 17:03:09 --> Helper loaded: common_helper
INFO - 2020-02-25 17:03:09 --> Helper loaded: language_helper
INFO - 2020-02-25 17:03:09 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:03:09 --> Helper loaded: email_helper
INFO - 2020-02-25 17:03:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:03:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:03:09 --> Parser Class Initialized
INFO - 2020-02-25 17:03:09 --> User Agent Class Initialized
INFO - 2020-02-25 17:03:09 --> Model Class Initialized
INFO - 2020-02-25 17:03:09 --> Database Driver Class Initialized
INFO - 2020-02-25 17:03:09 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:09 --> Template Class Initialized
INFO - 2020-02-25 17:03:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:03:09 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:03:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:03:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:03:10 --> Encryption Class Initialized
INFO - 2020-02-25 17:03:10 --> Controller Class Initialized
DEBUG - 2020-02-25 17:03:10 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:03:10 --> Model Class Initialized
ERROR - 2020-02-25 17:03:10 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:03:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:03:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:03:10 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:03:10 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:03:10 --> Final output sent to browser
DEBUG - 2020-02-25 17:03:10 --> Total execution time: 0.8731
INFO - 2020-02-25 17:03:47 --> Config Class Initialized
INFO - 2020-02-25 17:03:47 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:03:47 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:03:47 --> Utf8 Class Initialized
INFO - 2020-02-25 17:03:47 --> URI Class Initialized
INFO - 2020-02-25 17:03:47 --> Router Class Initialized
INFO - 2020-02-25 17:03:47 --> Output Class Initialized
INFO - 2020-02-25 17:03:47 --> Security Class Initialized
DEBUG - 2020-02-25 17:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:03:47 --> CSRF cookie sent
INFO - 2020-02-25 17:03:47 --> CSRF token verified
INFO - 2020-02-25 17:03:47 --> Input Class Initialized
INFO - 2020-02-25 17:03:47 --> Language Class Initialized
INFO - 2020-02-25 17:03:47 --> Language Class Initialized
INFO - 2020-02-25 17:03:47 --> Config Class Initialized
INFO - 2020-02-25 17:03:47 --> Loader Class Initialized
INFO - 2020-02-25 17:03:47 --> Helper loaded: url_helper
INFO - 2020-02-25 17:03:47 --> Helper loaded: common_helper
INFO - 2020-02-25 17:03:47 --> Helper loaded: language_helper
INFO - 2020-02-25 17:03:47 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:03:47 --> Helper loaded: email_helper
INFO - 2020-02-25 17:03:47 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:03:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:03:47 --> Parser Class Initialized
INFO - 2020-02-25 17:03:47 --> User Agent Class Initialized
INFO - 2020-02-25 17:03:48 --> Model Class Initialized
INFO - 2020-02-25 17:03:48 --> Database Driver Class Initialized
INFO - 2020-02-25 17:03:48 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:48 --> Template Class Initialized
INFO - 2020-02-25 17:03:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:03:48 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:03:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:03:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:03:48 --> Encryption Class Initialized
INFO - 2020-02-25 17:03:48 --> Controller Class Initialized
DEBUG - 2020-02-25 17:03:48 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:03:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:03:48 --> Model Class Initialized
ERROR - 2020-02-25 17:03:48 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:03:52 --> Config Class Initialized
INFO - 2020-02-25 17:03:52 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:03:52 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:03:52 --> Utf8 Class Initialized
INFO - 2020-02-25 17:03:52 --> URI Class Initialized
INFO - 2020-02-25 17:03:52 --> Router Class Initialized
INFO - 2020-02-25 17:03:52 --> Output Class Initialized
INFO - 2020-02-25 17:03:52 --> Security Class Initialized
DEBUG - 2020-02-25 17:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:03:52 --> CSRF cookie sent
INFO - 2020-02-25 17:03:52 --> Input Class Initialized
INFO - 2020-02-25 17:03:52 --> Language Class Initialized
INFO - 2020-02-25 17:03:52 --> Language Class Initialized
INFO - 2020-02-25 17:03:52 --> Config Class Initialized
INFO - 2020-02-25 17:03:53 --> Loader Class Initialized
INFO - 2020-02-25 17:03:53 --> Helper loaded: url_helper
INFO - 2020-02-25 17:03:53 --> Helper loaded: common_helper
INFO - 2020-02-25 17:03:53 --> Helper loaded: language_helper
INFO - 2020-02-25 17:03:53 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:03:53 --> Helper loaded: email_helper
INFO - 2020-02-25 17:03:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:03:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:03:53 --> Parser Class Initialized
INFO - 2020-02-25 17:03:53 --> User Agent Class Initialized
INFO - 2020-02-25 17:03:53 --> Model Class Initialized
INFO - 2020-02-25 17:03:53 --> Database Driver Class Initialized
INFO - 2020-02-25 17:03:53 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:53 --> Template Class Initialized
INFO - 2020-02-25 17:03:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:03:53 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:03:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:03:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:03:53 --> Encryption Class Initialized
INFO - 2020-02-25 17:03:53 --> Controller Class Initialized
DEBUG - 2020-02-25 17:03:53 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:03:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:03:53 --> Model Class Initialized
ERROR - 2020-02-25 17:03:53 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:03:53 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:03:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:03:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:03:53 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:03:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:03:53 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:53 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:03:53 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:03:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:03:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:03:53 --> Final output sent to browser
DEBUG - 2020-02-25 17:03:53 --> Total execution time: 0.8992
INFO - 2020-02-25 17:03:55 --> Config Class Initialized
INFO - 2020-02-25 17:03:55 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:03:55 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:03:55 --> Utf8 Class Initialized
INFO - 2020-02-25 17:03:55 --> URI Class Initialized
INFO - 2020-02-25 17:03:55 --> Router Class Initialized
INFO - 2020-02-25 17:03:55 --> Output Class Initialized
INFO - 2020-02-25 17:03:55 --> Security Class Initialized
DEBUG - 2020-02-25 17:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:03:55 --> CSRF cookie sent
INFO - 2020-02-25 17:03:55 --> Input Class Initialized
INFO - 2020-02-25 17:03:55 --> Language Class Initialized
INFO - 2020-02-25 17:03:55 --> Language Class Initialized
INFO - 2020-02-25 17:03:55 --> Config Class Initialized
INFO - 2020-02-25 17:03:55 --> Loader Class Initialized
INFO - 2020-02-25 17:03:55 --> Helper loaded: url_helper
INFO - 2020-02-25 17:03:55 --> Helper loaded: common_helper
INFO - 2020-02-25 17:03:55 --> Helper loaded: language_helper
INFO - 2020-02-25 17:03:56 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:03:56 --> Helper loaded: email_helper
INFO - 2020-02-25 17:03:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:03:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:03:56 --> Parser Class Initialized
INFO - 2020-02-25 17:03:56 --> User Agent Class Initialized
INFO - 2020-02-25 17:03:56 --> Model Class Initialized
INFO - 2020-02-25 17:03:56 --> Database Driver Class Initialized
INFO - 2020-02-25 17:03:56 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:56 --> Template Class Initialized
INFO - 2020-02-25 17:03:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:03:56 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:03:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:03:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:03:56 --> Encryption Class Initialized
INFO - 2020-02-25 17:03:56 --> Controller Class Initialized
DEBUG - 2020-02-25 17:03:56 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:03:56 --> Model Class Initialized
ERROR - 2020-02-25 17:03:56 --> Could not find the language line "Sorting"
ERROR - 2020-02-25 17:03:56 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\controllers\category.php 63
INFO - 2020-02-25 17:03:56 --> Config Class Initialized
INFO - 2020-02-25 17:03:56 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:03:56 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:03:56 --> Utf8 Class Initialized
INFO - 2020-02-25 17:03:56 --> URI Class Initialized
INFO - 2020-02-25 17:03:56 --> Router Class Initialized
INFO - 2020-02-25 17:03:56 --> Output Class Initialized
INFO - 2020-02-25 17:03:56 --> Security Class Initialized
DEBUG - 2020-02-25 17:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:03:56 --> CSRF cookie sent
INFO - 2020-02-25 17:03:56 --> Input Class Initialized
INFO - 2020-02-25 17:03:56 --> Language Class Initialized
INFO - 2020-02-25 17:03:56 --> Language Class Initialized
INFO - 2020-02-25 17:03:56 --> Config Class Initialized
INFO - 2020-02-25 17:03:56 --> Loader Class Initialized
INFO - 2020-02-25 17:03:56 --> Helper loaded: url_helper
INFO - 2020-02-25 17:03:56 --> Helper loaded: common_helper
INFO - 2020-02-25 17:03:56 --> Helper loaded: language_helper
INFO - 2020-02-25 17:03:56 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:03:56 --> Helper loaded: email_helper
INFO - 2020-02-25 17:03:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:03:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:03:56 --> Parser Class Initialized
INFO - 2020-02-25 17:03:56 --> User Agent Class Initialized
INFO - 2020-02-25 17:03:56 --> Model Class Initialized
INFO - 2020-02-25 17:03:56 --> Database Driver Class Initialized
INFO - 2020-02-25 17:03:56 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:56 --> Template Class Initialized
INFO - 2020-02-25 17:03:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:03:56 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:03:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:03:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:03:56 --> Encryption Class Initialized
INFO - 2020-02-25 17:03:56 --> Controller Class Initialized
DEBUG - 2020-02-25 17:03:56 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:03:56 --> Model Class Initialized
ERROR - 2020-02-25 17:03:56 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:03:56 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:03:56 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:03:56 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:56 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:56 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:03:57 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:03:57 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:03:57 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:57 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:03:57 --> Model Class Initialized
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:03:57 --> Final output sent to browser
DEBUG - 2020-02-25 17:03:57 --> Total execution time: 1.2211
INFO - 2020-02-25 17:04:03 --> Config Class Initialized
INFO - 2020-02-25 17:04:03 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:04:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:04:03 --> Utf8 Class Initialized
INFO - 2020-02-25 17:04:03 --> URI Class Initialized
INFO - 2020-02-25 17:04:03 --> Router Class Initialized
INFO - 2020-02-25 17:04:03 --> Output Class Initialized
INFO - 2020-02-25 17:04:03 --> Security Class Initialized
DEBUG - 2020-02-25 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:04:03 --> CSRF cookie sent
INFO - 2020-02-25 17:04:03 --> Input Class Initialized
INFO - 2020-02-25 17:04:03 --> Language Class Initialized
INFO - 2020-02-25 17:04:03 --> Language Class Initialized
INFO - 2020-02-25 17:04:03 --> Config Class Initialized
INFO - 2020-02-25 17:04:03 --> Loader Class Initialized
INFO - 2020-02-25 17:04:03 --> Helper loaded: url_helper
INFO - 2020-02-25 17:04:03 --> Helper loaded: common_helper
INFO - 2020-02-25 17:04:03 --> Helper loaded: language_helper
INFO - 2020-02-25 17:04:03 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:04:03 --> Helper loaded: email_helper
INFO - 2020-02-25 17:04:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:04:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:04:03 --> Parser Class Initialized
INFO - 2020-02-25 17:04:03 --> User Agent Class Initialized
INFO - 2020-02-25 17:04:03 --> Model Class Initialized
INFO - 2020-02-25 17:04:03 --> Database Driver Class Initialized
INFO - 2020-02-25 17:04:03 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:03 --> Template Class Initialized
INFO - 2020-02-25 17:04:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:04:03 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:04:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:04:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:04:03 --> Encryption Class Initialized
INFO - 2020-02-25 17:04:03 --> Controller Class Initialized
DEBUG - 2020-02-25 17:04:04 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:04:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:04 --> Model Class Initialized
ERROR - 2020-02-25 17:04:04 --> Could not find the language line "Sorting"
ERROR - 2020-02-25 17:04:04 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\controllers\category.php 63
INFO - 2020-02-25 17:04:04 --> Config Class Initialized
INFO - 2020-02-25 17:04:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:04:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:04:04 --> Utf8 Class Initialized
INFO - 2020-02-25 17:04:04 --> URI Class Initialized
INFO - 2020-02-25 17:04:04 --> Router Class Initialized
INFO - 2020-02-25 17:04:04 --> Output Class Initialized
INFO - 2020-02-25 17:04:04 --> Security Class Initialized
DEBUG - 2020-02-25 17:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:04:04 --> CSRF cookie sent
INFO - 2020-02-25 17:04:04 --> Input Class Initialized
INFO - 2020-02-25 17:04:04 --> Language Class Initialized
INFO - 2020-02-25 17:04:04 --> Language Class Initialized
INFO - 2020-02-25 17:04:04 --> Config Class Initialized
INFO - 2020-02-25 17:04:04 --> Loader Class Initialized
INFO - 2020-02-25 17:04:04 --> Helper loaded: url_helper
INFO - 2020-02-25 17:04:04 --> Helper loaded: common_helper
INFO - 2020-02-25 17:04:04 --> Helper loaded: language_helper
INFO - 2020-02-25 17:04:04 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:04:04 --> Helper loaded: email_helper
INFO - 2020-02-25 17:04:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:04:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:04:04 --> Parser Class Initialized
INFO - 2020-02-25 17:04:04 --> User Agent Class Initialized
INFO - 2020-02-25 17:04:04 --> Model Class Initialized
INFO - 2020-02-25 17:04:04 --> Database Driver Class Initialized
INFO - 2020-02-25 17:04:04 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:04 --> Template Class Initialized
INFO - 2020-02-25 17:04:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:04:04 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:04:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:04:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:04:04 --> Encryption Class Initialized
INFO - 2020-02-25 17:04:04 --> Controller Class Initialized
DEBUG - 2020-02-25 17:04:04 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:04:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:04 --> Model Class Initialized
ERROR - 2020-02-25 17:04:04 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:04:04 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:04:04 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:04:04 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:05 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:04:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:04:05 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:05 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:04:05 --> Final output sent to browser
DEBUG - 2020-02-25 17:04:05 --> Total execution time: 1.6328
INFO - 2020-02-25 17:04:06 --> Config Class Initialized
INFO - 2020-02-25 17:04:06 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:04:06 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:04:06 --> Utf8 Class Initialized
INFO - 2020-02-25 17:04:06 --> URI Class Initialized
INFO - 2020-02-25 17:04:06 --> Router Class Initialized
INFO - 2020-02-25 17:04:06 --> Output Class Initialized
INFO - 2020-02-25 17:04:06 --> Security Class Initialized
DEBUG - 2020-02-25 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:04:07 --> CSRF cookie sent
INFO - 2020-02-25 17:04:07 --> Input Class Initialized
INFO - 2020-02-25 17:04:07 --> Language Class Initialized
INFO - 2020-02-25 17:04:07 --> Language Class Initialized
INFO - 2020-02-25 17:04:07 --> Config Class Initialized
INFO - 2020-02-25 17:04:07 --> Loader Class Initialized
INFO - 2020-02-25 17:04:07 --> Helper loaded: url_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: common_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: language_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: email_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:04:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:04:07 --> Parser Class Initialized
INFO - 2020-02-25 17:04:07 --> User Agent Class Initialized
INFO - 2020-02-25 17:04:07 --> Model Class Initialized
INFO - 2020-02-25 17:04:07 --> Database Driver Class Initialized
INFO - 2020-02-25 17:04:07 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:07 --> Template Class Initialized
INFO - 2020-02-25 17:04:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:04:07 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:04:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:04:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:04:07 --> Encryption Class Initialized
INFO - 2020-02-25 17:04:07 --> Controller Class Initialized
DEBUG - 2020-02-25 17:04:07 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:04:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:07 --> Model Class Initialized
ERROR - 2020-02-25 17:04:07 --> Could not find the language line "Sorting"
ERROR - 2020-02-25 17:04:07 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\controllers\category.php 63
INFO - 2020-02-25 17:04:07 --> Config Class Initialized
INFO - 2020-02-25 17:04:07 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:04:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:04:07 --> Utf8 Class Initialized
INFO - 2020-02-25 17:04:07 --> URI Class Initialized
INFO - 2020-02-25 17:04:07 --> Router Class Initialized
INFO - 2020-02-25 17:04:07 --> Output Class Initialized
INFO - 2020-02-25 17:04:07 --> Security Class Initialized
DEBUG - 2020-02-25 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:04:07 --> CSRF cookie sent
INFO - 2020-02-25 17:04:07 --> Input Class Initialized
INFO - 2020-02-25 17:04:07 --> Language Class Initialized
INFO - 2020-02-25 17:04:07 --> Language Class Initialized
INFO - 2020-02-25 17:04:07 --> Config Class Initialized
INFO - 2020-02-25 17:04:07 --> Loader Class Initialized
INFO - 2020-02-25 17:04:07 --> Helper loaded: url_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: common_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: language_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: email_helper
INFO - 2020-02-25 17:04:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:04:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:04:07 --> Parser Class Initialized
INFO - 2020-02-25 17:04:07 --> User Agent Class Initialized
INFO - 2020-02-25 17:04:07 --> Model Class Initialized
INFO - 2020-02-25 17:04:07 --> Database Driver Class Initialized
INFO - 2020-02-25 17:04:07 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:07 --> Template Class Initialized
INFO - 2020-02-25 17:04:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:04:07 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:04:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:04:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:04:08 --> Encryption Class Initialized
INFO - 2020-02-25 17:04:08 --> Controller Class Initialized
DEBUG - 2020-02-25 17:04:08 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:08 --> Model Class Initialized
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:04:08 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:08 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:04:08 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:04:08 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:08 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:08 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:04:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:04:08 --> Final output sent to browser
DEBUG - 2020-02-25 17:04:08 --> Total execution time: 1.2616
INFO - 2020-02-25 17:04:10 --> Config Class Initialized
INFO - 2020-02-25 17:04:10 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:04:10 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:04:10 --> Utf8 Class Initialized
INFO - 2020-02-25 17:04:10 --> URI Class Initialized
INFO - 2020-02-25 17:04:10 --> Router Class Initialized
INFO - 2020-02-25 17:04:10 --> Output Class Initialized
INFO - 2020-02-25 17:04:10 --> Security Class Initialized
DEBUG - 2020-02-25 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:04:10 --> CSRF cookie sent
INFO - 2020-02-25 17:04:10 --> Input Class Initialized
INFO - 2020-02-25 17:04:10 --> Language Class Initialized
INFO - 2020-02-25 17:04:10 --> Language Class Initialized
INFO - 2020-02-25 17:04:10 --> Config Class Initialized
INFO - 2020-02-25 17:04:10 --> Loader Class Initialized
INFO - 2020-02-25 17:04:10 --> Helper loaded: url_helper
INFO - 2020-02-25 17:04:10 --> Helper loaded: common_helper
INFO - 2020-02-25 17:04:10 --> Helper loaded: language_helper
INFO - 2020-02-25 17:04:10 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:04:10 --> Helper loaded: email_helper
INFO - 2020-02-25 17:04:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:04:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:04:10 --> Parser Class Initialized
INFO - 2020-02-25 17:04:10 --> User Agent Class Initialized
INFO - 2020-02-25 17:04:10 --> Model Class Initialized
INFO - 2020-02-25 17:04:10 --> Database Driver Class Initialized
INFO - 2020-02-25 17:04:10 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:10 --> Template Class Initialized
INFO - 2020-02-25 17:04:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:04:10 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:04:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:04:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:04:10 --> Encryption Class Initialized
INFO - 2020-02-25 17:04:10 --> Controller Class Initialized
DEBUG - 2020-02-25 17:04:10 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:04:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:10 --> Model Class Initialized
ERROR - 2020-02-25 17:04:10 --> Could not find the language line "Sorting"
ERROR - 2020-02-25 17:04:10 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\controllers\category.php 63
INFO - 2020-02-25 17:04:11 --> Config Class Initialized
INFO - 2020-02-25 17:04:11 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:04:11 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:04:11 --> Utf8 Class Initialized
INFO - 2020-02-25 17:04:11 --> URI Class Initialized
INFO - 2020-02-25 17:04:11 --> Router Class Initialized
INFO - 2020-02-25 17:04:11 --> Output Class Initialized
INFO - 2020-02-25 17:04:11 --> Security Class Initialized
DEBUG - 2020-02-25 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:04:11 --> CSRF cookie sent
INFO - 2020-02-25 17:04:11 --> Input Class Initialized
INFO - 2020-02-25 17:04:11 --> Language Class Initialized
INFO - 2020-02-25 17:04:11 --> Language Class Initialized
INFO - 2020-02-25 17:04:11 --> Config Class Initialized
INFO - 2020-02-25 17:04:11 --> Loader Class Initialized
INFO - 2020-02-25 17:04:11 --> Helper loaded: url_helper
INFO - 2020-02-25 17:04:11 --> Helper loaded: common_helper
INFO - 2020-02-25 17:04:11 --> Helper loaded: language_helper
INFO - 2020-02-25 17:04:11 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:04:11 --> Helper loaded: email_helper
INFO - 2020-02-25 17:04:11 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:04:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:04:11 --> Parser Class Initialized
INFO - 2020-02-25 17:04:11 --> User Agent Class Initialized
INFO - 2020-02-25 17:04:11 --> Model Class Initialized
INFO - 2020-02-25 17:04:11 --> Database Driver Class Initialized
INFO - 2020-02-25 17:04:11 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:11 --> Template Class Initialized
INFO - 2020-02-25 17:04:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:04:11 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:04:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:04:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:04:11 --> Encryption Class Initialized
INFO - 2020-02-25 17:04:11 --> Controller Class Initialized
DEBUG - 2020-02-25 17:04:11 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:04:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:11 --> Model Class Initialized
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:04:11 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:11 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:12 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:12 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:04:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:04:12 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:12 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:04:12 --> Final output sent to browser
DEBUG - 2020-02-25 17:04:12 --> Total execution time: 1.2463
INFO - 2020-02-25 17:04:13 --> Config Class Initialized
INFO - 2020-02-25 17:04:13 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:04:13 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:04:13 --> Utf8 Class Initialized
INFO - 2020-02-25 17:04:13 --> URI Class Initialized
INFO - 2020-02-25 17:04:13 --> Router Class Initialized
INFO - 2020-02-25 17:04:13 --> Output Class Initialized
INFO - 2020-02-25 17:04:13 --> Security Class Initialized
DEBUG - 2020-02-25 17:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:04:13 --> CSRF cookie sent
INFO - 2020-02-25 17:04:13 --> Input Class Initialized
INFO - 2020-02-25 17:04:13 --> Language Class Initialized
INFO - 2020-02-25 17:04:13 --> Language Class Initialized
INFO - 2020-02-25 17:04:13 --> Config Class Initialized
INFO - 2020-02-25 17:04:13 --> Loader Class Initialized
INFO - 2020-02-25 17:04:13 --> Helper loaded: url_helper
INFO - 2020-02-25 17:04:13 --> Helper loaded: common_helper
INFO - 2020-02-25 17:04:13 --> Helper loaded: language_helper
INFO - 2020-02-25 17:04:13 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:04:13 --> Helper loaded: email_helper
INFO - 2020-02-25 17:04:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:04:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:04:13 --> Parser Class Initialized
INFO - 2020-02-25 17:04:13 --> User Agent Class Initialized
INFO - 2020-02-25 17:04:13 --> Model Class Initialized
INFO - 2020-02-25 17:04:13 --> Database Driver Class Initialized
INFO - 2020-02-25 17:04:13 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:13 --> Template Class Initialized
INFO - 2020-02-25 17:04:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:04:13 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:04:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:04:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:04:13 --> Encryption Class Initialized
INFO - 2020-02-25 17:04:13 --> Controller Class Initialized
DEBUG - 2020-02-25 17:04:13 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:04:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:13 --> Model Class Initialized
ERROR - 2020-02-25 17:04:13 --> Could not find the language line "Sorting"
ERROR - 2020-02-25 17:04:13 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\controllers\category.php 63
INFO - 2020-02-25 17:04:13 --> Config Class Initialized
INFO - 2020-02-25 17:04:13 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:04:13 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:04:13 --> Utf8 Class Initialized
INFO - 2020-02-25 17:04:13 --> URI Class Initialized
INFO - 2020-02-25 17:04:13 --> Router Class Initialized
INFO - 2020-02-25 17:04:13 --> Output Class Initialized
INFO - 2020-02-25 17:04:13 --> Security Class Initialized
DEBUG - 2020-02-25 17:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:04:14 --> CSRF cookie sent
INFO - 2020-02-25 17:04:14 --> Input Class Initialized
INFO - 2020-02-25 17:04:14 --> Language Class Initialized
INFO - 2020-02-25 17:04:14 --> Language Class Initialized
INFO - 2020-02-25 17:04:14 --> Config Class Initialized
INFO - 2020-02-25 17:04:14 --> Loader Class Initialized
INFO - 2020-02-25 17:04:14 --> Helper loaded: url_helper
INFO - 2020-02-25 17:04:14 --> Helper loaded: common_helper
INFO - 2020-02-25 17:04:14 --> Helper loaded: language_helper
INFO - 2020-02-25 17:04:14 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:04:14 --> Helper loaded: email_helper
INFO - 2020-02-25 17:04:14 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:04:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:04:14 --> Parser Class Initialized
INFO - 2020-02-25 17:04:14 --> User Agent Class Initialized
INFO - 2020-02-25 17:04:14 --> Model Class Initialized
INFO - 2020-02-25 17:04:14 --> Database Driver Class Initialized
INFO - 2020-02-25 17:04:14 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:14 --> Template Class Initialized
INFO - 2020-02-25 17:04:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:04:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:04:14 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:04:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:04:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:04:14 --> Encryption Class Initialized
INFO - 2020-02-25 17:04:14 --> Controller Class Initialized
DEBUG - 2020-02-25 17:04:14 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:14 --> Model Class Initialized
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:04:14 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:14 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:04:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:04:15 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:04:15 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:15 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:15 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:04:15 --> Final output sent to browser
DEBUG - 2020-02-25 17:04:15 --> Total execution time: 1.3133
INFO - 2020-02-25 17:04:16 --> Config Class Initialized
INFO - 2020-02-25 17:04:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:04:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:04:16 --> Utf8 Class Initialized
INFO - 2020-02-25 17:04:16 --> URI Class Initialized
INFO - 2020-02-25 17:04:16 --> Router Class Initialized
INFO - 2020-02-25 17:04:16 --> Output Class Initialized
INFO - 2020-02-25 17:04:16 --> Security Class Initialized
DEBUG - 2020-02-25 17:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:04:16 --> CSRF cookie sent
INFO - 2020-02-25 17:04:16 --> Input Class Initialized
INFO - 2020-02-25 17:04:16 --> Language Class Initialized
INFO - 2020-02-25 17:04:16 --> Language Class Initialized
INFO - 2020-02-25 17:04:16 --> Config Class Initialized
INFO - 2020-02-25 17:04:16 --> Loader Class Initialized
INFO - 2020-02-25 17:04:16 --> Helper loaded: url_helper
INFO - 2020-02-25 17:04:16 --> Helper loaded: common_helper
INFO - 2020-02-25 17:04:16 --> Helper loaded: language_helper
INFO - 2020-02-25 17:04:16 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:04:16 --> Helper loaded: email_helper
INFO - 2020-02-25 17:04:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:04:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:04:16 --> Parser Class Initialized
INFO - 2020-02-25 17:04:16 --> User Agent Class Initialized
INFO - 2020-02-25 17:04:16 --> Model Class Initialized
INFO - 2020-02-25 17:04:16 --> Database Driver Class Initialized
INFO - 2020-02-25 17:04:16 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:16 --> Template Class Initialized
INFO - 2020-02-25 17:04:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:04:16 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:04:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:04:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:04:17 --> Encryption Class Initialized
INFO - 2020-02-25 17:04:17 --> Controller Class Initialized
DEBUG - 2020-02-25 17:04:17 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:17 --> Model Class Initialized
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:04:17 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:04:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:04:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:04:17 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:04:17 --> Model Class Initialized
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:04:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:04:17 --> Final output sent to browser
DEBUG - 2020-02-25 17:04:18 --> Total execution time: 1.6699
INFO - 2020-02-25 17:05:35 --> Config Class Initialized
INFO - 2020-02-25 17:05:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:05:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:05:35 --> Utf8 Class Initialized
INFO - 2020-02-25 17:05:35 --> URI Class Initialized
INFO - 2020-02-25 17:05:35 --> Router Class Initialized
INFO - 2020-02-25 17:05:35 --> Output Class Initialized
INFO - 2020-02-25 17:05:35 --> Security Class Initialized
DEBUG - 2020-02-25 17:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:05:35 --> CSRF cookie sent
INFO - 2020-02-25 17:05:35 --> Input Class Initialized
INFO - 2020-02-25 17:05:36 --> Language Class Initialized
INFO - 2020-02-25 17:05:36 --> Language Class Initialized
INFO - 2020-02-25 17:05:36 --> Config Class Initialized
INFO - 2020-02-25 17:05:36 --> Loader Class Initialized
INFO - 2020-02-25 17:05:36 --> Helper loaded: url_helper
INFO - 2020-02-25 17:05:36 --> Helper loaded: common_helper
INFO - 2020-02-25 17:05:36 --> Helper loaded: language_helper
INFO - 2020-02-25 17:05:36 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:05:36 --> Helper loaded: email_helper
INFO - 2020-02-25 17:05:36 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:05:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:05:36 --> Parser Class Initialized
INFO - 2020-02-25 17:05:36 --> User Agent Class Initialized
INFO - 2020-02-25 17:05:36 --> Model Class Initialized
INFO - 2020-02-25 17:05:36 --> Database Driver Class Initialized
INFO - 2020-02-25 17:05:36 --> Model Class Initialized
DEBUG - 2020-02-25 17:05:36 --> Template Class Initialized
INFO - 2020-02-25 17:05:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:05:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:05:36 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:05:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:05:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:05:36 --> Encryption Class Initialized
INFO - 2020-02-25 17:05:36 --> Controller Class Initialized
DEBUG - 2020-02-25 17:05:36 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:05:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:05:36 --> Model Class Initialized
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:05:36 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:05:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:05:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:05:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:05:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:05:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:05:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:05:36 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:05:37 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:05:37 --> Model Class Initialized
DEBUG - 2020-02-25 17:05:37 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:05:37 --> Model Class Initialized
DEBUG - 2020-02-25 17:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:05:37 --> Final output sent to browser
DEBUG - 2020-02-25 17:05:37 --> Total execution time: 1.4474
INFO - 2020-02-25 17:05:47 --> Config Class Initialized
INFO - 2020-02-25 17:05:47 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:05:47 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:05:47 --> Utf8 Class Initialized
INFO - 2020-02-25 17:05:47 --> URI Class Initialized
INFO - 2020-02-25 17:05:47 --> Router Class Initialized
INFO - 2020-02-25 17:05:47 --> Output Class Initialized
INFO - 2020-02-25 17:05:47 --> Security Class Initialized
DEBUG - 2020-02-25 17:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:05:47 --> CSRF cookie sent
INFO - 2020-02-25 17:05:47 --> Input Class Initialized
INFO - 2020-02-25 17:05:47 --> Language Class Initialized
INFO - 2020-02-25 17:05:47 --> Language Class Initialized
INFO - 2020-02-25 17:05:47 --> Config Class Initialized
INFO - 2020-02-25 17:05:47 --> Loader Class Initialized
INFO - 2020-02-25 17:05:47 --> Helper loaded: url_helper
INFO - 2020-02-25 17:05:47 --> Helper loaded: common_helper
INFO - 2020-02-25 17:05:47 --> Helper loaded: language_helper
INFO - 2020-02-25 17:05:47 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:05:47 --> Helper loaded: email_helper
INFO - 2020-02-25 17:05:47 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:05:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:05:47 --> Parser Class Initialized
INFO - 2020-02-25 17:05:47 --> User Agent Class Initialized
INFO - 2020-02-25 17:05:47 --> Model Class Initialized
INFO - 2020-02-25 17:05:47 --> Database Driver Class Initialized
INFO - 2020-02-25 17:05:47 --> Model Class Initialized
DEBUG - 2020-02-25 17:05:47 --> Template Class Initialized
INFO - 2020-02-25 17:05:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:05:48 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:05:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:05:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:05:48 --> Encryption Class Initialized
INFO - 2020-02-25 17:05:48 --> Controller Class Initialized
DEBUG - 2020-02-25 17:05:48 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:05:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:05:48 --> Model Class Initialized
ERROR - 2020-02-25 17:05:48 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:06:21 --> Config Class Initialized
INFO - 2020-02-25 17:06:21 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:06:21 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:06:21 --> Utf8 Class Initialized
INFO - 2020-02-25 17:06:21 --> URI Class Initialized
INFO - 2020-02-25 17:06:21 --> Router Class Initialized
INFO - 2020-02-25 17:06:21 --> Output Class Initialized
INFO - 2020-02-25 17:06:21 --> Security Class Initialized
DEBUG - 2020-02-25 17:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:06:21 --> CSRF cookie sent
INFO - 2020-02-25 17:06:21 --> Input Class Initialized
INFO - 2020-02-25 17:06:21 --> Language Class Initialized
INFO - 2020-02-25 17:06:21 --> Language Class Initialized
INFO - 2020-02-25 17:06:21 --> Config Class Initialized
INFO - 2020-02-25 17:06:21 --> Loader Class Initialized
INFO - 2020-02-25 17:06:21 --> Helper loaded: url_helper
INFO - 2020-02-25 17:06:21 --> Helper loaded: common_helper
INFO - 2020-02-25 17:06:21 --> Helper loaded: language_helper
INFO - 2020-02-25 17:06:21 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:06:21 --> Helper loaded: email_helper
INFO - 2020-02-25 17:06:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:06:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:06:21 --> Parser Class Initialized
INFO - 2020-02-25 17:06:21 --> User Agent Class Initialized
INFO - 2020-02-25 17:06:21 --> Model Class Initialized
INFO - 2020-02-25 17:06:21 --> Database Driver Class Initialized
INFO - 2020-02-25 17:06:21 --> Model Class Initialized
DEBUG - 2020-02-25 17:06:21 --> Template Class Initialized
INFO - 2020-02-25 17:06:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:06:21 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:06:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:06:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:06:21 --> Encryption Class Initialized
INFO - 2020-02-25 17:06:21 --> Controller Class Initialized
DEBUG - 2020-02-25 17:06:21 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:06:22 --> Model Class Initialized
ERROR - 2020-02-25 17:06:22 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:06:37 --> Config Class Initialized
INFO - 2020-02-25 17:06:37 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:06:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:06:37 --> Utf8 Class Initialized
INFO - 2020-02-25 17:06:37 --> URI Class Initialized
INFO - 2020-02-25 17:06:37 --> Router Class Initialized
INFO - 2020-02-25 17:06:37 --> Output Class Initialized
INFO - 2020-02-25 17:06:37 --> Security Class Initialized
DEBUG - 2020-02-25 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:06:37 --> CSRF cookie sent
INFO - 2020-02-25 17:06:37 --> Input Class Initialized
INFO - 2020-02-25 17:06:37 --> Language Class Initialized
INFO - 2020-02-25 17:06:37 --> Language Class Initialized
INFO - 2020-02-25 17:06:37 --> Config Class Initialized
INFO - 2020-02-25 17:06:37 --> Loader Class Initialized
INFO - 2020-02-25 17:06:37 --> Helper loaded: url_helper
INFO - 2020-02-25 17:06:37 --> Helper loaded: common_helper
INFO - 2020-02-25 17:06:37 --> Helper loaded: language_helper
INFO - 2020-02-25 17:06:37 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:06:37 --> Helper loaded: email_helper
INFO - 2020-02-25 17:06:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:06:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:06:37 --> Parser Class Initialized
INFO - 2020-02-25 17:06:37 --> User Agent Class Initialized
INFO - 2020-02-25 17:06:37 --> Model Class Initialized
INFO - 2020-02-25 17:06:37 --> Database Driver Class Initialized
INFO - 2020-02-25 17:06:37 --> Model Class Initialized
DEBUG - 2020-02-25 17:06:37 --> Template Class Initialized
INFO - 2020-02-25 17:06:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:06:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:06:37 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:06:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:06:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:06:37 --> Encryption Class Initialized
INFO - 2020-02-25 17:06:38 --> Controller Class Initialized
DEBUG - 2020-02-25 17:06:38 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:06:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:06:38 --> Model Class Initialized
ERROR - 2020-02-25 17:06:38 --> Could not find the language line "Sorting"
ERROR - 2020-02-25 17:06:38 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\controllers\category.php 59
INFO - 2020-02-25 17:07:09 --> Config Class Initialized
INFO - 2020-02-25 17:07:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:09 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:09 --> URI Class Initialized
INFO - 2020-02-25 17:07:09 --> Router Class Initialized
INFO - 2020-02-25 17:07:09 --> Output Class Initialized
INFO - 2020-02-25 17:07:09 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:09 --> CSRF cookie sent
INFO - 2020-02-25 17:07:09 --> Input Class Initialized
INFO - 2020-02-25 17:07:09 --> Language Class Initialized
INFO - 2020-02-25 17:07:09 --> Language Class Initialized
INFO - 2020-02-25 17:07:09 --> Config Class Initialized
INFO - 2020-02-25 17:07:09 --> Loader Class Initialized
INFO - 2020-02-25 17:07:09 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:09 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:09 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:09 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:09 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:09 --> Parser Class Initialized
INFO - 2020-02-25 17:07:09 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:09 --> Model Class Initialized
INFO - 2020-02-25 17:07:09 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:09 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:09 --> Template Class Initialized
INFO - 2020-02-25 17:07:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:10 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:10 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:10 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:10 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:10 --> Model Class Initialized
ERROR - 2020-02-25 17:07:10 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:22 --> Config Class Initialized
INFO - 2020-02-25 17:07:22 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:22 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:22 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:22 --> URI Class Initialized
INFO - 2020-02-25 17:07:22 --> Router Class Initialized
INFO - 2020-02-25 17:07:22 --> Output Class Initialized
INFO - 2020-02-25 17:07:22 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:22 --> CSRF cookie sent
INFO - 2020-02-25 17:07:22 --> Input Class Initialized
INFO - 2020-02-25 17:07:22 --> Language Class Initialized
INFO - 2020-02-25 17:07:22 --> Language Class Initialized
INFO - 2020-02-25 17:07:22 --> Config Class Initialized
INFO - 2020-02-25 17:07:22 --> Loader Class Initialized
INFO - 2020-02-25 17:07:22 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:22 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:22 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:22 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:22 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:22 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:22 --> Parser Class Initialized
INFO - 2020-02-25 17:07:22 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:22 --> Model Class Initialized
INFO - 2020-02-25 17:07:22 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:22 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:22 --> Template Class Initialized
INFO - 2020-02-25 17:07:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:22 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:22 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:22 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:22 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:22 --> Model Class Initialized
ERROR - 2020-02-25 17:07:22 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:22 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:07:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:07:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:07:23 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:07:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:07:23 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:23 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:23 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:07:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:07:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:07:23 --> Final output sent to browser
DEBUG - 2020-02-25 17:07:23 --> Total execution time: 0.9626
INFO - 2020-02-25 17:07:25 --> Config Class Initialized
INFO - 2020-02-25 17:07:25 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:25 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:25 --> URI Class Initialized
INFO - 2020-02-25 17:07:25 --> Router Class Initialized
INFO - 2020-02-25 17:07:25 --> Output Class Initialized
INFO - 2020-02-25 17:07:25 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:25 --> CSRF cookie sent
INFO - 2020-02-25 17:07:25 --> Input Class Initialized
INFO - 2020-02-25 17:07:25 --> Language Class Initialized
INFO - 2020-02-25 17:07:25 --> Language Class Initialized
INFO - 2020-02-25 17:07:25 --> Config Class Initialized
INFO - 2020-02-25 17:07:25 --> Loader Class Initialized
INFO - 2020-02-25 17:07:25 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:25 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:25 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:25 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:25 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:25 --> Parser Class Initialized
INFO - 2020-02-25 17:07:25 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:25 --> Model Class Initialized
INFO - 2020-02-25 17:07:25 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:25 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:25 --> Template Class Initialized
INFO - 2020-02-25 17:07:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:25 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:25 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:25 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:25 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:25 --> Model Class Initialized
ERROR - 2020-02-25 17:07:25 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:25 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:07:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:07:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:07:25 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:07:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:07:25 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:25 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:25 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:07:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:07:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:07:25 --> Final output sent to browser
DEBUG - 2020-02-25 17:07:25 --> Total execution time: 0.9208
INFO - 2020-02-25 17:07:27 --> Config Class Initialized
INFO - 2020-02-25 17:07:27 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:27 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:27 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:27 --> URI Class Initialized
INFO - 2020-02-25 17:07:27 --> Router Class Initialized
INFO - 2020-02-25 17:07:27 --> Output Class Initialized
INFO - 2020-02-25 17:07:27 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:27 --> CSRF cookie sent
INFO - 2020-02-25 17:07:27 --> Input Class Initialized
INFO - 2020-02-25 17:07:27 --> Language Class Initialized
INFO - 2020-02-25 17:07:27 --> Language Class Initialized
INFO - 2020-02-25 17:07:27 --> Config Class Initialized
INFO - 2020-02-25 17:07:27 --> Loader Class Initialized
INFO - 2020-02-25 17:07:27 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:27 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:27 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:27 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:27 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:27 --> Parser Class Initialized
INFO - 2020-02-25 17:07:27 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:27 --> Model Class Initialized
INFO - 2020-02-25 17:07:27 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:27 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:27 --> Template Class Initialized
INFO - 2020-02-25 17:07:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:27 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:27 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:27 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:27 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:27 --> Model Class Initialized
ERROR - 2020-02-25 17:07:27 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:27 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:07:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:07:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:07:27 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:07:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:07:27 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:27 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:27 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:07:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:07:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:07:27 --> Final output sent to browser
DEBUG - 2020-02-25 17:07:27 --> Total execution time: 0.8927
INFO - 2020-02-25 17:07:28 --> Config Class Initialized
INFO - 2020-02-25 17:07:28 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:28 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:28 --> URI Class Initialized
INFO - 2020-02-25 17:07:28 --> Router Class Initialized
INFO - 2020-02-25 17:07:28 --> Output Class Initialized
INFO - 2020-02-25 17:07:29 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:29 --> CSRF cookie sent
INFO - 2020-02-25 17:07:29 --> Input Class Initialized
INFO - 2020-02-25 17:07:29 --> Language Class Initialized
INFO - 2020-02-25 17:07:29 --> Language Class Initialized
INFO - 2020-02-25 17:07:29 --> Config Class Initialized
INFO - 2020-02-25 17:07:29 --> Loader Class Initialized
INFO - 2020-02-25 17:07:29 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:29 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:29 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:29 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:29 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:29 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:29 --> Parser Class Initialized
INFO - 2020-02-25 17:07:29 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:29 --> Model Class Initialized
INFO - 2020-02-25 17:07:29 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:29 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:29 --> Template Class Initialized
INFO - 2020-02-25 17:07:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:29 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:29 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:29 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:29 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:29 --> Model Class Initialized
ERROR - 2020-02-25 17:07:29 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:29 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:07:29 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:07:29 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:29 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:29 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:07:29 --> Final output sent to browser
DEBUG - 2020-02-25 17:07:29 --> Total execution time: 0.8713
INFO - 2020-02-25 17:07:30 --> Config Class Initialized
INFO - 2020-02-25 17:07:30 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:30 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:30 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:30 --> URI Class Initialized
INFO - 2020-02-25 17:07:30 --> Router Class Initialized
INFO - 2020-02-25 17:07:30 --> Output Class Initialized
INFO - 2020-02-25 17:07:30 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:30 --> CSRF cookie sent
INFO - 2020-02-25 17:07:30 --> Input Class Initialized
INFO - 2020-02-25 17:07:30 --> Language Class Initialized
INFO - 2020-02-25 17:07:30 --> Language Class Initialized
INFO - 2020-02-25 17:07:30 --> Config Class Initialized
INFO - 2020-02-25 17:07:30 --> Loader Class Initialized
INFO - 2020-02-25 17:07:30 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:30 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:30 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:30 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:30 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:30 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:31 --> Parser Class Initialized
INFO - 2020-02-25 17:07:31 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:31 --> Model Class Initialized
INFO - 2020-02-25 17:07:31 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:31 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:31 --> Template Class Initialized
INFO - 2020-02-25 17:07:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:31 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:31 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:31 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:31 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:31 --> Model Class Initialized
ERROR - 2020-02-25 17:07:31 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:31 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:07:31 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:07:31 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:31 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:31 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:07:31 --> Final output sent to browser
DEBUG - 2020-02-25 17:07:31 --> Total execution time: 0.8843
INFO - 2020-02-25 17:07:32 --> Config Class Initialized
INFO - 2020-02-25 17:07:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:32 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:32 --> URI Class Initialized
INFO - 2020-02-25 17:07:33 --> Router Class Initialized
INFO - 2020-02-25 17:07:33 --> Output Class Initialized
INFO - 2020-02-25 17:07:33 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:33 --> CSRF cookie sent
INFO - 2020-02-25 17:07:33 --> Input Class Initialized
INFO - 2020-02-25 17:07:33 --> Language Class Initialized
INFO - 2020-02-25 17:07:33 --> Language Class Initialized
INFO - 2020-02-25 17:07:33 --> Config Class Initialized
INFO - 2020-02-25 17:07:33 --> Loader Class Initialized
INFO - 2020-02-25 17:07:33 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:33 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:33 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:33 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:33 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:33 --> Parser Class Initialized
INFO - 2020-02-25 17:07:33 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:33 --> Model Class Initialized
INFO - 2020-02-25 17:07:33 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:33 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:33 --> Template Class Initialized
INFO - 2020-02-25 17:07:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:33 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:33 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:33 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:33 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:33 --> Model Class Initialized
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:33 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:07:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:07:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:07:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
ERROR - 2020-02-25 17:07:33 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:07:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:07:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:07:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:07:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:07:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:07:34 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:07:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:07:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:07:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:07:34 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:07:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:07:34 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:34 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:34 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:07:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:07:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:07:34 --> Final output sent to browser
DEBUG - 2020-02-25 17:07:34 --> Total execution time: 1.4221
INFO - 2020-02-25 17:07:38 --> Config Class Initialized
INFO - 2020-02-25 17:07:38 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:38 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:38 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:38 --> URI Class Initialized
INFO - 2020-02-25 17:07:38 --> Router Class Initialized
INFO - 2020-02-25 17:07:38 --> Output Class Initialized
INFO - 2020-02-25 17:07:38 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:38 --> CSRF cookie sent
INFO - 2020-02-25 17:07:38 --> Input Class Initialized
INFO - 2020-02-25 17:07:38 --> Language Class Initialized
INFO - 2020-02-25 17:07:38 --> Language Class Initialized
INFO - 2020-02-25 17:07:38 --> Config Class Initialized
INFO - 2020-02-25 17:07:38 --> Loader Class Initialized
INFO - 2020-02-25 17:07:38 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:38 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:38 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:38 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:38 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:38 --> Parser Class Initialized
INFO - 2020-02-25 17:07:38 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:38 --> Model Class Initialized
INFO - 2020-02-25 17:07:38 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:38 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:38 --> Template Class Initialized
INFO - 2020-02-25 17:07:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:39 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:39 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:39 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:39 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:39 --> Model Class Initialized
ERROR - 2020-02-25 17:07:39 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:39 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:07:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:07:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:07:39 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:07:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:07:39 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:39 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:39 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:07:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:07:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:07:39 --> Final output sent to browser
DEBUG - 2020-02-25 17:07:39 --> Total execution time: 0.9075
INFO - 2020-02-25 17:07:44 --> Config Class Initialized
INFO - 2020-02-25 17:07:44 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:44 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:44 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:44 --> URI Class Initialized
INFO - 2020-02-25 17:07:44 --> Router Class Initialized
INFO - 2020-02-25 17:07:44 --> Output Class Initialized
INFO - 2020-02-25 17:07:45 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:45 --> CSRF cookie sent
INFO - 2020-02-25 17:07:45 --> CSRF token verified
INFO - 2020-02-25 17:07:45 --> Input Class Initialized
INFO - 2020-02-25 17:07:45 --> Language Class Initialized
INFO - 2020-02-25 17:07:45 --> Language Class Initialized
INFO - 2020-02-25 17:07:45 --> Config Class Initialized
INFO - 2020-02-25 17:07:45 --> Loader Class Initialized
INFO - 2020-02-25 17:07:45 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:45 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:45 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:45 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:45 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:45 --> Parser Class Initialized
INFO - 2020-02-25 17:07:45 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:45 --> Model Class Initialized
INFO - 2020-02-25 17:07:45 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:45 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:45 --> Template Class Initialized
INFO - 2020-02-25 17:07:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:45 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:45 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:45 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:45 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:45 --> Model Class Initialized
ERROR - 2020-02-25 17:07:45 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:50 --> Config Class Initialized
INFO - 2020-02-25 17:07:50 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:07:50 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:07:50 --> Utf8 Class Initialized
INFO - 2020-02-25 17:07:50 --> URI Class Initialized
INFO - 2020-02-25 17:07:50 --> Router Class Initialized
INFO - 2020-02-25 17:07:50 --> Output Class Initialized
INFO - 2020-02-25 17:07:50 --> Security Class Initialized
DEBUG - 2020-02-25 17:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:07:50 --> CSRF cookie sent
INFO - 2020-02-25 17:07:51 --> Input Class Initialized
INFO - 2020-02-25 17:07:51 --> Language Class Initialized
INFO - 2020-02-25 17:07:51 --> Language Class Initialized
INFO - 2020-02-25 17:07:51 --> Config Class Initialized
INFO - 2020-02-25 17:07:51 --> Loader Class Initialized
INFO - 2020-02-25 17:07:51 --> Helper loaded: url_helper
INFO - 2020-02-25 17:07:51 --> Helper loaded: common_helper
INFO - 2020-02-25 17:07:51 --> Helper loaded: language_helper
INFO - 2020-02-25 17:07:51 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:07:51 --> Helper loaded: email_helper
INFO - 2020-02-25 17:07:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:07:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:07:51 --> Parser Class Initialized
INFO - 2020-02-25 17:07:51 --> User Agent Class Initialized
INFO - 2020-02-25 17:07:51 --> Model Class Initialized
INFO - 2020-02-25 17:07:51 --> Database Driver Class Initialized
INFO - 2020-02-25 17:07:51 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:51 --> Template Class Initialized
INFO - 2020-02-25 17:07:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:07:51 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:07:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:07:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:07:51 --> Encryption Class Initialized
INFO - 2020-02-25 17:07:51 --> Controller Class Initialized
DEBUG - 2020-02-25 17:07:51 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:51 --> Model Class Initialized
ERROR - 2020-02-25 17:07:51 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:07:51 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:07:51 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:07:51 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:51 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:07:51 --> Model Class Initialized
DEBUG - 2020-02-25 17:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:07:51 --> Final output sent to browser
DEBUG - 2020-02-25 17:07:51 --> Total execution time: 0.9645
INFO - 2020-02-25 17:08:03 --> Config Class Initialized
INFO - 2020-02-25 17:08:03 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:08:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:08:03 --> Utf8 Class Initialized
INFO - 2020-02-25 17:08:03 --> URI Class Initialized
INFO - 2020-02-25 17:08:03 --> Router Class Initialized
INFO - 2020-02-25 17:08:03 --> Output Class Initialized
INFO - 2020-02-25 17:08:03 --> Security Class Initialized
DEBUG - 2020-02-25 17:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:08:03 --> CSRF cookie sent
INFO - 2020-02-25 17:08:03 --> Input Class Initialized
INFO - 2020-02-25 17:08:03 --> Language Class Initialized
INFO - 2020-02-25 17:08:03 --> Language Class Initialized
INFO - 2020-02-25 17:08:03 --> Config Class Initialized
INFO - 2020-02-25 17:08:03 --> Loader Class Initialized
INFO - 2020-02-25 17:08:03 --> Helper loaded: url_helper
INFO - 2020-02-25 17:08:03 --> Helper loaded: common_helper
INFO - 2020-02-25 17:08:03 --> Helper loaded: language_helper
INFO - 2020-02-25 17:08:03 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:08:03 --> Helper loaded: email_helper
INFO - 2020-02-25 17:08:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:08:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:08:03 --> Parser Class Initialized
INFO - 2020-02-25 17:08:03 --> User Agent Class Initialized
INFO - 2020-02-25 17:08:03 --> Model Class Initialized
INFO - 2020-02-25 17:08:03 --> Database Driver Class Initialized
INFO - 2020-02-25 17:08:03 --> Model Class Initialized
DEBUG - 2020-02-25 17:08:03 --> Template Class Initialized
INFO - 2020-02-25 17:08:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:08:03 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:08:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:08:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:08:03 --> Encryption Class Initialized
INFO - 2020-02-25 17:08:03 --> Controller Class Initialized
DEBUG - 2020-02-25 17:08:03 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:08:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:08:03 --> Model Class Initialized
ERROR - 2020-02-25 17:08:03 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:08:03 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:08:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:08:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:08:03 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:08:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:08:03 --> Model Class Initialized
DEBUG - 2020-02-25 17:08:03 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:08:03 --> Model Class Initialized
DEBUG - 2020-02-25 17:08:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:08:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:08:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:08:04 --> Final output sent to browser
DEBUG - 2020-02-25 17:08:04 --> Total execution time: 0.9558
INFO - 2020-02-25 17:10:19 --> Config Class Initialized
INFO - 2020-02-25 17:10:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:10:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:10:19 --> Utf8 Class Initialized
INFO - 2020-02-25 17:10:19 --> URI Class Initialized
INFO - 2020-02-25 17:10:19 --> Router Class Initialized
INFO - 2020-02-25 17:10:19 --> Output Class Initialized
INFO - 2020-02-25 17:10:19 --> Security Class Initialized
DEBUG - 2020-02-25 17:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:10:19 --> CSRF cookie sent
INFO - 2020-02-25 17:10:19 --> Input Class Initialized
INFO - 2020-02-25 17:10:19 --> Language Class Initialized
INFO - 2020-02-25 17:10:19 --> Language Class Initialized
INFO - 2020-02-25 17:10:19 --> Config Class Initialized
INFO - 2020-02-25 17:10:19 --> Loader Class Initialized
INFO - 2020-02-25 17:10:19 --> Helper loaded: url_helper
INFO - 2020-02-25 17:10:19 --> Helper loaded: common_helper
INFO - 2020-02-25 17:10:19 --> Helper loaded: language_helper
INFO - 2020-02-25 17:10:19 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:10:19 --> Helper loaded: email_helper
INFO - 2020-02-25 17:10:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:10:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:10:20 --> Parser Class Initialized
INFO - 2020-02-25 17:10:20 --> User Agent Class Initialized
INFO - 2020-02-25 17:10:20 --> Model Class Initialized
INFO - 2020-02-25 17:10:20 --> Database Driver Class Initialized
INFO - 2020-02-25 17:10:20 --> Model Class Initialized
DEBUG - 2020-02-25 17:10:20 --> Template Class Initialized
INFO - 2020-02-25 17:10:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:10:20 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:10:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:10:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:10:20 --> Encryption Class Initialized
INFO - 2020-02-25 17:10:20 --> Controller Class Initialized
DEBUG - 2020-02-25 17:10:20 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:10:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:10:20 --> Model Class Initialized
ERROR - 2020-02-25 17:10:20 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:10:20 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:10:20 --> Severity: Notice --> Undefined variable: languages D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
INFO - 2020-02-25 17:10:29 --> Config Class Initialized
INFO - 2020-02-25 17:10:29 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:10:29 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:10:29 --> Utf8 Class Initialized
INFO - 2020-02-25 17:10:29 --> URI Class Initialized
INFO - 2020-02-25 17:10:29 --> Router Class Initialized
INFO - 2020-02-25 17:10:29 --> Output Class Initialized
INFO - 2020-02-25 17:10:29 --> Security Class Initialized
DEBUG - 2020-02-25 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:10:29 --> CSRF cookie sent
INFO - 2020-02-25 17:10:29 --> Input Class Initialized
INFO - 2020-02-25 17:10:29 --> Language Class Initialized
INFO - 2020-02-25 17:10:29 --> Language Class Initialized
INFO - 2020-02-25 17:10:29 --> Config Class Initialized
INFO - 2020-02-25 17:10:29 --> Loader Class Initialized
INFO - 2020-02-25 17:10:29 --> Helper loaded: url_helper
INFO - 2020-02-25 17:10:29 --> Helper loaded: common_helper
INFO - 2020-02-25 17:10:29 --> Helper loaded: language_helper
INFO - 2020-02-25 17:10:29 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:10:29 --> Helper loaded: email_helper
INFO - 2020-02-25 17:10:29 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:10:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:10:29 --> Parser Class Initialized
INFO - 2020-02-25 17:10:29 --> User Agent Class Initialized
INFO - 2020-02-25 17:10:29 --> Model Class Initialized
INFO - 2020-02-25 17:10:29 --> Database Driver Class Initialized
INFO - 2020-02-25 17:10:29 --> Model Class Initialized
DEBUG - 2020-02-25 17:10:29 --> Template Class Initialized
INFO - 2020-02-25 17:10:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:10:29 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:10:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:10:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:10:29 --> Encryption Class Initialized
INFO - 2020-02-25 17:10:29 --> Controller Class Initialized
DEBUG - 2020-02-25 17:10:29 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:10:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:10:29 --> Model Class Initialized
ERROR - 2020-02-25 17:10:29 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:10:29 --> Helper loaded: inflector_helper
INFO - 2020-02-25 17:10:40 --> Config Class Initialized
INFO - 2020-02-25 17:10:40 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:10:40 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:10:40 --> Utf8 Class Initialized
INFO - 2020-02-25 17:10:40 --> URI Class Initialized
INFO - 2020-02-25 17:10:40 --> Router Class Initialized
INFO - 2020-02-25 17:10:40 --> Output Class Initialized
INFO - 2020-02-25 17:10:40 --> Security Class Initialized
DEBUG - 2020-02-25 17:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:10:40 --> CSRF cookie sent
INFO - 2020-02-25 17:10:40 --> Input Class Initialized
INFO - 2020-02-25 17:10:40 --> Language Class Initialized
INFO - 2020-02-25 17:10:40 --> Language Class Initialized
INFO - 2020-02-25 17:10:40 --> Config Class Initialized
INFO - 2020-02-25 17:10:40 --> Loader Class Initialized
INFO - 2020-02-25 17:10:40 --> Helper loaded: url_helper
INFO - 2020-02-25 17:10:40 --> Helper loaded: common_helper
INFO - 2020-02-25 17:10:40 --> Helper loaded: language_helper
INFO - 2020-02-25 17:10:40 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:10:40 --> Helper loaded: email_helper
INFO - 2020-02-25 17:10:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:10:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:10:40 --> Parser Class Initialized
INFO - 2020-02-25 17:10:40 --> User Agent Class Initialized
INFO - 2020-02-25 17:10:40 --> Model Class Initialized
INFO - 2020-02-25 17:10:40 --> Database Driver Class Initialized
INFO - 2020-02-25 17:10:40 --> Model Class Initialized
DEBUG - 2020-02-25 17:10:40 --> Template Class Initialized
INFO - 2020-02-25 17:10:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:10:40 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:10:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:10:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:10:40 --> Encryption Class Initialized
INFO - 2020-02-25 17:10:40 --> Controller Class Initialized
DEBUG - 2020-02-25 17:10:40 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:10:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:10:40 --> Model Class Initialized
ERROR - 2020-02-25 17:10:40 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:10:40 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:10:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:10:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:10:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:10:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:10:40 --> Model Class Initialized
DEBUG - 2020-02-25 17:10:40 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:10:40 --> Model Class Initialized
DEBUG - 2020-02-25 17:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:10:41 --> Final output sent to browser
DEBUG - 2020-02-25 17:10:41 --> Total execution time: 1.0061
INFO - 2020-02-25 17:10:51 --> Config Class Initialized
INFO - 2020-02-25 17:10:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:10:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:10:51 --> Utf8 Class Initialized
INFO - 2020-02-25 17:10:51 --> URI Class Initialized
INFO - 2020-02-25 17:10:51 --> Router Class Initialized
INFO - 2020-02-25 17:10:51 --> Output Class Initialized
INFO - 2020-02-25 17:10:51 --> Security Class Initialized
DEBUG - 2020-02-25 17:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:10:51 --> CSRF cookie sent
INFO - 2020-02-25 17:10:51 --> CSRF token verified
INFO - 2020-02-25 17:10:51 --> Input Class Initialized
INFO - 2020-02-25 17:10:51 --> Language Class Initialized
INFO - 2020-02-25 17:10:51 --> Language Class Initialized
INFO - 2020-02-25 17:10:51 --> Config Class Initialized
INFO - 2020-02-25 17:10:51 --> Loader Class Initialized
INFO - 2020-02-25 17:10:51 --> Helper loaded: url_helper
INFO - 2020-02-25 17:10:51 --> Helper loaded: common_helper
INFO - 2020-02-25 17:10:51 --> Helper loaded: language_helper
INFO - 2020-02-25 17:10:51 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:10:51 --> Helper loaded: email_helper
INFO - 2020-02-25 17:10:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:10:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:10:51 --> Parser Class Initialized
INFO - 2020-02-25 17:10:51 --> User Agent Class Initialized
INFO - 2020-02-25 17:10:51 --> Model Class Initialized
INFO - 2020-02-25 17:10:51 --> Database Driver Class Initialized
INFO - 2020-02-25 17:10:51 --> Model Class Initialized
DEBUG - 2020-02-25 17:10:51 --> Template Class Initialized
INFO - 2020-02-25 17:10:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:10:51 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:10:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:10:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:10:51 --> Encryption Class Initialized
INFO - 2020-02-25 17:10:51 --> Controller Class Initialized
DEBUG - 2020-02-25 17:10:51 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:10:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:10:51 --> Model Class Initialized
ERROR - 2020-02-25 17:10:51 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:10:56 --> Config Class Initialized
INFO - 2020-02-25 17:10:56 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:10:56 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:10:56 --> Utf8 Class Initialized
INFO - 2020-02-25 17:10:56 --> URI Class Initialized
INFO - 2020-02-25 17:10:56 --> Router Class Initialized
INFO - 2020-02-25 17:10:56 --> Output Class Initialized
INFO - 2020-02-25 17:10:56 --> Security Class Initialized
DEBUG - 2020-02-25 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:10:56 --> CSRF cookie sent
INFO - 2020-02-25 17:10:56 --> Input Class Initialized
INFO - 2020-02-25 17:10:56 --> Language Class Initialized
INFO - 2020-02-25 17:10:56 --> Language Class Initialized
INFO - 2020-02-25 17:10:56 --> Config Class Initialized
INFO - 2020-02-25 17:10:56 --> Loader Class Initialized
INFO - 2020-02-25 17:10:56 --> Helper loaded: url_helper
INFO - 2020-02-25 17:10:56 --> Helper loaded: common_helper
INFO - 2020-02-25 17:10:56 --> Helper loaded: language_helper
INFO - 2020-02-25 17:10:56 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:10:56 --> Helper loaded: email_helper
INFO - 2020-02-25 17:10:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:10:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:10:56 --> Parser Class Initialized
INFO - 2020-02-25 17:10:56 --> User Agent Class Initialized
INFO - 2020-02-25 17:10:56 --> Model Class Initialized
INFO - 2020-02-25 17:10:56 --> Database Driver Class Initialized
INFO - 2020-02-25 17:10:57 --> Model Class Initialized
DEBUG - 2020-02-25 17:10:57 --> Template Class Initialized
INFO - 2020-02-25 17:10:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:10:57 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:10:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:10:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:10:57 --> Encryption Class Initialized
INFO - 2020-02-25 17:10:57 --> Controller Class Initialized
DEBUG - 2020-02-25 17:10:57 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:10:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:10:57 --> Model Class Initialized
ERROR - 2020-02-25 17:10:57 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:10:57 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:10:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:10:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:10:57 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:10:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:10:57 --> Model Class Initialized
DEBUG - 2020-02-25 17:10:57 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:10:57 --> Model Class Initialized
DEBUG - 2020-02-25 17:10:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:10:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:10:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:10:57 --> Final output sent to browser
DEBUG - 2020-02-25 17:10:57 --> Total execution time: 1.0039
INFO - 2020-02-25 17:11:03 --> Config Class Initialized
INFO - 2020-02-25 17:11:03 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:11:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:11:03 --> Utf8 Class Initialized
INFO - 2020-02-25 17:11:03 --> URI Class Initialized
INFO - 2020-02-25 17:11:03 --> Router Class Initialized
INFO - 2020-02-25 17:11:03 --> Output Class Initialized
INFO - 2020-02-25 17:11:03 --> Security Class Initialized
DEBUG - 2020-02-25 17:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:11:03 --> CSRF cookie sent
INFO - 2020-02-25 17:11:03 --> Input Class Initialized
INFO - 2020-02-25 17:11:03 --> Language Class Initialized
INFO - 2020-02-25 17:11:03 --> Language Class Initialized
INFO - 2020-02-25 17:11:03 --> Config Class Initialized
INFO - 2020-02-25 17:11:03 --> Loader Class Initialized
INFO - 2020-02-25 17:11:03 --> Helper loaded: url_helper
INFO - 2020-02-25 17:11:03 --> Helper loaded: common_helper
INFO - 2020-02-25 17:11:03 --> Helper loaded: language_helper
INFO - 2020-02-25 17:11:03 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:11:03 --> Helper loaded: email_helper
INFO - 2020-02-25 17:11:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:11:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:11:03 --> Parser Class Initialized
INFO - 2020-02-25 17:11:03 --> User Agent Class Initialized
INFO - 2020-02-25 17:11:03 --> Model Class Initialized
INFO - 2020-02-25 17:11:03 --> Database Driver Class Initialized
INFO - 2020-02-25 17:11:03 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:03 --> Template Class Initialized
INFO - 2020-02-25 17:11:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:11:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:11:03 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:11:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:11:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:11:03 --> Encryption Class Initialized
INFO - 2020-02-25 17:11:03 --> Controller Class Initialized
DEBUG - 2020-02-25 17:11:03 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:11:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:03 --> Model Class Initialized
ERROR - 2020-02-25 17:11:03 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:11:03 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:11:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:11:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:11:03 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:11:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:11:03 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:03 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:03 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:11:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:11:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:11:04 --> Final output sent to browser
DEBUG - 2020-02-25 17:11:04 --> Total execution time: 0.9108
INFO - 2020-02-25 17:11:05 --> Config Class Initialized
INFO - 2020-02-25 17:11:05 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:11:05 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:11:05 --> Utf8 Class Initialized
INFO - 2020-02-25 17:11:05 --> URI Class Initialized
INFO - 2020-02-25 17:11:05 --> Router Class Initialized
INFO - 2020-02-25 17:11:05 --> Output Class Initialized
INFO - 2020-02-25 17:11:05 --> Security Class Initialized
DEBUG - 2020-02-25 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:11:05 --> CSRF cookie sent
INFO - 2020-02-25 17:11:05 --> Input Class Initialized
INFO - 2020-02-25 17:11:05 --> Language Class Initialized
INFO - 2020-02-25 17:11:05 --> Language Class Initialized
INFO - 2020-02-25 17:11:05 --> Config Class Initialized
INFO - 2020-02-25 17:11:05 --> Loader Class Initialized
INFO - 2020-02-25 17:11:05 --> Helper loaded: url_helper
INFO - 2020-02-25 17:11:05 --> Helper loaded: common_helper
INFO - 2020-02-25 17:11:05 --> Helper loaded: language_helper
INFO - 2020-02-25 17:11:05 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:11:05 --> Helper loaded: email_helper
INFO - 2020-02-25 17:11:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:11:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:11:05 --> Parser Class Initialized
INFO - 2020-02-25 17:11:05 --> User Agent Class Initialized
INFO - 2020-02-25 17:11:05 --> Model Class Initialized
INFO - 2020-02-25 17:11:05 --> Database Driver Class Initialized
INFO - 2020-02-25 17:11:05 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:05 --> Template Class Initialized
INFO - 2020-02-25 17:11:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:11:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:11:05 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:11:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:11:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:11:05 --> Encryption Class Initialized
INFO - 2020-02-25 17:11:05 --> Controller Class Initialized
DEBUG - 2020-02-25 17:11:05 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:11:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:05 --> Model Class Initialized
ERROR - 2020-02-25 17:11:05 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:11:05 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:11:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:11:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:11:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:11:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:11:05 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:06 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:11:06 --> Final output sent to browser
DEBUG - 2020-02-25 17:11:06 --> Total execution time: 0.9387
INFO - 2020-02-25 17:11:07 --> Config Class Initialized
INFO - 2020-02-25 17:11:07 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:11:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:11:07 --> Utf8 Class Initialized
INFO - 2020-02-25 17:11:07 --> URI Class Initialized
INFO - 2020-02-25 17:11:07 --> Router Class Initialized
INFO - 2020-02-25 17:11:07 --> Output Class Initialized
INFO - 2020-02-25 17:11:07 --> Security Class Initialized
DEBUG - 2020-02-25 17:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:11:07 --> CSRF cookie sent
INFO - 2020-02-25 17:11:07 --> Input Class Initialized
INFO - 2020-02-25 17:11:07 --> Language Class Initialized
INFO - 2020-02-25 17:11:07 --> Language Class Initialized
INFO - 2020-02-25 17:11:07 --> Config Class Initialized
INFO - 2020-02-25 17:11:07 --> Loader Class Initialized
INFO - 2020-02-25 17:11:07 --> Helper loaded: url_helper
INFO - 2020-02-25 17:11:07 --> Helper loaded: common_helper
INFO - 2020-02-25 17:11:07 --> Helper loaded: language_helper
INFO - 2020-02-25 17:11:07 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:11:07 --> Helper loaded: email_helper
INFO - 2020-02-25 17:11:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:11:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:11:07 --> Parser Class Initialized
INFO - 2020-02-25 17:11:07 --> User Agent Class Initialized
INFO - 2020-02-25 17:11:07 --> Model Class Initialized
INFO - 2020-02-25 17:11:07 --> Database Driver Class Initialized
INFO - 2020-02-25 17:11:07 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:07 --> Template Class Initialized
INFO - 2020-02-25 17:11:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:11:07 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:11:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:11:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:11:07 --> Encryption Class Initialized
INFO - 2020-02-25 17:11:07 --> Controller Class Initialized
DEBUG - 2020-02-25 17:11:07 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:11:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:07 --> Model Class Initialized
ERROR - 2020-02-25 17:11:07 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:11:07 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:11:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:11:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:11:08 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:11:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:11:08 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:08 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:08 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:11:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:11:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:11:08 --> Final output sent to browser
DEBUG - 2020-02-25 17:11:08 --> Total execution time: 0.9888
INFO - 2020-02-25 17:11:09 --> Config Class Initialized
INFO - 2020-02-25 17:11:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:11:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:11:09 --> Utf8 Class Initialized
INFO - 2020-02-25 17:11:09 --> URI Class Initialized
INFO - 2020-02-25 17:11:09 --> Router Class Initialized
INFO - 2020-02-25 17:11:09 --> Output Class Initialized
INFO - 2020-02-25 17:11:09 --> Security Class Initialized
DEBUG - 2020-02-25 17:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:11:09 --> CSRF cookie sent
INFO - 2020-02-25 17:11:09 --> Input Class Initialized
INFO - 2020-02-25 17:11:09 --> Language Class Initialized
INFO - 2020-02-25 17:11:09 --> Language Class Initialized
INFO - 2020-02-25 17:11:09 --> Config Class Initialized
INFO - 2020-02-25 17:11:09 --> Loader Class Initialized
INFO - 2020-02-25 17:11:09 --> Helper loaded: url_helper
INFO - 2020-02-25 17:11:09 --> Helper loaded: common_helper
INFO - 2020-02-25 17:11:09 --> Helper loaded: language_helper
INFO - 2020-02-25 17:11:09 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:11:09 --> Helper loaded: email_helper
INFO - 2020-02-25 17:11:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:11:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:11:09 --> Parser Class Initialized
INFO - 2020-02-25 17:11:09 --> User Agent Class Initialized
INFO - 2020-02-25 17:11:09 --> Model Class Initialized
INFO - 2020-02-25 17:11:09 --> Database Driver Class Initialized
INFO - 2020-02-25 17:11:09 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:09 --> Template Class Initialized
INFO - 2020-02-25 17:11:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:11:10 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:11:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:11:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:11:10 --> Encryption Class Initialized
INFO - 2020-02-25 17:11:10 --> Controller Class Initialized
DEBUG - 2020-02-25 17:11:10 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:11:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:10 --> Model Class Initialized
ERROR - 2020-02-25 17:11:10 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:11:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:11:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:11:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:11:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:11:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:11:10 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:10 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:11:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:11:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:11:10 --> Final output sent to browser
DEBUG - 2020-02-25 17:11:10 --> Total execution time: 0.9368
INFO - 2020-02-25 17:11:11 --> Config Class Initialized
INFO - 2020-02-25 17:11:11 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:11:11 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:11:11 --> Utf8 Class Initialized
INFO - 2020-02-25 17:11:11 --> URI Class Initialized
INFO - 2020-02-25 17:11:11 --> Router Class Initialized
INFO - 2020-02-25 17:11:11 --> Output Class Initialized
INFO - 2020-02-25 17:11:11 --> Security Class Initialized
DEBUG - 2020-02-25 17:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:11:11 --> CSRF cookie sent
INFO - 2020-02-25 17:11:11 --> Input Class Initialized
INFO - 2020-02-25 17:11:11 --> Language Class Initialized
INFO - 2020-02-25 17:11:11 --> Language Class Initialized
INFO - 2020-02-25 17:11:11 --> Config Class Initialized
INFO - 2020-02-25 17:11:11 --> Loader Class Initialized
INFO - 2020-02-25 17:11:11 --> Helper loaded: url_helper
INFO - 2020-02-25 17:11:11 --> Helper loaded: common_helper
INFO - 2020-02-25 17:11:11 --> Helper loaded: language_helper
INFO - 2020-02-25 17:11:11 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:11:11 --> Helper loaded: email_helper
INFO - 2020-02-25 17:11:11 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:11:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:11:11 --> Parser Class Initialized
INFO - 2020-02-25 17:11:11 --> User Agent Class Initialized
INFO - 2020-02-25 17:11:11 --> Model Class Initialized
INFO - 2020-02-25 17:11:11 --> Database Driver Class Initialized
INFO - 2020-02-25 17:11:11 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:11 --> Template Class Initialized
INFO - 2020-02-25 17:11:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:11:11 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:11:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:11:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:11:11 --> Encryption Class Initialized
INFO - 2020-02-25 17:11:11 --> Controller Class Initialized
DEBUG - 2020-02-25 17:11:11 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:11:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:11 --> Model Class Initialized
ERROR - 2020-02-25 17:11:12 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:11:12 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:11:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:11:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:11:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:11:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:11:12 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:12 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:11:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:11:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:11:12 --> Final output sent to browser
DEBUG - 2020-02-25 17:11:12 --> Total execution time: 0.9298
INFO - 2020-02-25 17:11:13 --> Config Class Initialized
INFO - 2020-02-25 17:11:13 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:11:13 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:11:13 --> Utf8 Class Initialized
INFO - 2020-02-25 17:11:13 --> URI Class Initialized
INFO - 2020-02-25 17:11:13 --> Router Class Initialized
INFO - 2020-02-25 17:11:13 --> Output Class Initialized
INFO - 2020-02-25 17:11:13 --> Security Class Initialized
DEBUG - 2020-02-25 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:11:13 --> CSRF cookie sent
INFO - 2020-02-25 17:11:13 --> Input Class Initialized
INFO - 2020-02-25 17:11:13 --> Language Class Initialized
INFO - 2020-02-25 17:11:13 --> Language Class Initialized
INFO - 2020-02-25 17:11:13 --> Config Class Initialized
INFO - 2020-02-25 17:11:13 --> Loader Class Initialized
INFO - 2020-02-25 17:11:13 --> Helper loaded: url_helper
INFO - 2020-02-25 17:11:13 --> Helper loaded: common_helper
INFO - 2020-02-25 17:11:13 --> Helper loaded: language_helper
INFO - 2020-02-25 17:11:13 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:11:13 --> Helper loaded: email_helper
INFO - 2020-02-25 17:11:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:11:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:11:13 --> Parser Class Initialized
INFO - 2020-02-25 17:11:13 --> User Agent Class Initialized
INFO - 2020-02-25 17:11:13 --> Model Class Initialized
INFO - 2020-02-25 17:11:13 --> Database Driver Class Initialized
INFO - 2020-02-25 17:11:13 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:13 --> Template Class Initialized
INFO - 2020-02-25 17:11:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:11:13 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:11:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:11:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:11:13 --> Encryption Class Initialized
INFO - 2020-02-25 17:11:13 --> Controller Class Initialized
DEBUG - 2020-02-25 17:11:13 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:11:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:13 --> Model Class Initialized
ERROR - 2020-02-25 17:11:13 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:11:13 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:11:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:11:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:11:13 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:11:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:11:13 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:13 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:13 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:11:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:11:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:11:14 --> Final output sent to browser
DEBUG - 2020-02-25 17:11:14 --> Total execution time: 0.9287
INFO - 2020-02-25 17:11:15 --> Config Class Initialized
INFO - 2020-02-25 17:11:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:11:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:11:15 --> Utf8 Class Initialized
INFO - 2020-02-25 17:11:15 --> URI Class Initialized
INFO - 2020-02-25 17:11:16 --> Router Class Initialized
INFO - 2020-02-25 17:11:16 --> Output Class Initialized
INFO - 2020-02-25 17:11:16 --> Security Class Initialized
DEBUG - 2020-02-25 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:11:16 --> CSRF cookie sent
INFO - 2020-02-25 17:11:16 --> Input Class Initialized
INFO - 2020-02-25 17:11:16 --> Language Class Initialized
INFO - 2020-02-25 17:11:16 --> Language Class Initialized
INFO - 2020-02-25 17:11:16 --> Config Class Initialized
INFO - 2020-02-25 17:11:16 --> Loader Class Initialized
INFO - 2020-02-25 17:11:16 --> Helper loaded: url_helper
INFO - 2020-02-25 17:11:16 --> Helper loaded: common_helper
INFO - 2020-02-25 17:11:16 --> Helper loaded: language_helper
INFO - 2020-02-25 17:11:16 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:11:16 --> Helper loaded: email_helper
INFO - 2020-02-25 17:11:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:11:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:11:16 --> Parser Class Initialized
INFO - 2020-02-25 17:11:16 --> User Agent Class Initialized
INFO - 2020-02-25 17:11:16 --> Model Class Initialized
INFO - 2020-02-25 17:11:16 --> Database Driver Class Initialized
INFO - 2020-02-25 17:11:16 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:16 --> Template Class Initialized
INFO - 2020-02-25 17:11:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:11:16 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:11:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:11:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:11:16 --> Encryption Class Initialized
INFO - 2020-02-25 17:11:16 --> Controller Class Initialized
DEBUG - 2020-02-25 17:11:16 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:11:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:16 --> Model Class Initialized
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:11:16 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:11:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:11:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:11:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:16 --> Could not find the language line "View"
ERROR - 2020-02-25 17:11:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:11:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:11:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:11:17 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:11:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:11:17 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:17 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:11:17 --> Final output sent to browser
DEBUG - 2020-02-25 17:11:17 --> Total execution time: 1.4520
INFO - 2020-02-25 17:11:20 --> Config Class Initialized
INFO - 2020-02-25 17:11:20 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:11:20 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:11:20 --> Utf8 Class Initialized
INFO - 2020-02-25 17:11:20 --> URI Class Initialized
INFO - 2020-02-25 17:11:20 --> Router Class Initialized
INFO - 2020-02-25 17:11:20 --> Output Class Initialized
INFO - 2020-02-25 17:11:20 --> Security Class Initialized
DEBUG - 2020-02-25 17:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:11:20 --> CSRF cookie sent
INFO - 2020-02-25 17:11:20 --> Input Class Initialized
INFO - 2020-02-25 17:11:20 --> Language Class Initialized
INFO - 2020-02-25 17:11:20 --> Language Class Initialized
INFO - 2020-02-25 17:11:20 --> Config Class Initialized
INFO - 2020-02-25 17:11:20 --> Loader Class Initialized
INFO - 2020-02-25 17:11:20 --> Helper loaded: url_helper
INFO - 2020-02-25 17:11:20 --> Helper loaded: common_helper
INFO - 2020-02-25 17:11:20 --> Helper loaded: language_helper
INFO - 2020-02-25 17:11:20 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:11:20 --> Helper loaded: email_helper
INFO - 2020-02-25 17:11:20 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:11:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:11:20 --> Parser Class Initialized
INFO - 2020-02-25 17:11:20 --> User Agent Class Initialized
INFO - 2020-02-25 17:11:20 --> Model Class Initialized
INFO - 2020-02-25 17:11:20 --> Database Driver Class Initialized
INFO - 2020-02-25 17:11:20 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:20 --> Template Class Initialized
INFO - 2020-02-25 17:11:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:11:20 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:11:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:11:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:11:20 --> Encryption Class Initialized
INFO - 2020-02-25 17:11:20 --> Controller Class Initialized
DEBUG - 2020-02-25 17:11:20 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:11:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:20 --> Model Class Initialized
ERROR - 2020-02-25 17:11:20 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:11:20 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:11:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 21
ERROR - 2020-02-25 17:11:20 --> Severity: Notice --> Undefined variable: languges D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 31
ERROR - 2020-02-25 17:11:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 54
ERROR - 2020-02-25 17:11:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 163
ERROR - 2020-02-25 17:11:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 165
DEBUG - 2020-02-25 17:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:11:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:11:21 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:11:21 --> Model Class Initialized
DEBUG - 2020-02-25 17:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:11:21 --> Final output sent to browser
DEBUG - 2020-02-25 17:11:21 --> Total execution time: 1.1494
INFO - 2020-02-25 17:12:14 --> Config Class Initialized
INFO - 2020-02-25 17:12:14 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:12:14 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:12:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:12:14 --> URI Class Initialized
INFO - 2020-02-25 17:12:14 --> Router Class Initialized
INFO - 2020-02-25 17:12:14 --> Output Class Initialized
INFO - 2020-02-25 17:12:14 --> Security Class Initialized
DEBUG - 2020-02-25 17:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:12:14 --> CSRF cookie sent
INFO - 2020-02-25 17:12:14 --> Input Class Initialized
INFO - 2020-02-25 17:12:14 --> Language Class Initialized
INFO - 2020-02-25 17:12:14 --> Language Class Initialized
INFO - 2020-02-25 17:12:14 --> Config Class Initialized
INFO - 2020-02-25 17:12:14 --> Loader Class Initialized
INFO - 2020-02-25 17:12:14 --> Helper loaded: url_helper
INFO - 2020-02-25 17:12:14 --> Helper loaded: common_helper
INFO - 2020-02-25 17:12:14 --> Helper loaded: language_helper
INFO - 2020-02-25 17:12:14 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:12:14 --> Helper loaded: email_helper
INFO - 2020-02-25 17:12:14 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:12:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:12:15 --> Parser Class Initialized
INFO - 2020-02-25 17:12:15 --> User Agent Class Initialized
INFO - 2020-02-25 17:12:15 --> Model Class Initialized
INFO - 2020-02-25 17:12:15 --> Database Driver Class Initialized
INFO - 2020-02-25 17:12:15 --> Model Class Initialized
DEBUG - 2020-02-25 17:12:15 --> Template Class Initialized
INFO - 2020-02-25 17:12:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:12:15 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:12:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:12:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:12:15 --> Encryption Class Initialized
INFO - 2020-02-25 17:12:15 --> Controller Class Initialized
DEBUG - 2020-02-25 17:12:15 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:12:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:12:15 --> Model Class Initialized
ERROR - 2020-02-25 17:12:15 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:12:15 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:12:15 --> Severity: Notice --> Undefined variable: languges D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 31
ERROR - 2020-02-25 17:12:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 54
ERROR - 2020-02-25 17:12:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 163
ERROR - 2020-02-25 17:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 165
DEBUG - 2020-02-25 17:12:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:12:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:12:15 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:12:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:12:15 --> Model Class Initialized
DEBUG - 2020-02-25 17:12:15 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:12:15 --> Model Class Initialized
DEBUG - 2020-02-25 17:12:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:12:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:12:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:12:15 --> Final output sent to browser
DEBUG - 2020-02-25 17:12:15 --> Total execution time: 1.1269
INFO - 2020-02-25 17:12:53 --> Config Class Initialized
INFO - 2020-02-25 17:12:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:12:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:12:53 --> Utf8 Class Initialized
INFO - 2020-02-25 17:12:54 --> URI Class Initialized
INFO - 2020-02-25 17:12:54 --> Router Class Initialized
INFO - 2020-02-25 17:12:54 --> Output Class Initialized
INFO - 2020-02-25 17:12:54 --> Security Class Initialized
DEBUG - 2020-02-25 17:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:12:54 --> CSRF cookie sent
INFO - 2020-02-25 17:12:54 --> Input Class Initialized
INFO - 2020-02-25 17:12:54 --> Language Class Initialized
INFO - 2020-02-25 17:12:54 --> Language Class Initialized
INFO - 2020-02-25 17:12:54 --> Config Class Initialized
INFO - 2020-02-25 17:12:54 --> Loader Class Initialized
INFO - 2020-02-25 17:12:54 --> Helper loaded: url_helper
INFO - 2020-02-25 17:12:54 --> Helper loaded: common_helper
INFO - 2020-02-25 17:12:54 --> Helper loaded: language_helper
INFO - 2020-02-25 17:12:54 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:12:54 --> Helper loaded: email_helper
INFO - 2020-02-25 17:12:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:12:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:12:54 --> Parser Class Initialized
INFO - 2020-02-25 17:12:54 --> User Agent Class Initialized
INFO - 2020-02-25 17:12:54 --> Model Class Initialized
INFO - 2020-02-25 17:12:54 --> Database Driver Class Initialized
INFO - 2020-02-25 17:12:54 --> Model Class Initialized
DEBUG - 2020-02-25 17:12:54 --> Template Class Initialized
INFO - 2020-02-25 17:12:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:12:54 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:12:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:12:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:12:54 --> Encryption Class Initialized
INFO - 2020-02-25 17:12:54 --> Controller Class Initialized
DEBUG - 2020-02-25 17:12:54 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:12:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:12:54 --> Model Class Initialized
ERROR - 2020-02-25 17:12:54 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:12:54 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:12:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 27
ERROR - 2020-02-25 17:12:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 136
ERROR - 2020-02-25 17:12:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 138
DEBUG - 2020-02-25 17:12:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:12:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:12:54 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:12:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:12:54 --> Model Class Initialized
DEBUG - 2020-02-25 17:12:54 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:12:54 --> Model Class Initialized
DEBUG - 2020-02-25 17:12:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:12:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:12:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:12:55 --> Final output sent to browser
DEBUG - 2020-02-25 17:12:55 --> Total execution time: 1.0987
INFO - 2020-02-25 17:13:17 --> Config Class Initialized
INFO - 2020-02-25 17:13:17 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:17 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:17 --> URI Class Initialized
INFO - 2020-02-25 17:13:17 --> Router Class Initialized
INFO - 2020-02-25 17:13:17 --> Output Class Initialized
INFO - 2020-02-25 17:13:17 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:17 --> CSRF cookie sent
INFO - 2020-02-25 17:13:17 --> Input Class Initialized
INFO - 2020-02-25 17:13:17 --> Language Class Initialized
INFO - 2020-02-25 17:13:17 --> Language Class Initialized
INFO - 2020-02-25 17:13:17 --> Config Class Initialized
INFO - 2020-02-25 17:13:17 --> Loader Class Initialized
INFO - 2020-02-25 17:13:17 --> Helper loaded: url_helper
INFO - 2020-02-25 17:13:17 --> Helper loaded: common_helper
INFO - 2020-02-25 17:13:17 --> Helper loaded: language_helper
INFO - 2020-02-25 17:13:17 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:13:17 --> Helper loaded: email_helper
INFO - 2020-02-25 17:13:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:13:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:13:17 --> Parser Class Initialized
INFO - 2020-02-25 17:13:17 --> User Agent Class Initialized
INFO - 2020-02-25 17:13:17 --> Model Class Initialized
INFO - 2020-02-25 17:13:17 --> Database Driver Class Initialized
INFO - 2020-02-25 17:13:17 --> Model Class Initialized
DEBUG - 2020-02-25 17:13:17 --> Template Class Initialized
INFO - 2020-02-25 17:13:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:13:17 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:13:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:13:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:13:17 --> Encryption Class Initialized
INFO - 2020-02-25 17:13:17 --> Controller Class Initialized
DEBUG - 2020-02-25 17:13:18 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:13:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:13:18 --> Model Class Initialized
ERROR - 2020-02-25 17:13:18 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:13:18 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:13:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 134
ERROR - 2020-02-25 17:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 136
DEBUG - 2020-02-25 17:13:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:13:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:13:18 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:13:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:13:18 --> Model Class Initialized
DEBUG - 2020-02-25 17:13:18 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:13:18 --> Model Class Initialized
DEBUG - 2020-02-25 17:13:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:13:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:13:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:13:18 --> Final output sent to browser
DEBUG - 2020-02-25 17:13:18 --> Total execution time: 1.0651
INFO - 2020-02-25 17:13:45 --> Config Class Initialized
INFO - 2020-02-25 17:13:45 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:45 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:45 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:45 --> URI Class Initialized
INFO - 2020-02-25 17:13:45 --> Router Class Initialized
INFO - 2020-02-25 17:13:45 --> Output Class Initialized
INFO - 2020-02-25 17:13:45 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:45 --> CSRF cookie sent
INFO - 2020-02-25 17:13:45 --> Input Class Initialized
INFO - 2020-02-25 17:13:45 --> Language Class Initialized
INFO - 2020-02-25 17:13:45 --> Language Class Initialized
INFO - 2020-02-25 17:13:45 --> Config Class Initialized
INFO - 2020-02-25 17:13:45 --> Loader Class Initialized
INFO - 2020-02-25 17:13:45 --> Helper loaded: url_helper
INFO - 2020-02-25 17:13:45 --> Helper loaded: common_helper
INFO - 2020-02-25 17:13:45 --> Helper loaded: language_helper
INFO - 2020-02-25 17:13:45 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:13:45 --> Helper loaded: email_helper
INFO - 2020-02-25 17:13:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:13:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:13:45 --> Parser Class Initialized
INFO - 2020-02-25 17:13:45 --> User Agent Class Initialized
INFO - 2020-02-25 17:13:45 --> Model Class Initialized
INFO - 2020-02-25 17:13:45 --> Database Driver Class Initialized
INFO - 2020-02-25 17:13:45 --> Model Class Initialized
DEBUG - 2020-02-25 17:13:45 --> Template Class Initialized
INFO - 2020-02-25 17:13:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:13:45 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:13:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:13:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:13:45 --> Encryption Class Initialized
INFO - 2020-02-25 17:13:45 --> Controller Class Initialized
DEBUG - 2020-02-25 17:13:45 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:13:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:13:46 --> Model Class Initialized
ERROR - 2020-02-25 17:13:46 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:13:46 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:13:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 128
ERROR - 2020-02-25 17:13:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 130
DEBUG - 2020-02-25 17:13:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:13:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:13:46 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:13:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:13:46 --> Model Class Initialized
DEBUG - 2020-02-25 17:13:46 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:13:46 --> Model Class Initialized
DEBUG - 2020-02-25 17:13:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:13:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:13:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:13:46 --> Final output sent to browser
DEBUG - 2020-02-25 17:13:46 --> Total execution time: 1.1603
INFO - 2020-02-25 17:14:16 --> Config Class Initialized
INFO - 2020-02-25 17:14:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:14:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:14:16 --> Utf8 Class Initialized
INFO - 2020-02-25 17:14:16 --> URI Class Initialized
INFO - 2020-02-25 17:14:16 --> Router Class Initialized
INFO - 2020-02-25 17:14:16 --> Output Class Initialized
INFO - 2020-02-25 17:14:16 --> Security Class Initialized
DEBUG - 2020-02-25 17:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:14:16 --> CSRF cookie sent
INFO - 2020-02-25 17:14:16 --> Input Class Initialized
INFO - 2020-02-25 17:14:16 --> Language Class Initialized
INFO - 2020-02-25 17:14:16 --> Language Class Initialized
INFO - 2020-02-25 17:14:16 --> Config Class Initialized
INFO - 2020-02-25 17:14:16 --> Loader Class Initialized
INFO - 2020-02-25 17:14:16 --> Helper loaded: url_helper
INFO - 2020-02-25 17:14:16 --> Helper loaded: common_helper
INFO - 2020-02-25 17:14:16 --> Helper loaded: language_helper
INFO - 2020-02-25 17:14:16 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:14:16 --> Helper loaded: email_helper
INFO - 2020-02-25 17:14:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:14:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:14:16 --> Parser Class Initialized
INFO - 2020-02-25 17:14:16 --> User Agent Class Initialized
INFO - 2020-02-25 17:14:16 --> Model Class Initialized
INFO - 2020-02-25 17:14:16 --> Database Driver Class Initialized
INFO - 2020-02-25 17:14:16 --> Model Class Initialized
DEBUG - 2020-02-25 17:14:16 --> Template Class Initialized
INFO - 2020-02-25 17:14:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:14:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:14:16 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:14:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:14:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:14:16 --> Encryption Class Initialized
INFO - 2020-02-25 17:14:16 --> Controller Class Initialized
DEBUG - 2020-02-25 17:14:16 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:14:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:14:16 --> Model Class Initialized
ERROR - 2020-02-25 17:14:16 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:14:16 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:14:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 128
ERROR - 2020-02-25 17:14:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 130
DEBUG - 2020-02-25 17:14:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:14:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:14:16 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:14:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:14:16 --> Model Class Initialized
DEBUG - 2020-02-25 17:14:16 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:14:16 --> Model Class Initialized
DEBUG - 2020-02-25 17:14:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:14:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:14:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:14:17 --> Final output sent to browser
DEBUG - 2020-02-25 17:14:17 --> Total execution time: 1.0289
INFO - 2020-02-25 17:14:36 --> Config Class Initialized
INFO - 2020-02-25 17:14:36 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:14:36 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:14:36 --> Utf8 Class Initialized
INFO - 2020-02-25 17:14:36 --> URI Class Initialized
INFO - 2020-02-25 17:14:36 --> Router Class Initialized
INFO - 2020-02-25 17:14:36 --> Output Class Initialized
INFO - 2020-02-25 17:14:36 --> Security Class Initialized
DEBUG - 2020-02-25 17:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:14:36 --> CSRF cookie sent
INFO - 2020-02-25 17:14:36 --> Input Class Initialized
INFO - 2020-02-25 17:14:36 --> Language Class Initialized
INFO - 2020-02-25 17:14:36 --> Language Class Initialized
INFO - 2020-02-25 17:14:36 --> Config Class Initialized
INFO - 2020-02-25 17:14:36 --> Loader Class Initialized
INFO - 2020-02-25 17:14:36 --> Helper loaded: url_helper
INFO - 2020-02-25 17:14:36 --> Helper loaded: common_helper
INFO - 2020-02-25 17:14:36 --> Helper loaded: language_helper
INFO - 2020-02-25 17:14:36 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:14:36 --> Helper loaded: email_helper
INFO - 2020-02-25 17:14:36 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:14:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:14:36 --> Parser Class Initialized
INFO - 2020-02-25 17:14:36 --> User Agent Class Initialized
INFO - 2020-02-25 17:14:36 --> Model Class Initialized
INFO - 2020-02-25 17:14:37 --> Database Driver Class Initialized
INFO - 2020-02-25 17:14:37 --> Model Class Initialized
DEBUG - 2020-02-25 17:14:37 --> Template Class Initialized
INFO - 2020-02-25 17:14:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:14:37 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:14:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:14:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:14:37 --> Encryption Class Initialized
INFO - 2020-02-25 17:14:37 --> Controller Class Initialized
DEBUG - 2020-02-25 17:14:37 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:14:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:14:37 --> Model Class Initialized
ERROR - 2020-02-25 17:14:37 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:14:37 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:14:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 128
ERROR - 2020-02-25 17:14:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 130
DEBUG - 2020-02-25 17:14:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:14:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:14:37 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:14:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:14:37 --> Model Class Initialized
DEBUG - 2020-02-25 17:14:37 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:14:37 --> Model Class Initialized
DEBUG - 2020-02-25 17:14:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:14:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:14:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:14:37 --> Final output sent to browser
DEBUG - 2020-02-25 17:14:37 --> Total execution time: 1.0457
INFO - 2020-02-25 17:15:51 --> Config Class Initialized
INFO - 2020-02-25 17:15:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:15:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:15:51 --> Utf8 Class Initialized
INFO - 2020-02-25 17:15:51 --> URI Class Initialized
INFO - 2020-02-25 17:15:51 --> Router Class Initialized
INFO - 2020-02-25 17:15:51 --> Output Class Initialized
INFO - 2020-02-25 17:15:51 --> Security Class Initialized
DEBUG - 2020-02-25 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:15:51 --> CSRF cookie sent
INFO - 2020-02-25 17:15:51 --> Input Class Initialized
INFO - 2020-02-25 17:15:51 --> Language Class Initialized
INFO - 2020-02-25 17:15:51 --> Language Class Initialized
INFO - 2020-02-25 17:15:51 --> Config Class Initialized
INFO - 2020-02-25 17:15:52 --> Loader Class Initialized
INFO - 2020-02-25 17:15:52 --> Helper loaded: url_helper
INFO - 2020-02-25 17:15:52 --> Helper loaded: common_helper
INFO - 2020-02-25 17:15:52 --> Helper loaded: language_helper
INFO - 2020-02-25 17:15:52 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:15:52 --> Helper loaded: email_helper
INFO - 2020-02-25 17:15:52 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:15:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:15:52 --> Parser Class Initialized
INFO - 2020-02-25 17:15:52 --> User Agent Class Initialized
INFO - 2020-02-25 17:15:52 --> Model Class Initialized
INFO - 2020-02-25 17:15:52 --> Database Driver Class Initialized
INFO - 2020-02-25 17:15:52 --> Model Class Initialized
DEBUG - 2020-02-25 17:15:52 --> Template Class Initialized
INFO - 2020-02-25 17:15:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:15:52 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:15:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:15:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:15:52 --> Encryption Class Initialized
INFO - 2020-02-25 17:15:52 --> Controller Class Initialized
DEBUG - 2020-02-25 17:15:52 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:15:52 --> Model Class Initialized
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:15:52 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "Delele"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
ERROR - 2020-02-25 17:15:52 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:15:53 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:15:53 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-02-25 17:15:53 --> Could not find the language line "View"
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:15:53 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:15:53 --> Model Class Initialized
DEBUG - 2020-02-25 17:15:53 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:15:53 --> Model Class Initialized
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:15:53 --> Final output sent to browser
DEBUG - 2020-02-25 17:15:53 --> Total execution time: 1.7045
INFO - 2020-02-25 17:15:55 --> Config Class Initialized
INFO - 2020-02-25 17:15:55 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:15:55 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:15:55 --> Utf8 Class Initialized
INFO - 2020-02-25 17:15:55 --> URI Class Initialized
INFO - 2020-02-25 17:15:55 --> Router Class Initialized
INFO - 2020-02-25 17:15:55 --> Output Class Initialized
INFO - 2020-02-25 17:15:55 --> Security Class Initialized
DEBUG - 2020-02-25 17:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:15:55 --> CSRF cookie sent
INFO - 2020-02-25 17:15:55 --> Input Class Initialized
INFO - 2020-02-25 17:15:55 --> Language Class Initialized
INFO - 2020-02-25 17:15:55 --> Language Class Initialized
INFO - 2020-02-25 17:15:55 --> Config Class Initialized
INFO - 2020-02-25 17:15:55 --> Loader Class Initialized
INFO - 2020-02-25 17:15:55 --> Helper loaded: url_helper
INFO - 2020-02-25 17:15:55 --> Helper loaded: common_helper
INFO - 2020-02-25 17:15:55 --> Helper loaded: language_helper
INFO - 2020-02-25 17:15:55 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:15:55 --> Helper loaded: email_helper
INFO - 2020-02-25 17:15:55 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:15:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:15:55 --> Parser Class Initialized
INFO - 2020-02-25 17:15:55 --> User Agent Class Initialized
INFO - 2020-02-25 17:15:55 --> Model Class Initialized
INFO - 2020-02-25 17:15:55 --> Database Driver Class Initialized
INFO - 2020-02-25 17:15:55 --> Model Class Initialized
DEBUG - 2020-02-25 17:15:55 --> Template Class Initialized
INFO - 2020-02-25 17:15:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:15:55 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:15:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:15:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:15:55 --> Encryption Class Initialized
INFO - 2020-02-25 17:15:55 --> Controller Class Initialized
DEBUG - 2020-02-25 17:15:55 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:15:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:15:55 --> Model Class Initialized
ERROR - 2020-02-25 17:15:55 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:15:55 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-25 17:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:15:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:15:56 --> Model Class Initialized
DEBUG - 2020-02-25 17:15:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:15:56 --> Model Class Initialized
DEBUG - 2020-02-25 17:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:15:56 --> Final output sent to browser
DEBUG - 2020-02-25 17:15:56 --> Total execution time: 1.0442
INFO - 2020-02-25 17:16:21 --> Config Class Initialized
INFO - 2020-02-25 17:16:21 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:16:21 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:16:21 --> Utf8 Class Initialized
INFO - 2020-02-25 17:16:21 --> URI Class Initialized
INFO - 2020-02-25 17:16:21 --> Router Class Initialized
INFO - 2020-02-25 17:16:21 --> Output Class Initialized
INFO - 2020-02-25 17:16:21 --> Security Class Initialized
DEBUG - 2020-02-25 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:16:21 --> CSRF cookie sent
INFO - 2020-02-25 17:16:21 --> Input Class Initialized
INFO - 2020-02-25 17:16:21 --> Language Class Initialized
INFO - 2020-02-25 17:16:21 --> Language Class Initialized
INFO - 2020-02-25 17:16:21 --> Config Class Initialized
INFO - 2020-02-25 17:16:21 --> Loader Class Initialized
INFO - 2020-02-25 17:16:21 --> Helper loaded: url_helper
INFO - 2020-02-25 17:16:21 --> Helper loaded: common_helper
INFO - 2020-02-25 17:16:21 --> Helper loaded: language_helper
INFO - 2020-02-25 17:16:21 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:16:21 --> Helper loaded: email_helper
INFO - 2020-02-25 17:16:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:16:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:16:22 --> Parser Class Initialized
INFO - 2020-02-25 17:16:22 --> User Agent Class Initialized
INFO - 2020-02-25 17:16:22 --> Model Class Initialized
INFO - 2020-02-25 17:16:22 --> Database Driver Class Initialized
INFO - 2020-02-25 17:16:22 --> Model Class Initialized
DEBUG - 2020-02-25 17:16:22 --> Template Class Initialized
INFO - 2020-02-25 17:16:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:16:22 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:16:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:16:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:16:22 --> Encryption Class Initialized
INFO - 2020-02-25 17:16:22 --> Controller Class Initialized
DEBUG - 2020-02-25 17:16:22 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:16:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:16:22 --> Model Class Initialized
ERROR - 2020-02-25 17:16:22 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:16:22 --> Helper loaded: inflector_helper
INFO - 2020-02-25 17:22:40 --> Config Class Initialized
INFO - 2020-02-25 17:22:40 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:22:40 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:22:40 --> Utf8 Class Initialized
INFO - 2020-02-25 17:22:40 --> URI Class Initialized
INFO - 2020-02-25 17:22:40 --> Router Class Initialized
INFO - 2020-02-25 17:22:40 --> Output Class Initialized
INFO - 2020-02-25 17:22:40 --> Security Class Initialized
DEBUG - 2020-02-25 17:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:22:40 --> CSRF cookie sent
INFO - 2020-02-25 17:22:40 --> Input Class Initialized
INFO - 2020-02-25 17:22:40 --> Language Class Initialized
INFO - 2020-02-25 17:22:40 --> Language Class Initialized
INFO - 2020-02-25 17:22:40 --> Config Class Initialized
INFO - 2020-02-25 17:22:40 --> Loader Class Initialized
INFO - 2020-02-25 17:22:40 --> Helper loaded: url_helper
INFO - 2020-02-25 17:22:40 --> Helper loaded: common_helper
INFO - 2020-02-25 17:22:40 --> Helper loaded: language_helper
INFO - 2020-02-25 17:22:40 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:22:40 --> Helper loaded: email_helper
INFO - 2020-02-25 17:22:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:22:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:22:40 --> Parser Class Initialized
INFO - 2020-02-25 17:22:40 --> User Agent Class Initialized
INFO - 2020-02-25 17:22:40 --> Model Class Initialized
INFO - 2020-02-25 17:22:40 --> Database Driver Class Initialized
INFO - 2020-02-25 17:22:40 --> Model Class Initialized
DEBUG - 2020-02-25 17:22:40 --> Template Class Initialized
INFO - 2020-02-25 17:22:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:22:40 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:22:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:22:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:22:40 --> Encryption Class Initialized
INFO - 2020-02-25 17:22:41 --> Controller Class Initialized
DEBUG - 2020-02-25 17:22:41 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:22:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:22:41 --> Model Class Initialized
ERROR - 2020-02-25 17:22:41 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:22:41 --> Helper loaded: inflector_helper
ERROR - 2020-02-25 17:22:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\add.php 131
DEBUG - 2020-02-25 17:22:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:22:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:22:41 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:22:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:22:41 --> Model Class Initialized
DEBUG - 2020-02-25 17:22:41 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:22:41 --> Model Class Initialized
DEBUG - 2020-02-25 17:22:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:22:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:22:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:22:41 --> Final output sent to browser
DEBUG - 2020-02-25 17:22:41 --> Total execution time: 1.1181
INFO - 2020-02-25 17:23:10 --> Config Class Initialized
INFO - 2020-02-25 17:23:10 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:23:10 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:23:10 --> Utf8 Class Initialized
INFO - 2020-02-25 17:23:10 --> URI Class Initialized
INFO - 2020-02-25 17:23:10 --> Router Class Initialized
INFO - 2020-02-25 17:23:10 --> Output Class Initialized
INFO - 2020-02-25 17:23:10 --> Security Class Initialized
DEBUG - 2020-02-25 17:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:23:10 --> CSRF cookie sent
INFO - 2020-02-25 17:23:10 --> Input Class Initialized
INFO - 2020-02-25 17:23:10 --> Language Class Initialized
INFO - 2020-02-25 17:23:10 --> Language Class Initialized
INFO - 2020-02-25 17:23:10 --> Config Class Initialized
INFO - 2020-02-25 17:23:10 --> Loader Class Initialized
INFO - 2020-02-25 17:23:10 --> Helper loaded: url_helper
INFO - 2020-02-25 17:23:10 --> Helper loaded: common_helper
INFO - 2020-02-25 17:23:10 --> Helper loaded: language_helper
INFO - 2020-02-25 17:23:10 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:23:10 --> Helper loaded: email_helper
INFO - 2020-02-25 17:23:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:23:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:23:10 --> Parser Class Initialized
INFO - 2020-02-25 17:23:10 --> User Agent Class Initialized
INFO - 2020-02-25 17:23:10 --> Model Class Initialized
INFO - 2020-02-25 17:23:10 --> Database Driver Class Initialized
INFO - 2020-02-25 17:23:10 --> Model Class Initialized
DEBUG - 2020-02-25 17:23:10 --> Template Class Initialized
INFO - 2020-02-25 17:23:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:23:10 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:23:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:23:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:23:10 --> Encryption Class Initialized
INFO - 2020-02-25 17:23:10 --> Controller Class Initialized
DEBUG - 2020-02-25 17:23:10 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:23:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:23:10 --> Model Class Initialized
ERROR - 2020-02-25 17:23:10 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:23:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:23:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:23:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:23:11 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:23:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:23:11 --> Model Class Initialized
DEBUG - 2020-02-25 17:23:11 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:23:11 --> Model Class Initialized
DEBUG - 2020-02-25 17:23:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:23:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:23:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:23:11 --> Final output sent to browser
DEBUG - 2020-02-25 17:23:11 --> Total execution time: 1.0283
INFO - 2020-02-25 17:23:31 --> Config Class Initialized
INFO - 2020-02-25 17:23:31 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:23:31 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:23:31 --> Utf8 Class Initialized
INFO - 2020-02-25 17:23:31 --> URI Class Initialized
INFO - 2020-02-25 17:23:31 --> Router Class Initialized
INFO - 2020-02-25 17:23:31 --> Output Class Initialized
INFO - 2020-02-25 17:23:31 --> Security Class Initialized
DEBUG - 2020-02-25 17:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:23:31 --> CSRF cookie sent
INFO - 2020-02-25 17:23:31 --> Input Class Initialized
INFO - 2020-02-25 17:23:31 --> Language Class Initialized
INFO - 2020-02-25 17:23:31 --> Language Class Initialized
INFO - 2020-02-25 17:23:31 --> Config Class Initialized
INFO - 2020-02-25 17:23:31 --> Loader Class Initialized
INFO - 2020-02-25 17:23:31 --> Helper loaded: url_helper
INFO - 2020-02-25 17:23:31 --> Helper loaded: common_helper
INFO - 2020-02-25 17:23:31 --> Helper loaded: language_helper
INFO - 2020-02-25 17:23:31 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:23:31 --> Helper loaded: email_helper
INFO - 2020-02-25 17:23:31 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:23:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:23:31 --> Parser Class Initialized
INFO - 2020-02-25 17:23:31 --> User Agent Class Initialized
INFO - 2020-02-25 17:23:31 --> Model Class Initialized
INFO - 2020-02-25 17:23:31 --> Database Driver Class Initialized
INFO - 2020-02-25 17:23:31 --> Model Class Initialized
DEBUG - 2020-02-25 17:23:31 --> Template Class Initialized
INFO - 2020-02-25 17:23:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:23:31 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:23:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:23:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:23:31 --> Encryption Class Initialized
INFO - 2020-02-25 17:23:31 --> Controller Class Initialized
DEBUG - 2020-02-25 17:23:31 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:23:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:23:31 --> Model Class Initialized
ERROR - 2020-02-25 17:23:31 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:23:31 --> Helper loaded: inflector_helper
INFO - 2020-02-25 17:24:22 --> Config Class Initialized
INFO - 2020-02-25 17:24:22 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:24:22 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:24:22 --> Utf8 Class Initialized
INFO - 2020-02-25 17:24:22 --> URI Class Initialized
INFO - 2020-02-25 17:24:22 --> Router Class Initialized
INFO - 2020-02-25 17:24:22 --> Output Class Initialized
INFO - 2020-02-25 17:24:22 --> Security Class Initialized
DEBUG - 2020-02-25 17:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:24:22 --> CSRF cookie sent
INFO - 2020-02-25 17:24:22 --> Input Class Initialized
INFO - 2020-02-25 17:24:22 --> Language Class Initialized
INFO - 2020-02-25 17:24:22 --> Language Class Initialized
INFO - 2020-02-25 17:24:22 --> Config Class Initialized
INFO - 2020-02-25 17:24:22 --> Loader Class Initialized
INFO - 2020-02-25 17:24:22 --> Helper loaded: url_helper
INFO - 2020-02-25 17:24:22 --> Helper loaded: common_helper
INFO - 2020-02-25 17:24:22 --> Helper loaded: language_helper
INFO - 2020-02-25 17:24:22 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:24:22 --> Helper loaded: email_helper
INFO - 2020-02-25 17:24:22 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:24:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:24:22 --> Parser Class Initialized
INFO - 2020-02-25 17:24:22 --> User Agent Class Initialized
INFO - 2020-02-25 17:24:22 --> Model Class Initialized
INFO - 2020-02-25 17:24:22 --> Database Driver Class Initialized
INFO - 2020-02-25 17:24:22 --> Model Class Initialized
DEBUG - 2020-02-25 17:24:22 --> Template Class Initialized
INFO - 2020-02-25 17:24:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:24:22 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:24:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:24:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:24:22 --> Encryption Class Initialized
INFO - 2020-02-25 17:24:22 --> Controller Class Initialized
DEBUG - 2020-02-25 17:24:22 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:24:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:24:22 --> Model Class Initialized
ERROR - 2020-02-25 17:24:22 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:24:22 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:24:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:24:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:24:22 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:24:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:24:23 --> Model Class Initialized
DEBUG - 2020-02-25 17:24:23 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:24:23 --> Model Class Initialized
DEBUG - 2020-02-25 17:24:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:24:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:24:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:24:23 --> Final output sent to browser
DEBUG - 2020-02-25 17:24:23 --> Total execution time: 1.0235
INFO - 2020-02-25 17:24:57 --> Config Class Initialized
INFO - 2020-02-25 17:24:57 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:24:57 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:24:57 --> Utf8 Class Initialized
INFO - 2020-02-25 17:24:57 --> URI Class Initialized
INFO - 2020-02-25 17:24:57 --> Router Class Initialized
INFO - 2020-02-25 17:24:57 --> Output Class Initialized
INFO - 2020-02-25 17:24:57 --> Security Class Initialized
DEBUG - 2020-02-25 17:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:24:57 --> CSRF cookie sent
INFO - 2020-02-25 17:24:57 --> Input Class Initialized
INFO - 2020-02-25 17:24:57 --> Language Class Initialized
INFO - 2020-02-25 17:24:57 --> Language Class Initialized
INFO - 2020-02-25 17:24:57 --> Config Class Initialized
INFO - 2020-02-25 17:24:57 --> Loader Class Initialized
INFO - 2020-02-25 17:24:57 --> Helper loaded: url_helper
INFO - 2020-02-25 17:24:57 --> Helper loaded: common_helper
INFO - 2020-02-25 17:24:57 --> Helper loaded: language_helper
INFO - 2020-02-25 17:24:57 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:24:57 --> Helper loaded: email_helper
INFO - 2020-02-25 17:24:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:24:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:24:57 --> Parser Class Initialized
INFO - 2020-02-25 17:24:57 --> User Agent Class Initialized
INFO - 2020-02-25 17:24:57 --> Model Class Initialized
INFO - 2020-02-25 17:24:57 --> Database Driver Class Initialized
INFO - 2020-02-25 17:24:57 --> Model Class Initialized
DEBUG - 2020-02-25 17:24:57 --> Template Class Initialized
INFO - 2020-02-25 17:24:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:24:57 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:24:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:24:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:24:58 --> Encryption Class Initialized
INFO - 2020-02-25 17:24:58 --> Controller Class Initialized
DEBUG - 2020-02-25 17:24:58 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:24:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:24:58 --> Model Class Initialized
ERROR - 2020-02-25 17:24:58 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:24:58 --> Helper loaded: inflector_helper
INFO - 2020-02-25 17:25:51 --> Config Class Initialized
INFO - 2020-02-25 17:25:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:25:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:25:51 --> Utf8 Class Initialized
INFO - 2020-02-25 17:25:51 --> URI Class Initialized
INFO - 2020-02-25 17:25:51 --> Router Class Initialized
INFO - 2020-02-25 17:25:51 --> Output Class Initialized
INFO - 2020-02-25 17:25:51 --> Security Class Initialized
DEBUG - 2020-02-25 17:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:25:51 --> CSRF cookie sent
INFO - 2020-02-25 17:25:51 --> Input Class Initialized
INFO - 2020-02-25 17:25:51 --> Language Class Initialized
INFO - 2020-02-25 17:25:51 --> Language Class Initialized
INFO - 2020-02-25 17:25:51 --> Config Class Initialized
INFO - 2020-02-25 17:25:51 --> Loader Class Initialized
INFO - 2020-02-25 17:25:51 --> Helper loaded: url_helper
INFO - 2020-02-25 17:25:51 --> Helper loaded: common_helper
INFO - 2020-02-25 17:25:51 --> Helper loaded: language_helper
INFO - 2020-02-25 17:25:51 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:25:51 --> Helper loaded: email_helper
INFO - 2020-02-25 17:25:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:25:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:25:51 --> Parser Class Initialized
INFO - 2020-02-25 17:25:51 --> User Agent Class Initialized
INFO - 2020-02-25 17:25:51 --> Model Class Initialized
INFO - 2020-02-25 17:25:51 --> Database Driver Class Initialized
INFO - 2020-02-25 17:25:51 --> Model Class Initialized
DEBUG - 2020-02-25 17:25:51 --> Template Class Initialized
INFO - 2020-02-25 17:25:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:25:51 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:25:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:25:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:25:51 --> Encryption Class Initialized
INFO - 2020-02-25 17:25:51 --> Controller Class Initialized
DEBUG - 2020-02-25 17:25:51 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:25:51 --> Model Class Initialized
ERROR - 2020-02-25 17:25:51 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:25:52 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:25:52 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:25:52 --> Model Class Initialized
DEBUG - 2020-02-25 17:25:52 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:25:52 --> Model Class Initialized
DEBUG - 2020-02-25 17:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:25:52 --> Final output sent to browser
DEBUG - 2020-02-25 17:25:52 --> Total execution time: 1.0755
INFO - 2020-02-25 17:26:54 --> Config Class Initialized
INFO - 2020-02-25 17:26:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:26:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:26:54 --> Utf8 Class Initialized
INFO - 2020-02-25 17:26:54 --> URI Class Initialized
INFO - 2020-02-25 17:26:54 --> Router Class Initialized
INFO - 2020-02-25 17:26:54 --> Output Class Initialized
INFO - 2020-02-25 17:26:54 --> Security Class Initialized
DEBUG - 2020-02-25 17:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:26:54 --> CSRF cookie sent
INFO - 2020-02-25 17:26:54 --> Input Class Initialized
INFO - 2020-02-25 17:26:54 --> Language Class Initialized
INFO - 2020-02-25 17:26:54 --> Language Class Initialized
INFO - 2020-02-25 17:26:54 --> Config Class Initialized
INFO - 2020-02-25 17:26:54 --> Loader Class Initialized
INFO - 2020-02-25 17:26:54 --> Helper loaded: url_helper
INFO - 2020-02-25 17:26:54 --> Helper loaded: common_helper
INFO - 2020-02-25 17:26:54 --> Helper loaded: language_helper
INFO - 2020-02-25 17:26:54 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:26:54 --> Helper loaded: email_helper
INFO - 2020-02-25 17:26:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:26:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:26:54 --> Parser Class Initialized
INFO - 2020-02-25 17:26:54 --> User Agent Class Initialized
INFO - 2020-02-25 17:26:54 --> Model Class Initialized
INFO - 2020-02-25 17:26:54 --> Database Driver Class Initialized
INFO - 2020-02-25 17:26:54 --> Model Class Initialized
DEBUG - 2020-02-25 17:26:54 --> Template Class Initialized
INFO - 2020-02-25 17:26:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:26:54 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:26:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:26:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:26:54 --> Encryption Class Initialized
INFO - 2020-02-25 17:26:54 --> Controller Class Initialized
DEBUG - 2020-02-25 17:26:54 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:26:54 --> Model Class Initialized
ERROR - 2020-02-25 17:26:54 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:26:54 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:26:54 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:26:54 --> Model Class Initialized
DEBUG - 2020-02-25 17:26:54 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:26:54 --> Model Class Initialized
DEBUG - 2020-02-25 17:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:26:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:26:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:26:55 --> Final output sent to browser
DEBUG - 2020-02-25 17:26:55 --> Total execution time: 1.0725
INFO - 2020-02-25 17:27:30 --> Config Class Initialized
INFO - 2020-02-25 17:27:30 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:27:30 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:27:30 --> Utf8 Class Initialized
INFO - 2020-02-25 17:27:30 --> URI Class Initialized
INFO - 2020-02-25 17:27:30 --> Router Class Initialized
INFO - 2020-02-25 17:27:30 --> Output Class Initialized
INFO - 2020-02-25 17:27:30 --> Security Class Initialized
DEBUG - 2020-02-25 17:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:27:30 --> CSRF cookie sent
INFO - 2020-02-25 17:27:30 --> Input Class Initialized
INFO - 2020-02-25 17:27:30 --> Language Class Initialized
INFO - 2020-02-25 17:27:30 --> Language Class Initialized
INFO - 2020-02-25 17:27:30 --> Config Class Initialized
INFO - 2020-02-25 17:27:30 --> Loader Class Initialized
INFO - 2020-02-25 17:27:30 --> Helper loaded: url_helper
INFO - 2020-02-25 17:27:30 --> Helper loaded: common_helper
INFO - 2020-02-25 17:27:30 --> Helper loaded: language_helper
INFO - 2020-02-25 17:27:30 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:27:30 --> Helper loaded: email_helper
INFO - 2020-02-25 17:27:30 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:27:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:27:30 --> Parser Class Initialized
INFO - 2020-02-25 17:27:30 --> User Agent Class Initialized
INFO - 2020-02-25 17:27:30 --> Model Class Initialized
INFO - 2020-02-25 17:27:30 --> Database Driver Class Initialized
INFO - 2020-02-25 17:27:30 --> Model Class Initialized
DEBUG - 2020-02-25 17:27:30 --> Template Class Initialized
INFO - 2020-02-25 17:27:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:27:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:27:30 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:27:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:27:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:27:31 --> Encryption Class Initialized
INFO - 2020-02-25 17:27:31 --> Controller Class Initialized
DEBUG - 2020-02-25 17:27:31 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:27:31 --> Model Class Initialized
ERROR - 2020-02-25 17:27:31 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:27:31 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:27:31 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:27:31 --> Model Class Initialized
DEBUG - 2020-02-25 17:27:31 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:27:31 --> Model Class Initialized
DEBUG - 2020-02-25 17:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:27:31 --> Final output sent to browser
DEBUG - 2020-02-25 17:27:31 --> Total execution time: 0.9901
INFO - 2020-02-25 17:28:42 --> Config Class Initialized
INFO - 2020-02-25 17:28:42 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:28:42 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:28:42 --> Utf8 Class Initialized
INFO - 2020-02-25 17:28:42 --> URI Class Initialized
INFO - 2020-02-25 17:28:42 --> Router Class Initialized
INFO - 2020-02-25 17:28:42 --> Output Class Initialized
INFO - 2020-02-25 17:28:42 --> Security Class Initialized
DEBUG - 2020-02-25 17:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:28:42 --> CSRF cookie sent
INFO - 2020-02-25 17:28:42 --> Input Class Initialized
INFO - 2020-02-25 17:28:42 --> Language Class Initialized
INFO - 2020-02-25 17:28:42 --> Language Class Initialized
INFO - 2020-02-25 17:28:42 --> Config Class Initialized
INFO - 2020-02-25 17:28:42 --> Loader Class Initialized
INFO - 2020-02-25 17:28:42 --> Helper loaded: url_helper
INFO - 2020-02-25 17:28:42 --> Helper loaded: common_helper
INFO - 2020-02-25 17:28:42 --> Helper loaded: language_helper
INFO - 2020-02-25 17:28:42 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:28:42 --> Helper loaded: email_helper
INFO - 2020-02-25 17:28:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:28:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:28:42 --> Parser Class Initialized
INFO - 2020-02-25 17:28:42 --> User Agent Class Initialized
INFO - 2020-02-25 17:28:42 --> Model Class Initialized
INFO - 2020-02-25 17:28:42 --> Database Driver Class Initialized
INFO - 2020-02-25 17:28:42 --> Model Class Initialized
DEBUG - 2020-02-25 17:28:42 --> Template Class Initialized
INFO - 2020-02-25 17:28:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:28:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:28:43 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:28:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:28:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:28:43 --> Encryption Class Initialized
INFO - 2020-02-25 17:28:43 --> Controller Class Initialized
DEBUG - 2020-02-25 17:28:43 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:28:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:28:43 --> Model Class Initialized
ERROR - 2020-02-25 17:28:43 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:28:43 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:28:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:28:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:28:43 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:28:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:28:43 --> Model Class Initialized
DEBUG - 2020-02-25 17:28:43 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:28:43 --> Model Class Initialized
DEBUG - 2020-02-25 17:28:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:28:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:28:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:28:43 --> Final output sent to browser
DEBUG - 2020-02-25 17:28:43 --> Total execution time: 1.0758
INFO - 2020-02-25 17:34:15 --> Config Class Initialized
INFO - 2020-02-25 17:34:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:34:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:34:15 --> Utf8 Class Initialized
INFO - 2020-02-25 17:34:15 --> URI Class Initialized
INFO - 2020-02-25 17:34:15 --> Router Class Initialized
INFO - 2020-02-25 17:34:15 --> Output Class Initialized
INFO - 2020-02-25 17:34:15 --> Security Class Initialized
DEBUG - 2020-02-25 17:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:34:15 --> CSRF cookie sent
INFO - 2020-02-25 17:34:15 --> Input Class Initialized
INFO - 2020-02-25 17:34:15 --> Language Class Initialized
INFO - 2020-02-25 17:34:15 --> Language Class Initialized
INFO - 2020-02-25 17:34:15 --> Config Class Initialized
INFO - 2020-02-25 17:34:15 --> Loader Class Initialized
INFO - 2020-02-25 17:34:15 --> Helper loaded: url_helper
INFO - 2020-02-25 17:34:15 --> Helper loaded: common_helper
INFO - 2020-02-25 17:34:15 --> Helper loaded: language_helper
INFO - 2020-02-25 17:34:16 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:34:16 --> Helper loaded: email_helper
INFO - 2020-02-25 17:34:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:34:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:34:16 --> Parser Class Initialized
INFO - 2020-02-25 17:34:16 --> User Agent Class Initialized
INFO - 2020-02-25 17:34:16 --> Model Class Initialized
INFO - 2020-02-25 17:34:16 --> Database Driver Class Initialized
INFO - 2020-02-25 17:34:16 --> Model Class Initialized
DEBUG - 2020-02-25 17:34:16 --> Template Class Initialized
INFO - 2020-02-25 17:34:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:34:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:34:16 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:34:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:34:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:34:16 --> Encryption Class Initialized
INFO - 2020-02-25 17:34:16 --> Controller Class Initialized
DEBUG - 2020-02-25 17:34:16 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:34:16 --> Model Class Initialized
ERROR - 2020-02-25 17:34:16 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:34:16 --> Helper loaded: inflector_helper
INFO - 2020-02-25 17:34:18 --> Config Class Initialized
INFO - 2020-02-25 17:34:18 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:34:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:34:18 --> Utf8 Class Initialized
INFO - 2020-02-25 17:34:18 --> URI Class Initialized
INFO - 2020-02-25 17:34:18 --> Router Class Initialized
INFO - 2020-02-25 17:34:18 --> Output Class Initialized
INFO - 2020-02-25 17:34:18 --> Security Class Initialized
DEBUG - 2020-02-25 17:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:34:18 --> CSRF cookie sent
INFO - 2020-02-25 17:34:18 --> Input Class Initialized
INFO - 2020-02-25 17:34:18 --> Language Class Initialized
INFO - 2020-02-25 17:34:18 --> Language Class Initialized
INFO - 2020-02-25 17:34:18 --> Config Class Initialized
INFO - 2020-02-25 17:34:18 --> Loader Class Initialized
INFO - 2020-02-25 17:34:19 --> Helper loaded: url_helper
INFO - 2020-02-25 17:34:19 --> Helper loaded: common_helper
INFO - 2020-02-25 17:34:19 --> Helper loaded: language_helper
INFO - 2020-02-25 17:34:19 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:34:19 --> Helper loaded: email_helper
INFO - 2020-02-25 17:34:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:34:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:34:19 --> Parser Class Initialized
INFO - 2020-02-25 17:34:19 --> User Agent Class Initialized
INFO - 2020-02-25 17:34:19 --> Model Class Initialized
INFO - 2020-02-25 17:34:19 --> Database Driver Class Initialized
INFO - 2020-02-25 17:34:19 --> Model Class Initialized
DEBUG - 2020-02-25 17:34:19 --> Template Class Initialized
INFO - 2020-02-25 17:34:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:34:19 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:34:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:34:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:34:19 --> Encryption Class Initialized
INFO - 2020-02-25 17:34:19 --> Controller Class Initialized
DEBUG - 2020-02-25 17:34:19 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:34:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:34:19 --> Model Class Initialized
ERROR - 2020-02-25 17:34:19 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:34:19 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:34:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:34:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:34:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:34:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:34:19 --> Model Class Initialized
DEBUG - 2020-02-25 17:34:19 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:34:19 --> Model Class Initialized
DEBUG - 2020-02-25 17:34:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:34:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:34:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:34:19 --> Final output sent to browser
DEBUG - 2020-02-25 17:34:19 --> Total execution time: 1.0191
INFO - 2020-02-25 17:36:25 --> Config Class Initialized
INFO - 2020-02-25 17:36:25 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:36:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:36:25 --> Utf8 Class Initialized
INFO - 2020-02-25 17:36:25 --> URI Class Initialized
INFO - 2020-02-25 17:36:26 --> Router Class Initialized
INFO - 2020-02-25 17:36:26 --> Output Class Initialized
INFO - 2020-02-25 17:36:26 --> Security Class Initialized
DEBUG - 2020-02-25 17:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:36:26 --> CSRF cookie sent
INFO - 2020-02-25 17:36:26 --> Input Class Initialized
INFO - 2020-02-25 17:36:26 --> Language Class Initialized
INFO - 2020-02-25 17:36:26 --> Language Class Initialized
INFO - 2020-02-25 17:36:26 --> Config Class Initialized
INFO - 2020-02-25 17:36:26 --> Loader Class Initialized
INFO - 2020-02-25 17:36:26 --> Helper loaded: url_helper
INFO - 2020-02-25 17:36:26 --> Helper loaded: common_helper
INFO - 2020-02-25 17:36:26 --> Helper loaded: language_helper
INFO - 2020-02-25 17:36:26 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:36:26 --> Helper loaded: email_helper
INFO - 2020-02-25 17:36:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:36:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:36:26 --> Parser Class Initialized
INFO - 2020-02-25 17:36:26 --> User Agent Class Initialized
INFO - 2020-02-25 17:36:26 --> Model Class Initialized
INFO - 2020-02-25 17:36:26 --> Database Driver Class Initialized
INFO - 2020-02-25 17:36:26 --> Model Class Initialized
DEBUG - 2020-02-25 17:36:26 --> Template Class Initialized
INFO - 2020-02-25 17:36:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:36:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:36:26 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:36:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:36:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:36:26 --> Encryption Class Initialized
INFO - 2020-02-25 17:36:26 --> Controller Class Initialized
DEBUG - 2020-02-25 17:36:26 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:36:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:36:26 --> Model Class Initialized
ERROR - 2020-02-25 17:36:26 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:36:26 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:36:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:36:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:36:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:36:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:36:26 --> Model Class Initialized
DEBUG - 2020-02-25 17:36:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:36:26 --> Model Class Initialized
DEBUG - 2020-02-25 17:36:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:36:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:36:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:36:26 --> Final output sent to browser
DEBUG - 2020-02-25 17:36:26 --> Total execution time: 1.0170
INFO - 2020-02-25 17:36:55 --> Config Class Initialized
INFO - 2020-02-25 17:36:55 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:36:55 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:36:55 --> Utf8 Class Initialized
INFO - 2020-02-25 17:36:55 --> URI Class Initialized
INFO - 2020-02-25 17:36:55 --> Router Class Initialized
INFO - 2020-02-25 17:36:55 --> Output Class Initialized
INFO - 2020-02-25 17:36:55 --> Security Class Initialized
DEBUG - 2020-02-25 17:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:36:55 --> CSRF cookie sent
INFO - 2020-02-25 17:36:55 --> Input Class Initialized
INFO - 2020-02-25 17:36:55 --> Language Class Initialized
INFO - 2020-02-25 17:36:55 --> Language Class Initialized
INFO - 2020-02-25 17:36:55 --> Config Class Initialized
INFO - 2020-02-25 17:36:55 --> Loader Class Initialized
INFO - 2020-02-25 17:36:55 --> Helper loaded: url_helper
INFO - 2020-02-25 17:36:55 --> Helper loaded: common_helper
INFO - 2020-02-25 17:36:55 --> Helper loaded: language_helper
INFO - 2020-02-25 17:36:55 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:36:55 --> Helper loaded: email_helper
INFO - 2020-02-25 17:36:55 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:36:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:36:55 --> Parser Class Initialized
INFO - 2020-02-25 17:36:56 --> User Agent Class Initialized
INFO - 2020-02-25 17:36:56 --> Model Class Initialized
INFO - 2020-02-25 17:36:56 --> Database Driver Class Initialized
INFO - 2020-02-25 17:36:56 --> Model Class Initialized
DEBUG - 2020-02-25 17:36:56 --> Template Class Initialized
INFO - 2020-02-25 17:36:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:36:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:36:56 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:36:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:36:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:36:56 --> Encryption Class Initialized
INFO - 2020-02-25 17:36:56 --> Controller Class Initialized
DEBUG - 2020-02-25 17:36:56 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:36:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:36:56 --> Model Class Initialized
ERROR - 2020-02-25 17:36:56 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:36:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:36:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:36:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:36:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:36:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:36:56 --> Model Class Initialized
DEBUG - 2020-02-25 17:36:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:36:56 --> Model Class Initialized
DEBUG - 2020-02-25 17:36:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:36:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:36:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:36:56 --> Final output sent to browser
DEBUG - 2020-02-25 17:36:56 --> Total execution time: 1.0554
INFO - 2020-02-25 17:38:17 --> Config Class Initialized
INFO - 2020-02-25 17:38:17 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:38:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:38:17 --> Utf8 Class Initialized
INFO - 2020-02-25 17:38:17 --> URI Class Initialized
INFO - 2020-02-25 17:38:17 --> Router Class Initialized
INFO - 2020-02-25 17:38:17 --> Output Class Initialized
INFO - 2020-02-25 17:38:17 --> Security Class Initialized
DEBUG - 2020-02-25 17:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:38:17 --> CSRF cookie sent
INFO - 2020-02-25 17:38:17 --> Input Class Initialized
INFO - 2020-02-25 17:38:17 --> Language Class Initialized
INFO - 2020-02-25 17:38:17 --> Language Class Initialized
INFO - 2020-02-25 17:38:17 --> Config Class Initialized
INFO - 2020-02-25 17:38:17 --> Loader Class Initialized
INFO - 2020-02-25 17:38:18 --> Helper loaded: url_helper
INFO - 2020-02-25 17:38:18 --> Helper loaded: common_helper
INFO - 2020-02-25 17:38:18 --> Helper loaded: language_helper
INFO - 2020-02-25 17:38:18 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:38:18 --> Helper loaded: email_helper
INFO - 2020-02-25 17:38:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:38:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:38:18 --> Parser Class Initialized
INFO - 2020-02-25 17:38:18 --> User Agent Class Initialized
INFO - 2020-02-25 17:38:18 --> Model Class Initialized
INFO - 2020-02-25 17:38:18 --> Database Driver Class Initialized
INFO - 2020-02-25 17:38:18 --> Model Class Initialized
DEBUG - 2020-02-25 17:38:18 --> Template Class Initialized
INFO - 2020-02-25 17:38:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:38:18 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:38:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:38:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:38:18 --> Encryption Class Initialized
INFO - 2020-02-25 17:38:18 --> Controller Class Initialized
DEBUG - 2020-02-25 17:38:18 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:38:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:38:18 --> Model Class Initialized
ERROR - 2020-02-25 17:38:18 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:38:18 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:38:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:38:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:38:18 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:38:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:38:18 --> Model Class Initialized
DEBUG - 2020-02-25 17:38:18 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:38:18 --> Model Class Initialized
DEBUG - 2020-02-25 17:38:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:38:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:38:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:38:18 --> Final output sent to browser
DEBUG - 2020-02-25 17:38:18 --> Total execution time: 1.0317
INFO - 2020-02-25 17:38:30 --> Config Class Initialized
INFO - 2020-02-25 17:38:30 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:38:30 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:38:30 --> Utf8 Class Initialized
INFO - 2020-02-25 17:38:30 --> URI Class Initialized
INFO - 2020-02-25 17:38:30 --> Router Class Initialized
INFO - 2020-02-25 17:38:30 --> Output Class Initialized
INFO - 2020-02-25 17:38:30 --> Security Class Initialized
DEBUG - 2020-02-25 17:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:38:30 --> CSRF cookie sent
INFO - 2020-02-25 17:38:30 --> Input Class Initialized
INFO - 2020-02-25 17:38:30 --> Language Class Initialized
INFO - 2020-02-25 17:38:30 --> Language Class Initialized
INFO - 2020-02-25 17:38:30 --> Config Class Initialized
INFO - 2020-02-25 17:38:30 --> Loader Class Initialized
INFO - 2020-02-25 17:38:30 --> Helper loaded: url_helper
INFO - 2020-02-25 17:38:30 --> Helper loaded: common_helper
INFO - 2020-02-25 17:38:30 --> Helper loaded: language_helper
INFO - 2020-02-25 17:38:30 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:38:30 --> Helper loaded: email_helper
INFO - 2020-02-25 17:38:30 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:38:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:38:30 --> Parser Class Initialized
INFO - 2020-02-25 17:38:30 --> User Agent Class Initialized
INFO - 2020-02-25 17:38:30 --> Model Class Initialized
INFO - 2020-02-25 17:38:30 --> Database Driver Class Initialized
INFO - 2020-02-25 17:38:30 --> Model Class Initialized
DEBUG - 2020-02-25 17:38:30 --> Template Class Initialized
INFO - 2020-02-25 17:38:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:38:30 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:38:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:38:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:38:30 --> Encryption Class Initialized
INFO - 2020-02-25 17:38:30 --> Controller Class Initialized
DEBUG - 2020-02-25 17:38:30 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:38:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:38:30 --> Model Class Initialized
ERROR - 2020-02-25 17:38:31 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:38:31 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:38:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:38:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:38:31 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:38:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:38:31 --> Model Class Initialized
DEBUG - 2020-02-25 17:38:31 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:38:31 --> Model Class Initialized
DEBUG - 2020-02-25 17:38:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:38:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:38:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:38:31 --> Final output sent to browser
DEBUG - 2020-02-25 17:38:31 --> Total execution time: 1.1202
INFO - 2020-02-25 17:39:17 --> Config Class Initialized
INFO - 2020-02-25 17:39:17 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:39:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:39:17 --> Utf8 Class Initialized
INFO - 2020-02-25 17:39:17 --> URI Class Initialized
INFO - 2020-02-25 17:39:17 --> Router Class Initialized
INFO - 2020-02-25 17:39:17 --> Output Class Initialized
INFO - 2020-02-25 17:39:17 --> Security Class Initialized
DEBUG - 2020-02-25 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:39:17 --> CSRF cookie sent
INFO - 2020-02-25 17:39:17 --> Input Class Initialized
INFO - 2020-02-25 17:39:17 --> Language Class Initialized
INFO - 2020-02-25 17:39:17 --> Language Class Initialized
INFO - 2020-02-25 17:39:18 --> Config Class Initialized
INFO - 2020-02-25 17:39:18 --> Loader Class Initialized
INFO - 2020-02-25 17:39:18 --> Helper loaded: url_helper
INFO - 2020-02-25 17:39:18 --> Helper loaded: common_helper
INFO - 2020-02-25 17:39:18 --> Helper loaded: language_helper
INFO - 2020-02-25 17:39:18 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:39:18 --> Helper loaded: email_helper
INFO - 2020-02-25 17:39:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:39:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:39:18 --> Parser Class Initialized
INFO - 2020-02-25 17:39:18 --> User Agent Class Initialized
INFO - 2020-02-25 17:39:18 --> Model Class Initialized
INFO - 2020-02-25 17:39:18 --> Database Driver Class Initialized
INFO - 2020-02-25 17:39:18 --> Model Class Initialized
DEBUG - 2020-02-25 17:39:18 --> Template Class Initialized
INFO - 2020-02-25 17:39:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:39:18 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:39:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:39:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:39:18 --> Encryption Class Initialized
INFO - 2020-02-25 17:39:18 --> Controller Class Initialized
DEBUG - 2020-02-25 17:39:18 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:39:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:39:18 --> Model Class Initialized
ERROR - 2020-02-25 17:39:18 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:39:18 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:39:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:39:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:39:18 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:39:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:39:18 --> Model Class Initialized
DEBUG - 2020-02-25 17:39:18 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:39:18 --> Model Class Initialized
DEBUG - 2020-02-25 17:39:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:39:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:39:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:39:18 --> Final output sent to browser
DEBUG - 2020-02-25 17:39:18 --> Total execution time: 1.0297
INFO - 2020-02-25 17:39:58 --> Config Class Initialized
INFO - 2020-02-25 17:39:58 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:39:58 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:39:58 --> Utf8 Class Initialized
INFO - 2020-02-25 17:39:58 --> URI Class Initialized
INFO - 2020-02-25 17:39:58 --> Router Class Initialized
INFO - 2020-02-25 17:39:58 --> Output Class Initialized
INFO - 2020-02-25 17:39:58 --> Security Class Initialized
DEBUG - 2020-02-25 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:39:58 --> CSRF cookie sent
INFO - 2020-02-25 17:39:58 --> Input Class Initialized
INFO - 2020-02-25 17:39:58 --> Language Class Initialized
INFO - 2020-02-25 17:39:59 --> Language Class Initialized
INFO - 2020-02-25 17:39:59 --> Config Class Initialized
INFO - 2020-02-25 17:39:59 --> Loader Class Initialized
INFO - 2020-02-25 17:39:59 --> Helper loaded: url_helper
INFO - 2020-02-25 17:39:59 --> Helper loaded: common_helper
INFO - 2020-02-25 17:39:59 --> Helper loaded: language_helper
INFO - 2020-02-25 17:39:59 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:39:59 --> Helper loaded: email_helper
INFO - 2020-02-25 17:39:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:39:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:39:59 --> Parser Class Initialized
INFO - 2020-02-25 17:39:59 --> User Agent Class Initialized
INFO - 2020-02-25 17:39:59 --> Model Class Initialized
INFO - 2020-02-25 17:39:59 --> Database Driver Class Initialized
INFO - 2020-02-25 17:39:59 --> Model Class Initialized
DEBUG - 2020-02-25 17:39:59 --> Template Class Initialized
INFO - 2020-02-25 17:39:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:39:59 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:39:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:39:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:39:59 --> Encryption Class Initialized
INFO - 2020-02-25 17:39:59 --> Controller Class Initialized
DEBUG - 2020-02-25 17:39:59 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:39:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:39:59 --> Model Class Initialized
ERROR - 2020-02-25 17:39:59 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:39:59 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:39:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:39:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:39:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:39:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:39:59 --> Model Class Initialized
DEBUG - 2020-02-25 17:39:59 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:39:59 --> Model Class Initialized
DEBUG - 2020-02-25 17:39:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:39:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:39:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:39:59 --> Final output sent to browser
DEBUG - 2020-02-25 17:39:59 --> Total execution time: 1.0502
INFO - 2020-02-25 17:43:38 --> Config Class Initialized
INFO - 2020-02-25 17:43:38 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:43:38 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:43:38 --> Utf8 Class Initialized
INFO - 2020-02-25 17:43:38 --> URI Class Initialized
INFO - 2020-02-25 17:43:38 --> Router Class Initialized
INFO - 2020-02-25 17:43:38 --> Output Class Initialized
INFO - 2020-02-25 17:43:38 --> Security Class Initialized
DEBUG - 2020-02-25 17:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:43:38 --> CSRF cookie sent
INFO - 2020-02-25 17:43:38 --> Input Class Initialized
INFO - 2020-02-25 17:43:38 --> Language Class Initialized
INFO - 2020-02-25 17:43:38 --> Language Class Initialized
INFO - 2020-02-25 17:43:38 --> Config Class Initialized
INFO - 2020-02-25 17:43:38 --> Loader Class Initialized
INFO - 2020-02-25 17:43:38 --> Helper loaded: url_helper
INFO - 2020-02-25 17:43:38 --> Helper loaded: common_helper
INFO - 2020-02-25 17:43:38 --> Helper loaded: language_helper
INFO - 2020-02-25 17:43:38 --> Helper loaded: cookie_helper
INFO - 2020-02-25 17:43:38 --> Helper loaded: email_helper
INFO - 2020-02-25 17:43:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-25 17:43:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-25 17:43:38 --> Parser Class Initialized
INFO - 2020-02-25 17:43:38 --> User Agent Class Initialized
INFO - 2020-02-25 17:43:38 --> Model Class Initialized
INFO - 2020-02-25 17:43:38 --> Database Driver Class Initialized
INFO - 2020-02-25 17:43:38 --> Model Class Initialized
DEBUG - 2020-02-25 17:43:38 --> Template Class Initialized
INFO - 2020-02-25 17:43:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-25 17:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:43:38 --> Pagination Class Initialized
DEBUG - 2020-02-25 17:43:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-25 17:43:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-25 17:43:38 --> Encryption Class Initialized
INFO - 2020-02-25 17:43:38 --> Controller Class Initialized
DEBUG - 2020-02-25 17:43:38 --> category MX_Controller Initialized
DEBUG - 2020-02-25 17:43:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:43:38 --> Model Class Initialized
ERROR - 2020-02-25 17:43:38 --> Could not find the language line "Sorting"
INFO - 2020-02-25 17:43:38 --> Helper loaded: inflector_helper
DEBUG - 2020-02-25 17:43:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-25 17:43:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-25 17:43:38 --> blocks MX_Controller Initialized
DEBUG - 2020-02-25 17:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-25 17:43:39 --> Model Class Initialized
DEBUG - 2020-02-25 17:43:39 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-25 17:43:39 --> Model Class Initialized
DEBUG - 2020-02-25 17:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-25 17:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-25 17:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-25 17:43:39 --> Final output sent to browser
DEBUG - 2020-02-25 17:43:39 --> Total execution time: 1.0406
