<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-17 00:12:03 --> Config Class Initialized
INFO - 2020-03-17 00:12:03 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:12:03 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:12:03 --> Utf8 Class Initialized
INFO - 2020-03-17 00:12:03 --> URI Class Initialized
DEBUG - 2020-03-17 00:12:03 --> No URI present. Default controller set.
INFO - 2020-03-17 00:12:03 --> Router Class Initialized
INFO - 2020-03-17 00:12:03 --> Output Class Initialized
INFO - 2020-03-17 00:12:03 --> Security Class Initialized
DEBUG - 2020-03-17 00:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:12:03 --> CSRF cookie sent
INFO - 2020-03-17 00:12:03 --> Input Class Initialized
INFO - 2020-03-17 00:12:03 --> Language Class Initialized
INFO - 2020-03-17 00:12:03 --> Language Class Initialized
INFO - 2020-03-17 00:12:03 --> Config Class Initialized
INFO - 2020-03-17 00:12:03 --> Loader Class Initialized
INFO - 2020-03-17 00:12:03 --> Helper loaded: url_helper
INFO - 2020-03-17 00:12:03 --> Helper loaded: common_helper
INFO - 2020-03-17 00:12:04 --> Helper loaded: language_helper
INFO - 2020-03-17 00:12:04 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:12:04 --> Helper loaded: email_helper
INFO - 2020-03-17 00:12:04 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:12:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:12:04 --> Parser Class Initialized
INFO - 2020-03-17 00:12:04 --> User Agent Class Initialized
INFO - 2020-03-17 00:12:04 --> Model Class Initialized
INFO - 2020-03-17 00:12:04 --> Database Driver Class Initialized
INFO - 2020-03-17 00:12:04 --> Model Class Initialized
DEBUG - 2020-03-17 00:12:04 --> Template Class Initialized
INFO - 2020-03-17 00:12:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:12:04 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:12:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:12:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:12:04 --> Encryption Class Initialized
DEBUG - 2020-03-17 00:12:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:12:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-17 00:12:04 --> Controller Class Initialized
DEBUG - 2020-03-17 00:12:04 --> pergo MX_Controller Initialized
DEBUG - 2020-03-17 00:12:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:12:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-17 00:12:04 --> Model Class Initialized
INFO - 2020-03-17 00:12:04 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:12:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-17 00:12:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-17 00:12:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-17 00:12:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-17 00:12:05 --> Final output sent to browser
DEBUG - 2020-03-17 00:12:05 --> Total execution time: 2.2827
INFO - 2020-03-17 00:12:09 --> Config Class Initialized
INFO - 2020-03-17 00:12:09 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:12:09 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:12:09 --> Utf8 Class Initialized
INFO - 2020-03-17 00:12:09 --> URI Class Initialized
INFO - 2020-03-17 00:12:09 --> Router Class Initialized
INFO - 2020-03-17 00:12:09 --> Output Class Initialized
INFO - 2020-03-17 00:12:09 --> Security Class Initialized
DEBUG - 2020-03-17 00:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:12:09 --> CSRF cookie sent
INFO - 2020-03-17 00:12:09 --> Input Class Initialized
INFO - 2020-03-17 00:12:09 --> Language Class Initialized
INFO - 2020-03-17 00:12:09 --> Language Class Initialized
INFO - 2020-03-17 00:12:09 --> Config Class Initialized
INFO - 2020-03-17 00:12:09 --> Loader Class Initialized
INFO - 2020-03-17 00:12:09 --> Helper loaded: url_helper
INFO - 2020-03-17 00:12:09 --> Helper loaded: common_helper
INFO - 2020-03-17 00:12:09 --> Helper loaded: language_helper
INFO - 2020-03-17 00:12:09 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:12:09 --> Helper loaded: email_helper
INFO - 2020-03-17 00:12:09 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:12:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:12:09 --> Parser Class Initialized
INFO - 2020-03-17 00:12:09 --> User Agent Class Initialized
INFO - 2020-03-17 00:12:09 --> Model Class Initialized
INFO - 2020-03-17 00:12:09 --> Database Driver Class Initialized
INFO - 2020-03-17 00:12:09 --> Model Class Initialized
DEBUG - 2020-03-17 00:12:09 --> Template Class Initialized
INFO - 2020-03-17 00:12:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:12:09 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:12:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:12:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:12:09 --> Encryption Class Initialized
INFO - 2020-03-17 00:12:09 --> Controller Class Initialized
DEBUG - 2020-03-17 00:12:09 --> package MX_Controller Initialized
DEBUG - 2020-03-17 00:12:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-17 00:12:09 --> Model Class Initialized
INFO - 2020-03-17 00:12:09 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:12:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:12:10 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:12:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:12:10 --> Model Class Initialized
DEBUG - 2020-03-17 00:12:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:12:10 --> Model Class Initialized
DEBUG - 2020-03-17 00:12:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-17 00:12:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:12:10 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:12:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:12:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:12:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:12:10 --> Final output sent to browser
DEBUG - 2020-03-17 00:12:10 --> Total execution time: 1.4979
INFO - 2020-03-17 00:12:20 --> Config Class Initialized
INFO - 2020-03-17 00:12:20 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:12:20 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:12:20 --> Utf8 Class Initialized
INFO - 2020-03-17 00:12:20 --> URI Class Initialized
INFO - 2020-03-17 00:12:20 --> Router Class Initialized
INFO - 2020-03-17 00:12:20 --> Output Class Initialized
INFO - 2020-03-17 00:12:20 --> Security Class Initialized
DEBUG - 2020-03-17 00:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:12:20 --> CSRF cookie sent
INFO - 2020-03-17 00:12:20 --> Input Class Initialized
INFO - 2020-03-17 00:12:20 --> Language Class Initialized
INFO - 2020-03-17 00:12:20 --> Language Class Initialized
INFO - 2020-03-17 00:12:20 --> Config Class Initialized
INFO - 2020-03-17 00:12:20 --> Loader Class Initialized
INFO - 2020-03-17 00:12:20 --> Helper loaded: url_helper
INFO - 2020-03-17 00:12:20 --> Helper loaded: common_helper
INFO - 2020-03-17 00:12:20 --> Helper loaded: language_helper
INFO - 2020-03-17 00:12:20 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:12:20 --> Helper loaded: email_helper
INFO - 2020-03-17 00:12:20 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:12:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:12:20 --> Parser Class Initialized
INFO - 2020-03-17 00:12:20 --> User Agent Class Initialized
INFO - 2020-03-17 00:12:20 --> Model Class Initialized
INFO - 2020-03-17 00:12:20 --> Database Driver Class Initialized
INFO - 2020-03-17 00:12:20 --> Model Class Initialized
DEBUG - 2020-03-17 00:12:20 --> Template Class Initialized
INFO - 2020-03-17 00:12:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:12:20 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:12:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:12:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:12:20 --> Encryption Class Initialized
INFO - 2020-03-17 00:12:20 --> Controller Class Initialized
DEBUG - 2020-03-17 00:12:20 --> auth MX_Controller Initialized
DEBUG - 2020-03-17 00:12:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-17 00:12:20 --> Model Class Initialized
DEBUG - 2020-03-17 00:12:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-17 00:12:20 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:12:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-17 00:12:20 --> pergo MX_Controller Initialized
DEBUG - 2020-03-17 00:12:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:12:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-17 00:12:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-17 00:12:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-17 00:12:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-17 00:12:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-17 00:12:20 --> Final output sent to browser
DEBUG - 2020-03-17 00:12:20 --> Total execution time: 0.7610
INFO - 2020-03-17 00:12:23 --> Config Class Initialized
INFO - 2020-03-17 00:12:23 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:12:23 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:12:23 --> Utf8 Class Initialized
INFO - 2020-03-17 00:12:23 --> URI Class Initialized
INFO - 2020-03-17 00:12:23 --> Router Class Initialized
INFO - 2020-03-17 00:12:23 --> Output Class Initialized
INFO - 2020-03-17 00:12:23 --> Security Class Initialized
DEBUG - 2020-03-17 00:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:12:23 --> CSRF cookie sent
INFO - 2020-03-17 00:12:23 --> CSRF token verified
INFO - 2020-03-17 00:12:23 --> Input Class Initialized
INFO - 2020-03-17 00:12:23 --> Language Class Initialized
INFO - 2020-03-17 00:12:23 --> Language Class Initialized
INFO - 2020-03-17 00:12:23 --> Config Class Initialized
INFO - 2020-03-17 00:12:23 --> Loader Class Initialized
INFO - 2020-03-17 00:12:23 --> Helper loaded: url_helper
INFO - 2020-03-17 00:12:23 --> Helper loaded: common_helper
INFO - 2020-03-17 00:12:23 --> Helper loaded: language_helper
INFO - 2020-03-17 00:12:23 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:12:23 --> Helper loaded: email_helper
INFO - 2020-03-17 00:12:23 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:12:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:12:23 --> Parser Class Initialized
INFO - 2020-03-17 00:12:23 --> User Agent Class Initialized
INFO - 2020-03-17 00:12:23 --> Model Class Initialized
INFO - 2020-03-17 00:12:23 --> Database Driver Class Initialized
INFO - 2020-03-17 00:12:23 --> Model Class Initialized
DEBUG - 2020-03-17 00:12:23 --> Template Class Initialized
INFO - 2020-03-17 00:12:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:12:23 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:12:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:12:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:12:23 --> Encryption Class Initialized
INFO - 2020-03-17 00:12:23 --> Controller Class Initialized
DEBUG - 2020-03-17 00:12:23 --> auth MX_Controller Initialized
DEBUG - 2020-03-17 00:12:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-17 00:12:23 --> Model Class Initialized
INFO - 2020-03-17 00:13:00 --> Config Class Initialized
INFO - 2020-03-17 00:13:00 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:13:00 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:13:00 --> Utf8 Class Initialized
INFO - 2020-03-17 00:13:00 --> URI Class Initialized
INFO - 2020-03-17 00:13:00 --> Router Class Initialized
INFO - 2020-03-17 00:13:00 --> Output Class Initialized
INFO - 2020-03-17 00:13:00 --> Security Class Initialized
DEBUG - 2020-03-17 00:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:13:00 --> CSRF cookie sent
INFO - 2020-03-17 00:13:00 --> CSRF token verified
INFO - 2020-03-17 00:13:00 --> Input Class Initialized
INFO - 2020-03-17 00:13:00 --> Language Class Initialized
INFO - 2020-03-17 00:13:00 --> Language Class Initialized
INFO - 2020-03-17 00:13:00 --> Config Class Initialized
INFO - 2020-03-17 00:13:00 --> Loader Class Initialized
INFO - 2020-03-17 00:13:00 --> Helper loaded: url_helper
INFO - 2020-03-17 00:13:00 --> Helper loaded: common_helper
INFO - 2020-03-17 00:13:00 --> Helper loaded: language_helper
INFO - 2020-03-17 00:13:00 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:13:00 --> Helper loaded: email_helper
INFO - 2020-03-17 00:13:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:13:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:13:01 --> Parser Class Initialized
INFO - 2020-03-17 00:13:01 --> User Agent Class Initialized
INFO - 2020-03-17 00:13:01 --> Model Class Initialized
INFO - 2020-03-17 00:13:01 --> Database Driver Class Initialized
INFO - 2020-03-17 00:13:01 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:01 --> Template Class Initialized
INFO - 2020-03-17 00:13:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:13:01 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:13:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:13:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:13:01 --> Encryption Class Initialized
INFO - 2020-03-17 00:13:01 --> Controller Class Initialized
DEBUG - 2020-03-17 00:13:01 --> auth MX_Controller Initialized
DEBUG - 2020-03-17 00:13:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-17 00:13:01 --> Model Class Initialized
INFO - 2020-03-17 00:13:16 --> Config Class Initialized
INFO - 2020-03-17 00:13:16 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:13:16 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:13:16 --> Utf8 Class Initialized
INFO - 2020-03-17 00:13:16 --> URI Class Initialized
INFO - 2020-03-17 00:13:16 --> Router Class Initialized
INFO - 2020-03-17 00:13:16 --> Output Class Initialized
INFO - 2020-03-17 00:13:16 --> Security Class Initialized
DEBUG - 2020-03-17 00:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:13:16 --> CSRF cookie sent
INFO - 2020-03-17 00:13:16 --> CSRF token verified
INFO - 2020-03-17 00:13:16 --> Input Class Initialized
INFO - 2020-03-17 00:13:16 --> Language Class Initialized
INFO - 2020-03-17 00:13:16 --> Language Class Initialized
INFO - 2020-03-17 00:13:16 --> Config Class Initialized
INFO - 2020-03-17 00:13:16 --> Loader Class Initialized
INFO - 2020-03-17 00:13:16 --> Helper loaded: url_helper
INFO - 2020-03-17 00:13:16 --> Helper loaded: common_helper
INFO - 2020-03-17 00:13:16 --> Helper loaded: language_helper
INFO - 2020-03-17 00:13:16 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:13:16 --> Helper loaded: email_helper
INFO - 2020-03-17 00:13:16 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:13:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:13:17 --> Parser Class Initialized
INFO - 2020-03-17 00:13:17 --> User Agent Class Initialized
INFO - 2020-03-17 00:13:17 --> Model Class Initialized
INFO - 2020-03-17 00:13:17 --> Database Driver Class Initialized
INFO - 2020-03-17 00:13:17 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:17 --> Template Class Initialized
INFO - 2020-03-17 00:13:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:13:17 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:13:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:13:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:13:17 --> Encryption Class Initialized
INFO - 2020-03-17 00:13:17 --> Controller Class Initialized
DEBUG - 2020-03-17 00:13:17 --> auth MX_Controller Initialized
DEBUG - 2020-03-17 00:13:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-17 00:13:17 --> Model Class Initialized
INFO - 2020-03-17 00:13:22 --> Config Class Initialized
INFO - 2020-03-17 00:13:22 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:13:22 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:13:22 --> Utf8 Class Initialized
INFO - 2020-03-17 00:13:22 --> URI Class Initialized
INFO - 2020-03-17 00:13:22 --> Router Class Initialized
INFO - 2020-03-17 00:13:22 --> Output Class Initialized
INFO - 2020-03-17 00:13:22 --> Security Class Initialized
DEBUG - 2020-03-17 00:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:13:22 --> CSRF cookie sent
INFO - 2020-03-17 00:13:22 --> Input Class Initialized
INFO - 2020-03-17 00:13:22 --> Language Class Initialized
INFO - 2020-03-17 00:13:22 --> Language Class Initialized
INFO - 2020-03-17 00:13:22 --> Config Class Initialized
INFO - 2020-03-17 00:13:22 --> Loader Class Initialized
INFO - 2020-03-17 00:13:22 --> Helper loaded: url_helper
INFO - 2020-03-17 00:13:22 --> Helper loaded: common_helper
INFO - 2020-03-17 00:13:22 --> Helper loaded: language_helper
INFO - 2020-03-17 00:13:22 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:13:22 --> Helper loaded: email_helper
INFO - 2020-03-17 00:13:22 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:13:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:13:22 --> Parser Class Initialized
INFO - 2020-03-17 00:13:22 --> User Agent Class Initialized
INFO - 2020-03-17 00:13:22 --> Model Class Initialized
INFO - 2020-03-17 00:13:22 --> Database Driver Class Initialized
INFO - 2020-03-17 00:13:22 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:22 --> Template Class Initialized
INFO - 2020-03-17 00:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:13:22 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:13:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:13:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:13:22 --> Encryption Class Initialized
INFO - 2020-03-17 00:13:22 --> Controller Class Initialized
DEBUG - 2020-03-17 00:13:22 --> statistics MX_Controller Initialized
DEBUG - 2020-03-17 00:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-17 00:13:22 --> Model Class Initialized
ERROR - 2020-03-17 00:13:22 --> Could not find the language line "Pending"
ERROR - 2020-03-17 00:13:22 --> Could not find the language line "Pending"
INFO - 2020-03-17 00:13:22 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 00:13:23 --> Could not find the language line "total_orders"
ERROR - 2020-03-17 00:13:23 --> Could not find the language line "total_orders"
ERROR - 2020-03-17 00:13:23 --> Could not find the language line "Pending"
DEBUG - 2020-03-17 00:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-17 00:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:13:23 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:13:23 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:13:23 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 00:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 00:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 00:13:23 --> Final output sent to browser
DEBUG - 2020-03-17 00:13:23 --> Total execution time: 1.2236
INFO - 2020-03-17 00:13:29 --> Config Class Initialized
INFO - 2020-03-17 00:13:29 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:13:29 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:13:29 --> Utf8 Class Initialized
INFO - 2020-03-17 00:13:30 --> URI Class Initialized
INFO - 2020-03-17 00:13:30 --> Router Class Initialized
INFO - 2020-03-17 00:13:30 --> Output Class Initialized
INFO - 2020-03-17 00:13:30 --> Security Class Initialized
DEBUG - 2020-03-17 00:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:13:30 --> CSRF cookie sent
INFO - 2020-03-17 00:13:30 --> Input Class Initialized
INFO - 2020-03-17 00:13:30 --> Language Class Initialized
INFO - 2020-03-17 00:13:30 --> Language Class Initialized
INFO - 2020-03-17 00:13:30 --> Config Class Initialized
INFO - 2020-03-17 00:13:30 --> Loader Class Initialized
INFO - 2020-03-17 00:13:30 --> Helper loaded: url_helper
INFO - 2020-03-17 00:13:30 --> Helper loaded: common_helper
INFO - 2020-03-17 00:13:30 --> Helper loaded: language_helper
INFO - 2020-03-17 00:13:30 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:13:30 --> Helper loaded: email_helper
INFO - 2020-03-17 00:13:30 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:13:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:13:30 --> Parser Class Initialized
INFO - 2020-03-17 00:13:30 --> User Agent Class Initialized
INFO - 2020-03-17 00:13:30 --> Model Class Initialized
INFO - 2020-03-17 00:13:30 --> Database Driver Class Initialized
INFO - 2020-03-17 00:13:30 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:30 --> Template Class Initialized
INFO - 2020-03-17 00:13:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:13:30 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:13:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:13:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:13:30 --> Encryption Class Initialized
INFO - 2020-03-17 00:13:30 --> Controller Class Initialized
DEBUG - 2020-03-17 00:13:30 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 00:13:30 --> Model Class Initialized
INFO - 2020-03-17 00:13:30 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:13:30 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:13:30 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:13:30 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 00:13:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 00:13:30 --> Final output sent to browser
DEBUG - 2020-03-17 00:13:31 --> Total execution time: 1.0578
INFO - 2020-03-17 00:13:34 --> Config Class Initialized
INFO - 2020-03-17 00:13:34 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:13:34 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:13:34 --> Utf8 Class Initialized
INFO - 2020-03-17 00:13:34 --> URI Class Initialized
INFO - 2020-03-17 00:13:34 --> Router Class Initialized
INFO - 2020-03-17 00:13:34 --> Output Class Initialized
INFO - 2020-03-17 00:13:34 --> Security Class Initialized
DEBUG - 2020-03-17 00:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:13:34 --> CSRF cookie sent
INFO - 2020-03-17 00:13:34 --> Input Class Initialized
INFO - 2020-03-17 00:13:34 --> Language Class Initialized
INFO - 2020-03-17 00:13:34 --> Language Class Initialized
INFO - 2020-03-17 00:13:34 --> Config Class Initialized
INFO - 2020-03-17 00:13:34 --> Loader Class Initialized
INFO - 2020-03-17 00:13:34 --> Helper loaded: url_helper
INFO - 2020-03-17 00:13:34 --> Helper loaded: common_helper
INFO - 2020-03-17 00:13:34 --> Helper loaded: language_helper
INFO - 2020-03-17 00:13:34 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:13:34 --> Helper loaded: email_helper
INFO - 2020-03-17 00:13:34 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:13:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:13:34 --> Parser Class Initialized
INFO - 2020-03-17 00:13:34 --> User Agent Class Initialized
INFO - 2020-03-17 00:13:34 --> Model Class Initialized
INFO - 2020-03-17 00:13:34 --> Database Driver Class Initialized
INFO - 2020-03-17 00:13:34 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:34 --> Template Class Initialized
INFO - 2020-03-17 00:13:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:13:34 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:13:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:13:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:13:34 --> Encryption Class Initialized
INFO - 2020-03-17 00:13:34 --> Controller Class Initialized
DEBUG - 2020-03-17 00:13:34 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 00:13:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 00:13:34 --> Model Class Initialized
INFO - 2020-03-17 00:13:34 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:13:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-17 00:13:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/stripe.php
DEBUG - 2020-03-17 00:13:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-17 00:13:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:13:34 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:13:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:13:34 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:13:34 --> Model Class Initialized
DEBUG - 2020-03-17 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 00:13:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 00:13:35 --> Final output sent to browser
DEBUG - 2020-03-17 00:13:35 --> Total execution time: 0.8070
INFO - 2020-03-17 00:14:01 --> Config Class Initialized
INFO - 2020-03-17 00:14:01 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:14:01 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:14:01 --> Utf8 Class Initialized
INFO - 2020-03-17 00:14:01 --> URI Class Initialized
INFO - 2020-03-17 00:14:01 --> Router Class Initialized
INFO - 2020-03-17 00:14:02 --> Output Class Initialized
INFO - 2020-03-17 00:14:02 --> Security Class Initialized
DEBUG - 2020-03-17 00:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:14:02 --> CSRF cookie sent
INFO - 2020-03-17 00:14:02 --> CSRF token verified
INFO - 2020-03-17 00:14:02 --> Input Class Initialized
INFO - 2020-03-17 00:14:02 --> Language Class Initialized
INFO - 2020-03-17 00:14:02 --> Language Class Initialized
INFO - 2020-03-17 00:14:02 --> Config Class Initialized
INFO - 2020-03-17 00:14:02 --> Loader Class Initialized
INFO - 2020-03-17 00:14:02 --> Helper loaded: url_helper
INFO - 2020-03-17 00:14:02 --> Helper loaded: common_helper
INFO - 2020-03-17 00:14:02 --> Helper loaded: language_helper
INFO - 2020-03-17 00:14:02 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:14:02 --> Helper loaded: email_helper
INFO - 2020-03-17 00:14:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:14:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:14:02 --> Parser Class Initialized
INFO - 2020-03-17 00:14:02 --> User Agent Class Initialized
INFO - 2020-03-17 00:14:02 --> Model Class Initialized
INFO - 2020-03-17 00:14:02 --> Database Driver Class Initialized
INFO - 2020-03-17 00:14:02 --> Model Class Initialized
DEBUG - 2020-03-17 00:14:02 --> Template Class Initialized
INFO - 2020-03-17 00:14:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:14:02 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:14:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:14:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:14:02 --> Encryption Class Initialized
INFO - 2020-03-17 00:14:02 --> Controller Class Initialized
DEBUG - 2020-03-17 00:14:02 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 00:14:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 00:14:02 --> Model Class Initialized
INFO - 2020-03-17 00:14:08 --> Config Class Initialized
INFO - 2020-03-17 00:14:08 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:14:08 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:14:08 --> Utf8 Class Initialized
INFO - 2020-03-17 00:14:08 --> URI Class Initialized
INFO - 2020-03-17 00:14:08 --> Router Class Initialized
INFO - 2020-03-17 00:14:08 --> Output Class Initialized
INFO - 2020-03-17 00:14:08 --> Security Class Initialized
DEBUG - 2020-03-17 00:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:14:08 --> CSRF cookie sent
INFO - 2020-03-17 00:14:08 --> Input Class Initialized
INFO - 2020-03-17 00:14:08 --> Language Class Initialized
INFO - 2020-03-17 00:14:08 --> Language Class Initialized
INFO - 2020-03-17 00:14:08 --> Config Class Initialized
INFO - 2020-03-17 00:14:08 --> Loader Class Initialized
INFO - 2020-03-17 00:14:08 --> Helper loaded: url_helper
INFO - 2020-03-17 00:14:08 --> Helper loaded: common_helper
INFO - 2020-03-17 00:14:08 --> Helper loaded: language_helper
INFO - 2020-03-17 00:14:08 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:14:08 --> Helper loaded: email_helper
INFO - 2020-03-17 00:14:08 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:14:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:14:08 --> Parser Class Initialized
INFO - 2020-03-17 00:14:08 --> User Agent Class Initialized
INFO - 2020-03-17 00:14:08 --> Model Class Initialized
INFO - 2020-03-17 00:14:08 --> Database Driver Class Initialized
INFO - 2020-03-17 00:14:08 --> Model Class Initialized
DEBUG - 2020-03-17 00:14:08 --> Template Class Initialized
INFO - 2020-03-17 00:14:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:14:08 --> Pagination Class Initialized
INFO - 2020-03-17 00:14:08 --> Config Class Initialized
INFO - 2020-03-17 00:14:08 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:14:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:14:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-03-17 00:14:08 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:14:08 --> Encryption Class Initialized
INFO - 2020-03-17 00:14:08 --> Utf8 Class Initialized
INFO - 2020-03-17 00:14:08 --> Controller Class Initialized
INFO - 2020-03-17 00:14:08 --> URI Class Initialized
DEBUG - 2020-03-17 00:14:08 --> setting MX_Controller Initialized
INFO - 2020-03-17 00:14:08 --> Router Class Initialized
DEBUG - 2020-03-17 00:14:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 00:14:08 --> Output Class Initialized
INFO - 2020-03-17 00:14:08 --> Model Class Initialized
INFO - 2020-03-17 00:14:08 --> Security Class Initialized
INFO - 2020-03-17 00:14:08 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:14:08 --> CSRF cookie sent
INFO - 2020-03-17 00:14:08 --> CSRF token verified
DEBUG - 2020-03-17 00:14:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
INFO - 2020-03-17 00:14:08 --> Input Class Initialized
INFO - 2020-03-17 00:14:08 --> Language Class Initialized
DEBUG - 2020-03-17 00:14:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/stripe.php
DEBUG - 2020-03-17 00:14:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-17 00:14:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
INFO - 2020-03-17 00:14:08 --> Language Class Initialized
INFO - 2020-03-17 00:14:08 --> Config Class Initialized
DEBUG - 2020-03-17 00:14:08 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:14:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:14:08 --> Loader Class Initialized
INFO - 2020-03-17 00:14:08 --> Model Class Initialized
INFO - 2020-03-17 00:14:08 --> Helper loaded: url_helper
DEBUG - 2020-03-17 00:14:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:14:09 --> Helper loaded: common_helper
INFO - 2020-03-17 00:14:09 --> Model Class Initialized
INFO - 2020-03-17 00:14:09 --> Helper loaded: language_helper
INFO - 2020-03-17 00:14:09 --> Helper loaded: cookie_helper
DEBUG - 2020-03-17 00:14:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
INFO - 2020-03-17 00:14:09 --> Helper loaded: email_helper
INFO - 2020-03-17 00:14:09 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:14:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:14:09 --> Parser Class Initialized
DEBUG - 2020-03-17 00:14:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 00:14:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 00:14:09 --> User Agent Class Initialized
INFO - 2020-03-17 00:14:09 --> Final output sent to browser
INFO - 2020-03-17 00:14:09 --> Model Class Initialized
DEBUG - 2020-03-17 00:14:09 --> Total execution time: 0.8600
INFO - 2020-03-17 00:14:09 --> Database Driver Class Initialized
INFO - 2020-03-17 00:14:09 --> Model Class Initialized
DEBUG - 2020-03-17 00:14:09 --> Template Class Initialized
INFO - 2020-03-17 00:14:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:14:09 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:14:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:14:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:14:09 --> Encryption Class Initialized
INFO - 2020-03-17 00:14:09 --> Controller Class Initialized
DEBUG - 2020-03-17 00:14:09 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:14:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:14:09 --> Model Class Initialized
INFO - 2020-03-17 00:14:09 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 00:14:09 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 00:14:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 00:14:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:14:09 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:14:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:14:09 --> Model Class Initialized
DEBUG - 2020-03-17 00:14:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:14:09 --> Model Class Initialized
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:14:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:14:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:14:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:14:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:14:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:14:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:14:09 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:14:10 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:14:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:14:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:14:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:14:10 --> Final output sent to browser
DEBUG - 2020-03-17 00:14:10 --> Total execution time: 1.3478
INFO - 2020-03-17 00:14:19 --> Config Class Initialized
INFO - 2020-03-17 00:14:19 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:14:19 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:14:19 --> Utf8 Class Initialized
INFO - 2020-03-17 00:14:19 --> URI Class Initialized
INFO - 2020-03-17 00:14:19 --> Router Class Initialized
INFO - 2020-03-17 00:14:19 --> Output Class Initialized
INFO - 2020-03-17 00:14:19 --> Security Class Initialized
DEBUG - 2020-03-17 00:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:14:19 --> CSRF cookie sent
INFO - 2020-03-17 00:14:19 --> CSRF token verified
INFO - 2020-03-17 00:14:19 --> Input Class Initialized
INFO - 2020-03-17 00:14:19 --> Language Class Initialized
INFO - 2020-03-17 00:14:19 --> Language Class Initialized
INFO - 2020-03-17 00:14:19 --> Config Class Initialized
INFO - 2020-03-17 00:14:19 --> Loader Class Initialized
INFO - 2020-03-17 00:14:19 --> Helper loaded: url_helper
INFO - 2020-03-17 00:14:19 --> Helper loaded: common_helper
INFO - 2020-03-17 00:14:19 --> Helper loaded: language_helper
INFO - 2020-03-17 00:14:19 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:14:19 --> Helper loaded: email_helper
INFO - 2020-03-17 00:14:19 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:14:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:14:19 --> Parser Class Initialized
INFO - 2020-03-17 00:14:19 --> User Agent Class Initialized
INFO - 2020-03-17 00:14:19 --> Model Class Initialized
INFO - 2020-03-17 00:14:19 --> Database Driver Class Initialized
INFO - 2020-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2020-03-17 00:14:19 --> Template Class Initialized
INFO - 2020-03-17 00:14:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:14:19 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:14:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:14:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:14:19 --> Encryption Class Initialized
INFO - 2020-03-17 00:14:20 --> Controller Class Initialized
DEBUG - 2020-03-17 00:14:20 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:14:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:14:20 --> Model Class Initialized
DEBUG - 2020-03-17 00:14:20 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:14:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 00:14:20 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 00:14:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 00:14:20 --> Final output sent to browser
DEBUG - 2020-03-17 00:14:20 --> Total execution time: 1.0156
INFO - 2020-03-17 00:14:31 --> Config Class Initialized
INFO - 2020-03-17 00:14:31 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:14:31 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:14:31 --> Utf8 Class Initialized
INFO - 2020-03-17 00:14:31 --> URI Class Initialized
INFO - 2020-03-17 00:14:31 --> Router Class Initialized
INFO - 2020-03-17 00:14:31 --> Output Class Initialized
INFO - 2020-03-17 00:14:31 --> Security Class Initialized
DEBUG - 2020-03-17 00:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:14:31 --> Input Class Initialized
INFO - 2020-03-17 00:14:31 --> Language Class Initialized
INFO - 2020-03-17 00:14:31 --> Language Class Initialized
INFO - 2020-03-17 00:14:31 --> Config Class Initialized
INFO - 2020-03-17 00:14:31 --> Loader Class Initialized
INFO - 2020-03-17 00:14:31 --> Helper loaded: url_helper
INFO - 2020-03-17 00:14:31 --> Helper loaded: common_helper
INFO - 2020-03-17 00:14:31 --> Helper loaded: language_helper
INFO - 2020-03-17 00:14:31 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:14:31 --> Helper loaded: email_helper
INFO - 2020-03-17 00:14:31 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:14:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:14:32 --> Parser Class Initialized
INFO - 2020-03-17 00:14:32 --> User Agent Class Initialized
INFO - 2020-03-17 00:14:32 --> Model Class Initialized
INFO - 2020-03-17 00:14:32 --> Database Driver Class Initialized
INFO - 2020-03-17 00:14:32 --> Model Class Initialized
DEBUG - 2020-03-17 00:14:32 --> Template Class Initialized
INFO - 2020-03-17 00:14:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:14:32 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:14:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:14:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:14:32 --> Encryption Class Initialized
INFO - 2020-03-17 00:14:32 --> Controller Class Initialized
DEBUG - 2020-03-17 00:14:32 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:14:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:14:32 --> Model Class Initialized
ERROR - 2020-03-17 00:14:34 --> Severity: error --> Exception: As per Indian regulations, export transactions require a customer name and address. More info here: https://stripe.com/docs/india-exports D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\libraries\stripe\stripe\stripe-php\lib\Exception\ApiErrorException.php 38
INFO - 2020-03-17 00:21:06 --> Config Class Initialized
INFO - 2020-03-17 00:21:06 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:21:06 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:21:06 --> Utf8 Class Initialized
INFO - 2020-03-17 00:21:06 --> URI Class Initialized
INFO - 2020-03-17 00:21:06 --> Router Class Initialized
INFO - 2020-03-17 00:21:06 --> Output Class Initialized
INFO - 2020-03-17 00:21:06 --> Security Class Initialized
DEBUG - 2020-03-17 00:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:21:06 --> CSRF cookie sent
INFO - 2020-03-17 00:21:06 --> Input Class Initialized
INFO - 2020-03-17 00:21:06 --> Language Class Initialized
INFO - 2020-03-17 00:21:06 --> Language Class Initialized
INFO - 2020-03-17 00:21:06 --> Config Class Initialized
INFO - 2020-03-17 00:21:06 --> Loader Class Initialized
INFO - 2020-03-17 00:21:06 --> Helper loaded: url_helper
INFO - 2020-03-17 00:21:06 --> Helper loaded: common_helper
INFO - 2020-03-17 00:21:06 --> Helper loaded: language_helper
INFO - 2020-03-17 00:21:06 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:21:06 --> Helper loaded: email_helper
INFO - 2020-03-17 00:21:06 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:21:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:21:06 --> Parser Class Initialized
INFO - 2020-03-17 00:21:06 --> User Agent Class Initialized
INFO - 2020-03-17 00:21:06 --> Model Class Initialized
INFO - 2020-03-17 00:21:06 --> Database Driver Class Initialized
INFO - 2020-03-17 00:21:06 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:07 --> Template Class Initialized
INFO - 2020-03-17 00:21:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:21:07 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:21:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:21:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:21:07 --> Encryption Class Initialized
INFO - 2020-03-17 00:21:07 --> Controller Class Initialized
DEBUG - 2020-03-17 00:21:07 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:21:07 --> Model Class Initialized
INFO - 2020-03-17 00:21:07 --> Config Class Initialized
INFO - 2020-03-17 00:21:07 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:21:07 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:21:07 --> Utf8 Class Initialized
INFO - 2020-03-17 00:21:07 --> URI Class Initialized
DEBUG - 2020-03-17 00:21:07 --> No URI present. Default controller set.
INFO - 2020-03-17 00:21:07 --> Router Class Initialized
INFO - 2020-03-17 00:21:07 --> Output Class Initialized
INFO - 2020-03-17 00:21:07 --> Security Class Initialized
DEBUG - 2020-03-17 00:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:21:07 --> CSRF cookie sent
INFO - 2020-03-17 00:21:07 --> Input Class Initialized
INFO - 2020-03-17 00:21:07 --> Language Class Initialized
INFO - 2020-03-17 00:21:07 --> Language Class Initialized
INFO - 2020-03-17 00:21:07 --> Config Class Initialized
INFO - 2020-03-17 00:21:07 --> Loader Class Initialized
INFO - 2020-03-17 00:21:07 --> Helper loaded: url_helper
INFO - 2020-03-17 00:21:07 --> Helper loaded: common_helper
INFO - 2020-03-17 00:21:07 --> Helper loaded: language_helper
INFO - 2020-03-17 00:21:07 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:21:07 --> Helper loaded: email_helper
INFO - 2020-03-17 00:21:07 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:21:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:21:07 --> Parser Class Initialized
INFO - 2020-03-17 00:21:07 --> User Agent Class Initialized
INFO - 2020-03-17 00:21:07 --> Model Class Initialized
INFO - 2020-03-17 00:21:07 --> Database Driver Class Initialized
INFO - 2020-03-17 00:21:07 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:07 --> Template Class Initialized
INFO - 2020-03-17 00:21:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:21:07 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:21:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:21:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:21:07 --> Encryption Class Initialized
DEBUG - 2020-03-17 00:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-17 00:21:07 --> Controller Class Initialized
DEBUG - 2020-03-17 00:21:07 --> pergo MX_Controller Initialized
DEBUG - 2020-03-17 00:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-17 00:21:07 --> Model Class Initialized
INFO - 2020-03-17 00:21:07 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-17 00:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-17 00:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-17 00:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-17 00:21:08 --> Final output sent to browser
DEBUG - 2020-03-17 00:21:08 --> Total execution time: 0.8205
INFO - 2020-03-17 00:21:15 --> Config Class Initialized
INFO - 2020-03-17 00:21:15 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:21:15 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:21:15 --> Utf8 Class Initialized
INFO - 2020-03-17 00:21:15 --> URI Class Initialized
INFO - 2020-03-17 00:21:15 --> Router Class Initialized
INFO - 2020-03-17 00:21:15 --> Output Class Initialized
INFO - 2020-03-17 00:21:15 --> Security Class Initialized
DEBUG - 2020-03-17 00:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:21:15 --> CSRF cookie sent
INFO - 2020-03-17 00:21:15 --> Input Class Initialized
INFO - 2020-03-17 00:21:15 --> Language Class Initialized
INFO - 2020-03-17 00:21:15 --> Language Class Initialized
INFO - 2020-03-17 00:21:15 --> Config Class Initialized
INFO - 2020-03-17 00:21:15 --> Loader Class Initialized
INFO - 2020-03-17 00:21:15 --> Helper loaded: url_helper
INFO - 2020-03-17 00:21:15 --> Helper loaded: common_helper
INFO - 2020-03-17 00:21:15 --> Helper loaded: language_helper
INFO - 2020-03-17 00:21:15 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:21:15 --> Helper loaded: email_helper
INFO - 2020-03-17 00:21:15 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:21:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:21:15 --> Parser Class Initialized
INFO - 2020-03-17 00:21:15 --> User Agent Class Initialized
INFO - 2020-03-17 00:21:15 --> Model Class Initialized
INFO - 2020-03-17 00:21:15 --> Database Driver Class Initialized
INFO - 2020-03-17 00:21:15 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:15 --> Template Class Initialized
INFO - 2020-03-17 00:21:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:21:15 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:21:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:21:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:21:15 --> Encryption Class Initialized
INFO - 2020-03-17 00:21:15 --> Controller Class Initialized
DEBUG - 2020-03-17 00:21:15 --> package MX_Controller Initialized
DEBUG - 2020-03-17 00:21:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-17 00:21:15 --> Model Class Initialized
INFO - 2020-03-17 00:21:15 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:21:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:21:15 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:21:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:21:15 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:21:15 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-17 00:21:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-17 00:21:15 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:16 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:21:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:21:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:21:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:21:16 --> Final output sent to browser
DEBUG - 2020-03-17 00:21:16 --> Total execution time: 1.1039
INFO - 2020-03-17 00:21:19 --> Config Class Initialized
INFO - 2020-03-17 00:21:19 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:21:19 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:21:19 --> Utf8 Class Initialized
INFO - 2020-03-17 00:21:19 --> URI Class Initialized
INFO - 2020-03-17 00:21:19 --> Router Class Initialized
INFO - 2020-03-17 00:21:19 --> Output Class Initialized
INFO - 2020-03-17 00:21:19 --> Security Class Initialized
DEBUG - 2020-03-17 00:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:21:19 --> CSRF cookie sent
INFO - 2020-03-17 00:21:19 --> CSRF token verified
INFO - 2020-03-17 00:21:19 --> Input Class Initialized
INFO - 2020-03-17 00:21:19 --> Language Class Initialized
INFO - 2020-03-17 00:21:19 --> Language Class Initialized
INFO - 2020-03-17 00:21:19 --> Config Class Initialized
INFO - 2020-03-17 00:21:19 --> Loader Class Initialized
INFO - 2020-03-17 00:21:19 --> Helper loaded: url_helper
INFO - 2020-03-17 00:21:19 --> Helper loaded: common_helper
INFO - 2020-03-17 00:21:19 --> Helper loaded: language_helper
INFO - 2020-03-17 00:21:19 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:21:19 --> Helper loaded: email_helper
INFO - 2020-03-17 00:21:19 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:21:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:21:19 --> Parser Class Initialized
INFO - 2020-03-17 00:21:19 --> User Agent Class Initialized
INFO - 2020-03-17 00:21:19 --> Model Class Initialized
INFO - 2020-03-17 00:21:19 --> Database Driver Class Initialized
INFO - 2020-03-17 00:21:19 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:19 --> Template Class Initialized
INFO - 2020-03-17 00:21:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:21:19 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:21:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:21:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:21:19 --> Encryption Class Initialized
INFO - 2020-03-17 00:21:19 --> Controller Class Initialized
DEBUG - 2020-03-17 00:21:19 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:21:19 --> Model Class Initialized
INFO - 2020-03-17 00:21:19 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 00:21:19 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 00:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 00:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:21:19 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:21:19 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:21:19 --> Model Class Initialized
ERROR - 2020-03-17 00:21:19 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:19 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:21:20 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:21:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:21:20 --> Final output sent to browser
DEBUG - 2020-03-17 00:21:20 --> Total execution time: 1.1445
INFO - 2020-03-17 00:21:30 --> Config Class Initialized
INFO - 2020-03-17 00:21:30 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:21:30 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:21:30 --> Utf8 Class Initialized
INFO - 2020-03-17 00:21:30 --> URI Class Initialized
INFO - 2020-03-17 00:21:30 --> Router Class Initialized
INFO - 2020-03-17 00:21:30 --> Output Class Initialized
INFO - 2020-03-17 00:21:30 --> Security Class Initialized
DEBUG - 2020-03-17 00:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:21:30 --> CSRF cookie sent
INFO - 2020-03-17 00:21:30 --> CSRF token verified
INFO - 2020-03-17 00:21:30 --> Input Class Initialized
INFO - 2020-03-17 00:21:30 --> Language Class Initialized
INFO - 2020-03-17 00:21:30 --> Language Class Initialized
INFO - 2020-03-17 00:21:30 --> Config Class Initialized
INFO - 2020-03-17 00:21:30 --> Loader Class Initialized
INFO - 2020-03-17 00:21:30 --> Helper loaded: url_helper
INFO - 2020-03-17 00:21:30 --> Helper loaded: common_helper
INFO - 2020-03-17 00:21:30 --> Helper loaded: language_helper
INFO - 2020-03-17 00:21:30 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:21:30 --> Helper loaded: email_helper
INFO - 2020-03-17 00:21:30 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:21:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:21:30 --> Parser Class Initialized
INFO - 2020-03-17 00:21:30 --> User Agent Class Initialized
INFO - 2020-03-17 00:21:30 --> Model Class Initialized
INFO - 2020-03-17 00:21:30 --> Database Driver Class Initialized
INFO - 2020-03-17 00:21:30 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:30 --> Template Class Initialized
INFO - 2020-03-17 00:21:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:21:30 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:21:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:21:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:21:30 --> Encryption Class Initialized
INFO - 2020-03-17 00:21:30 --> Controller Class Initialized
DEBUG - 2020-03-17 00:21:30 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:21:30 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:30 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 00:21:30 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 00:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 00:21:30 --> Final output sent to browser
DEBUG - 2020-03-17 00:21:30 --> Total execution time: 0.6463
INFO - 2020-03-17 00:21:43 --> Config Class Initialized
INFO - 2020-03-17 00:21:43 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:21:43 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:21:43 --> Utf8 Class Initialized
INFO - 2020-03-17 00:21:43 --> URI Class Initialized
INFO - 2020-03-17 00:21:43 --> Router Class Initialized
INFO - 2020-03-17 00:21:43 --> Output Class Initialized
INFO - 2020-03-17 00:21:43 --> Security Class Initialized
DEBUG - 2020-03-17 00:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:21:43 --> Input Class Initialized
INFO - 2020-03-17 00:21:43 --> Language Class Initialized
INFO - 2020-03-17 00:21:43 --> Language Class Initialized
INFO - 2020-03-17 00:21:43 --> Config Class Initialized
INFO - 2020-03-17 00:21:43 --> Loader Class Initialized
INFO - 2020-03-17 00:21:43 --> Helper loaded: url_helper
INFO - 2020-03-17 00:21:43 --> Helper loaded: common_helper
INFO - 2020-03-17 00:21:43 --> Helper loaded: language_helper
INFO - 2020-03-17 00:21:43 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:21:43 --> Helper loaded: email_helper
INFO - 2020-03-17 00:21:43 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:21:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:21:43 --> Parser Class Initialized
INFO - 2020-03-17 00:21:43 --> User Agent Class Initialized
INFO - 2020-03-17 00:21:44 --> Model Class Initialized
INFO - 2020-03-17 00:21:44 --> Database Driver Class Initialized
INFO - 2020-03-17 00:21:44 --> Model Class Initialized
DEBUG - 2020-03-17 00:21:44 --> Template Class Initialized
INFO - 2020-03-17 00:21:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:21:44 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:21:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:21:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:21:44 --> Encryption Class Initialized
INFO - 2020-03-17 00:21:44 --> Controller Class Initialized
DEBUG - 2020-03-17 00:21:44 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:21:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:21:44 --> Model Class Initialized
INFO - 2020-03-17 00:28:53 --> Config Class Initialized
INFO - 2020-03-17 00:28:53 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:28:53 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:28:53 --> Utf8 Class Initialized
INFO - 2020-03-17 00:28:53 --> URI Class Initialized
INFO - 2020-03-17 00:28:53 --> Router Class Initialized
INFO - 2020-03-17 00:28:53 --> Output Class Initialized
INFO - 2020-03-17 00:28:53 --> Security Class Initialized
DEBUG - 2020-03-17 00:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:28:53 --> Input Class Initialized
INFO - 2020-03-17 00:28:53 --> Language Class Initialized
INFO - 2020-03-17 00:28:53 --> Language Class Initialized
INFO - 2020-03-17 00:28:53 --> Config Class Initialized
INFO - 2020-03-17 00:28:53 --> Loader Class Initialized
INFO - 2020-03-17 00:28:53 --> Helper loaded: url_helper
INFO - 2020-03-17 00:28:53 --> Helper loaded: common_helper
INFO - 2020-03-17 00:28:53 --> Helper loaded: language_helper
INFO - 2020-03-17 00:28:53 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:28:53 --> Helper loaded: email_helper
INFO - 2020-03-17 00:28:53 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:28:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:28:53 --> Parser Class Initialized
INFO - 2020-03-17 00:28:53 --> User Agent Class Initialized
INFO - 2020-03-17 00:28:53 --> Model Class Initialized
INFO - 2020-03-17 00:28:54 --> Database Driver Class Initialized
INFO - 2020-03-17 00:28:54 --> Model Class Initialized
DEBUG - 2020-03-17 00:28:54 --> Template Class Initialized
INFO - 2020-03-17 00:28:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:28:54 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:28:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:28:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:28:54 --> Encryption Class Initialized
INFO - 2020-03-17 00:28:54 --> Controller Class Initialized
DEBUG - 2020-03-17 00:28:54 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:28:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:28:54 --> Model Class Initialized
INFO - 2020-03-17 00:29:56 --> Config Class Initialized
INFO - 2020-03-17 00:29:56 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:29:56 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:29:56 --> Utf8 Class Initialized
INFO - 2020-03-17 00:29:56 --> URI Class Initialized
INFO - 2020-03-17 00:29:56 --> Router Class Initialized
INFO - 2020-03-17 00:29:56 --> Output Class Initialized
INFO - 2020-03-17 00:29:56 --> Security Class Initialized
DEBUG - 2020-03-17 00:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:29:56 --> CSRF cookie sent
INFO - 2020-03-17 00:29:56 --> CSRF token verified
INFO - 2020-03-17 00:29:56 --> Input Class Initialized
INFO - 2020-03-17 00:29:56 --> Language Class Initialized
INFO - 2020-03-17 00:29:56 --> Language Class Initialized
INFO - 2020-03-17 00:29:56 --> Config Class Initialized
INFO - 2020-03-17 00:29:56 --> Loader Class Initialized
INFO - 2020-03-17 00:29:56 --> Helper loaded: url_helper
INFO - 2020-03-17 00:29:56 --> Helper loaded: common_helper
INFO - 2020-03-17 00:29:56 --> Helper loaded: language_helper
INFO - 2020-03-17 00:29:56 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:29:56 --> Helper loaded: email_helper
INFO - 2020-03-17 00:29:56 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:29:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:29:56 --> Parser Class Initialized
INFO - 2020-03-17 00:29:56 --> User Agent Class Initialized
INFO - 2020-03-17 00:29:56 --> Model Class Initialized
INFO - 2020-03-17 00:29:56 --> Database Driver Class Initialized
INFO - 2020-03-17 00:29:56 --> Model Class Initialized
DEBUG - 2020-03-17 00:29:56 --> Template Class Initialized
INFO - 2020-03-17 00:29:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:29:57 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:29:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:29:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:29:57 --> Encryption Class Initialized
INFO - 2020-03-17 00:29:57 --> Controller Class Initialized
DEBUG - 2020-03-17 00:29:57 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 00:29:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 00:29:57 --> Model Class Initialized
INFO - 2020-03-17 00:30:02 --> Config Class Initialized
INFO - 2020-03-17 00:30:02 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:30:02 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:30:02 --> Utf8 Class Initialized
INFO - 2020-03-17 00:30:02 --> URI Class Initialized
INFO - 2020-03-17 00:30:02 --> Router Class Initialized
INFO - 2020-03-17 00:30:02 --> Output Class Initialized
INFO - 2020-03-17 00:30:02 --> Security Class Initialized
DEBUG - 2020-03-17 00:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:30:02 --> CSRF cookie sent
INFO - 2020-03-17 00:30:02 --> Input Class Initialized
INFO - 2020-03-17 00:30:02 --> Language Class Initialized
INFO - 2020-03-17 00:30:02 --> Language Class Initialized
INFO - 2020-03-17 00:30:02 --> Config Class Initialized
INFO - 2020-03-17 00:30:02 --> Loader Class Initialized
INFO - 2020-03-17 00:30:02 --> Helper loaded: url_helper
INFO - 2020-03-17 00:30:02 --> Helper loaded: common_helper
INFO - 2020-03-17 00:30:02 --> Helper loaded: language_helper
INFO - 2020-03-17 00:30:02 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:30:02 --> Helper loaded: email_helper
INFO - 2020-03-17 00:30:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:30:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:30:02 --> Parser Class Initialized
INFO - 2020-03-17 00:30:02 --> User Agent Class Initialized
INFO - 2020-03-17 00:30:02 --> Model Class Initialized
INFO - 2020-03-17 00:30:02 --> Database Driver Class Initialized
INFO - 2020-03-17 00:30:02 --> Model Class Initialized
DEBUG - 2020-03-17 00:30:02 --> Template Class Initialized
INFO - 2020-03-17 00:30:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:30:02 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:30:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:30:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:30:02 --> Encryption Class Initialized
INFO - 2020-03-17 00:30:02 --> Controller Class Initialized
DEBUG - 2020-03-17 00:30:02 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 00:30:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 00:30:02 --> Model Class Initialized
INFO - 2020-03-17 00:30:02 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:30:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-17 00:30:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/stripe.php
DEBUG - 2020-03-17 00:30:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-17 00:30:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:30:02 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:30:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:30:02 --> Model Class Initialized
DEBUG - 2020-03-17 00:30:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:30:03 --> Model Class Initialized
DEBUG - 2020-03-17 00:30:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 00:30:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 00:30:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 00:30:03 --> Final output sent to browser
DEBUG - 2020-03-17 00:30:03 --> Total execution time: 0.8475
INFO - 2020-03-17 00:31:03 --> Config Class Initialized
INFO - 2020-03-17 00:31:03 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:31:03 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:31:03 --> Utf8 Class Initialized
INFO - 2020-03-17 00:31:03 --> URI Class Initialized
INFO - 2020-03-17 00:31:03 --> Router Class Initialized
INFO - 2020-03-17 00:31:03 --> Output Class Initialized
INFO - 2020-03-17 00:31:03 --> Security Class Initialized
DEBUG - 2020-03-17 00:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:31:03 --> CSRF cookie sent
INFO - 2020-03-17 00:31:03 --> CSRF token verified
INFO - 2020-03-17 00:31:03 --> Input Class Initialized
INFO - 2020-03-17 00:31:03 --> Language Class Initialized
INFO - 2020-03-17 00:31:03 --> Language Class Initialized
INFO - 2020-03-17 00:31:03 --> Config Class Initialized
INFO - 2020-03-17 00:31:03 --> Loader Class Initialized
INFO - 2020-03-17 00:31:03 --> Helper loaded: url_helper
INFO - 2020-03-17 00:31:03 --> Helper loaded: common_helper
INFO - 2020-03-17 00:31:03 --> Helper loaded: language_helper
INFO - 2020-03-17 00:31:03 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:31:03 --> Helper loaded: email_helper
INFO - 2020-03-17 00:31:03 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:31:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:31:03 --> Parser Class Initialized
INFO - 2020-03-17 00:31:03 --> User Agent Class Initialized
INFO - 2020-03-17 00:31:03 --> Model Class Initialized
INFO - 2020-03-17 00:31:03 --> Database Driver Class Initialized
INFO - 2020-03-17 00:31:03 --> Model Class Initialized
DEBUG - 2020-03-17 00:31:03 --> Template Class Initialized
INFO - 2020-03-17 00:31:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:31:03 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:31:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:31:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:31:03 --> Encryption Class Initialized
INFO - 2020-03-17 00:31:03 --> Controller Class Initialized
DEBUG - 2020-03-17 00:31:03 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:31:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:31:03 --> Model Class Initialized
INFO - 2020-03-17 00:31:03 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 00:31:03 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 00:31:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 00:31:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:31:03 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:31:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:31:03 --> Model Class Initialized
DEBUG - 2020-03-17 00:31:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:31:03 --> Model Class Initialized
ERROR - 2020-03-17 00:31:03 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:31:03 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:31:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:31:03 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:31:03 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:31:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:31:03 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:31:03 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:31:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:31:03 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:31:04 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:31:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:31:04 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:31:04 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:31:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:31:04 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:31:04 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:31:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:31:04 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:31:04 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:31:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:31:04 --> Final output sent to browser
DEBUG - 2020-03-17 00:31:04 --> Total execution time: 1.2124
INFO - 2020-03-17 00:31:12 --> Config Class Initialized
INFO - 2020-03-17 00:31:12 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:31:12 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:31:12 --> Utf8 Class Initialized
INFO - 2020-03-17 00:31:12 --> URI Class Initialized
INFO - 2020-03-17 00:31:12 --> Router Class Initialized
INFO - 2020-03-17 00:31:12 --> Output Class Initialized
INFO - 2020-03-17 00:31:13 --> Security Class Initialized
DEBUG - 2020-03-17 00:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:31:13 --> CSRF cookie sent
INFO - 2020-03-17 00:31:13 --> CSRF token verified
INFO - 2020-03-17 00:31:13 --> Input Class Initialized
INFO - 2020-03-17 00:31:13 --> Language Class Initialized
INFO - 2020-03-17 00:31:13 --> Language Class Initialized
INFO - 2020-03-17 00:31:13 --> Config Class Initialized
INFO - 2020-03-17 00:31:13 --> Loader Class Initialized
INFO - 2020-03-17 00:31:13 --> Helper loaded: url_helper
INFO - 2020-03-17 00:31:13 --> Helper loaded: common_helper
INFO - 2020-03-17 00:31:13 --> Helper loaded: language_helper
INFO - 2020-03-17 00:31:13 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:31:13 --> Helper loaded: email_helper
INFO - 2020-03-17 00:31:13 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:31:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:31:13 --> Parser Class Initialized
INFO - 2020-03-17 00:31:13 --> User Agent Class Initialized
INFO - 2020-03-17 00:31:13 --> Model Class Initialized
INFO - 2020-03-17 00:31:13 --> Database Driver Class Initialized
INFO - 2020-03-17 00:31:13 --> Model Class Initialized
DEBUG - 2020-03-17 00:31:13 --> Template Class Initialized
INFO - 2020-03-17 00:31:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:31:13 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:31:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:31:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:31:13 --> Encryption Class Initialized
INFO - 2020-03-17 00:31:13 --> Controller Class Initialized
DEBUG - 2020-03-17 00:31:13 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:31:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:31:13 --> Model Class Initialized
DEBUG - 2020-03-17 00:31:13 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:31:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 00:31:13 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 00:31:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 00:31:13 --> Final output sent to browser
DEBUG - 2020-03-17 00:31:13 --> Total execution time: 0.7006
INFO - 2020-03-17 00:31:27 --> Config Class Initialized
INFO - 2020-03-17 00:31:27 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:31:27 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:31:27 --> Utf8 Class Initialized
INFO - 2020-03-17 00:31:27 --> URI Class Initialized
INFO - 2020-03-17 00:31:27 --> Router Class Initialized
INFO - 2020-03-17 00:31:27 --> Output Class Initialized
INFO - 2020-03-17 00:31:27 --> Security Class Initialized
DEBUG - 2020-03-17 00:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:31:27 --> Input Class Initialized
INFO - 2020-03-17 00:31:27 --> Language Class Initialized
INFO - 2020-03-17 00:31:27 --> Language Class Initialized
INFO - 2020-03-17 00:31:27 --> Config Class Initialized
INFO - 2020-03-17 00:31:27 --> Loader Class Initialized
INFO - 2020-03-17 00:31:27 --> Helper loaded: url_helper
INFO - 2020-03-17 00:31:27 --> Helper loaded: common_helper
INFO - 2020-03-17 00:31:27 --> Helper loaded: language_helper
INFO - 2020-03-17 00:31:27 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:31:27 --> Helper loaded: email_helper
INFO - 2020-03-17 00:31:27 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:31:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:31:28 --> Parser Class Initialized
INFO - 2020-03-17 00:31:28 --> User Agent Class Initialized
INFO - 2020-03-17 00:31:28 --> Model Class Initialized
INFO - 2020-03-17 00:31:28 --> Database Driver Class Initialized
INFO - 2020-03-17 00:31:28 --> Model Class Initialized
DEBUG - 2020-03-17 00:31:28 --> Template Class Initialized
INFO - 2020-03-17 00:31:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:31:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:31:28 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:31:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:31:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:31:28 --> Encryption Class Initialized
INFO - 2020-03-17 00:31:28 --> Controller Class Initialized
DEBUG - 2020-03-17 00:31:28 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:31:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:31:28 --> Model Class Initialized
INFO - 2020-03-17 00:39:34 --> Config Class Initialized
INFO - 2020-03-17 00:39:34 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:39:34 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:39:34 --> Utf8 Class Initialized
INFO - 2020-03-17 00:39:34 --> URI Class Initialized
INFO - 2020-03-17 00:39:34 --> Router Class Initialized
INFO - 2020-03-17 00:39:34 --> Output Class Initialized
INFO - 2020-03-17 00:39:34 --> Security Class Initialized
DEBUG - 2020-03-17 00:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:39:34 --> CSRF cookie sent
INFO - 2020-03-17 00:39:34 --> CSRF token verified
INFO - 2020-03-17 00:39:34 --> Input Class Initialized
INFO - 2020-03-17 00:39:34 --> Language Class Initialized
INFO - 2020-03-17 00:39:34 --> Language Class Initialized
INFO - 2020-03-17 00:39:34 --> Config Class Initialized
INFO - 2020-03-17 00:39:34 --> Loader Class Initialized
INFO - 2020-03-17 00:39:34 --> Helper loaded: url_helper
INFO - 2020-03-17 00:39:34 --> Helper loaded: common_helper
INFO - 2020-03-17 00:39:34 --> Helper loaded: language_helper
INFO - 2020-03-17 00:39:34 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:39:34 --> Helper loaded: email_helper
INFO - 2020-03-17 00:39:34 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:39:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:39:34 --> Parser Class Initialized
INFO - 2020-03-17 00:39:34 --> User Agent Class Initialized
INFO - 2020-03-17 00:39:34 --> Model Class Initialized
INFO - 2020-03-17 00:39:34 --> Database Driver Class Initialized
INFO - 2020-03-17 00:39:34 --> Model Class Initialized
DEBUG - 2020-03-17 00:39:34 --> Template Class Initialized
INFO - 2020-03-17 00:39:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:39:34 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:39:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:39:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:39:34 --> Encryption Class Initialized
INFO - 2020-03-17 00:39:34 --> Controller Class Initialized
DEBUG - 2020-03-17 00:39:34 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:39:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:39:34 --> Model Class Initialized
DEBUG - 2020-03-17 00:39:35 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:39:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 00:39:35 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 00:39:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 00:39:35 --> Final output sent to browser
DEBUG - 2020-03-17 00:39:35 --> Total execution time: 0.6635
INFO - 2020-03-17 00:39:48 --> Config Class Initialized
INFO - 2020-03-17 00:39:48 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:39:48 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:39:48 --> Utf8 Class Initialized
INFO - 2020-03-17 00:39:48 --> URI Class Initialized
INFO - 2020-03-17 00:39:48 --> Router Class Initialized
INFO - 2020-03-17 00:39:48 --> Output Class Initialized
INFO - 2020-03-17 00:39:48 --> Security Class Initialized
DEBUG - 2020-03-17 00:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:39:48 --> Input Class Initialized
INFO - 2020-03-17 00:39:48 --> Language Class Initialized
INFO - 2020-03-17 00:39:48 --> Language Class Initialized
INFO - 2020-03-17 00:39:48 --> Config Class Initialized
INFO - 2020-03-17 00:39:48 --> Loader Class Initialized
INFO - 2020-03-17 00:39:48 --> Helper loaded: url_helper
INFO - 2020-03-17 00:39:48 --> Helper loaded: common_helper
INFO - 2020-03-17 00:39:48 --> Helper loaded: language_helper
INFO - 2020-03-17 00:39:48 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:39:48 --> Helper loaded: email_helper
INFO - 2020-03-17 00:39:48 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:39:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:39:48 --> Parser Class Initialized
INFO - 2020-03-17 00:39:48 --> User Agent Class Initialized
INFO - 2020-03-17 00:39:48 --> Model Class Initialized
INFO - 2020-03-17 00:39:48 --> Database Driver Class Initialized
INFO - 2020-03-17 00:39:48 --> Model Class Initialized
DEBUG - 2020-03-17 00:39:48 --> Template Class Initialized
INFO - 2020-03-17 00:39:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:39:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:39:48 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:39:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:39:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:39:48 --> Encryption Class Initialized
INFO - 2020-03-17 00:39:48 --> Controller Class Initialized
DEBUG - 2020-03-17 00:39:48 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:39:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:39:48 --> Model Class Initialized
INFO - 2020-03-17 00:42:40 --> Config Class Initialized
INFO - 2020-03-17 00:42:40 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:42:40 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:42:40 --> Utf8 Class Initialized
INFO - 2020-03-17 00:42:40 --> URI Class Initialized
INFO - 2020-03-17 00:42:40 --> Router Class Initialized
INFO - 2020-03-17 00:42:40 --> Output Class Initialized
INFO - 2020-03-17 00:42:40 --> Security Class Initialized
DEBUG - 2020-03-17 00:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:42:40 --> Input Class Initialized
INFO - 2020-03-17 00:42:40 --> Language Class Initialized
INFO - 2020-03-17 00:42:40 --> Language Class Initialized
INFO - 2020-03-17 00:42:40 --> Config Class Initialized
INFO - 2020-03-17 00:42:40 --> Loader Class Initialized
INFO - 2020-03-17 00:42:40 --> Helper loaded: url_helper
INFO - 2020-03-17 00:42:40 --> Helper loaded: common_helper
INFO - 2020-03-17 00:42:40 --> Helper loaded: language_helper
INFO - 2020-03-17 00:42:40 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:42:40 --> Helper loaded: email_helper
INFO - 2020-03-17 00:42:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:42:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:42:40 --> Parser Class Initialized
INFO - 2020-03-17 00:42:40 --> User Agent Class Initialized
INFO - 2020-03-17 00:42:40 --> Model Class Initialized
INFO - 2020-03-17 00:42:40 --> Database Driver Class Initialized
INFO - 2020-03-17 00:42:40 --> Model Class Initialized
DEBUG - 2020-03-17 00:42:40 --> Template Class Initialized
INFO - 2020-03-17 00:42:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:42:41 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:42:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:42:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:42:41 --> Encryption Class Initialized
INFO - 2020-03-17 00:42:41 --> Controller Class Initialized
DEBUG - 2020-03-17 00:42:41 --> stripe MX_Controller Initialized
ERROR - 2020-03-17 00:42:41 --> Severity: error --> Exception: syntax error, unexpected 'catch' (T_CATCH) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\libraries\stripeapi.php 81
INFO - 2020-03-17 00:43:10 --> Config Class Initialized
INFO - 2020-03-17 00:43:10 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:43:10 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:43:10 --> Utf8 Class Initialized
INFO - 2020-03-17 00:43:10 --> URI Class Initialized
INFO - 2020-03-17 00:43:10 --> Router Class Initialized
INFO - 2020-03-17 00:43:10 --> Output Class Initialized
INFO - 2020-03-17 00:43:10 --> Security Class Initialized
DEBUG - 2020-03-17 00:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:43:10 --> Input Class Initialized
INFO - 2020-03-17 00:43:10 --> Language Class Initialized
INFO - 2020-03-17 00:43:10 --> Language Class Initialized
INFO - 2020-03-17 00:43:10 --> Config Class Initialized
INFO - 2020-03-17 00:43:10 --> Loader Class Initialized
INFO - 2020-03-17 00:43:10 --> Helper loaded: url_helper
INFO - 2020-03-17 00:43:10 --> Helper loaded: common_helper
INFO - 2020-03-17 00:43:10 --> Helper loaded: language_helper
INFO - 2020-03-17 00:43:10 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:43:10 --> Helper loaded: email_helper
INFO - 2020-03-17 00:43:10 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:43:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:43:10 --> Parser Class Initialized
INFO - 2020-03-17 00:43:10 --> User Agent Class Initialized
INFO - 2020-03-17 00:43:10 --> Model Class Initialized
INFO - 2020-03-17 00:43:10 --> Database Driver Class Initialized
INFO - 2020-03-17 00:43:10 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:11 --> Template Class Initialized
INFO - 2020-03-17 00:43:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:43:11 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:43:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:43:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:43:11 --> Encryption Class Initialized
INFO - 2020-03-17 00:43:11 --> Controller Class Initialized
DEBUG - 2020-03-17 00:43:11 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:43:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:43:11 --> Model Class Initialized
ERROR - 2020-03-17 00:43:11 --> Severity: Notice --> Undefined variable: data_buyer_info D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\stripe.php 104
ERROR - 2020-03-17 00:43:13 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\stripe.php 115
DEBUG - 2020-03-17 00:43:13 --> orders MX_Controller Initialized
INFO - 2020-03-17 00:43:13 --> Config Class Initialized
INFO - 2020-03-17 00:43:13 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:43:13 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:43:13 --> Utf8 Class Initialized
INFO - 2020-03-17 00:43:13 --> URI Class Initialized
INFO - 2020-03-17 00:43:13 --> Router Class Initialized
INFO - 2020-03-17 00:43:13 --> Output Class Initialized
INFO - 2020-03-17 00:43:13 --> Security Class Initialized
DEBUG - 2020-03-17 00:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:43:13 --> CSRF cookie sent
INFO - 2020-03-17 00:43:13 --> Input Class Initialized
INFO - 2020-03-17 00:43:13 --> Language Class Initialized
INFO - 2020-03-17 00:43:13 --> Language Class Initialized
INFO - 2020-03-17 00:43:13 --> Config Class Initialized
INFO - 2020-03-17 00:43:13 --> Loader Class Initialized
INFO - 2020-03-17 00:43:13 --> Helper loaded: url_helper
INFO - 2020-03-17 00:43:13 --> Helper loaded: common_helper
INFO - 2020-03-17 00:43:13 --> Helper loaded: language_helper
INFO - 2020-03-17 00:43:13 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:43:13 --> Helper loaded: email_helper
INFO - 2020-03-17 00:43:13 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:43:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:43:13 --> Parser Class Initialized
INFO - 2020-03-17 00:43:13 --> User Agent Class Initialized
INFO - 2020-03-17 00:43:13 --> Model Class Initialized
INFO - 2020-03-17 00:43:13 --> Database Driver Class Initialized
INFO - 2020-03-17 00:43:13 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:13 --> Template Class Initialized
INFO - 2020-03-17 00:43:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:43:13 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:43:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:43:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:43:14 --> Encryption Class Initialized
INFO - 2020-03-17 00:43:14 --> Controller Class Initialized
DEBUG - 2020-03-17 00:43:14 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:43:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:43:14 --> Model Class Initialized
INFO - 2020-03-17 00:43:14 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:43:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-17 00:43:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:43:14 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:43:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:43:14 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:43:14 --> Model Class Initialized
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:14 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:43:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:43:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:43:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:43:14 --> Final output sent to browser
DEBUG - 2020-03-17 00:43:14 --> Total execution time: 1.0862
INFO - 2020-03-17 00:43:23 --> Config Class Initialized
INFO - 2020-03-17 00:43:23 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:43:23 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:43:23 --> Utf8 Class Initialized
INFO - 2020-03-17 00:43:23 --> URI Class Initialized
DEBUG - 2020-03-17 00:43:23 --> No URI present. Default controller set.
INFO - 2020-03-17 00:43:23 --> Router Class Initialized
INFO - 2020-03-17 00:43:23 --> Output Class Initialized
INFO - 2020-03-17 00:43:23 --> Security Class Initialized
DEBUG - 2020-03-17 00:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:43:23 --> CSRF cookie sent
INFO - 2020-03-17 00:43:23 --> Input Class Initialized
INFO - 2020-03-17 00:43:23 --> Language Class Initialized
INFO - 2020-03-17 00:43:23 --> Language Class Initialized
INFO - 2020-03-17 00:43:23 --> Config Class Initialized
INFO - 2020-03-17 00:43:23 --> Loader Class Initialized
INFO - 2020-03-17 00:43:23 --> Helper loaded: url_helper
INFO - 2020-03-17 00:43:23 --> Helper loaded: common_helper
INFO - 2020-03-17 00:43:23 --> Helper loaded: language_helper
INFO - 2020-03-17 00:43:23 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:43:23 --> Helper loaded: email_helper
INFO - 2020-03-17 00:43:23 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:43:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:43:23 --> Parser Class Initialized
INFO - 2020-03-17 00:43:23 --> User Agent Class Initialized
INFO - 2020-03-17 00:43:23 --> Model Class Initialized
INFO - 2020-03-17 00:43:23 --> Database Driver Class Initialized
INFO - 2020-03-17 00:43:23 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:23 --> Template Class Initialized
INFO - 2020-03-17 00:43:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:43:23 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:43:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:43:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:43:23 --> Encryption Class Initialized
DEBUG - 2020-03-17 00:43:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:43:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-17 00:43:23 --> Controller Class Initialized
DEBUG - 2020-03-17 00:43:23 --> pergo MX_Controller Initialized
DEBUG - 2020-03-17 00:43:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:43:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-17 00:43:23 --> Model Class Initialized
INFO - 2020-03-17 00:43:23 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:43:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-17 00:43:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-17 00:43:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-17 00:43:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-17 00:43:23 --> Final output sent to browser
DEBUG - 2020-03-17 00:43:23 --> Total execution time: 0.8158
INFO - 2020-03-17 00:43:26 --> Config Class Initialized
INFO - 2020-03-17 00:43:26 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:43:26 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:43:26 --> Utf8 Class Initialized
INFO - 2020-03-17 00:43:26 --> URI Class Initialized
INFO - 2020-03-17 00:43:26 --> Router Class Initialized
INFO - 2020-03-17 00:43:26 --> Output Class Initialized
INFO - 2020-03-17 00:43:26 --> Security Class Initialized
DEBUG - 2020-03-17 00:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:43:26 --> CSRF cookie sent
INFO - 2020-03-17 00:43:26 --> Input Class Initialized
INFO - 2020-03-17 00:43:26 --> Language Class Initialized
INFO - 2020-03-17 00:43:26 --> Language Class Initialized
INFO - 2020-03-17 00:43:26 --> Config Class Initialized
INFO - 2020-03-17 00:43:26 --> Loader Class Initialized
INFO - 2020-03-17 00:43:26 --> Helper loaded: url_helper
INFO - 2020-03-17 00:43:26 --> Helper loaded: common_helper
INFO - 2020-03-17 00:43:26 --> Helper loaded: language_helper
INFO - 2020-03-17 00:43:26 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:43:27 --> Helper loaded: email_helper
INFO - 2020-03-17 00:43:27 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:43:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:43:27 --> Parser Class Initialized
INFO - 2020-03-17 00:43:27 --> User Agent Class Initialized
INFO - 2020-03-17 00:43:27 --> Model Class Initialized
INFO - 2020-03-17 00:43:27 --> Database Driver Class Initialized
INFO - 2020-03-17 00:43:27 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:27 --> Template Class Initialized
INFO - 2020-03-17 00:43:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:43:27 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:43:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:43:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:43:27 --> Encryption Class Initialized
INFO - 2020-03-17 00:43:27 --> Controller Class Initialized
DEBUG - 2020-03-17 00:43:27 --> package MX_Controller Initialized
DEBUG - 2020-03-17 00:43:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-17 00:43:27 --> Model Class Initialized
INFO - 2020-03-17 00:43:27 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:43:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:43:27 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:43:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:43:27 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:43:27 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-17 00:43:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:27 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:43:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:43:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:43:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:43:27 --> Final output sent to browser
DEBUG - 2020-03-17 00:43:28 --> Total execution time: 1.3010
INFO - 2020-03-17 00:43:30 --> Config Class Initialized
INFO - 2020-03-17 00:43:30 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:43:30 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:43:30 --> Utf8 Class Initialized
INFO - 2020-03-17 00:43:30 --> URI Class Initialized
INFO - 2020-03-17 00:43:30 --> Router Class Initialized
INFO - 2020-03-17 00:43:30 --> Output Class Initialized
INFO - 2020-03-17 00:43:30 --> Security Class Initialized
DEBUG - 2020-03-17 00:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:43:31 --> CSRF cookie sent
INFO - 2020-03-17 00:43:31 --> CSRF token verified
INFO - 2020-03-17 00:43:31 --> Input Class Initialized
INFO - 2020-03-17 00:43:31 --> Language Class Initialized
INFO - 2020-03-17 00:43:31 --> Language Class Initialized
INFO - 2020-03-17 00:43:31 --> Config Class Initialized
INFO - 2020-03-17 00:43:31 --> Loader Class Initialized
INFO - 2020-03-17 00:43:31 --> Helper loaded: url_helper
INFO - 2020-03-17 00:43:31 --> Helper loaded: common_helper
INFO - 2020-03-17 00:43:31 --> Helper loaded: language_helper
INFO - 2020-03-17 00:43:31 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:43:31 --> Helper loaded: email_helper
INFO - 2020-03-17 00:43:31 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:43:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:43:31 --> Parser Class Initialized
INFO - 2020-03-17 00:43:31 --> User Agent Class Initialized
INFO - 2020-03-17 00:43:31 --> Model Class Initialized
INFO - 2020-03-17 00:43:31 --> Database Driver Class Initialized
INFO - 2020-03-17 00:43:31 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:31 --> Template Class Initialized
INFO - 2020-03-17 00:43:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:43:31 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:43:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:43:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:43:31 --> Encryption Class Initialized
INFO - 2020-03-17 00:43:31 --> Controller Class Initialized
DEBUG - 2020-03-17 00:43:31 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:43:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:43:31 --> Model Class Initialized
INFO - 2020-03-17 00:43:31 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 00:43:31 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 00:43:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 00:43:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:43:31 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:43:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:43:31 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:43:31 --> Model Class Initialized
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:43:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:43:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:43:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:43:32 --> Final output sent to browser
DEBUG - 2020-03-17 00:43:32 --> Total execution time: 1.2184
INFO - 2020-03-17 00:43:40 --> Config Class Initialized
INFO - 2020-03-17 00:43:40 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:43:40 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:43:40 --> Utf8 Class Initialized
INFO - 2020-03-17 00:43:40 --> URI Class Initialized
INFO - 2020-03-17 00:43:40 --> Router Class Initialized
INFO - 2020-03-17 00:43:40 --> Output Class Initialized
INFO - 2020-03-17 00:43:40 --> Security Class Initialized
DEBUG - 2020-03-17 00:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:43:40 --> CSRF cookie sent
INFO - 2020-03-17 00:43:40 --> CSRF token verified
INFO - 2020-03-17 00:43:40 --> Input Class Initialized
INFO - 2020-03-17 00:43:40 --> Language Class Initialized
INFO - 2020-03-17 00:43:40 --> Language Class Initialized
INFO - 2020-03-17 00:43:40 --> Config Class Initialized
INFO - 2020-03-17 00:43:40 --> Loader Class Initialized
INFO - 2020-03-17 00:43:40 --> Helper loaded: url_helper
INFO - 2020-03-17 00:43:40 --> Helper loaded: common_helper
INFO - 2020-03-17 00:43:40 --> Helper loaded: language_helper
INFO - 2020-03-17 00:43:40 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:43:40 --> Helper loaded: email_helper
INFO - 2020-03-17 00:43:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:43:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:43:41 --> Parser Class Initialized
INFO - 2020-03-17 00:43:41 --> User Agent Class Initialized
INFO - 2020-03-17 00:43:41 --> Model Class Initialized
INFO - 2020-03-17 00:43:41 --> Database Driver Class Initialized
INFO - 2020-03-17 00:43:41 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:41 --> Template Class Initialized
INFO - 2020-03-17 00:43:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:43:41 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:43:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:43:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:43:41 --> Encryption Class Initialized
INFO - 2020-03-17 00:43:41 --> Controller Class Initialized
DEBUG - 2020-03-17 00:43:41 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:43:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:43:41 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:41 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:43:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 00:43:41 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 00:43:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 00:43:41 --> Final output sent to browser
DEBUG - 2020-03-17 00:43:41 --> Total execution time: 0.6968
INFO - 2020-03-17 00:43:55 --> Config Class Initialized
INFO - 2020-03-17 00:43:55 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:43:55 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:43:55 --> Utf8 Class Initialized
INFO - 2020-03-17 00:43:55 --> URI Class Initialized
INFO - 2020-03-17 00:43:55 --> Router Class Initialized
INFO - 2020-03-17 00:43:55 --> Output Class Initialized
INFO - 2020-03-17 00:43:55 --> Security Class Initialized
DEBUG - 2020-03-17 00:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:43:56 --> Input Class Initialized
INFO - 2020-03-17 00:43:56 --> Language Class Initialized
INFO - 2020-03-17 00:43:56 --> Language Class Initialized
INFO - 2020-03-17 00:43:56 --> Config Class Initialized
INFO - 2020-03-17 00:43:56 --> Loader Class Initialized
INFO - 2020-03-17 00:43:56 --> Helper loaded: url_helper
INFO - 2020-03-17 00:43:56 --> Helper loaded: common_helper
INFO - 2020-03-17 00:43:56 --> Helper loaded: language_helper
INFO - 2020-03-17 00:43:56 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:43:56 --> Helper loaded: email_helper
INFO - 2020-03-17 00:43:56 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:43:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:43:56 --> Parser Class Initialized
INFO - 2020-03-17 00:43:56 --> User Agent Class Initialized
INFO - 2020-03-17 00:43:56 --> Model Class Initialized
INFO - 2020-03-17 00:43:56 --> Database Driver Class Initialized
INFO - 2020-03-17 00:43:56 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:56 --> Template Class Initialized
INFO - 2020-03-17 00:43:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:43:56 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:43:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:43:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:43:56 --> Encryption Class Initialized
INFO - 2020-03-17 00:43:56 --> Controller Class Initialized
DEBUG - 2020-03-17 00:43:56 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:43:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:43:56 --> Model Class Initialized
ERROR - 2020-03-17 00:43:56 --> Severity: Notice --> Undefined variable: data_buyer_info D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\stripe.php 104
ERROR - 2020-03-17 00:43:58 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\stripe.php 115
DEBUG - 2020-03-17 00:43:58 --> orders MX_Controller Initialized
INFO - 2020-03-17 00:43:58 --> Config Class Initialized
INFO - 2020-03-17 00:43:58 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:43:58 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:43:58 --> Utf8 Class Initialized
INFO - 2020-03-17 00:43:58 --> URI Class Initialized
INFO - 2020-03-17 00:43:58 --> Router Class Initialized
INFO - 2020-03-17 00:43:58 --> Output Class Initialized
INFO - 2020-03-17 00:43:58 --> Security Class Initialized
DEBUG - 2020-03-17 00:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:43:59 --> CSRF cookie sent
INFO - 2020-03-17 00:43:59 --> Input Class Initialized
INFO - 2020-03-17 00:43:59 --> Language Class Initialized
INFO - 2020-03-17 00:43:59 --> Language Class Initialized
INFO - 2020-03-17 00:43:59 --> Config Class Initialized
INFO - 2020-03-17 00:43:59 --> Loader Class Initialized
INFO - 2020-03-17 00:43:59 --> Helper loaded: url_helper
INFO - 2020-03-17 00:43:59 --> Helper loaded: common_helper
INFO - 2020-03-17 00:43:59 --> Helper loaded: language_helper
INFO - 2020-03-17 00:43:59 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:43:59 --> Helper loaded: email_helper
INFO - 2020-03-17 00:43:59 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:43:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:43:59 --> Parser Class Initialized
INFO - 2020-03-17 00:43:59 --> User Agent Class Initialized
INFO - 2020-03-17 00:43:59 --> Model Class Initialized
INFO - 2020-03-17 00:43:59 --> Database Driver Class Initialized
INFO - 2020-03-17 00:43:59 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:59 --> Template Class Initialized
INFO - 2020-03-17 00:43:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:43:59 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:43:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:43:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:43:59 --> Encryption Class Initialized
INFO - 2020-03-17 00:43:59 --> Controller Class Initialized
DEBUG - 2020-03-17 00:43:59 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:43:59 --> Model Class Initialized
INFO - 2020-03-17 00:43:59 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-17 00:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:43:59 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:43:59 --> Model Class Initialized
DEBUG - 2020-03-17 00:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:43:59 --> Model Class Initialized
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:43:59 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:43:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:43:59 --> Final output sent to browser
DEBUG - 2020-03-17 00:43:59 --> Total execution time: 1.0671
INFO - 2020-03-17 00:47:17 --> Config Class Initialized
INFO - 2020-03-17 00:47:17 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:47:17 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:47:17 --> Utf8 Class Initialized
INFO - 2020-03-17 00:47:17 --> URI Class Initialized
INFO - 2020-03-17 00:47:17 --> Router Class Initialized
INFO - 2020-03-17 00:47:17 --> Output Class Initialized
INFO - 2020-03-17 00:47:17 --> Security Class Initialized
DEBUG - 2020-03-17 00:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:47:17 --> CSRF cookie sent
INFO - 2020-03-17 00:47:17 --> CSRF token verified
INFO - 2020-03-17 00:47:17 --> Input Class Initialized
INFO - 2020-03-17 00:47:17 --> Language Class Initialized
INFO - 2020-03-17 00:47:17 --> Language Class Initialized
INFO - 2020-03-17 00:47:17 --> Config Class Initialized
INFO - 2020-03-17 00:47:17 --> Loader Class Initialized
INFO - 2020-03-17 00:47:17 --> Helper loaded: url_helper
INFO - 2020-03-17 00:47:17 --> Helper loaded: common_helper
INFO - 2020-03-17 00:47:17 --> Helper loaded: language_helper
INFO - 2020-03-17 00:47:17 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:47:17 --> Helper loaded: email_helper
INFO - 2020-03-17 00:47:17 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:47:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:47:17 --> Parser Class Initialized
INFO - 2020-03-17 00:47:17 --> User Agent Class Initialized
INFO - 2020-03-17 00:47:17 --> Model Class Initialized
INFO - 2020-03-17 00:47:17 --> Database Driver Class Initialized
INFO - 2020-03-17 00:47:17 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:17 --> Template Class Initialized
INFO - 2020-03-17 00:47:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:47:17 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:47:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:47:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:47:17 --> Encryption Class Initialized
INFO - 2020-03-17 00:47:17 --> Controller Class Initialized
DEBUG - 2020-03-17 00:47:17 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 00:47:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 00:47:17 --> Model Class Initialized
INFO - 2020-03-17 00:47:22 --> Config Class Initialized
INFO - 2020-03-17 00:47:22 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:47:22 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:47:22 --> Utf8 Class Initialized
INFO - 2020-03-17 00:47:22 --> URI Class Initialized
INFO - 2020-03-17 00:47:22 --> Router Class Initialized
INFO - 2020-03-17 00:47:22 --> Output Class Initialized
INFO - 2020-03-17 00:47:22 --> Security Class Initialized
DEBUG - 2020-03-17 00:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:47:22 --> CSRF cookie sent
INFO - 2020-03-17 00:47:22 --> Input Class Initialized
INFO - 2020-03-17 00:47:22 --> Language Class Initialized
INFO - 2020-03-17 00:47:22 --> Language Class Initialized
INFO - 2020-03-17 00:47:22 --> Config Class Initialized
INFO - 2020-03-17 00:47:22 --> Loader Class Initialized
INFO - 2020-03-17 00:47:22 --> Helper loaded: url_helper
INFO - 2020-03-17 00:47:22 --> Helper loaded: common_helper
INFO - 2020-03-17 00:47:22 --> Helper loaded: language_helper
INFO - 2020-03-17 00:47:22 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:47:22 --> Helper loaded: email_helper
INFO - 2020-03-17 00:47:22 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:47:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:47:22 --> Parser Class Initialized
INFO - 2020-03-17 00:47:22 --> User Agent Class Initialized
INFO - 2020-03-17 00:47:22 --> Model Class Initialized
INFO - 2020-03-17 00:47:22 --> Database Driver Class Initialized
INFO - 2020-03-17 00:47:22 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:22 --> Template Class Initialized
INFO - 2020-03-17 00:47:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:47:22 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:47:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:47:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:47:22 --> Encryption Class Initialized
INFO - 2020-03-17 00:47:22 --> Controller Class Initialized
DEBUG - 2020-03-17 00:47:22 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 00:47:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 00:47:22 --> Model Class Initialized
INFO - 2020-03-17 00:47:22 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:47:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-17 00:47:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/stripe.php
DEBUG - 2020-03-17 00:47:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-17 00:47:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:47:22 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:47:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:47:22 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:47:23 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 00:47:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 00:47:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 00:47:23 --> Final output sent to browser
DEBUG - 2020-03-17 00:47:23 --> Total execution time: 0.8695
INFO - 2020-03-17 00:47:38 --> Config Class Initialized
INFO - 2020-03-17 00:47:38 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:47:38 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:47:39 --> Utf8 Class Initialized
INFO - 2020-03-17 00:47:39 --> URI Class Initialized
DEBUG - 2020-03-17 00:47:39 --> No URI present. Default controller set.
INFO - 2020-03-17 00:47:39 --> Router Class Initialized
INFO - 2020-03-17 00:47:39 --> Output Class Initialized
INFO - 2020-03-17 00:47:39 --> Security Class Initialized
DEBUG - 2020-03-17 00:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:47:39 --> CSRF cookie sent
INFO - 2020-03-17 00:47:39 --> Input Class Initialized
INFO - 2020-03-17 00:47:39 --> Language Class Initialized
INFO - 2020-03-17 00:47:39 --> Language Class Initialized
INFO - 2020-03-17 00:47:39 --> Config Class Initialized
INFO - 2020-03-17 00:47:39 --> Loader Class Initialized
INFO - 2020-03-17 00:47:39 --> Helper loaded: url_helper
INFO - 2020-03-17 00:47:39 --> Helper loaded: common_helper
INFO - 2020-03-17 00:47:39 --> Helper loaded: language_helper
INFO - 2020-03-17 00:47:39 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:47:39 --> Helper loaded: email_helper
INFO - 2020-03-17 00:47:39 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:47:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:47:39 --> Parser Class Initialized
INFO - 2020-03-17 00:47:39 --> User Agent Class Initialized
INFO - 2020-03-17 00:47:39 --> Model Class Initialized
INFO - 2020-03-17 00:47:39 --> Database Driver Class Initialized
INFO - 2020-03-17 00:47:39 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:39 --> Template Class Initialized
INFO - 2020-03-17 00:47:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:47:39 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:47:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:47:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:47:39 --> Encryption Class Initialized
DEBUG - 2020-03-17 00:47:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:47:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-17 00:47:39 --> Controller Class Initialized
DEBUG - 2020-03-17 00:47:39 --> pergo MX_Controller Initialized
DEBUG - 2020-03-17 00:47:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:47:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-17 00:47:39 --> Model Class Initialized
INFO - 2020-03-17 00:47:39 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:47:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-17 00:47:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-17 00:47:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-17 00:47:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-17 00:47:39 --> Final output sent to browser
DEBUG - 2020-03-17 00:47:39 --> Total execution time: 0.8713
INFO - 2020-03-17 00:47:41 --> Config Class Initialized
INFO - 2020-03-17 00:47:41 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:47:41 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:47:41 --> Utf8 Class Initialized
INFO - 2020-03-17 00:47:41 --> URI Class Initialized
INFO - 2020-03-17 00:47:41 --> Router Class Initialized
INFO - 2020-03-17 00:47:41 --> Output Class Initialized
INFO - 2020-03-17 00:47:41 --> Security Class Initialized
DEBUG - 2020-03-17 00:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:47:41 --> CSRF cookie sent
INFO - 2020-03-17 00:47:41 --> Input Class Initialized
INFO - 2020-03-17 00:47:41 --> Language Class Initialized
INFO - 2020-03-17 00:47:41 --> Language Class Initialized
INFO - 2020-03-17 00:47:41 --> Config Class Initialized
INFO - 2020-03-17 00:47:41 --> Loader Class Initialized
INFO - 2020-03-17 00:47:42 --> Helper loaded: url_helper
INFO - 2020-03-17 00:47:42 --> Helper loaded: common_helper
INFO - 2020-03-17 00:47:42 --> Helper loaded: language_helper
INFO - 2020-03-17 00:47:42 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:47:42 --> Helper loaded: email_helper
INFO - 2020-03-17 00:47:42 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:47:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:47:42 --> Parser Class Initialized
INFO - 2020-03-17 00:47:42 --> User Agent Class Initialized
INFO - 2020-03-17 00:47:42 --> Model Class Initialized
INFO - 2020-03-17 00:47:42 --> Database Driver Class Initialized
INFO - 2020-03-17 00:47:42 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:42 --> Template Class Initialized
INFO - 2020-03-17 00:47:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:47:42 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:47:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:47:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:47:42 --> Encryption Class Initialized
INFO - 2020-03-17 00:47:42 --> Controller Class Initialized
DEBUG - 2020-03-17 00:47:42 --> package MX_Controller Initialized
DEBUG - 2020-03-17 00:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-17 00:47:42 --> Model Class Initialized
INFO - 2020-03-17 00:47:42 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:47:42 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:47:42 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:47:42 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-17 00:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:47:42 --> Final output sent to browser
DEBUG - 2020-03-17 00:47:43 --> Total execution time: 1.2219
INFO - 2020-03-17 00:47:45 --> Config Class Initialized
INFO - 2020-03-17 00:47:45 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:47:45 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:47:45 --> Utf8 Class Initialized
INFO - 2020-03-17 00:47:45 --> URI Class Initialized
INFO - 2020-03-17 00:47:45 --> Router Class Initialized
INFO - 2020-03-17 00:47:45 --> Output Class Initialized
INFO - 2020-03-17 00:47:45 --> Security Class Initialized
DEBUG - 2020-03-17 00:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:47:45 --> CSRF cookie sent
INFO - 2020-03-17 00:47:45 --> CSRF token verified
INFO - 2020-03-17 00:47:45 --> Input Class Initialized
INFO - 2020-03-17 00:47:45 --> Language Class Initialized
INFO - 2020-03-17 00:47:45 --> Language Class Initialized
INFO - 2020-03-17 00:47:45 --> Config Class Initialized
INFO - 2020-03-17 00:47:45 --> Loader Class Initialized
INFO - 2020-03-17 00:47:45 --> Helper loaded: url_helper
INFO - 2020-03-17 00:47:45 --> Helper loaded: common_helper
INFO - 2020-03-17 00:47:45 --> Helper loaded: language_helper
INFO - 2020-03-17 00:47:45 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:47:45 --> Helper loaded: email_helper
INFO - 2020-03-17 00:47:45 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:47:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:47:45 --> Parser Class Initialized
INFO - 2020-03-17 00:47:46 --> User Agent Class Initialized
INFO - 2020-03-17 00:47:46 --> Model Class Initialized
INFO - 2020-03-17 00:47:46 --> Database Driver Class Initialized
INFO - 2020-03-17 00:47:46 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:46 --> Template Class Initialized
INFO - 2020-03-17 00:47:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:47:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:47:46 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:47:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:47:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:47:46 --> Encryption Class Initialized
INFO - 2020-03-17 00:47:46 --> Controller Class Initialized
DEBUG - 2020-03-17 00:47:46 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:47:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:47:46 --> Model Class Initialized
INFO - 2020-03-17 00:47:46 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 00:47:46 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 00:47:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 00:47:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:47:46 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:47:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:47:46 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:47:46 --> Model Class Initialized
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:47:46 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:47:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:47:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:47:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:47:46 --> Final output sent to browser
DEBUG - 2020-03-17 00:47:46 --> Total execution time: 1.3380
INFO - 2020-03-17 00:47:54 --> Config Class Initialized
INFO - 2020-03-17 00:47:54 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:47:54 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:47:54 --> Utf8 Class Initialized
INFO - 2020-03-17 00:47:54 --> URI Class Initialized
INFO - 2020-03-17 00:47:54 --> Router Class Initialized
INFO - 2020-03-17 00:47:54 --> Output Class Initialized
INFO - 2020-03-17 00:47:54 --> Security Class Initialized
DEBUG - 2020-03-17 00:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:47:54 --> CSRF cookie sent
INFO - 2020-03-17 00:47:54 --> CSRF token verified
INFO - 2020-03-17 00:47:54 --> Input Class Initialized
INFO - 2020-03-17 00:47:54 --> Language Class Initialized
INFO - 2020-03-17 00:47:54 --> Language Class Initialized
INFO - 2020-03-17 00:47:54 --> Config Class Initialized
INFO - 2020-03-17 00:47:55 --> Loader Class Initialized
INFO - 2020-03-17 00:47:55 --> Helper loaded: url_helper
INFO - 2020-03-17 00:47:55 --> Helper loaded: common_helper
INFO - 2020-03-17 00:47:55 --> Helper loaded: language_helper
INFO - 2020-03-17 00:47:55 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:47:55 --> Helper loaded: email_helper
INFO - 2020-03-17 00:47:55 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:47:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:47:55 --> Parser Class Initialized
INFO - 2020-03-17 00:47:55 --> User Agent Class Initialized
INFO - 2020-03-17 00:47:55 --> Model Class Initialized
INFO - 2020-03-17 00:47:55 --> Database Driver Class Initialized
INFO - 2020-03-17 00:47:55 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:55 --> Template Class Initialized
INFO - 2020-03-17 00:47:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:47:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:47:55 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:47:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:47:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:47:55 --> Encryption Class Initialized
INFO - 2020-03-17 00:47:55 --> Controller Class Initialized
DEBUG - 2020-03-17 00:47:55 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:47:55 --> Model Class Initialized
DEBUG - 2020-03-17 00:47:55 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 00:47:55 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 00:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 00:47:55 --> Final output sent to browser
DEBUG - 2020-03-17 00:47:55 --> Total execution time: 0.7218
INFO - 2020-03-17 00:48:06 --> Config Class Initialized
INFO - 2020-03-17 00:48:06 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:48:06 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:48:06 --> Utf8 Class Initialized
INFO - 2020-03-17 00:48:06 --> URI Class Initialized
INFO - 2020-03-17 00:48:06 --> Router Class Initialized
INFO - 2020-03-17 00:48:06 --> Output Class Initialized
INFO - 2020-03-17 00:48:06 --> Security Class Initialized
DEBUG - 2020-03-17 00:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:48:06 --> Input Class Initialized
INFO - 2020-03-17 00:48:06 --> Language Class Initialized
INFO - 2020-03-17 00:48:06 --> Language Class Initialized
INFO - 2020-03-17 00:48:06 --> Config Class Initialized
INFO - 2020-03-17 00:48:06 --> Loader Class Initialized
INFO - 2020-03-17 00:48:06 --> Helper loaded: url_helper
INFO - 2020-03-17 00:48:06 --> Helper loaded: common_helper
INFO - 2020-03-17 00:48:06 --> Helper loaded: language_helper
INFO - 2020-03-17 00:48:06 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:48:06 --> Helper loaded: email_helper
INFO - 2020-03-17 00:48:06 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:48:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:48:06 --> Parser Class Initialized
INFO - 2020-03-17 00:48:06 --> User Agent Class Initialized
INFO - 2020-03-17 00:48:06 --> Model Class Initialized
INFO - 2020-03-17 00:48:06 --> Database Driver Class Initialized
INFO - 2020-03-17 00:48:06 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:06 --> Template Class Initialized
INFO - 2020-03-17 00:48:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:48:07 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:48:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:48:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:48:07 --> Encryption Class Initialized
INFO - 2020-03-17 00:48:07 --> Controller Class Initialized
DEBUG - 2020-03-17 00:48:07 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:48:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:48:07 --> Model Class Initialized
ERROR - 2020-03-17 00:48:07 --> Severity: Notice --> Undefined variable: data_buyer_info D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\stripe.php 104
INFO - 2020-03-17 00:48:07 --> Config Class Initialized
INFO - 2020-03-17 00:48:07 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:48:07 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:48:07 --> Utf8 Class Initialized
INFO - 2020-03-17 00:48:07 --> URI Class Initialized
INFO - 2020-03-17 00:48:07 --> Router Class Initialized
INFO - 2020-03-17 00:48:07 --> Output Class Initialized
INFO - 2020-03-17 00:48:07 --> Security Class Initialized
DEBUG - 2020-03-17 00:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:48:07 --> CSRF cookie sent
INFO - 2020-03-17 00:48:07 --> Input Class Initialized
INFO - 2020-03-17 00:48:07 --> Language Class Initialized
INFO - 2020-03-17 00:48:07 --> Language Class Initialized
INFO - 2020-03-17 00:48:07 --> Config Class Initialized
INFO - 2020-03-17 00:48:07 --> Loader Class Initialized
INFO - 2020-03-17 00:48:07 --> Helper loaded: url_helper
INFO - 2020-03-17 00:48:07 --> Helper loaded: common_helper
INFO - 2020-03-17 00:48:07 --> Helper loaded: language_helper
INFO - 2020-03-17 00:48:07 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:48:07 --> Helper loaded: email_helper
INFO - 2020-03-17 00:48:07 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:48:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:48:07 --> Parser Class Initialized
INFO - 2020-03-17 00:48:07 --> User Agent Class Initialized
INFO - 2020-03-17 00:48:07 --> Model Class Initialized
INFO - 2020-03-17 00:48:07 --> Database Driver Class Initialized
INFO - 2020-03-17 00:48:07 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:07 --> Template Class Initialized
INFO - 2020-03-17 00:48:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:48:07 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:48:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:48:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:48:07 --> Encryption Class Initialized
INFO - 2020-03-17 00:48:07 --> Controller Class Initialized
DEBUG - 2020-03-17 00:48:07 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:48:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:48:07 --> Model Class Initialized
INFO - 2020-03-17 00:48:07 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:48:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2020-03-17 00:48:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:48:07 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:48:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:48:07 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:48:07 --> Model Class Initialized
ERROR - 2020-03-17 00:48:07 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:08 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:48:08 --> Final output sent to browser
DEBUG - 2020-03-17 00:48:08 --> Total execution time: 1.1924
INFO - 2020-03-17 00:48:18 --> Config Class Initialized
INFO - 2020-03-17 00:48:18 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:48:18 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:48:18 --> Utf8 Class Initialized
INFO - 2020-03-17 00:48:18 --> URI Class Initialized
DEBUG - 2020-03-17 00:48:18 --> No URI present. Default controller set.
INFO - 2020-03-17 00:48:18 --> Router Class Initialized
INFO - 2020-03-17 00:48:18 --> Output Class Initialized
INFO - 2020-03-17 00:48:18 --> Security Class Initialized
DEBUG - 2020-03-17 00:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:48:18 --> CSRF cookie sent
INFO - 2020-03-17 00:48:18 --> Input Class Initialized
INFO - 2020-03-17 00:48:18 --> Language Class Initialized
INFO - 2020-03-17 00:48:18 --> Language Class Initialized
INFO - 2020-03-17 00:48:18 --> Config Class Initialized
INFO - 2020-03-17 00:48:18 --> Loader Class Initialized
INFO - 2020-03-17 00:48:18 --> Helper loaded: url_helper
INFO - 2020-03-17 00:48:18 --> Helper loaded: common_helper
INFO - 2020-03-17 00:48:18 --> Helper loaded: language_helper
INFO - 2020-03-17 00:48:18 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:48:18 --> Helper loaded: email_helper
INFO - 2020-03-17 00:48:18 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:48:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:48:18 --> Parser Class Initialized
INFO - 2020-03-17 00:48:18 --> User Agent Class Initialized
INFO - 2020-03-17 00:48:18 --> Model Class Initialized
INFO - 2020-03-17 00:48:18 --> Database Driver Class Initialized
INFO - 2020-03-17 00:48:18 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:18 --> Template Class Initialized
INFO - 2020-03-17 00:48:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:48:18 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:48:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:48:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:48:18 --> Encryption Class Initialized
DEBUG - 2020-03-17 00:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-17 00:48:18 --> Controller Class Initialized
DEBUG - 2020-03-17 00:48:18 --> pergo MX_Controller Initialized
DEBUG - 2020-03-17 00:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 00:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-17 00:48:18 --> Model Class Initialized
INFO - 2020-03-17 00:48:18 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-17 00:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-17 00:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-17 00:48:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-17 00:48:19 --> Final output sent to browser
DEBUG - 2020-03-17 00:48:19 --> Total execution time: 0.9886
INFO - 2020-03-17 00:48:40 --> Config Class Initialized
INFO - 2020-03-17 00:48:40 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:48:40 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:48:40 --> Utf8 Class Initialized
INFO - 2020-03-17 00:48:40 --> URI Class Initialized
INFO - 2020-03-17 00:48:40 --> Router Class Initialized
INFO - 2020-03-17 00:48:40 --> Output Class Initialized
INFO - 2020-03-17 00:48:40 --> Security Class Initialized
DEBUG - 2020-03-17 00:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:48:40 --> CSRF cookie sent
INFO - 2020-03-17 00:48:40 --> Input Class Initialized
INFO - 2020-03-17 00:48:40 --> Language Class Initialized
INFO - 2020-03-17 00:48:40 --> Language Class Initialized
INFO - 2020-03-17 00:48:40 --> Config Class Initialized
INFO - 2020-03-17 00:48:40 --> Loader Class Initialized
INFO - 2020-03-17 00:48:40 --> Helper loaded: url_helper
INFO - 2020-03-17 00:48:40 --> Helper loaded: common_helper
INFO - 2020-03-17 00:48:40 --> Helper loaded: language_helper
INFO - 2020-03-17 00:48:40 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:48:40 --> Helper loaded: email_helper
INFO - 2020-03-17 00:48:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:48:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:48:40 --> Parser Class Initialized
INFO - 2020-03-17 00:48:40 --> User Agent Class Initialized
INFO - 2020-03-17 00:48:40 --> Model Class Initialized
INFO - 2020-03-17 00:48:40 --> Database Driver Class Initialized
INFO - 2020-03-17 00:48:40 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:40 --> Template Class Initialized
INFO - 2020-03-17 00:48:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:48:40 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:48:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:48:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:48:40 --> Encryption Class Initialized
INFO - 2020-03-17 00:48:40 --> Controller Class Initialized
DEBUG - 2020-03-17 00:48:40 --> package MX_Controller Initialized
DEBUG - 2020-03-17 00:48:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-17 00:48:40 --> Model Class Initialized
INFO - 2020-03-17 00:48:40 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:48:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:48:40 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:48:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:48:40 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:48:40 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-17 00:48:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-17 00:48:40 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:40 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:41 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:48:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:48:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:48:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:48:41 --> Final output sent to browser
DEBUG - 2020-03-17 00:48:41 --> Total execution time: 1.2535
INFO - 2020-03-17 00:48:43 --> Config Class Initialized
INFO - 2020-03-17 00:48:43 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:48:43 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:48:43 --> Utf8 Class Initialized
INFO - 2020-03-17 00:48:43 --> URI Class Initialized
INFO - 2020-03-17 00:48:43 --> Router Class Initialized
INFO - 2020-03-17 00:48:43 --> Output Class Initialized
INFO - 2020-03-17 00:48:43 --> Security Class Initialized
DEBUG - 2020-03-17 00:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:48:43 --> CSRF cookie sent
INFO - 2020-03-17 00:48:43 --> CSRF token verified
INFO - 2020-03-17 00:48:43 --> Input Class Initialized
INFO - 2020-03-17 00:48:43 --> Language Class Initialized
INFO - 2020-03-17 00:48:43 --> Language Class Initialized
INFO - 2020-03-17 00:48:43 --> Config Class Initialized
INFO - 2020-03-17 00:48:43 --> Loader Class Initialized
INFO - 2020-03-17 00:48:43 --> Helper loaded: url_helper
INFO - 2020-03-17 00:48:43 --> Helper loaded: common_helper
INFO - 2020-03-17 00:48:43 --> Helper loaded: language_helper
INFO - 2020-03-17 00:48:43 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:48:43 --> Helper loaded: email_helper
INFO - 2020-03-17 00:48:43 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:48:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:48:43 --> Parser Class Initialized
INFO - 2020-03-17 00:48:43 --> User Agent Class Initialized
INFO - 2020-03-17 00:48:43 --> Model Class Initialized
INFO - 2020-03-17 00:48:43 --> Database Driver Class Initialized
INFO - 2020-03-17 00:48:44 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:44 --> Template Class Initialized
INFO - 2020-03-17 00:48:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:48:44 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:48:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:48:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:48:44 --> Encryption Class Initialized
INFO - 2020-03-17 00:48:44 --> Controller Class Initialized
DEBUG - 2020-03-17 00:48:44 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:48:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:48:44 --> Model Class Initialized
INFO - 2020-03-17 00:48:44 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 00:48:44 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 00:48:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 00:48:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:48:44 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:48:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:48:44 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:48:44 --> Model Class Initialized
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:48:44 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:48:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:48:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:48:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:48:44 --> Final output sent to browser
DEBUG - 2020-03-17 00:48:44 --> Total execution time: 1.3852
INFO - 2020-03-17 00:48:53 --> Config Class Initialized
INFO - 2020-03-17 00:48:53 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:48:53 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:48:53 --> Utf8 Class Initialized
INFO - 2020-03-17 00:48:53 --> URI Class Initialized
INFO - 2020-03-17 00:48:53 --> Router Class Initialized
INFO - 2020-03-17 00:48:53 --> Output Class Initialized
INFO - 2020-03-17 00:48:53 --> Security Class Initialized
DEBUG - 2020-03-17 00:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:48:53 --> CSRF cookie sent
INFO - 2020-03-17 00:48:53 --> CSRF token verified
INFO - 2020-03-17 00:48:53 --> Input Class Initialized
INFO - 2020-03-17 00:48:53 --> Language Class Initialized
INFO - 2020-03-17 00:48:53 --> Language Class Initialized
INFO - 2020-03-17 00:48:53 --> Config Class Initialized
INFO - 2020-03-17 00:48:53 --> Loader Class Initialized
INFO - 2020-03-17 00:48:53 --> Helper loaded: url_helper
INFO - 2020-03-17 00:48:53 --> Helper loaded: common_helper
INFO - 2020-03-17 00:48:53 --> Helper loaded: language_helper
INFO - 2020-03-17 00:48:53 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:48:53 --> Helper loaded: email_helper
INFO - 2020-03-17 00:48:53 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:48:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:48:53 --> Parser Class Initialized
INFO - 2020-03-17 00:48:53 --> User Agent Class Initialized
INFO - 2020-03-17 00:48:53 --> Model Class Initialized
INFO - 2020-03-17 00:48:53 --> Database Driver Class Initialized
INFO - 2020-03-17 00:48:53 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:53 --> Template Class Initialized
INFO - 2020-03-17 00:48:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:48:53 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:48:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:48:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:48:53 --> Encryption Class Initialized
INFO - 2020-03-17 00:48:53 --> Controller Class Initialized
DEBUG - 2020-03-17 00:48:53 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:48:53 --> Model Class Initialized
DEBUG - 2020-03-17 00:48:53 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 00:48:53 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 00:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 00:48:53 --> Final output sent to browser
DEBUG - 2020-03-17 00:48:53 --> Total execution time: 0.7628
INFO - 2020-03-17 00:49:06 --> Config Class Initialized
INFO - 2020-03-17 00:49:06 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:49:06 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:49:06 --> Utf8 Class Initialized
INFO - 2020-03-17 00:49:06 --> URI Class Initialized
INFO - 2020-03-17 00:49:06 --> Router Class Initialized
INFO - 2020-03-17 00:49:06 --> Output Class Initialized
INFO - 2020-03-17 00:49:06 --> Security Class Initialized
DEBUG - 2020-03-17 00:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:49:06 --> Input Class Initialized
INFO - 2020-03-17 00:49:06 --> Language Class Initialized
INFO - 2020-03-17 00:49:06 --> Language Class Initialized
INFO - 2020-03-17 00:49:06 --> Config Class Initialized
INFO - 2020-03-17 00:49:06 --> Loader Class Initialized
INFO - 2020-03-17 00:49:06 --> Helper loaded: url_helper
INFO - 2020-03-17 00:49:06 --> Helper loaded: common_helper
INFO - 2020-03-17 00:49:06 --> Helper loaded: language_helper
INFO - 2020-03-17 00:49:06 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:49:06 --> Helper loaded: email_helper
INFO - 2020-03-17 00:49:06 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:49:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:49:06 --> Parser Class Initialized
INFO - 2020-03-17 00:49:06 --> User Agent Class Initialized
INFO - 2020-03-17 00:49:06 --> Model Class Initialized
INFO - 2020-03-17 00:49:06 --> Database Driver Class Initialized
INFO - 2020-03-17 00:49:06 --> Model Class Initialized
DEBUG - 2020-03-17 00:49:06 --> Template Class Initialized
INFO - 2020-03-17 00:49:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:49:06 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:49:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:49:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:49:06 --> Encryption Class Initialized
INFO - 2020-03-17 00:49:06 --> Controller Class Initialized
DEBUG - 2020-03-17 00:49:06 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:49:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:49:06 --> Model Class Initialized
ERROR - 2020-03-17 00:49:06 --> Severity: Notice --> Undefined variable: data_buyer_info D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\stripe.php 104
INFO - 2020-03-17 00:49:46 --> Config Class Initialized
INFO - 2020-03-17 00:49:46 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:49:46 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:49:46 --> Utf8 Class Initialized
INFO - 2020-03-17 00:49:46 --> URI Class Initialized
INFO - 2020-03-17 00:49:46 --> Router Class Initialized
INFO - 2020-03-17 00:49:46 --> Output Class Initialized
INFO - 2020-03-17 00:49:46 --> Security Class Initialized
DEBUG - 2020-03-17 00:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:49:46 --> Input Class Initialized
INFO - 2020-03-17 00:49:46 --> Language Class Initialized
INFO - 2020-03-17 00:49:46 --> Language Class Initialized
INFO - 2020-03-17 00:49:46 --> Config Class Initialized
INFO - 2020-03-17 00:49:46 --> Loader Class Initialized
INFO - 2020-03-17 00:49:46 --> Helper loaded: url_helper
INFO - 2020-03-17 00:49:46 --> Helper loaded: common_helper
INFO - 2020-03-17 00:49:46 --> Helper loaded: language_helper
INFO - 2020-03-17 00:49:46 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:49:46 --> Helper loaded: email_helper
INFO - 2020-03-17 00:49:46 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:49:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:49:46 --> Parser Class Initialized
INFO - 2020-03-17 00:49:46 --> User Agent Class Initialized
INFO - 2020-03-17 00:49:46 --> Model Class Initialized
INFO - 2020-03-17 00:49:46 --> Database Driver Class Initialized
INFO - 2020-03-17 00:49:46 --> Model Class Initialized
DEBUG - 2020-03-17 00:49:46 --> Template Class Initialized
INFO - 2020-03-17 00:49:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:49:46 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:49:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:49:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:49:46 --> Encryption Class Initialized
INFO - 2020-03-17 00:49:46 --> Controller Class Initialized
DEBUG - 2020-03-17 00:49:46 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 00:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 00:49:46 --> Model Class Initialized
DEBUG - 2020-03-17 00:49:49 --> orders MX_Controller Initialized
INFO - 2020-03-17 00:49:49 --> Config Class Initialized
INFO - 2020-03-17 00:49:49 --> Hooks Class Initialized
DEBUG - 2020-03-17 00:49:49 --> UTF-8 Support Enabled
INFO - 2020-03-17 00:49:49 --> Utf8 Class Initialized
INFO - 2020-03-17 00:49:49 --> URI Class Initialized
INFO - 2020-03-17 00:49:49 --> Router Class Initialized
INFO - 2020-03-17 00:49:49 --> Output Class Initialized
INFO - 2020-03-17 00:49:49 --> Security Class Initialized
DEBUG - 2020-03-17 00:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 00:49:49 --> CSRF cookie sent
INFO - 2020-03-17 00:49:49 --> Input Class Initialized
INFO - 2020-03-17 00:49:49 --> Language Class Initialized
INFO - 2020-03-17 00:49:49 --> Language Class Initialized
INFO - 2020-03-17 00:49:49 --> Config Class Initialized
INFO - 2020-03-17 00:49:49 --> Loader Class Initialized
INFO - 2020-03-17 00:49:49 --> Helper loaded: url_helper
INFO - 2020-03-17 00:49:49 --> Helper loaded: common_helper
INFO - 2020-03-17 00:49:49 --> Helper loaded: language_helper
INFO - 2020-03-17 00:49:49 --> Helper loaded: cookie_helper
INFO - 2020-03-17 00:49:49 --> Helper loaded: email_helper
INFO - 2020-03-17 00:49:49 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 00:49:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 00:49:49 --> Parser Class Initialized
INFO - 2020-03-17 00:49:49 --> User Agent Class Initialized
INFO - 2020-03-17 00:49:49 --> Model Class Initialized
INFO - 2020-03-17 00:49:49 --> Database Driver Class Initialized
INFO - 2020-03-17 00:49:49 --> Model Class Initialized
DEBUG - 2020-03-17 00:49:49 --> Template Class Initialized
INFO - 2020-03-17 00:49:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 00:49:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 00:49:49 --> Pagination Class Initialized
DEBUG - 2020-03-17 00:49:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 00:49:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 00:49:49 --> Encryption Class Initialized
INFO - 2020-03-17 00:49:49 --> Controller Class Initialized
DEBUG - 2020-03-17 00:49:49 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 00:49:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 00:49:49 --> Model Class Initialized
INFO - 2020-03-17 00:49:49 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 00:49:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-17 00:49:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 00:49:49 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 00:49:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 00:49:49 --> Model Class Initialized
DEBUG - 2020-03-17 00:49:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 00:49:49 --> Model Class Initialized
ERROR - 2020-03-17 00:49:49 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:49:49 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:49:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:49:49 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:49:49 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 00:49:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 00:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 00:49:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 00:49:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 00:49:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 00:49:50 --> Final output sent to browser
DEBUG - 2020-03-17 00:49:50 --> Total execution time: 1.1359
INFO - 2020-03-17 11:20:05 --> Config Class Initialized
INFO - 2020-03-17 11:20:05 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:05 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:05 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:05 --> URI Class Initialized
DEBUG - 2020-03-17 11:20:05 --> No URI present. Default controller set.
INFO - 2020-03-17 11:20:05 --> Router Class Initialized
INFO - 2020-03-17 11:20:06 --> Output Class Initialized
INFO - 2020-03-17 11:20:06 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:06 --> CSRF cookie sent
INFO - 2020-03-17 11:20:06 --> Input Class Initialized
INFO - 2020-03-17 11:20:06 --> Language Class Initialized
INFO - 2020-03-17 11:20:06 --> Language Class Initialized
INFO - 2020-03-17 11:20:06 --> Config Class Initialized
INFO - 2020-03-17 11:20:06 --> Loader Class Initialized
INFO - 2020-03-17 11:20:06 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:06 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:06 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:06 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:06 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:06 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:06 --> Parser Class Initialized
INFO - 2020-03-17 11:20:06 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:06 --> Model Class Initialized
INFO - 2020-03-17 11:20:06 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:06 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:06 --> Template Class Initialized
INFO - 2020-03-17 11:20:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:06 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:07 --> Encryption Class Initialized
DEBUG - 2020-03-17 11:20:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 11:20:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-17 11:20:07 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:07 --> pergo MX_Controller Initialized
DEBUG - 2020-03-17 11:20:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 11:20:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-17 11:20:07 --> Model Class Initialized
INFO - 2020-03-17 11:20:07 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 11:20:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-17 11:20:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-17 11:20:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-17 11:20:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-17 11:20:07 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:07 --> Total execution time: 2.0030
INFO - 2020-03-17 11:20:11 --> Config Class Initialized
INFO - 2020-03-17 11:20:11 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:11 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:11 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:11 --> URI Class Initialized
INFO - 2020-03-17 11:20:11 --> Router Class Initialized
INFO - 2020-03-17 11:20:11 --> Output Class Initialized
INFO - 2020-03-17 11:20:11 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:12 --> CSRF cookie sent
INFO - 2020-03-17 11:20:12 --> Input Class Initialized
INFO - 2020-03-17 11:20:12 --> Language Class Initialized
INFO - 2020-03-17 11:20:12 --> Language Class Initialized
INFO - 2020-03-17 11:20:12 --> Config Class Initialized
INFO - 2020-03-17 11:20:12 --> Loader Class Initialized
INFO - 2020-03-17 11:20:12 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:12 --> Parser Class Initialized
INFO - 2020-03-17 11:20:12 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:12 --> Model Class Initialized
INFO - 2020-03-17 11:20:12 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:12 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:12 --> Template Class Initialized
INFO - 2020-03-17 11:20:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:12 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:12 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:12 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:12 --> auth MX_Controller Initialized
DEBUG - 2020-03-17 11:20:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-17 11:20:12 --> Model Class Initialized
INFO - 2020-03-17 11:20:12 --> Config Class Initialized
INFO - 2020-03-17 11:20:12 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:12 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:12 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:12 --> URI Class Initialized
INFO - 2020-03-17 11:20:12 --> Router Class Initialized
INFO - 2020-03-17 11:20:12 --> Output Class Initialized
INFO - 2020-03-17 11:20:12 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:12 --> CSRF cookie sent
INFO - 2020-03-17 11:20:12 --> Input Class Initialized
INFO - 2020-03-17 11:20:12 --> Language Class Initialized
INFO - 2020-03-17 11:20:12 --> Language Class Initialized
INFO - 2020-03-17 11:20:12 --> Config Class Initialized
INFO - 2020-03-17 11:20:12 --> Loader Class Initialized
INFO - 2020-03-17 11:20:12 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:12 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:12 --> Parser Class Initialized
INFO - 2020-03-17 11:20:12 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:12 --> Model Class Initialized
INFO - 2020-03-17 11:20:12 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:12 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:12 --> Template Class Initialized
INFO - 2020-03-17 11:20:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:13 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:13 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:13 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:13 --> statistics MX_Controller Initialized
DEBUG - 2020-03-17 11:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-17 11:20:13 --> Model Class Initialized
ERROR - 2020-03-17 11:20:13 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:13 --> Could not find the language line "Pending"
INFO - 2020-03-17 11:20:13 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 11:20:13 --> Could not find the language line "total_orders"
ERROR - 2020-03-17 11:20:13 --> Could not find the language line "total_orders"
ERROR - 2020-03-17 11:20:13 --> Could not find the language line "Pending"
DEBUG - 2020-03-17 11:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-17 11:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:13 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:13 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:13 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:13 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:13 --> Total execution time: 1.3181
INFO - 2020-03-17 11:20:18 --> Config Class Initialized
INFO - 2020-03-17 11:20:18 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:18 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:18 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:18 --> URI Class Initialized
INFO - 2020-03-17 11:20:18 --> Router Class Initialized
INFO - 2020-03-17 11:20:18 --> Output Class Initialized
INFO - 2020-03-17 11:20:18 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:18 --> CSRF cookie sent
INFO - 2020-03-17 11:20:18 --> Input Class Initialized
INFO - 2020-03-17 11:20:18 --> Language Class Initialized
INFO - 2020-03-17 11:20:18 --> Language Class Initialized
INFO - 2020-03-17 11:20:18 --> Config Class Initialized
INFO - 2020-03-17 11:20:18 --> Loader Class Initialized
INFO - 2020-03-17 11:20:18 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:18 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:18 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:18 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:18 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:18 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:18 --> Parser Class Initialized
INFO - 2020-03-17 11:20:18 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:18 --> Model Class Initialized
INFO - 2020-03-17 11:20:18 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:19 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:19 --> Template Class Initialized
INFO - 2020-03-17 11:20:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:19 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:19 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:19 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:19 --> social_network MX_Controller Initialized
DEBUG - 2020-03-17 11:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/social_network/models/social_network_model.php
INFO - 2020-03-17 11:20:19 --> Model Class Initialized
ERROR - 2020-03-17 11:20:19 --> Could not find the language line "Sorting"
INFO - 2020-03-17 11:20:19 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 11:20:19 --> Could not find the language line "social_networks"
DEBUG - 2020-03-17 11:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/social_network/views/index.php
DEBUG - 2020-03-17 11:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:19 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:19 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:19 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:19 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:19 --> Total execution time: 1.4203
INFO - 2020-03-17 11:20:21 --> Config Class Initialized
INFO - 2020-03-17 11:20:21 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:21 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:21 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:21 --> URI Class Initialized
INFO - 2020-03-17 11:20:21 --> Router Class Initialized
INFO - 2020-03-17 11:20:21 --> Output Class Initialized
INFO - 2020-03-17 11:20:21 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:21 --> CSRF cookie sent
INFO - 2020-03-17 11:20:21 --> Input Class Initialized
INFO - 2020-03-17 11:20:21 --> Language Class Initialized
INFO - 2020-03-17 11:20:21 --> Language Class Initialized
INFO - 2020-03-17 11:20:21 --> Config Class Initialized
INFO - 2020-03-17 11:20:21 --> Loader Class Initialized
INFO - 2020-03-17 11:20:21 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:21 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:21 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:21 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:21 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:21 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:21 --> Parser Class Initialized
INFO - 2020-03-17 11:20:21 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:21 --> Model Class Initialized
INFO - 2020-03-17 11:20:21 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:21 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:21 --> Template Class Initialized
INFO - 2020-03-17 11:20:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:21 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:21 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:21 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:21 --> transactions MX_Controller Initialized
DEBUG - 2020-03-17 11:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-17 11:20:21 --> Model Class Initialized
ERROR - 2020-03-17 11:20:21 --> Could not find the language line "order_id"
INFO - 2020-03-17 11:20:21 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 11:20:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-17 11:20:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:22 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:22 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:22 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:22 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:22 --> Total execution time: 1.1141
INFO - 2020-03-17 11:20:23 --> Config Class Initialized
INFO - 2020-03-17 11:20:23 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:23 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:23 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:23 --> URI Class Initialized
INFO - 2020-03-17 11:20:23 --> Router Class Initialized
INFO - 2020-03-17 11:20:23 --> Output Class Initialized
INFO - 2020-03-17 11:20:23 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:23 --> CSRF cookie sent
INFO - 2020-03-17 11:20:23 --> Input Class Initialized
INFO - 2020-03-17 11:20:23 --> Language Class Initialized
INFO - 2020-03-17 11:20:23 --> Language Class Initialized
INFO - 2020-03-17 11:20:23 --> Config Class Initialized
INFO - 2020-03-17 11:20:23 --> Loader Class Initialized
INFO - 2020-03-17 11:20:23 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:23 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:23 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:23 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:23 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:23 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:23 --> Parser Class Initialized
INFO - 2020-03-17 11:20:23 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:23 --> Model Class Initialized
INFO - 2020-03-17 11:20:23 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:23 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:23 --> Template Class Initialized
INFO - 2020-03-17 11:20:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:23 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:23 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:23 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:23 --> services MX_Controller Initialized
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:24 --> Model Class Initialized
INFO - 2020-03-17 11:20:24 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 11:20:24 --> Could not find the language line "Delele"
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2020-03-17 11:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:24 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:24 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:24 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:25 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:25 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:25 --> Total execution time: 1.7928
INFO - 2020-03-17 11:20:26 --> Config Class Initialized
INFO - 2020-03-17 11:20:26 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:26 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:26 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:26 --> URI Class Initialized
INFO - 2020-03-17 11:20:26 --> Router Class Initialized
INFO - 2020-03-17 11:20:26 --> Output Class Initialized
INFO - 2020-03-17 11:20:26 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:26 --> CSRF cookie sent
INFO - 2020-03-17 11:20:26 --> Input Class Initialized
INFO - 2020-03-17 11:20:26 --> Language Class Initialized
INFO - 2020-03-17 11:20:26 --> Language Class Initialized
INFO - 2020-03-17 11:20:26 --> Config Class Initialized
INFO - 2020-03-17 11:20:26 --> Loader Class Initialized
INFO - 2020-03-17 11:20:26 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:26 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:26 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:26 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:26 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:26 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:26 --> Parser Class Initialized
INFO - 2020-03-17 11:20:26 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:26 --> Model Class Initialized
INFO - 2020-03-17 11:20:26 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:26 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:26 --> Template Class Initialized
INFO - 2020-03-17 11:20:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:26 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:26 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:26 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:26 --> users MX_Controller Initialized
DEBUG - 2020-03-17 11:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/users/models/users_model.php
INFO - 2020-03-17 11:20:26 --> Model Class Initialized
ERROR - 2020-03-17 11:20:26 --> Could not find the language line "Last_Order"
INFO - 2020-03-17 11:20:26 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 11:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/users/views/index.php
DEBUG - 2020-03-17 11:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:26 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:26 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:27 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:27 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:27 --> Total execution time: 0.8754
INFO - 2020-03-17 11:20:28 --> Config Class Initialized
INFO - 2020-03-17 11:20:28 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:28 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:28 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:28 --> URI Class Initialized
INFO - 2020-03-17 11:20:28 --> Router Class Initialized
INFO - 2020-03-17 11:20:28 --> Output Class Initialized
INFO - 2020-03-17 11:20:28 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:28 --> CSRF cookie sent
INFO - 2020-03-17 11:20:28 --> Input Class Initialized
INFO - 2020-03-17 11:20:28 --> Language Class Initialized
INFO - 2020-03-17 11:20:28 --> Language Class Initialized
INFO - 2020-03-17 11:20:28 --> Config Class Initialized
INFO - 2020-03-17 11:20:28 --> Loader Class Initialized
INFO - 2020-03-17 11:20:28 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:28 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:28 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:28 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:29 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:29 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:29 --> Parser Class Initialized
INFO - 2020-03-17 11:20:29 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:29 --> Model Class Initialized
INFO - 2020-03-17 11:20:29 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:29 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:29 --> Template Class Initialized
INFO - 2020-03-17 11:20:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:29 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:29 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:29 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:29 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 11:20:29 --> Model Class Initialized
INFO - 2020-03-17 11:20:29 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:29 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:29 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:29 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:29 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:29 --> Total execution time: 0.9252
INFO - 2020-03-17 11:20:31 --> Config Class Initialized
INFO - 2020-03-17 11:20:31 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:31 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:31 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:31 --> URI Class Initialized
INFO - 2020-03-17 11:20:31 --> Router Class Initialized
INFO - 2020-03-17 11:20:31 --> Output Class Initialized
INFO - 2020-03-17 11:20:31 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:31 --> CSRF cookie sent
INFO - 2020-03-17 11:20:31 --> Input Class Initialized
INFO - 2020-03-17 11:20:31 --> Language Class Initialized
INFO - 2020-03-17 11:20:31 --> Language Class Initialized
INFO - 2020-03-17 11:20:31 --> Config Class Initialized
INFO - 2020-03-17 11:20:31 --> Loader Class Initialized
INFO - 2020-03-17 11:20:31 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:31 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:31 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:31 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:31 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:31 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:31 --> Parser Class Initialized
INFO - 2020-03-17 11:20:31 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:31 --> Model Class Initialized
INFO - 2020-03-17 11:20:31 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:31 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:31 --> Template Class Initialized
INFO - 2020-03-17 11:20:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:31 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:31 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:31 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:31 --> blogs MX_Controller Initialized
DEBUG - 2020-03-17 11:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/models/blogs_model.php
INFO - 2020-03-17 11:20:31 --> Model Class Initialized
INFO - 2020-03-17 11:20:31 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 11:20:31 --> Could not find the language line "Blogs"
ERROR - 2020-03-17 11:20:31 --> Could not find the language line "View"
ERROR - 2020-03-17 11:20:31 --> Could not find the language line "View"
ERROR - 2020-03-17 11:20:31 --> Could not find the language line "View"
DEBUG - 2020-03-17 11:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/views/index.php
DEBUG - 2020-03-17 11:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:31 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:31 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:31 --> Model Class Initialized
ERROR - 2020-03-17 11:20:31 --> Could not find the language line "Blogs"
ERROR - 2020-03-17 11:20:32 --> Could not find the language line "Blogs"
DEBUG - 2020-03-17 11:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:32 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:32 --> Total execution time: 0.9565
INFO - 2020-03-17 11:20:33 --> Config Class Initialized
INFO - 2020-03-17 11:20:33 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:33 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:33 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:33 --> URI Class Initialized
INFO - 2020-03-17 11:20:33 --> Router Class Initialized
INFO - 2020-03-17 11:20:33 --> Output Class Initialized
INFO - 2020-03-17 11:20:33 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:33 --> CSRF cookie sent
INFO - 2020-03-17 11:20:33 --> Input Class Initialized
INFO - 2020-03-17 11:20:33 --> Language Class Initialized
INFO - 2020-03-17 11:20:33 --> Language Class Initialized
INFO - 2020-03-17 11:20:33 --> Config Class Initialized
INFO - 2020-03-17 11:20:33 --> Loader Class Initialized
INFO - 2020-03-17 11:20:33 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:33 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:33 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:33 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:33 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:33 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:33 --> Parser Class Initialized
INFO - 2020-03-17 11:20:33 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:33 --> Model Class Initialized
INFO - 2020-03-17 11:20:33 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:33 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:33 --> Template Class Initialized
INFO - 2020-03-17 11:20:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:33 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:33 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:33 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:33 --> provider MX_Controller Initialized
DEBUG - 2020-03-17 11:20:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/models/provider_model.php
INFO - 2020-03-17 11:20:33 --> Model Class Initialized
ERROR - 2020-03-17 11:20:34 --> Could not find the language line "Balance"
INFO - 2020-03-17 11:20:34 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 11:20:34 --> Could not find the language line "api_providers"
DEBUG - 2020-03-17 11:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/views/index.php
DEBUG - 2020-03-17 11:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:34 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:34 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:34 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:34 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:34 --> Total execution time: 0.9260
INFO - 2020-03-17 11:20:35 --> Config Class Initialized
INFO - 2020-03-17 11:20:35 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:35 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:35 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:35 --> URI Class Initialized
INFO - 2020-03-17 11:20:35 --> Router Class Initialized
INFO - 2020-03-17 11:20:35 --> Output Class Initialized
INFO - 2020-03-17 11:20:35 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:35 --> CSRF cookie sent
INFO - 2020-03-17 11:20:35 --> Input Class Initialized
INFO - 2020-03-17 11:20:35 --> Language Class Initialized
INFO - 2020-03-17 11:20:35 --> Language Class Initialized
INFO - 2020-03-17 11:20:35 --> Config Class Initialized
INFO - 2020-03-17 11:20:35 --> Loader Class Initialized
INFO - 2020-03-17 11:20:35 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:35 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:35 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:35 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:35 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:35 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:35 --> Parser Class Initialized
INFO - 2020-03-17 11:20:35 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:35 --> Model Class Initialized
INFO - 2020-03-17 11:20:35 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:35 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:35 --> Template Class Initialized
INFO - 2020-03-17 11:20:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:36 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:36 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:36 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:36 --> faqs MX_Controller Initialized
DEBUG - 2020-03-17 11:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/models/faqs_model.php
INFO - 2020-03-17 11:20:36 --> Model Class Initialized
INFO - 2020-03-17 11:20:36 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 11:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/views/index.php
DEBUG - 2020-03-17 11:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:36 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:36 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:36 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:36 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:36 --> Total execution time: 0.8807
INFO - 2020-03-17 11:20:38 --> Config Class Initialized
INFO - 2020-03-17 11:20:38 --> Hooks Class Initialized
DEBUG - 2020-03-17 11:20:38 --> UTF-8 Support Enabled
INFO - 2020-03-17 11:20:38 --> Utf8 Class Initialized
INFO - 2020-03-17 11:20:38 --> URI Class Initialized
INFO - 2020-03-17 11:20:38 --> Router Class Initialized
INFO - 2020-03-17 11:20:38 --> Output Class Initialized
INFO - 2020-03-17 11:20:38 --> Security Class Initialized
DEBUG - 2020-03-17 11:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 11:20:38 --> CSRF cookie sent
INFO - 2020-03-17 11:20:38 --> Input Class Initialized
INFO - 2020-03-17 11:20:38 --> Language Class Initialized
INFO - 2020-03-17 11:20:38 --> Language Class Initialized
INFO - 2020-03-17 11:20:38 --> Config Class Initialized
INFO - 2020-03-17 11:20:38 --> Loader Class Initialized
INFO - 2020-03-17 11:20:38 --> Helper loaded: url_helper
INFO - 2020-03-17 11:20:38 --> Helper loaded: common_helper
INFO - 2020-03-17 11:20:38 --> Helper loaded: language_helper
INFO - 2020-03-17 11:20:38 --> Helper loaded: cookie_helper
INFO - 2020-03-17 11:20:38 --> Helper loaded: email_helper
INFO - 2020-03-17 11:20:38 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 11:20:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 11:20:39 --> Parser Class Initialized
INFO - 2020-03-17 11:20:39 --> User Agent Class Initialized
INFO - 2020-03-17 11:20:39 --> Model Class Initialized
INFO - 2020-03-17 11:20:39 --> Database Driver Class Initialized
INFO - 2020-03-17 11:20:39 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:39 --> Template Class Initialized
INFO - 2020-03-17 11:20:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 11:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 11:20:39 --> Pagination Class Initialized
DEBUG - 2020-03-17 11:20:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 11:20:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 11:20:39 --> Encryption Class Initialized
INFO - 2020-03-17 11:20:39 --> Controller Class Initialized
DEBUG - 2020-03-17 11:20:39 --> order MX_Controller Initialized
DEBUG - 2020-03-17 11:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2020-03-17 11:20:39 --> Model Class Initialized
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "order_id"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "order_basic_details"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "order_id"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "order_basic_details"
INFO - 2020-03-17 11:20:39 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-17 11:20:39 --> Could not find the language line "Pending"
DEBUG - 2020-03-17 11:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2020-03-17 11:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 11:20:39 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 11:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 11:20:40 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 11:20:40 --> Model Class Initialized
DEBUG - 2020-03-17 11:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 11:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 11:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 11:20:40 --> Final output sent to browser
DEBUG - 2020-03-17 11:20:40 --> Total execution time: 1.4954
INFO - 2020-03-17 14:24:41 --> Config Class Initialized
INFO - 2020-03-17 14:24:41 --> Hooks Class Initialized
DEBUG - 2020-03-17 14:24:41 --> UTF-8 Support Enabled
INFO - 2020-03-17 14:24:41 --> Utf8 Class Initialized
INFO - 2020-03-17 14:24:41 --> URI Class Initialized
INFO - 2020-03-17 14:24:41 --> Router Class Initialized
INFO - 2020-03-17 14:24:41 --> Output Class Initialized
INFO - 2020-03-17 14:24:41 --> Security Class Initialized
DEBUG - 2020-03-17 14:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 14:24:41 --> CSRF cookie sent
INFO - 2020-03-17 14:24:41 --> Input Class Initialized
INFO - 2020-03-17 14:24:41 --> Language Class Initialized
INFO - 2020-03-17 14:24:41 --> Language Class Initialized
INFO - 2020-03-17 14:24:41 --> Config Class Initialized
INFO - 2020-03-17 14:24:41 --> Loader Class Initialized
INFO - 2020-03-17 14:24:41 --> Helper loaded: url_helper
INFO - 2020-03-17 14:24:41 --> Helper loaded: common_helper
INFO - 2020-03-17 14:24:41 --> Helper loaded: language_helper
INFO - 2020-03-17 14:24:41 --> Helper loaded: cookie_helper
INFO - 2020-03-17 14:24:42 --> Helper loaded: email_helper
INFO - 2020-03-17 14:24:42 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 14:24:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 14:24:42 --> Parser Class Initialized
INFO - 2020-03-17 14:24:42 --> User Agent Class Initialized
INFO - 2020-03-17 14:24:42 --> Model Class Initialized
INFO - 2020-03-17 14:24:42 --> Database Driver Class Initialized
INFO - 2020-03-17 14:24:42 --> Model Class Initialized
DEBUG - 2020-03-17 14:24:42 --> Template Class Initialized
INFO - 2020-03-17 14:24:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 14:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 14:24:42 --> Pagination Class Initialized
DEBUG - 2020-03-17 14:24:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 14:24:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 14:24:42 --> Encryption Class Initialized
INFO - 2020-03-17 14:24:42 --> Controller Class Initialized
DEBUG - 2020-03-17 14:24:42 --> order MX_Controller Initialized
DEBUG - 2020-03-17 14:24:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2020-03-17 14:24:42 --> Model Class Initialized
ERROR - 2020-03-17 14:24:42 --> Could not find the language line "order_id"
ERROR - 2020-03-17 14:24:42 --> Could not find the language line "order_basic_details"
ERROR - 2020-03-17 14:24:42 --> Could not find the language line "order_id"
ERROR - 2020-03-17 14:24:42 --> Could not find the language line "order_basic_details"
INFO - 2020-03-17 14:24:42 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 14:24:42 --> Could not find the language line "Awaiting"
ERROR - 2020-03-17 14:24:42 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:42 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:42 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Awaiting"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Pending"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Awaiting"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Awaiting"
ERROR - 2020-03-17 14:24:43 --> Could not find the language line "Pending"
DEBUG - 2020-03-17 14:24:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2020-03-17 14:24:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 14:24:43 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 14:24:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 14:24:43 --> Model Class Initialized
DEBUG - 2020-03-17 14:24:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 14:24:43 --> Model Class Initialized
DEBUG - 2020-03-17 14:24:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 14:24:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 14:24:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 14:24:43 --> Final output sent to browser
DEBUG - 2020-03-17 14:24:43 --> Total execution time: 2.4287
INFO - 2020-03-17 15:40:43 --> Config Class Initialized
INFO - 2020-03-17 15:40:43 --> Hooks Class Initialized
DEBUG - 2020-03-17 15:40:43 --> UTF-8 Support Enabled
INFO - 2020-03-17 15:40:44 --> Utf8 Class Initialized
INFO - 2020-03-17 15:40:44 --> URI Class Initialized
DEBUG - 2020-03-17 15:40:44 --> No URI present. Default controller set.
INFO - 2020-03-17 15:40:44 --> Router Class Initialized
INFO - 2020-03-17 15:40:44 --> Output Class Initialized
INFO - 2020-03-17 15:40:44 --> Security Class Initialized
DEBUG - 2020-03-17 15:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 15:40:44 --> CSRF cookie sent
INFO - 2020-03-17 15:40:44 --> Input Class Initialized
INFO - 2020-03-17 15:40:44 --> Language Class Initialized
INFO - 2020-03-17 15:40:44 --> Language Class Initialized
INFO - 2020-03-17 15:40:44 --> Config Class Initialized
INFO - 2020-03-17 15:40:44 --> Loader Class Initialized
INFO - 2020-03-17 15:40:44 --> Helper loaded: url_helper
INFO - 2020-03-17 15:40:44 --> Helper loaded: common_helper
INFO - 2020-03-17 15:40:44 --> Helper loaded: language_helper
INFO - 2020-03-17 15:40:44 --> Helper loaded: cookie_helper
INFO - 2020-03-17 15:40:44 --> Helper loaded: email_helper
INFO - 2020-03-17 15:40:44 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 15:40:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 15:40:44 --> Parser Class Initialized
INFO - 2020-03-17 15:40:44 --> User Agent Class Initialized
INFO - 2020-03-17 15:40:44 --> Model Class Initialized
INFO - 2020-03-17 15:40:44 --> Database Driver Class Initialized
INFO - 2020-03-17 15:40:44 --> Model Class Initialized
DEBUG - 2020-03-17 15:40:45 --> Template Class Initialized
INFO - 2020-03-17 15:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 15:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 15:40:45 --> Pagination Class Initialized
DEBUG - 2020-03-17 15:40:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 15:40:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 15:40:45 --> Encryption Class Initialized
DEBUG - 2020-03-17 15:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 15:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-17 15:40:45 --> Controller Class Initialized
DEBUG - 2020-03-17 15:40:45 --> pergo MX_Controller Initialized
DEBUG - 2020-03-17 15:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-17 15:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-17 15:40:45 --> Model Class Initialized
INFO - 2020-03-17 15:40:45 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 15:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-17 15:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-17 15:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-17 15:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-17 15:40:45 --> Final output sent to browser
DEBUG - 2020-03-17 15:40:45 --> Total execution time: 2.0583
INFO - 2020-03-17 15:40:48 --> Config Class Initialized
INFO - 2020-03-17 15:40:48 --> Hooks Class Initialized
DEBUG - 2020-03-17 15:40:48 --> UTF-8 Support Enabled
INFO - 2020-03-17 15:40:48 --> Utf8 Class Initialized
INFO - 2020-03-17 15:40:49 --> URI Class Initialized
INFO - 2020-03-17 15:40:49 --> Router Class Initialized
INFO - 2020-03-17 15:40:49 --> Output Class Initialized
INFO - 2020-03-17 15:40:49 --> Security Class Initialized
DEBUG - 2020-03-17 15:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 15:40:49 --> CSRF cookie sent
INFO - 2020-03-17 15:40:49 --> Input Class Initialized
INFO - 2020-03-17 15:40:49 --> Language Class Initialized
INFO - 2020-03-17 15:40:49 --> Language Class Initialized
INFO - 2020-03-17 15:40:49 --> Config Class Initialized
INFO - 2020-03-17 15:40:49 --> Loader Class Initialized
INFO - 2020-03-17 15:40:49 --> Helper loaded: url_helper
INFO - 2020-03-17 15:40:49 --> Helper loaded: common_helper
INFO - 2020-03-17 15:40:49 --> Helper loaded: language_helper
INFO - 2020-03-17 15:40:49 --> Helper loaded: cookie_helper
INFO - 2020-03-17 15:40:49 --> Helper loaded: email_helper
INFO - 2020-03-17 15:40:49 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 15:40:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 15:40:49 --> Parser Class Initialized
INFO - 2020-03-17 15:40:49 --> User Agent Class Initialized
INFO - 2020-03-17 15:40:49 --> Model Class Initialized
INFO - 2020-03-17 15:40:49 --> Database Driver Class Initialized
INFO - 2020-03-17 15:40:49 --> Model Class Initialized
DEBUG - 2020-03-17 15:40:49 --> Template Class Initialized
INFO - 2020-03-17 15:40:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 15:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 15:40:49 --> Pagination Class Initialized
DEBUG - 2020-03-17 15:40:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 15:40:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 15:40:49 --> Encryption Class Initialized
INFO - 2020-03-17 15:40:49 --> Controller Class Initialized
DEBUG - 2020-03-17 15:40:49 --> package MX_Controller Initialized
DEBUG - 2020-03-17 15:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-17 15:40:49 --> Model Class Initialized
INFO - 2020-03-17 15:40:49 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 15:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 15:40:49 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 15:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 15:40:49 --> Model Class Initialized
DEBUG - 2020-03-17 15:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 15:40:49 --> Model Class Initialized
DEBUG - 2020-03-17 15:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-17 15:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:50 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 15:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 15:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 15:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 15:40:50 --> Final output sent to browser
DEBUG - 2020-03-17 15:40:50 --> Total execution time: 1.7287
INFO - 2020-03-17 15:40:53 --> Config Class Initialized
INFO - 2020-03-17 15:40:53 --> Hooks Class Initialized
DEBUG - 2020-03-17 15:40:53 --> UTF-8 Support Enabled
INFO - 2020-03-17 15:40:54 --> Utf8 Class Initialized
INFO - 2020-03-17 15:40:54 --> URI Class Initialized
INFO - 2020-03-17 15:40:54 --> Router Class Initialized
INFO - 2020-03-17 15:40:54 --> Output Class Initialized
INFO - 2020-03-17 15:40:54 --> Security Class Initialized
DEBUG - 2020-03-17 15:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 15:40:54 --> CSRF cookie sent
INFO - 2020-03-17 15:40:54 --> CSRF token verified
INFO - 2020-03-17 15:40:54 --> Input Class Initialized
INFO - 2020-03-17 15:40:54 --> Language Class Initialized
INFO - 2020-03-17 15:40:54 --> Language Class Initialized
INFO - 2020-03-17 15:40:54 --> Config Class Initialized
INFO - 2020-03-17 15:40:54 --> Loader Class Initialized
INFO - 2020-03-17 15:40:54 --> Helper loaded: url_helper
INFO - 2020-03-17 15:40:54 --> Helper loaded: common_helper
INFO - 2020-03-17 15:40:54 --> Helper loaded: language_helper
INFO - 2020-03-17 15:40:54 --> Helper loaded: cookie_helper
INFO - 2020-03-17 15:40:54 --> Helper loaded: email_helper
INFO - 2020-03-17 15:40:54 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 15:40:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 15:40:54 --> Parser Class Initialized
INFO - 2020-03-17 15:40:54 --> User Agent Class Initialized
INFO - 2020-03-17 15:40:54 --> Model Class Initialized
INFO - 2020-03-17 15:40:54 --> Database Driver Class Initialized
INFO - 2020-03-17 15:40:54 --> Model Class Initialized
DEBUG - 2020-03-17 15:40:54 --> Template Class Initialized
INFO - 2020-03-17 15:40:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 15:40:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 15:40:54 --> Pagination Class Initialized
DEBUG - 2020-03-17 15:40:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 15:40:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 15:40:54 --> Encryption Class Initialized
INFO - 2020-03-17 15:40:54 --> Controller Class Initialized
DEBUG - 2020-03-17 15:40:54 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 15:40:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 15:40:54 --> Model Class Initialized
INFO - 2020-03-17 15:40:54 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 15:40:54 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 15:40:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 15:40:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 15:40:54 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 15:40:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 15:40:54 --> Model Class Initialized
DEBUG - 2020-03-17 15:40:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 15:40:54 --> Model Class Initialized
ERROR - 2020-03-17 15:40:54 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:54 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:54 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 15:40:55 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 15:40:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 15:40:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 15:40:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 15:40:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 15:40:55 --> Final output sent to browser
DEBUG - 2020-03-17 15:40:55 --> Total execution time: 1.3842
INFO - 2020-03-17 15:41:04 --> Config Class Initialized
INFO - 2020-03-17 15:41:04 --> Hooks Class Initialized
DEBUG - 2020-03-17 15:41:04 --> UTF-8 Support Enabled
INFO - 2020-03-17 15:41:04 --> Utf8 Class Initialized
INFO - 2020-03-17 15:41:04 --> URI Class Initialized
INFO - 2020-03-17 15:41:04 --> Router Class Initialized
INFO - 2020-03-17 15:41:04 --> Output Class Initialized
INFO - 2020-03-17 15:41:04 --> Security Class Initialized
DEBUG - 2020-03-17 15:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 15:41:04 --> CSRF cookie sent
INFO - 2020-03-17 15:41:04 --> CSRF token verified
INFO - 2020-03-17 15:41:04 --> Input Class Initialized
INFO - 2020-03-17 15:41:04 --> Language Class Initialized
INFO - 2020-03-17 15:41:04 --> Language Class Initialized
INFO - 2020-03-17 15:41:04 --> Config Class Initialized
INFO - 2020-03-17 15:41:04 --> Loader Class Initialized
INFO - 2020-03-17 15:41:04 --> Helper loaded: url_helper
INFO - 2020-03-17 15:41:04 --> Helper loaded: common_helper
INFO - 2020-03-17 15:41:04 --> Helper loaded: language_helper
INFO - 2020-03-17 15:41:04 --> Helper loaded: cookie_helper
INFO - 2020-03-17 15:41:04 --> Helper loaded: email_helper
INFO - 2020-03-17 15:41:04 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 15:41:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 15:41:04 --> Parser Class Initialized
INFO - 2020-03-17 15:41:04 --> User Agent Class Initialized
INFO - 2020-03-17 15:41:04 --> Model Class Initialized
INFO - 2020-03-17 15:41:04 --> Database Driver Class Initialized
INFO - 2020-03-17 15:41:04 --> Model Class Initialized
DEBUG - 2020-03-17 15:41:04 --> Template Class Initialized
INFO - 2020-03-17 15:41:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 15:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 15:41:04 --> Pagination Class Initialized
DEBUG - 2020-03-17 15:41:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 15:41:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 15:41:04 --> Encryption Class Initialized
INFO - 2020-03-17 15:41:04 --> Controller Class Initialized
DEBUG - 2020-03-17 15:41:04 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 15:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 15:41:04 --> Model Class Initialized
DEBUG - 2020-03-17 15:41:04 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 15:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 15:41:04 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 15:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 15:41:04 --> Final output sent to browser
DEBUG - 2020-03-17 15:41:04 --> Total execution time: 0.7727
INFO - 2020-03-17 15:41:15 --> Config Class Initialized
INFO - 2020-03-17 15:41:15 --> Hooks Class Initialized
DEBUG - 2020-03-17 15:41:15 --> UTF-8 Support Enabled
INFO - 2020-03-17 15:41:15 --> Utf8 Class Initialized
INFO - 2020-03-17 15:41:15 --> URI Class Initialized
INFO - 2020-03-17 15:41:15 --> Router Class Initialized
INFO - 2020-03-17 15:41:15 --> Output Class Initialized
INFO - 2020-03-17 15:41:15 --> Security Class Initialized
DEBUG - 2020-03-17 15:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 15:41:15 --> Input Class Initialized
INFO - 2020-03-17 15:41:15 --> Language Class Initialized
INFO - 2020-03-17 15:41:15 --> Language Class Initialized
INFO - 2020-03-17 15:41:15 --> Config Class Initialized
INFO - 2020-03-17 15:41:15 --> Loader Class Initialized
INFO - 2020-03-17 15:41:15 --> Helper loaded: url_helper
INFO - 2020-03-17 15:41:15 --> Helper loaded: common_helper
INFO - 2020-03-17 15:41:15 --> Helper loaded: language_helper
INFO - 2020-03-17 15:41:15 --> Helper loaded: cookie_helper
INFO - 2020-03-17 15:41:16 --> Helper loaded: email_helper
INFO - 2020-03-17 15:41:16 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 15:41:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 15:41:16 --> Parser Class Initialized
INFO - 2020-03-17 15:41:16 --> User Agent Class Initialized
INFO - 2020-03-17 15:41:16 --> Model Class Initialized
INFO - 2020-03-17 15:41:16 --> Database Driver Class Initialized
INFO - 2020-03-17 15:41:16 --> Model Class Initialized
DEBUG - 2020-03-17 15:41:16 --> Template Class Initialized
INFO - 2020-03-17 15:41:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 15:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 15:41:16 --> Pagination Class Initialized
DEBUG - 2020-03-17 15:41:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 15:41:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 15:41:16 --> Encryption Class Initialized
INFO - 2020-03-17 15:41:16 --> Controller Class Initialized
DEBUG - 2020-03-17 15:41:16 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 15:41:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 15:41:16 --> Model Class Initialized
INFO - 2020-03-17 15:42:04 --> Config Class Initialized
INFO - 2020-03-17 15:42:04 --> Hooks Class Initialized
DEBUG - 2020-03-17 15:42:04 --> UTF-8 Support Enabled
INFO - 2020-03-17 15:42:04 --> Utf8 Class Initialized
INFO - 2020-03-17 15:42:04 --> URI Class Initialized
INFO - 2020-03-17 15:42:04 --> Router Class Initialized
INFO - 2020-03-17 15:42:04 --> Output Class Initialized
INFO - 2020-03-17 15:42:04 --> Security Class Initialized
DEBUG - 2020-03-17 15:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 15:42:04 --> Input Class Initialized
INFO - 2020-03-17 15:42:04 --> Language Class Initialized
INFO - 2020-03-17 15:42:04 --> Language Class Initialized
INFO - 2020-03-17 15:42:04 --> Config Class Initialized
INFO - 2020-03-17 15:42:04 --> Loader Class Initialized
INFO - 2020-03-17 15:42:04 --> Helper loaded: url_helper
INFO - 2020-03-17 15:42:05 --> Helper loaded: common_helper
INFO - 2020-03-17 15:42:05 --> Helper loaded: language_helper
INFO - 2020-03-17 15:42:05 --> Helper loaded: cookie_helper
INFO - 2020-03-17 15:42:05 --> Helper loaded: email_helper
INFO - 2020-03-17 15:42:05 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 15:42:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 15:42:05 --> Parser Class Initialized
INFO - 2020-03-17 15:42:05 --> User Agent Class Initialized
INFO - 2020-03-17 15:42:05 --> Model Class Initialized
INFO - 2020-03-17 15:42:05 --> Database Driver Class Initialized
INFO - 2020-03-17 15:42:05 --> Model Class Initialized
DEBUG - 2020-03-17 15:42:05 --> Template Class Initialized
INFO - 2020-03-17 15:42:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 15:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 15:42:05 --> Pagination Class Initialized
DEBUG - 2020-03-17 15:42:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 15:42:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 15:42:05 --> Encryption Class Initialized
INFO - 2020-03-17 15:42:05 --> Controller Class Initialized
DEBUG - 2020-03-17 15:42:05 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 15:42:05 --> Model Class Initialized
INFO - 2020-03-17 15:42:17 --> Config Class Initialized
INFO - 2020-03-17 15:42:17 --> Hooks Class Initialized
DEBUG - 2020-03-17 15:42:17 --> UTF-8 Support Enabled
INFO - 2020-03-17 15:42:17 --> Utf8 Class Initialized
INFO - 2020-03-17 15:42:17 --> URI Class Initialized
INFO - 2020-03-17 15:42:17 --> Router Class Initialized
INFO - 2020-03-17 15:42:17 --> Output Class Initialized
INFO - 2020-03-17 15:42:17 --> Security Class Initialized
DEBUG - 2020-03-17 15:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 15:42:17 --> Input Class Initialized
INFO - 2020-03-17 15:42:17 --> Language Class Initialized
INFO - 2020-03-17 15:42:17 --> Language Class Initialized
INFO - 2020-03-17 15:42:17 --> Config Class Initialized
INFO - 2020-03-17 15:42:17 --> Loader Class Initialized
INFO - 2020-03-17 15:42:17 --> Helper loaded: url_helper
INFO - 2020-03-17 15:42:17 --> Helper loaded: common_helper
INFO - 2020-03-17 15:42:17 --> Helper loaded: language_helper
INFO - 2020-03-17 15:42:17 --> Helper loaded: cookie_helper
INFO - 2020-03-17 15:42:17 --> Helper loaded: email_helper
INFO - 2020-03-17 15:42:17 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 15:42:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 15:42:17 --> Parser Class Initialized
INFO - 2020-03-17 15:42:17 --> User Agent Class Initialized
INFO - 2020-03-17 15:42:17 --> Model Class Initialized
INFO - 2020-03-17 15:42:17 --> Database Driver Class Initialized
INFO - 2020-03-17 15:42:17 --> Model Class Initialized
DEBUG - 2020-03-17 15:42:17 --> Template Class Initialized
INFO - 2020-03-17 15:42:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 15:42:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 15:42:17 --> Pagination Class Initialized
DEBUG - 2020-03-17 15:42:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 15:42:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 15:42:17 --> Encryption Class Initialized
INFO - 2020-03-17 15:42:17 --> Controller Class Initialized
DEBUG - 2020-03-17 15:42:17 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 15:42:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 15:42:17 --> Model Class Initialized
INFO - 2020-03-17 16:26:39 --> Config Class Initialized
INFO - 2020-03-17 16:26:39 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:26:39 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:26:39 --> Utf8 Class Initialized
INFO - 2020-03-17 16:26:39 --> URI Class Initialized
INFO - 2020-03-17 16:26:39 --> Router Class Initialized
INFO - 2020-03-17 16:26:39 --> Output Class Initialized
INFO - 2020-03-17 16:26:39 --> Security Class Initialized
DEBUG - 2020-03-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:26:39 --> Input Class Initialized
INFO - 2020-03-17 16:26:39 --> Language Class Initialized
INFO - 2020-03-17 16:26:39 --> Language Class Initialized
INFO - 2020-03-17 16:26:39 --> Config Class Initialized
INFO - 2020-03-17 16:26:39 --> Loader Class Initialized
INFO - 2020-03-17 16:26:39 --> Helper loaded: url_helper
INFO - 2020-03-17 16:26:39 --> Helper loaded: common_helper
INFO - 2020-03-17 16:26:39 --> Helper loaded: language_helper
INFO - 2020-03-17 16:26:39 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:26:39 --> Helper loaded: email_helper
INFO - 2020-03-17 16:26:39 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:26:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:26:39 --> Parser Class Initialized
INFO - 2020-03-17 16:26:39 --> User Agent Class Initialized
INFO - 2020-03-17 16:26:39 --> Model Class Initialized
INFO - 2020-03-17 16:26:39 --> Database Driver Class Initialized
INFO - 2020-03-17 16:26:39 --> Model Class Initialized
DEBUG - 2020-03-17 16:26:39 --> Template Class Initialized
INFO - 2020-03-17 16:26:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:26:39 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:26:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:26:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:26:39 --> Encryption Class Initialized
INFO - 2020-03-17 16:26:39 --> Controller Class Initialized
DEBUG - 2020-03-17 16:26:39 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:26:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 16:26:39 --> Model Class Initialized
INFO - 2020-03-17 16:31:39 --> Config Class Initialized
INFO - 2020-03-17 16:31:39 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:31:39 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:31:39 --> Utf8 Class Initialized
INFO - 2020-03-17 16:31:39 --> URI Class Initialized
INFO - 2020-03-17 16:31:39 --> Router Class Initialized
INFO - 2020-03-17 16:31:39 --> Output Class Initialized
INFO - 2020-03-17 16:31:39 --> Security Class Initialized
DEBUG - 2020-03-17 16:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:31:39 --> CSRF cookie sent
INFO - 2020-03-17 16:31:39 --> CSRF token verified
INFO - 2020-03-17 16:31:39 --> Input Class Initialized
INFO - 2020-03-17 16:31:39 --> Language Class Initialized
INFO - 2020-03-17 16:31:39 --> Language Class Initialized
INFO - 2020-03-17 16:31:39 --> Config Class Initialized
INFO - 2020-03-17 16:31:39 --> Loader Class Initialized
INFO - 2020-03-17 16:31:39 --> Helper loaded: url_helper
INFO - 2020-03-17 16:31:39 --> Helper loaded: common_helper
INFO - 2020-03-17 16:31:39 --> Helper loaded: language_helper
INFO - 2020-03-17 16:31:39 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:31:39 --> Helper loaded: email_helper
INFO - 2020-03-17 16:31:39 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:31:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:31:39 --> Parser Class Initialized
INFO - 2020-03-17 16:31:39 --> User Agent Class Initialized
INFO - 2020-03-17 16:31:39 --> Model Class Initialized
INFO - 2020-03-17 16:31:39 --> Database Driver Class Initialized
INFO - 2020-03-17 16:31:39 --> Model Class Initialized
DEBUG - 2020-03-17 16:31:39 --> Template Class Initialized
INFO - 2020-03-17 16:31:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:31:39 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:31:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:31:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:31:39 --> Encryption Class Initialized
INFO - 2020-03-17 16:31:39 --> Controller Class Initialized
DEBUG - 2020-03-17 16:31:39 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:31:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:31:39 --> Model Class Initialized
DEBUG - 2020-03-17 16:31:39 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:31:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 16:31:39 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 16:31:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 16:31:39 --> Final output sent to browser
DEBUG - 2020-03-17 16:31:39 --> Total execution time: 0.7479
INFO - 2020-03-17 16:43:29 --> Config Class Initialized
INFO - 2020-03-17 16:43:29 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:43:29 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:43:29 --> Utf8 Class Initialized
INFO - 2020-03-17 16:43:29 --> URI Class Initialized
INFO - 2020-03-17 16:43:29 --> Router Class Initialized
INFO - 2020-03-17 16:43:29 --> Output Class Initialized
INFO - 2020-03-17 16:43:29 --> Security Class Initialized
DEBUG - 2020-03-17 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:43:30 --> CSRF cookie sent
INFO - 2020-03-17 16:43:30 --> CSRF token verified
INFO - 2020-03-17 16:43:30 --> Input Class Initialized
INFO - 2020-03-17 16:43:30 --> Language Class Initialized
INFO - 2020-03-17 16:43:30 --> Language Class Initialized
INFO - 2020-03-17 16:43:30 --> Config Class Initialized
INFO - 2020-03-17 16:43:30 --> Loader Class Initialized
INFO - 2020-03-17 16:43:30 --> Helper loaded: url_helper
INFO - 2020-03-17 16:43:30 --> Helper loaded: common_helper
INFO - 2020-03-17 16:43:30 --> Helper loaded: language_helper
INFO - 2020-03-17 16:43:30 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:43:30 --> Helper loaded: email_helper
INFO - 2020-03-17 16:43:30 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:43:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:43:30 --> Parser Class Initialized
INFO - 2020-03-17 16:43:30 --> User Agent Class Initialized
INFO - 2020-03-17 16:43:30 --> Model Class Initialized
INFO - 2020-03-17 16:43:30 --> Database Driver Class Initialized
INFO - 2020-03-17 16:43:30 --> Model Class Initialized
DEBUG - 2020-03-17 16:43:30 --> Template Class Initialized
INFO - 2020-03-17 16:43:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:43:30 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:43:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:43:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:43:30 --> Encryption Class Initialized
INFO - 2020-03-17 16:43:30 --> Controller Class Initialized
DEBUG - 2020-03-17 16:43:30 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:43:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:43:30 --> Model Class Initialized
INFO - 2020-03-17 16:43:30 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 16:43:30 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 16:43:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 16:43:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 16:43:30 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 16:43:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 16:43:30 --> Model Class Initialized
DEBUG - 2020-03-17 16:43:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 16:43:30 --> Model Class Initialized
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:43:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:43:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:43:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:43:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:43:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:43:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:43:30 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:43:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 16:43:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 16:43:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 16:43:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 16:43:31 --> Final output sent to browser
DEBUG - 2020-03-17 16:43:31 --> Total execution time: 1.1512
INFO - 2020-03-17 16:43:38 --> Config Class Initialized
INFO - 2020-03-17 16:43:38 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:43:38 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:43:38 --> Utf8 Class Initialized
INFO - 2020-03-17 16:43:38 --> URI Class Initialized
INFO - 2020-03-17 16:43:38 --> Router Class Initialized
INFO - 2020-03-17 16:43:38 --> Output Class Initialized
INFO - 2020-03-17 16:43:39 --> Security Class Initialized
DEBUG - 2020-03-17 16:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:43:39 --> CSRF cookie sent
INFO - 2020-03-17 16:43:39 --> CSRF token verified
INFO - 2020-03-17 16:43:39 --> Input Class Initialized
INFO - 2020-03-17 16:43:39 --> Language Class Initialized
INFO - 2020-03-17 16:43:39 --> Language Class Initialized
INFO - 2020-03-17 16:43:39 --> Config Class Initialized
INFO - 2020-03-17 16:43:39 --> Loader Class Initialized
INFO - 2020-03-17 16:43:39 --> Helper loaded: url_helper
INFO - 2020-03-17 16:43:39 --> Helper loaded: common_helper
INFO - 2020-03-17 16:43:39 --> Helper loaded: language_helper
INFO - 2020-03-17 16:43:39 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:43:39 --> Helper loaded: email_helper
INFO - 2020-03-17 16:43:39 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:43:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:43:39 --> Parser Class Initialized
INFO - 2020-03-17 16:43:39 --> User Agent Class Initialized
INFO - 2020-03-17 16:43:39 --> Model Class Initialized
INFO - 2020-03-17 16:43:39 --> Database Driver Class Initialized
INFO - 2020-03-17 16:43:39 --> Model Class Initialized
DEBUG - 2020-03-17 16:43:39 --> Template Class Initialized
INFO - 2020-03-17 16:43:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:43:39 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:43:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:43:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:43:39 --> Encryption Class Initialized
INFO - 2020-03-17 16:43:39 --> Controller Class Initialized
DEBUG - 2020-03-17 16:43:39 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:43:39 --> Model Class Initialized
DEBUG - 2020-03-17 16:43:39 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 16:43:39 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 16:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 16:43:39 --> Final output sent to browser
DEBUG - 2020-03-17 16:43:39 --> Total execution time: 0.7201
INFO - 2020-03-17 16:43:50 --> Config Class Initialized
INFO - 2020-03-17 16:43:50 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:43:50 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:43:50 --> Utf8 Class Initialized
INFO - 2020-03-17 16:43:50 --> URI Class Initialized
INFO - 2020-03-17 16:43:50 --> Router Class Initialized
INFO - 2020-03-17 16:43:50 --> Output Class Initialized
INFO - 2020-03-17 16:43:50 --> Security Class Initialized
DEBUG - 2020-03-17 16:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:43:50 --> Input Class Initialized
INFO - 2020-03-17 16:43:50 --> Language Class Initialized
INFO - 2020-03-17 16:43:50 --> Language Class Initialized
INFO - 2020-03-17 16:43:50 --> Config Class Initialized
INFO - 2020-03-17 16:43:50 --> Loader Class Initialized
INFO - 2020-03-17 16:43:50 --> Helper loaded: url_helper
INFO - 2020-03-17 16:43:50 --> Helper loaded: common_helper
INFO - 2020-03-17 16:43:50 --> Helper loaded: language_helper
INFO - 2020-03-17 16:43:50 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:43:50 --> Helper loaded: email_helper
INFO - 2020-03-17 16:43:50 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:43:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:43:50 --> Parser Class Initialized
INFO - 2020-03-17 16:43:50 --> User Agent Class Initialized
INFO - 2020-03-17 16:43:50 --> Model Class Initialized
INFO - 2020-03-17 16:43:50 --> Database Driver Class Initialized
INFO - 2020-03-17 16:43:50 --> Model Class Initialized
DEBUG - 2020-03-17 16:43:50 --> Template Class Initialized
INFO - 2020-03-17 16:43:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:43:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:43:50 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:43:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:43:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:43:50 --> Encryption Class Initialized
INFO - 2020-03-17 16:43:50 --> Controller Class Initialized
DEBUG - 2020-03-17 16:43:50 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:43:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 16:43:50 --> Model Class Initialized
INFO - 2020-03-17 16:47:47 --> Config Class Initialized
INFO - 2020-03-17 16:47:47 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:47:47 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:47:47 --> Utf8 Class Initialized
INFO - 2020-03-17 16:47:47 --> URI Class Initialized
INFO - 2020-03-17 16:47:47 --> Router Class Initialized
INFO - 2020-03-17 16:47:47 --> Output Class Initialized
INFO - 2020-03-17 16:47:47 --> Security Class Initialized
DEBUG - 2020-03-17 16:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:47:47 --> CSRF cookie sent
INFO - 2020-03-17 16:47:47 --> CSRF token verified
INFO - 2020-03-17 16:47:47 --> Input Class Initialized
INFO - 2020-03-17 16:47:47 --> Language Class Initialized
INFO - 2020-03-17 16:47:47 --> Language Class Initialized
INFO - 2020-03-17 16:47:47 --> Config Class Initialized
INFO - 2020-03-17 16:47:47 --> Loader Class Initialized
INFO - 2020-03-17 16:47:48 --> Helper loaded: url_helper
INFO - 2020-03-17 16:47:48 --> Helper loaded: common_helper
INFO - 2020-03-17 16:47:48 --> Helper loaded: language_helper
INFO - 2020-03-17 16:47:48 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:47:48 --> Helper loaded: email_helper
INFO - 2020-03-17 16:47:48 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:47:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:47:48 --> Parser Class Initialized
INFO - 2020-03-17 16:47:48 --> User Agent Class Initialized
INFO - 2020-03-17 16:47:48 --> Model Class Initialized
INFO - 2020-03-17 16:47:48 --> Database Driver Class Initialized
INFO - 2020-03-17 16:47:48 --> Model Class Initialized
DEBUG - 2020-03-17 16:47:48 --> Template Class Initialized
INFO - 2020-03-17 16:47:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:47:48 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:47:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:47:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:47:48 --> Encryption Class Initialized
INFO - 2020-03-17 16:47:48 --> Controller Class Initialized
DEBUG - 2020-03-17 16:47:48 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:47:48 --> Model Class Initialized
INFO - 2020-03-17 16:47:48 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 16:47:48 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 16:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 16:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 16:47:48 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 16:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 16:47:48 --> Model Class Initialized
DEBUG - 2020-03-17 16:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 16:47:48 --> Model Class Initialized
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:47:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:47:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:47:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:47:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:47:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:47:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:47:48 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:47:49 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:47:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 16:47:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 16:47:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 16:47:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 16:47:49 --> Final output sent to browser
DEBUG - 2020-03-17 16:47:49 --> Total execution time: 1.4530
INFO - 2020-03-17 16:47:56 --> Config Class Initialized
INFO - 2020-03-17 16:47:56 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:47:56 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:47:56 --> Utf8 Class Initialized
INFO - 2020-03-17 16:47:56 --> URI Class Initialized
INFO - 2020-03-17 16:47:56 --> Router Class Initialized
INFO - 2020-03-17 16:47:56 --> Output Class Initialized
INFO - 2020-03-17 16:47:56 --> Security Class Initialized
DEBUG - 2020-03-17 16:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:47:56 --> CSRF cookie sent
INFO - 2020-03-17 16:47:56 --> CSRF token verified
INFO - 2020-03-17 16:47:56 --> Input Class Initialized
INFO - 2020-03-17 16:47:56 --> Language Class Initialized
INFO - 2020-03-17 16:47:56 --> Language Class Initialized
INFO - 2020-03-17 16:47:56 --> Config Class Initialized
INFO - 2020-03-17 16:47:56 --> Loader Class Initialized
INFO - 2020-03-17 16:47:56 --> Helper loaded: url_helper
INFO - 2020-03-17 16:47:56 --> Helper loaded: common_helper
INFO - 2020-03-17 16:47:56 --> Helper loaded: language_helper
INFO - 2020-03-17 16:47:56 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:47:56 --> Helper loaded: email_helper
INFO - 2020-03-17 16:47:56 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:47:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:47:56 --> Parser Class Initialized
INFO - 2020-03-17 16:47:57 --> User Agent Class Initialized
INFO - 2020-03-17 16:47:57 --> Model Class Initialized
INFO - 2020-03-17 16:47:57 --> Database Driver Class Initialized
INFO - 2020-03-17 16:47:57 --> Model Class Initialized
DEBUG - 2020-03-17 16:47:57 --> Template Class Initialized
INFO - 2020-03-17 16:47:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:47:57 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:47:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:47:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:47:57 --> Encryption Class Initialized
INFO - 2020-03-17 16:47:57 --> Controller Class Initialized
DEBUG - 2020-03-17 16:47:57 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:47:57 --> Model Class Initialized
DEBUG - 2020-03-17 16:47:57 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 16:47:57 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 16:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 16:47:57 --> Final output sent to browser
DEBUG - 2020-03-17 16:47:57 --> Total execution time: 0.7066
INFO - 2020-03-17 16:48:20 --> Config Class Initialized
INFO - 2020-03-17 16:48:20 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:48:20 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:48:20 --> Utf8 Class Initialized
INFO - 2020-03-17 16:48:20 --> URI Class Initialized
INFO - 2020-03-17 16:48:20 --> Router Class Initialized
INFO - 2020-03-17 16:48:20 --> Output Class Initialized
INFO - 2020-03-17 16:48:20 --> Security Class Initialized
DEBUG - 2020-03-17 16:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:48:20 --> Input Class Initialized
INFO - 2020-03-17 16:48:20 --> Language Class Initialized
INFO - 2020-03-17 16:48:20 --> Language Class Initialized
INFO - 2020-03-17 16:48:20 --> Config Class Initialized
INFO - 2020-03-17 16:48:20 --> Loader Class Initialized
INFO - 2020-03-17 16:48:20 --> Helper loaded: url_helper
INFO - 2020-03-17 16:48:20 --> Helper loaded: common_helper
INFO - 2020-03-17 16:48:20 --> Helper loaded: language_helper
INFO - 2020-03-17 16:48:20 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:48:20 --> Helper loaded: email_helper
INFO - 2020-03-17 16:48:20 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:48:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:48:20 --> Parser Class Initialized
INFO - 2020-03-17 16:48:20 --> User Agent Class Initialized
INFO - 2020-03-17 16:48:20 --> Model Class Initialized
INFO - 2020-03-17 16:48:20 --> Database Driver Class Initialized
INFO - 2020-03-17 16:48:20 --> Model Class Initialized
DEBUG - 2020-03-17 16:48:20 --> Template Class Initialized
INFO - 2020-03-17 16:48:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:48:20 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:48:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:48:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:48:20 --> Encryption Class Initialized
INFO - 2020-03-17 16:48:20 --> Controller Class Initialized
DEBUG - 2020-03-17 16:48:20 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 16:48:20 --> Model Class Initialized
INFO - 2020-03-17 16:48:51 --> Config Class Initialized
INFO - 2020-03-17 16:48:51 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:48:51 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:48:51 --> Utf8 Class Initialized
INFO - 2020-03-17 16:48:51 --> URI Class Initialized
INFO - 2020-03-17 16:48:51 --> Router Class Initialized
INFO - 2020-03-17 16:48:51 --> Output Class Initialized
INFO - 2020-03-17 16:48:51 --> Security Class Initialized
DEBUG - 2020-03-17 16:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:48:51 --> CSRF cookie sent
INFO - 2020-03-17 16:48:51 --> CSRF token verified
INFO - 2020-03-17 16:48:52 --> Input Class Initialized
INFO - 2020-03-17 16:48:52 --> Language Class Initialized
INFO - 2020-03-17 16:48:52 --> Language Class Initialized
INFO - 2020-03-17 16:48:52 --> Config Class Initialized
INFO - 2020-03-17 16:48:52 --> Loader Class Initialized
INFO - 2020-03-17 16:48:52 --> Helper loaded: url_helper
INFO - 2020-03-17 16:48:52 --> Helper loaded: common_helper
INFO - 2020-03-17 16:48:52 --> Helper loaded: language_helper
INFO - 2020-03-17 16:48:52 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:48:52 --> Helper loaded: email_helper
INFO - 2020-03-17 16:48:52 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:48:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:48:52 --> Parser Class Initialized
INFO - 2020-03-17 16:48:52 --> User Agent Class Initialized
INFO - 2020-03-17 16:48:52 --> Model Class Initialized
INFO - 2020-03-17 16:48:52 --> Database Driver Class Initialized
INFO - 2020-03-17 16:48:52 --> Model Class Initialized
DEBUG - 2020-03-17 16:48:52 --> Template Class Initialized
INFO - 2020-03-17 16:48:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:48:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:48:52 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:48:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:48:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:48:52 --> Encryption Class Initialized
INFO - 2020-03-17 16:48:52 --> Controller Class Initialized
DEBUG - 2020-03-17 16:48:52 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:48:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:48:52 --> Model Class Initialized
DEBUG - 2020-03-17 16:48:52 --> cardinity MX_Controller Initialized
DEBUG - 2020-03-17 16:48:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/index.php
INFO - 2020-03-17 16:48:52 --> Final output sent to browser
DEBUG - 2020-03-17 16:48:52 --> Total execution time: 0.6635
INFO - 2020-03-17 16:49:01 --> Config Class Initialized
INFO - 2020-03-17 16:49:01 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:49:01 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:49:01 --> Utf8 Class Initialized
INFO - 2020-03-17 16:49:01 --> URI Class Initialized
INFO - 2020-03-17 16:49:01 --> Router Class Initialized
INFO - 2020-03-17 16:49:01 --> Output Class Initialized
INFO - 2020-03-17 16:49:01 --> Security Class Initialized
DEBUG - 2020-03-17 16:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:49:01 --> CSRF cookie sent
INFO - 2020-03-17 16:49:01 --> CSRF token verified
INFO - 2020-03-17 16:49:01 --> Input Class Initialized
INFO - 2020-03-17 16:49:01 --> Language Class Initialized
INFO - 2020-03-17 16:49:01 --> Language Class Initialized
INFO - 2020-03-17 16:49:01 --> Config Class Initialized
INFO - 2020-03-17 16:49:01 --> Loader Class Initialized
INFO - 2020-03-17 16:49:01 --> Helper loaded: url_helper
INFO - 2020-03-17 16:49:01 --> Helper loaded: common_helper
INFO - 2020-03-17 16:49:01 --> Helper loaded: language_helper
INFO - 2020-03-17 16:49:01 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:49:01 --> Helper loaded: email_helper
INFO - 2020-03-17 16:49:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:49:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:49:01 --> Parser Class Initialized
INFO - 2020-03-17 16:49:01 --> User Agent Class Initialized
INFO - 2020-03-17 16:49:01 --> Model Class Initialized
INFO - 2020-03-17 16:49:01 --> Database Driver Class Initialized
INFO - 2020-03-17 16:49:01 --> Model Class Initialized
DEBUG - 2020-03-17 16:49:01 --> Template Class Initialized
INFO - 2020-03-17 16:49:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:49:01 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:49:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:49:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:49:01 --> Encryption Class Initialized
INFO - 2020-03-17 16:49:01 --> Controller Class Initialized
DEBUG - 2020-03-17 16:49:01 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:49:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:49:01 --> Model Class Initialized
INFO - 2020-03-17 16:49:01 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 16:49:01 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 16:49:02 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 16:49:02 --> Model Class Initialized
DEBUG - 2020-03-17 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 16:49:02 --> Model Class Initialized
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:49:02 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 16:49:02 --> Final output sent to browser
DEBUG - 2020-03-17 16:49:02 --> Total execution time: 1.5082
INFO - 2020-03-17 16:49:57 --> Config Class Initialized
INFO - 2020-03-17 16:49:57 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:49:57 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:49:57 --> Utf8 Class Initialized
INFO - 2020-03-17 16:49:57 --> URI Class Initialized
INFO - 2020-03-17 16:49:57 --> Router Class Initialized
INFO - 2020-03-17 16:49:57 --> Output Class Initialized
INFO - 2020-03-17 16:49:57 --> Security Class Initialized
DEBUG - 2020-03-17 16:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:49:58 --> CSRF cookie sent
INFO - 2020-03-17 16:49:58 --> CSRF token verified
INFO - 2020-03-17 16:49:58 --> Input Class Initialized
INFO - 2020-03-17 16:49:58 --> Language Class Initialized
INFO - 2020-03-17 16:49:58 --> Language Class Initialized
INFO - 2020-03-17 16:49:58 --> Config Class Initialized
INFO - 2020-03-17 16:49:58 --> Loader Class Initialized
INFO - 2020-03-17 16:49:58 --> Helper loaded: url_helper
INFO - 2020-03-17 16:49:58 --> Helper loaded: common_helper
INFO - 2020-03-17 16:49:58 --> Helper loaded: language_helper
INFO - 2020-03-17 16:49:58 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:49:58 --> Helper loaded: email_helper
INFO - 2020-03-17 16:49:58 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:49:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:49:58 --> Parser Class Initialized
INFO - 2020-03-17 16:49:58 --> User Agent Class Initialized
INFO - 2020-03-17 16:49:58 --> Model Class Initialized
INFO - 2020-03-17 16:49:58 --> Database Driver Class Initialized
INFO - 2020-03-17 16:49:58 --> Model Class Initialized
DEBUG - 2020-03-17 16:49:58 --> Template Class Initialized
INFO - 2020-03-17 16:49:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:49:58 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:49:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:49:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:49:58 --> Encryption Class Initialized
INFO - 2020-03-17 16:49:58 --> Controller Class Initialized
DEBUG - 2020-03-17 16:49:58 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:49:58 --> Model Class Initialized
DEBUG - 2020-03-17 16:49:58 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 16:49:58 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 16:49:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 16:49:58 --> Final output sent to browser
DEBUG - 2020-03-17 16:49:58 --> Total execution time: 0.8178
INFO - 2020-03-17 16:50:52 --> Config Class Initialized
INFO - 2020-03-17 16:50:52 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:50:52 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:50:52 --> Utf8 Class Initialized
INFO - 2020-03-17 16:50:52 --> URI Class Initialized
INFO - 2020-03-17 16:50:52 --> Router Class Initialized
INFO - 2020-03-17 16:50:52 --> Output Class Initialized
INFO - 2020-03-17 16:50:52 --> Security Class Initialized
DEBUG - 2020-03-17 16:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:50:52 --> CSRF cookie sent
INFO - 2020-03-17 16:50:52 --> CSRF token verified
INFO - 2020-03-17 16:50:52 --> Input Class Initialized
INFO - 2020-03-17 16:50:52 --> Language Class Initialized
INFO - 2020-03-17 16:50:52 --> Language Class Initialized
INFO - 2020-03-17 16:50:52 --> Config Class Initialized
INFO - 2020-03-17 16:50:52 --> Loader Class Initialized
INFO - 2020-03-17 16:50:52 --> Helper loaded: url_helper
INFO - 2020-03-17 16:50:52 --> Helper loaded: common_helper
INFO - 2020-03-17 16:50:52 --> Helper loaded: language_helper
INFO - 2020-03-17 16:50:52 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:50:52 --> Helper loaded: email_helper
INFO - 2020-03-17 16:50:52 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:50:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:50:52 --> Parser Class Initialized
INFO - 2020-03-17 16:50:52 --> User Agent Class Initialized
INFO - 2020-03-17 16:50:52 --> Model Class Initialized
INFO - 2020-03-17 16:50:53 --> Database Driver Class Initialized
INFO - 2020-03-17 16:50:53 --> Model Class Initialized
DEBUG - 2020-03-17 16:50:53 --> Template Class Initialized
INFO - 2020-03-17 16:50:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:50:53 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:50:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:50:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:50:53 --> Encryption Class Initialized
INFO - 2020-03-17 16:50:53 --> Controller Class Initialized
DEBUG - 2020-03-17 16:50:53 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:50:53 --> Model Class Initialized
INFO - 2020-03-17 16:50:53 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 16:50:53 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 16:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 16:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 16:50:53 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 16:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 16:50:53 --> Model Class Initialized
DEBUG - 2020-03-17 16:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 16:50:53 --> Model Class Initialized
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:50:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 16:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 16:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 16:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 16:50:53 --> Final output sent to browser
DEBUG - 2020-03-17 16:50:53 --> Total execution time: 1.1868
INFO - 2020-03-17 16:51:00 --> Config Class Initialized
INFO - 2020-03-17 16:51:00 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:51:00 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:51:00 --> Utf8 Class Initialized
INFO - 2020-03-17 16:51:00 --> URI Class Initialized
INFO - 2020-03-17 16:51:00 --> Router Class Initialized
INFO - 2020-03-17 16:51:00 --> Output Class Initialized
INFO - 2020-03-17 16:51:00 --> Security Class Initialized
DEBUG - 2020-03-17 16:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:51:00 --> CSRF cookie sent
INFO - 2020-03-17 16:51:00 --> CSRF token verified
INFO - 2020-03-17 16:51:00 --> Input Class Initialized
INFO - 2020-03-17 16:51:00 --> Language Class Initialized
INFO - 2020-03-17 16:51:00 --> Language Class Initialized
INFO - 2020-03-17 16:51:00 --> Config Class Initialized
INFO - 2020-03-17 16:51:00 --> Loader Class Initialized
INFO - 2020-03-17 16:51:01 --> Helper loaded: url_helper
INFO - 2020-03-17 16:51:01 --> Helper loaded: common_helper
INFO - 2020-03-17 16:51:01 --> Helper loaded: language_helper
INFO - 2020-03-17 16:51:01 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:51:01 --> Helper loaded: email_helper
INFO - 2020-03-17 16:51:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:51:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:51:01 --> Parser Class Initialized
INFO - 2020-03-17 16:51:01 --> User Agent Class Initialized
INFO - 2020-03-17 16:51:01 --> Model Class Initialized
INFO - 2020-03-17 16:51:01 --> Database Driver Class Initialized
INFO - 2020-03-17 16:51:01 --> Model Class Initialized
DEBUG - 2020-03-17 16:51:01 --> Template Class Initialized
INFO - 2020-03-17 16:51:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:51:01 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:51:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:51:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:51:01 --> Encryption Class Initialized
INFO - 2020-03-17 16:51:01 --> Controller Class Initialized
DEBUG - 2020-03-17 16:51:01 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:51:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:51:01 --> Model Class Initialized
DEBUG - 2020-03-17 16:51:01 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:51:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 16:51:01 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 16:51:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 16:51:01 --> Final output sent to browser
DEBUG - 2020-03-17 16:51:01 --> Total execution time: 0.7238
INFO - 2020-03-17 16:52:12 --> Config Class Initialized
INFO - 2020-03-17 16:52:12 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:52:12 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:52:12 --> Utf8 Class Initialized
INFO - 2020-03-17 16:52:12 --> URI Class Initialized
INFO - 2020-03-17 16:52:12 --> Router Class Initialized
INFO - 2020-03-17 16:52:12 --> Output Class Initialized
INFO - 2020-03-17 16:52:12 --> Security Class Initialized
DEBUG - 2020-03-17 16:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:52:12 --> Input Class Initialized
INFO - 2020-03-17 16:52:12 --> Language Class Initialized
INFO - 2020-03-17 16:52:13 --> Language Class Initialized
INFO - 2020-03-17 16:52:13 --> Config Class Initialized
INFO - 2020-03-17 16:52:13 --> Loader Class Initialized
INFO - 2020-03-17 16:52:13 --> Helper loaded: url_helper
INFO - 2020-03-17 16:52:13 --> Helper loaded: common_helper
INFO - 2020-03-17 16:52:13 --> Helper loaded: language_helper
INFO - 2020-03-17 16:52:13 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:52:13 --> Helper loaded: email_helper
INFO - 2020-03-17 16:52:13 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:52:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:52:13 --> Parser Class Initialized
INFO - 2020-03-17 16:52:13 --> User Agent Class Initialized
INFO - 2020-03-17 16:52:13 --> Model Class Initialized
INFO - 2020-03-17 16:52:13 --> Database Driver Class Initialized
INFO - 2020-03-17 16:52:13 --> Model Class Initialized
DEBUG - 2020-03-17 16:52:13 --> Template Class Initialized
INFO - 2020-03-17 16:52:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:52:13 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:52:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:52:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:52:13 --> Encryption Class Initialized
INFO - 2020-03-17 16:52:13 --> Controller Class Initialized
DEBUG - 2020-03-17 16:52:13 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:52:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 16:52:13 --> Model Class Initialized
INFO - 2020-03-17 16:52:26 --> Config Class Initialized
INFO - 2020-03-17 16:52:26 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:52:26 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:52:26 --> Utf8 Class Initialized
INFO - 2020-03-17 16:52:26 --> URI Class Initialized
INFO - 2020-03-17 16:52:26 --> Router Class Initialized
INFO - 2020-03-17 16:52:26 --> Output Class Initialized
INFO - 2020-03-17 16:52:26 --> Security Class Initialized
DEBUG - 2020-03-17 16:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:52:26 --> CSRF cookie sent
INFO - 2020-03-17 16:52:26 --> CSRF token verified
INFO - 2020-03-17 16:52:26 --> Input Class Initialized
INFO - 2020-03-17 16:52:26 --> Language Class Initialized
INFO - 2020-03-17 16:52:26 --> Language Class Initialized
INFO - 2020-03-17 16:52:26 --> Config Class Initialized
INFO - 2020-03-17 16:52:26 --> Loader Class Initialized
INFO - 2020-03-17 16:52:26 --> Helper loaded: url_helper
INFO - 2020-03-17 16:52:26 --> Helper loaded: common_helper
INFO - 2020-03-17 16:52:26 --> Helper loaded: language_helper
INFO - 2020-03-17 16:52:26 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:52:26 --> Helper loaded: email_helper
INFO - 2020-03-17 16:52:26 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:52:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:52:26 --> Parser Class Initialized
INFO - 2020-03-17 16:52:26 --> User Agent Class Initialized
INFO - 2020-03-17 16:52:26 --> Model Class Initialized
INFO - 2020-03-17 16:52:26 --> Database Driver Class Initialized
INFO - 2020-03-17 16:52:26 --> Model Class Initialized
DEBUG - 2020-03-17 16:52:26 --> Template Class Initialized
INFO - 2020-03-17 16:52:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:52:26 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:52:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:52:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:52:26 --> Encryption Class Initialized
INFO - 2020-03-17 16:52:26 --> Controller Class Initialized
DEBUG - 2020-03-17 16:52:26 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:52:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:52:26 --> Model Class Initialized
DEBUG - 2020-03-17 16:52:26 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:52:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 16:52:26 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 16:52:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 16:52:26 --> Final output sent to browser
DEBUG - 2020-03-17 16:52:26 --> Total execution time: 0.7520
INFO - 2020-03-17 16:55:17 --> Config Class Initialized
INFO - 2020-03-17 16:55:17 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:55:17 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:55:17 --> Utf8 Class Initialized
INFO - 2020-03-17 16:55:17 --> URI Class Initialized
INFO - 2020-03-17 16:55:17 --> Router Class Initialized
INFO - 2020-03-17 16:55:17 --> Output Class Initialized
INFO - 2020-03-17 16:55:17 --> Security Class Initialized
DEBUG - 2020-03-17 16:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:55:17 --> CSRF cookie sent
INFO - 2020-03-17 16:55:17 --> CSRF token verified
INFO - 2020-03-17 16:55:18 --> Input Class Initialized
INFO - 2020-03-17 16:55:18 --> Language Class Initialized
INFO - 2020-03-17 16:55:18 --> Language Class Initialized
INFO - 2020-03-17 16:55:18 --> Config Class Initialized
INFO - 2020-03-17 16:55:18 --> Loader Class Initialized
INFO - 2020-03-17 16:55:18 --> Helper loaded: url_helper
INFO - 2020-03-17 16:55:18 --> Helper loaded: common_helper
INFO - 2020-03-17 16:55:18 --> Helper loaded: language_helper
INFO - 2020-03-17 16:55:18 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:55:18 --> Helper loaded: email_helper
INFO - 2020-03-17 16:55:18 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:55:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:55:18 --> Parser Class Initialized
INFO - 2020-03-17 16:55:18 --> User Agent Class Initialized
INFO - 2020-03-17 16:55:18 --> Model Class Initialized
INFO - 2020-03-17 16:55:18 --> Database Driver Class Initialized
INFO - 2020-03-17 16:55:18 --> Model Class Initialized
DEBUG - 2020-03-17 16:55:18 --> Template Class Initialized
INFO - 2020-03-17 16:55:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:55:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:55:18 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:55:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:55:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:55:18 --> Encryption Class Initialized
INFO - 2020-03-17 16:55:18 --> Controller Class Initialized
DEBUG - 2020-03-17 16:55:18 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:55:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:55:18 --> Model Class Initialized
INFO - 2020-03-17 16:55:18 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 16:55:18 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 16:55:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 16:55:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 16:55:18 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 16:55:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 16:55:18 --> Model Class Initialized
DEBUG - 2020-03-17 16:55:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 16:55:18 --> Model Class Initialized
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:55:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:55:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:55:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:55:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:55:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:55:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:55:18 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:55:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 16:55:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 16:55:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 16:55:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 16:55:18 --> Final output sent to browser
DEBUG - 2020-03-17 16:55:19 --> Total execution time: 1.1549
INFO - 2020-03-17 16:55:26 --> Config Class Initialized
INFO - 2020-03-17 16:55:26 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:55:26 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:55:26 --> Utf8 Class Initialized
INFO - 2020-03-17 16:55:26 --> URI Class Initialized
INFO - 2020-03-17 16:55:27 --> Router Class Initialized
INFO - 2020-03-17 16:55:27 --> Output Class Initialized
INFO - 2020-03-17 16:55:27 --> Security Class Initialized
DEBUG - 2020-03-17 16:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:55:27 --> CSRF cookie sent
INFO - 2020-03-17 16:55:27 --> CSRF token verified
INFO - 2020-03-17 16:55:27 --> Input Class Initialized
INFO - 2020-03-17 16:55:27 --> Language Class Initialized
INFO - 2020-03-17 16:55:27 --> Language Class Initialized
INFO - 2020-03-17 16:55:27 --> Config Class Initialized
INFO - 2020-03-17 16:55:27 --> Loader Class Initialized
INFO - 2020-03-17 16:55:27 --> Helper loaded: url_helper
INFO - 2020-03-17 16:55:27 --> Helper loaded: common_helper
INFO - 2020-03-17 16:55:27 --> Helper loaded: language_helper
INFO - 2020-03-17 16:55:27 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:55:27 --> Helper loaded: email_helper
INFO - 2020-03-17 16:55:27 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:55:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:55:27 --> Parser Class Initialized
INFO - 2020-03-17 16:55:27 --> User Agent Class Initialized
INFO - 2020-03-17 16:55:27 --> Model Class Initialized
INFO - 2020-03-17 16:55:27 --> Database Driver Class Initialized
INFO - 2020-03-17 16:55:27 --> Model Class Initialized
DEBUG - 2020-03-17 16:55:27 --> Template Class Initialized
INFO - 2020-03-17 16:55:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:55:27 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:55:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:55:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:55:27 --> Encryption Class Initialized
INFO - 2020-03-17 16:55:27 --> Controller Class Initialized
DEBUG - 2020-03-17 16:55:27 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:55:27 --> Model Class Initialized
DEBUG - 2020-03-17 16:55:27 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 16:55:27 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 16:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 16:55:27 --> Final output sent to browser
DEBUG - 2020-03-17 16:55:27 --> Total execution time: 0.7406
INFO - 2020-03-17 16:55:39 --> Config Class Initialized
INFO - 2020-03-17 16:55:39 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:55:39 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:55:39 --> Utf8 Class Initialized
INFO - 2020-03-17 16:55:39 --> URI Class Initialized
INFO - 2020-03-17 16:55:39 --> Router Class Initialized
INFO - 2020-03-17 16:55:39 --> Output Class Initialized
INFO - 2020-03-17 16:55:39 --> Security Class Initialized
DEBUG - 2020-03-17 16:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:55:39 --> Input Class Initialized
INFO - 2020-03-17 16:55:39 --> Language Class Initialized
INFO - 2020-03-17 16:55:39 --> Language Class Initialized
INFO - 2020-03-17 16:55:39 --> Config Class Initialized
INFO - 2020-03-17 16:55:39 --> Loader Class Initialized
INFO - 2020-03-17 16:55:39 --> Helper loaded: url_helper
INFO - 2020-03-17 16:55:39 --> Helper loaded: common_helper
INFO - 2020-03-17 16:55:39 --> Helper loaded: language_helper
INFO - 2020-03-17 16:55:39 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:55:39 --> Helper loaded: email_helper
INFO - 2020-03-17 16:55:39 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:55:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:55:39 --> Parser Class Initialized
INFO - 2020-03-17 16:55:39 --> User Agent Class Initialized
INFO - 2020-03-17 16:55:39 --> Model Class Initialized
INFO - 2020-03-17 16:55:39 --> Database Driver Class Initialized
INFO - 2020-03-17 16:55:39 --> Model Class Initialized
DEBUG - 2020-03-17 16:55:39 --> Template Class Initialized
INFO - 2020-03-17 16:55:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:55:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:55:39 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:55:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:55:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:55:39 --> Encryption Class Initialized
INFO - 2020-03-17 16:55:39 --> Controller Class Initialized
DEBUG - 2020-03-17 16:55:39 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:55:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 16:55:39 --> Model Class Initialized
INFO - 2020-03-17 16:58:41 --> Config Class Initialized
INFO - 2020-03-17 16:58:41 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:58:41 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:58:41 --> Utf8 Class Initialized
INFO - 2020-03-17 16:58:41 --> URI Class Initialized
INFO - 2020-03-17 16:58:41 --> Router Class Initialized
INFO - 2020-03-17 16:58:41 --> Output Class Initialized
INFO - 2020-03-17 16:58:41 --> Security Class Initialized
DEBUG - 2020-03-17 16:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:58:41 --> CSRF cookie sent
INFO - 2020-03-17 16:58:41 --> CSRF token verified
INFO - 2020-03-17 16:58:41 --> Input Class Initialized
INFO - 2020-03-17 16:58:41 --> Language Class Initialized
INFO - 2020-03-17 16:58:41 --> Language Class Initialized
INFO - 2020-03-17 16:58:41 --> Config Class Initialized
INFO - 2020-03-17 16:58:41 --> Loader Class Initialized
INFO - 2020-03-17 16:58:41 --> Helper loaded: url_helper
INFO - 2020-03-17 16:58:41 --> Helper loaded: common_helper
INFO - 2020-03-17 16:58:41 --> Helper loaded: language_helper
INFO - 2020-03-17 16:58:42 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:58:42 --> Helper loaded: email_helper
INFO - 2020-03-17 16:58:42 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:58:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:58:42 --> Parser Class Initialized
INFO - 2020-03-17 16:58:42 --> User Agent Class Initialized
INFO - 2020-03-17 16:58:42 --> Model Class Initialized
INFO - 2020-03-17 16:58:42 --> Database Driver Class Initialized
INFO - 2020-03-17 16:58:42 --> Model Class Initialized
DEBUG - 2020-03-17 16:58:42 --> Template Class Initialized
INFO - 2020-03-17 16:58:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:58:42 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:58:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:58:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:58:42 --> Encryption Class Initialized
INFO - 2020-03-17 16:58:42 --> Controller Class Initialized
DEBUG - 2020-03-17 16:58:42 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:58:42 --> Model Class Initialized
INFO - 2020-03-17 16:58:42 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 16:58:42 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 16:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 16:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 16:58:42 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 16:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 16:58:42 --> Model Class Initialized
DEBUG - 2020-03-17 16:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 16:58:42 --> Model Class Initialized
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:58:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 16:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 16:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 16:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 16:58:42 --> Final output sent to browser
DEBUG - 2020-03-17 16:58:42 --> Total execution time: 1.1789
INFO - 2020-03-17 16:58:53 --> Config Class Initialized
INFO - 2020-03-17 16:58:53 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:58:53 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:58:53 --> Utf8 Class Initialized
INFO - 2020-03-17 16:58:53 --> URI Class Initialized
INFO - 2020-03-17 16:58:53 --> Router Class Initialized
INFO - 2020-03-17 16:58:53 --> Output Class Initialized
INFO - 2020-03-17 16:58:53 --> Security Class Initialized
DEBUG - 2020-03-17 16:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:58:53 --> CSRF cookie sent
INFO - 2020-03-17 16:58:53 --> CSRF token verified
INFO - 2020-03-17 16:58:53 --> Input Class Initialized
INFO - 2020-03-17 16:58:53 --> Language Class Initialized
INFO - 2020-03-17 16:58:53 --> Language Class Initialized
INFO - 2020-03-17 16:58:53 --> Config Class Initialized
INFO - 2020-03-17 16:58:53 --> Loader Class Initialized
INFO - 2020-03-17 16:58:53 --> Helper loaded: url_helper
INFO - 2020-03-17 16:58:53 --> Helper loaded: common_helper
INFO - 2020-03-17 16:58:53 --> Helper loaded: language_helper
INFO - 2020-03-17 16:58:53 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:58:53 --> Helper loaded: email_helper
INFO - 2020-03-17 16:58:53 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:58:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:58:54 --> Parser Class Initialized
INFO - 2020-03-17 16:58:54 --> User Agent Class Initialized
INFO - 2020-03-17 16:58:54 --> Model Class Initialized
INFO - 2020-03-17 16:58:54 --> Database Driver Class Initialized
INFO - 2020-03-17 16:58:54 --> Model Class Initialized
DEBUG - 2020-03-17 16:58:54 --> Template Class Initialized
INFO - 2020-03-17 16:58:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:58:54 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:58:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:58:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:58:54 --> Encryption Class Initialized
INFO - 2020-03-17 16:58:54 --> Controller Class Initialized
DEBUG - 2020-03-17 16:58:54 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:58:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:58:54 --> Model Class Initialized
DEBUG - 2020-03-17 16:58:54 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 16:58:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 16:58:54 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 16:58:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 16:58:54 --> Final output sent to browser
DEBUG - 2020-03-17 16:58:54 --> Total execution time: 0.8840
INFO - 2020-03-17 16:59:55 --> Config Class Initialized
INFO - 2020-03-17 16:59:55 --> Hooks Class Initialized
DEBUG - 2020-03-17 16:59:55 --> UTF-8 Support Enabled
INFO - 2020-03-17 16:59:55 --> Utf8 Class Initialized
INFO - 2020-03-17 16:59:55 --> URI Class Initialized
INFO - 2020-03-17 16:59:55 --> Router Class Initialized
INFO - 2020-03-17 16:59:55 --> Output Class Initialized
INFO - 2020-03-17 16:59:55 --> Security Class Initialized
DEBUG - 2020-03-17 16:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 16:59:55 --> CSRF cookie sent
INFO - 2020-03-17 16:59:55 --> CSRF token verified
INFO - 2020-03-17 16:59:55 --> Input Class Initialized
INFO - 2020-03-17 16:59:55 --> Language Class Initialized
INFO - 2020-03-17 16:59:55 --> Language Class Initialized
INFO - 2020-03-17 16:59:55 --> Config Class Initialized
INFO - 2020-03-17 16:59:55 --> Loader Class Initialized
INFO - 2020-03-17 16:59:55 --> Helper loaded: url_helper
INFO - 2020-03-17 16:59:55 --> Helper loaded: common_helper
INFO - 2020-03-17 16:59:55 --> Helper loaded: language_helper
INFO - 2020-03-17 16:59:55 --> Helper loaded: cookie_helper
INFO - 2020-03-17 16:59:55 --> Helper loaded: email_helper
INFO - 2020-03-17 16:59:56 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 16:59:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 16:59:56 --> Parser Class Initialized
INFO - 2020-03-17 16:59:56 --> User Agent Class Initialized
INFO - 2020-03-17 16:59:56 --> Model Class Initialized
INFO - 2020-03-17 16:59:56 --> Database Driver Class Initialized
INFO - 2020-03-17 16:59:56 --> Model Class Initialized
DEBUG - 2020-03-17 16:59:56 --> Template Class Initialized
INFO - 2020-03-17 16:59:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 16:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 16:59:56 --> Pagination Class Initialized
DEBUG - 2020-03-17 16:59:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 16:59:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 16:59:56 --> Encryption Class Initialized
INFO - 2020-03-17 16:59:56 --> Controller Class Initialized
DEBUG - 2020-03-17 16:59:56 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 16:59:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 16:59:56 --> Model Class Initialized
INFO - 2020-03-17 16:59:56 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 16:59:56 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 16:59:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 16:59:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 16:59:56 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 16:59:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 16:59:56 --> Model Class Initialized
DEBUG - 2020-03-17 16:59:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 16:59:56 --> Model Class Initialized
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:59:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:59:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:59:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:59:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:59:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:59:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 16:59:56 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 16:59:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 16:59:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 16:59:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 16:59:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 16:59:56 --> Final output sent to browser
DEBUG - 2020-03-17 16:59:56 --> Total execution time: 1.2016
INFO - 2020-03-17 17:00:09 --> Config Class Initialized
INFO - 2020-03-17 17:00:09 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:00:09 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:00:09 --> Utf8 Class Initialized
INFO - 2020-03-17 17:00:09 --> URI Class Initialized
INFO - 2020-03-17 17:00:09 --> Router Class Initialized
INFO - 2020-03-17 17:00:09 --> Output Class Initialized
INFO - 2020-03-17 17:00:09 --> Security Class Initialized
DEBUG - 2020-03-17 17:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:00:09 --> CSRF cookie sent
INFO - 2020-03-17 17:00:09 --> CSRF token verified
INFO - 2020-03-17 17:00:09 --> Input Class Initialized
INFO - 2020-03-17 17:00:09 --> Language Class Initialized
INFO - 2020-03-17 17:00:09 --> Language Class Initialized
INFO - 2020-03-17 17:00:09 --> Config Class Initialized
INFO - 2020-03-17 17:00:09 --> Loader Class Initialized
INFO - 2020-03-17 17:00:09 --> Helper loaded: url_helper
INFO - 2020-03-17 17:00:09 --> Helper loaded: common_helper
INFO - 2020-03-17 17:00:09 --> Helper loaded: language_helper
INFO - 2020-03-17 17:00:09 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:00:09 --> Helper loaded: email_helper
INFO - 2020-03-17 17:00:09 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:00:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:00:09 --> Parser Class Initialized
INFO - 2020-03-17 17:00:09 --> User Agent Class Initialized
INFO - 2020-03-17 17:00:09 --> Model Class Initialized
INFO - 2020-03-17 17:00:09 --> Database Driver Class Initialized
INFO - 2020-03-17 17:00:09 --> Model Class Initialized
DEBUG - 2020-03-17 17:00:09 --> Template Class Initialized
INFO - 2020-03-17 17:00:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:00:09 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:00:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:00:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:00:09 --> Encryption Class Initialized
INFO - 2020-03-17 17:00:09 --> Controller Class Initialized
DEBUG - 2020-03-17 17:00:09 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 17:00:09 --> Model Class Initialized
DEBUG - 2020-03-17 17:00:09 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 17:00:09 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 17:00:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 17:00:09 --> Final output sent to browser
DEBUG - 2020-03-17 17:00:09 --> Total execution time: 0.7737
INFO - 2020-03-17 17:04:40 --> Config Class Initialized
INFO - 2020-03-17 17:04:41 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:04:41 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:04:41 --> Utf8 Class Initialized
INFO - 2020-03-17 17:04:41 --> URI Class Initialized
INFO - 2020-03-17 17:04:41 --> Router Class Initialized
INFO - 2020-03-17 17:04:41 --> Output Class Initialized
INFO - 2020-03-17 17:04:41 --> Security Class Initialized
DEBUG - 2020-03-17 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:04:41 --> CSRF cookie sent
INFO - 2020-03-17 17:04:41 --> CSRF token verified
INFO - 2020-03-17 17:04:41 --> Input Class Initialized
INFO - 2020-03-17 17:04:41 --> Language Class Initialized
INFO - 2020-03-17 17:04:41 --> Language Class Initialized
INFO - 2020-03-17 17:04:41 --> Config Class Initialized
INFO - 2020-03-17 17:04:41 --> Loader Class Initialized
INFO - 2020-03-17 17:04:41 --> Helper loaded: url_helper
INFO - 2020-03-17 17:04:41 --> Helper loaded: common_helper
INFO - 2020-03-17 17:04:41 --> Helper loaded: language_helper
INFO - 2020-03-17 17:04:41 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:04:41 --> Helper loaded: email_helper
INFO - 2020-03-17 17:04:41 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:04:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:04:41 --> Parser Class Initialized
INFO - 2020-03-17 17:04:41 --> User Agent Class Initialized
INFO - 2020-03-17 17:04:41 --> Model Class Initialized
INFO - 2020-03-17 17:04:41 --> Database Driver Class Initialized
INFO - 2020-03-17 17:04:41 --> Model Class Initialized
DEBUG - 2020-03-17 17:04:41 --> Template Class Initialized
INFO - 2020-03-17 17:04:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:04:41 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:04:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:04:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:04:41 --> Encryption Class Initialized
INFO - 2020-03-17 17:04:41 --> Controller Class Initialized
DEBUG - 2020-03-17 17:04:41 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 17:04:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 17:04:41 --> Model Class Initialized
INFO - 2020-03-17 17:04:41 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 17:04:41 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 17:04:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 17:04:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 17:04:41 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 17:04:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 17:04:41 --> Model Class Initialized
DEBUG - 2020-03-17 17:04:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 17:04:41 --> Model Class Initialized
ERROR - 2020-03-17 17:04:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:04:41 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:04:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:04:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:04:41 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:04:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:04:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:04:41 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:04:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:04:41 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:04:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:04:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:04:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:04:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:04:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:04:42 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:04:42 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 17:04:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 17:04:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 17:04:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 17:04:42 --> Final output sent to browser
DEBUG - 2020-03-17 17:04:42 --> Total execution time: 1.2576
INFO - 2020-03-17 17:04:56 --> Config Class Initialized
INFO - 2020-03-17 17:04:56 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:04:56 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:04:56 --> Utf8 Class Initialized
INFO - 2020-03-17 17:04:56 --> URI Class Initialized
INFO - 2020-03-17 17:04:56 --> Router Class Initialized
INFO - 2020-03-17 17:04:56 --> Output Class Initialized
INFO - 2020-03-17 17:04:56 --> Security Class Initialized
DEBUG - 2020-03-17 17:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:04:56 --> CSRF cookie sent
INFO - 2020-03-17 17:04:56 --> CSRF token verified
INFO - 2020-03-17 17:04:56 --> Input Class Initialized
INFO - 2020-03-17 17:04:56 --> Language Class Initialized
INFO - 2020-03-17 17:04:56 --> Language Class Initialized
INFO - 2020-03-17 17:04:56 --> Config Class Initialized
INFO - 2020-03-17 17:04:56 --> Loader Class Initialized
INFO - 2020-03-17 17:04:56 --> Helper loaded: url_helper
INFO - 2020-03-17 17:04:56 --> Helper loaded: common_helper
INFO - 2020-03-17 17:04:56 --> Helper loaded: language_helper
INFO - 2020-03-17 17:04:56 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:04:56 --> Helper loaded: email_helper
INFO - 2020-03-17 17:04:56 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:04:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:04:57 --> Parser Class Initialized
INFO - 2020-03-17 17:04:57 --> User Agent Class Initialized
INFO - 2020-03-17 17:04:57 --> Model Class Initialized
INFO - 2020-03-17 17:04:57 --> Database Driver Class Initialized
INFO - 2020-03-17 17:04:57 --> Model Class Initialized
DEBUG - 2020-03-17 17:04:57 --> Template Class Initialized
INFO - 2020-03-17 17:04:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:04:57 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:04:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:04:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:04:57 --> Encryption Class Initialized
INFO - 2020-03-17 17:04:57 --> Controller Class Initialized
DEBUG - 2020-03-17 17:04:57 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 17:04:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 17:04:57 --> Model Class Initialized
DEBUG - 2020-03-17 17:04:57 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:04:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 17:04:57 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 17:04:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 17:04:57 --> Final output sent to browser
DEBUG - 2020-03-17 17:04:57 --> Total execution time: 0.7709
INFO - 2020-03-17 17:16:30 --> Config Class Initialized
INFO - 2020-03-17 17:16:30 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:16:30 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:16:30 --> Utf8 Class Initialized
INFO - 2020-03-17 17:16:30 --> URI Class Initialized
INFO - 2020-03-17 17:16:30 --> Router Class Initialized
INFO - 2020-03-17 17:16:30 --> Output Class Initialized
INFO - 2020-03-17 17:16:30 --> Security Class Initialized
DEBUG - 2020-03-17 17:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:16:30 --> CSRF cookie sent
INFO - 2020-03-17 17:16:30 --> CSRF token verified
INFO - 2020-03-17 17:16:30 --> Input Class Initialized
INFO - 2020-03-17 17:16:30 --> Language Class Initialized
INFO - 2020-03-17 17:16:30 --> Language Class Initialized
INFO - 2020-03-17 17:16:30 --> Config Class Initialized
INFO - 2020-03-17 17:16:30 --> Loader Class Initialized
INFO - 2020-03-17 17:16:30 --> Helper loaded: url_helper
INFO - 2020-03-17 17:16:30 --> Helper loaded: common_helper
INFO - 2020-03-17 17:16:30 --> Helper loaded: language_helper
INFO - 2020-03-17 17:16:30 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:16:30 --> Helper loaded: email_helper
INFO - 2020-03-17 17:16:30 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:16:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:16:30 --> Parser Class Initialized
INFO - 2020-03-17 17:16:30 --> User Agent Class Initialized
INFO - 2020-03-17 17:16:31 --> Model Class Initialized
INFO - 2020-03-17 17:16:31 --> Database Driver Class Initialized
INFO - 2020-03-17 17:16:31 --> Model Class Initialized
DEBUG - 2020-03-17 17:16:31 --> Template Class Initialized
INFO - 2020-03-17 17:16:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:16:31 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:16:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:16:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:16:31 --> Encryption Class Initialized
INFO - 2020-03-17 17:16:31 --> Controller Class Initialized
DEBUG - 2020-03-17 17:16:31 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 17:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 17:16:31 --> Model Class Initialized
INFO - 2020-03-17 17:16:31 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 17:16:31 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 17:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 17:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 17:16:31 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 17:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 17:16:31 --> Model Class Initialized
DEBUG - 2020-03-17 17:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 17:16:31 --> Model Class Initialized
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:16:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 17:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 17:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 17:16:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 17:16:31 --> Final output sent to browser
DEBUG - 2020-03-17 17:16:31 --> Total execution time: 1.1902
INFO - 2020-03-17 17:16:39 --> Config Class Initialized
INFO - 2020-03-17 17:16:39 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:16:39 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:16:39 --> Utf8 Class Initialized
INFO - 2020-03-17 17:16:39 --> URI Class Initialized
INFO - 2020-03-17 17:16:39 --> Router Class Initialized
INFO - 2020-03-17 17:16:39 --> Output Class Initialized
INFO - 2020-03-17 17:16:39 --> Security Class Initialized
DEBUG - 2020-03-17 17:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:16:39 --> CSRF cookie sent
INFO - 2020-03-17 17:16:39 --> CSRF token verified
INFO - 2020-03-17 17:16:39 --> Input Class Initialized
INFO - 2020-03-17 17:16:39 --> Language Class Initialized
INFO - 2020-03-17 17:16:39 --> Language Class Initialized
INFO - 2020-03-17 17:16:39 --> Config Class Initialized
INFO - 2020-03-17 17:16:39 --> Loader Class Initialized
INFO - 2020-03-17 17:16:40 --> Helper loaded: url_helper
INFO - 2020-03-17 17:16:40 --> Helper loaded: common_helper
INFO - 2020-03-17 17:16:40 --> Helper loaded: language_helper
INFO - 2020-03-17 17:16:40 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:16:40 --> Helper loaded: email_helper
INFO - 2020-03-17 17:16:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:16:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:16:40 --> Parser Class Initialized
INFO - 2020-03-17 17:16:40 --> User Agent Class Initialized
INFO - 2020-03-17 17:16:40 --> Model Class Initialized
INFO - 2020-03-17 17:16:40 --> Database Driver Class Initialized
INFO - 2020-03-17 17:16:40 --> Model Class Initialized
DEBUG - 2020-03-17 17:16:40 --> Template Class Initialized
INFO - 2020-03-17 17:16:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:16:40 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:16:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:16:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:16:40 --> Encryption Class Initialized
INFO - 2020-03-17 17:16:40 --> Controller Class Initialized
DEBUG - 2020-03-17 17:16:40 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 17:16:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 17:16:40 --> Model Class Initialized
DEBUG - 2020-03-17 17:16:40 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:16:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 17:16:40 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 17:16:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 17:16:40 --> Final output sent to browser
DEBUG - 2020-03-17 17:16:40 --> Total execution time: 0.7535
INFO - 2020-03-17 17:17:44 --> Config Class Initialized
INFO - 2020-03-17 17:17:44 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:17:44 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:17:44 --> Utf8 Class Initialized
INFO - 2020-03-17 17:17:44 --> URI Class Initialized
INFO - 2020-03-17 17:17:44 --> Router Class Initialized
INFO - 2020-03-17 17:17:44 --> Output Class Initialized
INFO - 2020-03-17 17:17:44 --> Security Class Initialized
DEBUG - 2020-03-17 17:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:17:44 --> CSRF cookie sent
INFO - 2020-03-17 17:17:44 --> CSRF token verified
INFO - 2020-03-17 17:17:44 --> Input Class Initialized
INFO - 2020-03-17 17:17:44 --> Language Class Initialized
INFO - 2020-03-17 17:17:44 --> Language Class Initialized
INFO - 2020-03-17 17:17:44 --> Config Class Initialized
INFO - 2020-03-17 17:17:44 --> Loader Class Initialized
INFO - 2020-03-17 17:17:44 --> Helper loaded: url_helper
INFO - 2020-03-17 17:17:44 --> Helper loaded: common_helper
INFO - 2020-03-17 17:17:44 --> Helper loaded: language_helper
INFO - 2020-03-17 17:17:44 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:17:44 --> Helper loaded: email_helper
INFO - 2020-03-17 17:17:44 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:17:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:17:44 --> Parser Class Initialized
INFO - 2020-03-17 17:17:44 --> User Agent Class Initialized
INFO - 2020-03-17 17:17:44 --> Model Class Initialized
INFO - 2020-03-17 17:17:44 --> Database Driver Class Initialized
INFO - 2020-03-17 17:17:44 --> Model Class Initialized
DEBUG - 2020-03-17 17:17:44 --> Template Class Initialized
INFO - 2020-03-17 17:17:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:17:44 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:17:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:17:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:17:44 --> Encryption Class Initialized
INFO - 2020-03-17 17:17:44 --> Controller Class Initialized
DEBUG - 2020-03-17 17:17:44 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 17:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 17:17:44 --> Model Class Initialized
INFO - 2020-03-17 17:17:44 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 17:17:44 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 17:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 17:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 17:17:44 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 17:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 17:17:44 --> Model Class Initialized
DEBUG - 2020-03-17 17:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 17:17:45 --> Model Class Initialized
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:17:45 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 17:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 17:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 17:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 17:17:45 --> Final output sent to browser
DEBUG - 2020-03-17 17:17:45 --> Total execution time: 1.2074
INFO - 2020-03-17 17:17:54 --> Config Class Initialized
INFO - 2020-03-17 17:17:54 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:17:54 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:17:54 --> Utf8 Class Initialized
INFO - 2020-03-17 17:17:54 --> URI Class Initialized
INFO - 2020-03-17 17:17:54 --> Router Class Initialized
INFO - 2020-03-17 17:17:54 --> Output Class Initialized
INFO - 2020-03-17 17:17:54 --> Security Class Initialized
DEBUG - 2020-03-17 17:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:17:54 --> CSRF cookie sent
INFO - 2020-03-17 17:17:54 --> CSRF token verified
INFO - 2020-03-17 17:17:54 --> Input Class Initialized
INFO - 2020-03-17 17:17:54 --> Language Class Initialized
INFO - 2020-03-17 17:17:54 --> Language Class Initialized
INFO - 2020-03-17 17:17:54 --> Config Class Initialized
INFO - 2020-03-17 17:17:54 --> Loader Class Initialized
INFO - 2020-03-17 17:17:54 --> Helper loaded: url_helper
INFO - 2020-03-17 17:17:54 --> Helper loaded: common_helper
INFO - 2020-03-17 17:17:54 --> Helper loaded: language_helper
INFO - 2020-03-17 17:17:54 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:17:54 --> Helper loaded: email_helper
INFO - 2020-03-17 17:17:54 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:17:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:17:54 --> Parser Class Initialized
INFO - 2020-03-17 17:17:54 --> User Agent Class Initialized
INFO - 2020-03-17 17:17:55 --> Model Class Initialized
INFO - 2020-03-17 17:17:55 --> Database Driver Class Initialized
INFO - 2020-03-17 17:17:55 --> Model Class Initialized
DEBUG - 2020-03-17 17:17:55 --> Template Class Initialized
INFO - 2020-03-17 17:17:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:17:55 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:17:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:17:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:17:55 --> Encryption Class Initialized
INFO - 2020-03-17 17:17:55 --> Controller Class Initialized
DEBUG - 2020-03-17 17:17:55 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 17:17:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 17:17:55 --> Model Class Initialized
DEBUG - 2020-03-17 17:17:55 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:17:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 17:17:55 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 17:17:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 17:17:55 --> Final output sent to browser
DEBUG - 2020-03-17 17:17:55 --> Total execution time: 0.7708
INFO - 2020-03-17 17:23:52 --> Config Class Initialized
INFO - 2020-03-17 17:23:52 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:23:52 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:23:52 --> Utf8 Class Initialized
INFO - 2020-03-17 17:23:52 --> URI Class Initialized
INFO - 2020-03-17 17:23:52 --> Router Class Initialized
INFO - 2020-03-17 17:23:52 --> Output Class Initialized
INFO - 2020-03-17 17:23:52 --> Security Class Initialized
DEBUG - 2020-03-17 17:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:23:52 --> CSRF cookie sent
INFO - 2020-03-17 17:23:52 --> CSRF token verified
INFO - 2020-03-17 17:23:52 --> Input Class Initialized
INFO - 2020-03-17 17:23:52 --> Language Class Initialized
INFO - 2020-03-17 17:23:52 --> Language Class Initialized
INFO - 2020-03-17 17:23:52 --> Config Class Initialized
INFO - 2020-03-17 17:23:52 --> Loader Class Initialized
INFO - 2020-03-17 17:23:52 --> Helper loaded: url_helper
INFO - 2020-03-17 17:23:52 --> Helper loaded: common_helper
INFO - 2020-03-17 17:23:52 --> Helper loaded: language_helper
INFO - 2020-03-17 17:23:52 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:23:52 --> Helper loaded: email_helper
INFO - 2020-03-17 17:23:52 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:23:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:23:52 --> Parser Class Initialized
INFO - 2020-03-17 17:23:52 --> User Agent Class Initialized
INFO - 2020-03-17 17:23:52 --> Model Class Initialized
INFO - 2020-03-17 17:23:52 --> Database Driver Class Initialized
INFO - 2020-03-17 17:23:52 --> Model Class Initialized
DEBUG - 2020-03-17 17:23:52 --> Template Class Initialized
INFO - 2020-03-17 17:23:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:23:52 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:23:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:23:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:23:52 --> Encryption Class Initialized
INFO - 2020-03-17 17:23:52 --> Controller Class Initialized
DEBUG - 2020-03-17 17:23:52 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 17:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 17:23:52 --> Model Class Initialized
INFO - 2020-03-17 17:23:52 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 17:23:52 --> Could not find the language line "shopier"
DEBUG - 2020-03-17 17:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-17 17:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 17:23:52 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 17:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 17:23:52 --> Model Class Initialized
DEBUG - 2020-03-17 17:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 17:23:52 --> Model Class Initialized
ERROR - 2020-03-17 17:23:52 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:23:52 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:23:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 17:23:53 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 17:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 17:23:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 17:23:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 17:23:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 17:23:53 --> Final output sent to browser
DEBUG - 2020-03-17 17:23:53 --> Total execution time: 1.3157
INFO - 2020-03-17 17:24:00 --> Config Class Initialized
INFO - 2020-03-17 17:24:00 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:24:00 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:24:00 --> Utf8 Class Initialized
INFO - 2020-03-17 17:24:00 --> URI Class Initialized
INFO - 2020-03-17 17:24:00 --> Router Class Initialized
INFO - 2020-03-17 17:24:00 --> Output Class Initialized
INFO - 2020-03-17 17:24:00 --> Security Class Initialized
DEBUG - 2020-03-17 17:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:24:01 --> CSRF cookie sent
INFO - 2020-03-17 17:24:01 --> CSRF token verified
INFO - 2020-03-17 17:24:01 --> Input Class Initialized
INFO - 2020-03-17 17:24:01 --> Language Class Initialized
INFO - 2020-03-17 17:24:01 --> Language Class Initialized
INFO - 2020-03-17 17:24:01 --> Config Class Initialized
INFO - 2020-03-17 17:24:01 --> Loader Class Initialized
INFO - 2020-03-17 17:24:01 --> Helper loaded: url_helper
INFO - 2020-03-17 17:24:01 --> Helper loaded: common_helper
INFO - 2020-03-17 17:24:01 --> Helper loaded: language_helper
INFO - 2020-03-17 17:24:01 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:24:01 --> Helper loaded: email_helper
INFO - 2020-03-17 17:24:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:24:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:24:01 --> Parser Class Initialized
INFO - 2020-03-17 17:24:01 --> User Agent Class Initialized
INFO - 2020-03-17 17:24:01 --> Model Class Initialized
INFO - 2020-03-17 17:24:01 --> Database Driver Class Initialized
INFO - 2020-03-17 17:24:01 --> Model Class Initialized
DEBUG - 2020-03-17 17:24:01 --> Template Class Initialized
INFO - 2020-03-17 17:24:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:24:01 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:24:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:24:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:24:01 --> Encryption Class Initialized
INFO - 2020-03-17 17:24:01 --> Controller Class Initialized
DEBUG - 2020-03-17 17:24:01 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 17:24:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 17:24:01 --> Model Class Initialized
DEBUG - 2020-03-17 17:24:01 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:24:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-17 17:24:01 --> Could not find the language line "Your_name"
DEBUG - 2020-03-17 17:24:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-17 17:24:01 --> Final output sent to browser
DEBUG - 2020-03-17 17:24:01 --> Total execution time: 0.7894
INFO - 2020-03-17 17:24:21 --> Config Class Initialized
INFO - 2020-03-17 17:24:21 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:24:21 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:24:21 --> Utf8 Class Initialized
INFO - 2020-03-17 17:24:21 --> URI Class Initialized
INFO - 2020-03-17 17:24:21 --> Router Class Initialized
INFO - 2020-03-17 17:24:21 --> Output Class Initialized
INFO - 2020-03-17 17:24:21 --> Security Class Initialized
DEBUG - 2020-03-17 17:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:24:21 --> Input Class Initialized
INFO - 2020-03-17 17:24:21 --> Language Class Initialized
INFO - 2020-03-17 17:24:21 --> Language Class Initialized
INFO - 2020-03-17 17:24:21 --> Config Class Initialized
INFO - 2020-03-17 17:24:21 --> Loader Class Initialized
INFO - 2020-03-17 17:24:21 --> Helper loaded: url_helper
INFO - 2020-03-17 17:24:21 --> Helper loaded: common_helper
INFO - 2020-03-17 17:24:21 --> Helper loaded: language_helper
INFO - 2020-03-17 17:24:21 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:24:21 --> Helper loaded: email_helper
INFO - 2020-03-17 17:24:21 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:24:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:24:21 --> Parser Class Initialized
INFO - 2020-03-17 17:24:21 --> User Agent Class Initialized
INFO - 2020-03-17 17:24:21 --> Model Class Initialized
INFO - 2020-03-17 17:24:21 --> Database Driver Class Initialized
INFO - 2020-03-17 17:24:21 --> Model Class Initialized
DEBUG - 2020-03-17 17:24:21 --> Template Class Initialized
INFO - 2020-03-17 17:24:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:24:21 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:24:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:24:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:24:21 --> Encryption Class Initialized
INFO - 2020-03-17 17:24:21 --> Controller Class Initialized
DEBUG - 2020-03-17 17:24:21 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:24:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 17:24:21 --> Model Class Initialized
INFO - 2020-03-17 17:28:22 --> Config Class Initialized
INFO - 2020-03-17 17:28:22 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:28:22 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:28:22 --> Utf8 Class Initialized
INFO - 2020-03-17 17:28:22 --> URI Class Initialized
INFO - 2020-03-17 17:28:22 --> Router Class Initialized
INFO - 2020-03-17 17:28:22 --> Output Class Initialized
INFO - 2020-03-17 17:28:22 --> Security Class Initialized
DEBUG - 2020-03-17 17:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:28:22 --> Input Class Initialized
INFO - 2020-03-17 17:28:22 --> Language Class Initialized
ERROR - 2020-03-17 17:28:22 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\stripe.php 78
INFO - 2020-03-17 17:28:54 --> Config Class Initialized
INFO - 2020-03-17 17:28:54 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:28:54 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:28:54 --> Utf8 Class Initialized
INFO - 2020-03-17 17:28:54 --> URI Class Initialized
INFO - 2020-03-17 17:28:54 --> Router Class Initialized
INFO - 2020-03-17 17:28:54 --> Output Class Initialized
INFO - 2020-03-17 17:28:54 --> Security Class Initialized
DEBUG - 2020-03-17 17:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:28:55 --> Input Class Initialized
INFO - 2020-03-17 17:28:55 --> Language Class Initialized
ERROR - 2020-03-17 17:28:55 --> Severity: error --> Exception: syntax error, unexpected '$data_charge' (T_VARIABLE) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\stripe.php 88
INFO - 2020-03-17 17:29:14 --> Config Class Initialized
INFO - 2020-03-17 17:29:14 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:29:14 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:29:14 --> Utf8 Class Initialized
INFO - 2020-03-17 17:29:14 --> URI Class Initialized
INFO - 2020-03-17 17:29:14 --> Router Class Initialized
INFO - 2020-03-17 17:29:14 --> Output Class Initialized
INFO - 2020-03-17 17:29:14 --> Security Class Initialized
DEBUG - 2020-03-17 17:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:29:14 --> Input Class Initialized
INFO - 2020-03-17 17:29:14 --> Language Class Initialized
INFO - 2020-03-17 17:29:14 --> Language Class Initialized
INFO - 2020-03-17 17:29:14 --> Config Class Initialized
INFO - 2020-03-17 17:29:14 --> Loader Class Initialized
INFO - 2020-03-17 17:29:14 --> Helper loaded: url_helper
INFO - 2020-03-17 17:29:14 --> Helper loaded: common_helper
INFO - 2020-03-17 17:29:14 --> Helper loaded: language_helper
INFO - 2020-03-17 17:29:14 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:29:14 --> Helper loaded: email_helper
INFO - 2020-03-17 17:29:14 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:29:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:29:14 --> Parser Class Initialized
INFO - 2020-03-17 17:29:15 --> User Agent Class Initialized
INFO - 2020-03-17 17:29:15 --> Model Class Initialized
INFO - 2020-03-17 17:29:15 --> Database Driver Class Initialized
INFO - 2020-03-17 17:29:15 --> Model Class Initialized
DEBUG - 2020-03-17 17:29:15 --> Template Class Initialized
INFO - 2020-03-17 17:29:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:29:15 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:29:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:29:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:29:15 --> Encryption Class Initialized
INFO - 2020-03-17 17:29:15 --> Controller Class Initialized
DEBUG - 2020-03-17 17:29:15 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:29:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 17:29:15 --> Model Class Initialized
ERROR - 2020-03-17 17:29:16 --> Severity: error --> Exception: Received unknown parameter: data_payment_method D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\libraries\stripe\stripe\stripe-php\lib\Exception\ApiErrorException.php 38
INFO - 2020-03-17 17:33:37 --> Config Class Initialized
INFO - 2020-03-17 17:33:37 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:33:37 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:33:37 --> Utf8 Class Initialized
INFO - 2020-03-17 17:33:37 --> URI Class Initialized
INFO - 2020-03-17 17:33:37 --> Router Class Initialized
INFO - 2020-03-17 17:33:37 --> Output Class Initialized
INFO - 2020-03-17 17:33:37 --> Security Class Initialized
DEBUG - 2020-03-17 17:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:33:37 --> CSRF cookie sent
INFO - 2020-03-17 17:33:37 --> Input Class Initialized
INFO - 2020-03-17 17:33:37 --> Language Class Initialized
INFO - 2020-03-17 17:33:37 --> Language Class Initialized
INFO - 2020-03-17 17:33:37 --> Config Class Initialized
INFO - 2020-03-17 17:33:37 --> Loader Class Initialized
INFO - 2020-03-17 17:33:37 --> Helper loaded: url_helper
INFO - 2020-03-17 17:33:37 --> Helper loaded: common_helper
INFO - 2020-03-17 17:33:37 --> Helper loaded: language_helper
INFO - 2020-03-17 17:33:37 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:33:37 --> Helper loaded: email_helper
INFO - 2020-03-17 17:33:37 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:33:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:33:37 --> Parser Class Initialized
INFO - 2020-03-17 17:33:37 --> User Agent Class Initialized
INFO - 2020-03-17 17:33:37 --> Model Class Initialized
INFO - 2020-03-17 17:33:37 --> Database Driver Class Initialized
INFO - 2020-03-17 17:33:37 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:38 --> Template Class Initialized
INFO - 2020-03-17 17:33:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:33:38 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:33:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:33:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:33:38 --> Encryption Class Initialized
INFO - 2020-03-17 17:33:38 --> Controller Class Initialized
DEBUG - 2020-03-17 17:33:38 --> auth MX_Controller Initialized
DEBUG - 2020-03-17 17:33:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-17 17:33:38 --> Model Class Initialized
INFO - 2020-03-17 17:33:38 --> Config Class Initialized
INFO - 2020-03-17 17:33:38 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:33:38 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:33:38 --> Utf8 Class Initialized
INFO - 2020-03-17 17:33:38 --> URI Class Initialized
INFO - 2020-03-17 17:33:38 --> Router Class Initialized
INFO - 2020-03-17 17:33:38 --> Output Class Initialized
INFO - 2020-03-17 17:33:38 --> Security Class Initialized
DEBUG - 2020-03-17 17:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:33:38 --> CSRF cookie sent
INFO - 2020-03-17 17:33:38 --> Input Class Initialized
INFO - 2020-03-17 17:33:38 --> Language Class Initialized
INFO - 2020-03-17 17:33:38 --> Language Class Initialized
INFO - 2020-03-17 17:33:38 --> Config Class Initialized
INFO - 2020-03-17 17:33:38 --> Loader Class Initialized
INFO - 2020-03-17 17:33:38 --> Helper loaded: url_helper
INFO - 2020-03-17 17:33:38 --> Helper loaded: common_helper
INFO - 2020-03-17 17:33:38 --> Helper loaded: language_helper
INFO - 2020-03-17 17:33:38 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:33:38 --> Helper loaded: email_helper
INFO - 2020-03-17 17:33:38 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:33:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:33:38 --> Parser Class Initialized
INFO - 2020-03-17 17:33:38 --> User Agent Class Initialized
INFO - 2020-03-17 17:33:38 --> Model Class Initialized
INFO - 2020-03-17 17:33:38 --> Database Driver Class Initialized
INFO - 2020-03-17 17:33:38 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:38 --> Template Class Initialized
INFO - 2020-03-17 17:33:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:33:38 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:33:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:33:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:33:38 --> Encryption Class Initialized
INFO - 2020-03-17 17:33:38 --> Controller Class Initialized
DEBUG - 2020-03-17 17:33:38 --> statistics MX_Controller Initialized
DEBUG - 2020-03-17 17:33:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-17 17:33:38 --> Model Class Initialized
ERROR - 2020-03-17 17:33:38 --> Could not find the language line "Pending"
ERROR - 2020-03-17 17:33:39 --> Could not find the language line "Pending"
INFO - 2020-03-17 17:33:39 --> Helper loaded: inflector_helper
ERROR - 2020-03-17 17:33:39 --> Could not find the language line "total_orders"
ERROR - 2020-03-17 17:33:39 --> Could not find the language line "total_orders"
ERROR - 2020-03-17 17:33:39 --> Could not find the language line "Pending"
DEBUG - 2020-03-17 17:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-17 17:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 17:33:39 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 17:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 17:33:39 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 17:33:39 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 17:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 17:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 17:33:39 --> Final output sent to browser
DEBUG - 2020-03-17 17:33:39 --> Total execution time: 1.2727
INFO - 2020-03-17 17:33:43 --> Config Class Initialized
INFO - 2020-03-17 17:33:43 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:33:43 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:33:43 --> Utf8 Class Initialized
INFO - 2020-03-17 17:33:43 --> URI Class Initialized
INFO - 2020-03-17 17:33:43 --> Router Class Initialized
INFO - 2020-03-17 17:33:43 --> Output Class Initialized
INFO - 2020-03-17 17:33:43 --> Security Class Initialized
DEBUG - 2020-03-17 17:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:33:43 --> CSRF cookie sent
INFO - 2020-03-17 17:33:43 --> Input Class Initialized
INFO - 2020-03-17 17:33:43 --> Language Class Initialized
INFO - 2020-03-17 17:33:44 --> Language Class Initialized
INFO - 2020-03-17 17:33:44 --> Config Class Initialized
INFO - 2020-03-17 17:33:44 --> Loader Class Initialized
INFO - 2020-03-17 17:33:44 --> Helper loaded: url_helper
INFO - 2020-03-17 17:33:44 --> Helper loaded: common_helper
INFO - 2020-03-17 17:33:44 --> Helper loaded: language_helper
INFO - 2020-03-17 17:33:44 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:33:44 --> Helper loaded: email_helper
INFO - 2020-03-17 17:33:44 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:33:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:33:44 --> Parser Class Initialized
INFO - 2020-03-17 17:33:44 --> User Agent Class Initialized
INFO - 2020-03-17 17:33:44 --> Model Class Initialized
INFO - 2020-03-17 17:33:44 --> Database Driver Class Initialized
INFO - 2020-03-17 17:33:44 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:44 --> Template Class Initialized
INFO - 2020-03-17 17:33:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:33:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:33:44 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:33:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:33:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:33:44 --> Encryption Class Initialized
INFO - 2020-03-17 17:33:44 --> Controller Class Initialized
DEBUG - 2020-03-17 17:33:44 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 17:33:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 17:33:44 --> Model Class Initialized
INFO - 2020-03-17 17:33:44 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 17:33:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-17 17:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2020-03-17 17:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-17 17:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 17:33:45 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 17:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 17:33:45 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 17:33:45 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 17:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 17:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 17:33:45 --> Final output sent to browser
DEBUG - 2020-03-17 17:33:45 --> Total execution time: 1.5506
INFO - 2020-03-17 17:33:50 --> Config Class Initialized
INFO - 2020-03-17 17:33:50 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:33:50 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:33:50 --> Utf8 Class Initialized
INFO - 2020-03-17 17:33:50 --> URI Class Initialized
INFO - 2020-03-17 17:33:50 --> Router Class Initialized
INFO - 2020-03-17 17:33:50 --> Output Class Initialized
INFO - 2020-03-17 17:33:50 --> Security Class Initialized
DEBUG - 2020-03-17 17:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:33:50 --> CSRF cookie sent
INFO - 2020-03-17 17:33:50 --> Input Class Initialized
INFO - 2020-03-17 17:33:50 --> Language Class Initialized
INFO - 2020-03-17 17:33:50 --> Language Class Initialized
INFO - 2020-03-17 17:33:50 --> Config Class Initialized
INFO - 2020-03-17 17:33:50 --> Loader Class Initialized
INFO - 2020-03-17 17:33:50 --> Helper loaded: url_helper
INFO - 2020-03-17 17:33:50 --> Helper loaded: common_helper
INFO - 2020-03-17 17:33:50 --> Helper loaded: language_helper
INFO - 2020-03-17 17:33:50 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:33:50 --> Helper loaded: email_helper
INFO - 2020-03-17 17:33:50 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:33:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:33:50 --> Parser Class Initialized
INFO - 2020-03-17 17:33:50 --> User Agent Class Initialized
INFO - 2020-03-17 17:33:50 --> Model Class Initialized
INFO - 2020-03-17 17:33:50 --> Database Driver Class Initialized
INFO - 2020-03-17 17:33:50 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:50 --> Template Class Initialized
INFO - 2020-03-17 17:33:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:33:50 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:33:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:33:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:33:50 --> Encryption Class Initialized
INFO - 2020-03-17 17:33:50 --> Controller Class Initialized
DEBUG - 2020-03-17 17:33:50 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 17:33:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 17:33:50 --> Model Class Initialized
INFO - 2020-03-17 17:33:50 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 17:33:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-17 17:33:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/stripe.php
DEBUG - 2020-03-17 17:33:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-17 17:33:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 17:33:51 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 17:33:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 17:33:51 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 17:33:51 --> Model Class Initialized
DEBUG - 2020-03-17 17:33:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 17:33:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 17:33:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 17:33:51 --> Final output sent to browser
DEBUG - 2020-03-17 17:33:51 --> Total execution time: 1.2557
INFO - 2020-03-17 17:34:05 --> Config Class Initialized
INFO - 2020-03-17 17:34:05 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:34:05 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:34:05 --> Utf8 Class Initialized
INFO - 2020-03-17 17:34:05 --> URI Class Initialized
INFO - 2020-03-17 17:34:05 --> Router Class Initialized
INFO - 2020-03-17 17:34:05 --> Output Class Initialized
INFO - 2020-03-17 17:34:05 --> Security Class Initialized
DEBUG - 2020-03-17 17:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:34:05 --> CSRF cookie sent
INFO - 2020-03-17 17:34:05 --> CSRF token verified
INFO - 2020-03-17 17:34:05 --> Input Class Initialized
INFO - 2020-03-17 17:34:05 --> Language Class Initialized
INFO - 2020-03-17 17:34:05 --> Language Class Initialized
INFO - 2020-03-17 17:34:05 --> Config Class Initialized
INFO - 2020-03-17 17:34:05 --> Loader Class Initialized
INFO - 2020-03-17 17:34:05 --> Helper loaded: url_helper
INFO - 2020-03-17 17:34:05 --> Helper loaded: common_helper
INFO - 2020-03-17 17:34:05 --> Helper loaded: language_helper
INFO - 2020-03-17 17:34:05 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:34:05 --> Helper loaded: email_helper
INFO - 2020-03-17 17:34:05 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:34:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:34:05 --> Parser Class Initialized
INFO - 2020-03-17 17:34:05 --> User Agent Class Initialized
INFO - 2020-03-17 17:34:05 --> Model Class Initialized
INFO - 2020-03-17 17:34:05 --> Database Driver Class Initialized
INFO - 2020-03-17 17:34:05 --> Model Class Initialized
DEBUG - 2020-03-17 17:34:05 --> Template Class Initialized
INFO - 2020-03-17 17:34:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:34:05 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:34:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:34:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:34:05 --> Encryption Class Initialized
INFO - 2020-03-17 17:34:05 --> Controller Class Initialized
DEBUG - 2020-03-17 17:34:05 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 17:34:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 17:34:05 --> Model Class Initialized
INFO - 2020-03-17 17:34:10 --> Config Class Initialized
INFO - 2020-03-17 17:34:10 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:34:10 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:34:10 --> Utf8 Class Initialized
INFO - 2020-03-17 17:34:10 --> URI Class Initialized
INFO - 2020-03-17 17:34:10 --> Router Class Initialized
INFO - 2020-03-17 17:34:10 --> Output Class Initialized
INFO - 2020-03-17 17:34:10 --> Security Class Initialized
DEBUG - 2020-03-17 17:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:34:10 --> CSRF cookie sent
INFO - 2020-03-17 17:34:10 --> Input Class Initialized
INFO - 2020-03-17 17:34:10 --> Language Class Initialized
INFO - 2020-03-17 17:34:10 --> Language Class Initialized
INFO - 2020-03-17 17:34:10 --> Config Class Initialized
INFO - 2020-03-17 17:34:10 --> Loader Class Initialized
INFO - 2020-03-17 17:34:10 --> Helper loaded: url_helper
INFO - 2020-03-17 17:34:10 --> Helper loaded: common_helper
INFO - 2020-03-17 17:34:10 --> Helper loaded: language_helper
INFO - 2020-03-17 17:34:10 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:34:10 --> Helper loaded: email_helper
INFO - 2020-03-17 17:34:10 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:34:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:34:10 --> Parser Class Initialized
INFO - 2020-03-17 17:34:10 --> User Agent Class Initialized
INFO - 2020-03-17 17:34:10 --> Model Class Initialized
INFO - 2020-03-17 17:34:11 --> Database Driver Class Initialized
INFO - 2020-03-17 17:34:11 --> Model Class Initialized
DEBUG - 2020-03-17 17:34:11 --> Template Class Initialized
INFO - 2020-03-17 17:34:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:34:11 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:34:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:34:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:34:11 --> Encryption Class Initialized
INFO - 2020-03-17 17:34:11 --> Controller Class Initialized
DEBUG - 2020-03-17 17:34:11 --> setting MX_Controller Initialized
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-17 17:34:11 --> Model Class Initialized
INFO - 2020-03-17 17:34:11 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/stripe.php
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 17:34:11 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 17:34:11 --> Model Class Initialized
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 17:34:11 --> Model Class Initialized
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-17 17:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-17 17:34:11 --> Final output sent to browser
DEBUG - 2020-03-17 17:34:11 --> Total execution time: 1.0015
INFO - 2020-03-17 17:34:17 --> Config Class Initialized
INFO - 2020-03-17 17:34:17 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:34:17 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:34:17 --> Utf8 Class Initialized
INFO - 2020-03-17 17:34:17 --> URI Class Initialized
INFO - 2020-03-17 17:34:17 --> Router Class Initialized
INFO - 2020-03-17 17:34:17 --> Output Class Initialized
INFO - 2020-03-17 17:34:17 --> Security Class Initialized
DEBUG - 2020-03-17 17:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:34:17 --> Input Class Initialized
INFO - 2020-03-17 17:34:17 --> Language Class Initialized
INFO - 2020-03-17 17:34:17 --> Language Class Initialized
INFO - 2020-03-17 17:34:17 --> Config Class Initialized
INFO - 2020-03-17 17:34:17 --> Loader Class Initialized
INFO - 2020-03-17 17:34:17 --> Helper loaded: url_helper
INFO - 2020-03-17 17:34:17 --> Helper loaded: common_helper
INFO - 2020-03-17 17:34:17 --> Helper loaded: language_helper
INFO - 2020-03-17 17:34:17 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:34:17 --> Helper loaded: email_helper
INFO - 2020-03-17 17:34:17 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:34:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:34:17 --> Parser Class Initialized
INFO - 2020-03-17 17:34:17 --> User Agent Class Initialized
INFO - 2020-03-17 17:34:17 --> Model Class Initialized
INFO - 2020-03-17 17:34:17 --> Database Driver Class Initialized
INFO - 2020-03-17 17:34:18 --> Model Class Initialized
DEBUG - 2020-03-17 17:34:18 --> Template Class Initialized
INFO - 2020-03-17 17:34:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:34:18 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:34:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:34:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:34:18 --> Encryption Class Initialized
INFO - 2020-03-17 17:34:18 --> Controller Class Initialized
DEBUG - 2020-03-17 17:34:18 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 17:34:18 --> Model Class Initialized
INFO - 2020-03-17 17:38:24 --> Config Class Initialized
INFO - 2020-03-17 17:38:24 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:38:24 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:38:24 --> Utf8 Class Initialized
INFO - 2020-03-17 17:38:24 --> URI Class Initialized
INFO - 2020-03-17 17:38:24 --> Router Class Initialized
INFO - 2020-03-17 17:38:24 --> Output Class Initialized
INFO - 2020-03-17 17:38:24 --> Security Class Initialized
DEBUG - 2020-03-17 17:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:38:24 --> Input Class Initialized
INFO - 2020-03-17 17:38:24 --> Language Class Initialized
INFO - 2020-03-17 17:38:24 --> Language Class Initialized
INFO - 2020-03-17 17:38:24 --> Config Class Initialized
INFO - 2020-03-17 17:38:24 --> Loader Class Initialized
INFO - 2020-03-17 17:38:24 --> Helper loaded: url_helper
INFO - 2020-03-17 17:38:24 --> Helper loaded: common_helper
INFO - 2020-03-17 17:38:24 --> Helper loaded: language_helper
INFO - 2020-03-17 17:38:24 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:38:24 --> Helper loaded: email_helper
INFO - 2020-03-17 17:38:24 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:38:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:38:24 --> Parser Class Initialized
INFO - 2020-03-17 17:38:24 --> User Agent Class Initialized
INFO - 2020-03-17 17:38:24 --> Model Class Initialized
INFO - 2020-03-17 17:38:24 --> Database Driver Class Initialized
INFO - 2020-03-17 17:38:24 --> Model Class Initialized
DEBUG - 2020-03-17 17:38:24 --> Template Class Initialized
INFO - 2020-03-17 17:38:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:38:24 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:38:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:38:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:38:24 --> Encryption Class Initialized
INFO - 2020-03-17 17:38:24 --> Controller Class Initialized
DEBUG - 2020-03-17 17:38:24 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:38:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 17:38:24 --> Model Class Initialized
INFO - 2020-03-17 17:40:00 --> Config Class Initialized
INFO - 2020-03-17 17:40:00 --> Hooks Class Initialized
DEBUG - 2020-03-17 17:40:00 --> UTF-8 Support Enabled
INFO - 2020-03-17 17:40:00 --> Utf8 Class Initialized
INFO - 2020-03-17 17:40:00 --> URI Class Initialized
INFO - 2020-03-17 17:40:00 --> Router Class Initialized
INFO - 2020-03-17 17:40:00 --> Output Class Initialized
INFO - 2020-03-17 17:40:00 --> Security Class Initialized
DEBUG - 2020-03-17 17:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 17:40:00 --> Input Class Initialized
INFO - 2020-03-17 17:40:00 --> Language Class Initialized
INFO - 2020-03-17 17:40:00 --> Language Class Initialized
INFO - 2020-03-17 17:40:00 --> Config Class Initialized
INFO - 2020-03-17 17:40:00 --> Loader Class Initialized
INFO - 2020-03-17 17:40:00 --> Helper loaded: url_helper
INFO - 2020-03-17 17:40:00 --> Helper loaded: common_helper
INFO - 2020-03-17 17:40:00 --> Helper loaded: language_helper
INFO - 2020-03-17 17:40:00 --> Helper loaded: cookie_helper
INFO - 2020-03-17 17:40:00 --> Helper loaded: email_helper
INFO - 2020-03-17 17:40:00 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 17:40:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 17:40:00 --> Parser Class Initialized
INFO - 2020-03-17 17:40:00 --> User Agent Class Initialized
INFO - 2020-03-17 17:40:01 --> Model Class Initialized
INFO - 2020-03-17 17:40:01 --> Database Driver Class Initialized
INFO - 2020-03-17 17:40:01 --> Model Class Initialized
DEBUG - 2020-03-17 17:40:01 --> Template Class Initialized
INFO - 2020-03-17 17:40:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 17:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 17:40:01 --> Pagination Class Initialized
DEBUG - 2020-03-17 17:40:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 17:40:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 17:40:01 --> Encryption Class Initialized
INFO - 2020-03-17 17:40:01 --> Controller Class Initialized
DEBUG - 2020-03-17 17:40:01 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 17:40:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 17:40:01 --> Model Class Initialized
INFO - 2020-03-17 18:18:01 --> Config Class Initialized
INFO - 2020-03-17 18:18:01 --> Hooks Class Initialized
DEBUG - 2020-03-17 18:18:01 --> UTF-8 Support Enabled
INFO - 2020-03-17 18:18:01 --> Utf8 Class Initialized
INFO - 2020-03-17 18:18:01 --> URI Class Initialized
INFO - 2020-03-17 18:18:01 --> Router Class Initialized
INFO - 2020-03-17 18:18:01 --> Output Class Initialized
INFO - 2020-03-17 18:18:01 --> Security Class Initialized
DEBUG - 2020-03-17 18:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 18:18:01 --> Input Class Initialized
INFO - 2020-03-17 18:18:01 --> Language Class Initialized
INFO - 2020-03-17 18:18:01 --> Language Class Initialized
INFO - 2020-03-17 18:18:01 --> Config Class Initialized
INFO - 2020-03-17 18:18:01 --> Loader Class Initialized
INFO - 2020-03-17 18:18:01 --> Helper loaded: url_helper
INFO - 2020-03-17 18:18:01 --> Helper loaded: common_helper
INFO - 2020-03-17 18:18:01 --> Helper loaded: language_helper
INFO - 2020-03-17 18:18:01 --> Helper loaded: cookie_helper
INFO - 2020-03-17 18:18:01 --> Helper loaded: email_helper
INFO - 2020-03-17 18:18:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 18:18:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 18:18:01 --> Parser Class Initialized
INFO - 2020-03-17 18:18:01 --> User Agent Class Initialized
INFO - 2020-03-17 18:18:01 --> Model Class Initialized
INFO - 2020-03-17 18:18:01 --> Database Driver Class Initialized
INFO - 2020-03-17 18:18:01 --> Model Class Initialized
DEBUG - 2020-03-17 18:18:01 --> Template Class Initialized
INFO - 2020-03-17 18:18:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 18:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 18:18:01 --> Pagination Class Initialized
DEBUG - 2020-03-17 18:18:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 18:18:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 18:18:01 --> Encryption Class Initialized
INFO - 2020-03-17 18:18:01 --> Controller Class Initialized
DEBUG - 2020-03-17 18:18:01 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 18:18:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 18:18:01 --> Model Class Initialized
INFO - 2020-03-17 18:18:27 --> Config Class Initialized
INFO - 2020-03-17 18:18:27 --> Hooks Class Initialized
DEBUG - 2020-03-17 18:18:27 --> UTF-8 Support Enabled
INFO - 2020-03-17 18:18:27 --> Utf8 Class Initialized
INFO - 2020-03-17 18:18:27 --> URI Class Initialized
INFO - 2020-03-17 18:18:27 --> Router Class Initialized
INFO - 2020-03-17 18:18:27 --> Output Class Initialized
INFO - 2020-03-17 18:18:27 --> Security Class Initialized
DEBUG - 2020-03-17 18:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 18:18:27 --> Input Class Initialized
INFO - 2020-03-17 18:18:27 --> Language Class Initialized
INFO - 2020-03-17 18:18:27 --> Language Class Initialized
INFO - 2020-03-17 18:18:27 --> Config Class Initialized
INFO - 2020-03-17 18:18:27 --> Loader Class Initialized
INFO - 2020-03-17 18:18:27 --> Helper loaded: url_helper
INFO - 2020-03-17 18:18:27 --> Helper loaded: common_helper
INFO - 2020-03-17 18:18:27 --> Helper loaded: language_helper
INFO - 2020-03-17 18:18:27 --> Helper loaded: cookie_helper
INFO - 2020-03-17 18:18:27 --> Helper loaded: email_helper
INFO - 2020-03-17 18:18:27 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 18:18:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 18:18:27 --> Parser Class Initialized
INFO - 2020-03-17 18:18:27 --> User Agent Class Initialized
INFO - 2020-03-17 18:18:27 --> Model Class Initialized
INFO - 2020-03-17 18:18:28 --> Database Driver Class Initialized
INFO - 2020-03-17 18:18:28 --> Model Class Initialized
DEBUG - 2020-03-17 18:18:28 --> Template Class Initialized
INFO - 2020-03-17 18:18:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 18:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 18:18:28 --> Pagination Class Initialized
DEBUG - 2020-03-17 18:18:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 18:18:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 18:18:28 --> Encryption Class Initialized
INFO - 2020-03-17 18:18:28 --> Controller Class Initialized
DEBUG - 2020-03-17 18:18:28 --> stripe MX_Controller Initialized
DEBUG - 2020-03-17 18:18:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2020-03-17 18:18:28 --> Model Class Initialized
DEBUG - 2020-03-17 18:18:30 --> orders MX_Controller Initialized
INFO - 2020-03-17 18:18:31 --> Config Class Initialized
INFO - 2020-03-17 18:18:31 --> Hooks Class Initialized
DEBUG - 2020-03-17 18:18:31 --> UTF-8 Support Enabled
INFO - 2020-03-17 18:18:31 --> Utf8 Class Initialized
INFO - 2020-03-17 18:18:31 --> URI Class Initialized
INFO - 2020-03-17 18:18:31 --> Router Class Initialized
INFO - 2020-03-17 18:18:31 --> Output Class Initialized
INFO - 2020-03-17 18:18:31 --> Security Class Initialized
DEBUG - 2020-03-17 18:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-17 18:18:31 --> CSRF cookie sent
INFO - 2020-03-17 18:18:31 --> Input Class Initialized
INFO - 2020-03-17 18:18:31 --> Language Class Initialized
INFO - 2020-03-17 18:18:31 --> Language Class Initialized
INFO - 2020-03-17 18:18:31 --> Config Class Initialized
INFO - 2020-03-17 18:18:31 --> Loader Class Initialized
INFO - 2020-03-17 18:18:31 --> Helper loaded: url_helper
INFO - 2020-03-17 18:18:31 --> Helper loaded: common_helper
INFO - 2020-03-17 18:18:31 --> Helper loaded: language_helper
INFO - 2020-03-17 18:18:31 --> Helper loaded: cookie_helper
INFO - 2020-03-17 18:18:31 --> Helper loaded: email_helper
INFO - 2020-03-17 18:18:31 --> Helper loaded: file_manager_helper
INFO - 2020-03-17 18:18:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-17 18:18:31 --> Parser Class Initialized
INFO - 2020-03-17 18:18:31 --> User Agent Class Initialized
INFO - 2020-03-17 18:18:31 --> Model Class Initialized
INFO - 2020-03-17 18:18:31 --> Database Driver Class Initialized
INFO - 2020-03-17 18:18:31 --> Model Class Initialized
DEBUG - 2020-03-17 18:18:31 --> Template Class Initialized
INFO - 2020-03-17 18:18:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-17 18:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-17 18:18:31 --> Pagination Class Initialized
DEBUG - 2020-03-17 18:18:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-17 18:18:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-17 18:18:31 --> Encryption Class Initialized
INFO - 2020-03-17 18:18:31 --> Controller Class Initialized
DEBUG - 2020-03-17 18:18:31 --> checkout MX_Controller Initialized
DEBUG - 2020-03-17 18:18:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-17 18:18:31 --> Model Class Initialized
INFO - 2020-03-17 18:18:31 --> Helper loaded: inflector_helper
DEBUG - 2020-03-17 18:18:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-17 18:18:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-17 18:18:31 --> blocks MX_Controller Initialized
DEBUG - 2020-03-17 18:18:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-17 18:18:31 --> Model Class Initialized
DEBUG - 2020-03-17 18:18:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-17 18:18:31 --> Model Class Initialized
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 18:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 18:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 18:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 18:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 18:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 18:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-17 18:18:32 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-17 18:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-17 18:18:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-17 18:18:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-17 18:18:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-17 18:18:32 --> Final output sent to browser
DEBUG - 2020-03-17 18:18:32 --> Total execution time: 1.4660
