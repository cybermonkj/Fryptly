<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-11 10:03:28 --> Config Class Initialized
INFO - 2020-01-11 10:03:28 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:03:28 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:03:28 --> Utf8 Class Initialized
INFO - 2020-01-11 10:03:28 --> URI Class Initialized
DEBUG - 2020-01-11 10:03:28 --> No URI present. Default controller set.
INFO - 2020-01-11 10:03:28 --> Router Class Initialized
INFO - 2020-01-11 10:03:28 --> Output Class Initialized
INFO - 2020-01-11 10:03:28 --> Security Class Initialized
DEBUG - 2020-01-11 10:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:03:28 --> CSRF cookie sent
INFO - 2020-01-11 10:03:28 --> Input Class Initialized
INFO - 2020-01-11 10:03:28 --> Language Class Initialized
INFO - 2020-01-11 10:03:28 --> Language Class Initialized
INFO - 2020-01-11 10:03:28 --> Config Class Initialized
INFO - 2020-01-11 10:03:28 --> Loader Class Initialized
INFO - 2020-01-11 10:03:28 --> Helper loaded: url_helper
INFO - 2020-01-11 10:03:28 --> Helper loaded: common_helper
INFO - 2020-01-11 10:03:28 --> Helper loaded: language_helper
INFO - 2020-01-11 10:03:28 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:03:28 --> Helper loaded: email_helper
INFO - 2020-01-11 10:03:28 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:03:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:03:29 --> Parser Class Initialized
INFO - 2020-01-11 10:03:29 --> User Agent Class Initialized
INFO - 2020-01-11 10:03:29 --> Model Class Initialized
INFO - 2020-01-11 10:03:29 --> Database Driver Class Initialized
INFO - 2020-01-11 10:03:29 --> Model Class Initialized
DEBUG - 2020-01-11 10:03:29 --> Template Class Initialized
INFO - 2020-01-11 10:03:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:03:29 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:03:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:03:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:03:29 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:03:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:03:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:03:29 --> Controller Class Initialized
DEBUG - 2020-01-11 10:03:29 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:03:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:03:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:03:29 --> Model Class Initialized
INFO - 2020-01-11 10:03:29 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:03:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:03:30 --> Final output sent to browser
DEBUG - 2020-01-11 10:03:30 --> Total execution time: 2.3129
INFO - 2020-01-11 10:05:54 --> Config Class Initialized
INFO - 2020-01-11 10:05:54 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:05:54 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:05:54 --> Utf8 Class Initialized
INFO - 2020-01-11 10:05:54 --> URI Class Initialized
DEBUG - 2020-01-11 10:05:54 --> No URI present. Default controller set.
INFO - 2020-01-11 10:05:54 --> Router Class Initialized
INFO - 2020-01-11 10:05:54 --> Output Class Initialized
INFO - 2020-01-11 10:05:54 --> Security Class Initialized
DEBUG - 2020-01-11 10:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:05:54 --> CSRF cookie sent
INFO - 2020-01-11 10:05:54 --> Input Class Initialized
INFO - 2020-01-11 10:05:54 --> Language Class Initialized
INFO - 2020-01-11 10:05:54 --> Language Class Initialized
INFO - 2020-01-11 10:05:54 --> Config Class Initialized
INFO - 2020-01-11 10:05:54 --> Loader Class Initialized
INFO - 2020-01-11 10:05:54 --> Helper loaded: url_helper
INFO - 2020-01-11 10:05:54 --> Helper loaded: common_helper
INFO - 2020-01-11 10:05:54 --> Helper loaded: language_helper
INFO - 2020-01-11 10:05:54 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:05:54 --> Helper loaded: email_helper
INFO - 2020-01-11 10:05:54 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:05:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:05:54 --> Parser Class Initialized
INFO - 2020-01-11 10:05:54 --> User Agent Class Initialized
INFO - 2020-01-11 10:05:54 --> Model Class Initialized
INFO - 2020-01-11 10:05:54 --> Database Driver Class Initialized
INFO - 2020-01-11 10:05:54 --> Model Class Initialized
DEBUG - 2020-01-11 10:05:54 --> Template Class Initialized
INFO - 2020-01-11 10:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:05:55 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:05:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:05:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:05:55 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:05:55 --> Controller Class Initialized
DEBUG - 2020-01-11 10:05:55 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:05:55 --> Model Class Initialized
INFO - 2020-01-11 10:05:55 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:05:55 --> Final output sent to browser
DEBUG - 2020-01-11 10:05:55 --> Total execution time: 0.9019
INFO - 2020-01-11 10:06:14 --> Config Class Initialized
INFO - 2020-01-11 10:06:14 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:06:14 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:06:14 --> Utf8 Class Initialized
INFO - 2020-01-11 10:06:14 --> URI Class Initialized
DEBUG - 2020-01-11 10:06:14 --> No URI present. Default controller set.
INFO - 2020-01-11 10:06:14 --> Router Class Initialized
INFO - 2020-01-11 10:06:15 --> Output Class Initialized
INFO - 2020-01-11 10:06:15 --> Security Class Initialized
DEBUG - 2020-01-11 10:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:06:15 --> CSRF cookie sent
INFO - 2020-01-11 10:06:15 --> Input Class Initialized
INFO - 2020-01-11 10:06:15 --> Language Class Initialized
INFO - 2020-01-11 10:06:15 --> Language Class Initialized
INFO - 2020-01-11 10:06:15 --> Config Class Initialized
INFO - 2020-01-11 10:06:15 --> Loader Class Initialized
INFO - 2020-01-11 10:06:15 --> Helper loaded: url_helper
INFO - 2020-01-11 10:06:15 --> Helper loaded: common_helper
INFO - 2020-01-11 10:06:15 --> Helper loaded: language_helper
INFO - 2020-01-11 10:06:15 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:06:15 --> Helper loaded: email_helper
INFO - 2020-01-11 10:06:15 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:06:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:06:15 --> Parser Class Initialized
INFO - 2020-01-11 10:06:15 --> User Agent Class Initialized
INFO - 2020-01-11 10:06:15 --> Model Class Initialized
INFO - 2020-01-11 10:06:15 --> Database Driver Class Initialized
INFO - 2020-01-11 10:06:15 --> Model Class Initialized
DEBUG - 2020-01-11 10:06:15 --> Template Class Initialized
INFO - 2020-01-11 10:06:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:06:15 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:06:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:06:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:06:15 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:06:15 --> Controller Class Initialized
DEBUG - 2020-01-11 10:06:15 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:06:15 --> Model Class Initialized
INFO - 2020-01-11 10:06:15 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:06:15 --> Final output sent to browser
DEBUG - 2020-01-11 10:06:15 --> Total execution time: 0.7943
INFO - 2020-01-11 10:06:26 --> Config Class Initialized
INFO - 2020-01-11 10:06:26 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:06:26 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:06:26 --> Utf8 Class Initialized
INFO - 2020-01-11 10:06:26 --> URI Class Initialized
DEBUG - 2020-01-11 10:06:26 --> No URI present. Default controller set.
INFO - 2020-01-11 10:06:26 --> Router Class Initialized
INFO - 2020-01-11 10:06:26 --> Output Class Initialized
INFO - 2020-01-11 10:06:26 --> Security Class Initialized
DEBUG - 2020-01-11 10:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:06:26 --> CSRF cookie sent
INFO - 2020-01-11 10:06:26 --> Input Class Initialized
INFO - 2020-01-11 10:06:26 --> Language Class Initialized
INFO - 2020-01-11 10:06:26 --> Language Class Initialized
INFO - 2020-01-11 10:06:26 --> Config Class Initialized
INFO - 2020-01-11 10:06:26 --> Loader Class Initialized
INFO - 2020-01-11 10:06:26 --> Helper loaded: url_helper
INFO - 2020-01-11 10:06:26 --> Helper loaded: common_helper
INFO - 2020-01-11 10:06:26 --> Helper loaded: language_helper
INFO - 2020-01-11 10:06:26 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:06:26 --> Helper loaded: email_helper
INFO - 2020-01-11 10:06:26 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:06:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:06:26 --> Parser Class Initialized
INFO - 2020-01-11 10:06:26 --> User Agent Class Initialized
INFO - 2020-01-11 10:06:26 --> Model Class Initialized
INFO - 2020-01-11 10:06:26 --> Database Driver Class Initialized
INFO - 2020-01-11 10:06:26 --> Model Class Initialized
DEBUG - 2020-01-11 10:06:26 --> Template Class Initialized
INFO - 2020-01-11 10:06:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:06:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:06:26 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:06:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:06:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:06:26 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:06:26 --> Controller Class Initialized
DEBUG - 2020-01-11 10:06:26 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:06:26 --> Model Class Initialized
INFO - 2020-01-11 10:06:26 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:06:26 --> Final output sent to browser
DEBUG - 2020-01-11 10:06:26 --> Total execution time: 0.7575
INFO - 2020-01-11 10:06:39 --> Config Class Initialized
INFO - 2020-01-11 10:06:39 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:06:39 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:06:39 --> Utf8 Class Initialized
INFO - 2020-01-11 10:06:39 --> URI Class Initialized
DEBUG - 2020-01-11 10:06:39 --> No URI present. Default controller set.
INFO - 2020-01-11 10:06:39 --> Router Class Initialized
INFO - 2020-01-11 10:06:39 --> Output Class Initialized
INFO - 2020-01-11 10:06:39 --> Security Class Initialized
DEBUG - 2020-01-11 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:06:39 --> CSRF cookie sent
INFO - 2020-01-11 10:06:39 --> Input Class Initialized
INFO - 2020-01-11 10:06:39 --> Language Class Initialized
INFO - 2020-01-11 10:06:39 --> Language Class Initialized
INFO - 2020-01-11 10:06:39 --> Config Class Initialized
INFO - 2020-01-11 10:06:39 --> Loader Class Initialized
INFO - 2020-01-11 10:06:39 --> Helper loaded: url_helper
INFO - 2020-01-11 10:06:39 --> Helper loaded: common_helper
INFO - 2020-01-11 10:06:39 --> Helper loaded: language_helper
INFO - 2020-01-11 10:06:39 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:06:39 --> Helper loaded: email_helper
INFO - 2020-01-11 10:06:39 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:06:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:06:39 --> Parser Class Initialized
INFO - 2020-01-11 10:06:39 --> User Agent Class Initialized
INFO - 2020-01-11 10:06:39 --> Model Class Initialized
INFO - 2020-01-11 10:06:39 --> Database Driver Class Initialized
INFO - 2020-01-11 10:06:39 --> Model Class Initialized
DEBUG - 2020-01-11 10:06:39 --> Template Class Initialized
INFO - 2020-01-11 10:06:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:06:39 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:06:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:06:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:06:39 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:06:39 --> Controller Class Initialized
DEBUG - 2020-01-11 10:06:39 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:06:39 --> Model Class Initialized
INFO - 2020-01-11 10:06:39 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:06:40 --> Final output sent to browser
DEBUG - 2020-01-11 10:06:40 --> Total execution time: 0.6054
INFO - 2020-01-11 10:06:52 --> Config Class Initialized
INFO - 2020-01-11 10:06:52 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:06:52 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:06:52 --> Utf8 Class Initialized
INFO - 2020-01-11 10:06:52 --> URI Class Initialized
DEBUG - 2020-01-11 10:06:52 --> No URI present. Default controller set.
INFO - 2020-01-11 10:06:52 --> Router Class Initialized
INFO - 2020-01-11 10:06:52 --> Output Class Initialized
INFO - 2020-01-11 10:06:52 --> Security Class Initialized
DEBUG - 2020-01-11 10:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:06:52 --> CSRF cookie sent
INFO - 2020-01-11 10:06:52 --> Input Class Initialized
INFO - 2020-01-11 10:06:52 --> Language Class Initialized
INFO - 2020-01-11 10:06:52 --> Language Class Initialized
INFO - 2020-01-11 10:06:52 --> Config Class Initialized
INFO - 2020-01-11 10:06:52 --> Loader Class Initialized
INFO - 2020-01-11 10:06:52 --> Helper loaded: url_helper
INFO - 2020-01-11 10:06:52 --> Helper loaded: common_helper
INFO - 2020-01-11 10:06:52 --> Helper loaded: language_helper
INFO - 2020-01-11 10:06:52 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:06:52 --> Helper loaded: email_helper
INFO - 2020-01-11 10:06:52 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:06:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:06:52 --> Parser Class Initialized
INFO - 2020-01-11 10:06:52 --> User Agent Class Initialized
INFO - 2020-01-11 10:06:52 --> Model Class Initialized
INFO - 2020-01-11 10:06:52 --> Database Driver Class Initialized
INFO - 2020-01-11 10:06:52 --> Model Class Initialized
DEBUG - 2020-01-11 10:06:52 --> Template Class Initialized
INFO - 2020-01-11 10:06:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:06:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:06:52 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:06:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:06:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:06:52 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:06:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:06:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:06:53 --> Controller Class Initialized
DEBUG - 2020-01-11 10:06:53 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:06:53 --> Model Class Initialized
INFO - 2020-01-11 10:06:53 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:06:53 --> Final output sent to browser
DEBUG - 2020-01-11 10:06:53 --> Total execution time: 0.6001
INFO - 2020-01-11 10:07:50 --> Config Class Initialized
INFO - 2020-01-11 10:07:50 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:07:50 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:07:50 --> Utf8 Class Initialized
INFO - 2020-01-11 10:07:50 --> URI Class Initialized
DEBUG - 2020-01-11 10:07:50 --> No URI present. Default controller set.
INFO - 2020-01-11 10:07:50 --> Router Class Initialized
INFO - 2020-01-11 10:07:50 --> Output Class Initialized
INFO - 2020-01-11 10:07:50 --> Security Class Initialized
DEBUG - 2020-01-11 10:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:07:50 --> CSRF cookie sent
INFO - 2020-01-11 10:07:50 --> Input Class Initialized
INFO - 2020-01-11 10:07:50 --> Language Class Initialized
INFO - 2020-01-11 10:07:50 --> Language Class Initialized
INFO - 2020-01-11 10:07:50 --> Config Class Initialized
INFO - 2020-01-11 10:07:50 --> Loader Class Initialized
INFO - 2020-01-11 10:07:50 --> Helper loaded: url_helper
INFO - 2020-01-11 10:07:50 --> Helper loaded: common_helper
INFO - 2020-01-11 10:07:51 --> Helper loaded: language_helper
INFO - 2020-01-11 10:07:51 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:07:51 --> Helper loaded: email_helper
INFO - 2020-01-11 10:07:51 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:07:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:07:51 --> Parser Class Initialized
INFO - 2020-01-11 10:07:51 --> User Agent Class Initialized
INFO - 2020-01-11 10:07:51 --> Model Class Initialized
INFO - 2020-01-11 10:07:51 --> Database Driver Class Initialized
INFO - 2020-01-11 10:07:51 --> Model Class Initialized
DEBUG - 2020-01-11 10:07:51 --> Template Class Initialized
INFO - 2020-01-11 10:07:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:07:51 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:07:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:07:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:07:51 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:07:51 --> Controller Class Initialized
DEBUG - 2020-01-11 10:07:51 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:07:51 --> Model Class Initialized
INFO - 2020-01-11 10:07:51 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:07:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:07:51 --> Final output sent to browser
DEBUG - 2020-01-11 10:07:51 --> Total execution time: 0.6717
INFO - 2020-01-11 10:11:17 --> Config Class Initialized
INFO - 2020-01-11 10:11:17 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:11:17 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:11:17 --> Utf8 Class Initialized
INFO - 2020-01-11 10:11:17 --> URI Class Initialized
DEBUG - 2020-01-11 10:11:17 --> No URI present. Default controller set.
INFO - 2020-01-11 10:11:17 --> Router Class Initialized
INFO - 2020-01-11 10:11:17 --> Output Class Initialized
INFO - 2020-01-11 10:11:17 --> Security Class Initialized
DEBUG - 2020-01-11 10:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:11:17 --> CSRF cookie sent
INFO - 2020-01-11 10:11:17 --> Input Class Initialized
INFO - 2020-01-11 10:11:17 --> Language Class Initialized
INFO - 2020-01-11 10:11:17 --> Language Class Initialized
INFO - 2020-01-11 10:11:17 --> Config Class Initialized
INFO - 2020-01-11 10:11:17 --> Loader Class Initialized
INFO - 2020-01-11 10:11:17 --> Helper loaded: url_helper
INFO - 2020-01-11 10:11:17 --> Helper loaded: common_helper
INFO - 2020-01-11 10:11:17 --> Helper loaded: language_helper
INFO - 2020-01-11 10:11:17 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:11:17 --> Helper loaded: email_helper
INFO - 2020-01-11 10:11:17 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:11:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:11:17 --> Parser Class Initialized
INFO - 2020-01-11 10:11:17 --> User Agent Class Initialized
INFO - 2020-01-11 10:11:17 --> Model Class Initialized
INFO - 2020-01-11 10:11:17 --> Database Driver Class Initialized
INFO - 2020-01-11 10:11:17 --> Model Class Initialized
DEBUG - 2020-01-11 10:11:17 --> Template Class Initialized
INFO - 2020-01-11 10:11:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:11:17 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:11:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:11:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:11:17 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:11:17 --> Controller Class Initialized
DEBUG - 2020-01-11 10:11:17 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:11:17 --> Model Class Initialized
INFO - 2020-01-11 10:11:17 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:11:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:11:17 --> Final output sent to browser
DEBUG - 2020-01-11 10:11:17 --> Total execution time: 0.6977
INFO - 2020-01-11 10:12:30 --> Config Class Initialized
INFO - 2020-01-11 10:12:30 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:12:30 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:12:30 --> Utf8 Class Initialized
INFO - 2020-01-11 10:12:30 --> URI Class Initialized
DEBUG - 2020-01-11 10:12:31 --> No URI present. Default controller set.
INFO - 2020-01-11 10:12:31 --> Router Class Initialized
INFO - 2020-01-11 10:12:31 --> Output Class Initialized
INFO - 2020-01-11 10:12:31 --> Security Class Initialized
DEBUG - 2020-01-11 10:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:12:31 --> CSRF cookie sent
INFO - 2020-01-11 10:12:31 --> Input Class Initialized
INFO - 2020-01-11 10:12:31 --> Language Class Initialized
INFO - 2020-01-11 10:12:31 --> Language Class Initialized
INFO - 2020-01-11 10:12:31 --> Config Class Initialized
INFO - 2020-01-11 10:12:31 --> Loader Class Initialized
INFO - 2020-01-11 10:12:31 --> Helper loaded: url_helper
INFO - 2020-01-11 10:12:31 --> Helper loaded: common_helper
INFO - 2020-01-11 10:12:31 --> Helper loaded: language_helper
INFO - 2020-01-11 10:12:31 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:12:31 --> Helper loaded: email_helper
INFO - 2020-01-11 10:12:31 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:12:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:12:31 --> Parser Class Initialized
INFO - 2020-01-11 10:12:31 --> User Agent Class Initialized
INFO - 2020-01-11 10:12:31 --> Model Class Initialized
INFO - 2020-01-11 10:12:31 --> Database Driver Class Initialized
INFO - 2020-01-11 10:12:31 --> Model Class Initialized
DEBUG - 2020-01-11 10:12:31 --> Template Class Initialized
INFO - 2020-01-11 10:12:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:12:31 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:12:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:12:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:12:31 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:12:31 --> Controller Class Initialized
DEBUG - 2020-01-11 10:12:31 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:12:31 --> Model Class Initialized
INFO - 2020-01-11 10:12:31 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:12:31 --> Final output sent to browser
DEBUG - 2020-01-11 10:12:31 --> Total execution time: 0.7200
INFO - 2020-01-11 10:14:12 --> Config Class Initialized
INFO - 2020-01-11 10:14:12 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:14:12 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:14:12 --> Utf8 Class Initialized
INFO - 2020-01-11 10:14:12 --> URI Class Initialized
DEBUG - 2020-01-11 10:14:12 --> No URI present. Default controller set.
INFO - 2020-01-11 10:14:12 --> Router Class Initialized
INFO - 2020-01-11 10:14:12 --> Output Class Initialized
INFO - 2020-01-11 10:14:12 --> Security Class Initialized
DEBUG - 2020-01-11 10:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:14:12 --> CSRF cookie sent
INFO - 2020-01-11 10:14:12 --> Input Class Initialized
INFO - 2020-01-11 10:14:12 --> Language Class Initialized
INFO - 2020-01-11 10:14:12 --> Language Class Initialized
INFO - 2020-01-11 10:14:12 --> Config Class Initialized
INFO - 2020-01-11 10:14:12 --> Loader Class Initialized
INFO - 2020-01-11 10:14:12 --> Helper loaded: url_helper
INFO - 2020-01-11 10:14:12 --> Helper loaded: common_helper
INFO - 2020-01-11 10:14:12 --> Helper loaded: language_helper
INFO - 2020-01-11 10:14:12 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:14:12 --> Helper loaded: email_helper
INFO - 2020-01-11 10:14:12 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:14:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:14:12 --> Parser Class Initialized
INFO - 2020-01-11 10:14:12 --> User Agent Class Initialized
INFO - 2020-01-11 10:14:12 --> Model Class Initialized
INFO - 2020-01-11 10:14:12 --> Database Driver Class Initialized
INFO - 2020-01-11 10:14:12 --> Model Class Initialized
DEBUG - 2020-01-11 10:14:12 --> Template Class Initialized
INFO - 2020-01-11 10:14:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:14:12 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:14:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:14:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:14:12 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:14:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:14:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:14:12 --> Controller Class Initialized
DEBUG - 2020-01-11 10:14:12 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:14:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:14:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:14:12 --> Model Class Initialized
INFO - 2020-01-11 10:14:12 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:14:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:14:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:14:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:14:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:14:12 --> Final output sent to browser
DEBUG - 2020-01-11 10:14:12 --> Total execution time: 0.6729
INFO - 2020-01-11 10:14:24 --> Config Class Initialized
INFO - 2020-01-11 10:14:24 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:14:24 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:14:24 --> Utf8 Class Initialized
INFO - 2020-01-11 10:14:24 --> URI Class Initialized
DEBUG - 2020-01-11 10:14:24 --> No URI present. Default controller set.
INFO - 2020-01-11 10:14:24 --> Router Class Initialized
INFO - 2020-01-11 10:14:24 --> Output Class Initialized
INFO - 2020-01-11 10:14:24 --> Security Class Initialized
DEBUG - 2020-01-11 10:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:14:24 --> CSRF cookie sent
INFO - 2020-01-11 10:14:24 --> Input Class Initialized
INFO - 2020-01-11 10:14:24 --> Language Class Initialized
INFO - 2020-01-11 10:14:24 --> Language Class Initialized
INFO - 2020-01-11 10:14:24 --> Config Class Initialized
INFO - 2020-01-11 10:14:24 --> Loader Class Initialized
INFO - 2020-01-11 10:14:24 --> Helper loaded: url_helper
INFO - 2020-01-11 10:14:24 --> Helper loaded: common_helper
INFO - 2020-01-11 10:14:24 --> Helper loaded: language_helper
INFO - 2020-01-11 10:14:24 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:14:24 --> Helper loaded: email_helper
INFO - 2020-01-11 10:14:24 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:14:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:14:24 --> Parser Class Initialized
INFO - 2020-01-11 10:14:24 --> User Agent Class Initialized
INFO - 2020-01-11 10:14:25 --> Model Class Initialized
INFO - 2020-01-11 10:14:25 --> Database Driver Class Initialized
INFO - 2020-01-11 10:14:25 --> Model Class Initialized
DEBUG - 2020-01-11 10:14:25 --> Template Class Initialized
INFO - 2020-01-11 10:14:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:14:25 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:14:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:14:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:14:25 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:14:25 --> Controller Class Initialized
DEBUG - 2020-01-11 10:14:25 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:14:25 --> Model Class Initialized
INFO - 2020-01-11 10:14:25 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:14:25 --> Final output sent to browser
DEBUG - 2020-01-11 10:14:25 --> Total execution time: 0.6490
INFO - 2020-01-11 10:15:26 --> Config Class Initialized
INFO - 2020-01-11 10:15:27 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:15:27 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:15:27 --> Utf8 Class Initialized
INFO - 2020-01-11 10:15:27 --> URI Class Initialized
DEBUG - 2020-01-11 10:15:27 --> No URI present. Default controller set.
INFO - 2020-01-11 10:15:27 --> Router Class Initialized
INFO - 2020-01-11 10:15:27 --> Output Class Initialized
INFO - 2020-01-11 10:15:27 --> Security Class Initialized
DEBUG - 2020-01-11 10:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:15:27 --> CSRF cookie sent
INFO - 2020-01-11 10:15:27 --> Input Class Initialized
INFO - 2020-01-11 10:15:27 --> Language Class Initialized
INFO - 2020-01-11 10:15:27 --> Language Class Initialized
INFO - 2020-01-11 10:15:27 --> Config Class Initialized
INFO - 2020-01-11 10:15:27 --> Loader Class Initialized
INFO - 2020-01-11 10:15:27 --> Helper loaded: url_helper
INFO - 2020-01-11 10:15:27 --> Helper loaded: common_helper
INFO - 2020-01-11 10:15:27 --> Helper loaded: language_helper
INFO - 2020-01-11 10:15:27 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:15:27 --> Helper loaded: email_helper
INFO - 2020-01-11 10:15:27 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:15:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:15:27 --> Parser Class Initialized
INFO - 2020-01-11 10:15:27 --> User Agent Class Initialized
INFO - 2020-01-11 10:15:27 --> Model Class Initialized
INFO - 2020-01-11 10:15:27 --> Database Driver Class Initialized
INFO - 2020-01-11 10:15:27 --> Model Class Initialized
DEBUG - 2020-01-11 10:15:27 --> Template Class Initialized
INFO - 2020-01-11 10:15:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:15:27 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:15:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:15:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:15:27 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:15:27 --> Controller Class Initialized
DEBUG - 2020-01-11 10:15:27 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:15:27 --> Model Class Initialized
INFO - 2020-01-11 10:15:27 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:15:27 --> Final output sent to browser
DEBUG - 2020-01-11 10:15:27 --> Total execution time: 0.6398
INFO - 2020-01-11 10:16:02 --> Config Class Initialized
INFO - 2020-01-11 10:16:02 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:16:02 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:16:02 --> Utf8 Class Initialized
INFO - 2020-01-11 10:16:02 --> URI Class Initialized
DEBUG - 2020-01-11 10:16:02 --> No URI present. Default controller set.
INFO - 2020-01-11 10:16:02 --> Router Class Initialized
INFO - 2020-01-11 10:16:02 --> Output Class Initialized
INFO - 2020-01-11 10:16:02 --> Security Class Initialized
DEBUG - 2020-01-11 10:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:16:02 --> CSRF cookie sent
INFO - 2020-01-11 10:16:02 --> Input Class Initialized
INFO - 2020-01-11 10:16:02 --> Language Class Initialized
INFO - 2020-01-11 10:16:02 --> Language Class Initialized
INFO - 2020-01-11 10:16:02 --> Config Class Initialized
INFO - 2020-01-11 10:16:02 --> Loader Class Initialized
INFO - 2020-01-11 10:16:02 --> Helper loaded: url_helper
INFO - 2020-01-11 10:16:02 --> Helper loaded: common_helper
INFO - 2020-01-11 10:16:02 --> Helper loaded: language_helper
INFO - 2020-01-11 10:16:02 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:16:02 --> Helper loaded: email_helper
INFO - 2020-01-11 10:16:02 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:16:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:16:02 --> Parser Class Initialized
INFO - 2020-01-11 10:16:02 --> User Agent Class Initialized
INFO - 2020-01-11 10:16:02 --> Model Class Initialized
INFO - 2020-01-11 10:16:02 --> Database Driver Class Initialized
INFO - 2020-01-11 10:16:02 --> Model Class Initialized
DEBUG - 2020-01-11 10:16:02 --> Template Class Initialized
INFO - 2020-01-11 10:16:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:16:02 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:16:02 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:16:02 --> Controller Class Initialized
DEBUG - 2020-01-11 10:16:02 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:16:03 --> Model Class Initialized
INFO - 2020-01-11 10:16:03 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:16:03 --> Final output sent to browser
DEBUG - 2020-01-11 10:16:03 --> Total execution time: 0.6297
INFO - 2020-01-11 10:16:23 --> Config Class Initialized
INFO - 2020-01-11 10:16:23 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:16:23 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:16:23 --> Utf8 Class Initialized
INFO - 2020-01-11 10:16:23 --> URI Class Initialized
DEBUG - 2020-01-11 10:16:23 --> No URI present. Default controller set.
INFO - 2020-01-11 10:16:23 --> Router Class Initialized
INFO - 2020-01-11 10:16:23 --> Output Class Initialized
INFO - 2020-01-11 10:16:23 --> Security Class Initialized
DEBUG - 2020-01-11 10:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:16:23 --> CSRF cookie sent
INFO - 2020-01-11 10:16:23 --> Input Class Initialized
INFO - 2020-01-11 10:16:23 --> Language Class Initialized
INFO - 2020-01-11 10:16:23 --> Language Class Initialized
INFO - 2020-01-11 10:16:23 --> Config Class Initialized
INFO - 2020-01-11 10:16:23 --> Loader Class Initialized
INFO - 2020-01-11 10:16:23 --> Helper loaded: url_helper
INFO - 2020-01-11 10:16:23 --> Helper loaded: common_helper
INFO - 2020-01-11 10:16:23 --> Helper loaded: language_helper
INFO - 2020-01-11 10:16:23 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:16:23 --> Helper loaded: email_helper
INFO - 2020-01-11 10:16:23 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:16:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:16:23 --> Parser Class Initialized
INFO - 2020-01-11 10:16:23 --> User Agent Class Initialized
INFO - 2020-01-11 10:16:23 --> Model Class Initialized
INFO - 2020-01-11 10:16:23 --> Database Driver Class Initialized
INFO - 2020-01-11 10:16:23 --> Model Class Initialized
DEBUG - 2020-01-11 10:16:23 --> Template Class Initialized
INFO - 2020-01-11 10:16:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:16:23 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:16:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:16:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:16:23 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:16:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:16:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:16:23 --> Controller Class Initialized
DEBUG - 2020-01-11 10:16:23 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:16:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:16:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:16:23 --> Model Class Initialized
INFO - 2020-01-11 10:16:23 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:16:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:16:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:16:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:16:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:16:24 --> Final output sent to browser
DEBUG - 2020-01-11 10:16:24 --> Total execution time: 0.6637
INFO - 2020-01-11 10:19:55 --> Config Class Initialized
INFO - 2020-01-11 10:19:55 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:19:55 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:19:55 --> Utf8 Class Initialized
INFO - 2020-01-11 10:19:55 --> URI Class Initialized
DEBUG - 2020-01-11 10:19:55 --> No URI present. Default controller set.
INFO - 2020-01-11 10:19:55 --> Router Class Initialized
INFO - 2020-01-11 10:19:55 --> Output Class Initialized
INFO - 2020-01-11 10:19:55 --> Security Class Initialized
DEBUG - 2020-01-11 10:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:19:55 --> CSRF cookie sent
INFO - 2020-01-11 10:19:55 --> Input Class Initialized
INFO - 2020-01-11 10:19:55 --> Language Class Initialized
INFO - 2020-01-11 10:19:55 --> Language Class Initialized
INFO - 2020-01-11 10:19:55 --> Config Class Initialized
INFO - 2020-01-11 10:19:55 --> Loader Class Initialized
INFO - 2020-01-11 10:19:55 --> Helper loaded: url_helper
INFO - 2020-01-11 10:19:55 --> Helper loaded: common_helper
INFO - 2020-01-11 10:19:55 --> Helper loaded: language_helper
INFO - 2020-01-11 10:19:55 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:19:55 --> Helper loaded: email_helper
INFO - 2020-01-11 10:19:55 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:19:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:19:56 --> Parser Class Initialized
INFO - 2020-01-11 10:19:56 --> User Agent Class Initialized
INFO - 2020-01-11 10:19:56 --> Model Class Initialized
INFO - 2020-01-11 10:19:56 --> Database Driver Class Initialized
INFO - 2020-01-11 10:19:56 --> Model Class Initialized
DEBUG - 2020-01-11 10:19:56 --> Template Class Initialized
INFO - 2020-01-11 10:19:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:19:56 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:19:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:19:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:19:56 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:19:56 --> Controller Class Initialized
DEBUG - 2020-01-11 10:19:56 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:19:56 --> Model Class Initialized
INFO - 2020-01-11 10:19:56 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:19:56 --> Final output sent to browser
DEBUG - 2020-01-11 10:19:56 --> Total execution time: 0.6431
INFO - 2020-01-11 10:20:25 --> Config Class Initialized
INFO - 2020-01-11 10:20:25 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:20:25 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:20:25 --> Utf8 Class Initialized
INFO - 2020-01-11 10:20:25 --> URI Class Initialized
DEBUG - 2020-01-11 10:20:25 --> No URI present. Default controller set.
INFO - 2020-01-11 10:20:25 --> Router Class Initialized
INFO - 2020-01-11 10:20:25 --> Output Class Initialized
INFO - 2020-01-11 10:20:25 --> Security Class Initialized
DEBUG - 2020-01-11 10:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:20:25 --> CSRF cookie sent
INFO - 2020-01-11 10:20:25 --> Input Class Initialized
INFO - 2020-01-11 10:20:25 --> Language Class Initialized
INFO - 2020-01-11 10:20:25 --> Language Class Initialized
INFO - 2020-01-11 10:20:25 --> Config Class Initialized
INFO - 2020-01-11 10:20:25 --> Loader Class Initialized
INFO - 2020-01-11 10:20:25 --> Helper loaded: url_helper
INFO - 2020-01-11 10:20:25 --> Helper loaded: common_helper
INFO - 2020-01-11 10:20:25 --> Helper loaded: language_helper
INFO - 2020-01-11 10:20:25 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:20:25 --> Helper loaded: email_helper
INFO - 2020-01-11 10:20:25 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:20:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:20:25 --> Parser Class Initialized
INFO - 2020-01-11 10:20:25 --> User Agent Class Initialized
INFO - 2020-01-11 10:20:25 --> Model Class Initialized
INFO - 2020-01-11 10:20:25 --> Database Driver Class Initialized
INFO - 2020-01-11 10:20:25 --> Model Class Initialized
DEBUG - 2020-01-11 10:20:25 --> Template Class Initialized
INFO - 2020-01-11 10:20:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:20:26 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:20:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:20:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:20:26 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:20:26 --> Controller Class Initialized
DEBUG - 2020-01-11 10:20:26 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:20:26 --> Model Class Initialized
INFO - 2020-01-11 10:20:26 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:20:26 --> Final output sent to browser
DEBUG - 2020-01-11 10:20:26 --> Total execution time: 0.6230
INFO - 2020-01-11 10:20:37 --> Config Class Initialized
INFO - 2020-01-11 10:20:37 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:20:37 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:20:37 --> Utf8 Class Initialized
INFO - 2020-01-11 10:20:37 --> URI Class Initialized
DEBUG - 2020-01-11 10:20:37 --> No URI present. Default controller set.
INFO - 2020-01-11 10:20:37 --> Router Class Initialized
INFO - 2020-01-11 10:20:38 --> Output Class Initialized
INFO - 2020-01-11 10:20:38 --> Security Class Initialized
DEBUG - 2020-01-11 10:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:20:38 --> CSRF cookie sent
INFO - 2020-01-11 10:20:38 --> Input Class Initialized
INFO - 2020-01-11 10:20:38 --> Language Class Initialized
INFO - 2020-01-11 10:20:38 --> Language Class Initialized
INFO - 2020-01-11 10:20:38 --> Config Class Initialized
INFO - 2020-01-11 10:20:38 --> Loader Class Initialized
INFO - 2020-01-11 10:20:38 --> Helper loaded: url_helper
INFO - 2020-01-11 10:20:38 --> Helper loaded: common_helper
INFO - 2020-01-11 10:20:38 --> Helper loaded: language_helper
INFO - 2020-01-11 10:20:38 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:20:38 --> Helper loaded: email_helper
INFO - 2020-01-11 10:20:38 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:20:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:20:38 --> Parser Class Initialized
INFO - 2020-01-11 10:20:38 --> User Agent Class Initialized
INFO - 2020-01-11 10:20:38 --> Model Class Initialized
INFO - 2020-01-11 10:20:38 --> Database Driver Class Initialized
INFO - 2020-01-11 10:20:38 --> Model Class Initialized
DEBUG - 2020-01-11 10:20:38 --> Template Class Initialized
INFO - 2020-01-11 10:20:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:20:38 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:20:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:20:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:20:38 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:20:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:20:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:20:38 --> Controller Class Initialized
DEBUG - 2020-01-11 10:20:38 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:20:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:20:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:20:38 --> Model Class Initialized
INFO - 2020-01-11 10:20:38 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:20:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:20:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:20:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:20:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:20:38 --> Final output sent to browser
DEBUG - 2020-01-11 10:20:38 --> Total execution time: 0.9525
INFO - 2020-01-11 10:20:47 --> Config Class Initialized
INFO - 2020-01-11 10:20:47 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:20:47 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:20:47 --> Utf8 Class Initialized
INFO - 2020-01-11 10:20:47 --> URI Class Initialized
DEBUG - 2020-01-11 10:20:47 --> No URI present. Default controller set.
INFO - 2020-01-11 10:20:47 --> Router Class Initialized
INFO - 2020-01-11 10:20:47 --> Output Class Initialized
INFO - 2020-01-11 10:20:47 --> Security Class Initialized
DEBUG - 2020-01-11 10:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:20:47 --> CSRF cookie sent
INFO - 2020-01-11 10:20:47 --> Input Class Initialized
INFO - 2020-01-11 10:20:47 --> Language Class Initialized
INFO - 2020-01-11 10:20:47 --> Language Class Initialized
INFO - 2020-01-11 10:20:47 --> Config Class Initialized
INFO - 2020-01-11 10:20:47 --> Loader Class Initialized
INFO - 2020-01-11 10:20:47 --> Helper loaded: url_helper
INFO - 2020-01-11 10:20:47 --> Helper loaded: common_helper
INFO - 2020-01-11 10:20:47 --> Helper loaded: language_helper
INFO - 2020-01-11 10:20:47 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:20:47 --> Helper loaded: email_helper
INFO - 2020-01-11 10:20:47 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:20:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:20:47 --> Parser Class Initialized
INFO - 2020-01-11 10:20:47 --> User Agent Class Initialized
INFO - 2020-01-11 10:20:47 --> Model Class Initialized
INFO - 2020-01-11 10:20:48 --> Database Driver Class Initialized
INFO - 2020-01-11 10:20:48 --> Model Class Initialized
DEBUG - 2020-01-11 10:20:48 --> Template Class Initialized
INFO - 2020-01-11 10:20:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:20:48 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:20:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:20:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:20:48 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:20:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:20:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:20:48 --> Controller Class Initialized
DEBUG - 2020-01-11 10:20:48 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:20:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:20:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:20:48 --> Model Class Initialized
INFO - 2020-01-11 10:20:48 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:20:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:20:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:20:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:20:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:20:48 --> Final output sent to browser
DEBUG - 2020-01-11 10:20:48 --> Total execution time: 0.7492
INFO - 2020-01-11 10:21:04 --> Config Class Initialized
INFO - 2020-01-11 10:21:04 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:21:04 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:21:04 --> Utf8 Class Initialized
INFO - 2020-01-11 10:21:04 --> URI Class Initialized
DEBUG - 2020-01-11 10:21:04 --> No URI present. Default controller set.
INFO - 2020-01-11 10:21:04 --> Router Class Initialized
INFO - 2020-01-11 10:21:04 --> Output Class Initialized
INFO - 2020-01-11 10:21:04 --> Security Class Initialized
DEBUG - 2020-01-11 10:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:21:04 --> CSRF cookie sent
INFO - 2020-01-11 10:21:04 --> Input Class Initialized
INFO - 2020-01-11 10:21:04 --> Language Class Initialized
INFO - 2020-01-11 10:21:04 --> Language Class Initialized
INFO - 2020-01-11 10:21:04 --> Config Class Initialized
INFO - 2020-01-11 10:21:04 --> Loader Class Initialized
INFO - 2020-01-11 10:21:04 --> Helper loaded: url_helper
INFO - 2020-01-11 10:21:04 --> Helper loaded: common_helper
INFO - 2020-01-11 10:21:04 --> Helper loaded: language_helper
INFO - 2020-01-11 10:21:04 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:21:04 --> Helper loaded: email_helper
INFO - 2020-01-11 10:21:04 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:21:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:21:04 --> Parser Class Initialized
INFO - 2020-01-11 10:21:04 --> User Agent Class Initialized
INFO - 2020-01-11 10:21:05 --> Model Class Initialized
INFO - 2020-01-11 10:21:05 --> Database Driver Class Initialized
INFO - 2020-01-11 10:21:05 --> Model Class Initialized
DEBUG - 2020-01-11 10:21:05 --> Template Class Initialized
INFO - 2020-01-11 10:21:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:21:05 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:21:05 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:21:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:21:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:21:05 --> Controller Class Initialized
DEBUG - 2020-01-11 10:21:05 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:21:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:21:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:21:05 --> Model Class Initialized
INFO - 2020-01-11 10:21:05 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:21:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:21:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:21:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:21:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:21:05 --> Final output sent to browser
DEBUG - 2020-01-11 10:21:05 --> Total execution time: 0.6806
INFO - 2020-01-11 10:22:35 --> Config Class Initialized
INFO - 2020-01-11 10:22:35 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:22:35 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:22:35 --> Utf8 Class Initialized
INFO - 2020-01-11 10:22:35 --> URI Class Initialized
DEBUG - 2020-01-11 10:22:35 --> No URI present. Default controller set.
INFO - 2020-01-11 10:22:35 --> Router Class Initialized
INFO - 2020-01-11 10:22:35 --> Output Class Initialized
INFO - 2020-01-11 10:22:35 --> Security Class Initialized
DEBUG - 2020-01-11 10:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:22:35 --> CSRF cookie sent
INFO - 2020-01-11 10:22:35 --> Input Class Initialized
INFO - 2020-01-11 10:22:35 --> Language Class Initialized
INFO - 2020-01-11 10:22:35 --> Language Class Initialized
INFO - 2020-01-11 10:22:35 --> Config Class Initialized
INFO - 2020-01-11 10:22:35 --> Loader Class Initialized
INFO - 2020-01-11 10:22:35 --> Helper loaded: url_helper
INFO - 2020-01-11 10:22:35 --> Helper loaded: common_helper
INFO - 2020-01-11 10:22:35 --> Helper loaded: language_helper
INFO - 2020-01-11 10:22:35 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:22:35 --> Helper loaded: email_helper
INFO - 2020-01-11 10:22:35 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:22:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:22:35 --> Parser Class Initialized
INFO - 2020-01-11 10:22:35 --> User Agent Class Initialized
INFO - 2020-01-11 10:22:35 --> Model Class Initialized
INFO - 2020-01-11 10:22:35 --> Database Driver Class Initialized
INFO - 2020-01-11 10:22:35 --> Model Class Initialized
DEBUG - 2020-01-11 10:22:35 --> Template Class Initialized
INFO - 2020-01-11 10:22:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:22:35 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:22:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:22:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:22:35 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:22:35 --> Controller Class Initialized
DEBUG - 2020-01-11 10:22:35 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:22:35 --> Model Class Initialized
INFO - 2020-01-11 10:22:35 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:22:35 --> Final output sent to browser
DEBUG - 2020-01-11 10:22:35 --> Total execution time: 0.6760
INFO - 2020-01-11 10:22:50 --> Config Class Initialized
INFO - 2020-01-11 10:22:50 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:22:50 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:22:50 --> Utf8 Class Initialized
INFO - 2020-01-11 10:22:50 --> URI Class Initialized
DEBUG - 2020-01-11 10:22:50 --> No URI present. Default controller set.
INFO - 2020-01-11 10:22:50 --> Router Class Initialized
INFO - 2020-01-11 10:22:50 --> Output Class Initialized
INFO - 2020-01-11 10:22:50 --> Security Class Initialized
DEBUG - 2020-01-11 10:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:22:50 --> CSRF cookie sent
INFO - 2020-01-11 10:22:50 --> Input Class Initialized
INFO - 2020-01-11 10:22:50 --> Language Class Initialized
INFO - 2020-01-11 10:22:50 --> Language Class Initialized
INFO - 2020-01-11 10:22:50 --> Config Class Initialized
INFO - 2020-01-11 10:22:50 --> Loader Class Initialized
INFO - 2020-01-11 10:22:50 --> Helper loaded: url_helper
INFO - 2020-01-11 10:22:50 --> Helper loaded: common_helper
INFO - 2020-01-11 10:22:50 --> Helper loaded: language_helper
INFO - 2020-01-11 10:22:50 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:22:50 --> Helper loaded: email_helper
INFO - 2020-01-11 10:22:50 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:22:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:22:50 --> Parser Class Initialized
INFO - 2020-01-11 10:22:50 --> User Agent Class Initialized
INFO - 2020-01-11 10:22:50 --> Model Class Initialized
INFO - 2020-01-11 10:22:50 --> Database Driver Class Initialized
INFO - 2020-01-11 10:22:50 --> Model Class Initialized
DEBUG - 2020-01-11 10:22:50 --> Template Class Initialized
INFO - 2020-01-11 10:22:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:22:50 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:22:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:22:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:22:50 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:22:50 --> Controller Class Initialized
DEBUG - 2020-01-11 10:22:50 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:22:50 --> Model Class Initialized
INFO - 2020-01-11 10:22:50 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:22:50 --> Final output sent to browser
DEBUG - 2020-01-11 10:22:50 --> Total execution time: 0.7026
INFO - 2020-01-11 10:22:59 --> Config Class Initialized
INFO - 2020-01-11 10:22:59 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:22:59 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:22:59 --> Utf8 Class Initialized
INFO - 2020-01-11 10:22:59 --> URI Class Initialized
DEBUG - 2020-01-11 10:22:59 --> No URI present. Default controller set.
INFO - 2020-01-11 10:22:59 --> Router Class Initialized
INFO - 2020-01-11 10:22:59 --> Output Class Initialized
INFO - 2020-01-11 10:22:59 --> Security Class Initialized
DEBUG - 2020-01-11 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:22:59 --> CSRF cookie sent
INFO - 2020-01-11 10:22:59 --> Input Class Initialized
INFO - 2020-01-11 10:22:59 --> Language Class Initialized
INFO - 2020-01-11 10:22:59 --> Language Class Initialized
INFO - 2020-01-11 10:22:59 --> Config Class Initialized
INFO - 2020-01-11 10:22:59 --> Loader Class Initialized
INFO - 2020-01-11 10:22:59 --> Helper loaded: url_helper
INFO - 2020-01-11 10:22:59 --> Helper loaded: common_helper
INFO - 2020-01-11 10:22:59 --> Helper loaded: language_helper
INFO - 2020-01-11 10:22:59 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:22:59 --> Helper loaded: email_helper
INFO - 2020-01-11 10:22:59 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:22:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:22:59 --> Parser Class Initialized
INFO - 2020-01-11 10:22:59 --> User Agent Class Initialized
INFO - 2020-01-11 10:22:59 --> Model Class Initialized
INFO - 2020-01-11 10:22:59 --> Database Driver Class Initialized
INFO - 2020-01-11 10:22:59 --> Model Class Initialized
DEBUG - 2020-01-11 10:22:59 --> Template Class Initialized
INFO - 2020-01-11 10:22:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:22:59 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:22:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:22:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:22:59 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:22:59 --> Controller Class Initialized
DEBUG - 2020-01-11 10:22:59 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:22:59 --> Model Class Initialized
INFO - 2020-01-11 10:22:59 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:22:59 --> Final output sent to browser
DEBUG - 2020-01-11 10:22:59 --> Total execution time: 0.7235
INFO - 2020-01-11 10:23:22 --> Config Class Initialized
INFO - 2020-01-11 10:23:22 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:23:22 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:23:22 --> Utf8 Class Initialized
INFO - 2020-01-11 10:23:22 --> URI Class Initialized
DEBUG - 2020-01-11 10:23:22 --> No URI present. Default controller set.
INFO - 2020-01-11 10:23:22 --> Router Class Initialized
INFO - 2020-01-11 10:23:22 --> Output Class Initialized
INFO - 2020-01-11 10:23:22 --> Security Class Initialized
DEBUG - 2020-01-11 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:23:22 --> CSRF cookie sent
INFO - 2020-01-11 10:23:22 --> Input Class Initialized
INFO - 2020-01-11 10:23:22 --> Language Class Initialized
INFO - 2020-01-11 10:23:22 --> Language Class Initialized
INFO - 2020-01-11 10:23:22 --> Config Class Initialized
INFO - 2020-01-11 10:23:22 --> Loader Class Initialized
INFO - 2020-01-11 10:23:22 --> Helper loaded: url_helper
INFO - 2020-01-11 10:23:22 --> Helper loaded: common_helper
INFO - 2020-01-11 10:23:22 --> Helper loaded: language_helper
INFO - 2020-01-11 10:23:22 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:23:22 --> Helper loaded: email_helper
INFO - 2020-01-11 10:23:22 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:23:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:23:22 --> Parser Class Initialized
INFO - 2020-01-11 10:23:22 --> User Agent Class Initialized
INFO - 2020-01-11 10:23:22 --> Model Class Initialized
INFO - 2020-01-11 10:23:22 --> Database Driver Class Initialized
INFO - 2020-01-11 10:23:22 --> Model Class Initialized
DEBUG - 2020-01-11 10:23:22 --> Template Class Initialized
INFO - 2020-01-11 10:23:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:23:22 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:23:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:23:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:23:23 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:23:23 --> Controller Class Initialized
DEBUG - 2020-01-11 10:23:23 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:23:23 --> Model Class Initialized
INFO - 2020-01-11 10:23:23 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:23:23 --> Final output sent to browser
DEBUG - 2020-01-11 10:23:23 --> Total execution time: 0.7093
INFO - 2020-01-11 10:23:43 --> Config Class Initialized
INFO - 2020-01-11 10:23:43 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:23:43 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:23:43 --> Utf8 Class Initialized
INFO - 2020-01-11 10:23:43 --> URI Class Initialized
DEBUG - 2020-01-11 10:23:43 --> No URI present. Default controller set.
INFO - 2020-01-11 10:23:43 --> Router Class Initialized
INFO - 2020-01-11 10:23:43 --> Output Class Initialized
INFO - 2020-01-11 10:23:43 --> Security Class Initialized
DEBUG - 2020-01-11 10:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:23:43 --> CSRF cookie sent
INFO - 2020-01-11 10:23:43 --> Input Class Initialized
INFO - 2020-01-11 10:23:43 --> Language Class Initialized
INFO - 2020-01-11 10:23:43 --> Language Class Initialized
INFO - 2020-01-11 10:23:43 --> Config Class Initialized
INFO - 2020-01-11 10:23:43 --> Loader Class Initialized
INFO - 2020-01-11 10:23:43 --> Helper loaded: url_helper
INFO - 2020-01-11 10:23:43 --> Helper loaded: common_helper
INFO - 2020-01-11 10:23:43 --> Helper loaded: language_helper
INFO - 2020-01-11 10:23:43 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:23:43 --> Helper loaded: email_helper
INFO - 2020-01-11 10:23:43 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:23:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:23:44 --> Parser Class Initialized
INFO - 2020-01-11 10:23:44 --> User Agent Class Initialized
INFO - 2020-01-11 10:23:44 --> Model Class Initialized
INFO - 2020-01-11 10:23:44 --> Database Driver Class Initialized
INFO - 2020-01-11 10:23:44 --> Model Class Initialized
DEBUG - 2020-01-11 10:23:44 --> Template Class Initialized
INFO - 2020-01-11 10:23:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:23:44 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:23:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:23:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:23:44 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:23:44 --> Controller Class Initialized
DEBUG - 2020-01-11 10:23:44 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:23:44 --> Model Class Initialized
INFO - 2020-01-11 10:23:44 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:23:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:23:44 --> Final output sent to browser
DEBUG - 2020-01-11 10:23:44 --> Total execution time: 0.7421
INFO - 2020-01-11 10:25:03 --> Config Class Initialized
INFO - 2020-01-11 10:25:03 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:25:03 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:25:03 --> Utf8 Class Initialized
INFO - 2020-01-11 10:25:03 --> URI Class Initialized
DEBUG - 2020-01-11 10:25:03 --> No URI present. Default controller set.
INFO - 2020-01-11 10:25:03 --> Router Class Initialized
INFO - 2020-01-11 10:25:03 --> Output Class Initialized
INFO - 2020-01-11 10:25:03 --> Security Class Initialized
DEBUG - 2020-01-11 10:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:25:03 --> CSRF cookie sent
INFO - 2020-01-11 10:25:03 --> Input Class Initialized
INFO - 2020-01-11 10:25:03 --> Language Class Initialized
INFO - 2020-01-11 10:25:03 --> Language Class Initialized
INFO - 2020-01-11 10:25:03 --> Config Class Initialized
INFO - 2020-01-11 10:25:03 --> Loader Class Initialized
INFO - 2020-01-11 10:25:03 --> Helper loaded: url_helper
INFO - 2020-01-11 10:25:03 --> Helper loaded: common_helper
INFO - 2020-01-11 10:25:03 --> Helper loaded: language_helper
INFO - 2020-01-11 10:25:03 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:25:03 --> Helper loaded: email_helper
INFO - 2020-01-11 10:25:03 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:25:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:25:03 --> Parser Class Initialized
INFO - 2020-01-11 10:25:03 --> User Agent Class Initialized
INFO - 2020-01-11 10:25:03 --> Model Class Initialized
INFO - 2020-01-11 10:25:03 --> Database Driver Class Initialized
INFO - 2020-01-11 10:25:03 --> Model Class Initialized
DEBUG - 2020-01-11 10:25:03 --> Template Class Initialized
INFO - 2020-01-11 10:25:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:25:03 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:25:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:25:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:25:03 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:25:03 --> Controller Class Initialized
DEBUG - 2020-01-11 10:25:03 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:25:03 --> Model Class Initialized
INFO - 2020-01-11 10:25:03 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:25:03 --> Final output sent to browser
DEBUG - 2020-01-11 10:25:03 --> Total execution time: 0.7454
INFO - 2020-01-11 10:26:09 --> Config Class Initialized
INFO - 2020-01-11 10:26:09 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:26:09 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:26:09 --> Utf8 Class Initialized
INFO - 2020-01-11 10:26:09 --> URI Class Initialized
DEBUG - 2020-01-11 10:26:09 --> No URI present. Default controller set.
INFO - 2020-01-11 10:26:09 --> Router Class Initialized
INFO - 2020-01-11 10:26:09 --> Output Class Initialized
INFO - 2020-01-11 10:26:10 --> Security Class Initialized
DEBUG - 2020-01-11 10:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:26:10 --> CSRF cookie sent
INFO - 2020-01-11 10:26:10 --> Input Class Initialized
INFO - 2020-01-11 10:26:10 --> Language Class Initialized
INFO - 2020-01-11 10:26:10 --> Language Class Initialized
INFO - 2020-01-11 10:26:10 --> Config Class Initialized
INFO - 2020-01-11 10:26:10 --> Loader Class Initialized
INFO - 2020-01-11 10:26:10 --> Helper loaded: url_helper
INFO - 2020-01-11 10:26:10 --> Helper loaded: common_helper
INFO - 2020-01-11 10:26:10 --> Helper loaded: language_helper
INFO - 2020-01-11 10:26:10 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:26:10 --> Helper loaded: email_helper
INFO - 2020-01-11 10:26:10 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:26:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:26:10 --> Parser Class Initialized
INFO - 2020-01-11 10:26:10 --> User Agent Class Initialized
INFO - 2020-01-11 10:26:10 --> Model Class Initialized
INFO - 2020-01-11 10:26:10 --> Database Driver Class Initialized
INFO - 2020-01-11 10:26:10 --> Model Class Initialized
DEBUG - 2020-01-11 10:26:10 --> Template Class Initialized
INFO - 2020-01-11 10:26:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:26:10 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:26:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:26:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:26:10 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:26:10 --> Controller Class Initialized
DEBUG - 2020-01-11 10:26:10 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:26:10 --> Model Class Initialized
INFO - 2020-01-11 10:26:10 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:26:10 --> Final output sent to browser
DEBUG - 2020-01-11 10:26:10 --> Total execution time: 0.7726
INFO - 2020-01-11 10:26:54 --> Config Class Initialized
INFO - 2020-01-11 10:26:54 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:26:54 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:26:54 --> Utf8 Class Initialized
INFO - 2020-01-11 10:26:54 --> URI Class Initialized
DEBUG - 2020-01-11 10:26:54 --> No URI present. Default controller set.
INFO - 2020-01-11 10:26:54 --> Router Class Initialized
INFO - 2020-01-11 10:26:54 --> Output Class Initialized
INFO - 2020-01-11 10:26:54 --> Security Class Initialized
DEBUG - 2020-01-11 10:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:26:54 --> CSRF cookie sent
INFO - 2020-01-11 10:26:54 --> Input Class Initialized
INFO - 2020-01-11 10:26:54 --> Language Class Initialized
INFO - 2020-01-11 10:26:54 --> Language Class Initialized
INFO - 2020-01-11 10:26:54 --> Config Class Initialized
INFO - 2020-01-11 10:26:54 --> Loader Class Initialized
INFO - 2020-01-11 10:26:54 --> Helper loaded: url_helper
INFO - 2020-01-11 10:26:54 --> Helper loaded: common_helper
INFO - 2020-01-11 10:26:54 --> Helper loaded: language_helper
INFO - 2020-01-11 10:26:54 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:26:54 --> Helper loaded: email_helper
INFO - 2020-01-11 10:26:54 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:26:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:26:54 --> Parser Class Initialized
INFO - 2020-01-11 10:26:54 --> User Agent Class Initialized
INFO - 2020-01-11 10:26:54 --> Model Class Initialized
INFO - 2020-01-11 10:26:54 --> Database Driver Class Initialized
INFO - 2020-01-11 10:26:54 --> Model Class Initialized
DEBUG - 2020-01-11 10:26:54 --> Template Class Initialized
INFO - 2020-01-11 10:26:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:26:54 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:26:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:26:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:26:54 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:26:54 --> Controller Class Initialized
DEBUG - 2020-01-11 10:26:54 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:26:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:26:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:26:55 --> Model Class Initialized
INFO - 2020-01-11 10:26:55 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:26:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:26:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:26:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:26:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:26:55 --> Final output sent to browser
DEBUG - 2020-01-11 10:26:55 --> Total execution time: 0.8404
INFO - 2020-01-11 10:27:02 --> Config Class Initialized
INFO - 2020-01-11 10:27:02 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:27:02 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:27:02 --> Utf8 Class Initialized
INFO - 2020-01-11 10:27:02 --> URI Class Initialized
DEBUG - 2020-01-11 10:27:02 --> No URI present. Default controller set.
INFO - 2020-01-11 10:27:02 --> Router Class Initialized
INFO - 2020-01-11 10:27:02 --> Output Class Initialized
INFO - 2020-01-11 10:27:02 --> Security Class Initialized
DEBUG - 2020-01-11 10:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:27:02 --> CSRF cookie sent
INFO - 2020-01-11 10:27:02 --> Input Class Initialized
INFO - 2020-01-11 10:27:02 --> Language Class Initialized
INFO - 2020-01-11 10:27:02 --> Language Class Initialized
INFO - 2020-01-11 10:27:02 --> Config Class Initialized
INFO - 2020-01-11 10:27:02 --> Loader Class Initialized
INFO - 2020-01-11 10:27:02 --> Helper loaded: url_helper
INFO - 2020-01-11 10:27:02 --> Helper loaded: common_helper
INFO - 2020-01-11 10:27:02 --> Helper loaded: language_helper
INFO - 2020-01-11 10:27:02 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:27:02 --> Helper loaded: email_helper
INFO - 2020-01-11 10:27:02 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:27:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:27:02 --> Parser Class Initialized
INFO - 2020-01-11 10:27:02 --> User Agent Class Initialized
INFO - 2020-01-11 10:27:02 --> Model Class Initialized
INFO - 2020-01-11 10:27:02 --> Database Driver Class Initialized
INFO - 2020-01-11 10:27:02 --> Model Class Initialized
DEBUG - 2020-01-11 10:27:02 --> Template Class Initialized
INFO - 2020-01-11 10:27:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:27:02 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:27:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:27:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:27:02 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:27:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:27:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:27:02 --> Controller Class Initialized
DEBUG - 2020-01-11 10:27:02 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:27:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:27:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:27:02 --> Model Class Initialized
INFO - 2020-01-11 10:27:02 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:27:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:27:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:27:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:27:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:27:02 --> Final output sent to browser
DEBUG - 2020-01-11 10:27:02 --> Total execution time: 0.7874
INFO - 2020-01-11 10:27:44 --> Config Class Initialized
INFO - 2020-01-11 10:27:44 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:27:44 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:27:44 --> Utf8 Class Initialized
INFO - 2020-01-11 10:27:44 --> URI Class Initialized
DEBUG - 2020-01-11 10:27:44 --> No URI present. Default controller set.
INFO - 2020-01-11 10:27:44 --> Router Class Initialized
INFO - 2020-01-11 10:27:44 --> Output Class Initialized
INFO - 2020-01-11 10:27:44 --> Security Class Initialized
DEBUG - 2020-01-11 10:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:27:44 --> CSRF cookie sent
INFO - 2020-01-11 10:27:44 --> Input Class Initialized
INFO - 2020-01-11 10:27:44 --> Language Class Initialized
INFO - 2020-01-11 10:27:44 --> Language Class Initialized
INFO - 2020-01-11 10:27:44 --> Config Class Initialized
INFO - 2020-01-11 10:27:45 --> Loader Class Initialized
INFO - 2020-01-11 10:27:45 --> Helper loaded: url_helper
INFO - 2020-01-11 10:27:45 --> Helper loaded: common_helper
INFO - 2020-01-11 10:27:45 --> Helper loaded: language_helper
INFO - 2020-01-11 10:27:45 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:27:45 --> Helper loaded: email_helper
INFO - 2020-01-11 10:27:45 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:27:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:27:45 --> Parser Class Initialized
INFO - 2020-01-11 10:27:45 --> User Agent Class Initialized
INFO - 2020-01-11 10:27:45 --> Model Class Initialized
INFO - 2020-01-11 10:27:45 --> Database Driver Class Initialized
INFO - 2020-01-11 10:27:45 --> Model Class Initialized
DEBUG - 2020-01-11 10:27:45 --> Template Class Initialized
INFO - 2020-01-11 10:27:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:27:45 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:27:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:27:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:27:45 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:27:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:27:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:27:45 --> Controller Class Initialized
DEBUG - 2020-01-11 10:27:45 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:27:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:27:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:27:45 --> Model Class Initialized
INFO - 2020-01-11 10:27:45 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:27:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:27:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:27:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:27:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:27:45 --> Final output sent to browser
DEBUG - 2020-01-11 10:27:45 --> Total execution time: 0.7164
INFO - 2020-01-11 10:33:24 --> Config Class Initialized
INFO - 2020-01-11 10:33:24 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:33:24 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:33:24 --> Utf8 Class Initialized
INFO - 2020-01-11 10:33:24 --> URI Class Initialized
DEBUG - 2020-01-11 10:33:24 --> No URI present. Default controller set.
INFO - 2020-01-11 10:33:24 --> Router Class Initialized
INFO - 2020-01-11 10:33:24 --> Output Class Initialized
INFO - 2020-01-11 10:33:24 --> Security Class Initialized
DEBUG - 2020-01-11 10:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:33:24 --> CSRF cookie sent
INFO - 2020-01-11 10:33:24 --> Input Class Initialized
INFO - 2020-01-11 10:33:24 --> Language Class Initialized
INFO - 2020-01-11 10:33:24 --> Language Class Initialized
INFO - 2020-01-11 10:33:24 --> Config Class Initialized
INFO - 2020-01-11 10:33:24 --> Loader Class Initialized
INFO - 2020-01-11 10:33:24 --> Helper loaded: url_helper
INFO - 2020-01-11 10:33:24 --> Helper loaded: common_helper
INFO - 2020-01-11 10:33:24 --> Helper loaded: language_helper
INFO - 2020-01-11 10:33:24 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:33:24 --> Helper loaded: email_helper
INFO - 2020-01-11 10:33:24 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:33:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:33:24 --> Parser Class Initialized
INFO - 2020-01-11 10:33:24 --> User Agent Class Initialized
INFO - 2020-01-11 10:33:24 --> Model Class Initialized
INFO - 2020-01-11 10:33:24 --> Database Driver Class Initialized
INFO - 2020-01-11 10:33:24 --> Model Class Initialized
DEBUG - 2020-01-11 10:33:24 --> Template Class Initialized
INFO - 2020-01-11 10:33:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:33:24 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:33:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:33:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:33:24 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:33:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:33:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:33:24 --> Controller Class Initialized
DEBUG - 2020-01-11 10:33:24 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:33:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:33:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:33:24 --> Model Class Initialized
INFO - 2020-01-11 10:33:25 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:33:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:33:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:33:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:33:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:33:25 --> Final output sent to browser
DEBUG - 2020-01-11 10:33:25 --> Total execution time: 0.6933
INFO - 2020-01-11 10:34:51 --> Config Class Initialized
INFO - 2020-01-11 10:34:51 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:34:51 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:34:51 --> Utf8 Class Initialized
INFO - 2020-01-11 10:34:51 --> URI Class Initialized
DEBUG - 2020-01-11 10:34:51 --> No URI present. Default controller set.
INFO - 2020-01-11 10:34:51 --> Router Class Initialized
INFO - 2020-01-11 10:34:51 --> Output Class Initialized
INFO - 2020-01-11 10:34:51 --> Security Class Initialized
DEBUG - 2020-01-11 10:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:34:51 --> CSRF cookie sent
INFO - 2020-01-11 10:34:51 --> Input Class Initialized
INFO - 2020-01-11 10:34:51 --> Language Class Initialized
INFO - 2020-01-11 10:34:51 --> Language Class Initialized
INFO - 2020-01-11 10:34:51 --> Config Class Initialized
INFO - 2020-01-11 10:34:51 --> Loader Class Initialized
INFO - 2020-01-11 10:34:51 --> Helper loaded: url_helper
INFO - 2020-01-11 10:34:51 --> Helper loaded: common_helper
INFO - 2020-01-11 10:34:51 --> Helper loaded: language_helper
INFO - 2020-01-11 10:34:51 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:34:51 --> Helper loaded: email_helper
INFO - 2020-01-11 10:34:51 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:34:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:34:51 --> Parser Class Initialized
INFO - 2020-01-11 10:34:51 --> User Agent Class Initialized
INFO - 2020-01-11 10:34:51 --> Model Class Initialized
INFO - 2020-01-11 10:34:51 --> Database Driver Class Initialized
INFO - 2020-01-11 10:34:51 --> Model Class Initialized
DEBUG - 2020-01-11 10:34:51 --> Template Class Initialized
INFO - 2020-01-11 10:34:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:34:51 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:34:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:34:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:34:51 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:34:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:34:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:34:51 --> Controller Class Initialized
DEBUG - 2020-01-11 10:34:51 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:34:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:34:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:34:51 --> Model Class Initialized
INFO - 2020-01-11 10:34:51 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:34:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:34:52 --> Final output sent to browser
DEBUG - 2020-01-11 10:34:52 --> Total execution time: 0.7287
INFO - 2020-01-11 10:35:42 --> Config Class Initialized
INFO - 2020-01-11 10:35:42 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:35:42 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:35:42 --> Utf8 Class Initialized
INFO - 2020-01-11 10:35:42 --> URI Class Initialized
DEBUG - 2020-01-11 10:35:42 --> No URI present. Default controller set.
INFO - 2020-01-11 10:35:42 --> Router Class Initialized
INFO - 2020-01-11 10:35:42 --> Output Class Initialized
INFO - 2020-01-11 10:35:42 --> Security Class Initialized
DEBUG - 2020-01-11 10:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:35:42 --> CSRF cookie sent
INFO - 2020-01-11 10:35:42 --> Input Class Initialized
INFO - 2020-01-11 10:35:42 --> Language Class Initialized
INFO - 2020-01-11 10:35:42 --> Language Class Initialized
INFO - 2020-01-11 10:35:42 --> Config Class Initialized
INFO - 2020-01-11 10:35:42 --> Loader Class Initialized
INFO - 2020-01-11 10:35:42 --> Helper loaded: url_helper
INFO - 2020-01-11 10:35:42 --> Helper loaded: common_helper
INFO - 2020-01-11 10:35:42 --> Helper loaded: language_helper
INFO - 2020-01-11 10:35:42 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:35:43 --> Helper loaded: email_helper
INFO - 2020-01-11 10:35:43 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:35:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:35:43 --> Parser Class Initialized
INFO - 2020-01-11 10:35:43 --> User Agent Class Initialized
INFO - 2020-01-11 10:35:43 --> Model Class Initialized
INFO - 2020-01-11 10:35:43 --> Database Driver Class Initialized
INFO - 2020-01-11 10:35:43 --> Model Class Initialized
DEBUG - 2020-01-11 10:35:43 --> Template Class Initialized
INFO - 2020-01-11 10:35:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:35:43 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:35:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:35:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:35:43 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:35:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:35:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:35:43 --> Controller Class Initialized
DEBUG - 2020-01-11 10:35:43 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:35:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:35:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:35:43 --> Model Class Initialized
INFO - 2020-01-11 10:35:43 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:35:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:35:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:35:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:35:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:35:43 --> Final output sent to browser
DEBUG - 2020-01-11 10:35:43 --> Total execution time: 0.7231
INFO - 2020-01-11 10:37:41 --> Config Class Initialized
INFO - 2020-01-11 10:37:41 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:37:41 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:37:41 --> Utf8 Class Initialized
INFO - 2020-01-11 10:37:41 --> URI Class Initialized
DEBUG - 2020-01-11 10:37:41 --> No URI present. Default controller set.
INFO - 2020-01-11 10:37:41 --> Router Class Initialized
INFO - 2020-01-11 10:37:41 --> Output Class Initialized
INFO - 2020-01-11 10:37:41 --> Security Class Initialized
DEBUG - 2020-01-11 10:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:37:41 --> CSRF cookie sent
INFO - 2020-01-11 10:37:41 --> Input Class Initialized
INFO - 2020-01-11 10:37:41 --> Language Class Initialized
INFO - 2020-01-11 10:37:41 --> Language Class Initialized
INFO - 2020-01-11 10:37:41 --> Config Class Initialized
INFO - 2020-01-11 10:37:41 --> Loader Class Initialized
INFO - 2020-01-11 10:37:41 --> Helper loaded: url_helper
INFO - 2020-01-11 10:37:41 --> Helper loaded: common_helper
INFO - 2020-01-11 10:37:41 --> Helper loaded: language_helper
INFO - 2020-01-11 10:37:41 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:37:41 --> Helper loaded: email_helper
INFO - 2020-01-11 10:37:41 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:37:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:37:41 --> Parser Class Initialized
INFO - 2020-01-11 10:37:41 --> User Agent Class Initialized
INFO - 2020-01-11 10:37:41 --> Model Class Initialized
INFO - 2020-01-11 10:37:42 --> Database Driver Class Initialized
INFO - 2020-01-11 10:37:42 --> Model Class Initialized
DEBUG - 2020-01-11 10:37:42 --> Template Class Initialized
INFO - 2020-01-11 10:37:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:37:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:37:42 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:37:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:37:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:37:42 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:37:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:37:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:37:42 --> Controller Class Initialized
DEBUG - 2020-01-11 10:37:42 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:37:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:37:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:37:42 --> Model Class Initialized
INFO - 2020-01-11 10:37:42 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:37:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:37:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:37:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:37:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:37:42 --> Final output sent to browser
DEBUG - 2020-01-11 10:37:42 --> Total execution time: 0.8709
INFO - 2020-01-11 10:38:57 --> Config Class Initialized
INFO - 2020-01-11 10:38:57 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:38:57 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:38:57 --> Utf8 Class Initialized
INFO - 2020-01-11 10:38:57 --> URI Class Initialized
DEBUG - 2020-01-11 10:38:57 --> No URI present. Default controller set.
INFO - 2020-01-11 10:38:57 --> Router Class Initialized
INFO - 2020-01-11 10:38:57 --> Output Class Initialized
INFO - 2020-01-11 10:38:57 --> Security Class Initialized
DEBUG - 2020-01-11 10:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:38:57 --> CSRF cookie sent
INFO - 2020-01-11 10:38:57 --> Input Class Initialized
INFO - 2020-01-11 10:38:57 --> Language Class Initialized
INFO - 2020-01-11 10:38:57 --> Language Class Initialized
INFO - 2020-01-11 10:38:57 --> Config Class Initialized
INFO - 2020-01-11 10:38:57 --> Loader Class Initialized
INFO - 2020-01-11 10:38:57 --> Helper loaded: url_helper
INFO - 2020-01-11 10:38:57 --> Helper loaded: common_helper
INFO - 2020-01-11 10:38:57 --> Helper loaded: language_helper
INFO - 2020-01-11 10:38:57 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:38:57 --> Helper loaded: email_helper
INFO - 2020-01-11 10:38:57 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:38:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:38:57 --> Parser Class Initialized
INFO - 2020-01-11 10:38:57 --> User Agent Class Initialized
INFO - 2020-01-11 10:38:57 --> Model Class Initialized
INFO - 2020-01-11 10:38:57 --> Database Driver Class Initialized
INFO - 2020-01-11 10:38:57 --> Model Class Initialized
DEBUG - 2020-01-11 10:38:57 --> Template Class Initialized
INFO - 2020-01-11 10:38:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:38:57 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:38:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:38:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:38:57 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:38:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:38:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:38:57 --> Controller Class Initialized
DEBUG - 2020-01-11 10:38:57 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:38:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:38:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:38:58 --> Model Class Initialized
INFO - 2020-01-11 10:38:58 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:38:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:38:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:38:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:38:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:38:58 --> Final output sent to browser
DEBUG - 2020-01-11 10:38:58 --> Total execution time: 0.8718
INFO - 2020-01-11 10:39:38 --> Config Class Initialized
INFO - 2020-01-11 10:39:38 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:39:38 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:39:38 --> Utf8 Class Initialized
INFO - 2020-01-11 10:39:38 --> URI Class Initialized
DEBUG - 2020-01-11 10:39:38 --> No URI present. Default controller set.
INFO - 2020-01-11 10:39:38 --> Router Class Initialized
INFO - 2020-01-11 10:39:38 --> Output Class Initialized
INFO - 2020-01-11 10:39:38 --> Security Class Initialized
DEBUG - 2020-01-11 10:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:39:38 --> CSRF cookie sent
INFO - 2020-01-11 10:39:38 --> Input Class Initialized
INFO - 2020-01-11 10:39:38 --> Language Class Initialized
INFO - 2020-01-11 10:39:38 --> Language Class Initialized
INFO - 2020-01-11 10:39:38 --> Config Class Initialized
INFO - 2020-01-11 10:39:38 --> Loader Class Initialized
INFO - 2020-01-11 10:39:38 --> Helper loaded: url_helper
INFO - 2020-01-11 10:39:38 --> Helper loaded: common_helper
INFO - 2020-01-11 10:39:38 --> Helper loaded: language_helper
INFO - 2020-01-11 10:39:38 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:39:38 --> Helper loaded: email_helper
INFO - 2020-01-11 10:39:38 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:39:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:39:38 --> Parser Class Initialized
INFO - 2020-01-11 10:39:38 --> User Agent Class Initialized
INFO - 2020-01-11 10:39:38 --> Model Class Initialized
INFO - 2020-01-11 10:39:38 --> Database Driver Class Initialized
INFO - 2020-01-11 10:39:38 --> Model Class Initialized
DEBUG - 2020-01-11 10:39:38 --> Template Class Initialized
INFO - 2020-01-11 10:39:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:39:38 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:39:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:39:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:39:38 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:39:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:39:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:39:38 --> Controller Class Initialized
DEBUG - 2020-01-11 10:39:38 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:39:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:39:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:39:38 --> Model Class Initialized
INFO - 2020-01-11 10:39:39 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:39:39 --> Final output sent to browser
DEBUG - 2020-01-11 10:39:39 --> Total execution time: 0.7512
INFO - 2020-01-11 10:41:27 --> Config Class Initialized
INFO - 2020-01-11 10:41:27 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:41:27 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:41:27 --> Utf8 Class Initialized
INFO - 2020-01-11 10:41:27 --> URI Class Initialized
DEBUG - 2020-01-11 10:41:27 --> No URI present. Default controller set.
INFO - 2020-01-11 10:41:27 --> Router Class Initialized
INFO - 2020-01-11 10:41:27 --> Output Class Initialized
INFO - 2020-01-11 10:41:27 --> Security Class Initialized
DEBUG - 2020-01-11 10:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:41:27 --> CSRF cookie sent
INFO - 2020-01-11 10:41:27 --> Input Class Initialized
INFO - 2020-01-11 10:41:27 --> Language Class Initialized
INFO - 2020-01-11 10:41:27 --> Language Class Initialized
INFO - 2020-01-11 10:41:27 --> Config Class Initialized
INFO - 2020-01-11 10:41:27 --> Loader Class Initialized
INFO - 2020-01-11 10:41:27 --> Helper loaded: url_helper
INFO - 2020-01-11 10:41:27 --> Helper loaded: common_helper
INFO - 2020-01-11 10:41:27 --> Helper loaded: language_helper
INFO - 2020-01-11 10:41:27 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:41:27 --> Helper loaded: email_helper
INFO - 2020-01-11 10:41:27 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:41:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:41:27 --> Parser Class Initialized
INFO - 2020-01-11 10:41:27 --> User Agent Class Initialized
INFO - 2020-01-11 10:41:27 --> Model Class Initialized
INFO - 2020-01-11 10:41:27 --> Database Driver Class Initialized
INFO - 2020-01-11 10:41:27 --> Model Class Initialized
DEBUG - 2020-01-11 10:41:27 --> Template Class Initialized
INFO - 2020-01-11 10:41:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:41:27 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:41:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:41:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:41:27 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:41:27 --> Controller Class Initialized
DEBUG - 2020-01-11 10:41:27 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:41:27 --> Model Class Initialized
INFO - 2020-01-11 10:41:27 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:41:27 --> Final output sent to browser
DEBUG - 2020-01-11 10:41:27 --> Total execution time: 0.7748
INFO - 2020-01-11 10:43:17 --> Config Class Initialized
INFO - 2020-01-11 10:43:17 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:43:17 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:43:17 --> Utf8 Class Initialized
INFO - 2020-01-11 10:43:17 --> URI Class Initialized
DEBUG - 2020-01-11 10:43:17 --> No URI present. Default controller set.
INFO - 2020-01-11 10:43:17 --> Router Class Initialized
INFO - 2020-01-11 10:43:17 --> Output Class Initialized
INFO - 2020-01-11 10:43:17 --> Security Class Initialized
DEBUG - 2020-01-11 10:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:43:17 --> CSRF cookie sent
INFO - 2020-01-11 10:43:17 --> Input Class Initialized
INFO - 2020-01-11 10:43:18 --> Language Class Initialized
INFO - 2020-01-11 10:43:18 --> Language Class Initialized
INFO - 2020-01-11 10:43:18 --> Config Class Initialized
INFO - 2020-01-11 10:43:18 --> Loader Class Initialized
INFO - 2020-01-11 10:43:18 --> Helper loaded: url_helper
INFO - 2020-01-11 10:43:18 --> Helper loaded: common_helper
INFO - 2020-01-11 10:43:18 --> Helper loaded: language_helper
INFO - 2020-01-11 10:43:18 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:43:18 --> Helper loaded: email_helper
INFO - 2020-01-11 10:43:18 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:43:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:43:18 --> Parser Class Initialized
INFO - 2020-01-11 10:43:18 --> User Agent Class Initialized
INFO - 2020-01-11 10:43:18 --> Model Class Initialized
INFO - 2020-01-11 10:43:18 --> Database Driver Class Initialized
INFO - 2020-01-11 10:43:18 --> Model Class Initialized
DEBUG - 2020-01-11 10:43:18 --> Template Class Initialized
INFO - 2020-01-11 10:43:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:43:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:43:18 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:43:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:43:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:43:18 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:43:18 --> Controller Class Initialized
DEBUG - 2020-01-11 10:43:18 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:43:18 --> Model Class Initialized
INFO - 2020-01-11 10:43:18 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:43:18 --> Final output sent to browser
DEBUG - 2020-01-11 10:43:18 --> Total execution time: 0.7737
INFO - 2020-01-11 10:44:16 --> Config Class Initialized
INFO - 2020-01-11 10:44:16 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:44:16 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:44:16 --> Utf8 Class Initialized
INFO - 2020-01-11 10:44:16 --> URI Class Initialized
DEBUG - 2020-01-11 10:44:16 --> No URI present. Default controller set.
INFO - 2020-01-11 10:44:16 --> Router Class Initialized
INFO - 2020-01-11 10:44:16 --> Output Class Initialized
INFO - 2020-01-11 10:44:16 --> Security Class Initialized
DEBUG - 2020-01-11 10:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:44:16 --> CSRF cookie sent
INFO - 2020-01-11 10:44:16 --> Input Class Initialized
INFO - 2020-01-11 10:44:16 --> Language Class Initialized
INFO - 2020-01-11 10:44:16 --> Language Class Initialized
INFO - 2020-01-11 10:44:16 --> Config Class Initialized
INFO - 2020-01-11 10:44:16 --> Loader Class Initialized
INFO - 2020-01-11 10:44:16 --> Helper loaded: url_helper
INFO - 2020-01-11 10:44:16 --> Helper loaded: common_helper
INFO - 2020-01-11 10:44:16 --> Helper loaded: language_helper
INFO - 2020-01-11 10:44:16 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:44:16 --> Helper loaded: email_helper
INFO - 2020-01-11 10:44:16 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:44:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:44:16 --> Parser Class Initialized
INFO - 2020-01-11 10:44:16 --> User Agent Class Initialized
INFO - 2020-01-11 10:44:16 --> Model Class Initialized
INFO - 2020-01-11 10:44:16 --> Database Driver Class Initialized
INFO - 2020-01-11 10:44:16 --> Model Class Initialized
DEBUG - 2020-01-11 10:44:16 --> Template Class Initialized
INFO - 2020-01-11 10:44:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:44:16 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:44:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:44:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:44:16 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:44:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:44:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:44:16 --> Controller Class Initialized
DEBUG - 2020-01-11 10:44:16 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:44:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:44:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:44:16 --> Model Class Initialized
INFO - 2020-01-11 10:44:16 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:44:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:44:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:44:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:44:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:44:16 --> Final output sent to browser
DEBUG - 2020-01-11 10:44:16 --> Total execution time: 0.7614
INFO - 2020-01-11 10:45:04 --> Config Class Initialized
INFO - 2020-01-11 10:45:04 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:45:04 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:45:04 --> Utf8 Class Initialized
INFO - 2020-01-11 10:45:04 --> URI Class Initialized
DEBUG - 2020-01-11 10:45:04 --> No URI present. Default controller set.
INFO - 2020-01-11 10:45:04 --> Router Class Initialized
INFO - 2020-01-11 10:45:04 --> Output Class Initialized
INFO - 2020-01-11 10:45:04 --> Security Class Initialized
DEBUG - 2020-01-11 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:45:04 --> CSRF cookie sent
INFO - 2020-01-11 10:45:04 --> Input Class Initialized
INFO - 2020-01-11 10:45:04 --> Language Class Initialized
INFO - 2020-01-11 10:45:04 --> Language Class Initialized
INFO - 2020-01-11 10:45:04 --> Config Class Initialized
INFO - 2020-01-11 10:45:04 --> Loader Class Initialized
INFO - 2020-01-11 10:45:04 --> Helper loaded: url_helper
INFO - 2020-01-11 10:45:04 --> Helper loaded: common_helper
INFO - 2020-01-11 10:45:04 --> Helper loaded: language_helper
INFO - 2020-01-11 10:45:04 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:45:04 --> Helper loaded: email_helper
INFO - 2020-01-11 10:45:04 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:45:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:45:04 --> Parser Class Initialized
INFO - 2020-01-11 10:45:04 --> User Agent Class Initialized
INFO - 2020-01-11 10:45:04 --> Model Class Initialized
INFO - 2020-01-11 10:45:04 --> Database Driver Class Initialized
INFO - 2020-01-11 10:45:04 --> Model Class Initialized
DEBUG - 2020-01-11 10:45:04 --> Template Class Initialized
INFO - 2020-01-11 10:45:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:45:04 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:45:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:45:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:45:05 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:45:05 --> Controller Class Initialized
DEBUG - 2020-01-11 10:45:05 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:45:05 --> Model Class Initialized
INFO - 2020-01-11 10:45:05 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:45:05 --> Final output sent to browser
DEBUG - 2020-01-11 10:45:05 --> Total execution time: 0.7745
INFO - 2020-01-11 10:46:29 --> Config Class Initialized
INFO - 2020-01-11 10:46:29 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:46:29 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:46:29 --> Utf8 Class Initialized
INFO - 2020-01-11 10:46:29 --> URI Class Initialized
DEBUG - 2020-01-11 10:46:29 --> No URI present. Default controller set.
INFO - 2020-01-11 10:46:29 --> Router Class Initialized
INFO - 2020-01-11 10:46:29 --> Output Class Initialized
INFO - 2020-01-11 10:46:29 --> Security Class Initialized
DEBUG - 2020-01-11 10:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:46:29 --> CSRF cookie sent
INFO - 2020-01-11 10:46:29 --> Input Class Initialized
INFO - 2020-01-11 10:46:29 --> Language Class Initialized
INFO - 2020-01-11 10:46:29 --> Language Class Initialized
INFO - 2020-01-11 10:46:29 --> Config Class Initialized
INFO - 2020-01-11 10:46:29 --> Loader Class Initialized
INFO - 2020-01-11 10:46:29 --> Helper loaded: url_helper
INFO - 2020-01-11 10:46:29 --> Helper loaded: common_helper
INFO - 2020-01-11 10:46:29 --> Helper loaded: language_helper
INFO - 2020-01-11 10:46:29 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:46:29 --> Helper loaded: email_helper
INFO - 2020-01-11 10:46:29 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:46:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:46:29 --> Parser Class Initialized
INFO - 2020-01-11 10:46:29 --> User Agent Class Initialized
INFO - 2020-01-11 10:46:29 --> Model Class Initialized
INFO - 2020-01-11 10:46:29 --> Database Driver Class Initialized
INFO - 2020-01-11 10:46:29 --> Model Class Initialized
DEBUG - 2020-01-11 10:46:29 --> Template Class Initialized
INFO - 2020-01-11 10:46:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:46:29 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:46:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:46:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:46:29 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:46:29 --> Controller Class Initialized
DEBUG - 2020-01-11 10:46:29 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:46:29 --> Model Class Initialized
INFO - 2020-01-11 10:46:29 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:46:29 --> Final output sent to browser
DEBUG - 2020-01-11 10:46:29 --> Total execution time: 0.7297
INFO - 2020-01-11 10:50:09 --> Config Class Initialized
INFO - 2020-01-11 10:50:09 --> Hooks Class Initialized
DEBUG - 2020-01-11 10:50:09 --> UTF-8 Support Enabled
INFO - 2020-01-11 10:50:09 --> Utf8 Class Initialized
INFO - 2020-01-11 10:50:09 --> URI Class Initialized
DEBUG - 2020-01-11 10:50:09 --> No URI present. Default controller set.
INFO - 2020-01-11 10:50:09 --> Router Class Initialized
INFO - 2020-01-11 10:50:09 --> Output Class Initialized
INFO - 2020-01-11 10:50:09 --> Security Class Initialized
DEBUG - 2020-01-11 10:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-11 10:50:09 --> CSRF cookie sent
INFO - 2020-01-11 10:50:09 --> Input Class Initialized
INFO - 2020-01-11 10:50:09 --> Language Class Initialized
INFO - 2020-01-11 10:50:09 --> Language Class Initialized
INFO - 2020-01-11 10:50:09 --> Config Class Initialized
INFO - 2020-01-11 10:50:09 --> Loader Class Initialized
INFO - 2020-01-11 10:50:09 --> Helper loaded: url_helper
INFO - 2020-01-11 10:50:09 --> Helper loaded: common_helper
INFO - 2020-01-11 10:50:09 --> Helper loaded: language_helper
INFO - 2020-01-11 10:50:09 --> Helper loaded: cookie_helper
INFO - 2020-01-11 10:50:09 --> Helper loaded: email_helper
INFO - 2020-01-11 10:50:09 --> Helper loaded: file_manager_helper
INFO - 2020-01-11 10:50:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-01-11 10:50:09 --> Parser Class Initialized
INFO - 2020-01-11 10:50:09 --> User Agent Class Initialized
INFO - 2020-01-11 10:50:09 --> Model Class Initialized
INFO - 2020-01-11 10:50:09 --> Database Driver Class Initialized
INFO - 2020-01-11 10:50:09 --> Model Class Initialized
DEBUG - 2020-01-11 10:50:09 --> Template Class Initialized
INFO - 2020-01-11 10:50:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-01-11 10:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-11 10:50:09 --> Pagination Class Initialized
DEBUG - 2020-01-11 10:50:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-01-11 10:50:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-01-11 10:50:09 --> Encryption Class Initialized
DEBUG - 2020-01-11 10:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-01-11 10:50:09 --> Controller Class Initialized
DEBUG - 2020-01-11 10:50:09 --> pergo MX_Controller Initialized
DEBUG - 2020-01-11 10:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-01-11 10:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-01-11 10:50:09 --> Model Class Initialized
INFO - 2020-01-11 10:50:09 --> Helper loaded: inflector_helper
DEBUG - 2020-01-11 10:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-01-11 10:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-01-11 10:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-01-11 10:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-01-11 10:50:09 --> Final output sent to browser
DEBUG - 2020-01-11 10:50:09 --> Total execution time: 0.7911
