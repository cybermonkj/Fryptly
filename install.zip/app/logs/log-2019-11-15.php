<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-15 10:56:08 --> Config Class Initialized
INFO - 2019-11-15 10:56:08 --> Hooks Class Initialized
DEBUG - 2019-11-15 10:56:08 --> UTF-8 Support Enabled
INFO - 2019-11-15 10:56:08 --> Utf8 Class Initialized
INFO - 2019-11-15 10:56:08 --> URI Class Initialized
DEBUG - 2019-11-15 10:56:08 --> No URI present. Default controller set.
INFO - 2019-11-15 10:56:08 --> Router Class Initialized
INFO - 2019-11-15 10:56:08 --> Output Class Initialized
INFO - 2019-11-15 10:56:09 --> Security Class Initialized
DEBUG - 2019-11-15 10:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-15 10:56:09 --> CSRF cookie sent
INFO - 2019-11-15 10:56:09 --> Input Class Initialized
INFO - 2019-11-15 10:56:09 --> Language Class Initialized
INFO - 2019-11-15 10:56:09 --> Language Class Initialized
INFO - 2019-11-15 10:56:09 --> Config Class Initialized
INFO - 2019-11-15 10:56:09 --> Loader Class Initialized
INFO - 2019-11-15 10:56:09 --> Helper loaded: url_helper
INFO - 2019-11-15 10:56:09 --> Helper loaded: common_helper
INFO - 2019-11-15 10:56:09 --> Helper loaded: language_helper
INFO - 2019-11-15 10:56:09 --> Helper loaded: cookie_helper
INFO - 2019-11-15 10:56:09 --> Helper loaded: email_helper
INFO - 2019-11-15 10:56:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-15 10:56:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-15 10:56:09 --> Parser Class Initialized
INFO - 2019-11-15 10:56:09 --> User Agent Class Initialized
INFO - 2019-11-15 10:56:09 --> Model Class Initialized
INFO - 2019-11-15 10:56:09 --> Database Driver Class Initialized
INFO - 2019-11-15 10:56:09 --> Model Class Initialized
DEBUG - 2019-11-15 10:56:09 --> Template Class Initialized
INFO - 2019-11-15 10:56:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-15 10:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-15 10:56:09 --> Pagination Class Initialized
DEBUG - 2019-11-15 10:56:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-15 10:56:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-15 10:56:09 --> Encryption Class Initialized
DEBUG - 2019-11-15 10:56:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-15 10:56:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-15 10:56:09 --> Controller Class Initialized
DEBUG - 2019-11-15 10:56:09 --> pergo MX_Controller Initialized
DEBUG - 2019-11-15 10:56:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-15 10:56:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-15 10:56:09 --> Model Class Initialized
INFO - 2019-11-15 10:56:10 --> Helper loaded: inflector_helper
DEBUG - 2019-11-15 10:56:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-15 10:56:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-15 10:56:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-15 10:56:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-15 10:56:10 --> Final output sent to browser
DEBUG - 2019-11-15 10:56:10 --> Total execution time: 1.6949
