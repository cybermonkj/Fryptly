<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-09 00:00:11 --> Config Class Initialized
INFO - 2019-11-09 00:00:11 --> Hooks Class Initialized
DEBUG - 2019-11-09 00:00:11 --> UTF-8 Support Enabled
INFO - 2019-11-09 00:00:11 --> Utf8 Class Initialized
INFO - 2019-11-09 00:00:11 --> URI Class Initialized
INFO - 2019-11-09 00:00:11 --> Router Class Initialized
INFO - 2019-11-09 00:00:11 --> Output Class Initialized
INFO - 2019-11-09 00:00:11 --> Security Class Initialized
DEBUG - 2019-11-09 00:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 00:00:11 --> Input Class Initialized
INFO - 2019-11-09 00:00:11 --> Language Class Initialized
INFO - 2019-11-09 00:00:11 --> Language Class Initialized
INFO - 2019-11-09 00:00:11 --> Config Class Initialized
INFO - 2019-11-09 00:00:11 --> Loader Class Initialized
INFO - 2019-11-09 00:00:11 --> Helper loaded: url_helper
INFO - 2019-11-09 00:00:11 --> Helper loaded: common_helper
INFO - 2019-11-09 00:00:11 --> Helper loaded: language_helper
INFO - 2019-11-09 00:00:11 --> Helper loaded: cookie_helper
INFO - 2019-11-09 00:00:11 --> Helper loaded: email_helper
INFO - 2019-11-09 00:00:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 00:00:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 00:00:11 --> Parser Class Initialized
INFO - 2019-11-09 00:00:11 --> User Agent Class Initialized
INFO - 2019-11-09 00:00:11 --> Model Class Initialized
INFO - 2019-11-09 00:00:11 --> Database Driver Class Initialized
INFO - 2019-11-09 00:00:11 --> Model Class Initialized
DEBUG - 2019-11-09 00:00:11 --> Template Class Initialized
INFO - 2019-11-09 00:00:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 00:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 00:00:12 --> Pagination Class Initialized
DEBUG - 2019-11-09 00:00:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 00:00:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 00:00:12 --> Encryption Class Initialized
INFO - 2019-11-09 00:00:12 --> Controller Class Initialized
DEBUG - 2019-11-09 00:00:12 --> paytm MX_Controller Initialized
INFO - 2019-11-09 00:00:12 --> Model Class Initialized
DEBUG - 2019-11-09 00:00:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 00:00:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-09 00:00:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-09 00:00:12 --> Final output sent to browser
DEBUG - 2019-11-09 00:00:12 --> Total execution time: 0.3835
INFO - 2019-11-09 00:01:48 --> Config Class Initialized
INFO - 2019-11-09 00:01:48 --> Hooks Class Initialized
DEBUG - 2019-11-09 00:01:48 --> UTF-8 Support Enabled
INFO - 2019-11-09 00:01:48 --> Utf8 Class Initialized
INFO - 2019-11-09 00:01:48 --> URI Class Initialized
INFO - 2019-11-09 00:01:48 --> Router Class Initialized
INFO - 2019-11-09 00:01:48 --> Output Class Initialized
INFO - 2019-11-09 00:01:48 --> Security Class Initialized
DEBUG - 2019-11-09 00:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 00:01:48 --> Input Class Initialized
INFO - 2019-11-09 00:01:48 --> Language Class Initialized
INFO - 2019-11-09 00:01:48 --> Language Class Initialized
INFO - 2019-11-09 00:01:48 --> Config Class Initialized
INFO - 2019-11-09 00:01:48 --> Loader Class Initialized
INFO - 2019-11-09 00:01:48 --> Helper loaded: url_helper
INFO - 2019-11-09 00:01:48 --> Helper loaded: common_helper
INFO - 2019-11-09 00:01:48 --> Helper loaded: language_helper
INFO - 2019-11-09 00:01:48 --> Helper loaded: cookie_helper
INFO - 2019-11-09 00:01:48 --> Helper loaded: email_helper
INFO - 2019-11-09 00:01:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 00:01:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 00:01:48 --> Parser Class Initialized
INFO - 2019-11-09 00:01:48 --> User Agent Class Initialized
INFO - 2019-11-09 00:01:48 --> Model Class Initialized
INFO - 2019-11-09 00:01:48 --> Database Driver Class Initialized
INFO - 2019-11-09 00:01:49 --> Model Class Initialized
DEBUG - 2019-11-09 00:01:49 --> Template Class Initialized
INFO - 2019-11-09 00:01:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 00:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 00:01:49 --> Pagination Class Initialized
DEBUG - 2019-11-09 00:01:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 00:01:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 00:01:49 --> Encryption Class Initialized
INFO - 2019-11-09 00:01:49 --> Controller Class Initialized
DEBUG - 2019-11-09 00:01:49 --> paytm MX_Controller Initialized
INFO - 2019-11-09 00:01:49 --> Model Class Initialized
DEBUG - 2019-11-09 00:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 00:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-09 00:01:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-09 00:01:49 --> Final output sent to browser
DEBUG - 2019-11-09 00:01:49 --> Total execution time: 0.3538
INFO - 2019-11-09 00:04:59 --> Config Class Initialized
INFO - 2019-11-09 00:04:59 --> Hooks Class Initialized
DEBUG - 2019-11-09 00:04:59 --> UTF-8 Support Enabled
INFO - 2019-11-09 00:04:59 --> Utf8 Class Initialized
INFO - 2019-11-09 00:04:59 --> URI Class Initialized
INFO - 2019-11-09 00:04:59 --> Router Class Initialized
INFO - 2019-11-09 00:04:59 --> Output Class Initialized
INFO - 2019-11-09 00:04:59 --> Security Class Initialized
DEBUG - 2019-11-09 00:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 00:04:59 --> Input Class Initialized
INFO - 2019-11-09 00:04:59 --> Language Class Initialized
INFO - 2019-11-09 00:04:59 --> Language Class Initialized
INFO - 2019-11-09 00:04:59 --> Config Class Initialized
INFO - 2019-11-09 00:04:59 --> Loader Class Initialized
INFO - 2019-11-09 00:04:59 --> Helper loaded: url_helper
INFO - 2019-11-09 00:04:59 --> Helper loaded: common_helper
INFO - 2019-11-09 00:04:59 --> Helper loaded: language_helper
INFO - 2019-11-09 00:04:59 --> Helper loaded: cookie_helper
INFO - 2019-11-09 00:04:59 --> Helper loaded: email_helper
INFO - 2019-11-09 00:04:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 00:04:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 00:04:59 --> Parser Class Initialized
INFO - 2019-11-09 00:04:59 --> User Agent Class Initialized
INFO - 2019-11-09 00:04:59 --> Model Class Initialized
INFO - 2019-11-09 00:04:59 --> Database Driver Class Initialized
INFO - 2019-11-09 00:04:59 --> Model Class Initialized
DEBUG - 2019-11-09 00:04:59 --> Template Class Initialized
INFO - 2019-11-09 00:04:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 00:04:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 00:04:59 --> Pagination Class Initialized
DEBUG - 2019-11-09 00:04:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 00:04:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 00:04:59 --> Encryption Class Initialized
INFO - 2019-11-09 00:04:59 --> Controller Class Initialized
DEBUG - 2019-11-09 00:04:59 --> paytm MX_Controller Initialized
INFO - 2019-11-09 00:04:59 --> Model Class Initialized
DEBUG - 2019-11-09 00:04:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 00:04:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 00:04:59 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 00:04:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 00:04:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/redirect.php
INFO - 2019-11-09 00:04:59 --> Final output sent to browser
DEBUG - 2019-11-09 00:04:59 --> Total execution time: 0.4291
INFO - 2019-11-09 00:05:50 --> Config Class Initialized
INFO - 2019-11-09 00:05:50 --> Hooks Class Initialized
DEBUG - 2019-11-09 00:05:50 --> UTF-8 Support Enabled
INFO - 2019-11-09 00:05:50 --> Utf8 Class Initialized
INFO - 2019-11-09 00:05:50 --> URI Class Initialized
INFO - 2019-11-09 00:05:50 --> Router Class Initialized
INFO - 2019-11-09 00:05:50 --> Output Class Initialized
INFO - 2019-11-09 00:05:50 --> Security Class Initialized
DEBUG - 2019-11-09 00:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 00:05:50 --> Input Class Initialized
INFO - 2019-11-09 00:05:50 --> Language Class Initialized
INFO - 2019-11-09 00:05:50 --> Language Class Initialized
INFO - 2019-11-09 00:05:50 --> Config Class Initialized
INFO - 2019-11-09 00:05:50 --> Loader Class Initialized
INFO - 2019-11-09 00:05:50 --> Helper loaded: url_helper
INFO - 2019-11-09 00:05:50 --> Helper loaded: common_helper
INFO - 2019-11-09 00:05:50 --> Helper loaded: language_helper
INFO - 2019-11-09 00:05:50 --> Helper loaded: cookie_helper
INFO - 2019-11-09 00:05:50 --> Helper loaded: email_helper
INFO - 2019-11-09 00:05:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 00:05:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 00:05:50 --> Parser Class Initialized
INFO - 2019-11-09 00:05:50 --> User Agent Class Initialized
INFO - 2019-11-09 00:05:50 --> Model Class Initialized
INFO - 2019-11-09 00:05:50 --> Database Driver Class Initialized
INFO - 2019-11-09 00:05:50 --> Model Class Initialized
DEBUG - 2019-11-09 00:05:50 --> Template Class Initialized
INFO - 2019-11-09 00:05:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 00:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 00:05:50 --> Pagination Class Initialized
DEBUG - 2019-11-09 00:05:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 00:05:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 00:05:50 --> Encryption Class Initialized
INFO - 2019-11-09 00:05:50 --> Controller Class Initialized
DEBUG - 2019-11-09 00:05:50 --> paytm MX_Controller Initialized
INFO - 2019-11-09 00:05:50 --> Model Class Initialized
DEBUG - 2019-11-09 00:05:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 00:05:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 00:05:50 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 00:05:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 00:05:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/redirect.php
INFO - 2019-11-09 00:05:50 --> Final output sent to browser
DEBUG - 2019-11-09 00:05:50 --> Total execution time: 0.4160
INFO - 2019-11-09 00:08:37 --> Config Class Initialized
INFO - 2019-11-09 00:08:37 --> Hooks Class Initialized
DEBUG - 2019-11-09 00:08:37 --> UTF-8 Support Enabled
INFO - 2019-11-09 00:08:37 --> Utf8 Class Initialized
INFO - 2019-11-09 00:08:37 --> URI Class Initialized
INFO - 2019-11-09 00:08:38 --> Router Class Initialized
INFO - 2019-11-09 00:08:38 --> Output Class Initialized
INFO - 2019-11-09 00:08:38 --> Security Class Initialized
DEBUG - 2019-11-09 00:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 00:08:38 --> CSRF cookie sent
INFO - 2019-11-09 00:08:38 --> CSRF token verified
INFO - 2019-11-09 00:08:38 --> Input Class Initialized
INFO - 2019-11-09 00:08:38 --> Language Class Initialized
INFO - 2019-11-09 00:08:38 --> Language Class Initialized
INFO - 2019-11-09 00:08:38 --> Config Class Initialized
INFO - 2019-11-09 00:08:38 --> Loader Class Initialized
INFO - 2019-11-09 00:08:38 --> Helper loaded: url_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: common_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: language_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: cookie_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: email_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 00:08:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 00:08:38 --> Parser Class Initialized
INFO - 2019-11-09 00:08:38 --> User Agent Class Initialized
INFO - 2019-11-09 00:08:38 --> Model Class Initialized
INFO - 2019-11-09 00:08:38 --> Database Driver Class Initialized
INFO - 2019-11-09 00:08:38 --> Model Class Initialized
DEBUG - 2019-11-09 00:08:38 --> Template Class Initialized
INFO - 2019-11-09 00:08:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 00:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 00:08:38 --> Pagination Class Initialized
DEBUG - 2019-11-09 00:08:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 00:08:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 00:08:38 --> Encryption Class Initialized
INFO - 2019-11-09 00:08:38 --> Controller Class Initialized
DEBUG - 2019-11-09 00:08:38 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 00:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 00:08:38 --> Model Class Initialized
DEBUG - 2019-11-09 00:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 00:08:38 --> Final output sent to browser
DEBUG - 2019-11-09 00:08:38 --> Total execution time: 0.4375
INFO - 2019-11-09 00:08:38 --> Config Class Initialized
INFO - 2019-11-09 00:08:38 --> Hooks Class Initialized
DEBUG - 2019-11-09 00:08:38 --> UTF-8 Support Enabled
INFO - 2019-11-09 00:08:38 --> Utf8 Class Initialized
INFO - 2019-11-09 00:08:38 --> URI Class Initialized
INFO - 2019-11-09 00:08:38 --> Router Class Initialized
INFO - 2019-11-09 00:08:38 --> Output Class Initialized
INFO - 2019-11-09 00:08:38 --> Security Class Initialized
DEBUG - 2019-11-09 00:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 00:08:38 --> Input Class Initialized
INFO - 2019-11-09 00:08:38 --> Language Class Initialized
INFO - 2019-11-09 00:08:38 --> Language Class Initialized
INFO - 2019-11-09 00:08:38 --> Config Class Initialized
INFO - 2019-11-09 00:08:38 --> Loader Class Initialized
INFO - 2019-11-09 00:08:38 --> Helper loaded: url_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: common_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: language_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: cookie_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: email_helper
INFO - 2019-11-09 00:08:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 00:08:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 00:08:38 --> Parser Class Initialized
INFO - 2019-11-09 00:08:38 --> User Agent Class Initialized
INFO - 2019-11-09 00:08:38 --> Model Class Initialized
INFO - 2019-11-09 00:08:38 --> Database Driver Class Initialized
INFO - 2019-11-09 00:08:38 --> Model Class Initialized
DEBUG - 2019-11-09 00:08:38 --> Template Class Initialized
INFO - 2019-11-09 00:08:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 00:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 00:08:38 --> Pagination Class Initialized
DEBUG - 2019-11-09 00:08:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 00:08:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 00:08:38 --> Encryption Class Initialized
INFO - 2019-11-09 00:08:38 --> Controller Class Initialized
DEBUG - 2019-11-09 00:08:38 --> paytm MX_Controller Initialized
INFO - 2019-11-09 00:08:38 --> Model Class Initialized
DEBUG - 2019-11-09 00:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 00:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 00:08:38 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 00:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 00:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/redirect.php
INFO - 2019-11-09 00:08:38 --> Final output sent to browser
DEBUG - 2019-11-09 00:08:38 --> Total execution time: 0.4121
INFO - 2019-11-09 00:09:15 --> Config Class Initialized
INFO - 2019-11-09 00:09:15 --> Hooks Class Initialized
DEBUG - 2019-11-09 00:09:15 --> UTF-8 Support Enabled
INFO - 2019-11-09 00:09:15 --> Utf8 Class Initialized
INFO - 2019-11-09 00:09:15 --> URI Class Initialized
INFO - 2019-11-09 00:09:15 --> Router Class Initialized
INFO - 2019-11-09 00:09:15 --> Output Class Initialized
INFO - 2019-11-09 00:09:15 --> Security Class Initialized
DEBUG - 2019-11-09 00:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 00:09:15 --> CSRF cookie sent
INFO - 2019-11-09 00:09:15 --> CSRF token verified
INFO - 2019-11-09 00:09:15 --> Input Class Initialized
INFO - 2019-11-09 00:09:15 --> Language Class Initialized
INFO - 2019-11-09 00:09:15 --> Language Class Initialized
INFO - 2019-11-09 00:09:15 --> Config Class Initialized
INFO - 2019-11-09 00:09:15 --> Loader Class Initialized
INFO - 2019-11-09 00:09:15 --> Helper loaded: url_helper
INFO - 2019-11-09 00:09:15 --> Helper loaded: common_helper
INFO - 2019-11-09 00:09:15 --> Helper loaded: language_helper
INFO - 2019-11-09 00:09:15 --> Helper loaded: cookie_helper
INFO - 2019-11-09 00:09:15 --> Helper loaded: email_helper
INFO - 2019-11-09 00:09:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 00:09:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 00:09:15 --> Parser Class Initialized
INFO - 2019-11-09 00:09:16 --> User Agent Class Initialized
INFO - 2019-11-09 00:09:16 --> Model Class Initialized
INFO - 2019-11-09 00:09:16 --> Database Driver Class Initialized
INFO - 2019-11-09 00:09:16 --> Model Class Initialized
DEBUG - 2019-11-09 00:09:16 --> Template Class Initialized
INFO - 2019-11-09 00:09:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 00:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 00:09:16 --> Pagination Class Initialized
DEBUG - 2019-11-09 00:09:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 00:09:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 00:09:16 --> Encryption Class Initialized
INFO - 2019-11-09 00:09:16 --> Controller Class Initialized
DEBUG - 2019-11-09 00:09:16 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 00:09:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 00:09:16 --> Model Class Initialized
DEBUG - 2019-11-09 00:09:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 00:09:16 --> Final output sent to browser
DEBUG - 2019-11-09 00:09:16 --> Total execution time: 0.4372
INFO - 2019-11-09 00:09:16 --> Config Class Initialized
INFO - 2019-11-09 00:09:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 00:09:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 00:09:16 --> Utf8 Class Initialized
INFO - 2019-11-09 00:09:16 --> URI Class Initialized
INFO - 2019-11-09 00:09:16 --> Router Class Initialized
INFO - 2019-11-09 00:09:16 --> Output Class Initialized
INFO - 2019-11-09 00:09:16 --> Security Class Initialized
DEBUG - 2019-11-09 00:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 00:09:16 --> Input Class Initialized
INFO - 2019-11-09 00:09:16 --> Language Class Initialized
INFO - 2019-11-09 00:09:16 --> Language Class Initialized
INFO - 2019-11-09 00:09:16 --> Config Class Initialized
INFO - 2019-11-09 00:09:16 --> Loader Class Initialized
INFO - 2019-11-09 00:09:16 --> Helper loaded: url_helper
INFO - 2019-11-09 00:09:16 --> Helper loaded: common_helper
INFO - 2019-11-09 00:09:16 --> Helper loaded: language_helper
INFO - 2019-11-09 00:09:16 --> Helper loaded: cookie_helper
INFO - 2019-11-09 00:09:16 --> Helper loaded: email_helper
INFO - 2019-11-09 00:09:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 00:09:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 00:09:16 --> Parser Class Initialized
INFO - 2019-11-09 00:09:16 --> User Agent Class Initialized
INFO - 2019-11-09 00:09:16 --> Model Class Initialized
INFO - 2019-11-09 00:09:16 --> Database Driver Class Initialized
INFO - 2019-11-09 00:09:16 --> Model Class Initialized
DEBUG - 2019-11-09 00:09:16 --> Template Class Initialized
INFO - 2019-11-09 00:09:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 00:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 00:09:16 --> Pagination Class Initialized
DEBUG - 2019-11-09 00:09:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 00:09:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 00:09:16 --> Encryption Class Initialized
INFO - 2019-11-09 00:09:16 --> Controller Class Initialized
DEBUG - 2019-11-09 00:09:16 --> paytm MX_Controller Initialized
INFO - 2019-11-09 00:09:16 --> Model Class Initialized
DEBUG - 2019-11-09 00:09:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 00:09:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 00:09:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 00:09:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 00:09:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/redirect.php
INFO - 2019-11-09 00:09:16 --> Final output sent to browser
DEBUG - 2019-11-09 00:09:16 --> Total execution time: 0.4235
INFO - 2019-11-09 09:05:58 --> Config Class Initialized
INFO - 2019-11-09 09:05:58 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:05:58 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:05:58 --> Utf8 Class Initialized
INFO - 2019-11-09 09:05:58 --> URI Class Initialized
INFO - 2019-11-09 09:05:58 --> Router Class Initialized
INFO - 2019-11-09 09:05:58 --> Output Class Initialized
INFO - 2019-11-09 09:05:58 --> Security Class Initialized
DEBUG - 2019-11-09 09:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:05:58 --> Input Class Initialized
INFO - 2019-11-09 09:05:58 --> Language Class Initialized
INFO - 2019-11-09 09:05:58 --> Language Class Initialized
INFO - 2019-11-09 09:05:58 --> Config Class Initialized
INFO - 2019-11-09 09:05:58 --> Loader Class Initialized
INFO - 2019-11-09 09:05:58 --> Helper loaded: url_helper
INFO - 2019-11-09 09:05:58 --> Helper loaded: common_helper
INFO - 2019-11-09 09:05:59 --> Helper loaded: language_helper
INFO - 2019-11-09 09:05:59 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:05:59 --> Helper loaded: email_helper
INFO - 2019-11-09 09:05:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:05:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:05:59 --> Parser Class Initialized
INFO - 2019-11-09 09:05:59 --> User Agent Class Initialized
INFO - 2019-11-09 09:05:59 --> Model Class Initialized
INFO - 2019-11-09 09:05:59 --> Database Driver Class Initialized
INFO - 2019-11-09 09:05:59 --> Model Class Initialized
DEBUG - 2019-11-09 09:05:59 --> Template Class Initialized
INFO - 2019-11-09 09:05:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:05:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:05:59 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:05:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:05:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:05:59 --> Encryption Class Initialized
INFO - 2019-11-09 09:05:59 --> Controller Class Initialized
DEBUG - 2019-11-09 09:05:59 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:05:59 --> Model Class Initialized
DEBUG - 2019-11-09 09:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:05:59 --> Config Class Initialized
INFO - 2019-11-09 09:05:59 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:05:59 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:05:59 --> Utf8 Class Initialized
INFO - 2019-11-09 09:05:59 --> URI Class Initialized
DEBUG - 2019-11-09 09:05:59 --> No URI present. Default controller set.
INFO - 2019-11-09 09:05:59 --> Router Class Initialized
INFO - 2019-11-09 09:05:59 --> Output Class Initialized
INFO - 2019-11-09 09:05:59 --> Security Class Initialized
DEBUG - 2019-11-09 09:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:05:59 --> CSRF cookie sent
INFO - 2019-11-09 09:05:59 --> Input Class Initialized
INFO - 2019-11-09 09:05:59 --> Language Class Initialized
INFO - 2019-11-09 09:06:00 --> Language Class Initialized
INFO - 2019-11-09 09:06:00 --> Config Class Initialized
INFO - 2019-11-09 09:06:00 --> Loader Class Initialized
INFO - 2019-11-09 09:06:00 --> Helper loaded: url_helper
INFO - 2019-11-09 09:06:00 --> Helper loaded: common_helper
INFO - 2019-11-09 09:06:00 --> Helper loaded: language_helper
INFO - 2019-11-09 09:06:00 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:06:00 --> Helper loaded: email_helper
INFO - 2019-11-09 09:06:00 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:06:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:06:00 --> Parser Class Initialized
INFO - 2019-11-09 09:06:00 --> User Agent Class Initialized
INFO - 2019-11-09 09:06:00 --> Model Class Initialized
INFO - 2019-11-09 09:06:00 --> Database Driver Class Initialized
INFO - 2019-11-09 09:06:00 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:00 --> Template Class Initialized
INFO - 2019-11-09 09:06:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:06:00 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:06:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:06:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:06:00 --> Encryption Class Initialized
DEBUG - 2019-11-09 09:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 09:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 09:06:00 --> Controller Class Initialized
DEBUG - 2019-11-09 09:06:00 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 09:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 09:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 09:06:00 --> Model Class Initialized
INFO - 2019-11-09 09:06:00 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 09:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 09:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 09:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 09:06:00 --> Final output sent to browser
DEBUG - 2019-11-09 09:06:00 --> Total execution time: 1.0210
INFO - 2019-11-09 09:06:03 --> Config Class Initialized
INFO - 2019-11-09 09:06:03 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:06:03 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:06:03 --> Utf8 Class Initialized
INFO - 2019-11-09 09:06:03 --> URI Class Initialized
INFO - 2019-11-09 09:06:03 --> Router Class Initialized
INFO - 2019-11-09 09:06:03 --> Output Class Initialized
INFO - 2019-11-09 09:06:03 --> Security Class Initialized
DEBUG - 2019-11-09 09:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:06:03 --> CSRF cookie sent
INFO - 2019-11-09 09:06:03 --> Input Class Initialized
INFO - 2019-11-09 09:06:03 --> Language Class Initialized
INFO - 2019-11-09 09:06:03 --> Language Class Initialized
INFO - 2019-11-09 09:06:03 --> Config Class Initialized
INFO - 2019-11-09 09:06:03 --> Loader Class Initialized
INFO - 2019-11-09 09:06:03 --> Helper loaded: url_helper
INFO - 2019-11-09 09:06:03 --> Helper loaded: common_helper
INFO - 2019-11-09 09:06:03 --> Helper loaded: language_helper
INFO - 2019-11-09 09:06:03 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:06:03 --> Helper loaded: email_helper
INFO - 2019-11-09 09:06:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:06:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:06:03 --> Parser Class Initialized
INFO - 2019-11-09 09:06:03 --> User Agent Class Initialized
INFO - 2019-11-09 09:06:03 --> Model Class Initialized
INFO - 2019-11-09 09:06:03 --> Database Driver Class Initialized
INFO - 2019-11-09 09:06:03 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:03 --> Template Class Initialized
INFO - 2019-11-09 09:06:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:06:03 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:06:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:06:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:06:03 --> Encryption Class Initialized
INFO - 2019-11-09 09:06:03 --> Controller Class Initialized
DEBUG - 2019-11-09 09:06:03 --> package MX_Controller Initialized
DEBUG - 2019-11-09 09:06:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 09:06:04 --> Model Class Initialized
INFO - 2019-11-09 09:06:04 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:06:04 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:06:04 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:06:04 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 09:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 09:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:06:04 --> Final output sent to browser
DEBUG - 2019-11-09 09:06:04 --> Total execution time: 1.3346
INFO - 2019-11-09 09:06:07 --> Config Class Initialized
INFO - 2019-11-09 09:06:07 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:06:07 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:06:07 --> Utf8 Class Initialized
INFO - 2019-11-09 09:06:07 --> URI Class Initialized
INFO - 2019-11-09 09:06:07 --> Router Class Initialized
INFO - 2019-11-09 09:06:07 --> Output Class Initialized
INFO - 2019-11-09 09:06:08 --> Security Class Initialized
DEBUG - 2019-11-09 09:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:06:08 --> CSRF cookie sent
INFO - 2019-11-09 09:06:08 --> CSRF token verified
INFO - 2019-11-09 09:06:08 --> Input Class Initialized
INFO - 2019-11-09 09:06:08 --> Language Class Initialized
INFO - 2019-11-09 09:06:08 --> Language Class Initialized
INFO - 2019-11-09 09:06:08 --> Config Class Initialized
INFO - 2019-11-09 09:06:08 --> Loader Class Initialized
INFO - 2019-11-09 09:06:08 --> Helper loaded: url_helper
INFO - 2019-11-09 09:06:08 --> Helper loaded: common_helper
INFO - 2019-11-09 09:06:08 --> Helper loaded: language_helper
INFO - 2019-11-09 09:06:08 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:06:08 --> Helper loaded: email_helper
INFO - 2019-11-09 09:06:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:06:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:06:08 --> Parser Class Initialized
INFO - 2019-11-09 09:06:08 --> User Agent Class Initialized
INFO - 2019-11-09 09:06:08 --> Model Class Initialized
INFO - 2019-11-09 09:06:08 --> Database Driver Class Initialized
INFO - 2019-11-09 09:06:08 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:08 --> Template Class Initialized
INFO - 2019-11-09 09:06:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:06:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:06:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:06:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:06:08 --> Encryption Class Initialized
INFO - 2019-11-09 09:06:08 --> Controller Class Initialized
DEBUG - 2019-11-09 09:06:08 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 09:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 09:06:08 --> Model Class Initialized
INFO - 2019-11-09 09:06:08 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 09:06:08 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 09:06:08 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 09:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 09:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:06:08 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:06:08 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:06:08 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:06:08 --> Final output sent to browser
DEBUG - 2019-11-09 09:06:08 --> Total execution time: 0.8818
INFO - 2019-11-09 09:06:17 --> Config Class Initialized
INFO - 2019-11-09 09:06:17 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:06:17 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:06:17 --> Utf8 Class Initialized
INFO - 2019-11-09 09:06:17 --> URI Class Initialized
INFO - 2019-11-09 09:06:17 --> Router Class Initialized
INFO - 2019-11-09 09:06:17 --> Output Class Initialized
INFO - 2019-11-09 09:06:17 --> Security Class Initialized
DEBUG - 2019-11-09 09:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:06:17 --> CSRF cookie sent
INFO - 2019-11-09 09:06:17 --> CSRF token verified
INFO - 2019-11-09 09:06:17 --> Input Class Initialized
INFO - 2019-11-09 09:06:17 --> Language Class Initialized
INFO - 2019-11-09 09:06:17 --> Language Class Initialized
INFO - 2019-11-09 09:06:17 --> Config Class Initialized
INFO - 2019-11-09 09:06:17 --> Loader Class Initialized
INFO - 2019-11-09 09:06:17 --> Helper loaded: url_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: common_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: language_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: email_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:06:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:06:17 --> Parser Class Initialized
INFO - 2019-11-09 09:06:17 --> User Agent Class Initialized
INFO - 2019-11-09 09:06:17 --> Model Class Initialized
INFO - 2019-11-09 09:06:17 --> Database Driver Class Initialized
INFO - 2019-11-09 09:06:17 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:17 --> Template Class Initialized
INFO - 2019-11-09 09:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:06:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:06:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:06:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:06:17 --> Encryption Class Initialized
INFO - 2019-11-09 09:06:17 --> Controller Class Initialized
DEBUG - 2019-11-09 09:06:17 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 09:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 09:06:17 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 09:06:17 --> Final output sent to browser
DEBUG - 2019-11-09 09:06:17 --> Total execution time: 0.5031
INFO - 2019-11-09 09:06:17 --> Config Class Initialized
INFO - 2019-11-09 09:06:17 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:06:17 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:06:17 --> Utf8 Class Initialized
INFO - 2019-11-09 09:06:17 --> URI Class Initialized
INFO - 2019-11-09 09:06:17 --> Router Class Initialized
INFO - 2019-11-09 09:06:17 --> Output Class Initialized
INFO - 2019-11-09 09:06:17 --> Security Class Initialized
DEBUG - 2019-11-09 09:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:06:17 --> Input Class Initialized
INFO - 2019-11-09 09:06:17 --> Language Class Initialized
INFO - 2019-11-09 09:06:17 --> Language Class Initialized
INFO - 2019-11-09 09:06:17 --> Config Class Initialized
INFO - 2019-11-09 09:06:17 --> Loader Class Initialized
INFO - 2019-11-09 09:06:17 --> Helper loaded: url_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: common_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: language_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: email_helper
INFO - 2019-11-09 09:06:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:06:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:06:17 --> Parser Class Initialized
INFO - 2019-11-09 09:06:17 --> User Agent Class Initialized
INFO - 2019-11-09 09:06:17 --> Model Class Initialized
INFO - 2019-11-09 09:06:17 --> Database Driver Class Initialized
INFO - 2019-11-09 09:06:17 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:17 --> Template Class Initialized
INFO - 2019-11-09 09:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:06:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:06:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:06:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:06:17 --> Encryption Class Initialized
INFO - 2019-11-09 09:06:18 --> Controller Class Initialized
DEBUG - 2019-11-09 09:06:18 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:06:18 --> Model Class Initialized
DEBUG - 2019-11-09 09:06:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:06:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:06:18 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:06:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:06:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/redirect.php
INFO - 2019-11-09 09:06:18 --> Final output sent to browser
DEBUG - 2019-11-09 09:06:18 --> Total execution time: 0.5127
INFO - 2019-11-09 09:10:08 --> Config Class Initialized
INFO - 2019-11-09 09:10:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:10:08 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:10:08 --> Utf8 Class Initialized
INFO - 2019-11-09 09:10:08 --> URI Class Initialized
INFO - 2019-11-09 09:10:08 --> Router Class Initialized
INFO - 2019-11-09 09:10:08 --> Output Class Initialized
INFO - 2019-11-09 09:10:08 --> Security Class Initialized
DEBUG - 2019-11-09 09:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:10:08 --> Input Class Initialized
INFO - 2019-11-09 09:10:08 --> Language Class Initialized
INFO - 2019-11-09 09:10:08 --> Language Class Initialized
INFO - 2019-11-09 09:10:08 --> Config Class Initialized
INFO - 2019-11-09 09:10:08 --> Loader Class Initialized
INFO - 2019-11-09 09:10:08 --> Helper loaded: url_helper
INFO - 2019-11-09 09:10:08 --> Helper loaded: common_helper
INFO - 2019-11-09 09:10:08 --> Helper loaded: language_helper
INFO - 2019-11-09 09:10:08 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:10:08 --> Helper loaded: email_helper
INFO - 2019-11-09 09:10:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:10:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:10:08 --> Parser Class Initialized
INFO - 2019-11-09 09:10:08 --> User Agent Class Initialized
INFO - 2019-11-09 09:10:08 --> Model Class Initialized
INFO - 2019-11-09 09:10:08 --> Database Driver Class Initialized
INFO - 2019-11-09 09:10:08 --> Model Class Initialized
DEBUG - 2019-11-09 09:10:08 --> Template Class Initialized
INFO - 2019-11-09 09:10:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:10:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:10:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:10:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:10:08 --> Encryption Class Initialized
INFO - 2019-11-09 09:10:08 --> Controller Class Initialized
DEBUG - 2019-11-09 09:10:08 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:10:09 --> Model Class Initialized
DEBUG - 2019-11-09 09:10:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:10:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:10:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:10:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:10:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/redirect.php
INFO - 2019-11-09 09:10:09 --> Final output sent to browser
DEBUG - 2019-11-09 09:10:09 --> Total execution time: 0.5542
INFO - 2019-11-09 09:10:27 --> Config Class Initialized
INFO - 2019-11-09 09:10:27 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:10:27 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:10:27 --> Utf8 Class Initialized
INFO - 2019-11-09 09:10:27 --> URI Class Initialized
INFO - 2019-11-09 09:10:27 --> Router Class Initialized
INFO - 2019-11-09 09:10:27 --> Output Class Initialized
INFO - 2019-11-09 09:10:27 --> Security Class Initialized
DEBUG - 2019-11-09 09:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:10:27 --> Input Class Initialized
INFO - 2019-11-09 09:10:27 --> Language Class Initialized
INFO - 2019-11-09 09:10:27 --> Language Class Initialized
INFO - 2019-11-09 09:10:27 --> Config Class Initialized
INFO - 2019-11-09 09:10:27 --> Loader Class Initialized
INFO - 2019-11-09 09:10:27 --> Helper loaded: url_helper
INFO - 2019-11-09 09:10:27 --> Helper loaded: common_helper
INFO - 2019-11-09 09:10:27 --> Helper loaded: language_helper
INFO - 2019-11-09 09:10:27 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:10:27 --> Helper loaded: email_helper
INFO - 2019-11-09 09:10:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:10:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:10:27 --> Parser Class Initialized
INFO - 2019-11-09 09:10:27 --> User Agent Class Initialized
INFO - 2019-11-09 09:10:27 --> Model Class Initialized
INFO - 2019-11-09 09:10:27 --> Database Driver Class Initialized
INFO - 2019-11-09 09:10:27 --> Model Class Initialized
DEBUG - 2019-11-09 09:10:27 --> Template Class Initialized
INFO - 2019-11-09 09:10:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:10:27 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:10:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:10:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:10:27 --> Encryption Class Initialized
INFO - 2019-11-09 09:10:27 --> Controller Class Initialized
DEBUG - 2019-11-09 09:10:27 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:10:27 --> Model Class Initialized
DEBUG - 2019-11-09 09:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:10:27 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/redirect.php
INFO - 2019-11-09 09:10:27 --> Final output sent to browser
DEBUG - 2019-11-09 09:10:27 --> Total execution time: 0.5720
INFO - 2019-11-09 09:17:25 --> Config Class Initialized
INFO - 2019-11-09 09:17:25 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:17:25 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:17:25 --> Utf8 Class Initialized
INFO - 2019-11-09 09:17:25 --> URI Class Initialized
INFO - 2019-11-09 09:17:25 --> Router Class Initialized
INFO - 2019-11-09 09:17:25 --> Output Class Initialized
INFO - 2019-11-09 09:17:25 --> Security Class Initialized
DEBUG - 2019-11-09 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:17:25 --> Input Class Initialized
INFO - 2019-11-09 09:17:25 --> Language Class Initialized
INFO - 2019-11-09 09:17:25 --> Language Class Initialized
INFO - 2019-11-09 09:17:25 --> Config Class Initialized
INFO - 2019-11-09 09:17:25 --> Loader Class Initialized
INFO - 2019-11-09 09:17:25 --> Helper loaded: url_helper
INFO - 2019-11-09 09:17:25 --> Helper loaded: common_helper
INFO - 2019-11-09 09:17:25 --> Helper loaded: language_helper
INFO - 2019-11-09 09:17:25 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:17:25 --> Helper loaded: email_helper
INFO - 2019-11-09 09:17:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:17:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:17:25 --> Parser Class Initialized
INFO - 2019-11-09 09:17:25 --> User Agent Class Initialized
INFO - 2019-11-09 09:17:25 --> Model Class Initialized
INFO - 2019-11-09 09:17:25 --> Database Driver Class Initialized
INFO - 2019-11-09 09:17:25 --> Model Class Initialized
DEBUG - 2019-11-09 09:17:25 --> Template Class Initialized
INFO - 2019-11-09 09:17:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:17:25 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:17:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:17:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:17:26 --> Encryption Class Initialized
INFO - 2019-11-09 09:17:26 --> Controller Class Initialized
DEBUG - 2019-11-09 09:17:26 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:17:26 --> Model Class Initialized
DEBUG - 2019-11-09 09:17:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:17:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:17:26 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:17:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:17:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/redirect.php
INFO - 2019-11-09 09:17:26 --> Final output sent to browser
DEBUG - 2019-11-09 09:17:26 --> Total execution time: 0.5544
INFO - 2019-11-09 09:19:36 --> Config Class Initialized
INFO - 2019-11-09 09:19:36 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:19:36 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:19:36 --> Utf8 Class Initialized
INFO - 2019-11-09 09:19:36 --> URI Class Initialized
INFO - 2019-11-09 09:19:36 --> Router Class Initialized
INFO - 2019-11-09 09:19:36 --> Output Class Initialized
INFO - 2019-11-09 09:19:36 --> Security Class Initialized
DEBUG - 2019-11-09 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:19:36 --> Input Class Initialized
INFO - 2019-11-09 09:19:36 --> Language Class Initialized
INFO - 2019-11-09 09:19:36 --> Language Class Initialized
INFO - 2019-11-09 09:19:36 --> Config Class Initialized
INFO - 2019-11-09 09:19:36 --> Loader Class Initialized
INFO - 2019-11-09 09:19:36 --> Helper loaded: url_helper
INFO - 2019-11-09 09:19:36 --> Helper loaded: common_helper
INFO - 2019-11-09 09:19:36 --> Helper loaded: language_helper
INFO - 2019-11-09 09:19:37 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:19:37 --> Helper loaded: email_helper
INFO - 2019-11-09 09:19:37 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:19:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:19:37 --> Parser Class Initialized
INFO - 2019-11-09 09:19:37 --> User Agent Class Initialized
INFO - 2019-11-09 09:19:37 --> Model Class Initialized
INFO - 2019-11-09 09:19:37 --> Database Driver Class Initialized
INFO - 2019-11-09 09:19:37 --> Model Class Initialized
DEBUG - 2019-11-09 09:19:37 --> Template Class Initialized
INFO - 2019-11-09 09:19:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:19:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:19:37 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:19:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:19:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:19:37 --> Encryption Class Initialized
INFO - 2019-11-09 09:19:37 --> Controller Class Initialized
DEBUG - 2019-11-09 09:19:37 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:19:37 --> Model Class Initialized
DEBUG - 2019-11-09 09:19:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:19:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:19:37 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:19:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:19:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:19:37 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:19:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:19:37 --> Model Class Initialized
DEBUG - 2019-11-09 09:19:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:19:37 --> Model Class Initialized
DEBUG - 2019-11-09 09:19:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:19:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:19:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:19:37 --> Final output sent to browser
DEBUG - 2019-11-09 09:19:37 --> Total execution time: 0.7129
INFO - 2019-11-09 09:20:04 --> Config Class Initialized
INFO - 2019-11-09 09:20:04 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:20:04 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:20:04 --> Utf8 Class Initialized
INFO - 2019-11-09 09:20:04 --> URI Class Initialized
INFO - 2019-11-09 09:20:04 --> Router Class Initialized
INFO - 2019-11-09 09:20:04 --> Output Class Initialized
INFO - 2019-11-09 09:20:04 --> Security Class Initialized
DEBUG - 2019-11-09 09:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:20:05 --> CSRF cookie sent
INFO - 2019-11-09 09:20:05 --> CSRF token verified
INFO - 2019-11-09 09:20:05 --> Input Class Initialized
INFO - 2019-11-09 09:20:05 --> Language Class Initialized
INFO - 2019-11-09 09:20:05 --> Language Class Initialized
INFO - 2019-11-09 09:20:05 --> Config Class Initialized
INFO - 2019-11-09 09:20:05 --> Loader Class Initialized
INFO - 2019-11-09 09:20:05 --> Helper loaded: url_helper
INFO - 2019-11-09 09:20:05 --> Helper loaded: common_helper
INFO - 2019-11-09 09:20:05 --> Helper loaded: language_helper
INFO - 2019-11-09 09:20:05 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:20:05 --> Helper loaded: email_helper
INFO - 2019-11-09 09:20:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:20:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:20:05 --> Parser Class Initialized
INFO - 2019-11-09 09:20:05 --> User Agent Class Initialized
INFO - 2019-11-09 09:20:05 --> Model Class Initialized
INFO - 2019-11-09 09:20:05 --> Database Driver Class Initialized
INFO - 2019-11-09 09:20:05 --> Model Class Initialized
DEBUG - 2019-11-09 09:20:05 --> Template Class Initialized
INFO - 2019-11-09 09:20:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:20:05 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:20:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:20:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:20:05 --> Encryption Class Initialized
INFO - 2019-11-09 09:20:05 --> Controller Class Initialized
DEBUG - 2019-11-09 09:20:05 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 09:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 09:20:05 --> Model Class Initialized
INFO - 2019-11-09 09:20:05 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 09:20:05 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 09:20:05 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 09:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 09:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:20:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:20:05 --> Model Class Initialized
DEBUG - 2019-11-09 09:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:20:05 --> Model Class Initialized
DEBUG - 2019-11-09 09:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:20:05 --> Final output sent to browser
DEBUG - 2019-11-09 09:20:05 --> Total execution time: 0.8521
INFO - 2019-11-09 09:20:20 --> Config Class Initialized
INFO - 2019-11-09 09:20:20 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:20:20 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:20:20 --> Utf8 Class Initialized
INFO - 2019-11-09 09:20:20 --> URI Class Initialized
INFO - 2019-11-09 09:20:20 --> Router Class Initialized
INFO - 2019-11-09 09:20:20 --> Output Class Initialized
INFO - 2019-11-09 09:20:20 --> Security Class Initialized
DEBUG - 2019-11-09 09:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:20:20 --> CSRF cookie sent
INFO - 2019-11-09 09:20:20 --> CSRF token verified
INFO - 2019-11-09 09:20:20 --> Input Class Initialized
INFO - 2019-11-09 09:20:20 --> Language Class Initialized
INFO - 2019-11-09 09:20:20 --> Language Class Initialized
INFO - 2019-11-09 09:20:20 --> Config Class Initialized
INFO - 2019-11-09 09:20:20 --> Loader Class Initialized
INFO - 2019-11-09 09:20:20 --> Helper loaded: url_helper
INFO - 2019-11-09 09:20:20 --> Helper loaded: common_helper
INFO - 2019-11-09 09:20:20 --> Helper loaded: language_helper
INFO - 2019-11-09 09:20:20 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:20:20 --> Helper loaded: email_helper
INFO - 2019-11-09 09:20:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:20:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:20:20 --> Parser Class Initialized
INFO - 2019-11-09 09:20:20 --> User Agent Class Initialized
INFO - 2019-11-09 09:20:20 --> Model Class Initialized
INFO - 2019-11-09 09:20:20 --> Database Driver Class Initialized
INFO - 2019-11-09 09:20:20 --> Model Class Initialized
DEBUG - 2019-11-09 09:20:20 --> Template Class Initialized
INFO - 2019-11-09 09:20:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:20:20 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:20:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:20:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:20:20 --> Encryption Class Initialized
INFO - 2019-11-09 09:20:20 --> Controller Class Initialized
DEBUG - 2019-11-09 09:20:20 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 09:20:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 09:20:20 --> Model Class Initialized
DEBUG - 2019-11-09 09:20:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 09:20:20 --> Final output sent to browser
DEBUG - 2019-11-09 09:20:20 --> Total execution time: 0.5322
INFO - 2019-11-09 09:20:20 --> Config Class Initialized
INFO - 2019-11-09 09:20:20 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:20:20 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:20:20 --> Utf8 Class Initialized
INFO - 2019-11-09 09:20:20 --> URI Class Initialized
INFO - 2019-11-09 09:20:20 --> Router Class Initialized
INFO - 2019-11-09 09:20:20 --> Output Class Initialized
INFO - 2019-11-09 09:20:20 --> Security Class Initialized
DEBUG - 2019-11-09 09:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:20:20 --> Input Class Initialized
INFO - 2019-11-09 09:20:20 --> Language Class Initialized
INFO - 2019-11-09 09:20:20 --> Language Class Initialized
INFO - 2019-11-09 09:20:20 --> Config Class Initialized
INFO - 2019-11-09 09:20:20 --> Loader Class Initialized
INFO - 2019-11-09 09:20:20 --> Helper loaded: url_helper
INFO - 2019-11-09 09:20:20 --> Helper loaded: common_helper
INFO - 2019-11-09 09:20:21 --> Helper loaded: language_helper
INFO - 2019-11-09 09:20:21 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:20:21 --> Helper loaded: email_helper
INFO - 2019-11-09 09:20:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:20:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:20:21 --> Parser Class Initialized
INFO - 2019-11-09 09:20:21 --> User Agent Class Initialized
INFO - 2019-11-09 09:20:21 --> Model Class Initialized
INFO - 2019-11-09 09:20:21 --> Database Driver Class Initialized
INFO - 2019-11-09 09:20:21 --> Model Class Initialized
DEBUG - 2019-11-09 09:20:21 --> Template Class Initialized
INFO - 2019-11-09 09:20:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:20:21 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:20:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:20:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:20:21 --> Encryption Class Initialized
INFO - 2019-11-09 09:20:21 --> Controller Class Initialized
DEBUG - 2019-11-09 09:20:21 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:20:21 --> Model Class Initialized
DEBUG - 2019-11-09 09:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:20:21 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:20:21 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:20:21 --> Model Class Initialized
DEBUG - 2019-11-09 09:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:20:21 --> Model Class Initialized
DEBUG - 2019-11-09 09:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:20:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:20:21 --> Final output sent to browser
DEBUG - 2019-11-09 09:20:21 --> Total execution time: 0.7134
INFO - 2019-11-09 09:21:35 --> Config Class Initialized
INFO - 2019-11-09 09:21:35 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:21:35 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:21:35 --> Utf8 Class Initialized
INFO - 2019-11-09 09:21:35 --> URI Class Initialized
INFO - 2019-11-09 09:21:35 --> Router Class Initialized
INFO - 2019-11-09 09:21:35 --> Output Class Initialized
INFO - 2019-11-09 09:21:35 --> Security Class Initialized
DEBUG - 2019-11-09 09:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:21:35 --> Input Class Initialized
INFO - 2019-11-09 09:21:35 --> Language Class Initialized
INFO - 2019-11-09 09:21:35 --> Language Class Initialized
INFO - 2019-11-09 09:21:35 --> Config Class Initialized
INFO - 2019-11-09 09:21:35 --> Loader Class Initialized
INFO - 2019-11-09 09:21:35 --> Helper loaded: url_helper
INFO - 2019-11-09 09:21:35 --> Helper loaded: common_helper
INFO - 2019-11-09 09:21:35 --> Helper loaded: language_helper
INFO - 2019-11-09 09:21:35 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:21:35 --> Helper loaded: email_helper
INFO - 2019-11-09 09:21:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:21:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:21:35 --> Parser Class Initialized
INFO - 2019-11-09 09:21:35 --> User Agent Class Initialized
INFO - 2019-11-09 09:21:35 --> Model Class Initialized
INFO - 2019-11-09 09:21:35 --> Database Driver Class Initialized
INFO - 2019-11-09 09:21:35 --> Model Class Initialized
DEBUG - 2019-11-09 09:21:35 --> Template Class Initialized
INFO - 2019-11-09 09:21:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:21:35 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:21:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:21:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:21:35 --> Encryption Class Initialized
INFO - 2019-11-09 09:21:35 --> Controller Class Initialized
DEBUG - 2019-11-09 09:21:35 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:21:35 --> Model Class Initialized
DEBUG - 2019-11-09 09:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:21:35 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:21:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:21:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:21:36 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:21:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:21:36 --> Model Class Initialized
DEBUG - 2019-11-09 09:21:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:21:36 --> Model Class Initialized
DEBUG - 2019-11-09 09:21:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:21:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:21:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:21:36 --> Final output sent to browser
DEBUG - 2019-11-09 09:21:36 --> Total execution time: 0.7141
INFO - 2019-11-09 09:22:46 --> Config Class Initialized
INFO - 2019-11-09 09:22:46 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:22:46 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:22:46 --> Utf8 Class Initialized
INFO - 2019-11-09 09:22:46 --> URI Class Initialized
INFO - 2019-11-09 09:22:46 --> Router Class Initialized
INFO - 2019-11-09 09:22:46 --> Output Class Initialized
INFO - 2019-11-09 09:22:46 --> Security Class Initialized
DEBUG - 2019-11-09 09:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:22:46 --> Input Class Initialized
INFO - 2019-11-09 09:22:46 --> Language Class Initialized
INFO - 2019-11-09 09:22:46 --> Language Class Initialized
INFO - 2019-11-09 09:22:46 --> Config Class Initialized
INFO - 2019-11-09 09:22:46 --> Loader Class Initialized
INFO - 2019-11-09 09:22:46 --> Helper loaded: url_helper
INFO - 2019-11-09 09:22:46 --> Helper loaded: common_helper
INFO - 2019-11-09 09:22:46 --> Helper loaded: language_helper
INFO - 2019-11-09 09:22:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:22:46 --> Helper loaded: email_helper
INFO - 2019-11-09 09:22:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:22:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:22:46 --> Parser Class Initialized
INFO - 2019-11-09 09:22:46 --> User Agent Class Initialized
INFO - 2019-11-09 09:22:46 --> Model Class Initialized
INFO - 2019-11-09 09:22:46 --> Database Driver Class Initialized
INFO - 2019-11-09 09:22:46 --> Model Class Initialized
DEBUG - 2019-11-09 09:22:46 --> Template Class Initialized
INFO - 2019-11-09 09:22:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:22:46 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:22:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:22:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:22:46 --> Encryption Class Initialized
INFO - 2019-11-09 09:22:46 --> Controller Class Initialized
DEBUG - 2019-11-09 09:22:46 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:22:46 --> Model Class Initialized
DEBUG - 2019-11-09 09:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:22:46 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:22:46 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:22:46 --> Model Class Initialized
DEBUG - 2019-11-09 09:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:22:46 --> Model Class Initialized
DEBUG - 2019-11-09 09:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:22:46 --> Final output sent to browser
DEBUG - 2019-11-09 09:22:46 --> Total execution time: 0.7608
INFO - 2019-11-09 09:25:16 --> Config Class Initialized
INFO - 2019-11-09 09:25:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:25:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:25:16 --> Utf8 Class Initialized
INFO - 2019-11-09 09:25:16 --> URI Class Initialized
INFO - 2019-11-09 09:25:16 --> Router Class Initialized
INFO - 2019-11-09 09:25:16 --> Output Class Initialized
INFO - 2019-11-09 09:25:16 --> Security Class Initialized
DEBUG - 2019-11-09 09:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:25:16 --> Input Class Initialized
INFO - 2019-11-09 09:25:16 --> Language Class Initialized
INFO - 2019-11-09 09:25:16 --> Language Class Initialized
INFO - 2019-11-09 09:25:16 --> Config Class Initialized
INFO - 2019-11-09 09:25:16 --> Loader Class Initialized
INFO - 2019-11-09 09:25:16 --> Helper loaded: url_helper
INFO - 2019-11-09 09:25:16 --> Helper loaded: common_helper
INFO - 2019-11-09 09:25:16 --> Helper loaded: language_helper
INFO - 2019-11-09 09:25:16 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:25:16 --> Helper loaded: email_helper
INFO - 2019-11-09 09:25:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:25:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:25:16 --> Parser Class Initialized
INFO - 2019-11-09 09:25:16 --> User Agent Class Initialized
INFO - 2019-11-09 09:25:16 --> Model Class Initialized
INFO - 2019-11-09 09:25:16 --> Database Driver Class Initialized
INFO - 2019-11-09 09:25:16 --> Model Class Initialized
DEBUG - 2019-11-09 09:25:16 --> Template Class Initialized
INFO - 2019-11-09 09:25:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:25:16 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:25:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:25:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:25:16 --> Encryption Class Initialized
INFO - 2019-11-09 09:25:16 --> Controller Class Initialized
DEBUG - 2019-11-09 09:25:16 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:25:16 --> Model Class Initialized
DEBUG - 2019-11-09 09:25:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:25:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:25:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:25:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:25:17 --> Model Class Initialized
DEBUG - 2019-11-09 09:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:25:17 --> Model Class Initialized
DEBUG - 2019-11-09 09:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:25:17 --> Final output sent to browser
DEBUG - 2019-11-09 09:25:17 --> Total execution time: 0.7133
INFO - 2019-11-09 09:26:59 --> Config Class Initialized
INFO - 2019-11-09 09:26:59 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:26:59 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:26:59 --> Utf8 Class Initialized
INFO - 2019-11-09 09:26:59 --> URI Class Initialized
INFO - 2019-11-09 09:26:59 --> Router Class Initialized
INFO - 2019-11-09 09:26:59 --> Output Class Initialized
INFO - 2019-11-09 09:26:59 --> Security Class Initialized
DEBUG - 2019-11-09 09:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:26:59 --> Input Class Initialized
INFO - 2019-11-09 09:26:59 --> Language Class Initialized
INFO - 2019-11-09 09:26:59 --> Language Class Initialized
INFO - 2019-11-09 09:26:59 --> Config Class Initialized
INFO - 2019-11-09 09:26:59 --> Loader Class Initialized
INFO - 2019-11-09 09:26:59 --> Helper loaded: url_helper
INFO - 2019-11-09 09:26:59 --> Helper loaded: common_helper
INFO - 2019-11-09 09:26:59 --> Helper loaded: language_helper
INFO - 2019-11-09 09:26:59 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:26:59 --> Helper loaded: email_helper
INFO - 2019-11-09 09:27:00 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:27:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:27:00 --> Parser Class Initialized
INFO - 2019-11-09 09:27:00 --> User Agent Class Initialized
INFO - 2019-11-09 09:27:00 --> Model Class Initialized
INFO - 2019-11-09 09:27:00 --> Database Driver Class Initialized
INFO - 2019-11-09 09:27:00 --> Model Class Initialized
DEBUG - 2019-11-09 09:27:00 --> Template Class Initialized
INFO - 2019-11-09 09:27:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:27:00 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:27:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:27:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:27:00 --> Encryption Class Initialized
INFO - 2019-11-09 09:27:00 --> Controller Class Initialized
DEBUG - 2019-11-09 09:27:00 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:27:00 --> Model Class Initialized
DEBUG - 2019-11-09 09:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:27:00 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 09:27:00 --> Severity: Notice --> Undefined index: body D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 65
DEBUG - 2019-11-09 09:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:27:00 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:27:00 --> Model Class Initialized
DEBUG - 2019-11-09 09:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:27:00 --> Model Class Initialized
DEBUG - 2019-11-09 09:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:27:00 --> Final output sent to browser
DEBUG - 2019-11-09 09:27:00 --> Total execution time: 0.7952
INFO - 2019-11-09 09:27:49 --> Config Class Initialized
INFO - 2019-11-09 09:27:49 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:27:49 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:27:49 --> Utf8 Class Initialized
INFO - 2019-11-09 09:27:49 --> URI Class Initialized
INFO - 2019-11-09 09:27:49 --> Router Class Initialized
INFO - 2019-11-09 09:27:49 --> Output Class Initialized
INFO - 2019-11-09 09:27:49 --> Security Class Initialized
DEBUG - 2019-11-09 09:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:27:49 --> Input Class Initialized
INFO - 2019-11-09 09:27:49 --> Language Class Initialized
INFO - 2019-11-09 09:27:49 --> Language Class Initialized
INFO - 2019-11-09 09:27:49 --> Config Class Initialized
INFO - 2019-11-09 09:27:49 --> Loader Class Initialized
INFO - 2019-11-09 09:27:49 --> Helper loaded: url_helper
INFO - 2019-11-09 09:27:49 --> Helper loaded: common_helper
INFO - 2019-11-09 09:27:49 --> Helper loaded: language_helper
INFO - 2019-11-09 09:27:49 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:27:49 --> Helper loaded: email_helper
INFO - 2019-11-09 09:27:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:27:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:27:49 --> Parser Class Initialized
INFO - 2019-11-09 09:27:49 --> User Agent Class Initialized
INFO - 2019-11-09 09:27:49 --> Model Class Initialized
INFO - 2019-11-09 09:27:49 --> Database Driver Class Initialized
INFO - 2019-11-09 09:27:49 --> Model Class Initialized
DEBUG - 2019-11-09 09:27:49 --> Template Class Initialized
INFO - 2019-11-09 09:27:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:27:49 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:27:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:27:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:27:49 --> Encryption Class Initialized
INFO - 2019-11-09 09:27:49 --> Controller Class Initialized
DEBUG - 2019-11-09 09:27:49 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:27:49 --> Model Class Initialized
DEBUG - 2019-11-09 09:27:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:27:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:27:49 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:27:50 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:27:50 --> Model Class Initialized
DEBUG - 2019-11-09 09:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:27:50 --> Model Class Initialized
DEBUG - 2019-11-09 09:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:27:50 --> Final output sent to browser
DEBUG - 2019-11-09 09:27:50 --> Total execution time: 0.7624
INFO - 2019-11-09 09:29:18 --> Config Class Initialized
INFO - 2019-11-09 09:29:18 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:29:18 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:29:18 --> Utf8 Class Initialized
INFO - 2019-11-09 09:29:18 --> URI Class Initialized
INFO - 2019-11-09 09:29:18 --> Router Class Initialized
INFO - 2019-11-09 09:29:18 --> Output Class Initialized
INFO - 2019-11-09 09:29:18 --> Security Class Initialized
DEBUG - 2019-11-09 09:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:29:18 --> Input Class Initialized
INFO - 2019-11-09 09:29:18 --> Language Class Initialized
INFO - 2019-11-09 09:29:18 --> Language Class Initialized
INFO - 2019-11-09 09:29:18 --> Config Class Initialized
INFO - 2019-11-09 09:29:18 --> Loader Class Initialized
INFO - 2019-11-09 09:29:18 --> Helper loaded: url_helper
INFO - 2019-11-09 09:29:18 --> Helper loaded: common_helper
INFO - 2019-11-09 09:29:18 --> Helper loaded: language_helper
INFO - 2019-11-09 09:29:18 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:29:18 --> Helper loaded: email_helper
INFO - 2019-11-09 09:29:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:29:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:29:19 --> Parser Class Initialized
INFO - 2019-11-09 09:29:19 --> User Agent Class Initialized
INFO - 2019-11-09 09:29:19 --> Model Class Initialized
INFO - 2019-11-09 09:29:19 --> Database Driver Class Initialized
INFO - 2019-11-09 09:29:19 --> Model Class Initialized
DEBUG - 2019-11-09 09:29:19 --> Template Class Initialized
INFO - 2019-11-09 09:29:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:29:19 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:29:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:29:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:29:19 --> Encryption Class Initialized
INFO - 2019-11-09 09:29:19 --> Controller Class Initialized
DEBUG - 2019-11-09 09:29:19 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:29:19 --> Model Class Initialized
DEBUG - 2019-11-09 09:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:29:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:29:19 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:29:19 --> Model Class Initialized
DEBUG - 2019-11-09 09:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:29:19 --> Model Class Initialized
DEBUG - 2019-11-09 09:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:29:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:29:19 --> Final output sent to browser
DEBUG - 2019-11-09 09:29:19 --> Total execution time: 0.7834
INFO - 2019-11-09 09:30:08 --> Config Class Initialized
INFO - 2019-11-09 09:30:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:30:09 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:30:09 --> Utf8 Class Initialized
INFO - 2019-11-09 09:30:09 --> URI Class Initialized
INFO - 2019-11-09 09:30:09 --> Router Class Initialized
INFO - 2019-11-09 09:30:09 --> Output Class Initialized
INFO - 2019-11-09 09:30:09 --> Security Class Initialized
DEBUG - 2019-11-09 09:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:30:09 --> Input Class Initialized
INFO - 2019-11-09 09:30:09 --> Language Class Initialized
INFO - 2019-11-09 09:30:09 --> Language Class Initialized
INFO - 2019-11-09 09:30:09 --> Config Class Initialized
INFO - 2019-11-09 09:30:09 --> Loader Class Initialized
INFO - 2019-11-09 09:30:09 --> Helper loaded: url_helper
INFO - 2019-11-09 09:30:09 --> Helper loaded: common_helper
INFO - 2019-11-09 09:30:09 --> Helper loaded: language_helper
INFO - 2019-11-09 09:30:09 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:30:09 --> Helper loaded: email_helper
INFO - 2019-11-09 09:30:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:30:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:30:09 --> Parser Class Initialized
INFO - 2019-11-09 09:30:09 --> User Agent Class Initialized
INFO - 2019-11-09 09:30:09 --> Model Class Initialized
INFO - 2019-11-09 09:30:09 --> Database Driver Class Initialized
INFO - 2019-11-09 09:30:09 --> Model Class Initialized
DEBUG - 2019-11-09 09:30:09 --> Template Class Initialized
INFO - 2019-11-09 09:30:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:30:09 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:30:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:30:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:30:09 --> Encryption Class Initialized
INFO - 2019-11-09 09:30:09 --> Controller Class Initialized
DEBUG - 2019-11-09 09:30:09 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:30:09 --> Model Class Initialized
DEBUG - 2019-11-09 09:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:30:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:30:09 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:30:09 --> Model Class Initialized
DEBUG - 2019-11-09 09:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:30:09 --> Model Class Initialized
DEBUG - 2019-11-09 09:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:30:09 --> Final output sent to browser
DEBUG - 2019-11-09 09:30:09 --> Total execution time: 0.9006
INFO - 2019-11-09 09:30:43 --> Config Class Initialized
INFO - 2019-11-09 09:30:43 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:30:43 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:30:43 --> Utf8 Class Initialized
INFO - 2019-11-09 09:30:43 --> URI Class Initialized
INFO - 2019-11-09 09:30:43 --> Router Class Initialized
INFO - 2019-11-09 09:30:44 --> Output Class Initialized
INFO - 2019-11-09 09:30:44 --> Security Class Initialized
DEBUG - 2019-11-09 09:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:30:44 --> Input Class Initialized
INFO - 2019-11-09 09:30:44 --> Language Class Initialized
INFO - 2019-11-09 09:30:44 --> Language Class Initialized
INFO - 2019-11-09 09:30:44 --> Config Class Initialized
INFO - 2019-11-09 09:30:44 --> Loader Class Initialized
INFO - 2019-11-09 09:30:44 --> Helper loaded: url_helper
INFO - 2019-11-09 09:30:44 --> Helper loaded: common_helper
INFO - 2019-11-09 09:30:44 --> Helper loaded: language_helper
INFO - 2019-11-09 09:30:44 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:30:44 --> Helper loaded: email_helper
INFO - 2019-11-09 09:30:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:30:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:30:44 --> Parser Class Initialized
INFO - 2019-11-09 09:30:44 --> User Agent Class Initialized
INFO - 2019-11-09 09:30:44 --> Model Class Initialized
INFO - 2019-11-09 09:30:44 --> Database Driver Class Initialized
INFO - 2019-11-09 09:30:44 --> Model Class Initialized
DEBUG - 2019-11-09 09:30:44 --> Template Class Initialized
INFO - 2019-11-09 09:30:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:30:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:30:44 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:30:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:30:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:30:44 --> Encryption Class Initialized
INFO - 2019-11-09 09:30:44 --> Controller Class Initialized
DEBUG - 2019-11-09 09:30:44 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:30:44 --> Model Class Initialized
DEBUG - 2019-11-09 09:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:30:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:30:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:30:44 --> Model Class Initialized
DEBUG - 2019-11-09 09:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:30:44 --> Model Class Initialized
DEBUG - 2019-11-09 09:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:30:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:30:44 --> Final output sent to browser
DEBUG - 2019-11-09 09:30:44 --> Total execution time: 0.9116
INFO - 2019-11-09 09:31:23 --> Config Class Initialized
INFO - 2019-11-09 09:31:23 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:31:23 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:31:23 --> Utf8 Class Initialized
INFO - 2019-11-09 09:31:23 --> URI Class Initialized
INFO - 2019-11-09 09:31:23 --> Router Class Initialized
INFO - 2019-11-09 09:31:23 --> Output Class Initialized
INFO - 2019-11-09 09:31:23 --> Security Class Initialized
DEBUG - 2019-11-09 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:31:24 --> Input Class Initialized
INFO - 2019-11-09 09:31:24 --> Language Class Initialized
INFO - 2019-11-09 09:31:24 --> Language Class Initialized
INFO - 2019-11-09 09:31:24 --> Config Class Initialized
INFO - 2019-11-09 09:31:24 --> Loader Class Initialized
INFO - 2019-11-09 09:31:24 --> Helper loaded: url_helper
INFO - 2019-11-09 09:31:24 --> Helper loaded: common_helper
INFO - 2019-11-09 09:31:24 --> Helper loaded: language_helper
INFO - 2019-11-09 09:31:24 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:31:24 --> Helper loaded: email_helper
INFO - 2019-11-09 09:31:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:31:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:31:24 --> Parser Class Initialized
INFO - 2019-11-09 09:31:24 --> User Agent Class Initialized
INFO - 2019-11-09 09:31:24 --> Model Class Initialized
INFO - 2019-11-09 09:31:24 --> Database Driver Class Initialized
INFO - 2019-11-09 09:31:24 --> Model Class Initialized
DEBUG - 2019-11-09 09:31:24 --> Template Class Initialized
INFO - 2019-11-09 09:31:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:31:24 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:31:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:31:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:31:24 --> Encryption Class Initialized
INFO - 2019-11-09 09:31:24 --> Controller Class Initialized
DEBUG - 2019-11-09 09:31:24 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:31:24 --> Model Class Initialized
DEBUG - 2019-11-09 09:31:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:31:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:31:24 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:31:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:31:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:31:24 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:31:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:31:24 --> Model Class Initialized
DEBUG - 2019-11-09 09:31:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:31:24 --> Model Class Initialized
DEBUG - 2019-11-09 09:31:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:31:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:31:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:31:24 --> Final output sent to browser
DEBUG - 2019-11-09 09:31:24 --> Total execution time: 0.8728
INFO - 2019-11-09 09:31:48 --> Config Class Initialized
INFO - 2019-11-09 09:31:48 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:31:49 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:31:49 --> Utf8 Class Initialized
INFO - 2019-11-09 09:31:49 --> URI Class Initialized
INFO - 2019-11-09 09:31:49 --> Router Class Initialized
INFO - 2019-11-09 09:31:49 --> Output Class Initialized
INFO - 2019-11-09 09:31:49 --> Security Class Initialized
DEBUG - 2019-11-09 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:31:49 --> Input Class Initialized
INFO - 2019-11-09 09:31:49 --> Language Class Initialized
INFO - 2019-11-09 09:31:49 --> Language Class Initialized
INFO - 2019-11-09 09:31:49 --> Config Class Initialized
INFO - 2019-11-09 09:31:49 --> Loader Class Initialized
INFO - 2019-11-09 09:31:49 --> Helper loaded: url_helper
INFO - 2019-11-09 09:31:49 --> Helper loaded: common_helper
INFO - 2019-11-09 09:31:49 --> Helper loaded: language_helper
INFO - 2019-11-09 09:31:49 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:31:49 --> Helper loaded: email_helper
INFO - 2019-11-09 09:31:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:31:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:31:49 --> Parser Class Initialized
INFO - 2019-11-09 09:31:49 --> User Agent Class Initialized
INFO - 2019-11-09 09:31:49 --> Model Class Initialized
INFO - 2019-11-09 09:31:49 --> Database Driver Class Initialized
INFO - 2019-11-09 09:31:49 --> Model Class Initialized
DEBUG - 2019-11-09 09:31:49 --> Template Class Initialized
INFO - 2019-11-09 09:31:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:31:49 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:31:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:31:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:31:49 --> Encryption Class Initialized
INFO - 2019-11-09 09:31:49 --> Controller Class Initialized
DEBUG - 2019-11-09 09:31:49 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:31:49 --> Model Class Initialized
DEBUG - 2019-11-09 09:31:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:31:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:31:49 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:31:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:31:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:31:49 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:31:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:31:49 --> Model Class Initialized
DEBUG - 2019-11-09 09:31:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:31:49 --> Model Class Initialized
DEBUG - 2019-11-09 09:31:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:31:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:31:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:31:49 --> Final output sent to browser
DEBUG - 2019-11-09 09:31:49 --> Total execution time: 0.8657
INFO - 2019-11-09 09:32:01 --> Config Class Initialized
INFO - 2019-11-09 09:32:01 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:32:01 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:32:01 --> Utf8 Class Initialized
INFO - 2019-11-09 09:32:01 --> URI Class Initialized
INFO - 2019-11-09 09:32:01 --> Router Class Initialized
INFO - 2019-11-09 09:32:01 --> Output Class Initialized
INFO - 2019-11-09 09:32:01 --> Security Class Initialized
DEBUG - 2019-11-09 09:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:32:01 --> Input Class Initialized
INFO - 2019-11-09 09:32:01 --> Language Class Initialized
INFO - 2019-11-09 09:32:01 --> Language Class Initialized
INFO - 2019-11-09 09:32:01 --> Config Class Initialized
INFO - 2019-11-09 09:32:01 --> Loader Class Initialized
INFO - 2019-11-09 09:32:01 --> Helper loaded: url_helper
INFO - 2019-11-09 09:32:01 --> Helper loaded: common_helper
INFO - 2019-11-09 09:32:01 --> Helper loaded: language_helper
INFO - 2019-11-09 09:32:01 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:32:01 --> Helper loaded: email_helper
INFO - 2019-11-09 09:32:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:32:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:32:01 --> Parser Class Initialized
INFO - 2019-11-09 09:32:01 --> User Agent Class Initialized
INFO - 2019-11-09 09:32:01 --> Model Class Initialized
INFO - 2019-11-09 09:32:01 --> Database Driver Class Initialized
INFO - 2019-11-09 09:32:01 --> Model Class Initialized
DEBUG - 2019-11-09 09:32:01 --> Template Class Initialized
INFO - 2019-11-09 09:32:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:32:01 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:32:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:32:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:32:01 --> Encryption Class Initialized
INFO - 2019-11-09 09:32:01 --> Controller Class Initialized
DEBUG - 2019-11-09 09:32:01 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:32:01 --> Model Class Initialized
DEBUG - 2019-11-09 09:32:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:32:02 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:32:02 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:32:02 --> Model Class Initialized
DEBUG - 2019-11-09 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:32:02 --> Model Class Initialized
DEBUG - 2019-11-09 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:32:02 --> Final output sent to browser
DEBUG - 2019-11-09 09:32:02 --> Total execution time: 0.8955
INFO - 2019-11-09 09:32:20 --> Config Class Initialized
INFO - 2019-11-09 09:32:20 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:32:20 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:32:20 --> Utf8 Class Initialized
INFO - 2019-11-09 09:32:20 --> URI Class Initialized
INFO - 2019-11-09 09:32:20 --> Router Class Initialized
INFO - 2019-11-09 09:32:20 --> Output Class Initialized
INFO - 2019-11-09 09:32:20 --> Security Class Initialized
DEBUG - 2019-11-09 09:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:32:20 --> Input Class Initialized
INFO - 2019-11-09 09:32:20 --> Language Class Initialized
INFO - 2019-11-09 09:32:20 --> Language Class Initialized
INFO - 2019-11-09 09:32:20 --> Config Class Initialized
INFO - 2019-11-09 09:32:20 --> Loader Class Initialized
INFO - 2019-11-09 09:32:20 --> Helper loaded: url_helper
INFO - 2019-11-09 09:32:20 --> Helper loaded: common_helper
INFO - 2019-11-09 09:32:20 --> Helper loaded: language_helper
INFO - 2019-11-09 09:32:20 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:32:20 --> Helper loaded: email_helper
INFO - 2019-11-09 09:32:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:32:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:32:20 --> Parser Class Initialized
INFO - 2019-11-09 09:32:20 --> User Agent Class Initialized
INFO - 2019-11-09 09:32:20 --> Model Class Initialized
INFO - 2019-11-09 09:32:20 --> Database Driver Class Initialized
INFO - 2019-11-09 09:32:20 --> Model Class Initialized
DEBUG - 2019-11-09 09:32:20 --> Template Class Initialized
INFO - 2019-11-09 09:32:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:32:20 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:32:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:32:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:32:20 --> Encryption Class Initialized
INFO - 2019-11-09 09:32:20 --> Controller Class Initialized
DEBUG - 2019-11-09 09:32:20 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:32:20 --> Model Class Initialized
DEBUG - 2019-11-09 09:32:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:32:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:32:20 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:32:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:32:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:32:20 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:32:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:32:20 --> Model Class Initialized
DEBUG - 2019-11-09 09:32:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:32:20 --> Model Class Initialized
DEBUG - 2019-11-09 09:32:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:32:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:32:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:32:21 --> Final output sent to browser
DEBUG - 2019-11-09 09:32:21 --> Total execution time: 0.8466
INFO - 2019-11-09 09:34:26 --> Config Class Initialized
INFO - 2019-11-09 09:34:26 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:34:26 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:34:26 --> Utf8 Class Initialized
INFO - 2019-11-09 09:34:26 --> URI Class Initialized
INFO - 2019-11-09 09:34:26 --> Router Class Initialized
INFO - 2019-11-09 09:34:26 --> Output Class Initialized
INFO - 2019-11-09 09:34:26 --> Security Class Initialized
DEBUG - 2019-11-09 09:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:34:26 --> Input Class Initialized
INFO - 2019-11-09 09:34:26 --> Language Class Initialized
INFO - 2019-11-09 09:34:26 --> Language Class Initialized
INFO - 2019-11-09 09:34:26 --> Config Class Initialized
INFO - 2019-11-09 09:34:26 --> Loader Class Initialized
INFO - 2019-11-09 09:34:26 --> Helper loaded: url_helper
INFO - 2019-11-09 09:34:26 --> Helper loaded: common_helper
INFO - 2019-11-09 09:34:26 --> Helper loaded: language_helper
INFO - 2019-11-09 09:34:26 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:34:26 --> Helper loaded: email_helper
INFO - 2019-11-09 09:34:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:34:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:34:26 --> Parser Class Initialized
INFO - 2019-11-09 09:34:26 --> User Agent Class Initialized
INFO - 2019-11-09 09:34:26 --> Model Class Initialized
INFO - 2019-11-09 09:34:26 --> Database Driver Class Initialized
INFO - 2019-11-09 09:34:26 --> Model Class Initialized
DEBUG - 2019-11-09 09:34:26 --> Template Class Initialized
INFO - 2019-11-09 09:34:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:34:26 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:34:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:34:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:34:26 --> Encryption Class Initialized
INFO - 2019-11-09 09:34:26 --> Controller Class Initialized
DEBUG - 2019-11-09 09:34:26 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:34:26 --> Model Class Initialized
DEBUG - 2019-11-09 09:34:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:34:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:34:26 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:34:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:34:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:34:26 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:34:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:34:27 --> Model Class Initialized
DEBUG - 2019-11-09 09:34:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:34:27 --> Model Class Initialized
DEBUG - 2019-11-09 09:34:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:34:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:34:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:34:27 --> Final output sent to browser
DEBUG - 2019-11-09 09:34:27 --> Total execution time: 0.8246
INFO - 2019-11-09 09:34:51 --> Config Class Initialized
INFO - 2019-11-09 09:34:51 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:34:51 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:34:51 --> Utf8 Class Initialized
INFO - 2019-11-09 09:34:51 --> URI Class Initialized
INFO - 2019-11-09 09:34:51 --> Router Class Initialized
INFO - 2019-11-09 09:34:51 --> Output Class Initialized
INFO - 2019-11-09 09:34:51 --> Security Class Initialized
DEBUG - 2019-11-09 09:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:34:51 --> Input Class Initialized
INFO - 2019-11-09 09:34:51 --> Language Class Initialized
INFO - 2019-11-09 09:34:51 --> Language Class Initialized
INFO - 2019-11-09 09:34:51 --> Config Class Initialized
INFO - 2019-11-09 09:34:51 --> Loader Class Initialized
INFO - 2019-11-09 09:34:51 --> Helper loaded: url_helper
INFO - 2019-11-09 09:34:51 --> Helper loaded: common_helper
INFO - 2019-11-09 09:34:51 --> Helper loaded: language_helper
INFO - 2019-11-09 09:34:51 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:34:51 --> Helper loaded: email_helper
INFO - 2019-11-09 09:34:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:34:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:34:51 --> Parser Class Initialized
INFO - 2019-11-09 09:34:51 --> User Agent Class Initialized
INFO - 2019-11-09 09:34:51 --> Model Class Initialized
INFO - 2019-11-09 09:34:51 --> Database Driver Class Initialized
INFO - 2019-11-09 09:34:51 --> Model Class Initialized
DEBUG - 2019-11-09 09:34:51 --> Template Class Initialized
INFO - 2019-11-09 09:34:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:34:51 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:34:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:34:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:34:51 --> Encryption Class Initialized
INFO - 2019-11-09 09:34:51 --> Controller Class Initialized
DEBUG - 2019-11-09 09:34:51 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:34:51 --> Model Class Initialized
DEBUG - 2019-11-09 09:34:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:34:52 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:34:52 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:34:52 --> Model Class Initialized
DEBUG - 2019-11-09 09:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:34:52 --> Model Class Initialized
DEBUG - 2019-11-09 09:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:34:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:34:52 --> Final output sent to browser
DEBUG - 2019-11-09 09:34:52 --> Total execution time: 0.8576
INFO - 2019-11-09 09:36:46 --> Config Class Initialized
INFO - 2019-11-09 09:36:46 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:36:46 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:36:46 --> Utf8 Class Initialized
INFO - 2019-11-09 09:36:46 --> URI Class Initialized
INFO - 2019-11-09 09:36:46 --> Router Class Initialized
INFO - 2019-11-09 09:36:46 --> Output Class Initialized
INFO - 2019-11-09 09:36:46 --> Security Class Initialized
DEBUG - 2019-11-09 09:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:36:46 --> Input Class Initialized
INFO - 2019-11-09 09:36:46 --> Language Class Initialized
INFO - 2019-11-09 09:36:46 --> Language Class Initialized
INFO - 2019-11-09 09:36:46 --> Config Class Initialized
INFO - 2019-11-09 09:36:46 --> Loader Class Initialized
INFO - 2019-11-09 09:36:46 --> Helper loaded: url_helper
INFO - 2019-11-09 09:36:46 --> Helper loaded: common_helper
INFO - 2019-11-09 09:36:46 --> Helper loaded: language_helper
INFO - 2019-11-09 09:36:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:36:46 --> Helper loaded: email_helper
INFO - 2019-11-09 09:36:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:36:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:36:47 --> Parser Class Initialized
INFO - 2019-11-09 09:36:47 --> User Agent Class Initialized
INFO - 2019-11-09 09:36:47 --> Model Class Initialized
INFO - 2019-11-09 09:36:47 --> Database Driver Class Initialized
INFO - 2019-11-09 09:36:47 --> Model Class Initialized
DEBUG - 2019-11-09 09:36:47 --> Template Class Initialized
INFO - 2019-11-09 09:36:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:36:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:36:47 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:36:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:36:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:36:47 --> Encryption Class Initialized
INFO - 2019-11-09 09:36:47 --> Controller Class Initialized
DEBUG - 2019-11-09 09:36:47 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:36:47 --> Model Class Initialized
DEBUG - 2019-11-09 09:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:36:47 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:36:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:36:47 --> Model Class Initialized
DEBUG - 2019-11-09 09:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:36:47 --> Model Class Initialized
DEBUG - 2019-11-09 09:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:36:47 --> Final output sent to browser
DEBUG - 2019-11-09 09:36:47 --> Total execution time: 0.8377
INFO - 2019-11-09 09:37:00 --> Config Class Initialized
INFO - 2019-11-09 09:37:00 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:37:00 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:37:00 --> Utf8 Class Initialized
INFO - 2019-11-09 09:37:00 --> URI Class Initialized
INFO - 2019-11-09 09:37:00 --> Router Class Initialized
INFO - 2019-11-09 09:37:00 --> Output Class Initialized
INFO - 2019-11-09 09:37:00 --> Security Class Initialized
DEBUG - 2019-11-09 09:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:37:00 --> Input Class Initialized
INFO - 2019-11-09 09:37:00 --> Language Class Initialized
INFO - 2019-11-09 09:37:00 --> Language Class Initialized
INFO - 2019-11-09 09:37:00 --> Config Class Initialized
INFO - 2019-11-09 09:37:00 --> Loader Class Initialized
INFO - 2019-11-09 09:37:00 --> Helper loaded: url_helper
INFO - 2019-11-09 09:37:00 --> Helper loaded: common_helper
INFO - 2019-11-09 09:37:00 --> Helper loaded: language_helper
INFO - 2019-11-09 09:37:00 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:37:00 --> Helper loaded: email_helper
INFO - 2019-11-09 09:37:00 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:37:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:37:00 --> Parser Class Initialized
INFO - 2019-11-09 09:37:00 --> User Agent Class Initialized
INFO - 2019-11-09 09:37:00 --> Model Class Initialized
INFO - 2019-11-09 09:37:00 --> Database Driver Class Initialized
INFO - 2019-11-09 09:37:00 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:00 --> Template Class Initialized
INFO - 2019-11-09 09:37:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:37:00 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:37:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:37:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:37:00 --> Encryption Class Initialized
INFO - 2019-11-09 09:37:00 --> Controller Class Initialized
DEBUG - 2019-11-09 09:37:00 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:37:00 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:37:00 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:37:00 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:37:00 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:37:00 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:37:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:37:00 --> Final output sent to browser
DEBUG - 2019-11-09 09:37:00 --> Total execution time: 0.8338
INFO - 2019-11-09 09:37:15 --> Config Class Initialized
INFO - 2019-11-09 09:37:15 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:37:15 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:37:15 --> Utf8 Class Initialized
INFO - 2019-11-09 09:37:15 --> URI Class Initialized
INFO - 2019-11-09 09:37:16 --> Router Class Initialized
INFO - 2019-11-09 09:37:16 --> Output Class Initialized
INFO - 2019-11-09 09:37:16 --> Security Class Initialized
DEBUG - 2019-11-09 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:37:16 --> CSRF cookie sent
INFO - 2019-11-09 09:37:16 --> CSRF token verified
INFO - 2019-11-09 09:37:16 --> Input Class Initialized
INFO - 2019-11-09 09:37:16 --> Language Class Initialized
INFO - 2019-11-09 09:37:16 --> Language Class Initialized
INFO - 2019-11-09 09:37:16 --> Config Class Initialized
INFO - 2019-11-09 09:37:16 --> Loader Class Initialized
INFO - 2019-11-09 09:37:16 --> Helper loaded: url_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: common_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: language_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: email_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:37:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:37:16 --> Parser Class Initialized
INFO - 2019-11-09 09:37:16 --> User Agent Class Initialized
INFO - 2019-11-09 09:37:16 --> Model Class Initialized
INFO - 2019-11-09 09:37:16 --> Database Driver Class Initialized
INFO - 2019-11-09 09:37:16 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:16 --> Template Class Initialized
INFO - 2019-11-09 09:37:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:37:16 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:37:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:37:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:37:16 --> Encryption Class Initialized
INFO - 2019-11-09 09:37:16 --> Controller Class Initialized
DEBUG - 2019-11-09 09:37:16 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 09:37:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 09:37:16 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/index.php
INFO - 2019-11-09 09:37:16 --> Final output sent to browser
DEBUG - 2019-11-09 09:37:16 --> Total execution time: 0.6069
INFO - 2019-11-09 09:37:16 --> Config Class Initialized
INFO - 2019-11-09 09:37:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:37:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:37:16 --> Utf8 Class Initialized
INFO - 2019-11-09 09:37:16 --> URI Class Initialized
INFO - 2019-11-09 09:37:16 --> Router Class Initialized
INFO - 2019-11-09 09:37:16 --> Output Class Initialized
INFO - 2019-11-09 09:37:16 --> Security Class Initialized
DEBUG - 2019-11-09 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:37:16 --> Input Class Initialized
INFO - 2019-11-09 09:37:16 --> Language Class Initialized
INFO - 2019-11-09 09:37:16 --> Language Class Initialized
INFO - 2019-11-09 09:37:16 --> Config Class Initialized
INFO - 2019-11-09 09:37:16 --> Loader Class Initialized
INFO - 2019-11-09 09:37:16 --> Helper loaded: url_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: common_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: language_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: email_helper
INFO - 2019-11-09 09:37:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:37:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:37:16 --> Parser Class Initialized
INFO - 2019-11-09 09:37:16 --> User Agent Class Initialized
INFO - 2019-11-09 09:37:16 --> Model Class Initialized
INFO - 2019-11-09 09:37:16 --> Database Driver Class Initialized
INFO - 2019-11-09 09:37:17 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:17 --> Template Class Initialized
INFO - 2019-11-09 09:37:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:37:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:37:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:37:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:37:17 --> Encryption Class Initialized
INFO - 2019-11-09 09:37:17 --> Controller Class Initialized
DEBUG - 2019-11-09 09:37:17 --> cardinity MX_Controller Initialized
INFO - 2019-11-09 09:37:17 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/cardinity_form.php
INFO - 2019-11-09 09:37:17 --> Final output sent to browser
DEBUG - 2019-11-09 09:37:17 --> Total execution time: 0.5894
INFO - 2019-11-09 09:37:39 --> Config Class Initialized
INFO - 2019-11-09 09:37:39 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:37:39 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:37:39 --> Utf8 Class Initialized
INFO - 2019-11-09 09:37:39 --> URI Class Initialized
INFO - 2019-11-09 09:37:39 --> Router Class Initialized
INFO - 2019-11-09 09:37:39 --> Output Class Initialized
INFO - 2019-11-09 09:37:39 --> Security Class Initialized
DEBUG - 2019-11-09 09:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:37:39 --> CSRF cookie sent
INFO - 2019-11-09 09:37:39 --> CSRF token verified
INFO - 2019-11-09 09:37:39 --> Input Class Initialized
INFO - 2019-11-09 09:37:39 --> Language Class Initialized
INFO - 2019-11-09 09:37:39 --> Language Class Initialized
INFO - 2019-11-09 09:37:39 --> Config Class Initialized
INFO - 2019-11-09 09:37:39 --> Loader Class Initialized
INFO - 2019-11-09 09:37:39 --> Helper loaded: url_helper
INFO - 2019-11-09 09:37:39 --> Helper loaded: common_helper
INFO - 2019-11-09 09:37:39 --> Helper loaded: language_helper
INFO - 2019-11-09 09:37:39 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:37:40 --> Helper loaded: email_helper
INFO - 2019-11-09 09:37:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:37:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:37:40 --> Parser Class Initialized
INFO - 2019-11-09 09:37:40 --> User Agent Class Initialized
INFO - 2019-11-09 09:37:40 --> Model Class Initialized
INFO - 2019-11-09 09:37:40 --> Database Driver Class Initialized
INFO - 2019-11-09 09:37:40 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:40 --> Template Class Initialized
INFO - 2019-11-09 09:37:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:37:40 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:37:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:37:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:37:40 --> Encryption Class Initialized
INFO - 2019-11-09 09:37:40 --> Controller Class Initialized
DEBUG - 2019-11-09 09:37:40 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 09:37:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 09:37:40 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 09:37:40 --> Final output sent to browser
DEBUG - 2019-11-09 09:37:40 --> Total execution time: 0.7298
INFO - 2019-11-09 09:37:40 --> Config Class Initialized
INFO - 2019-11-09 09:37:40 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:37:40 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:37:40 --> Utf8 Class Initialized
INFO - 2019-11-09 09:37:40 --> URI Class Initialized
INFO - 2019-11-09 09:37:40 --> Router Class Initialized
INFO - 2019-11-09 09:37:40 --> Output Class Initialized
INFO - 2019-11-09 09:37:40 --> Security Class Initialized
DEBUG - 2019-11-09 09:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:37:40 --> Input Class Initialized
INFO - 2019-11-09 09:37:40 --> Language Class Initialized
INFO - 2019-11-09 09:37:40 --> Language Class Initialized
INFO - 2019-11-09 09:37:40 --> Config Class Initialized
INFO - 2019-11-09 09:37:40 --> Loader Class Initialized
INFO - 2019-11-09 09:37:40 --> Helper loaded: url_helper
INFO - 2019-11-09 09:37:40 --> Helper loaded: common_helper
INFO - 2019-11-09 09:37:40 --> Helper loaded: language_helper
INFO - 2019-11-09 09:37:40 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:37:40 --> Helper loaded: email_helper
INFO - 2019-11-09 09:37:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:37:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:37:40 --> Parser Class Initialized
INFO - 2019-11-09 09:37:40 --> User Agent Class Initialized
INFO - 2019-11-09 09:37:40 --> Model Class Initialized
INFO - 2019-11-09 09:37:40 --> Database Driver Class Initialized
INFO - 2019-11-09 09:37:40 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:40 --> Template Class Initialized
INFO - 2019-11-09 09:37:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:37:40 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:37:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:37:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:37:40 --> Encryption Class Initialized
INFO - 2019-11-09 09:37:40 --> Controller Class Initialized
DEBUG - 2019-11-09 09:37:40 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:37:40 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:37:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:37:41 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:37:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:37:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:37:41 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:37:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:37:41 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:37:41 --> Model Class Initialized
DEBUG - 2019-11-09 09:37:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:37:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:37:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:37:41 --> Final output sent to browser
DEBUG - 2019-11-09 09:37:41 --> Total execution time: 0.7935
INFO - 2019-11-09 09:38:01 --> Config Class Initialized
INFO - 2019-11-09 09:38:01 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:38:01 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:38:01 --> Utf8 Class Initialized
INFO - 2019-11-09 09:38:01 --> URI Class Initialized
INFO - 2019-11-09 09:38:01 --> Router Class Initialized
INFO - 2019-11-09 09:38:01 --> Output Class Initialized
INFO - 2019-11-09 09:38:01 --> Security Class Initialized
DEBUG - 2019-11-09 09:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:38:01 --> CSRF cookie sent
INFO - 2019-11-09 09:38:01 --> CSRF token verified
INFO - 2019-11-09 09:38:01 --> Input Class Initialized
INFO - 2019-11-09 09:38:01 --> Language Class Initialized
INFO - 2019-11-09 09:38:01 --> Language Class Initialized
INFO - 2019-11-09 09:38:01 --> Config Class Initialized
INFO - 2019-11-09 09:38:01 --> Loader Class Initialized
INFO - 2019-11-09 09:38:01 --> Helper loaded: url_helper
INFO - 2019-11-09 09:38:01 --> Helper loaded: common_helper
INFO - 2019-11-09 09:38:01 --> Helper loaded: language_helper
INFO - 2019-11-09 09:38:01 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:38:01 --> Helper loaded: email_helper
INFO - 2019-11-09 09:38:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:38:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:38:01 --> Parser Class Initialized
INFO - 2019-11-09 09:38:01 --> User Agent Class Initialized
INFO - 2019-11-09 09:38:01 --> Model Class Initialized
INFO - 2019-11-09 09:38:01 --> Database Driver Class Initialized
INFO - 2019-11-09 09:38:01 --> Model Class Initialized
DEBUG - 2019-11-09 09:38:01 --> Template Class Initialized
INFO - 2019-11-09 09:38:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:38:01 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:38:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:38:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:38:01 --> Encryption Class Initialized
INFO - 2019-11-09 09:38:01 --> Controller Class Initialized
DEBUG - 2019-11-09 09:38:01 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 09:38:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 09:38:01 --> Model Class Initialized
DEBUG - 2019-11-09 09:38:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 09:38:01 --> Final output sent to browser
DEBUG - 2019-11-09 09:38:01 --> Total execution time: 0.6087
INFO - 2019-11-09 09:38:02 --> Config Class Initialized
INFO - 2019-11-09 09:38:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 09:38:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 09:38:02 --> Utf8 Class Initialized
INFO - 2019-11-09 09:38:02 --> URI Class Initialized
INFO - 2019-11-09 09:38:02 --> Router Class Initialized
INFO - 2019-11-09 09:38:02 --> Output Class Initialized
INFO - 2019-11-09 09:38:02 --> Security Class Initialized
DEBUG - 2019-11-09 09:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 09:38:02 --> Input Class Initialized
INFO - 2019-11-09 09:38:02 --> Language Class Initialized
INFO - 2019-11-09 09:38:02 --> Language Class Initialized
INFO - 2019-11-09 09:38:02 --> Config Class Initialized
INFO - 2019-11-09 09:38:02 --> Loader Class Initialized
INFO - 2019-11-09 09:38:02 --> Helper loaded: url_helper
INFO - 2019-11-09 09:38:02 --> Helper loaded: common_helper
INFO - 2019-11-09 09:38:02 --> Helper loaded: language_helper
INFO - 2019-11-09 09:38:02 --> Helper loaded: cookie_helper
INFO - 2019-11-09 09:38:02 --> Helper loaded: email_helper
INFO - 2019-11-09 09:38:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 09:38:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 09:38:02 --> Parser Class Initialized
INFO - 2019-11-09 09:38:02 --> User Agent Class Initialized
INFO - 2019-11-09 09:38:02 --> Model Class Initialized
INFO - 2019-11-09 09:38:02 --> Database Driver Class Initialized
INFO - 2019-11-09 09:38:02 --> Model Class Initialized
DEBUG - 2019-11-09 09:38:02 --> Template Class Initialized
INFO - 2019-11-09 09:38:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 09:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 09:38:02 --> Pagination Class Initialized
DEBUG - 2019-11-09 09:38:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 09:38:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 09:38:02 --> Encryption Class Initialized
INFO - 2019-11-09 09:38:02 --> Controller Class Initialized
DEBUG - 2019-11-09 09:38:02 --> paytm MX_Controller Initialized
INFO - 2019-11-09 09:38:02 --> Model Class Initialized
DEBUG - 2019-11-09 09:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 09:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 09:38:02 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 09:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
DEBUG - 2019-11-09 09:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 09:38:02 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 09:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 09:38:02 --> Model Class Initialized
DEBUG - 2019-11-09 09:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 09:38:02 --> Model Class Initialized
DEBUG - 2019-11-09 09:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 09:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 09:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 09:38:02 --> Final output sent to browser
DEBUG - 2019-11-09 09:38:02 --> Total execution time: 0.8924
INFO - 2019-11-09 10:15:56 --> Config Class Initialized
INFO - 2019-11-09 10:15:56 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:15:56 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:15:56 --> Utf8 Class Initialized
INFO - 2019-11-09 10:15:56 --> URI Class Initialized
INFO - 2019-11-09 10:15:56 --> Router Class Initialized
INFO - 2019-11-09 10:15:56 --> Output Class Initialized
INFO - 2019-11-09 10:15:56 --> Security Class Initialized
DEBUG - 2019-11-09 10:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:15:56 --> CSRF cookie sent
INFO - 2019-11-09 10:15:56 --> CSRF token verified
INFO - 2019-11-09 10:15:56 --> Input Class Initialized
INFO - 2019-11-09 10:15:56 --> Language Class Initialized
INFO - 2019-11-09 10:15:56 --> Language Class Initialized
INFO - 2019-11-09 10:15:56 --> Config Class Initialized
INFO - 2019-11-09 10:15:56 --> Loader Class Initialized
INFO - 2019-11-09 10:15:56 --> Helper loaded: url_helper
INFO - 2019-11-09 10:15:56 --> Helper loaded: common_helper
INFO - 2019-11-09 10:15:56 --> Helper loaded: language_helper
INFO - 2019-11-09 10:15:56 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:15:56 --> Helper loaded: email_helper
INFO - 2019-11-09 10:15:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:15:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:15:56 --> Parser Class Initialized
INFO - 2019-11-09 10:15:56 --> User Agent Class Initialized
INFO - 2019-11-09 10:15:56 --> Model Class Initialized
INFO - 2019-11-09 10:15:56 --> Database Driver Class Initialized
INFO - 2019-11-09 10:15:56 --> Model Class Initialized
DEBUG - 2019-11-09 10:15:56 --> Template Class Initialized
INFO - 2019-11-09 10:15:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:15:56 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:15:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:15:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:15:56 --> Encryption Class Initialized
INFO - 2019-11-09 10:15:56 --> Controller Class Initialized
DEBUG - 2019-11-09 10:15:56 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:15:56 --> Model Class Initialized
INFO - 2019-11-09 10:15:56 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 10:15:56 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 10:15:56 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 10:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 10:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 10:15:57 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 10:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 10:15:57 --> Model Class Initialized
DEBUG - 2019-11-09 10:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 10:15:57 --> Model Class Initialized
DEBUG - 2019-11-09 10:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 10:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 10:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 10:15:57 --> Final output sent to browser
DEBUG - 2019-11-09 10:15:57 --> Total execution time: 0.8354
INFO - 2019-11-09 10:16:05 --> Config Class Initialized
INFO - 2019-11-09 10:16:05 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:16:05 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:16:05 --> Utf8 Class Initialized
INFO - 2019-11-09 10:16:05 --> URI Class Initialized
INFO - 2019-11-09 10:16:05 --> Router Class Initialized
INFO - 2019-11-09 10:16:05 --> Output Class Initialized
INFO - 2019-11-09 10:16:05 --> Security Class Initialized
DEBUG - 2019-11-09 10:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:16:05 --> CSRF cookie sent
INFO - 2019-11-09 10:16:05 --> CSRF token verified
INFO - 2019-11-09 10:16:05 --> Input Class Initialized
INFO - 2019-11-09 10:16:05 --> Language Class Initialized
INFO - 2019-11-09 10:16:05 --> Language Class Initialized
INFO - 2019-11-09 10:16:05 --> Config Class Initialized
INFO - 2019-11-09 10:16:05 --> Loader Class Initialized
INFO - 2019-11-09 10:16:05 --> Helper loaded: url_helper
INFO - 2019-11-09 10:16:05 --> Helper loaded: common_helper
INFO - 2019-11-09 10:16:05 --> Helper loaded: language_helper
INFO - 2019-11-09 10:16:05 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:16:05 --> Helper loaded: email_helper
INFO - 2019-11-09 10:16:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:16:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:16:05 --> Parser Class Initialized
INFO - 2019-11-09 10:16:05 --> User Agent Class Initialized
INFO - 2019-11-09 10:16:05 --> Model Class Initialized
INFO - 2019-11-09 10:16:05 --> Database Driver Class Initialized
INFO - 2019-11-09 10:16:05 --> Model Class Initialized
DEBUG - 2019-11-09 10:16:05 --> Template Class Initialized
INFO - 2019-11-09 10:16:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:16:05 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:16:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:16:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:16:05 --> Encryption Class Initialized
INFO - 2019-11-09 10:16:05 --> Controller Class Initialized
DEBUG - 2019-11-09 10:16:05 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:16:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:16:05 --> Model Class Initialized
ERROR - 2019-11-09 10:16:05 --> Severity: error --> Exception: Class 'paypal' not found D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\checkout.php 43
INFO - 2019-11-09 10:18:15 --> Config Class Initialized
INFO - 2019-11-09 10:18:15 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:18:15 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:18:15 --> Utf8 Class Initialized
INFO - 2019-11-09 10:18:15 --> URI Class Initialized
INFO - 2019-11-09 10:18:15 --> Router Class Initialized
INFO - 2019-11-09 10:18:15 --> Output Class Initialized
INFO - 2019-11-09 10:18:15 --> Security Class Initialized
DEBUG - 2019-11-09 10:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:18:15 --> CSRF cookie sent
INFO - 2019-11-09 10:18:15 --> CSRF token verified
INFO - 2019-11-09 10:18:15 --> Input Class Initialized
INFO - 2019-11-09 10:18:15 --> Language Class Initialized
ERROR - 2019-11-09 10:18:15 --> Severity: error --> Exception: syntax error, unexpected ''.php'' (T_CONSTANT_ENCAPSED_STRING) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\checkout.php 43
INFO - 2019-11-09 10:18:32 --> Config Class Initialized
INFO - 2019-11-09 10:18:32 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:18:32 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:18:32 --> Utf8 Class Initialized
INFO - 2019-11-09 10:18:32 --> URI Class Initialized
INFO - 2019-11-09 10:18:32 --> Router Class Initialized
INFO - 2019-11-09 10:18:32 --> Output Class Initialized
INFO - 2019-11-09 10:18:32 --> Security Class Initialized
DEBUG - 2019-11-09 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:18:32 --> CSRF cookie sent
INFO - 2019-11-09 10:18:32 --> CSRF token verified
INFO - 2019-11-09 10:18:32 --> Input Class Initialized
INFO - 2019-11-09 10:18:33 --> Language Class Initialized
INFO - 2019-11-09 10:18:33 --> Language Class Initialized
INFO - 2019-11-09 10:18:33 --> Config Class Initialized
INFO - 2019-11-09 10:18:33 --> Loader Class Initialized
INFO - 2019-11-09 10:18:33 --> Helper loaded: url_helper
INFO - 2019-11-09 10:18:33 --> Helper loaded: common_helper
INFO - 2019-11-09 10:18:33 --> Helper loaded: language_helper
INFO - 2019-11-09 10:18:33 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:18:33 --> Helper loaded: email_helper
INFO - 2019-11-09 10:18:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:18:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:18:33 --> Parser Class Initialized
INFO - 2019-11-09 10:18:33 --> User Agent Class Initialized
INFO - 2019-11-09 10:18:33 --> Model Class Initialized
INFO - 2019-11-09 10:18:33 --> Database Driver Class Initialized
INFO - 2019-11-09 10:18:33 --> Model Class Initialized
DEBUG - 2019-11-09 10:18:33 --> Template Class Initialized
INFO - 2019-11-09 10:18:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:18:33 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:18:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:18:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:18:33 --> Encryption Class Initialized
INFO - 2019-11-09 10:18:33 --> Controller Class Initialized
DEBUG - 2019-11-09 10:18:33 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:18:33 --> Model Class Initialized
DEBUG - 2019-11-09 10:18:33 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
INFO - 2019-11-09 10:18:33 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 10:18:33 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 10:18:33 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 10:18:33 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 10:18:33 --> Model Class Initialized
DEBUG - 2019-11-09 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 10:18:33 --> Model Class Initialized
DEBUG - 2019-11-09 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 10:18:33 --> Final output sent to browser
DEBUG - 2019-11-09 10:18:33 --> Total execution time: 1.0331
INFO - 2019-11-09 10:21:36 --> Config Class Initialized
INFO - 2019-11-09 10:21:36 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:21:36 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:21:36 --> Utf8 Class Initialized
INFO - 2019-11-09 10:21:36 --> URI Class Initialized
INFO - 2019-11-09 10:21:36 --> Router Class Initialized
INFO - 2019-11-09 10:21:36 --> Output Class Initialized
INFO - 2019-11-09 10:21:36 --> Security Class Initialized
DEBUG - 2019-11-09 10:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:21:36 --> CSRF cookie sent
INFO - 2019-11-09 10:21:36 --> CSRF token verified
INFO - 2019-11-09 10:21:36 --> Input Class Initialized
INFO - 2019-11-09 10:21:36 --> Language Class Initialized
INFO - 2019-11-09 10:21:36 --> Language Class Initialized
INFO - 2019-11-09 10:21:36 --> Config Class Initialized
INFO - 2019-11-09 10:21:36 --> Loader Class Initialized
INFO - 2019-11-09 10:21:36 --> Helper loaded: url_helper
INFO - 2019-11-09 10:21:36 --> Helper loaded: common_helper
INFO - 2019-11-09 10:21:36 --> Helper loaded: language_helper
INFO - 2019-11-09 10:21:36 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:21:36 --> Helper loaded: email_helper
INFO - 2019-11-09 10:21:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:21:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:21:36 --> Parser Class Initialized
INFO - 2019-11-09 10:21:36 --> User Agent Class Initialized
INFO - 2019-11-09 10:21:36 --> Model Class Initialized
INFO - 2019-11-09 10:21:36 --> Database Driver Class Initialized
INFO - 2019-11-09 10:21:36 --> Model Class Initialized
DEBUG - 2019-11-09 10:21:36 --> Template Class Initialized
INFO - 2019-11-09 10:21:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:21:36 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:21:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:21:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:21:36 --> Encryption Class Initialized
INFO - 2019-11-09 10:21:36 --> Controller Class Initialized
DEBUG - 2019-11-09 10:21:36 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:21:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:21:36 --> Model Class Initialized
INFO - 2019-11-09 10:21:36 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 10:21:37 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 10:21:37 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 10:21:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 10:21:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 10:21:37 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 10:21:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 10:21:37 --> Model Class Initialized
DEBUG - 2019-11-09 10:21:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 10:21:37 --> Model Class Initialized
DEBUG - 2019-11-09 10:21:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 10:21:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 10:21:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 10:21:37 --> Final output sent to browser
DEBUG - 2019-11-09 10:21:37 --> Total execution time: 0.9224
INFO - 2019-11-09 10:21:51 --> Config Class Initialized
INFO - 2019-11-09 10:21:51 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:21:51 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:21:51 --> Utf8 Class Initialized
INFO - 2019-11-09 10:21:51 --> URI Class Initialized
INFO - 2019-11-09 10:21:51 --> Router Class Initialized
INFO - 2019-11-09 10:21:51 --> Output Class Initialized
INFO - 2019-11-09 10:21:51 --> Security Class Initialized
DEBUG - 2019-11-09 10:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:21:52 --> CSRF cookie sent
INFO - 2019-11-09 10:21:52 --> CSRF token verified
INFO - 2019-11-09 10:21:52 --> Input Class Initialized
INFO - 2019-11-09 10:21:52 --> Language Class Initialized
INFO - 2019-11-09 10:21:52 --> Language Class Initialized
INFO - 2019-11-09 10:21:52 --> Config Class Initialized
INFO - 2019-11-09 10:21:52 --> Loader Class Initialized
INFO - 2019-11-09 10:21:52 --> Helper loaded: url_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: common_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: language_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: email_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:21:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:21:52 --> Parser Class Initialized
INFO - 2019-11-09 10:21:52 --> User Agent Class Initialized
INFO - 2019-11-09 10:21:52 --> Model Class Initialized
INFO - 2019-11-09 10:21:52 --> Database Driver Class Initialized
INFO - 2019-11-09 10:21:52 --> Model Class Initialized
DEBUG - 2019-11-09 10:21:52 --> Template Class Initialized
INFO - 2019-11-09 10:21:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:21:52 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:21:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:21:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:21:52 --> Encryption Class Initialized
INFO - 2019-11-09 10:21:52 --> Controller Class Initialized
DEBUG - 2019-11-09 10:21:52 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:21:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:21:52 --> Model Class Initialized
DEBUG - 2019-11-09 10:21:52 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 10:21:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
INFO - 2019-11-09 10:21:52 --> Config Class Initialized
INFO - 2019-11-09 10:21:52 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:21:52 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:21:52 --> Utf8 Class Initialized
INFO - 2019-11-09 10:21:52 --> URI Class Initialized
INFO - 2019-11-09 10:21:52 --> Router Class Initialized
INFO - 2019-11-09 10:21:52 --> Output Class Initialized
INFO - 2019-11-09 10:21:52 --> Security Class Initialized
DEBUG - 2019-11-09 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:21:52 --> CSRF cookie sent
INFO - 2019-11-09 10:21:52 --> Input Class Initialized
INFO - 2019-11-09 10:21:52 --> Language Class Initialized
INFO - 2019-11-09 10:21:52 --> Language Class Initialized
INFO - 2019-11-09 10:21:52 --> Config Class Initialized
INFO - 2019-11-09 10:21:52 --> Loader Class Initialized
INFO - 2019-11-09 10:21:52 --> Helper loaded: url_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: common_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: language_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: email_helper
INFO - 2019-11-09 10:21:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:21:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:21:52 --> Parser Class Initialized
INFO - 2019-11-09 10:21:52 --> User Agent Class Initialized
INFO - 2019-11-09 10:21:52 --> Model Class Initialized
INFO - 2019-11-09 10:21:52 --> Database Driver Class Initialized
INFO - 2019-11-09 10:21:52 --> Model Class Initialized
DEBUG - 2019-11-09 10:21:52 --> Template Class Initialized
INFO - 2019-11-09 10:21:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:21:52 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:21:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:21:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:21:52 --> Encryption Class Initialized
INFO - 2019-11-09 10:21:52 --> Controller Class Initialized
DEBUG - 2019-11-09 10:21:52 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:21:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:21:52 --> Model Class Initialized
INFO - 2019-11-09 10:21:53 --> Config Class Initialized
INFO - 2019-11-09 10:21:53 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:21:53 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:21:53 --> Utf8 Class Initialized
INFO - 2019-11-09 10:21:53 --> URI Class Initialized
DEBUG - 2019-11-09 10:21:53 --> No URI present. Default controller set.
INFO - 2019-11-09 10:21:53 --> Router Class Initialized
INFO - 2019-11-09 10:21:53 --> Output Class Initialized
INFO - 2019-11-09 10:21:53 --> Security Class Initialized
DEBUG - 2019-11-09 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:21:53 --> CSRF cookie sent
INFO - 2019-11-09 10:21:53 --> Input Class Initialized
INFO - 2019-11-09 10:21:53 --> Language Class Initialized
INFO - 2019-11-09 10:21:53 --> Language Class Initialized
INFO - 2019-11-09 10:21:53 --> Config Class Initialized
INFO - 2019-11-09 10:21:53 --> Loader Class Initialized
INFO - 2019-11-09 10:21:53 --> Helper loaded: url_helper
INFO - 2019-11-09 10:21:53 --> Helper loaded: common_helper
INFO - 2019-11-09 10:21:53 --> Helper loaded: language_helper
INFO - 2019-11-09 10:21:53 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:21:53 --> Helper loaded: email_helper
INFO - 2019-11-09 10:21:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:21:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:21:53 --> Parser Class Initialized
INFO - 2019-11-09 10:21:53 --> User Agent Class Initialized
INFO - 2019-11-09 10:21:53 --> Model Class Initialized
INFO - 2019-11-09 10:21:53 --> Database Driver Class Initialized
INFO - 2019-11-09 10:21:53 --> Model Class Initialized
DEBUG - 2019-11-09 10:21:53 --> Template Class Initialized
INFO - 2019-11-09 10:21:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:21:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:21:53 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:21:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:21:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:21:53 --> Encryption Class Initialized
DEBUG - 2019-11-09 10:21:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 10:21:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 10:21:53 --> Controller Class Initialized
DEBUG - 2019-11-09 10:21:53 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 10:21:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 10:21:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 10:21:53 --> Model Class Initialized
INFO - 2019-11-09 10:21:53 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 10:21:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 10:21:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 10:21:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 10:21:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 10:21:53 --> Final output sent to browser
DEBUG - 2019-11-09 10:21:53 --> Total execution time: 0.7387
INFO - 2019-11-09 10:23:51 --> Config Class Initialized
INFO - 2019-11-09 10:23:51 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:23:51 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:23:51 --> Utf8 Class Initialized
INFO - 2019-11-09 10:23:51 --> URI Class Initialized
INFO - 2019-11-09 10:23:51 --> Router Class Initialized
INFO - 2019-11-09 10:23:51 --> Output Class Initialized
INFO - 2019-11-09 10:23:51 --> Security Class Initialized
DEBUG - 2019-11-09 10:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:23:51 --> CSRF cookie sent
INFO - 2019-11-09 10:23:51 --> CSRF token verified
INFO - 2019-11-09 10:23:51 --> Input Class Initialized
INFO - 2019-11-09 10:23:51 --> Language Class Initialized
INFO - 2019-11-09 10:23:51 --> Language Class Initialized
INFO - 2019-11-09 10:23:51 --> Config Class Initialized
INFO - 2019-11-09 10:23:51 --> Loader Class Initialized
INFO - 2019-11-09 10:23:51 --> Helper loaded: url_helper
INFO - 2019-11-09 10:23:51 --> Helper loaded: common_helper
INFO - 2019-11-09 10:23:52 --> Helper loaded: language_helper
INFO - 2019-11-09 10:23:52 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:23:52 --> Helper loaded: email_helper
INFO - 2019-11-09 10:23:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:23:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:23:52 --> Parser Class Initialized
INFO - 2019-11-09 10:23:52 --> User Agent Class Initialized
INFO - 2019-11-09 10:23:52 --> Model Class Initialized
INFO - 2019-11-09 10:23:52 --> Database Driver Class Initialized
INFO - 2019-11-09 10:23:52 --> Model Class Initialized
DEBUG - 2019-11-09 10:23:52 --> Template Class Initialized
INFO - 2019-11-09 10:23:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:23:52 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:23:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:23:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:23:52 --> Encryption Class Initialized
INFO - 2019-11-09 10:23:52 --> Controller Class Initialized
DEBUG - 2019-11-09 10:23:52 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:23:52 --> Model Class Initialized
INFO - 2019-11-09 10:23:52 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 10:23:52 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 10:23:52 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 10:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 10:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 10:23:52 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 10:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 10:23:52 --> Model Class Initialized
DEBUG - 2019-11-09 10:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 10:23:52 --> Model Class Initialized
DEBUG - 2019-11-09 10:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 10:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 10:23:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 10:23:52 --> Final output sent to browser
DEBUG - 2019-11-09 10:23:52 --> Total execution time: 1.0888
INFO - 2019-11-09 10:24:06 --> Config Class Initialized
INFO - 2019-11-09 10:24:06 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:24:06 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:24:06 --> Utf8 Class Initialized
INFO - 2019-11-09 10:24:06 --> URI Class Initialized
INFO - 2019-11-09 10:24:07 --> Router Class Initialized
INFO - 2019-11-09 10:24:07 --> Output Class Initialized
INFO - 2019-11-09 10:24:07 --> Security Class Initialized
DEBUG - 2019-11-09 10:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:24:07 --> CSRF cookie sent
INFO - 2019-11-09 10:24:07 --> CSRF token verified
INFO - 2019-11-09 10:24:07 --> Input Class Initialized
INFO - 2019-11-09 10:24:07 --> Language Class Initialized
INFO - 2019-11-09 10:24:07 --> Language Class Initialized
INFO - 2019-11-09 10:24:07 --> Config Class Initialized
INFO - 2019-11-09 10:24:07 --> Loader Class Initialized
INFO - 2019-11-09 10:24:07 --> Helper loaded: url_helper
INFO - 2019-11-09 10:24:07 --> Helper loaded: common_helper
INFO - 2019-11-09 10:24:07 --> Helper loaded: language_helper
INFO - 2019-11-09 10:24:07 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:24:07 --> Helper loaded: email_helper
INFO - 2019-11-09 10:24:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:24:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:24:07 --> Parser Class Initialized
INFO - 2019-11-09 10:24:07 --> User Agent Class Initialized
INFO - 2019-11-09 10:24:07 --> Model Class Initialized
INFO - 2019-11-09 10:24:07 --> Database Driver Class Initialized
INFO - 2019-11-09 10:24:07 --> Model Class Initialized
DEBUG - 2019-11-09 10:24:07 --> Template Class Initialized
INFO - 2019-11-09 10:24:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:24:07 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:24:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:24:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:24:07 --> Encryption Class Initialized
INFO - 2019-11-09 10:24:07 --> Controller Class Initialized
DEBUG - 2019-11-09 10:24:07 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:24:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:24:07 --> Model Class Initialized
DEBUG - 2019-11-09 10:24:07 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 10:24:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
INFO - 2019-11-09 10:25:50 --> Config Class Initialized
INFO - 2019-11-09 10:25:50 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:25:51 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:25:51 --> Utf8 Class Initialized
INFO - 2019-11-09 10:25:51 --> URI Class Initialized
INFO - 2019-11-09 10:25:51 --> Router Class Initialized
INFO - 2019-11-09 10:25:51 --> Output Class Initialized
INFO - 2019-11-09 10:25:51 --> Security Class Initialized
DEBUG - 2019-11-09 10:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:25:51 --> CSRF cookie sent
INFO - 2019-11-09 10:25:51 --> CSRF token verified
INFO - 2019-11-09 10:25:51 --> Input Class Initialized
INFO - 2019-11-09 10:25:51 --> Language Class Initialized
INFO - 2019-11-09 10:25:51 --> Language Class Initialized
INFO - 2019-11-09 10:25:51 --> Config Class Initialized
INFO - 2019-11-09 10:25:51 --> Loader Class Initialized
INFO - 2019-11-09 10:25:51 --> Helper loaded: url_helper
INFO - 2019-11-09 10:25:51 --> Helper loaded: common_helper
INFO - 2019-11-09 10:25:51 --> Helper loaded: language_helper
INFO - 2019-11-09 10:25:51 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:25:51 --> Helper loaded: email_helper
INFO - 2019-11-09 10:25:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:25:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:25:51 --> Parser Class Initialized
INFO - 2019-11-09 10:25:51 --> User Agent Class Initialized
INFO - 2019-11-09 10:25:51 --> Model Class Initialized
INFO - 2019-11-09 10:25:51 --> Database Driver Class Initialized
INFO - 2019-11-09 10:25:51 --> Model Class Initialized
DEBUG - 2019-11-09 10:25:51 --> Template Class Initialized
INFO - 2019-11-09 10:25:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:25:51 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:25:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:25:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:25:51 --> Encryption Class Initialized
INFO - 2019-11-09 10:25:51 --> Controller Class Initialized
DEBUG - 2019-11-09 10:25:51 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:25:51 --> Model Class Initialized
INFO - 2019-11-09 10:25:51 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 10:25:51 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 10:25:51 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 10:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 10:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 10:25:51 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 10:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 10:25:51 --> Model Class Initialized
DEBUG - 2019-11-09 10:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 10:25:51 --> Model Class Initialized
DEBUG - 2019-11-09 10:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 10:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 10:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 10:25:51 --> Final output sent to browser
DEBUG - 2019-11-09 10:25:51 --> Total execution time: 0.8678
INFO - 2019-11-09 10:26:00 --> Config Class Initialized
INFO - 2019-11-09 10:26:00 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:26:00 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:26:00 --> Utf8 Class Initialized
INFO - 2019-11-09 10:26:00 --> URI Class Initialized
INFO - 2019-11-09 10:26:00 --> Router Class Initialized
INFO - 2019-11-09 10:26:00 --> Output Class Initialized
INFO - 2019-11-09 10:26:00 --> Security Class Initialized
DEBUG - 2019-11-09 10:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:26:00 --> CSRF cookie sent
INFO - 2019-11-09 10:26:00 --> CSRF token verified
INFO - 2019-11-09 10:26:00 --> Input Class Initialized
INFO - 2019-11-09 10:26:00 --> Language Class Initialized
INFO - 2019-11-09 10:26:00 --> Language Class Initialized
INFO - 2019-11-09 10:26:00 --> Config Class Initialized
INFO - 2019-11-09 10:26:00 --> Loader Class Initialized
INFO - 2019-11-09 10:26:00 --> Helper loaded: url_helper
INFO - 2019-11-09 10:26:00 --> Helper loaded: common_helper
INFO - 2019-11-09 10:26:00 --> Helper loaded: language_helper
INFO - 2019-11-09 10:26:00 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:26:00 --> Helper loaded: email_helper
INFO - 2019-11-09 10:26:00 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:26:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:26:00 --> Parser Class Initialized
INFO - 2019-11-09 10:26:00 --> User Agent Class Initialized
INFO - 2019-11-09 10:26:00 --> Model Class Initialized
INFO - 2019-11-09 10:26:00 --> Database Driver Class Initialized
INFO - 2019-11-09 10:26:00 --> Model Class Initialized
DEBUG - 2019-11-09 10:26:00 --> Template Class Initialized
INFO - 2019-11-09 10:26:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:26:00 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:26:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:26:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:26:00 --> Encryption Class Initialized
INFO - 2019-11-09 10:26:00 --> Controller Class Initialized
DEBUG - 2019-11-09 10:26:00 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:26:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:26:00 --> Model Class Initialized
DEBUG - 2019-11-09 10:26:00 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 10:26:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
INFO - 2019-11-09 10:35:05 --> Config Class Initialized
INFO - 2019-11-09 10:35:06 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:35:06 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:35:06 --> Utf8 Class Initialized
INFO - 2019-11-09 10:35:06 --> URI Class Initialized
INFO - 2019-11-09 10:35:06 --> Router Class Initialized
INFO - 2019-11-09 10:35:06 --> Output Class Initialized
INFO - 2019-11-09 10:35:06 --> Security Class Initialized
DEBUG - 2019-11-09 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:35:06 --> CSRF cookie sent
INFO - 2019-11-09 10:35:06 --> CSRF token verified
INFO - 2019-11-09 10:35:06 --> Input Class Initialized
INFO - 2019-11-09 10:35:06 --> Language Class Initialized
INFO - 2019-11-09 10:35:06 --> Language Class Initialized
INFO - 2019-11-09 10:35:06 --> Config Class Initialized
INFO - 2019-11-09 10:35:06 --> Loader Class Initialized
INFO - 2019-11-09 10:35:06 --> Helper loaded: url_helper
INFO - 2019-11-09 10:35:06 --> Helper loaded: common_helper
INFO - 2019-11-09 10:35:06 --> Helper loaded: language_helper
INFO - 2019-11-09 10:35:06 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:35:06 --> Helper loaded: email_helper
INFO - 2019-11-09 10:35:06 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:35:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:35:06 --> Parser Class Initialized
INFO - 2019-11-09 10:35:06 --> User Agent Class Initialized
INFO - 2019-11-09 10:35:06 --> Model Class Initialized
INFO - 2019-11-09 10:35:06 --> Database Driver Class Initialized
INFO - 2019-11-09 10:35:06 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:06 --> Template Class Initialized
INFO - 2019-11-09 10:35:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:35:06 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:35:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:35:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:35:06 --> Encryption Class Initialized
INFO - 2019-11-09 10:35:06 --> Controller Class Initialized
DEBUG - 2019-11-09 10:35:06 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:35:06 --> Model Class Initialized
INFO - 2019-11-09 10:35:06 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 10:35:06 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 10:35:06 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 10:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 10:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 10:35:06 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 10:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 10:35:06 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 10:35:06 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 10:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 10:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 10:35:06 --> Final output sent to browser
DEBUG - 2019-11-09 10:35:06 --> Total execution time: 0.8494
INFO - 2019-11-09 10:35:18 --> Config Class Initialized
INFO - 2019-11-09 10:35:18 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:35:18 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:35:18 --> Utf8 Class Initialized
INFO - 2019-11-09 10:35:18 --> URI Class Initialized
INFO - 2019-11-09 10:35:18 --> Router Class Initialized
INFO - 2019-11-09 10:35:18 --> Output Class Initialized
INFO - 2019-11-09 10:35:18 --> Security Class Initialized
DEBUG - 2019-11-09 10:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:35:18 --> CSRF cookie sent
INFO - 2019-11-09 10:35:18 --> CSRF token verified
INFO - 2019-11-09 10:35:18 --> Input Class Initialized
INFO - 2019-11-09 10:35:18 --> Language Class Initialized
INFO - 2019-11-09 10:35:18 --> Language Class Initialized
INFO - 2019-11-09 10:35:18 --> Config Class Initialized
INFO - 2019-11-09 10:35:18 --> Loader Class Initialized
INFO - 2019-11-09 10:35:18 --> Helper loaded: url_helper
INFO - 2019-11-09 10:35:18 --> Helper loaded: common_helper
INFO - 2019-11-09 10:35:19 --> Helper loaded: language_helper
INFO - 2019-11-09 10:35:19 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:35:19 --> Helper loaded: email_helper
INFO - 2019-11-09 10:35:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:35:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:35:19 --> Parser Class Initialized
INFO - 2019-11-09 10:35:19 --> User Agent Class Initialized
INFO - 2019-11-09 10:35:19 --> Model Class Initialized
INFO - 2019-11-09 10:35:19 --> Database Driver Class Initialized
INFO - 2019-11-09 10:35:19 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:19 --> Template Class Initialized
INFO - 2019-11-09 10:35:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:35:19 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:35:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:35:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:35:19 --> Encryption Class Initialized
INFO - 2019-11-09 10:35:19 --> Controller Class Initialized
DEBUG - 2019-11-09 10:35:19 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:35:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:35:19 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:19 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 10:35:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
INFO - 2019-11-09 10:35:30 --> Config Class Initialized
INFO - 2019-11-09 10:35:30 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:35:30 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:35:30 --> Utf8 Class Initialized
INFO - 2019-11-09 10:35:30 --> URI Class Initialized
INFO - 2019-11-09 10:35:30 --> Router Class Initialized
INFO - 2019-11-09 10:35:30 --> Output Class Initialized
INFO - 2019-11-09 10:35:30 --> Security Class Initialized
DEBUG - 2019-11-09 10:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:35:30 --> CSRF cookie sent
INFO - 2019-11-09 10:35:30 --> Input Class Initialized
INFO - 2019-11-09 10:35:30 --> Language Class Initialized
INFO - 2019-11-09 10:35:30 --> Language Class Initialized
INFO - 2019-11-09 10:35:30 --> Config Class Initialized
INFO - 2019-11-09 10:35:30 --> Loader Class Initialized
INFO - 2019-11-09 10:35:30 --> Helper loaded: url_helper
INFO - 2019-11-09 10:35:30 --> Helper loaded: common_helper
INFO - 2019-11-09 10:35:30 --> Helper loaded: language_helper
INFO - 2019-11-09 10:35:30 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:35:30 --> Helper loaded: email_helper
INFO - 2019-11-09 10:35:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:35:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:35:30 --> Parser Class Initialized
INFO - 2019-11-09 10:35:30 --> User Agent Class Initialized
INFO - 2019-11-09 10:35:30 --> Model Class Initialized
INFO - 2019-11-09 10:35:30 --> Database Driver Class Initialized
INFO - 2019-11-09 10:35:30 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:30 --> Template Class Initialized
INFO - 2019-11-09 10:35:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:35:30 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:35:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:35:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:35:30 --> Encryption Class Initialized
INFO - 2019-11-09 10:35:30 --> Controller Class Initialized
DEBUG - 2019-11-09 10:35:30 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:35:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:35:30 --> Model Class Initialized
INFO - 2019-11-09 10:35:35 --> Config Class Initialized
INFO - 2019-11-09 10:35:35 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:35:35 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:35:35 --> Utf8 Class Initialized
INFO - 2019-11-09 10:35:35 --> URI Class Initialized
INFO - 2019-11-09 10:35:35 --> Router Class Initialized
INFO - 2019-11-09 10:35:35 --> Output Class Initialized
INFO - 2019-11-09 10:35:35 --> Security Class Initialized
DEBUG - 2019-11-09 10:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:35:35 --> CSRF cookie sent
INFO - 2019-11-09 10:35:35 --> CSRF token verified
INFO - 2019-11-09 10:35:35 --> Input Class Initialized
INFO - 2019-11-09 10:35:35 --> Language Class Initialized
INFO - 2019-11-09 10:35:35 --> Language Class Initialized
INFO - 2019-11-09 10:35:35 --> Config Class Initialized
INFO - 2019-11-09 10:35:35 --> Loader Class Initialized
INFO - 2019-11-09 10:35:35 --> Helper loaded: url_helper
INFO - 2019-11-09 10:35:35 --> Helper loaded: common_helper
INFO - 2019-11-09 10:35:35 --> Helper loaded: language_helper
INFO - 2019-11-09 10:35:35 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:35:35 --> Helper loaded: email_helper
INFO - 2019-11-09 10:35:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:35:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:35:35 --> Parser Class Initialized
INFO - 2019-11-09 10:35:35 --> User Agent Class Initialized
INFO - 2019-11-09 10:35:35 --> Model Class Initialized
INFO - 2019-11-09 10:35:35 --> Database Driver Class Initialized
INFO - 2019-11-09 10:35:35 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:35 --> Template Class Initialized
INFO - 2019-11-09 10:35:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:35:35 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:35:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:35:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:35:35 --> Encryption Class Initialized
INFO - 2019-11-09 10:35:35 --> Controller Class Initialized
DEBUG - 2019-11-09 10:35:35 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:35:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:35:35 --> Model Class Initialized
INFO - 2019-11-09 10:35:35 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 10:35:35 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 10:35:35 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 10:35:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 10:35:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 10:35:35 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 10:35:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 10:35:35 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 10:35:35 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 10:35:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 10:35:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 10:35:36 --> Final output sent to browser
DEBUG - 2019-11-09 10:35:36 --> Total execution time: 0.9037
INFO - 2019-11-09 10:35:44 --> Config Class Initialized
INFO - 2019-11-09 10:35:44 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:35:44 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:35:44 --> Utf8 Class Initialized
INFO - 2019-11-09 10:35:44 --> URI Class Initialized
INFO - 2019-11-09 10:35:44 --> Router Class Initialized
INFO - 2019-11-09 10:35:44 --> Output Class Initialized
INFO - 2019-11-09 10:35:44 --> Security Class Initialized
DEBUG - 2019-11-09 10:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:35:44 --> CSRF cookie sent
INFO - 2019-11-09 10:35:44 --> CSRF token verified
INFO - 2019-11-09 10:35:44 --> Input Class Initialized
INFO - 2019-11-09 10:35:44 --> Language Class Initialized
INFO - 2019-11-09 10:35:44 --> Language Class Initialized
INFO - 2019-11-09 10:35:44 --> Config Class Initialized
INFO - 2019-11-09 10:35:44 --> Loader Class Initialized
INFO - 2019-11-09 10:35:44 --> Helper loaded: url_helper
INFO - 2019-11-09 10:35:44 --> Helper loaded: common_helper
INFO - 2019-11-09 10:35:44 --> Helper loaded: language_helper
INFO - 2019-11-09 10:35:44 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:35:44 --> Helper loaded: email_helper
INFO - 2019-11-09 10:35:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:35:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:35:44 --> Parser Class Initialized
INFO - 2019-11-09 10:35:44 --> User Agent Class Initialized
INFO - 2019-11-09 10:35:44 --> Model Class Initialized
INFO - 2019-11-09 10:35:44 --> Database Driver Class Initialized
INFO - 2019-11-09 10:35:44 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:44 --> Template Class Initialized
INFO - 2019-11-09 10:35:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:35:45 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:35:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:35:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:35:45 --> Encryption Class Initialized
INFO - 2019-11-09 10:35:45 --> Controller Class Initialized
DEBUG - 2019-11-09 10:35:45 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:35:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:35:45 --> Model Class Initialized
DEBUG - 2019-11-09 10:35:45 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 10:35:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
INFO - 2019-11-09 10:36:30 --> Config Class Initialized
INFO - 2019-11-09 10:36:30 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:36:30 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:36:30 --> Utf8 Class Initialized
INFO - 2019-11-09 10:36:30 --> URI Class Initialized
INFO - 2019-11-09 10:36:30 --> Router Class Initialized
INFO - 2019-11-09 10:36:30 --> Output Class Initialized
INFO - 2019-11-09 10:36:30 --> Security Class Initialized
DEBUG - 2019-11-09 10:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:36:30 --> CSRF cookie sent
INFO - 2019-11-09 10:36:30 --> CSRF token verified
INFO - 2019-11-09 10:36:30 --> Input Class Initialized
INFO - 2019-11-09 10:36:30 --> Language Class Initialized
INFO - 2019-11-09 10:36:30 --> Language Class Initialized
INFO - 2019-11-09 10:36:30 --> Config Class Initialized
INFO - 2019-11-09 10:36:30 --> Loader Class Initialized
INFO - 2019-11-09 10:36:30 --> Helper loaded: url_helper
INFO - 2019-11-09 10:36:30 --> Helper loaded: common_helper
INFO - 2019-11-09 10:36:30 --> Helper loaded: language_helper
INFO - 2019-11-09 10:36:30 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:36:30 --> Helper loaded: email_helper
INFO - 2019-11-09 10:36:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:36:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:36:30 --> Parser Class Initialized
INFO - 2019-11-09 10:36:30 --> User Agent Class Initialized
INFO - 2019-11-09 10:36:30 --> Model Class Initialized
INFO - 2019-11-09 10:36:30 --> Database Driver Class Initialized
INFO - 2019-11-09 10:36:30 --> Model Class Initialized
DEBUG - 2019-11-09 10:36:30 --> Template Class Initialized
INFO - 2019-11-09 10:36:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:36:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:36:30 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:36:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:36:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:36:30 --> Encryption Class Initialized
INFO - 2019-11-09 10:36:30 --> Controller Class Initialized
DEBUG - 2019-11-09 10:36:30 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:36:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:36:30 --> Model Class Initialized
INFO - 2019-11-09 10:36:30 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 10:36:30 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 10:36:30 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 10:36:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 10:36:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 10:36:30 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 10:36:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 10:36:30 --> Model Class Initialized
DEBUG - 2019-11-09 10:36:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 10:36:30 --> Model Class Initialized
DEBUG - 2019-11-09 10:36:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 10:36:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 10:36:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 10:36:30 --> Final output sent to browser
DEBUG - 2019-11-09 10:36:30 --> Total execution time: 0.9142
INFO - 2019-11-09 10:36:42 --> Config Class Initialized
INFO - 2019-11-09 10:36:42 --> Hooks Class Initialized
DEBUG - 2019-11-09 10:36:42 --> UTF-8 Support Enabled
INFO - 2019-11-09 10:36:42 --> Utf8 Class Initialized
INFO - 2019-11-09 10:36:42 --> URI Class Initialized
INFO - 2019-11-09 10:36:42 --> Router Class Initialized
INFO - 2019-11-09 10:36:42 --> Output Class Initialized
INFO - 2019-11-09 10:36:42 --> Security Class Initialized
DEBUG - 2019-11-09 10:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 10:36:42 --> CSRF cookie sent
INFO - 2019-11-09 10:36:42 --> CSRF token verified
INFO - 2019-11-09 10:36:42 --> Input Class Initialized
INFO - 2019-11-09 10:36:42 --> Language Class Initialized
INFO - 2019-11-09 10:36:42 --> Language Class Initialized
INFO - 2019-11-09 10:36:42 --> Config Class Initialized
INFO - 2019-11-09 10:36:42 --> Loader Class Initialized
INFO - 2019-11-09 10:36:42 --> Helper loaded: url_helper
INFO - 2019-11-09 10:36:42 --> Helper loaded: common_helper
INFO - 2019-11-09 10:36:42 --> Helper loaded: language_helper
INFO - 2019-11-09 10:36:42 --> Helper loaded: cookie_helper
INFO - 2019-11-09 10:36:42 --> Helper loaded: email_helper
INFO - 2019-11-09 10:36:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 10:36:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 10:36:42 --> Parser Class Initialized
INFO - 2019-11-09 10:36:42 --> User Agent Class Initialized
INFO - 2019-11-09 10:36:42 --> Model Class Initialized
INFO - 2019-11-09 10:36:42 --> Database Driver Class Initialized
INFO - 2019-11-09 10:36:42 --> Model Class Initialized
DEBUG - 2019-11-09 10:36:42 --> Template Class Initialized
INFO - 2019-11-09 10:36:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 10:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 10:36:42 --> Pagination Class Initialized
DEBUG - 2019-11-09 10:36:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 10:36:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 10:36:42 --> Encryption Class Initialized
INFO - 2019-11-09 10:36:42 --> Controller Class Initialized
DEBUG - 2019-11-09 10:36:42 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 10:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 10:36:42 --> Model Class Initialized
DEBUG - 2019-11-09 10:36:42 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 10:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
DEBUG - 2019-11-09 10:36:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paypal/index.php
INFO - 2019-11-09 10:36:47 --> Final output sent to browser
DEBUG - 2019-11-09 10:36:47 --> Total execution time: 5.6380
INFO - 2019-11-09 11:04:46 --> Config Class Initialized
INFO - 2019-11-09 11:04:47 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:04:47 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:04:47 --> Utf8 Class Initialized
INFO - 2019-11-09 11:04:47 --> URI Class Initialized
INFO - 2019-11-09 11:04:47 --> Router Class Initialized
INFO - 2019-11-09 11:04:47 --> Output Class Initialized
INFO - 2019-11-09 11:04:47 --> Security Class Initialized
DEBUG - 2019-11-09 11:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:04:47 --> CSRF cookie sent
INFO - 2019-11-09 11:04:47 --> CSRF token verified
INFO - 2019-11-09 11:04:47 --> Input Class Initialized
INFO - 2019-11-09 11:04:47 --> Language Class Initialized
INFO - 2019-11-09 11:04:47 --> Language Class Initialized
INFO - 2019-11-09 11:04:47 --> Config Class Initialized
INFO - 2019-11-09 11:04:47 --> Loader Class Initialized
INFO - 2019-11-09 11:04:47 --> Helper loaded: url_helper
INFO - 2019-11-09 11:04:47 --> Helper loaded: common_helper
INFO - 2019-11-09 11:04:47 --> Helper loaded: language_helper
INFO - 2019-11-09 11:04:47 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:04:47 --> Helper loaded: email_helper
INFO - 2019-11-09 11:04:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:04:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:04:47 --> Parser Class Initialized
INFO - 2019-11-09 11:04:47 --> User Agent Class Initialized
INFO - 2019-11-09 11:04:47 --> Model Class Initialized
INFO - 2019-11-09 11:04:47 --> Database Driver Class Initialized
INFO - 2019-11-09 11:04:47 --> Model Class Initialized
DEBUG - 2019-11-09 11:04:47 --> Template Class Initialized
INFO - 2019-11-09 11:04:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:04:47 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:04:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:04:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:04:47 --> Encryption Class Initialized
INFO - 2019-11-09 11:04:47 --> Controller Class Initialized
DEBUG - 2019-11-09 11:04:47 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:04:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:04:47 --> Model Class Initialized
INFO - 2019-11-09 11:04:47 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:04:47 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:04:47 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:04:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:04:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:04:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:04:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:04:47 --> Model Class Initialized
DEBUG - 2019-11-09 11:04:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:04:47 --> Model Class Initialized
DEBUG - 2019-11-09 11:04:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:04:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:04:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:04:47 --> Final output sent to browser
DEBUG - 2019-11-09 11:04:47 --> Total execution time: 0.8849
INFO - 2019-11-09 11:05:03 --> Config Class Initialized
INFO - 2019-11-09 11:05:03 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:05:03 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:05:03 --> Utf8 Class Initialized
INFO - 2019-11-09 11:05:03 --> URI Class Initialized
INFO - 2019-11-09 11:05:03 --> Router Class Initialized
INFO - 2019-11-09 11:05:03 --> Output Class Initialized
INFO - 2019-11-09 11:05:03 --> Security Class Initialized
DEBUG - 2019-11-09 11:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:05:03 --> CSRF cookie sent
INFO - 2019-11-09 11:05:03 --> CSRF token verified
INFO - 2019-11-09 11:05:03 --> Input Class Initialized
INFO - 2019-11-09 11:05:03 --> Language Class Initialized
INFO - 2019-11-09 11:05:03 --> Language Class Initialized
INFO - 2019-11-09 11:05:03 --> Config Class Initialized
INFO - 2019-11-09 11:05:03 --> Loader Class Initialized
INFO - 2019-11-09 11:05:03 --> Helper loaded: url_helper
INFO - 2019-11-09 11:05:03 --> Helper loaded: common_helper
INFO - 2019-11-09 11:05:03 --> Helper loaded: language_helper
INFO - 2019-11-09 11:05:04 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:05:04 --> Helper loaded: email_helper
INFO - 2019-11-09 11:05:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:05:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:05:04 --> Parser Class Initialized
INFO - 2019-11-09 11:05:04 --> User Agent Class Initialized
INFO - 2019-11-09 11:05:04 --> Model Class Initialized
INFO - 2019-11-09 11:05:04 --> Database Driver Class Initialized
INFO - 2019-11-09 11:05:04 --> Model Class Initialized
DEBUG - 2019-11-09 11:05:04 --> Template Class Initialized
INFO - 2019-11-09 11:05:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:05:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:05:04 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:05:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:05:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:05:04 --> Encryption Class Initialized
INFO - 2019-11-09 11:05:04 --> Controller Class Initialized
DEBUG - 2019-11-09 11:05:04 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:05:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:05:04 --> Model Class Initialized
DEBUG - 2019-11-09 11:05:04 --> paytm MX_Controller Initialized
DEBUG - 2019-11-09 11:05:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 11:05:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
ERROR - 2019-11-09 11:05:04 --> Severity: Notice --> Undefined variable: module D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\index.php 2
ERROR - 2019-11-09 11:05:04 --> Severity: Notice --> Undefined variable: payment_method D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\index.php 2
ERROR - 2019-11-09 11:05:04 --> Severity: Notice --> Undefined variable: item_ids D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\index.php 5
ERROR - 2019-11-09 11:05:04 --> Severity: Notice --> Undefined variable: email D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\index.php 6
ERROR - 2019-11-09 11:05:04 --> Severity: Notice --> Undefined variable: link D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\index.php 7
ERROR - 2019-11-09 11:05:04 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\index.php 8
DEBUG - 2019-11-09 11:05:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 11:05:04 --> Final output sent to browser
DEBUG - 2019-11-09 11:05:04 --> Total execution time: 0.7640
INFO - 2019-11-09 11:06:08 --> Config Class Initialized
INFO - 2019-11-09 11:06:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:06:08 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:06:08 --> Utf8 Class Initialized
INFO - 2019-11-09 11:06:08 --> URI Class Initialized
INFO - 2019-11-09 11:06:08 --> Router Class Initialized
INFO - 2019-11-09 11:06:08 --> Output Class Initialized
INFO - 2019-11-09 11:06:08 --> Security Class Initialized
DEBUG - 2019-11-09 11:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:06:09 --> CSRF cookie sent
INFO - 2019-11-09 11:06:09 --> CSRF token verified
INFO - 2019-11-09 11:06:09 --> Input Class Initialized
INFO - 2019-11-09 11:06:09 --> Language Class Initialized
INFO - 2019-11-09 11:06:09 --> Language Class Initialized
INFO - 2019-11-09 11:06:09 --> Config Class Initialized
INFO - 2019-11-09 11:06:09 --> Loader Class Initialized
INFO - 2019-11-09 11:06:09 --> Helper loaded: url_helper
INFO - 2019-11-09 11:06:09 --> Helper loaded: common_helper
INFO - 2019-11-09 11:06:09 --> Helper loaded: language_helper
INFO - 2019-11-09 11:06:09 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:06:09 --> Helper loaded: email_helper
INFO - 2019-11-09 11:06:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:06:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:06:09 --> Parser Class Initialized
INFO - 2019-11-09 11:06:09 --> User Agent Class Initialized
INFO - 2019-11-09 11:06:09 --> Model Class Initialized
INFO - 2019-11-09 11:06:09 --> Database Driver Class Initialized
INFO - 2019-11-09 11:06:09 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:09 --> Template Class Initialized
INFO - 2019-11-09 11:06:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:06:09 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:06:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:06:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:06:09 --> Encryption Class Initialized
INFO - 2019-11-09 11:06:09 --> Controller Class Initialized
DEBUG - 2019-11-09 11:06:09 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:06:09 --> Model Class Initialized
INFO - 2019-11-09 11:06:09 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:06:09 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:06:09 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:06:09 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:06:09 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:06:09 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:06:09 --> Final output sent to browser
DEBUG - 2019-11-09 11:06:09 --> Total execution time: 0.9819
INFO - 2019-11-09 11:06:21 --> Config Class Initialized
INFO - 2019-11-09 11:06:21 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:06:21 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:06:21 --> Utf8 Class Initialized
INFO - 2019-11-09 11:06:21 --> URI Class Initialized
INFO - 2019-11-09 11:06:21 --> Router Class Initialized
INFO - 2019-11-09 11:06:21 --> Output Class Initialized
INFO - 2019-11-09 11:06:21 --> Security Class Initialized
DEBUG - 2019-11-09 11:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:06:21 --> CSRF cookie sent
INFO - 2019-11-09 11:06:21 --> CSRF token verified
INFO - 2019-11-09 11:06:21 --> Input Class Initialized
INFO - 2019-11-09 11:06:21 --> Language Class Initialized
INFO - 2019-11-09 11:06:21 --> Language Class Initialized
INFO - 2019-11-09 11:06:21 --> Config Class Initialized
INFO - 2019-11-09 11:06:21 --> Loader Class Initialized
INFO - 2019-11-09 11:06:21 --> Helper loaded: url_helper
INFO - 2019-11-09 11:06:21 --> Helper loaded: common_helper
INFO - 2019-11-09 11:06:21 --> Helper loaded: language_helper
INFO - 2019-11-09 11:06:21 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:06:21 --> Helper loaded: email_helper
INFO - 2019-11-09 11:06:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:06:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:06:21 --> Parser Class Initialized
INFO - 2019-11-09 11:06:21 --> User Agent Class Initialized
INFO - 2019-11-09 11:06:21 --> Model Class Initialized
INFO - 2019-11-09 11:06:21 --> Database Driver Class Initialized
INFO - 2019-11-09 11:06:21 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:21 --> Template Class Initialized
INFO - 2019-11-09 11:06:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:06:21 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:06:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:06:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:06:21 --> Encryption Class Initialized
INFO - 2019-11-09 11:06:21 --> Controller Class Initialized
DEBUG - 2019-11-09 11:06:21 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:06:21 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:21 --> paytm MX_Controller Initialized
DEBUG - 2019-11-09 11:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 11:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-09 11:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 11:06:21 --> Final output sent to browser
DEBUG - 2019-11-09 11:06:21 --> Total execution time: 0.6630
INFO - 2019-11-09 11:06:54 --> Config Class Initialized
INFO - 2019-11-09 11:06:54 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:06:54 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:06:54 --> Utf8 Class Initialized
INFO - 2019-11-09 11:06:54 --> URI Class Initialized
INFO - 2019-11-09 11:06:54 --> Router Class Initialized
INFO - 2019-11-09 11:06:54 --> Output Class Initialized
INFO - 2019-11-09 11:06:54 --> Security Class Initialized
DEBUG - 2019-11-09 11:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:06:54 --> Input Class Initialized
INFO - 2019-11-09 11:06:54 --> Language Class Initialized
INFO - 2019-11-09 11:06:54 --> Language Class Initialized
INFO - 2019-11-09 11:06:54 --> Config Class Initialized
INFO - 2019-11-09 11:06:54 --> Loader Class Initialized
INFO - 2019-11-09 11:06:54 --> Helper loaded: url_helper
INFO - 2019-11-09 11:06:54 --> Helper loaded: common_helper
INFO - 2019-11-09 11:06:54 --> Helper loaded: language_helper
INFO - 2019-11-09 11:06:54 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:06:54 --> Helper loaded: email_helper
INFO - 2019-11-09 11:06:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:06:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:06:54 --> Parser Class Initialized
INFO - 2019-11-09 11:06:54 --> User Agent Class Initialized
INFO - 2019-11-09 11:06:54 --> Model Class Initialized
INFO - 2019-11-09 11:06:54 --> Database Driver Class Initialized
INFO - 2019-11-09 11:06:54 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:54 --> Template Class Initialized
INFO - 2019-11-09 11:06:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:06:54 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:06:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:06:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:06:54 --> Encryption Class Initialized
INFO - 2019-11-09 11:06:54 --> Controller Class Initialized
DEBUG - 2019-11-09 11:06:54 --> paytm MX_Controller Initialized
INFO - 2019-11-09 11:06:54 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 11:06:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-09 11:06:54 --> orders MX_Controller Initialized
INFO - 2019-11-09 11:06:54 --> Config Class Initialized
INFO - 2019-11-09 11:06:54 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:06:54 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:06:54 --> Utf8 Class Initialized
INFO - 2019-11-09 11:06:54 --> URI Class Initialized
INFO - 2019-11-09 11:06:54 --> Router Class Initialized
INFO - 2019-11-09 11:06:54 --> Output Class Initialized
INFO - 2019-11-09 11:06:54 --> Security Class Initialized
DEBUG - 2019-11-09 11:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:06:54 --> CSRF cookie sent
INFO - 2019-11-09 11:06:54 --> Input Class Initialized
INFO - 2019-11-09 11:06:54 --> Language Class Initialized
INFO - 2019-11-09 11:06:54 --> Language Class Initialized
INFO - 2019-11-09 11:06:54 --> Config Class Initialized
INFO - 2019-11-09 11:06:54 --> Loader Class Initialized
INFO - 2019-11-09 11:06:55 --> Helper loaded: url_helper
INFO - 2019-11-09 11:06:55 --> Helper loaded: common_helper
INFO - 2019-11-09 11:06:55 --> Helper loaded: language_helper
INFO - 2019-11-09 11:06:55 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:06:55 --> Helper loaded: email_helper
INFO - 2019-11-09 11:06:55 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:06:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:06:55 --> Parser Class Initialized
INFO - 2019-11-09 11:06:55 --> User Agent Class Initialized
INFO - 2019-11-09 11:06:55 --> Model Class Initialized
INFO - 2019-11-09 11:06:55 --> Database Driver Class Initialized
INFO - 2019-11-09 11:06:55 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:55 --> Template Class Initialized
INFO - 2019-11-09 11:06:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:06:55 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:06:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:06:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:06:55 --> Encryption Class Initialized
INFO - 2019-11-09 11:06:55 --> Controller Class Initialized
DEBUG - 2019-11-09 11:06:55 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:06:55 --> Model Class Initialized
INFO - 2019-11-09 11:06:55 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 11:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-09 11:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:06:55 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:06:55 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:06:55 --> Model Class Initialized
DEBUG - 2019-11-09 11:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:06:55 --> Final output sent to browser
DEBUG - 2019-11-09 11:06:55 --> Total execution time: 0.8454
INFO - 2019-11-09 11:15:33 --> Config Class Initialized
INFO - 2019-11-09 11:15:33 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:15:33 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:15:33 --> Utf8 Class Initialized
INFO - 2019-11-09 11:15:33 --> URI Class Initialized
INFO - 2019-11-09 11:15:33 --> Router Class Initialized
INFO - 2019-11-09 11:15:33 --> Output Class Initialized
INFO - 2019-11-09 11:15:33 --> Security Class Initialized
DEBUG - 2019-11-09 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:15:33 --> Input Class Initialized
INFO - 2019-11-09 11:15:33 --> Language Class Initialized
INFO - 2019-11-09 11:15:33 --> Language Class Initialized
INFO - 2019-11-09 11:15:33 --> Config Class Initialized
INFO - 2019-11-09 11:15:33 --> Loader Class Initialized
INFO - 2019-11-09 11:15:33 --> Helper loaded: url_helper
INFO - 2019-11-09 11:15:33 --> Helper loaded: common_helper
INFO - 2019-11-09 11:15:33 --> Helper loaded: language_helper
INFO - 2019-11-09 11:15:33 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:15:33 --> Helper loaded: email_helper
INFO - 2019-11-09 11:15:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:15:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:15:33 --> Parser Class Initialized
INFO - 2019-11-09 11:15:34 --> User Agent Class Initialized
INFO - 2019-11-09 11:15:34 --> Model Class Initialized
INFO - 2019-11-09 11:15:34 --> Database Driver Class Initialized
INFO - 2019-11-09 11:15:34 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:34 --> Template Class Initialized
INFO - 2019-11-09 11:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:15:34 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:15:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:15:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:15:34 --> Encryption Class Initialized
INFO - 2019-11-09 11:15:34 --> Controller Class Initialized
DEBUG - 2019-11-09 11:15:34 --> paytm MX_Controller Initialized
INFO - 2019-11-09 11:15:34 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 11:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-09 11:15:34 --> Config Class Initialized
INFO - 2019-11-09 11:15:34 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:15:34 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:15:34 --> Utf8 Class Initialized
INFO - 2019-11-09 11:15:34 --> URI Class Initialized
INFO - 2019-11-09 11:15:34 --> Router Class Initialized
INFO - 2019-11-09 11:15:34 --> Output Class Initialized
INFO - 2019-11-09 11:15:34 --> Security Class Initialized
DEBUG - 2019-11-09 11:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:15:34 --> CSRF cookie sent
INFO - 2019-11-09 11:15:34 --> Input Class Initialized
INFO - 2019-11-09 11:15:34 --> Language Class Initialized
INFO - 2019-11-09 11:15:34 --> Language Class Initialized
INFO - 2019-11-09 11:15:34 --> Config Class Initialized
INFO - 2019-11-09 11:15:34 --> Loader Class Initialized
INFO - 2019-11-09 11:15:34 --> Helper loaded: url_helper
INFO - 2019-11-09 11:15:34 --> Helper loaded: common_helper
INFO - 2019-11-09 11:15:34 --> Helper loaded: language_helper
INFO - 2019-11-09 11:15:34 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:15:34 --> Helper loaded: email_helper
INFO - 2019-11-09 11:15:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:15:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:15:34 --> Parser Class Initialized
INFO - 2019-11-09 11:15:34 --> User Agent Class Initialized
INFO - 2019-11-09 11:15:34 --> Model Class Initialized
INFO - 2019-11-09 11:15:34 --> Database Driver Class Initialized
INFO - 2019-11-09 11:15:34 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:34 --> Template Class Initialized
INFO - 2019-11-09 11:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:15:34 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:15:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:15:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:15:34 --> Encryption Class Initialized
INFO - 2019-11-09 11:15:34 --> Controller Class Initialized
DEBUG - 2019-11-09 11:15:34 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:15:34 --> Model Class Initialized
INFO - 2019-11-09 11:15:34 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 11:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-11-09 11:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:15:34 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:15:34 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:15:35 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:15:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:15:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:15:35 --> Final output sent to browser
DEBUG - 2019-11-09 11:15:35 --> Total execution time: 0.8353
INFO - 2019-11-09 11:15:37 --> Config Class Initialized
INFO - 2019-11-09 11:15:37 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:15:37 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:15:37 --> Utf8 Class Initialized
INFO - 2019-11-09 11:15:37 --> URI Class Initialized
INFO - 2019-11-09 11:15:37 --> Router Class Initialized
INFO - 2019-11-09 11:15:37 --> Output Class Initialized
INFO - 2019-11-09 11:15:37 --> Security Class Initialized
DEBUG - 2019-11-09 11:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:15:37 --> CSRF cookie sent
INFO - 2019-11-09 11:15:37 --> Input Class Initialized
INFO - 2019-11-09 11:15:37 --> Language Class Initialized
INFO - 2019-11-09 11:15:38 --> Language Class Initialized
INFO - 2019-11-09 11:15:38 --> Config Class Initialized
INFO - 2019-11-09 11:15:38 --> Loader Class Initialized
INFO - 2019-11-09 11:15:38 --> Helper loaded: url_helper
INFO - 2019-11-09 11:15:38 --> Helper loaded: common_helper
INFO - 2019-11-09 11:15:38 --> Helper loaded: language_helper
INFO - 2019-11-09 11:15:38 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:15:38 --> Helper loaded: email_helper
INFO - 2019-11-09 11:15:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:15:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:15:38 --> Parser Class Initialized
INFO - 2019-11-09 11:15:38 --> User Agent Class Initialized
INFO - 2019-11-09 11:15:38 --> Model Class Initialized
INFO - 2019-11-09 11:15:38 --> Database Driver Class Initialized
INFO - 2019-11-09 11:15:38 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:38 --> Template Class Initialized
INFO - 2019-11-09 11:15:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:15:38 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:15:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:15:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:15:38 --> Encryption Class Initialized
INFO - 2019-11-09 11:15:38 --> Controller Class Initialized
DEBUG - 2019-11-09 11:15:38 --> package MX_Controller Initialized
DEBUG - 2019-11-09 11:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 11:15:38 --> Model Class Initialized
INFO - 2019-11-09 11:15:38 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 11:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:15:38 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:15:38 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:15:38 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 11:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 11:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:15:38 --> Final output sent to browser
DEBUG - 2019-11-09 11:15:38 --> Total execution time: 0.9072
INFO - 2019-11-09 11:15:41 --> Config Class Initialized
INFO - 2019-11-09 11:15:41 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:15:41 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:15:41 --> Utf8 Class Initialized
INFO - 2019-11-09 11:15:41 --> URI Class Initialized
INFO - 2019-11-09 11:15:41 --> Router Class Initialized
INFO - 2019-11-09 11:15:41 --> Output Class Initialized
INFO - 2019-11-09 11:15:41 --> Security Class Initialized
DEBUG - 2019-11-09 11:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:15:41 --> CSRF cookie sent
INFO - 2019-11-09 11:15:41 --> CSRF token verified
INFO - 2019-11-09 11:15:41 --> Input Class Initialized
INFO - 2019-11-09 11:15:41 --> Language Class Initialized
INFO - 2019-11-09 11:15:41 --> Language Class Initialized
INFO - 2019-11-09 11:15:41 --> Config Class Initialized
INFO - 2019-11-09 11:15:41 --> Loader Class Initialized
INFO - 2019-11-09 11:15:41 --> Helper loaded: url_helper
INFO - 2019-11-09 11:15:41 --> Helper loaded: common_helper
INFO - 2019-11-09 11:15:41 --> Helper loaded: language_helper
INFO - 2019-11-09 11:15:41 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:15:41 --> Helper loaded: email_helper
INFO - 2019-11-09 11:15:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:15:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:15:41 --> Parser Class Initialized
INFO - 2019-11-09 11:15:41 --> User Agent Class Initialized
INFO - 2019-11-09 11:15:41 --> Model Class Initialized
INFO - 2019-11-09 11:15:41 --> Database Driver Class Initialized
INFO - 2019-11-09 11:15:41 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:41 --> Template Class Initialized
INFO - 2019-11-09 11:15:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:15:41 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:15:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:15:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:15:41 --> Encryption Class Initialized
INFO - 2019-11-09 11:15:41 --> Controller Class Initialized
DEBUG - 2019-11-09 11:15:42 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:15:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:15:42 --> Model Class Initialized
INFO - 2019-11-09 11:15:42 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:15:42 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:15:42 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:15:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:15:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:15:42 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:15:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:15:42 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:15:42 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:15:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:15:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:15:42 --> Final output sent to browser
DEBUG - 2019-11-09 11:15:42 --> Total execution time: 1.0344
INFO - 2019-11-09 11:15:50 --> Config Class Initialized
INFO - 2019-11-09 11:15:50 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:15:50 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:15:50 --> Utf8 Class Initialized
INFO - 2019-11-09 11:15:50 --> URI Class Initialized
INFO - 2019-11-09 11:15:50 --> Router Class Initialized
INFO - 2019-11-09 11:15:50 --> Output Class Initialized
INFO - 2019-11-09 11:15:50 --> Security Class Initialized
DEBUG - 2019-11-09 11:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:15:50 --> CSRF cookie sent
INFO - 2019-11-09 11:15:50 --> CSRF token verified
INFO - 2019-11-09 11:15:50 --> Input Class Initialized
INFO - 2019-11-09 11:15:50 --> Language Class Initialized
INFO - 2019-11-09 11:15:50 --> Language Class Initialized
INFO - 2019-11-09 11:15:50 --> Config Class Initialized
INFO - 2019-11-09 11:15:50 --> Loader Class Initialized
INFO - 2019-11-09 11:15:50 --> Helper loaded: url_helper
INFO - 2019-11-09 11:15:51 --> Helper loaded: common_helper
INFO - 2019-11-09 11:15:51 --> Helper loaded: language_helper
INFO - 2019-11-09 11:15:51 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:15:51 --> Helper loaded: email_helper
INFO - 2019-11-09 11:15:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:15:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:15:51 --> Parser Class Initialized
INFO - 2019-11-09 11:15:51 --> User Agent Class Initialized
INFO - 2019-11-09 11:15:51 --> Model Class Initialized
INFO - 2019-11-09 11:15:51 --> Database Driver Class Initialized
INFO - 2019-11-09 11:15:51 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:51 --> Template Class Initialized
INFO - 2019-11-09 11:15:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:15:51 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:15:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:15:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:15:51 --> Encryption Class Initialized
INFO - 2019-11-09 11:15:51 --> Controller Class Initialized
DEBUG - 2019-11-09 11:15:51 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:15:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:15:51 --> Model Class Initialized
INFO - 2019-11-09 11:15:55 --> Config Class Initialized
INFO - 2019-11-09 11:15:55 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:15:55 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:15:55 --> Utf8 Class Initialized
INFO - 2019-11-09 11:15:55 --> URI Class Initialized
INFO - 2019-11-09 11:15:55 --> Router Class Initialized
INFO - 2019-11-09 11:15:55 --> Output Class Initialized
INFO - 2019-11-09 11:15:56 --> Security Class Initialized
DEBUG - 2019-11-09 11:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:15:56 --> CSRF cookie sent
INFO - 2019-11-09 11:15:56 --> CSRF token verified
INFO - 2019-11-09 11:15:56 --> Input Class Initialized
INFO - 2019-11-09 11:15:56 --> Language Class Initialized
INFO - 2019-11-09 11:15:56 --> Language Class Initialized
INFO - 2019-11-09 11:15:56 --> Config Class Initialized
INFO - 2019-11-09 11:15:56 --> Loader Class Initialized
INFO - 2019-11-09 11:15:56 --> Helper loaded: url_helper
INFO - 2019-11-09 11:15:56 --> Helper loaded: common_helper
INFO - 2019-11-09 11:15:56 --> Helper loaded: language_helper
INFO - 2019-11-09 11:15:56 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:15:56 --> Helper loaded: email_helper
INFO - 2019-11-09 11:15:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:15:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:15:56 --> Parser Class Initialized
INFO - 2019-11-09 11:15:56 --> User Agent Class Initialized
INFO - 2019-11-09 11:15:56 --> Model Class Initialized
INFO - 2019-11-09 11:15:56 --> Database Driver Class Initialized
INFO - 2019-11-09 11:15:56 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:56 --> Template Class Initialized
INFO - 2019-11-09 11:15:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:15:56 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:15:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:15:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:15:56 --> Encryption Class Initialized
INFO - 2019-11-09 11:15:56 --> Controller Class Initialized
DEBUG - 2019-11-09 11:15:56 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:15:56 --> Model Class Initialized
DEBUG - 2019-11-09 11:15:56 --> cardinity MX_Controller Initialized
DEBUG - 2019-11-09 11:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/cardinity_form.php
INFO - 2019-11-09 11:15:56 --> Final output sent to browser
DEBUG - 2019-11-09 11:15:56 --> Total execution time: 0.7189
INFO - 2019-11-09 11:17:17 --> Config Class Initialized
INFO - 2019-11-09 11:17:17 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:17:17 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:17:17 --> Utf8 Class Initialized
INFO - 2019-11-09 11:17:17 --> URI Class Initialized
INFO - 2019-11-09 11:17:17 --> Router Class Initialized
INFO - 2019-11-09 11:17:17 --> Output Class Initialized
INFO - 2019-11-09 11:17:17 --> Security Class Initialized
DEBUG - 2019-11-09 11:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:17:17 --> CSRF cookie sent
INFO - 2019-11-09 11:17:17 --> CSRF token verified
INFO - 2019-11-09 11:17:17 --> Input Class Initialized
INFO - 2019-11-09 11:17:17 --> Language Class Initialized
INFO - 2019-11-09 11:17:17 --> Language Class Initialized
INFO - 2019-11-09 11:17:17 --> Config Class Initialized
INFO - 2019-11-09 11:17:17 --> Loader Class Initialized
INFO - 2019-11-09 11:17:17 --> Helper loaded: url_helper
INFO - 2019-11-09 11:17:17 --> Helper loaded: common_helper
INFO - 2019-11-09 11:17:17 --> Helper loaded: language_helper
INFO - 2019-11-09 11:17:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:17:17 --> Helper loaded: email_helper
INFO - 2019-11-09 11:17:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:17:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:17:17 --> Parser Class Initialized
INFO - 2019-11-09 11:17:17 --> User Agent Class Initialized
INFO - 2019-11-09 11:17:17 --> Model Class Initialized
INFO - 2019-11-09 11:17:17 --> Database Driver Class Initialized
INFO - 2019-11-09 11:17:17 --> Model Class Initialized
DEBUG - 2019-11-09 11:17:17 --> Template Class Initialized
INFO - 2019-11-09 11:17:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:17:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:17:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:17:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:17:17 --> Encryption Class Initialized
INFO - 2019-11-09 11:17:17 --> Controller Class Initialized
DEBUG - 2019-11-09 11:17:17 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:17:18 --> Model Class Initialized
DEBUG - 2019-11-09 11:17:18 --> cardinity MX_Controller Initialized
DEBUG - 2019-11-09 11:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/cardinity_form.php
INFO - 2019-11-09 11:17:18 --> Final output sent to browser
DEBUG - 2019-11-09 11:17:18 --> Total execution time: 0.6401
INFO - 2019-11-09 11:17:37 --> Config Class Initialized
INFO - 2019-11-09 11:17:37 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:17:37 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:17:37 --> Utf8 Class Initialized
INFO - 2019-11-09 11:17:37 --> URI Class Initialized
INFO - 2019-11-09 11:17:37 --> Router Class Initialized
INFO - 2019-11-09 11:17:37 --> Output Class Initialized
INFO - 2019-11-09 11:17:37 --> Security Class Initialized
DEBUG - 2019-11-09 11:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:17:37 --> CSRF cookie sent
INFO - 2019-11-09 11:17:37 --> CSRF token verified
INFO - 2019-11-09 11:17:37 --> Input Class Initialized
INFO - 2019-11-09 11:17:37 --> Language Class Initialized
INFO - 2019-11-09 11:17:37 --> Language Class Initialized
INFO - 2019-11-09 11:17:37 --> Config Class Initialized
INFO - 2019-11-09 11:17:37 --> Loader Class Initialized
INFO - 2019-11-09 11:17:37 --> Helper loaded: url_helper
INFO - 2019-11-09 11:17:37 --> Helper loaded: common_helper
INFO - 2019-11-09 11:17:37 --> Helper loaded: language_helper
INFO - 2019-11-09 11:17:37 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:17:37 --> Helper loaded: email_helper
INFO - 2019-11-09 11:17:37 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:17:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:17:37 --> Parser Class Initialized
INFO - 2019-11-09 11:17:37 --> User Agent Class Initialized
INFO - 2019-11-09 11:17:37 --> Model Class Initialized
INFO - 2019-11-09 11:17:37 --> Database Driver Class Initialized
INFO - 2019-11-09 11:17:37 --> Model Class Initialized
DEBUG - 2019-11-09 11:17:37 --> Template Class Initialized
INFO - 2019-11-09 11:17:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:17:37 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:17:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:17:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:17:37 --> Encryption Class Initialized
INFO - 2019-11-09 11:17:37 --> Controller Class Initialized
DEBUG - 2019-11-09 11:17:37 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:17:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:17:37 --> Model Class Initialized
INFO - 2019-11-09 11:17:37 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:17:37 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:17:37 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:17:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:17:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:17:37 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:17:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:17:37 --> Model Class Initialized
DEBUG - 2019-11-09 11:17:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:17:37 --> Model Class Initialized
DEBUG - 2019-11-09 11:17:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:17:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:17:38 --> Final output sent to browser
DEBUG - 2019-11-09 11:17:38 --> Total execution time: 1.0403
INFO - 2019-11-09 11:17:45 --> Config Class Initialized
INFO - 2019-11-09 11:17:45 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:17:45 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:17:45 --> Utf8 Class Initialized
INFO - 2019-11-09 11:17:45 --> URI Class Initialized
INFO - 2019-11-09 11:17:45 --> Router Class Initialized
INFO - 2019-11-09 11:17:45 --> Output Class Initialized
INFO - 2019-11-09 11:17:45 --> Security Class Initialized
DEBUG - 2019-11-09 11:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:17:45 --> CSRF cookie sent
INFO - 2019-11-09 11:17:45 --> CSRF token verified
INFO - 2019-11-09 11:17:45 --> Input Class Initialized
INFO - 2019-11-09 11:17:45 --> Language Class Initialized
INFO - 2019-11-09 11:17:45 --> Language Class Initialized
INFO - 2019-11-09 11:17:45 --> Config Class Initialized
INFO - 2019-11-09 11:17:45 --> Loader Class Initialized
INFO - 2019-11-09 11:17:45 --> Helper loaded: url_helper
INFO - 2019-11-09 11:17:45 --> Helper loaded: common_helper
INFO - 2019-11-09 11:17:45 --> Helper loaded: language_helper
INFO - 2019-11-09 11:17:45 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:17:45 --> Helper loaded: email_helper
INFO - 2019-11-09 11:17:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:17:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:17:45 --> Parser Class Initialized
INFO - 2019-11-09 11:17:45 --> User Agent Class Initialized
INFO - 2019-11-09 11:17:45 --> Model Class Initialized
INFO - 2019-11-09 11:17:45 --> Database Driver Class Initialized
INFO - 2019-11-09 11:17:45 --> Model Class Initialized
DEBUG - 2019-11-09 11:17:45 --> Template Class Initialized
INFO - 2019-11-09 11:17:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:17:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:17:46 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:17:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:17:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:17:46 --> Encryption Class Initialized
INFO - 2019-11-09 11:17:46 --> Controller Class Initialized
DEBUG - 2019-11-09 11:17:46 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:17:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:17:46 --> Model Class Initialized
ERROR - 2019-11-09 11:17:46 --> Severity: error --> Exception: syntax error, unexpected ''/index'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\coinbase.php 78
INFO - 2019-11-09 11:17:55 --> Config Class Initialized
INFO - 2019-11-09 11:17:55 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:17:55 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:17:55 --> Utf8 Class Initialized
INFO - 2019-11-09 11:17:55 --> URI Class Initialized
INFO - 2019-11-09 11:17:55 --> Router Class Initialized
INFO - 2019-11-09 11:17:55 --> Output Class Initialized
INFO - 2019-11-09 11:17:56 --> Security Class Initialized
DEBUG - 2019-11-09 11:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:17:56 --> CSRF cookie sent
INFO - 2019-11-09 11:17:56 --> CSRF token verified
INFO - 2019-11-09 11:17:56 --> Input Class Initialized
INFO - 2019-11-09 11:17:56 --> Language Class Initialized
INFO - 2019-11-09 11:17:56 --> Language Class Initialized
INFO - 2019-11-09 11:17:56 --> Config Class Initialized
INFO - 2019-11-09 11:17:56 --> Loader Class Initialized
INFO - 2019-11-09 11:17:56 --> Helper loaded: url_helper
INFO - 2019-11-09 11:17:56 --> Helper loaded: common_helper
INFO - 2019-11-09 11:17:56 --> Helper loaded: language_helper
INFO - 2019-11-09 11:17:56 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:17:56 --> Helper loaded: email_helper
INFO - 2019-11-09 11:17:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:17:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:17:56 --> Parser Class Initialized
INFO - 2019-11-09 11:17:56 --> User Agent Class Initialized
INFO - 2019-11-09 11:17:56 --> Model Class Initialized
INFO - 2019-11-09 11:17:56 --> Database Driver Class Initialized
INFO - 2019-11-09 11:17:56 --> Model Class Initialized
DEBUG - 2019-11-09 11:17:56 --> Template Class Initialized
INFO - 2019-11-09 11:17:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:17:56 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:17:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:17:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:17:56 --> Encryption Class Initialized
INFO - 2019-11-09 11:17:56 --> Controller Class Initialized
DEBUG - 2019-11-09 11:17:56 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:17:56 --> Model Class Initialized
INFO - 2019-11-09 11:17:56 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:17:56 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:17:56 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:17:56 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:17:56 --> Model Class Initialized
DEBUG - 2019-11-09 11:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:17:56 --> Model Class Initialized
DEBUG - 2019-11-09 11:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:17:56 --> Final output sent to browser
DEBUG - 2019-11-09 11:17:56 --> Total execution time: 1.0468
INFO - 2019-11-09 11:18:02 --> Config Class Initialized
INFO - 2019-11-09 11:18:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:18:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:18:02 --> Utf8 Class Initialized
INFO - 2019-11-09 11:18:02 --> URI Class Initialized
INFO - 2019-11-09 11:18:02 --> Router Class Initialized
INFO - 2019-11-09 11:18:02 --> Output Class Initialized
INFO - 2019-11-09 11:18:02 --> Security Class Initialized
DEBUG - 2019-11-09 11:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:18:02 --> CSRF cookie sent
INFO - 2019-11-09 11:18:02 --> CSRF token verified
INFO - 2019-11-09 11:18:02 --> Input Class Initialized
INFO - 2019-11-09 11:18:02 --> Language Class Initialized
INFO - 2019-11-09 11:18:02 --> Language Class Initialized
INFO - 2019-11-09 11:18:02 --> Config Class Initialized
INFO - 2019-11-09 11:18:02 --> Loader Class Initialized
INFO - 2019-11-09 11:18:02 --> Helper loaded: url_helper
INFO - 2019-11-09 11:18:02 --> Helper loaded: common_helper
INFO - 2019-11-09 11:18:02 --> Helper loaded: language_helper
INFO - 2019-11-09 11:18:02 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:18:02 --> Helper loaded: email_helper
INFO - 2019-11-09 11:18:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:18:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:18:03 --> Parser Class Initialized
INFO - 2019-11-09 11:18:03 --> User Agent Class Initialized
INFO - 2019-11-09 11:18:03 --> Model Class Initialized
INFO - 2019-11-09 11:18:03 --> Database Driver Class Initialized
INFO - 2019-11-09 11:18:03 --> Model Class Initialized
DEBUG - 2019-11-09 11:18:03 --> Template Class Initialized
INFO - 2019-11-09 11:18:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:18:03 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:18:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:18:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:18:03 --> Encryption Class Initialized
INFO - 2019-11-09 11:18:03 --> Controller Class Initialized
DEBUG - 2019-11-09 11:18:03 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:18:03 --> Model Class Initialized
ERROR - 2019-11-09 11:18:03 --> Severity: error --> Exception: syntax error, unexpected ''/index'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\coinbase.php 78
INFO - 2019-11-09 11:21:20 --> Config Class Initialized
INFO - 2019-11-09 11:21:20 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:21:20 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:21:20 --> Utf8 Class Initialized
INFO - 2019-11-09 11:21:20 --> URI Class Initialized
INFO - 2019-11-09 11:21:20 --> Router Class Initialized
INFO - 2019-11-09 11:21:20 --> Output Class Initialized
INFO - 2019-11-09 11:21:20 --> Security Class Initialized
DEBUG - 2019-11-09 11:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:21:20 --> CSRF cookie sent
INFO - 2019-11-09 11:21:20 --> CSRF token verified
INFO - 2019-11-09 11:21:20 --> Input Class Initialized
INFO - 2019-11-09 11:21:20 --> Language Class Initialized
INFO - 2019-11-09 11:21:20 --> Language Class Initialized
INFO - 2019-11-09 11:21:20 --> Config Class Initialized
INFO - 2019-11-09 11:21:20 --> Loader Class Initialized
INFO - 2019-11-09 11:21:20 --> Helper loaded: url_helper
INFO - 2019-11-09 11:21:20 --> Helper loaded: common_helper
INFO - 2019-11-09 11:21:20 --> Helper loaded: language_helper
INFO - 2019-11-09 11:21:20 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:21:20 --> Helper loaded: email_helper
INFO - 2019-11-09 11:21:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:21:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:21:20 --> Parser Class Initialized
INFO - 2019-11-09 11:21:20 --> User Agent Class Initialized
INFO - 2019-11-09 11:21:20 --> Model Class Initialized
INFO - 2019-11-09 11:21:20 --> Database Driver Class Initialized
INFO - 2019-11-09 11:21:20 --> Model Class Initialized
DEBUG - 2019-11-09 11:21:20 --> Template Class Initialized
INFO - 2019-11-09 11:21:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:21:21 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:21:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:21:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:21:21 --> Encryption Class Initialized
INFO - 2019-11-09 11:21:21 --> Controller Class Initialized
DEBUG - 2019-11-09 11:21:21 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:21:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:21:21 --> Model Class Initialized
INFO - 2019-11-09 11:21:21 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:21:21 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:21:21 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:21:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:21:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:21:21 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:21:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:21:21 --> Model Class Initialized
DEBUG - 2019-11-09 11:21:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:21:21 --> Model Class Initialized
DEBUG - 2019-11-09 11:21:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:21:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:21:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:21:21 --> Final output sent to browser
DEBUG - 2019-11-09 11:21:21 --> Total execution time: 0.9927
INFO - 2019-11-09 11:21:31 --> Config Class Initialized
INFO - 2019-11-09 11:21:31 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:21:31 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:21:31 --> Utf8 Class Initialized
INFO - 2019-11-09 11:21:31 --> URI Class Initialized
INFO - 2019-11-09 11:21:31 --> Router Class Initialized
INFO - 2019-11-09 11:21:31 --> Output Class Initialized
INFO - 2019-11-09 11:21:31 --> Security Class Initialized
DEBUG - 2019-11-09 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:21:31 --> CSRF cookie sent
INFO - 2019-11-09 11:21:31 --> CSRF token verified
INFO - 2019-11-09 11:21:31 --> Input Class Initialized
INFO - 2019-11-09 11:21:31 --> Language Class Initialized
INFO - 2019-11-09 11:21:31 --> Language Class Initialized
INFO - 2019-11-09 11:21:31 --> Config Class Initialized
INFO - 2019-11-09 11:21:31 --> Loader Class Initialized
INFO - 2019-11-09 11:21:31 --> Helper loaded: url_helper
INFO - 2019-11-09 11:21:31 --> Helper loaded: common_helper
INFO - 2019-11-09 11:21:31 --> Helper loaded: language_helper
INFO - 2019-11-09 11:21:31 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:21:31 --> Helper loaded: email_helper
INFO - 2019-11-09 11:21:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:21:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:21:31 --> Parser Class Initialized
INFO - 2019-11-09 11:21:31 --> User Agent Class Initialized
INFO - 2019-11-09 11:21:31 --> Model Class Initialized
INFO - 2019-11-09 11:21:31 --> Database Driver Class Initialized
INFO - 2019-11-09 11:21:31 --> Model Class Initialized
DEBUG - 2019-11-09 11:21:31 --> Template Class Initialized
INFO - 2019-11-09 11:21:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:21:31 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:21:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:21:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:21:31 --> Encryption Class Initialized
INFO - 2019-11-09 11:21:31 --> Controller Class Initialized
DEBUG - 2019-11-09 11:21:31 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:21:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:21:31 --> Model Class Initialized
DEBUG - 2019-11-09 11:21:31 --> coinbase MX_Controller Initialized
DEBUG - 2019-11-09 11:21:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinbase_api.php
DEBUG - 2019-11-09 11:21:33 --> orders MX_Controller Initialized
ERROR - 2019-11-09 11:21:33 --> Severity: Notice --> Undefined variable: response D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\coinbase.php 78
ERROR - 2019-11-09 11:21:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\coinbase.php 78
DEBUG - 2019-11-09 11:21:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinbase/index.php
INFO - 2019-11-09 11:21:33 --> Final output sent to browser
DEBUG - 2019-11-09 11:21:33 --> Total execution time: 2.8107
INFO - 2019-11-09 11:21:34 --> Config Class Initialized
INFO - 2019-11-09 11:21:34 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:21:34 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:21:34 --> Utf8 Class Initialized
INFO - 2019-11-09 11:21:34 --> URI Class Initialized
INFO - 2019-11-09 11:21:34 --> Router Class Initialized
INFO - 2019-11-09 11:21:34 --> Output Class Initialized
INFO - 2019-11-09 11:21:34 --> Security Class Initialized
DEBUG - 2019-11-09 11:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:21:34 --> CSRF cookie sent
INFO - 2019-11-09 11:21:34 --> CSRF token verified
INFO - 2019-11-09 11:21:34 --> Input Class Initialized
INFO - 2019-11-09 11:21:34 --> Language Class Initialized
INFO - 2019-11-09 11:21:34 --> Language Class Initialized
INFO - 2019-11-09 11:21:34 --> Config Class Initialized
INFO - 2019-11-09 11:21:34 --> Loader Class Initialized
INFO - 2019-11-09 11:21:34 --> Helper loaded: url_helper
INFO - 2019-11-09 11:21:34 --> Helper loaded: common_helper
INFO - 2019-11-09 11:21:34 --> Helper loaded: language_helper
INFO - 2019-11-09 11:21:34 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:21:34 --> Helper loaded: email_helper
INFO - 2019-11-09 11:21:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:21:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:21:34 --> Parser Class Initialized
INFO - 2019-11-09 11:21:34 --> User Agent Class Initialized
INFO - 2019-11-09 11:21:34 --> Model Class Initialized
INFO - 2019-11-09 11:21:34 --> Database Driver Class Initialized
INFO - 2019-11-09 11:21:34 --> Model Class Initialized
DEBUG - 2019-11-09 11:21:34 --> Template Class Initialized
INFO - 2019-11-09 11:21:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:21:34 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:21:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:21:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:21:34 --> Encryption Class Initialized
INFO - 2019-11-09 11:21:34 --> Controller Class Initialized
DEBUG - 2019-11-09 11:21:34 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:21:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:21:34 --> Model Class Initialized
INFO - 2019-11-09 11:21:34 --> Config Class Initialized
INFO - 2019-11-09 11:21:34 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:21:34 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:21:34 --> Utf8 Class Initialized
INFO - 2019-11-09 11:21:34 --> URI Class Initialized
DEBUG - 2019-11-09 11:21:34 --> No URI present. Default controller set.
INFO - 2019-11-09 11:21:34 --> Router Class Initialized
INFO - 2019-11-09 11:21:34 --> Output Class Initialized
INFO - 2019-11-09 11:21:34 --> Security Class Initialized
DEBUG - 2019-11-09 11:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:21:34 --> CSRF cookie sent
INFO - 2019-11-09 11:21:34 --> Input Class Initialized
INFO - 2019-11-09 11:21:34 --> Language Class Initialized
INFO - 2019-11-09 11:21:34 --> Language Class Initialized
INFO - 2019-11-09 11:21:34 --> Config Class Initialized
INFO - 2019-11-09 11:21:34 --> Loader Class Initialized
INFO - 2019-11-09 11:21:34 --> Helper loaded: url_helper
INFO - 2019-11-09 11:21:34 --> Helper loaded: common_helper
INFO - 2019-11-09 11:21:34 --> Helper loaded: language_helper
INFO - 2019-11-09 11:21:34 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:21:35 --> Helper loaded: email_helper
INFO - 2019-11-09 11:21:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:21:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:21:35 --> Parser Class Initialized
INFO - 2019-11-09 11:21:35 --> User Agent Class Initialized
INFO - 2019-11-09 11:21:35 --> Model Class Initialized
INFO - 2019-11-09 11:21:35 --> Database Driver Class Initialized
INFO - 2019-11-09 11:21:35 --> Model Class Initialized
DEBUG - 2019-11-09 11:21:35 --> Template Class Initialized
INFO - 2019-11-09 11:21:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:21:35 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:21:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:21:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:21:35 --> Encryption Class Initialized
DEBUG - 2019-11-09 11:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 11:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 11:21:35 --> Controller Class Initialized
DEBUG - 2019-11-09 11:21:35 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 11:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 11:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 11:21:35 --> Model Class Initialized
INFO - 2019-11-09 11:21:35 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 11:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 11:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 11:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 11:21:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 11:21:35 --> Final output sent to browser
DEBUG - 2019-11-09 11:21:35 --> Total execution time: 0.8231
INFO - 2019-11-09 11:22:14 --> Config Class Initialized
INFO - 2019-11-09 11:22:14 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:22:14 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:22:14 --> Utf8 Class Initialized
INFO - 2019-11-09 11:22:14 --> URI Class Initialized
INFO - 2019-11-09 11:22:14 --> Router Class Initialized
INFO - 2019-11-09 11:22:14 --> Output Class Initialized
INFO - 2019-11-09 11:22:14 --> Security Class Initialized
DEBUG - 2019-11-09 11:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:22:14 --> CSRF cookie sent
INFO - 2019-11-09 11:22:14 --> Input Class Initialized
INFO - 2019-11-09 11:22:14 --> Language Class Initialized
INFO - 2019-11-09 11:22:14 --> Language Class Initialized
INFO - 2019-11-09 11:22:14 --> Config Class Initialized
INFO - 2019-11-09 11:22:14 --> Loader Class Initialized
INFO - 2019-11-09 11:22:14 --> Helper loaded: url_helper
INFO - 2019-11-09 11:22:14 --> Helper loaded: common_helper
INFO - 2019-11-09 11:22:14 --> Helper loaded: language_helper
INFO - 2019-11-09 11:22:14 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:22:14 --> Helper loaded: email_helper
INFO - 2019-11-09 11:22:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:22:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:22:14 --> Parser Class Initialized
INFO - 2019-11-09 11:22:14 --> User Agent Class Initialized
INFO - 2019-11-09 11:22:14 --> Model Class Initialized
INFO - 2019-11-09 11:22:14 --> Database Driver Class Initialized
INFO - 2019-11-09 11:22:14 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:14 --> Template Class Initialized
INFO - 2019-11-09 11:22:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:22:14 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:22:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:22:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:22:14 --> Encryption Class Initialized
INFO - 2019-11-09 11:22:14 --> Controller Class Initialized
DEBUG - 2019-11-09 11:22:14 --> package MX_Controller Initialized
DEBUG - 2019-11-09 11:22:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 11:22:14 --> Model Class Initialized
INFO - 2019-11-09 11:22:14 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 11:22:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:22:14 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:22:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:22:14 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:22:14 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 11:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 11:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:22:15 --> Final output sent to browser
DEBUG - 2019-11-09 11:22:15 --> Total execution time: 1.1691
INFO - 2019-11-09 11:22:18 --> Config Class Initialized
INFO - 2019-11-09 11:22:18 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:22:18 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:22:18 --> Utf8 Class Initialized
INFO - 2019-11-09 11:22:18 --> URI Class Initialized
INFO - 2019-11-09 11:22:18 --> Router Class Initialized
INFO - 2019-11-09 11:22:18 --> Output Class Initialized
INFO - 2019-11-09 11:22:18 --> Security Class Initialized
DEBUG - 2019-11-09 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:22:18 --> CSRF cookie sent
INFO - 2019-11-09 11:22:18 --> Input Class Initialized
INFO - 2019-11-09 11:22:18 --> Language Class Initialized
INFO - 2019-11-09 11:22:18 --> Language Class Initialized
INFO - 2019-11-09 11:22:18 --> Config Class Initialized
INFO - 2019-11-09 11:22:18 --> Loader Class Initialized
INFO - 2019-11-09 11:22:18 --> Helper loaded: url_helper
INFO - 2019-11-09 11:22:18 --> Helper loaded: common_helper
INFO - 2019-11-09 11:22:18 --> Helper loaded: language_helper
INFO - 2019-11-09 11:22:18 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:22:18 --> Helper loaded: email_helper
INFO - 2019-11-09 11:22:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:22:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:22:19 --> Parser Class Initialized
INFO - 2019-11-09 11:22:19 --> User Agent Class Initialized
INFO - 2019-11-09 11:22:19 --> Model Class Initialized
INFO - 2019-11-09 11:22:19 --> Database Driver Class Initialized
INFO - 2019-11-09 11:22:19 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:19 --> Template Class Initialized
INFO - 2019-11-09 11:22:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:22:19 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:22:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:22:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:22:19 --> Encryption Class Initialized
INFO - 2019-11-09 11:22:19 --> Controller Class Initialized
DEBUG - 2019-11-09 11:22:19 --> package MX_Controller Initialized
DEBUG - 2019-11-09 11:22:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 11:22:19 --> Model Class Initialized
INFO - 2019-11-09 11:22:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 11:22:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:22:19 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:22:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:22:19 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:22:19 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 11:22:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 11:22:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:22:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:22:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:22:19 --> Final output sent to browser
DEBUG - 2019-11-09 11:22:19 --> Total execution time: 1.0430
INFO - 2019-11-09 11:22:22 --> Config Class Initialized
INFO - 2019-11-09 11:22:22 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:22:22 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:22:22 --> Utf8 Class Initialized
INFO - 2019-11-09 11:22:22 --> URI Class Initialized
INFO - 2019-11-09 11:22:22 --> Router Class Initialized
INFO - 2019-11-09 11:22:22 --> Output Class Initialized
INFO - 2019-11-09 11:22:22 --> Security Class Initialized
DEBUG - 2019-11-09 11:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:22:22 --> CSRF cookie sent
INFO - 2019-11-09 11:22:22 --> CSRF token verified
INFO - 2019-11-09 11:22:22 --> Input Class Initialized
INFO - 2019-11-09 11:22:22 --> Language Class Initialized
INFO - 2019-11-09 11:22:22 --> Language Class Initialized
INFO - 2019-11-09 11:22:22 --> Config Class Initialized
INFO - 2019-11-09 11:22:22 --> Loader Class Initialized
INFO - 2019-11-09 11:22:22 --> Helper loaded: url_helper
INFO - 2019-11-09 11:22:22 --> Helper loaded: common_helper
INFO - 2019-11-09 11:22:22 --> Helper loaded: language_helper
INFO - 2019-11-09 11:22:22 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:22:22 --> Helper loaded: email_helper
INFO - 2019-11-09 11:22:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:22:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:22:22 --> Parser Class Initialized
INFO - 2019-11-09 11:22:22 --> User Agent Class Initialized
INFO - 2019-11-09 11:22:22 --> Model Class Initialized
INFO - 2019-11-09 11:22:22 --> Database Driver Class Initialized
INFO - 2019-11-09 11:22:22 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:22 --> Template Class Initialized
INFO - 2019-11-09 11:22:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:22:22 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:22:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:22:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:22:22 --> Encryption Class Initialized
INFO - 2019-11-09 11:22:22 --> Controller Class Initialized
DEBUG - 2019-11-09 11:22:22 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:22:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:22:22 --> Model Class Initialized
INFO - 2019-11-09 11:22:22 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:22:22 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:22:22 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:22:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:22:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:22:22 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:22:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:22:22 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:22:22 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:22:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:22:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:22:23 --> Final output sent to browser
DEBUG - 2019-11-09 11:22:23 --> Total execution time: 1.0218
INFO - 2019-11-09 11:22:29 --> Config Class Initialized
INFO - 2019-11-09 11:22:29 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:22:29 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:22:29 --> Utf8 Class Initialized
INFO - 2019-11-09 11:22:29 --> URI Class Initialized
INFO - 2019-11-09 11:22:29 --> Router Class Initialized
INFO - 2019-11-09 11:22:29 --> Output Class Initialized
INFO - 2019-11-09 11:22:30 --> Security Class Initialized
DEBUG - 2019-11-09 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:22:30 --> CSRF cookie sent
INFO - 2019-11-09 11:22:30 --> CSRF token verified
INFO - 2019-11-09 11:22:30 --> Input Class Initialized
INFO - 2019-11-09 11:22:30 --> Language Class Initialized
INFO - 2019-11-09 11:22:30 --> Language Class Initialized
INFO - 2019-11-09 11:22:30 --> Config Class Initialized
INFO - 2019-11-09 11:22:30 --> Loader Class Initialized
INFO - 2019-11-09 11:22:30 --> Helper loaded: url_helper
INFO - 2019-11-09 11:22:30 --> Helper loaded: common_helper
INFO - 2019-11-09 11:22:30 --> Helper loaded: language_helper
INFO - 2019-11-09 11:22:30 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:22:30 --> Helper loaded: email_helper
INFO - 2019-11-09 11:22:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:22:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:22:30 --> Parser Class Initialized
INFO - 2019-11-09 11:22:30 --> User Agent Class Initialized
INFO - 2019-11-09 11:22:30 --> Model Class Initialized
INFO - 2019-11-09 11:22:30 --> Database Driver Class Initialized
INFO - 2019-11-09 11:22:30 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:30 --> Template Class Initialized
INFO - 2019-11-09 11:22:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:22:30 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:22:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:22:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:22:30 --> Encryption Class Initialized
INFO - 2019-11-09 11:22:30 --> Controller Class Initialized
DEBUG - 2019-11-09 11:22:30 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:22:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:22:30 --> Model Class Initialized
DEBUG - 2019-11-09 11:22:30 --> paytm MX_Controller Initialized
DEBUG - 2019-11-09 11:22:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 11:22:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-09 11:22:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 11:22:30 --> Final output sent to browser
DEBUG - 2019-11-09 11:22:30 --> Total execution time: 0.7327
INFO - 2019-11-09 11:24:02 --> Config Class Initialized
INFO - 2019-11-09 11:24:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:24:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:24:02 --> Utf8 Class Initialized
INFO - 2019-11-09 11:24:02 --> URI Class Initialized
INFO - 2019-11-09 11:24:02 --> Router Class Initialized
INFO - 2019-11-09 11:24:02 --> Output Class Initialized
INFO - 2019-11-09 11:24:02 --> Security Class Initialized
DEBUG - 2019-11-09 11:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:24:02 --> CSRF cookie sent
INFO - 2019-11-09 11:24:02 --> CSRF token verified
INFO - 2019-11-09 11:24:02 --> Input Class Initialized
INFO - 2019-11-09 11:24:02 --> Language Class Initialized
INFO - 2019-11-09 11:24:03 --> Language Class Initialized
INFO - 2019-11-09 11:24:03 --> Config Class Initialized
INFO - 2019-11-09 11:24:03 --> Loader Class Initialized
INFO - 2019-11-09 11:24:03 --> Helper loaded: url_helper
INFO - 2019-11-09 11:24:03 --> Helper loaded: common_helper
INFO - 2019-11-09 11:24:03 --> Helper loaded: language_helper
INFO - 2019-11-09 11:24:03 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:24:03 --> Helper loaded: email_helper
INFO - 2019-11-09 11:24:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:24:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:24:03 --> Parser Class Initialized
INFO - 2019-11-09 11:24:03 --> User Agent Class Initialized
INFO - 2019-11-09 11:24:03 --> Model Class Initialized
INFO - 2019-11-09 11:24:03 --> Database Driver Class Initialized
INFO - 2019-11-09 11:24:03 --> Model Class Initialized
DEBUG - 2019-11-09 11:24:03 --> Template Class Initialized
INFO - 2019-11-09 11:24:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:24:03 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:24:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:24:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:24:03 --> Encryption Class Initialized
INFO - 2019-11-09 11:24:03 --> Controller Class Initialized
DEBUG - 2019-11-09 11:24:03 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:24:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:24:03 --> Model Class Initialized
INFO - 2019-11-09 11:24:03 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:24:03 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:24:03 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:24:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:24:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:24:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:24:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:24:03 --> Model Class Initialized
DEBUG - 2019-11-09 11:24:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:24:03 --> Model Class Initialized
DEBUG - 2019-11-09 11:24:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:24:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:24:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:24:03 --> Final output sent to browser
DEBUG - 2019-11-09 11:24:03 --> Total execution time: 0.9813
INFO - 2019-11-09 11:24:13 --> Config Class Initialized
INFO - 2019-11-09 11:24:13 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:24:13 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:24:13 --> Utf8 Class Initialized
INFO - 2019-11-09 11:24:13 --> URI Class Initialized
INFO - 2019-11-09 11:24:13 --> Router Class Initialized
INFO - 2019-11-09 11:24:13 --> Output Class Initialized
INFO - 2019-11-09 11:24:13 --> Security Class Initialized
DEBUG - 2019-11-09 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:24:13 --> CSRF cookie sent
INFO - 2019-11-09 11:24:13 --> CSRF token verified
INFO - 2019-11-09 11:24:13 --> Input Class Initialized
INFO - 2019-11-09 11:24:13 --> Language Class Initialized
INFO - 2019-11-09 11:24:13 --> Language Class Initialized
INFO - 2019-11-09 11:24:13 --> Config Class Initialized
INFO - 2019-11-09 11:24:13 --> Loader Class Initialized
INFO - 2019-11-09 11:24:13 --> Helper loaded: url_helper
INFO - 2019-11-09 11:24:13 --> Helper loaded: common_helper
INFO - 2019-11-09 11:24:13 --> Helper loaded: language_helper
INFO - 2019-11-09 11:24:13 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:24:13 --> Helper loaded: email_helper
INFO - 2019-11-09 11:24:13 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:24:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:24:13 --> Parser Class Initialized
INFO - 2019-11-09 11:24:13 --> User Agent Class Initialized
INFO - 2019-11-09 11:24:14 --> Model Class Initialized
INFO - 2019-11-09 11:24:14 --> Database Driver Class Initialized
INFO - 2019-11-09 11:24:14 --> Model Class Initialized
DEBUG - 2019-11-09 11:24:14 --> Template Class Initialized
INFO - 2019-11-09 11:24:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:24:14 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:24:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:24:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:24:14 --> Encryption Class Initialized
INFO - 2019-11-09 11:24:14 --> Controller Class Initialized
DEBUG - 2019-11-09 11:24:14 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:24:14 --> Model Class Initialized
DEBUG - 2019-11-09 11:24:14 --> cardinity MX_Controller Initialized
DEBUG - 2019-11-09 11:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/cardinity_form.php
INFO - 2019-11-09 11:24:14 --> Final output sent to browser
DEBUG - 2019-11-09 11:24:14 --> Total execution time: 0.7279
INFO - 2019-11-09 11:25:43 --> Config Class Initialized
INFO - 2019-11-09 11:25:43 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:25:43 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:25:43 --> Utf8 Class Initialized
INFO - 2019-11-09 11:25:43 --> URI Class Initialized
INFO - 2019-11-09 11:25:43 --> Router Class Initialized
INFO - 2019-11-09 11:25:43 --> Output Class Initialized
INFO - 2019-11-09 11:25:43 --> Security Class Initialized
DEBUG - 2019-11-09 11:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:25:43 --> CSRF cookie sent
INFO - 2019-11-09 11:25:43 --> CSRF token verified
INFO - 2019-11-09 11:25:43 --> Input Class Initialized
INFO - 2019-11-09 11:25:43 --> Language Class Initialized
INFO - 2019-11-09 11:25:44 --> Language Class Initialized
INFO - 2019-11-09 11:25:44 --> Config Class Initialized
INFO - 2019-11-09 11:25:44 --> Loader Class Initialized
INFO - 2019-11-09 11:25:44 --> Helper loaded: url_helper
INFO - 2019-11-09 11:25:44 --> Helper loaded: common_helper
INFO - 2019-11-09 11:25:44 --> Helper loaded: language_helper
INFO - 2019-11-09 11:25:44 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:25:44 --> Helper loaded: email_helper
INFO - 2019-11-09 11:25:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:25:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:25:44 --> Parser Class Initialized
INFO - 2019-11-09 11:25:44 --> User Agent Class Initialized
INFO - 2019-11-09 11:25:44 --> Model Class Initialized
INFO - 2019-11-09 11:25:44 --> Database Driver Class Initialized
INFO - 2019-11-09 11:25:44 --> Model Class Initialized
DEBUG - 2019-11-09 11:25:44 --> Template Class Initialized
INFO - 2019-11-09 11:25:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:25:44 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:25:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:25:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:25:44 --> Encryption Class Initialized
INFO - 2019-11-09 11:25:44 --> Controller Class Initialized
DEBUG - 2019-11-09 11:25:44 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:25:44 --> Model Class Initialized
INFO - 2019-11-09 11:25:44 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:25:44 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:25:44 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:25:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:25:44 --> Model Class Initialized
DEBUG - 2019-11-09 11:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:25:44 --> Model Class Initialized
DEBUG - 2019-11-09 11:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:25:44 --> Final output sent to browser
DEBUG - 2019-11-09 11:25:44 --> Total execution time: 0.9292
INFO - 2019-11-09 11:25:52 --> Config Class Initialized
INFO - 2019-11-09 11:25:52 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:25:52 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:25:52 --> Utf8 Class Initialized
INFO - 2019-11-09 11:25:52 --> URI Class Initialized
INFO - 2019-11-09 11:25:52 --> Router Class Initialized
INFO - 2019-11-09 11:25:52 --> Output Class Initialized
INFO - 2019-11-09 11:25:52 --> Security Class Initialized
DEBUG - 2019-11-09 11:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:25:52 --> CSRF cookie sent
INFO - 2019-11-09 11:25:52 --> CSRF token verified
INFO - 2019-11-09 11:25:52 --> Input Class Initialized
INFO - 2019-11-09 11:25:52 --> Language Class Initialized
INFO - 2019-11-09 11:25:52 --> Language Class Initialized
INFO - 2019-11-09 11:25:52 --> Config Class Initialized
INFO - 2019-11-09 11:25:52 --> Loader Class Initialized
INFO - 2019-11-09 11:25:52 --> Helper loaded: url_helper
INFO - 2019-11-09 11:25:52 --> Helper loaded: common_helper
INFO - 2019-11-09 11:25:52 --> Helper loaded: language_helper
INFO - 2019-11-09 11:25:52 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:25:52 --> Helper loaded: email_helper
INFO - 2019-11-09 11:25:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:25:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:25:52 --> Parser Class Initialized
INFO - 2019-11-09 11:25:52 --> User Agent Class Initialized
INFO - 2019-11-09 11:25:52 --> Model Class Initialized
INFO - 2019-11-09 11:25:52 --> Database Driver Class Initialized
INFO - 2019-11-09 11:25:52 --> Model Class Initialized
DEBUG - 2019-11-09 11:25:52 --> Template Class Initialized
INFO - 2019-11-09 11:25:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:25:52 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:25:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:25:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:25:52 --> Encryption Class Initialized
INFO - 2019-11-09 11:25:52 --> Controller Class Initialized
DEBUG - 2019-11-09 11:25:52 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:25:52 --> Model Class Initialized
DEBUG - 2019-11-09 11:25:52 --> paytm MX_Controller Initialized
DEBUG - 2019-11-09 11:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-09 11:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-09 11:25:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-09 11:25:52 --> Final output sent to browser
DEBUG - 2019-11-09 11:25:52 --> Total execution time: 0.7115
INFO - 2019-11-09 11:26:48 --> Config Class Initialized
INFO - 2019-11-09 11:26:48 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:26:48 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:26:48 --> Utf8 Class Initialized
INFO - 2019-11-09 11:26:48 --> URI Class Initialized
INFO - 2019-11-09 11:26:48 --> Router Class Initialized
INFO - 2019-11-09 11:26:48 --> Output Class Initialized
INFO - 2019-11-09 11:26:48 --> Security Class Initialized
DEBUG - 2019-11-09 11:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:26:48 --> CSRF cookie sent
INFO - 2019-11-09 11:26:48 --> CSRF token verified
INFO - 2019-11-09 11:26:48 --> Input Class Initialized
INFO - 2019-11-09 11:26:48 --> Language Class Initialized
INFO - 2019-11-09 11:26:48 --> Language Class Initialized
INFO - 2019-11-09 11:26:48 --> Config Class Initialized
INFO - 2019-11-09 11:26:48 --> Loader Class Initialized
INFO - 2019-11-09 11:26:49 --> Helper loaded: url_helper
INFO - 2019-11-09 11:26:49 --> Helper loaded: common_helper
INFO - 2019-11-09 11:26:49 --> Helper loaded: language_helper
INFO - 2019-11-09 11:26:49 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:26:49 --> Helper loaded: email_helper
INFO - 2019-11-09 11:26:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:26:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:26:49 --> Parser Class Initialized
INFO - 2019-11-09 11:26:49 --> User Agent Class Initialized
INFO - 2019-11-09 11:26:49 --> Model Class Initialized
INFO - 2019-11-09 11:26:49 --> Database Driver Class Initialized
INFO - 2019-11-09 11:26:49 --> Model Class Initialized
DEBUG - 2019-11-09 11:26:49 --> Template Class Initialized
INFO - 2019-11-09 11:26:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:26:49 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:26:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:26:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:26:49 --> Encryption Class Initialized
INFO - 2019-11-09 11:26:49 --> Controller Class Initialized
DEBUG - 2019-11-09 11:26:49 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:26:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:26:49 --> Model Class Initialized
DEBUG - 2019-11-09 11:26:49 --> coinbase MX_Controller Initialized
DEBUG - 2019-11-09 11:26:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinbase_api.php
DEBUG - 2019-11-09 11:26:50 --> orders MX_Controller Initialized
DEBUG - 2019-11-09 11:26:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinbase/index.php
INFO - 2019-11-09 11:26:50 --> Final output sent to browser
DEBUG - 2019-11-09 11:26:50 --> Total execution time: 2.0764
INFO - 2019-11-09 11:29:46 --> Config Class Initialized
INFO - 2019-11-09 11:29:46 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:29:46 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:29:46 --> Utf8 Class Initialized
INFO - 2019-11-09 11:29:46 --> URI Class Initialized
INFO - 2019-11-09 11:29:46 --> Router Class Initialized
INFO - 2019-11-09 11:29:46 --> Output Class Initialized
INFO - 2019-11-09 11:29:46 --> Security Class Initialized
DEBUG - 2019-11-09 11:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:29:46 --> CSRF cookie sent
INFO - 2019-11-09 11:29:46 --> CSRF token verified
INFO - 2019-11-09 11:29:46 --> Input Class Initialized
INFO - 2019-11-09 11:29:46 --> Language Class Initialized
INFO - 2019-11-09 11:29:46 --> Language Class Initialized
INFO - 2019-11-09 11:29:46 --> Config Class Initialized
INFO - 2019-11-09 11:29:46 --> Loader Class Initialized
INFO - 2019-11-09 11:29:46 --> Helper loaded: url_helper
INFO - 2019-11-09 11:29:46 --> Helper loaded: common_helper
INFO - 2019-11-09 11:29:46 --> Helper loaded: language_helper
INFO - 2019-11-09 11:29:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:29:46 --> Helper loaded: email_helper
INFO - 2019-11-09 11:29:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:29:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:29:46 --> Parser Class Initialized
INFO - 2019-11-09 11:29:46 --> User Agent Class Initialized
INFO - 2019-11-09 11:29:46 --> Model Class Initialized
INFO - 2019-11-09 11:29:46 --> Database Driver Class Initialized
INFO - 2019-11-09 11:29:46 --> Model Class Initialized
DEBUG - 2019-11-09 11:29:46 --> Template Class Initialized
INFO - 2019-11-09 11:29:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:29:46 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:29:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:29:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:29:46 --> Encryption Class Initialized
INFO - 2019-11-09 11:29:46 --> Controller Class Initialized
DEBUG - 2019-11-09 11:29:46 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:29:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:29:46 --> Model Class Initialized
INFO - 2019-11-09 11:29:46 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 11:29:46 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 11:29:46 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 11:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 11:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 11:29:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 11:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 11:29:47 --> Model Class Initialized
DEBUG - 2019-11-09 11:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 11:29:47 --> Model Class Initialized
DEBUG - 2019-11-09 11:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 11:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 11:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 11:29:47 --> Final output sent to browser
DEBUG - 2019-11-09 11:29:47 --> Total execution time: 0.9717
INFO - 2019-11-09 11:29:54 --> Config Class Initialized
INFO - 2019-11-09 11:29:54 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:29:54 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:29:54 --> Utf8 Class Initialized
INFO - 2019-11-09 11:29:54 --> URI Class Initialized
INFO - 2019-11-09 11:29:54 --> Router Class Initialized
INFO - 2019-11-09 11:29:54 --> Output Class Initialized
INFO - 2019-11-09 11:29:54 --> Security Class Initialized
DEBUG - 2019-11-09 11:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:29:54 --> CSRF cookie sent
INFO - 2019-11-09 11:29:54 --> CSRF token verified
INFO - 2019-11-09 11:29:54 --> Input Class Initialized
INFO - 2019-11-09 11:29:54 --> Language Class Initialized
INFO - 2019-11-09 11:29:54 --> Language Class Initialized
INFO - 2019-11-09 11:29:54 --> Config Class Initialized
INFO - 2019-11-09 11:29:54 --> Loader Class Initialized
INFO - 2019-11-09 11:29:54 --> Helper loaded: url_helper
INFO - 2019-11-09 11:29:54 --> Helper loaded: common_helper
INFO - 2019-11-09 11:29:54 --> Helper loaded: language_helper
INFO - 2019-11-09 11:29:54 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:29:54 --> Helper loaded: email_helper
INFO - 2019-11-09 11:29:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:29:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:29:54 --> Parser Class Initialized
INFO - 2019-11-09 11:29:55 --> User Agent Class Initialized
INFO - 2019-11-09 11:29:55 --> Model Class Initialized
INFO - 2019-11-09 11:29:55 --> Database Driver Class Initialized
INFO - 2019-11-09 11:29:55 --> Model Class Initialized
DEBUG - 2019-11-09 11:29:55 --> Template Class Initialized
INFO - 2019-11-09 11:29:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:29:55 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:29:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:29:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:29:55 --> Encryption Class Initialized
INFO - 2019-11-09 11:29:55 --> Controller Class Initialized
DEBUG - 2019-11-09 11:29:55 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:29:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:29:55 --> Model Class Initialized
INFO - 2019-11-09 11:29:59 --> Config Class Initialized
INFO - 2019-11-09 11:29:59 --> Hooks Class Initialized
DEBUG - 2019-11-09 11:29:59 --> UTF-8 Support Enabled
INFO - 2019-11-09 11:29:59 --> Utf8 Class Initialized
INFO - 2019-11-09 11:29:59 --> URI Class Initialized
INFO - 2019-11-09 11:29:59 --> Router Class Initialized
INFO - 2019-11-09 11:29:59 --> Output Class Initialized
INFO - 2019-11-09 11:29:59 --> Security Class Initialized
DEBUG - 2019-11-09 11:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 11:29:59 --> CSRF cookie sent
INFO - 2019-11-09 11:29:59 --> CSRF token verified
INFO - 2019-11-09 11:29:59 --> Input Class Initialized
INFO - 2019-11-09 11:29:59 --> Language Class Initialized
INFO - 2019-11-09 11:29:59 --> Language Class Initialized
INFO - 2019-11-09 11:29:59 --> Config Class Initialized
INFO - 2019-11-09 11:29:59 --> Loader Class Initialized
INFO - 2019-11-09 11:29:59 --> Helper loaded: url_helper
INFO - 2019-11-09 11:29:59 --> Helper loaded: common_helper
INFO - 2019-11-09 11:29:59 --> Helper loaded: language_helper
INFO - 2019-11-09 11:29:59 --> Helper loaded: cookie_helper
INFO - 2019-11-09 11:29:59 --> Helper loaded: email_helper
INFO - 2019-11-09 11:29:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 11:29:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 11:29:59 --> Parser Class Initialized
INFO - 2019-11-09 11:29:59 --> User Agent Class Initialized
INFO - 2019-11-09 11:29:59 --> Model Class Initialized
INFO - 2019-11-09 11:29:59 --> Database Driver Class Initialized
INFO - 2019-11-09 11:29:59 --> Model Class Initialized
DEBUG - 2019-11-09 11:29:59 --> Template Class Initialized
INFO - 2019-11-09 11:30:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 11:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 11:30:00 --> Pagination Class Initialized
DEBUG - 2019-11-09 11:30:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 11:30:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 11:30:00 --> Encryption Class Initialized
INFO - 2019-11-09 11:30:00 --> Controller Class Initialized
DEBUG - 2019-11-09 11:30:00 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 11:30:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 11:30:00 --> Model Class Initialized
DEBUG - 2019-11-09 11:30:00 --> coinbase MX_Controller Initialized
DEBUG - 2019-11-09 11:30:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinbase_api.php
DEBUG - 2019-11-09 11:30:02 --> orders MX_Controller Initialized
DEBUG - 2019-11-09 11:30:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinbase/index.php
INFO - 2019-11-09 11:30:02 --> Final output sent to browser
DEBUG - 2019-11-09 11:30:02 --> Total execution time: 2.9053
INFO - 2019-11-09 14:22:00 --> Config Class Initialized
INFO - 2019-11-09 14:22:00 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:22:00 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:22:00 --> Utf8 Class Initialized
INFO - 2019-11-09 14:22:00 --> URI Class Initialized
DEBUG - 2019-11-09 14:22:00 --> No URI present. Default controller set.
INFO - 2019-11-09 14:22:00 --> Router Class Initialized
INFO - 2019-11-09 14:22:00 --> Output Class Initialized
INFO - 2019-11-09 14:22:01 --> Security Class Initialized
DEBUG - 2019-11-09 14:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:22:01 --> CSRF cookie sent
INFO - 2019-11-09 14:22:01 --> Input Class Initialized
INFO - 2019-11-09 14:22:01 --> Language Class Initialized
INFO - 2019-11-09 14:22:01 --> Language Class Initialized
INFO - 2019-11-09 14:22:01 --> Config Class Initialized
INFO - 2019-11-09 14:22:01 --> Loader Class Initialized
INFO - 2019-11-09 14:22:01 --> Helper loaded: url_helper
INFO - 2019-11-09 14:22:01 --> Helper loaded: common_helper
INFO - 2019-11-09 14:22:01 --> Helper loaded: language_helper
INFO - 2019-11-09 14:22:01 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:22:01 --> Helper loaded: email_helper
INFO - 2019-11-09 14:22:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:22:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:22:01 --> Parser Class Initialized
INFO - 2019-11-09 14:22:01 --> User Agent Class Initialized
INFO - 2019-11-09 14:22:01 --> Model Class Initialized
INFO - 2019-11-09 14:22:01 --> Database Driver Class Initialized
INFO - 2019-11-09 14:22:01 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:01 --> Template Class Initialized
INFO - 2019-11-09 14:22:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:22:02 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:22:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:22:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:22:02 --> Encryption Class Initialized
DEBUG - 2019-11-09 14:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 14:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 14:22:02 --> Controller Class Initialized
DEBUG - 2019-11-09 14:22:02 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 14:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 14:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 14:22:02 --> Model Class Initialized
INFO - 2019-11-09 14:22:02 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 14:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 14:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 14:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 14:22:02 --> Final output sent to browser
DEBUG - 2019-11-09 14:22:02 --> Total execution time: 2.2338
INFO - 2019-11-09 14:22:08 --> Config Class Initialized
INFO - 2019-11-09 14:22:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:22:08 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:22:08 --> Utf8 Class Initialized
INFO - 2019-11-09 14:22:08 --> URI Class Initialized
INFO - 2019-11-09 14:22:08 --> Router Class Initialized
INFO - 2019-11-09 14:22:08 --> Output Class Initialized
INFO - 2019-11-09 14:22:08 --> Security Class Initialized
DEBUG - 2019-11-09 14:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:22:08 --> CSRF cookie sent
INFO - 2019-11-09 14:22:08 --> Input Class Initialized
INFO - 2019-11-09 14:22:08 --> Language Class Initialized
INFO - 2019-11-09 14:22:08 --> Language Class Initialized
INFO - 2019-11-09 14:22:08 --> Config Class Initialized
INFO - 2019-11-09 14:22:08 --> Loader Class Initialized
INFO - 2019-11-09 14:22:08 --> Helper loaded: url_helper
INFO - 2019-11-09 14:22:08 --> Helper loaded: common_helper
INFO - 2019-11-09 14:22:08 --> Helper loaded: language_helper
INFO - 2019-11-09 14:22:08 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:22:08 --> Helper loaded: email_helper
INFO - 2019-11-09 14:22:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:22:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:22:08 --> Parser Class Initialized
INFO - 2019-11-09 14:22:08 --> User Agent Class Initialized
INFO - 2019-11-09 14:22:08 --> Model Class Initialized
INFO - 2019-11-09 14:22:08 --> Database Driver Class Initialized
INFO - 2019-11-09 14:22:08 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:08 --> Template Class Initialized
INFO - 2019-11-09 14:22:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:22:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:22:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:22:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:22:09 --> Encryption Class Initialized
INFO - 2019-11-09 14:22:09 --> Controller Class Initialized
DEBUG - 2019-11-09 14:22:09 --> auth MX_Controller Initialized
DEBUG - 2019-11-09 14:22:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-09 14:22:09 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 14:22:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:22:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-09 14:22:09 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 14:22:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 14:22:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-09 14:22:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 14:22:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 14:22:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-09 14:22:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 14:22:09 --> Final output sent to browser
DEBUG - 2019-11-09 14:22:09 --> Total execution time: 1.3109
INFO - 2019-11-09 14:22:24 --> Config Class Initialized
INFO - 2019-11-09 14:22:24 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:22:24 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:22:24 --> Utf8 Class Initialized
INFO - 2019-11-09 14:22:24 --> URI Class Initialized
INFO - 2019-11-09 14:22:24 --> Router Class Initialized
INFO - 2019-11-09 14:22:24 --> Output Class Initialized
INFO - 2019-11-09 14:22:24 --> Security Class Initialized
DEBUG - 2019-11-09 14:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:22:24 --> CSRF cookie sent
INFO - 2019-11-09 14:22:24 --> CSRF token verified
INFO - 2019-11-09 14:22:24 --> Input Class Initialized
INFO - 2019-11-09 14:22:24 --> Language Class Initialized
INFO - 2019-11-09 14:22:24 --> Language Class Initialized
INFO - 2019-11-09 14:22:24 --> Config Class Initialized
INFO - 2019-11-09 14:22:24 --> Loader Class Initialized
INFO - 2019-11-09 14:22:24 --> Helper loaded: url_helper
INFO - 2019-11-09 14:22:24 --> Helper loaded: common_helper
INFO - 2019-11-09 14:22:24 --> Helper loaded: language_helper
INFO - 2019-11-09 14:22:24 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:22:24 --> Helper loaded: email_helper
INFO - 2019-11-09 14:22:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:22:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:22:25 --> Parser Class Initialized
INFO - 2019-11-09 14:22:25 --> User Agent Class Initialized
INFO - 2019-11-09 14:22:25 --> Model Class Initialized
INFO - 2019-11-09 14:22:25 --> Database Driver Class Initialized
INFO - 2019-11-09 14:22:25 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:25 --> Template Class Initialized
INFO - 2019-11-09 14:22:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:22:25 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:22:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:22:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:22:25 --> Encryption Class Initialized
INFO - 2019-11-09 14:22:25 --> Controller Class Initialized
DEBUG - 2019-11-09 14:22:25 --> auth MX_Controller Initialized
DEBUG - 2019-11-09 14:22:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-09 14:22:25 --> Model Class Initialized
INFO - 2019-11-09 14:22:29 --> Config Class Initialized
INFO - 2019-11-09 14:22:29 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:22:29 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:22:29 --> Utf8 Class Initialized
INFO - 2019-11-09 14:22:29 --> URI Class Initialized
INFO - 2019-11-09 14:22:29 --> Router Class Initialized
INFO - 2019-11-09 14:22:30 --> Output Class Initialized
INFO - 2019-11-09 14:22:30 --> Security Class Initialized
DEBUG - 2019-11-09 14:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:22:30 --> CSRF cookie sent
INFO - 2019-11-09 14:22:30 --> Input Class Initialized
INFO - 2019-11-09 14:22:30 --> Language Class Initialized
INFO - 2019-11-09 14:22:30 --> Language Class Initialized
INFO - 2019-11-09 14:22:30 --> Config Class Initialized
INFO - 2019-11-09 14:22:30 --> Loader Class Initialized
INFO - 2019-11-09 14:22:30 --> Helper loaded: url_helper
INFO - 2019-11-09 14:22:30 --> Helper loaded: common_helper
INFO - 2019-11-09 14:22:30 --> Helper loaded: language_helper
INFO - 2019-11-09 14:22:30 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:22:30 --> Helper loaded: email_helper
INFO - 2019-11-09 14:22:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:22:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:22:30 --> Parser Class Initialized
INFO - 2019-11-09 14:22:30 --> User Agent Class Initialized
INFO - 2019-11-09 14:22:30 --> Model Class Initialized
INFO - 2019-11-09 14:22:30 --> Database Driver Class Initialized
INFO - 2019-11-09 14:22:30 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:30 --> Template Class Initialized
INFO - 2019-11-09 14:22:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:22:30 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:22:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:22:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:22:30 --> Encryption Class Initialized
INFO - 2019-11-09 14:22:30 --> Controller Class Initialized
DEBUG - 2019-11-09 14:22:30 --> statistics MX_Controller Initialized
DEBUG - 2019-11-09 14:22:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-09 14:22:30 --> Model Class Initialized
ERROR - 2019-11-09 14:22:30 --> Could not find the language line "Pending"
ERROR - 2019-11-09 14:22:30 --> Could not find the language line "Pending"
INFO - 2019-11-09 14:22:30 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 14:22:30 --> Could not find the language line "total_orders"
ERROR - 2019-11-09 14:22:30 --> Could not find the language line "total_orders"
ERROR - 2019-11-09 14:22:30 --> Could not find the language line "Pending"
DEBUG - 2019-11-09 14:22:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-09 14:22:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:22:30 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:22:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:22:30 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:22:31 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 14:22:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 14:22:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 14:22:31 --> Final output sent to browser
DEBUG - 2019-11-09 14:22:31 --> Total execution time: 1.3630
INFO - 2019-11-09 14:22:35 --> Config Class Initialized
INFO - 2019-11-09 14:22:35 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:22:35 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:22:35 --> Utf8 Class Initialized
INFO - 2019-11-09 14:22:35 --> URI Class Initialized
INFO - 2019-11-09 14:22:35 --> Router Class Initialized
INFO - 2019-11-09 14:22:35 --> Output Class Initialized
INFO - 2019-11-09 14:22:35 --> Security Class Initialized
DEBUG - 2019-11-09 14:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:22:35 --> CSRF cookie sent
INFO - 2019-11-09 14:22:35 --> Input Class Initialized
INFO - 2019-11-09 14:22:35 --> Language Class Initialized
INFO - 2019-11-09 14:22:35 --> Language Class Initialized
INFO - 2019-11-09 14:22:35 --> Config Class Initialized
INFO - 2019-11-09 14:22:36 --> Loader Class Initialized
INFO - 2019-11-09 14:22:36 --> Helper loaded: url_helper
INFO - 2019-11-09 14:22:36 --> Helper loaded: common_helper
INFO - 2019-11-09 14:22:36 --> Helper loaded: language_helper
INFO - 2019-11-09 14:22:36 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:22:36 --> Helper loaded: email_helper
INFO - 2019-11-09 14:22:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:22:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:22:36 --> Parser Class Initialized
INFO - 2019-11-09 14:22:36 --> User Agent Class Initialized
INFO - 2019-11-09 14:22:36 --> Model Class Initialized
INFO - 2019-11-09 14:22:36 --> Database Driver Class Initialized
INFO - 2019-11-09 14:22:36 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:36 --> Template Class Initialized
INFO - 2019-11-09 14:22:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:22:36 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:22:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:22:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:22:36 --> Encryption Class Initialized
INFO - 2019-11-09 14:22:36 --> Controller Class Initialized
DEBUG - 2019-11-09 14:22:36 --> transactions MX_Controller Initialized
DEBUG - 2019-11-09 14:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-09 14:22:36 --> Model Class Initialized
ERROR - 2019-11-09 14:22:36 --> Could not find the language line "order_id"
INFO - 2019-11-09 14:22:36 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-09 14:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:22:36 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:22:36 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:22:36 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 14:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 14:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 14:22:36 --> Final output sent to browser
DEBUG - 2019-11-09 14:22:36 --> Total execution time: 1.0099
INFO - 2019-11-09 14:22:49 --> Config Class Initialized
INFO - 2019-11-09 14:22:49 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:22:49 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:22:49 --> Utf8 Class Initialized
INFO - 2019-11-09 14:22:49 --> URI Class Initialized
INFO - 2019-11-09 14:22:49 --> Router Class Initialized
INFO - 2019-11-09 14:22:49 --> Output Class Initialized
INFO - 2019-11-09 14:22:49 --> Security Class Initialized
DEBUG - 2019-11-09 14:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:22:49 --> CSRF cookie sent
INFO - 2019-11-09 14:22:49 --> Input Class Initialized
INFO - 2019-11-09 14:22:49 --> Language Class Initialized
INFO - 2019-11-09 14:22:49 --> Language Class Initialized
INFO - 2019-11-09 14:22:49 --> Config Class Initialized
INFO - 2019-11-09 14:22:49 --> Loader Class Initialized
INFO - 2019-11-09 14:22:49 --> Helper loaded: url_helper
INFO - 2019-11-09 14:22:49 --> Helper loaded: common_helper
INFO - 2019-11-09 14:22:49 --> Helper loaded: language_helper
INFO - 2019-11-09 14:22:49 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:22:49 --> Helper loaded: email_helper
INFO - 2019-11-09 14:22:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:22:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:22:49 --> Parser Class Initialized
INFO - 2019-11-09 14:22:49 --> User Agent Class Initialized
INFO - 2019-11-09 14:22:49 --> Model Class Initialized
INFO - 2019-11-09 14:22:49 --> Database Driver Class Initialized
INFO - 2019-11-09 14:22:49 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:49 --> Template Class Initialized
INFO - 2019-11-09 14:22:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:22:49 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:22:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:22:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:22:49 --> Encryption Class Initialized
INFO - 2019-11-09 14:22:49 --> Controller Class Initialized
DEBUG - 2019-11-09 14:22:49 --> setting MX_Controller Initialized
DEBUG - 2019-11-09 14:22:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-09 14:22:49 --> Model Class Initialized
INFO - 2019-11-09 14:22:49 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:22:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-09 14:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-09 14:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-09 14:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:22:50 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:22:50 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:22:50 --> Model Class Initialized
DEBUG - 2019-11-09 14:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 14:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 14:22:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 14:22:50 --> Final output sent to browser
DEBUG - 2019-11-09 14:22:50 --> Total execution time: 1.1567
INFO - 2019-11-09 14:25:43 --> Config Class Initialized
INFO - 2019-11-09 14:25:43 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:25:43 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:25:43 --> Utf8 Class Initialized
INFO - 2019-11-09 14:25:43 --> URI Class Initialized
INFO - 2019-11-09 14:25:43 --> Router Class Initialized
INFO - 2019-11-09 14:25:43 --> Output Class Initialized
INFO - 2019-11-09 14:25:43 --> Security Class Initialized
DEBUG - 2019-11-09 14:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:25:43 --> CSRF cookie sent
INFO - 2019-11-09 14:25:43 --> Input Class Initialized
INFO - 2019-11-09 14:25:43 --> Language Class Initialized
INFO - 2019-11-09 14:25:43 --> Language Class Initialized
INFO - 2019-11-09 14:25:43 --> Config Class Initialized
INFO - 2019-11-09 14:25:43 --> Loader Class Initialized
INFO - 2019-11-09 14:25:43 --> Helper loaded: url_helper
INFO - 2019-11-09 14:25:43 --> Helper loaded: common_helper
INFO - 2019-11-09 14:25:43 --> Helper loaded: language_helper
INFO - 2019-11-09 14:25:43 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:25:43 --> Helper loaded: email_helper
INFO - 2019-11-09 14:25:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:25:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:25:43 --> Parser Class Initialized
INFO - 2019-11-09 14:25:43 --> User Agent Class Initialized
INFO - 2019-11-09 14:25:43 --> Model Class Initialized
INFO - 2019-11-09 14:25:43 --> Database Driver Class Initialized
INFO - 2019-11-09 14:25:43 --> Model Class Initialized
DEBUG - 2019-11-09 14:25:43 --> Template Class Initialized
INFO - 2019-11-09 14:25:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:25:43 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:25:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:25:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:25:43 --> Encryption Class Initialized
INFO - 2019-11-09 14:25:43 --> Controller Class Initialized
DEBUG - 2019-11-09 14:25:43 --> setting MX_Controller Initialized
DEBUG - 2019-11-09 14:25:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-09 14:25:43 --> Model Class Initialized
INFO - 2019-11-09 14:25:43 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-09 14:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-09 14:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-09 14:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:25:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:25:44 --> Model Class Initialized
DEBUG - 2019-11-09 14:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:25:44 --> Model Class Initialized
DEBUG - 2019-11-09 14:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 14:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 14:25:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 14:25:44 --> Final output sent to browser
DEBUG - 2019-11-09 14:25:44 --> Total execution time: 1.1851
INFO - 2019-11-09 14:25:45 --> Config Class Initialized
INFO - 2019-11-09 14:25:45 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:25:45 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:25:45 --> Utf8 Class Initialized
INFO - 2019-11-09 14:25:45 --> URI Class Initialized
INFO - 2019-11-09 14:25:45 --> Router Class Initialized
INFO - 2019-11-09 14:25:45 --> Output Class Initialized
INFO - 2019-11-09 14:25:46 --> Security Class Initialized
DEBUG - 2019-11-09 14:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:25:46 --> CSRF cookie sent
INFO - 2019-11-09 14:25:46 --> Input Class Initialized
INFO - 2019-11-09 14:25:46 --> Language Class Initialized
INFO - 2019-11-09 14:25:46 --> Language Class Initialized
INFO - 2019-11-09 14:25:46 --> Config Class Initialized
INFO - 2019-11-09 14:25:46 --> Loader Class Initialized
INFO - 2019-11-09 14:25:46 --> Helper loaded: url_helper
INFO - 2019-11-09 14:25:46 --> Helper loaded: common_helper
INFO - 2019-11-09 14:25:46 --> Helper loaded: language_helper
INFO - 2019-11-09 14:25:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:25:46 --> Helper loaded: email_helper
INFO - 2019-11-09 14:25:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:25:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:25:46 --> Parser Class Initialized
INFO - 2019-11-09 14:25:46 --> User Agent Class Initialized
INFO - 2019-11-09 14:25:46 --> Model Class Initialized
INFO - 2019-11-09 14:25:46 --> Database Driver Class Initialized
INFO - 2019-11-09 14:25:46 --> Model Class Initialized
DEBUG - 2019-11-09 14:25:46 --> Template Class Initialized
INFO - 2019-11-09 14:25:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:25:46 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:25:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:25:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:25:46 --> Encryption Class Initialized
INFO - 2019-11-09 14:25:46 --> Controller Class Initialized
DEBUG - 2019-11-09 14:25:46 --> setting MX_Controller Initialized
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-09 14:25:46 --> Model Class Initialized
INFO - 2019-11-09 14:25:46 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-09 14:25:46 --> Could not find the language line "currency_rate"
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paystack.php
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:25:46 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:25:46 --> Model Class Initialized
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:25:46 --> Model Class Initialized
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 14:25:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 14:25:46 --> Final output sent to browser
DEBUG - 2019-11-09 14:25:46 --> Total execution time: 1.1164
INFO - 2019-11-09 14:27:12 --> Config Class Initialized
INFO - 2019-11-09 14:27:12 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:27:12 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:27:12 --> Utf8 Class Initialized
INFO - 2019-11-09 14:27:12 --> URI Class Initialized
INFO - 2019-11-09 14:27:12 --> Router Class Initialized
INFO - 2019-11-09 14:27:12 --> Output Class Initialized
INFO - 2019-11-09 14:27:12 --> Security Class Initialized
DEBUG - 2019-11-09 14:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:27:12 --> CSRF cookie sent
INFO - 2019-11-09 14:27:12 --> Input Class Initialized
INFO - 2019-11-09 14:27:12 --> Language Class Initialized
INFO - 2019-11-09 14:27:12 --> Language Class Initialized
INFO - 2019-11-09 14:27:12 --> Config Class Initialized
INFO - 2019-11-09 14:27:12 --> Loader Class Initialized
INFO - 2019-11-09 14:27:12 --> Helper loaded: url_helper
INFO - 2019-11-09 14:27:12 --> Helper loaded: common_helper
INFO - 2019-11-09 14:27:12 --> Helper loaded: language_helper
INFO - 2019-11-09 14:27:12 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:27:12 --> Helper loaded: email_helper
INFO - 2019-11-09 14:27:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:27:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:27:12 --> Parser Class Initialized
INFO - 2019-11-09 14:27:12 --> User Agent Class Initialized
INFO - 2019-11-09 14:27:12 --> Model Class Initialized
INFO - 2019-11-09 14:27:12 --> Database Driver Class Initialized
INFO - 2019-11-09 14:27:12 --> Model Class Initialized
DEBUG - 2019-11-09 14:27:12 --> Template Class Initialized
INFO - 2019-11-09 14:27:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:27:12 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:27:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:27:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:27:13 --> Encryption Class Initialized
INFO - 2019-11-09 14:27:13 --> Controller Class Initialized
DEBUG - 2019-11-09 14:27:13 --> setting MX_Controller Initialized
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-09 14:27:13 --> Model Class Initialized
INFO - 2019-11-09 14:27:13 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-09 14:27:13 --> Could not find the language line "currency_rate"
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paystack.php
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:27:13 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:27:13 --> Model Class Initialized
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:27:13 --> Model Class Initialized
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 14:27:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 14:27:13 --> Final output sent to browser
DEBUG - 2019-11-09 14:27:13 --> Total execution time: 1.1017
INFO - 2019-11-09 14:27:56 --> Config Class Initialized
INFO - 2019-11-09 14:27:56 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:27:56 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:27:56 --> Utf8 Class Initialized
INFO - 2019-11-09 14:27:56 --> URI Class Initialized
INFO - 2019-11-09 14:27:56 --> Router Class Initialized
INFO - 2019-11-09 14:27:56 --> Output Class Initialized
INFO - 2019-11-09 14:27:56 --> Security Class Initialized
DEBUG - 2019-11-09 14:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:27:56 --> CSRF cookie sent
INFO - 2019-11-09 14:27:56 --> Input Class Initialized
INFO - 2019-11-09 14:27:56 --> Language Class Initialized
INFO - 2019-11-09 14:27:56 --> Language Class Initialized
INFO - 2019-11-09 14:27:56 --> Config Class Initialized
INFO - 2019-11-09 14:27:56 --> Loader Class Initialized
INFO - 2019-11-09 14:27:56 --> Helper loaded: url_helper
INFO - 2019-11-09 14:27:56 --> Helper loaded: common_helper
INFO - 2019-11-09 14:27:56 --> Helper loaded: language_helper
INFO - 2019-11-09 14:27:56 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:27:56 --> Helper loaded: email_helper
INFO - 2019-11-09 14:27:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:27:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:27:56 --> Parser Class Initialized
INFO - 2019-11-09 14:27:56 --> User Agent Class Initialized
INFO - 2019-11-09 14:27:56 --> Model Class Initialized
INFO - 2019-11-09 14:27:56 --> Database Driver Class Initialized
INFO - 2019-11-09 14:27:56 --> Model Class Initialized
DEBUG - 2019-11-09 14:27:56 --> Template Class Initialized
INFO - 2019-11-09 14:27:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:27:56 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:27:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:27:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:27:56 --> Encryption Class Initialized
INFO - 2019-11-09 14:27:56 --> Controller Class Initialized
DEBUG - 2019-11-09 14:27:56 --> setting MX_Controller Initialized
DEBUG - 2019-11-09 14:27:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-09 14:27:56 --> Model Class Initialized
INFO - 2019-11-09 14:27:57 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-09 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paystack.php
DEBUG - 2019-11-09 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-09 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:27:57 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:27:57 --> Model Class Initialized
DEBUG - 2019-11-09 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:27:57 --> Model Class Initialized
DEBUG - 2019-11-09 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 14:27:57 --> Final output sent to browser
DEBUG - 2019-11-09 14:27:57 --> Total execution time: 1.0351
INFO - 2019-11-09 14:28:32 --> Config Class Initialized
INFO - 2019-11-09 14:28:32 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:28:33 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:28:33 --> Utf8 Class Initialized
INFO - 2019-11-09 14:28:33 --> URI Class Initialized
INFO - 2019-11-09 14:28:33 --> Router Class Initialized
INFO - 2019-11-09 14:28:33 --> Output Class Initialized
INFO - 2019-11-09 14:28:33 --> Security Class Initialized
DEBUG - 2019-11-09 14:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:28:33 --> CSRF cookie sent
INFO - 2019-11-09 14:28:33 --> Input Class Initialized
INFO - 2019-11-09 14:28:33 --> Language Class Initialized
INFO - 2019-11-09 14:28:33 --> Language Class Initialized
INFO - 2019-11-09 14:28:33 --> Config Class Initialized
INFO - 2019-11-09 14:28:33 --> Loader Class Initialized
INFO - 2019-11-09 14:28:33 --> Helper loaded: url_helper
INFO - 2019-11-09 14:28:33 --> Helper loaded: common_helper
INFO - 2019-11-09 14:28:33 --> Helper loaded: language_helper
INFO - 2019-11-09 14:28:33 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:28:33 --> Helper loaded: email_helper
INFO - 2019-11-09 14:28:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:28:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:28:33 --> Parser Class Initialized
INFO - 2019-11-09 14:28:33 --> User Agent Class Initialized
INFO - 2019-11-09 14:28:33 --> Model Class Initialized
INFO - 2019-11-09 14:28:33 --> Database Driver Class Initialized
INFO - 2019-11-09 14:28:33 --> Model Class Initialized
DEBUG - 2019-11-09 14:28:33 --> Template Class Initialized
INFO - 2019-11-09 14:28:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:28:33 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:28:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:28:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:28:33 --> Encryption Class Initialized
INFO - 2019-11-09 14:28:33 --> Controller Class Initialized
DEBUG - 2019-11-09 14:28:33 --> setting MX_Controller Initialized
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-09 14:28:33 --> Model Class Initialized
INFO - 2019-11-09 14:28:33 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paystack.php
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:28:33 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:28:33 --> Model Class Initialized
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:28:33 --> Model Class Initialized
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 14:28:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 14:28:34 --> Final output sent to browser
DEBUG - 2019-11-09 14:28:34 --> Total execution time: 1.0456
INFO - 2019-11-09 14:29:25 --> Config Class Initialized
INFO - 2019-11-09 14:29:25 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:29:25 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:29:25 --> Utf8 Class Initialized
INFO - 2019-11-09 14:29:25 --> URI Class Initialized
DEBUG - 2019-11-09 14:29:25 --> No URI present. Default controller set.
INFO - 2019-11-09 14:29:25 --> Router Class Initialized
INFO - 2019-11-09 14:29:25 --> Output Class Initialized
INFO - 2019-11-09 14:29:25 --> Security Class Initialized
DEBUG - 2019-11-09 14:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:29:25 --> CSRF cookie sent
INFO - 2019-11-09 14:29:25 --> Input Class Initialized
INFO - 2019-11-09 14:29:25 --> Language Class Initialized
INFO - 2019-11-09 14:29:25 --> Language Class Initialized
INFO - 2019-11-09 14:29:25 --> Config Class Initialized
INFO - 2019-11-09 14:29:25 --> Loader Class Initialized
INFO - 2019-11-09 14:29:25 --> Helper loaded: url_helper
INFO - 2019-11-09 14:29:25 --> Helper loaded: common_helper
INFO - 2019-11-09 14:29:25 --> Helper loaded: language_helper
INFO - 2019-11-09 14:29:25 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:29:25 --> Helper loaded: email_helper
INFO - 2019-11-09 14:29:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:29:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:29:25 --> Parser Class Initialized
INFO - 2019-11-09 14:29:25 --> User Agent Class Initialized
INFO - 2019-11-09 14:29:25 --> Model Class Initialized
INFO - 2019-11-09 14:29:25 --> Database Driver Class Initialized
INFO - 2019-11-09 14:29:25 --> Model Class Initialized
DEBUG - 2019-11-09 14:29:25 --> Template Class Initialized
INFO - 2019-11-09 14:29:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:29:25 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:29:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:29:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:29:25 --> Encryption Class Initialized
DEBUG - 2019-11-09 14:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 14:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 14:29:25 --> Controller Class Initialized
DEBUG - 2019-11-09 14:29:25 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 14:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 14:29:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 14:29:26 --> Model Class Initialized
INFO - 2019-11-09 14:29:26 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:29:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 14:29:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 14:29:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 14:29:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 14:29:26 --> Final output sent to browser
DEBUG - 2019-11-09 14:29:26 --> Total execution time: 0.8429
INFO - 2019-11-09 14:34:45 --> Config Class Initialized
INFO - 2019-11-09 14:34:45 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:34:45 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:34:45 --> Utf8 Class Initialized
INFO - 2019-11-09 14:34:45 --> URI Class Initialized
DEBUG - 2019-11-09 14:34:45 --> No URI present. Default controller set.
INFO - 2019-11-09 14:34:45 --> Router Class Initialized
INFO - 2019-11-09 14:34:45 --> Output Class Initialized
INFO - 2019-11-09 14:34:45 --> Security Class Initialized
DEBUG - 2019-11-09 14:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:34:45 --> CSRF cookie sent
INFO - 2019-11-09 14:34:45 --> Input Class Initialized
INFO - 2019-11-09 14:34:45 --> Language Class Initialized
INFO - 2019-11-09 14:34:45 --> Language Class Initialized
INFO - 2019-11-09 14:34:45 --> Config Class Initialized
INFO - 2019-11-09 14:34:45 --> Loader Class Initialized
INFO - 2019-11-09 14:34:45 --> Helper loaded: url_helper
INFO - 2019-11-09 14:34:45 --> Helper loaded: common_helper
INFO - 2019-11-09 14:34:45 --> Helper loaded: language_helper
INFO - 2019-11-09 14:34:45 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:34:45 --> Helper loaded: email_helper
INFO - 2019-11-09 14:34:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:34:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:34:45 --> Parser Class Initialized
INFO - 2019-11-09 14:34:45 --> User Agent Class Initialized
INFO - 2019-11-09 14:34:45 --> Model Class Initialized
INFO - 2019-11-09 14:34:46 --> Database Driver Class Initialized
INFO - 2019-11-09 14:34:46 --> Model Class Initialized
DEBUG - 2019-11-09 14:34:46 --> Template Class Initialized
INFO - 2019-11-09 14:34:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:34:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:34:46 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:34:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:34:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:34:46 --> Encryption Class Initialized
DEBUG - 2019-11-09 14:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 14:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 14:34:46 --> Controller Class Initialized
DEBUG - 2019-11-09 14:34:46 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 14:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 14:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 14:34:46 --> Model Class Initialized
INFO - 2019-11-09 14:34:46 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 14:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 14:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 14:34:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 14:34:46 --> Final output sent to browser
DEBUG - 2019-11-09 14:34:46 --> Total execution time: 1.0718
INFO - 2019-11-09 14:34:53 --> Config Class Initialized
INFO - 2019-11-09 14:34:53 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:34:53 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:34:53 --> Utf8 Class Initialized
INFO - 2019-11-09 14:34:53 --> URI Class Initialized
INFO - 2019-11-09 14:34:53 --> Router Class Initialized
INFO - 2019-11-09 14:34:53 --> Output Class Initialized
INFO - 2019-11-09 14:34:53 --> Security Class Initialized
DEBUG - 2019-11-09 14:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:34:53 --> CSRF cookie sent
INFO - 2019-11-09 14:34:53 --> CSRF token verified
INFO - 2019-11-09 14:34:53 --> Input Class Initialized
INFO - 2019-11-09 14:34:53 --> Language Class Initialized
INFO - 2019-11-09 14:34:53 --> Language Class Initialized
INFO - 2019-11-09 14:34:53 --> Config Class Initialized
INFO - 2019-11-09 14:34:53 --> Loader Class Initialized
INFO - 2019-11-09 14:34:53 --> Helper loaded: url_helper
INFO - 2019-11-09 14:34:53 --> Helper loaded: common_helper
INFO - 2019-11-09 14:34:53 --> Helper loaded: language_helper
INFO - 2019-11-09 14:34:53 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:34:53 --> Helper loaded: email_helper
INFO - 2019-11-09 14:34:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:34:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:34:53 --> Parser Class Initialized
INFO - 2019-11-09 14:34:53 --> User Agent Class Initialized
INFO - 2019-11-09 14:34:53 --> Model Class Initialized
INFO - 2019-11-09 14:34:53 --> Database Driver Class Initialized
INFO - 2019-11-09 14:34:53 --> Model Class Initialized
DEBUG - 2019-11-09 14:34:53 --> Template Class Initialized
INFO - 2019-11-09 14:34:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:34:54 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:34:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:34:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:34:54 --> Encryption Class Initialized
INFO - 2019-11-09 14:34:54 --> Controller Class Initialized
DEBUG - 2019-11-09 14:34:54 --> language MX_Controller Initialized
DEBUG - 2019-11-09 14:34:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-09 14:34:54 --> Model Class Initialized
INFO - 2019-11-09 14:34:55 --> Config Class Initialized
INFO - 2019-11-09 14:34:55 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:34:55 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:34:55 --> Utf8 Class Initialized
INFO - 2019-11-09 14:34:55 --> URI Class Initialized
DEBUG - 2019-11-09 14:34:55 --> No URI present. Default controller set.
INFO - 2019-11-09 14:34:55 --> Router Class Initialized
INFO - 2019-11-09 14:34:55 --> Output Class Initialized
INFO - 2019-11-09 14:34:55 --> Security Class Initialized
DEBUG - 2019-11-09 14:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:34:55 --> CSRF cookie sent
INFO - 2019-11-09 14:34:55 --> Input Class Initialized
INFO - 2019-11-09 14:34:55 --> Language Class Initialized
INFO - 2019-11-09 14:34:55 --> Language Class Initialized
INFO - 2019-11-09 14:34:55 --> Config Class Initialized
INFO - 2019-11-09 14:34:55 --> Loader Class Initialized
INFO - 2019-11-09 14:34:55 --> Helper loaded: url_helper
INFO - 2019-11-09 14:34:55 --> Helper loaded: common_helper
INFO - 2019-11-09 14:34:55 --> Helper loaded: language_helper
INFO - 2019-11-09 14:34:55 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:34:55 --> Helper loaded: email_helper
INFO - 2019-11-09 14:34:55 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:34:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:34:55 --> Parser Class Initialized
INFO - 2019-11-09 14:34:55 --> User Agent Class Initialized
INFO - 2019-11-09 14:34:55 --> Model Class Initialized
INFO - 2019-11-09 14:34:55 --> Database Driver Class Initialized
INFO - 2019-11-09 14:34:55 --> Model Class Initialized
DEBUG - 2019-11-09 14:34:55 --> Template Class Initialized
INFO - 2019-11-09 14:34:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:34:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:34:55 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:34:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:34:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:34:55 --> Encryption Class Initialized
DEBUG - 2019-11-09 14:34:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 14:34:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 14:34:56 --> Controller Class Initialized
DEBUG - 2019-11-09 14:34:56 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 14:34:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 14:34:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 14:34:56 --> Model Class Initialized
INFO - 2019-11-09 14:34:56 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:34:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 14:34:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 14:34:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 14:34:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 14:34:56 --> Final output sent to browser
DEBUG - 2019-11-09 14:34:56 --> Total execution time: 1.1476
INFO - 2019-11-09 14:34:58 --> Config Class Initialized
INFO - 2019-11-09 14:34:58 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:34:58 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:34:58 --> Utf8 Class Initialized
INFO - 2019-11-09 14:34:58 --> URI Class Initialized
INFO - 2019-11-09 14:34:58 --> Router Class Initialized
INFO - 2019-11-09 14:34:58 --> Output Class Initialized
INFO - 2019-11-09 14:34:58 --> Security Class Initialized
DEBUG - 2019-11-09 14:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:34:58 --> CSRF cookie sent
INFO - 2019-11-09 14:34:58 --> Input Class Initialized
INFO - 2019-11-09 14:34:58 --> Language Class Initialized
INFO - 2019-11-09 14:34:58 --> Language Class Initialized
INFO - 2019-11-09 14:34:58 --> Config Class Initialized
INFO - 2019-11-09 14:34:58 --> Loader Class Initialized
INFO - 2019-11-09 14:34:58 --> Helper loaded: url_helper
INFO - 2019-11-09 14:34:58 --> Helper loaded: common_helper
INFO - 2019-11-09 14:34:58 --> Helper loaded: language_helper
INFO - 2019-11-09 14:34:58 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:34:58 --> Helper loaded: email_helper
INFO - 2019-11-09 14:34:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:34:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:34:58 --> Parser Class Initialized
INFO - 2019-11-09 14:34:58 --> User Agent Class Initialized
INFO - 2019-11-09 14:34:58 --> Model Class Initialized
INFO - 2019-11-09 14:34:58 --> Database Driver Class Initialized
INFO - 2019-11-09 14:34:58 --> Model Class Initialized
DEBUG - 2019-11-09 14:34:58 --> Template Class Initialized
INFO - 2019-11-09 14:34:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:34:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:34:58 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:34:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:34:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:34:58 --> Encryption Class Initialized
INFO - 2019-11-09 14:34:58 --> Controller Class Initialized
DEBUG - 2019-11-09 14:34:58 --> package MX_Controller Initialized
DEBUG - 2019-11-09 14:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 14:34:58 --> Model Class Initialized
INFO - 2019-11-09 14:34:58 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:34:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:34:59 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:34:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:34:59 --> Model Class Initialized
DEBUG - 2019-11-09 14:34:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:34:59 --> Model Class Initialized
DEBUG - 2019-11-09 14:34:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 14:34:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 14:34:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 14:34:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 14:34:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 14:34:59 --> Final output sent to browser
DEBUG - 2019-11-09 14:34:59 --> Total execution time: 1.1402
INFO - 2019-11-09 14:35:02 --> Config Class Initialized
INFO - 2019-11-09 14:35:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:35:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:35:02 --> Utf8 Class Initialized
INFO - 2019-11-09 14:35:02 --> URI Class Initialized
INFO - 2019-11-09 14:35:02 --> Router Class Initialized
INFO - 2019-11-09 14:35:02 --> Output Class Initialized
INFO - 2019-11-09 14:35:02 --> Security Class Initialized
DEBUG - 2019-11-09 14:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:35:02 --> CSRF cookie sent
INFO - 2019-11-09 14:35:02 --> CSRF token verified
INFO - 2019-11-09 14:35:02 --> Input Class Initialized
INFO - 2019-11-09 14:35:02 --> Language Class Initialized
INFO - 2019-11-09 14:35:02 --> Language Class Initialized
INFO - 2019-11-09 14:35:02 --> Config Class Initialized
INFO - 2019-11-09 14:35:02 --> Loader Class Initialized
INFO - 2019-11-09 14:35:02 --> Helper loaded: url_helper
INFO - 2019-11-09 14:35:02 --> Helper loaded: common_helper
INFO - 2019-11-09 14:35:02 --> Helper loaded: language_helper
INFO - 2019-11-09 14:35:02 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:35:02 --> Helper loaded: email_helper
INFO - 2019-11-09 14:35:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:35:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:35:02 --> Parser Class Initialized
INFO - 2019-11-09 14:35:02 --> User Agent Class Initialized
INFO - 2019-11-09 14:35:02 --> Model Class Initialized
INFO - 2019-11-09 14:35:02 --> Database Driver Class Initialized
INFO - 2019-11-09 14:35:02 --> Model Class Initialized
DEBUG - 2019-11-09 14:35:02 --> Template Class Initialized
INFO - 2019-11-09 14:35:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:35:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:35:02 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:35:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:35:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:35:02 --> Encryption Class Initialized
INFO - 2019-11-09 14:35:03 --> Controller Class Initialized
DEBUG - 2019-11-09 14:35:03 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:35:03 --> Model Class Initialized
INFO - 2019-11-09 14:35:03 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 14:35:03 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 14:35:03 --> Could not find the language line "paystack"
ERROR - 2019-11-09 14:35:03 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 14:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 14:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:35:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:35:03 --> Model Class Initialized
DEBUG - 2019-11-09 14:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:35:03 --> Model Class Initialized
DEBUG - 2019-11-09 14:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 14:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 14:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 14:35:03 --> Final output sent to browser
DEBUG - 2019-11-09 14:35:03 --> Total execution time: 1.1622
INFO - 2019-11-09 14:47:17 --> Config Class Initialized
INFO - 2019-11-09 14:47:17 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:47:17 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:47:17 --> Utf8 Class Initialized
INFO - 2019-11-09 14:47:17 --> URI Class Initialized
INFO - 2019-11-09 14:47:17 --> Router Class Initialized
INFO - 2019-11-09 14:47:17 --> Output Class Initialized
INFO - 2019-11-09 14:47:17 --> Security Class Initialized
DEBUG - 2019-11-09 14:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:47:17 --> CSRF cookie sent
INFO - 2019-11-09 14:47:17 --> CSRF token verified
INFO - 2019-11-09 14:47:17 --> Input Class Initialized
INFO - 2019-11-09 14:47:17 --> Language Class Initialized
INFO - 2019-11-09 14:47:17 --> Language Class Initialized
INFO - 2019-11-09 14:47:17 --> Config Class Initialized
INFO - 2019-11-09 14:47:17 --> Loader Class Initialized
INFO - 2019-11-09 14:47:17 --> Helper loaded: url_helper
INFO - 2019-11-09 14:47:17 --> Helper loaded: common_helper
INFO - 2019-11-09 14:47:17 --> Helper loaded: language_helper
INFO - 2019-11-09 14:47:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:47:18 --> Helper loaded: email_helper
INFO - 2019-11-09 14:47:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:47:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:47:18 --> Parser Class Initialized
INFO - 2019-11-09 14:47:18 --> User Agent Class Initialized
INFO - 2019-11-09 14:47:18 --> Model Class Initialized
INFO - 2019-11-09 14:47:18 --> Database Driver Class Initialized
INFO - 2019-11-09 14:47:18 --> Model Class Initialized
DEBUG - 2019-11-09 14:47:18 --> Template Class Initialized
INFO - 2019-11-09 14:47:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:47:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:47:18 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:47:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:47:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:47:18 --> Encryption Class Initialized
INFO - 2019-11-09 14:47:18 --> Controller Class Initialized
DEBUG - 2019-11-09 14:47:18 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:47:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:47:18 --> Model Class Initialized
INFO - 2019-11-09 14:47:18 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 14:47:18 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 14:47:18 --> Could not find the language line "paystack"
ERROR - 2019-11-09 14:47:18 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 14:47:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 14:47:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:47:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:47:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:47:18 --> Model Class Initialized
DEBUG - 2019-11-09 14:47:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:47:18 --> Model Class Initialized
DEBUG - 2019-11-09 14:47:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 14:47:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 14:47:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 14:47:18 --> Final output sent to browser
DEBUG - 2019-11-09 14:47:18 --> Total execution time: 0.9250
INFO - 2019-11-09 14:47:30 --> Config Class Initialized
INFO - 2019-11-09 14:47:30 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:47:30 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:47:30 --> Utf8 Class Initialized
INFO - 2019-11-09 14:47:30 --> URI Class Initialized
INFO - 2019-11-09 14:47:30 --> Router Class Initialized
INFO - 2019-11-09 14:47:30 --> Output Class Initialized
INFO - 2019-11-09 14:47:30 --> Security Class Initialized
DEBUG - 2019-11-09 14:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:47:30 --> CSRF cookie sent
INFO - 2019-11-09 14:47:30 --> CSRF token verified
INFO - 2019-11-09 14:47:30 --> Input Class Initialized
INFO - 2019-11-09 14:47:30 --> Language Class Initialized
INFO - 2019-11-09 14:47:30 --> Language Class Initialized
INFO - 2019-11-09 14:47:30 --> Config Class Initialized
INFO - 2019-11-09 14:47:30 --> Loader Class Initialized
INFO - 2019-11-09 14:47:30 --> Helper loaded: url_helper
INFO - 2019-11-09 14:47:30 --> Helper loaded: common_helper
INFO - 2019-11-09 14:47:30 --> Helper loaded: language_helper
INFO - 2019-11-09 14:47:30 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:47:30 --> Helper loaded: email_helper
INFO - 2019-11-09 14:47:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:47:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:47:30 --> Parser Class Initialized
INFO - 2019-11-09 14:47:30 --> User Agent Class Initialized
INFO - 2019-11-09 14:47:30 --> Model Class Initialized
INFO - 2019-11-09 14:47:30 --> Database Driver Class Initialized
INFO - 2019-11-09 14:47:30 --> Model Class Initialized
DEBUG - 2019-11-09 14:47:30 --> Template Class Initialized
INFO - 2019-11-09 14:47:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:47:30 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:47:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:47:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:47:30 --> Encryption Class Initialized
INFO - 2019-11-09 14:47:30 --> Controller Class Initialized
DEBUG - 2019-11-09 14:47:30 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:47:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:47:30 --> Model Class Initialized
ERROR - 2019-11-09 14:47:30 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\paystack.php 58
INFO - 2019-11-09 14:47:56 --> Config Class Initialized
INFO - 2019-11-09 14:47:56 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:47:56 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:47:56 --> Utf8 Class Initialized
INFO - 2019-11-09 14:47:56 --> URI Class Initialized
INFO - 2019-11-09 14:47:56 --> Router Class Initialized
INFO - 2019-11-09 14:47:56 --> Output Class Initialized
INFO - 2019-11-09 14:47:56 --> Security Class Initialized
DEBUG - 2019-11-09 14:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:47:56 --> CSRF cookie sent
INFO - 2019-11-09 14:47:56 --> CSRF token verified
INFO - 2019-11-09 14:47:56 --> Input Class Initialized
INFO - 2019-11-09 14:47:56 --> Language Class Initialized
INFO - 2019-11-09 14:47:56 --> Language Class Initialized
INFO - 2019-11-09 14:47:56 --> Config Class Initialized
INFO - 2019-11-09 14:47:56 --> Loader Class Initialized
INFO - 2019-11-09 14:47:56 --> Helper loaded: url_helper
INFO - 2019-11-09 14:47:56 --> Helper loaded: common_helper
INFO - 2019-11-09 14:47:56 --> Helper loaded: language_helper
INFO - 2019-11-09 14:47:56 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:47:56 --> Helper loaded: email_helper
INFO - 2019-11-09 14:47:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:47:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:47:56 --> Parser Class Initialized
INFO - 2019-11-09 14:47:56 --> User Agent Class Initialized
INFO - 2019-11-09 14:47:56 --> Model Class Initialized
INFO - 2019-11-09 14:47:56 --> Database Driver Class Initialized
INFO - 2019-11-09 14:47:56 --> Model Class Initialized
DEBUG - 2019-11-09 14:47:56 --> Template Class Initialized
INFO - 2019-11-09 14:47:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:47:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:47:56 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:47:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:47:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:47:56 --> Encryption Class Initialized
INFO - 2019-11-09 14:47:56 --> Controller Class Initialized
DEBUG - 2019-11-09 14:47:56 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:47:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:47:56 --> Model Class Initialized
INFO - 2019-11-09 14:47:56 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 14:47:56 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 14:47:57 --> Could not find the language line "paystack"
ERROR - 2019-11-09 14:47:57 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 14:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 14:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:47:57 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:47:57 --> Model Class Initialized
DEBUG - 2019-11-09 14:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:47:57 --> Model Class Initialized
DEBUG - 2019-11-09 14:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 14:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 14:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 14:47:57 --> Final output sent to browser
DEBUG - 2019-11-09 14:47:57 --> Total execution time: 1.1215
INFO - 2019-11-09 14:48:10 --> Config Class Initialized
INFO - 2019-11-09 14:48:10 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:48:10 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:48:10 --> Utf8 Class Initialized
INFO - 2019-11-09 14:48:10 --> URI Class Initialized
INFO - 2019-11-09 14:48:10 --> Router Class Initialized
INFO - 2019-11-09 14:48:10 --> Output Class Initialized
INFO - 2019-11-09 14:48:10 --> Security Class Initialized
DEBUG - 2019-11-09 14:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:48:10 --> CSRF cookie sent
INFO - 2019-11-09 14:48:10 --> CSRF token verified
INFO - 2019-11-09 14:48:10 --> Input Class Initialized
INFO - 2019-11-09 14:48:10 --> Language Class Initialized
INFO - 2019-11-09 14:48:10 --> Language Class Initialized
INFO - 2019-11-09 14:48:10 --> Config Class Initialized
INFO - 2019-11-09 14:48:10 --> Loader Class Initialized
INFO - 2019-11-09 14:48:10 --> Helper loaded: url_helper
INFO - 2019-11-09 14:48:10 --> Helper loaded: common_helper
INFO - 2019-11-09 14:48:10 --> Helper loaded: language_helper
INFO - 2019-11-09 14:48:10 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:48:10 --> Helper loaded: email_helper
INFO - 2019-11-09 14:48:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:48:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:48:10 --> Parser Class Initialized
INFO - 2019-11-09 14:48:10 --> User Agent Class Initialized
INFO - 2019-11-09 14:48:10 --> Model Class Initialized
INFO - 2019-11-09 14:48:10 --> Database Driver Class Initialized
INFO - 2019-11-09 14:48:10 --> Model Class Initialized
DEBUG - 2019-11-09 14:48:10 --> Template Class Initialized
INFO - 2019-11-09 14:48:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:48:10 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:48:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:48:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:48:10 --> Encryption Class Initialized
INFO - 2019-11-09 14:48:10 --> Controller Class Initialized
DEBUG - 2019-11-09 14:48:10 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:48:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:48:11 --> Model Class Initialized
DEBUG - 2019-11-09 14:48:11 --> paystack MX_Controller Initialized
ERROR - 2019-11-09 14:48:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\paystack.php 77
INFO - 2019-11-09 14:50:02 --> Config Class Initialized
INFO - 2019-11-09 14:50:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:50:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:50:02 --> Utf8 Class Initialized
INFO - 2019-11-09 14:50:02 --> URI Class Initialized
INFO - 2019-11-09 14:50:02 --> Router Class Initialized
INFO - 2019-11-09 14:50:02 --> Output Class Initialized
INFO - 2019-11-09 14:50:02 --> Security Class Initialized
DEBUG - 2019-11-09 14:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:50:02 --> CSRF cookie sent
INFO - 2019-11-09 14:50:02 --> CSRF token verified
INFO - 2019-11-09 14:50:02 --> Input Class Initialized
INFO - 2019-11-09 14:50:02 --> Language Class Initialized
INFO - 2019-11-09 14:50:02 --> Language Class Initialized
INFO - 2019-11-09 14:50:02 --> Config Class Initialized
INFO - 2019-11-09 14:50:02 --> Loader Class Initialized
INFO - 2019-11-09 14:50:02 --> Helper loaded: url_helper
INFO - 2019-11-09 14:50:02 --> Helper loaded: common_helper
INFO - 2019-11-09 14:50:02 --> Helper loaded: language_helper
INFO - 2019-11-09 14:50:02 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:50:02 --> Helper loaded: email_helper
INFO - 2019-11-09 14:50:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:50:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:50:02 --> Parser Class Initialized
INFO - 2019-11-09 14:50:02 --> User Agent Class Initialized
INFO - 2019-11-09 14:50:02 --> Model Class Initialized
INFO - 2019-11-09 14:50:02 --> Database Driver Class Initialized
INFO - 2019-11-09 14:50:02 --> Model Class Initialized
DEBUG - 2019-11-09 14:50:02 --> Template Class Initialized
INFO - 2019-11-09 14:50:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:50:02 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:50:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:50:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:50:02 --> Encryption Class Initialized
INFO - 2019-11-09 14:50:03 --> Controller Class Initialized
DEBUG - 2019-11-09 14:50:03 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:50:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:50:03 --> Model Class Initialized
INFO - 2019-11-09 14:50:03 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 14:50:03 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 14:50:03 --> Could not find the language line "paystack"
ERROR - 2019-11-09 14:50:03 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 14:50:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 14:50:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:50:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:50:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:50:03 --> Model Class Initialized
DEBUG - 2019-11-09 14:50:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:50:03 --> Model Class Initialized
DEBUG - 2019-11-09 14:50:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 14:50:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 14:50:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 14:50:03 --> Final output sent to browser
DEBUG - 2019-11-09 14:50:03 --> Total execution time: 1.0896
INFO - 2019-11-09 14:50:16 --> Config Class Initialized
INFO - 2019-11-09 14:50:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:50:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:50:16 --> Utf8 Class Initialized
INFO - 2019-11-09 14:50:16 --> URI Class Initialized
INFO - 2019-11-09 14:50:16 --> Router Class Initialized
INFO - 2019-11-09 14:50:16 --> Output Class Initialized
INFO - 2019-11-09 14:50:16 --> Security Class Initialized
DEBUG - 2019-11-09 14:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:50:16 --> CSRF cookie sent
INFO - 2019-11-09 14:50:16 --> CSRF token verified
INFO - 2019-11-09 14:50:16 --> Input Class Initialized
INFO - 2019-11-09 14:50:17 --> Language Class Initialized
INFO - 2019-11-09 14:50:17 --> Language Class Initialized
INFO - 2019-11-09 14:50:17 --> Config Class Initialized
INFO - 2019-11-09 14:50:17 --> Loader Class Initialized
INFO - 2019-11-09 14:50:17 --> Helper loaded: url_helper
INFO - 2019-11-09 14:50:17 --> Helper loaded: common_helper
INFO - 2019-11-09 14:50:17 --> Helper loaded: language_helper
INFO - 2019-11-09 14:50:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:50:17 --> Helper loaded: email_helper
INFO - 2019-11-09 14:50:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:50:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:50:17 --> Parser Class Initialized
INFO - 2019-11-09 14:50:17 --> User Agent Class Initialized
INFO - 2019-11-09 14:50:17 --> Model Class Initialized
INFO - 2019-11-09 14:50:17 --> Database Driver Class Initialized
INFO - 2019-11-09 14:50:17 --> Model Class Initialized
DEBUG - 2019-11-09 14:50:17 --> Template Class Initialized
INFO - 2019-11-09 14:50:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:50:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:50:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:50:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:50:17 --> Encryption Class Initialized
INFO - 2019-11-09 14:50:17 --> Controller Class Initialized
DEBUG - 2019-11-09 14:50:17 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:50:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:50:17 --> Model Class Initialized
DEBUG - 2019-11-09 14:50:17 --> paystack MX_Controller Initialized
INFO - 2019-11-09 14:55:11 --> Config Class Initialized
INFO - 2019-11-09 14:55:11 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:55:11 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:55:11 --> Utf8 Class Initialized
INFO - 2019-11-09 14:55:11 --> URI Class Initialized
INFO - 2019-11-09 14:55:11 --> Router Class Initialized
INFO - 2019-11-09 14:55:11 --> Output Class Initialized
INFO - 2019-11-09 14:55:11 --> Security Class Initialized
DEBUG - 2019-11-09 14:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:55:11 --> CSRF cookie sent
INFO - 2019-11-09 14:55:11 --> CSRF token verified
INFO - 2019-11-09 14:55:11 --> Input Class Initialized
INFO - 2019-11-09 14:55:11 --> Language Class Initialized
INFO - 2019-11-09 14:55:11 --> Language Class Initialized
INFO - 2019-11-09 14:55:11 --> Config Class Initialized
INFO - 2019-11-09 14:55:11 --> Loader Class Initialized
INFO - 2019-11-09 14:55:11 --> Helper loaded: url_helper
INFO - 2019-11-09 14:55:11 --> Helper loaded: common_helper
INFO - 2019-11-09 14:55:11 --> Helper loaded: language_helper
INFO - 2019-11-09 14:55:12 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:55:12 --> Helper loaded: email_helper
INFO - 2019-11-09 14:55:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:55:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:55:12 --> Parser Class Initialized
INFO - 2019-11-09 14:55:12 --> User Agent Class Initialized
INFO - 2019-11-09 14:55:12 --> Model Class Initialized
INFO - 2019-11-09 14:55:12 --> Database Driver Class Initialized
INFO - 2019-11-09 14:55:12 --> Model Class Initialized
DEBUG - 2019-11-09 14:55:12 --> Template Class Initialized
INFO - 2019-11-09 14:55:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:55:12 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:55:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:55:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:55:12 --> Encryption Class Initialized
INFO - 2019-11-09 14:55:12 --> Controller Class Initialized
DEBUG - 2019-11-09 14:55:12 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:55:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:55:12 --> Model Class Initialized
INFO - 2019-11-09 14:55:12 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 14:55:12 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 14:55:12 --> Could not find the language line "paystack"
ERROR - 2019-11-09 14:55:12 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 14:55:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 14:55:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 14:55:12 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 14:55:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 14:55:12 --> Model Class Initialized
DEBUG - 2019-11-09 14:55:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 14:55:12 --> Model Class Initialized
DEBUG - 2019-11-09 14:55:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 14:55:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 14:55:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 14:55:12 --> Final output sent to browser
DEBUG - 2019-11-09 14:55:12 --> Total execution time: 1.1442
INFO - 2019-11-09 14:55:27 --> Config Class Initialized
INFO - 2019-11-09 14:55:27 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:55:27 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:55:27 --> Utf8 Class Initialized
INFO - 2019-11-09 14:55:27 --> URI Class Initialized
INFO - 2019-11-09 14:55:27 --> Router Class Initialized
INFO - 2019-11-09 14:55:27 --> Output Class Initialized
INFO - 2019-11-09 14:55:28 --> Security Class Initialized
DEBUG - 2019-11-09 14:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:55:28 --> CSRF cookie sent
INFO - 2019-11-09 14:55:28 --> CSRF token verified
INFO - 2019-11-09 14:55:28 --> Input Class Initialized
INFO - 2019-11-09 14:55:28 --> Language Class Initialized
INFO - 2019-11-09 14:55:28 --> Language Class Initialized
INFO - 2019-11-09 14:55:28 --> Config Class Initialized
INFO - 2019-11-09 14:55:28 --> Loader Class Initialized
INFO - 2019-11-09 14:55:28 --> Helper loaded: url_helper
INFO - 2019-11-09 14:55:28 --> Helper loaded: common_helper
INFO - 2019-11-09 14:55:28 --> Helper loaded: language_helper
INFO - 2019-11-09 14:55:28 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:55:28 --> Helper loaded: email_helper
INFO - 2019-11-09 14:55:28 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:55:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:55:28 --> Parser Class Initialized
INFO - 2019-11-09 14:55:28 --> User Agent Class Initialized
INFO - 2019-11-09 14:55:28 --> Model Class Initialized
INFO - 2019-11-09 14:55:28 --> Database Driver Class Initialized
INFO - 2019-11-09 14:55:28 --> Model Class Initialized
DEBUG - 2019-11-09 14:55:28 --> Template Class Initialized
INFO - 2019-11-09 14:55:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:55:28 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:55:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:55:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:55:28 --> Encryption Class Initialized
INFO - 2019-11-09 14:55:28 --> Controller Class Initialized
DEBUG - 2019-11-09 14:55:28 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:55:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:55:28 --> Model Class Initialized
DEBUG - 2019-11-09 14:55:28 --> paystack MX_Controller Initialized
INFO - 2019-11-09 14:57:52 --> Config Class Initialized
INFO - 2019-11-09 14:57:52 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:57:52 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:57:52 --> Utf8 Class Initialized
INFO - 2019-11-09 14:57:52 --> URI Class Initialized
INFO - 2019-11-09 14:57:52 --> Router Class Initialized
INFO - 2019-11-09 14:57:52 --> Output Class Initialized
INFO - 2019-11-09 14:57:52 --> Security Class Initialized
DEBUG - 2019-11-09 14:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:57:52 --> CSRF cookie sent
INFO - 2019-11-09 14:57:52 --> CSRF token verified
INFO - 2019-11-09 14:57:53 --> Input Class Initialized
INFO - 2019-11-09 14:57:53 --> Language Class Initialized
INFO - 2019-11-09 14:57:53 --> Language Class Initialized
INFO - 2019-11-09 14:57:53 --> Config Class Initialized
INFO - 2019-11-09 14:57:53 --> Loader Class Initialized
INFO - 2019-11-09 14:57:53 --> Helper loaded: url_helper
INFO - 2019-11-09 14:57:53 --> Helper loaded: common_helper
INFO - 2019-11-09 14:57:53 --> Helper loaded: language_helper
INFO - 2019-11-09 14:57:53 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:57:53 --> Helper loaded: email_helper
INFO - 2019-11-09 14:57:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:57:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:57:53 --> Parser Class Initialized
INFO - 2019-11-09 14:57:53 --> User Agent Class Initialized
INFO - 2019-11-09 14:57:53 --> Model Class Initialized
INFO - 2019-11-09 14:57:53 --> Database Driver Class Initialized
INFO - 2019-11-09 14:57:53 --> Model Class Initialized
DEBUG - 2019-11-09 14:57:53 --> Template Class Initialized
INFO - 2019-11-09 14:57:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:57:53 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:57:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:57:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:57:53 --> Encryption Class Initialized
INFO - 2019-11-09 14:57:53 --> Controller Class Initialized
DEBUG - 2019-11-09 14:57:53 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 14:57:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 14:57:53 --> Model Class Initialized
DEBUG - 2019-11-09 14:57:53 --> paystack MX_Controller Initialized
DEBUG - 2019-11-09 14:58:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paystack/index.php
INFO - 2019-11-09 14:58:01 --> Final output sent to browser
DEBUG - 2019-11-09 14:58:01 --> Total execution time: 8.3440
INFO - 2019-11-09 14:58:43 --> Config Class Initialized
INFO - 2019-11-09 14:58:43 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:58:43 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:58:43 --> Utf8 Class Initialized
INFO - 2019-11-09 14:58:43 --> URI Class Initialized
INFO - 2019-11-09 14:58:43 --> Router Class Initialized
INFO - 2019-11-09 14:58:43 --> Output Class Initialized
INFO - 2019-11-09 14:58:43 --> Security Class Initialized
DEBUG - 2019-11-09 14:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:58:44 --> Input Class Initialized
INFO - 2019-11-09 14:58:44 --> Language Class Initialized
INFO - 2019-11-09 14:58:44 --> Language Class Initialized
INFO - 2019-11-09 14:58:44 --> Config Class Initialized
INFO - 2019-11-09 14:58:44 --> Loader Class Initialized
INFO - 2019-11-09 14:58:44 --> Helper loaded: url_helper
INFO - 2019-11-09 14:58:44 --> Helper loaded: common_helper
INFO - 2019-11-09 14:58:44 --> Helper loaded: language_helper
INFO - 2019-11-09 14:58:44 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:58:44 --> Helper loaded: email_helper
INFO - 2019-11-09 14:58:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:58:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:58:44 --> Parser Class Initialized
INFO - 2019-11-09 14:58:44 --> User Agent Class Initialized
INFO - 2019-11-09 14:58:44 --> Model Class Initialized
INFO - 2019-11-09 14:58:44 --> Database Driver Class Initialized
INFO - 2019-11-09 14:58:44 --> Model Class Initialized
DEBUG - 2019-11-09 14:58:44 --> Template Class Initialized
INFO - 2019-11-09 14:58:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:58:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:58:44 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:58:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:58:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:58:44 --> Encryption Class Initialized
INFO - 2019-11-09 14:58:44 --> Controller Class Initialized
DEBUG - 2019-11-09 14:58:44 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 14:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 14:58:44 --> Model Class Initialized
INFO - 2019-11-09 14:58:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 14:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 14:58:44 --> Final output sent to browser
DEBUG - 2019-11-09 14:58:44 --> Total execution time: 0.7752
INFO - 2019-11-09 14:58:44 --> Config Class Initialized
INFO - 2019-11-09 14:58:44 --> Hooks Class Initialized
DEBUG - 2019-11-09 14:58:44 --> UTF-8 Support Enabled
INFO - 2019-11-09 14:58:44 --> Utf8 Class Initialized
INFO - 2019-11-09 14:58:44 --> URI Class Initialized
INFO - 2019-11-09 14:58:44 --> Router Class Initialized
INFO - 2019-11-09 14:58:44 --> Output Class Initialized
INFO - 2019-11-09 14:58:44 --> Security Class Initialized
DEBUG - 2019-11-09 14:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 14:58:44 --> CSRF cookie sent
INFO - 2019-11-09 14:58:44 --> Input Class Initialized
INFO - 2019-11-09 14:58:44 --> Language Class Initialized
INFO - 2019-11-09 14:58:44 --> Language Class Initialized
INFO - 2019-11-09 14:58:44 --> Config Class Initialized
INFO - 2019-11-09 14:58:45 --> Loader Class Initialized
INFO - 2019-11-09 14:58:45 --> Helper loaded: url_helper
INFO - 2019-11-09 14:58:45 --> Helper loaded: common_helper
INFO - 2019-11-09 14:58:45 --> Helper loaded: language_helper
INFO - 2019-11-09 14:58:45 --> Helper loaded: cookie_helper
INFO - 2019-11-09 14:58:45 --> Helper loaded: email_helper
INFO - 2019-11-09 14:58:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 14:58:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 14:58:45 --> Parser Class Initialized
INFO - 2019-11-09 14:58:45 --> User Agent Class Initialized
INFO - 2019-11-09 14:58:45 --> Model Class Initialized
INFO - 2019-11-09 14:58:45 --> Database Driver Class Initialized
INFO - 2019-11-09 14:58:45 --> Model Class Initialized
DEBUG - 2019-11-09 14:58:45 --> Template Class Initialized
INFO - 2019-11-09 14:58:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 14:58:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 14:58:45 --> Pagination Class Initialized
DEBUG - 2019-11-09 14:58:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 14:58:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 14:58:45 --> Encryption Class Initialized
INFO - 2019-11-09 14:58:45 --> Controller Class Initialized
DEBUG - 2019-11-09 14:58:45 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 14:58:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 14:58:45 --> Model Class Initialized
INFO - 2019-11-09 14:58:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 14:58:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 14:58:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 14:58:45 --> Final output sent to browser
DEBUG - 2019-11-09 14:58:45 --> Total execution time: 0.7290
INFO - 2019-11-09 15:02:36 --> Config Class Initialized
INFO - 2019-11-09 15:02:36 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:02:36 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:02:36 --> Utf8 Class Initialized
INFO - 2019-11-09 15:02:36 --> URI Class Initialized
INFO - 2019-11-09 15:02:36 --> Router Class Initialized
INFO - 2019-11-09 15:02:36 --> Output Class Initialized
INFO - 2019-11-09 15:02:36 --> Security Class Initialized
DEBUG - 2019-11-09 15:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:02:36 --> CSRF cookie sent
INFO - 2019-11-09 15:02:36 --> CSRF token verified
INFO - 2019-11-09 15:02:36 --> Input Class Initialized
INFO - 2019-11-09 15:02:36 --> Language Class Initialized
INFO - 2019-11-09 15:02:36 --> Language Class Initialized
INFO - 2019-11-09 15:02:36 --> Config Class Initialized
INFO - 2019-11-09 15:02:36 --> Loader Class Initialized
INFO - 2019-11-09 15:02:36 --> Helper loaded: url_helper
INFO - 2019-11-09 15:02:36 --> Helper loaded: common_helper
INFO - 2019-11-09 15:02:36 --> Helper loaded: language_helper
INFO - 2019-11-09 15:02:36 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:02:36 --> Helper loaded: email_helper
INFO - 2019-11-09 15:02:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:02:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:02:36 --> Parser Class Initialized
INFO - 2019-11-09 15:02:36 --> User Agent Class Initialized
INFO - 2019-11-09 15:02:36 --> Model Class Initialized
INFO - 2019-11-09 15:02:36 --> Database Driver Class Initialized
INFO - 2019-11-09 15:02:36 --> Model Class Initialized
DEBUG - 2019-11-09 15:02:36 --> Template Class Initialized
INFO - 2019-11-09 15:02:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:02:36 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:02:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:02:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:02:36 --> Encryption Class Initialized
INFO - 2019-11-09 15:02:36 --> Controller Class Initialized
DEBUG - 2019-11-09 15:02:36 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:02:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:02:37 --> Model Class Initialized
DEBUG - 2019-11-09 15:02:37 --> paystack MX_Controller Initialized
DEBUG - 2019-11-09 15:02:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paystack/index.php
INFO - 2019-11-09 15:02:38 --> Final output sent to browser
DEBUG - 2019-11-09 15:02:38 --> Total execution time: 1.8455
INFO - 2019-11-09 15:02:52 --> Config Class Initialized
INFO - 2019-11-09 15:02:52 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:02:53 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:02:53 --> Utf8 Class Initialized
INFO - 2019-11-09 15:02:53 --> URI Class Initialized
INFO - 2019-11-09 15:02:53 --> Router Class Initialized
INFO - 2019-11-09 15:02:53 --> Output Class Initialized
INFO - 2019-11-09 15:02:53 --> Security Class Initialized
DEBUG - 2019-11-09 15:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:02:53 --> Input Class Initialized
INFO - 2019-11-09 15:02:53 --> Language Class Initialized
INFO - 2019-11-09 15:02:53 --> Language Class Initialized
INFO - 2019-11-09 15:02:53 --> Config Class Initialized
INFO - 2019-11-09 15:02:53 --> Loader Class Initialized
INFO - 2019-11-09 15:02:53 --> Helper loaded: url_helper
INFO - 2019-11-09 15:02:53 --> Helper loaded: common_helper
INFO - 2019-11-09 15:02:53 --> Helper loaded: language_helper
INFO - 2019-11-09 15:02:53 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:02:53 --> Helper loaded: email_helper
INFO - 2019-11-09 15:02:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:02:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:02:53 --> Parser Class Initialized
INFO - 2019-11-09 15:02:53 --> User Agent Class Initialized
INFO - 2019-11-09 15:02:53 --> Model Class Initialized
INFO - 2019-11-09 15:02:53 --> Database Driver Class Initialized
INFO - 2019-11-09 15:02:53 --> Model Class Initialized
DEBUG - 2019-11-09 15:02:53 --> Template Class Initialized
INFO - 2019-11-09 15:02:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:02:53 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:02:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:02:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:02:53 --> Encryption Class Initialized
INFO - 2019-11-09 15:02:53 --> Controller Class Initialized
DEBUG - 2019-11-09 15:02:53 --> paystack MX_Controller Initialized
INFO - 2019-11-09 15:02:53 --> Model Class Initialized
INFO - 2019-11-09 15:06:38 --> Config Class Initialized
INFO - 2019-11-09 15:06:38 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:06:38 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:06:38 --> Utf8 Class Initialized
INFO - 2019-11-09 15:06:38 --> URI Class Initialized
INFO - 2019-11-09 15:06:38 --> Router Class Initialized
INFO - 2019-11-09 15:06:38 --> Output Class Initialized
INFO - 2019-11-09 15:06:38 --> Security Class Initialized
DEBUG - 2019-11-09 15:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:06:38 --> Input Class Initialized
INFO - 2019-11-09 15:06:38 --> Language Class Initialized
INFO - 2019-11-09 15:06:38 --> Language Class Initialized
INFO - 2019-11-09 15:06:38 --> Config Class Initialized
INFO - 2019-11-09 15:06:38 --> Loader Class Initialized
INFO - 2019-11-09 15:06:38 --> Helper loaded: url_helper
INFO - 2019-11-09 15:06:38 --> Helper loaded: common_helper
INFO - 2019-11-09 15:06:38 --> Helper loaded: language_helper
INFO - 2019-11-09 15:06:38 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:06:38 --> Helper loaded: email_helper
INFO - 2019-11-09 15:06:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:06:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:06:38 --> Parser Class Initialized
INFO - 2019-11-09 15:06:38 --> User Agent Class Initialized
INFO - 2019-11-09 15:06:38 --> Model Class Initialized
INFO - 2019-11-09 15:06:38 --> Database Driver Class Initialized
INFO - 2019-11-09 15:06:38 --> Model Class Initialized
DEBUG - 2019-11-09 15:06:38 --> Template Class Initialized
INFO - 2019-11-09 15:06:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:06:38 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:06:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:06:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:06:38 --> Encryption Class Initialized
INFO - 2019-11-09 15:06:38 --> Controller Class Initialized
DEBUG - 2019-11-09 15:06:39 --> paystack MX_Controller Initialized
INFO - 2019-11-09 15:06:39 --> Model Class Initialized
INFO - 2019-11-09 15:15:33 --> Config Class Initialized
INFO - 2019-11-09 15:15:33 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:15:33 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:15:33 --> Utf8 Class Initialized
INFO - 2019-11-09 15:15:33 --> URI Class Initialized
INFO - 2019-11-09 15:15:33 --> Router Class Initialized
INFO - 2019-11-09 15:15:33 --> Output Class Initialized
INFO - 2019-11-09 15:15:33 --> Security Class Initialized
DEBUG - 2019-11-09 15:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:15:33 --> Input Class Initialized
INFO - 2019-11-09 15:15:33 --> Language Class Initialized
ERROR - 2019-11-09 15:15:33 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\paystack.php 117
INFO - 2019-11-09 15:15:50 --> Config Class Initialized
INFO - 2019-11-09 15:15:50 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:15:50 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:15:50 --> Utf8 Class Initialized
INFO - 2019-11-09 15:15:50 --> URI Class Initialized
INFO - 2019-11-09 15:15:50 --> Router Class Initialized
INFO - 2019-11-09 15:15:50 --> Output Class Initialized
INFO - 2019-11-09 15:15:50 --> Security Class Initialized
DEBUG - 2019-11-09 15:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:15:51 --> Input Class Initialized
INFO - 2019-11-09 15:15:51 --> Language Class Initialized
INFO - 2019-11-09 15:15:51 --> Language Class Initialized
INFO - 2019-11-09 15:15:51 --> Config Class Initialized
INFO - 2019-11-09 15:15:51 --> Loader Class Initialized
INFO - 2019-11-09 15:15:51 --> Helper loaded: url_helper
INFO - 2019-11-09 15:15:51 --> Helper loaded: common_helper
INFO - 2019-11-09 15:15:51 --> Helper loaded: language_helper
INFO - 2019-11-09 15:15:51 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:15:51 --> Helper loaded: email_helper
INFO - 2019-11-09 15:15:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:15:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:15:51 --> Parser Class Initialized
INFO - 2019-11-09 15:15:51 --> User Agent Class Initialized
INFO - 2019-11-09 15:15:51 --> Model Class Initialized
INFO - 2019-11-09 15:15:51 --> Database Driver Class Initialized
INFO - 2019-11-09 15:15:51 --> Model Class Initialized
DEBUG - 2019-11-09 15:15:51 --> Template Class Initialized
INFO - 2019-11-09 15:15:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:15:51 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:15:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:15:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:15:51 --> Encryption Class Initialized
INFO - 2019-11-09 15:15:51 --> Controller Class Initialized
DEBUG - 2019-11-09 15:15:51 --> paystack MX_Controller Initialized
INFO - 2019-11-09 15:15:51 --> Model Class Initialized
DEBUG - 2019-11-09 15:15:54 --> orders MX_Controller Initialized
INFO - 2019-11-09 15:15:54 --> Config Class Initialized
INFO - 2019-11-09 15:15:54 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:15:54 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:15:54 --> Utf8 Class Initialized
INFO - 2019-11-09 15:15:54 --> URI Class Initialized
INFO - 2019-11-09 15:15:54 --> Router Class Initialized
INFO - 2019-11-09 15:15:54 --> Output Class Initialized
INFO - 2019-11-09 15:15:54 --> Security Class Initialized
DEBUG - 2019-11-09 15:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:15:54 --> CSRF cookie sent
INFO - 2019-11-09 15:15:54 --> Input Class Initialized
INFO - 2019-11-09 15:15:54 --> Language Class Initialized
INFO - 2019-11-09 15:15:54 --> Language Class Initialized
INFO - 2019-11-09 15:15:54 --> Config Class Initialized
INFO - 2019-11-09 15:15:54 --> Loader Class Initialized
INFO - 2019-11-09 15:15:54 --> Helper loaded: url_helper
INFO - 2019-11-09 15:15:54 --> Helper loaded: common_helper
INFO - 2019-11-09 15:15:54 --> Helper loaded: language_helper
INFO - 2019-11-09 15:15:54 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:15:54 --> Helper loaded: email_helper
INFO - 2019-11-09 15:15:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:15:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:15:54 --> Parser Class Initialized
INFO - 2019-11-09 15:15:54 --> User Agent Class Initialized
INFO - 2019-11-09 15:15:54 --> Model Class Initialized
INFO - 2019-11-09 15:15:54 --> Database Driver Class Initialized
INFO - 2019-11-09 15:15:54 --> Model Class Initialized
DEBUG - 2019-11-09 15:15:54 --> Template Class Initialized
INFO - 2019-11-09 15:15:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:15:54 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:15:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:15:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:15:54 --> Encryption Class Initialized
INFO - 2019-11-09 15:15:54 --> Controller Class Initialized
DEBUG - 2019-11-09 15:15:54 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:15:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:15:54 --> Model Class Initialized
INFO - 2019-11-09 15:15:54 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 15:15:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-09 15:15:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:15:54 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:15:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:15:54 --> Model Class Initialized
DEBUG - 2019-11-09 15:15:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:15:54 --> Model Class Initialized
DEBUG - 2019-11-09 15:15:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 15:15:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 15:15:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 15:15:55 --> Final output sent to browser
DEBUG - 2019-11-09 15:15:55 --> Total execution time: 0.9032
INFO - 2019-11-09 15:16:08 --> Config Class Initialized
INFO - 2019-11-09 15:16:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:16:08 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:16:08 --> Utf8 Class Initialized
INFO - 2019-11-09 15:16:08 --> URI Class Initialized
INFO - 2019-11-09 15:16:08 --> Router Class Initialized
INFO - 2019-11-09 15:16:08 --> Output Class Initialized
INFO - 2019-11-09 15:16:08 --> Security Class Initialized
DEBUG - 2019-11-09 15:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:16:08 --> CSRF cookie sent
INFO - 2019-11-09 15:16:08 --> Input Class Initialized
INFO - 2019-11-09 15:16:08 --> Language Class Initialized
INFO - 2019-11-09 15:16:08 --> Language Class Initialized
INFO - 2019-11-09 15:16:08 --> Config Class Initialized
INFO - 2019-11-09 15:16:08 --> Loader Class Initialized
INFO - 2019-11-09 15:16:08 --> Helper loaded: url_helper
INFO - 2019-11-09 15:16:08 --> Helper loaded: common_helper
INFO - 2019-11-09 15:16:08 --> Helper loaded: language_helper
INFO - 2019-11-09 15:16:08 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:16:08 --> Helper loaded: email_helper
INFO - 2019-11-09 15:16:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:16:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:16:08 --> Parser Class Initialized
INFO - 2019-11-09 15:16:08 --> User Agent Class Initialized
INFO - 2019-11-09 15:16:08 --> Model Class Initialized
INFO - 2019-11-09 15:16:08 --> Database Driver Class Initialized
INFO - 2019-11-09 15:16:08 --> Model Class Initialized
DEBUG - 2019-11-09 15:16:08 --> Template Class Initialized
INFO - 2019-11-09 15:16:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:16:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:16:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:16:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:16:08 --> Encryption Class Initialized
INFO - 2019-11-09 15:16:08 --> Controller Class Initialized
DEBUG - 2019-11-09 15:16:08 --> order MX_Controller Initialized
DEBUG - 2019-11-09 15:16:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-09 15:16:08 --> Model Class Initialized
ERROR - 2019-11-09 15:16:08 --> Could not find the language line "order_id"
ERROR - 2019-11-09 15:16:08 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-09 15:16:08 --> Could not find the language line "order_id"
ERROR - 2019-11-09 15:16:08 --> Could not find the language line "order_basic_details"
INFO - 2019-11-09 15:16:08 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 15:16:09 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 15:16:09 --> Could not find the language line "Pending"
ERROR - 2019-11-09 15:16:09 --> Could not find the language line "Pending"
ERROR - 2019-11-09 15:16:09 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 15:16:09 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 15:16:09 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 15:16:09 --> Could not find the language line "Pending"
DEBUG - 2019-11-09 15:16:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-09 15:16:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:16:09 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:16:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:16:09 --> Model Class Initialized
DEBUG - 2019-11-09 15:16:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:16:09 --> Model Class Initialized
DEBUG - 2019-11-09 15:16:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 15:16:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 15:16:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 15:16:09 --> Final output sent to browser
DEBUG - 2019-11-09 15:16:09 --> Total execution time: 1.2680
INFO - 2019-11-09 15:16:15 --> Config Class Initialized
INFO - 2019-11-09 15:16:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:16:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:16:16 --> Utf8 Class Initialized
INFO - 2019-11-09 15:16:16 --> URI Class Initialized
INFO - 2019-11-09 15:16:16 --> Router Class Initialized
INFO - 2019-11-09 15:16:16 --> Output Class Initialized
INFO - 2019-11-09 15:16:16 --> Security Class Initialized
DEBUG - 2019-11-09 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:16:16 --> CSRF cookie sent
INFO - 2019-11-09 15:16:16 --> Input Class Initialized
INFO - 2019-11-09 15:16:16 --> Language Class Initialized
INFO - 2019-11-09 15:16:16 --> Language Class Initialized
INFO - 2019-11-09 15:16:16 --> Config Class Initialized
INFO - 2019-11-09 15:16:16 --> Loader Class Initialized
INFO - 2019-11-09 15:16:16 --> Helper loaded: url_helper
INFO - 2019-11-09 15:16:16 --> Helper loaded: common_helper
INFO - 2019-11-09 15:16:16 --> Helper loaded: language_helper
INFO - 2019-11-09 15:16:16 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:16:16 --> Helper loaded: email_helper
INFO - 2019-11-09 15:16:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:16:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:16:16 --> Parser Class Initialized
INFO - 2019-11-09 15:16:16 --> User Agent Class Initialized
INFO - 2019-11-09 15:16:16 --> Model Class Initialized
INFO - 2019-11-09 15:16:16 --> Database Driver Class Initialized
INFO - 2019-11-09 15:16:16 --> Model Class Initialized
DEBUG - 2019-11-09 15:16:16 --> Template Class Initialized
INFO - 2019-11-09 15:16:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:16:16 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:16:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:16:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:16:16 --> Encryption Class Initialized
INFO - 2019-11-09 15:16:16 --> Controller Class Initialized
DEBUG - 2019-11-09 15:16:16 --> transactions MX_Controller Initialized
DEBUG - 2019-11-09 15:16:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-09 15:16:16 --> Model Class Initialized
ERROR - 2019-11-09 15:16:16 --> Could not find the language line "order_id"
INFO - 2019-11-09 15:16:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 15:16:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-09 15:16:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:16:16 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:16:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:16:16 --> Model Class Initialized
DEBUG - 2019-11-09 15:16:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:16:16 --> Model Class Initialized
DEBUG - 2019-11-09 15:16:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 15:16:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 15:16:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 15:16:16 --> Final output sent to browser
DEBUG - 2019-11-09 15:16:16 --> Total execution time: 0.9440
INFO - 2019-11-09 15:17:17 --> Config Class Initialized
INFO - 2019-11-09 15:17:17 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:17:17 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:17:17 --> Utf8 Class Initialized
INFO - 2019-11-09 15:17:17 --> URI Class Initialized
INFO - 2019-11-09 15:17:17 --> Router Class Initialized
INFO - 2019-11-09 15:17:17 --> Output Class Initialized
INFO - 2019-11-09 15:17:17 --> Security Class Initialized
DEBUG - 2019-11-09 15:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:17:17 --> CSRF cookie sent
INFO - 2019-11-09 15:17:17 --> CSRF token verified
INFO - 2019-11-09 15:17:17 --> Input Class Initialized
INFO - 2019-11-09 15:17:17 --> Language Class Initialized
INFO - 2019-11-09 15:17:17 --> Language Class Initialized
INFO - 2019-11-09 15:17:17 --> Config Class Initialized
INFO - 2019-11-09 15:17:17 --> Loader Class Initialized
INFO - 2019-11-09 15:17:17 --> Helper loaded: url_helper
INFO - 2019-11-09 15:17:17 --> Helper loaded: common_helper
INFO - 2019-11-09 15:17:17 --> Helper loaded: language_helper
INFO - 2019-11-09 15:17:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:17:17 --> Helper loaded: email_helper
INFO - 2019-11-09 15:17:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:17:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:17:17 --> Parser Class Initialized
INFO - 2019-11-09 15:17:17 --> User Agent Class Initialized
INFO - 2019-11-09 15:17:18 --> Model Class Initialized
INFO - 2019-11-09 15:17:18 --> Database Driver Class Initialized
INFO - 2019-11-09 15:17:18 --> Model Class Initialized
DEBUG - 2019-11-09 15:17:18 --> Template Class Initialized
INFO - 2019-11-09 15:17:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:17:18 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:17:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:17:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:17:18 --> Encryption Class Initialized
INFO - 2019-11-09 15:17:18 --> Controller Class Initialized
DEBUG - 2019-11-09 15:17:18 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:17:18 --> Model Class Initialized
INFO - 2019-11-09 15:17:18 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 15:17:18 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 15:17:18 --> Could not find the language line "paystack"
ERROR - 2019-11-09 15:17:18 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:17:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:17:18 --> Model Class Initialized
DEBUG - 2019-11-09 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:17:18 --> Model Class Initialized
DEBUG - 2019-11-09 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 15:17:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 15:17:18 --> Final output sent to browser
DEBUG - 2019-11-09 15:17:18 --> Total execution time: 1.0057
INFO - 2019-11-09 15:17:26 --> Config Class Initialized
INFO - 2019-11-09 15:17:26 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:17:26 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:17:26 --> Utf8 Class Initialized
INFO - 2019-11-09 15:17:26 --> URI Class Initialized
INFO - 2019-11-09 15:17:26 --> Router Class Initialized
INFO - 2019-11-09 15:17:26 --> Output Class Initialized
INFO - 2019-11-09 15:17:26 --> Security Class Initialized
DEBUG - 2019-11-09 15:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:17:26 --> CSRF cookie sent
INFO - 2019-11-09 15:17:26 --> CSRF token verified
INFO - 2019-11-09 15:17:26 --> Input Class Initialized
INFO - 2019-11-09 15:17:26 --> Language Class Initialized
INFO - 2019-11-09 15:17:26 --> Language Class Initialized
INFO - 2019-11-09 15:17:26 --> Config Class Initialized
INFO - 2019-11-09 15:17:26 --> Loader Class Initialized
INFO - 2019-11-09 15:17:26 --> Helper loaded: url_helper
INFO - 2019-11-09 15:17:26 --> Helper loaded: common_helper
INFO - 2019-11-09 15:17:26 --> Helper loaded: language_helper
INFO - 2019-11-09 15:17:26 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:17:26 --> Helper loaded: email_helper
INFO - 2019-11-09 15:17:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:17:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:17:26 --> Parser Class Initialized
INFO - 2019-11-09 15:17:26 --> User Agent Class Initialized
INFO - 2019-11-09 15:17:26 --> Model Class Initialized
INFO - 2019-11-09 15:17:26 --> Database Driver Class Initialized
INFO - 2019-11-09 15:17:26 --> Model Class Initialized
DEBUG - 2019-11-09 15:17:26 --> Template Class Initialized
INFO - 2019-11-09 15:17:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:17:26 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:17:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:17:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:17:26 --> Encryption Class Initialized
INFO - 2019-11-09 15:17:26 --> Controller Class Initialized
DEBUG - 2019-11-09 15:17:26 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:17:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:17:26 --> Model Class Initialized
DEBUG - 2019-11-09 15:17:26 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:17:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 15:17:27 --> Config Class Initialized
INFO - 2019-11-09 15:17:27 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:17:27 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:17:27 --> Utf8 Class Initialized
INFO - 2019-11-09 15:17:27 --> URI Class Initialized
INFO - 2019-11-09 15:17:27 --> Router Class Initialized
INFO - 2019-11-09 15:17:27 --> Output Class Initialized
INFO - 2019-11-09 15:17:27 --> Security Class Initialized
DEBUG - 2019-11-09 15:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:17:27 --> CSRF cookie sent
INFO - 2019-11-09 15:17:27 --> Input Class Initialized
INFO - 2019-11-09 15:17:27 --> Language Class Initialized
INFO - 2019-11-09 15:17:27 --> Language Class Initialized
INFO - 2019-11-09 15:17:27 --> Config Class Initialized
INFO - 2019-11-09 15:17:27 --> Loader Class Initialized
INFO - 2019-11-09 15:17:27 --> Helper loaded: url_helper
INFO - 2019-11-09 15:17:27 --> Helper loaded: common_helper
INFO - 2019-11-09 15:17:27 --> Helper loaded: language_helper
INFO - 2019-11-09 15:17:27 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:17:27 --> Helper loaded: email_helper
INFO - 2019-11-09 15:17:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:17:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:17:27 --> Parser Class Initialized
INFO - 2019-11-09 15:17:27 --> User Agent Class Initialized
INFO - 2019-11-09 15:17:27 --> Model Class Initialized
INFO - 2019-11-09 15:17:27 --> Database Driver Class Initialized
INFO - 2019-11-09 15:17:27 --> Model Class Initialized
DEBUG - 2019-11-09 15:17:27 --> Template Class Initialized
INFO - 2019-11-09 15:17:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:17:27 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:17:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:17:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:17:27 --> Encryption Class Initialized
INFO - 2019-11-09 15:17:27 --> Controller Class Initialized
DEBUG - 2019-11-09 15:17:27 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:17:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:17:27 --> Model Class Initialized
INFO - 2019-11-09 15:17:27 --> Config Class Initialized
INFO - 2019-11-09 15:17:27 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:17:27 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:17:27 --> Utf8 Class Initialized
INFO - 2019-11-09 15:17:28 --> URI Class Initialized
DEBUG - 2019-11-09 15:17:28 --> No URI present. Default controller set.
INFO - 2019-11-09 15:17:28 --> Router Class Initialized
INFO - 2019-11-09 15:17:28 --> Output Class Initialized
INFO - 2019-11-09 15:17:28 --> Security Class Initialized
DEBUG - 2019-11-09 15:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:17:28 --> CSRF cookie sent
INFO - 2019-11-09 15:17:28 --> Input Class Initialized
INFO - 2019-11-09 15:17:28 --> Language Class Initialized
INFO - 2019-11-09 15:17:28 --> Language Class Initialized
INFO - 2019-11-09 15:17:28 --> Config Class Initialized
INFO - 2019-11-09 15:17:28 --> Loader Class Initialized
INFO - 2019-11-09 15:17:28 --> Helper loaded: url_helper
INFO - 2019-11-09 15:17:28 --> Helper loaded: common_helper
INFO - 2019-11-09 15:17:28 --> Helper loaded: language_helper
INFO - 2019-11-09 15:17:28 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:17:28 --> Helper loaded: email_helper
INFO - 2019-11-09 15:17:28 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:17:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:17:28 --> Parser Class Initialized
INFO - 2019-11-09 15:17:28 --> User Agent Class Initialized
INFO - 2019-11-09 15:17:28 --> Model Class Initialized
INFO - 2019-11-09 15:17:28 --> Database Driver Class Initialized
INFO - 2019-11-09 15:17:28 --> Model Class Initialized
DEBUG - 2019-11-09 15:17:28 --> Template Class Initialized
INFO - 2019-11-09 15:17:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:17:28 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:17:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:17:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:17:28 --> Encryption Class Initialized
DEBUG - 2019-11-09 15:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 15:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 15:17:28 --> Controller Class Initialized
DEBUG - 2019-11-09 15:17:28 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 15:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 15:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 15:17:28 --> Model Class Initialized
INFO - 2019-11-09 15:17:28 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 15:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 15:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 15:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 15:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 15:17:28 --> Final output sent to browser
DEBUG - 2019-11-09 15:17:28 --> Total execution time: 0.9194
INFO - 2019-11-09 15:27:31 --> Config Class Initialized
INFO - 2019-11-09 15:27:31 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:27:31 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:27:31 --> Utf8 Class Initialized
INFO - 2019-11-09 15:27:31 --> URI Class Initialized
INFO - 2019-11-09 15:27:31 --> Router Class Initialized
INFO - 2019-11-09 15:27:31 --> Output Class Initialized
INFO - 2019-11-09 15:27:32 --> Security Class Initialized
DEBUG - 2019-11-09 15:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:27:32 --> CSRF cookie sent
INFO - 2019-11-09 15:27:32 --> CSRF token verified
INFO - 2019-11-09 15:27:32 --> Input Class Initialized
INFO - 2019-11-09 15:27:32 --> Language Class Initialized
INFO - 2019-11-09 15:27:32 --> Language Class Initialized
INFO - 2019-11-09 15:27:32 --> Config Class Initialized
INFO - 2019-11-09 15:27:32 --> Loader Class Initialized
INFO - 2019-11-09 15:27:32 --> Helper loaded: url_helper
INFO - 2019-11-09 15:27:32 --> Helper loaded: common_helper
INFO - 2019-11-09 15:27:32 --> Helper loaded: language_helper
INFO - 2019-11-09 15:27:32 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:27:32 --> Helper loaded: email_helper
INFO - 2019-11-09 15:27:32 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:27:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:27:32 --> Parser Class Initialized
INFO - 2019-11-09 15:27:32 --> User Agent Class Initialized
INFO - 2019-11-09 15:27:32 --> Model Class Initialized
INFO - 2019-11-09 15:27:32 --> Database Driver Class Initialized
INFO - 2019-11-09 15:27:32 --> Model Class Initialized
DEBUG - 2019-11-09 15:27:32 --> Template Class Initialized
INFO - 2019-11-09 15:27:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:27:32 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:27:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:27:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:27:32 --> Encryption Class Initialized
INFO - 2019-11-09 15:27:32 --> Controller Class Initialized
DEBUG - 2019-11-09 15:27:32 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:27:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:27:32 --> Model Class Initialized
INFO - 2019-11-09 15:27:32 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 15:27:32 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 15:27:32 --> Could not find the language line "paystack"
ERROR - 2019-11-09 15:27:32 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 15:27:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 15:27:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:27:32 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:27:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:27:32 --> Model Class Initialized
DEBUG - 2019-11-09 15:27:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:27:32 --> Model Class Initialized
DEBUG - 2019-11-09 15:27:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 15:27:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 15:27:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 15:27:33 --> Final output sent to browser
DEBUG - 2019-11-09 15:27:33 --> Total execution time: 1.2603
INFO - 2019-11-09 15:27:40 --> Config Class Initialized
INFO - 2019-11-09 15:27:40 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:27:40 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:27:40 --> Utf8 Class Initialized
INFO - 2019-11-09 15:27:40 --> URI Class Initialized
INFO - 2019-11-09 15:27:40 --> Router Class Initialized
INFO - 2019-11-09 15:27:40 --> Output Class Initialized
INFO - 2019-11-09 15:27:40 --> Security Class Initialized
DEBUG - 2019-11-09 15:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:27:40 --> CSRF cookie sent
INFO - 2019-11-09 15:27:40 --> CSRF token verified
INFO - 2019-11-09 15:27:40 --> Input Class Initialized
INFO - 2019-11-09 15:27:40 --> Language Class Initialized
INFO - 2019-11-09 15:27:40 --> Language Class Initialized
INFO - 2019-11-09 15:27:40 --> Config Class Initialized
INFO - 2019-11-09 15:27:40 --> Loader Class Initialized
INFO - 2019-11-09 15:27:40 --> Helper loaded: url_helper
INFO - 2019-11-09 15:27:40 --> Helper loaded: common_helper
INFO - 2019-11-09 15:27:40 --> Helper loaded: language_helper
INFO - 2019-11-09 15:27:40 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:27:40 --> Helper loaded: email_helper
INFO - 2019-11-09 15:27:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:27:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:27:40 --> Parser Class Initialized
INFO - 2019-11-09 15:27:40 --> User Agent Class Initialized
INFO - 2019-11-09 15:27:40 --> Model Class Initialized
INFO - 2019-11-09 15:27:40 --> Database Driver Class Initialized
INFO - 2019-11-09 15:27:40 --> Model Class Initialized
DEBUG - 2019-11-09 15:27:40 --> Template Class Initialized
INFO - 2019-11-09 15:27:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:27:40 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:27:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:27:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:27:41 --> Encryption Class Initialized
INFO - 2019-11-09 15:27:41 --> Controller Class Initialized
DEBUG - 2019-11-09 15:27:41 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:27:41 --> Model Class Initialized
DEBUG - 2019-11-09 15:27:41 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 15:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
DEBUG - 2019-11-09 15:27:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paypal/index.php
INFO - 2019-11-09 15:27:47 --> Final output sent to browser
DEBUG - 2019-11-09 15:27:47 --> Total execution time: 6.7000
INFO - 2019-11-09 15:28:04 --> Config Class Initialized
INFO - 2019-11-09 15:28:04 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:28:04 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:28:04 --> Utf8 Class Initialized
INFO - 2019-11-09 15:28:04 --> URI Class Initialized
INFO - 2019-11-09 15:28:04 --> Router Class Initialized
INFO - 2019-11-09 15:28:04 --> Output Class Initialized
INFO - 2019-11-09 15:28:04 --> Security Class Initialized
DEBUG - 2019-11-09 15:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:28:04 --> CSRF cookie sent
INFO - 2019-11-09 15:28:04 --> CSRF token verified
INFO - 2019-11-09 15:28:04 --> Input Class Initialized
INFO - 2019-11-09 15:28:05 --> Language Class Initialized
INFO - 2019-11-09 15:28:05 --> Language Class Initialized
INFO - 2019-11-09 15:28:05 --> Config Class Initialized
INFO - 2019-11-09 15:28:05 --> Loader Class Initialized
INFO - 2019-11-09 15:28:05 --> Helper loaded: url_helper
INFO - 2019-11-09 15:28:05 --> Helper loaded: common_helper
INFO - 2019-11-09 15:28:05 --> Helper loaded: language_helper
INFO - 2019-11-09 15:28:05 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:28:05 --> Helper loaded: email_helper
INFO - 2019-11-09 15:28:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:28:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:28:05 --> Parser Class Initialized
INFO - 2019-11-09 15:28:05 --> User Agent Class Initialized
INFO - 2019-11-09 15:28:05 --> Model Class Initialized
INFO - 2019-11-09 15:28:05 --> Database Driver Class Initialized
INFO - 2019-11-09 15:28:05 --> Model Class Initialized
DEBUG - 2019-11-09 15:28:05 --> Template Class Initialized
INFO - 2019-11-09 15:28:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:28:05 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:28:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:28:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:28:05 --> Encryption Class Initialized
INFO - 2019-11-09 15:28:05 --> Controller Class Initialized
DEBUG - 2019-11-09 15:28:05 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:28:05 --> Model Class Initialized
DEBUG - 2019-11-09 15:28:05 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
ERROR - 2019-11-09 15:28:09 --> Severity: error --> Exception: Error executing API call (422: Unprocessable Entity): The webhook URL is invalid because it is unreachable from Mollie's point of view. Field: webhookUrl. Documentation: https://docs.mollie.com/guides/handling-errors. D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\libraries\mollie\vendor\mollie\mollie-api-php\src\MollieApiClient.php 321
INFO - 2019-11-09 15:30:09 --> Config Class Initialized
INFO - 2019-11-09 15:30:09 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:30:09 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:30:09 --> Utf8 Class Initialized
INFO - 2019-11-09 15:30:09 --> URI Class Initialized
INFO - 2019-11-09 15:30:09 --> Router Class Initialized
INFO - 2019-11-09 15:30:09 --> Output Class Initialized
INFO - 2019-11-09 15:30:09 --> Security Class Initialized
DEBUG - 2019-11-09 15:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:30:09 --> CSRF cookie sent
INFO - 2019-11-09 15:30:10 --> CSRF token verified
INFO - 2019-11-09 15:30:10 --> Input Class Initialized
INFO - 2019-11-09 15:30:10 --> Language Class Initialized
INFO - 2019-11-09 15:30:10 --> Language Class Initialized
INFO - 2019-11-09 15:30:10 --> Config Class Initialized
INFO - 2019-11-09 15:30:10 --> Loader Class Initialized
INFO - 2019-11-09 15:30:10 --> Helper loaded: url_helper
INFO - 2019-11-09 15:30:10 --> Helper loaded: common_helper
INFO - 2019-11-09 15:30:10 --> Helper loaded: language_helper
INFO - 2019-11-09 15:30:10 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:30:10 --> Helper loaded: email_helper
INFO - 2019-11-09 15:30:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:30:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:30:10 --> Parser Class Initialized
INFO - 2019-11-09 15:30:10 --> User Agent Class Initialized
INFO - 2019-11-09 15:30:10 --> Model Class Initialized
INFO - 2019-11-09 15:30:10 --> Database Driver Class Initialized
INFO - 2019-11-09 15:30:10 --> Model Class Initialized
DEBUG - 2019-11-09 15:30:10 --> Template Class Initialized
INFO - 2019-11-09 15:30:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:30:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:30:10 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:30:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:30:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:30:10 --> Encryption Class Initialized
INFO - 2019-11-09 15:30:10 --> Controller Class Initialized
DEBUG - 2019-11-09 15:30:10 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:30:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:30:10 --> Model Class Initialized
INFO - 2019-11-09 15:30:10 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 15:30:10 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 15:30:10 --> Could not find the language line "paystack"
ERROR - 2019-11-09 15:30:10 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 15:30:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 15:30:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:30:10 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:30:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:30:10 --> Model Class Initialized
DEBUG - 2019-11-09 15:30:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:30:10 --> Model Class Initialized
DEBUG - 2019-11-09 15:30:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 15:30:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 15:30:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 15:30:10 --> Final output sent to browser
DEBUG - 2019-11-09 15:30:10 --> Total execution time: 1.0757
INFO - 2019-11-09 15:32:17 --> Config Class Initialized
INFO - 2019-11-09 15:32:17 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:32:17 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:32:17 --> Utf8 Class Initialized
INFO - 2019-11-09 15:32:17 --> URI Class Initialized
INFO - 2019-11-09 15:32:17 --> Router Class Initialized
INFO - 2019-11-09 15:32:17 --> Output Class Initialized
INFO - 2019-11-09 15:32:17 --> Security Class Initialized
DEBUG - 2019-11-09 15:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:32:17 --> CSRF cookie sent
INFO - 2019-11-09 15:32:17 --> CSRF token verified
INFO - 2019-11-09 15:32:17 --> Input Class Initialized
INFO - 2019-11-09 15:32:17 --> Language Class Initialized
INFO - 2019-11-09 15:32:17 --> Language Class Initialized
INFO - 2019-11-09 15:32:17 --> Config Class Initialized
INFO - 2019-11-09 15:32:17 --> Loader Class Initialized
INFO - 2019-11-09 15:32:17 --> Helper loaded: url_helper
INFO - 2019-11-09 15:32:17 --> Helper loaded: common_helper
INFO - 2019-11-09 15:32:17 --> Helper loaded: language_helper
INFO - 2019-11-09 15:32:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:32:17 --> Helper loaded: email_helper
INFO - 2019-11-09 15:32:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:32:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:32:17 --> Parser Class Initialized
INFO - 2019-11-09 15:32:17 --> User Agent Class Initialized
INFO - 2019-11-09 15:32:17 --> Model Class Initialized
INFO - 2019-11-09 15:32:17 --> Database Driver Class Initialized
INFO - 2019-11-09 15:32:17 --> Model Class Initialized
DEBUG - 2019-11-09 15:32:17 --> Template Class Initialized
INFO - 2019-11-09 15:32:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:32:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:32:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:32:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:32:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:32:18 --> Encryption Class Initialized
INFO - 2019-11-09 15:32:18 --> Controller Class Initialized
DEBUG - 2019-11-09 15:32:18 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:32:18 --> Model Class Initialized
INFO - 2019-11-09 15:32:18 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 15:32:18 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 15:32:18 --> Could not find the language line "paystack"
ERROR - 2019-11-09 15:32:18 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 15:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 15:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:32:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:32:18 --> Model Class Initialized
DEBUG - 2019-11-09 15:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:32:18 --> Model Class Initialized
DEBUG - 2019-11-09 15:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 15:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 15:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 15:32:18 --> Final output sent to browser
DEBUG - 2019-11-09 15:32:18 --> Total execution time: 1.1553
INFO - 2019-11-09 15:32:25 --> Config Class Initialized
INFO - 2019-11-09 15:32:25 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:32:25 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:32:25 --> Utf8 Class Initialized
INFO - 2019-11-09 15:32:25 --> URI Class Initialized
INFO - 2019-11-09 15:32:25 --> Router Class Initialized
INFO - 2019-11-09 15:32:25 --> Output Class Initialized
INFO - 2019-11-09 15:32:25 --> Security Class Initialized
DEBUG - 2019-11-09 15:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:32:25 --> CSRF cookie sent
INFO - 2019-11-09 15:32:25 --> CSRF token verified
INFO - 2019-11-09 15:32:25 --> Input Class Initialized
INFO - 2019-11-09 15:32:25 --> Language Class Initialized
INFO - 2019-11-09 15:32:25 --> Language Class Initialized
INFO - 2019-11-09 15:32:25 --> Config Class Initialized
INFO - 2019-11-09 15:32:26 --> Loader Class Initialized
INFO - 2019-11-09 15:32:26 --> Helper loaded: url_helper
INFO - 2019-11-09 15:32:26 --> Helper loaded: common_helper
INFO - 2019-11-09 15:32:26 --> Helper loaded: language_helper
INFO - 2019-11-09 15:32:26 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:32:26 --> Helper loaded: email_helper
INFO - 2019-11-09 15:32:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:32:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:32:26 --> Parser Class Initialized
INFO - 2019-11-09 15:32:26 --> User Agent Class Initialized
INFO - 2019-11-09 15:32:26 --> Model Class Initialized
INFO - 2019-11-09 15:32:26 --> Database Driver Class Initialized
INFO - 2019-11-09 15:32:26 --> Model Class Initialized
DEBUG - 2019-11-09 15:32:26 --> Template Class Initialized
INFO - 2019-11-09 15:32:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:32:26 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:32:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:32:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:32:26 --> Encryption Class Initialized
INFO - 2019-11-09 15:32:26 --> Controller Class Initialized
DEBUG - 2019-11-09 15:32:26 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:32:26 --> Model Class Initialized
DEBUG - 2019-11-09 15:32:26 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-09 15:32:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-09 15:32:28 --> Final output sent to browser
DEBUG - 2019-11-09 15:32:28 --> Total execution time: 2.3198
INFO - 2019-11-09 15:32:41 --> Config Class Initialized
INFO - 2019-11-09 15:32:41 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:32:41 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:32:41 --> Utf8 Class Initialized
INFO - 2019-11-09 15:32:41 --> URI Class Initialized
INFO - 2019-11-09 15:32:41 --> Router Class Initialized
INFO - 2019-11-09 15:32:41 --> Output Class Initialized
INFO - 2019-11-09 15:32:41 --> Security Class Initialized
DEBUG - 2019-11-09 15:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:32:42 --> Input Class Initialized
INFO - 2019-11-09 15:32:42 --> Language Class Initialized
INFO - 2019-11-09 15:32:42 --> Language Class Initialized
INFO - 2019-11-09 15:32:42 --> Config Class Initialized
INFO - 2019-11-09 15:32:42 --> Loader Class Initialized
INFO - 2019-11-09 15:32:42 --> Helper loaded: url_helper
INFO - 2019-11-09 15:32:42 --> Helper loaded: common_helper
INFO - 2019-11-09 15:32:42 --> Helper loaded: language_helper
INFO - 2019-11-09 15:32:42 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:32:42 --> Helper loaded: email_helper
INFO - 2019-11-09 15:32:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:32:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:32:42 --> Parser Class Initialized
INFO - 2019-11-09 15:32:42 --> User Agent Class Initialized
INFO - 2019-11-09 15:32:42 --> Model Class Initialized
INFO - 2019-11-09 15:32:42 --> Database Driver Class Initialized
INFO - 2019-11-09 15:32:42 --> Model Class Initialized
DEBUG - 2019-11-09 15:32:42 --> Template Class Initialized
INFO - 2019-11-09 15:32:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:32:42 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:32:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:32:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:32:42 --> Encryption Class Initialized
INFO - 2019-11-09 15:32:42 --> Controller Class Initialized
DEBUG - 2019-11-09 15:32:42 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 15:32:42 --> Model Class Initialized
INFO - 2019-11-09 15:32:44 --> Config Class Initialized
INFO - 2019-11-09 15:32:44 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:32:44 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:32:44 --> Utf8 Class Initialized
INFO - 2019-11-09 15:32:44 --> URI Class Initialized
INFO - 2019-11-09 15:32:44 --> Router Class Initialized
INFO - 2019-11-09 15:32:44 --> Output Class Initialized
INFO - 2019-11-09 15:32:44 --> Security Class Initialized
DEBUG - 2019-11-09 15:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:32:44 --> CSRF cookie sent
INFO - 2019-11-09 15:32:44 --> Input Class Initialized
INFO - 2019-11-09 15:32:44 --> Language Class Initialized
INFO - 2019-11-09 15:32:44 --> Language Class Initialized
INFO - 2019-11-09 15:32:44 --> Config Class Initialized
INFO - 2019-11-09 15:32:44 --> Loader Class Initialized
INFO - 2019-11-09 15:32:44 --> Helper loaded: url_helper
INFO - 2019-11-09 15:32:44 --> Helper loaded: common_helper
INFO - 2019-11-09 15:32:44 --> Helper loaded: language_helper
INFO - 2019-11-09 15:32:44 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:32:44 --> Helper loaded: email_helper
INFO - 2019-11-09 15:32:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:32:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:32:44 --> Parser Class Initialized
INFO - 2019-11-09 15:32:44 --> User Agent Class Initialized
INFO - 2019-11-09 15:32:44 --> Model Class Initialized
INFO - 2019-11-09 15:32:44 --> Database Driver Class Initialized
INFO - 2019-11-09 15:32:44 --> Model Class Initialized
DEBUG - 2019-11-09 15:32:44 --> Template Class Initialized
INFO - 2019-11-09 15:32:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:32:44 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:32:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:32:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:32:44 --> Encryption Class Initialized
INFO - 2019-11-09 15:32:44 --> Controller Class Initialized
DEBUG - 2019-11-09 15:32:44 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 15:32:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 15:32:44 --> Model Class Initialized
INFO - 2019-11-09 15:32:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 15:32:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 15:32:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 15:32:44 --> Final output sent to browser
DEBUG - 2019-11-09 15:32:44 --> Total execution time: 0.7874
INFO - 2019-11-09 15:32:44 --> Config Class Initialized
INFO - 2019-11-09 15:32:45 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:32:45 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:32:45 --> Utf8 Class Initialized
INFO - 2019-11-09 15:32:45 --> URI Class Initialized
INFO - 2019-11-09 15:32:45 --> Router Class Initialized
INFO - 2019-11-09 15:32:45 --> Output Class Initialized
INFO - 2019-11-09 15:32:45 --> Security Class Initialized
DEBUG - 2019-11-09 15:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:32:45 --> CSRF cookie sent
INFO - 2019-11-09 15:32:45 --> Input Class Initialized
INFO - 2019-11-09 15:32:45 --> Language Class Initialized
INFO - 2019-11-09 15:32:45 --> Language Class Initialized
INFO - 2019-11-09 15:32:45 --> Config Class Initialized
INFO - 2019-11-09 15:32:45 --> Loader Class Initialized
INFO - 2019-11-09 15:32:45 --> Helper loaded: url_helper
INFO - 2019-11-09 15:32:45 --> Helper loaded: common_helper
INFO - 2019-11-09 15:32:45 --> Helper loaded: language_helper
INFO - 2019-11-09 15:32:45 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:32:45 --> Helper loaded: email_helper
INFO - 2019-11-09 15:32:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:32:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:32:45 --> Parser Class Initialized
INFO - 2019-11-09 15:32:45 --> User Agent Class Initialized
INFO - 2019-11-09 15:32:45 --> Model Class Initialized
INFO - 2019-11-09 15:32:45 --> Database Driver Class Initialized
INFO - 2019-11-09 15:32:45 --> Model Class Initialized
DEBUG - 2019-11-09 15:32:45 --> Template Class Initialized
INFO - 2019-11-09 15:32:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:32:45 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:32:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:32:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:32:45 --> Encryption Class Initialized
INFO - 2019-11-09 15:32:45 --> Controller Class Initialized
DEBUG - 2019-11-09 15:32:45 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 15:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 15:32:45 --> Model Class Initialized
INFO - 2019-11-09 15:32:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 15:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 15:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 15:32:45 --> Final output sent to browser
DEBUG - 2019-11-09 15:32:45 --> Total execution time: 0.7962
INFO - 2019-11-09 15:38:10 --> Config Class Initialized
INFO - 2019-11-09 15:38:10 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:38:10 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:38:10 --> Utf8 Class Initialized
INFO - 2019-11-09 15:38:10 --> URI Class Initialized
INFO - 2019-11-09 15:38:10 --> Router Class Initialized
INFO - 2019-11-09 15:38:10 --> Output Class Initialized
INFO - 2019-11-09 15:38:10 --> Security Class Initialized
DEBUG - 2019-11-09 15:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:38:10 --> CSRF cookie sent
INFO - 2019-11-09 15:38:10 --> CSRF token verified
INFO - 2019-11-09 15:38:10 --> Input Class Initialized
INFO - 2019-11-09 15:38:10 --> Language Class Initialized
INFO - 2019-11-09 15:38:10 --> Language Class Initialized
INFO - 2019-11-09 15:38:10 --> Config Class Initialized
INFO - 2019-11-09 15:38:10 --> Loader Class Initialized
INFO - 2019-11-09 15:38:10 --> Helper loaded: url_helper
INFO - 2019-11-09 15:38:10 --> Helper loaded: common_helper
INFO - 2019-11-09 15:38:10 --> Helper loaded: language_helper
INFO - 2019-11-09 15:38:10 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:38:10 --> Helper loaded: email_helper
INFO - 2019-11-09 15:38:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:38:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:38:10 --> Parser Class Initialized
INFO - 2019-11-09 15:38:10 --> User Agent Class Initialized
INFO - 2019-11-09 15:38:10 --> Model Class Initialized
INFO - 2019-11-09 15:38:10 --> Database Driver Class Initialized
INFO - 2019-11-09 15:38:10 --> Model Class Initialized
DEBUG - 2019-11-09 15:38:10 --> Template Class Initialized
INFO - 2019-11-09 15:38:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:38:10 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:38:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:38:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:38:10 --> Encryption Class Initialized
INFO - 2019-11-09 15:38:10 --> Controller Class Initialized
DEBUG - 2019-11-09 15:38:11 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:38:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:38:11 --> Model Class Initialized
DEBUG - 2019-11-09 15:38:11 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:38:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-09 15:38:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-09 15:38:12 --> Final output sent to browser
DEBUG - 2019-11-09 15:38:12 --> Total execution time: 2.2889
INFO - 2019-11-09 15:38:24 --> Config Class Initialized
INFO - 2019-11-09 15:38:24 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:38:24 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:38:24 --> Utf8 Class Initialized
INFO - 2019-11-09 15:38:24 --> URI Class Initialized
INFO - 2019-11-09 15:38:24 --> Router Class Initialized
INFO - 2019-11-09 15:38:24 --> Output Class Initialized
INFO - 2019-11-09 15:38:24 --> Security Class Initialized
DEBUG - 2019-11-09 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:38:24 --> Input Class Initialized
INFO - 2019-11-09 15:38:24 --> Language Class Initialized
INFO - 2019-11-09 15:38:24 --> Language Class Initialized
INFO - 2019-11-09 15:38:24 --> Config Class Initialized
INFO - 2019-11-09 15:38:24 --> Loader Class Initialized
INFO - 2019-11-09 15:38:24 --> Helper loaded: url_helper
INFO - 2019-11-09 15:38:24 --> Helper loaded: common_helper
INFO - 2019-11-09 15:38:24 --> Helper loaded: language_helper
INFO - 2019-11-09 15:38:24 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:38:24 --> Helper loaded: email_helper
INFO - 2019-11-09 15:38:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:38:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:38:24 --> Parser Class Initialized
INFO - 2019-11-09 15:38:24 --> User Agent Class Initialized
INFO - 2019-11-09 15:38:24 --> Model Class Initialized
INFO - 2019-11-09 15:38:24 --> Database Driver Class Initialized
INFO - 2019-11-09 15:38:24 --> Model Class Initialized
DEBUG - 2019-11-09 15:38:24 --> Template Class Initialized
INFO - 2019-11-09 15:38:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:38:25 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:38:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:38:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:38:25 --> Encryption Class Initialized
INFO - 2019-11-09 15:38:25 --> Controller Class Initialized
DEBUG - 2019-11-09 15:38:25 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 15:38:25 --> Model Class Initialized
INFO - 2019-11-09 15:40:07 --> Config Class Initialized
INFO - 2019-11-09 15:40:07 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:40:07 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:40:07 --> Utf8 Class Initialized
INFO - 2019-11-09 15:40:07 --> URI Class Initialized
INFO - 2019-11-09 15:40:07 --> Router Class Initialized
INFO - 2019-11-09 15:40:07 --> Output Class Initialized
INFO - 2019-11-09 15:40:07 --> Security Class Initialized
DEBUG - 2019-11-09 15:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:40:07 --> Input Class Initialized
INFO - 2019-11-09 15:40:07 --> Language Class Initialized
INFO - 2019-11-09 15:40:07 --> Language Class Initialized
INFO - 2019-11-09 15:40:07 --> Config Class Initialized
INFO - 2019-11-09 15:40:07 --> Loader Class Initialized
INFO - 2019-11-09 15:40:07 --> Helper loaded: url_helper
INFO - 2019-11-09 15:40:07 --> Helper loaded: common_helper
INFO - 2019-11-09 15:40:07 --> Helper loaded: language_helper
INFO - 2019-11-09 15:40:07 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:40:07 --> Helper loaded: email_helper
INFO - 2019-11-09 15:40:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:40:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:40:08 --> Parser Class Initialized
INFO - 2019-11-09 15:40:08 --> User Agent Class Initialized
INFO - 2019-11-09 15:40:08 --> Model Class Initialized
INFO - 2019-11-09 15:40:08 --> Database Driver Class Initialized
INFO - 2019-11-09 15:40:08 --> Model Class Initialized
DEBUG - 2019-11-09 15:40:08 --> Template Class Initialized
INFO - 2019-11-09 15:40:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:40:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:40:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:40:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:40:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:40:08 --> Encryption Class Initialized
INFO - 2019-11-09 15:40:08 --> Controller Class Initialized
DEBUG - 2019-11-09 15:40:08 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:40:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 15:40:08 --> Model Class Initialized
INFO - 2019-11-09 15:51:57 --> Config Class Initialized
INFO - 2019-11-09 15:51:57 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:51:57 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:51:57 --> Utf8 Class Initialized
INFO - 2019-11-09 15:51:57 --> URI Class Initialized
INFO - 2019-11-09 15:51:57 --> Router Class Initialized
INFO - 2019-11-09 15:51:57 --> Output Class Initialized
INFO - 2019-11-09 15:51:57 --> Security Class Initialized
DEBUG - 2019-11-09 15:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:51:57 --> CSRF cookie sent
INFO - 2019-11-09 15:51:57 --> Input Class Initialized
INFO - 2019-11-09 15:51:57 --> Language Class Initialized
INFO - 2019-11-09 15:51:57 --> Language Class Initialized
INFO - 2019-11-09 15:51:57 --> Config Class Initialized
INFO - 2019-11-09 15:51:57 --> Loader Class Initialized
INFO - 2019-11-09 15:51:57 --> Helper loaded: url_helper
INFO - 2019-11-09 15:51:57 --> Helper loaded: common_helper
INFO - 2019-11-09 15:51:57 --> Helper loaded: language_helper
INFO - 2019-11-09 15:51:57 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:51:57 --> Helper loaded: email_helper
INFO - 2019-11-09 15:51:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:51:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:51:57 --> Parser Class Initialized
INFO - 2019-11-09 15:51:57 --> User Agent Class Initialized
INFO - 2019-11-09 15:51:57 --> Model Class Initialized
INFO - 2019-11-09 15:51:57 --> Database Driver Class Initialized
INFO - 2019-11-09 15:51:57 --> Model Class Initialized
DEBUG - 2019-11-09 15:51:57 --> Template Class Initialized
INFO - 2019-11-09 15:51:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:51:57 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:51:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:51:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:51:57 --> Encryption Class Initialized
INFO - 2019-11-09 15:51:57 --> Controller Class Initialized
DEBUG - 2019-11-09 15:51:57 --> package MX_Controller Initialized
DEBUG - 2019-11-09 15:51:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 15:51:57 --> Model Class Initialized
INFO - 2019-11-09 15:51:57 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 15:51:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:51:58 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:51:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:51:58 --> Model Class Initialized
DEBUG - 2019-11-09 15:51:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:51:58 --> Model Class Initialized
DEBUG - 2019-11-09 15:51:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 15:51:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 15:51:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 15:51:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 15:51:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 15:51:58 --> Final output sent to browser
DEBUG - 2019-11-09 15:51:58 --> Total execution time: 1.2145
INFO - 2019-11-09 15:52:02 --> Config Class Initialized
INFO - 2019-11-09 15:52:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:52:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:52:02 --> Utf8 Class Initialized
INFO - 2019-11-09 15:52:02 --> URI Class Initialized
INFO - 2019-11-09 15:52:02 --> Router Class Initialized
INFO - 2019-11-09 15:52:02 --> Output Class Initialized
INFO - 2019-11-09 15:52:02 --> Security Class Initialized
DEBUG - 2019-11-09 15:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:52:02 --> CSRF cookie sent
INFO - 2019-11-09 15:52:02 --> CSRF token verified
INFO - 2019-11-09 15:52:02 --> Input Class Initialized
INFO - 2019-11-09 15:52:02 --> Language Class Initialized
INFO - 2019-11-09 15:52:02 --> Language Class Initialized
INFO - 2019-11-09 15:52:02 --> Config Class Initialized
INFO - 2019-11-09 15:52:02 --> Loader Class Initialized
INFO - 2019-11-09 15:52:02 --> Helper loaded: url_helper
INFO - 2019-11-09 15:52:02 --> Helper loaded: common_helper
INFO - 2019-11-09 15:52:02 --> Helper loaded: language_helper
INFO - 2019-11-09 15:52:02 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:52:02 --> Helper loaded: email_helper
INFO - 2019-11-09 15:52:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:52:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:52:02 --> Parser Class Initialized
INFO - 2019-11-09 15:52:02 --> User Agent Class Initialized
INFO - 2019-11-09 15:52:02 --> Model Class Initialized
INFO - 2019-11-09 15:52:02 --> Database Driver Class Initialized
INFO - 2019-11-09 15:52:02 --> Model Class Initialized
DEBUG - 2019-11-09 15:52:02 --> Template Class Initialized
INFO - 2019-11-09 15:52:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:52:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:52:02 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:52:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:52:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:52:02 --> Encryption Class Initialized
INFO - 2019-11-09 15:52:02 --> Controller Class Initialized
DEBUG - 2019-11-09 15:52:02 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:52:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:52:02 --> Model Class Initialized
INFO - 2019-11-09 15:52:02 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 15:52:03 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 15:52:03 --> Could not find the language line "paystack"
ERROR - 2019-11-09 15:52:03 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 15:52:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 15:52:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:52:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:52:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:52:03 --> Model Class Initialized
DEBUG - 2019-11-09 15:52:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:52:03 --> Model Class Initialized
DEBUG - 2019-11-09 15:52:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 15:52:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 15:52:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 15:52:03 --> Final output sent to browser
DEBUG - 2019-11-09 15:52:03 --> Total execution time: 1.2395
INFO - 2019-11-09 15:52:15 --> Config Class Initialized
INFO - 2019-11-09 15:52:15 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:52:15 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:52:15 --> Utf8 Class Initialized
INFO - 2019-11-09 15:52:15 --> URI Class Initialized
INFO - 2019-11-09 15:52:15 --> Router Class Initialized
INFO - 2019-11-09 15:52:15 --> Output Class Initialized
INFO - 2019-11-09 15:52:15 --> Security Class Initialized
DEBUG - 2019-11-09 15:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:52:15 --> CSRF cookie sent
INFO - 2019-11-09 15:52:15 --> CSRF token verified
INFO - 2019-11-09 15:52:15 --> Input Class Initialized
INFO - 2019-11-09 15:52:15 --> Language Class Initialized
INFO - 2019-11-09 15:52:15 --> Language Class Initialized
INFO - 2019-11-09 15:52:15 --> Config Class Initialized
INFO - 2019-11-09 15:52:15 --> Loader Class Initialized
INFO - 2019-11-09 15:52:15 --> Helper loaded: url_helper
INFO - 2019-11-09 15:52:15 --> Helper loaded: common_helper
INFO - 2019-11-09 15:52:15 --> Helper loaded: language_helper
INFO - 2019-11-09 15:52:15 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:52:15 --> Helper loaded: email_helper
INFO - 2019-11-09 15:52:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:52:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:52:15 --> Parser Class Initialized
INFO - 2019-11-09 15:52:15 --> User Agent Class Initialized
INFO - 2019-11-09 15:52:15 --> Model Class Initialized
INFO - 2019-11-09 15:52:15 --> Database Driver Class Initialized
INFO - 2019-11-09 15:52:15 --> Model Class Initialized
DEBUG - 2019-11-09 15:52:15 --> Template Class Initialized
INFO - 2019-11-09 15:52:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:52:15 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:52:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:52:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:52:15 --> Encryption Class Initialized
INFO - 2019-11-09 15:52:15 --> Controller Class Initialized
DEBUG - 2019-11-09 15:52:15 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:52:15 --> Model Class Initialized
DEBUG - 2019-11-09 15:52:15 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 15:55:27 --> Config Class Initialized
INFO - 2019-11-09 15:55:27 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:55:27 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:55:27 --> Utf8 Class Initialized
INFO - 2019-11-09 15:55:27 --> URI Class Initialized
INFO - 2019-11-09 15:55:27 --> Router Class Initialized
INFO - 2019-11-09 15:55:27 --> Output Class Initialized
INFO - 2019-11-09 15:55:27 --> Security Class Initialized
DEBUG - 2019-11-09 15:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:55:27 --> CSRF cookie sent
INFO - 2019-11-09 15:55:27 --> CSRF token verified
INFO - 2019-11-09 15:55:27 --> Input Class Initialized
INFO - 2019-11-09 15:55:27 --> Language Class Initialized
INFO - 2019-11-09 15:55:27 --> Language Class Initialized
INFO - 2019-11-09 15:55:27 --> Config Class Initialized
INFO - 2019-11-09 15:55:27 --> Loader Class Initialized
INFO - 2019-11-09 15:55:27 --> Helper loaded: url_helper
INFO - 2019-11-09 15:55:27 --> Helper loaded: common_helper
INFO - 2019-11-09 15:55:27 --> Helper loaded: language_helper
INFO - 2019-11-09 15:55:27 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:55:27 --> Helper loaded: email_helper
INFO - 2019-11-09 15:55:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:55:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:55:27 --> Parser Class Initialized
INFO - 2019-11-09 15:55:27 --> User Agent Class Initialized
INFO - 2019-11-09 15:55:27 --> Model Class Initialized
INFO - 2019-11-09 15:55:27 --> Database Driver Class Initialized
INFO - 2019-11-09 15:55:27 --> Model Class Initialized
DEBUG - 2019-11-09 15:55:27 --> Template Class Initialized
INFO - 2019-11-09 15:55:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:55:27 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:55:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:55:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:55:28 --> Encryption Class Initialized
INFO - 2019-11-09 15:55:28 --> Controller Class Initialized
DEBUG - 2019-11-09 15:55:28 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:55:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:55:28 --> Model Class Initialized
INFO - 2019-11-09 15:55:28 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 15:55:28 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 15:55:28 --> Could not find the language line "paystack"
ERROR - 2019-11-09 15:55:28 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 15:55:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 15:55:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:55:28 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:55:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:55:28 --> Model Class Initialized
DEBUG - 2019-11-09 15:55:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:55:28 --> Model Class Initialized
DEBUG - 2019-11-09 15:55:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 15:55:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 15:55:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 15:55:28 --> Final output sent to browser
DEBUG - 2019-11-09 15:55:28 --> Total execution time: 1.1241
INFO - 2019-11-09 15:55:37 --> Config Class Initialized
INFO - 2019-11-09 15:55:37 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:55:37 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:55:37 --> Utf8 Class Initialized
INFO - 2019-11-09 15:55:37 --> URI Class Initialized
INFO - 2019-11-09 15:55:37 --> Router Class Initialized
INFO - 2019-11-09 15:55:37 --> Output Class Initialized
INFO - 2019-11-09 15:55:38 --> Security Class Initialized
DEBUG - 2019-11-09 15:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:55:38 --> CSRF cookie sent
INFO - 2019-11-09 15:55:38 --> CSRF token verified
INFO - 2019-11-09 15:55:38 --> Input Class Initialized
INFO - 2019-11-09 15:55:38 --> Language Class Initialized
INFO - 2019-11-09 15:55:38 --> Language Class Initialized
INFO - 2019-11-09 15:55:38 --> Config Class Initialized
INFO - 2019-11-09 15:55:38 --> Loader Class Initialized
INFO - 2019-11-09 15:55:38 --> Helper loaded: url_helper
INFO - 2019-11-09 15:55:38 --> Helper loaded: common_helper
INFO - 2019-11-09 15:55:38 --> Helper loaded: language_helper
INFO - 2019-11-09 15:55:38 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:55:38 --> Helper loaded: email_helper
INFO - 2019-11-09 15:55:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:55:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:55:38 --> Parser Class Initialized
INFO - 2019-11-09 15:55:38 --> User Agent Class Initialized
INFO - 2019-11-09 15:55:38 --> Model Class Initialized
INFO - 2019-11-09 15:55:38 --> Database Driver Class Initialized
INFO - 2019-11-09 15:55:38 --> Model Class Initialized
DEBUG - 2019-11-09 15:55:38 --> Template Class Initialized
INFO - 2019-11-09 15:55:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:55:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:55:38 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:55:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:55:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:55:38 --> Encryption Class Initialized
INFO - 2019-11-09 15:55:38 --> Controller Class Initialized
DEBUG - 2019-11-09 15:55:38 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:55:38 --> Model Class Initialized
DEBUG - 2019-11-09 15:55:38 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 15:55:53 --> Config Class Initialized
INFO - 2019-11-09 15:55:53 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:55:53 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:55:53 --> Utf8 Class Initialized
INFO - 2019-11-09 15:55:53 --> URI Class Initialized
INFO - 2019-11-09 15:55:53 --> Router Class Initialized
INFO - 2019-11-09 15:55:53 --> Output Class Initialized
INFO - 2019-11-09 15:55:53 --> Security Class Initialized
DEBUG - 2019-11-09 15:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:55:53 --> CSRF cookie sent
INFO - 2019-11-09 15:55:53 --> CSRF token verified
INFO - 2019-11-09 15:55:53 --> Input Class Initialized
INFO - 2019-11-09 15:55:53 --> Language Class Initialized
INFO - 2019-11-09 15:55:53 --> Language Class Initialized
INFO - 2019-11-09 15:55:53 --> Config Class Initialized
INFO - 2019-11-09 15:55:53 --> Loader Class Initialized
INFO - 2019-11-09 15:55:53 --> Helper loaded: url_helper
INFO - 2019-11-09 15:55:53 --> Helper loaded: common_helper
INFO - 2019-11-09 15:55:53 --> Helper loaded: language_helper
INFO - 2019-11-09 15:55:53 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:55:53 --> Helper loaded: email_helper
INFO - 2019-11-09 15:55:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:55:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:55:53 --> Parser Class Initialized
INFO - 2019-11-09 15:55:53 --> User Agent Class Initialized
INFO - 2019-11-09 15:55:53 --> Model Class Initialized
INFO - 2019-11-09 15:55:53 --> Database Driver Class Initialized
INFO - 2019-11-09 15:55:53 --> Model Class Initialized
DEBUG - 2019-11-09 15:55:53 --> Template Class Initialized
INFO - 2019-11-09 15:55:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:55:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:55:53 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:55:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:55:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:55:53 --> Encryption Class Initialized
INFO - 2019-11-09 15:55:53 --> Controller Class Initialized
DEBUG - 2019-11-09 15:55:53 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:55:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:55:53 --> Model Class Initialized
INFO - 2019-11-09 15:55:54 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 15:55:54 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 15:55:54 --> Could not find the language line "paystack"
ERROR - 2019-11-09 15:55:54 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 15:55:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 15:55:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 15:55:54 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 15:55:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 15:55:54 --> Model Class Initialized
DEBUG - 2019-11-09 15:55:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 15:55:54 --> Model Class Initialized
DEBUG - 2019-11-09 15:55:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 15:55:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 15:55:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 15:55:54 --> Final output sent to browser
DEBUG - 2019-11-09 15:55:54 --> Total execution time: 1.1050
INFO - 2019-11-09 15:56:01 --> Config Class Initialized
INFO - 2019-11-09 15:56:01 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:56:01 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:56:01 --> Utf8 Class Initialized
INFO - 2019-11-09 15:56:01 --> URI Class Initialized
INFO - 2019-11-09 15:56:01 --> Router Class Initialized
INFO - 2019-11-09 15:56:01 --> Output Class Initialized
INFO - 2019-11-09 15:56:01 --> Security Class Initialized
DEBUG - 2019-11-09 15:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:56:01 --> CSRF cookie sent
INFO - 2019-11-09 15:56:01 --> CSRF token verified
INFO - 2019-11-09 15:56:01 --> Input Class Initialized
INFO - 2019-11-09 15:56:01 --> Language Class Initialized
INFO - 2019-11-09 15:56:01 --> Language Class Initialized
INFO - 2019-11-09 15:56:01 --> Config Class Initialized
INFO - 2019-11-09 15:56:01 --> Loader Class Initialized
INFO - 2019-11-09 15:56:01 --> Helper loaded: url_helper
INFO - 2019-11-09 15:56:01 --> Helper loaded: common_helper
INFO - 2019-11-09 15:56:01 --> Helper loaded: language_helper
INFO - 2019-11-09 15:56:01 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:56:02 --> Helper loaded: email_helper
INFO - 2019-11-09 15:56:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:56:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:56:02 --> Parser Class Initialized
INFO - 2019-11-09 15:56:02 --> User Agent Class Initialized
INFO - 2019-11-09 15:56:02 --> Model Class Initialized
INFO - 2019-11-09 15:56:02 --> Database Driver Class Initialized
INFO - 2019-11-09 15:56:02 --> Model Class Initialized
DEBUG - 2019-11-09 15:56:02 --> Template Class Initialized
INFO - 2019-11-09 15:56:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:56:02 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:56:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:56:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:56:02 --> Encryption Class Initialized
INFO - 2019-11-09 15:56:02 --> Controller Class Initialized
DEBUG - 2019-11-09 15:56:02 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:56:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:56:02 --> Model Class Initialized
DEBUG - 2019-11-09 15:56:02 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:56:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-09 15:56:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-09 15:56:03 --> Final output sent to browser
DEBUG - 2019-11-09 15:56:03 --> Total execution time: 2.3421
INFO - 2019-11-09 15:56:10 --> Config Class Initialized
INFO - 2019-11-09 15:56:10 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:56:10 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:56:10 --> Utf8 Class Initialized
INFO - 2019-11-09 15:56:10 --> URI Class Initialized
INFO - 2019-11-09 15:56:10 --> Router Class Initialized
INFO - 2019-11-09 15:56:10 --> Output Class Initialized
INFO - 2019-11-09 15:56:10 --> Security Class Initialized
DEBUG - 2019-11-09 15:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:56:10 --> Input Class Initialized
INFO - 2019-11-09 15:56:10 --> Language Class Initialized
INFO - 2019-11-09 15:56:10 --> Language Class Initialized
INFO - 2019-11-09 15:56:10 --> Config Class Initialized
INFO - 2019-11-09 15:56:10 --> Loader Class Initialized
INFO - 2019-11-09 15:56:10 --> Helper loaded: url_helper
INFO - 2019-11-09 15:56:10 --> Helper loaded: common_helper
INFO - 2019-11-09 15:56:10 --> Helper loaded: language_helper
INFO - 2019-11-09 15:56:10 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:56:10 --> Helper loaded: email_helper
INFO - 2019-11-09 15:56:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:56:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:56:10 --> Parser Class Initialized
INFO - 2019-11-09 15:56:10 --> User Agent Class Initialized
INFO - 2019-11-09 15:56:10 --> Model Class Initialized
INFO - 2019-11-09 15:56:10 --> Database Driver Class Initialized
INFO - 2019-11-09 15:56:10 --> Model Class Initialized
DEBUG - 2019-11-09 15:56:10 --> Template Class Initialized
INFO - 2019-11-09 15:56:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:56:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:56:10 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:56:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:56:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:56:10 --> Encryption Class Initialized
INFO - 2019-11-09 15:56:10 --> Controller Class Initialized
DEBUG - 2019-11-09 15:56:10 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:56:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 15:56:10 --> Model Class Initialized
ERROR - 2019-11-09 15:56:17 --> Severity: Notice --> Undefined property: stdClass::$payment D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 93
ERROR - 2019-11-09 15:56:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 93
INFO - 2019-11-09 15:57:12 --> Config Class Initialized
INFO - 2019-11-09 15:57:12 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:57:12 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:57:12 --> Utf8 Class Initialized
INFO - 2019-11-09 15:57:12 --> URI Class Initialized
INFO - 2019-11-09 15:57:12 --> Router Class Initialized
INFO - 2019-11-09 15:57:12 --> Output Class Initialized
INFO - 2019-11-09 15:57:12 --> Security Class Initialized
DEBUG - 2019-11-09 15:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:57:12 --> Input Class Initialized
INFO - 2019-11-09 15:57:12 --> Language Class Initialized
INFO - 2019-11-09 15:57:12 --> Language Class Initialized
INFO - 2019-11-09 15:57:12 --> Config Class Initialized
INFO - 2019-11-09 15:57:12 --> Loader Class Initialized
INFO - 2019-11-09 15:57:12 --> Helper loaded: url_helper
INFO - 2019-11-09 15:57:12 --> Helper loaded: common_helper
INFO - 2019-11-09 15:57:12 --> Helper loaded: language_helper
INFO - 2019-11-09 15:57:12 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:57:12 --> Helper loaded: email_helper
INFO - 2019-11-09 15:57:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:57:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:57:12 --> Parser Class Initialized
INFO - 2019-11-09 15:57:12 --> User Agent Class Initialized
INFO - 2019-11-09 15:57:12 --> Model Class Initialized
INFO - 2019-11-09 15:57:13 --> Database Driver Class Initialized
INFO - 2019-11-09 15:57:13 --> Model Class Initialized
DEBUG - 2019-11-09 15:57:13 --> Template Class Initialized
INFO - 2019-11-09 15:57:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:57:13 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:57:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:57:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:57:13 --> Encryption Class Initialized
INFO - 2019-11-09 15:57:13 --> Controller Class Initialized
DEBUG - 2019-11-09 15:57:13 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:57:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 15:57:13 --> Model Class Initialized
ERROR - 2019-11-09 15:57:16 --> Severity: Notice --> Undefined property: stdClass::$payment D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 93
ERROR - 2019-11-09 15:57:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 93
INFO - 2019-11-09 15:57:30 --> Config Class Initialized
INFO - 2019-11-09 15:57:30 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:57:30 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:57:30 --> Utf8 Class Initialized
INFO - 2019-11-09 15:57:30 --> URI Class Initialized
INFO - 2019-11-09 15:57:30 --> Router Class Initialized
INFO - 2019-11-09 15:57:30 --> Output Class Initialized
INFO - 2019-11-09 15:57:30 --> Security Class Initialized
DEBUG - 2019-11-09 15:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:57:30 --> CSRF cookie sent
INFO - 2019-11-09 15:57:30 --> CSRF token verified
INFO - 2019-11-09 15:57:30 --> Input Class Initialized
INFO - 2019-11-09 15:57:30 --> Language Class Initialized
INFO - 2019-11-09 15:57:30 --> Language Class Initialized
INFO - 2019-11-09 15:57:30 --> Config Class Initialized
INFO - 2019-11-09 15:57:30 --> Loader Class Initialized
INFO - 2019-11-09 15:57:30 --> Helper loaded: url_helper
INFO - 2019-11-09 15:57:30 --> Helper loaded: common_helper
INFO - 2019-11-09 15:57:30 --> Helper loaded: language_helper
INFO - 2019-11-09 15:57:30 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:57:30 --> Helper loaded: email_helper
INFO - 2019-11-09 15:57:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:57:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:57:30 --> Parser Class Initialized
INFO - 2019-11-09 15:57:30 --> User Agent Class Initialized
INFO - 2019-11-09 15:57:30 --> Model Class Initialized
INFO - 2019-11-09 15:57:30 --> Database Driver Class Initialized
INFO - 2019-11-09 15:57:30 --> Model Class Initialized
DEBUG - 2019-11-09 15:57:30 --> Template Class Initialized
INFO - 2019-11-09 15:57:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:57:30 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:57:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:57:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:57:31 --> Encryption Class Initialized
INFO - 2019-11-09 15:57:31 --> Controller Class Initialized
DEBUG - 2019-11-09 15:57:31 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 15:57:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 15:57:31 --> Model Class Initialized
DEBUG - 2019-11-09 15:57:31 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:57:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-09 15:57:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-09 15:57:34 --> Final output sent to browser
DEBUG - 2019-11-09 15:57:34 --> Total execution time: 3.9323
INFO - 2019-11-09 15:57:39 --> Config Class Initialized
INFO - 2019-11-09 15:57:39 --> Hooks Class Initialized
DEBUG - 2019-11-09 15:57:39 --> UTF-8 Support Enabled
INFO - 2019-11-09 15:57:39 --> Utf8 Class Initialized
INFO - 2019-11-09 15:57:39 --> URI Class Initialized
INFO - 2019-11-09 15:57:39 --> Router Class Initialized
INFO - 2019-11-09 15:57:39 --> Output Class Initialized
INFO - 2019-11-09 15:57:39 --> Security Class Initialized
DEBUG - 2019-11-09 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 15:57:39 --> Input Class Initialized
INFO - 2019-11-09 15:57:39 --> Language Class Initialized
INFO - 2019-11-09 15:57:39 --> Language Class Initialized
INFO - 2019-11-09 15:57:39 --> Config Class Initialized
INFO - 2019-11-09 15:57:39 --> Loader Class Initialized
INFO - 2019-11-09 15:57:39 --> Helper loaded: url_helper
INFO - 2019-11-09 15:57:39 --> Helper loaded: common_helper
INFO - 2019-11-09 15:57:39 --> Helper loaded: language_helper
INFO - 2019-11-09 15:57:40 --> Helper loaded: cookie_helper
INFO - 2019-11-09 15:57:40 --> Helper loaded: email_helper
INFO - 2019-11-09 15:57:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 15:57:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 15:57:40 --> Parser Class Initialized
INFO - 2019-11-09 15:57:40 --> User Agent Class Initialized
INFO - 2019-11-09 15:57:40 --> Model Class Initialized
INFO - 2019-11-09 15:57:40 --> Database Driver Class Initialized
INFO - 2019-11-09 15:57:40 --> Model Class Initialized
DEBUG - 2019-11-09 15:57:40 --> Template Class Initialized
INFO - 2019-11-09 15:57:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 15:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 15:57:40 --> Pagination Class Initialized
DEBUG - 2019-11-09 15:57:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 15:57:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 15:57:40 --> Encryption Class Initialized
INFO - 2019-11-09 15:57:40 --> Controller Class Initialized
DEBUG - 2019-11-09 15:57:40 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 15:57:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 15:57:40 --> Model Class Initialized
INFO - 2019-11-09 16:00:29 --> Config Class Initialized
INFO - 2019-11-09 16:00:29 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:00:29 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:00:29 --> Utf8 Class Initialized
INFO - 2019-11-09 16:00:29 --> URI Class Initialized
INFO - 2019-11-09 16:00:29 --> Router Class Initialized
INFO - 2019-11-09 16:00:29 --> Output Class Initialized
INFO - 2019-11-09 16:00:29 --> Security Class Initialized
DEBUG - 2019-11-09 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:00:30 --> Input Class Initialized
INFO - 2019-11-09 16:00:30 --> Language Class Initialized
INFO - 2019-11-09 16:00:30 --> Language Class Initialized
INFO - 2019-11-09 16:00:30 --> Config Class Initialized
INFO - 2019-11-09 16:00:30 --> Loader Class Initialized
INFO - 2019-11-09 16:00:30 --> Helper loaded: url_helper
INFO - 2019-11-09 16:00:30 --> Helper loaded: common_helper
INFO - 2019-11-09 16:00:30 --> Helper loaded: language_helper
INFO - 2019-11-09 16:00:30 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:00:30 --> Helper loaded: email_helper
INFO - 2019-11-09 16:00:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:00:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:00:30 --> Parser Class Initialized
INFO - 2019-11-09 16:00:30 --> User Agent Class Initialized
INFO - 2019-11-09 16:00:30 --> Model Class Initialized
INFO - 2019-11-09 16:00:30 --> Database Driver Class Initialized
INFO - 2019-11-09 16:00:30 --> Model Class Initialized
DEBUG - 2019-11-09 16:00:30 --> Template Class Initialized
INFO - 2019-11-09 16:00:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:00:30 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:00:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:00:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:00:30 --> Encryption Class Initialized
INFO - 2019-11-09 16:00:30 --> Controller Class Initialized
DEBUG - 2019-11-09 16:00:30 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 16:00:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 16:00:30 --> Model Class Initialized
INFO - 2019-11-09 16:03:19 --> Config Class Initialized
INFO - 2019-11-09 16:03:19 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:03:19 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:03:19 --> Utf8 Class Initialized
INFO - 2019-11-09 16:03:19 --> URI Class Initialized
INFO - 2019-11-09 16:03:19 --> Router Class Initialized
INFO - 2019-11-09 16:03:19 --> Output Class Initialized
INFO - 2019-11-09 16:03:19 --> Security Class Initialized
DEBUG - 2019-11-09 16:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:03:19 --> Input Class Initialized
INFO - 2019-11-09 16:03:20 --> Language Class Initialized
INFO - 2019-11-09 16:03:20 --> Language Class Initialized
INFO - 2019-11-09 16:03:20 --> Config Class Initialized
INFO - 2019-11-09 16:03:20 --> Loader Class Initialized
INFO - 2019-11-09 16:03:20 --> Helper loaded: url_helper
INFO - 2019-11-09 16:03:20 --> Helper loaded: common_helper
INFO - 2019-11-09 16:03:20 --> Helper loaded: language_helper
INFO - 2019-11-09 16:03:20 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:03:20 --> Helper loaded: email_helper
INFO - 2019-11-09 16:03:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:03:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:03:20 --> Parser Class Initialized
INFO - 2019-11-09 16:03:20 --> User Agent Class Initialized
INFO - 2019-11-09 16:03:20 --> Model Class Initialized
INFO - 2019-11-09 16:03:20 --> Database Driver Class Initialized
INFO - 2019-11-09 16:03:20 --> Model Class Initialized
DEBUG - 2019-11-09 16:03:20 --> Template Class Initialized
INFO - 2019-11-09 16:03:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:03:20 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:03:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:03:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:03:20 --> Encryption Class Initialized
INFO - 2019-11-09 16:03:20 --> Controller Class Initialized
DEBUG - 2019-11-09 16:03:20 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 16:03:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 16:03:20 --> Model Class Initialized
DEBUG - 2019-11-09 16:03:22 --> orders MX_Controller Initialized
INFO - 2019-11-09 16:03:22 --> Config Class Initialized
INFO - 2019-11-09 16:03:22 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:03:22 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:03:22 --> Utf8 Class Initialized
INFO - 2019-11-09 16:03:22 --> URI Class Initialized
INFO - 2019-11-09 16:03:22 --> Router Class Initialized
INFO - 2019-11-09 16:03:22 --> Output Class Initialized
INFO - 2019-11-09 16:03:22 --> Security Class Initialized
DEBUG - 2019-11-09 16:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:03:22 --> CSRF cookie sent
INFO - 2019-11-09 16:03:22 --> Input Class Initialized
INFO - 2019-11-09 16:03:22 --> Language Class Initialized
INFO - 2019-11-09 16:03:22 --> Language Class Initialized
INFO - 2019-11-09 16:03:22 --> Config Class Initialized
INFO - 2019-11-09 16:03:22 --> Loader Class Initialized
INFO - 2019-11-09 16:03:22 --> Helper loaded: url_helper
INFO - 2019-11-09 16:03:22 --> Helper loaded: common_helper
INFO - 2019-11-09 16:03:22 --> Helper loaded: language_helper
INFO - 2019-11-09 16:03:22 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:03:22 --> Helper loaded: email_helper
INFO - 2019-11-09 16:03:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:03:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:03:22 --> Parser Class Initialized
INFO - 2019-11-09 16:03:22 --> User Agent Class Initialized
INFO - 2019-11-09 16:03:22 --> Model Class Initialized
INFO - 2019-11-09 16:03:22 --> Database Driver Class Initialized
INFO - 2019-11-09 16:03:22 --> Model Class Initialized
DEBUG - 2019-11-09 16:03:22 --> Template Class Initialized
INFO - 2019-11-09 16:03:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:03:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:03:22 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:03:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:03:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:03:22 --> Encryption Class Initialized
INFO - 2019-11-09 16:03:22 --> Controller Class Initialized
DEBUG - 2019-11-09 16:03:22 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:03:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:03:22 --> Model Class Initialized
INFO - 2019-11-09 16:03:22 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:03:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-09 16:03:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:03:23 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:03:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:03:23 --> Model Class Initialized
DEBUG - 2019-11-09 16:03:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:03:23 --> Model Class Initialized
DEBUG - 2019-11-09 16:03:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:03:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:03:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:03:23 --> Final output sent to browser
DEBUG - 2019-11-09 16:03:23 --> Total execution time: 1.0913
INFO - 2019-11-09 16:07:59 --> Config Class Initialized
INFO - 2019-11-09 16:07:59 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:07:59 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:07:59 --> Utf8 Class Initialized
INFO - 2019-11-09 16:07:59 --> URI Class Initialized
DEBUG - 2019-11-09 16:07:59 --> No URI present. Default controller set.
INFO - 2019-11-09 16:07:59 --> Router Class Initialized
INFO - 2019-11-09 16:07:59 --> Output Class Initialized
INFO - 2019-11-09 16:07:59 --> Security Class Initialized
DEBUG - 2019-11-09 16:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:07:59 --> CSRF cookie sent
INFO - 2019-11-09 16:07:59 --> Input Class Initialized
INFO - 2019-11-09 16:07:59 --> Language Class Initialized
INFO - 2019-11-09 16:07:59 --> Language Class Initialized
INFO - 2019-11-09 16:07:59 --> Config Class Initialized
INFO - 2019-11-09 16:07:59 --> Loader Class Initialized
INFO - 2019-11-09 16:07:59 --> Helper loaded: url_helper
INFO - 2019-11-09 16:07:59 --> Helper loaded: common_helper
INFO - 2019-11-09 16:07:59 --> Helper loaded: language_helper
INFO - 2019-11-09 16:07:59 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:07:59 --> Helper loaded: email_helper
INFO - 2019-11-09 16:07:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:07:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:07:59 --> Parser Class Initialized
INFO - 2019-11-09 16:07:59 --> User Agent Class Initialized
INFO - 2019-11-09 16:07:59 --> Model Class Initialized
INFO - 2019-11-09 16:07:59 --> Database Driver Class Initialized
INFO - 2019-11-09 16:07:59 --> Model Class Initialized
DEBUG - 2019-11-09 16:07:59 --> Template Class Initialized
INFO - 2019-11-09 16:07:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:07:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:07:59 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:07:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:07:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:07:59 --> Encryption Class Initialized
DEBUG - 2019-11-09 16:07:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:07:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 16:07:59 --> Controller Class Initialized
DEBUG - 2019-11-09 16:07:59 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 16:07:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:07:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 16:07:59 --> Model Class Initialized
INFO - 2019-11-09 16:07:59 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:07:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 16:08:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 16:08:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 16:08:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 16:08:00 --> Final output sent to browser
DEBUG - 2019-11-09 16:08:00 --> Total execution time: 1.1143
INFO - 2019-11-09 16:08:02 --> Config Class Initialized
INFO - 2019-11-09 16:08:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:08:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:08:03 --> Utf8 Class Initialized
INFO - 2019-11-09 16:08:03 --> URI Class Initialized
INFO - 2019-11-09 16:08:03 --> Router Class Initialized
INFO - 2019-11-09 16:08:03 --> Output Class Initialized
INFO - 2019-11-09 16:08:03 --> Security Class Initialized
DEBUG - 2019-11-09 16:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:08:03 --> CSRF cookie sent
INFO - 2019-11-09 16:08:03 --> Input Class Initialized
INFO - 2019-11-09 16:08:03 --> Language Class Initialized
INFO - 2019-11-09 16:08:03 --> Language Class Initialized
INFO - 2019-11-09 16:08:03 --> Config Class Initialized
INFO - 2019-11-09 16:08:03 --> Loader Class Initialized
INFO - 2019-11-09 16:08:03 --> Helper loaded: url_helper
INFO - 2019-11-09 16:08:03 --> Helper loaded: common_helper
INFO - 2019-11-09 16:08:03 --> Helper loaded: language_helper
INFO - 2019-11-09 16:08:03 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:08:03 --> Helper loaded: email_helper
INFO - 2019-11-09 16:08:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:08:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:08:03 --> Parser Class Initialized
INFO - 2019-11-09 16:08:03 --> User Agent Class Initialized
INFO - 2019-11-09 16:08:03 --> Model Class Initialized
INFO - 2019-11-09 16:08:03 --> Database Driver Class Initialized
INFO - 2019-11-09 16:08:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:03 --> Template Class Initialized
INFO - 2019-11-09 16:08:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:08:03 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:08:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:08:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:08:03 --> Encryption Class Initialized
INFO - 2019-11-09 16:08:03 --> Controller Class Initialized
DEBUG - 2019-11-09 16:08:03 --> package MX_Controller Initialized
DEBUG - 2019-11-09 16:08:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 16:08:03 --> Model Class Initialized
INFO - 2019-11-09 16:08:03 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:08:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:08:04 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:08:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:08:04 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:08:04 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 16:08:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 16:08:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:08:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:08:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:08:04 --> Final output sent to browser
DEBUG - 2019-11-09 16:08:04 --> Total execution time: 1.4499
INFO - 2019-11-09 16:08:07 --> Config Class Initialized
INFO - 2019-11-09 16:08:07 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:08:07 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:08:07 --> Utf8 Class Initialized
INFO - 2019-11-09 16:08:07 --> URI Class Initialized
INFO - 2019-11-09 16:08:07 --> Router Class Initialized
INFO - 2019-11-09 16:08:07 --> Output Class Initialized
INFO - 2019-11-09 16:08:07 --> Security Class Initialized
DEBUG - 2019-11-09 16:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:08:07 --> CSRF cookie sent
INFO - 2019-11-09 16:08:07 --> CSRF token verified
INFO - 2019-11-09 16:08:07 --> Input Class Initialized
INFO - 2019-11-09 16:08:07 --> Language Class Initialized
INFO - 2019-11-09 16:08:07 --> Language Class Initialized
INFO - 2019-11-09 16:08:07 --> Config Class Initialized
INFO - 2019-11-09 16:08:07 --> Loader Class Initialized
INFO - 2019-11-09 16:08:07 --> Helper loaded: url_helper
INFO - 2019-11-09 16:08:08 --> Helper loaded: common_helper
INFO - 2019-11-09 16:08:08 --> Helper loaded: language_helper
INFO - 2019-11-09 16:08:08 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:08:08 --> Helper loaded: email_helper
INFO - 2019-11-09 16:08:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:08:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:08:08 --> Parser Class Initialized
INFO - 2019-11-09 16:08:08 --> User Agent Class Initialized
INFO - 2019-11-09 16:08:08 --> Model Class Initialized
INFO - 2019-11-09 16:08:08 --> Database Driver Class Initialized
INFO - 2019-11-09 16:08:08 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:08 --> Template Class Initialized
INFO - 2019-11-09 16:08:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:08:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:08:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:08:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:08:08 --> Encryption Class Initialized
INFO - 2019-11-09 16:08:08 --> Controller Class Initialized
DEBUG - 2019-11-09 16:08:08 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:08:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:08:08 --> Model Class Initialized
INFO - 2019-11-09 16:08:08 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:08:08 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:08:08 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:08:08 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:08:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:08:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:08:08 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:08:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:08:08 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:08:08 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:08:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:08:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:08:08 --> Final output sent to browser
DEBUG - 2019-11-09 16:08:09 --> Total execution time: 1.4063
INFO - 2019-11-09 16:08:16 --> Config Class Initialized
INFO - 2019-11-09 16:08:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:08:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:08:16 --> Utf8 Class Initialized
INFO - 2019-11-09 16:08:17 --> URI Class Initialized
INFO - 2019-11-09 16:08:17 --> Router Class Initialized
INFO - 2019-11-09 16:08:17 --> Output Class Initialized
INFO - 2019-11-09 16:08:17 --> Security Class Initialized
DEBUG - 2019-11-09 16:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:08:17 --> CSRF cookie sent
INFO - 2019-11-09 16:08:17 --> CSRF token verified
INFO - 2019-11-09 16:08:17 --> Input Class Initialized
INFO - 2019-11-09 16:08:17 --> Language Class Initialized
INFO - 2019-11-09 16:08:17 --> Language Class Initialized
INFO - 2019-11-09 16:08:17 --> Config Class Initialized
INFO - 2019-11-09 16:08:17 --> Loader Class Initialized
INFO - 2019-11-09 16:08:17 --> Helper loaded: url_helper
INFO - 2019-11-09 16:08:17 --> Helper loaded: common_helper
INFO - 2019-11-09 16:08:17 --> Helper loaded: language_helper
INFO - 2019-11-09 16:08:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:08:17 --> Helper loaded: email_helper
INFO - 2019-11-09 16:08:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:08:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:08:17 --> Parser Class Initialized
INFO - 2019-11-09 16:08:17 --> User Agent Class Initialized
INFO - 2019-11-09 16:08:17 --> Model Class Initialized
INFO - 2019-11-09 16:08:17 --> Database Driver Class Initialized
INFO - 2019-11-09 16:08:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:17 --> Template Class Initialized
INFO - 2019-11-09 16:08:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:08:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:08:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:08:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:08:17 --> Encryption Class Initialized
INFO - 2019-11-09 16:08:17 --> Controller Class Initialized
DEBUG - 2019-11-09 16:08:17 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:08:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:08:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:17 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 16:08:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-09 16:08:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-09 16:08:19 --> Final output sent to browser
DEBUG - 2019-11-09 16:08:19 --> Total execution time: 2.1471
INFO - 2019-11-09 16:08:26 --> Config Class Initialized
INFO - 2019-11-09 16:08:26 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:08:26 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:08:26 --> Utf8 Class Initialized
INFO - 2019-11-09 16:08:26 --> URI Class Initialized
INFO - 2019-11-09 16:08:26 --> Router Class Initialized
INFO - 2019-11-09 16:08:26 --> Output Class Initialized
INFO - 2019-11-09 16:08:26 --> Security Class Initialized
DEBUG - 2019-11-09 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:08:26 --> Input Class Initialized
INFO - 2019-11-09 16:08:26 --> Language Class Initialized
INFO - 2019-11-09 16:08:26 --> Language Class Initialized
INFO - 2019-11-09 16:08:26 --> Config Class Initialized
INFO - 2019-11-09 16:08:26 --> Loader Class Initialized
INFO - 2019-11-09 16:08:27 --> Helper loaded: url_helper
INFO - 2019-11-09 16:08:27 --> Helper loaded: common_helper
INFO - 2019-11-09 16:08:27 --> Helper loaded: language_helper
INFO - 2019-11-09 16:08:27 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:08:27 --> Helper loaded: email_helper
INFO - 2019-11-09 16:08:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:08:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:08:27 --> Parser Class Initialized
INFO - 2019-11-09 16:08:27 --> User Agent Class Initialized
INFO - 2019-11-09 16:08:27 --> Model Class Initialized
INFO - 2019-11-09 16:08:27 --> Database Driver Class Initialized
INFO - 2019-11-09 16:08:27 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:27 --> Template Class Initialized
INFO - 2019-11-09 16:08:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:08:27 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:08:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:08:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:08:27 --> Encryption Class Initialized
INFO - 2019-11-09 16:08:27 --> Controller Class Initialized
DEBUG - 2019-11-09 16:08:27 --> mollie MX_Controller Initialized
DEBUG - 2019-11-09 16:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-09 16:08:27 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:28 --> orders MX_Controller Initialized
INFO - 2019-11-09 16:08:28 --> Config Class Initialized
INFO - 2019-11-09 16:08:28 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:08:28 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:08:28 --> Utf8 Class Initialized
INFO - 2019-11-09 16:08:28 --> URI Class Initialized
INFO - 2019-11-09 16:08:29 --> Router Class Initialized
INFO - 2019-11-09 16:08:29 --> Output Class Initialized
INFO - 2019-11-09 16:08:29 --> Security Class Initialized
DEBUG - 2019-11-09 16:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:08:29 --> CSRF cookie sent
INFO - 2019-11-09 16:08:29 --> Input Class Initialized
INFO - 2019-11-09 16:08:29 --> Language Class Initialized
INFO - 2019-11-09 16:08:29 --> Language Class Initialized
INFO - 2019-11-09 16:08:29 --> Config Class Initialized
INFO - 2019-11-09 16:08:29 --> Loader Class Initialized
INFO - 2019-11-09 16:08:29 --> Helper loaded: url_helper
INFO - 2019-11-09 16:08:29 --> Helper loaded: common_helper
INFO - 2019-11-09 16:08:29 --> Helper loaded: language_helper
INFO - 2019-11-09 16:08:29 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:08:29 --> Helper loaded: email_helper
INFO - 2019-11-09 16:08:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:08:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:08:29 --> Parser Class Initialized
INFO - 2019-11-09 16:08:29 --> User Agent Class Initialized
INFO - 2019-11-09 16:08:29 --> Model Class Initialized
INFO - 2019-11-09 16:08:29 --> Database Driver Class Initialized
INFO - 2019-11-09 16:08:29 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:29 --> Template Class Initialized
INFO - 2019-11-09 16:08:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:08:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:08:29 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:08:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:08:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:08:29 --> Encryption Class Initialized
INFO - 2019-11-09 16:08:29 --> Controller Class Initialized
DEBUG - 2019-11-09 16:08:29 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:08:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:08:29 --> Model Class Initialized
INFO - 2019-11-09 16:08:29 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:08:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-09 16:08:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:08:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:08:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:08:29 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:08:29 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:08:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:08:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:08:29 --> Final output sent to browser
DEBUG - 2019-11-09 16:08:30 --> Total execution time: 1.0916
INFO - 2019-11-09 16:08:35 --> Config Class Initialized
INFO - 2019-11-09 16:08:35 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:08:35 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:08:35 --> Utf8 Class Initialized
INFO - 2019-11-09 16:08:35 --> URI Class Initialized
INFO - 2019-11-09 16:08:35 --> Router Class Initialized
INFO - 2019-11-09 16:08:35 --> Output Class Initialized
INFO - 2019-11-09 16:08:35 --> Security Class Initialized
DEBUG - 2019-11-09 16:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:08:35 --> CSRF cookie sent
INFO - 2019-11-09 16:08:35 --> Input Class Initialized
INFO - 2019-11-09 16:08:35 --> Language Class Initialized
INFO - 2019-11-09 16:08:35 --> Language Class Initialized
INFO - 2019-11-09 16:08:35 --> Config Class Initialized
INFO - 2019-11-09 16:08:35 --> Loader Class Initialized
INFO - 2019-11-09 16:08:35 --> Helper loaded: url_helper
INFO - 2019-11-09 16:08:35 --> Helper loaded: common_helper
INFO - 2019-11-09 16:08:35 --> Helper loaded: language_helper
INFO - 2019-11-09 16:08:35 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:08:35 --> Helper loaded: email_helper
INFO - 2019-11-09 16:08:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:08:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:08:35 --> Parser Class Initialized
INFO - 2019-11-09 16:08:35 --> User Agent Class Initialized
INFO - 2019-11-09 16:08:35 --> Model Class Initialized
INFO - 2019-11-09 16:08:35 --> Database Driver Class Initialized
INFO - 2019-11-09 16:08:35 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:35 --> Template Class Initialized
INFO - 2019-11-09 16:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:08:35 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:08:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:08:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:08:35 --> Encryption Class Initialized
INFO - 2019-11-09 16:08:35 --> Controller Class Initialized
DEBUG - 2019-11-09 16:08:36 --> transactions MX_Controller Initialized
DEBUG - 2019-11-09 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-09 16:08:36 --> Model Class Initialized
ERROR - 2019-11-09 16:08:36 --> Could not find the language line "order_id"
INFO - 2019-11-09 16:08:36 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-09 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:08:36 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:08:36 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:08:36 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 16:08:36 --> Final output sent to browser
DEBUG - 2019-11-09 16:08:36 --> Total execution time: 1.1231
INFO - 2019-11-09 16:08:39 --> Config Class Initialized
INFO - 2019-11-09 16:08:39 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:08:39 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:08:39 --> Utf8 Class Initialized
INFO - 2019-11-09 16:08:39 --> URI Class Initialized
INFO - 2019-11-09 16:08:39 --> Router Class Initialized
INFO - 2019-11-09 16:08:39 --> Output Class Initialized
INFO - 2019-11-09 16:08:39 --> Security Class Initialized
DEBUG - 2019-11-09 16:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:08:39 --> CSRF cookie sent
INFO - 2019-11-09 16:08:39 --> Input Class Initialized
INFO - 2019-11-09 16:08:39 --> Language Class Initialized
INFO - 2019-11-09 16:08:39 --> Language Class Initialized
INFO - 2019-11-09 16:08:39 --> Config Class Initialized
INFO - 2019-11-09 16:08:39 --> Loader Class Initialized
INFO - 2019-11-09 16:08:39 --> Helper loaded: url_helper
INFO - 2019-11-09 16:08:39 --> Helper loaded: common_helper
INFO - 2019-11-09 16:08:39 --> Helper loaded: language_helper
INFO - 2019-11-09 16:08:39 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:08:39 --> Helper loaded: email_helper
INFO - 2019-11-09 16:08:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:08:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:08:39 --> Parser Class Initialized
INFO - 2019-11-09 16:08:39 --> User Agent Class Initialized
INFO - 2019-11-09 16:08:39 --> Model Class Initialized
INFO - 2019-11-09 16:08:39 --> Database Driver Class Initialized
INFO - 2019-11-09 16:08:39 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:39 --> Template Class Initialized
INFO - 2019-11-09 16:08:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:08:39 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:08:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:08:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:08:40 --> Encryption Class Initialized
INFO - 2019-11-09 16:08:40 --> Controller Class Initialized
DEBUG - 2019-11-09 16:08:40 --> order MX_Controller Initialized
DEBUG - 2019-11-09 16:08:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-09 16:08:40 --> Model Class Initialized
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "order_id"
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "order_id"
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "order_basic_details"
INFO - 2019-11-09 16:08:40 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "Pending"
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "Pending"
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "Pending"
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "Pending"
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 16:08:40 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-09 16:08:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-09 16:08:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:08:40 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:08:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:08:40 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:08:40 --> Model Class Initialized
DEBUG - 2019-11-09 16:08:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 16:08:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 16:08:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 16:08:40 --> Final output sent to browser
DEBUG - 2019-11-09 16:08:40 --> Total execution time: 1.3187
INFO - 2019-11-09 16:10:43 --> Config Class Initialized
INFO - 2019-11-09 16:10:43 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:10:43 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:10:43 --> Utf8 Class Initialized
INFO - 2019-11-09 16:10:43 --> URI Class Initialized
INFO - 2019-11-09 16:10:43 --> Router Class Initialized
INFO - 2019-11-09 16:10:43 --> Output Class Initialized
INFO - 2019-11-09 16:10:43 --> Security Class Initialized
DEBUG - 2019-11-09 16:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:10:43 --> CSRF cookie sent
INFO - 2019-11-09 16:10:44 --> Input Class Initialized
INFO - 2019-11-09 16:10:44 --> Language Class Initialized
INFO - 2019-11-09 16:10:44 --> Language Class Initialized
INFO - 2019-11-09 16:10:44 --> Config Class Initialized
INFO - 2019-11-09 16:10:44 --> Loader Class Initialized
INFO - 2019-11-09 16:10:44 --> Helper loaded: url_helper
INFO - 2019-11-09 16:10:44 --> Helper loaded: common_helper
INFO - 2019-11-09 16:10:44 --> Helper loaded: language_helper
INFO - 2019-11-09 16:10:44 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:10:44 --> Helper loaded: email_helper
INFO - 2019-11-09 16:10:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:10:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:10:44 --> Parser Class Initialized
INFO - 2019-11-09 16:10:44 --> User Agent Class Initialized
INFO - 2019-11-09 16:10:44 --> Model Class Initialized
INFO - 2019-11-09 16:10:44 --> Database Driver Class Initialized
INFO - 2019-11-09 16:10:44 --> Model Class Initialized
DEBUG - 2019-11-09 16:10:44 --> Template Class Initialized
INFO - 2019-11-09 16:10:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:10:44 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:10:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:10:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:10:44 --> Encryption Class Initialized
INFO - 2019-11-09 16:10:44 --> Controller Class Initialized
DEBUG - 2019-11-09 16:10:44 --> package MX_Controller Initialized
DEBUG - 2019-11-09 16:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 16:10:44 --> Model Class Initialized
INFO - 2019-11-09 16:10:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:10:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:10:44 --> Model Class Initialized
DEBUG - 2019-11-09 16:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:10:44 --> Model Class Initialized
DEBUG - 2019-11-09 16:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 16:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 16:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:10:44 --> Final output sent to browser
DEBUG - 2019-11-09 16:10:44 --> Total execution time: 1.1278
INFO - 2019-11-09 16:10:49 --> Config Class Initialized
INFO - 2019-11-09 16:10:49 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:10:49 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:10:49 --> Utf8 Class Initialized
INFO - 2019-11-09 16:10:49 --> URI Class Initialized
INFO - 2019-11-09 16:10:49 --> Router Class Initialized
INFO - 2019-11-09 16:10:49 --> Output Class Initialized
INFO - 2019-11-09 16:10:49 --> Security Class Initialized
DEBUG - 2019-11-09 16:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:10:49 --> CSRF cookie sent
INFO - 2019-11-09 16:10:49 --> CSRF token verified
INFO - 2019-11-09 16:10:49 --> Input Class Initialized
INFO - 2019-11-09 16:10:49 --> Language Class Initialized
INFO - 2019-11-09 16:10:49 --> Language Class Initialized
INFO - 2019-11-09 16:10:49 --> Config Class Initialized
INFO - 2019-11-09 16:10:49 --> Loader Class Initialized
INFO - 2019-11-09 16:10:49 --> Helper loaded: url_helper
INFO - 2019-11-09 16:10:49 --> Helper loaded: common_helper
INFO - 2019-11-09 16:10:49 --> Helper loaded: language_helper
INFO - 2019-11-09 16:10:49 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:10:49 --> Helper loaded: email_helper
INFO - 2019-11-09 16:10:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:10:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:10:49 --> Parser Class Initialized
INFO - 2019-11-09 16:10:49 --> User Agent Class Initialized
INFO - 2019-11-09 16:10:49 --> Model Class Initialized
INFO - 2019-11-09 16:10:49 --> Database Driver Class Initialized
INFO - 2019-11-09 16:10:49 --> Model Class Initialized
DEBUG - 2019-11-09 16:10:49 --> Template Class Initialized
INFO - 2019-11-09 16:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:10:49 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:10:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:10:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:10:49 --> Encryption Class Initialized
INFO - 2019-11-09 16:10:49 --> Controller Class Initialized
DEBUG - 2019-11-09 16:10:49 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:10:49 --> Model Class Initialized
INFO - 2019-11-09 16:10:50 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:10:50 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:10:50 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:10:50 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:10:50 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:10:50 --> Model Class Initialized
DEBUG - 2019-11-09 16:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:10:50 --> Model Class Initialized
DEBUG - 2019-11-09 16:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:10:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:10:50 --> Final output sent to browser
DEBUG - 2019-11-09 16:10:50 --> Total execution time: 1.3086
INFO - 2019-11-09 16:10:59 --> Config Class Initialized
INFO - 2019-11-09 16:10:59 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:10:59 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:10:59 --> Utf8 Class Initialized
INFO - 2019-11-09 16:10:59 --> URI Class Initialized
INFO - 2019-11-09 16:10:59 --> Router Class Initialized
INFO - 2019-11-09 16:10:59 --> Output Class Initialized
INFO - 2019-11-09 16:10:59 --> Security Class Initialized
DEBUG - 2019-11-09 16:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:10:59 --> CSRF cookie sent
INFO - 2019-11-09 16:10:59 --> CSRF token verified
INFO - 2019-11-09 16:10:59 --> Input Class Initialized
INFO - 2019-11-09 16:10:59 --> Language Class Initialized
INFO - 2019-11-09 16:10:59 --> Language Class Initialized
INFO - 2019-11-09 16:10:59 --> Config Class Initialized
INFO - 2019-11-09 16:10:59 --> Loader Class Initialized
INFO - 2019-11-09 16:10:59 --> Helper loaded: url_helper
INFO - 2019-11-09 16:10:59 --> Helper loaded: common_helper
INFO - 2019-11-09 16:10:59 --> Helper loaded: language_helper
INFO - 2019-11-09 16:10:59 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:10:59 --> Helper loaded: email_helper
INFO - 2019-11-09 16:10:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:10:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:10:59 --> Parser Class Initialized
INFO - 2019-11-09 16:10:59 --> User Agent Class Initialized
INFO - 2019-11-09 16:10:59 --> Model Class Initialized
INFO - 2019-11-09 16:10:59 --> Database Driver Class Initialized
INFO - 2019-11-09 16:10:59 --> Model Class Initialized
DEBUG - 2019-11-09 16:10:59 --> Template Class Initialized
INFO - 2019-11-09 16:10:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:10:59 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:10:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:10:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:10:59 --> Encryption Class Initialized
INFO - 2019-11-09 16:10:59 --> Controller Class Initialized
DEBUG - 2019-11-09 16:10:59 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:10:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:10:59 --> Model Class Initialized
DEBUG - 2019-11-09 16:10:59 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 16:10:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
DEBUG - 2019-11-09 16:11:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paypal/index.php
INFO - 2019-11-09 16:11:13 --> Final output sent to browser
DEBUG - 2019-11-09 16:11:13 --> Total execution time: 14.2099
INFO - 2019-11-09 16:16:02 --> Config Class Initialized
INFO - 2019-11-09 16:16:03 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:16:03 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:16:03 --> Utf8 Class Initialized
INFO - 2019-11-09 16:16:03 --> URI Class Initialized
INFO - 2019-11-09 16:16:03 --> Router Class Initialized
INFO - 2019-11-09 16:16:03 --> Output Class Initialized
INFO - 2019-11-09 16:16:03 --> Security Class Initialized
DEBUG - 2019-11-09 16:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:16:03 --> Input Class Initialized
INFO - 2019-11-09 16:16:03 --> Language Class Initialized
INFO - 2019-11-09 16:16:03 --> Language Class Initialized
INFO - 2019-11-09 16:16:03 --> Config Class Initialized
INFO - 2019-11-09 16:16:03 --> Loader Class Initialized
INFO - 2019-11-09 16:16:03 --> Helper loaded: url_helper
INFO - 2019-11-09 16:16:03 --> Helper loaded: common_helper
INFO - 2019-11-09 16:16:03 --> Helper loaded: language_helper
INFO - 2019-11-09 16:16:03 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:16:03 --> Helper loaded: email_helper
INFO - 2019-11-09 16:16:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:16:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:16:03 --> Parser Class Initialized
INFO - 2019-11-09 16:16:03 --> User Agent Class Initialized
INFO - 2019-11-09 16:16:03 --> Model Class Initialized
INFO - 2019-11-09 16:16:03 --> Database Driver Class Initialized
INFO - 2019-11-09 16:16:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:16:03 --> Template Class Initialized
INFO - 2019-11-09 16:16:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:16:03 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:16:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:16:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:16:03 --> Encryption Class Initialized
INFO - 2019-11-09 16:16:03 --> Controller Class Initialized
DEBUG - 2019-11-09 16:16:03 --> paypal MX_Controller Initialized
DEBUG - 2019-11-09 16:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
INFO - 2019-11-09 16:16:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:16:17 --> orders MX_Controller Initialized
INFO - 2019-11-09 16:16:17 --> Config Class Initialized
INFO - 2019-11-09 16:16:17 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:16:17 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:16:17 --> Utf8 Class Initialized
INFO - 2019-11-09 16:16:17 --> URI Class Initialized
INFO - 2019-11-09 16:16:17 --> Router Class Initialized
INFO - 2019-11-09 16:16:17 --> Output Class Initialized
INFO - 2019-11-09 16:16:17 --> Security Class Initialized
DEBUG - 2019-11-09 16:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:16:17 --> CSRF cookie sent
INFO - 2019-11-09 16:16:17 --> Input Class Initialized
INFO - 2019-11-09 16:16:17 --> Language Class Initialized
INFO - 2019-11-09 16:16:17 --> Language Class Initialized
INFO - 2019-11-09 16:16:18 --> Config Class Initialized
INFO - 2019-11-09 16:16:18 --> Loader Class Initialized
INFO - 2019-11-09 16:16:18 --> Helper loaded: url_helper
INFO - 2019-11-09 16:16:18 --> Helper loaded: common_helper
INFO - 2019-11-09 16:16:18 --> Helper loaded: language_helper
INFO - 2019-11-09 16:16:18 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:16:18 --> Helper loaded: email_helper
INFO - 2019-11-09 16:16:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:16:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:16:18 --> Parser Class Initialized
INFO - 2019-11-09 16:16:18 --> User Agent Class Initialized
INFO - 2019-11-09 16:16:18 --> Model Class Initialized
INFO - 2019-11-09 16:16:18 --> Database Driver Class Initialized
INFO - 2019-11-09 16:16:18 --> Model Class Initialized
DEBUG - 2019-11-09 16:16:18 --> Template Class Initialized
INFO - 2019-11-09 16:16:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:16:18 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:16:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:16:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:16:18 --> Encryption Class Initialized
INFO - 2019-11-09 16:16:18 --> Controller Class Initialized
DEBUG - 2019-11-09 16:16:18 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:16:18 --> Model Class Initialized
INFO - 2019-11-09 16:16:18 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-09 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:16:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:16:18 --> Model Class Initialized
DEBUG - 2019-11-09 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:16:18 --> Model Class Initialized
DEBUG - 2019-11-09 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:16:18 --> Final output sent to browser
DEBUG - 2019-11-09 16:16:18 --> Total execution time: 1.0342
INFO - 2019-11-09 16:16:48 --> Config Class Initialized
INFO - 2019-11-09 16:16:48 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:16:48 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:16:48 --> Utf8 Class Initialized
INFO - 2019-11-09 16:16:48 --> URI Class Initialized
INFO - 2019-11-09 16:16:48 --> Router Class Initialized
INFO - 2019-11-09 16:16:48 --> Output Class Initialized
INFO - 2019-11-09 16:16:48 --> Security Class Initialized
DEBUG - 2019-11-09 16:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:16:48 --> CSRF cookie sent
INFO - 2019-11-09 16:16:48 --> Input Class Initialized
INFO - 2019-11-09 16:16:48 --> Language Class Initialized
INFO - 2019-11-09 16:16:48 --> Language Class Initialized
INFO - 2019-11-09 16:16:48 --> Config Class Initialized
INFO - 2019-11-09 16:16:48 --> Loader Class Initialized
INFO - 2019-11-09 16:16:48 --> Helper loaded: url_helper
INFO - 2019-11-09 16:16:48 --> Helper loaded: common_helper
INFO - 2019-11-09 16:16:48 --> Helper loaded: language_helper
INFO - 2019-11-09 16:16:48 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:16:48 --> Helper loaded: email_helper
INFO - 2019-11-09 16:16:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:16:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:16:48 --> Parser Class Initialized
INFO - 2019-11-09 16:16:48 --> User Agent Class Initialized
INFO - 2019-11-09 16:16:48 --> Model Class Initialized
INFO - 2019-11-09 16:16:48 --> Database Driver Class Initialized
INFO - 2019-11-09 16:16:48 --> Model Class Initialized
DEBUG - 2019-11-09 16:16:48 --> Template Class Initialized
INFO - 2019-11-09 16:16:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:16:48 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:16:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:16:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:16:48 --> Encryption Class Initialized
INFO - 2019-11-09 16:16:48 --> Controller Class Initialized
DEBUG - 2019-11-09 16:16:48 --> package MX_Controller Initialized
DEBUG - 2019-11-09 16:16:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 16:16:49 --> Model Class Initialized
INFO - 2019-11-09 16:16:49 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:16:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:16:49 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:16:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:16:49 --> Model Class Initialized
DEBUG - 2019-11-09 16:16:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:16:49 --> Model Class Initialized
DEBUG - 2019-11-09 16:16:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 16:16:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 16:16:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:16:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:16:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:16:49 --> Final output sent to browser
DEBUG - 2019-11-09 16:16:49 --> Total execution time: 1.0029
INFO - 2019-11-09 16:25:16 --> Config Class Initialized
INFO - 2019-11-09 16:25:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:25:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:25:16 --> Utf8 Class Initialized
INFO - 2019-11-09 16:25:16 --> URI Class Initialized
INFO - 2019-11-09 16:25:16 --> Router Class Initialized
INFO - 2019-11-09 16:25:16 --> Output Class Initialized
INFO - 2019-11-09 16:25:16 --> Security Class Initialized
DEBUG - 2019-11-09 16:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:25:16 --> CSRF cookie sent
INFO - 2019-11-09 16:25:16 --> CSRF token verified
INFO - 2019-11-09 16:25:17 --> Input Class Initialized
INFO - 2019-11-09 16:25:17 --> Language Class Initialized
INFO - 2019-11-09 16:25:17 --> Language Class Initialized
INFO - 2019-11-09 16:25:17 --> Config Class Initialized
INFO - 2019-11-09 16:25:17 --> Loader Class Initialized
INFO - 2019-11-09 16:25:17 --> Helper loaded: url_helper
INFO - 2019-11-09 16:25:17 --> Helper loaded: common_helper
INFO - 2019-11-09 16:25:17 --> Helper loaded: language_helper
INFO - 2019-11-09 16:25:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:25:17 --> Helper loaded: email_helper
INFO - 2019-11-09 16:25:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:25:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:25:17 --> Parser Class Initialized
INFO - 2019-11-09 16:25:17 --> User Agent Class Initialized
INFO - 2019-11-09 16:25:17 --> Model Class Initialized
INFO - 2019-11-09 16:25:17 --> Database Driver Class Initialized
INFO - 2019-11-09 16:25:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:25:17 --> Template Class Initialized
INFO - 2019-11-09 16:25:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:25:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:25:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:25:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:25:17 --> Encryption Class Initialized
INFO - 2019-11-09 16:25:17 --> Controller Class Initialized
DEBUG - 2019-11-09 16:25:17 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:25:17 --> Model Class Initialized
INFO - 2019-11-09 16:25:17 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:25:17 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:25:17 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:25:17 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:25:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:25:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:25:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:25:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:25:17 --> Final output sent to browser
DEBUG - 2019-11-09 16:25:17 --> Total execution time: 1.1511
INFO - 2019-11-09 16:25:24 --> Config Class Initialized
INFO - 2019-11-09 16:25:24 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:25:24 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:25:24 --> Utf8 Class Initialized
INFO - 2019-11-09 16:25:24 --> URI Class Initialized
INFO - 2019-11-09 16:25:24 --> Router Class Initialized
INFO - 2019-11-09 16:25:24 --> Output Class Initialized
INFO - 2019-11-09 16:25:24 --> Security Class Initialized
DEBUG - 2019-11-09 16:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:25:24 --> CSRF cookie sent
INFO - 2019-11-09 16:25:24 --> CSRF token verified
INFO - 2019-11-09 16:25:24 --> Input Class Initialized
INFO - 2019-11-09 16:25:24 --> Language Class Initialized
INFO - 2019-11-09 16:25:24 --> Language Class Initialized
INFO - 2019-11-09 16:25:24 --> Config Class Initialized
INFO - 2019-11-09 16:25:24 --> Loader Class Initialized
INFO - 2019-11-09 16:25:24 --> Helper loaded: url_helper
INFO - 2019-11-09 16:25:24 --> Helper loaded: common_helper
INFO - 2019-11-09 16:25:24 --> Helper loaded: language_helper
INFO - 2019-11-09 16:25:24 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:25:24 --> Helper loaded: email_helper
INFO - 2019-11-09 16:25:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:25:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:25:24 --> Parser Class Initialized
INFO - 2019-11-09 16:25:24 --> User Agent Class Initialized
INFO - 2019-11-09 16:25:24 --> Model Class Initialized
INFO - 2019-11-09 16:25:24 --> Database Driver Class Initialized
INFO - 2019-11-09 16:25:24 --> Model Class Initialized
DEBUG - 2019-11-09 16:25:24 --> Template Class Initialized
INFO - 2019-11-09 16:25:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:25:24 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:25:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:25:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:25:24 --> Encryption Class Initialized
INFO - 2019-11-09 16:25:24 --> Controller Class Initialized
DEBUG - 2019-11-09 16:25:24 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:25:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:25:24 --> Model Class Initialized
ERROR - 2019-11-09 16:25:24 --> Severity: error --> Exception: syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\coinpayments.php 38
INFO - 2019-11-09 16:25:32 --> Config Class Initialized
INFO - 2019-11-09 16:25:32 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:25:32 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:25:32 --> Utf8 Class Initialized
INFO - 2019-11-09 16:25:33 --> URI Class Initialized
INFO - 2019-11-09 16:25:33 --> Router Class Initialized
INFO - 2019-11-09 16:25:33 --> Output Class Initialized
INFO - 2019-11-09 16:25:33 --> Security Class Initialized
DEBUG - 2019-11-09 16:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:25:33 --> CSRF cookie sent
INFO - 2019-11-09 16:25:33 --> CSRF token verified
INFO - 2019-11-09 16:25:33 --> Input Class Initialized
INFO - 2019-11-09 16:25:33 --> Language Class Initialized
INFO - 2019-11-09 16:25:33 --> Language Class Initialized
INFO - 2019-11-09 16:25:33 --> Config Class Initialized
INFO - 2019-11-09 16:25:33 --> Loader Class Initialized
INFO - 2019-11-09 16:25:33 --> Helper loaded: url_helper
INFO - 2019-11-09 16:25:33 --> Helper loaded: common_helper
INFO - 2019-11-09 16:25:33 --> Helper loaded: language_helper
INFO - 2019-11-09 16:25:33 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:25:33 --> Helper loaded: email_helper
INFO - 2019-11-09 16:25:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:25:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:25:33 --> Parser Class Initialized
INFO - 2019-11-09 16:25:33 --> User Agent Class Initialized
INFO - 2019-11-09 16:25:33 --> Model Class Initialized
INFO - 2019-11-09 16:25:33 --> Database Driver Class Initialized
INFO - 2019-11-09 16:25:33 --> Model Class Initialized
DEBUG - 2019-11-09 16:25:33 --> Template Class Initialized
INFO - 2019-11-09 16:25:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:25:33 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:25:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:25:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:25:33 --> Encryption Class Initialized
INFO - 2019-11-09 16:25:33 --> Controller Class Initialized
DEBUG - 2019-11-09 16:25:33 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:25:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:25:33 --> Model Class Initialized
INFO - 2019-11-09 16:25:33 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:25:33 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:25:33 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:25:33 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:25:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:25:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:25:33 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:25:34 --> Model Class Initialized
DEBUG - 2019-11-09 16:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:25:34 --> Model Class Initialized
DEBUG - 2019-11-09 16:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:25:34 --> Final output sent to browser
DEBUG - 2019-11-09 16:25:34 --> Total execution time: 1.2535
INFO - 2019-11-09 16:25:41 --> Config Class Initialized
INFO - 2019-11-09 16:25:41 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:25:41 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:25:41 --> Utf8 Class Initialized
INFO - 2019-11-09 16:25:41 --> URI Class Initialized
INFO - 2019-11-09 16:25:41 --> Router Class Initialized
INFO - 2019-11-09 16:25:41 --> Output Class Initialized
INFO - 2019-11-09 16:25:41 --> Security Class Initialized
DEBUG - 2019-11-09 16:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:25:41 --> CSRF cookie sent
INFO - 2019-11-09 16:25:41 --> CSRF token verified
INFO - 2019-11-09 16:25:41 --> Input Class Initialized
INFO - 2019-11-09 16:25:41 --> Language Class Initialized
INFO - 2019-11-09 16:25:41 --> Language Class Initialized
INFO - 2019-11-09 16:25:41 --> Config Class Initialized
INFO - 2019-11-09 16:25:41 --> Loader Class Initialized
INFO - 2019-11-09 16:25:41 --> Helper loaded: url_helper
INFO - 2019-11-09 16:25:41 --> Helper loaded: common_helper
INFO - 2019-11-09 16:25:41 --> Helper loaded: language_helper
INFO - 2019-11-09 16:25:41 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:25:41 --> Helper loaded: email_helper
INFO - 2019-11-09 16:25:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:25:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:25:41 --> Parser Class Initialized
INFO - 2019-11-09 16:25:41 --> User Agent Class Initialized
INFO - 2019-11-09 16:25:41 --> Model Class Initialized
INFO - 2019-11-09 16:25:41 --> Database Driver Class Initialized
INFO - 2019-11-09 16:25:41 --> Model Class Initialized
DEBUG - 2019-11-09 16:25:41 --> Template Class Initialized
INFO - 2019-11-09 16:25:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:25:41 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:25:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:25:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:25:41 --> Encryption Class Initialized
INFO - 2019-11-09 16:25:41 --> Controller Class Initialized
DEBUG - 2019-11-09 16:25:41 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:25:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:25:41 --> Model Class Initialized
ERROR - 2019-11-09 16:25:42 --> Severity: error --> Exception: syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\coinpayments.php 38
INFO - 2019-11-09 16:26:25 --> Config Class Initialized
INFO - 2019-11-09 16:26:25 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:26:25 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:26:25 --> Utf8 Class Initialized
INFO - 2019-11-09 16:26:25 --> URI Class Initialized
INFO - 2019-11-09 16:26:25 --> Router Class Initialized
INFO - 2019-11-09 16:26:25 --> Output Class Initialized
INFO - 2019-11-09 16:26:25 --> Security Class Initialized
DEBUG - 2019-11-09 16:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:26:26 --> CSRF cookie sent
INFO - 2019-11-09 16:26:26 --> CSRF token verified
INFO - 2019-11-09 16:26:26 --> Input Class Initialized
INFO - 2019-11-09 16:26:26 --> Language Class Initialized
INFO - 2019-11-09 16:26:26 --> Language Class Initialized
INFO - 2019-11-09 16:26:26 --> Config Class Initialized
INFO - 2019-11-09 16:26:26 --> Loader Class Initialized
INFO - 2019-11-09 16:26:26 --> Helper loaded: url_helper
INFO - 2019-11-09 16:26:26 --> Helper loaded: common_helper
INFO - 2019-11-09 16:26:26 --> Helper loaded: language_helper
INFO - 2019-11-09 16:26:26 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:26:26 --> Helper loaded: email_helper
INFO - 2019-11-09 16:26:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:26:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:26:26 --> Parser Class Initialized
INFO - 2019-11-09 16:26:26 --> User Agent Class Initialized
INFO - 2019-11-09 16:26:26 --> Model Class Initialized
INFO - 2019-11-09 16:26:26 --> Database Driver Class Initialized
INFO - 2019-11-09 16:26:26 --> Model Class Initialized
DEBUG - 2019-11-09 16:26:26 --> Template Class Initialized
INFO - 2019-11-09 16:26:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:26:26 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:26:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:26:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:26:26 --> Encryption Class Initialized
INFO - 2019-11-09 16:26:26 --> Controller Class Initialized
DEBUG - 2019-11-09 16:26:26 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:26:26 --> Model Class Initialized
INFO - 2019-11-09 16:26:26 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:26:26 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:26:26 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:26:26 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:26:26 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:26:26 --> Model Class Initialized
DEBUG - 2019-11-09 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:26:26 --> Model Class Initialized
DEBUG - 2019-11-09 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:26:27 --> Final output sent to browser
DEBUG - 2019-11-09 16:26:27 --> Total execution time: 1.2022
INFO - 2019-11-09 16:26:34 --> Config Class Initialized
INFO - 2019-11-09 16:26:34 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:26:34 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:26:34 --> Utf8 Class Initialized
INFO - 2019-11-09 16:26:34 --> URI Class Initialized
INFO - 2019-11-09 16:26:34 --> Router Class Initialized
INFO - 2019-11-09 16:26:34 --> Output Class Initialized
INFO - 2019-11-09 16:26:34 --> Security Class Initialized
DEBUG - 2019-11-09 16:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:26:34 --> CSRF cookie sent
INFO - 2019-11-09 16:26:34 --> CSRF token verified
INFO - 2019-11-09 16:26:34 --> Input Class Initialized
INFO - 2019-11-09 16:26:34 --> Language Class Initialized
INFO - 2019-11-09 16:26:34 --> Language Class Initialized
INFO - 2019-11-09 16:26:35 --> Config Class Initialized
INFO - 2019-11-09 16:26:35 --> Loader Class Initialized
INFO - 2019-11-09 16:26:35 --> Helper loaded: url_helper
INFO - 2019-11-09 16:26:35 --> Helper loaded: common_helper
INFO - 2019-11-09 16:26:35 --> Helper loaded: language_helper
INFO - 2019-11-09 16:26:35 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:26:35 --> Helper loaded: email_helper
INFO - 2019-11-09 16:26:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:26:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:26:35 --> Parser Class Initialized
INFO - 2019-11-09 16:26:35 --> User Agent Class Initialized
INFO - 2019-11-09 16:26:35 --> Model Class Initialized
INFO - 2019-11-09 16:26:35 --> Database Driver Class Initialized
INFO - 2019-11-09 16:26:35 --> Model Class Initialized
DEBUG - 2019-11-09 16:26:35 --> Template Class Initialized
INFO - 2019-11-09 16:26:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:26:35 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:26:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:26:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:26:35 --> Encryption Class Initialized
INFO - 2019-11-09 16:26:35 --> Controller Class Initialized
DEBUG - 2019-11-09 16:26:35 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:26:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:26:35 --> Model Class Initialized
DEBUG - 2019-11-09 16:26:35 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:26:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
ERROR - 2019-11-09 16:26:35 --> Could not find the language line "choose_your_coin"
DEBUG - 2019-11-09 16:26:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinpayments/index.php
INFO - 2019-11-09 16:26:35 --> Final output sent to browser
DEBUG - 2019-11-09 16:26:35 --> Total execution time: 1.0244
INFO - 2019-11-09 16:26:45 --> Config Class Initialized
INFO - 2019-11-09 16:26:45 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:26:45 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:26:45 --> Utf8 Class Initialized
INFO - 2019-11-09 16:26:45 --> URI Class Initialized
INFO - 2019-11-09 16:26:46 --> Router Class Initialized
INFO - 2019-11-09 16:26:46 --> Output Class Initialized
INFO - 2019-11-09 16:26:46 --> Security Class Initialized
DEBUG - 2019-11-09 16:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:26:46 --> Input Class Initialized
INFO - 2019-11-09 16:26:46 --> Language Class Initialized
INFO - 2019-11-09 16:26:46 --> Language Class Initialized
INFO - 2019-11-09 16:26:46 --> Config Class Initialized
INFO - 2019-11-09 16:26:46 --> Loader Class Initialized
INFO - 2019-11-09 16:26:46 --> Helper loaded: url_helper
INFO - 2019-11-09 16:26:46 --> Helper loaded: common_helper
INFO - 2019-11-09 16:26:46 --> Helper loaded: language_helper
INFO - 2019-11-09 16:26:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:26:46 --> Helper loaded: email_helper
INFO - 2019-11-09 16:26:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:26:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:26:46 --> Parser Class Initialized
INFO - 2019-11-09 16:26:46 --> User Agent Class Initialized
INFO - 2019-11-09 16:26:46 --> Model Class Initialized
INFO - 2019-11-09 16:26:46 --> Database Driver Class Initialized
INFO - 2019-11-09 16:26:46 --> Model Class Initialized
DEBUG - 2019-11-09 16:26:46 --> Template Class Initialized
INFO - 2019-11-09 16:26:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:26:46 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:26:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:26:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:26:46 --> Encryption Class Initialized
INFO - 2019-11-09 16:26:46 --> Controller Class Initialized
DEBUG - 2019-11-09 16:26:46 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:26:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
INFO - 2019-11-09 16:26:46 --> Model Class Initialized
DEBUG - 2019-11-09 16:26:49 --> orders MX_Controller Initialized
INFO - 2019-11-09 16:29:04 --> Config Class Initialized
INFO - 2019-11-09 16:29:04 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:29:04 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:29:04 --> Utf8 Class Initialized
INFO - 2019-11-09 16:29:04 --> URI Class Initialized
INFO - 2019-11-09 16:29:04 --> Router Class Initialized
INFO - 2019-11-09 16:29:04 --> Output Class Initialized
INFO - 2019-11-09 16:29:04 --> Security Class Initialized
DEBUG - 2019-11-09 16:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:29:04 --> CSRF cookie sent
INFO - 2019-11-09 16:29:04 --> CSRF token verified
INFO - 2019-11-09 16:29:04 --> Input Class Initialized
INFO - 2019-11-09 16:29:04 --> Language Class Initialized
INFO - 2019-11-09 16:29:04 --> Language Class Initialized
INFO - 2019-11-09 16:29:04 --> Config Class Initialized
INFO - 2019-11-09 16:29:04 --> Loader Class Initialized
INFO - 2019-11-09 16:29:04 --> Helper loaded: url_helper
INFO - 2019-11-09 16:29:04 --> Helper loaded: common_helper
INFO - 2019-11-09 16:29:04 --> Helper loaded: language_helper
INFO - 2019-11-09 16:29:04 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:29:04 --> Helper loaded: email_helper
INFO - 2019-11-09 16:29:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:29:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:29:04 --> Parser Class Initialized
INFO - 2019-11-09 16:29:04 --> User Agent Class Initialized
INFO - 2019-11-09 16:29:04 --> Model Class Initialized
INFO - 2019-11-09 16:29:04 --> Database Driver Class Initialized
INFO - 2019-11-09 16:29:04 --> Model Class Initialized
DEBUG - 2019-11-09 16:29:04 --> Template Class Initialized
INFO - 2019-11-09 16:29:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:29:04 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:29:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:29:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:29:04 --> Encryption Class Initialized
INFO - 2019-11-09 16:29:05 --> Controller Class Initialized
DEBUG - 2019-11-09 16:29:05 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:29:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:29:05 --> Model Class Initialized
DEBUG - 2019-11-09 16:29:05 --> coinbase MX_Controller Initialized
DEBUG - 2019-11-09 16:29:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinbase_api.php
DEBUG - 2019-11-09 16:29:06 --> orders MX_Controller Initialized
DEBUG - 2019-11-09 16:29:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinbase/index.php
INFO - 2019-11-09 16:29:06 --> Final output sent to browser
DEBUG - 2019-11-09 16:29:06 --> Total execution time: 2.5852
INFO - 2019-11-09 16:29:24 --> Config Class Initialized
INFO - 2019-11-09 16:29:24 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:29:24 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:29:24 --> Utf8 Class Initialized
INFO - 2019-11-09 16:29:24 --> URI Class Initialized
INFO - 2019-11-09 16:29:24 --> Router Class Initialized
INFO - 2019-11-09 16:29:24 --> Output Class Initialized
INFO - 2019-11-09 16:29:24 --> Security Class Initialized
DEBUG - 2019-11-09 16:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:29:24 --> CSRF cookie sent
INFO - 2019-11-09 16:29:24 --> CSRF token verified
INFO - 2019-11-09 16:29:24 --> Input Class Initialized
INFO - 2019-11-09 16:29:24 --> Language Class Initialized
INFO - 2019-11-09 16:29:24 --> Language Class Initialized
INFO - 2019-11-09 16:29:24 --> Config Class Initialized
INFO - 2019-11-09 16:29:24 --> Loader Class Initialized
INFO - 2019-11-09 16:29:24 --> Helper loaded: url_helper
INFO - 2019-11-09 16:29:24 --> Helper loaded: common_helper
INFO - 2019-11-09 16:29:24 --> Helper loaded: language_helper
INFO - 2019-11-09 16:29:24 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:29:24 --> Helper loaded: email_helper
INFO - 2019-11-09 16:29:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:29:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:29:24 --> Parser Class Initialized
INFO - 2019-11-09 16:29:25 --> User Agent Class Initialized
INFO - 2019-11-09 16:29:25 --> Model Class Initialized
INFO - 2019-11-09 16:29:25 --> Database Driver Class Initialized
INFO - 2019-11-09 16:29:25 --> Model Class Initialized
DEBUG - 2019-11-09 16:29:25 --> Template Class Initialized
INFO - 2019-11-09 16:29:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:29:25 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:29:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:29:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:29:25 --> Encryption Class Initialized
INFO - 2019-11-09 16:29:25 --> Controller Class Initialized
DEBUG - 2019-11-09 16:29:25 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:29:25 --> Model Class Initialized
DEBUG - 2019-11-09 16:29:25 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
ERROR - 2019-11-09 16:29:25 --> Could not find the language line "choose_your_coin"
DEBUG - 2019-11-09 16:29:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinpayments/index.php
INFO - 2019-11-09 16:29:25 --> Final output sent to browser
DEBUG - 2019-11-09 16:29:25 --> Total execution time: 0.8765
INFO - 2019-11-09 16:34:10 --> Config Class Initialized
INFO - 2019-11-09 16:34:10 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:34:10 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:34:10 --> Utf8 Class Initialized
INFO - 2019-11-09 16:34:10 --> URI Class Initialized
INFO - 2019-11-09 16:34:10 --> Router Class Initialized
INFO - 2019-11-09 16:34:10 --> Output Class Initialized
INFO - 2019-11-09 16:34:10 --> Security Class Initialized
DEBUG - 2019-11-09 16:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:34:11 --> CSRF cookie sent
INFO - 2019-11-09 16:34:11 --> Input Class Initialized
INFO - 2019-11-09 16:34:11 --> Language Class Initialized
INFO - 2019-11-09 16:34:11 --> Language Class Initialized
INFO - 2019-11-09 16:34:11 --> Config Class Initialized
INFO - 2019-11-09 16:34:11 --> Loader Class Initialized
INFO - 2019-11-09 16:34:11 --> Helper loaded: url_helper
INFO - 2019-11-09 16:34:11 --> Helper loaded: common_helper
INFO - 2019-11-09 16:34:11 --> Helper loaded: language_helper
INFO - 2019-11-09 16:34:11 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:34:11 --> Helper loaded: email_helper
INFO - 2019-11-09 16:34:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:34:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:34:11 --> Parser Class Initialized
INFO - 2019-11-09 16:34:11 --> User Agent Class Initialized
INFO - 2019-11-09 16:34:11 --> Model Class Initialized
INFO - 2019-11-09 16:34:11 --> Database Driver Class Initialized
INFO - 2019-11-09 16:34:11 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:11 --> Template Class Initialized
INFO - 2019-11-09 16:34:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:34:11 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:34:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:34:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:34:11 --> Encryption Class Initialized
INFO - 2019-11-09 16:34:11 --> Controller Class Initialized
DEBUG - 2019-11-09 16:34:11 --> order MX_Controller Initialized
DEBUG - 2019-11-09 16:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-09 16:34:11 --> Model Class Initialized
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "order_id"
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "order_id"
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "order_basic_details"
INFO - 2019-11-09 16:34:11 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "Pending"
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "Pending"
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "Pending"
ERROR - 2019-11-09 16:34:11 --> Could not find the language line "Pending"
DEBUG - 2019-11-09 16:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-09 16:34:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:34:11 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:34:12 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:34:12 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 16:34:12 --> Final output sent to browser
DEBUG - 2019-11-09 16:34:12 --> Total execution time: 1.3550
INFO - 2019-11-09 16:34:17 --> Config Class Initialized
INFO - 2019-11-09 16:34:17 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:34:17 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:34:17 --> Utf8 Class Initialized
INFO - 2019-11-09 16:34:17 --> URI Class Initialized
INFO - 2019-11-09 16:34:17 --> Router Class Initialized
INFO - 2019-11-09 16:34:17 --> Output Class Initialized
INFO - 2019-11-09 16:34:17 --> Security Class Initialized
DEBUG - 2019-11-09 16:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:34:17 --> CSRF cookie sent
INFO - 2019-11-09 16:34:17 --> Input Class Initialized
INFO - 2019-11-09 16:34:17 --> Language Class Initialized
INFO - 2019-11-09 16:34:17 --> Language Class Initialized
INFO - 2019-11-09 16:34:17 --> Config Class Initialized
INFO - 2019-11-09 16:34:17 --> Loader Class Initialized
INFO - 2019-11-09 16:34:17 --> Helper loaded: url_helper
INFO - 2019-11-09 16:34:17 --> Helper loaded: common_helper
INFO - 2019-11-09 16:34:17 --> Helper loaded: language_helper
INFO - 2019-11-09 16:34:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:34:17 --> Helper loaded: email_helper
INFO - 2019-11-09 16:34:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:34:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:34:17 --> Parser Class Initialized
INFO - 2019-11-09 16:34:17 --> User Agent Class Initialized
INFO - 2019-11-09 16:34:17 --> Model Class Initialized
INFO - 2019-11-09 16:34:17 --> Database Driver Class Initialized
INFO - 2019-11-09 16:34:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:17 --> Template Class Initialized
INFO - 2019-11-09 16:34:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:34:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:34:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:34:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:34:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:34:17 --> Encryption Class Initialized
INFO - 2019-11-09 16:34:18 --> Controller Class Initialized
DEBUG - 2019-11-09 16:34:18 --> transactions MX_Controller Initialized
DEBUG - 2019-11-09 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-09 16:34:18 --> Model Class Initialized
ERROR - 2019-11-09 16:34:18 --> Could not find the language line "order_id"
INFO - 2019-11-09 16:34:18 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-09 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:34:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:34:18 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:34:18 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 16:34:18 --> Final output sent to browser
DEBUG - 2019-11-09 16:34:18 --> Total execution time: 1.1114
INFO - 2019-11-09 16:34:24 --> Config Class Initialized
INFO - 2019-11-09 16:34:24 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:34:24 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:34:24 --> Utf8 Class Initialized
INFO - 2019-11-09 16:34:24 --> URI Class Initialized
INFO - 2019-11-09 16:34:24 --> Router Class Initialized
INFO - 2019-11-09 16:34:24 --> Output Class Initialized
INFO - 2019-11-09 16:34:24 --> Security Class Initialized
DEBUG - 2019-11-09 16:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:34:24 --> CSRF cookie sent
INFO - 2019-11-09 16:34:24 --> CSRF token verified
INFO - 2019-11-09 16:34:24 --> Input Class Initialized
INFO - 2019-11-09 16:34:24 --> Language Class Initialized
INFO - 2019-11-09 16:34:24 --> Language Class Initialized
INFO - 2019-11-09 16:34:24 --> Config Class Initialized
INFO - 2019-11-09 16:34:24 --> Loader Class Initialized
INFO - 2019-11-09 16:34:24 --> Helper loaded: url_helper
INFO - 2019-11-09 16:34:25 --> Helper loaded: common_helper
INFO - 2019-11-09 16:34:25 --> Helper loaded: language_helper
INFO - 2019-11-09 16:34:25 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:34:25 --> Helper loaded: email_helper
INFO - 2019-11-09 16:34:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:34:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:34:25 --> Parser Class Initialized
INFO - 2019-11-09 16:34:25 --> User Agent Class Initialized
INFO - 2019-11-09 16:34:25 --> Model Class Initialized
INFO - 2019-11-09 16:34:25 --> Database Driver Class Initialized
INFO - 2019-11-09 16:34:25 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:25 --> Template Class Initialized
INFO - 2019-11-09 16:34:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:34:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:34:25 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:34:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:34:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:34:25 --> Encryption Class Initialized
INFO - 2019-11-09 16:34:25 --> Controller Class Initialized
DEBUG - 2019-11-09 16:34:25 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:34:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:34:25 --> Model Class Initialized
INFO - 2019-11-09 16:34:25 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:34:25 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:34:25 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:34:25 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:34:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:34:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:34:25 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:34:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:34:25 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:34:25 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:34:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:34:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:34:25 --> Final output sent to browser
DEBUG - 2019-11-09 16:34:25 --> Total execution time: 1.0719
INFO - 2019-11-09 16:34:38 --> Config Class Initialized
INFO - 2019-11-09 16:34:38 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:34:38 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:34:38 --> Utf8 Class Initialized
INFO - 2019-11-09 16:34:38 --> URI Class Initialized
INFO - 2019-11-09 16:34:38 --> Router Class Initialized
INFO - 2019-11-09 16:34:38 --> Output Class Initialized
INFO - 2019-11-09 16:34:38 --> Security Class Initialized
DEBUG - 2019-11-09 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:34:38 --> CSRF cookie sent
INFO - 2019-11-09 16:34:38 --> CSRF token verified
INFO - 2019-11-09 16:34:39 --> Input Class Initialized
INFO - 2019-11-09 16:34:39 --> Language Class Initialized
INFO - 2019-11-09 16:34:39 --> Language Class Initialized
INFO - 2019-11-09 16:34:39 --> Config Class Initialized
INFO - 2019-11-09 16:34:39 --> Loader Class Initialized
INFO - 2019-11-09 16:34:39 --> Helper loaded: url_helper
INFO - 2019-11-09 16:34:39 --> Helper loaded: common_helper
INFO - 2019-11-09 16:34:39 --> Helper loaded: language_helper
INFO - 2019-11-09 16:34:39 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:34:39 --> Helper loaded: email_helper
INFO - 2019-11-09 16:34:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:34:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:34:39 --> Parser Class Initialized
INFO - 2019-11-09 16:34:39 --> User Agent Class Initialized
INFO - 2019-11-09 16:34:39 --> Model Class Initialized
INFO - 2019-11-09 16:34:39 --> Database Driver Class Initialized
INFO - 2019-11-09 16:34:39 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:39 --> Template Class Initialized
INFO - 2019-11-09 16:34:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:34:39 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:34:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:34:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:34:39 --> Encryption Class Initialized
INFO - 2019-11-09 16:34:39 --> Controller Class Initialized
DEBUG - 2019-11-09 16:34:39 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:34:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:34:39 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:39 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:34:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
ERROR - 2019-11-09 16:34:39 --> Could not find the language line "choose_your_coin"
DEBUG - 2019-11-09 16:34:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinpayments/index.php
INFO - 2019-11-09 16:34:39 --> Final output sent to browser
DEBUG - 2019-11-09 16:34:39 --> Total execution time: 0.8768
INFO - 2019-11-09 16:34:48 --> Config Class Initialized
INFO - 2019-11-09 16:34:48 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:34:48 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:34:48 --> Utf8 Class Initialized
INFO - 2019-11-09 16:34:48 --> URI Class Initialized
INFO - 2019-11-09 16:34:48 --> Router Class Initialized
INFO - 2019-11-09 16:34:48 --> Output Class Initialized
INFO - 2019-11-09 16:34:48 --> Security Class Initialized
DEBUG - 2019-11-09 16:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:34:48 --> Input Class Initialized
INFO - 2019-11-09 16:34:48 --> Language Class Initialized
INFO - 2019-11-09 16:34:48 --> Language Class Initialized
INFO - 2019-11-09 16:34:48 --> Config Class Initialized
INFO - 2019-11-09 16:34:48 --> Loader Class Initialized
INFO - 2019-11-09 16:34:48 --> Helper loaded: url_helper
INFO - 2019-11-09 16:34:48 --> Helper loaded: common_helper
INFO - 2019-11-09 16:34:48 --> Helper loaded: language_helper
INFO - 2019-11-09 16:34:48 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:34:48 --> Helper loaded: email_helper
INFO - 2019-11-09 16:34:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:34:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:34:48 --> Parser Class Initialized
INFO - 2019-11-09 16:34:48 --> User Agent Class Initialized
INFO - 2019-11-09 16:34:48 --> Model Class Initialized
INFO - 2019-11-09 16:34:48 --> Database Driver Class Initialized
INFO - 2019-11-09 16:34:48 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:48 --> Template Class Initialized
INFO - 2019-11-09 16:34:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:34:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:34:48 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:34:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:34:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:34:48 --> Encryption Class Initialized
INFO - 2019-11-09 16:34:48 --> Controller Class Initialized
DEBUG - 2019-11-09 16:34:48 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:34:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
INFO - 2019-11-09 16:34:48 --> Model Class Initialized
DEBUG - 2019-11-09 16:34:50 --> orders MX_Controller Initialized
INFO - 2019-11-09 16:35:16 --> Config Class Initialized
INFO - 2019-11-09 16:35:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:35:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:35:16 --> Utf8 Class Initialized
INFO - 2019-11-09 16:35:16 --> URI Class Initialized
INFO - 2019-11-09 16:35:16 --> Router Class Initialized
INFO - 2019-11-09 16:35:16 --> Output Class Initialized
INFO - 2019-11-09 16:35:16 --> Security Class Initialized
DEBUG - 2019-11-09 16:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:35:16 --> CSRF cookie sent
INFO - 2019-11-09 16:35:16 --> Input Class Initialized
INFO - 2019-11-09 16:35:16 --> Language Class Initialized
INFO - 2019-11-09 16:35:16 --> Language Class Initialized
INFO - 2019-11-09 16:35:17 --> Config Class Initialized
INFO - 2019-11-09 16:35:17 --> Loader Class Initialized
INFO - 2019-11-09 16:35:17 --> Helper loaded: url_helper
INFO - 2019-11-09 16:35:17 --> Helper loaded: common_helper
INFO - 2019-11-09 16:35:17 --> Helper loaded: language_helper
INFO - 2019-11-09 16:35:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:35:17 --> Helper loaded: email_helper
INFO - 2019-11-09 16:35:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:35:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:35:17 --> Parser Class Initialized
INFO - 2019-11-09 16:35:17 --> User Agent Class Initialized
INFO - 2019-11-09 16:35:17 --> Model Class Initialized
INFO - 2019-11-09 16:35:17 --> Database Driver Class Initialized
INFO - 2019-11-09 16:35:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:35:17 --> Template Class Initialized
INFO - 2019-11-09 16:35:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:35:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:35:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:35:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:35:17 --> Encryption Class Initialized
INFO - 2019-11-09 16:35:17 --> Controller Class Initialized
DEBUG - 2019-11-09 16:35:17 --> transactions MX_Controller Initialized
DEBUG - 2019-11-09 16:35:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-09 16:35:17 --> Model Class Initialized
ERROR - 2019-11-09 16:35:17 --> Could not find the language line "order_id"
INFO - 2019-11-09 16:35:17 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:35:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-09 16:35:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:35:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:35:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:35:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:35:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:35:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:35:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 16:35:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 16:35:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 16:35:17 --> Final output sent to browser
DEBUG - 2019-11-09 16:35:17 --> Total execution time: 1.1798
INFO - 2019-11-09 16:35:19 --> Config Class Initialized
INFO - 2019-11-09 16:35:19 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:35:19 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:35:20 --> Utf8 Class Initialized
INFO - 2019-11-09 16:35:20 --> URI Class Initialized
INFO - 2019-11-09 16:35:20 --> Router Class Initialized
INFO - 2019-11-09 16:35:20 --> Output Class Initialized
INFO - 2019-11-09 16:35:20 --> Security Class Initialized
DEBUG - 2019-11-09 16:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:35:20 --> CSRF cookie sent
INFO - 2019-11-09 16:35:20 --> Input Class Initialized
INFO - 2019-11-09 16:35:20 --> Language Class Initialized
INFO - 2019-11-09 16:35:20 --> Language Class Initialized
INFO - 2019-11-09 16:35:20 --> Config Class Initialized
INFO - 2019-11-09 16:35:20 --> Loader Class Initialized
INFO - 2019-11-09 16:35:20 --> Helper loaded: url_helper
INFO - 2019-11-09 16:35:20 --> Helper loaded: common_helper
INFO - 2019-11-09 16:35:20 --> Helper loaded: language_helper
INFO - 2019-11-09 16:35:20 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:35:20 --> Helper loaded: email_helper
INFO - 2019-11-09 16:35:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:35:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:35:20 --> Parser Class Initialized
INFO - 2019-11-09 16:35:20 --> User Agent Class Initialized
INFO - 2019-11-09 16:35:20 --> Model Class Initialized
INFO - 2019-11-09 16:35:20 --> Database Driver Class Initialized
INFO - 2019-11-09 16:35:20 --> Model Class Initialized
DEBUG - 2019-11-09 16:35:20 --> Template Class Initialized
INFO - 2019-11-09 16:35:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:35:20 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:35:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:35:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:35:20 --> Encryption Class Initialized
INFO - 2019-11-09 16:35:20 --> Controller Class Initialized
DEBUG - 2019-11-09 16:35:20 --> order MX_Controller Initialized
DEBUG - 2019-11-09 16:35:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-09 16:35:20 --> Model Class Initialized
ERROR - 2019-11-09 16:35:20 --> Could not find the language line "order_id"
ERROR - 2019-11-09 16:35:20 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-09 16:35:20 --> Could not find the language line "order_id"
ERROR - 2019-11-09 16:35:20 --> Could not find the language line "order_basic_details"
INFO - 2019-11-09 16:35:20 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:35:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 16:35:20 --> Could not find the language line "Pending"
ERROR - 2019-11-09 16:35:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 16:35:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 16:35:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 16:35:21 --> Could not find the language line "Pending"
ERROR - 2019-11-09 16:35:21 --> Could not find the language line "Pending"
DEBUG - 2019-11-09 16:35:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-09 16:35:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:35:21 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:35:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:35:21 --> Model Class Initialized
DEBUG - 2019-11-09 16:35:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:35:21 --> Model Class Initialized
DEBUG - 2019-11-09 16:35:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 16:35:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 16:35:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 16:35:21 --> Final output sent to browser
DEBUG - 2019-11-09 16:35:21 --> Total execution time: 1.3704
INFO - 2019-11-09 16:36:07 --> Config Class Initialized
INFO - 2019-11-09 16:36:07 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:36:07 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:36:07 --> Utf8 Class Initialized
INFO - 2019-11-09 16:36:07 --> URI Class Initialized
INFO - 2019-11-09 16:36:07 --> Router Class Initialized
INFO - 2019-11-09 16:36:07 --> Output Class Initialized
INFO - 2019-11-09 16:36:07 --> Security Class Initialized
DEBUG - 2019-11-09 16:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:36:07 --> Input Class Initialized
INFO - 2019-11-09 16:36:07 --> Language Class Initialized
INFO - 2019-11-09 16:36:07 --> Language Class Initialized
INFO - 2019-11-09 16:36:07 --> Config Class Initialized
INFO - 2019-11-09 16:36:07 --> Loader Class Initialized
INFO - 2019-11-09 16:36:07 --> Helper loaded: url_helper
INFO - 2019-11-09 16:36:07 --> Helper loaded: common_helper
INFO - 2019-11-09 16:36:07 --> Helper loaded: language_helper
INFO - 2019-11-09 16:36:07 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:36:07 --> Helper loaded: email_helper
INFO - 2019-11-09 16:36:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:36:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:36:07 --> Parser Class Initialized
INFO - 2019-11-09 16:36:07 --> User Agent Class Initialized
INFO - 2019-11-09 16:36:07 --> Model Class Initialized
INFO - 2019-11-09 16:36:07 --> Database Driver Class Initialized
INFO - 2019-11-09 16:36:07 --> Model Class Initialized
DEBUG - 2019-11-09 16:36:07 --> Template Class Initialized
INFO - 2019-11-09 16:36:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:36:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:36:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:36:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:36:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:36:08 --> Encryption Class Initialized
INFO - 2019-11-09 16:36:08 --> Controller Class Initialized
DEBUG - 2019-11-09 16:36:08 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:36:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
INFO - 2019-11-09 16:36:08 --> Model Class Initialized
INFO - 2019-11-09 16:36:08 --> Config Class Initialized
INFO - 2019-11-09 16:36:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:36:08 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:36:08 --> Utf8 Class Initialized
INFO - 2019-11-09 16:36:08 --> URI Class Initialized
INFO - 2019-11-09 16:36:08 --> Router Class Initialized
INFO - 2019-11-09 16:36:08 --> Output Class Initialized
INFO - 2019-11-09 16:36:08 --> Security Class Initialized
DEBUG - 2019-11-09 16:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:36:08 --> CSRF cookie sent
INFO - 2019-11-09 16:36:08 --> Input Class Initialized
INFO - 2019-11-09 16:36:08 --> Language Class Initialized
INFO - 2019-11-09 16:36:08 --> Language Class Initialized
INFO - 2019-11-09 16:36:08 --> Config Class Initialized
INFO - 2019-11-09 16:36:08 --> Loader Class Initialized
INFO - 2019-11-09 16:36:08 --> Helper loaded: url_helper
INFO - 2019-11-09 16:36:08 --> Helper loaded: common_helper
INFO - 2019-11-09 16:36:08 --> Helper loaded: language_helper
INFO - 2019-11-09 16:36:08 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:36:08 --> Helper loaded: email_helper
INFO - 2019-11-09 16:36:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:36:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:36:08 --> Parser Class Initialized
INFO - 2019-11-09 16:36:08 --> User Agent Class Initialized
INFO - 2019-11-09 16:36:08 --> Model Class Initialized
INFO - 2019-11-09 16:36:08 --> Database Driver Class Initialized
INFO - 2019-11-09 16:36:08 --> Model Class Initialized
DEBUG - 2019-11-09 16:36:08 --> Template Class Initialized
INFO - 2019-11-09 16:36:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:36:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:36:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:36:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:36:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:36:08 --> Encryption Class Initialized
INFO - 2019-11-09 16:36:08 --> Controller Class Initialized
DEBUG - 2019-11-09 16:36:08 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:36:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:36:08 --> Model Class Initialized
INFO - 2019-11-09 16:36:09 --> Config Class Initialized
INFO - 2019-11-09 16:36:09 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:36:09 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:36:09 --> Utf8 Class Initialized
INFO - 2019-11-09 16:36:09 --> URI Class Initialized
DEBUG - 2019-11-09 16:36:09 --> No URI present. Default controller set.
INFO - 2019-11-09 16:36:09 --> Router Class Initialized
INFO - 2019-11-09 16:36:09 --> Output Class Initialized
INFO - 2019-11-09 16:36:09 --> Security Class Initialized
DEBUG - 2019-11-09 16:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:36:09 --> CSRF cookie sent
INFO - 2019-11-09 16:36:09 --> Input Class Initialized
INFO - 2019-11-09 16:36:09 --> Language Class Initialized
INFO - 2019-11-09 16:36:09 --> Language Class Initialized
INFO - 2019-11-09 16:36:09 --> Config Class Initialized
INFO - 2019-11-09 16:36:09 --> Loader Class Initialized
INFO - 2019-11-09 16:36:09 --> Helper loaded: url_helper
INFO - 2019-11-09 16:36:09 --> Helper loaded: common_helper
INFO - 2019-11-09 16:36:09 --> Helper loaded: language_helper
INFO - 2019-11-09 16:36:09 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:36:09 --> Helper loaded: email_helper
INFO - 2019-11-09 16:36:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:36:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:36:09 --> Parser Class Initialized
INFO - 2019-11-09 16:36:09 --> User Agent Class Initialized
INFO - 2019-11-09 16:36:09 --> Model Class Initialized
INFO - 2019-11-09 16:36:09 --> Database Driver Class Initialized
INFO - 2019-11-09 16:36:09 --> Model Class Initialized
DEBUG - 2019-11-09 16:36:09 --> Template Class Initialized
INFO - 2019-11-09 16:36:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:36:09 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:36:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:36:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:36:09 --> Encryption Class Initialized
DEBUG - 2019-11-09 16:36:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:36:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 16:36:09 --> Controller Class Initialized
DEBUG - 2019-11-09 16:36:09 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 16:36:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:36:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 16:36:09 --> Model Class Initialized
INFO - 2019-11-09 16:36:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:36:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 16:36:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 16:36:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 16:36:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 16:36:10 --> Final output sent to browser
DEBUG - 2019-11-09 16:36:10 --> Total execution time: 1.0129
INFO - 2019-11-09 16:37:30 --> Config Class Initialized
INFO - 2019-11-09 16:37:30 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:37:30 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:37:30 --> Utf8 Class Initialized
INFO - 2019-11-09 16:37:30 --> URI Class Initialized
INFO - 2019-11-09 16:37:30 --> Router Class Initialized
INFO - 2019-11-09 16:37:30 --> Output Class Initialized
INFO - 2019-11-09 16:37:30 --> Security Class Initialized
DEBUG - 2019-11-09 16:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:37:30 --> Input Class Initialized
INFO - 2019-11-09 16:37:30 --> Language Class Initialized
INFO - 2019-11-09 16:37:30 --> Language Class Initialized
INFO - 2019-11-09 16:37:30 --> Config Class Initialized
INFO - 2019-11-09 16:37:30 --> Loader Class Initialized
INFO - 2019-11-09 16:37:30 --> Helper loaded: url_helper
INFO - 2019-11-09 16:37:30 --> Helper loaded: common_helper
INFO - 2019-11-09 16:37:30 --> Helper loaded: language_helper
INFO - 2019-11-09 16:37:30 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:37:30 --> Helper loaded: email_helper
INFO - 2019-11-09 16:37:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:37:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:37:31 --> Parser Class Initialized
INFO - 2019-11-09 16:37:31 --> User Agent Class Initialized
INFO - 2019-11-09 16:37:31 --> Model Class Initialized
INFO - 2019-11-09 16:37:31 --> Database Driver Class Initialized
INFO - 2019-11-09 16:37:31 --> Model Class Initialized
DEBUG - 2019-11-09 16:37:31 --> Template Class Initialized
INFO - 2019-11-09 16:37:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:37:31 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:37:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:37:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:37:31 --> Encryption Class Initialized
INFO - 2019-11-09 16:37:31 --> Controller Class Initialized
DEBUG - 2019-11-09 16:37:31 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:37:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
INFO - 2019-11-09 16:37:31 --> Model Class Initialized
INFO - 2019-11-09 16:37:31 --> Config Class Initialized
INFO - 2019-11-09 16:37:31 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:37:31 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:37:31 --> Utf8 Class Initialized
INFO - 2019-11-09 16:37:31 --> URI Class Initialized
DEBUG - 2019-11-09 16:37:31 --> No URI present. Default controller set.
INFO - 2019-11-09 16:37:31 --> Router Class Initialized
INFO - 2019-11-09 16:37:31 --> Output Class Initialized
INFO - 2019-11-09 16:37:31 --> Security Class Initialized
DEBUG - 2019-11-09 16:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:37:31 --> CSRF cookie sent
INFO - 2019-11-09 16:37:31 --> Input Class Initialized
INFO - 2019-11-09 16:37:31 --> Language Class Initialized
INFO - 2019-11-09 16:37:31 --> Language Class Initialized
INFO - 2019-11-09 16:37:31 --> Config Class Initialized
INFO - 2019-11-09 16:37:31 --> Loader Class Initialized
INFO - 2019-11-09 16:37:31 --> Helper loaded: url_helper
INFO - 2019-11-09 16:37:31 --> Helper loaded: common_helper
INFO - 2019-11-09 16:37:31 --> Helper loaded: language_helper
INFO - 2019-11-09 16:37:31 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:37:31 --> Helper loaded: email_helper
INFO - 2019-11-09 16:37:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:37:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:37:31 --> Parser Class Initialized
INFO - 2019-11-09 16:37:31 --> User Agent Class Initialized
INFO - 2019-11-09 16:37:31 --> Model Class Initialized
INFO - 2019-11-09 16:37:32 --> Database Driver Class Initialized
INFO - 2019-11-09 16:37:32 --> Model Class Initialized
DEBUG - 2019-11-09 16:37:32 --> Template Class Initialized
INFO - 2019-11-09 16:37:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:37:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:37:32 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:37:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:37:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:37:32 --> Encryption Class Initialized
DEBUG - 2019-11-09 16:37:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:37:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 16:37:32 --> Controller Class Initialized
DEBUG - 2019-11-09 16:37:32 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 16:37:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:37:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 16:37:32 --> Model Class Initialized
INFO - 2019-11-09 16:37:32 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:37:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 16:37:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 16:37:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 16:37:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 16:37:32 --> Final output sent to browser
DEBUG - 2019-11-09 16:37:32 --> Total execution time: 1.1763
INFO - 2019-11-09 16:37:57 --> Config Class Initialized
INFO - 2019-11-09 16:37:57 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:37:57 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:37:57 --> Utf8 Class Initialized
INFO - 2019-11-09 16:37:57 --> URI Class Initialized
INFO - 2019-11-09 16:37:57 --> Router Class Initialized
INFO - 2019-11-09 16:37:57 --> Output Class Initialized
INFO - 2019-11-09 16:37:57 --> Security Class Initialized
DEBUG - 2019-11-09 16:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:37:57 --> CSRF cookie sent
INFO - 2019-11-09 16:37:57 --> Input Class Initialized
INFO - 2019-11-09 16:37:57 --> Language Class Initialized
INFO - 2019-11-09 16:37:57 --> Language Class Initialized
INFO - 2019-11-09 16:37:57 --> Config Class Initialized
INFO - 2019-11-09 16:37:57 --> Loader Class Initialized
INFO - 2019-11-09 16:37:57 --> Helper loaded: url_helper
INFO - 2019-11-09 16:37:57 --> Helper loaded: common_helper
INFO - 2019-11-09 16:37:57 --> Helper loaded: language_helper
INFO - 2019-11-09 16:37:57 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:37:57 --> Helper loaded: email_helper
INFO - 2019-11-09 16:37:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:37:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:37:57 --> Parser Class Initialized
INFO - 2019-11-09 16:37:57 --> User Agent Class Initialized
INFO - 2019-11-09 16:37:57 --> Model Class Initialized
INFO - 2019-11-09 16:37:57 --> Database Driver Class Initialized
INFO - 2019-11-09 16:37:57 --> Model Class Initialized
DEBUG - 2019-11-09 16:37:58 --> Template Class Initialized
INFO - 2019-11-09 16:37:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:37:58 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:37:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:37:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:37:58 --> Encryption Class Initialized
INFO - 2019-11-09 16:37:58 --> Controller Class Initialized
DEBUG - 2019-11-09 16:37:58 --> package MX_Controller Initialized
DEBUG - 2019-11-09 16:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 16:37:58 --> Model Class Initialized
INFO - 2019-11-09 16:37:58 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:37:58 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:37:58 --> Model Class Initialized
DEBUG - 2019-11-09 16:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:37:58 --> Model Class Initialized
DEBUG - 2019-11-09 16:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 16:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 16:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:37:58 --> Final output sent to browser
DEBUG - 2019-11-09 16:37:58 --> Total execution time: 1.4322
INFO - 2019-11-09 16:38:01 --> Config Class Initialized
INFO - 2019-11-09 16:38:01 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:38:01 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:38:01 --> Utf8 Class Initialized
INFO - 2019-11-09 16:38:01 --> URI Class Initialized
INFO - 2019-11-09 16:38:01 --> Router Class Initialized
INFO - 2019-11-09 16:38:02 --> Output Class Initialized
INFO - 2019-11-09 16:38:02 --> Security Class Initialized
DEBUG - 2019-11-09 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:38:02 --> CSRF cookie sent
INFO - 2019-11-09 16:38:02 --> CSRF token verified
INFO - 2019-11-09 16:38:02 --> Input Class Initialized
INFO - 2019-11-09 16:38:02 --> Language Class Initialized
INFO - 2019-11-09 16:38:02 --> Language Class Initialized
INFO - 2019-11-09 16:38:02 --> Config Class Initialized
INFO - 2019-11-09 16:38:02 --> Loader Class Initialized
INFO - 2019-11-09 16:38:02 --> Helper loaded: url_helper
INFO - 2019-11-09 16:38:02 --> Helper loaded: common_helper
INFO - 2019-11-09 16:38:02 --> Helper loaded: language_helper
INFO - 2019-11-09 16:38:02 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:38:02 --> Helper loaded: email_helper
INFO - 2019-11-09 16:38:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:38:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:38:02 --> Parser Class Initialized
INFO - 2019-11-09 16:38:02 --> User Agent Class Initialized
INFO - 2019-11-09 16:38:02 --> Model Class Initialized
INFO - 2019-11-09 16:38:02 --> Database Driver Class Initialized
INFO - 2019-11-09 16:38:02 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:02 --> Template Class Initialized
INFO - 2019-11-09 16:38:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:38:02 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:38:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:38:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:38:02 --> Encryption Class Initialized
INFO - 2019-11-09 16:38:02 --> Controller Class Initialized
DEBUG - 2019-11-09 16:38:02 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:38:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:38:02 --> Model Class Initialized
INFO - 2019-11-09 16:38:02 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:38:02 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:38:02 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:38:02 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:38:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:38:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:38:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:38:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:38:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:38:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:38:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:38:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:38:03 --> Final output sent to browser
DEBUG - 2019-11-09 16:38:03 --> Total execution time: 1.4376
INFO - 2019-11-09 16:38:13 --> Config Class Initialized
INFO - 2019-11-09 16:38:14 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:38:14 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:38:14 --> Utf8 Class Initialized
INFO - 2019-11-09 16:38:14 --> URI Class Initialized
INFO - 2019-11-09 16:38:14 --> Router Class Initialized
INFO - 2019-11-09 16:38:14 --> Output Class Initialized
INFO - 2019-11-09 16:38:14 --> Security Class Initialized
DEBUG - 2019-11-09 16:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:38:14 --> CSRF cookie sent
INFO - 2019-11-09 16:38:14 --> CSRF token verified
INFO - 2019-11-09 16:38:14 --> Input Class Initialized
INFO - 2019-11-09 16:38:14 --> Language Class Initialized
INFO - 2019-11-09 16:38:14 --> Language Class Initialized
INFO - 2019-11-09 16:38:14 --> Config Class Initialized
INFO - 2019-11-09 16:38:14 --> Loader Class Initialized
INFO - 2019-11-09 16:38:14 --> Helper loaded: url_helper
INFO - 2019-11-09 16:38:14 --> Helper loaded: common_helper
INFO - 2019-11-09 16:38:14 --> Helper loaded: language_helper
INFO - 2019-11-09 16:38:14 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:38:14 --> Helper loaded: email_helper
INFO - 2019-11-09 16:38:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:38:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:38:14 --> Parser Class Initialized
INFO - 2019-11-09 16:38:14 --> User Agent Class Initialized
INFO - 2019-11-09 16:38:14 --> Model Class Initialized
INFO - 2019-11-09 16:38:14 --> Database Driver Class Initialized
INFO - 2019-11-09 16:38:14 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:14 --> Template Class Initialized
INFO - 2019-11-09 16:38:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:38:14 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:38:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:38:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:38:14 --> Encryption Class Initialized
INFO - 2019-11-09 16:38:14 --> Controller Class Initialized
DEBUG - 2019-11-09 16:38:14 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:38:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:38:14 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:14 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:38:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
ERROR - 2019-11-09 16:38:14 --> Could not find the language line "choose_your_coin"
DEBUG - 2019-11-09 16:38:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinpayments/index.php
INFO - 2019-11-09 16:38:14 --> Final output sent to browser
DEBUG - 2019-11-09 16:38:15 --> Total execution time: 0.9879
INFO - 2019-11-09 16:38:35 --> Config Class Initialized
INFO - 2019-11-09 16:38:35 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:38:35 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:38:35 --> Utf8 Class Initialized
INFO - 2019-11-09 16:38:35 --> URI Class Initialized
INFO - 2019-11-09 16:38:35 --> Router Class Initialized
INFO - 2019-11-09 16:38:35 --> Output Class Initialized
INFO - 2019-11-09 16:38:35 --> Security Class Initialized
DEBUG - 2019-11-09 16:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:38:35 --> Input Class Initialized
INFO - 2019-11-09 16:38:35 --> Language Class Initialized
INFO - 2019-11-09 16:38:35 --> Language Class Initialized
INFO - 2019-11-09 16:38:35 --> Config Class Initialized
INFO - 2019-11-09 16:38:36 --> Loader Class Initialized
INFO - 2019-11-09 16:38:36 --> Helper loaded: url_helper
INFO - 2019-11-09 16:38:36 --> Helper loaded: common_helper
INFO - 2019-11-09 16:38:36 --> Helper loaded: language_helper
INFO - 2019-11-09 16:38:36 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:38:36 --> Helper loaded: email_helper
INFO - 2019-11-09 16:38:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:38:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:38:36 --> Parser Class Initialized
INFO - 2019-11-09 16:38:36 --> User Agent Class Initialized
INFO - 2019-11-09 16:38:36 --> Model Class Initialized
INFO - 2019-11-09 16:38:36 --> Database Driver Class Initialized
INFO - 2019-11-09 16:38:36 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:36 --> Template Class Initialized
INFO - 2019-11-09 16:38:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:38:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:38:36 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:38:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:38:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:38:36 --> Encryption Class Initialized
INFO - 2019-11-09 16:38:36 --> Controller Class Initialized
DEBUG - 2019-11-09 16:38:36 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
INFO - 2019-11-09 16:38:36 --> Model Class Initialized
INFO - 2019-11-09 16:38:36 --> Config Class Initialized
INFO - 2019-11-09 16:38:36 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:38:36 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:38:36 --> Utf8 Class Initialized
INFO - 2019-11-09 16:38:36 --> URI Class Initialized
DEBUG - 2019-11-09 16:38:36 --> No URI present. Default controller set.
INFO - 2019-11-09 16:38:36 --> Router Class Initialized
INFO - 2019-11-09 16:38:36 --> Output Class Initialized
INFO - 2019-11-09 16:38:36 --> Security Class Initialized
DEBUG - 2019-11-09 16:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:38:36 --> CSRF cookie sent
INFO - 2019-11-09 16:38:36 --> Input Class Initialized
INFO - 2019-11-09 16:38:36 --> Language Class Initialized
INFO - 2019-11-09 16:38:36 --> Language Class Initialized
INFO - 2019-11-09 16:38:36 --> Config Class Initialized
INFO - 2019-11-09 16:38:36 --> Loader Class Initialized
INFO - 2019-11-09 16:38:36 --> Helper loaded: url_helper
INFO - 2019-11-09 16:38:36 --> Helper loaded: common_helper
INFO - 2019-11-09 16:38:36 --> Helper loaded: language_helper
INFO - 2019-11-09 16:38:36 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:38:37 --> Helper loaded: email_helper
INFO - 2019-11-09 16:38:37 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:38:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:38:37 --> Parser Class Initialized
INFO - 2019-11-09 16:38:37 --> User Agent Class Initialized
INFO - 2019-11-09 16:38:37 --> Model Class Initialized
INFO - 2019-11-09 16:38:37 --> Database Driver Class Initialized
INFO - 2019-11-09 16:38:37 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:37 --> Template Class Initialized
INFO - 2019-11-09 16:38:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:38:37 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:38:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:38:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:38:37 --> Encryption Class Initialized
DEBUG - 2019-11-09 16:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 16:38:37 --> Controller Class Initialized
DEBUG - 2019-11-09 16:38:37 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 16:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 16:38:37 --> Model Class Initialized
INFO - 2019-11-09 16:38:37 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 16:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 16:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 16:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 16:38:37 --> Final output sent to browser
DEBUG - 2019-11-09 16:38:37 --> Total execution time: 1.1724
INFO - 2019-11-09 16:38:44 --> Config Class Initialized
INFO - 2019-11-09 16:38:44 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:38:44 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:38:44 --> Utf8 Class Initialized
INFO - 2019-11-09 16:38:44 --> URI Class Initialized
INFO - 2019-11-09 16:38:44 --> Router Class Initialized
INFO - 2019-11-09 16:38:44 --> Output Class Initialized
INFO - 2019-11-09 16:38:44 --> Security Class Initialized
DEBUG - 2019-11-09 16:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:38:45 --> CSRF cookie sent
INFO - 2019-11-09 16:38:45 --> Input Class Initialized
INFO - 2019-11-09 16:38:45 --> Language Class Initialized
INFO - 2019-11-09 16:38:45 --> Language Class Initialized
INFO - 2019-11-09 16:38:45 --> Config Class Initialized
INFO - 2019-11-09 16:38:45 --> Loader Class Initialized
INFO - 2019-11-09 16:38:45 --> Helper loaded: url_helper
INFO - 2019-11-09 16:38:45 --> Helper loaded: common_helper
INFO - 2019-11-09 16:38:45 --> Helper loaded: language_helper
INFO - 2019-11-09 16:38:45 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:38:45 --> Helper loaded: email_helper
INFO - 2019-11-09 16:38:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:38:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:38:45 --> Parser Class Initialized
INFO - 2019-11-09 16:38:45 --> User Agent Class Initialized
INFO - 2019-11-09 16:38:45 --> Model Class Initialized
INFO - 2019-11-09 16:38:45 --> Database Driver Class Initialized
INFO - 2019-11-09 16:38:45 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:45 --> Template Class Initialized
INFO - 2019-11-09 16:38:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:38:45 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:38:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:38:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:38:45 --> Encryption Class Initialized
INFO - 2019-11-09 16:38:45 --> Controller Class Initialized
DEBUG - 2019-11-09 16:38:45 --> package MX_Controller Initialized
DEBUG - 2019-11-09 16:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 16:38:45 --> Model Class Initialized
INFO - 2019-11-09 16:38:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:38:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:38:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:38:46 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:38:46 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 16:38:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 16:38:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:38:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:38:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:38:46 --> Final output sent to browser
DEBUG - 2019-11-09 16:38:46 --> Total execution time: 1.6074
INFO - 2019-11-09 16:38:49 --> Config Class Initialized
INFO - 2019-11-09 16:38:49 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:38:49 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:38:49 --> Utf8 Class Initialized
INFO - 2019-11-09 16:38:50 --> URI Class Initialized
INFO - 2019-11-09 16:38:50 --> Router Class Initialized
INFO - 2019-11-09 16:38:50 --> Output Class Initialized
INFO - 2019-11-09 16:38:50 --> Security Class Initialized
DEBUG - 2019-11-09 16:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:38:50 --> CSRF cookie sent
INFO - 2019-11-09 16:38:50 --> CSRF token verified
INFO - 2019-11-09 16:38:50 --> Input Class Initialized
INFO - 2019-11-09 16:38:50 --> Language Class Initialized
INFO - 2019-11-09 16:38:50 --> Language Class Initialized
INFO - 2019-11-09 16:38:50 --> Config Class Initialized
INFO - 2019-11-09 16:38:50 --> Loader Class Initialized
INFO - 2019-11-09 16:38:50 --> Helper loaded: url_helper
INFO - 2019-11-09 16:38:50 --> Helper loaded: common_helper
INFO - 2019-11-09 16:38:50 --> Helper loaded: language_helper
INFO - 2019-11-09 16:38:50 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:38:50 --> Helper loaded: email_helper
INFO - 2019-11-09 16:38:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:38:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:38:50 --> Parser Class Initialized
INFO - 2019-11-09 16:38:50 --> User Agent Class Initialized
INFO - 2019-11-09 16:38:50 --> Model Class Initialized
INFO - 2019-11-09 16:38:50 --> Database Driver Class Initialized
INFO - 2019-11-09 16:38:50 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:50 --> Template Class Initialized
INFO - 2019-11-09 16:38:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:38:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:38:50 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:38:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:38:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:38:50 --> Encryption Class Initialized
INFO - 2019-11-09 16:38:50 --> Controller Class Initialized
DEBUG - 2019-11-09 16:38:50 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:38:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:38:50 --> Model Class Initialized
INFO - 2019-11-09 16:38:50 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:38:50 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:38:50 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:38:51 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:38:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:38:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:38:51 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:38:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:38:51 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:38:51 --> Model Class Initialized
DEBUG - 2019-11-09 16:38:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:38:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:38:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:38:51 --> Final output sent to browser
DEBUG - 2019-11-09 16:38:51 --> Total execution time: 1.4015
INFO - 2019-11-09 16:39:02 --> Config Class Initialized
INFO - 2019-11-09 16:39:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:39:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:39:02 --> Utf8 Class Initialized
INFO - 2019-11-09 16:39:03 --> URI Class Initialized
INFO - 2019-11-09 16:39:03 --> Router Class Initialized
INFO - 2019-11-09 16:39:03 --> Output Class Initialized
INFO - 2019-11-09 16:39:03 --> Security Class Initialized
DEBUG - 2019-11-09 16:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:39:03 --> CSRF cookie sent
INFO - 2019-11-09 16:39:03 --> CSRF token verified
INFO - 2019-11-09 16:39:03 --> Input Class Initialized
INFO - 2019-11-09 16:39:03 --> Language Class Initialized
INFO - 2019-11-09 16:39:03 --> Language Class Initialized
INFO - 2019-11-09 16:39:03 --> Config Class Initialized
INFO - 2019-11-09 16:39:03 --> Loader Class Initialized
INFO - 2019-11-09 16:39:03 --> Helper loaded: url_helper
INFO - 2019-11-09 16:39:03 --> Helper loaded: common_helper
INFO - 2019-11-09 16:39:03 --> Helper loaded: language_helper
INFO - 2019-11-09 16:39:03 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:39:03 --> Helper loaded: email_helper
INFO - 2019-11-09 16:39:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:39:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:39:03 --> Parser Class Initialized
INFO - 2019-11-09 16:39:03 --> User Agent Class Initialized
INFO - 2019-11-09 16:39:03 --> Model Class Initialized
INFO - 2019-11-09 16:39:03 --> Database Driver Class Initialized
INFO - 2019-11-09 16:39:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:39:03 --> Template Class Initialized
INFO - 2019-11-09 16:39:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:39:03 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:39:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:39:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:39:03 --> Encryption Class Initialized
INFO - 2019-11-09 16:39:03 --> Controller Class Initialized
DEBUG - 2019-11-09 16:39:03 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:39:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:39:03 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
ERROR - 2019-11-09 16:39:03 --> Could not find the language line "choose_your_coin"
DEBUG - 2019-11-09 16:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinpayments/index.php
INFO - 2019-11-09 16:39:03 --> Final output sent to browser
DEBUG - 2019-11-09 16:39:03 --> Total execution time: 0.9723
INFO - 2019-11-09 16:39:05 --> Config Class Initialized
INFO - 2019-11-09 16:39:05 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:39:05 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:39:05 --> Utf8 Class Initialized
INFO - 2019-11-09 16:39:05 --> URI Class Initialized
INFO - 2019-11-09 16:39:05 --> Router Class Initialized
INFO - 2019-11-09 16:39:05 --> Output Class Initialized
INFO - 2019-11-09 16:39:05 --> Security Class Initialized
DEBUG - 2019-11-09 16:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:39:05 --> Input Class Initialized
INFO - 2019-11-09 16:39:05 --> Language Class Initialized
INFO - 2019-11-09 16:39:05 --> Language Class Initialized
INFO - 2019-11-09 16:39:05 --> Config Class Initialized
INFO - 2019-11-09 16:39:05 --> Loader Class Initialized
INFO - 2019-11-09 16:39:05 --> Helper loaded: url_helper
INFO - 2019-11-09 16:39:05 --> Helper loaded: common_helper
INFO - 2019-11-09 16:39:05 --> Helper loaded: language_helper
INFO - 2019-11-09 16:39:05 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:39:05 --> Helper loaded: email_helper
INFO - 2019-11-09 16:39:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:39:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:39:05 --> Parser Class Initialized
INFO - 2019-11-09 16:39:05 --> User Agent Class Initialized
INFO - 2019-11-09 16:39:05 --> Model Class Initialized
INFO - 2019-11-09 16:39:05 --> Database Driver Class Initialized
INFO - 2019-11-09 16:39:05 --> Model Class Initialized
DEBUG - 2019-11-09 16:39:05 --> Template Class Initialized
INFO - 2019-11-09 16:39:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:39:05 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:39:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:39:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:39:05 --> Encryption Class Initialized
INFO - 2019-11-09 16:39:05 --> Controller Class Initialized
DEBUG - 2019-11-09 16:39:05 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
INFO - 2019-11-09 16:39:05 --> Model Class Initialized
DEBUG - 2019-11-09 16:39:08 --> orders MX_Controller Initialized
INFO - 2019-11-09 16:42:54 --> Config Class Initialized
INFO - 2019-11-09 16:42:54 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:42:54 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:42:54 --> Utf8 Class Initialized
INFO - 2019-11-09 16:42:54 --> URI Class Initialized
INFO - 2019-11-09 16:42:54 --> Router Class Initialized
INFO - 2019-11-09 16:42:54 --> Output Class Initialized
INFO - 2019-11-09 16:42:54 --> Security Class Initialized
DEBUG - 2019-11-09 16:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:42:54 --> CSRF cookie sent
INFO - 2019-11-09 16:42:54 --> Input Class Initialized
INFO - 2019-11-09 16:42:54 --> Language Class Initialized
INFO - 2019-11-09 16:42:54 --> Language Class Initialized
INFO - 2019-11-09 16:42:54 --> Config Class Initialized
INFO - 2019-11-09 16:42:54 --> Loader Class Initialized
INFO - 2019-11-09 16:42:54 --> Helper loaded: url_helper
INFO - 2019-11-09 16:42:54 --> Helper loaded: common_helper
INFO - 2019-11-09 16:42:54 --> Helper loaded: language_helper
INFO - 2019-11-09 16:42:54 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:42:54 --> Helper loaded: email_helper
INFO - 2019-11-09 16:42:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:42:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:42:54 --> Parser Class Initialized
INFO - 2019-11-09 16:42:54 --> User Agent Class Initialized
INFO - 2019-11-09 16:42:54 --> Model Class Initialized
INFO - 2019-11-09 16:42:54 --> Database Driver Class Initialized
INFO - 2019-11-09 16:42:54 --> Model Class Initialized
DEBUG - 2019-11-09 16:42:54 --> Template Class Initialized
INFO - 2019-11-09 16:42:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:42:54 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:42:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:42:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:42:55 --> Encryption Class Initialized
INFO - 2019-11-09 16:42:55 --> Controller Class Initialized
DEBUG - 2019-11-09 16:42:55 --> package MX_Controller Initialized
DEBUG - 2019-11-09 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 16:42:55 --> Model Class Initialized
INFO - 2019-11-09 16:42:55 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:42:55 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:42:55 --> Model Class Initialized
DEBUG - 2019-11-09 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:42:55 --> Model Class Initialized
DEBUG - 2019-11-09 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:42:55 --> Final output sent to browser
DEBUG - 2019-11-09 16:42:55 --> Total execution time: 1.4033
INFO - 2019-11-09 16:42:58 --> Config Class Initialized
INFO - 2019-11-09 16:42:58 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:42:58 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:42:58 --> Utf8 Class Initialized
INFO - 2019-11-09 16:42:58 --> URI Class Initialized
INFO - 2019-11-09 16:42:58 --> Router Class Initialized
INFO - 2019-11-09 16:42:58 --> Output Class Initialized
INFO - 2019-11-09 16:42:58 --> Security Class Initialized
DEBUG - 2019-11-09 16:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:42:58 --> CSRF cookie sent
INFO - 2019-11-09 16:42:58 --> CSRF token verified
INFO - 2019-11-09 16:42:58 --> Input Class Initialized
INFO - 2019-11-09 16:42:58 --> Language Class Initialized
INFO - 2019-11-09 16:42:58 --> Language Class Initialized
INFO - 2019-11-09 16:42:58 --> Config Class Initialized
INFO - 2019-11-09 16:42:58 --> Loader Class Initialized
INFO - 2019-11-09 16:42:58 --> Helper loaded: url_helper
INFO - 2019-11-09 16:42:58 --> Helper loaded: common_helper
INFO - 2019-11-09 16:42:58 --> Helper loaded: language_helper
INFO - 2019-11-09 16:42:58 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:42:59 --> Helper loaded: email_helper
INFO - 2019-11-09 16:42:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:42:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:42:59 --> Parser Class Initialized
INFO - 2019-11-09 16:42:59 --> User Agent Class Initialized
INFO - 2019-11-09 16:42:59 --> Model Class Initialized
INFO - 2019-11-09 16:42:59 --> Database Driver Class Initialized
INFO - 2019-11-09 16:42:59 --> Model Class Initialized
DEBUG - 2019-11-09 16:42:59 --> Template Class Initialized
INFO - 2019-11-09 16:42:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:42:59 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:42:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:42:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:42:59 --> Encryption Class Initialized
INFO - 2019-11-09 16:42:59 --> Controller Class Initialized
DEBUG - 2019-11-09 16:42:59 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:42:59 --> Model Class Initialized
INFO - 2019-11-09 16:42:59 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:42:59 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:42:59 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:42:59 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:42:59 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:42:59 --> Model Class Initialized
DEBUG - 2019-11-09 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:42:59 --> Model Class Initialized
DEBUG - 2019-11-09 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:42:59 --> Final output sent to browser
DEBUG - 2019-11-09 16:42:59 --> Total execution time: 1.3436
INFO - 2019-11-09 16:43:06 --> Config Class Initialized
INFO - 2019-11-09 16:43:07 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:43:07 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:43:07 --> Utf8 Class Initialized
INFO - 2019-11-09 16:43:07 --> URI Class Initialized
INFO - 2019-11-09 16:43:07 --> Router Class Initialized
INFO - 2019-11-09 16:43:07 --> Output Class Initialized
INFO - 2019-11-09 16:43:07 --> Security Class Initialized
DEBUG - 2019-11-09 16:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:43:07 --> CSRF cookie sent
INFO - 2019-11-09 16:43:07 --> CSRF token verified
INFO - 2019-11-09 16:43:07 --> Input Class Initialized
INFO - 2019-11-09 16:43:07 --> Language Class Initialized
INFO - 2019-11-09 16:43:07 --> Language Class Initialized
INFO - 2019-11-09 16:43:07 --> Config Class Initialized
INFO - 2019-11-09 16:43:07 --> Loader Class Initialized
INFO - 2019-11-09 16:43:07 --> Helper loaded: url_helper
INFO - 2019-11-09 16:43:07 --> Helper loaded: common_helper
INFO - 2019-11-09 16:43:07 --> Helper loaded: language_helper
INFO - 2019-11-09 16:43:07 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:43:07 --> Helper loaded: email_helper
INFO - 2019-11-09 16:43:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:43:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:43:07 --> Parser Class Initialized
INFO - 2019-11-09 16:43:07 --> User Agent Class Initialized
INFO - 2019-11-09 16:43:07 --> Model Class Initialized
INFO - 2019-11-09 16:43:07 --> Database Driver Class Initialized
INFO - 2019-11-09 16:43:07 --> Model Class Initialized
DEBUG - 2019-11-09 16:43:07 --> Template Class Initialized
INFO - 2019-11-09 16:43:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:43:07 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:43:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:43:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:43:07 --> Encryption Class Initialized
INFO - 2019-11-09 16:43:07 --> Controller Class Initialized
DEBUG - 2019-11-09 16:43:07 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:43:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:43:07 --> Model Class Initialized
DEBUG - 2019-11-09 16:43:07 --> coinpayments MX_Controller Initialized
DEBUG - 2019-11-09 16:43:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
ERROR - 2019-11-09 16:43:07 --> Could not find the language line "choose_your_coin"
DEBUG - 2019-11-09 16:43:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinpayments/index.php
INFO - 2019-11-09 16:43:07 --> Final output sent to browser
DEBUG - 2019-11-09 16:43:07 --> Total execution time: 0.9412
INFO - 2019-11-09 16:43:12 --> Config Class Initialized
INFO - 2019-11-09 16:43:12 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:43:12 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:43:12 --> Utf8 Class Initialized
INFO - 2019-11-09 16:43:12 --> URI Class Initialized
INFO - 2019-11-09 16:43:12 --> Router Class Initialized
INFO - 2019-11-09 16:43:12 --> Output Class Initialized
INFO - 2019-11-09 16:43:12 --> Security Class Initialized
DEBUG - 2019-11-09 16:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:43:12 --> CSRF cookie sent
INFO - 2019-11-09 16:43:12 --> CSRF token verified
INFO - 2019-11-09 16:43:12 --> Input Class Initialized
INFO - 2019-11-09 16:43:12 --> Language Class Initialized
INFO - 2019-11-09 16:43:12 --> Language Class Initialized
INFO - 2019-11-09 16:43:13 --> Config Class Initialized
INFO - 2019-11-09 16:43:13 --> Loader Class Initialized
INFO - 2019-11-09 16:43:13 --> Helper loaded: url_helper
INFO - 2019-11-09 16:43:13 --> Helper loaded: common_helper
INFO - 2019-11-09 16:43:13 --> Helper loaded: language_helper
INFO - 2019-11-09 16:43:13 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:43:13 --> Helper loaded: email_helper
INFO - 2019-11-09 16:43:13 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:43:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:43:13 --> Parser Class Initialized
INFO - 2019-11-09 16:43:13 --> User Agent Class Initialized
INFO - 2019-11-09 16:43:13 --> Model Class Initialized
INFO - 2019-11-09 16:43:13 --> Database Driver Class Initialized
INFO - 2019-11-09 16:43:13 --> Model Class Initialized
DEBUG - 2019-11-09 16:43:13 --> Template Class Initialized
INFO - 2019-11-09 16:43:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:43:13 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:43:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:43:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:43:13 --> Encryption Class Initialized
INFO - 2019-11-09 16:43:13 --> Controller Class Initialized
DEBUG - 2019-11-09 16:43:13 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:43:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:43:13 --> Model Class Initialized
INFO - 2019-11-09 16:43:13 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:43:13 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:43:13 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:43:13 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:43:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:43:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:43:13 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:43:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:43:13 --> Model Class Initialized
DEBUG - 2019-11-09 16:43:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:43:13 --> Model Class Initialized
DEBUG - 2019-11-09 16:43:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:43:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:43:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:43:13 --> Final output sent to browser
DEBUG - 2019-11-09 16:43:14 --> Total execution time: 1.3111
INFO - 2019-11-09 16:43:21 --> Config Class Initialized
INFO - 2019-11-09 16:43:21 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:43:21 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:43:21 --> Utf8 Class Initialized
INFO - 2019-11-09 16:43:21 --> URI Class Initialized
INFO - 2019-11-09 16:43:21 --> Router Class Initialized
INFO - 2019-11-09 16:43:21 --> Output Class Initialized
INFO - 2019-11-09 16:43:21 --> Security Class Initialized
DEBUG - 2019-11-09 16:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:43:22 --> CSRF cookie sent
INFO - 2019-11-09 16:43:22 --> CSRF token verified
INFO - 2019-11-09 16:43:22 --> Input Class Initialized
INFO - 2019-11-09 16:43:22 --> Language Class Initialized
INFO - 2019-11-09 16:43:22 --> Language Class Initialized
INFO - 2019-11-09 16:43:22 --> Config Class Initialized
INFO - 2019-11-09 16:43:22 --> Loader Class Initialized
INFO - 2019-11-09 16:43:22 --> Helper loaded: url_helper
INFO - 2019-11-09 16:43:22 --> Helper loaded: common_helper
INFO - 2019-11-09 16:43:22 --> Helper loaded: language_helper
INFO - 2019-11-09 16:43:22 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:43:22 --> Helper loaded: email_helper
INFO - 2019-11-09 16:43:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:43:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:43:22 --> Parser Class Initialized
INFO - 2019-11-09 16:43:22 --> User Agent Class Initialized
INFO - 2019-11-09 16:43:22 --> Model Class Initialized
INFO - 2019-11-09 16:43:22 --> Database Driver Class Initialized
INFO - 2019-11-09 16:43:22 --> Model Class Initialized
DEBUG - 2019-11-09 16:43:22 --> Template Class Initialized
INFO - 2019-11-09 16:43:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:43:22 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:43:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:43:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:43:22 --> Encryption Class Initialized
INFO - 2019-11-09 16:43:22 --> Controller Class Initialized
DEBUG - 2019-11-09 16:43:22 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:43:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:43:22 --> Model Class Initialized
DEBUG - 2019-11-09 16:43:22 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 16:43:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 16:43:24 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 16:43:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 16:43:24 --> Final output sent to browser
DEBUG - 2019-11-09 16:43:24 --> Total execution time: 2.3033
INFO - 2019-11-09 16:45:19 --> Config Class Initialized
INFO - 2019-11-09 16:45:19 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:45:19 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:45:19 --> Utf8 Class Initialized
INFO - 2019-11-09 16:45:19 --> URI Class Initialized
INFO - 2019-11-09 16:45:19 --> Router Class Initialized
INFO - 2019-11-09 16:45:19 --> Output Class Initialized
INFO - 2019-11-09 16:45:19 --> Security Class Initialized
DEBUG - 2019-11-09 16:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:45:19 --> Input Class Initialized
INFO - 2019-11-09 16:45:19 --> Language Class Initialized
INFO - 2019-11-09 16:45:19 --> Language Class Initialized
INFO - 2019-11-09 16:45:19 --> Config Class Initialized
INFO - 2019-11-09 16:45:19 --> Loader Class Initialized
INFO - 2019-11-09 16:45:19 --> Helper loaded: url_helper
INFO - 2019-11-09 16:45:19 --> Helper loaded: common_helper
INFO - 2019-11-09 16:45:19 --> Helper loaded: language_helper
INFO - 2019-11-09 16:45:19 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:45:19 --> Helper loaded: email_helper
INFO - 2019-11-09 16:45:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:45:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:45:19 --> Parser Class Initialized
INFO - 2019-11-09 16:45:19 --> User Agent Class Initialized
INFO - 2019-11-09 16:45:20 --> Model Class Initialized
INFO - 2019-11-09 16:45:20 --> Database Driver Class Initialized
INFO - 2019-11-09 16:45:20 --> Model Class Initialized
DEBUG - 2019-11-09 16:45:20 --> Template Class Initialized
INFO - 2019-11-09 16:45:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:45:20 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:45:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:45:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:45:20 --> Encryption Class Initialized
INFO - 2019-11-09 16:45:20 --> Controller Class Initialized
DEBUG - 2019-11-09 16:45:20 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 16:45:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2019-11-09 16:45:20 --> Model Class Initialized
ERROR - 2019-11-09 16:45:20 --> Severity: Notice --> Undefined variable: currency2 D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\stripe.php 50
INFO - 2019-11-09 16:45:20 --> Config Class Initialized
INFO - 2019-11-09 16:45:20 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:45:20 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:45:20 --> Utf8 Class Initialized
INFO - 2019-11-09 16:45:20 --> URI Class Initialized
DEBUG - 2019-11-09 16:45:20 --> No URI present. Default controller set.
INFO - 2019-11-09 16:45:20 --> Router Class Initialized
INFO - 2019-11-09 16:45:20 --> Output Class Initialized
INFO - 2019-11-09 16:45:20 --> Security Class Initialized
DEBUG - 2019-11-09 16:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:45:20 --> CSRF cookie sent
INFO - 2019-11-09 16:45:20 --> Input Class Initialized
INFO - 2019-11-09 16:45:20 --> Language Class Initialized
INFO - 2019-11-09 16:45:20 --> Language Class Initialized
INFO - 2019-11-09 16:45:20 --> Config Class Initialized
INFO - 2019-11-09 16:45:20 --> Loader Class Initialized
INFO - 2019-11-09 16:45:20 --> Helper loaded: url_helper
INFO - 2019-11-09 16:45:20 --> Helper loaded: common_helper
INFO - 2019-11-09 16:45:20 --> Helper loaded: language_helper
INFO - 2019-11-09 16:45:20 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:45:20 --> Helper loaded: email_helper
INFO - 2019-11-09 16:45:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:45:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:45:20 --> Parser Class Initialized
INFO - 2019-11-09 16:45:20 --> User Agent Class Initialized
INFO - 2019-11-09 16:45:20 --> Model Class Initialized
INFO - 2019-11-09 16:45:20 --> Database Driver Class Initialized
INFO - 2019-11-09 16:45:20 --> Model Class Initialized
DEBUG - 2019-11-09 16:45:20 --> Template Class Initialized
INFO - 2019-11-09 16:45:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:45:21 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:45:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:45:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:45:21 --> Encryption Class Initialized
DEBUG - 2019-11-09 16:45:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:45:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 16:45:21 --> Controller Class Initialized
DEBUG - 2019-11-09 16:45:21 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 16:45:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 16:45:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 16:45:21 --> Model Class Initialized
INFO - 2019-11-09 16:45:21 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:45:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 16:45:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 16:45:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 16:45:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 16:45:21 --> Final output sent to browser
DEBUG - 2019-11-09 16:45:21 --> Total execution time: 1.1188
INFO - 2019-11-09 16:46:02 --> Config Class Initialized
INFO - 2019-11-09 16:46:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:46:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:46:02 --> Utf8 Class Initialized
INFO - 2019-11-09 16:46:02 --> URI Class Initialized
INFO - 2019-11-09 16:46:02 --> Router Class Initialized
INFO - 2019-11-09 16:46:02 --> Output Class Initialized
INFO - 2019-11-09 16:46:02 --> Security Class Initialized
DEBUG - 2019-11-09 16:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:46:02 --> CSRF cookie sent
INFO - 2019-11-09 16:46:02 --> Input Class Initialized
INFO - 2019-11-09 16:46:02 --> Language Class Initialized
INFO - 2019-11-09 16:46:02 --> Language Class Initialized
INFO - 2019-11-09 16:46:02 --> Config Class Initialized
INFO - 2019-11-09 16:46:02 --> Loader Class Initialized
INFO - 2019-11-09 16:46:02 --> Helper loaded: url_helper
INFO - 2019-11-09 16:46:02 --> Helper loaded: common_helper
INFO - 2019-11-09 16:46:02 --> Helper loaded: language_helper
INFO - 2019-11-09 16:46:02 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:46:02 --> Helper loaded: email_helper
INFO - 2019-11-09 16:46:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:46:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:46:02 --> Parser Class Initialized
INFO - 2019-11-09 16:46:02 --> User Agent Class Initialized
INFO - 2019-11-09 16:46:02 --> Model Class Initialized
INFO - 2019-11-09 16:46:02 --> Database Driver Class Initialized
INFO - 2019-11-09 16:46:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:03 --> Template Class Initialized
INFO - 2019-11-09 16:46:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:46:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:46:03 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:46:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:46:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:46:03 --> Encryption Class Initialized
INFO - 2019-11-09 16:46:03 --> Controller Class Initialized
DEBUG - 2019-11-09 16:46:03 --> package MX_Controller Initialized
DEBUG - 2019-11-09 16:46:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 16:46:03 --> Model Class Initialized
INFO - 2019-11-09 16:46:03 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:46:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:46:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:46:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:46:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:46:03 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 16:46:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 16:46:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:46:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:46:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:46:03 --> Final output sent to browser
DEBUG - 2019-11-09 16:46:03 --> Total execution time: 1.3619
INFO - 2019-11-09 16:46:07 --> Config Class Initialized
INFO - 2019-11-09 16:46:07 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:46:07 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:46:07 --> Utf8 Class Initialized
INFO - 2019-11-09 16:46:07 --> URI Class Initialized
INFO - 2019-11-09 16:46:07 --> Router Class Initialized
INFO - 2019-11-09 16:46:07 --> Output Class Initialized
INFO - 2019-11-09 16:46:07 --> Security Class Initialized
DEBUG - 2019-11-09 16:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:46:07 --> CSRF cookie sent
INFO - 2019-11-09 16:46:07 --> CSRF token verified
INFO - 2019-11-09 16:46:07 --> Input Class Initialized
INFO - 2019-11-09 16:46:07 --> Language Class Initialized
INFO - 2019-11-09 16:46:07 --> Language Class Initialized
INFO - 2019-11-09 16:46:07 --> Config Class Initialized
INFO - 2019-11-09 16:46:07 --> Loader Class Initialized
INFO - 2019-11-09 16:46:07 --> Helper loaded: url_helper
INFO - 2019-11-09 16:46:07 --> Helper loaded: common_helper
INFO - 2019-11-09 16:46:07 --> Helper loaded: language_helper
INFO - 2019-11-09 16:46:07 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:46:07 --> Helper loaded: email_helper
INFO - 2019-11-09 16:46:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:46:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:46:07 --> Parser Class Initialized
INFO - 2019-11-09 16:46:07 --> User Agent Class Initialized
INFO - 2019-11-09 16:46:07 --> Model Class Initialized
INFO - 2019-11-09 16:46:07 --> Database Driver Class Initialized
INFO - 2019-11-09 16:46:07 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:07 --> Template Class Initialized
INFO - 2019-11-09 16:46:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:46:07 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:46:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:46:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:46:07 --> Encryption Class Initialized
INFO - 2019-11-09 16:46:07 --> Controller Class Initialized
DEBUG - 2019-11-09 16:46:07 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:46:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:46:07 --> Model Class Initialized
INFO - 2019-11-09 16:46:07 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:46:07 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:46:07 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:46:07 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:46:08 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:46:08 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:46:08 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:46:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:46:08 --> Final output sent to browser
DEBUG - 2019-11-09 16:46:08 --> Total execution time: 1.2629
INFO - 2019-11-09 16:46:17 --> Config Class Initialized
INFO - 2019-11-09 16:46:17 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:46:17 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:46:17 --> Utf8 Class Initialized
INFO - 2019-11-09 16:46:17 --> URI Class Initialized
INFO - 2019-11-09 16:46:17 --> Router Class Initialized
INFO - 2019-11-09 16:46:18 --> Output Class Initialized
INFO - 2019-11-09 16:46:18 --> Security Class Initialized
DEBUG - 2019-11-09 16:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:46:18 --> CSRF cookie sent
INFO - 2019-11-09 16:46:18 --> CSRF token verified
INFO - 2019-11-09 16:46:18 --> Input Class Initialized
INFO - 2019-11-09 16:46:18 --> Language Class Initialized
INFO - 2019-11-09 16:46:18 --> Language Class Initialized
INFO - 2019-11-09 16:46:18 --> Config Class Initialized
INFO - 2019-11-09 16:46:18 --> Loader Class Initialized
INFO - 2019-11-09 16:46:18 --> Helper loaded: url_helper
INFO - 2019-11-09 16:46:18 --> Helper loaded: common_helper
INFO - 2019-11-09 16:46:18 --> Helper loaded: language_helper
INFO - 2019-11-09 16:46:18 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:46:18 --> Helper loaded: email_helper
INFO - 2019-11-09 16:46:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:46:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:46:18 --> Parser Class Initialized
INFO - 2019-11-09 16:46:18 --> User Agent Class Initialized
INFO - 2019-11-09 16:46:18 --> Model Class Initialized
INFO - 2019-11-09 16:46:18 --> Database Driver Class Initialized
INFO - 2019-11-09 16:46:18 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:18 --> Template Class Initialized
INFO - 2019-11-09 16:46:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:46:18 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:46:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:46:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:46:18 --> Encryption Class Initialized
INFO - 2019-11-09 16:46:18 --> Controller Class Initialized
DEBUG - 2019-11-09 16:46:18 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:46:18 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:18 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 16:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 16:46:18 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 16:46:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 16:46:18 --> Final output sent to browser
DEBUG - 2019-11-09 16:46:18 --> Total execution time: 0.9910
INFO - 2019-11-09 16:46:40 --> Config Class Initialized
INFO - 2019-11-09 16:46:40 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:46:40 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:46:40 --> Utf8 Class Initialized
INFO - 2019-11-09 16:46:40 --> URI Class Initialized
INFO - 2019-11-09 16:46:40 --> Router Class Initialized
INFO - 2019-11-09 16:46:40 --> Output Class Initialized
INFO - 2019-11-09 16:46:40 --> Security Class Initialized
DEBUG - 2019-11-09 16:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:46:40 --> Input Class Initialized
INFO - 2019-11-09 16:46:40 --> Language Class Initialized
INFO - 2019-11-09 16:46:41 --> Language Class Initialized
INFO - 2019-11-09 16:46:41 --> Config Class Initialized
INFO - 2019-11-09 16:46:41 --> Loader Class Initialized
INFO - 2019-11-09 16:46:41 --> Helper loaded: url_helper
INFO - 2019-11-09 16:46:41 --> Helper loaded: common_helper
INFO - 2019-11-09 16:46:41 --> Helper loaded: language_helper
INFO - 2019-11-09 16:46:41 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:46:41 --> Helper loaded: email_helper
INFO - 2019-11-09 16:46:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:46:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:46:41 --> Parser Class Initialized
INFO - 2019-11-09 16:46:41 --> User Agent Class Initialized
INFO - 2019-11-09 16:46:41 --> Model Class Initialized
INFO - 2019-11-09 16:46:41 --> Database Driver Class Initialized
INFO - 2019-11-09 16:46:41 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:41 --> Template Class Initialized
INFO - 2019-11-09 16:46:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:46:41 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:46:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:46:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:46:41 --> Encryption Class Initialized
INFO - 2019-11-09 16:46:41 --> Controller Class Initialized
DEBUG - 2019-11-09 16:46:41 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 16:46:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2019-11-09 16:46:41 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:43 --> orders MX_Controller Initialized
INFO - 2019-11-09 16:46:43 --> Config Class Initialized
INFO - 2019-11-09 16:46:43 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:46:43 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:46:43 --> Utf8 Class Initialized
INFO - 2019-11-09 16:46:43 --> URI Class Initialized
INFO - 2019-11-09 16:46:43 --> Router Class Initialized
INFO - 2019-11-09 16:46:43 --> Output Class Initialized
INFO - 2019-11-09 16:46:43 --> Security Class Initialized
DEBUG - 2019-11-09 16:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:46:43 --> CSRF cookie sent
INFO - 2019-11-09 16:46:43 --> Input Class Initialized
INFO - 2019-11-09 16:46:43 --> Language Class Initialized
INFO - 2019-11-09 16:46:43 --> Language Class Initialized
INFO - 2019-11-09 16:46:43 --> Config Class Initialized
INFO - 2019-11-09 16:46:43 --> Loader Class Initialized
INFO - 2019-11-09 16:46:43 --> Helper loaded: url_helper
INFO - 2019-11-09 16:46:43 --> Helper loaded: common_helper
INFO - 2019-11-09 16:46:43 --> Helper loaded: language_helper
INFO - 2019-11-09 16:46:43 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:46:43 --> Helper loaded: email_helper
INFO - 2019-11-09 16:46:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:46:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:46:43 --> Parser Class Initialized
INFO - 2019-11-09 16:46:43 --> User Agent Class Initialized
INFO - 2019-11-09 16:46:43 --> Model Class Initialized
INFO - 2019-11-09 16:46:43 --> Database Driver Class Initialized
INFO - 2019-11-09 16:46:43 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:43 --> Template Class Initialized
INFO - 2019-11-09 16:46:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:46:43 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:46:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:46:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:46:43 --> Encryption Class Initialized
INFO - 2019-11-09 16:46:43 --> Controller Class Initialized
DEBUG - 2019-11-09 16:46:43 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:46:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:46:44 --> Model Class Initialized
INFO - 2019-11-09 16:46:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:46:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-09 16:46:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:46:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:46:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:46:44 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:46:44 --> Model Class Initialized
DEBUG - 2019-11-09 16:46:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:46:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:46:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:46:44 --> Final output sent to browser
DEBUG - 2019-11-09 16:46:44 --> Total execution time: 1.0821
INFO - 2019-11-09 16:58:16 --> Config Class Initialized
INFO - 2019-11-09 16:58:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:58:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:58:16 --> Utf8 Class Initialized
INFO - 2019-11-09 16:58:16 --> URI Class Initialized
INFO - 2019-11-09 16:58:17 --> Router Class Initialized
INFO - 2019-11-09 16:58:17 --> Output Class Initialized
INFO - 2019-11-09 16:58:17 --> Security Class Initialized
DEBUG - 2019-11-09 16:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:58:17 --> CSRF cookie sent
INFO - 2019-11-09 16:58:17 --> Input Class Initialized
INFO - 2019-11-09 16:58:17 --> Language Class Initialized
INFO - 2019-11-09 16:58:17 --> Language Class Initialized
INFO - 2019-11-09 16:58:17 --> Config Class Initialized
INFO - 2019-11-09 16:58:17 --> Loader Class Initialized
INFO - 2019-11-09 16:58:17 --> Helper loaded: url_helper
INFO - 2019-11-09 16:58:17 --> Helper loaded: common_helper
INFO - 2019-11-09 16:58:17 --> Helper loaded: language_helper
INFO - 2019-11-09 16:58:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:58:17 --> Helper loaded: email_helper
INFO - 2019-11-09 16:58:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:58:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:58:17 --> Parser Class Initialized
INFO - 2019-11-09 16:58:17 --> User Agent Class Initialized
INFO - 2019-11-09 16:58:17 --> Model Class Initialized
INFO - 2019-11-09 16:58:17 --> Database Driver Class Initialized
INFO - 2019-11-09 16:58:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:58:17 --> Template Class Initialized
INFO - 2019-11-09 16:58:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:58:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:58:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:58:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:58:17 --> Encryption Class Initialized
INFO - 2019-11-09 16:58:17 --> Controller Class Initialized
DEBUG - 2019-11-09 16:58:17 --> package MX_Controller Initialized
DEBUG - 2019-11-09 16:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 16:58:17 --> Model Class Initialized
INFO - 2019-11-09 16:58:17 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 16:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:58:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:58:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:58:17 --> Model Class Initialized
DEBUG - 2019-11-09 16:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 16:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 16:58:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:58:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:58:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:58:18 --> Final output sent to browser
DEBUG - 2019-11-09 16:58:18 --> Total execution time: 1.2255
INFO - 2019-11-09 16:58:22 --> Config Class Initialized
INFO - 2019-11-09 16:58:22 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:58:22 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:58:22 --> Utf8 Class Initialized
INFO - 2019-11-09 16:58:22 --> URI Class Initialized
INFO - 2019-11-09 16:58:22 --> Router Class Initialized
INFO - 2019-11-09 16:58:23 --> Output Class Initialized
INFO - 2019-11-09 16:58:23 --> Security Class Initialized
DEBUG - 2019-11-09 16:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:58:23 --> CSRF cookie sent
INFO - 2019-11-09 16:58:23 --> CSRF token verified
INFO - 2019-11-09 16:58:23 --> Input Class Initialized
INFO - 2019-11-09 16:58:23 --> Language Class Initialized
INFO - 2019-11-09 16:58:23 --> Language Class Initialized
INFO - 2019-11-09 16:58:23 --> Config Class Initialized
INFO - 2019-11-09 16:58:23 --> Loader Class Initialized
INFO - 2019-11-09 16:58:23 --> Helper loaded: url_helper
INFO - 2019-11-09 16:58:23 --> Helper loaded: common_helper
INFO - 2019-11-09 16:58:23 --> Helper loaded: language_helper
INFO - 2019-11-09 16:58:23 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:58:23 --> Helper loaded: email_helper
INFO - 2019-11-09 16:58:23 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:58:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:58:23 --> Parser Class Initialized
INFO - 2019-11-09 16:58:23 --> User Agent Class Initialized
INFO - 2019-11-09 16:58:23 --> Model Class Initialized
INFO - 2019-11-09 16:58:23 --> Database Driver Class Initialized
INFO - 2019-11-09 16:58:23 --> Model Class Initialized
DEBUG - 2019-11-09 16:58:23 --> Template Class Initialized
INFO - 2019-11-09 16:58:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:58:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:58:23 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:58:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:58:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:58:23 --> Encryption Class Initialized
INFO - 2019-11-09 16:58:23 --> Controller Class Initialized
DEBUG - 2019-11-09 16:58:23 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:58:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:58:23 --> Model Class Initialized
INFO - 2019-11-09 16:58:23 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:58:23 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:58:23 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:58:23 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:58:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:58:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:58:23 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:58:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:58:23 --> Model Class Initialized
DEBUG - 2019-11-09 16:58:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:58:23 --> Model Class Initialized
DEBUG - 2019-11-09 16:58:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:58:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:58:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:58:24 --> Final output sent to browser
DEBUG - 2019-11-09 16:58:24 --> Total execution time: 1.1981
INFO - 2019-11-09 16:59:15 --> Config Class Initialized
INFO - 2019-11-09 16:59:15 --> Hooks Class Initialized
DEBUG - 2019-11-09 16:59:15 --> UTF-8 Support Enabled
INFO - 2019-11-09 16:59:15 --> Utf8 Class Initialized
INFO - 2019-11-09 16:59:15 --> URI Class Initialized
INFO - 2019-11-09 16:59:15 --> Router Class Initialized
INFO - 2019-11-09 16:59:15 --> Output Class Initialized
INFO - 2019-11-09 16:59:15 --> Security Class Initialized
DEBUG - 2019-11-09 16:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 16:59:15 --> CSRF cookie sent
INFO - 2019-11-09 16:59:15 --> CSRF token verified
INFO - 2019-11-09 16:59:15 --> Input Class Initialized
INFO - 2019-11-09 16:59:15 --> Language Class Initialized
INFO - 2019-11-09 16:59:15 --> Language Class Initialized
INFO - 2019-11-09 16:59:15 --> Config Class Initialized
INFO - 2019-11-09 16:59:15 --> Loader Class Initialized
INFO - 2019-11-09 16:59:15 --> Helper loaded: url_helper
INFO - 2019-11-09 16:59:15 --> Helper loaded: common_helper
INFO - 2019-11-09 16:59:15 --> Helper loaded: language_helper
INFO - 2019-11-09 16:59:15 --> Helper loaded: cookie_helper
INFO - 2019-11-09 16:59:15 --> Helper loaded: email_helper
INFO - 2019-11-09 16:59:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 16:59:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 16:59:15 --> Parser Class Initialized
INFO - 2019-11-09 16:59:15 --> User Agent Class Initialized
INFO - 2019-11-09 16:59:15 --> Model Class Initialized
INFO - 2019-11-09 16:59:15 --> Database Driver Class Initialized
INFO - 2019-11-09 16:59:15 --> Model Class Initialized
DEBUG - 2019-11-09 16:59:15 --> Template Class Initialized
INFO - 2019-11-09 16:59:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 16:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 16:59:15 --> Pagination Class Initialized
DEBUG - 2019-11-09 16:59:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 16:59:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 16:59:15 --> Encryption Class Initialized
INFO - 2019-11-09 16:59:15 --> Controller Class Initialized
DEBUG - 2019-11-09 16:59:15 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 16:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 16:59:15 --> Model Class Initialized
INFO - 2019-11-09 16:59:16 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 16:59:16 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 16:59:16 --> Could not find the language line "paystack"
ERROR - 2019-11-09 16:59:16 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 16:59:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 16:59:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 16:59:16 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 16:59:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 16:59:16 --> Model Class Initialized
DEBUG - 2019-11-09 16:59:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 16:59:16 --> Model Class Initialized
DEBUG - 2019-11-09 16:59:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 16:59:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 16:59:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 16:59:16 --> Final output sent to browser
DEBUG - 2019-11-09 16:59:16 --> Total execution time: 1.1989
INFO - 2019-11-09 17:00:09 --> Config Class Initialized
INFO - 2019-11-09 17:00:09 --> Hooks Class Initialized
DEBUG - 2019-11-09 17:00:09 --> UTF-8 Support Enabled
INFO - 2019-11-09 17:00:09 --> Utf8 Class Initialized
INFO - 2019-11-09 17:00:09 --> URI Class Initialized
INFO - 2019-11-09 17:00:09 --> Router Class Initialized
INFO - 2019-11-09 17:00:09 --> Output Class Initialized
INFO - 2019-11-09 17:00:09 --> Security Class Initialized
DEBUG - 2019-11-09 17:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 17:00:10 --> CSRF cookie sent
INFO - 2019-11-09 17:00:10 --> CSRF token verified
INFO - 2019-11-09 17:00:10 --> Input Class Initialized
INFO - 2019-11-09 17:00:10 --> Language Class Initialized
INFO - 2019-11-09 17:00:10 --> Language Class Initialized
INFO - 2019-11-09 17:00:10 --> Config Class Initialized
INFO - 2019-11-09 17:00:10 --> Loader Class Initialized
INFO - 2019-11-09 17:00:10 --> Helper loaded: url_helper
INFO - 2019-11-09 17:00:10 --> Helper loaded: common_helper
INFO - 2019-11-09 17:00:10 --> Helper loaded: language_helper
INFO - 2019-11-09 17:00:10 --> Helper loaded: cookie_helper
INFO - 2019-11-09 17:00:10 --> Helper loaded: email_helper
INFO - 2019-11-09 17:00:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 17:00:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 17:00:10 --> Parser Class Initialized
INFO - 2019-11-09 17:00:10 --> User Agent Class Initialized
INFO - 2019-11-09 17:00:10 --> Model Class Initialized
INFO - 2019-11-09 17:00:10 --> Database Driver Class Initialized
INFO - 2019-11-09 17:00:10 --> Model Class Initialized
DEBUG - 2019-11-09 17:00:10 --> Template Class Initialized
INFO - 2019-11-09 17:00:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 17:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 17:00:10 --> Pagination Class Initialized
DEBUG - 2019-11-09 17:00:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 17:00:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 17:00:10 --> Encryption Class Initialized
INFO - 2019-11-09 17:00:10 --> Controller Class Initialized
DEBUG - 2019-11-09 17:00:10 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 17:00:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 17:00:10 --> Model Class Initialized
INFO - 2019-11-09 17:00:10 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 17:00:10 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 17:00:10 --> Could not find the language line "paystack"
ERROR - 2019-11-09 17:00:10 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 17:00:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 17:00:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 17:00:10 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 17:00:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 17:00:10 --> Model Class Initialized
DEBUG - 2019-11-09 17:00:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 17:00:10 --> Model Class Initialized
DEBUG - 2019-11-09 17:00:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 17:00:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 17:00:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 17:00:11 --> Final output sent to browser
DEBUG - 2019-11-09 17:00:11 --> Total execution time: 1.2497
INFO - 2019-11-09 17:00:26 --> Config Class Initialized
INFO - 2019-11-09 17:00:26 --> Hooks Class Initialized
DEBUG - 2019-11-09 17:00:26 --> UTF-8 Support Enabled
INFO - 2019-11-09 17:00:26 --> Utf8 Class Initialized
INFO - 2019-11-09 17:00:26 --> URI Class Initialized
INFO - 2019-11-09 17:00:26 --> Router Class Initialized
INFO - 2019-11-09 17:00:26 --> Output Class Initialized
INFO - 2019-11-09 17:00:26 --> Security Class Initialized
DEBUG - 2019-11-09 17:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 17:00:26 --> CSRF cookie sent
INFO - 2019-11-09 17:00:26 --> CSRF token verified
INFO - 2019-11-09 17:00:26 --> Input Class Initialized
INFO - 2019-11-09 17:00:26 --> Language Class Initialized
INFO - 2019-11-09 17:00:26 --> Language Class Initialized
INFO - 2019-11-09 17:00:26 --> Config Class Initialized
INFO - 2019-11-09 17:00:26 --> Loader Class Initialized
INFO - 2019-11-09 17:00:26 --> Helper loaded: url_helper
INFO - 2019-11-09 17:00:26 --> Helper loaded: common_helper
INFO - 2019-11-09 17:00:26 --> Helper loaded: language_helper
INFO - 2019-11-09 17:00:26 --> Helper loaded: cookie_helper
INFO - 2019-11-09 17:00:26 --> Helper loaded: email_helper
INFO - 2019-11-09 17:00:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 17:00:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 17:00:26 --> Parser Class Initialized
INFO - 2019-11-09 17:00:26 --> User Agent Class Initialized
INFO - 2019-11-09 17:00:26 --> Model Class Initialized
INFO - 2019-11-09 17:00:26 --> Database Driver Class Initialized
INFO - 2019-11-09 17:00:27 --> Model Class Initialized
DEBUG - 2019-11-09 17:00:27 --> Template Class Initialized
INFO - 2019-11-09 17:00:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 17:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 17:00:27 --> Pagination Class Initialized
DEBUG - 2019-11-09 17:00:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 17:00:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 17:00:27 --> Encryption Class Initialized
INFO - 2019-11-09 17:00:27 --> Controller Class Initialized
DEBUG - 2019-11-09 17:00:27 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 17:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 17:00:27 --> Model Class Initialized
INFO - 2019-11-09 17:00:27 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 17:00:27 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 17:00:27 --> Could not find the language line "paystack"
ERROR - 2019-11-09 17:00:27 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 17:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 17:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 17:00:27 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 17:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 17:00:27 --> Model Class Initialized
DEBUG - 2019-11-09 17:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 17:00:27 --> Model Class Initialized
DEBUG - 2019-11-09 17:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 17:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 17:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 17:00:27 --> Final output sent to browser
DEBUG - 2019-11-09 17:00:27 --> Total execution time: 1.2205
INFO - 2019-11-09 17:01:42 --> Config Class Initialized
INFO - 2019-11-09 17:01:42 --> Hooks Class Initialized
DEBUG - 2019-11-09 17:01:42 --> UTF-8 Support Enabled
INFO - 2019-11-09 17:01:42 --> Utf8 Class Initialized
INFO - 2019-11-09 17:01:42 --> URI Class Initialized
INFO - 2019-11-09 17:01:42 --> Router Class Initialized
INFO - 2019-11-09 17:01:42 --> Output Class Initialized
INFO - 2019-11-09 17:01:42 --> Security Class Initialized
DEBUG - 2019-11-09 17:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 17:01:42 --> CSRF cookie sent
INFO - 2019-11-09 17:01:42 --> CSRF token verified
INFO - 2019-11-09 17:01:42 --> Input Class Initialized
INFO - 2019-11-09 17:01:42 --> Language Class Initialized
INFO - 2019-11-09 17:01:42 --> Language Class Initialized
INFO - 2019-11-09 17:01:42 --> Config Class Initialized
INFO - 2019-11-09 17:01:42 --> Loader Class Initialized
INFO - 2019-11-09 17:01:42 --> Helper loaded: url_helper
INFO - 2019-11-09 17:01:42 --> Helper loaded: common_helper
INFO - 2019-11-09 17:01:42 --> Helper loaded: language_helper
INFO - 2019-11-09 17:01:42 --> Helper loaded: cookie_helper
INFO - 2019-11-09 17:01:43 --> Helper loaded: email_helper
INFO - 2019-11-09 17:01:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 17:01:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 17:01:43 --> Parser Class Initialized
INFO - 2019-11-09 17:01:43 --> User Agent Class Initialized
INFO - 2019-11-09 17:01:43 --> Model Class Initialized
INFO - 2019-11-09 17:01:43 --> Database Driver Class Initialized
INFO - 2019-11-09 17:01:43 --> Model Class Initialized
DEBUG - 2019-11-09 17:01:43 --> Template Class Initialized
INFO - 2019-11-09 17:01:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 17:01:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 17:01:43 --> Pagination Class Initialized
DEBUG - 2019-11-09 17:01:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 17:01:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 17:01:43 --> Encryption Class Initialized
INFO - 2019-11-09 17:01:43 --> Controller Class Initialized
DEBUG - 2019-11-09 17:01:43 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 17:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 17:01:43 --> Model Class Initialized
INFO - 2019-11-09 17:01:43 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 17:01:43 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 17:01:43 --> Could not find the language line "paystack"
ERROR - 2019-11-09 17:01:43 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 17:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 17:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 17:01:43 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 17:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 17:01:43 --> Model Class Initialized
DEBUG - 2019-11-09 17:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 17:01:43 --> Model Class Initialized
DEBUG - 2019-11-09 17:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 17:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 17:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 17:01:43 --> Final output sent to browser
DEBUG - 2019-11-09 17:01:43 --> Total execution time: 1.3119
INFO - 2019-11-09 17:01:52 --> Config Class Initialized
INFO - 2019-11-09 17:01:52 --> Hooks Class Initialized
DEBUG - 2019-11-09 17:01:52 --> UTF-8 Support Enabled
INFO - 2019-11-09 17:01:52 --> Utf8 Class Initialized
INFO - 2019-11-09 17:01:52 --> URI Class Initialized
INFO - 2019-11-09 17:01:52 --> Router Class Initialized
INFO - 2019-11-09 17:01:52 --> Output Class Initialized
INFO - 2019-11-09 17:01:52 --> Security Class Initialized
DEBUG - 2019-11-09 17:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 17:01:52 --> CSRF cookie sent
INFO - 2019-11-09 17:01:52 --> CSRF token verified
INFO - 2019-11-09 17:01:52 --> Input Class Initialized
INFO - 2019-11-09 17:01:52 --> Language Class Initialized
INFO - 2019-11-09 17:01:52 --> Language Class Initialized
INFO - 2019-11-09 17:01:52 --> Config Class Initialized
INFO - 2019-11-09 17:01:52 --> Loader Class Initialized
INFO - 2019-11-09 17:01:52 --> Helper loaded: url_helper
INFO - 2019-11-09 17:01:52 --> Helper loaded: common_helper
INFO - 2019-11-09 17:01:52 --> Helper loaded: language_helper
INFO - 2019-11-09 17:01:53 --> Helper loaded: cookie_helper
INFO - 2019-11-09 17:01:53 --> Helper loaded: email_helper
INFO - 2019-11-09 17:01:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 17:01:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 17:01:53 --> Parser Class Initialized
INFO - 2019-11-09 17:01:53 --> User Agent Class Initialized
INFO - 2019-11-09 17:01:53 --> Model Class Initialized
INFO - 2019-11-09 17:01:53 --> Database Driver Class Initialized
INFO - 2019-11-09 17:01:53 --> Model Class Initialized
DEBUG - 2019-11-09 17:01:53 --> Template Class Initialized
INFO - 2019-11-09 17:01:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 17:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 17:01:53 --> Pagination Class Initialized
DEBUG - 2019-11-09 17:01:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 17:01:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 17:01:53 --> Encryption Class Initialized
INFO - 2019-11-09 17:01:53 --> Controller Class Initialized
DEBUG - 2019-11-09 17:01:53 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 17:01:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 17:01:53 --> Model Class Initialized
DEBUG - 2019-11-09 17:01:53 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 17:01:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 17:01:53 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 17:01:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 17:01:53 --> Final output sent to browser
DEBUG - 2019-11-09 17:01:53 --> Total execution time: 0.9804
INFO - 2019-11-09 17:26:05 --> Config Class Initialized
INFO - 2019-11-09 17:26:05 --> Hooks Class Initialized
DEBUG - 2019-11-09 17:26:05 --> UTF-8 Support Enabled
INFO - 2019-11-09 17:26:05 --> Utf8 Class Initialized
INFO - 2019-11-09 17:26:05 --> URI Class Initialized
INFO - 2019-11-09 17:26:05 --> Router Class Initialized
INFO - 2019-11-09 17:26:05 --> Output Class Initialized
INFO - 2019-11-09 17:26:05 --> Security Class Initialized
DEBUG - 2019-11-09 17:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 17:26:05 --> CSRF cookie sent
INFO - 2019-11-09 17:26:05 --> CSRF token verified
INFO - 2019-11-09 17:26:05 --> Input Class Initialized
INFO - 2019-11-09 17:26:05 --> Language Class Initialized
INFO - 2019-11-09 17:26:05 --> Language Class Initialized
INFO - 2019-11-09 17:26:05 --> Config Class Initialized
INFO - 2019-11-09 17:26:05 --> Loader Class Initialized
INFO - 2019-11-09 17:26:05 --> Helper loaded: url_helper
INFO - 2019-11-09 17:26:05 --> Helper loaded: common_helper
INFO - 2019-11-09 17:26:05 --> Helper loaded: language_helper
INFO - 2019-11-09 17:26:05 --> Helper loaded: cookie_helper
INFO - 2019-11-09 17:26:05 --> Helper loaded: email_helper
INFO - 2019-11-09 17:26:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 17:26:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 17:26:05 --> Parser Class Initialized
INFO - 2019-11-09 17:26:05 --> User Agent Class Initialized
INFO - 2019-11-09 17:26:05 --> Model Class Initialized
INFO - 2019-11-09 17:26:05 --> Database Driver Class Initialized
INFO - 2019-11-09 17:26:05 --> Model Class Initialized
DEBUG - 2019-11-09 17:26:05 --> Template Class Initialized
INFO - 2019-11-09 17:26:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 17:26:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 17:26:05 --> Pagination Class Initialized
DEBUG - 2019-11-09 17:26:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 17:26:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 17:26:05 --> Encryption Class Initialized
INFO - 2019-11-09 17:26:05 --> Controller Class Initialized
DEBUG - 2019-11-09 17:26:05 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 17:26:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 17:26:05 --> Model Class Initialized
INFO - 2019-11-09 17:26:06 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 17:26:06 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 17:26:06 --> Could not find the language line "paystack"
ERROR - 2019-11-09 17:26:06 --> Could not find the language line "paytm"
ERROR - 2019-11-09 17:26:06 --> Could not find the language line "Your_name"
ERROR - 2019-11-09 17:26:06 --> Severity: Notice --> Undefined variable: email D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\index.php 86
ERROR - 2019-11-09 17:26:06 --> Severity: Notice --> Undefined variable: item_ids D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\index.php 112
ERROR - 2019-11-09 17:26:06 --> Severity: Notice --> Undefined variable: email D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\index.php 113
ERROR - 2019-11-09 17:26:06 --> Severity: Notice --> Undefined variable: link D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\index.php 114
ERROR - 2019-11-09 17:26:06 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\index.php 115
DEBUG - 2019-11-09 17:26:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 17:26:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 17:26:06 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 17:26:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 17:26:06 --> Model Class Initialized
DEBUG - 2019-11-09 17:26:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 17:26:06 --> Model Class Initialized
DEBUG - 2019-11-09 17:26:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 17:26:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 17:26:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 17:26:06 --> Final output sent to browser
DEBUG - 2019-11-09 17:26:06 --> Total execution time: 1.3925
INFO - 2019-11-09 17:26:40 --> Config Class Initialized
INFO - 2019-11-09 17:26:40 --> Hooks Class Initialized
DEBUG - 2019-11-09 17:26:40 --> UTF-8 Support Enabled
INFO - 2019-11-09 17:26:40 --> Utf8 Class Initialized
INFO - 2019-11-09 17:26:40 --> URI Class Initialized
INFO - 2019-11-09 17:26:40 --> Router Class Initialized
INFO - 2019-11-09 17:26:40 --> Output Class Initialized
INFO - 2019-11-09 17:26:40 --> Security Class Initialized
DEBUG - 2019-11-09 17:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 17:26:40 --> CSRF cookie sent
INFO - 2019-11-09 17:26:40 --> CSRF token verified
INFO - 2019-11-09 17:26:40 --> Input Class Initialized
INFO - 2019-11-09 17:26:40 --> Language Class Initialized
INFO - 2019-11-09 17:26:40 --> Language Class Initialized
INFO - 2019-11-09 17:26:40 --> Config Class Initialized
INFO - 2019-11-09 17:26:40 --> Loader Class Initialized
INFO - 2019-11-09 17:26:40 --> Helper loaded: url_helper
INFO - 2019-11-09 17:26:40 --> Helper loaded: common_helper
INFO - 2019-11-09 17:26:40 --> Helper loaded: language_helper
INFO - 2019-11-09 17:26:40 --> Helper loaded: cookie_helper
INFO - 2019-11-09 17:26:40 --> Helper loaded: email_helper
INFO - 2019-11-09 17:26:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 17:26:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 17:26:40 --> Parser Class Initialized
INFO - 2019-11-09 17:26:40 --> User Agent Class Initialized
INFO - 2019-11-09 17:26:40 --> Model Class Initialized
INFO - 2019-11-09 17:26:40 --> Database Driver Class Initialized
INFO - 2019-11-09 17:26:40 --> Model Class Initialized
DEBUG - 2019-11-09 17:26:40 --> Template Class Initialized
INFO - 2019-11-09 17:26:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 17:26:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 17:26:41 --> Pagination Class Initialized
DEBUG - 2019-11-09 17:26:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 17:26:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 17:26:41 --> Encryption Class Initialized
INFO - 2019-11-09 17:26:41 --> Controller Class Initialized
DEBUG - 2019-11-09 17:26:41 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 17:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 17:26:41 --> Model Class Initialized
INFO - 2019-11-09 17:26:41 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 17:26:41 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 17:26:41 --> Could not find the language line "paystack"
ERROR - 2019-11-09 17:26:41 --> Could not find the language line "paytm"
ERROR - 2019-11-09 17:26:41 --> Could not find the language line "Your_name"
ERROR - 2019-11-09 17:26:41 --> Severity: Notice --> Undefined variable: item_ids D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\index.php 112
ERROR - 2019-11-09 17:26:41 --> Severity: Notice --> Undefined variable: email D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\index.php 113
ERROR - 2019-11-09 17:26:41 --> Severity: Notice --> Undefined variable: link D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\index.php 114
ERROR - 2019-11-09 17:26:41 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\index.php 115
DEBUG - 2019-11-09 17:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 17:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 17:26:41 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 17:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 17:26:41 --> Model Class Initialized
DEBUG - 2019-11-09 17:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 17:26:41 --> Model Class Initialized
DEBUG - 2019-11-09 17:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 17:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 17:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 17:26:41 --> Final output sent to browser
DEBUG - 2019-11-09 17:26:41 --> Total execution time: 1.4101
INFO - 2019-11-09 17:27:10 --> Config Class Initialized
INFO - 2019-11-09 17:27:10 --> Hooks Class Initialized
DEBUG - 2019-11-09 17:27:10 --> UTF-8 Support Enabled
INFO - 2019-11-09 17:27:10 --> Utf8 Class Initialized
INFO - 2019-11-09 17:27:10 --> URI Class Initialized
INFO - 2019-11-09 17:27:10 --> Router Class Initialized
INFO - 2019-11-09 17:27:10 --> Output Class Initialized
INFO - 2019-11-09 17:27:10 --> Security Class Initialized
DEBUG - 2019-11-09 17:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 17:27:10 --> CSRF cookie sent
INFO - 2019-11-09 17:27:10 --> CSRF token verified
INFO - 2019-11-09 17:27:10 --> Input Class Initialized
INFO - 2019-11-09 17:27:10 --> Language Class Initialized
INFO - 2019-11-09 17:27:10 --> Language Class Initialized
INFO - 2019-11-09 17:27:10 --> Config Class Initialized
INFO - 2019-11-09 17:27:10 --> Loader Class Initialized
INFO - 2019-11-09 17:27:10 --> Helper loaded: url_helper
INFO - 2019-11-09 17:27:10 --> Helper loaded: common_helper
INFO - 2019-11-09 17:27:10 --> Helper loaded: language_helper
INFO - 2019-11-09 17:27:10 --> Helper loaded: cookie_helper
INFO - 2019-11-09 17:27:10 --> Helper loaded: email_helper
INFO - 2019-11-09 17:27:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 17:27:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 17:27:11 --> Parser Class Initialized
INFO - 2019-11-09 17:27:11 --> User Agent Class Initialized
INFO - 2019-11-09 17:27:11 --> Model Class Initialized
INFO - 2019-11-09 17:27:11 --> Database Driver Class Initialized
INFO - 2019-11-09 17:27:11 --> Model Class Initialized
DEBUG - 2019-11-09 17:27:11 --> Template Class Initialized
INFO - 2019-11-09 17:27:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 17:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 17:27:11 --> Pagination Class Initialized
DEBUG - 2019-11-09 17:27:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 17:27:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 17:27:11 --> Encryption Class Initialized
INFO - 2019-11-09 17:27:11 --> Controller Class Initialized
DEBUG - 2019-11-09 17:27:11 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 17:27:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 17:27:11 --> Model Class Initialized
INFO - 2019-11-09 17:27:11 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 17:27:11 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 17:27:11 --> Could not find the language line "paystack"
ERROR - 2019-11-09 17:27:11 --> Could not find the language line "paytm"
ERROR - 2019-11-09 17:27:11 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 17:27:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 17:27:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 17:27:11 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 17:27:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 17:27:11 --> Model Class Initialized
DEBUG - 2019-11-09 17:27:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 17:27:11 --> Model Class Initialized
DEBUG - 2019-11-09 17:27:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 17:27:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 17:27:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 17:27:11 --> Final output sent to browser
DEBUG - 2019-11-09 17:27:11 --> Total execution time: 1.4062
INFO - 2019-11-09 21:41:52 --> Config Class Initialized
INFO - 2019-11-09 21:41:52 --> Hooks Class Initialized
DEBUG - 2019-11-09 21:41:52 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:41:52 --> Utf8 Class Initialized
INFO - 2019-11-09 21:41:52 --> URI Class Initialized
DEBUG - 2019-11-09 21:41:52 --> No URI present. Default controller set.
INFO - 2019-11-09 21:41:52 --> Router Class Initialized
INFO - 2019-11-09 21:41:52 --> Output Class Initialized
INFO - 2019-11-09 21:41:52 --> Security Class Initialized
DEBUG - 2019-11-09 21:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:41:52 --> CSRF cookie sent
INFO - 2019-11-09 21:41:52 --> Input Class Initialized
INFO - 2019-11-09 21:41:52 --> Language Class Initialized
INFO - 2019-11-09 21:41:53 --> Language Class Initialized
INFO - 2019-11-09 21:41:53 --> Config Class Initialized
INFO - 2019-11-09 21:41:53 --> Loader Class Initialized
INFO - 2019-11-09 21:41:53 --> Helper loaded: url_helper
INFO - 2019-11-09 21:41:53 --> Helper loaded: common_helper
INFO - 2019-11-09 21:41:53 --> Helper loaded: language_helper
INFO - 2019-11-09 21:41:53 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:41:53 --> Helper loaded: email_helper
INFO - 2019-11-09 21:41:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:41:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:41:53 --> Parser Class Initialized
INFO - 2019-11-09 21:41:53 --> User Agent Class Initialized
INFO - 2019-11-09 21:41:53 --> Model Class Initialized
INFO - 2019-11-09 21:41:53 --> Database Driver Class Initialized
INFO - 2019-11-09 21:41:56 --> Model Class Initialized
DEBUG - 2019-11-09 21:41:57 --> Template Class Initialized
INFO - 2019-11-09 21:41:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:41:57 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:41:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:41:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:41:57 --> Encryption Class Initialized
DEBUG - 2019-11-09 21:41:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 21:41:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 21:41:57 --> Controller Class Initialized
DEBUG - 2019-11-09 21:41:57 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 21:41:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 21:41:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 21:41:57 --> Model Class Initialized
INFO - 2019-11-09 21:41:57 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 21:41:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 21:41:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 21:41:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 21:41:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 21:41:57 --> Final output sent to browser
DEBUG - 2019-11-09 21:41:57 --> Total execution time: 4.9064
INFO - 2019-11-09 21:47:56 --> Config Class Initialized
INFO - 2019-11-09 21:47:56 --> Hooks Class Initialized
DEBUG - 2019-11-09 21:47:56 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:47:56 --> Utf8 Class Initialized
INFO - 2019-11-09 21:47:56 --> URI Class Initialized
INFO - 2019-11-09 21:47:56 --> Router Class Initialized
INFO - 2019-11-09 21:47:56 --> Output Class Initialized
INFO - 2019-11-09 21:47:56 --> Security Class Initialized
DEBUG - 2019-11-09 21:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:47:57 --> CSRF cookie sent
INFO - 2019-11-09 21:47:57 --> Input Class Initialized
INFO - 2019-11-09 21:47:57 --> Language Class Initialized
INFO - 2019-11-09 21:47:57 --> Language Class Initialized
INFO - 2019-11-09 21:47:57 --> Config Class Initialized
INFO - 2019-11-09 21:47:57 --> Loader Class Initialized
INFO - 2019-11-09 21:47:57 --> Helper loaded: url_helper
INFO - 2019-11-09 21:47:57 --> Helper loaded: common_helper
INFO - 2019-11-09 21:47:57 --> Helper loaded: language_helper
INFO - 2019-11-09 21:47:57 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:47:57 --> Helper loaded: email_helper
INFO - 2019-11-09 21:47:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:47:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:47:57 --> Parser Class Initialized
INFO - 2019-11-09 21:47:57 --> User Agent Class Initialized
INFO - 2019-11-09 21:47:57 --> Model Class Initialized
INFO - 2019-11-09 21:47:57 --> Database Driver Class Initialized
INFO - 2019-11-09 21:47:57 --> Model Class Initialized
DEBUG - 2019-11-09 21:47:57 --> Template Class Initialized
INFO - 2019-11-09 21:47:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:47:57 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:47:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:47:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:47:57 --> Encryption Class Initialized
INFO - 2019-11-09 21:47:57 --> Controller Class Initialized
DEBUG - 2019-11-09 21:47:57 --> package MX_Controller Initialized
DEBUG - 2019-11-09 21:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 21:47:57 --> Model Class Initialized
INFO - 2019-11-09 21:47:57 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 21:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 21:47:57 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 21:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 21:47:57 --> Model Class Initialized
DEBUG - 2019-11-09 21:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 21:47:57 --> Model Class Initialized
DEBUG - 2019-11-09 21:47:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 21:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 21:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 21:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 21:47:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 21:47:58 --> Final output sent to browser
DEBUG - 2019-11-09 21:47:58 --> Total execution time: 1.3268
INFO - 2019-11-09 21:48:04 --> Config Class Initialized
INFO - 2019-11-09 21:48:04 --> Hooks Class Initialized
DEBUG - 2019-11-09 21:48:04 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:48:04 --> Utf8 Class Initialized
INFO - 2019-11-09 21:48:04 --> URI Class Initialized
INFO - 2019-11-09 21:48:04 --> Router Class Initialized
INFO - 2019-11-09 21:48:04 --> Output Class Initialized
INFO - 2019-11-09 21:48:04 --> Security Class Initialized
DEBUG - 2019-11-09 21:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:48:04 --> CSRF cookie sent
INFO - 2019-11-09 21:48:04 --> CSRF token verified
INFO - 2019-11-09 21:48:04 --> Input Class Initialized
INFO - 2019-11-09 21:48:04 --> Language Class Initialized
INFO - 2019-11-09 21:48:04 --> Language Class Initialized
INFO - 2019-11-09 21:48:04 --> Config Class Initialized
INFO - 2019-11-09 21:48:04 --> Loader Class Initialized
INFO - 2019-11-09 21:48:04 --> Helper loaded: url_helper
INFO - 2019-11-09 21:48:04 --> Helper loaded: common_helper
INFO - 2019-11-09 21:48:04 --> Helper loaded: language_helper
INFO - 2019-11-09 21:48:04 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:48:04 --> Helper loaded: email_helper
INFO - 2019-11-09 21:48:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:48:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:48:04 --> Parser Class Initialized
INFO - 2019-11-09 21:48:04 --> User Agent Class Initialized
INFO - 2019-11-09 21:48:04 --> Model Class Initialized
INFO - 2019-11-09 21:48:04 --> Database Driver Class Initialized
INFO - 2019-11-09 21:48:04 --> Model Class Initialized
DEBUG - 2019-11-09 21:48:05 --> Template Class Initialized
INFO - 2019-11-09 21:48:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:48:05 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:48:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:48:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:48:05 --> Encryption Class Initialized
INFO - 2019-11-09 21:48:05 --> Controller Class Initialized
DEBUG - 2019-11-09 21:48:05 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 21:48:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 21:48:05 --> Model Class Initialized
INFO - 2019-11-09 21:48:05 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 21:48:05 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 21:48:05 --> Could not find the language line "paystack"
ERROR - 2019-11-09 21:48:05 --> Could not find the language line "paytm"
ERROR - 2019-11-09 21:48:05 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 21:48:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 21:48:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 21:48:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 21:48:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 21:48:05 --> Model Class Initialized
DEBUG - 2019-11-09 21:48:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 21:48:05 --> Model Class Initialized
DEBUG - 2019-11-09 21:48:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 21:48:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 21:48:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 21:48:05 --> Final output sent to browser
DEBUG - 2019-11-09 21:48:05 --> Total execution time: 1.3543
INFO - 2019-11-09 21:52:45 --> Config Class Initialized
INFO - 2019-11-09 21:52:46 --> Hooks Class Initialized
DEBUG - 2019-11-09 21:52:46 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:52:46 --> Utf8 Class Initialized
INFO - 2019-11-09 21:52:46 --> URI Class Initialized
INFO - 2019-11-09 21:52:46 --> Router Class Initialized
INFO - 2019-11-09 21:52:46 --> Output Class Initialized
INFO - 2019-11-09 21:52:46 --> Security Class Initialized
DEBUG - 2019-11-09 21:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:52:46 --> CSRF cookie sent
INFO - 2019-11-09 21:52:46 --> CSRF token verified
INFO - 2019-11-09 21:52:46 --> Input Class Initialized
INFO - 2019-11-09 21:52:46 --> Language Class Initialized
INFO - 2019-11-09 21:52:46 --> Language Class Initialized
INFO - 2019-11-09 21:52:46 --> Config Class Initialized
INFO - 2019-11-09 21:52:46 --> Loader Class Initialized
INFO - 2019-11-09 21:52:46 --> Helper loaded: url_helper
INFO - 2019-11-09 21:52:46 --> Helper loaded: common_helper
INFO - 2019-11-09 21:52:46 --> Helper loaded: language_helper
INFO - 2019-11-09 21:52:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:52:46 --> Helper loaded: email_helper
INFO - 2019-11-09 21:52:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:52:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:52:46 --> Parser Class Initialized
INFO - 2019-11-09 21:52:46 --> User Agent Class Initialized
INFO - 2019-11-09 21:52:46 --> Model Class Initialized
INFO - 2019-11-09 21:52:46 --> Database Driver Class Initialized
INFO - 2019-11-09 21:52:46 --> Model Class Initialized
DEBUG - 2019-11-09 21:52:46 --> Template Class Initialized
INFO - 2019-11-09 21:52:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:52:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:52:46 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:52:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:52:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:52:46 --> Encryption Class Initialized
INFO - 2019-11-09 21:52:46 --> Controller Class Initialized
DEBUG - 2019-11-09 21:52:46 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 21:52:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 21:52:46 --> Model Class Initialized
INFO - 2019-11-09 21:52:46 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 21:52:46 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 21:52:46 --> Could not find the language line "paystack"
ERROR - 2019-11-09 21:52:46 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 21:52:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 21:52:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 21:52:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 21:52:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 21:52:47 --> Model Class Initialized
DEBUG - 2019-11-09 21:52:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 21:52:47 --> Model Class Initialized
DEBUG - 2019-11-09 21:52:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 21:52:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 21:52:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 21:52:47 --> Final output sent to browser
DEBUG - 2019-11-09 21:52:47 --> Total execution time: 1.2240
INFO - 2019-11-09 21:52:47 --> Config Class Initialized
INFO - 2019-11-09 21:52:47 --> Config Class Initialized
INFO - 2019-11-09 21:52:47 --> Hooks Class Initialized
INFO - 2019-11-09 21:52:47 --> Hooks Class Initialized
INFO - 2019-11-09 21:52:47 --> Config Class Initialized
DEBUG - 2019-11-09 21:52:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 21:52:47 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:52:47 --> Utf8 Class Initialized
INFO - 2019-11-09 21:52:47 --> Utf8 Class Initialized
INFO - 2019-11-09 21:52:47 --> Hooks Class Initialized
INFO - 2019-11-09 21:52:47 --> URI Class Initialized
INFO - 2019-11-09 21:52:47 --> URI Class Initialized
DEBUG - 2019-11-09 21:52:47 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:52:47 --> Utf8 Class Initialized
INFO - 2019-11-09 21:52:47 --> Router Class Initialized
INFO - 2019-11-09 21:52:47 --> Router Class Initialized
INFO - 2019-11-09 21:52:47 --> URI Class Initialized
INFO - 2019-11-09 21:52:47 --> Output Class Initialized
INFO - 2019-11-09 21:52:47 --> Output Class Initialized
INFO - 2019-11-09 21:52:47 --> Security Class Initialized
INFO - 2019-11-09 21:52:47 --> Security Class Initialized
INFO - 2019-11-09 21:52:47 --> Router Class Initialized
DEBUG - 2019-11-09 21:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 21:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:52:47 --> Output Class Initialized
INFO - 2019-11-09 21:52:47 --> CSRF cookie sent
INFO - 2019-11-09 21:52:47 --> CSRF cookie sent
INFO - 2019-11-09 21:52:47 --> Security Class Initialized
INFO - 2019-11-09 21:52:47 --> Input Class Initialized
INFO - 2019-11-09 21:52:47 --> Input Class Initialized
DEBUG - 2019-11-09 21:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:52:47 --> CSRF cookie sent
INFO - 2019-11-09 21:52:47 --> Language Class Initialized
INFO - 2019-11-09 21:52:47 --> Language Class Initialized
INFO - 2019-11-09 21:52:47 --> Input Class Initialized
INFO - 2019-11-09 21:52:47 --> Language Class Initialized
INFO - 2019-11-09 21:52:47 --> Language Class Initialized
INFO - 2019-11-09 21:52:47 --> Config Class Initialized
INFO - 2019-11-09 21:52:47 --> Config Class Initialized
INFO - 2019-11-09 21:52:47 --> Language Class Initialized
INFO - 2019-11-09 21:52:47 --> Language Class Initialized
INFO - 2019-11-09 21:52:47 --> Loader Class Initialized
INFO - 2019-11-09 21:52:47 --> Loader Class Initialized
INFO - 2019-11-09 21:52:47 --> Config Class Initialized
INFO - 2019-11-09 21:52:47 --> Helper loaded: url_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: url_helper
INFO - 2019-11-09 21:52:47 --> Loader Class Initialized
INFO - 2019-11-09 21:52:47 --> Helper loaded: common_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: common_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: language_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: language_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: url_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: common_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: email_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: email_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: language_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:52:47 --> Helper loaded: email_helper
INFO - 2019-11-09 21:52:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:52:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:52:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:52:47 --> Parser Class Initialized
INFO - 2019-11-09 21:52:47 --> Parser Class Initialized
INFO - 2019-11-09 21:52:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:52:47 --> User Agent Class Initialized
INFO - 2019-11-09 21:52:47 --> User Agent Class Initialized
INFO - 2019-11-09 21:52:47 --> Model Class Initialized
INFO - 2019-11-09 21:52:47 --> Model Class Initialized
INFO - 2019-11-09 21:52:47 --> Parser Class Initialized
INFO - 2019-11-09 21:52:47 --> User Agent Class Initialized
INFO - 2019-11-09 21:52:47 --> Database Driver Class Initialized
INFO - 2019-11-09 21:52:47 --> Database Driver Class Initialized
INFO - 2019-11-09 21:52:47 --> Model Class Initialized
INFO - 2019-11-09 21:52:47 --> Model Class Initialized
INFO - 2019-11-09 21:52:47 --> Model Class Initialized
DEBUG - 2019-11-09 21:52:47 --> Template Class Initialized
DEBUG - 2019-11-09 21:52:47 --> Template Class Initialized
INFO - 2019-11-09 21:52:47 --> Database Driver Class Initialized
INFO - 2019-11-09 21:52:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:52:47 --> Model Class Initialized
DEBUG - 2019-11-09 21:52:47 --> Template Class Initialized
INFO - 2019-11-09 21:52:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:52:47 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:52:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:52:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:52:47 --> Encryption Class Initialized
INFO - 2019-11-09 21:52:47 --> Controller Class Initialized
DEBUG - 2019-11-09 21:52:48 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 21:52:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 21:52:48 --> Model Class Initialized
INFO - 2019-11-09 21:52:48 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 21:52:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 21:52:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 21:52:48 --> Final output sent to browser
DEBUG - 2019-11-09 21:52:48 --> Total execution time: 0.8626
INFO - 2019-11-09 21:52:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:52:48 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:52:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:52:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:52:48 --> Encryption Class Initialized
INFO - 2019-11-09 21:52:48 --> Controller Class Initialized
DEBUG - 2019-11-09 21:52:48 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 21:52:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 21:52:48 --> Model Class Initialized
INFO - 2019-11-09 21:52:48 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 21:52:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 21:52:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 21:52:48 --> Final output sent to browser
DEBUG - 2019-11-09 21:52:48 --> Total execution time: 1.1906
INFO - 2019-11-09 21:52:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:52:48 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:52:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:52:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:52:48 --> Encryption Class Initialized
INFO - 2019-11-09 21:52:48 --> Controller Class Initialized
DEBUG - 2019-11-09 21:52:48 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 21:52:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 21:52:48 --> Model Class Initialized
INFO - 2019-11-09 21:52:48 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 21:52:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 21:52:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 21:52:48 --> Final output sent to browser
DEBUG - 2019-11-09 21:52:48 --> Total execution time: 1.4989
INFO - 2019-11-09 21:54:44 --> Config Class Initialized
INFO - 2019-11-09 21:54:44 --> Hooks Class Initialized
DEBUG - 2019-11-09 21:54:45 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:54:45 --> Utf8 Class Initialized
INFO - 2019-11-09 21:54:45 --> URI Class Initialized
INFO - 2019-11-09 21:54:45 --> Router Class Initialized
INFO - 2019-11-09 21:54:45 --> Output Class Initialized
INFO - 2019-11-09 21:54:45 --> Security Class Initialized
DEBUG - 2019-11-09 21:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:54:45 --> CSRF cookie sent
INFO - 2019-11-09 21:54:45 --> CSRF token verified
INFO - 2019-11-09 21:54:45 --> Input Class Initialized
INFO - 2019-11-09 21:54:45 --> Language Class Initialized
INFO - 2019-11-09 21:54:45 --> Language Class Initialized
INFO - 2019-11-09 21:54:45 --> Config Class Initialized
INFO - 2019-11-09 21:54:45 --> Loader Class Initialized
INFO - 2019-11-09 21:54:45 --> Helper loaded: url_helper
INFO - 2019-11-09 21:54:45 --> Helper loaded: common_helper
INFO - 2019-11-09 21:54:45 --> Helper loaded: language_helper
INFO - 2019-11-09 21:54:45 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:54:45 --> Helper loaded: email_helper
INFO - 2019-11-09 21:54:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:54:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:54:45 --> Parser Class Initialized
INFO - 2019-11-09 21:54:45 --> User Agent Class Initialized
INFO - 2019-11-09 21:54:45 --> Model Class Initialized
INFO - 2019-11-09 21:54:45 --> Database Driver Class Initialized
INFO - 2019-11-09 21:54:45 --> Model Class Initialized
DEBUG - 2019-11-09 21:54:45 --> Template Class Initialized
INFO - 2019-11-09 21:54:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:54:45 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:54:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:54:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:54:45 --> Encryption Class Initialized
INFO - 2019-11-09 21:54:45 --> Controller Class Initialized
DEBUG - 2019-11-09 21:54:45 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 21:54:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 21:54:45 --> Model Class Initialized
INFO - 2019-11-09 21:54:45 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 21:54:45 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 21:54:45 --> Could not find the language line "paystack"
ERROR - 2019-11-09 21:54:45 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 21:54:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 21:54:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 21:54:46 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 21:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 21:54:46 --> Model Class Initialized
DEBUG - 2019-11-09 21:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 21:54:46 --> Model Class Initialized
DEBUG - 2019-11-09 21:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 21:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 21:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 21:54:46 --> Final output sent to browser
DEBUG - 2019-11-09 21:54:46 --> Total execution time: 1.2380
INFO - 2019-11-09 21:54:46 --> Config Class Initialized
INFO - 2019-11-09 21:54:46 --> Config Class Initialized
INFO - 2019-11-09 21:54:46 --> Hooks Class Initialized
INFO - 2019-11-09 21:54:46 --> Hooks Class Initialized
INFO - 2019-11-09 21:54:46 --> Config Class Initialized
DEBUG - 2019-11-09 21:54:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 21:54:46 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:54:46 --> Utf8 Class Initialized
INFO - 2019-11-09 21:54:46 --> Hooks Class Initialized
INFO - 2019-11-09 21:54:46 --> Utf8 Class Initialized
INFO - 2019-11-09 21:54:46 --> URI Class Initialized
INFO - 2019-11-09 21:54:46 --> URI Class Initialized
DEBUG - 2019-11-09 21:54:46 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:54:46 --> Utf8 Class Initialized
INFO - 2019-11-09 21:54:46 --> Router Class Initialized
INFO - 2019-11-09 21:54:46 --> Router Class Initialized
INFO - 2019-11-09 21:54:46 --> URI Class Initialized
INFO - 2019-11-09 21:54:46 --> Output Class Initialized
INFO - 2019-11-09 21:54:46 --> Output Class Initialized
INFO - 2019-11-09 21:54:46 --> Security Class Initialized
INFO - 2019-11-09 21:54:46 --> Security Class Initialized
INFO - 2019-11-09 21:54:46 --> Router Class Initialized
DEBUG - 2019-11-09 21:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 21:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:54:46 --> Output Class Initialized
INFO - 2019-11-09 21:54:46 --> CSRF cookie sent
INFO - 2019-11-09 21:54:46 --> CSRF cookie sent
INFO - 2019-11-09 21:54:46 --> Security Class Initialized
INFO - 2019-11-09 21:54:46 --> Input Class Initialized
INFO - 2019-11-09 21:54:46 --> Input Class Initialized
DEBUG - 2019-11-09 21:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:54:46 --> CSRF cookie sent
INFO - 2019-11-09 21:54:46 --> Language Class Initialized
INFO - 2019-11-09 21:54:46 --> Language Class Initialized
INFO - 2019-11-09 21:54:46 --> Input Class Initialized
INFO - 2019-11-09 21:54:46 --> Language Class Initialized
INFO - 2019-11-09 21:54:46 --> Language Class Initialized
INFO - 2019-11-09 21:54:46 --> Config Class Initialized
INFO - 2019-11-09 21:54:46 --> Config Class Initialized
INFO - 2019-11-09 21:54:46 --> Language Class Initialized
INFO - 2019-11-09 21:54:46 --> Language Class Initialized
INFO - 2019-11-09 21:54:46 --> Loader Class Initialized
INFO - 2019-11-09 21:54:46 --> Loader Class Initialized
INFO - 2019-11-09 21:54:46 --> Config Class Initialized
INFO - 2019-11-09 21:54:46 --> Helper loaded: url_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: url_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: common_helper
INFO - 2019-11-09 21:54:46 --> Loader Class Initialized
INFO - 2019-11-09 21:54:46 --> Helper loaded: common_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: language_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: language_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: url_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: common_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: email_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: email_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: language_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:54:46 --> Helper loaded: email_helper
INFO - 2019-11-09 21:54:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:54:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:54:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:54:46 --> Parser Class Initialized
INFO - 2019-11-09 21:54:46 --> Parser Class Initialized
INFO - 2019-11-09 21:54:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:54:46 --> User Agent Class Initialized
INFO - 2019-11-09 21:54:46 --> User Agent Class Initialized
INFO - 2019-11-09 21:54:46 --> Model Class Initialized
INFO - 2019-11-09 21:54:46 --> Model Class Initialized
INFO - 2019-11-09 21:54:46 --> Parser Class Initialized
INFO - 2019-11-09 21:54:46 --> User Agent Class Initialized
INFO - 2019-11-09 21:54:46 --> Database Driver Class Initialized
INFO - 2019-11-09 21:54:46 --> Database Driver Class Initialized
INFO - 2019-11-09 21:54:46 --> Model Class Initialized
INFO - 2019-11-09 21:54:46 --> Model Class Initialized
INFO - 2019-11-09 21:54:46 --> Model Class Initialized
DEBUG - 2019-11-09 21:54:46 --> Template Class Initialized
DEBUG - 2019-11-09 21:54:46 --> Template Class Initialized
INFO - 2019-11-09 21:54:46 --> Database Driver Class Initialized
INFO - 2019-11-09 21:54:46 --> Model Class Initialized
INFO - 2019-11-09 21:54:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2019-11-09 21:54:46 --> Template Class Initialized
INFO - 2019-11-09 21:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:54:46 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:54:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:54:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:54:47 --> Encryption Class Initialized
INFO - 2019-11-09 21:54:47 --> Controller Class Initialized
DEBUG - 2019-11-09 21:54:47 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 21:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 21:54:47 --> Model Class Initialized
INFO - 2019-11-09 21:54:47 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 21:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 21:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 21:54:47 --> Final output sent to browser
DEBUG - 2019-11-09 21:54:47 --> Total execution time: 0.9174
INFO - 2019-11-09 21:54:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:54:47 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:54:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:54:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:54:47 --> Encryption Class Initialized
INFO - 2019-11-09 21:54:47 --> Controller Class Initialized
DEBUG - 2019-11-09 21:54:47 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 21:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 21:54:47 --> Model Class Initialized
INFO - 2019-11-09 21:54:47 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 21:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 21:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 21:54:47 --> Final output sent to browser
DEBUG - 2019-11-09 21:54:47 --> Total execution time: 1.2150
INFO - 2019-11-09 21:54:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:54:47 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:54:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:54:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:54:47 --> Encryption Class Initialized
INFO - 2019-11-09 21:54:47 --> Controller Class Initialized
DEBUG - 2019-11-09 21:54:47 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 21:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 21:54:47 --> Model Class Initialized
INFO - 2019-11-09 21:54:47 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 21:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 21:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 21:54:47 --> Final output sent to browser
DEBUG - 2019-11-09 21:54:47 --> Total execution time: 1.5349
INFO - 2019-11-09 21:56:22 --> Config Class Initialized
INFO - 2019-11-09 21:56:22 --> Hooks Class Initialized
DEBUG - 2019-11-09 21:56:22 --> UTF-8 Support Enabled
INFO - 2019-11-09 21:56:22 --> Utf8 Class Initialized
INFO - 2019-11-09 21:56:22 --> URI Class Initialized
INFO - 2019-11-09 21:56:22 --> Router Class Initialized
INFO - 2019-11-09 21:56:22 --> Output Class Initialized
INFO - 2019-11-09 21:56:22 --> Security Class Initialized
DEBUG - 2019-11-09 21:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 21:56:22 --> CSRF cookie sent
INFO - 2019-11-09 21:56:23 --> CSRF token verified
INFO - 2019-11-09 21:56:23 --> Input Class Initialized
INFO - 2019-11-09 21:56:23 --> Language Class Initialized
INFO - 2019-11-09 21:56:23 --> Language Class Initialized
INFO - 2019-11-09 21:56:23 --> Config Class Initialized
INFO - 2019-11-09 21:56:23 --> Loader Class Initialized
INFO - 2019-11-09 21:56:23 --> Helper loaded: url_helper
INFO - 2019-11-09 21:56:23 --> Helper loaded: common_helper
INFO - 2019-11-09 21:56:23 --> Helper loaded: language_helper
INFO - 2019-11-09 21:56:23 --> Helper loaded: cookie_helper
INFO - 2019-11-09 21:56:23 --> Helper loaded: email_helper
INFO - 2019-11-09 21:56:23 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 21:56:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 21:56:23 --> Parser Class Initialized
INFO - 2019-11-09 21:56:23 --> User Agent Class Initialized
INFO - 2019-11-09 21:56:23 --> Model Class Initialized
INFO - 2019-11-09 21:56:23 --> Database Driver Class Initialized
INFO - 2019-11-09 21:56:23 --> Model Class Initialized
DEBUG - 2019-11-09 21:56:23 --> Template Class Initialized
INFO - 2019-11-09 21:56:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 21:56:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 21:56:23 --> Pagination Class Initialized
DEBUG - 2019-11-09 21:56:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 21:56:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 21:56:23 --> Encryption Class Initialized
INFO - 2019-11-09 21:56:23 --> Controller Class Initialized
DEBUG - 2019-11-09 21:56:23 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 21:56:23 --> Model Class Initialized
INFO - 2019-11-09 21:56:23 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 21:56:23 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 21:56:23 --> Could not find the language line "paystack"
ERROR - 2019-11-09 21:56:23 --> Could not find the language line "paytm"
ERROR - 2019-11-09 21:56:23 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 21:56:23 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 21:56:23 --> Model Class Initialized
DEBUG - 2019-11-09 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 21:56:23 --> Model Class Initialized
DEBUG - 2019-11-09 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 21:56:23 --> Final output sent to browser
DEBUG - 2019-11-09 21:56:24 --> Total execution time: 1.1777
INFO - 2019-11-09 22:00:39 --> Config Class Initialized
INFO - 2019-11-09 22:00:39 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:00:39 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:00:39 --> Utf8 Class Initialized
INFO - 2019-11-09 22:00:39 --> URI Class Initialized
INFO - 2019-11-09 22:00:39 --> Router Class Initialized
INFO - 2019-11-09 22:00:39 --> Output Class Initialized
INFO - 2019-11-09 22:00:39 --> Security Class Initialized
DEBUG - 2019-11-09 22:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:00:40 --> CSRF cookie sent
INFO - 2019-11-09 22:00:40 --> CSRF token verified
INFO - 2019-11-09 22:00:40 --> Input Class Initialized
INFO - 2019-11-09 22:00:40 --> Language Class Initialized
INFO - 2019-11-09 22:00:40 --> Language Class Initialized
INFO - 2019-11-09 22:00:40 --> Config Class Initialized
INFO - 2019-11-09 22:00:40 --> Loader Class Initialized
INFO - 2019-11-09 22:00:40 --> Helper loaded: url_helper
INFO - 2019-11-09 22:00:40 --> Helper loaded: common_helper
INFO - 2019-11-09 22:00:40 --> Helper loaded: language_helper
INFO - 2019-11-09 22:00:40 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:00:40 --> Helper loaded: email_helper
INFO - 2019-11-09 22:00:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:00:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:00:40 --> Parser Class Initialized
INFO - 2019-11-09 22:00:40 --> User Agent Class Initialized
INFO - 2019-11-09 22:00:40 --> Model Class Initialized
INFO - 2019-11-09 22:00:40 --> Database Driver Class Initialized
INFO - 2019-11-09 22:00:40 --> Model Class Initialized
DEBUG - 2019-11-09 22:00:40 --> Template Class Initialized
INFO - 2019-11-09 22:00:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:00:40 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:00:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:00:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:00:40 --> Encryption Class Initialized
INFO - 2019-11-09 22:00:40 --> Controller Class Initialized
DEBUG - 2019-11-09 22:00:40 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:00:40 --> Model Class Initialized
INFO - 2019-11-09 22:00:40 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:00:40 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:00:40 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:00:40 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:00:40 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:00:40 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:00:40 --> Model Class Initialized
DEBUG - 2019-11-09 22:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:00:40 --> Model Class Initialized
DEBUG - 2019-11-09 22:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:00:41 --> Final output sent to browser
DEBUG - 2019-11-09 22:00:41 --> Total execution time: 1.3337
INFO - 2019-11-09 22:01:07 --> Config Class Initialized
INFO - 2019-11-09 22:01:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:01:08 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:01:08 --> Utf8 Class Initialized
INFO - 2019-11-09 22:01:08 --> URI Class Initialized
INFO - 2019-11-09 22:01:08 --> Router Class Initialized
INFO - 2019-11-09 22:01:08 --> Output Class Initialized
INFO - 2019-11-09 22:01:08 --> Security Class Initialized
DEBUG - 2019-11-09 22:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:01:08 --> CSRF cookie sent
INFO - 2019-11-09 22:01:08 --> CSRF token verified
INFO - 2019-11-09 22:01:08 --> Input Class Initialized
INFO - 2019-11-09 22:01:08 --> Language Class Initialized
INFO - 2019-11-09 22:01:08 --> Language Class Initialized
INFO - 2019-11-09 22:01:08 --> Config Class Initialized
INFO - 2019-11-09 22:01:08 --> Loader Class Initialized
INFO - 2019-11-09 22:01:08 --> Helper loaded: url_helper
INFO - 2019-11-09 22:01:08 --> Helper loaded: common_helper
INFO - 2019-11-09 22:01:08 --> Helper loaded: language_helper
INFO - 2019-11-09 22:01:08 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:01:08 --> Helper loaded: email_helper
INFO - 2019-11-09 22:01:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:01:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:01:08 --> Parser Class Initialized
INFO - 2019-11-09 22:01:08 --> User Agent Class Initialized
INFO - 2019-11-09 22:01:08 --> Model Class Initialized
INFO - 2019-11-09 22:01:08 --> Database Driver Class Initialized
INFO - 2019-11-09 22:01:08 --> Model Class Initialized
DEBUG - 2019-11-09 22:01:08 --> Template Class Initialized
INFO - 2019-11-09 22:01:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:01:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:01:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:01:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:01:08 --> Encryption Class Initialized
INFO - 2019-11-09 22:01:08 --> Controller Class Initialized
DEBUG - 2019-11-09 22:01:08 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:01:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:01:08 --> Model Class Initialized
INFO - 2019-11-09 22:01:08 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:01:08 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:01:08 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:01:08 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:01:08 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:01:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:01:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:01:09 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:01:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:01:09 --> Model Class Initialized
DEBUG - 2019-11-09 22:01:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:01:09 --> Model Class Initialized
DEBUG - 2019-11-09 22:01:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:01:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:01:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:01:09 --> Final output sent to browser
DEBUG - 2019-11-09 22:01:09 --> Total execution time: 1.2610
INFO - 2019-11-09 22:01:27 --> Config Class Initialized
INFO - 2019-11-09 22:01:27 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:01:27 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:01:27 --> Utf8 Class Initialized
INFO - 2019-11-09 22:01:27 --> URI Class Initialized
INFO - 2019-11-09 22:01:27 --> Router Class Initialized
INFO - 2019-11-09 22:01:27 --> Output Class Initialized
INFO - 2019-11-09 22:01:27 --> Security Class Initialized
DEBUG - 2019-11-09 22:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:01:27 --> CSRF cookie sent
INFO - 2019-11-09 22:01:27 --> CSRF token verified
INFO - 2019-11-09 22:01:27 --> Input Class Initialized
INFO - 2019-11-09 22:01:27 --> Language Class Initialized
INFO - 2019-11-09 22:01:27 --> Language Class Initialized
INFO - 2019-11-09 22:01:27 --> Config Class Initialized
INFO - 2019-11-09 22:01:27 --> Loader Class Initialized
INFO - 2019-11-09 22:01:27 --> Helper loaded: url_helper
INFO - 2019-11-09 22:01:27 --> Helper loaded: common_helper
INFO - 2019-11-09 22:01:27 --> Helper loaded: language_helper
INFO - 2019-11-09 22:01:27 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:01:27 --> Helper loaded: email_helper
INFO - 2019-11-09 22:01:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:01:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:01:27 --> Parser Class Initialized
INFO - 2019-11-09 22:01:27 --> User Agent Class Initialized
INFO - 2019-11-09 22:01:27 --> Model Class Initialized
INFO - 2019-11-09 22:01:27 --> Database Driver Class Initialized
INFO - 2019-11-09 22:01:27 --> Model Class Initialized
DEBUG - 2019-11-09 22:01:27 --> Template Class Initialized
INFO - 2019-11-09 22:01:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:01:27 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:01:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:01:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:01:28 --> Encryption Class Initialized
INFO - 2019-11-09 22:01:28 --> Controller Class Initialized
DEBUG - 2019-11-09 22:01:28 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:01:28 --> Model Class Initialized
INFO - 2019-11-09 22:01:28 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:01:28 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:01:28 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:01:28 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:01:28 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:01:28 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:01:28 --> Model Class Initialized
DEBUG - 2019-11-09 22:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:01:28 --> Model Class Initialized
DEBUG - 2019-11-09 22:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:01:28 --> Final output sent to browser
DEBUG - 2019-11-09 22:01:28 --> Total execution time: 1.2209
INFO - 2019-11-09 22:02:50 --> Config Class Initialized
INFO - 2019-11-09 22:02:50 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:02:50 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:02:50 --> Utf8 Class Initialized
INFO - 2019-11-09 22:02:50 --> URI Class Initialized
INFO - 2019-11-09 22:02:50 --> Router Class Initialized
INFO - 2019-11-09 22:02:50 --> Output Class Initialized
INFO - 2019-11-09 22:02:50 --> Security Class Initialized
DEBUG - 2019-11-09 22:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:02:51 --> CSRF cookie sent
INFO - 2019-11-09 22:02:51 --> CSRF token verified
INFO - 2019-11-09 22:02:51 --> Input Class Initialized
INFO - 2019-11-09 22:02:51 --> Language Class Initialized
INFO - 2019-11-09 22:02:51 --> Language Class Initialized
INFO - 2019-11-09 22:02:51 --> Config Class Initialized
INFO - 2019-11-09 22:02:51 --> Loader Class Initialized
INFO - 2019-11-09 22:02:51 --> Helper loaded: url_helper
INFO - 2019-11-09 22:02:51 --> Helper loaded: common_helper
INFO - 2019-11-09 22:02:51 --> Helper loaded: language_helper
INFO - 2019-11-09 22:02:51 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:02:51 --> Helper loaded: email_helper
INFO - 2019-11-09 22:02:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:02:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:02:51 --> Parser Class Initialized
INFO - 2019-11-09 22:02:51 --> User Agent Class Initialized
INFO - 2019-11-09 22:02:51 --> Model Class Initialized
INFO - 2019-11-09 22:02:51 --> Database Driver Class Initialized
INFO - 2019-11-09 22:02:51 --> Model Class Initialized
DEBUG - 2019-11-09 22:02:51 --> Template Class Initialized
INFO - 2019-11-09 22:02:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:02:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:02:51 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:02:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:02:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:02:51 --> Encryption Class Initialized
INFO - 2019-11-09 22:02:51 --> Controller Class Initialized
DEBUG - 2019-11-09 22:02:51 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:02:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:02:51 --> Model Class Initialized
INFO - 2019-11-09 22:02:51 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:02:51 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:02:51 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:02:51 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:02:51 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:02:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:02:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:02:51 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:02:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:02:51 --> Model Class Initialized
DEBUG - 2019-11-09 22:02:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:02:51 --> Model Class Initialized
DEBUG - 2019-11-09 22:02:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:02:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:02:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:02:51 --> Final output sent to browser
DEBUG - 2019-11-09 22:02:51 --> Total execution time: 1.1440
INFO - 2019-11-09 22:03:13 --> Config Class Initialized
INFO - 2019-11-09 22:03:13 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:03:13 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:03:13 --> Utf8 Class Initialized
INFO - 2019-11-09 22:03:13 --> URI Class Initialized
INFO - 2019-11-09 22:03:13 --> Router Class Initialized
INFO - 2019-11-09 22:03:13 --> Output Class Initialized
INFO - 2019-11-09 22:03:13 --> Security Class Initialized
DEBUG - 2019-11-09 22:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:03:13 --> CSRF cookie sent
INFO - 2019-11-09 22:03:13 --> CSRF token verified
INFO - 2019-11-09 22:03:13 --> Input Class Initialized
INFO - 2019-11-09 22:03:13 --> Language Class Initialized
INFO - 2019-11-09 22:03:13 --> Language Class Initialized
INFO - 2019-11-09 22:03:13 --> Config Class Initialized
INFO - 2019-11-09 22:03:13 --> Loader Class Initialized
INFO - 2019-11-09 22:03:13 --> Helper loaded: url_helper
INFO - 2019-11-09 22:03:13 --> Helper loaded: common_helper
INFO - 2019-11-09 22:03:13 --> Helper loaded: language_helper
INFO - 2019-11-09 22:03:13 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:03:13 --> Helper loaded: email_helper
INFO - 2019-11-09 22:03:13 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:03:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:03:13 --> Parser Class Initialized
INFO - 2019-11-09 22:03:13 --> User Agent Class Initialized
INFO - 2019-11-09 22:03:13 --> Model Class Initialized
INFO - 2019-11-09 22:03:13 --> Database Driver Class Initialized
INFO - 2019-11-09 22:03:13 --> Model Class Initialized
DEBUG - 2019-11-09 22:03:13 --> Template Class Initialized
INFO - 2019-11-09 22:03:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:03:13 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:03:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:03:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:03:14 --> Encryption Class Initialized
INFO - 2019-11-09 22:03:14 --> Controller Class Initialized
DEBUG - 2019-11-09 22:03:14 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:03:14 --> Model Class Initialized
INFO - 2019-11-09 22:03:14 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:03:14 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:03:14 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:03:14 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:03:14 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:03:14 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:03:14 --> Model Class Initialized
DEBUG - 2019-11-09 22:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:03:14 --> Model Class Initialized
DEBUG - 2019-11-09 22:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:03:14 --> Final output sent to browser
DEBUG - 2019-11-09 22:03:14 --> Total execution time: 1.1781
INFO - 2019-11-09 22:03:41 --> Config Class Initialized
INFO - 2019-11-09 22:03:41 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:03:41 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:03:41 --> Utf8 Class Initialized
INFO - 2019-11-09 22:03:41 --> URI Class Initialized
INFO - 2019-11-09 22:03:41 --> Router Class Initialized
INFO - 2019-11-09 22:03:42 --> Output Class Initialized
INFO - 2019-11-09 22:03:42 --> Security Class Initialized
DEBUG - 2019-11-09 22:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:03:42 --> CSRF cookie sent
INFO - 2019-11-09 22:03:42 --> CSRF token verified
INFO - 2019-11-09 22:03:42 --> Input Class Initialized
INFO - 2019-11-09 22:03:42 --> Language Class Initialized
INFO - 2019-11-09 22:03:42 --> Language Class Initialized
INFO - 2019-11-09 22:03:42 --> Config Class Initialized
INFO - 2019-11-09 22:03:42 --> Loader Class Initialized
INFO - 2019-11-09 22:03:42 --> Helper loaded: url_helper
INFO - 2019-11-09 22:03:42 --> Helper loaded: common_helper
INFO - 2019-11-09 22:03:42 --> Helper loaded: language_helper
INFO - 2019-11-09 22:03:42 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:03:42 --> Helper loaded: email_helper
INFO - 2019-11-09 22:03:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:03:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:03:42 --> Parser Class Initialized
INFO - 2019-11-09 22:03:42 --> User Agent Class Initialized
INFO - 2019-11-09 22:03:42 --> Model Class Initialized
INFO - 2019-11-09 22:03:42 --> Database Driver Class Initialized
INFO - 2019-11-09 22:03:42 --> Model Class Initialized
DEBUG - 2019-11-09 22:03:42 --> Template Class Initialized
INFO - 2019-11-09 22:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:03:42 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:03:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:03:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:03:42 --> Encryption Class Initialized
INFO - 2019-11-09 22:03:42 --> Controller Class Initialized
DEBUG - 2019-11-09 22:03:42 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:03:42 --> Model Class Initialized
INFO - 2019-11-09 22:03:42 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:03:42 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:03:42 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:03:42 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:03:42 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:03:42 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:03:42 --> Model Class Initialized
DEBUG - 2019-11-09 22:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:03:42 --> Model Class Initialized
DEBUG - 2019-11-09 22:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:03:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:03:43 --> Final output sent to browser
DEBUG - 2019-11-09 22:03:43 --> Total execution time: 1.1624
INFO - 2019-11-09 22:04:14 --> Config Class Initialized
INFO - 2019-11-09 22:04:14 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:04:14 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:04:14 --> Utf8 Class Initialized
INFO - 2019-11-09 22:04:14 --> URI Class Initialized
INFO - 2019-11-09 22:04:14 --> Router Class Initialized
INFO - 2019-11-09 22:04:14 --> Output Class Initialized
INFO - 2019-11-09 22:04:14 --> Security Class Initialized
DEBUG - 2019-11-09 22:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:04:14 --> CSRF cookie sent
INFO - 2019-11-09 22:04:14 --> CSRF token verified
INFO - 2019-11-09 22:04:14 --> Input Class Initialized
INFO - 2019-11-09 22:04:14 --> Language Class Initialized
INFO - 2019-11-09 22:04:14 --> Language Class Initialized
INFO - 2019-11-09 22:04:15 --> Config Class Initialized
INFO - 2019-11-09 22:04:15 --> Loader Class Initialized
INFO - 2019-11-09 22:04:15 --> Helper loaded: url_helper
INFO - 2019-11-09 22:04:15 --> Helper loaded: common_helper
INFO - 2019-11-09 22:04:15 --> Helper loaded: language_helper
INFO - 2019-11-09 22:04:15 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:04:15 --> Helper loaded: email_helper
INFO - 2019-11-09 22:04:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:04:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:04:15 --> Parser Class Initialized
INFO - 2019-11-09 22:04:15 --> User Agent Class Initialized
INFO - 2019-11-09 22:04:15 --> Model Class Initialized
INFO - 2019-11-09 22:04:15 --> Database Driver Class Initialized
INFO - 2019-11-09 22:04:15 --> Model Class Initialized
DEBUG - 2019-11-09 22:04:15 --> Template Class Initialized
INFO - 2019-11-09 22:04:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:04:15 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:04:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:04:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:04:15 --> Encryption Class Initialized
INFO - 2019-11-09 22:04:15 --> Controller Class Initialized
DEBUG - 2019-11-09 22:04:15 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:04:15 --> Model Class Initialized
INFO - 2019-11-09 22:04:15 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:04:15 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:04:15 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:04:15 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:04:15 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:04:15 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:04:15 --> Model Class Initialized
DEBUG - 2019-11-09 22:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:04:15 --> Model Class Initialized
DEBUG - 2019-11-09 22:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:04:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:04:15 --> Final output sent to browser
DEBUG - 2019-11-09 22:04:15 --> Total execution time: 1.2114
INFO - 2019-11-09 22:04:34 --> Config Class Initialized
INFO - 2019-11-09 22:04:34 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:04:34 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:04:34 --> Utf8 Class Initialized
INFO - 2019-11-09 22:04:34 --> URI Class Initialized
INFO - 2019-11-09 22:04:34 --> Router Class Initialized
INFO - 2019-11-09 22:04:34 --> Output Class Initialized
INFO - 2019-11-09 22:04:34 --> Security Class Initialized
DEBUG - 2019-11-09 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:04:34 --> CSRF cookie sent
INFO - 2019-11-09 22:04:34 --> CSRF token verified
INFO - 2019-11-09 22:04:34 --> Input Class Initialized
INFO - 2019-11-09 22:04:34 --> Language Class Initialized
INFO - 2019-11-09 22:04:34 --> Language Class Initialized
INFO - 2019-11-09 22:04:34 --> Config Class Initialized
INFO - 2019-11-09 22:04:34 --> Loader Class Initialized
INFO - 2019-11-09 22:04:34 --> Helper loaded: url_helper
INFO - 2019-11-09 22:04:35 --> Helper loaded: common_helper
INFO - 2019-11-09 22:04:35 --> Helper loaded: language_helper
INFO - 2019-11-09 22:04:35 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:04:35 --> Helper loaded: email_helper
INFO - 2019-11-09 22:04:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:04:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:04:35 --> Parser Class Initialized
INFO - 2019-11-09 22:04:35 --> User Agent Class Initialized
INFO - 2019-11-09 22:04:35 --> Model Class Initialized
INFO - 2019-11-09 22:04:35 --> Database Driver Class Initialized
INFO - 2019-11-09 22:04:35 --> Model Class Initialized
DEBUG - 2019-11-09 22:04:35 --> Template Class Initialized
INFO - 2019-11-09 22:04:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:04:35 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:04:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:04:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:04:35 --> Encryption Class Initialized
INFO - 2019-11-09 22:04:35 --> Controller Class Initialized
DEBUG - 2019-11-09 22:04:35 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:04:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:04:35 --> Model Class Initialized
INFO - 2019-11-09 22:04:35 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:04:35 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:04:35 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:04:35 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:04:35 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:04:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:04:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:04:35 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:04:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:04:35 --> Model Class Initialized
DEBUG - 2019-11-09 22:04:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:04:35 --> Model Class Initialized
DEBUG - 2019-11-09 22:04:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:04:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:04:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:04:35 --> Final output sent to browser
DEBUG - 2019-11-09 22:04:35 --> Total execution time: 1.1862
INFO - 2019-11-09 22:18:29 --> Config Class Initialized
INFO - 2019-11-09 22:18:29 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:18:29 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:18:29 --> Utf8 Class Initialized
INFO - 2019-11-09 22:18:29 --> URI Class Initialized
INFO - 2019-11-09 22:18:29 --> Router Class Initialized
INFO - 2019-11-09 22:18:29 --> Output Class Initialized
INFO - 2019-11-09 22:18:29 --> Security Class Initialized
DEBUG - 2019-11-09 22:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:18:29 --> CSRF cookie sent
INFO - 2019-11-09 22:18:29 --> CSRF token verified
INFO - 2019-11-09 22:18:29 --> Input Class Initialized
INFO - 2019-11-09 22:18:29 --> Language Class Initialized
INFO - 2019-11-09 22:18:29 --> Language Class Initialized
INFO - 2019-11-09 22:18:29 --> Config Class Initialized
INFO - 2019-11-09 22:18:29 --> Loader Class Initialized
INFO - 2019-11-09 22:18:29 --> Helper loaded: url_helper
INFO - 2019-11-09 22:18:29 --> Helper loaded: common_helper
INFO - 2019-11-09 22:18:29 --> Helper loaded: language_helper
INFO - 2019-11-09 22:18:29 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:18:29 --> Helper loaded: email_helper
INFO - 2019-11-09 22:18:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:18:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:18:29 --> Parser Class Initialized
INFO - 2019-11-09 22:18:29 --> User Agent Class Initialized
INFO - 2019-11-09 22:18:29 --> Model Class Initialized
INFO - 2019-11-09 22:18:29 --> Database Driver Class Initialized
INFO - 2019-11-09 22:18:29 --> Model Class Initialized
DEBUG - 2019-11-09 22:18:29 --> Template Class Initialized
INFO - 2019-11-09 22:18:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:18:29 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:18:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:18:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:18:30 --> Encryption Class Initialized
INFO - 2019-11-09 22:18:30 --> Controller Class Initialized
DEBUG - 2019-11-09 22:18:30 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:18:30 --> Model Class Initialized
INFO - 2019-11-09 22:18:30 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:18:30 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:18:30 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:18:30 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:18:30 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:18:30 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:18:30 --> Model Class Initialized
DEBUG - 2019-11-09 22:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:18:30 --> Model Class Initialized
DEBUG - 2019-11-09 22:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:18:30 --> Final output sent to browser
DEBUG - 2019-11-09 22:18:30 --> Total execution time: 1.3601
INFO - 2019-11-09 22:34:28 --> Config Class Initialized
INFO - 2019-11-09 22:34:28 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:34:28 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:34:28 --> Utf8 Class Initialized
INFO - 2019-11-09 22:34:28 --> URI Class Initialized
INFO - 2019-11-09 22:34:28 --> Router Class Initialized
INFO - 2019-11-09 22:34:28 --> Output Class Initialized
INFO - 2019-11-09 22:34:28 --> Security Class Initialized
DEBUG - 2019-11-09 22:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:34:28 --> CSRF cookie sent
INFO - 2019-11-09 22:34:28 --> CSRF token verified
INFO - 2019-11-09 22:34:28 --> Input Class Initialized
INFO - 2019-11-09 22:34:28 --> Language Class Initialized
INFO - 2019-11-09 22:34:28 --> Language Class Initialized
INFO - 2019-11-09 22:34:28 --> Config Class Initialized
INFO - 2019-11-09 22:34:29 --> Loader Class Initialized
INFO - 2019-11-09 22:34:29 --> Helper loaded: url_helper
INFO - 2019-11-09 22:34:29 --> Helper loaded: common_helper
INFO - 2019-11-09 22:34:29 --> Helper loaded: language_helper
INFO - 2019-11-09 22:34:29 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:34:29 --> Helper loaded: email_helper
INFO - 2019-11-09 22:34:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:34:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:34:29 --> Parser Class Initialized
INFO - 2019-11-09 22:34:29 --> User Agent Class Initialized
INFO - 2019-11-09 22:34:29 --> Model Class Initialized
INFO - 2019-11-09 22:34:29 --> Database Driver Class Initialized
INFO - 2019-11-09 22:34:29 --> Model Class Initialized
DEBUG - 2019-11-09 22:34:29 --> Template Class Initialized
INFO - 2019-11-09 22:34:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:34:29 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:34:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:34:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:34:29 --> Encryption Class Initialized
INFO - 2019-11-09 22:34:29 --> Controller Class Initialized
DEBUG - 2019-11-09 22:34:29 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:34:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:34:29 --> Model Class Initialized
INFO - 2019-11-09 22:34:29 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:34:29 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:34:29 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:34:29 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:34:29 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:34:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:34:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:34:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:34:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:34:29 --> Model Class Initialized
DEBUG - 2019-11-09 22:34:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:34:29 --> Model Class Initialized
DEBUG - 2019-11-09 22:34:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:34:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:34:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:34:30 --> Final output sent to browser
DEBUG - 2019-11-09 22:34:30 --> Total execution time: 1.4035
INFO - 2019-11-09 22:34:30 --> Config Class Initialized
INFO - 2019-11-09 22:34:30 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:34:30 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:34:30 --> Utf8 Class Initialized
INFO - 2019-11-09 22:34:30 --> URI Class Initialized
INFO - 2019-11-09 22:34:30 --> Router Class Initialized
INFO - 2019-11-09 22:34:30 --> Output Class Initialized
INFO - 2019-11-09 22:34:30 --> Security Class Initialized
DEBUG - 2019-11-09 22:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:34:30 --> CSRF cookie sent
INFO - 2019-11-09 22:34:30 --> Input Class Initialized
INFO - 2019-11-09 22:34:30 --> Language Class Initialized
INFO - 2019-11-09 22:34:30 --> Language Class Initialized
INFO - 2019-11-09 22:34:30 --> Config Class Initialized
INFO - 2019-11-09 22:34:30 --> Loader Class Initialized
INFO - 2019-11-09 22:34:30 --> Helper loaded: url_helper
INFO - 2019-11-09 22:34:30 --> Helper loaded: common_helper
INFO - 2019-11-09 22:34:30 --> Helper loaded: language_helper
INFO - 2019-11-09 22:34:30 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:34:30 --> Helper loaded: email_helper
INFO - 2019-11-09 22:34:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:34:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:34:30 --> Parser Class Initialized
INFO - 2019-11-09 22:34:30 --> User Agent Class Initialized
INFO - 2019-11-09 22:34:30 --> Model Class Initialized
INFO - 2019-11-09 22:34:30 --> Database Driver Class Initialized
INFO - 2019-11-09 22:34:30 --> Model Class Initialized
DEBUG - 2019-11-09 22:34:30 --> Template Class Initialized
INFO - 2019-11-09 22:34:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:34:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:34:30 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:34:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:34:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:34:31 --> Encryption Class Initialized
INFO - 2019-11-09 22:34:31 --> Controller Class Initialized
DEBUG - 2019-11-09 22:34:31 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-09 22:34:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-09 22:34:31 --> Model Class Initialized
INFO - 2019-11-09 22:34:31 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 22:34:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-09 22:34:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-09 22:34:31 --> Final output sent to browser
DEBUG - 2019-11-09 22:34:31 --> Total execution time: 1.1170
INFO - 2019-11-09 22:37:46 --> Config Class Initialized
INFO - 2019-11-09 22:37:46 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:37:46 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:37:46 --> Utf8 Class Initialized
INFO - 2019-11-09 22:37:46 --> URI Class Initialized
INFO - 2019-11-09 22:37:46 --> Router Class Initialized
INFO - 2019-11-09 22:37:46 --> Output Class Initialized
INFO - 2019-11-09 22:37:46 --> Security Class Initialized
DEBUG - 2019-11-09 22:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:37:46 --> CSRF cookie sent
INFO - 2019-11-09 22:37:46 --> CSRF token verified
INFO - 2019-11-09 22:37:46 --> Input Class Initialized
INFO - 2019-11-09 22:37:46 --> Language Class Initialized
INFO - 2019-11-09 22:37:46 --> Language Class Initialized
INFO - 2019-11-09 22:37:46 --> Config Class Initialized
INFO - 2019-11-09 22:37:46 --> Loader Class Initialized
INFO - 2019-11-09 22:37:46 --> Helper loaded: url_helper
INFO - 2019-11-09 22:37:46 --> Helper loaded: common_helper
INFO - 2019-11-09 22:37:46 --> Helper loaded: language_helper
INFO - 2019-11-09 22:37:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:37:47 --> Helper loaded: email_helper
INFO - 2019-11-09 22:37:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:37:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:37:47 --> Parser Class Initialized
INFO - 2019-11-09 22:37:47 --> User Agent Class Initialized
INFO - 2019-11-09 22:37:47 --> Model Class Initialized
INFO - 2019-11-09 22:37:47 --> Database Driver Class Initialized
INFO - 2019-11-09 22:37:47 --> Model Class Initialized
DEBUG - 2019-11-09 22:37:47 --> Template Class Initialized
INFO - 2019-11-09 22:37:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:37:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:37:47 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:37:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:37:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:37:47 --> Encryption Class Initialized
INFO - 2019-11-09 22:37:47 --> Controller Class Initialized
DEBUG - 2019-11-09 22:37:47 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:37:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:37:47 --> Model Class Initialized
INFO - 2019-11-09 22:37:47 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:37:47 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:37:47 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:37:47 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:37:47 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:37:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:37:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:37:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:37:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:37:47 --> Model Class Initialized
DEBUG - 2019-11-09 22:37:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:37:47 --> Model Class Initialized
DEBUG - 2019-11-09 22:37:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:37:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:37:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:37:47 --> Final output sent to browser
DEBUG - 2019-11-09 22:37:47 --> Total execution time: 1.3380
INFO - 2019-11-09 22:40:05 --> Config Class Initialized
INFO - 2019-11-09 22:40:05 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:40:05 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:40:05 --> Utf8 Class Initialized
INFO - 2019-11-09 22:40:05 --> URI Class Initialized
INFO - 2019-11-09 22:40:05 --> Router Class Initialized
INFO - 2019-11-09 22:40:05 --> Output Class Initialized
INFO - 2019-11-09 22:40:05 --> Security Class Initialized
DEBUG - 2019-11-09 22:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:40:05 --> CSRF cookie sent
INFO - 2019-11-09 22:40:05 --> CSRF token verified
INFO - 2019-11-09 22:40:05 --> Input Class Initialized
INFO - 2019-11-09 22:40:05 --> Language Class Initialized
INFO - 2019-11-09 22:40:05 --> Language Class Initialized
INFO - 2019-11-09 22:40:05 --> Config Class Initialized
INFO - 2019-11-09 22:40:05 --> Loader Class Initialized
INFO - 2019-11-09 22:40:05 --> Helper loaded: url_helper
INFO - 2019-11-09 22:40:05 --> Helper loaded: common_helper
INFO - 2019-11-09 22:40:05 --> Helper loaded: language_helper
INFO - 2019-11-09 22:40:05 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:40:05 --> Helper loaded: email_helper
INFO - 2019-11-09 22:40:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:40:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:40:05 --> Parser Class Initialized
INFO - 2019-11-09 22:40:05 --> User Agent Class Initialized
INFO - 2019-11-09 22:40:05 --> Model Class Initialized
INFO - 2019-11-09 22:40:05 --> Database Driver Class Initialized
INFO - 2019-11-09 22:40:05 --> Model Class Initialized
DEBUG - 2019-11-09 22:40:05 --> Template Class Initialized
INFO - 2019-11-09 22:40:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:40:06 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:40:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:40:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:40:06 --> Encryption Class Initialized
INFO - 2019-11-09 22:40:06 --> Controller Class Initialized
DEBUG - 2019-11-09 22:40:06 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:40:06 --> Model Class Initialized
INFO - 2019-11-09 22:40:06 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:40:06 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:40:06 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:40:06 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:40:06 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:40:06 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:40:06 --> Model Class Initialized
DEBUG - 2019-11-09 22:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:40:06 --> Model Class Initialized
DEBUG - 2019-11-09 22:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:40:06 --> Final output sent to browser
DEBUG - 2019-11-09 22:40:06 --> Total execution time: 1.2845
INFO - 2019-11-09 22:42:02 --> Config Class Initialized
INFO - 2019-11-09 22:42:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:42:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:42:02 --> Utf8 Class Initialized
INFO - 2019-11-09 22:42:02 --> URI Class Initialized
INFO - 2019-11-09 22:42:02 --> Router Class Initialized
INFO - 2019-11-09 22:42:02 --> Output Class Initialized
INFO - 2019-11-09 22:42:02 --> Security Class Initialized
DEBUG - 2019-11-09 22:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:42:02 --> CSRF cookie sent
INFO - 2019-11-09 22:42:02 --> CSRF token verified
INFO - 2019-11-09 22:42:02 --> Input Class Initialized
INFO - 2019-11-09 22:42:02 --> Language Class Initialized
INFO - 2019-11-09 22:42:02 --> Language Class Initialized
INFO - 2019-11-09 22:42:02 --> Config Class Initialized
INFO - 2019-11-09 22:42:02 --> Loader Class Initialized
INFO - 2019-11-09 22:42:02 --> Helper loaded: url_helper
INFO - 2019-11-09 22:42:02 --> Helper loaded: common_helper
INFO - 2019-11-09 22:42:02 --> Helper loaded: language_helper
INFO - 2019-11-09 22:42:02 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:42:02 --> Helper loaded: email_helper
INFO - 2019-11-09 22:42:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:42:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:42:02 --> Parser Class Initialized
INFO - 2019-11-09 22:42:02 --> User Agent Class Initialized
INFO - 2019-11-09 22:42:02 --> Model Class Initialized
INFO - 2019-11-09 22:42:02 --> Database Driver Class Initialized
INFO - 2019-11-09 22:42:02 --> Model Class Initialized
DEBUG - 2019-11-09 22:42:02 --> Template Class Initialized
INFO - 2019-11-09 22:42:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:42:02 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:42:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:42:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:42:02 --> Encryption Class Initialized
INFO - 2019-11-09 22:42:02 --> Controller Class Initialized
DEBUG - 2019-11-09 22:42:02 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:42:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:42:03 --> Model Class Initialized
INFO - 2019-11-09 22:42:03 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:42:03 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:42:03 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:42:03 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:42:03 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:42:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:42:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:42:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:42:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:42:03 --> Model Class Initialized
DEBUG - 2019-11-09 22:42:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:42:03 --> Model Class Initialized
DEBUG - 2019-11-09 22:42:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:42:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:42:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:42:03 --> Final output sent to browser
DEBUG - 2019-11-09 22:42:03 --> Total execution time: 1.2962
INFO - 2019-11-09 22:44:43 --> Config Class Initialized
INFO - 2019-11-09 22:44:43 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:44:43 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:44:43 --> Utf8 Class Initialized
INFO - 2019-11-09 22:44:43 --> URI Class Initialized
INFO - 2019-11-09 22:44:43 --> Router Class Initialized
INFO - 2019-11-09 22:44:43 --> Output Class Initialized
INFO - 2019-11-09 22:44:43 --> Security Class Initialized
DEBUG - 2019-11-09 22:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:44:43 --> CSRF cookie sent
INFO - 2019-11-09 22:44:43 --> CSRF token verified
INFO - 2019-11-09 22:44:43 --> Input Class Initialized
INFO - 2019-11-09 22:44:43 --> Language Class Initialized
INFO - 2019-11-09 22:44:43 --> Language Class Initialized
INFO - 2019-11-09 22:44:43 --> Config Class Initialized
INFO - 2019-11-09 22:44:43 --> Loader Class Initialized
INFO - 2019-11-09 22:44:43 --> Helper loaded: url_helper
INFO - 2019-11-09 22:44:43 --> Helper loaded: common_helper
INFO - 2019-11-09 22:44:43 --> Helper loaded: language_helper
INFO - 2019-11-09 22:44:43 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:44:43 --> Helper loaded: email_helper
INFO - 2019-11-09 22:44:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:44:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:44:43 --> Parser Class Initialized
INFO - 2019-11-09 22:44:43 --> User Agent Class Initialized
INFO - 2019-11-09 22:44:43 --> Model Class Initialized
INFO - 2019-11-09 22:44:43 --> Database Driver Class Initialized
INFO - 2019-11-09 22:44:43 --> Model Class Initialized
DEBUG - 2019-11-09 22:44:43 --> Template Class Initialized
INFO - 2019-11-09 22:44:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:44:43 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:44:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:44:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:44:43 --> Encryption Class Initialized
INFO - 2019-11-09 22:44:43 --> Controller Class Initialized
DEBUG - 2019-11-09 22:44:43 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:44:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:44:43 --> Model Class Initialized
INFO - 2019-11-09 22:44:44 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:44:44 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:44:44 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:44:44 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:44:44 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:44:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:44:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:44:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:44:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:44:44 --> Model Class Initialized
DEBUG - 2019-11-09 22:44:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:44:44 --> Model Class Initialized
DEBUG - 2019-11-09 22:44:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:44:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:44:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:44:44 --> Final output sent to browser
DEBUG - 2019-11-09 22:44:44 --> Total execution time: 1.4124
INFO - 2019-11-09 22:45:16 --> Config Class Initialized
INFO - 2019-11-09 22:45:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:45:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:45:16 --> Utf8 Class Initialized
INFO - 2019-11-09 22:45:16 --> URI Class Initialized
INFO - 2019-11-09 22:45:16 --> Router Class Initialized
INFO - 2019-11-09 22:45:16 --> Output Class Initialized
INFO - 2019-11-09 22:45:16 --> Security Class Initialized
DEBUG - 2019-11-09 22:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:45:16 --> CSRF cookie sent
INFO - 2019-11-09 22:45:16 --> CSRF token verified
INFO - 2019-11-09 22:45:16 --> Input Class Initialized
INFO - 2019-11-09 22:45:16 --> Language Class Initialized
INFO - 2019-11-09 22:45:16 --> Language Class Initialized
INFO - 2019-11-09 22:45:16 --> Config Class Initialized
INFO - 2019-11-09 22:45:16 --> Loader Class Initialized
INFO - 2019-11-09 22:45:16 --> Helper loaded: url_helper
INFO - 2019-11-09 22:45:16 --> Helper loaded: common_helper
INFO - 2019-11-09 22:45:16 --> Helper loaded: language_helper
INFO - 2019-11-09 22:45:16 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:45:16 --> Helper loaded: email_helper
INFO - 2019-11-09 22:45:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:45:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:45:16 --> Parser Class Initialized
INFO - 2019-11-09 22:45:16 --> User Agent Class Initialized
INFO - 2019-11-09 22:45:16 --> Model Class Initialized
INFO - 2019-11-09 22:45:16 --> Database Driver Class Initialized
INFO - 2019-11-09 22:45:16 --> Model Class Initialized
DEBUG - 2019-11-09 22:45:16 --> Template Class Initialized
INFO - 2019-11-09 22:45:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:45:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:45:16 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:45:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:45:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:45:16 --> Encryption Class Initialized
INFO - 2019-11-09 22:45:16 --> Controller Class Initialized
DEBUG - 2019-11-09 22:45:17 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:45:17 --> Model Class Initialized
INFO - 2019-11-09 22:45:17 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:45:17 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:45:17 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:45:17 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:45:17 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:45:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:45:17 --> Model Class Initialized
DEBUG - 2019-11-09 22:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:45:17 --> Model Class Initialized
DEBUG - 2019-11-09 22:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:45:17 --> Final output sent to browser
DEBUG - 2019-11-09 22:45:17 --> Total execution time: 1.2719
INFO - 2019-11-09 22:48:07 --> Config Class Initialized
INFO - 2019-11-09 22:48:07 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:48:07 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:48:07 --> Utf8 Class Initialized
INFO - 2019-11-09 22:48:07 --> URI Class Initialized
INFO - 2019-11-09 22:48:07 --> Router Class Initialized
INFO - 2019-11-09 22:48:07 --> Output Class Initialized
INFO - 2019-11-09 22:48:07 --> Security Class Initialized
DEBUG - 2019-11-09 22:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:48:07 --> Input Class Initialized
INFO - 2019-11-09 22:48:07 --> Language Class Initialized
INFO - 2019-11-09 22:48:07 --> Language Class Initialized
INFO - 2019-11-09 22:48:07 --> Config Class Initialized
INFO - 2019-11-09 22:48:07 --> Loader Class Initialized
INFO - 2019-11-09 22:48:07 --> Helper loaded: url_helper
INFO - 2019-11-09 22:48:07 --> Helper loaded: common_helper
INFO - 2019-11-09 22:48:07 --> Helper loaded: language_helper
INFO - 2019-11-09 22:48:07 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:48:07 --> Helper loaded: email_helper
INFO - 2019-11-09 22:48:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:48:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:48:07 --> Parser Class Initialized
INFO - 2019-11-09 22:48:07 --> User Agent Class Initialized
INFO - 2019-11-09 22:48:07 --> Model Class Initialized
INFO - 2019-11-09 22:48:07 --> Database Driver Class Initialized
INFO - 2019-11-09 22:48:07 --> Model Class Initialized
DEBUG - 2019-11-09 22:48:07 --> Template Class Initialized
INFO - 2019-11-09 22:48:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:48:07 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:48:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:48:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:48:07 --> Encryption Class Initialized
INFO - 2019-11-09 22:48:07 --> Controller Class Initialized
DEBUG - 2019-11-09 22:48:08 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 22:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2019-11-09 22:48:08 --> Model Class Initialized
INFO - 2019-11-09 22:48:08 --> Config Class Initialized
INFO - 2019-11-09 22:48:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:48:08 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:48:08 --> Utf8 Class Initialized
INFO - 2019-11-09 22:48:08 --> URI Class Initialized
DEBUG - 2019-11-09 22:48:08 --> No URI present. Default controller set.
INFO - 2019-11-09 22:48:08 --> Router Class Initialized
INFO - 2019-11-09 22:48:08 --> Output Class Initialized
INFO - 2019-11-09 22:48:08 --> Security Class Initialized
DEBUG - 2019-11-09 22:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:48:08 --> CSRF cookie sent
INFO - 2019-11-09 22:48:08 --> Input Class Initialized
INFO - 2019-11-09 22:48:08 --> Language Class Initialized
INFO - 2019-11-09 22:48:08 --> Language Class Initialized
INFO - 2019-11-09 22:48:08 --> Config Class Initialized
INFO - 2019-11-09 22:48:08 --> Loader Class Initialized
INFO - 2019-11-09 22:48:08 --> Helper loaded: url_helper
INFO - 2019-11-09 22:48:08 --> Helper loaded: common_helper
INFO - 2019-11-09 22:48:08 --> Helper loaded: language_helper
INFO - 2019-11-09 22:48:08 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:48:08 --> Helper loaded: email_helper
INFO - 2019-11-09 22:48:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:48:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:48:08 --> Parser Class Initialized
INFO - 2019-11-09 22:48:08 --> User Agent Class Initialized
INFO - 2019-11-09 22:48:08 --> Model Class Initialized
INFO - 2019-11-09 22:48:08 --> Database Driver Class Initialized
INFO - 2019-11-09 22:48:08 --> Model Class Initialized
DEBUG - 2019-11-09 22:48:08 --> Template Class Initialized
INFO - 2019-11-09 22:48:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:48:08 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:48:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:48:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:48:08 --> Encryption Class Initialized
DEBUG - 2019-11-09 22:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 22:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 22:48:08 --> Controller Class Initialized
DEBUG - 2019-11-09 22:48:08 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 22:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 22:48:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 22:48:09 --> Model Class Initialized
INFO - 2019-11-09 22:48:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 22:48:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 22:48:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 22:48:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 22:48:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 22:48:09 --> Final output sent to browser
DEBUG - 2019-11-09 22:48:09 --> Total execution time: 1.1997
INFO - 2019-11-09 22:52:26 --> Config Class Initialized
INFO - 2019-11-09 22:52:26 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:52:26 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:52:26 --> Utf8 Class Initialized
INFO - 2019-11-09 22:52:26 --> URI Class Initialized
INFO - 2019-11-09 22:52:26 --> Router Class Initialized
INFO - 2019-11-09 22:52:26 --> Output Class Initialized
INFO - 2019-11-09 22:52:26 --> Security Class Initialized
DEBUG - 2019-11-09 22:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:52:26 --> CSRF cookie sent
INFO - 2019-11-09 22:52:26 --> CSRF token verified
INFO - 2019-11-09 22:52:26 --> Input Class Initialized
INFO - 2019-11-09 22:52:26 --> Language Class Initialized
INFO - 2019-11-09 22:52:26 --> Language Class Initialized
INFO - 2019-11-09 22:52:26 --> Config Class Initialized
INFO - 2019-11-09 22:52:26 --> Loader Class Initialized
INFO - 2019-11-09 22:52:26 --> Helper loaded: url_helper
INFO - 2019-11-09 22:52:26 --> Helper loaded: common_helper
INFO - 2019-11-09 22:52:26 --> Helper loaded: language_helper
INFO - 2019-11-09 22:52:26 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:52:26 --> Helper loaded: email_helper
INFO - 2019-11-09 22:52:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:52:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:52:26 --> Parser Class Initialized
INFO - 2019-11-09 22:52:26 --> User Agent Class Initialized
INFO - 2019-11-09 22:52:26 --> Model Class Initialized
INFO - 2019-11-09 22:52:26 --> Database Driver Class Initialized
INFO - 2019-11-09 22:52:26 --> Model Class Initialized
DEBUG - 2019-11-09 22:52:26 --> Template Class Initialized
INFO - 2019-11-09 22:52:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:52:26 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:52:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:52:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:52:27 --> Encryption Class Initialized
INFO - 2019-11-09 22:52:27 --> Controller Class Initialized
DEBUG - 2019-11-09 22:52:27 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:52:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:52:27 --> Model Class Initialized
INFO - 2019-11-09 22:52:27 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:52:27 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:52:27 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:52:27 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:52:27 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:52:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:52:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:52:27 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:52:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:52:27 --> Model Class Initialized
DEBUG - 2019-11-09 22:52:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:52:27 --> Model Class Initialized
DEBUG - 2019-11-09 22:52:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:52:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:52:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:52:27 --> Final output sent to browser
DEBUG - 2019-11-09 22:52:27 --> Total execution time: 1.3960
INFO - 2019-11-09 22:55:19 --> Config Class Initialized
INFO - 2019-11-09 22:55:19 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:55:19 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:55:19 --> Utf8 Class Initialized
INFO - 2019-11-09 22:55:19 --> URI Class Initialized
INFO - 2019-11-09 22:55:19 --> Router Class Initialized
INFO - 2019-11-09 22:55:19 --> Output Class Initialized
INFO - 2019-11-09 22:55:19 --> Security Class Initialized
DEBUG - 2019-11-09 22:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:55:19 --> CSRF cookie sent
INFO - 2019-11-09 22:55:19 --> CSRF token verified
INFO - 2019-11-09 22:55:19 --> Input Class Initialized
INFO - 2019-11-09 22:55:19 --> Language Class Initialized
INFO - 2019-11-09 22:55:19 --> Language Class Initialized
INFO - 2019-11-09 22:55:19 --> Config Class Initialized
INFO - 2019-11-09 22:55:19 --> Loader Class Initialized
INFO - 2019-11-09 22:55:19 --> Helper loaded: url_helper
INFO - 2019-11-09 22:55:19 --> Helper loaded: common_helper
INFO - 2019-11-09 22:55:19 --> Helper loaded: language_helper
INFO - 2019-11-09 22:55:19 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:55:19 --> Helper loaded: email_helper
INFO - 2019-11-09 22:55:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:55:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:55:19 --> Parser Class Initialized
INFO - 2019-11-09 22:55:19 --> User Agent Class Initialized
INFO - 2019-11-09 22:55:19 --> Model Class Initialized
INFO - 2019-11-09 22:55:19 --> Database Driver Class Initialized
INFO - 2019-11-09 22:55:19 --> Model Class Initialized
DEBUG - 2019-11-09 22:55:19 --> Template Class Initialized
INFO - 2019-11-09 22:55:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:55:20 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:55:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:55:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:55:20 --> Encryption Class Initialized
INFO - 2019-11-09 22:55:20 --> Controller Class Initialized
DEBUG - 2019-11-09 22:55:20 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:55:20 --> Model Class Initialized
INFO - 2019-11-09 22:55:20 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:55:20 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:55:20 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:55:20 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:55:20 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:55:20 --> Model Class Initialized
DEBUG - 2019-11-09 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:55:20 --> Model Class Initialized
DEBUG - 2019-11-09 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:55:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:55:20 --> Final output sent to browser
DEBUG - 2019-11-09 22:55:20 --> Total execution time: 1.2889
INFO - 2019-11-09 22:55:28 --> Config Class Initialized
INFO - 2019-11-09 22:55:28 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:55:28 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:55:28 --> Utf8 Class Initialized
INFO - 2019-11-09 22:55:28 --> URI Class Initialized
INFO - 2019-11-09 22:55:28 --> Router Class Initialized
INFO - 2019-11-09 22:55:28 --> Output Class Initialized
INFO - 2019-11-09 22:55:29 --> Security Class Initialized
DEBUG - 2019-11-09 22:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:55:29 --> CSRF cookie sent
INFO - 2019-11-09 22:55:29 --> CSRF token verified
INFO - 2019-11-09 22:55:29 --> Input Class Initialized
INFO - 2019-11-09 22:55:29 --> Language Class Initialized
INFO - 2019-11-09 22:55:29 --> Language Class Initialized
INFO - 2019-11-09 22:55:29 --> Config Class Initialized
INFO - 2019-11-09 22:55:29 --> Loader Class Initialized
INFO - 2019-11-09 22:55:29 --> Helper loaded: url_helper
INFO - 2019-11-09 22:55:29 --> Helper loaded: common_helper
INFO - 2019-11-09 22:55:29 --> Helper loaded: language_helper
INFO - 2019-11-09 22:55:29 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:55:29 --> Helper loaded: email_helper
INFO - 2019-11-09 22:55:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:55:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:55:29 --> Parser Class Initialized
INFO - 2019-11-09 22:55:29 --> User Agent Class Initialized
INFO - 2019-11-09 22:55:29 --> Model Class Initialized
INFO - 2019-11-09 22:55:29 --> Database Driver Class Initialized
INFO - 2019-11-09 22:55:29 --> Model Class Initialized
DEBUG - 2019-11-09 22:55:29 --> Template Class Initialized
INFO - 2019-11-09 22:55:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:55:29 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:55:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:55:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:55:29 --> Encryption Class Initialized
INFO - 2019-11-09 22:55:29 --> Controller Class Initialized
DEBUG - 2019-11-09 22:55:29 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:55:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:55:29 --> Model Class Initialized
DEBUG - 2019-11-09 22:55:29 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 22:55:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 22:55:29 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:55:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 22:55:29 --> Final output sent to browser
DEBUG - 2019-11-09 22:55:29 --> Total execution time: 1.0039
INFO - 2019-11-09 22:56:52 --> Config Class Initialized
INFO - 2019-11-09 22:56:52 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:56:52 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:56:52 --> Utf8 Class Initialized
INFO - 2019-11-09 22:56:52 --> URI Class Initialized
INFO - 2019-11-09 22:56:52 --> Router Class Initialized
INFO - 2019-11-09 22:56:52 --> Output Class Initialized
INFO - 2019-11-09 22:56:52 --> Security Class Initialized
DEBUG - 2019-11-09 22:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:56:52 --> CSRF cookie sent
INFO - 2019-11-09 22:56:53 --> CSRF token verified
INFO - 2019-11-09 22:56:53 --> Input Class Initialized
INFO - 2019-11-09 22:56:53 --> Language Class Initialized
INFO - 2019-11-09 22:56:53 --> Language Class Initialized
INFO - 2019-11-09 22:56:53 --> Config Class Initialized
INFO - 2019-11-09 22:56:53 --> Loader Class Initialized
INFO - 2019-11-09 22:56:53 --> Helper loaded: url_helper
INFO - 2019-11-09 22:56:53 --> Helper loaded: common_helper
INFO - 2019-11-09 22:56:53 --> Helper loaded: language_helper
INFO - 2019-11-09 22:56:53 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:56:53 --> Helper loaded: email_helper
INFO - 2019-11-09 22:56:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:56:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:56:53 --> Parser Class Initialized
INFO - 2019-11-09 22:56:53 --> User Agent Class Initialized
INFO - 2019-11-09 22:56:53 --> Model Class Initialized
INFO - 2019-11-09 22:56:53 --> Database Driver Class Initialized
INFO - 2019-11-09 22:56:53 --> Model Class Initialized
DEBUG - 2019-11-09 22:56:53 --> Template Class Initialized
INFO - 2019-11-09 22:56:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:56:53 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:56:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:56:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:56:53 --> Encryption Class Initialized
INFO - 2019-11-09 22:56:53 --> Controller Class Initialized
DEBUG - 2019-11-09 22:56:53 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:56:53 --> Model Class Initialized
INFO - 2019-11-09 22:56:53 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:56:53 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:56:53 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:56:53 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:56:53 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:56:53 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:56:53 --> Model Class Initialized
DEBUG - 2019-11-09 22:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:56:53 --> Model Class Initialized
DEBUG - 2019-11-09 22:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:56:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:56:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:56:54 --> Final output sent to browser
DEBUG - 2019-11-09 22:56:54 --> Total execution time: 1.3115
INFO - 2019-11-09 22:57:08 --> Config Class Initialized
INFO - 2019-11-09 22:57:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:57:08 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:57:08 --> Utf8 Class Initialized
INFO - 2019-11-09 22:57:08 --> URI Class Initialized
INFO - 2019-11-09 22:57:08 --> Router Class Initialized
INFO - 2019-11-09 22:57:08 --> Output Class Initialized
INFO - 2019-11-09 22:57:08 --> Security Class Initialized
DEBUG - 2019-11-09 22:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:57:08 --> CSRF cookie sent
INFO - 2019-11-09 22:57:08 --> CSRF token verified
INFO - 2019-11-09 22:57:08 --> Input Class Initialized
INFO - 2019-11-09 22:57:08 --> Language Class Initialized
INFO - 2019-11-09 22:57:08 --> Language Class Initialized
INFO - 2019-11-09 22:57:08 --> Config Class Initialized
INFO - 2019-11-09 22:57:09 --> Loader Class Initialized
INFO - 2019-11-09 22:57:09 --> Helper loaded: url_helper
INFO - 2019-11-09 22:57:09 --> Helper loaded: common_helper
INFO - 2019-11-09 22:57:09 --> Helper loaded: language_helper
INFO - 2019-11-09 22:57:09 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:57:09 --> Helper loaded: email_helper
INFO - 2019-11-09 22:57:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:57:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:57:09 --> Parser Class Initialized
INFO - 2019-11-09 22:57:09 --> User Agent Class Initialized
INFO - 2019-11-09 22:57:09 --> Model Class Initialized
INFO - 2019-11-09 22:57:09 --> Database Driver Class Initialized
INFO - 2019-11-09 22:57:09 --> Model Class Initialized
DEBUG - 2019-11-09 22:57:09 --> Template Class Initialized
INFO - 2019-11-09 22:57:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:57:09 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:57:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:57:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:57:09 --> Encryption Class Initialized
INFO - 2019-11-09 22:57:09 --> Controller Class Initialized
DEBUG - 2019-11-09 22:57:09 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:57:09 --> Model Class Initialized
DEBUG - 2019-11-09 22:57:09 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 22:57:09 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:57:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 22:57:09 --> Final output sent to browser
DEBUG - 2019-11-09 22:57:09 --> Total execution time: 0.9966
INFO - 2019-11-09 22:58:21 --> Config Class Initialized
INFO - 2019-11-09 22:58:21 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:58:21 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:58:21 --> Utf8 Class Initialized
INFO - 2019-11-09 22:58:21 --> URI Class Initialized
INFO - 2019-11-09 22:58:21 --> Router Class Initialized
INFO - 2019-11-09 22:58:21 --> Output Class Initialized
INFO - 2019-11-09 22:58:21 --> Security Class Initialized
DEBUG - 2019-11-09 22:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:58:21 --> CSRF cookie sent
INFO - 2019-11-09 22:58:21 --> CSRF token verified
INFO - 2019-11-09 22:58:21 --> Input Class Initialized
INFO - 2019-11-09 22:58:21 --> Language Class Initialized
INFO - 2019-11-09 22:58:21 --> Language Class Initialized
INFO - 2019-11-09 22:58:21 --> Config Class Initialized
INFO - 2019-11-09 22:58:21 --> Loader Class Initialized
INFO - 2019-11-09 22:58:21 --> Helper loaded: url_helper
INFO - 2019-11-09 22:58:21 --> Helper loaded: common_helper
INFO - 2019-11-09 22:58:21 --> Helper loaded: language_helper
INFO - 2019-11-09 22:58:21 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:58:21 --> Helper loaded: email_helper
INFO - 2019-11-09 22:58:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:58:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:58:22 --> Parser Class Initialized
INFO - 2019-11-09 22:58:22 --> User Agent Class Initialized
INFO - 2019-11-09 22:58:22 --> Model Class Initialized
INFO - 2019-11-09 22:58:22 --> Database Driver Class Initialized
INFO - 2019-11-09 22:58:22 --> Model Class Initialized
DEBUG - 2019-11-09 22:58:22 --> Template Class Initialized
INFO - 2019-11-09 22:58:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:58:22 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:58:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:58:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:58:22 --> Encryption Class Initialized
INFO - 2019-11-09 22:58:22 --> Controller Class Initialized
DEBUG - 2019-11-09 22:58:22 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:58:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:58:22 --> Model Class Initialized
INFO - 2019-11-09 22:58:22 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:58:22 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:58:22 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:58:22 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:58:22 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:58:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:58:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:58:22 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:58:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:58:22 --> Model Class Initialized
DEBUG - 2019-11-09 22:58:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:58:22 --> Model Class Initialized
DEBUG - 2019-11-09 22:58:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:58:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:58:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:58:22 --> Final output sent to browser
DEBUG - 2019-11-09 22:58:22 --> Total execution time: 1.2821
INFO - 2019-11-09 22:58:39 --> Config Class Initialized
INFO - 2019-11-09 22:58:39 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:58:39 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:58:39 --> Utf8 Class Initialized
INFO - 2019-11-09 22:58:39 --> URI Class Initialized
INFO - 2019-11-09 22:58:39 --> Router Class Initialized
INFO - 2019-11-09 22:58:39 --> Output Class Initialized
INFO - 2019-11-09 22:58:39 --> Security Class Initialized
DEBUG - 2019-11-09 22:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:58:39 --> CSRF cookie sent
INFO - 2019-11-09 22:58:39 --> CSRF token verified
INFO - 2019-11-09 22:58:39 --> Input Class Initialized
INFO - 2019-11-09 22:58:40 --> Language Class Initialized
INFO - 2019-11-09 22:58:40 --> Language Class Initialized
INFO - 2019-11-09 22:58:40 --> Config Class Initialized
INFO - 2019-11-09 22:58:40 --> Loader Class Initialized
INFO - 2019-11-09 22:58:40 --> Helper loaded: url_helper
INFO - 2019-11-09 22:58:40 --> Helper loaded: common_helper
INFO - 2019-11-09 22:58:40 --> Helper loaded: language_helper
INFO - 2019-11-09 22:58:40 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:58:40 --> Helper loaded: email_helper
INFO - 2019-11-09 22:58:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:58:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:58:40 --> Parser Class Initialized
INFO - 2019-11-09 22:58:40 --> User Agent Class Initialized
INFO - 2019-11-09 22:58:40 --> Model Class Initialized
INFO - 2019-11-09 22:58:40 --> Database Driver Class Initialized
INFO - 2019-11-09 22:58:40 --> Model Class Initialized
DEBUG - 2019-11-09 22:58:40 --> Template Class Initialized
INFO - 2019-11-09 22:58:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:58:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:58:40 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:58:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:58:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:58:40 --> Encryption Class Initialized
INFO - 2019-11-09 22:58:40 --> Controller Class Initialized
DEBUG - 2019-11-09 22:58:40 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:58:40 --> Model Class Initialized
DEBUG - 2019-11-09 22:58:40 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 22:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 22:58:40 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 22:58:40 --> Final output sent to browser
DEBUG - 2019-11-09 22:58:40 --> Total execution time: 1.0378
INFO - 2019-11-09 22:59:08 --> Config Class Initialized
INFO - 2019-11-09 22:59:08 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:59:08 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:59:08 --> Utf8 Class Initialized
INFO - 2019-11-09 22:59:08 --> URI Class Initialized
INFO - 2019-11-09 22:59:08 --> Router Class Initialized
INFO - 2019-11-09 22:59:08 --> Output Class Initialized
INFO - 2019-11-09 22:59:09 --> Security Class Initialized
DEBUG - 2019-11-09 22:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:59:09 --> CSRF cookie sent
INFO - 2019-11-09 22:59:09 --> CSRF token verified
INFO - 2019-11-09 22:59:09 --> Input Class Initialized
INFO - 2019-11-09 22:59:09 --> Language Class Initialized
INFO - 2019-11-09 22:59:09 --> Language Class Initialized
INFO - 2019-11-09 22:59:09 --> Config Class Initialized
INFO - 2019-11-09 22:59:09 --> Loader Class Initialized
INFO - 2019-11-09 22:59:09 --> Helper loaded: url_helper
INFO - 2019-11-09 22:59:09 --> Helper loaded: common_helper
INFO - 2019-11-09 22:59:09 --> Helper loaded: language_helper
INFO - 2019-11-09 22:59:09 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:59:09 --> Helper loaded: email_helper
INFO - 2019-11-09 22:59:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:59:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:59:09 --> Parser Class Initialized
INFO - 2019-11-09 22:59:09 --> User Agent Class Initialized
INFO - 2019-11-09 22:59:09 --> Model Class Initialized
INFO - 2019-11-09 22:59:09 --> Database Driver Class Initialized
INFO - 2019-11-09 22:59:09 --> Model Class Initialized
DEBUG - 2019-11-09 22:59:09 --> Template Class Initialized
INFO - 2019-11-09 22:59:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:59:09 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:59:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:59:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:59:09 --> Encryption Class Initialized
INFO - 2019-11-09 22:59:09 --> Controller Class Initialized
DEBUG - 2019-11-09 22:59:09 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:59:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:59:09 --> Model Class Initialized
INFO - 2019-11-09 22:59:09 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 22:59:09 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 22:59:09 --> Could not find the language line "paystack"
ERROR - 2019-11-09 22:59:09 --> Could not find the language line "paytm"
ERROR - 2019-11-09 22:59:09 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:59:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 22:59:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 22:59:09 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 22:59:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 22:59:09 --> Model Class Initialized
DEBUG - 2019-11-09 22:59:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 22:59:10 --> Model Class Initialized
DEBUG - 2019-11-09 22:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 22:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 22:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 22:59:10 --> Final output sent to browser
DEBUG - 2019-11-09 22:59:10 --> Total execution time: 1.3034
INFO - 2019-11-09 22:59:19 --> Config Class Initialized
INFO - 2019-11-09 22:59:19 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:59:19 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:59:19 --> Utf8 Class Initialized
INFO - 2019-11-09 22:59:19 --> URI Class Initialized
INFO - 2019-11-09 22:59:19 --> Router Class Initialized
INFO - 2019-11-09 22:59:19 --> Output Class Initialized
INFO - 2019-11-09 22:59:19 --> Security Class Initialized
DEBUG - 2019-11-09 22:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:59:19 --> CSRF cookie sent
INFO - 2019-11-09 22:59:19 --> CSRF token verified
INFO - 2019-11-09 22:59:19 --> Input Class Initialized
INFO - 2019-11-09 22:59:19 --> Language Class Initialized
INFO - 2019-11-09 22:59:19 --> Language Class Initialized
INFO - 2019-11-09 22:59:19 --> Config Class Initialized
INFO - 2019-11-09 22:59:19 --> Loader Class Initialized
INFO - 2019-11-09 22:59:19 --> Helper loaded: url_helper
INFO - 2019-11-09 22:59:19 --> Helper loaded: common_helper
INFO - 2019-11-09 22:59:19 --> Helper loaded: language_helper
INFO - 2019-11-09 22:59:19 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:59:19 --> Helper loaded: email_helper
INFO - 2019-11-09 22:59:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:59:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:59:19 --> Parser Class Initialized
INFO - 2019-11-09 22:59:19 --> User Agent Class Initialized
INFO - 2019-11-09 22:59:19 --> Model Class Initialized
INFO - 2019-11-09 22:59:19 --> Database Driver Class Initialized
INFO - 2019-11-09 22:59:19 --> Model Class Initialized
DEBUG - 2019-11-09 22:59:19 --> Template Class Initialized
INFO - 2019-11-09 22:59:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:59:20 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:59:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:59:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:59:20 --> Encryption Class Initialized
INFO - 2019-11-09 22:59:20 --> Controller Class Initialized
DEBUG - 2019-11-09 22:59:20 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 22:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 22:59:20 --> Model Class Initialized
DEBUG - 2019-11-09 22:59:20 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 22:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 22:59:20 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 22:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 22:59:20 --> Final output sent to browser
DEBUG - 2019-11-09 22:59:20 --> Total execution time: 1.0575
INFO - 2019-11-09 22:59:59 --> Config Class Initialized
INFO - 2019-11-09 22:59:59 --> Hooks Class Initialized
DEBUG - 2019-11-09 22:59:59 --> UTF-8 Support Enabled
INFO - 2019-11-09 22:59:59 --> Utf8 Class Initialized
INFO - 2019-11-09 22:59:59 --> URI Class Initialized
INFO - 2019-11-09 22:59:59 --> Router Class Initialized
INFO - 2019-11-09 22:59:59 --> Output Class Initialized
INFO - 2019-11-09 22:59:59 --> Security Class Initialized
DEBUG - 2019-11-09 22:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 22:59:59 --> Input Class Initialized
INFO - 2019-11-09 22:59:59 --> Language Class Initialized
INFO - 2019-11-09 22:59:59 --> Language Class Initialized
INFO - 2019-11-09 22:59:59 --> Config Class Initialized
INFO - 2019-11-09 22:59:59 --> Loader Class Initialized
INFO - 2019-11-09 22:59:59 --> Helper loaded: url_helper
INFO - 2019-11-09 22:59:59 --> Helper loaded: common_helper
INFO - 2019-11-09 22:59:59 --> Helper loaded: language_helper
INFO - 2019-11-09 22:59:59 --> Helper loaded: cookie_helper
INFO - 2019-11-09 22:59:59 --> Helper loaded: email_helper
INFO - 2019-11-09 22:59:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 22:59:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 22:59:59 --> Parser Class Initialized
INFO - 2019-11-09 22:59:59 --> User Agent Class Initialized
INFO - 2019-11-09 22:59:59 --> Model Class Initialized
INFO - 2019-11-09 22:59:59 --> Database Driver Class Initialized
INFO - 2019-11-09 22:59:59 --> Model Class Initialized
DEBUG - 2019-11-09 22:59:59 --> Template Class Initialized
INFO - 2019-11-09 22:59:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 22:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 22:59:59 --> Pagination Class Initialized
DEBUG - 2019-11-09 22:59:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 22:59:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 22:59:59 --> Encryption Class Initialized
INFO - 2019-11-09 22:59:59 --> Controller Class Initialized
DEBUG - 2019-11-09 22:59:59 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 22:59:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2019-11-09 22:59:59 --> Model Class Initialized
DEBUG - 2019-11-09 23:00:01 --> orders MX_Controller Initialized
INFO - 2019-11-09 23:00:01 --> Config Class Initialized
INFO - 2019-11-09 23:00:01 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:00:01 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:00:01 --> Utf8 Class Initialized
INFO - 2019-11-09 23:00:01 --> URI Class Initialized
INFO - 2019-11-09 23:00:01 --> Router Class Initialized
INFO - 2019-11-09 23:00:01 --> Output Class Initialized
INFO - 2019-11-09 23:00:01 --> Security Class Initialized
DEBUG - 2019-11-09 23:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:00:01 --> CSRF cookie sent
INFO - 2019-11-09 23:00:02 --> Input Class Initialized
INFO - 2019-11-09 23:00:02 --> Language Class Initialized
INFO - 2019-11-09 23:00:02 --> Language Class Initialized
INFO - 2019-11-09 23:00:02 --> Config Class Initialized
INFO - 2019-11-09 23:00:02 --> Loader Class Initialized
INFO - 2019-11-09 23:00:02 --> Helper loaded: url_helper
INFO - 2019-11-09 23:00:02 --> Helper loaded: common_helper
INFO - 2019-11-09 23:00:02 --> Helper loaded: language_helper
INFO - 2019-11-09 23:00:02 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:00:02 --> Helper loaded: email_helper
INFO - 2019-11-09 23:00:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:00:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:00:02 --> Parser Class Initialized
INFO - 2019-11-09 23:00:02 --> User Agent Class Initialized
INFO - 2019-11-09 23:00:02 --> Model Class Initialized
INFO - 2019-11-09 23:00:02 --> Database Driver Class Initialized
INFO - 2019-11-09 23:00:02 --> Model Class Initialized
DEBUG - 2019-11-09 23:00:02 --> Template Class Initialized
INFO - 2019-11-09 23:00:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:00:02 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:00:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:00:02 --> Encryption Class Initialized
INFO - 2019-11-09 23:00:02 --> Controller Class Initialized
DEBUG - 2019-11-09 23:00:02 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:00:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:00:02 --> Model Class Initialized
INFO - 2019-11-09 23:00:02 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 23:00:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-09 23:00:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:00:02 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:00:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:00:02 --> Model Class Initialized
DEBUG - 2019-11-09 23:00:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:00:02 --> Model Class Initialized
DEBUG - 2019-11-09 23:00:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 23:00:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 23:00:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 23:00:02 --> Final output sent to browser
DEBUG - 2019-11-09 23:00:02 --> Total execution time: 1.1243
INFO - 2019-11-09 23:02:48 --> Config Class Initialized
INFO - 2019-11-09 23:02:48 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:02:48 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:02:48 --> Utf8 Class Initialized
INFO - 2019-11-09 23:02:48 --> URI Class Initialized
INFO - 2019-11-09 23:02:48 --> Router Class Initialized
INFO - 2019-11-09 23:02:48 --> Output Class Initialized
INFO - 2019-11-09 23:02:48 --> Security Class Initialized
DEBUG - 2019-11-09 23:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:02:48 --> CSRF cookie sent
INFO - 2019-11-09 23:02:49 --> Input Class Initialized
INFO - 2019-11-09 23:02:49 --> Language Class Initialized
INFO - 2019-11-09 23:02:49 --> Language Class Initialized
INFO - 2019-11-09 23:02:49 --> Config Class Initialized
INFO - 2019-11-09 23:02:49 --> Loader Class Initialized
INFO - 2019-11-09 23:02:49 --> Helper loaded: url_helper
INFO - 2019-11-09 23:02:49 --> Helper loaded: common_helper
INFO - 2019-11-09 23:02:49 --> Helper loaded: language_helper
INFO - 2019-11-09 23:02:49 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:02:49 --> Helper loaded: email_helper
INFO - 2019-11-09 23:02:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:02:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:02:49 --> Parser Class Initialized
INFO - 2019-11-09 23:02:49 --> User Agent Class Initialized
INFO - 2019-11-09 23:02:49 --> Model Class Initialized
INFO - 2019-11-09 23:02:49 --> Database Driver Class Initialized
INFO - 2019-11-09 23:02:49 --> Model Class Initialized
DEBUG - 2019-11-09 23:02:49 --> Template Class Initialized
INFO - 2019-11-09 23:02:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:02:49 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:02:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:02:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:02:49 --> Encryption Class Initialized
INFO - 2019-11-09 23:02:49 --> Controller Class Initialized
DEBUG - 2019-11-09 23:02:49 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:02:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:02:49 --> Model Class Initialized
INFO - 2019-11-09 23:02:49 --> Config Class Initialized
INFO - 2019-11-09 23:02:49 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:02:49 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:02:49 --> Utf8 Class Initialized
INFO - 2019-11-09 23:02:49 --> URI Class Initialized
DEBUG - 2019-11-09 23:02:49 --> No URI present. Default controller set.
INFO - 2019-11-09 23:02:49 --> Router Class Initialized
INFO - 2019-11-09 23:02:49 --> Output Class Initialized
INFO - 2019-11-09 23:02:49 --> Security Class Initialized
DEBUG - 2019-11-09 23:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:02:49 --> CSRF cookie sent
INFO - 2019-11-09 23:02:49 --> Input Class Initialized
INFO - 2019-11-09 23:02:50 --> Language Class Initialized
INFO - 2019-11-09 23:02:50 --> Language Class Initialized
INFO - 2019-11-09 23:02:50 --> Config Class Initialized
INFO - 2019-11-09 23:02:50 --> Loader Class Initialized
INFO - 2019-11-09 23:02:50 --> Helper loaded: url_helper
INFO - 2019-11-09 23:02:50 --> Helper loaded: common_helper
INFO - 2019-11-09 23:02:50 --> Helper loaded: language_helper
INFO - 2019-11-09 23:02:50 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:02:50 --> Helper loaded: email_helper
INFO - 2019-11-09 23:02:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:02:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:02:50 --> Parser Class Initialized
INFO - 2019-11-09 23:02:50 --> User Agent Class Initialized
INFO - 2019-11-09 23:02:50 --> Model Class Initialized
INFO - 2019-11-09 23:02:50 --> Database Driver Class Initialized
INFO - 2019-11-09 23:02:50 --> Model Class Initialized
DEBUG - 2019-11-09 23:02:50 --> Template Class Initialized
INFO - 2019-11-09 23:02:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:02:50 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:02:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:02:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:02:50 --> Encryption Class Initialized
DEBUG - 2019-11-09 23:02:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 23:02:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 23:02:50 --> Controller Class Initialized
DEBUG - 2019-11-09 23:02:50 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 23:02:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 23:02:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 23:02:50 --> Model Class Initialized
INFO - 2019-11-09 23:02:50 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 23:02:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 23:02:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 23:02:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 23:02:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 23:02:50 --> Final output sent to browser
DEBUG - 2019-11-09 23:02:50 --> Total execution time: 1.2785
INFO - 2019-11-09 23:03:11 --> Config Class Initialized
INFO - 2019-11-09 23:03:11 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:03:11 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:03:11 --> Utf8 Class Initialized
INFO - 2019-11-09 23:03:11 --> URI Class Initialized
INFO - 2019-11-09 23:03:11 --> Router Class Initialized
INFO - 2019-11-09 23:03:11 --> Output Class Initialized
INFO - 2019-11-09 23:03:11 --> Security Class Initialized
DEBUG - 2019-11-09 23:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:03:11 --> CSRF cookie sent
INFO - 2019-11-09 23:03:11 --> Input Class Initialized
INFO - 2019-11-09 23:03:11 --> Language Class Initialized
INFO - 2019-11-09 23:03:11 --> Language Class Initialized
INFO - 2019-11-09 23:03:11 --> Config Class Initialized
INFO - 2019-11-09 23:03:11 --> Loader Class Initialized
INFO - 2019-11-09 23:03:11 --> Helper loaded: url_helper
INFO - 2019-11-09 23:03:11 --> Helper loaded: common_helper
INFO - 2019-11-09 23:03:11 --> Helper loaded: language_helper
INFO - 2019-11-09 23:03:11 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:03:11 --> Helper loaded: email_helper
INFO - 2019-11-09 23:03:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:03:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:03:11 --> Parser Class Initialized
INFO - 2019-11-09 23:03:11 --> User Agent Class Initialized
INFO - 2019-11-09 23:03:11 --> Model Class Initialized
INFO - 2019-11-09 23:03:11 --> Database Driver Class Initialized
INFO - 2019-11-09 23:03:11 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:11 --> Template Class Initialized
INFO - 2019-11-09 23:03:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:03:12 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:03:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:03:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:03:12 --> Encryption Class Initialized
INFO - 2019-11-09 23:03:12 --> Controller Class Initialized
DEBUG - 2019-11-09 23:03:12 --> package MX_Controller Initialized
DEBUG - 2019-11-09 23:03:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-09 23:03:12 --> Model Class Initialized
INFO - 2019-11-09 23:03:12 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 23:03:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:03:12 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:03:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:03:12 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:03:12 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-09 23:03:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-09 23:03:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 23:03:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 23:03:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 23:03:12 --> Final output sent to browser
DEBUG - 2019-11-09 23:03:12 --> Total execution time: 1.5343
INFO - 2019-11-09 23:03:16 --> Config Class Initialized
INFO - 2019-11-09 23:03:16 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:03:16 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:03:16 --> Utf8 Class Initialized
INFO - 2019-11-09 23:03:16 --> URI Class Initialized
INFO - 2019-11-09 23:03:16 --> Router Class Initialized
INFO - 2019-11-09 23:03:16 --> Output Class Initialized
INFO - 2019-11-09 23:03:16 --> Security Class Initialized
DEBUG - 2019-11-09 23:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:03:16 --> CSRF cookie sent
INFO - 2019-11-09 23:03:16 --> CSRF token verified
INFO - 2019-11-09 23:03:16 --> Input Class Initialized
INFO - 2019-11-09 23:03:16 --> Language Class Initialized
INFO - 2019-11-09 23:03:16 --> Language Class Initialized
INFO - 2019-11-09 23:03:16 --> Config Class Initialized
INFO - 2019-11-09 23:03:16 --> Loader Class Initialized
INFO - 2019-11-09 23:03:16 --> Helper loaded: url_helper
INFO - 2019-11-09 23:03:16 --> Helper loaded: common_helper
INFO - 2019-11-09 23:03:16 --> Helper loaded: language_helper
INFO - 2019-11-09 23:03:17 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:03:17 --> Helper loaded: email_helper
INFO - 2019-11-09 23:03:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:03:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:03:17 --> Parser Class Initialized
INFO - 2019-11-09 23:03:17 --> User Agent Class Initialized
INFO - 2019-11-09 23:03:17 --> Model Class Initialized
INFO - 2019-11-09 23:03:17 --> Database Driver Class Initialized
INFO - 2019-11-09 23:03:17 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:17 --> Template Class Initialized
INFO - 2019-11-09 23:03:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:03:17 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:03:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:03:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:03:17 --> Encryption Class Initialized
INFO - 2019-11-09 23:03:17 --> Controller Class Initialized
DEBUG - 2019-11-09 23:03:17 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:03:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:03:17 --> Model Class Initialized
INFO - 2019-11-09 23:03:17 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 23:03:17 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 23:03:17 --> Could not find the language line "paystack"
ERROR - 2019-11-09 23:03:17 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 23:03:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 23:03:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:03:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:03:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:03:17 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:03:17 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 23:03:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 23:03:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 23:03:18 --> Final output sent to browser
DEBUG - 2019-11-09 23:03:18 --> Total execution time: 1.5666
INFO - 2019-11-09 23:03:25 --> Config Class Initialized
INFO - 2019-11-09 23:03:25 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:03:25 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:03:25 --> Utf8 Class Initialized
INFO - 2019-11-09 23:03:25 --> URI Class Initialized
INFO - 2019-11-09 23:03:25 --> Router Class Initialized
INFO - 2019-11-09 23:03:25 --> Output Class Initialized
INFO - 2019-11-09 23:03:25 --> Security Class Initialized
DEBUG - 2019-11-09 23:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:03:25 --> CSRF cookie sent
INFO - 2019-11-09 23:03:25 --> CSRF token verified
INFO - 2019-11-09 23:03:25 --> Input Class Initialized
INFO - 2019-11-09 23:03:25 --> Language Class Initialized
INFO - 2019-11-09 23:03:25 --> Language Class Initialized
INFO - 2019-11-09 23:03:25 --> Config Class Initialized
INFO - 2019-11-09 23:03:25 --> Loader Class Initialized
INFO - 2019-11-09 23:03:25 --> Helper loaded: url_helper
INFO - 2019-11-09 23:03:25 --> Helper loaded: common_helper
INFO - 2019-11-09 23:03:25 --> Helper loaded: language_helper
INFO - 2019-11-09 23:03:25 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:03:25 --> Helper loaded: email_helper
INFO - 2019-11-09 23:03:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:03:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:03:25 --> Parser Class Initialized
INFO - 2019-11-09 23:03:25 --> User Agent Class Initialized
INFO - 2019-11-09 23:03:25 --> Model Class Initialized
INFO - 2019-11-09 23:03:26 --> Database Driver Class Initialized
INFO - 2019-11-09 23:03:26 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:26 --> Template Class Initialized
INFO - 2019-11-09 23:03:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:03:26 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:03:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:03:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:03:26 --> Encryption Class Initialized
INFO - 2019-11-09 23:03:26 --> Controller Class Initialized
DEBUG - 2019-11-09 23:03:26 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:03:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:03:26 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:26 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 23:03:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 23:03:26 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 23:03:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 23:03:26 --> Final output sent to browser
DEBUG - 2019-11-09 23:03:26 --> Total execution time: 1.0504
INFO - 2019-11-09 23:03:52 --> Config Class Initialized
INFO - 2019-11-09 23:03:52 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:03:52 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:03:52 --> Utf8 Class Initialized
INFO - 2019-11-09 23:03:52 --> URI Class Initialized
INFO - 2019-11-09 23:03:52 --> Router Class Initialized
INFO - 2019-11-09 23:03:52 --> Output Class Initialized
INFO - 2019-11-09 23:03:52 --> Security Class Initialized
DEBUG - 2019-11-09 23:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:03:53 --> Input Class Initialized
INFO - 2019-11-09 23:03:53 --> Language Class Initialized
INFO - 2019-11-09 23:03:53 --> Language Class Initialized
INFO - 2019-11-09 23:03:53 --> Config Class Initialized
INFO - 2019-11-09 23:03:53 --> Loader Class Initialized
INFO - 2019-11-09 23:03:53 --> Helper loaded: url_helper
INFO - 2019-11-09 23:03:53 --> Helper loaded: common_helper
INFO - 2019-11-09 23:03:53 --> Helper loaded: language_helper
INFO - 2019-11-09 23:03:53 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:03:53 --> Helper loaded: email_helper
INFO - 2019-11-09 23:03:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:03:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:03:53 --> Parser Class Initialized
INFO - 2019-11-09 23:03:53 --> User Agent Class Initialized
INFO - 2019-11-09 23:03:53 --> Model Class Initialized
INFO - 2019-11-09 23:03:53 --> Database Driver Class Initialized
INFO - 2019-11-09 23:03:53 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:53 --> Template Class Initialized
INFO - 2019-11-09 23:03:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:03:53 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:03:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:03:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:03:53 --> Encryption Class Initialized
INFO - 2019-11-09 23:03:53 --> Controller Class Initialized
DEBUG - 2019-11-09 23:03:53 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 23:03:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2019-11-09 23:03:53 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:55 --> orders MX_Controller Initialized
INFO - 2019-11-09 23:03:55 --> Config Class Initialized
INFO - 2019-11-09 23:03:55 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:03:55 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:03:55 --> Utf8 Class Initialized
INFO - 2019-11-09 23:03:55 --> URI Class Initialized
INFO - 2019-11-09 23:03:55 --> Router Class Initialized
INFO - 2019-11-09 23:03:55 --> Output Class Initialized
INFO - 2019-11-09 23:03:55 --> Security Class Initialized
DEBUG - 2019-11-09 23:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:03:55 --> CSRF cookie sent
INFO - 2019-11-09 23:03:55 --> Input Class Initialized
INFO - 2019-11-09 23:03:55 --> Language Class Initialized
INFO - 2019-11-09 23:03:55 --> Language Class Initialized
INFO - 2019-11-09 23:03:55 --> Config Class Initialized
INFO - 2019-11-09 23:03:55 --> Loader Class Initialized
INFO - 2019-11-09 23:03:55 --> Helper loaded: url_helper
INFO - 2019-11-09 23:03:55 --> Helper loaded: common_helper
INFO - 2019-11-09 23:03:55 --> Helper loaded: language_helper
INFO - 2019-11-09 23:03:55 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:03:55 --> Helper loaded: email_helper
INFO - 2019-11-09 23:03:55 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:03:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:03:55 --> Parser Class Initialized
INFO - 2019-11-09 23:03:55 --> User Agent Class Initialized
INFO - 2019-11-09 23:03:55 --> Model Class Initialized
INFO - 2019-11-09 23:03:55 --> Database Driver Class Initialized
INFO - 2019-11-09 23:03:55 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:55 --> Template Class Initialized
INFO - 2019-11-09 23:03:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:03:55 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:03:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:03:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:03:56 --> Encryption Class Initialized
INFO - 2019-11-09 23:03:56 --> Controller Class Initialized
DEBUG - 2019-11-09 23:03:56 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:03:56 --> Model Class Initialized
INFO - 2019-11-09 23:03:56 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 23:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-09 23:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:03:56 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:03:56 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:03:56 --> Model Class Initialized
DEBUG - 2019-11-09 23:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 23:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 23:03:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 23:03:56 --> Final output sent to browser
DEBUG - 2019-11-09 23:03:56 --> Total execution time: 1.2338
INFO - 2019-11-09 23:06:10 --> Config Class Initialized
INFO - 2019-11-09 23:06:10 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:06:10 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:06:10 --> Utf8 Class Initialized
INFO - 2019-11-09 23:06:10 --> URI Class Initialized
INFO - 2019-11-09 23:06:10 --> Router Class Initialized
INFO - 2019-11-09 23:06:10 --> Output Class Initialized
INFO - 2019-11-09 23:06:10 --> Security Class Initialized
DEBUG - 2019-11-09 23:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:06:10 --> CSRF cookie sent
INFO - 2019-11-09 23:06:10 --> CSRF token verified
INFO - 2019-11-09 23:06:10 --> Input Class Initialized
INFO - 2019-11-09 23:06:10 --> Language Class Initialized
INFO - 2019-11-09 23:06:10 --> Language Class Initialized
INFO - 2019-11-09 23:06:10 --> Config Class Initialized
INFO - 2019-11-09 23:06:10 --> Loader Class Initialized
INFO - 2019-11-09 23:06:10 --> Helper loaded: url_helper
INFO - 2019-11-09 23:06:10 --> Helper loaded: common_helper
INFO - 2019-11-09 23:06:10 --> Helper loaded: language_helper
INFO - 2019-11-09 23:06:10 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:06:10 --> Helper loaded: email_helper
INFO - 2019-11-09 23:06:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:06:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:06:10 --> Parser Class Initialized
INFO - 2019-11-09 23:06:10 --> User Agent Class Initialized
INFO - 2019-11-09 23:06:11 --> Model Class Initialized
INFO - 2019-11-09 23:06:11 --> Database Driver Class Initialized
INFO - 2019-11-09 23:06:11 --> Model Class Initialized
DEBUG - 2019-11-09 23:06:11 --> Template Class Initialized
INFO - 2019-11-09 23:06:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:06:11 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:06:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:06:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:06:11 --> Encryption Class Initialized
INFO - 2019-11-09 23:06:11 --> Controller Class Initialized
DEBUG - 2019-11-09 23:06:11 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:06:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:06:11 --> Model Class Initialized
DEBUG - 2019-11-09 23:06:11 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 23:06:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 23:06:11 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 23:06:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 23:06:11 --> Final output sent to browser
DEBUG - 2019-11-09 23:06:11 --> Total execution time: 1.0205
INFO - 2019-11-09 23:08:11 --> Config Class Initialized
INFO - 2019-11-09 23:08:11 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:08:11 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:08:11 --> Utf8 Class Initialized
INFO - 2019-11-09 23:08:11 --> URI Class Initialized
INFO - 2019-11-09 23:08:11 --> Router Class Initialized
INFO - 2019-11-09 23:08:11 --> Output Class Initialized
INFO - 2019-11-09 23:08:11 --> Security Class Initialized
DEBUG - 2019-11-09 23:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:08:11 --> CSRF cookie sent
INFO - 2019-11-09 23:08:11 --> CSRF token verified
INFO - 2019-11-09 23:08:11 --> Input Class Initialized
INFO - 2019-11-09 23:08:11 --> Language Class Initialized
INFO - 2019-11-09 23:08:11 --> Language Class Initialized
INFO - 2019-11-09 23:08:11 --> Config Class Initialized
INFO - 2019-11-09 23:08:11 --> Loader Class Initialized
INFO - 2019-11-09 23:08:11 --> Helper loaded: url_helper
INFO - 2019-11-09 23:08:11 --> Helper loaded: common_helper
INFO - 2019-11-09 23:08:11 --> Helper loaded: language_helper
INFO - 2019-11-09 23:08:11 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:08:11 --> Helper loaded: email_helper
INFO - 2019-11-09 23:08:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:08:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:08:12 --> Parser Class Initialized
INFO - 2019-11-09 23:08:12 --> User Agent Class Initialized
INFO - 2019-11-09 23:08:12 --> Model Class Initialized
INFO - 2019-11-09 23:08:12 --> Database Driver Class Initialized
INFO - 2019-11-09 23:08:12 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:12 --> Template Class Initialized
INFO - 2019-11-09 23:08:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:08:12 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:08:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:08:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:08:12 --> Encryption Class Initialized
INFO - 2019-11-09 23:08:12 --> Controller Class Initialized
DEBUG - 2019-11-09 23:08:12 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:08:12 --> Model Class Initialized
INFO - 2019-11-09 23:08:12 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 23:08:12 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 23:08:12 --> Could not find the language line "paystack"
ERROR - 2019-11-09 23:08:12 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 23:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 23:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:08:12 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:08:12 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:08:12 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 23:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 23:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 23:08:12 --> Final output sent to browser
DEBUG - 2019-11-09 23:08:12 --> Total execution time: 1.4532
INFO - 2019-11-09 23:08:22 --> Config Class Initialized
INFO - 2019-11-09 23:08:22 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:08:22 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:08:22 --> Utf8 Class Initialized
INFO - 2019-11-09 23:08:22 --> URI Class Initialized
INFO - 2019-11-09 23:08:22 --> Router Class Initialized
INFO - 2019-11-09 23:08:22 --> Output Class Initialized
INFO - 2019-11-09 23:08:22 --> Security Class Initialized
DEBUG - 2019-11-09 23:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:08:22 --> CSRF cookie sent
INFO - 2019-11-09 23:08:22 --> CSRF token verified
INFO - 2019-11-09 23:08:22 --> Input Class Initialized
INFO - 2019-11-09 23:08:22 --> Language Class Initialized
INFO - 2019-11-09 23:08:22 --> Language Class Initialized
INFO - 2019-11-09 23:08:22 --> Config Class Initialized
INFO - 2019-11-09 23:08:22 --> Loader Class Initialized
INFO - 2019-11-09 23:08:22 --> Helper loaded: url_helper
INFO - 2019-11-09 23:08:22 --> Helper loaded: common_helper
INFO - 2019-11-09 23:08:22 --> Helper loaded: language_helper
INFO - 2019-11-09 23:08:22 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:08:22 --> Helper loaded: email_helper
INFO - 2019-11-09 23:08:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:08:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:08:22 --> Parser Class Initialized
INFO - 2019-11-09 23:08:22 --> User Agent Class Initialized
INFO - 2019-11-09 23:08:22 --> Model Class Initialized
INFO - 2019-11-09 23:08:22 --> Database Driver Class Initialized
INFO - 2019-11-09 23:08:22 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:22 --> Template Class Initialized
INFO - 2019-11-09 23:08:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:08:22 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:08:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:08:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:08:22 --> Encryption Class Initialized
INFO - 2019-11-09 23:08:22 --> Controller Class Initialized
DEBUG - 2019-11-09 23:08:22 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:08:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:08:22 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:22 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 23:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 23:08:23 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 23:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 23:08:23 --> Final output sent to browser
DEBUG - 2019-11-09 23:08:23 --> Total execution time: 1.1001
INFO - 2019-11-09 23:08:46 --> Config Class Initialized
INFO - 2019-11-09 23:08:46 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:08:46 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:08:46 --> Utf8 Class Initialized
INFO - 2019-11-09 23:08:46 --> URI Class Initialized
INFO - 2019-11-09 23:08:46 --> Router Class Initialized
INFO - 2019-11-09 23:08:46 --> Output Class Initialized
INFO - 2019-11-09 23:08:46 --> Security Class Initialized
DEBUG - 2019-11-09 23:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:08:46 --> CSRF cookie sent
INFO - 2019-11-09 23:08:46 --> CSRF token verified
INFO - 2019-11-09 23:08:46 --> Input Class Initialized
INFO - 2019-11-09 23:08:46 --> Language Class Initialized
INFO - 2019-11-09 23:08:46 --> Language Class Initialized
INFO - 2019-11-09 23:08:46 --> Config Class Initialized
INFO - 2019-11-09 23:08:46 --> Loader Class Initialized
INFO - 2019-11-09 23:08:46 --> Helper loaded: url_helper
INFO - 2019-11-09 23:08:46 --> Helper loaded: common_helper
INFO - 2019-11-09 23:08:46 --> Helper loaded: language_helper
INFO - 2019-11-09 23:08:46 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:08:46 --> Helper loaded: email_helper
INFO - 2019-11-09 23:08:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:08:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:08:47 --> Parser Class Initialized
INFO - 2019-11-09 23:08:47 --> User Agent Class Initialized
INFO - 2019-11-09 23:08:47 --> Model Class Initialized
INFO - 2019-11-09 23:08:47 --> Database Driver Class Initialized
INFO - 2019-11-09 23:08:47 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:47 --> Template Class Initialized
INFO - 2019-11-09 23:08:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:08:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:08:47 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:08:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:08:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:08:47 --> Encryption Class Initialized
INFO - 2019-11-09 23:08:47 --> Controller Class Initialized
DEBUG - 2019-11-09 23:08:47 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:08:47 --> Model Class Initialized
INFO - 2019-11-09 23:08:47 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 23:08:47 --> Could not find the language line "dotpay"
ERROR - 2019-11-09 23:08:47 --> Could not find the language line "paystack"
ERROR - 2019-11-09 23:08:47 --> Could not find the language line "paytm"
DEBUG - 2019-11-09 23:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-09 23:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:08:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:08:47 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:08:47 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 23:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 23:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 23:08:47 --> Final output sent to browser
DEBUG - 2019-11-09 23:08:48 --> Total execution time: 1.5711
INFO - 2019-11-09 23:08:57 --> Config Class Initialized
INFO - 2019-11-09 23:08:57 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:08:57 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:08:57 --> Utf8 Class Initialized
INFO - 2019-11-09 23:08:57 --> URI Class Initialized
INFO - 2019-11-09 23:08:57 --> Router Class Initialized
INFO - 2019-11-09 23:08:57 --> Output Class Initialized
INFO - 2019-11-09 23:08:57 --> Security Class Initialized
DEBUG - 2019-11-09 23:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:08:57 --> CSRF cookie sent
INFO - 2019-11-09 23:08:57 --> CSRF token verified
INFO - 2019-11-09 23:08:57 --> Input Class Initialized
INFO - 2019-11-09 23:08:57 --> Language Class Initialized
INFO - 2019-11-09 23:08:57 --> Language Class Initialized
INFO - 2019-11-09 23:08:57 --> Config Class Initialized
INFO - 2019-11-09 23:08:57 --> Loader Class Initialized
INFO - 2019-11-09 23:08:57 --> Helper loaded: url_helper
INFO - 2019-11-09 23:08:57 --> Helper loaded: common_helper
INFO - 2019-11-09 23:08:57 --> Helper loaded: language_helper
INFO - 2019-11-09 23:08:57 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:08:57 --> Helper loaded: email_helper
INFO - 2019-11-09 23:08:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:08:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:08:58 --> Parser Class Initialized
INFO - 2019-11-09 23:08:58 --> User Agent Class Initialized
INFO - 2019-11-09 23:08:58 --> Model Class Initialized
INFO - 2019-11-09 23:08:58 --> Database Driver Class Initialized
INFO - 2019-11-09 23:08:58 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:58 --> Template Class Initialized
INFO - 2019-11-09 23:08:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:08:58 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:08:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:08:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:08:58 --> Encryption Class Initialized
INFO - 2019-11-09 23:08:58 --> Controller Class Initialized
DEBUG - 2019-11-09 23:08:58 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:08:58 --> Model Class Initialized
DEBUG - 2019-11-09 23:08:58 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 23:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2019-11-09 23:08:58 --> Could not find the language line "Your_name"
DEBUG - 2019-11-09 23:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-11-09 23:08:58 --> Final output sent to browser
DEBUG - 2019-11-09 23:08:58 --> Total execution time: 1.1328
INFO - 2019-11-09 23:09:25 --> Config Class Initialized
INFO - 2019-11-09 23:09:25 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:09:25 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:09:25 --> Utf8 Class Initialized
INFO - 2019-11-09 23:09:25 --> URI Class Initialized
INFO - 2019-11-09 23:09:25 --> Router Class Initialized
INFO - 2019-11-09 23:09:25 --> Output Class Initialized
INFO - 2019-11-09 23:09:25 --> Security Class Initialized
DEBUG - 2019-11-09 23:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:09:25 --> Input Class Initialized
INFO - 2019-11-09 23:09:25 --> Language Class Initialized
INFO - 2019-11-09 23:09:25 --> Language Class Initialized
INFO - 2019-11-09 23:09:25 --> Config Class Initialized
INFO - 2019-11-09 23:09:25 --> Loader Class Initialized
INFO - 2019-11-09 23:09:25 --> Helper loaded: url_helper
INFO - 2019-11-09 23:09:25 --> Helper loaded: common_helper
INFO - 2019-11-09 23:09:25 --> Helper loaded: language_helper
INFO - 2019-11-09 23:09:26 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:09:26 --> Helper loaded: email_helper
INFO - 2019-11-09 23:09:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:09:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:09:26 --> Parser Class Initialized
INFO - 2019-11-09 23:09:26 --> User Agent Class Initialized
INFO - 2019-11-09 23:09:26 --> Model Class Initialized
INFO - 2019-11-09 23:09:26 --> Database Driver Class Initialized
INFO - 2019-11-09 23:09:26 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:26 --> Template Class Initialized
INFO - 2019-11-09 23:09:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:09:26 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:09:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:09:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:09:26 --> Encryption Class Initialized
INFO - 2019-11-09 23:09:26 --> Controller Class Initialized
DEBUG - 2019-11-09 23:09:26 --> stripe MX_Controller Initialized
DEBUG - 2019-11-09 23:09:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2019-11-09 23:09:26 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:28 --> orders MX_Controller Initialized
INFO - 2019-11-09 23:09:28 --> Config Class Initialized
INFO - 2019-11-09 23:09:28 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:09:28 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:09:28 --> Utf8 Class Initialized
INFO - 2019-11-09 23:09:28 --> URI Class Initialized
INFO - 2019-11-09 23:09:28 --> Router Class Initialized
INFO - 2019-11-09 23:09:28 --> Output Class Initialized
INFO - 2019-11-09 23:09:28 --> Security Class Initialized
DEBUG - 2019-11-09 23:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:09:28 --> CSRF cookie sent
INFO - 2019-11-09 23:09:28 --> Input Class Initialized
INFO - 2019-11-09 23:09:28 --> Language Class Initialized
INFO - 2019-11-09 23:09:28 --> Language Class Initialized
INFO - 2019-11-09 23:09:28 --> Config Class Initialized
INFO - 2019-11-09 23:09:28 --> Loader Class Initialized
INFO - 2019-11-09 23:09:28 --> Helper loaded: url_helper
INFO - 2019-11-09 23:09:28 --> Helper loaded: common_helper
INFO - 2019-11-09 23:09:28 --> Helper loaded: language_helper
INFO - 2019-11-09 23:09:28 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:09:28 --> Helper loaded: email_helper
INFO - 2019-11-09 23:09:28 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:09:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:09:28 --> Parser Class Initialized
INFO - 2019-11-09 23:09:28 --> User Agent Class Initialized
INFO - 2019-11-09 23:09:28 --> Model Class Initialized
INFO - 2019-11-09 23:09:28 --> Database Driver Class Initialized
INFO - 2019-11-09 23:09:28 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:28 --> Template Class Initialized
INFO - 2019-11-09 23:09:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:09:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:09:28 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:09:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:09:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:09:28 --> Encryption Class Initialized
INFO - 2019-11-09 23:09:29 --> Controller Class Initialized
DEBUG - 2019-11-09 23:09:29 --> checkout MX_Controller Initialized
DEBUG - 2019-11-09 23:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-09 23:09:29 --> Model Class Initialized
INFO - 2019-11-09 23:09:29 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 23:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-09 23:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:09:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:09:29 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:09:29 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-09 23:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-09 23:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-09 23:09:29 --> Final output sent to browser
DEBUG - 2019-11-09 23:09:29 --> Total execution time: 1.2985
INFO - 2019-11-09 23:09:51 --> Config Class Initialized
INFO - 2019-11-09 23:09:51 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:09:51 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:09:51 --> Utf8 Class Initialized
INFO - 2019-11-09 23:09:51 --> URI Class Initialized
INFO - 2019-11-09 23:09:51 --> Router Class Initialized
INFO - 2019-11-09 23:09:51 --> Output Class Initialized
INFO - 2019-11-09 23:09:51 --> Security Class Initialized
DEBUG - 2019-11-09 23:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:09:51 --> CSRF cookie sent
INFO - 2019-11-09 23:09:51 --> Input Class Initialized
INFO - 2019-11-09 23:09:51 --> Language Class Initialized
INFO - 2019-11-09 23:09:51 --> Language Class Initialized
INFO - 2019-11-09 23:09:51 --> Config Class Initialized
INFO - 2019-11-09 23:09:51 --> Loader Class Initialized
INFO - 2019-11-09 23:09:51 --> Helper loaded: url_helper
INFO - 2019-11-09 23:09:51 --> Helper loaded: common_helper
INFO - 2019-11-09 23:09:51 --> Helper loaded: language_helper
INFO - 2019-11-09 23:09:51 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:09:51 --> Helper loaded: email_helper
INFO - 2019-11-09 23:09:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:09:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:09:51 --> Parser Class Initialized
INFO - 2019-11-09 23:09:51 --> User Agent Class Initialized
INFO - 2019-11-09 23:09:51 --> Model Class Initialized
INFO - 2019-11-09 23:09:51 --> Database Driver Class Initialized
INFO - 2019-11-09 23:09:51 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:51 --> Template Class Initialized
INFO - 2019-11-09 23:09:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:09:52 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:09:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:09:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:09:52 --> Encryption Class Initialized
INFO - 2019-11-09 23:09:52 --> Controller Class Initialized
DEBUG - 2019-11-09 23:09:52 --> auth MX_Controller Initialized
DEBUG - 2019-11-09 23:09:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-09 23:09:52 --> Model Class Initialized
INFO - 2019-11-09 23:09:52 --> Config Class Initialized
INFO - 2019-11-09 23:09:52 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:09:52 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:09:52 --> Utf8 Class Initialized
INFO - 2019-11-09 23:09:52 --> URI Class Initialized
INFO - 2019-11-09 23:09:52 --> Router Class Initialized
INFO - 2019-11-09 23:09:52 --> Output Class Initialized
INFO - 2019-11-09 23:09:52 --> Security Class Initialized
DEBUG - 2019-11-09 23:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:09:52 --> CSRF cookie sent
INFO - 2019-11-09 23:09:52 --> Input Class Initialized
INFO - 2019-11-09 23:09:52 --> Language Class Initialized
INFO - 2019-11-09 23:09:52 --> Language Class Initialized
INFO - 2019-11-09 23:09:52 --> Config Class Initialized
INFO - 2019-11-09 23:09:52 --> Loader Class Initialized
INFO - 2019-11-09 23:09:52 --> Helper loaded: url_helper
INFO - 2019-11-09 23:09:52 --> Helper loaded: common_helper
INFO - 2019-11-09 23:09:52 --> Helper loaded: language_helper
INFO - 2019-11-09 23:09:52 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:09:52 --> Helper loaded: email_helper
INFO - 2019-11-09 23:09:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:09:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:09:52 --> Parser Class Initialized
INFO - 2019-11-09 23:09:52 --> User Agent Class Initialized
INFO - 2019-11-09 23:09:52 --> Model Class Initialized
INFO - 2019-11-09 23:09:53 --> Database Driver Class Initialized
INFO - 2019-11-09 23:09:53 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:53 --> Template Class Initialized
INFO - 2019-11-09 23:09:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:09:53 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:09:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:09:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:09:53 --> Encryption Class Initialized
INFO - 2019-11-09 23:09:53 --> Controller Class Initialized
DEBUG - 2019-11-09 23:09:53 --> statistics MX_Controller Initialized
DEBUG - 2019-11-09 23:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-09 23:09:53 --> Model Class Initialized
ERROR - 2019-11-09 23:09:53 --> Could not find the language line "Pending"
ERROR - 2019-11-09 23:09:53 --> Could not find the language line "Pending"
INFO - 2019-11-09 23:09:53 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 23:09:53 --> Could not find the language line "total_orders"
ERROR - 2019-11-09 23:09:53 --> Could not find the language line "total_orders"
ERROR - 2019-11-09 23:09:53 --> Could not find the language line "Pending"
DEBUG - 2019-11-09 23:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-09 23:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:09:53 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:09:53 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:09:53 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 23:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 23:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 23:09:53 --> Final output sent to browser
DEBUG - 2019-11-09 23:09:53 --> Total execution time: 1.5914
INFO - 2019-11-09 23:09:56 --> Config Class Initialized
INFO - 2019-11-09 23:09:56 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:09:56 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:09:56 --> Utf8 Class Initialized
INFO - 2019-11-09 23:09:56 --> URI Class Initialized
INFO - 2019-11-09 23:09:56 --> Router Class Initialized
INFO - 2019-11-09 23:09:56 --> Output Class Initialized
INFO - 2019-11-09 23:09:56 --> Security Class Initialized
DEBUG - 2019-11-09 23:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:09:56 --> CSRF cookie sent
INFO - 2019-11-09 23:09:56 --> Input Class Initialized
INFO - 2019-11-09 23:09:56 --> Language Class Initialized
INFO - 2019-11-09 23:09:56 --> Language Class Initialized
INFO - 2019-11-09 23:09:56 --> Config Class Initialized
INFO - 2019-11-09 23:09:56 --> Loader Class Initialized
INFO - 2019-11-09 23:09:56 --> Helper loaded: url_helper
INFO - 2019-11-09 23:09:56 --> Helper loaded: common_helper
INFO - 2019-11-09 23:09:56 --> Helper loaded: language_helper
INFO - 2019-11-09 23:09:56 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:09:57 --> Helper loaded: email_helper
INFO - 2019-11-09 23:09:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:09:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:09:57 --> Parser Class Initialized
INFO - 2019-11-09 23:09:57 --> User Agent Class Initialized
INFO - 2019-11-09 23:09:57 --> Model Class Initialized
INFO - 2019-11-09 23:09:57 --> Database Driver Class Initialized
INFO - 2019-11-09 23:09:57 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:57 --> Template Class Initialized
INFO - 2019-11-09 23:09:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:09:57 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:09:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:09:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:09:57 --> Encryption Class Initialized
INFO - 2019-11-09 23:09:57 --> Controller Class Initialized
DEBUG - 2019-11-09 23:09:57 --> order MX_Controller Initialized
DEBUG - 2019-11-09 23:09:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-09 23:09:57 --> Model Class Initialized
ERROR - 2019-11-09 23:09:57 --> Could not find the language line "order_id"
ERROR - 2019-11-09 23:09:57 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-09 23:09:57 --> Could not find the language line "order_id"
ERROR - 2019-11-09 23:09:57 --> Could not find the language line "order_basic_details"
INFO - 2019-11-09 23:09:57 --> Helper loaded: inflector_helper
ERROR - 2019-11-09 23:09:57 --> Could not find the language line "Awaiting"
ERROR - 2019-11-09 23:09:57 --> Could not find the language line "Pending"
ERROR - 2019-11-09 23:09:57 --> Could not find the language line "Pending"
ERROR - 2019-11-09 23:09:57 --> Could not find the language line "Pending"
ERROR - 2019-11-09 23:09:57 --> Could not find the language line "Pending"
ERROR - 2019-11-09 23:09:58 --> Could not find the language line "Pending"
ERROR - 2019-11-09 23:09:58 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-09 23:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-09 23:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:09:58 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:09:58 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:09:58 --> Model Class Initialized
DEBUG - 2019-11-09 23:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 23:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 23:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 23:09:58 --> Final output sent to browser
DEBUG - 2019-11-09 23:09:58 --> Total execution time: 2.1045
INFO - 2019-11-09 23:10:02 --> Config Class Initialized
INFO - 2019-11-09 23:10:02 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:10:02 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:10:02 --> Utf8 Class Initialized
INFO - 2019-11-09 23:10:02 --> URI Class Initialized
INFO - 2019-11-09 23:10:02 --> Router Class Initialized
INFO - 2019-11-09 23:10:02 --> Output Class Initialized
INFO - 2019-11-09 23:10:02 --> Security Class Initialized
DEBUG - 2019-11-09 23:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:10:02 --> CSRF cookie sent
INFO - 2019-11-09 23:10:03 --> Input Class Initialized
INFO - 2019-11-09 23:10:03 --> Language Class Initialized
INFO - 2019-11-09 23:10:03 --> Language Class Initialized
INFO - 2019-11-09 23:10:03 --> Config Class Initialized
INFO - 2019-11-09 23:10:03 --> Loader Class Initialized
INFO - 2019-11-09 23:10:03 --> Helper loaded: url_helper
INFO - 2019-11-09 23:10:03 --> Helper loaded: common_helper
INFO - 2019-11-09 23:10:03 --> Helper loaded: language_helper
INFO - 2019-11-09 23:10:03 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:10:03 --> Helper loaded: email_helper
INFO - 2019-11-09 23:10:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:10:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:10:03 --> Parser Class Initialized
INFO - 2019-11-09 23:10:03 --> User Agent Class Initialized
INFO - 2019-11-09 23:10:03 --> Model Class Initialized
INFO - 2019-11-09 23:10:03 --> Database Driver Class Initialized
INFO - 2019-11-09 23:10:03 --> Model Class Initialized
DEBUG - 2019-11-09 23:10:03 --> Template Class Initialized
INFO - 2019-11-09 23:10:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:10:03 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:10:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:10:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:10:03 --> Encryption Class Initialized
INFO - 2019-11-09 23:10:03 --> Controller Class Initialized
DEBUG - 2019-11-09 23:10:03 --> transactions MX_Controller Initialized
DEBUG - 2019-11-09 23:10:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-09 23:10:03 --> Model Class Initialized
ERROR - 2019-11-09 23:10:03 --> Could not find the language line "order_id"
INFO - 2019-11-09 23:10:03 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 23:10:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-09 23:10:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-09 23:10:04 --> blocks MX_Controller Initialized
DEBUG - 2019-11-09 23:10:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-09 23:10:04 --> Model Class Initialized
DEBUG - 2019-11-09 23:10:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-09 23:10:04 --> Model Class Initialized
DEBUG - 2019-11-09 23:10:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-09 23:10:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-09 23:10:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-09 23:10:04 --> Final output sent to browser
DEBUG - 2019-11-09 23:10:04 --> Total execution time: 2.0537
INFO - 2019-11-09 23:10:09 --> Config Class Initialized
INFO - 2019-11-09 23:10:09 --> Hooks Class Initialized
DEBUG - 2019-11-09 23:10:09 --> UTF-8 Support Enabled
INFO - 2019-11-09 23:10:09 --> Utf8 Class Initialized
INFO - 2019-11-09 23:10:09 --> URI Class Initialized
DEBUG - 2019-11-09 23:10:09 --> No URI present. Default controller set.
INFO - 2019-11-09 23:10:09 --> Router Class Initialized
INFO - 2019-11-09 23:10:09 --> Output Class Initialized
INFO - 2019-11-09 23:10:09 --> Security Class Initialized
DEBUG - 2019-11-09 23:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-09 23:10:09 --> CSRF cookie sent
INFO - 2019-11-09 23:10:09 --> Input Class Initialized
INFO - 2019-11-09 23:10:09 --> Language Class Initialized
INFO - 2019-11-09 23:10:09 --> Language Class Initialized
INFO - 2019-11-09 23:10:09 --> Config Class Initialized
INFO - 2019-11-09 23:10:09 --> Loader Class Initialized
INFO - 2019-11-09 23:10:09 --> Helper loaded: url_helper
INFO - 2019-11-09 23:10:09 --> Helper loaded: common_helper
INFO - 2019-11-09 23:10:09 --> Helper loaded: language_helper
INFO - 2019-11-09 23:10:09 --> Helper loaded: cookie_helper
INFO - 2019-11-09 23:10:09 --> Helper loaded: email_helper
INFO - 2019-11-09 23:10:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-09 23:10:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-09 23:10:10 --> Parser Class Initialized
INFO - 2019-11-09 23:10:10 --> User Agent Class Initialized
INFO - 2019-11-09 23:10:10 --> Model Class Initialized
INFO - 2019-11-09 23:10:10 --> Database Driver Class Initialized
INFO - 2019-11-09 23:10:10 --> Model Class Initialized
DEBUG - 2019-11-09 23:10:10 --> Template Class Initialized
INFO - 2019-11-09 23:10:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-09 23:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-09 23:10:10 --> Pagination Class Initialized
DEBUG - 2019-11-09 23:10:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-09 23:10:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-09 23:10:10 --> Encryption Class Initialized
DEBUG - 2019-11-09 23:10:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 23:10:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-09 23:10:10 --> Controller Class Initialized
DEBUG - 2019-11-09 23:10:10 --> pergo MX_Controller Initialized
DEBUG - 2019-11-09 23:10:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-09 23:10:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-09 23:10:10 --> Model Class Initialized
INFO - 2019-11-09 23:10:10 --> Helper loaded: inflector_helper
DEBUG - 2019-11-09 23:10:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-09 23:10:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-09 23:10:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-09 23:10:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-09 23:10:10 --> Final output sent to browser
DEBUG - 2019-11-09 23:10:10 --> Total execution time: 1.6301
