<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-04 08:44:00 --> Config Class Initialized
INFO - 2019-11-04 08:44:00 --> Hooks Class Initialized
DEBUG - 2019-11-04 08:44:00 --> UTF-8 Support Enabled
INFO - 2019-11-04 08:44:00 --> Utf8 Class Initialized
INFO - 2019-11-04 08:44:00 --> URI Class Initialized
INFO - 2019-11-04 08:44:01 --> Router Class Initialized
INFO - 2019-11-04 08:44:01 --> Output Class Initialized
INFO - 2019-11-04 08:44:01 --> Security Class Initialized
DEBUG - 2019-11-04 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 08:44:01 --> CSRF cookie sent
INFO - 2019-11-04 08:44:01 --> Input Class Initialized
INFO - 2019-11-04 08:44:01 --> Language Class Initialized
INFO - 2019-11-04 08:44:01 --> Language Class Initialized
INFO - 2019-11-04 08:44:01 --> Config Class Initialized
INFO - 2019-11-04 08:44:01 --> Loader Class Initialized
INFO - 2019-11-04 08:44:01 --> Helper loaded: url_helper
INFO - 2019-11-04 08:44:01 --> Helper loaded: common_helper
INFO - 2019-11-04 08:44:01 --> Helper loaded: language_helper
INFO - 2019-11-04 08:44:01 --> Helper loaded: cookie_helper
INFO - 2019-11-04 08:44:01 --> Helper loaded: email_helper
INFO - 2019-11-04 08:44:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 08:44:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 08:44:01 --> Parser Class Initialized
INFO - 2019-11-04 08:44:01 --> User Agent Class Initialized
INFO - 2019-11-04 08:44:01 --> Model Class Initialized
INFO - 2019-11-04 08:44:01 --> Database Driver Class Initialized
INFO - 2019-11-04 08:44:05 --> Model Class Initialized
DEBUG - 2019-11-04 08:44:05 --> Template Class Initialized
INFO - 2019-11-04 08:44:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 08:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 08:44:05 --> Pagination Class Initialized
DEBUG - 2019-11-04 08:44:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 08:44:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 08:44:05 --> Encryption Class Initialized
INFO - 2019-11-04 08:44:05 --> Controller Class Initialized
DEBUG - 2019-11-04 08:44:05 --> order MX_Controller Initialized
DEBUG - 2019-11-04 08:44:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-04 08:44:05 --> Model Class Initialized
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "order_id"
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "order_id"
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "order_basic_details"
INFO - 2019-11-04 08:44:05 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "Pending"
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "Pending"
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "Pending"
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-04 08:44:05 --> Could not find the language line "Pending"
DEBUG - 2019-11-04 08:44:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-04 08:44:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 08:44:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 08:44:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 08:44:05 --> Model Class Initialized
DEBUG - 2019-11-04 08:44:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 08:44:06 --> Model Class Initialized
DEBUG - 2019-11-04 08:44:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 08:44:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 08:44:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 08:44:06 --> Final output sent to browser
DEBUG - 2019-11-04 08:44:06 --> Total execution time: 5.4068
INFO - 2019-11-04 09:29:33 --> Config Class Initialized
INFO - 2019-11-04 09:29:33 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:29:33 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:29:33 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:33 --> URI Class Initialized
INFO - 2019-11-04 09:29:33 --> Router Class Initialized
INFO - 2019-11-04 09:29:33 --> Output Class Initialized
INFO - 2019-11-04 09:29:33 --> Security Class Initialized
DEBUG - 2019-11-04 09:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:29:33 --> CSRF cookie sent
INFO - 2019-11-04 09:29:33 --> Input Class Initialized
INFO - 2019-11-04 09:29:33 --> Language Class Initialized
INFO - 2019-11-04 09:29:33 --> Language Class Initialized
INFO - 2019-11-04 09:29:33 --> Config Class Initialized
INFO - 2019-11-04 09:29:33 --> Loader Class Initialized
INFO - 2019-11-04 09:29:33 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:33 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:33 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:33 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:33 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:33 --> Parser Class Initialized
INFO - 2019-11-04 09:29:33 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:33 --> Model Class Initialized
INFO - 2019-11-04 09:29:33 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:33 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:33 --> Template Class Initialized
INFO - 2019-11-04 09:29:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:33 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:29:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:29:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:33 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:33 --> Controller Class Initialized
DEBUG - 2019-11-04 09:29:33 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:29:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:33 --> Model Class Initialized
INFO - 2019-11-04 09:29:33 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 09:29:33 --> Could not find the language line "Delele"
DEBUG - 2019-11-04 09:29:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2019-11-04 09:29:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:29:33 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:29:33 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:33 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:29:33 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:29:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:29:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:29:33 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:33 --> Total execution time: 0.6668
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Hooks Class Initialized
INFO - 2019-11-04 09:29:34 --> Hooks Class Initialized
INFO - 2019-11-04 09:29:34 --> Hooks Class Initialized
INFO - 2019-11-04 09:29:34 --> Hooks Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Hooks Class Initialized
INFO - 2019-11-04 09:29:34 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:29:34 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:29:34 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:34 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:34 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:34 --> Utf8 Class Initialized
DEBUG - 2019-11-04 09:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:29:34 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:29:34 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:34 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:34 --> URI Class Initialized
INFO - 2019-11-04 09:29:34 --> URI Class Initialized
INFO - 2019-11-04 09:29:34 --> URI Class Initialized
INFO - 2019-11-04 09:29:34 --> URI Class Initialized
INFO - 2019-11-04 09:29:34 --> URI Class Initialized
INFO - 2019-11-04 09:29:34 --> URI Class Initialized
INFO - 2019-11-04 09:29:34 --> Router Class Initialized
INFO - 2019-11-04 09:29:34 --> Router Class Initialized
INFO - 2019-11-04 09:29:34 --> Router Class Initialized
INFO - 2019-11-04 09:29:34 --> Router Class Initialized
INFO - 2019-11-04 09:29:34 --> Output Class Initialized
INFO - 2019-11-04 09:29:34 --> Output Class Initialized
INFO - 2019-11-04 09:29:34 --> Output Class Initialized
INFO - 2019-11-04 09:29:34 --> Output Class Initialized
INFO - 2019-11-04 09:29:34 --> Router Class Initialized
INFO - 2019-11-04 09:29:34 --> Router Class Initialized
INFO - 2019-11-04 09:29:34 --> Security Class Initialized
INFO - 2019-11-04 09:29:34 --> Security Class Initialized
INFO - 2019-11-04 09:29:34 --> Security Class Initialized
INFO - 2019-11-04 09:29:34 --> Security Class Initialized
INFO - 2019-11-04 09:29:34 --> Output Class Initialized
INFO - 2019-11-04 09:29:34 --> Output Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:29:34 --> Security Class Initialized
INFO - 2019-11-04 09:29:34 --> Security Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:29:34 --> CSRF cookie sent
INFO - 2019-11-04 09:29:34 --> CSRF cookie sent
INFO - 2019-11-04 09:29:34 --> CSRF cookie sent
INFO - 2019-11-04 09:29:34 --> CSRF cookie sent
DEBUG - 2019-11-04 09:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:29:34 --> CSRF token verified
INFO - 2019-11-04 09:29:34 --> CSRF token verified
INFO - 2019-11-04 09:29:34 --> CSRF cookie sent
INFO - 2019-11-04 09:29:34 --> CSRF token verified
INFO - 2019-11-04 09:29:34 --> CSRF token verified
INFO - 2019-11-04 09:29:34 --> CSRF cookie sent
INFO - 2019-11-04 09:29:34 --> Input Class Initialized
INFO - 2019-11-04 09:29:34 --> CSRF token verified
INFO - 2019-11-04 09:29:34 --> Input Class Initialized
INFO - 2019-11-04 09:29:34 --> CSRF token verified
INFO - 2019-11-04 09:29:34 --> Input Class Initialized
INFO - 2019-11-04 09:29:34 --> Input Class Initialized
INFO - 2019-11-04 09:29:34 --> Input Class Initialized
INFO - 2019-11-04 09:29:34 --> Input Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Loader Class Initialized
INFO - 2019-11-04 09:29:34 --> Loader Class Initialized
INFO - 2019-11-04 09:29:34 --> Loader Class Initialized
INFO - 2019-11-04 09:29:34 --> Loader Class Initialized
INFO - 2019-11-04 09:29:34 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:34 --> Loader Class Initialized
INFO - 2019-11-04 09:29:34 --> Loader Class Initialized
INFO - 2019-11-04 09:29:34 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:34 --> Parser Class Initialized
INFO - 2019-11-04 09:29:34 --> Parser Class Initialized
INFO - 2019-11-04 09:29:34 --> Parser Class Initialized
INFO - 2019-11-04 09:29:34 --> Parser Class Initialized
INFO - 2019-11-04 09:29:34 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:34 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:34 --> Parser Class Initialized
INFO - 2019-11-04 09:29:34 --> Parser Class Initialized
INFO - 2019-11-04 09:29:34 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:34 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:34 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:34 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:34 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:34 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:34 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Template Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Template Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Template Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Template Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Template Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Template Class Initialized
INFO - 2019-11-04 09:29:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:34 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:29:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:34 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:34 --> Controller Class Initialized
DEBUG - 2019-11-04 09:29:34 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:29:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:29:34 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:34 --> Total execution time: 0.4693
INFO - 2019-11-04 09:29:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:34 --> Config Class Initialized
INFO - 2019-11-04 09:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:34 --> Hooks Class Initialized
INFO - 2019-11-04 09:29:34 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-04 09:29:34 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:29:34 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:34 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:34 --> URI Class Initialized
INFO - 2019-11-04 09:29:34 --> Controller Class Initialized
INFO - 2019-11-04 09:29:34 --> Router Class Initialized
DEBUG - 2019-11-04 09:29:34 --> services MX_Controller Initialized
INFO - 2019-11-04 09:29:34 --> Output Class Initialized
INFO - 2019-11-04 09:29:34 --> Security Class Initialized
DEBUG - 2019-11-04 09:29:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:34 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:29:34 --> CSRF cookie sent
INFO - 2019-11-04 09:29:34 --> CSRF token verified
INFO - 2019-11-04 09:29:34 --> Input Class Initialized
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
DEBUG - 2019-11-04 09:29:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:29:34 --> Final output sent to browser
INFO - 2019-11-04 09:29:34 --> Language Class Initialized
INFO - 2019-11-04 09:29:35 --> Config Class Initialized
DEBUG - 2019-11-04 09:29:35 --> Total execution time: 0.6314
INFO - 2019-11-04 09:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:35 --> Loader Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:35 --> Config Class Initialized
INFO - 2019-11-04 09:29:35 --> Hooks Class Initialized
INFO - 2019-11-04 09:29:35 --> Pagination Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:35 --> Helper loaded: language_helper
DEBUG - 2019-11-04 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-04 09:29:35 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:29:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:35 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:35 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:35 --> URI Class Initialized
INFO - 2019-11-04 09:29:35 --> Controller Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:35 --> Router Class Initialized
DEBUG - 2019-11-04 09:29:35 --> services MX_Controller Initialized
INFO - 2019-11-04 09:29:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:35 --> Output Class Initialized
INFO - 2019-11-04 09:29:35 --> Security Class Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:35 --> Parser Class Initialized
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:29:35 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:35 --> CSRF cookie sent
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
INFO - 2019-11-04 09:29:35 --> CSRF token verified
INFO - 2019-11-04 09:29:35 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:35 --> Input Class Initialized
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
INFO - 2019-11-04 09:29:35 --> Language Class Initialized
DEBUG - 2019-11-04 09:29:35 --> Template Class Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:29:35 --> Language Class Initialized
INFO - 2019-11-04 09:29:35 --> Config Class Initialized
INFO - 2019-11-04 09:29:35 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:35 --> Total execution time: 0.8184
INFO - 2019-11-04 09:29:35 --> Loader Class Initialized
INFO - 2019-11-04 09:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:35 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:35 --> Config Class Initialized
INFO - 2019-11-04 09:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:35 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:35 --> Pagination Class Initialized
INFO - 2019-11-04 09:29:35 --> Hooks Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:35 --> Helper loaded: cookie_helper
DEBUG - 2019-11-04 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-04 09:29:35 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:29:35 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:35 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:35 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:35 --> URI Class Initialized
INFO - 2019-11-04 09:29:35 --> Controller Class Initialized
INFO - 2019-11-04 09:29:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:35 --> Router Class Initialized
DEBUG - 2019-11-04 09:29:35 --> services MX_Controller Initialized
INFO - 2019-11-04 09:29:35 --> Output Class Initialized
INFO - 2019-11-04 09:29:35 --> Parser Class Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:35 --> Security Class Initialized
INFO - 2019-11-04 09:29:35 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
INFO - 2019-11-04 09:29:35 --> CSRF cookie sent
INFO - 2019-11-04 09:29:35 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:35 --> CSRF token verified
INFO - 2019-11-04 09:29:35 --> Input Class Initialized
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
INFO - 2019-11-04 09:29:35 --> Language Class Initialized
DEBUG - 2019-11-04 09:29:35 --> Template Class Initialized
INFO - 2019-11-04 09:29:35 --> Language Class Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:29:35 --> Config Class Initialized
INFO - 2019-11-04 09:29:35 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:35 --> Total execution time: 1.0192
INFO - 2019-11-04 09:29:35 --> Loader Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:35 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:35 --> Pagination Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:35 --> Helper loaded: cookie_helper
DEBUG - 2019-11-04 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:29:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:35 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:35 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:35 --> Controller Class Initialized
INFO - 2019-11-04 09:29:35 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-04 09:29:35 --> services MX_Controller Initialized
INFO - 2019-11-04 09:29:35 --> Parser Class Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:35 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
INFO - 2019-11-04 09:29:35 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:35 --> Template Class Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:29:35 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:35 --> Total execution time: 1.1501
INFO - 2019-11-04 09:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:35 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:29:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:35 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:35 --> Controller Class Initialized
DEBUG - 2019-11-04 09:29:35 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:29:35 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:35 --> Total execution time: 1.3144
INFO - 2019-11-04 09:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:35 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:29:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:35 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:35 --> Controller Class Initialized
DEBUG - 2019-11-04 09:29:35 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:29:35 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:35 --> Total execution time: 0.9701
INFO - 2019-11-04 09:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:35 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:29:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:35 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:35 --> Controller Class Initialized
DEBUG - 2019-11-04 09:29:35 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:35 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:29:35 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:35 --> Total execution time: 0.9646
INFO - 2019-11-04 09:29:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:36 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:29:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:29:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:36 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:36 --> Controller Class Initialized
DEBUG - 2019-11-04 09:29:36 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:36 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:29:36 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:36 --> Total execution time: 0.9416
INFO - 2019-11-04 09:29:38 --> Config Class Initialized
INFO - 2019-11-04 09:29:38 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:29:38 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:29:38 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:38 --> URI Class Initialized
INFO - 2019-11-04 09:29:38 --> Router Class Initialized
INFO - 2019-11-04 09:29:38 --> Output Class Initialized
INFO - 2019-11-04 09:29:38 --> Security Class Initialized
DEBUG - 2019-11-04 09:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:29:38 --> CSRF cookie sent
INFO - 2019-11-04 09:29:38 --> Input Class Initialized
INFO - 2019-11-04 09:29:38 --> Language Class Initialized
INFO - 2019-11-04 09:29:38 --> Language Class Initialized
INFO - 2019-11-04 09:29:38 --> Config Class Initialized
INFO - 2019-11-04 09:29:38 --> Loader Class Initialized
INFO - 2019-11-04 09:29:38 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:38 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:38 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:38 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:38 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:38 --> Parser Class Initialized
INFO - 2019-11-04 09:29:38 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:38 --> Model Class Initialized
INFO - 2019-11-04 09:29:38 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:38 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:38 --> Template Class Initialized
INFO - 2019-11-04 09:29:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:38 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:29:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:29:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:38 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:38 --> Controller Class Initialized
DEBUG - 2019-11-04 09:29:38 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:29:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:38 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/update.php
INFO - 2019-11-04 09:29:38 --> Final output sent to browser
DEBUG - 2019-11-04 09:29:38 --> Total execution time: 0.6247
INFO - 2019-11-04 09:29:47 --> Config Class Initialized
INFO - 2019-11-04 09:29:47 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:29:47 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:29:47 --> Utf8 Class Initialized
INFO - 2019-11-04 09:29:47 --> URI Class Initialized
INFO - 2019-11-04 09:29:47 --> Router Class Initialized
INFO - 2019-11-04 09:29:47 --> Output Class Initialized
INFO - 2019-11-04 09:29:47 --> Security Class Initialized
DEBUG - 2019-11-04 09:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:29:47 --> CSRF cookie sent
INFO - 2019-11-04 09:29:47 --> CSRF token verified
INFO - 2019-11-04 09:29:47 --> Input Class Initialized
INFO - 2019-11-04 09:29:47 --> Language Class Initialized
INFO - 2019-11-04 09:29:47 --> Language Class Initialized
INFO - 2019-11-04 09:29:47 --> Config Class Initialized
INFO - 2019-11-04 09:29:47 --> Loader Class Initialized
INFO - 2019-11-04 09:29:47 --> Helper loaded: url_helper
INFO - 2019-11-04 09:29:47 --> Helper loaded: common_helper
INFO - 2019-11-04 09:29:47 --> Helper loaded: language_helper
INFO - 2019-11-04 09:29:47 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:29:47 --> Helper loaded: email_helper
INFO - 2019-11-04 09:29:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:29:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:29:47 --> Parser Class Initialized
INFO - 2019-11-04 09:29:47 --> User Agent Class Initialized
INFO - 2019-11-04 09:29:47 --> Model Class Initialized
INFO - 2019-11-04 09:29:47 --> Database Driver Class Initialized
INFO - 2019-11-04 09:29:48 --> Model Class Initialized
DEBUG - 2019-11-04 09:29:48 --> Template Class Initialized
INFO - 2019-11-04 09:29:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:29:48 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:29:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:29:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:29:48 --> Encryption Class Initialized
INFO - 2019-11-04 09:29:48 --> Controller Class Initialized
DEBUG - 2019-11-04 09:29:48 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:29:48 --> Model Class Initialized
INFO - 2019-11-04 09:30:15 --> Config Class Initialized
INFO - 2019-11-04 09:30:15 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:30:15 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:30:15 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:15 --> URI Class Initialized
INFO - 2019-11-04 09:30:15 --> Router Class Initialized
INFO - 2019-11-04 09:30:15 --> Output Class Initialized
INFO - 2019-11-04 09:30:15 --> Security Class Initialized
DEBUG - 2019-11-04 09:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:30:15 --> CSRF cookie sent
INFO - 2019-11-04 09:30:15 --> CSRF token verified
INFO - 2019-11-04 09:30:15 --> Input Class Initialized
INFO - 2019-11-04 09:30:15 --> Language Class Initialized
INFO - 2019-11-04 09:30:15 --> Language Class Initialized
INFO - 2019-11-04 09:30:15 --> Config Class Initialized
INFO - 2019-11-04 09:30:15 --> Loader Class Initialized
INFO - 2019-11-04 09:30:15 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:15 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:15 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:15 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:15 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:15 --> Parser Class Initialized
INFO - 2019-11-04 09:30:15 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:15 --> Model Class Initialized
INFO - 2019-11-04 09:30:15 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:15 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:15 --> Template Class Initialized
INFO - 2019-11-04 09:30:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:15 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:30:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:15 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:15 --> Controller Class Initialized
DEBUG - 2019-11-04 09:30:15 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:30:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:15 --> Model Class Initialized
INFO - 2019-11-04 09:30:31 --> Config Class Initialized
INFO - 2019-11-04 09:30:31 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:30:31 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:30:31 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:31 --> URI Class Initialized
INFO - 2019-11-04 09:30:31 --> Router Class Initialized
INFO - 2019-11-04 09:30:31 --> Output Class Initialized
INFO - 2019-11-04 09:30:31 --> Security Class Initialized
DEBUG - 2019-11-04 09:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:30:31 --> CSRF cookie sent
INFO - 2019-11-04 09:30:31 --> CSRF token verified
INFO - 2019-11-04 09:30:31 --> Input Class Initialized
INFO - 2019-11-04 09:30:31 --> Language Class Initialized
INFO - 2019-11-04 09:30:31 --> Language Class Initialized
INFO - 2019-11-04 09:30:31 --> Config Class Initialized
INFO - 2019-11-04 09:30:31 --> Loader Class Initialized
INFO - 2019-11-04 09:30:31 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:31 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:31 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:31 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:31 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:31 --> Parser Class Initialized
INFO - 2019-11-04 09:30:31 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:31 --> Model Class Initialized
INFO - 2019-11-04 09:30:31 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:31 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:32 --> Template Class Initialized
INFO - 2019-11-04 09:30:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:32 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:30:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:32 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:32 --> Controller Class Initialized
DEBUG - 2019-11-04 09:30:32 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:30:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:32 --> Model Class Initialized
INFO - 2019-11-04 09:30:36 --> Config Class Initialized
INFO - 2019-11-04 09:30:36 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:30:36 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:30:36 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:36 --> URI Class Initialized
INFO - 2019-11-04 09:30:36 --> Router Class Initialized
INFO - 2019-11-04 09:30:36 --> Output Class Initialized
INFO - 2019-11-04 09:30:36 --> Security Class Initialized
DEBUG - 2019-11-04 09:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:30:36 --> CSRF cookie sent
INFO - 2019-11-04 09:30:36 --> Input Class Initialized
INFO - 2019-11-04 09:30:36 --> Language Class Initialized
INFO - 2019-11-04 09:30:36 --> Language Class Initialized
INFO - 2019-11-04 09:30:36 --> Config Class Initialized
INFO - 2019-11-04 09:30:36 --> Loader Class Initialized
INFO - 2019-11-04 09:30:36 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:36 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:36 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:36 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:36 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:37 --> Parser Class Initialized
INFO - 2019-11-04 09:30:37 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:37 --> Model Class Initialized
INFO - 2019-11-04 09:30:37 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:37 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:37 --> Template Class Initialized
INFO - 2019-11-04 09:30:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:37 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:30:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:37 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:37 --> Controller Class Initialized
DEBUG - 2019-11-04 09:30:37 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:37 --> Model Class Initialized
INFO - 2019-11-04 09:30:37 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 09:30:37 --> Could not find the language line "Delele"
DEBUG - 2019-11-04 09:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2019-11-04 09:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:30:37 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:30:37 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:37 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:30:37 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:30:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:30:37 --> Final output sent to browser
DEBUG - 2019-11-04 09:30:37 --> Total execution time: 0.7378
INFO - 2019-11-04 09:30:37 --> Config Class Initialized
INFO - 2019-11-04 09:30:37 --> Config Class Initialized
INFO - 2019-11-04 09:30:37 --> Config Class Initialized
INFO - 2019-11-04 09:30:37 --> Config Class Initialized
INFO - 2019-11-04 09:30:37 --> Config Class Initialized
INFO - 2019-11-04 09:30:37 --> Config Class Initialized
INFO - 2019-11-04 09:30:37 --> Hooks Class Initialized
INFO - 2019-11-04 09:30:37 --> Hooks Class Initialized
INFO - 2019-11-04 09:30:37 --> Hooks Class Initialized
INFO - 2019-11-04 09:30:37 --> Hooks Class Initialized
INFO - 2019-11-04 09:30:37 --> Hooks Class Initialized
INFO - 2019-11-04 09:30:37 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:30:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:30:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:30:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:30:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:30:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:30:37 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:30:37 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:37 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:37 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:37 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:37 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:37 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:38 --> URI Class Initialized
INFO - 2019-11-04 09:30:38 --> URI Class Initialized
INFO - 2019-11-04 09:30:38 --> URI Class Initialized
INFO - 2019-11-04 09:30:38 --> URI Class Initialized
INFO - 2019-11-04 09:30:38 --> URI Class Initialized
INFO - 2019-11-04 09:30:38 --> URI Class Initialized
INFO - 2019-11-04 09:30:38 --> Router Class Initialized
INFO - 2019-11-04 09:30:38 --> Router Class Initialized
INFO - 2019-11-04 09:30:38 --> Router Class Initialized
INFO - 2019-11-04 09:30:38 --> Router Class Initialized
INFO - 2019-11-04 09:30:38 --> Router Class Initialized
INFO - 2019-11-04 09:30:38 --> Router Class Initialized
INFO - 2019-11-04 09:30:38 --> Output Class Initialized
INFO - 2019-11-04 09:30:38 --> Output Class Initialized
INFO - 2019-11-04 09:30:38 --> Output Class Initialized
INFO - 2019-11-04 09:30:38 --> Output Class Initialized
INFO - 2019-11-04 09:30:38 --> Output Class Initialized
INFO - 2019-11-04 09:30:38 --> Output Class Initialized
INFO - 2019-11-04 09:30:38 --> Security Class Initialized
INFO - 2019-11-04 09:30:38 --> Security Class Initialized
INFO - 2019-11-04 09:30:38 --> Security Class Initialized
INFO - 2019-11-04 09:30:38 --> Security Class Initialized
INFO - 2019-11-04 09:30:38 --> Security Class Initialized
INFO - 2019-11-04 09:30:38 --> Security Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:30:38 --> CSRF cookie sent
INFO - 2019-11-04 09:30:38 --> CSRF cookie sent
INFO - 2019-11-04 09:30:38 --> CSRF cookie sent
INFO - 2019-11-04 09:30:38 --> CSRF cookie sent
INFO - 2019-11-04 09:30:38 --> CSRF cookie sent
INFO - 2019-11-04 09:30:38 --> CSRF cookie sent
INFO - 2019-11-04 09:30:38 --> CSRF token verified
INFO - 2019-11-04 09:30:38 --> CSRF token verified
INFO - 2019-11-04 09:30:38 --> CSRF token verified
INFO - 2019-11-04 09:30:38 --> CSRF token verified
INFO - 2019-11-04 09:30:38 --> CSRF token verified
INFO - 2019-11-04 09:30:38 --> CSRF token verified
INFO - 2019-11-04 09:30:38 --> Input Class Initialized
INFO - 2019-11-04 09:30:38 --> Input Class Initialized
INFO - 2019-11-04 09:30:38 --> Input Class Initialized
INFO - 2019-11-04 09:30:38 --> Input Class Initialized
INFO - 2019-11-04 09:30:38 --> Input Class Initialized
INFO - 2019-11-04 09:30:38 --> Input Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Loader Class Initialized
INFO - 2019-11-04 09:30:38 --> Loader Class Initialized
INFO - 2019-11-04 09:30:38 --> Loader Class Initialized
INFO - 2019-11-04 09:30:38 --> Loader Class Initialized
INFO - 2019-11-04 09:30:38 --> Loader Class Initialized
INFO - 2019-11-04 09:30:38 --> Loader Class Initialized
INFO - 2019-11-04 09:30:38 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:38 --> Parser Class Initialized
INFO - 2019-11-04 09:30:38 --> Parser Class Initialized
INFO - 2019-11-04 09:30:38 --> Parser Class Initialized
INFO - 2019-11-04 09:30:38 --> Parser Class Initialized
INFO - 2019-11-04 09:30:38 --> Parser Class Initialized
INFO - 2019-11-04 09:30:38 --> Parser Class Initialized
INFO - 2019-11-04 09:30:38 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:38 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:38 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:38 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:38 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:38 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:38 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:38 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:38 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:38 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:38 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Template Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Template Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Template Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Template Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Template Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Template Class Initialized
INFO - 2019-11-04 09:30:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:38 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:38 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:38 --> Controller Class Initialized
DEBUG - 2019-11-04 09:30:38 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:30:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:30:38 --> Final output sent to browser
DEBUG - 2019-11-04 09:30:38 --> Total execution time: 0.5135
INFO - 2019-11-04 09:30:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Hooks Class Initialized
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:38 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:30:38 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:30:38 --> Utf8 Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:38 --> URI Class Initialized
INFO - 2019-11-04 09:30:38 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:38 --> Router Class Initialized
INFO - 2019-11-04 09:30:38 --> Controller Class Initialized
INFO - 2019-11-04 09:30:38 --> Output Class Initialized
DEBUG - 2019-11-04 09:30:38 --> services MX_Controller Initialized
INFO - 2019-11-04 09:30:38 --> Security Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:30:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> CSRF cookie sent
INFO - 2019-11-04 09:30:38 --> CSRF token verified
INFO - 2019-11-04 09:30:38 --> Input Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
DEBUG - 2019-11-04 09:30:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Final output sent to browser
DEBUG - 2019-11-04 09:30:38 --> Total execution time: 0.6862
INFO - 2019-11-04 09:30:38 --> Loader Class Initialized
INFO - 2019-11-04 09:30:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:38 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:38 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:38 --> Pagination Class Initialized
INFO - 2019-11-04 09:30:38 --> Hooks Class Initialized
INFO - 2019-11-04 09:30:38 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: cookie_helper
DEBUG - 2019-11-04 09:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-04 09:30:38 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:30:38 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:38 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:38 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:38 --> URI Class Initialized
INFO - 2019-11-04 09:30:38 --> Controller Class Initialized
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:38 --> Router Class Initialized
DEBUG - 2019-11-04 09:30:38 --> services MX_Controller Initialized
INFO - 2019-11-04 09:30:38 --> Parser Class Initialized
INFO - 2019-11-04 09:30:38 --> Output Class Initialized
INFO - 2019-11-04 09:30:38 --> Security Class Initialized
DEBUG - 2019-11-04 09:30:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:38 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> CSRF cookie sent
INFO - 2019-11-04 09:30:38 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:38 --> CSRF token verified
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Input Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Template Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
DEBUG - 2019-11-04 09:30:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:30:38 --> Final output sent to browser
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Total execution time: 0.8615
INFO - 2019-11-04 09:30:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:38 --> Loader Class Initialized
INFO - 2019-11-04 09:30:38 --> Config Class Initialized
INFO - 2019-11-04 09:30:38 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:38 --> Hooks Class Initialized
INFO - 2019-11-04 09:30:38 --> Pagination Class Initialized
INFO - 2019-11-04 09:30:38 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:38 --> Helper loaded: language_helper
DEBUG - 2019-11-04 09:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-04 09:30:38 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:30:38 --> Utf8 Class Initialized
INFO - 2019-11-04 09:30:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:38 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:38 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:38 --> Helper loaded: email_helper
INFO - 2019-11-04 09:30:38 --> URI Class Initialized
INFO - 2019-11-04 09:30:38 --> Controller Class Initialized
INFO - 2019-11-04 09:30:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:38 --> Router Class Initialized
DEBUG - 2019-11-04 09:30:38 --> services MX_Controller Initialized
INFO - 2019-11-04 09:30:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:38 --> Output Class Initialized
INFO - 2019-11-04 09:30:38 --> Security Class Initialized
DEBUG - 2019-11-04 09:30:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:38 --> Parser Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:30:38 --> User Agent Class Initialized
INFO - 2019-11-04 09:30:38 --> CSRF cookie sent
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> CSRF token verified
INFO - 2019-11-04 09:30:38 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:38 --> Input Class Initialized
INFO - 2019-11-04 09:30:38 --> Model Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
DEBUG - 2019-11-04 09:30:38 --> Template Class Initialized
INFO - 2019-11-04 09:30:38 --> Language Class Initialized
INFO - 2019-11-04 09:30:39 --> Config Class Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:30:39 --> Final output sent to browser
INFO - 2019-11-04 09:30:39 --> Loader Class Initialized
DEBUG - 2019-11-04 09:30:39 --> Total execution time: 1.0622
INFO - 2019-11-04 09:30:39 --> Helper loaded: url_helper
INFO - 2019-11-04 09:30:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:39 --> Helper loaded: common_helper
INFO - 2019-11-04 09:30:39 --> Helper loaded: language_helper
INFO - 2019-11-04 09:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:39 --> Pagination Class Initialized
INFO - 2019-11-04 09:30:39 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:30:39 --> Helper loaded: email_helper
DEBUG - 2019-11-04 09:30:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:30:39 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:30:39 --> Controller Class Initialized
INFO - 2019-11-04 09:30:39 --> Parser Class Initialized
DEBUG - 2019-11-04 09:30:39 --> services MX_Controller Initialized
INFO - 2019-11-04 09:30:39 --> User Agent Class Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:39 --> Model Class Initialized
INFO - 2019-11-04 09:30:39 --> Model Class Initialized
INFO - 2019-11-04 09:30:39 --> Database Driver Class Initialized
INFO - 2019-11-04 09:30:39 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:39 --> Template Class Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:30:39 --> Final output sent to browser
DEBUG - 2019-11-04 09:30:39 --> Total execution time: 1.2320
INFO - 2019-11-04 09:30:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:39 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:30:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:39 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:39 --> Controller Class Initialized
DEBUG - 2019-11-04 09:30:39 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:39 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:30:39 --> Final output sent to browser
DEBUG - 2019-11-04 09:30:39 --> Total execution time: 1.4201
INFO - 2019-11-04 09:30:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:39 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:30:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:39 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:39 --> Controller Class Initialized
DEBUG - 2019-11-04 09:30:39 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:39 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:30:39 --> Final output sent to browser
DEBUG - 2019-11-04 09:30:39 --> Total execution time: 1.0538
INFO - 2019-11-04 09:30:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:39 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:30:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:39 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:39 --> Controller Class Initialized
DEBUG - 2019-11-04 09:30:39 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:39 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:30:39 --> Final output sent to browser
DEBUG - 2019-11-04 09:30:39 --> Total execution time: 1.0282
INFO - 2019-11-04 09:30:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:30:39 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:30:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:30:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:30:39 --> Encryption Class Initialized
INFO - 2019-11-04 09:30:39 --> Controller Class Initialized
DEBUG - 2019-11-04 09:30:39 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:30:39 --> Model Class Initialized
DEBUG - 2019-11-04 09:30:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:30:39 --> Final output sent to browser
DEBUG - 2019-11-04 09:30:39 --> Total execution time: 1.0200
INFO - 2019-11-04 09:32:02 --> Config Class Initialized
INFO - 2019-11-04 09:32:02 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:32:02 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:02 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:02 --> URI Class Initialized
INFO - 2019-11-04 09:32:02 --> Router Class Initialized
INFO - 2019-11-04 09:32:02 --> Output Class Initialized
INFO - 2019-11-04 09:32:02 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:32:02 --> CSRF cookie sent
INFO - 2019-11-04 09:32:02 --> Input Class Initialized
INFO - 2019-11-04 09:32:02 --> Language Class Initialized
INFO - 2019-11-04 09:32:02 --> Language Class Initialized
INFO - 2019-11-04 09:32:02 --> Config Class Initialized
INFO - 2019-11-04 09:32:02 --> Loader Class Initialized
INFO - 2019-11-04 09:32:02 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:02 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:02 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:02 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:02 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:02 --> Parser Class Initialized
INFO - 2019-11-04 09:32:02 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:02 --> Model Class Initialized
INFO - 2019-11-04 09:32:02 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:02 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:02 --> Template Class Initialized
INFO - 2019-11-04 09:32:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:02 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:02 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:02 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:02 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:02 --> Model Class Initialized
INFO - 2019-11-04 09:32:02 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 09:32:02 --> Could not find the language line "Delele"
DEBUG - 2019-11-04 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2019-11-04 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:32:02 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:32:02 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:02 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:32:02 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:32:02 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:02 --> Total execution time: 0.6232
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:03 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:03 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:03 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:03 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:03 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:03 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:03 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:03 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:03 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:03 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:03 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:03 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:03 --> URI Class Initialized
INFO - 2019-11-04 09:32:03 --> URI Class Initialized
INFO - 2019-11-04 09:32:03 --> URI Class Initialized
INFO - 2019-11-04 09:32:03 --> URI Class Initialized
INFO - 2019-11-04 09:32:03 --> URI Class Initialized
INFO - 2019-11-04 09:32:03 --> URI Class Initialized
INFO - 2019-11-04 09:32:03 --> Router Class Initialized
INFO - 2019-11-04 09:32:03 --> Router Class Initialized
INFO - 2019-11-04 09:32:03 --> Router Class Initialized
INFO - 2019-11-04 09:32:03 --> Router Class Initialized
INFO - 2019-11-04 09:32:03 --> Router Class Initialized
INFO - 2019-11-04 09:32:03 --> Router Class Initialized
INFO - 2019-11-04 09:32:03 --> Output Class Initialized
INFO - 2019-11-04 09:32:03 --> Output Class Initialized
INFO - 2019-11-04 09:32:03 --> Output Class Initialized
INFO - 2019-11-04 09:32:03 --> Output Class Initialized
INFO - 2019-11-04 09:32:03 --> Output Class Initialized
INFO - 2019-11-04 09:32:03 --> Output Class Initialized
INFO - 2019-11-04 09:32:03 --> Security Class Initialized
INFO - 2019-11-04 09:32:03 --> Security Class Initialized
INFO - 2019-11-04 09:32:03 --> Security Class Initialized
INFO - 2019-11-04 09:32:03 --> Security Class Initialized
INFO - 2019-11-04 09:32:03 --> Security Class Initialized
INFO - 2019-11-04 09:32:03 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:32:03 --> CSRF cookie sent
INFO - 2019-11-04 09:32:03 --> CSRF cookie sent
INFO - 2019-11-04 09:32:03 --> CSRF cookie sent
INFO - 2019-11-04 09:32:03 --> CSRF cookie sent
INFO - 2019-11-04 09:32:03 --> CSRF cookie sent
INFO - 2019-11-04 09:32:03 --> CSRF cookie sent
INFO - 2019-11-04 09:32:03 --> CSRF token verified
INFO - 2019-11-04 09:32:03 --> CSRF token verified
INFO - 2019-11-04 09:32:03 --> CSRF token verified
INFO - 2019-11-04 09:32:03 --> CSRF token verified
INFO - 2019-11-04 09:32:03 --> CSRF token verified
INFO - 2019-11-04 09:32:03 --> CSRF token verified
INFO - 2019-11-04 09:32:03 --> Input Class Initialized
INFO - 2019-11-04 09:32:03 --> Input Class Initialized
INFO - 2019-11-04 09:32:03 --> Input Class Initialized
INFO - 2019-11-04 09:32:03 --> Input Class Initialized
INFO - 2019-11-04 09:32:03 --> Input Class Initialized
INFO - 2019-11-04 09:32:03 --> Input Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Loader Class Initialized
INFO - 2019-11-04 09:32:03 --> Loader Class Initialized
INFO - 2019-11-04 09:32:03 --> Loader Class Initialized
INFO - 2019-11-04 09:32:03 --> Loader Class Initialized
INFO - 2019-11-04 09:32:03 --> Loader Class Initialized
INFO - 2019-11-04 09:32:03 --> Loader Class Initialized
INFO - 2019-11-04 09:32:03 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:03 --> Parser Class Initialized
INFO - 2019-11-04 09:32:03 --> Parser Class Initialized
INFO - 2019-11-04 09:32:03 --> Parser Class Initialized
INFO - 2019-11-04 09:32:03 --> Parser Class Initialized
INFO - 2019-11-04 09:32:03 --> Parser Class Initialized
INFO - 2019-11-04 09:32:03 --> Parser Class Initialized
INFO - 2019-11-04 09:32:03 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:03 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:03 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:03 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:03 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:03 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:03 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:03 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:03 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:03 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:03 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Template Class Initialized
INFO - 2019-11-04 09:32:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:03 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:03 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:03 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:03 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:03 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:03 --> Total execution time: 0.5395
INFO - 2019-11-04 09:32:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:03 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:03 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:03 --> Utf8 Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:03 --> URI Class Initialized
INFO - 2019-11-04 09:32:03 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:03 --> Router Class Initialized
INFO - 2019-11-04 09:32:03 --> Controller Class Initialized
INFO - 2019-11-04 09:32:03 --> Output Class Initialized
DEBUG - 2019-11-04 09:32:03 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:03 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:03 --> Model Class Initialized
INFO - 2019-11-04 09:32:03 --> CSRF cookie sent
INFO - 2019-11-04 09:32:03 --> CSRF token verified
INFO - 2019-11-04 09:32:03 --> Input Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
INFO - 2019-11-04 09:32:03 --> Language Class Initialized
DEBUG - 2019-11-04 09:32:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:03 --> Total execution time: 0.7308
INFO - 2019-11-04 09:32:03 --> Loader Class Initialized
INFO - 2019-11-04 09:32:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:03 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:03 --> Config Class Initialized
INFO - 2019-11-04 09:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:03 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:04 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:04 --> Pagination Class Initialized
INFO - 2019-11-04 09:32:04 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:04 --> Helper loaded: cookie_helper
DEBUG - 2019-11-04 09:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-04 09:32:04 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:04 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:04 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:04 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:04 --> URI Class Initialized
INFO - 2019-11-04 09:32:04 --> Controller Class Initialized
INFO - 2019-11-04 09:32:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:04 --> Router Class Initialized
DEBUG - 2019-11-04 09:32:04 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:04 --> Output Class Initialized
INFO - 2019-11-04 09:32:04 --> Parser Class Initialized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:04 --> Security Class Initialized
INFO - 2019-11-04 09:32:04 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
INFO - 2019-11-04 09:32:04 --> CSRF cookie sent
INFO - 2019-11-04 09:32:04 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:04 --> CSRF token verified
INFO - 2019-11-04 09:32:04 --> Input Class Initialized
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
INFO - 2019-11-04 09:32:04 --> Language Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:04 --> Final output sent to browser
INFO - 2019-11-04 09:32:04 --> Language Class Initialized
INFO - 2019-11-04 09:32:04 --> Config Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Total execution time: 0.9234
INFO - 2019-11-04 09:32:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:04 --> Loader Class Initialized
INFO - 2019-11-04 09:32:04 --> Config Class Initialized
INFO - 2019-11-04 09:32:04 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:04 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:04 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:04 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:04 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:04 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:04 --> Helper loaded: language_helper
DEBUG - 2019-11-04 09:32:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:04 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:04 --> URI Class Initialized
INFO - 2019-11-04 09:32:04 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:04 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:04 --> Router Class Initialized
INFO - 2019-11-04 09:32:04 --> Controller Class Initialized
INFO - 2019-11-04 09:32:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:04 --> Output Class Initialized
DEBUG - 2019-11-04 09:32:04 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:04 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:04 --> Parser Class Initialized
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
INFO - 2019-11-04 09:32:04 --> CSRF cookie sent
INFO - 2019-11-04 09:32:04 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:04 --> CSRF token verified
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
INFO - 2019-11-04 09:32:04 --> Input Class Initialized
INFO - 2019-11-04 09:32:04 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:04 --> Language Class Initialized
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Template Class Initialized
INFO - 2019-11-04 09:32:04 --> Language Class Initialized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:04 --> Config Class Initialized
INFO - 2019-11-04 09:32:04 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:04 --> Total execution time: 1.1380
INFO - 2019-11-04 09:32:04 --> Loader Class Initialized
INFO - 2019-11-04 09:32:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:04 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:04 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:04 --> Pagination Class Initialized
INFO - 2019-11-04 09:32:04 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:04 --> Helper loaded: cookie_helper
DEBUG - 2019-11-04 09:32:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:04 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:04 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:04 --> Controller Class Initialized
INFO - 2019-11-04 09:32:04 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-04 09:32:04 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:04 --> Parser Class Initialized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:04 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
INFO - 2019-11-04 09:32:04 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:04 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:04 --> Total execution time: 1.3460
INFO - 2019-11-04 09:32:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:04 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:04 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:04 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:04 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:04 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:04 --> Total execution time: 1.5416
INFO - 2019-11-04 09:32:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:04 --> Pagination Class Initialized
INFO - 2019-11-04 09:32:04 --> Config Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:04 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:04 --> Encryption Class Initialized
DEBUG - 2019-11-04 09:32:04 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:04 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:04 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:04 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:04 --> URI Class Initialized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:04 --> Router Class Initialized
INFO - 2019-11-04 09:32:04 --> Model Class Initialized
INFO - 2019-11-04 09:32:04 --> Output Class Initialized
INFO - 2019-11-04 09:32:04 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:32:04 --> CSRF cookie sent
INFO - 2019-11-04 09:32:04 --> Input Class Initialized
DEBUG - 2019-11-04 09:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:04 --> Final output sent to browser
INFO - 2019-11-04 09:32:04 --> Language Class Initialized
DEBUG - 2019-11-04 09:32:04 --> Total execution time: 1.1861
INFO - 2019-11-04 09:32:04 --> Language Class Initialized
INFO - 2019-11-04 09:32:04 --> Config Class Initialized
INFO - 2019-11-04 09:32:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:05 --> Loader Class Initialized
INFO - 2019-11-04 09:32:05 --> Pagination Class Initialized
INFO - 2019-11-04 09:32:05 --> Helper loaded: url_helper
DEBUG - 2019-11-04 09:32:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:05 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:05 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:05 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:05 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:05 --> Controller Class Initialized
INFO - 2019-11-04 09:32:05 --> Helper loaded: email_helper
DEBUG - 2019-11-04 09:32:05 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:05 --> Helper loaded: file_manager_helper
DEBUG - 2019-11-04 09:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:05 --> Model Class Initialized
INFO - 2019-11-04 09:32:05 --> Parser Class Initialized
INFO - 2019-11-04 09:32:05 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:05 --> Model Class Initialized
INFO - 2019-11-04 09:32:05 --> Database Driver Class Initialized
DEBUG - 2019-11-04 09:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:05 --> Final output sent to browser
INFO - 2019-11-04 09:32:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:05 --> Total execution time: 1.1400
DEBUG - 2019-11-04 09:32:05 --> Template Class Initialized
INFO - 2019-11-04 09:32:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:05 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:05 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:05 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:05 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:05 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:05 --> Total execution time: 1.1096
INFO - 2019-11-04 09:32:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:05 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:05 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:05 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:05 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/update.php
INFO - 2019-11-04 09:32:05 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:05 --> Total execution time: 0.6366
INFO - 2019-11-04 09:32:13 --> Config Class Initialized
INFO - 2019-11-04 09:32:13 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:32:13 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:13 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:13 --> URI Class Initialized
INFO - 2019-11-04 09:32:13 --> Router Class Initialized
INFO - 2019-11-04 09:32:13 --> Output Class Initialized
INFO - 2019-11-04 09:32:13 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:32:13 --> CSRF cookie sent
INFO - 2019-11-04 09:32:13 --> CSRF token verified
INFO - 2019-11-04 09:32:13 --> Input Class Initialized
INFO - 2019-11-04 09:32:13 --> Language Class Initialized
INFO - 2019-11-04 09:32:13 --> Language Class Initialized
INFO - 2019-11-04 09:32:13 --> Config Class Initialized
INFO - 2019-11-04 09:32:13 --> Loader Class Initialized
INFO - 2019-11-04 09:32:13 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:13 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:13 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:13 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:13 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:13 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:13 --> Parser Class Initialized
INFO - 2019-11-04 09:32:13 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:13 --> Model Class Initialized
INFO - 2019-11-04 09:32:13 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:13 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:13 --> Template Class Initialized
INFO - 2019-11-04 09:32:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:14 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:14 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:14 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:14 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:14 --> Model Class Initialized
INFO - 2019-11-04 09:32:19 --> Config Class Initialized
INFO - 2019-11-04 09:32:19 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:32:19 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:19 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:19 --> URI Class Initialized
INFO - 2019-11-04 09:32:19 --> Router Class Initialized
INFO - 2019-11-04 09:32:19 --> Output Class Initialized
INFO - 2019-11-04 09:32:19 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:32:19 --> CSRF cookie sent
INFO - 2019-11-04 09:32:19 --> CSRF token verified
INFO - 2019-11-04 09:32:19 --> Input Class Initialized
INFO - 2019-11-04 09:32:19 --> Language Class Initialized
INFO - 2019-11-04 09:32:19 --> Language Class Initialized
INFO - 2019-11-04 09:32:19 --> Config Class Initialized
INFO - 2019-11-04 09:32:19 --> Loader Class Initialized
INFO - 2019-11-04 09:32:19 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:19 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:19 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:19 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:19 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:20 --> Parser Class Initialized
INFO - 2019-11-04 09:32:20 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:20 --> Model Class Initialized
INFO - 2019-11-04 09:32:20 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:20 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:20 --> Template Class Initialized
INFO - 2019-11-04 09:32:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:20 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:20 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:20 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:20 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:20 --> Model Class Initialized
INFO - 2019-11-04 09:32:24 --> Config Class Initialized
INFO - 2019-11-04 09:32:24 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:32:24 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:24 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:24 --> URI Class Initialized
INFO - 2019-11-04 09:32:25 --> Router Class Initialized
INFO - 2019-11-04 09:32:25 --> Output Class Initialized
INFO - 2019-11-04 09:32:25 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:32:25 --> CSRF cookie sent
INFO - 2019-11-04 09:32:25 --> Input Class Initialized
INFO - 2019-11-04 09:32:25 --> Language Class Initialized
INFO - 2019-11-04 09:32:25 --> Language Class Initialized
INFO - 2019-11-04 09:32:25 --> Config Class Initialized
INFO - 2019-11-04 09:32:25 --> Loader Class Initialized
INFO - 2019-11-04 09:32:25 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:25 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:25 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:25 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:25 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:25 --> Parser Class Initialized
INFO - 2019-11-04 09:32:25 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:25 --> Model Class Initialized
INFO - 2019-11-04 09:32:25 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:25 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:25 --> Template Class Initialized
INFO - 2019-11-04 09:32:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:25 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:25 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:25 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:25 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:25 --> Model Class Initialized
INFO - 2019-11-04 09:32:25 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 09:32:25 --> Could not find the language line "Delele"
DEBUG - 2019-11-04 09:32:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2019-11-04 09:32:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:32:25 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:32:25 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:25 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:32:25 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:32:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:32:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:32:25 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:25 --> Total execution time: 0.9172
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:26 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:26 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:26 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:26 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:26 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 09:32:26 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:26 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:26 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:26 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:26 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:26 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:26 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:26 --> URI Class Initialized
INFO - 2019-11-04 09:32:26 --> URI Class Initialized
INFO - 2019-11-04 09:32:26 --> URI Class Initialized
INFO - 2019-11-04 09:32:26 --> URI Class Initialized
INFO - 2019-11-04 09:32:26 --> URI Class Initialized
INFO - 2019-11-04 09:32:26 --> URI Class Initialized
INFO - 2019-11-04 09:32:26 --> Router Class Initialized
INFO - 2019-11-04 09:32:26 --> Router Class Initialized
INFO - 2019-11-04 09:32:26 --> Router Class Initialized
INFO - 2019-11-04 09:32:26 --> Router Class Initialized
INFO - 2019-11-04 09:32:26 --> Router Class Initialized
INFO - 2019-11-04 09:32:26 --> Router Class Initialized
INFO - 2019-11-04 09:32:26 --> Output Class Initialized
INFO - 2019-11-04 09:32:26 --> Output Class Initialized
INFO - 2019-11-04 09:32:26 --> Output Class Initialized
INFO - 2019-11-04 09:32:26 --> Output Class Initialized
INFO - 2019-11-04 09:32:26 --> Output Class Initialized
INFO - 2019-11-04 09:32:26 --> Output Class Initialized
INFO - 2019-11-04 09:32:26 --> Security Class Initialized
INFO - 2019-11-04 09:32:26 --> Security Class Initialized
INFO - 2019-11-04 09:32:26 --> Security Class Initialized
INFO - 2019-11-04 09:32:26 --> Security Class Initialized
INFO - 2019-11-04 09:32:26 --> Security Class Initialized
INFO - 2019-11-04 09:32:26 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:32:26 --> CSRF cookie sent
INFO - 2019-11-04 09:32:26 --> CSRF cookie sent
INFO - 2019-11-04 09:32:26 --> CSRF cookie sent
INFO - 2019-11-04 09:32:26 --> CSRF cookie sent
INFO - 2019-11-04 09:32:26 --> CSRF cookie sent
INFO - 2019-11-04 09:32:26 --> CSRF cookie sent
INFO - 2019-11-04 09:32:26 --> CSRF token verified
INFO - 2019-11-04 09:32:26 --> CSRF token verified
INFO - 2019-11-04 09:32:26 --> CSRF token verified
INFO - 2019-11-04 09:32:26 --> CSRF token verified
INFO - 2019-11-04 09:32:26 --> CSRF token verified
INFO - 2019-11-04 09:32:26 --> CSRF token verified
INFO - 2019-11-04 09:32:26 --> Input Class Initialized
INFO - 2019-11-04 09:32:26 --> Input Class Initialized
INFO - 2019-11-04 09:32:26 --> Input Class Initialized
INFO - 2019-11-04 09:32:26 --> Input Class Initialized
INFO - 2019-11-04 09:32:26 --> Input Class Initialized
INFO - 2019-11-04 09:32:26 --> Input Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Language Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:26 --> Loader Class Initialized
INFO - 2019-11-04 09:32:26 --> Loader Class Initialized
INFO - 2019-11-04 09:32:26 --> Loader Class Initialized
INFO - 2019-11-04 09:32:26 --> Loader Class Initialized
INFO - 2019-11-04 09:32:26 --> Loader Class Initialized
INFO - 2019-11-04 09:32:26 --> Loader Class Initialized
INFO - 2019-11-04 09:32:26 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:26 --> Parser Class Initialized
INFO - 2019-11-04 09:32:26 --> Parser Class Initialized
INFO - 2019-11-04 09:32:26 --> Parser Class Initialized
INFO - 2019-11-04 09:32:26 --> Parser Class Initialized
INFO - 2019-11-04 09:32:26 --> Parser Class Initialized
INFO - 2019-11-04 09:32:26 --> Parser Class Initialized
INFO - 2019-11-04 09:32:26 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:26 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:26 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:26 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:26 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:26 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:26 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:26 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:26 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:26 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:26 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:26 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:26 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:26 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:26 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:26 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:26 --> Template Class Initialized
INFO - 2019-11-04 09:32:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:26 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:26 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:26 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:26 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:26 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:26 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:26 --> Total execution time: 0.5459
INFO - 2019-11-04 09:32:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:26 --> Config Class Initialized
INFO - 2019-11-04 09:32:27 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:27 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:27 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:27 --> Utf8 Class Initialized
DEBUG - 2019-11-04 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:27 --> URI Class Initialized
INFO - 2019-11-04 09:32:27 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:27 --> Router Class Initialized
INFO - 2019-11-04 09:32:27 --> Controller Class Initialized
INFO - 2019-11-04 09:32:27 --> Output Class Initialized
DEBUG - 2019-11-04 09:32:27 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:27 --> Security Class Initialized
DEBUG - 2019-11-04 09:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
INFO - 2019-11-04 09:32:27 --> CSRF cookie sent
INFO - 2019-11-04 09:32:27 --> CSRF token verified
INFO - 2019-11-04 09:32:27 --> Input Class Initialized
INFO - 2019-11-04 09:32:27 --> Language Class Initialized
INFO - 2019-11-04 09:32:27 --> Language Class Initialized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:27 --> Config Class Initialized
INFO - 2019-11-04 09:32:27 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:27 --> Total execution time: 0.7249
INFO - 2019-11-04 09:32:27 --> Loader Class Initialized
INFO - 2019-11-04 09:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:27 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:27 --> Config Class Initialized
INFO - 2019-11-04 09:32:27 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:27 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:27 --> Pagination Class Initialized
INFO - 2019-11-04 09:32:27 --> Helper loaded: language_helper
DEBUG - 2019-11-04 09:32:27 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:27 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:27 --> Helper loaded: cookie_helper
DEBUG - 2019-11-04 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:27 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:27 --> URI Class Initialized
INFO - 2019-11-04 09:32:27 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:27 --> Router Class Initialized
INFO - 2019-11-04 09:32:27 --> Controller Class Initialized
INFO - 2019-11-04 09:32:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:32:27 --> Output Class Initialized
DEBUG - 2019-11-04 09:32:27 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:27 --> Security Class Initialized
INFO - 2019-11-04 09:32:27 --> Parser Class Initialized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
DEBUG - 2019-11-04 09:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:32:27 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:27 --> CSRF cookie sent
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
INFO - 2019-11-04 09:32:27 --> CSRF token verified
INFO - 2019-11-04 09:32:27 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:27 --> Input Class Initialized
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
INFO - 2019-11-04 09:32:27 --> Language Class Initialized
DEBUG - 2019-11-04 09:32:27 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:27 --> Language Class Initialized
INFO - 2019-11-04 09:32:27 --> Final output sent to browser
INFO - 2019-11-04 09:32:27 --> Config Class Initialized
DEBUG - 2019-11-04 09:32:27 --> Total execution time: 0.9014
INFO - 2019-11-04 09:32:27 --> Loader Class Initialized
INFO - 2019-11-04 09:32:27 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:27 --> Config Class Initialized
INFO - 2019-11-04 09:32:27 --> Hooks Class Initialized
INFO - 2019-11-04 09:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:27 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:27 --> Pagination Class Initialized
INFO - 2019-11-04 09:32:27 --> Helper loaded: language_helper
DEBUG - 2019-11-04 09:32:27 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:32:27 --> Utf8 Class Initialized
INFO - 2019-11-04 09:32:27 --> Helper loaded: cookie_helper
DEBUG - 2019-11-04 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:27 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:27 --> URI Class Initialized
INFO - 2019-11-04 09:32:27 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:27 --> Router Class Initialized
INFO - 2019-11-04 09:32:27 --> Controller Class Initialized
INFO - 2019-11-04 09:32:27 --> Output Class Initialized
INFO - 2019-11-04 09:32:27 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-04 09:32:27 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:27 --> Security Class Initialized
INFO - 2019-11-04 09:32:27 --> Parser Class Initialized
DEBUG - 2019-11-04 09:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:27 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
INFO - 2019-11-04 09:32:27 --> CSRF cookie sent
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
INFO - 2019-11-04 09:32:27 --> CSRF token verified
INFO - 2019-11-04 09:32:27 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:27 --> Input Class Initialized
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
INFO - 2019-11-04 09:32:27 --> Language Class Initialized
DEBUG - 2019-11-04 09:32:27 --> Template Class Initialized
INFO - 2019-11-04 09:32:27 --> Language Class Initialized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:27 --> Config Class Initialized
INFO - 2019-11-04 09:32:27 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:27 --> Total execution time: 1.0843
INFO - 2019-11-04 09:32:27 --> Loader Class Initialized
INFO - 2019-11-04 09:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:27 --> Helper loaded: url_helper
INFO - 2019-11-04 09:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:27 --> Helper loaded: common_helper
INFO - 2019-11-04 09:32:27 --> Pagination Class Initialized
INFO - 2019-11-04 09:32:27 --> Helper loaded: language_helper
INFO - 2019-11-04 09:32:27 --> Helper loaded: cookie_helper
DEBUG - 2019-11-04 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:27 --> Helper loaded: email_helper
INFO - 2019-11-04 09:32:27 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:32:27 --> Controller Class Initialized
INFO - 2019-11-04 09:32:27 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-04 09:32:27 --> services MX_Controller Initialized
INFO - 2019-11-04 09:32:27 --> Parser Class Initialized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:27 --> User Agent Class Initialized
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
INFO - 2019-11-04 09:32:27 --> Database Driver Class Initialized
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:27 --> Template Class Initialized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:27 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:27 --> Total execution time: 1.2811
INFO - 2019-11-04 09:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:27 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:27 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:27 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:27 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:27 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:27 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:27 --> Total execution time: 1.4816
INFO - 2019-11-04 09:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:27 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:27 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:27 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:28 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:28 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:28 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:28 --> Total execution time: 1.0781
INFO - 2019-11-04 09:32:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:28 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:28 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:28 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:28 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:28 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:28 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:28 --> Total execution time: 1.1006
INFO - 2019-11-04 09:32:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:32:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:32:28 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:32:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:32:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:32:28 --> Encryption Class Initialized
INFO - 2019-11-04 09:32:28 --> Controller Class Initialized
DEBUG - 2019-11-04 09:32:28 --> services MX_Controller Initialized
DEBUG - 2019-11-04 09:32:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:32:28 --> Model Class Initialized
DEBUG - 2019-11-04 09:32:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-04 09:32:28 --> Final output sent to browser
DEBUG - 2019-11-04 09:32:28 --> Total execution time: 1.1202
INFO - 2019-11-04 09:33:45 --> Config Class Initialized
INFO - 2019-11-04 09:33:45 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:33:45 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:33:45 --> Utf8 Class Initialized
INFO - 2019-11-04 09:33:45 --> URI Class Initialized
INFO - 2019-11-04 09:33:45 --> Router Class Initialized
INFO - 2019-11-04 09:33:45 --> Output Class Initialized
INFO - 2019-11-04 09:33:45 --> Security Class Initialized
DEBUG - 2019-11-04 09:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:33:45 --> CSRF cookie sent
INFO - 2019-11-04 09:33:45 --> Input Class Initialized
INFO - 2019-11-04 09:33:45 --> Language Class Initialized
INFO - 2019-11-04 09:33:45 --> Language Class Initialized
INFO - 2019-11-04 09:33:45 --> Config Class Initialized
INFO - 2019-11-04 09:33:45 --> Loader Class Initialized
INFO - 2019-11-04 09:33:45 --> Helper loaded: url_helper
INFO - 2019-11-04 09:33:45 --> Helper loaded: common_helper
INFO - 2019-11-04 09:33:45 --> Helper loaded: language_helper
INFO - 2019-11-04 09:33:45 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:33:45 --> Helper loaded: email_helper
INFO - 2019-11-04 09:33:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:33:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:33:45 --> Parser Class Initialized
INFO - 2019-11-04 09:33:45 --> User Agent Class Initialized
INFO - 2019-11-04 09:33:45 --> Model Class Initialized
INFO - 2019-11-04 09:33:45 --> Database Driver Class Initialized
INFO - 2019-11-04 09:33:45 --> Model Class Initialized
DEBUG - 2019-11-04 09:33:45 --> Template Class Initialized
INFO - 2019-11-04 09:33:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:33:45 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:33:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:33:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:33:45 --> Encryption Class Initialized
INFO - 2019-11-04 09:33:45 --> Controller Class Initialized
DEBUG - 2019-11-04 09:33:45 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 09:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 09:33:45 --> Model Class Initialized
INFO - 2019-11-04 09:33:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 09:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 09:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-04 09:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 09:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:33:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:33:45 --> Model Class Initialized
DEBUG - 2019-11-04 09:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:33:45 --> Model Class Initialized
DEBUG - 2019-11-04 09:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:33:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:33:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:33:46 --> Final output sent to browser
DEBUG - 2019-11-04 09:33:46 --> Total execution time: 0.9065
INFO - 2019-11-04 09:35:01 --> Config Class Initialized
INFO - 2019-11-04 09:35:01 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:35:01 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:35:01 --> Utf8 Class Initialized
INFO - 2019-11-04 09:35:01 --> URI Class Initialized
INFO - 2019-11-04 09:35:01 --> Router Class Initialized
INFO - 2019-11-04 09:35:01 --> Output Class Initialized
INFO - 2019-11-04 09:35:01 --> Security Class Initialized
DEBUG - 2019-11-04 09:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:35:01 --> CSRF cookie sent
INFO - 2019-11-04 09:35:01 --> Input Class Initialized
INFO - 2019-11-04 09:35:01 --> Language Class Initialized
INFO - 2019-11-04 09:35:01 --> Language Class Initialized
INFO - 2019-11-04 09:35:01 --> Config Class Initialized
INFO - 2019-11-04 09:35:01 --> Loader Class Initialized
INFO - 2019-11-04 09:35:01 --> Helper loaded: url_helper
INFO - 2019-11-04 09:35:01 --> Helper loaded: common_helper
INFO - 2019-11-04 09:35:01 --> Helper loaded: language_helper
INFO - 2019-11-04 09:35:01 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:35:01 --> Helper loaded: email_helper
INFO - 2019-11-04 09:35:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:35:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:35:01 --> Parser Class Initialized
INFO - 2019-11-04 09:35:01 --> User Agent Class Initialized
INFO - 2019-11-04 09:35:01 --> Model Class Initialized
INFO - 2019-11-04 09:35:01 --> Database Driver Class Initialized
INFO - 2019-11-04 09:35:01 --> Model Class Initialized
DEBUG - 2019-11-04 09:35:01 --> Template Class Initialized
INFO - 2019-11-04 09:35:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:35:01 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:35:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:35:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:35:01 --> Encryption Class Initialized
INFO - 2019-11-04 09:35:01 --> Controller Class Initialized
DEBUG - 2019-11-04 09:35:01 --> language MX_Controller Initialized
DEBUG - 2019-11-04 09:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-04 09:35:01 --> Model Class Initialized
INFO - 2019-11-04 09:35:01 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 09:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-11-04 09:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:35:01 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:35:01 --> Model Class Initialized
DEBUG - 2019-11-04 09:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:35:01 --> Model Class Initialized
DEBUG - 2019-11-04 09:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:35:02 --> Final output sent to browser
DEBUG - 2019-11-04 09:35:02 --> Total execution time: 0.8369
INFO - 2019-11-04 09:35:04 --> Config Class Initialized
INFO - 2019-11-04 09:35:04 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:35:04 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:35:04 --> Utf8 Class Initialized
INFO - 2019-11-04 09:35:04 --> URI Class Initialized
INFO - 2019-11-04 09:35:04 --> Router Class Initialized
INFO - 2019-11-04 09:35:04 --> Output Class Initialized
INFO - 2019-11-04 09:35:04 --> Security Class Initialized
DEBUG - 2019-11-04 09:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:35:04 --> CSRF cookie sent
INFO - 2019-11-04 09:35:04 --> Input Class Initialized
INFO - 2019-11-04 09:35:04 --> Language Class Initialized
INFO - 2019-11-04 09:35:04 --> Language Class Initialized
INFO - 2019-11-04 09:35:05 --> Config Class Initialized
INFO - 2019-11-04 09:35:05 --> Loader Class Initialized
INFO - 2019-11-04 09:35:05 --> Helper loaded: url_helper
INFO - 2019-11-04 09:35:05 --> Helper loaded: common_helper
INFO - 2019-11-04 09:35:05 --> Helper loaded: language_helper
INFO - 2019-11-04 09:35:05 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:35:05 --> Helper loaded: email_helper
INFO - 2019-11-04 09:35:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:35:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:35:05 --> Parser Class Initialized
INFO - 2019-11-04 09:35:05 --> User Agent Class Initialized
INFO - 2019-11-04 09:35:05 --> Model Class Initialized
INFO - 2019-11-04 09:35:05 --> Database Driver Class Initialized
INFO - 2019-11-04 09:35:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:35:05 --> Template Class Initialized
INFO - 2019-11-04 09:35:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:35:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:35:05 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:35:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:35:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:35:05 --> Encryption Class Initialized
INFO - 2019-11-04 09:35:05 --> Controller Class Initialized
DEBUG - 2019-11-04 09:35:05 --> language MX_Controller Initialized
DEBUG - 2019-11-04 09:35:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-04 09:35:05 --> Model Class Initialized
INFO - 2019-11-04 09:35:07 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 09:35:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2019-11-04 09:35:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:35:07 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:35:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:35:07 --> Model Class Initialized
DEBUG - 2019-11-04 09:35:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:35:07 --> Model Class Initialized
DEBUG - 2019-11-04 09:35:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:35:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:35:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:35:07 --> Final output sent to browser
DEBUG - 2019-11-04 09:35:07 --> Total execution time: 2.4081
INFO - 2019-11-04 09:38:04 --> Config Class Initialized
INFO - 2019-11-04 09:38:04 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:38:04 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:38:04 --> Utf8 Class Initialized
INFO - 2019-11-04 09:38:04 --> URI Class Initialized
INFO - 2019-11-04 09:38:04 --> Router Class Initialized
INFO - 2019-11-04 09:38:04 --> Output Class Initialized
INFO - 2019-11-04 09:38:04 --> Security Class Initialized
DEBUG - 2019-11-04 09:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:38:04 --> CSRF cookie sent
INFO - 2019-11-04 09:38:04 --> Input Class Initialized
INFO - 2019-11-04 09:38:04 --> Language Class Initialized
INFO - 2019-11-04 09:38:04 --> Language Class Initialized
INFO - 2019-11-04 09:38:04 --> Config Class Initialized
INFO - 2019-11-04 09:38:04 --> Loader Class Initialized
INFO - 2019-11-04 09:38:04 --> Helper loaded: url_helper
INFO - 2019-11-04 09:38:04 --> Helper loaded: common_helper
INFO - 2019-11-04 09:38:05 --> Helper loaded: language_helper
INFO - 2019-11-04 09:38:05 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:38:05 --> Helper loaded: email_helper
INFO - 2019-11-04 09:38:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:38:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:38:05 --> Parser Class Initialized
INFO - 2019-11-04 09:38:05 --> User Agent Class Initialized
INFO - 2019-11-04 09:38:05 --> Model Class Initialized
INFO - 2019-11-04 09:38:05 --> Database Driver Class Initialized
INFO - 2019-11-04 09:38:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:38:05 --> Template Class Initialized
INFO - 2019-11-04 09:38:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:38:05 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:38:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:38:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:38:05 --> Encryption Class Initialized
INFO - 2019-11-04 09:38:05 --> Controller Class Initialized
DEBUG - 2019-11-04 09:38:05 --> order MX_Controller Initialized
DEBUG - 2019-11-04 09:38:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-04 09:38:05 --> Model Class Initialized
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "order_id"
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "order_id"
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "order_basic_details"
INFO - 2019-11-04 09:38:05 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "Pending"
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "Pending"
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "Pending"
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-04 09:38:05 --> Could not find the language line "Pending"
DEBUG - 2019-11-04 09:38:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-04 09:38:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:38:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:38:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:38:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:38:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:38:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:38:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:38:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:38:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:38:05 --> Final output sent to browser
DEBUG - 2019-11-04 09:38:05 --> Total execution time: 1.0526
INFO - 2019-11-04 09:51:21 --> Config Class Initialized
INFO - 2019-11-04 09:51:22 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:51:22 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:51:22 --> Utf8 Class Initialized
INFO - 2019-11-04 09:51:22 --> URI Class Initialized
INFO - 2019-11-04 09:51:22 --> Router Class Initialized
INFO - 2019-11-04 09:51:22 --> Output Class Initialized
INFO - 2019-11-04 09:51:22 --> Security Class Initialized
DEBUG - 2019-11-04 09:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:51:22 --> CSRF cookie sent
INFO - 2019-11-04 09:51:22 --> Input Class Initialized
INFO - 2019-11-04 09:51:22 --> Language Class Initialized
INFO - 2019-11-04 09:51:22 --> Language Class Initialized
INFO - 2019-11-04 09:51:22 --> Config Class Initialized
INFO - 2019-11-04 09:51:22 --> Loader Class Initialized
INFO - 2019-11-04 09:51:22 --> Helper loaded: url_helper
INFO - 2019-11-04 09:51:22 --> Helper loaded: common_helper
INFO - 2019-11-04 09:51:22 --> Helper loaded: language_helper
INFO - 2019-11-04 09:51:22 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:51:22 --> Helper loaded: email_helper
INFO - 2019-11-04 09:51:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:51:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:51:22 --> Parser Class Initialized
INFO - 2019-11-04 09:51:22 --> User Agent Class Initialized
INFO - 2019-11-04 09:51:22 --> Model Class Initialized
INFO - 2019-11-04 09:51:22 --> Database Driver Class Initialized
INFO - 2019-11-04 09:51:22 --> Model Class Initialized
DEBUG - 2019-11-04 09:51:22 --> Template Class Initialized
INFO - 2019-11-04 09:51:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:51:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:51:22 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:51:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:51:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:51:22 --> Encryption Class Initialized
INFO - 2019-11-04 09:51:22 --> Controller Class Initialized
DEBUG - 2019-11-04 09:51:22 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 09:51:22 --> Model Class Initialized
INFO - 2019-11-04 09:51:22 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:51:22 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:51:22 --> Model Class Initialized
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:51:22 --> Model Class Initialized
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:51:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:51:22 --> Final output sent to browser
DEBUG - 2019-11-04 09:51:22 --> Total execution time: 0.6988
INFO - 2019-11-04 09:51:53 --> Config Class Initialized
INFO - 2019-11-04 09:51:53 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:51:53 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:51:53 --> Utf8 Class Initialized
INFO - 2019-11-04 09:51:53 --> URI Class Initialized
INFO - 2019-11-04 09:51:53 --> Router Class Initialized
INFO - 2019-11-04 09:51:53 --> Output Class Initialized
INFO - 2019-11-04 09:51:53 --> Security Class Initialized
DEBUG - 2019-11-04 09:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:51:53 --> CSRF cookie sent
INFO - 2019-11-04 09:51:53 --> Input Class Initialized
INFO - 2019-11-04 09:51:53 --> Language Class Initialized
INFO - 2019-11-04 09:51:53 --> Language Class Initialized
INFO - 2019-11-04 09:51:53 --> Config Class Initialized
INFO - 2019-11-04 09:51:53 --> Loader Class Initialized
INFO - 2019-11-04 09:51:53 --> Helper loaded: url_helper
INFO - 2019-11-04 09:51:53 --> Helper loaded: common_helper
INFO - 2019-11-04 09:51:53 --> Helper loaded: language_helper
INFO - 2019-11-04 09:51:53 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:51:53 --> Helper loaded: email_helper
INFO - 2019-11-04 09:51:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:51:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:51:53 --> Parser Class Initialized
INFO - 2019-11-04 09:51:53 --> User Agent Class Initialized
INFO - 2019-11-04 09:51:53 --> Model Class Initialized
INFO - 2019-11-04 09:51:53 --> Database Driver Class Initialized
INFO - 2019-11-04 09:51:53 --> Model Class Initialized
DEBUG - 2019-11-04 09:51:53 --> Template Class Initialized
INFO - 2019-11-04 09:51:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:51:53 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:51:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:51:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:51:53 --> Encryption Class Initialized
INFO - 2019-11-04 09:51:53 --> Controller Class Initialized
DEBUG - 2019-11-04 09:51:53 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 09:51:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 09:51:53 --> Model Class Initialized
INFO - 2019-11-04 09:51:54 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 09:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 09:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-04 09:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 09:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:51:54 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:51:54 --> Model Class Initialized
DEBUG - 2019-11-04 09:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:51:54 --> Model Class Initialized
DEBUG - 2019-11-04 09:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:51:54 --> Final output sent to browser
DEBUG - 2019-11-04 09:51:54 --> Total execution time: 0.6595
INFO - 2019-11-04 09:52:04 --> Config Class Initialized
INFO - 2019-11-04 09:52:04 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:52:04 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:52:04 --> Utf8 Class Initialized
INFO - 2019-11-04 09:52:04 --> URI Class Initialized
INFO - 2019-11-04 09:52:04 --> Router Class Initialized
INFO - 2019-11-04 09:52:04 --> Output Class Initialized
INFO - 2019-11-04 09:52:05 --> Security Class Initialized
DEBUG - 2019-11-04 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:52:05 --> CSRF cookie sent
INFO - 2019-11-04 09:52:05 --> Input Class Initialized
INFO - 2019-11-04 09:52:05 --> Language Class Initialized
INFO - 2019-11-04 09:52:05 --> Language Class Initialized
INFO - 2019-11-04 09:52:05 --> Config Class Initialized
INFO - 2019-11-04 09:52:05 --> Loader Class Initialized
INFO - 2019-11-04 09:52:05 --> Helper loaded: url_helper
INFO - 2019-11-04 09:52:05 --> Helper loaded: common_helper
INFO - 2019-11-04 09:52:05 --> Helper loaded: language_helper
INFO - 2019-11-04 09:52:05 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:52:05 --> Helper loaded: email_helper
INFO - 2019-11-04 09:52:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:52:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:52:05 --> Parser Class Initialized
INFO - 2019-11-04 09:52:05 --> User Agent Class Initialized
INFO - 2019-11-04 09:52:05 --> Model Class Initialized
INFO - 2019-11-04 09:52:05 --> Database Driver Class Initialized
INFO - 2019-11-04 09:52:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:52:05 --> Template Class Initialized
INFO - 2019-11-04 09:52:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:52:05 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:52:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:52:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:52:05 --> Encryption Class Initialized
INFO - 2019-11-04 09:52:05 --> Controller Class Initialized
DEBUG - 2019-11-04 09:52:05 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 09:52:05 --> Model Class Initialized
INFO - 2019-11-04 09:52:05 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/payment.php
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:52:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:52:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:52:05 --> Model Class Initialized
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:52:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:52:05 --> Final output sent to browser
DEBUG - 2019-11-04 09:52:05 --> Total execution time: 0.7040
INFO - 2019-11-04 09:52:14 --> Config Class Initialized
INFO - 2019-11-04 09:52:14 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:52:14 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:52:14 --> Utf8 Class Initialized
INFO - 2019-11-04 09:52:14 --> URI Class Initialized
INFO - 2019-11-04 09:52:14 --> Router Class Initialized
INFO - 2019-11-04 09:52:14 --> Output Class Initialized
INFO - 2019-11-04 09:52:15 --> Security Class Initialized
DEBUG - 2019-11-04 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:52:15 --> CSRF cookie sent
INFO - 2019-11-04 09:52:15 --> Input Class Initialized
INFO - 2019-11-04 09:52:15 --> Language Class Initialized
INFO - 2019-11-04 09:52:15 --> Language Class Initialized
INFO - 2019-11-04 09:52:15 --> Config Class Initialized
INFO - 2019-11-04 09:52:15 --> Loader Class Initialized
INFO - 2019-11-04 09:52:15 --> Helper loaded: url_helper
INFO - 2019-11-04 09:52:15 --> Helper loaded: common_helper
INFO - 2019-11-04 09:52:15 --> Helper loaded: language_helper
INFO - 2019-11-04 09:52:15 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:52:15 --> Helper loaded: email_helper
INFO - 2019-11-04 09:52:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:52:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:52:15 --> Parser Class Initialized
INFO - 2019-11-04 09:52:15 --> User Agent Class Initialized
INFO - 2019-11-04 09:52:15 --> Model Class Initialized
INFO - 2019-11-04 09:52:15 --> Database Driver Class Initialized
INFO - 2019-11-04 09:52:15 --> Model Class Initialized
DEBUG - 2019-11-04 09:52:15 --> Template Class Initialized
INFO - 2019-11-04 09:52:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:52:15 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:52:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:52:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:52:15 --> Encryption Class Initialized
INFO - 2019-11-04 09:52:15 --> Controller Class Initialized
DEBUG - 2019-11-04 09:52:15 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 09:52:15 --> Model Class Initialized
INFO - 2019-11-04 09:52:15 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-04 09:52:15 --> Could not find the language line "Default_Homepage"
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/default_setting.php
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:52:15 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:52:15 --> Model Class Initialized
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:52:15 --> Model Class Initialized
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:52:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:52:15 --> Final output sent to browser
DEBUG - 2019-11-04 09:52:15 --> Total execution time: 0.7217
INFO - 2019-11-04 09:52:16 --> Config Class Initialized
INFO - 2019-11-04 09:52:16 --> Hooks Class Initialized
DEBUG - 2019-11-04 09:52:16 --> UTF-8 Support Enabled
INFO - 2019-11-04 09:52:16 --> Utf8 Class Initialized
INFO - 2019-11-04 09:52:16 --> URI Class Initialized
INFO - 2019-11-04 09:52:16 --> Router Class Initialized
INFO - 2019-11-04 09:52:16 --> Output Class Initialized
INFO - 2019-11-04 09:52:16 --> Security Class Initialized
DEBUG - 2019-11-04 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 09:52:16 --> CSRF cookie sent
INFO - 2019-11-04 09:52:16 --> Input Class Initialized
INFO - 2019-11-04 09:52:16 --> Language Class Initialized
INFO - 2019-11-04 09:52:16 --> Language Class Initialized
INFO - 2019-11-04 09:52:16 --> Config Class Initialized
INFO - 2019-11-04 09:52:16 --> Loader Class Initialized
INFO - 2019-11-04 09:52:16 --> Helper loaded: url_helper
INFO - 2019-11-04 09:52:16 --> Helper loaded: common_helper
INFO - 2019-11-04 09:52:16 --> Helper loaded: language_helper
INFO - 2019-11-04 09:52:16 --> Helper loaded: cookie_helper
INFO - 2019-11-04 09:52:16 --> Helper loaded: email_helper
INFO - 2019-11-04 09:52:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 09:52:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 09:52:16 --> Parser Class Initialized
INFO - 2019-11-04 09:52:16 --> User Agent Class Initialized
INFO - 2019-11-04 09:52:16 --> Model Class Initialized
INFO - 2019-11-04 09:52:16 --> Database Driver Class Initialized
INFO - 2019-11-04 09:52:16 --> Model Class Initialized
DEBUG - 2019-11-04 09:52:16 --> Template Class Initialized
INFO - 2019-11-04 09:52:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 09:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 09:52:16 --> Pagination Class Initialized
DEBUG - 2019-11-04 09:52:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 09:52:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 09:52:16 --> Encryption Class Initialized
INFO - 2019-11-04 09:52:16 --> Controller Class Initialized
DEBUG - 2019-11-04 09:52:16 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 09:52:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 09:52:16 --> Model Class Initialized
INFO - 2019-11-04 09:52:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 09:52:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-04 09:52:17 --> Could not find the language line "auto_currency_converter"
ERROR - 2019-11-04 09:52:17 --> Could not find the language line "currency_rate"
ERROR - 2019-11-04 09:52:17 --> Could not find the language line "applying_when_you_fetch_sync_all_services_from_smm_providers"
ERROR - 2019-11-04 09:52:17 --> Could not find the language line "1_original_currency"
ERROR - 2019-11-04 09:52:17 --> Could not find the language line "new_currency"
ERROR - 2019-11-04 09:52:17 --> Could not find the language line "if_you_dont_want_to_change_currency_rate_then_leave_this_currency_rate_field_to_1"
DEBUG - 2019-11-04 09:52:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/currency.php
DEBUG - 2019-11-04 09:52:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 09:52:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 09:52:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 09:52:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 09:52:17 --> Model Class Initialized
DEBUG - 2019-11-04 09:52:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 09:52:17 --> Model Class Initialized
DEBUG - 2019-11-04 09:52:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 09:52:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 09:52:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 09:52:17 --> Final output sent to browser
DEBUG - 2019-11-04 09:52:17 --> Total execution time: 0.8586
INFO - 2019-11-04 10:12:18 --> Config Class Initialized
INFO - 2019-11-04 10:12:18 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:12:18 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:12:18 --> Utf8 Class Initialized
INFO - 2019-11-04 10:12:18 --> URI Class Initialized
INFO - 2019-11-04 10:12:18 --> Router Class Initialized
INFO - 2019-11-04 10:12:18 --> Output Class Initialized
INFO - 2019-11-04 10:12:18 --> Security Class Initialized
DEBUG - 2019-11-04 10:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:12:18 --> CSRF cookie sent
INFO - 2019-11-04 10:12:18 --> Input Class Initialized
INFO - 2019-11-04 10:12:18 --> Language Class Initialized
INFO - 2019-11-04 10:12:18 --> Language Class Initialized
INFO - 2019-11-04 10:12:18 --> Config Class Initialized
INFO - 2019-11-04 10:12:18 --> Loader Class Initialized
INFO - 2019-11-04 10:12:18 --> Helper loaded: url_helper
INFO - 2019-11-04 10:12:18 --> Helper loaded: common_helper
INFO - 2019-11-04 10:12:18 --> Helper loaded: language_helper
INFO - 2019-11-04 10:12:18 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:12:18 --> Helper loaded: email_helper
INFO - 2019-11-04 10:12:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:12:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:12:18 --> Parser Class Initialized
INFO - 2019-11-04 10:12:18 --> User Agent Class Initialized
INFO - 2019-11-04 10:12:18 --> Model Class Initialized
INFO - 2019-11-04 10:12:18 --> Database Driver Class Initialized
INFO - 2019-11-04 10:12:18 --> Model Class Initialized
DEBUG - 2019-11-04 10:12:18 --> Template Class Initialized
INFO - 2019-11-04 10:12:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:12:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:12:18 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:12:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:12:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:12:18 --> Encryption Class Initialized
INFO - 2019-11-04 10:12:18 --> Controller Class Initialized
DEBUG - 2019-11-04 10:12:18 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:12:18 --> Model Class Initialized
INFO - 2019-11-04 10:12:18 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:12:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:12:18 --> Model Class Initialized
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:12:18 --> Model Class Initialized
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:12:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:12:18 --> Final output sent to browser
DEBUG - 2019-11-04 10:12:18 --> Total execution time: 0.7163
INFO - 2019-11-04 10:12:44 --> Config Class Initialized
INFO - 2019-11-04 10:12:44 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:12:44 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:12:44 --> Utf8 Class Initialized
INFO - 2019-11-04 10:12:44 --> URI Class Initialized
INFO - 2019-11-04 10:12:44 --> Router Class Initialized
INFO - 2019-11-04 10:12:44 --> Output Class Initialized
INFO - 2019-11-04 10:12:44 --> Security Class Initialized
DEBUG - 2019-11-04 10:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:12:44 --> CSRF cookie sent
INFO - 2019-11-04 10:12:44 --> Input Class Initialized
INFO - 2019-11-04 10:12:44 --> Language Class Initialized
INFO - 2019-11-04 10:12:44 --> Language Class Initialized
INFO - 2019-11-04 10:12:44 --> Config Class Initialized
INFO - 2019-11-04 10:12:44 --> Loader Class Initialized
INFO - 2019-11-04 10:12:44 --> Helper loaded: url_helper
INFO - 2019-11-04 10:12:44 --> Helper loaded: common_helper
INFO - 2019-11-04 10:12:44 --> Helper loaded: language_helper
INFO - 2019-11-04 10:12:44 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:12:44 --> Helper loaded: email_helper
INFO - 2019-11-04 10:12:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:12:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:12:44 --> Parser Class Initialized
INFO - 2019-11-04 10:12:44 --> User Agent Class Initialized
INFO - 2019-11-04 10:12:44 --> Model Class Initialized
INFO - 2019-11-04 10:12:44 --> Database Driver Class Initialized
INFO - 2019-11-04 10:12:44 --> Model Class Initialized
DEBUG - 2019-11-04 10:12:44 --> Template Class Initialized
INFO - 2019-11-04 10:12:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:12:44 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:12:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:12:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:12:44 --> Encryption Class Initialized
INFO - 2019-11-04 10:12:44 --> Controller Class Initialized
DEBUG - 2019-11-04 10:12:44 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:12:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:12:44 --> Model Class Initialized
INFO - 2019-11-04 10:12:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:12:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 10:12:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-04 10:12:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 10:12:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:12:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:12:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:12:44 --> Model Class Initialized
DEBUG - 2019-11-04 10:12:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:12:44 --> Model Class Initialized
DEBUG - 2019-11-04 10:12:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:12:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:12:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:12:45 --> Final output sent to browser
DEBUG - 2019-11-04 10:12:45 --> Total execution time: 0.7868
INFO - 2019-11-04 10:17:32 --> Config Class Initialized
INFO - 2019-11-04 10:17:32 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:17:32 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:17:32 --> Utf8 Class Initialized
INFO - 2019-11-04 10:17:32 --> URI Class Initialized
INFO - 2019-11-04 10:17:32 --> Router Class Initialized
INFO - 2019-11-04 10:17:32 --> Output Class Initialized
INFO - 2019-11-04 10:17:32 --> Security Class Initialized
DEBUG - 2019-11-04 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:17:32 --> CSRF cookie sent
INFO - 2019-11-04 10:17:32 --> CSRF token verified
INFO - 2019-11-04 10:17:32 --> Input Class Initialized
INFO - 2019-11-04 10:17:32 --> Language Class Initialized
INFO - 2019-11-04 10:17:32 --> Language Class Initialized
INFO - 2019-11-04 10:17:32 --> Config Class Initialized
INFO - 2019-11-04 10:17:32 --> Loader Class Initialized
INFO - 2019-11-04 10:17:32 --> Helper loaded: url_helper
INFO - 2019-11-04 10:17:32 --> Helper loaded: common_helper
INFO - 2019-11-04 10:17:32 --> Helper loaded: language_helper
INFO - 2019-11-04 10:17:32 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:17:32 --> Helper loaded: email_helper
INFO - 2019-11-04 10:17:32 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:17:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:17:32 --> Parser Class Initialized
INFO - 2019-11-04 10:17:32 --> User Agent Class Initialized
INFO - 2019-11-04 10:17:32 --> Model Class Initialized
INFO - 2019-11-04 10:17:32 --> Database Driver Class Initialized
INFO - 2019-11-04 10:17:32 --> Model Class Initialized
DEBUG - 2019-11-04 10:17:32 --> Template Class Initialized
INFO - 2019-11-04 10:17:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:17:33 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:17:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:17:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:17:33 --> Encryption Class Initialized
INFO - 2019-11-04 10:17:33 --> Controller Class Initialized
DEBUG - 2019-11-04 10:17:33 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:17:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:17:33 --> Model Class Initialized
INFO - 2019-11-04 10:17:37 --> Config Class Initialized
INFO - 2019-11-04 10:17:37 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:17:37 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:17:37 --> Utf8 Class Initialized
INFO - 2019-11-04 10:17:37 --> URI Class Initialized
INFO - 2019-11-04 10:17:37 --> Router Class Initialized
INFO - 2019-11-04 10:17:37 --> Output Class Initialized
INFO - 2019-11-04 10:17:37 --> Security Class Initialized
DEBUG - 2019-11-04 10:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:17:37 --> CSRF cookie sent
INFO - 2019-11-04 10:17:37 --> Input Class Initialized
INFO - 2019-11-04 10:17:37 --> Language Class Initialized
INFO - 2019-11-04 10:17:37 --> Language Class Initialized
INFO - 2019-11-04 10:17:37 --> Config Class Initialized
INFO - 2019-11-04 10:17:37 --> Loader Class Initialized
INFO - 2019-11-04 10:17:37 --> Helper loaded: url_helper
INFO - 2019-11-04 10:17:37 --> Helper loaded: common_helper
INFO - 2019-11-04 10:17:37 --> Helper loaded: language_helper
INFO - 2019-11-04 10:17:37 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:17:38 --> Helper loaded: email_helper
INFO - 2019-11-04 10:17:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:17:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:17:38 --> Parser Class Initialized
INFO - 2019-11-04 10:17:38 --> User Agent Class Initialized
INFO - 2019-11-04 10:17:38 --> Model Class Initialized
INFO - 2019-11-04 10:17:38 --> Database Driver Class Initialized
INFO - 2019-11-04 10:17:38 --> Model Class Initialized
DEBUG - 2019-11-04 10:17:38 --> Template Class Initialized
INFO - 2019-11-04 10:17:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:17:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:17:38 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:17:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:17:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:17:38 --> Encryption Class Initialized
INFO - 2019-11-04 10:17:38 --> Controller Class Initialized
DEBUG - 2019-11-04 10:17:38 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:17:38 --> Model Class Initialized
INFO - 2019-11-04 10:17:38 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:17:38 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:17:38 --> Model Class Initialized
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:17:38 --> Model Class Initialized
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:17:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:17:38 --> Final output sent to browser
DEBUG - 2019-11-04 10:17:38 --> Total execution time: 0.9572
INFO - 2019-11-04 10:20:11 --> Config Class Initialized
INFO - 2019-11-04 10:20:11 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:20:11 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:20:11 --> Utf8 Class Initialized
INFO - 2019-11-04 10:20:11 --> URI Class Initialized
INFO - 2019-11-04 10:20:11 --> Router Class Initialized
INFO - 2019-11-04 10:20:11 --> Output Class Initialized
INFO - 2019-11-04 10:20:11 --> Security Class Initialized
DEBUG - 2019-11-04 10:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:20:11 --> CSRF cookie sent
INFO - 2019-11-04 10:20:11 --> Input Class Initialized
INFO - 2019-11-04 10:20:11 --> Language Class Initialized
INFO - 2019-11-04 10:20:11 --> Language Class Initialized
INFO - 2019-11-04 10:20:11 --> Config Class Initialized
INFO - 2019-11-04 10:20:11 --> Loader Class Initialized
INFO - 2019-11-04 10:20:11 --> Helper loaded: url_helper
INFO - 2019-11-04 10:20:11 --> Helper loaded: common_helper
INFO - 2019-11-04 10:20:11 --> Helper loaded: language_helper
INFO - 2019-11-04 10:20:11 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:20:11 --> Helper loaded: email_helper
INFO - 2019-11-04 10:20:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:20:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:20:11 --> Parser Class Initialized
INFO - 2019-11-04 10:20:11 --> User Agent Class Initialized
INFO - 2019-11-04 10:20:11 --> Model Class Initialized
INFO - 2019-11-04 10:20:11 --> Database Driver Class Initialized
INFO - 2019-11-04 10:20:11 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:11 --> Template Class Initialized
INFO - 2019-11-04 10:20:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:20:11 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:20:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:20:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:20:12 --> Encryption Class Initialized
INFO - 2019-11-04 10:20:12 --> Controller Class Initialized
DEBUG - 2019-11-04 10:20:12 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:20:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:20:12 --> Model Class Initialized
INFO - 2019-11-04 10:20:12 --> Config Class Initialized
INFO - 2019-11-04 10:20:12 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:20:12 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:20:12 --> Utf8 Class Initialized
INFO - 2019-11-04 10:20:12 --> URI Class Initialized
DEBUG - 2019-11-04 10:20:12 --> No URI present. Default controller set.
INFO - 2019-11-04 10:20:12 --> Router Class Initialized
INFO - 2019-11-04 10:20:12 --> Output Class Initialized
INFO - 2019-11-04 10:20:12 --> Security Class Initialized
DEBUG - 2019-11-04 10:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:20:12 --> CSRF cookie sent
INFO - 2019-11-04 10:20:12 --> Input Class Initialized
INFO - 2019-11-04 10:20:12 --> Language Class Initialized
INFO - 2019-11-04 10:20:12 --> Language Class Initialized
INFO - 2019-11-04 10:20:12 --> Config Class Initialized
INFO - 2019-11-04 10:20:12 --> Loader Class Initialized
INFO - 2019-11-04 10:20:12 --> Helper loaded: url_helper
INFO - 2019-11-04 10:20:12 --> Helper loaded: common_helper
INFO - 2019-11-04 10:20:12 --> Helper loaded: language_helper
INFO - 2019-11-04 10:20:12 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:20:12 --> Helper loaded: email_helper
INFO - 2019-11-04 10:20:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:20:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:20:12 --> Parser Class Initialized
INFO - 2019-11-04 10:20:12 --> User Agent Class Initialized
INFO - 2019-11-04 10:20:12 --> Model Class Initialized
INFO - 2019-11-04 10:20:12 --> Database Driver Class Initialized
INFO - 2019-11-04 10:20:12 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:12 --> Template Class Initialized
INFO - 2019-11-04 10:20:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:20:12 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:20:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:20:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:20:12 --> Encryption Class Initialized
DEBUG - 2019-11-04 10:20:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-04 10:20:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-04 10:20:12 --> Controller Class Initialized
DEBUG - 2019-11-04 10:20:12 --> pergo MX_Controller Initialized
DEBUG - 2019-11-04 10:20:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-04 10:20:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-04 10:20:12 --> Model Class Initialized
INFO - 2019-11-04 10:20:12 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:20:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-04 10:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-04 10:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-04 10:20:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-04 10:20:13 --> Final output sent to browser
DEBUG - 2019-11-04 10:20:13 --> Total execution time: 1.0837
INFO - 2019-11-04 10:20:18 --> Config Class Initialized
INFO - 2019-11-04 10:20:18 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:20:18 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:20:18 --> Utf8 Class Initialized
INFO - 2019-11-04 10:20:18 --> URI Class Initialized
INFO - 2019-11-04 10:20:18 --> Router Class Initialized
INFO - 2019-11-04 10:20:18 --> Output Class Initialized
INFO - 2019-11-04 10:20:18 --> Security Class Initialized
DEBUG - 2019-11-04 10:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:20:19 --> CSRF cookie sent
INFO - 2019-11-04 10:20:19 --> Input Class Initialized
INFO - 2019-11-04 10:20:19 --> Language Class Initialized
INFO - 2019-11-04 10:20:19 --> Language Class Initialized
INFO - 2019-11-04 10:20:19 --> Config Class Initialized
INFO - 2019-11-04 10:20:19 --> Loader Class Initialized
INFO - 2019-11-04 10:20:19 --> Helper loaded: url_helper
INFO - 2019-11-04 10:20:19 --> Helper loaded: common_helper
INFO - 2019-11-04 10:20:19 --> Helper loaded: language_helper
INFO - 2019-11-04 10:20:19 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:20:19 --> Helper loaded: email_helper
INFO - 2019-11-04 10:20:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:20:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:20:19 --> Parser Class Initialized
INFO - 2019-11-04 10:20:19 --> User Agent Class Initialized
INFO - 2019-11-04 10:20:19 --> Model Class Initialized
INFO - 2019-11-04 10:20:19 --> Database Driver Class Initialized
INFO - 2019-11-04 10:20:19 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:19 --> Template Class Initialized
INFO - 2019-11-04 10:20:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:20:19 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:20:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:20:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:20:19 --> Encryption Class Initialized
INFO - 2019-11-04 10:20:19 --> Controller Class Initialized
DEBUG - 2019-11-04 10:20:19 --> package MX_Controller Initialized
DEBUG - 2019-11-04 10:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-04 10:20:19 --> Model Class Initialized
INFO - 2019-11-04 10:20:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:20:19 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:20:19 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:20:19 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-04 10:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-04 10:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-04 10:20:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-04 10:20:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-04 10:20:20 --> Final output sent to browser
DEBUG - 2019-11-04 10:20:20 --> Total execution time: 1.1893
INFO - 2019-11-04 10:20:22 --> Config Class Initialized
INFO - 2019-11-04 10:20:22 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:20:22 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:20:22 --> Utf8 Class Initialized
INFO - 2019-11-04 10:20:22 --> URI Class Initialized
INFO - 2019-11-04 10:20:22 --> Router Class Initialized
INFO - 2019-11-04 10:20:22 --> Output Class Initialized
INFO - 2019-11-04 10:20:22 --> Security Class Initialized
DEBUG - 2019-11-04 10:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:20:22 --> CSRF cookie sent
INFO - 2019-11-04 10:20:22 --> CSRF token verified
INFO - 2019-11-04 10:20:22 --> Input Class Initialized
INFO - 2019-11-04 10:20:22 --> Language Class Initialized
INFO - 2019-11-04 10:20:22 --> Language Class Initialized
INFO - 2019-11-04 10:20:22 --> Config Class Initialized
INFO - 2019-11-04 10:20:22 --> Loader Class Initialized
INFO - 2019-11-04 10:20:22 --> Helper loaded: url_helper
INFO - 2019-11-04 10:20:22 --> Helper loaded: common_helper
INFO - 2019-11-04 10:20:22 --> Helper loaded: language_helper
INFO - 2019-11-04 10:20:22 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:20:22 --> Helper loaded: email_helper
INFO - 2019-11-04 10:20:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:20:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:20:23 --> Parser Class Initialized
INFO - 2019-11-04 10:20:23 --> User Agent Class Initialized
INFO - 2019-11-04 10:20:23 --> Model Class Initialized
INFO - 2019-11-04 10:20:23 --> Database Driver Class Initialized
INFO - 2019-11-04 10:20:23 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:23 --> Template Class Initialized
INFO - 2019-11-04 10:20:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:20:23 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:20:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:20:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:20:23 --> Encryption Class Initialized
INFO - 2019-11-04 10:20:23 --> Controller Class Initialized
DEBUG - 2019-11-04 10:20:23 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:20:23 --> Model Class Initialized
INFO - 2019-11-04 10:20:23 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 10:20:23 --> Could not find the language line "dotpay"
DEBUG - 2019-11-04 10:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-04 10:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:20:23 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:20:23 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:20:23 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-04 10:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-04 10:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-04 10:20:23 --> Final output sent to browser
DEBUG - 2019-11-04 10:20:23 --> Total execution time: 0.7704
INFO - 2019-11-04 10:20:32 --> Config Class Initialized
INFO - 2019-11-04 10:20:32 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:20:32 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:20:32 --> Utf8 Class Initialized
INFO - 2019-11-04 10:20:32 --> URI Class Initialized
INFO - 2019-11-04 10:20:32 --> Router Class Initialized
INFO - 2019-11-04 10:20:32 --> Output Class Initialized
INFO - 2019-11-04 10:20:32 --> Security Class Initialized
DEBUG - 2019-11-04 10:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:20:32 --> CSRF cookie sent
INFO - 2019-11-04 10:20:32 --> CSRF token verified
INFO - 2019-11-04 10:20:32 --> Input Class Initialized
INFO - 2019-11-04 10:20:32 --> Language Class Initialized
INFO - 2019-11-04 10:20:32 --> Language Class Initialized
INFO - 2019-11-04 10:20:32 --> Config Class Initialized
INFO - 2019-11-04 10:20:32 --> Loader Class Initialized
INFO - 2019-11-04 10:20:32 --> Helper loaded: url_helper
INFO - 2019-11-04 10:20:32 --> Helper loaded: common_helper
INFO - 2019-11-04 10:20:32 --> Helper loaded: language_helper
INFO - 2019-11-04 10:20:32 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:20:32 --> Helper loaded: email_helper
INFO - 2019-11-04 10:20:32 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:20:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:20:32 --> Parser Class Initialized
INFO - 2019-11-04 10:20:32 --> User Agent Class Initialized
INFO - 2019-11-04 10:20:32 --> Model Class Initialized
INFO - 2019-11-04 10:20:32 --> Database Driver Class Initialized
INFO - 2019-11-04 10:20:32 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:32 --> Template Class Initialized
INFO - 2019-11-04 10:20:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:20:32 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:20:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:20:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:20:33 --> Encryption Class Initialized
INFO - 2019-11-04 10:20:33 --> Controller Class Initialized
DEBUG - 2019-11-04 10:20:33 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:20:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:20:33 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-04 10:20:33 --> Final output sent to browser
DEBUG - 2019-11-04 10:20:33 --> Total execution time: 0.5576
INFO - 2019-11-04 10:20:33 --> Config Class Initialized
INFO - 2019-11-04 10:20:33 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:20:33 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:20:33 --> Utf8 Class Initialized
INFO - 2019-11-04 10:20:33 --> URI Class Initialized
INFO - 2019-11-04 10:20:33 --> Router Class Initialized
INFO - 2019-11-04 10:20:33 --> Output Class Initialized
INFO - 2019-11-04 10:20:33 --> Security Class Initialized
DEBUG - 2019-11-04 10:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:20:33 --> Input Class Initialized
INFO - 2019-11-04 10:20:33 --> Language Class Initialized
INFO - 2019-11-04 10:20:33 --> Language Class Initialized
INFO - 2019-11-04 10:20:33 --> Config Class Initialized
INFO - 2019-11-04 10:20:33 --> Loader Class Initialized
INFO - 2019-11-04 10:20:33 --> Helper loaded: url_helper
INFO - 2019-11-04 10:20:33 --> Helper loaded: common_helper
INFO - 2019-11-04 10:20:33 --> Helper loaded: language_helper
INFO - 2019-11-04 10:20:33 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:20:33 --> Helper loaded: email_helper
INFO - 2019-11-04 10:20:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:20:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:20:33 --> Parser Class Initialized
INFO - 2019-11-04 10:20:33 --> User Agent Class Initialized
INFO - 2019-11-04 10:20:33 --> Model Class Initialized
INFO - 2019-11-04 10:20:33 --> Database Driver Class Initialized
INFO - 2019-11-04 10:20:33 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:33 --> Template Class Initialized
INFO - 2019-11-04 10:20:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:20:33 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:20:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:20:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:20:33 --> Encryption Class Initialized
INFO - 2019-11-04 10:20:33 --> Controller Class Initialized
DEBUG - 2019-11-04 10:20:33 --> dotpay MX_Controller Initialized
INFO - 2019-11-04 10:20:33 --> Model Class Initialized
DEBUG - 2019-11-04 10:20:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-04 10:20:33 --> Final output sent to browser
DEBUG - 2019-11-04 10:20:33 --> Total execution time: 0.4965
INFO - 2019-11-04 10:22:05 --> Config Class Initialized
INFO - 2019-11-04 10:22:05 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:22:05 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:22:05 --> Utf8 Class Initialized
INFO - 2019-11-04 10:22:05 --> URI Class Initialized
INFO - 2019-11-04 10:22:05 --> Router Class Initialized
INFO - 2019-11-04 10:22:05 --> Output Class Initialized
INFO - 2019-11-04 10:22:05 --> Security Class Initialized
DEBUG - 2019-11-04 10:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:22:05 --> CSRF cookie sent
INFO - 2019-11-04 10:22:05 --> Input Class Initialized
INFO - 2019-11-04 10:22:05 --> Language Class Initialized
INFO - 2019-11-04 10:22:05 --> Language Class Initialized
INFO - 2019-11-04 10:22:05 --> Config Class Initialized
INFO - 2019-11-04 10:22:05 --> Loader Class Initialized
INFO - 2019-11-04 10:22:06 --> Helper loaded: url_helper
INFO - 2019-11-04 10:22:06 --> Helper loaded: common_helper
INFO - 2019-11-04 10:22:06 --> Helper loaded: language_helper
INFO - 2019-11-04 10:22:06 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:22:06 --> Helper loaded: email_helper
INFO - 2019-11-04 10:22:06 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:22:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:22:06 --> Parser Class Initialized
INFO - 2019-11-04 10:22:06 --> User Agent Class Initialized
INFO - 2019-11-04 10:22:06 --> Model Class Initialized
INFO - 2019-11-04 10:22:06 --> Database Driver Class Initialized
INFO - 2019-11-04 10:22:06 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:06 --> Template Class Initialized
INFO - 2019-11-04 10:22:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:22:06 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:22:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:22:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:22:06 --> Encryption Class Initialized
INFO - 2019-11-04 10:22:06 --> Controller Class Initialized
DEBUG - 2019-11-04 10:22:06 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:22:06 --> Model Class Initialized
INFO - 2019-11-04 10:22:06 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:22:06 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:22:06 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:22:06 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:22:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:22:06 --> Final output sent to browser
DEBUG - 2019-11-04 10:22:06 --> Total execution time: 0.8595
INFO - 2019-11-04 10:22:10 --> Config Class Initialized
INFO - 2019-11-04 10:22:10 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:22:10 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:22:10 --> Utf8 Class Initialized
INFO - 2019-11-04 10:22:10 --> URI Class Initialized
INFO - 2019-11-04 10:22:10 --> Router Class Initialized
INFO - 2019-11-04 10:22:10 --> Output Class Initialized
INFO - 2019-11-04 10:22:10 --> Security Class Initialized
DEBUG - 2019-11-04 10:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:22:10 --> CSRF cookie sent
INFO - 2019-11-04 10:22:10 --> CSRF token verified
INFO - 2019-11-04 10:22:10 --> Input Class Initialized
INFO - 2019-11-04 10:22:10 --> Language Class Initialized
INFO - 2019-11-04 10:22:10 --> Language Class Initialized
INFO - 2019-11-04 10:22:10 --> Config Class Initialized
INFO - 2019-11-04 10:22:10 --> Loader Class Initialized
INFO - 2019-11-04 10:22:10 --> Helper loaded: url_helper
INFO - 2019-11-04 10:22:10 --> Helper loaded: common_helper
INFO - 2019-11-04 10:22:10 --> Helper loaded: language_helper
INFO - 2019-11-04 10:22:10 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:22:10 --> Helper loaded: email_helper
INFO - 2019-11-04 10:22:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:22:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:22:10 --> Parser Class Initialized
INFO - 2019-11-04 10:22:10 --> User Agent Class Initialized
INFO - 2019-11-04 10:22:10 --> Model Class Initialized
INFO - 2019-11-04 10:22:10 --> Database Driver Class Initialized
INFO - 2019-11-04 10:22:10 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:10 --> Template Class Initialized
INFO - 2019-11-04 10:22:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:22:10 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:22:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:22:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:22:10 --> Encryption Class Initialized
INFO - 2019-11-04 10:22:10 --> Controller Class Initialized
DEBUG - 2019-11-04 10:22:10 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:22:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:22:10 --> Model Class Initialized
INFO - 2019-11-04 10:22:15 --> Config Class Initialized
INFO - 2019-11-04 10:22:15 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:22:15 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:22:15 --> Utf8 Class Initialized
INFO - 2019-11-04 10:22:15 --> URI Class Initialized
INFO - 2019-11-04 10:22:15 --> Router Class Initialized
INFO - 2019-11-04 10:22:15 --> Output Class Initialized
INFO - 2019-11-04 10:22:15 --> Security Class Initialized
DEBUG - 2019-11-04 10:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:22:15 --> CSRF cookie sent
INFO - 2019-11-04 10:22:15 --> Input Class Initialized
INFO - 2019-11-04 10:22:15 --> Language Class Initialized
INFO - 2019-11-04 10:22:15 --> Language Class Initialized
INFO - 2019-11-04 10:22:15 --> Config Class Initialized
INFO - 2019-11-04 10:22:15 --> Loader Class Initialized
INFO - 2019-11-04 10:22:15 --> Helper loaded: url_helper
INFO - 2019-11-04 10:22:15 --> Helper loaded: common_helper
INFO - 2019-11-04 10:22:15 --> Helper loaded: language_helper
INFO - 2019-11-04 10:22:15 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:22:15 --> Helper loaded: email_helper
INFO - 2019-11-04 10:22:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:22:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:22:15 --> Parser Class Initialized
INFO - 2019-11-04 10:22:15 --> User Agent Class Initialized
INFO - 2019-11-04 10:22:15 --> Model Class Initialized
INFO - 2019-11-04 10:22:15 --> Database Driver Class Initialized
INFO - 2019-11-04 10:22:15 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:15 --> Template Class Initialized
INFO - 2019-11-04 10:22:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:22:15 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:22:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:22:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:22:15 --> Encryption Class Initialized
INFO - 2019-11-04 10:22:15 --> Controller Class Initialized
DEBUG - 2019-11-04 10:22:15 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:22:15 --> Model Class Initialized
INFO - 2019-11-04 10:22:15 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 10:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-04 10:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 10:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:22:15 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:22:15 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:22:15 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:22:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:22:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:22:16 --> Final output sent to browser
DEBUG - 2019-11-04 10:22:16 --> Total execution time: 0.8068
INFO - 2019-11-04 10:22:21 --> Config Class Initialized
INFO - 2019-11-04 10:22:21 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:22:21 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:22:21 --> Utf8 Class Initialized
INFO - 2019-11-04 10:22:21 --> URI Class Initialized
INFO - 2019-11-04 10:22:21 --> Router Class Initialized
INFO - 2019-11-04 10:22:21 --> Output Class Initialized
INFO - 2019-11-04 10:22:21 --> Security Class Initialized
DEBUG - 2019-11-04 10:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:22:21 --> CSRF cookie sent
INFO - 2019-11-04 10:22:21 --> Input Class Initialized
INFO - 2019-11-04 10:22:21 --> Language Class Initialized
INFO - 2019-11-04 10:22:21 --> Language Class Initialized
INFO - 2019-11-04 10:22:21 --> Config Class Initialized
INFO - 2019-11-04 10:22:21 --> Loader Class Initialized
INFO - 2019-11-04 10:22:21 --> Helper loaded: url_helper
INFO - 2019-11-04 10:22:21 --> Helper loaded: common_helper
INFO - 2019-11-04 10:22:21 --> Helper loaded: language_helper
INFO - 2019-11-04 10:22:21 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:22:21 --> Helper loaded: email_helper
INFO - 2019-11-04 10:22:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:22:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:22:21 --> Parser Class Initialized
INFO - 2019-11-04 10:22:21 --> User Agent Class Initialized
INFO - 2019-11-04 10:22:21 --> Model Class Initialized
INFO - 2019-11-04 10:22:21 --> Database Driver Class Initialized
INFO - 2019-11-04 10:22:21 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:21 --> Template Class Initialized
INFO - 2019-11-04 10:22:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:22:21 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:22:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:22:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:22:21 --> Encryption Class Initialized
INFO - 2019-11-04 10:22:21 --> Controller Class Initialized
DEBUG - 2019-11-04 10:22:21 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:22:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:22:21 --> Model Class Initialized
INFO - 2019-11-04 10:22:21 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:22:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 10:22:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-04 10:22:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 10:22:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:22:21 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:22:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:22:21 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:22:21 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:22:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:22:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:22:22 --> Final output sent to browser
DEBUG - 2019-11-04 10:22:22 --> Total execution time: 0.8354
INFO - 2019-11-04 10:22:26 --> Config Class Initialized
INFO - 2019-11-04 10:22:26 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:22:26 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:22:26 --> Utf8 Class Initialized
INFO - 2019-11-04 10:22:26 --> URI Class Initialized
INFO - 2019-11-04 10:22:26 --> Router Class Initialized
INFO - 2019-11-04 10:22:26 --> Output Class Initialized
INFO - 2019-11-04 10:22:26 --> Security Class Initialized
DEBUG - 2019-11-04 10:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:22:26 --> CSRF cookie sent
INFO - 2019-11-04 10:22:26 --> CSRF token verified
INFO - 2019-11-04 10:22:26 --> Input Class Initialized
INFO - 2019-11-04 10:22:26 --> Language Class Initialized
INFO - 2019-11-04 10:22:26 --> Language Class Initialized
INFO - 2019-11-04 10:22:26 --> Config Class Initialized
INFO - 2019-11-04 10:22:26 --> Loader Class Initialized
INFO - 2019-11-04 10:22:26 --> Helper loaded: url_helper
INFO - 2019-11-04 10:22:26 --> Helper loaded: common_helper
INFO - 2019-11-04 10:22:26 --> Helper loaded: language_helper
INFO - 2019-11-04 10:22:26 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:22:26 --> Helper loaded: email_helper
INFO - 2019-11-04 10:22:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:22:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:22:26 --> Parser Class Initialized
INFO - 2019-11-04 10:22:26 --> User Agent Class Initialized
INFO - 2019-11-04 10:22:26 --> Model Class Initialized
INFO - 2019-11-04 10:22:26 --> Database Driver Class Initialized
INFO - 2019-11-04 10:22:26 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:26 --> Template Class Initialized
INFO - 2019-11-04 10:22:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:22:26 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:22:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:22:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:22:26 --> Encryption Class Initialized
INFO - 2019-11-04 10:22:26 --> Controller Class Initialized
DEBUG - 2019-11-04 10:22:26 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:22:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:22:26 --> Model Class Initialized
INFO - 2019-11-04 10:22:31 --> Config Class Initialized
INFO - 2019-11-04 10:22:31 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:22:31 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:22:31 --> Utf8 Class Initialized
INFO - 2019-11-04 10:22:31 --> URI Class Initialized
INFO - 2019-11-04 10:22:31 --> Router Class Initialized
INFO - 2019-11-04 10:22:31 --> Output Class Initialized
INFO - 2019-11-04 10:22:31 --> Security Class Initialized
DEBUG - 2019-11-04 10:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:22:31 --> CSRF cookie sent
INFO - 2019-11-04 10:22:31 --> Input Class Initialized
INFO - 2019-11-04 10:22:31 --> Language Class Initialized
INFO - 2019-11-04 10:22:31 --> Language Class Initialized
INFO - 2019-11-04 10:22:31 --> Config Class Initialized
INFO - 2019-11-04 10:22:31 --> Loader Class Initialized
INFO - 2019-11-04 10:22:31 --> Helper loaded: url_helper
INFO - 2019-11-04 10:22:31 --> Helper loaded: common_helper
INFO - 2019-11-04 10:22:31 --> Helper loaded: language_helper
INFO - 2019-11-04 10:22:31 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:22:31 --> Helper loaded: email_helper
INFO - 2019-11-04 10:22:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:22:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:22:31 --> Parser Class Initialized
INFO - 2019-11-04 10:22:31 --> User Agent Class Initialized
INFO - 2019-11-04 10:22:31 --> Model Class Initialized
INFO - 2019-11-04 10:22:31 --> Database Driver Class Initialized
INFO - 2019-11-04 10:22:31 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:31 --> Template Class Initialized
INFO - 2019-11-04 10:22:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:22:31 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:22:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:22:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:22:31 --> Encryption Class Initialized
INFO - 2019-11-04 10:22:31 --> Controller Class Initialized
DEBUG - 2019-11-04 10:22:31 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:22:32 --> Model Class Initialized
INFO - 2019-11-04 10:22:32 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:22:32 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:22:32 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:22:32 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:22:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:22:32 --> Final output sent to browser
DEBUG - 2019-11-04 10:22:32 --> Total execution time: 0.7774
INFO - 2019-11-04 10:22:46 --> Config Class Initialized
INFO - 2019-11-04 10:22:46 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:22:46 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:22:46 --> Utf8 Class Initialized
INFO - 2019-11-04 10:22:46 --> URI Class Initialized
INFO - 2019-11-04 10:22:46 --> Router Class Initialized
INFO - 2019-11-04 10:22:46 --> Output Class Initialized
INFO - 2019-11-04 10:22:46 --> Security Class Initialized
DEBUG - 2019-11-04 10:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:22:46 --> CSRF cookie sent
INFO - 2019-11-04 10:22:46 --> CSRF token verified
INFO - 2019-11-04 10:22:46 --> Input Class Initialized
INFO - 2019-11-04 10:22:46 --> Language Class Initialized
INFO - 2019-11-04 10:22:46 --> Language Class Initialized
INFO - 2019-11-04 10:22:46 --> Config Class Initialized
INFO - 2019-11-04 10:22:46 --> Loader Class Initialized
INFO - 2019-11-04 10:22:46 --> Helper loaded: url_helper
INFO - 2019-11-04 10:22:46 --> Helper loaded: common_helper
INFO - 2019-11-04 10:22:46 --> Helper loaded: language_helper
INFO - 2019-11-04 10:22:46 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:22:46 --> Helper loaded: email_helper
INFO - 2019-11-04 10:22:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:22:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:22:46 --> Parser Class Initialized
INFO - 2019-11-04 10:22:46 --> User Agent Class Initialized
INFO - 2019-11-04 10:22:46 --> Model Class Initialized
INFO - 2019-11-04 10:22:46 --> Database Driver Class Initialized
INFO - 2019-11-04 10:22:46 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:46 --> Template Class Initialized
INFO - 2019-11-04 10:22:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:22:46 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:22:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:22:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:22:46 --> Encryption Class Initialized
INFO - 2019-11-04 10:22:46 --> Controller Class Initialized
DEBUG - 2019-11-04 10:22:46 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:22:46 --> Model Class Initialized
INFO - 2019-11-04 10:22:46 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 10:22:46 --> Could not find the language line "dotpay"
DEBUG - 2019-11-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:22:46 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:22:46 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:22:46 --> Model Class Initialized
DEBUG - 2019-11-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-04 10:22:46 --> Final output sent to browser
DEBUG - 2019-11-04 10:22:46 --> Total execution time: 0.7424
INFO - 2019-11-04 10:32:41 --> Config Class Initialized
INFO - 2019-11-04 10:32:41 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:32:41 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:32:41 --> Utf8 Class Initialized
INFO - 2019-11-04 10:32:41 --> URI Class Initialized
INFO - 2019-11-04 10:32:41 --> Router Class Initialized
INFO - 2019-11-04 10:32:41 --> Output Class Initialized
INFO - 2019-11-04 10:32:41 --> Security Class Initialized
DEBUG - 2019-11-04 10:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:32:41 --> CSRF cookie sent
INFO - 2019-11-04 10:32:41 --> CSRF token verified
INFO - 2019-11-04 10:32:41 --> Input Class Initialized
INFO - 2019-11-04 10:32:41 --> Language Class Initialized
INFO - 2019-11-04 10:32:41 --> Language Class Initialized
INFO - 2019-11-04 10:32:41 --> Config Class Initialized
INFO - 2019-11-04 10:32:42 --> Loader Class Initialized
INFO - 2019-11-04 10:32:42 --> Helper loaded: url_helper
INFO - 2019-11-04 10:32:42 --> Helper loaded: common_helper
INFO - 2019-11-04 10:32:42 --> Helper loaded: language_helper
INFO - 2019-11-04 10:32:42 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:32:42 --> Helper loaded: email_helper
INFO - 2019-11-04 10:32:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:32:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:32:42 --> Parser Class Initialized
INFO - 2019-11-04 10:32:42 --> User Agent Class Initialized
INFO - 2019-11-04 10:32:42 --> Model Class Initialized
INFO - 2019-11-04 10:32:42 --> Database Driver Class Initialized
INFO - 2019-11-04 10:32:42 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:42 --> Template Class Initialized
INFO - 2019-11-04 10:32:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:32:42 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:32:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:32:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:32:42 --> Encryption Class Initialized
INFO - 2019-11-04 10:32:42 --> Controller Class Initialized
DEBUG - 2019-11-04 10:32:42 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:32:42 --> Model Class Initialized
INFO - 2019-11-04 10:32:42 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 10:32:42 --> Could not find the language line "dotpay"
DEBUG - 2019-11-04 10:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-04 10:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:32:42 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:32:42 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:32:42 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-04 10:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-04 10:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-04 10:32:42 --> Final output sent to browser
DEBUG - 2019-11-04 10:32:42 --> Total execution time: 0.7483
INFO - 2019-11-04 10:32:47 --> Config Class Initialized
INFO - 2019-11-04 10:32:47 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:32:47 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:32:47 --> Utf8 Class Initialized
INFO - 2019-11-04 10:32:47 --> URI Class Initialized
INFO - 2019-11-04 10:32:47 --> Router Class Initialized
INFO - 2019-11-04 10:32:47 --> Output Class Initialized
INFO - 2019-11-04 10:32:47 --> Security Class Initialized
DEBUG - 2019-11-04 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:32:47 --> CSRF cookie sent
INFO - 2019-11-04 10:32:47 --> CSRF token verified
INFO - 2019-11-04 10:32:47 --> Input Class Initialized
INFO - 2019-11-04 10:32:47 --> Language Class Initialized
INFO - 2019-11-04 10:32:47 --> Language Class Initialized
INFO - 2019-11-04 10:32:47 --> Config Class Initialized
INFO - 2019-11-04 10:32:47 --> Loader Class Initialized
INFO - 2019-11-04 10:32:47 --> Helper loaded: url_helper
INFO - 2019-11-04 10:32:47 --> Helper loaded: common_helper
INFO - 2019-11-04 10:32:47 --> Helper loaded: language_helper
INFO - 2019-11-04 10:32:47 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:32:47 --> Helper loaded: email_helper
INFO - 2019-11-04 10:32:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:32:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:32:47 --> Parser Class Initialized
INFO - 2019-11-04 10:32:47 --> User Agent Class Initialized
INFO - 2019-11-04 10:32:47 --> Model Class Initialized
INFO - 2019-11-04 10:32:47 --> Database Driver Class Initialized
INFO - 2019-11-04 10:32:47 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:47 --> Template Class Initialized
INFO - 2019-11-04 10:32:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:32:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:32:47 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:32:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:32:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:32:48 --> Encryption Class Initialized
INFO - 2019-11-04 10:32:48 --> Controller Class Initialized
DEBUG - 2019-11-04 10:32:48 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:32:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:32:48 --> Model Class Initialized
INFO - 2019-11-04 10:32:48 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 10:32:48 --> Could not find the language line "dotpay"
DEBUG - 2019-11-04 10:32:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-04 10:32:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:32:48 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:32:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:32:48 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:32:48 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-04 10:32:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-04 10:32:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-04 10:32:48 --> Final output sent to browser
DEBUG - 2019-11-04 10:32:48 --> Total execution time: 0.7900
INFO - 2019-11-04 10:32:56 --> Config Class Initialized
INFO - 2019-11-04 10:32:56 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:32:56 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:32:56 --> Utf8 Class Initialized
INFO - 2019-11-04 10:32:56 --> URI Class Initialized
INFO - 2019-11-04 10:32:56 --> Router Class Initialized
INFO - 2019-11-04 10:32:56 --> Output Class Initialized
INFO - 2019-11-04 10:32:56 --> Security Class Initialized
DEBUG - 2019-11-04 10:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:32:56 --> CSRF cookie sent
INFO - 2019-11-04 10:32:56 --> CSRF token verified
INFO - 2019-11-04 10:32:56 --> Input Class Initialized
INFO - 2019-11-04 10:32:56 --> Language Class Initialized
INFO - 2019-11-04 10:32:56 --> Language Class Initialized
INFO - 2019-11-04 10:32:56 --> Config Class Initialized
INFO - 2019-11-04 10:32:56 --> Loader Class Initialized
INFO - 2019-11-04 10:32:56 --> Helper loaded: url_helper
INFO - 2019-11-04 10:32:56 --> Helper loaded: common_helper
INFO - 2019-11-04 10:32:56 --> Helper loaded: language_helper
INFO - 2019-11-04 10:32:56 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:32:56 --> Helper loaded: email_helper
INFO - 2019-11-04 10:32:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:32:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:32:56 --> Parser Class Initialized
INFO - 2019-11-04 10:32:56 --> User Agent Class Initialized
INFO - 2019-11-04 10:32:56 --> Model Class Initialized
INFO - 2019-11-04 10:32:56 --> Database Driver Class Initialized
INFO - 2019-11-04 10:32:56 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:56 --> Template Class Initialized
INFO - 2019-11-04 10:32:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:32:56 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:32:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:32:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:32:56 --> Encryption Class Initialized
INFO - 2019-11-04 10:32:56 --> Controller Class Initialized
DEBUG - 2019-11-04 10:32:56 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:32:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:32:56 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-04 10:32:56 --> Final output sent to browser
DEBUG - 2019-11-04 10:32:56 --> Total execution time: 0.5892
INFO - 2019-11-04 10:32:56 --> Config Class Initialized
INFO - 2019-11-04 10:32:56 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:32:56 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:32:56 --> Utf8 Class Initialized
INFO - 2019-11-04 10:32:56 --> URI Class Initialized
INFO - 2019-11-04 10:32:56 --> Router Class Initialized
INFO - 2019-11-04 10:32:56 --> Output Class Initialized
INFO - 2019-11-04 10:32:56 --> Security Class Initialized
DEBUG - 2019-11-04 10:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:32:56 --> Input Class Initialized
INFO - 2019-11-04 10:32:56 --> Language Class Initialized
INFO - 2019-11-04 10:32:57 --> Language Class Initialized
INFO - 2019-11-04 10:32:57 --> Config Class Initialized
INFO - 2019-11-04 10:32:57 --> Loader Class Initialized
INFO - 2019-11-04 10:32:57 --> Helper loaded: url_helper
INFO - 2019-11-04 10:32:57 --> Helper loaded: common_helper
INFO - 2019-11-04 10:32:57 --> Helper loaded: language_helper
INFO - 2019-11-04 10:32:57 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:32:57 --> Helper loaded: email_helper
INFO - 2019-11-04 10:32:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:32:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:32:57 --> Parser Class Initialized
INFO - 2019-11-04 10:32:57 --> User Agent Class Initialized
INFO - 2019-11-04 10:32:57 --> Model Class Initialized
INFO - 2019-11-04 10:32:57 --> Database Driver Class Initialized
INFO - 2019-11-04 10:32:57 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:57 --> Template Class Initialized
INFO - 2019-11-04 10:32:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:32:57 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:32:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:32:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:32:57 --> Encryption Class Initialized
INFO - 2019-11-04 10:32:57 --> Controller Class Initialized
DEBUG - 2019-11-04 10:32:57 --> dotpay MX_Controller Initialized
INFO - 2019-11-04 10:32:57 --> Model Class Initialized
DEBUG - 2019-11-04 10:32:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-04 10:32:57 --> Final output sent to browser
DEBUG - 2019-11-04 10:32:57 --> Total execution time: 0.5329
INFO - 2019-11-04 10:33:42 --> Config Class Initialized
INFO - 2019-11-04 10:33:42 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:33:42 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:33:42 --> Utf8 Class Initialized
INFO - 2019-11-04 10:33:42 --> URI Class Initialized
INFO - 2019-11-04 10:33:42 --> Router Class Initialized
INFO - 2019-11-04 10:33:42 --> Output Class Initialized
INFO - 2019-11-04 10:33:42 --> Security Class Initialized
DEBUG - 2019-11-04 10:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:33:43 --> CSRF cookie sent
INFO - 2019-11-04 10:33:43 --> CSRF token verified
INFO - 2019-11-04 10:33:43 --> Input Class Initialized
INFO - 2019-11-04 10:33:43 --> Language Class Initialized
INFO - 2019-11-04 10:33:43 --> Language Class Initialized
INFO - 2019-11-04 10:33:43 --> Config Class Initialized
INFO - 2019-11-04 10:33:43 --> Loader Class Initialized
INFO - 2019-11-04 10:33:43 --> Helper loaded: url_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: common_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: language_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: email_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:33:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:33:43 --> Parser Class Initialized
INFO - 2019-11-04 10:33:43 --> User Agent Class Initialized
INFO - 2019-11-04 10:33:43 --> Model Class Initialized
INFO - 2019-11-04 10:33:43 --> Database Driver Class Initialized
INFO - 2019-11-04 10:33:43 --> Model Class Initialized
DEBUG - 2019-11-04 10:33:43 --> Template Class Initialized
INFO - 2019-11-04 10:33:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:33:43 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:33:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:33:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:33:43 --> Encryption Class Initialized
INFO - 2019-11-04 10:33:43 --> Controller Class Initialized
DEBUG - 2019-11-04 10:33:43 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:33:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:33:43 --> Model Class Initialized
DEBUG - 2019-11-04 10:33:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-04 10:33:43 --> Final output sent to browser
DEBUG - 2019-11-04 10:33:43 --> Total execution time: 0.5999
INFO - 2019-11-04 10:33:43 --> Config Class Initialized
INFO - 2019-11-04 10:33:43 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:33:43 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:33:43 --> Utf8 Class Initialized
INFO - 2019-11-04 10:33:43 --> URI Class Initialized
INFO - 2019-11-04 10:33:43 --> Router Class Initialized
INFO - 2019-11-04 10:33:43 --> Output Class Initialized
INFO - 2019-11-04 10:33:43 --> Security Class Initialized
DEBUG - 2019-11-04 10:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:33:43 --> Input Class Initialized
INFO - 2019-11-04 10:33:43 --> Language Class Initialized
INFO - 2019-11-04 10:33:43 --> Language Class Initialized
INFO - 2019-11-04 10:33:43 --> Config Class Initialized
INFO - 2019-11-04 10:33:43 --> Loader Class Initialized
INFO - 2019-11-04 10:33:43 --> Helper loaded: url_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: common_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: language_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: email_helper
INFO - 2019-11-04 10:33:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:33:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:33:43 --> Parser Class Initialized
INFO - 2019-11-04 10:33:43 --> User Agent Class Initialized
INFO - 2019-11-04 10:33:43 --> Model Class Initialized
INFO - 2019-11-04 10:33:43 --> Database Driver Class Initialized
INFO - 2019-11-04 10:33:43 --> Model Class Initialized
DEBUG - 2019-11-04 10:33:43 --> Template Class Initialized
INFO - 2019-11-04 10:33:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:33:43 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:33:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:33:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:33:43 --> Encryption Class Initialized
INFO - 2019-11-04 10:33:44 --> Controller Class Initialized
DEBUG - 2019-11-04 10:33:44 --> dotpay MX_Controller Initialized
INFO - 2019-11-04 10:33:44 --> Model Class Initialized
DEBUG - 2019-11-04 10:33:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-04 10:33:44 --> Final output sent to browser
DEBUG - 2019-11-04 10:33:44 --> Total execution time: 0.5496
INFO - 2019-11-04 10:34:08 --> Config Class Initialized
INFO - 2019-11-04 10:34:08 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:34:08 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:34:08 --> Utf8 Class Initialized
INFO - 2019-11-04 10:34:08 --> URI Class Initialized
INFO - 2019-11-04 10:34:08 --> Router Class Initialized
INFO - 2019-11-04 10:34:08 --> Output Class Initialized
INFO - 2019-11-04 10:34:08 --> Security Class Initialized
DEBUG - 2019-11-04 10:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:34:08 --> CSRF cookie sent
INFO - 2019-11-04 10:34:08 --> CSRF token verified
INFO - 2019-11-04 10:34:08 --> Input Class Initialized
INFO - 2019-11-04 10:34:08 --> Language Class Initialized
INFO - 2019-11-04 10:34:08 --> Language Class Initialized
INFO - 2019-11-04 10:34:08 --> Config Class Initialized
INFO - 2019-11-04 10:34:08 --> Loader Class Initialized
INFO - 2019-11-04 10:34:08 --> Helper loaded: url_helper
INFO - 2019-11-04 10:34:08 --> Helper loaded: common_helper
INFO - 2019-11-04 10:34:08 --> Helper loaded: language_helper
INFO - 2019-11-04 10:34:08 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:34:08 --> Helper loaded: email_helper
INFO - 2019-11-04 10:34:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:34:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:34:08 --> Parser Class Initialized
INFO - 2019-11-04 10:34:08 --> User Agent Class Initialized
INFO - 2019-11-04 10:34:08 --> Model Class Initialized
INFO - 2019-11-04 10:34:08 --> Database Driver Class Initialized
INFO - 2019-11-04 10:34:08 --> Model Class Initialized
DEBUG - 2019-11-04 10:34:08 --> Template Class Initialized
INFO - 2019-11-04 10:34:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:34:08 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:34:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:34:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:34:09 --> Encryption Class Initialized
INFO - 2019-11-04 10:34:09 --> Controller Class Initialized
DEBUG - 2019-11-04 10:34:09 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:34:09 --> Model Class Initialized
INFO - 2019-11-04 10:34:09 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 10:34:09 --> Could not find the language line "dotpay"
DEBUG - 2019-11-04 10:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-04 10:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:34:09 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:34:09 --> Model Class Initialized
DEBUG - 2019-11-04 10:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:34:09 --> Model Class Initialized
DEBUG - 2019-11-04 10:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-04 10:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-04 10:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-04 10:34:09 --> Final output sent to browser
DEBUG - 2019-11-04 10:34:09 --> Total execution time: 0.7555
INFO - 2019-11-04 10:34:15 --> Config Class Initialized
INFO - 2019-11-04 10:34:15 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:34:15 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:34:15 --> Utf8 Class Initialized
INFO - 2019-11-04 10:34:15 --> URI Class Initialized
INFO - 2019-11-04 10:34:15 --> Router Class Initialized
INFO - 2019-11-04 10:34:15 --> Output Class Initialized
INFO - 2019-11-04 10:34:15 --> Security Class Initialized
DEBUG - 2019-11-04 10:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:34:15 --> CSRF cookie sent
INFO - 2019-11-04 10:34:15 --> CSRF token verified
INFO - 2019-11-04 10:34:15 --> Input Class Initialized
INFO - 2019-11-04 10:34:15 --> Language Class Initialized
INFO - 2019-11-04 10:34:15 --> Language Class Initialized
INFO - 2019-11-04 10:34:15 --> Config Class Initialized
INFO - 2019-11-04 10:34:15 --> Loader Class Initialized
INFO - 2019-11-04 10:34:15 --> Helper loaded: url_helper
INFO - 2019-11-04 10:34:15 --> Helper loaded: common_helper
INFO - 2019-11-04 10:34:15 --> Helper loaded: language_helper
INFO - 2019-11-04 10:34:15 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:34:15 --> Helper loaded: email_helper
INFO - 2019-11-04 10:34:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:34:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:34:15 --> Parser Class Initialized
INFO - 2019-11-04 10:34:15 --> User Agent Class Initialized
INFO - 2019-11-04 10:34:15 --> Model Class Initialized
INFO - 2019-11-04 10:34:15 --> Database Driver Class Initialized
INFO - 2019-11-04 10:34:15 --> Model Class Initialized
DEBUG - 2019-11-04 10:34:15 --> Template Class Initialized
INFO - 2019-11-04 10:34:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:34:15 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:34:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:34:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:34:15 --> Encryption Class Initialized
INFO - 2019-11-04 10:34:16 --> Controller Class Initialized
DEBUG - 2019-11-04 10:34:16 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:34:16 --> Model Class Initialized
DEBUG - 2019-11-04 10:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-04 10:34:16 --> Final output sent to browser
DEBUG - 2019-11-04 10:34:16 --> Total execution time: 0.5727
INFO - 2019-11-04 10:34:16 --> Config Class Initialized
INFO - 2019-11-04 10:34:16 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:34:16 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:34:16 --> Utf8 Class Initialized
INFO - 2019-11-04 10:34:16 --> URI Class Initialized
INFO - 2019-11-04 10:34:16 --> Router Class Initialized
INFO - 2019-11-04 10:34:16 --> Output Class Initialized
INFO - 2019-11-04 10:34:16 --> Security Class Initialized
DEBUG - 2019-11-04 10:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:34:16 --> Input Class Initialized
INFO - 2019-11-04 10:34:16 --> Language Class Initialized
INFO - 2019-11-04 10:34:16 --> Language Class Initialized
INFO - 2019-11-04 10:34:16 --> Config Class Initialized
INFO - 2019-11-04 10:34:16 --> Loader Class Initialized
INFO - 2019-11-04 10:34:16 --> Helper loaded: url_helper
INFO - 2019-11-04 10:34:16 --> Helper loaded: common_helper
INFO - 2019-11-04 10:34:16 --> Helper loaded: language_helper
INFO - 2019-11-04 10:34:16 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:34:16 --> Helper loaded: email_helper
INFO - 2019-11-04 10:34:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:34:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:34:16 --> Parser Class Initialized
INFO - 2019-11-04 10:34:16 --> User Agent Class Initialized
INFO - 2019-11-04 10:34:16 --> Model Class Initialized
INFO - 2019-11-04 10:34:16 --> Database Driver Class Initialized
INFO - 2019-11-04 10:34:16 --> Model Class Initialized
DEBUG - 2019-11-04 10:34:16 --> Template Class Initialized
INFO - 2019-11-04 10:34:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:34:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:34:16 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:34:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:34:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:34:16 --> Encryption Class Initialized
INFO - 2019-11-04 10:34:16 --> Controller Class Initialized
DEBUG - 2019-11-04 10:34:16 --> dotpay MX_Controller Initialized
INFO - 2019-11-04 10:34:16 --> Model Class Initialized
DEBUG - 2019-11-04 10:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-04 10:34:16 --> Final output sent to browser
DEBUG - 2019-11-04 10:34:16 --> Total execution time: 0.5546
INFO - 2019-11-04 10:35:00 --> Config Class Initialized
INFO - 2019-11-04 10:35:00 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:35:00 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:35:00 --> Utf8 Class Initialized
INFO - 2019-11-04 10:35:00 --> URI Class Initialized
INFO - 2019-11-04 10:35:00 --> Router Class Initialized
INFO - 2019-11-04 10:35:01 --> Output Class Initialized
INFO - 2019-11-04 10:35:01 --> Security Class Initialized
DEBUG - 2019-11-04 10:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:35:01 --> CSRF cookie sent
INFO - 2019-11-04 10:35:01 --> CSRF token verified
INFO - 2019-11-04 10:35:01 --> Input Class Initialized
INFO - 2019-11-04 10:35:01 --> Language Class Initialized
INFO - 2019-11-04 10:35:01 --> Language Class Initialized
INFO - 2019-11-04 10:35:01 --> Config Class Initialized
INFO - 2019-11-04 10:35:01 --> Loader Class Initialized
INFO - 2019-11-04 10:35:01 --> Helper loaded: url_helper
INFO - 2019-11-04 10:35:01 --> Helper loaded: common_helper
INFO - 2019-11-04 10:35:01 --> Helper loaded: language_helper
INFO - 2019-11-04 10:35:01 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:35:01 --> Helper loaded: email_helper
INFO - 2019-11-04 10:35:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:35:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:35:01 --> Parser Class Initialized
INFO - 2019-11-04 10:35:01 --> User Agent Class Initialized
INFO - 2019-11-04 10:35:01 --> Model Class Initialized
INFO - 2019-11-04 10:35:01 --> Database Driver Class Initialized
INFO - 2019-11-04 10:35:01 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:01 --> Template Class Initialized
INFO - 2019-11-04 10:35:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:35:01 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:35:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:35:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:35:01 --> Encryption Class Initialized
INFO - 2019-11-04 10:35:01 --> Controller Class Initialized
DEBUG - 2019-11-04 10:35:01 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:35:01 --> Model Class Initialized
INFO - 2019-11-04 10:35:01 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 10:35:01 --> Could not find the language line "dotpay"
DEBUG - 2019-11-04 10:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-04 10:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:35:01 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:35:01 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:35:01 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-04 10:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-04 10:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-04 10:35:01 --> Final output sent to browser
DEBUG - 2019-11-04 10:35:01 --> Total execution time: 0.8233
INFO - 2019-11-04 10:35:07 --> Config Class Initialized
INFO - 2019-11-04 10:35:07 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:35:07 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:35:07 --> Utf8 Class Initialized
INFO - 2019-11-04 10:35:07 --> URI Class Initialized
INFO - 2019-11-04 10:35:07 --> Router Class Initialized
INFO - 2019-11-04 10:35:07 --> Output Class Initialized
INFO - 2019-11-04 10:35:07 --> Security Class Initialized
DEBUG - 2019-11-04 10:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:35:07 --> CSRF cookie sent
INFO - 2019-11-04 10:35:07 --> CSRF token verified
INFO - 2019-11-04 10:35:07 --> Input Class Initialized
INFO - 2019-11-04 10:35:07 --> Language Class Initialized
INFO - 2019-11-04 10:35:07 --> Language Class Initialized
INFO - 2019-11-04 10:35:07 --> Config Class Initialized
INFO - 2019-11-04 10:35:07 --> Loader Class Initialized
INFO - 2019-11-04 10:35:07 --> Helper loaded: url_helper
INFO - 2019-11-04 10:35:07 --> Helper loaded: common_helper
INFO - 2019-11-04 10:35:07 --> Helper loaded: language_helper
INFO - 2019-11-04 10:35:07 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:35:07 --> Helper loaded: email_helper
INFO - 2019-11-04 10:35:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:35:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:35:07 --> Parser Class Initialized
INFO - 2019-11-04 10:35:07 --> User Agent Class Initialized
INFO - 2019-11-04 10:35:07 --> Model Class Initialized
INFO - 2019-11-04 10:35:07 --> Database Driver Class Initialized
INFO - 2019-11-04 10:35:07 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:07 --> Template Class Initialized
INFO - 2019-11-04 10:35:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:35:07 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:35:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:35:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:35:07 --> Encryption Class Initialized
INFO - 2019-11-04 10:35:07 --> Controller Class Initialized
DEBUG - 2019-11-04 10:35:07 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:35:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:35:07 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-04 10:35:07 --> Final output sent to browser
DEBUG - 2019-11-04 10:35:07 --> Total execution time: 0.6102
INFO - 2019-11-04 10:35:07 --> Config Class Initialized
INFO - 2019-11-04 10:35:07 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:35:07 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:35:07 --> Utf8 Class Initialized
INFO - 2019-11-04 10:35:07 --> URI Class Initialized
INFO - 2019-11-04 10:35:07 --> Router Class Initialized
INFO - 2019-11-04 10:35:07 --> Output Class Initialized
INFO - 2019-11-04 10:35:07 --> Security Class Initialized
DEBUG - 2019-11-04 10:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:35:07 --> Input Class Initialized
INFO - 2019-11-04 10:35:08 --> Language Class Initialized
INFO - 2019-11-04 10:35:08 --> Language Class Initialized
INFO - 2019-11-04 10:35:08 --> Config Class Initialized
INFO - 2019-11-04 10:35:08 --> Loader Class Initialized
INFO - 2019-11-04 10:35:08 --> Helper loaded: url_helper
INFO - 2019-11-04 10:35:08 --> Helper loaded: common_helper
INFO - 2019-11-04 10:35:08 --> Helper loaded: language_helper
INFO - 2019-11-04 10:35:08 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:35:08 --> Helper loaded: email_helper
INFO - 2019-11-04 10:35:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:35:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:35:08 --> Parser Class Initialized
INFO - 2019-11-04 10:35:08 --> User Agent Class Initialized
INFO - 2019-11-04 10:35:08 --> Model Class Initialized
INFO - 2019-11-04 10:35:08 --> Database Driver Class Initialized
INFO - 2019-11-04 10:35:08 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:08 --> Template Class Initialized
INFO - 2019-11-04 10:35:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:35:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:35:08 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:35:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:35:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:35:08 --> Encryption Class Initialized
INFO - 2019-11-04 10:35:08 --> Controller Class Initialized
DEBUG - 2019-11-04 10:35:08 --> dotpay MX_Controller Initialized
INFO - 2019-11-04 10:35:08 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-04 10:35:08 --> Final output sent to browser
DEBUG - 2019-11-04 10:35:08 --> Total execution time: 0.5677
INFO - 2019-11-04 10:35:45 --> Config Class Initialized
INFO - 2019-11-04 10:35:45 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:35:45 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:35:45 --> Utf8 Class Initialized
INFO - 2019-11-04 10:35:45 --> URI Class Initialized
INFO - 2019-11-04 10:35:45 --> Router Class Initialized
INFO - 2019-11-04 10:35:45 --> Output Class Initialized
INFO - 2019-11-04 10:35:45 --> Security Class Initialized
DEBUG - 2019-11-04 10:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:35:45 --> CSRF cookie sent
INFO - 2019-11-04 10:35:45 --> CSRF token verified
INFO - 2019-11-04 10:35:45 --> Input Class Initialized
INFO - 2019-11-04 10:35:45 --> Language Class Initialized
INFO - 2019-11-04 10:35:45 --> Language Class Initialized
INFO - 2019-11-04 10:35:46 --> Config Class Initialized
INFO - 2019-11-04 10:35:46 --> Loader Class Initialized
INFO - 2019-11-04 10:35:46 --> Helper loaded: url_helper
INFO - 2019-11-04 10:35:46 --> Helper loaded: common_helper
INFO - 2019-11-04 10:35:46 --> Helper loaded: language_helper
INFO - 2019-11-04 10:35:46 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:35:46 --> Helper loaded: email_helper
INFO - 2019-11-04 10:35:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:35:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:35:46 --> Parser Class Initialized
INFO - 2019-11-04 10:35:46 --> User Agent Class Initialized
INFO - 2019-11-04 10:35:46 --> Model Class Initialized
INFO - 2019-11-04 10:35:46 --> Database Driver Class Initialized
INFO - 2019-11-04 10:35:46 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:46 --> Template Class Initialized
INFO - 2019-11-04 10:35:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:35:46 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:35:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:35:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:35:46 --> Encryption Class Initialized
INFO - 2019-11-04 10:35:46 --> Controller Class Initialized
DEBUG - 2019-11-04 10:35:46 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:35:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:35:46 --> Model Class Initialized
INFO - 2019-11-04 10:35:52 --> Config Class Initialized
INFO - 2019-11-04 10:35:52 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:35:52 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:35:52 --> Utf8 Class Initialized
INFO - 2019-11-04 10:35:52 --> URI Class Initialized
INFO - 2019-11-04 10:35:52 --> Router Class Initialized
INFO - 2019-11-04 10:35:52 --> Output Class Initialized
INFO - 2019-11-04 10:35:52 --> Security Class Initialized
DEBUG - 2019-11-04 10:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:35:52 --> CSRF cookie sent
INFO - 2019-11-04 10:35:52 --> Input Class Initialized
INFO - 2019-11-04 10:35:52 --> Language Class Initialized
INFO - 2019-11-04 10:35:52 --> Language Class Initialized
INFO - 2019-11-04 10:35:52 --> Config Class Initialized
INFO - 2019-11-04 10:35:52 --> Loader Class Initialized
INFO - 2019-11-04 10:35:52 --> Helper loaded: url_helper
INFO - 2019-11-04 10:35:52 --> Helper loaded: common_helper
INFO - 2019-11-04 10:35:52 --> Helper loaded: language_helper
INFO - 2019-11-04 10:35:52 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:35:52 --> Helper loaded: email_helper
INFO - 2019-11-04 10:35:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:35:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:35:52 --> Parser Class Initialized
INFO - 2019-11-04 10:35:52 --> User Agent Class Initialized
INFO - 2019-11-04 10:35:52 --> Model Class Initialized
INFO - 2019-11-04 10:35:52 --> Database Driver Class Initialized
INFO - 2019-11-04 10:35:52 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:52 --> Template Class Initialized
INFO - 2019-11-04 10:35:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:35:52 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:35:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:35:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:35:52 --> Encryption Class Initialized
INFO - 2019-11-04 10:35:52 --> Controller Class Initialized
DEBUG - 2019-11-04 10:35:52 --> setting MX_Controller Initialized
DEBUG - 2019-11-04 10:35:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-04 10:35:52 --> Model Class Initialized
INFO - 2019-11-04 10:35:52 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:35:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-04 10:35:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-04 10:35:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-04 10:35:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:35:52 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:35:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:35:52 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:35:52 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:35:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:35:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:35:53 --> Final output sent to browser
DEBUG - 2019-11-04 10:35:53 --> Total execution time: 0.8838
INFO - 2019-11-04 10:35:54 --> Config Class Initialized
INFO - 2019-11-04 10:35:54 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:35:54 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:35:54 --> Utf8 Class Initialized
INFO - 2019-11-04 10:35:54 --> URI Class Initialized
INFO - 2019-11-04 10:35:54 --> Router Class Initialized
INFO - 2019-11-04 10:35:54 --> Output Class Initialized
INFO - 2019-11-04 10:35:54 --> Security Class Initialized
DEBUG - 2019-11-04 10:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:35:54 --> CSRF cookie sent
INFO - 2019-11-04 10:35:54 --> CSRF token verified
INFO - 2019-11-04 10:35:54 --> Input Class Initialized
INFO - 2019-11-04 10:35:54 --> Language Class Initialized
INFO - 2019-11-04 10:35:54 --> Language Class Initialized
INFO - 2019-11-04 10:35:54 --> Config Class Initialized
INFO - 2019-11-04 10:35:54 --> Loader Class Initialized
INFO - 2019-11-04 10:35:54 --> Helper loaded: url_helper
INFO - 2019-11-04 10:35:54 --> Helper loaded: common_helper
INFO - 2019-11-04 10:35:54 --> Helper loaded: language_helper
INFO - 2019-11-04 10:35:54 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:35:54 --> Helper loaded: email_helper
INFO - 2019-11-04 10:35:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:35:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:35:54 --> Parser Class Initialized
INFO - 2019-11-04 10:35:54 --> User Agent Class Initialized
INFO - 2019-11-04 10:35:54 --> Model Class Initialized
INFO - 2019-11-04 10:35:54 --> Database Driver Class Initialized
INFO - 2019-11-04 10:35:54 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:54 --> Template Class Initialized
INFO - 2019-11-04 10:35:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:35:54 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:35:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:35:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:35:54 --> Encryption Class Initialized
INFO - 2019-11-04 10:35:54 --> Controller Class Initialized
DEBUG - 2019-11-04 10:35:54 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:35:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:35:54 --> Model Class Initialized
INFO - 2019-11-04 10:35:54 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 10:35:54 --> Could not find the language line "dotpay"
DEBUG - 2019-11-04 10:35:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-04 10:35:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:35:54 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:35:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:35:54 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:35:54 --> Model Class Initialized
DEBUG - 2019-11-04 10:35:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-04 10:35:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-04 10:35:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-04 10:35:54 --> Final output sent to browser
DEBUG - 2019-11-04 10:35:54 --> Total execution time: 0.8410
INFO - 2019-11-04 10:36:00 --> Config Class Initialized
INFO - 2019-11-04 10:36:00 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:36:00 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:36:00 --> Utf8 Class Initialized
INFO - 2019-11-04 10:36:00 --> URI Class Initialized
INFO - 2019-11-04 10:36:00 --> Router Class Initialized
INFO - 2019-11-04 10:36:00 --> Output Class Initialized
INFO - 2019-11-04 10:36:00 --> Security Class Initialized
DEBUG - 2019-11-04 10:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:36:00 --> CSRF cookie sent
INFO - 2019-11-04 10:36:00 --> CSRF token verified
INFO - 2019-11-04 10:36:00 --> Input Class Initialized
INFO - 2019-11-04 10:36:00 --> Language Class Initialized
INFO - 2019-11-04 10:36:00 --> Language Class Initialized
INFO - 2019-11-04 10:36:00 --> Config Class Initialized
INFO - 2019-11-04 10:36:00 --> Loader Class Initialized
INFO - 2019-11-04 10:36:00 --> Helper loaded: url_helper
INFO - 2019-11-04 10:36:00 --> Helper loaded: common_helper
INFO - 2019-11-04 10:36:01 --> Helper loaded: language_helper
INFO - 2019-11-04 10:36:01 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:36:01 --> Helper loaded: email_helper
INFO - 2019-11-04 10:36:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:36:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:36:01 --> Parser Class Initialized
INFO - 2019-11-04 10:36:01 --> User Agent Class Initialized
INFO - 2019-11-04 10:36:01 --> Model Class Initialized
INFO - 2019-11-04 10:36:01 --> Database Driver Class Initialized
INFO - 2019-11-04 10:36:01 --> Model Class Initialized
DEBUG - 2019-11-04 10:36:01 --> Template Class Initialized
INFO - 2019-11-04 10:36:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:36:01 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:36:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:36:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:36:01 --> Encryption Class Initialized
INFO - 2019-11-04 10:36:01 --> Controller Class Initialized
DEBUG - 2019-11-04 10:36:01 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:36:01 --> Model Class Initialized
DEBUG - 2019-11-04 10:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-04 10:36:01 --> Final output sent to browser
DEBUG - 2019-11-04 10:36:01 --> Total execution time: 0.6093
INFO - 2019-11-04 10:36:01 --> Config Class Initialized
INFO - 2019-11-04 10:36:01 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:36:01 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:36:01 --> Utf8 Class Initialized
INFO - 2019-11-04 10:36:01 --> URI Class Initialized
INFO - 2019-11-04 10:36:01 --> Router Class Initialized
INFO - 2019-11-04 10:36:01 --> Output Class Initialized
INFO - 2019-11-04 10:36:01 --> Security Class Initialized
DEBUG - 2019-11-04 10:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:36:01 --> Input Class Initialized
INFO - 2019-11-04 10:36:01 --> Language Class Initialized
INFO - 2019-11-04 10:36:01 --> Language Class Initialized
INFO - 2019-11-04 10:36:01 --> Config Class Initialized
INFO - 2019-11-04 10:36:01 --> Loader Class Initialized
INFO - 2019-11-04 10:36:01 --> Helper loaded: url_helper
INFO - 2019-11-04 10:36:01 --> Helper loaded: common_helper
INFO - 2019-11-04 10:36:01 --> Helper loaded: language_helper
INFO - 2019-11-04 10:36:01 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:36:01 --> Helper loaded: email_helper
INFO - 2019-11-04 10:36:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:36:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:36:01 --> Parser Class Initialized
INFO - 2019-11-04 10:36:01 --> User Agent Class Initialized
INFO - 2019-11-04 10:36:01 --> Model Class Initialized
INFO - 2019-11-04 10:36:01 --> Database Driver Class Initialized
INFO - 2019-11-04 10:36:01 --> Model Class Initialized
DEBUG - 2019-11-04 10:36:01 --> Template Class Initialized
INFO - 2019-11-04 10:36:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:36:01 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:36:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:36:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:36:01 --> Encryption Class Initialized
INFO - 2019-11-04 10:36:01 --> Controller Class Initialized
DEBUG - 2019-11-04 10:36:01 --> dotpay MX_Controller Initialized
INFO - 2019-11-04 10:36:01 --> Model Class Initialized
DEBUG - 2019-11-04 10:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-04 10:36:01 --> Final output sent to browser
DEBUG - 2019-11-04 10:36:02 --> Total execution time: 0.5914
INFO - 2019-11-04 10:39:04 --> Config Class Initialized
INFO - 2019-11-04 10:39:04 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:39:04 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:39:04 --> Utf8 Class Initialized
INFO - 2019-11-04 10:39:04 --> URI Class Initialized
INFO - 2019-11-04 10:39:04 --> Router Class Initialized
INFO - 2019-11-04 10:39:04 --> Output Class Initialized
INFO - 2019-11-04 10:39:04 --> Security Class Initialized
DEBUG - 2019-11-04 10:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:39:04 --> Input Class Initialized
INFO - 2019-11-04 10:39:05 --> Language Class Initialized
INFO - 2019-11-04 10:39:05 --> Language Class Initialized
INFO - 2019-11-04 10:39:05 --> Config Class Initialized
INFO - 2019-11-04 10:39:05 --> Loader Class Initialized
INFO - 2019-11-04 10:39:05 --> Helper loaded: url_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: common_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: language_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: email_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:39:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:39:05 --> Parser Class Initialized
INFO - 2019-11-04 10:39:05 --> User Agent Class Initialized
INFO - 2019-11-04 10:39:05 --> Model Class Initialized
INFO - 2019-11-04 10:39:05 --> Database Driver Class Initialized
INFO - 2019-11-04 10:39:05 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:05 --> Template Class Initialized
INFO - 2019-11-04 10:39:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:39:05 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:39:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:39:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:39:05 --> Encryption Class Initialized
INFO - 2019-11-04 10:39:05 --> Controller Class Initialized
DEBUG - 2019-11-04 10:39:05 --> dotpay MX_Controller Initialized
INFO - 2019-11-04 10:39:05 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:05 --> orders MX_Controller Initialized
INFO - 2019-11-04 10:39:05 --> Config Class Initialized
INFO - 2019-11-04 10:39:05 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:39:05 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:39:05 --> Utf8 Class Initialized
INFO - 2019-11-04 10:39:05 --> URI Class Initialized
INFO - 2019-11-04 10:39:05 --> Router Class Initialized
INFO - 2019-11-04 10:39:05 --> Output Class Initialized
INFO - 2019-11-04 10:39:05 --> Security Class Initialized
DEBUG - 2019-11-04 10:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:39:05 --> CSRF cookie sent
INFO - 2019-11-04 10:39:05 --> Input Class Initialized
INFO - 2019-11-04 10:39:05 --> Language Class Initialized
INFO - 2019-11-04 10:39:05 --> Language Class Initialized
INFO - 2019-11-04 10:39:05 --> Config Class Initialized
INFO - 2019-11-04 10:39:05 --> Loader Class Initialized
INFO - 2019-11-04 10:39:05 --> Helper loaded: url_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: common_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: language_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: email_helper
INFO - 2019-11-04 10:39:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:39:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:39:05 --> Parser Class Initialized
INFO - 2019-11-04 10:39:05 --> User Agent Class Initialized
INFO - 2019-11-04 10:39:05 --> Model Class Initialized
INFO - 2019-11-04 10:39:05 --> Database Driver Class Initialized
INFO - 2019-11-04 10:39:05 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:05 --> Template Class Initialized
INFO - 2019-11-04 10:39:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:39:05 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:39:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:39:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:39:05 --> Encryption Class Initialized
INFO - 2019-11-04 10:39:05 --> Controller Class Initialized
DEBUG - 2019-11-04 10:39:05 --> checkout MX_Controller Initialized
DEBUG - 2019-11-04 10:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-04 10:39:05 --> Model Class Initialized
INFO - 2019-11-04 10:39:05 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-04 10:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:39:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:39:05 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:39:06 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-04 10:39:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-04 10:39:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-04 10:39:06 --> Final output sent to browser
DEBUG - 2019-11-04 10:39:06 --> Total execution time: 0.6997
INFO - 2019-11-04 10:39:14 --> Config Class Initialized
INFO - 2019-11-04 10:39:14 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:39:14 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:39:15 --> Utf8 Class Initialized
INFO - 2019-11-04 10:39:15 --> URI Class Initialized
INFO - 2019-11-04 10:39:15 --> Router Class Initialized
INFO - 2019-11-04 10:39:15 --> Output Class Initialized
INFO - 2019-11-04 10:39:15 --> Security Class Initialized
DEBUG - 2019-11-04 10:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:39:15 --> CSRF cookie sent
INFO - 2019-11-04 10:39:15 --> Input Class Initialized
INFO - 2019-11-04 10:39:15 --> Language Class Initialized
INFO - 2019-11-04 10:39:15 --> Language Class Initialized
INFO - 2019-11-04 10:39:15 --> Config Class Initialized
INFO - 2019-11-04 10:39:15 --> Loader Class Initialized
INFO - 2019-11-04 10:39:15 --> Helper loaded: url_helper
INFO - 2019-11-04 10:39:15 --> Helper loaded: common_helper
INFO - 2019-11-04 10:39:15 --> Helper loaded: language_helper
INFO - 2019-11-04 10:39:15 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:39:15 --> Helper loaded: email_helper
INFO - 2019-11-04 10:39:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:39:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:39:15 --> Parser Class Initialized
INFO - 2019-11-04 10:39:15 --> User Agent Class Initialized
INFO - 2019-11-04 10:39:15 --> Model Class Initialized
INFO - 2019-11-04 10:39:15 --> Database Driver Class Initialized
INFO - 2019-11-04 10:39:15 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:15 --> Template Class Initialized
INFO - 2019-11-04 10:39:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:39:15 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:39:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:39:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:39:15 --> Encryption Class Initialized
INFO - 2019-11-04 10:39:15 --> Controller Class Initialized
DEBUG - 2019-11-04 10:39:15 --> transactions MX_Controller Initialized
DEBUG - 2019-11-04 10:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-04 10:39:15 --> Model Class Initialized
ERROR - 2019-11-04 10:39:15 --> Could not find the language line "order_id"
INFO - 2019-11-04 10:39:15 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-04 10:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:39:15 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:39:15 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:39:15 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:39:15 --> Final output sent to browser
DEBUG - 2019-11-04 10:39:15 --> Total execution time: 0.8689
INFO - 2019-11-04 10:39:54 --> Config Class Initialized
INFO - 2019-11-04 10:39:54 --> Hooks Class Initialized
DEBUG - 2019-11-04 10:39:54 --> UTF-8 Support Enabled
INFO - 2019-11-04 10:39:54 --> Utf8 Class Initialized
INFO - 2019-11-04 10:39:54 --> URI Class Initialized
INFO - 2019-11-04 10:39:54 --> Router Class Initialized
INFO - 2019-11-04 10:39:54 --> Output Class Initialized
INFO - 2019-11-04 10:39:54 --> Security Class Initialized
DEBUG - 2019-11-04 10:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 10:39:54 --> CSRF cookie sent
INFO - 2019-11-04 10:39:54 --> Input Class Initialized
INFO - 2019-11-04 10:39:54 --> Language Class Initialized
INFO - 2019-11-04 10:39:54 --> Language Class Initialized
INFO - 2019-11-04 10:39:54 --> Config Class Initialized
INFO - 2019-11-04 10:39:54 --> Loader Class Initialized
INFO - 2019-11-04 10:39:54 --> Helper loaded: url_helper
INFO - 2019-11-04 10:39:54 --> Helper loaded: common_helper
INFO - 2019-11-04 10:39:54 --> Helper loaded: language_helper
INFO - 2019-11-04 10:39:54 --> Helper loaded: cookie_helper
INFO - 2019-11-04 10:39:54 --> Helper loaded: email_helper
INFO - 2019-11-04 10:39:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 10:39:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 10:39:54 --> Parser Class Initialized
INFO - 2019-11-04 10:39:54 --> User Agent Class Initialized
INFO - 2019-11-04 10:39:54 --> Model Class Initialized
INFO - 2019-11-04 10:39:54 --> Database Driver Class Initialized
INFO - 2019-11-04 10:39:54 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:54 --> Template Class Initialized
INFO - 2019-11-04 10:39:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 10:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 10:39:55 --> Pagination Class Initialized
DEBUG - 2019-11-04 10:39:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 10:39:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 10:39:55 --> Encryption Class Initialized
INFO - 2019-11-04 10:39:55 --> Controller Class Initialized
DEBUG - 2019-11-04 10:39:55 --> transactions MX_Controller Initialized
DEBUG - 2019-11-04 10:39:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-04 10:39:55 --> Model Class Initialized
ERROR - 2019-11-04 10:39:55 --> Could not find the language line "order_id"
INFO - 2019-11-04 10:39:55 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 10:39:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-04 10:39:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 10:39:55 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 10:39:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 10:39:55 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 10:39:55 --> Model Class Initialized
DEBUG - 2019-11-04 10:39:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 10:39:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 10:39:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 10:39:55 --> Final output sent to browser
DEBUG - 2019-11-04 10:39:55 --> Total execution time: 0.8540
INFO - 2019-11-04 14:58:39 --> Config Class Initialized
INFO - 2019-11-04 14:58:39 --> Hooks Class Initialized
DEBUG - 2019-11-04 14:58:39 --> UTF-8 Support Enabled
INFO - 2019-11-04 14:58:39 --> Utf8 Class Initialized
INFO - 2019-11-04 14:58:39 --> URI Class Initialized
INFO - 2019-11-04 14:58:39 --> Router Class Initialized
INFO - 2019-11-04 14:58:39 --> Output Class Initialized
INFO - 2019-11-04 14:58:39 --> Security Class Initialized
DEBUG - 2019-11-04 14:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 14:58:39 --> CSRF cookie sent
INFO - 2019-11-04 14:58:39 --> Input Class Initialized
INFO - 2019-11-04 14:58:39 --> Language Class Initialized
INFO - 2019-11-04 14:58:39 --> Language Class Initialized
INFO - 2019-11-04 14:58:39 --> Config Class Initialized
INFO - 2019-11-04 14:58:40 --> Loader Class Initialized
INFO - 2019-11-04 14:58:40 --> Helper loaded: url_helper
INFO - 2019-11-04 14:58:40 --> Helper loaded: common_helper
INFO - 2019-11-04 14:58:40 --> Helper loaded: language_helper
INFO - 2019-11-04 14:58:40 --> Helper loaded: cookie_helper
INFO - 2019-11-04 14:58:40 --> Helper loaded: email_helper
INFO - 2019-11-04 14:58:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 14:58:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 14:58:40 --> Parser Class Initialized
INFO - 2019-11-04 14:58:40 --> User Agent Class Initialized
INFO - 2019-11-04 14:58:40 --> Model Class Initialized
INFO - 2019-11-04 14:58:40 --> Database Driver Class Initialized
INFO - 2019-11-04 14:58:40 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:40 --> Template Class Initialized
INFO - 2019-11-04 14:58:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 14:58:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 14:58:40 --> Pagination Class Initialized
DEBUG - 2019-11-04 14:58:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 14:58:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 14:58:40 --> Encryption Class Initialized
INFO - 2019-11-04 14:58:40 --> Controller Class Initialized
DEBUG - 2019-11-04 14:58:40 --> auth MX_Controller Initialized
DEBUG - 2019-11-04 14:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-04 14:58:40 --> Model Class Initialized
INFO - 2019-11-04 14:58:40 --> Config Class Initialized
INFO - 2019-11-04 14:58:41 --> Hooks Class Initialized
DEBUG - 2019-11-04 14:58:41 --> UTF-8 Support Enabled
INFO - 2019-11-04 14:58:41 --> Utf8 Class Initialized
INFO - 2019-11-04 14:58:41 --> URI Class Initialized
INFO - 2019-11-04 14:58:41 --> Router Class Initialized
INFO - 2019-11-04 14:58:41 --> Output Class Initialized
INFO - 2019-11-04 14:58:41 --> Security Class Initialized
DEBUG - 2019-11-04 14:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 14:58:41 --> CSRF cookie sent
INFO - 2019-11-04 14:58:41 --> Input Class Initialized
INFO - 2019-11-04 14:58:41 --> Language Class Initialized
INFO - 2019-11-04 14:58:41 --> Language Class Initialized
INFO - 2019-11-04 14:58:41 --> Config Class Initialized
INFO - 2019-11-04 14:58:41 --> Loader Class Initialized
INFO - 2019-11-04 14:58:41 --> Helper loaded: url_helper
INFO - 2019-11-04 14:58:41 --> Helper loaded: common_helper
INFO - 2019-11-04 14:58:41 --> Helper loaded: language_helper
INFO - 2019-11-04 14:58:41 --> Helper loaded: cookie_helper
INFO - 2019-11-04 14:58:41 --> Helper loaded: email_helper
INFO - 2019-11-04 14:58:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 14:58:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 14:58:41 --> Parser Class Initialized
INFO - 2019-11-04 14:58:41 --> User Agent Class Initialized
INFO - 2019-11-04 14:58:41 --> Model Class Initialized
INFO - 2019-11-04 14:58:41 --> Database Driver Class Initialized
INFO - 2019-11-04 14:58:41 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:41 --> Template Class Initialized
INFO - 2019-11-04 14:58:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 14:58:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 14:58:41 --> Pagination Class Initialized
DEBUG - 2019-11-04 14:58:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 14:58:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 14:58:41 --> Encryption Class Initialized
INFO - 2019-11-04 14:58:41 --> Controller Class Initialized
DEBUG - 2019-11-04 14:58:41 --> statistics MX_Controller Initialized
DEBUG - 2019-11-04 14:58:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-04 14:58:41 --> Model Class Initialized
ERROR - 2019-11-04 14:58:41 --> Could not find the language line "Pending"
ERROR - 2019-11-04 14:58:41 --> Could not find the language line "Pending"
INFO - 2019-11-04 14:58:41 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 14:58:41 --> Could not find the language line "total_orders"
ERROR - 2019-11-04 14:58:41 --> Could not find the language line "total_orders"
ERROR - 2019-11-04 14:58:41 --> Could not find the language line "Pending"
DEBUG - 2019-11-04 14:58:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-04 14:58:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 14:58:41 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 14:58:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 14:58:41 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 14:58:42 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 14:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 14:58:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 14:58:42 --> Final output sent to browser
DEBUG - 2019-11-04 14:58:42 --> Total execution time: 1.2314
INFO - 2019-11-04 14:58:49 --> Config Class Initialized
INFO - 2019-11-04 14:58:49 --> Hooks Class Initialized
DEBUG - 2019-11-04 14:58:49 --> UTF-8 Support Enabled
INFO - 2019-11-04 14:58:49 --> Utf8 Class Initialized
INFO - 2019-11-04 14:58:49 --> URI Class Initialized
INFO - 2019-11-04 14:58:49 --> Router Class Initialized
INFO - 2019-11-04 14:58:49 --> Output Class Initialized
INFO - 2019-11-04 14:58:49 --> Security Class Initialized
DEBUG - 2019-11-04 14:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 14:58:49 --> CSRF cookie sent
INFO - 2019-11-04 14:58:49 --> Input Class Initialized
INFO - 2019-11-04 14:58:49 --> Language Class Initialized
INFO - 2019-11-04 14:58:49 --> Language Class Initialized
INFO - 2019-11-04 14:58:49 --> Config Class Initialized
INFO - 2019-11-04 14:58:49 --> Loader Class Initialized
INFO - 2019-11-04 14:58:49 --> Helper loaded: url_helper
INFO - 2019-11-04 14:58:49 --> Helper loaded: common_helper
INFO - 2019-11-04 14:58:49 --> Helper loaded: language_helper
INFO - 2019-11-04 14:58:49 --> Helper loaded: cookie_helper
INFO - 2019-11-04 14:58:49 --> Helper loaded: email_helper
INFO - 2019-11-04 14:58:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 14:58:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 14:58:49 --> Parser Class Initialized
INFO - 2019-11-04 14:58:49 --> User Agent Class Initialized
INFO - 2019-11-04 14:58:49 --> Model Class Initialized
INFO - 2019-11-04 14:58:49 --> Database Driver Class Initialized
INFO - 2019-11-04 14:58:49 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:49 --> Template Class Initialized
INFO - 2019-11-04 14:58:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 14:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 14:58:49 --> Pagination Class Initialized
DEBUG - 2019-11-04 14:58:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 14:58:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 14:58:49 --> Encryption Class Initialized
INFO - 2019-11-04 14:58:49 --> Controller Class Initialized
DEBUG - 2019-11-04 14:58:49 --> transactions MX_Controller Initialized
DEBUG - 2019-11-04 14:58:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-04 14:58:49 --> Model Class Initialized
ERROR - 2019-11-04 14:58:49 --> Could not find the language line "order_id"
INFO - 2019-11-04 14:58:49 --> Helper loaded: inflector_helper
DEBUG - 2019-11-04 14:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-04 14:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 14:58:50 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 14:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 14:58:50 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 14:58:50 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 14:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 14:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 14:58:50 --> Final output sent to browser
DEBUG - 2019-11-04 14:58:50 --> Total execution time: 0.8624
INFO - 2019-11-04 14:58:55 --> Config Class Initialized
INFO - 2019-11-04 14:58:55 --> Hooks Class Initialized
DEBUG - 2019-11-04 14:58:55 --> UTF-8 Support Enabled
INFO - 2019-11-04 14:58:55 --> Utf8 Class Initialized
INFO - 2019-11-04 14:58:55 --> URI Class Initialized
INFO - 2019-11-04 14:58:55 --> Router Class Initialized
INFO - 2019-11-04 14:58:55 --> Output Class Initialized
INFO - 2019-11-04 14:58:56 --> Security Class Initialized
DEBUG - 2019-11-04 14:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-04 14:58:56 --> CSRF cookie sent
INFO - 2019-11-04 14:58:56 --> Input Class Initialized
INFO - 2019-11-04 14:58:56 --> Language Class Initialized
INFO - 2019-11-04 14:58:56 --> Language Class Initialized
INFO - 2019-11-04 14:58:56 --> Config Class Initialized
INFO - 2019-11-04 14:58:56 --> Loader Class Initialized
INFO - 2019-11-04 14:58:56 --> Helper loaded: url_helper
INFO - 2019-11-04 14:58:56 --> Helper loaded: common_helper
INFO - 2019-11-04 14:58:56 --> Helper loaded: language_helper
INFO - 2019-11-04 14:58:56 --> Helper loaded: cookie_helper
INFO - 2019-11-04 14:58:56 --> Helper loaded: email_helper
INFO - 2019-11-04 14:58:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-04 14:58:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-04 14:58:56 --> Parser Class Initialized
INFO - 2019-11-04 14:58:56 --> User Agent Class Initialized
INFO - 2019-11-04 14:58:56 --> Model Class Initialized
INFO - 2019-11-04 14:58:56 --> Database Driver Class Initialized
INFO - 2019-11-04 14:58:56 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:56 --> Template Class Initialized
INFO - 2019-11-04 14:58:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-04 14:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-04 14:58:56 --> Pagination Class Initialized
DEBUG - 2019-11-04 14:58:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-04 14:58:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-04 14:58:56 --> Encryption Class Initialized
INFO - 2019-11-04 14:58:56 --> Controller Class Initialized
DEBUG - 2019-11-04 14:58:56 --> order MX_Controller Initialized
DEBUG - 2019-11-04 14:58:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-04 14:58:56 --> Model Class Initialized
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "order_id"
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "order_id"
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "order_basic_details"
INFO - 2019-11-04 14:58:56 --> Helper loaded: inflector_helper
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "Awaiting"
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "Pending"
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "Pending"
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "Pending"
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "Pending"
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "Awaiting"
ERROR - 2019-11-04 14:58:56 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-04 14:58:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-04 14:58:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-04 14:58:56 --> blocks MX_Controller Initialized
DEBUG - 2019-11-04 14:58:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-04 14:58:56 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-04 14:58:57 --> Model Class Initialized
DEBUG - 2019-11-04 14:58:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-04 14:58:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-04 14:58:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-04 14:58:57 --> Final output sent to browser
DEBUG - 2019-11-04 14:58:57 --> Total execution time: 1.2479
