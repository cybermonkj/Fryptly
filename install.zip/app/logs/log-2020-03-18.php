<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-18 11:35:48 --> Config Class Initialized
INFO - 2020-03-18 11:35:48 --> Hooks Class Initialized
DEBUG - 2020-03-18 11:35:48 --> UTF-8 Support Enabled
INFO - 2020-03-18 11:35:48 --> Utf8 Class Initialized
INFO - 2020-03-18 11:35:48 --> URI Class Initialized
INFO - 2020-03-18 11:35:48 --> Router Class Initialized
INFO - 2020-03-18 11:35:49 --> Output Class Initialized
INFO - 2020-03-18 11:35:49 --> Security Class Initialized
DEBUG - 2020-03-18 11:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 11:35:49 --> CSRF cookie sent
INFO - 2020-03-18 11:35:49 --> Input Class Initialized
INFO - 2020-03-18 11:35:49 --> Language Class Initialized
INFO - 2020-03-18 11:35:49 --> Language Class Initialized
INFO - 2020-03-18 11:35:49 --> Config Class Initialized
INFO - 2020-03-18 11:35:49 --> Loader Class Initialized
INFO - 2020-03-18 11:35:49 --> Helper loaded: url_helper
INFO - 2020-03-18 11:35:49 --> Helper loaded: common_helper
INFO - 2020-03-18 11:35:49 --> Helper loaded: language_helper
INFO - 2020-03-18 11:35:49 --> Helper loaded: cookie_helper
INFO - 2020-03-18 11:35:49 --> Helper loaded: email_helper
INFO - 2020-03-18 11:35:49 --> Helper loaded: file_manager_helper
INFO - 2020-03-18 11:35:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-18 11:35:49 --> Parser Class Initialized
INFO - 2020-03-18 11:35:49 --> User Agent Class Initialized
INFO - 2020-03-18 11:35:49 --> Model Class Initialized
INFO - 2020-03-18 11:35:49 --> Database Driver Class Initialized
INFO - 2020-03-18 11:35:49 --> Model Class Initialized
DEBUG - 2020-03-18 11:35:49 --> Template Class Initialized
INFO - 2020-03-18 11:35:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-18 11:35:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-18 11:35:50 --> Pagination Class Initialized
DEBUG - 2020-03-18 11:35:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-18 11:35:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-18 11:35:50 --> Encryption Class Initialized
INFO - 2020-03-18 11:35:50 --> Controller Class Initialized
DEBUG - 2020-03-18 11:35:50 --> auth MX_Controller Initialized
DEBUG - 2020-03-18 11:35:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-18 11:35:50 --> Model Class Initialized
DEBUG - 2020-03-18 11:35:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-18 11:35:50 --> Helper loaded: inflector_helper
DEBUG - 2020-03-18 11:35:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-18 11:35:50 --> pergo MX_Controller Initialized
DEBUG - 2020-03-18 11:35:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-18 11:35:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-18 11:35:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-18 11:35:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-18 11:35:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-18 11:35:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-18 11:35:50 --> Final output sent to browser
DEBUG - 2020-03-18 11:35:50 --> Total execution time: 1.7999
INFO - 2020-03-18 11:35:59 --> Config Class Initialized
INFO - 2020-03-18 11:35:59 --> Hooks Class Initialized
DEBUG - 2020-03-18 11:35:59 --> UTF-8 Support Enabled
INFO - 2020-03-18 11:35:59 --> Utf8 Class Initialized
INFO - 2020-03-18 11:35:59 --> URI Class Initialized
DEBUG - 2020-03-18 11:35:59 --> No URI present. Default controller set.
INFO - 2020-03-18 11:35:59 --> Router Class Initialized
INFO - 2020-03-18 11:35:59 --> Output Class Initialized
INFO - 2020-03-18 11:35:59 --> Security Class Initialized
DEBUG - 2020-03-18 11:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 11:35:59 --> CSRF cookie sent
INFO - 2020-03-18 11:35:59 --> Input Class Initialized
INFO - 2020-03-18 11:35:59 --> Language Class Initialized
INFO - 2020-03-18 11:35:59 --> Language Class Initialized
INFO - 2020-03-18 11:35:59 --> Config Class Initialized
INFO - 2020-03-18 11:35:59 --> Loader Class Initialized
INFO - 2020-03-18 11:35:59 --> Helper loaded: url_helper
INFO - 2020-03-18 11:35:59 --> Helper loaded: common_helper
INFO - 2020-03-18 11:35:59 --> Helper loaded: language_helper
INFO - 2020-03-18 11:35:59 --> Helper loaded: cookie_helper
INFO - 2020-03-18 11:35:59 --> Helper loaded: email_helper
INFO - 2020-03-18 11:35:59 --> Helper loaded: file_manager_helper
INFO - 2020-03-18 11:35:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-18 11:35:59 --> Parser Class Initialized
INFO - 2020-03-18 11:35:59 --> User Agent Class Initialized
INFO - 2020-03-18 11:35:59 --> Model Class Initialized
INFO - 2020-03-18 11:35:59 --> Database Driver Class Initialized
INFO - 2020-03-18 11:35:59 --> Model Class Initialized
DEBUG - 2020-03-18 11:35:59 --> Template Class Initialized
INFO - 2020-03-18 11:35:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-18 11:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-18 11:35:59 --> Pagination Class Initialized
DEBUG - 2020-03-18 11:35:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-18 11:35:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-18 11:35:59 --> Encryption Class Initialized
DEBUG - 2020-03-18 11:35:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-18 11:35:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-18 11:35:59 --> Controller Class Initialized
DEBUG - 2020-03-18 11:35:59 --> pergo MX_Controller Initialized
DEBUG - 2020-03-18 11:35:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-18 11:35:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-18 11:35:59 --> Model Class Initialized
INFO - 2020-03-18 11:35:59 --> Helper loaded: inflector_helper
DEBUG - 2020-03-18 11:35:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-18 11:36:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-18 11:36:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-18 11:36:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-18 11:36:00 --> Final output sent to browser
DEBUG - 2020-03-18 11:36:00 --> Total execution time: 0.9033
INFO - 2020-03-18 11:36:05 --> Config Class Initialized
INFO - 2020-03-18 11:36:05 --> Hooks Class Initialized
DEBUG - 2020-03-18 11:36:05 --> UTF-8 Support Enabled
INFO - 2020-03-18 11:36:05 --> Utf8 Class Initialized
INFO - 2020-03-18 11:36:05 --> URI Class Initialized
INFO - 2020-03-18 11:36:05 --> Router Class Initialized
INFO - 2020-03-18 11:36:05 --> Output Class Initialized
INFO - 2020-03-18 11:36:05 --> Security Class Initialized
DEBUG - 2020-03-18 11:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 11:36:05 --> CSRF cookie sent
INFO - 2020-03-18 11:36:05 --> Input Class Initialized
INFO - 2020-03-18 11:36:05 --> Language Class Initialized
INFO - 2020-03-18 11:36:05 --> Language Class Initialized
INFO - 2020-03-18 11:36:05 --> Config Class Initialized
INFO - 2020-03-18 11:36:05 --> Loader Class Initialized
INFO - 2020-03-18 11:36:05 --> Helper loaded: url_helper
INFO - 2020-03-18 11:36:05 --> Helper loaded: common_helper
INFO - 2020-03-18 11:36:05 --> Helper loaded: language_helper
INFO - 2020-03-18 11:36:05 --> Helper loaded: cookie_helper
INFO - 2020-03-18 11:36:05 --> Helper loaded: email_helper
INFO - 2020-03-18 11:36:05 --> Helper loaded: file_manager_helper
INFO - 2020-03-18 11:36:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-18 11:36:05 --> Parser Class Initialized
INFO - 2020-03-18 11:36:05 --> User Agent Class Initialized
INFO - 2020-03-18 11:36:05 --> Model Class Initialized
INFO - 2020-03-18 11:36:05 --> Database Driver Class Initialized
INFO - 2020-03-18 11:36:05 --> Model Class Initialized
DEBUG - 2020-03-18 11:36:05 --> Template Class Initialized
INFO - 2020-03-18 11:36:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-18 11:36:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-18 11:36:05 --> Pagination Class Initialized
DEBUG - 2020-03-18 11:36:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-18 11:36:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-18 11:36:05 --> Encryption Class Initialized
INFO - 2020-03-18 11:36:05 --> Controller Class Initialized
DEBUG - 2020-03-18 11:36:05 --> package MX_Controller Initialized
DEBUG - 2020-03-18 11:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-18 11:36:05 --> Model Class Initialized
INFO - 2020-03-18 11:36:05 --> Helper loaded: inflector_helper
DEBUG - 2020-03-18 11:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-18 11:36:05 --> blocks MX_Controller Initialized
DEBUG - 2020-03-18 11:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-18 11:36:05 --> Model Class Initialized
DEBUG - 2020-03-18 11:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-18 11:36:05 --> Model Class Initialized
DEBUG - 2020-03-18 11:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-18 11:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:06 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-18 11:36:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-18 11:36:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-18 11:36:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-18 11:36:06 --> Final output sent to browser
DEBUG - 2020-03-18 11:36:06 --> Total execution time: 1.2940
INFO - 2020-03-18 11:36:12 --> Config Class Initialized
INFO - 2020-03-18 11:36:12 --> Hooks Class Initialized
DEBUG - 2020-03-18 11:36:12 --> UTF-8 Support Enabled
INFO - 2020-03-18 11:36:12 --> Utf8 Class Initialized
INFO - 2020-03-18 11:36:12 --> URI Class Initialized
INFO - 2020-03-18 11:36:12 --> Router Class Initialized
INFO - 2020-03-18 11:36:12 --> Output Class Initialized
INFO - 2020-03-18 11:36:12 --> Security Class Initialized
DEBUG - 2020-03-18 11:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 11:36:12 --> CSRF cookie sent
INFO - 2020-03-18 11:36:12 --> CSRF token verified
INFO - 2020-03-18 11:36:12 --> Input Class Initialized
INFO - 2020-03-18 11:36:12 --> Language Class Initialized
INFO - 2020-03-18 11:36:12 --> Language Class Initialized
INFO - 2020-03-18 11:36:12 --> Config Class Initialized
INFO - 2020-03-18 11:36:12 --> Loader Class Initialized
INFO - 2020-03-18 11:36:12 --> Helper loaded: url_helper
INFO - 2020-03-18 11:36:12 --> Helper loaded: common_helper
INFO - 2020-03-18 11:36:12 --> Helper loaded: language_helper
INFO - 2020-03-18 11:36:12 --> Helper loaded: cookie_helper
INFO - 2020-03-18 11:36:12 --> Helper loaded: email_helper
INFO - 2020-03-18 11:36:12 --> Helper loaded: file_manager_helper
INFO - 2020-03-18 11:36:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-18 11:36:12 --> Parser Class Initialized
INFO - 2020-03-18 11:36:12 --> User Agent Class Initialized
INFO - 2020-03-18 11:36:12 --> Model Class Initialized
INFO - 2020-03-18 11:36:12 --> Database Driver Class Initialized
INFO - 2020-03-18 11:36:12 --> Model Class Initialized
DEBUG - 2020-03-18 11:36:12 --> Template Class Initialized
INFO - 2020-03-18 11:36:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-18 11:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-18 11:36:12 --> Pagination Class Initialized
DEBUG - 2020-03-18 11:36:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-18 11:36:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-18 11:36:12 --> Encryption Class Initialized
INFO - 2020-03-18 11:36:12 --> Controller Class Initialized
DEBUG - 2020-03-18 11:36:12 --> checkout MX_Controller Initialized
DEBUG - 2020-03-18 11:36:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-18 11:36:12 --> Model Class Initialized
INFO - 2020-03-18 11:36:12 --> Helper loaded: inflector_helper
ERROR - 2020-03-18 11:36:12 --> Could not find the language line "shopier"
DEBUG - 2020-03-18 11:36:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-18 11:36:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-18 11:36:12 --> blocks MX_Controller Initialized
DEBUG - 2020-03-18 11:36:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-18 11:36:12 --> Model Class Initialized
DEBUG - 2020-03-18 11:36:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-18 11:36:12 --> Model Class Initialized
ERROR - 2020-03-18 11:36:12 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-18 11:36:13 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-18 11:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-18 11:36:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-18 11:36:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-18 11:36:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-18 11:36:13 --> Final output sent to browser
DEBUG - 2020-03-18 11:36:13 --> Total execution time: 1.0289
INFO - 2020-03-18 11:37:04 --> Config Class Initialized
INFO - 2020-03-18 11:37:04 --> Hooks Class Initialized
DEBUG - 2020-03-18 11:37:04 --> UTF-8 Support Enabled
INFO - 2020-03-18 11:37:04 --> Utf8 Class Initialized
INFO - 2020-03-18 11:37:04 --> URI Class Initialized
INFO - 2020-03-18 11:37:04 --> Router Class Initialized
INFO - 2020-03-18 11:37:04 --> Output Class Initialized
INFO - 2020-03-18 11:37:04 --> Security Class Initialized
DEBUG - 2020-03-18 11:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-18 11:37:04 --> CSRF cookie sent
INFO - 2020-03-18 11:37:04 --> CSRF token verified
INFO - 2020-03-18 11:37:04 --> Input Class Initialized
INFO - 2020-03-18 11:37:04 --> Language Class Initialized
INFO - 2020-03-18 11:37:04 --> Language Class Initialized
INFO - 2020-03-18 11:37:04 --> Config Class Initialized
INFO - 2020-03-18 11:37:04 --> Loader Class Initialized
INFO - 2020-03-18 11:37:04 --> Helper loaded: url_helper
INFO - 2020-03-18 11:37:04 --> Helper loaded: common_helper
INFO - 2020-03-18 11:37:04 --> Helper loaded: language_helper
INFO - 2020-03-18 11:37:04 --> Helper loaded: cookie_helper
INFO - 2020-03-18 11:37:04 --> Helper loaded: email_helper
INFO - 2020-03-18 11:37:04 --> Helper loaded: file_manager_helper
INFO - 2020-03-18 11:37:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-18 11:37:04 --> Parser Class Initialized
INFO - 2020-03-18 11:37:04 --> User Agent Class Initialized
INFO - 2020-03-18 11:37:04 --> Model Class Initialized
INFO - 2020-03-18 11:37:04 --> Database Driver Class Initialized
INFO - 2020-03-18 11:37:04 --> Model Class Initialized
DEBUG - 2020-03-18 11:37:04 --> Template Class Initialized
INFO - 2020-03-18 11:37:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-18 11:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-18 11:37:04 --> Pagination Class Initialized
DEBUG - 2020-03-18 11:37:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-18 11:37:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-18 11:37:04 --> Encryption Class Initialized
INFO - 2020-03-18 11:37:04 --> Controller Class Initialized
DEBUG - 2020-03-18 11:37:04 --> checkout MX_Controller Initialized
DEBUG - 2020-03-18 11:37:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-18 11:37:04 --> Model Class Initialized
DEBUG - 2020-03-18 11:37:04 --> stripe MX_Controller Initialized
DEBUG - 2020-03-18 11:37:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-18 11:37:04 --> Could not find the language line "Your_name"
DEBUG - 2020-03-18 11:37:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-18 11:37:04 --> Final output sent to browser
DEBUG - 2020-03-18 11:37:04 --> Total execution time: 0.5077
