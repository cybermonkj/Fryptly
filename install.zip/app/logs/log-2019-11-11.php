<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-11 21:52:40 --> Config Class Initialized
INFO - 2019-11-11 21:52:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 21:52:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 21:52:40 --> Utf8 Class Initialized
INFO - 2019-11-11 21:52:40 --> URI Class Initialized
DEBUG - 2019-11-11 21:52:40 --> No URI present. Default controller set.
INFO - 2019-11-11 21:52:40 --> Router Class Initialized
INFO - 2019-11-11 21:52:40 --> Output Class Initialized
INFO - 2019-11-11 21:52:40 --> Security Class Initialized
DEBUG - 2019-11-11 21:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 21:52:40 --> CSRF cookie sent
INFO - 2019-11-11 21:52:40 --> Input Class Initialized
INFO - 2019-11-11 21:52:40 --> Language Class Initialized
INFO - 2019-11-11 21:52:40 --> Language Class Initialized
INFO - 2019-11-11 21:52:40 --> Config Class Initialized
INFO - 2019-11-11 21:52:40 --> Loader Class Initialized
INFO - 2019-11-11 21:52:40 --> Helper loaded: url_helper
INFO - 2019-11-11 21:52:41 --> Helper loaded: common_helper
INFO - 2019-11-11 21:52:41 --> Helper loaded: language_helper
INFO - 2019-11-11 21:52:41 --> Helper loaded: cookie_helper
INFO - 2019-11-11 21:52:41 --> Helper loaded: email_helper
INFO - 2019-11-11 21:52:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-11 21:52:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-11 21:52:41 --> Parser Class Initialized
INFO - 2019-11-11 21:52:41 --> User Agent Class Initialized
INFO - 2019-11-11 21:52:41 --> Model Class Initialized
INFO - 2019-11-11 21:52:41 --> Database Driver Class Initialized
INFO - 2019-11-11 21:52:41 --> Model Class Initialized
DEBUG - 2019-11-11 21:52:41 --> Template Class Initialized
INFO - 2019-11-11 21:52:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-11 21:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-11 21:52:41 --> Pagination Class Initialized
DEBUG - 2019-11-11 21:52:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-11 21:52:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-11 21:52:41 --> Encryption Class Initialized
DEBUG - 2019-11-11 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-11 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-11 21:52:41 --> Controller Class Initialized
DEBUG - 2019-11-11 21:52:41 --> pergo MX_Controller Initialized
DEBUG - 2019-11-11 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-11 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-11 21:52:41 --> Model Class Initialized
INFO - 2019-11-11 21:52:41 --> Helper loaded: inflector_helper
DEBUG - 2019-11-11 21:52:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-11 21:52:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-11 21:52:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-11 21:52:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-11 21:52:42 --> Final output sent to browser
DEBUG - 2019-11-11 21:52:42 --> Total execution time: 2.3095
INFO - 2019-11-11 21:52:48 --> Config Class Initialized
INFO - 2019-11-11 21:52:48 --> Hooks Class Initialized
DEBUG - 2019-11-11 21:52:48 --> UTF-8 Support Enabled
INFO - 2019-11-11 21:52:48 --> Utf8 Class Initialized
INFO - 2019-11-11 21:52:48 --> URI Class Initialized
INFO - 2019-11-11 21:52:48 --> Router Class Initialized
INFO - 2019-11-11 21:52:48 --> Output Class Initialized
INFO - 2019-11-11 21:52:48 --> Security Class Initialized
DEBUG - 2019-11-11 21:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 21:52:48 --> CSRF cookie sent
INFO - 2019-11-11 21:52:48 --> Input Class Initialized
INFO - 2019-11-11 21:52:48 --> Language Class Initialized
INFO - 2019-11-11 21:52:48 --> Language Class Initialized
INFO - 2019-11-11 21:52:48 --> Config Class Initialized
INFO - 2019-11-11 21:52:48 --> Loader Class Initialized
INFO - 2019-11-11 21:52:48 --> Helper loaded: url_helper
INFO - 2019-11-11 21:52:48 --> Helper loaded: common_helper
INFO - 2019-11-11 21:52:48 --> Helper loaded: language_helper
INFO - 2019-11-11 21:52:48 --> Helper loaded: cookie_helper
INFO - 2019-11-11 21:52:48 --> Helper loaded: email_helper
INFO - 2019-11-11 21:52:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-11 21:52:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-11 21:52:49 --> Parser Class Initialized
INFO - 2019-11-11 21:52:49 --> User Agent Class Initialized
INFO - 2019-11-11 21:52:49 --> Model Class Initialized
INFO - 2019-11-11 21:52:49 --> Database Driver Class Initialized
INFO - 2019-11-11 21:52:49 --> Model Class Initialized
DEBUG - 2019-11-11 21:52:49 --> Template Class Initialized
INFO - 2019-11-11 21:52:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-11 21:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-11 21:52:49 --> Pagination Class Initialized
DEBUG - 2019-11-11 21:52:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-11 21:52:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-11 21:52:49 --> Encryption Class Initialized
INFO - 2019-11-11 21:52:49 --> Controller Class Initialized
DEBUG - 2019-11-11 21:52:49 --> auth MX_Controller Initialized
DEBUG - 2019-11-11 21:52:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-11 21:52:49 --> Model Class Initialized
DEBUG - 2019-11-11 21:52:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-11 21:52:49 --> Helper loaded: inflector_helper
DEBUG - 2019-11-11 21:52:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-11 21:52:49 --> pergo MX_Controller Initialized
DEBUG - 2019-11-11 21:52:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-11 21:52:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-11 21:52:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-11 21:52:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-11 21:52:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-11 21:52:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-11 21:52:49 --> Final output sent to browser
DEBUG - 2019-11-11 21:52:49 --> Total execution time: 0.8129
INFO - 2019-11-11 21:52:52 --> Config Class Initialized
INFO - 2019-11-11 21:52:52 --> Hooks Class Initialized
DEBUG - 2019-11-11 21:52:52 --> UTF-8 Support Enabled
INFO - 2019-11-11 21:52:52 --> Utf8 Class Initialized
INFO - 2019-11-11 21:52:52 --> URI Class Initialized
INFO - 2019-11-11 21:52:52 --> Router Class Initialized
INFO - 2019-11-11 21:52:52 --> Output Class Initialized
INFO - 2019-11-11 21:52:52 --> Security Class Initialized
DEBUG - 2019-11-11 21:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 21:52:52 --> CSRF cookie sent
INFO - 2019-11-11 21:52:52 --> CSRF token verified
INFO - 2019-11-11 21:52:52 --> Input Class Initialized
INFO - 2019-11-11 21:52:52 --> Language Class Initialized
INFO - 2019-11-11 21:52:52 --> Language Class Initialized
INFO - 2019-11-11 21:52:52 --> Config Class Initialized
INFO - 2019-11-11 21:52:52 --> Loader Class Initialized
INFO - 2019-11-11 21:52:52 --> Helper loaded: url_helper
INFO - 2019-11-11 21:52:52 --> Helper loaded: common_helper
INFO - 2019-11-11 21:52:52 --> Helper loaded: language_helper
INFO - 2019-11-11 21:52:52 --> Helper loaded: cookie_helper
INFO - 2019-11-11 21:52:52 --> Helper loaded: email_helper
INFO - 2019-11-11 21:52:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-11 21:52:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-11 21:52:52 --> Parser Class Initialized
INFO - 2019-11-11 21:52:52 --> User Agent Class Initialized
INFO - 2019-11-11 21:52:52 --> Model Class Initialized
INFO - 2019-11-11 21:52:52 --> Database Driver Class Initialized
INFO - 2019-11-11 21:52:52 --> Model Class Initialized
DEBUG - 2019-11-11 21:52:52 --> Template Class Initialized
INFO - 2019-11-11 21:52:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-11 21:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-11 21:52:52 --> Pagination Class Initialized
DEBUG - 2019-11-11 21:52:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-11 21:52:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-11 21:52:52 --> Encryption Class Initialized
INFO - 2019-11-11 21:52:52 --> Controller Class Initialized
DEBUG - 2019-11-11 21:52:52 --> auth MX_Controller Initialized
DEBUG - 2019-11-11 21:52:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-11 21:52:52 --> Model Class Initialized
INFO - 2019-11-11 21:52:57 --> Config Class Initialized
INFO - 2019-11-11 21:52:57 --> Hooks Class Initialized
DEBUG - 2019-11-11 21:52:57 --> UTF-8 Support Enabled
INFO - 2019-11-11 21:52:57 --> Utf8 Class Initialized
INFO - 2019-11-11 21:52:57 --> URI Class Initialized
INFO - 2019-11-11 21:52:57 --> Router Class Initialized
INFO - 2019-11-11 21:52:57 --> Output Class Initialized
INFO - 2019-11-11 21:52:57 --> Security Class Initialized
DEBUG - 2019-11-11 21:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 21:52:57 --> CSRF cookie sent
INFO - 2019-11-11 21:52:57 --> Input Class Initialized
INFO - 2019-11-11 21:52:57 --> Language Class Initialized
INFO - 2019-11-11 21:52:57 --> Language Class Initialized
INFO - 2019-11-11 21:52:58 --> Config Class Initialized
INFO - 2019-11-11 21:52:58 --> Loader Class Initialized
INFO - 2019-11-11 21:52:58 --> Helper loaded: url_helper
INFO - 2019-11-11 21:52:58 --> Helper loaded: common_helper
INFO - 2019-11-11 21:52:58 --> Helper loaded: language_helper
INFO - 2019-11-11 21:52:58 --> Helper loaded: cookie_helper
INFO - 2019-11-11 21:52:58 --> Helper loaded: email_helper
INFO - 2019-11-11 21:52:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-11 21:52:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-11 21:52:58 --> Parser Class Initialized
INFO - 2019-11-11 21:52:58 --> User Agent Class Initialized
INFO - 2019-11-11 21:52:58 --> Model Class Initialized
INFO - 2019-11-11 21:52:58 --> Database Driver Class Initialized
INFO - 2019-11-11 21:52:58 --> Model Class Initialized
DEBUG - 2019-11-11 21:52:58 --> Template Class Initialized
INFO - 2019-11-11 21:52:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-11 21:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-11 21:52:58 --> Pagination Class Initialized
DEBUG - 2019-11-11 21:52:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-11 21:52:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-11 21:52:58 --> Encryption Class Initialized
INFO - 2019-11-11 21:52:58 --> Controller Class Initialized
DEBUG - 2019-11-11 21:52:58 --> statistics MX_Controller Initialized
DEBUG - 2019-11-11 21:52:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-11 21:52:58 --> Model Class Initialized
ERROR - 2019-11-11 21:52:58 --> Could not find the language line "Pending"
ERROR - 2019-11-11 21:52:58 --> Could not find the language line "Pending"
INFO - 2019-11-11 21:52:58 --> Helper loaded: inflector_helper
ERROR - 2019-11-11 21:52:58 --> Could not find the language line "total_orders"
ERROR - 2019-11-11 21:52:58 --> Could not find the language line "total_orders"
ERROR - 2019-11-11 21:52:58 --> Could not find the language line "Pending"
DEBUG - 2019-11-11 21:52:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-11 21:52:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-11 21:52:58 --> blocks MX_Controller Initialized
DEBUG - 2019-11-11 21:52:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-11 21:52:58 --> Model Class Initialized
DEBUG - 2019-11-11 21:52:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-11 21:52:58 --> Model Class Initialized
DEBUG - 2019-11-11 21:52:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-11 21:52:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-11 21:52:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-11 21:52:58 --> Final output sent to browser
DEBUG - 2019-11-11 21:52:58 --> Total execution time: 1.1538
