<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-09 08:44:30 --> Config Class Initialized
INFO - 2019-12-09 08:44:30 --> Hooks Class Initialized
DEBUG - 2019-12-09 08:44:30 --> UTF-8 Support Enabled
INFO - 2019-12-09 08:44:30 --> Utf8 Class Initialized
INFO - 2019-12-09 08:44:30 --> URI Class Initialized
DEBUG - 2019-12-09 08:44:30 --> No URI present. Default controller set.
INFO - 2019-12-09 08:44:30 --> Router Class Initialized
INFO - 2019-12-09 08:44:30 --> Output Class Initialized
INFO - 2019-12-09 08:44:31 --> Security Class Initialized
DEBUG - 2019-12-09 08:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 08:44:31 --> CSRF cookie sent
INFO - 2019-12-09 08:44:31 --> Input Class Initialized
INFO - 2019-12-09 08:44:31 --> Language Class Initialized
INFO - 2019-12-09 08:44:31 --> Language Class Initialized
INFO - 2019-12-09 08:44:31 --> Config Class Initialized
INFO - 2019-12-09 08:44:31 --> Loader Class Initialized
INFO - 2019-12-09 08:44:31 --> Helper loaded: url_helper
INFO - 2019-12-09 08:44:31 --> Helper loaded: common_helper
INFO - 2019-12-09 08:44:31 --> Helper loaded: language_helper
INFO - 2019-12-09 08:44:31 --> Helper loaded: cookie_helper
INFO - 2019-12-09 08:44:31 --> Helper loaded: email_helper
INFO - 2019-12-09 08:44:31 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 08:44:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 08:44:31 --> Parser Class Initialized
INFO - 2019-12-09 08:44:31 --> User Agent Class Initialized
INFO - 2019-12-09 08:44:31 --> Model Class Initialized
INFO - 2019-12-09 08:44:31 --> Database Driver Class Initialized
INFO - 2019-12-09 08:44:31 --> Model Class Initialized
DEBUG - 2019-12-09 08:44:31 --> Template Class Initialized
INFO - 2019-12-09 08:44:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 08:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 08:44:31 --> Pagination Class Initialized
DEBUG - 2019-12-09 08:44:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 08:44:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 08:44:31 --> Encryption Class Initialized
DEBUG - 2019-12-09 08:44:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 08:44:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-09 08:44:31 --> Controller Class Initialized
DEBUG - 2019-12-09 08:44:31 --> pergo MX_Controller Initialized
DEBUG - 2019-12-09 08:44:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 08:44:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-09 08:44:31 --> Model Class Initialized
INFO - 2019-12-09 08:44:31 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 08:44:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-09 08:44:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-09 08:44:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-09 08:44:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-09 08:44:31 --> Final output sent to browser
DEBUG - 2019-12-09 08:44:31 --> Total execution time: 1.2259
INFO - 2019-12-09 08:44:38 --> Config Class Initialized
INFO - 2019-12-09 08:44:38 --> Hooks Class Initialized
DEBUG - 2019-12-09 08:44:38 --> UTF-8 Support Enabled
INFO - 2019-12-09 08:44:38 --> Utf8 Class Initialized
INFO - 2019-12-09 08:44:38 --> URI Class Initialized
INFO - 2019-12-09 08:44:38 --> Router Class Initialized
INFO - 2019-12-09 08:44:38 --> Output Class Initialized
INFO - 2019-12-09 08:44:38 --> Security Class Initialized
DEBUG - 2019-12-09 08:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 08:44:38 --> CSRF cookie sent
INFO - 2019-12-09 08:44:38 --> Input Class Initialized
INFO - 2019-12-09 08:44:38 --> Language Class Initialized
INFO - 2019-12-09 08:44:38 --> Language Class Initialized
INFO - 2019-12-09 08:44:38 --> Config Class Initialized
INFO - 2019-12-09 08:44:38 --> Loader Class Initialized
INFO - 2019-12-09 08:44:38 --> Helper loaded: url_helper
INFO - 2019-12-09 08:44:38 --> Helper loaded: common_helper
INFO - 2019-12-09 08:44:38 --> Helper loaded: language_helper
INFO - 2019-12-09 08:44:38 --> Helper loaded: cookie_helper
INFO - 2019-12-09 08:44:38 --> Helper loaded: email_helper
INFO - 2019-12-09 08:44:38 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 08:44:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 08:44:38 --> Parser Class Initialized
INFO - 2019-12-09 08:44:38 --> User Agent Class Initialized
DEBUG - 2019-12-09 08:44:38 --> Template Class Initialized
INFO - 2019-12-09 08:44:38 --> Database Driver Class Initialized
INFO - 2019-12-09 08:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 08:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 08:44:38 --> Pagination Class Initialized
DEBUG - 2019-12-09 08:44:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 08:44:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 08:44:39 --> Encryption Class Initialized
INFO - 2019-12-09 08:44:39 --> Controller Class Initialized
DEBUG - 2019-12-09 08:44:39 --> payop MX_Controller Initialized
INFO - 2019-12-09 08:44:39 --> Model Class Initialized
INFO - 2019-12-09 08:44:39 --> Model Class Initialized
INFO - 2019-12-09 08:44:39 --> Model Class Initialized
ERROR - 2019-12-09 08:44:40 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 08:44:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 10:29:53 --> Config Class Initialized
INFO - 2019-12-09 10:29:53 --> Hooks Class Initialized
DEBUG - 2019-12-09 10:29:53 --> UTF-8 Support Enabled
INFO - 2019-12-09 10:29:53 --> Utf8 Class Initialized
INFO - 2019-12-09 10:29:53 --> URI Class Initialized
DEBUG - 2019-12-09 10:29:53 --> No URI present. Default controller set.
INFO - 2019-12-09 10:29:53 --> Router Class Initialized
INFO - 2019-12-09 10:29:53 --> Output Class Initialized
INFO - 2019-12-09 10:29:53 --> Security Class Initialized
DEBUG - 2019-12-09 10:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 10:29:53 --> CSRF cookie sent
INFO - 2019-12-09 10:29:53 --> Input Class Initialized
INFO - 2019-12-09 10:29:53 --> Language Class Initialized
INFO - 2019-12-09 10:29:54 --> Language Class Initialized
INFO - 2019-12-09 10:29:54 --> Config Class Initialized
INFO - 2019-12-09 10:29:54 --> Loader Class Initialized
INFO - 2019-12-09 10:29:54 --> Helper loaded: url_helper
INFO - 2019-12-09 10:29:54 --> Helper loaded: common_helper
INFO - 2019-12-09 10:29:54 --> Helper loaded: language_helper
INFO - 2019-12-09 10:29:54 --> Helper loaded: cookie_helper
INFO - 2019-12-09 10:29:54 --> Helper loaded: email_helper
INFO - 2019-12-09 10:29:54 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 10:29:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 10:29:54 --> Parser Class Initialized
INFO - 2019-12-09 10:29:54 --> User Agent Class Initialized
INFO - 2019-12-09 10:29:54 --> Model Class Initialized
INFO - 2019-12-09 10:29:54 --> Database Driver Class Initialized
INFO - 2019-12-09 10:29:54 --> Model Class Initialized
DEBUG - 2019-12-09 10:29:54 --> Template Class Initialized
INFO - 2019-12-09 10:29:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 10:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 10:29:54 --> Pagination Class Initialized
DEBUG - 2019-12-09 10:29:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 10:29:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 10:29:54 --> Encryption Class Initialized
DEBUG - 2019-12-09 10:29:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 10:29:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-09 10:29:54 --> Controller Class Initialized
DEBUG - 2019-12-09 10:29:54 --> pergo MX_Controller Initialized
DEBUG - 2019-12-09 10:29:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 10:29:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-09 10:29:54 --> Model Class Initialized
INFO - 2019-12-09 10:29:54 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 10:29:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-09 10:29:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-09 10:29:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-09 10:29:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-09 10:29:55 --> Final output sent to browser
DEBUG - 2019-12-09 10:29:55 --> Total execution time: 1.7318
INFO - 2019-12-09 14:07:57 --> Config Class Initialized
INFO - 2019-12-09 14:07:57 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:07:57 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:07:57 --> Utf8 Class Initialized
INFO - 2019-12-09 14:07:57 --> URI Class Initialized
DEBUG - 2019-12-09 14:07:57 --> No URI present. Default controller set.
INFO - 2019-12-09 14:07:57 --> Router Class Initialized
INFO - 2019-12-09 14:07:57 --> Output Class Initialized
INFO - 2019-12-09 14:07:57 --> Security Class Initialized
DEBUG - 2019-12-09 14:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:07:57 --> CSRF cookie sent
INFO - 2019-12-09 14:07:57 --> Input Class Initialized
INFO - 2019-12-09 14:07:57 --> Language Class Initialized
INFO - 2019-12-09 14:07:57 --> Language Class Initialized
INFO - 2019-12-09 14:07:57 --> Config Class Initialized
INFO - 2019-12-09 14:07:57 --> Loader Class Initialized
INFO - 2019-12-09 14:07:57 --> Helper loaded: url_helper
INFO - 2019-12-09 14:07:57 --> Helper loaded: common_helper
INFO - 2019-12-09 14:07:57 --> Helper loaded: language_helper
INFO - 2019-12-09 14:07:57 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:07:57 --> Helper loaded: email_helper
INFO - 2019-12-09 14:07:57 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:07:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:07:57 --> Parser Class Initialized
INFO - 2019-12-09 14:07:57 --> User Agent Class Initialized
INFO - 2019-12-09 14:07:57 --> Model Class Initialized
INFO - 2019-12-09 14:07:57 --> Database Driver Class Initialized
INFO - 2019-12-09 14:07:57 --> Model Class Initialized
DEBUG - 2019-12-09 14:07:57 --> Template Class Initialized
INFO - 2019-12-09 14:07:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:07:57 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:07:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:07:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:07:58 --> Encryption Class Initialized
DEBUG - 2019-12-09 14:07:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 14:07:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-09 14:07:58 --> Controller Class Initialized
DEBUG - 2019-12-09 14:07:58 --> pergo MX_Controller Initialized
DEBUG - 2019-12-09 14:07:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 14:07:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-09 14:07:58 --> Model Class Initialized
INFO - 2019-12-09 14:07:58 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 14:07:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-09 14:07:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-09 14:07:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-09 14:07:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-09 14:07:58 --> Final output sent to browser
DEBUG - 2019-12-09 14:07:58 --> Total execution time: 0.5812
INFO - 2019-12-09 14:09:29 --> Config Class Initialized
INFO - 2019-12-09 14:09:29 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:09:29 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:09:29 --> Utf8 Class Initialized
INFO - 2019-12-09 14:09:30 --> URI Class Initialized
INFO - 2019-12-09 14:09:30 --> Router Class Initialized
INFO - 2019-12-09 14:09:30 --> Output Class Initialized
INFO - 2019-12-09 14:09:30 --> Security Class Initialized
DEBUG - 2019-12-09 14:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:09:30 --> CSRF cookie sent
INFO - 2019-12-09 14:09:30 --> Input Class Initialized
INFO - 2019-12-09 14:09:30 --> Language Class Initialized
INFO - 2019-12-09 14:09:30 --> Language Class Initialized
INFO - 2019-12-09 14:09:30 --> Config Class Initialized
INFO - 2019-12-09 14:09:30 --> Loader Class Initialized
INFO - 2019-12-09 14:09:30 --> Helper loaded: url_helper
INFO - 2019-12-09 14:09:30 --> Helper loaded: common_helper
INFO - 2019-12-09 14:09:30 --> Helper loaded: language_helper
INFO - 2019-12-09 14:09:30 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:09:30 --> Helper loaded: email_helper
INFO - 2019-12-09 14:09:30 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:09:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:09:30 --> Parser Class Initialized
INFO - 2019-12-09 14:09:30 --> User Agent Class Initialized
INFO - 2019-12-09 14:09:30 --> Model Class Initialized
INFO - 2019-12-09 14:09:30 --> Database Driver Class Initialized
INFO - 2019-12-09 14:09:30 --> Model Class Initialized
DEBUG - 2019-12-09 14:09:30 --> Template Class Initialized
INFO - 2019-12-09 14:09:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:09:30 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:09:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:09:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:09:30 --> Encryption Class Initialized
INFO - 2019-12-09 14:09:30 --> Controller Class Initialized
DEBUG - 2019-12-09 14:09:30 --> auth MX_Controller Initialized
DEBUG - 2019-12-09 14:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-09 14:09:30 --> Model Class Initialized
DEBUG - 2019-12-09 14:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-09 14:09:30 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 14:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-12-09 14:09:30 --> pergo MX_Controller Initialized
DEBUG - 2019-12-09 14:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 14:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-12-09 14:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-09 14:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-09 14:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-12-09 14:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-09 14:09:30 --> Final output sent to browser
DEBUG - 2019-12-09 14:09:30 --> Total execution time: 0.7518
INFO - 2019-12-09 14:09:33 --> Config Class Initialized
INFO - 2019-12-09 14:09:33 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:09:33 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:09:33 --> Utf8 Class Initialized
INFO - 2019-12-09 14:09:33 --> URI Class Initialized
INFO - 2019-12-09 14:09:33 --> Router Class Initialized
INFO - 2019-12-09 14:09:33 --> Output Class Initialized
INFO - 2019-12-09 14:09:33 --> Security Class Initialized
DEBUG - 2019-12-09 14:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:09:33 --> CSRF cookie sent
INFO - 2019-12-09 14:09:33 --> CSRF token verified
INFO - 2019-12-09 14:09:34 --> Input Class Initialized
INFO - 2019-12-09 14:09:34 --> Language Class Initialized
INFO - 2019-12-09 14:09:34 --> Language Class Initialized
INFO - 2019-12-09 14:09:34 --> Config Class Initialized
INFO - 2019-12-09 14:09:34 --> Loader Class Initialized
INFO - 2019-12-09 14:09:34 --> Helper loaded: url_helper
INFO - 2019-12-09 14:09:34 --> Helper loaded: common_helper
INFO - 2019-12-09 14:09:34 --> Helper loaded: language_helper
INFO - 2019-12-09 14:09:34 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:09:34 --> Helper loaded: email_helper
INFO - 2019-12-09 14:09:34 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:09:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:09:34 --> Parser Class Initialized
INFO - 2019-12-09 14:09:34 --> User Agent Class Initialized
INFO - 2019-12-09 14:09:34 --> Model Class Initialized
INFO - 2019-12-09 14:09:34 --> Database Driver Class Initialized
INFO - 2019-12-09 14:09:34 --> Model Class Initialized
DEBUG - 2019-12-09 14:09:34 --> Template Class Initialized
INFO - 2019-12-09 14:09:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:09:34 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:09:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:09:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:09:34 --> Encryption Class Initialized
INFO - 2019-12-09 14:09:34 --> Controller Class Initialized
DEBUG - 2019-12-09 14:09:34 --> auth MX_Controller Initialized
DEBUG - 2019-12-09 14:09:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-09 14:09:34 --> Model Class Initialized
INFO - 2019-12-09 14:09:38 --> Config Class Initialized
INFO - 2019-12-09 14:09:38 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:09:38 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:09:38 --> Utf8 Class Initialized
INFO - 2019-12-09 14:09:38 --> URI Class Initialized
INFO - 2019-12-09 14:09:38 --> Router Class Initialized
INFO - 2019-12-09 14:09:38 --> Output Class Initialized
INFO - 2019-12-09 14:09:39 --> Security Class Initialized
DEBUG - 2019-12-09 14:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:09:39 --> CSRF cookie sent
INFO - 2019-12-09 14:09:39 --> Input Class Initialized
INFO - 2019-12-09 14:09:39 --> Language Class Initialized
INFO - 2019-12-09 14:09:39 --> Language Class Initialized
INFO - 2019-12-09 14:09:39 --> Config Class Initialized
INFO - 2019-12-09 14:09:39 --> Loader Class Initialized
INFO - 2019-12-09 14:09:39 --> Helper loaded: url_helper
INFO - 2019-12-09 14:09:39 --> Helper loaded: common_helper
INFO - 2019-12-09 14:09:39 --> Helper loaded: language_helper
INFO - 2019-12-09 14:09:39 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:09:39 --> Helper loaded: email_helper
INFO - 2019-12-09 14:09:39 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:09:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:09:39 --> Parser Class Initialized
INFO - 2019-12-09 14:09:39 --> User Agent Class Initialized
INFO - 2019-12-09 14:09:39 --> Model Class Initialized
INFO - 2019-12-09 14:09:39 --> Database Driver Class Initialized
INFO - 2019-12-09 14:09:39 --> Model Class Initialized
DEBUG - 2019-12-09 14:09:39 --> Template Class Initialized
INFO - 2019-12-09 14:09:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:09:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:09:39 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:09:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:09:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:09:39 --> Encryption Class Initialized
INFO - 2019-12-09 14:09:39 --> Controller Class Initialized
DEBUG - 2019-12-09 14:09:39 --> statistics MX_Controller Initialized
DEBUG - 2019-12-09 14:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-09 14:09:39 --> Model Class Initialized
ERROR - 2019-12-09 14:09:39 --> Could not find the language line "Pending"
ERROR - 2019-12-09 14:09:39 --> Could not find the language line "Pending"
INFO - 2019-12-09 14:09:39 --> Helper loaded: inflector_helper
ERROR - 2019-12-09 14:09:39 --> Could not find the language line "total_orders"
ERROR - 2019-12-09 14:09:39 --> Could not find the language line "total_orders"
ERROR - 2019-12-09 14:09:39 --> Could not find the language line "Pending"
DEBUG - 2019-12-09 14:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-12-09 14:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 14:09:39 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 14:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 14:09:39 --> Model Class Initialized
DEBUG - 2019-12-09 14:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 14:09:39 --> Model Class Initialized
DEBUG - 2019-12-09 14:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 14:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 14:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 14:09:39 --> Final output sent to browser
DEBUG - 2019-12-09 14:09:39 --> Total execution time: 1.0313
INFO - 2019-12-09 14:11:52 --> Config Class Initialized
INFO - 2019-12-09 14:11:52 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:11:53 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:11:53 --> Utf8 Class Initialized
INFO - 2019-12-09 14:11:53 --> URI Class Initialized
INFO - 2019-12-09 14:11:53 --> Router Class Initialized
INFO - 2019-12-09 14:11:53 --> Output Class Initialized
INFO - 2019-12-09 14:11:53 --> Security Class Initialized
DEBUG - 2019-12-09 14:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:11:53 --> CSRF cookie sent
INFO - 2019-12-09 14:11:53 --> Input Class Initialized
INFO - 2019-12-09 14:11:53 --> Language Class Initialized
INFO - 2019-12-09 14:11:53 --> Language Class Initialized
INFO - 2019-12-09 14:11:53 --> Config Class Initialized
INFO - 2019-12-09 14:11:53 --> Loader Class Initialized
INFO - 2019-12-09 14:11:53 --> Helper loaded: url_helper
INFO - 2019-12-09 14:11:53 --> Helper loaded: common_helper
INFO - 2019-12-09 14:11:53 --> Helper loaded: language_helper
INFO - 2019-12-09 14:11:53 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:11:53 --> Helper loaded: email_helper
INFO - 2019-12-09 14:11:53 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:11:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:11:53 --> Parser Class Initialized
INFO - 2019-12-09 14:11:53 --> User Agent Class Initialized
INFO - 2019-12-09 14:11:53 --> Model Class Initialized
INFO - 2019-12-09 14:11:53 --> Database Driver Class Initialized
INFO - 2019-12-09 14:11:53 --> Model Class Initialized
DEBUG - 2019-12-09 14:11:53 --> Template Class Initialized
INFO - 2019-12-09 14:11:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:11:53 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:11:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:11:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:11:53 --> Encryption Class Initialized
INFO - 2019-12-09 14:11:53 --> Controller Class Initialized
DEBUG - 2019-12-09 14:11:53 --> transactions MX_Controller Initialized
DEBUG - 2019-12-09 14:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-09 14:11:53 --> Model Class Initialized
ERROR - 2019-12-09 14:11:53 --> Could not find the language line "order_id"
INFO - 2019-12-09 14:11:53 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 14:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-09 14:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 14:11:53 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 14:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 14:11:53 --> Model Class Initialized
DEBUG - 2019-12-09 14:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 14:11:53 --> Model Class Initialized
DEBUG - 2019-12-09 14:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 14:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 14:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 14:11:53 --> Final output sent to browser
DEBUG - 2019-12-09 14:11:53 --> Total execution time: 0.6218
INFO - 2019-12-09 14:14:28 --> Config Class Initialized
INFO - 2019-12-09 14:14:28 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:14:28 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:14:28 --> Utf8 Class Initialized
INFO - 2019-12-09 14:14:28 --> URI Class Initialized
INFO - 2019-12-09 14:14:28 --> Router Class Initialized
INFO - 2019-12-09 14:14:28 --> Output Class Initialized
INFO - 2019-12-09 14:14:28 --> Security Class Initialized
DEBUG - 2019-12-09 14:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:14:28 --> CSRF cookie sent
INFO - 2019-12-09 14:14:28 --> Input Class Initialized
INFO - 2019-12-09 14:14:28 --> Language Class Initialized
INFO - 2019-12-09 14:14:28 --> Language Class Initialized
INFO - 2019-12-09 14:14:28 --> Config Class Initialized
INFO - 2019-12-09 14:14:28 --> Loader Class Initialized
INFO - 2019-12-09 14:14:28 --> Helper loaded: url_helper
INFO - 2019-12-09 14:14:28 --> Helper loaded: common_helper
INFO - 2019-12-09 14:14:28 --> Helper loaded: language_helper
INFO - 2019-12-09 14:14:28 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:14:28 --> Helper loaded: email_helper
INFO - 2019-12-09 14:14:28 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:14:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:14:28 --> Parser Class Initialized
INFO - 2019-12-09 14:14:28 --> User Agent Class Initialized
DEBUG - 2019-12-09 14:14:28 --> Template Class Initialized
INFO - 2019-12-09 14:14:28 --> Database Driver Class Initialized
INFO - 2019-12-09 14:14:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:14:29 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:14:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:14:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:14:29 --> Encryption Class Initialized
INFO - 2019-12-09 14:14:29 --> Controller Class Initialized
DEBUG - 2019-12-09 14:14:29 --> payop MX_Controller Initialized
INFO - 2019-12-09 14:14:29 --> Model Class Initialized
INFO - 2019-12-09 14:14:29 --> Model Class Initialized
INFO - 2019-12-09 14:14:29 --> Model Class Initialized
ERROR - 2019-12-09 14:14:30 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 14:14:30 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 14:15:09 --> Config Class Initialized
INFO - 2019-12-09 14:15:09 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:15:09 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:15:09 --> Utf8 Class Initialized
INFO - 2019-12-09 14:15:09 --> URI Class Initialized
INFO - 2019-12-09 14:15:09 --> Router Class Initialized
INFO - 2019-12-09 14:15:09 --> Output Class Initialized
INFO - 2019-12-09 14:15:09 --> Security Class Initialized
DEBUG - 2019-12-09 14:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:15:09 --> CSRF cookie sent
INFO - 2019-12-09 14:15:09 --> Input Class Initialized
INFO - 2019-12-09 14:15:10 --> Language Class Initialized
INFO - 2019-12-09 14:15:10 --> Language Class Initialized
INFO - 2019-12-09 14:15:10 --> Config Class Initialized
INFO - 2019-12-09 14:15:10 --> Loader Class Initialized
INFO - 2019-12-09 14:15:10 --> Helper loaded: url_helper
INFO - 2019-12-09 14:15:10 --> Helper loaded: common_helper
INFO - 2019-12-09 14:15:10 --> Helper loaded: language_helper
INFO - 2019-12-09 14:15:10 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:15:10 --> Helper loaded: email_helper
INFO - 2019-12-09 14:15:10 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:15:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:15:10 --> Parser Class Initialized
INFO - 2019-12-09 14:15:10 --> User Agent Class Initialized
DEBUG - 2019-12-09 14:15:10 --> Template Class Initialized
INFO - 2019-12-09 14:15:10 --> Database Driver Class Initialized
INFO - 2019-12-09 14:15:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:15:10 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:15:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:15:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:15:10 --> Encryption Class Initialized
INFO - 2019-12-09 14:15:10 --> Controller Class Initialized
DEBUG - 2019-12-09 14:15:10 --> payop MX_Controller Initialized
INFO - 2019-12-09 14:15:10 --> Model Class Initialized
INFO - 2019-12-09 14:15:10 --> Model Class Initialized
INFO - 2019-12-09 14:15:10 --> Model Class Initialized
ERROR - 2019-12-09 14:15:11 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 14:15:11 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 14:29:34 --> Config Class Initialized
INFO - 2019-12-09 14:29:34 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:29:34 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:29:34 --> Utf8 Class Initialized
INFO - 2019-12-09 14:29:34 --> URI Class Initialized
INFO - 2019-12-09 14:29:34 --> Router Class Initialized
INFO - 2019-12-09 14:29:34 --> Output Class Initialized
INFO - 2019-12-09 14:29:34 --> Security Class Initialized
DEBUG - 2019-12-09 14:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:29:34 --> CSRF cookie sent
INFO - 2019-12-09 14:29:34 --> Input Class Initialized
INFO - 2019-12-09 14:29:34 --> Language Class Initialized
INFO - 2019-12-09 14:29:34 --> Language Class Initialized
INFO - 2019-12-09 14:29:34 --> Config Class Initialized
INFO - 2019-12-09 14:29:34 --> Loader Class Initialized
INFO - 2019-12-09 14:29:34 --> Helper loaded: url_helper
INFO - 2019-12-09 14:29:34 --> Helper loaded: common_helper
INFO - 2019-12-09 14:29:34 --> Helper loaded: language_helper
INFO - 2019-12-09 14:29:35 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:29:35 --> Helper loaded: email_helper
INFO - 2019-12-09 14:29:35 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:29:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:29:35 --> Parser Class Initialized
INFO - 2019-12-09 14:29:35 --> User Agent Class Initialized
DEBUG - 2019-12-09 14:29:35 --> Template Class Initialized
INFO - 2019-12-09 14:29:35 --> Database Driver Class Initialized
INFO - 2019-12-09 14:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:29:35 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:29:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:29:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:29:35 --> Encryption Class Initialized
INFO - 2019-12-09 14:29:35 --> Controller Class Initialized
DEBUG - 2019-12-09 14:29:35 --> payop MX_Controller Initialized
INFO - 2019-12-09 14:29:35 --> Model Class Initialized
INFO - 2019-12-09 14:29:35 --> Model Class Initialized
INFO - 2019-12-09 14:29:35 --> Model Class Initialized
ERROR - 2019-12-09 14:29:37 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 14:29:37 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 14:32:12 --> Config Class Initialized
INFO - 2019-12-09 14:32:12 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:32:12 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:32:12 --> Utf8 Class Initialized
INFO - 2019-12-09 14:32:12 --> URI Class Initialized
INFO - 2019-12-09 14:32:12 --> Router Class Initialized
INFO - 2019-12-09 14:32:12 --> Output Class Initialized
INFO - 2019-12-09 14:32:12 --> Security Class Initialized
DEBUG - 2019-12-09 14:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:32:12 --> CSRF cookie sent
INFO - 2019-12-09 14:32:12 --> Input Class Initialized
INFO - 2019-12-09 14:32:12 --> Language Class Initialized
INFO - 2019-12-09 14:32:12 --> Language Class Initialized
INFO - 2019-12-09 14:32:12 --> Config Class Initialized
INFO - 2019-12-09 14:32:12 --> Loader Class Initialized
INFO - 2019-12-09 14:32:12 --> Helper loaded: url_helper
INFO - 2019-12-09 14:32:12 --> Helper loaded: common_helper
INFO - 2019-12-09 14:32:12 --> Helper loaded: language_helper
INFO - 2019-12-09 14:32:12 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:32:12 --> Helper loaded: email_helper
INFO - 2019-12-09 14:32:12 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:32:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:32:12 --> Parser Class Initialized
INFO - 2019-12-09 14:32:12 --> User Agent Class Initialized
DEBUG - 2019-12-09 14:32:12 --> Template Class Initialized
INFO - 2019-12-09 14:32:12 --> Database Driver Class Initialized
INFO - 2019-12-09 14:32:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:32:12 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:32:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:32:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:32:12 --> Encryption Class Initialized
INFO - 2019-12-09 14:32:12 --> Controller Class Initialized
DEBUG - 2019-12-09 14:32:12 --> payop MX_Controller Initialized
INFO - 2019-12-09 14:32:12 --> Model Class Initialized
INFO - 2019-12-09 14:32:12 --> Model Class Initialized
INFO - 2019-12-09 14:32:12 --> Model Class Initialized
ERROR - 2019-12-09 14:32:14 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 14:32:14 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 14:37:05 --> Config Class Initialized
INFO - 2019-12-09 14:37:05 --> Hooks Class Initialized
DEBUG - 2019-12-09 14:37:05 --> UTF-8 Support Enabled
INFO - 2019-12-09 14:37:05 --> Utf8 Class Initialized
INFO - 2019-12-09 14:37:05 --> URI Class Initialized
INFO - 2019-12-09 14:37:05 --> Router Class Initialized
INFO - 2019-12-09 14:37:05 --> Output Class Initialized
INFO - 2019-12-09 14:37:05 --> Security Class Initialized
DEBUG - 2019-12-09 14:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 14:37:05 --> CSRF cookie sent
INFO - 2019-12-09 14:37:05 --> Input Class Initialized
INFO - 2019-12-09 14:37:05 --> Language Class Initialized
INFO - 2019-12-09 14:37:05 --> Language Class Initialized
INFO - 2019-12-09 14:37:05 --> Config Class Initialized
INFO - 2019-12-09 14:37:05 --> Loader Class Initialized
INFO - 2019-12-09 14:37:05 --> Helper loaded: url_helper
INFO - 2019-12-09 14:37:05 --> Helper loaded: common_helper
INFO - 2019-12-09 14:37:05 --> Helper loaded: language_helper
INFO - 2019-12-09 14:37:05 --> Helper loaded: cookie_helper
INFO - 2019-12-09 14:37:05 --> Helper loaded: email_helper
INFO - 2019-12-09 14:37:05 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 14:37:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 14:37:05 --> Parser Class Initialized
INFO - 2019-12-09 14:37:05 --> User Agent Class Initialized
DEBUG - 2019-12-09 14:37:05 --> Template Class Initialized
INFO - 2019-12-09 14:37:05 --> Database Driver Class Initialized
INFO - 2019-12-09 14:37:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 14:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 14:37:05 --> Pagination Class Initialized
DEBUG - 2019-12-09 14:37:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 14:37:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 14:37:05 --> Encryption Class Initialized
INFO - 2019-12-09 14:37:05 --> Controller Class Initialized
DEBUG - 2019-12-09 14:37:05 --> payop MX_Controller Initialized
INFO - 2019-12-09 14:37:05 --> Model Class Initialized
INFO - 2019-12-09 14:37:05 --> Model Class Initialized
INFO - 2019-12-09 14:37:06 --> Model Class Initialized
ERROR - 2019-12-09 14:37:08 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 14:37:08 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:02:40 --> Config Class Initialized
INFO - 2019-12-09 15:02:40 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:02:40 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:02:40 --> Utf8 Class Initialized
INFO - 2019-12-09 15:02:40 --> URI Class Initialized
INFO - 2019-12-09 15:02:40 --> Router Class Initialized
INFO - 2019-12-09 15:02:40 --> Output Class Initialized
INFO - 2019-12-09 15:02:40 --> Security Class Initialized
DEBUG - 2019-12-09 15:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:02:40 --> CSRF cookie sent
INFO - 2019-12-09 15:02:40 --> Input Class Initialized
INFO - 2019-12-09 15:02:40 --> Language Class Initialized
INFO - 2019-12-09 15:02:40 --> Language Class Initialized
INFO - 2019-12-09 15:02:40 --> Config Class Initialized
INFO - 2019-12-09 15:02:40 --> Loader Class Initialized
INFO - 2019-12-09 15:02:40 --> Helper loaded: url_helper
INFO - 2019-12-09 15:02:40 --> Helper loaded: common_helper
INFO - 2019-12-09 15:02:40 --> Helper loaded: language_helper
INFO - 2019-12-09 15:02:40 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:02:40 --> Helper loaded: email_helper
INFO - 2019-12-09 15:02:40 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:02:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:02:40 --> Parser Class Initialized
INFO - 2019-12-09 15:02:40 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:02:40 --> Template Class Initialized
INFO - 2019-12-09 15:02:40 --> Database Driver Class Initialized
INFO - 2019-12-09 15:02:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:02:40 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:02:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:02:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:02:40 --> Encryption Class Initialized
INFO - 2019-12-09 15:02:40 --> Controller Class Initialized
DEBUG - 2019-12-09 15:02:40 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:02:40 --> Model Class Initialized
INFO - 2019-12-09 15:02:40 --> Model Class Initialized
INFO - 2019-12-09 15:02:40 --> Model Class Initialized
ERROR - 2019-12-09 15:02:43 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:02:43 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:06:14 --> Config Class Initialized
INFO - 2019-12-09 15:06:14 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:06:14 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:06:14 --> Utf8 Class Initialized
INFO - 2019-12-09 15:06:14 --> URI Class Initialized
INFO - 2019-12-09 15:06:14 --> Router Class Initialized
INFO - 2019-12-09 15:06:14 --> Output Class Initialized
INFO - 2019-12-09 15:06:14 --> Security Class Initialized
DEBUG - 2019-12-09 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:06:14 --> CSRF cookie sent
INFO - 2019-12-09 15:06:14 --> Input Class Initialized
INFO - 2019-12-09 15:06:14 --> Language Class Initialized
INFO - 2019-12-09 15:06:14 --> Language Class Initialized
INFO - 2019-12-09 15:06:14 --> Config Class Initialized
INFO - 2019-12-09 15:06:14 --> Loader Class Initialized
INFO - 2019-12-09 15:06:14 --> Helper loaded: url_helper
INFO - 2019-12-09 15:06:14 --> Helper loaded: common_helper
INFO - 2019-12-09 15:06:14 --> Helper loaded: language_helper
INFO - 2019-12-09 15:06:14 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:06:14 --> Helper loaded: email_helper
INFO - 2019-12-09 15:06:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:06:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:06:14 --> Parser Class Initialized
INFO - 2019-12-09 15:06:14 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:06:14 --> Template Class Initialized
INFO - 2019-12-09 15:06:14 --> Database Driver Class Initialized
INFO - 2019-12-09 15:06:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:06:14 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:06:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:06:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:06:14 --> Encryption Class Initialized
INFO - 2019-12-09 15:06:14 --> Controller Class Initialized
DEBUG - 2019-12-09 15:06:14 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:06:14 --> Model Class Initialized
INFO - 2019-12-09 15:06:14 --> Model Class Initialized
INFO - 2019-12-09 15:06:14 --> Model Class Initialized
ERROR - 2019-12-09 15:06:15 --> Severity: Notice --> Undefined index: data D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 161
ERROR - 2019-12-09 15:06:17 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:06:17 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:10:48 --> Config Class Initialized
INFO - 2019-12-09 15:10:48 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:10:48 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:10:48 --> Utf8 Class Initialized
INFO - 2019-12-09 15:10:48 --> URI Class Initialized
INFO - 2019-12-09 15:10:48 --> Router Class Initialized
INFO - 2019-12-09 15:10:48 --> Output Class Initialized
INFO - 2019-12-09 15:10:48 --> Security Class Initialized
DEBUG - 2019-12-09 15:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:10:49 --> CSRF cookie sent
INFO - 2019-12-09 15:10:49 --> Input Class Initialized
INFO - 2019-12-09 15:10:49 --> Language Class Initialized
INFO - 2019-12-09 15:10:49 --> Language Class Initialized
INFO - 2019-12-09 15:10:49 --> Config Class Initialized
INFO - 2019-12-09 15:10:49 --> Loader Class Initialized
INFO - 2019-12-09 15:10:49 --> Helper loaded: url_helper
INFO - 2019-12-09 15:10:49 --> Helper loaded: common_helper
INFO - 2019-12-09 15:10:49 --> Helper loaded: language_helper
INFO - 2019-12-09 15:10:49 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:10:49 --> Helper loaded: email_helper
INFO - 2019-12-09 15:10:49 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:10:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:10:49 --> Parser Class Initialized
INFO - 2019-12-09 15:10:49 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:10:49 --> Template Class Initialized
INFO - 2019-12-09 15:10:49 --> Database Driver Class Initialized
INFO - 2019-12-09 15:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:10:49 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:10:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:10:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:10:49 --> Encryption Class Initialized
INFO - 2019-12-09 15:10:49 --> Controller Class Initialized
DEBUG - 2019-12-09 15:10:49 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:10:49 --> Model Class Initialized
INFO - 2019-12-09 15:10:49 --> Model Class Initialized
INFO - 2019-12-09 15:10:49 --> Model Class Initialized
ERROR - 2019-12-09 15:10:52 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:10:52 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:13:42 --> Config Class Initialized
INFO - 2019-12-09 15:13:42 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:13:42 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:13:42 --> Utf8 Class Initialized
INFO - 2019-12-09 15:13:42 --> URI Class Initialized
INFO - 2019-12-09 15:13:42 --> Router Class Initialized
INFO - 2019-12-09 15:13:42 --> Output Class Initialized
INFO - 2019-12-09 15:13:42 --> Security Class Initialized
DEBUG - 2019-12-09 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:13:42 --> CSRF cookie sent
INFO - 2019-12-09 15:13:42 --> Input Class Initialized
INFO - 2019-12-09 15:13:42 --> Language Class Initialized
INFO - 2019-12-09 15:13:42 --> Language Class Initialized
INFO - 2019-12-09 15:13:43 --> Config Class Initialized
INFO - 2019-12-09 15:13:43 --> Loader Class Initialized
INFO - 2019-12-09 15:13:43 --> Helper loaded: url_helper
INFO - 2019-12-09 15:13:43 --> Helper loaded: common_helper
INFO - 2019-12-09 15:13:43 --> Helper loaded: language_helper
INFO - 2019-12-09 15:13:43 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:13:43 --> Helper loaded: email_helper
INFO - 2019-12-09 15:13:43 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:13:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:13:43 --> Parser Class Initialized
INFO - 2019-12-09 15:13:43 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:13:43 --> Template Class Initialized
INFO - 2019-12-09 15:13:43 --> Database Driver Class Initialized
INFO - 2019-12-09 15:13:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:13:43 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:13:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:13:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:13:43 --> Encryption Class Initialized
INFO - 2019-12-09 15:13:43 --> Controller Class Initialized
DEBUG - 2019-12-09 15:13:43 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:13:43 --> Model Class Initialized
INFO - 2019-12-09 15:13:43 --> Model Class Initialized
INFO - 2019-12-09 15:13:43 --> Model Class Initialized
ERROR - 2019-12-09 15:13:46 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:13:46 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:15:06 --> Config Class Initialized
INFO - 2019-12-09 15:15:06 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:15:06 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:15:06 --> Utf8 Class Initialized
INFO - 2019-12-09 15:15:06 --> URI Class Initialized
INFO - 2019-12-09 15:15:06 --> Router Class Initialized
INFO - 2019-12-09 15:15:06 --> Output Class Initialized
INFO - 2019-12-09 15:15:06 --> Security Class Initialized
DEBUG - 2019-12-09 15:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:15:06 --> CSRF cookie sent
INFO - 2019-12-09 15:15:06 --> Input Class Initialized
INFO - 2019-12-09 15:15:06 --> Language Class Initialized
INFO - 2019-12-09 15:15:06 --> Language Class Initialized
INFO - 2019-12-09 15:15:06 --> Config Class Initialized
INFO - 2019-12-09 15:15:06 --> Loader Class Initialized
INFO - 2019-12-09 15:15:06 --> Helper loaded: url_helper
INFO - 2019-12-09 15:15:06 --> Helper loaded: common_helper
INFO - 2019-12-09 15:15:06 --> Helper loaded: language_helper
INFO - 2019-12-09 15:15:06 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:15:06 --> Helper loaded: email_helper
INFO - 2019-12-09 15:15:06 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:15:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:15:06 --> Parser Class Initialized
INFO - 2019-12-09 15:15:06 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:15:06 --> Template Class Initialized
INFO - 2019-12-09 15:15:06 --> Database Driver Class Initialized
INFO - 2019-12-09 15:15:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:15:06 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:15:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:15:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:15:06 --> Encryption Class Initialized
INFO - 2019-12-09 15:15:06 --> Controller Class Initialized
DEBUG - 2019-12-09 15:15:06 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:15:06 --> Model Class Initialized
INFO - 2019-12-09 15:15:06 --> Model Class Initialized
INFO - 2019-12-09 15:15:06 --> Model Class Initialized
ERROR - 2019-12-09 15:15:09 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:15:09 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:16:00 --> Config Class Initialized
INFO - 2019-12-09 15:16:00 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:16:00 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:16:00 --> Utf8 Class Initialized
INFO - 2019-12-09 15:16:00 --> URI Class Initialized
INFO - 2019-12-09 15:16:00 --> Router Class Initialized
INFO - 2019-12-09 15:16:00 --> Output Class Initialized
INFO - 2019-12-09 15:16:00 --> Security Class Initialized
DEBUG - 2019-12-09 15:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:16:00 --> CSRF cookie sent
INFO - 2019-12-09 15:16:00 --> Input Class Initialized
INFO - 2019-12-09 15:16:00 --> Language Class Initialized
INFO - 2019-12-09 15:16:00 --> Language Class Initialized
INFO - 2019-12-09 15:16:00 --> Config Class Initialized
INFO - 2019-12-09 15:16:00 --> Loader Class Initialized
INFO - 2019-12-09 15:16:00 --> Helper loaded: url_helper
INFO - 2019-12-09 15:16:00 --> Helper loaded: common_helper
INFO - 2019-12-09 15:16:00 --> Helper loaded: language_helper
INFO - 2019-12-09 15:16:00 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:16:00 --> Helper loaded: email_helper
INFO - 2019-12-09 15:16:00 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:16:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:16:00 --> Parser Class Initialized
INFO - 2019-12-09 15:16:00 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:16:00 --> Template Class Initialized
INFO - 2019-12-09 15:16:00 --> Database Driver Class Initialized
INFO - 2019-12-09 15:16:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:16:00 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:16:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:16:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:16:00 --> Encryption Class Initialized
INFO - 2019-12-09 15:16:00 --> Controller Class Initialized
DEBUG - 2019-12-09 15:16:00 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:16:00 --> Model Class Initialized
INFO - 2019-12-09 15:16:00 --> Model Class Initialized
INFO - 2019-12-09 15:16:00 --> Model Class Initialized
ERROR - 2019-12-09 15:16:03 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:16:03 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:18:01 --> Config Class Initialized
INFO - 2019-12-09 15:18:01 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:18:01 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:18:01 --> Utf8 Class Initialized
INFO - 2019-12-09 15:18:01 --> URI Class Initialized
INFO - 2019-12-09 15:18:01 --> Router Class Initialized
INFO - 2019-12-09 15:18:01 --> Output Class Initialized
INFO - 2019-12-09 15:18:01 --> Security Class Initialized
DEBUG - 2019-12-09 15:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:18:01 --> CSRF cookie sent
INFO - 2019-12-09 15:18:01 --> Input Class Initialized
INFO - 2019-12-09 15:18:01 --> Language Class Initialized
INFO - 2019-12-09 15:18:01 --> Language Class Initialized
INFO - 2019-12-09 15:18:01 --> Config Class Initialized
INFO - 2019-12-09 15:18:01 --> Loader Class Initialized
INFO - 2019-12-09 15:18:01 --> Helper loaded: url_helper
INFO - 2019-12-09 15:18:01 --> Helper loaded: common_helper
INFO - 2019-12-09 15:18:01 --> Helper loaded: language_helper
INFO - 2019-12-09 15:18:01 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:18:01 --> Helper loaded: email_helper
INFO - 2019-12-09 15:18:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:18:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:18:01 --> Parser Class Initialized
INFO - 2019-12-09 15:18:01 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:18:01 --> Template Class Initialized
INFO - 2019-12-09 15:18:01 --> Database Driver Class Initialized
INFO - 2019-12-09 15:18:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:18:01 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:18:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:18:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:18:01 --> Encryption Class Initialized
INFO - 2019-12-09 15:18:01 --> Controller Class Initialized
DEBUG - 2019-12-09 15:18:01 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:18:01 --> Model Class Initialized
INFO - 2019-12-09 15:18:01 --> Model Class Initialized
INFO - 2019-12-09 15:18:01 --> Model Class Initialized
ERROR - 2019-12-09 15:18:04 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:18:04 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:19:23 --> Config Class Initialized
INFO - 2019-12-09 15:19:23 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:19:23 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:19:23 --> Utf8 Class Initialized
INFO - 2019-12-09 15:19:23 --> URI Class Initialized
INFO - 2019-12-09 15:19:23 --> Router Class Initialized
INFO - 2019-12-09 15:19:23 --> Output Class Initialized
INFO - 2019-12-09 15:19:23 --> Security Class Initialized
DEBUG - 2019-12-09 15:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:19:23 --> CSRF cookie sent
INFO - 2019-12-09 15:19:23 --> Input Class Initialized
INFO - 2019-12-09 15:19:23 --> Language Class Initialized
INFO - 2019-12-09 15:19:23 --> Language Class Initialized
INFO - 2019-12-09 15:19:23 --> Config Class Initialized
INFO - 2019-12-09 15:19:23 --> Loader Class Initialized
INFO - 2019-12-09 15:19:23 --> Helper loaded: url_helper
INFO - 2019-12-09 15:19:23 --> Helper loaded: common_helper
INFO - 2019-12-09 15:19:23 --> Helper loaded: language_helper
INFO - 2019-12-09 15:19:23 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:19:23 --> Helper loaded: email_helper
INFO - 2019-12-09 15:19:23 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:19:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:19:23 --> Parser Class Initialized
INFO - 2019-12-09 15:19:23 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:19:23 --> Template Class Initialized
INFO - 2019-12-09 15:19:23 --> Database Driver Class Initialized
INFO - 2019-12-09 15:19:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:19:23 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:19:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:19:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:19:23 --> Encryption Class Initialized
INFO - 2019-12-09 15:19:23 --> Controller Class Initialized
DEBUG - 2019-12-09 15:19:23 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:19:23 --> Model Class Initialized
INFO - 2019-12-09 15:19:23 --> Model Class Initialized
INFO - 2019-12-09 15:19:23 --> Model Class Initialized
ERROR - 2019-12-09 15:19:26 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:19:26 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:22:18 --> Config Class Initialized
INFO - 2019-12-09 15:22:18 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:22:18 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:22:18 --> Utf8 Class Initialized
INFO - 2019-12-09 15:22:18 --> URI Class Initialized
INFO - 2019-12-09 15:22:18 --> Router Class Initialized
INFO - 2019-12-09 15:22:18 --> Output Class Initialized
INFO - 2019-12-09 15:22:18 --> Security Class Initialized
DEBUG - 2019-12-09 15:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:22:18 --> CSRF cookie sent
INFO - 2019-12-09 15:22:18 --> Input Class Initialized
INFO - 2019-12-09 15:22:18 --> Language Class Initialized
INFO - 2019-12-09 15:22:18 --> Language Class Initialized
INFO - 2019-12-09 15:22:18 --> Config Class Initialized
INFO - 2019-12-09 15:22:18 --> Loader Class Initialized
INFO - 2019-12-09 15:22:18 --> Helper loaded: url_helper
INFO - 2019-12-09 15:22:18 --> Helper loaded: common_helper
INFO - 2019-12-09 15:22:18 --> Helper loaded: language_helper
INFO - 2019-12-09 15:22:18 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:22:18 --> Helper loaded: email_helper
INFO - 2019-12-09 15:22:18 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:22:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:22:18 --> Parser Class Initialized
INFO - 2019-12-09 15:22:18 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:22:18 --> Template Class Initialized
INFO - 2019-12-09 15:22:18 --> Database Driver Class Initialized
INFO - 2019-12-09 15:22:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:22:18 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:22:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:22:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:22:18 --> Encryption Class Initialized
INFO - 2019-12-09 15:22:18 --> Controller Class Initialized
DEBUG - 2019-12-09 15:22:18 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:22:18 --> Model Class Initialized
INFO - 2019-12-09 15:22:18 --> Model Class Initialized
INFO - 2019-12-09 15:22:18 --> Model Class Initialized
INFO - 2019-12-09 15:22:21 --> Final output sent to browser
DEBUG - 2019-12-09 15:22:21 --> Total execution time: 3.2387
ERROR - 2019-12-09 15:22:21 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:22:21 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:22:25 --> Config Class Initialized
INFO - 2019-12-09 15:22:25 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:22:25 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:22:25 --> Utf8 Class Initialized
INFO - 2019-12-09 15:22:25 --> URI Class Initialized
INFO - 2019-12-09 15:22:25 --> Router Class Initialized
INFO - 2019-12-09 15:22:25 --> Output Class Initialized
INFO - 2019-12-09 15:22:25 --> Security Class Initialized
DEBUG - 2019-12-09 15:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:22:25 --> CSRF cookie sent
INFO - 2019-12-09 15:22:25 --> Input Class Initialized
INFO - 2019-12-09 15:22:25 --> Language Class Initialized
INFO - 2019-12-09 15:22:25 --> Language Class Initialized
INFO - 2019-12-09 15:22:25 --> Config Class Initialized
INFO - 2019-12-09 15:22:25 --> Loader Class Initialized
INFO - 2019-12-09 15:22:25 --> Helper loaded: url_helper
INFO - 2019-12-09 15:22:25 --> Helper loaded: common_helper
INFO - 2019-12-09 15:22:25 --> Helper loaded: language_helper
INFO - 2019-12-09 15:22:25 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:22:25 --> Helper loaded: email_helper
INFO - 2019-12-09 15:22:25 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:22:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:22:25 --> Parser Class Initialized
INFO - 2019-12-09 15:22:25 --> User Agent Class Initialized
INFO - 2019-12-09 15:22:25 --> Model Class Initialized
INFO - 2019-12-09 15:22:25 --> Database Driver Class Initialized
INFO - 2019-12-09 15:22:25 --> Model Class Initialized
DEBUG - 2019-12-09 15:22:25 --> Template Class Initialized
INFO - 2019-12-09 15:22:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:22:25 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:22:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:22:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:22:25 --> Encryption Class Initialized
INFO - 2019-12-09 15:22:25 --> Controller Class Initialized
DEBUG - 2019-12-09 15:22:25 --> transactions MX_Controller Initialized
DEBUG - 2019-12-09 15:22:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-09 15:22:25 --> Model Class Initialized
ERROR - 2019-12-09 15:22:25 --> Could not find the language line "order_id"
INFO - 2019-12-09 15:22:26 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 15:22:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-09 15:22:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 15:22:26 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 15:22:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 15:22:26 --> Model Class Initialized
DEBUG - 2019-12-09 15:22:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 15:22:26 --> Model Class Initialized
DEBUG - 2019-12-09 15:22:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 15:22:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 15:22:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 15:22:26 --> Final output sent to browser
DEBUG - 2019-12-09 15:22:26 --> Total execution time: 0.7868
INFO - 2019-12-09 15:23:14 --> Config Class Initialized
INFO - 2019-12-09 15:23:14 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:23:14 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:23:14 --> Utf8 Class Initialized
INFO - 2019-12-09 15:23:14 --> URI Class Initialized
INFO - 2019-12-09 15:23:14 --> Router Class Initialized
INFO - 2019-12-09 15:23:14 --> Output Class Initialized
INFO - 2019-12-09 15:23:14 --> Security Class Initialized
DEBUG - 2019-12-09 15:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:23:14 --> CSRF cookie sent
INFO - 2019-12-09 15:23:14 --> Input Class Initialized
INFO - 2019-12-09 15:23:14 --> Language Class Initialized
ERROR - 2019-12-09 15:23:14 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 169
INFO - 2019-12-09 15:23:24 --> Config Class Initialized
INFO - 2019-12-09 15:23:24 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:23:24 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:23:24 --> Utf8 Class Initialized
INFO - 2019-12-09 15:23:24 --> URI Class Initialized
INFO - 2019-12-09 15:23:24 --> Router Class Initialized
INFO - 2019-12-09 15:23:24 --> Output Class Initialized
INFO - 2019-12-09 15:23:24 --> Security Class Initialized
DEBUG - 2019-12-09 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:23:24 --> CSRF cookie sent
INFO - 2019-12-09 15:23:24 --> Input Class Initialized
INFO - 2019-12-09 15:23:24 --> Language Class Initialized
INFO - 2019-12-09 15:23:24 --> Language Class Initialized
INFO - 2019-12-09 15:23:24 --> Config Class Initialized
INFO - 2019-12-09 15:23:24 --> Loader Class Initialized
INFO - 2019-12-09 15:23:24 --> Helper loaded: url_helper
INFO - 2019-12-09 15:23:24 --> Helper loaded: common_helper
INFO - 2019-12-09 15:23:24 --> Helper loaded: language_helper
INFO - 2019-12-09 15:23:24 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:23:24 --> Helper loaded: email_helper
INFO - 2019-12-09 15:23:25 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:23:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:23:25 --> Parser Class Initialized
INFO - 2019-12-09 15:23:25 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:23:25 --> Template Class Initialized
INFO - 2019-12-09 15:23:25 --> Database Driver Class Initialized
INFO - 2019-12-09 15:23:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:23:25 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:23:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:23:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:23:25 --> Encryption Class Initialized
INFO - 2019-12-09 15:23:25 --> Controller Class Initialized
DEBUG - 2019-12-09 15:23:25 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:23:25 --> Model Class Initialized
INFO - 2019-12-09 15:23:25 --> Model Class Initialized
INFO - 2019-12-09 15:23:25 --> Model Class Initialized
INFO - 2019-12-09 15:23:28 --> Final output sent to browser
DEBUG - 2019-12-09 15:23:28 --> Total execution time: 3.4007
ERROR - 2019-12-09 15:23:28 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:23:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:23:51 --> Config Class Initialized
INFO - 2019-12-09 15:23:51 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:23:51 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:23:51 --> Utf8 Class Initialized
INFO - 2019-12-09 15:23:51 --> URI Class Initialized
INFO - 2019-12-09 15:23:51 --> Router Class Initialized
INFO - 2019-12-09 15:23:51 --> Output Class Initialized
INFO - 2019-12-09 15:23:51 --> Security Class Initialized
DEBUG - 2019-12-09 15:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:23:51 --> CSRF cookie sent
INFO - 2019-12-09 15:23:51 --> Input Class Initialized
INFO - 2019-12-09 15:23:51 --> Language Class Initialized
INFO - 2019-12-09 15:23:51 --> Language Class Initialized
INFO - 2019-12-09 15:23:51 --> Config Class Initialized
INFO - 2019-12-09 15:23:51 --> Loader Class Initialized
INFO - 2019-12-09 15:23:51 --> Helper loaded: url_helper
INFO - 2019-12-09 15:23:51 --> Helper loaded: common_helper
INFO - 2019-12-09 15:23:51 --> Helper loaded: language_helper
INFO - 2019-12-09 15:23:51 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:23:51 --> Helper loaded: email_helper
INFO - 2019-12-09 15:23:51 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:23:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:23:51 --> Parser Class Initialized
INFO - 2019-12-09 15:23:51 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:23:51 --> Template Class Initialized
INFO - 2019-12-09 15:23:51 --> Database Driver Class Initialized
INFO - 2019-12-09 15:23:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:23:51 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:23:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:23:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:23:52 --> Encryption Class Initialized
INFO - 2019-12-09 15:23:52 --> Controller Class Initialized
DEBUG - 2019-12-09 15:23:52 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:23:52 --> Model Class Initialized
INFO - 2019-12-09 15:23:52 --> Model Class Initialized
INFO - 2019-12-09 15:23:52 --> Model Class Initialized
INFO - 2019-12-09 15:23:54 --> Final output sent to browser
DEBUG - 2019-12-09 15:23:54 --> Total execution time: 3.2620
ERROR - 2019-12-09 15:23:54 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:23:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:24:36 --> Config Class Initialized
INFO - 2019-12-09 15:24:36 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:24:36 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:24:36 --> Utf8 Class Initialized
INFO - 2019-12-09 15:24:36 --> URI Class Initialized
INFO - 2019-12-09 15:24:36 --> Router Class Initialized
INFO - 2019-12-09 15:24:36 --> Output Class Initialized
INFO - 2019-12-09 15:24:36 --> Security Class Initialized
DEBUG - 2019-12-09 15:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:24:36 --> CSRF cookie sent
INFO - 2019-12-09 15:24:36 --> Input Class Initialized
INFO - 2019-12-09 15:24:36 --> Language Class Initialized
INFO - 2019-12-09 15:24:36 --> Language Class Initialized
INFO - 2019-12-09 15:24:36 --> Config Class Initialized
INFO - 2019-12-09 15:24:36 --> Loader Class Initialized
INFO - 2019-12-09 15:24:36 --> Helper loaded: url_helper
INFO - 2019-12-09 15:24:36 --> Helper loaded: common_helper
INFO - 2019-12-09 15:24:36 --> Helper loaded: language_helper
INFO - 2019-12-09 15:24:36 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:24:36 --> Helper loaded: email_helper
INFO - 2019-12-09 15:24:36 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:24:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:24:36 --> Parser Class Initialized
INFO - 2019-12-09 15:24:36 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:24:36 --> Template Class Initialized
INFO - 2019-12-09 15:24:36 --> Database Driver Class Initialized
INFO - 2019-12-09 15:24:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:24:36 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:24:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:24:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:24:36 --> Encryption Class Initialized
INFO - 2019-12-09 15:24:36 --> Controller Class Initialized
DEBUG - 2019-12-09 15:24:36 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:24:36 --> Model Class Initialized
INFO - 2019-12-09 15:24:36 --> Model Class Initialized
INFO - 2019-12-09 15:24:36 --> Model Class Initialized
INFO - 2019-12-09 15:24:39 --> Final output sent to browser
DEBUG - 2019-12-09 15:24:39 --> Total execution time: 3.3276
ERROR - 2019-12-09 15:24:39 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:24:39 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:24:45 --> Config Class Initialized
INFO - 2019-12-09 15:24:45 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:24:45 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:24:45 --> Utf8 Class Initialized
INFO - 2019-12-09 15:24:45 --> URI Class Initialized
INFO - 2019-12-09 15:24:45 --> Router Class Initialized
INFO - 2019-12-09 15:24:45 --> Output Class Initialized
INFO - 2019-12-09 15:24:45 --> Security Class Initialized
DEBUG - 2019-12-09 15:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:24:45 --> CSRF cookie sent
INFO - 2019-12-09 15:24:45 --> Input Class Initialized
INFO - 2019-12-09 15:24:45 --> Language Class Initialized
INFO - 2019-12-09 15:24:45 --> Language Class Initialized
INFO - 2019-12-09 15:24:45 --> Config Class Initialized
INFO - 2019-12-09 15:24:45 --> Loader Class Initialized
INFO - 2019-12-09 15:24:45 --> Helper loaded: url_helper
INFO - 2019-12-09 15:24:45 --> Helper loaded: common_helper
INFO - 2019-12-09 15:24:45 --> Helper loaded: language_helper
INFO - 2019-12-09 15:24:45 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:24:45 --> Helper loaded: email_helper
INFO - 2019-12-09 15:24:45 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:24:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:24:45 --> Parser Class Initialized
INFO - 2019-12-09 15:24:45 --> User Agent Class Initialized
INFO - 2019-12-09 15:24:45 --> Model Class Initialized
INFO - 2019-12-09 15:24:45 --> Database Driver Class Initialized
INFO - 2019-12-09 15:24:45 --> Model Class Initialized
DEBUG - 2019-12-09 15:24:45 --> Template Class Initialized
INFO - 2019-12-09 15:24:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:24:45 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:24:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:24:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:24:45 --> Encryption Class Initialized
INFO - 2019-12-09 15:24:45 --> Controller Class Initialized
DEBUG - 2019-12-09 15:24:45 --> transactions MX_Controller Initialized
DEBUG - 2019-12-09 15:24:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-09 15:24:45 --> Model Class Initialized
ERROR - 2019-12-09 15:24:45 --> Could not find the language line "order_id"
INFO - 2019-12-09 15:24:45 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 15:24:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-09 15:24:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 15:24:45 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 15:24:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 15:24:45 --> Model Class Initialized
DEBUG - 2019-12-09 15:24:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 15:24:45 --> Model Class Initialized
DEBUG - 2019-12-09 15:24:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 15:24:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 15:24:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 15:24:45 --> Final output sent to browser
DEBUG - 2019-12-09 15:24:45 --> Total execution time: 0.7994
INFO - 2019-12-09 15:25:11 --> Config Class Initialized
INFO - 2019-12-09 15:25:11 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:25:11 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:25:11 --> Utf8 Class Initialized
INFO - 2019-12-09 15:25:11 --> URI Class Initialized
INFO - 2019-12-09 15:25:11 --> Router Class Initialized
INFO - 2019-12-09 15:25:11 --> Output Class Initialized
INFO - 2019-12-09 15:25:11 --> Security Class Initialized
DEBUG - 2019-12-09 15:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:25:11 --> CSRF cookie sent
INFO - 2019-12-09 15:25:11 --> Input Class Initialized
INFO - 2019-12-09 15:25:11 --> Language Class Initialized
INFO - 2019-12-09 15:25:11 --> Language Class Initialized
INFO - 2019-12-09 15:25:11 --> Config Class Initialized
INFO - 2019-12-09 15:25:11 --> Loader Class Initialized
INFO - 2019-12-09 15:25:11 --> Helper loaded: url_helper
INFO - 2019-12-09 15:25:11 --> Helper loaded: common_helper
INFO - 2019-12-09 15:25:11 --> Helper loaded: language_helper
INFO - 2019-12-09 15:25:11 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:25:11 --> Helper loaded: email_helper
INFO - 2019-12-09 15:25:12 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:25:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:25:12 --> Parser Class Initialized
INFO - 2019-12-09 15:25:12 --> User Agent Class Initialized
INFO - 2019-12-09 15:25:12 --> Model Class Initialized
INFO - 2019-12-09 15:25:12 --> Database Driver Class Initialized
INFO - 2019-12-09 15:25:12 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:12 --> Template Class Initialized
INFO - 2019-12-09 15:25:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:25:12 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:25:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:25:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:25:12 --> Encryption Class Initialized
INFO - 2019-12-09 15:25:12 --> Controller Class Initialized
DEBUG - 2019-12-09 15:25:12 --> order MX_Controller Initialized
DEBUG - 2019-12-09 15:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-09 15:25:12 --> Model Class Initialized
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "order_id"
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "order_id"
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "order_basic_details"
INFO - 2019-12-09 15:25:12 --> Helper loaded: inflector_helper
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "Awaiting"
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "Pending"
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "Awaiting"
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "Awaiting"
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "Pending"
ERROR - 2019-12-09 15:25:12 --> Could not find the language line "Pending"
DEBUG - 2019-12-09 15:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-09 15:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 15:25:12 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 15:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 15:25:12 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 15:25:12 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 15:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 15:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 15:25:12 --> Final output sent to browser
DEBUG - 2019-12-09 15:25:12 --> Total execution time: 0.9847
INFO - 2019-12-09 15:25:29 --> Config Class Initialized
INFO - 2019-12-09 15:25:29 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:25:29 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:25:29 --> Utf8 Class Initialized
INFO - 2019-12-09 15:25:29 --> URI Class Initialized
DEBUG - 2019-12-09 15:25:29 --> No URI present. Default controller set.
INFO - 2019-12-09 15:25:29 --> Router Class Initialized
INFO - 2019-12-09 15:25:29 --> Output Class Initialized
INFO - 2019-12-09 15:25:29 --> Security Class Initialized
DEBUG - 2019-12-09 15:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:25:29 --> CSRF cookie sent
INFO - 2019-12-09 15:25:29 --> Input Class Initialized
INFO - 2019-12-09 15:25:29 --> Language Class Initialized
INFO - 2019-12-09 15:25:29 --> Language Class Initialized
INFO - 2019-12-09 15:25:29 --> Config Class Initialized
INFO - 2019-12-09 15:25:29 --> Loader Class Initialized
INFO - 2019-12-09 15:25:29 --> Helper loaded: url_helper
INFO - 2019-12-09 15:25:29 --> Helper loaded: common_helper
INFO - 2019-12-09 15:25:29 --> Helper loaded: language_helper
INFO - 2019-12-09 15:25:29 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:25:29 --> Helper loaded: email_helper
INFO - 2019-12-09 15:25:29 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:25:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:25:29 --> Parser Class Initialized
INFO - 2019-12-09 15:25:29 --> User Agent Class Initialized
INFO - 2019-12-09 15:25:29 --> Model Class Initialized
INFO - 2019-12-09 15:25:29 --> Database Driver Class Initialized
INFO - 2019-12-09 15:25:29 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:29 --> Template Class Initialized
INFO - 2019-12-09 15:25:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:25:30 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:25:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:25:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:25:30 --> Encryption Class Initialized
DEBUG - 2019-12-09 15:25:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 15:25:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-09 15:25:30 --> Controller Class Initialized
DEBUG - 2019-12-09 15:25:30 --> pergo MX_Controller Initialized
DEBUG - 2019-12-09 15:25:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 15:25:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-09 15:25:30 --> Model Class Initialized
INFO - 2019-12-09 15:25:30 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 15:25:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-09 15:25:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-09 15:25:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-09 15:25:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-09 15:25:30 --> Final output sent to browser
DEBUG - 2019-12-09 15:25:30 --> Total execution time: 0.7626
INFO - 2019-12-09 15:25:33 --> Config Class Initialized
INFO - 2019-12-09 15:25:33 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:25:33 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:25:33 --> Utf8 Class Initialized
INFO - 2019-12-09 15:25:33 --> URI Class Initialized
INFO - 2019-12-09 15:25:33 --> Router Class Initialized
INFO - 2019-12-09 15:25:33 --> Output Class Initialized
INFO - 2019-12-09 15:25:33 --> Security Class Initialized
DEBUG - 2019-12-09 15:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:25:33 --> CSRF cookie sent
INFO - 2019-12-09 15:25:33 --> Input Class Initialized
INFO - 2019-12-09 15:25:33 --> Language Class Initialized
INFO - 2019-12-09 15:25:33 --> Language Class Initialized
INFO - 2019-12-09 15:25:33 --> Config Class Initialized
INFO - 2019-12-09 15:25:33 --> Loader Class Initialized
INFO - 2019-12-09 15:25:33 --> Helper loaded: url_helper
INFO - 2019-12-09 15:25:33 --> Helper loaded: common_helper
INFO - 2019-12-09 15:25:33 --> Helper loaded: language_helper
INFO - 2019-12-09 15:25:33 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:25:33 --> Helper loaded: email_helper
INFO - 2019-12-09 15:25:33 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:25:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:25:33 --> Parser Class Initialized
INFO - 2019-12-09 15:25:33 --> User Agent Class Initialized
INFO - 2019-12-09 15:25:33 --> Model Class Initialized
INFO - 2019-12-09 15:25:33 --> Database Driver Class Initialized
INFO - 2019-12-09 15:25:33 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:33 --> Template Class Initialized
INFO - 2019-12-09 15:25:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:25:33 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:25:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:25:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:25:33 --> Encryption Class Initialized
INFO - 2019-12-09 15:25:33 --> Controller Class Initialized
DEBUG - 2019-12-09 15:25:33 --> package MX_Controller Initialized
DEBUG - 2019-12-09 15:25:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-09 15:25:33 --> Model Class Initialized
INFO - 2019-12-09 15:25:33 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 15:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 15:25:34 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 15:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 15:25:34 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 15:25:34 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-09 15:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-09 15:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-09 15:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-09 15:25:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-09 15:25:34 --> Final output sent to browser
DEBUG - 2019-12-09 15:25:34 --> Total execution time: 1.1879
INFO - 2019-12-09 15:25:37 --> Config Class Initialized
INFO - 2019-12-09 15:25:37 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:25:37 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:25:37 --> Utf8 Class Initialized
INFO - 2019-12-09 15:25:37 --> URI Class Initialized
INFO - 2019-12-09 15:25:37 --> Router Class Initialized
INFO - 2019-12-09 15:25:37 --> Output Class Initialized
INFO - 2019-12-09 15:25:37 --> Security Class Initialized
DEBUG - 2019-12-09 15:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:25:37 --> CSRF cookie sent
INFO - 2019-12-09 15:25:37 --> CSRF token verified
INFO - 2019-12-09 15:25:37 --> Input Class Initialized
INFO - 2019-12-09 15:25:37 --> Language Class Initialized
INFO - 2019-12-09 15:25:37 --> Language Class Initialized
INFO - 2019-12-09 15:25:37 --> Config Class Initialized
INFO - 2019-12-09 15:25:37 --> Loader Class Initialized
INFO - 2019-12-09 15:25:37 --> Helper loaded: url_helper
INFO - 2019-12-09 15:25:37 --> Helper loaded: common_helper
INFO - 2019-12-09 15:25:37 --> Helper loaded: language_helper
INFO - 2019-12-09 15:25:37 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:25:37 --> Helper loaded: email_helper
INFO - 2019-12-09 15:25:37 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:25:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:25:37 --> Parser Class Initialized
INFO - 2019-12-09 15:25:37 --> User Agent Class Initialized
INFO - 2019-12-09 15:25:37 --> Model Class Initialized
INFO - 2019-12-09 15:25:37 --> Database Driver Class Initialized
INFO - 2019-12-09 15:25:37 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:37 --> Template Class Initialized
INFO - 2019-12-09 15:25:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:25:37 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:25:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:25:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:25:38 --> Encryption Class Initialized
INFO - 2019-12-09 15:25:38 --> Controller Class Initialized
DEBUG - 2019-12-09 15:25:38 --> checkout MX_Controller Initialized
DEBUG - 2019-12-09 15:25:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-09 15:25:38 --> Model Class Initialized
INFO - 2019-12-09 15:25:38 --> Helper loaded: inflector_helper
ERROR - 2019-12-09 15:25:38 --> Could not find the language line "hesabe"
ERROR - 2019-12-09 15:25:38 --> Could not find the language line "payop"
ERROR - 2019-12-09 15:25:38 --> Could not find the language line "shopier"
DEBUG - 2019-12-09 15:25:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-09 15:25:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 15:25:38 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 15:25:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 15:25:38 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 15:25:38 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-09 15:25:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-09 15:25:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-09 15:25:38 --> Final output sent to browser
DEBUG - 2019-12-09 15:25:38 --> Total execution time: 0.9428
INFO - 2019-12-09 15:25:48 --> Config Class Initialized
INFO - 2019-12-09 15:25:48 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:25:48 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:25:48 --> Utf8 Class Initialized
INFO - 2019-12-09 15:25:48 --> URI Class Initialized
INFO - 2019-12-09 15:25:48 --> Router Class Initialized
INFO - 2019-12-09 15:25:49 --> Output Class Initialized
INFO - 2019-12-09 15:25:49 --> Security Class Initialized
DEBUG - 2019-12-09 15:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:25:49 --> CSRF cookie sent
INFO - 2019-12-09 15:25:49 --> CSRF token verified
INFO - 2019-12-09 15:25:49 --> Input Class Initialized
INFO - 2019-12-09 15:25:49 --> Language Class Initialized
INFO - 2019-12-09 15:25:49 --> Language Class Initialized
INFO - 2019-12-09 15:25:49 --> Config Class Initialized
INFO - 2019-12-09 15:25:49 --> Loader Class Initialized
INFO - 2019-12-09 15:25:49 --> Helper loaded: url_helper
INFO - 2019-12-09 15:25:49 --> Helper loaded: common_helper
INFO - 2019-12-09 15:25:49 --> Helper loaded: language_helper
INFO - 2019-12-09 15:25:49 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:25:49 --> Helper loaded: email_helper
INFO - 2019-12-09 15:25:49 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:25:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:25:49 --> Parser Class Initialized
INFO - 2019-12-09 15:25:49 --> User Agent Class Initialized
INFO - 2019-12-09 15:25:49 --> Model Class Initialized
INFO - 2019-12-09 15:25:49 --> Database Driver Class Initialized
INFO - 2019-12-09 15:25:49 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:49 --> Template Class Initialized
INFO - 2019-12-09 15:25:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:25:49 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:25:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:25:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:25:49 --> Encryption Class Initialized
INFO - 2019-12-09 15:25:49 --> Controller Class Initialized
DEBUG - 2019-12-09 15:25:49 --> checkout MX_Controller Initialized
DEBUG - 2019-12-09 15:25:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-09 15:25:49 --> Model Class Initialized
DEBUG - 2019-12-09 15:25:49 --> payop MX_Controller Initialized
DEBUG - 2019-12-09 15:25:50 --> orders MX_Controller Initialized
DEBUG - 2019-12-09 15:25:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payop/index.php
INFO - 2019-12-09 15:25:50 --> Final output sent to browser
DEBUG - 2019-12-09 15:25:50 --> Total execution time: 1.8264
INFO - 2019-12-09 15:26:03 --> Config Class Initialized
INFO - 2019-12-09 15:26:03 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:26:03 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:26:03 --> Utf8 Class Initialized
INFO - 2019-12-09 15:26:03 --> URI Class Initialized
INFO - 2019-12-09 15:26:03 --> Router Class Initialized
INFO - 2019-12-09 15:26:03 --> Output Class Initialized
INFO - 2019-12-09 15:26:03 --> Security Class Initialized
DEBUG - 2019-12-09 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:26:03 --> CSRF cookie sent
INFO - 2019-12-09 15:26:03 --> Input Class Initialized
INFO - 2019-12-09 15:26:03 --> Language Class Initialized
INFO - 2019-12-09 15:26:03 --> Language Class Initialized
INFO - 2019-12-09 15:26:03 --> Config Class Initialized
INFO - 2019-12-09 15:26:03 --> Loader Class Initialized
INFO - 2019-12-09 15:26:03 --> Helper loaded: url_helper
INFO - 2019-12-09 15:26:03 --> Helper loaded: common_helper
INFO - 2019-12-09 15:26:03 --> Helper loaded: language_helper
INFO - 2019-12-09 15:26:03 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:26:03 --> Helper loaded: email_helper
INFO - 2019-12-09 15:26:03 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:26:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:26:03 --> Parser Class Initialized
INFO - 2019-12-09 15:26:03 --> User Agent Class Initialized
INFO - 2019-12-09 15:26:03 --> Model Class Initialized
INFO - 2019-12-09 15:26:03 --> Database Driver Class Initialized
INFO - 2019-12-09 15:26:03 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:03 --> Template Class Initialized
INFO - 2019-12-09 15:26:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:26:04 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:26:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:26:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:26:04 --> Encryption Class Initialized
INFO - 2019-12-09 15:26:04 --> Controller Class Initialized
DEBUG - 2019-12-09 15:26:04 --> auth MX_Controller Initialized
DEBUG - 2019-12-09 15:26:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-09 15:26:04 --> Model Class Initialized
INFO - 2019-12-09 15:26:04 --> Config Class Initialized
INFO - 2019-12-09 15:26:04 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:26:04 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:26:04 --> Utf8 Class Initialized
INFO - 2019-12-09 15:26:04 --> URI Class Initialized
INFO - 2019-12-09 15:26:04 --> Router Class Initialized
INFO - 2019-12-09 15:26:04 --> Output Class Initialized
INFO - 2019-12-09 15:26:04 --> Security Class Initialized
DEBUG - 2019-12-09 15:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:26:04 --> CSRF cookie sent
INFO - 2019-12-09 15:26:04 --> Input Class Initialized
INFO - 2019-12-09 15:26:04 --> Language Class Initialized
INFO - 2019-12-09 15:26:04 --> Language Class Initialized
INFO - 2019-12-09 15:26:04 --> Config Class Initialized
INFO - 2019-12-09 15:26:04 --> Loader Class Initialized
INFO - 2019-12-09 15:26:04 --> Helper loaded: url_helper
INFO - 2019-12-09 15:26:04 --> Helper loaded: common_helper
INFO - 2019-12-09 15:26:04 --> Helper loaded: language_helper
INFO - 2019-12-09 15:26:04 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:26:04 --> Helper loaded: email_helper
INFO - 2019-12-09 15:26:04 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:26:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:26:04 --> Parser Class Initialized
INFO - 2019-12-09 15:26:04 --> User Agent Class Initialized
INFO - 2019-12-09 15:26:04 --> Model Class Initialized
INFO - 2019-12-09 15:26:04 --> Database Driver Class Initialized
INFO - 2019-12-09 15:26:04 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:04 --> Template Class Initialized
INFO - 2019-12-09 15:26:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:26:04 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:26:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:26:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:26:04 --> Encryption Class Initialized
INFO - 2019-12-09 15:26:04 --> Config Class Initialized
INFO - 2019-12-09 15:26:04 --> Hooks Class Initialized
INFO - 2019-12-09 15:26:04 --> Controller Class Initialized
DEBUG - 2019-12-09 15:26:04 --> statistics MX_Controller Initialized
DEBUG - 2019-12-09 15:26:04 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:26:04 --> Utf8 Class Initialized
DEBUG - 2019-12-09 15:26:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-09 15:26:04 --> Model Class Initialized
INFO - 2019-12-09 15:26:04 --> URI Class Initialized
INFO - 2019-12-09 15:26:04 --> Router Class Initialized
ERROR - 2019-12-09 15:26:04 --> Could not find the language line "Pending"
INFO - 2019-12-09 15:26:04 --> Output Class Initialized
ERROR - 2019-12-09 15:26:04 --> Could not find the language line "Pending"
INFO - 2019-12-09 15:26:04 --> Security Class Initialized
INFO - 2019-12-09 15:26:04 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 15:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-12-09 15:26:04 --> Could not find the language line "total_orders"
INFO - 2019-12-09 15:26:04 --> CSRF cookie sent
ERROR - 2019-12-09 15:26:04 --> Could not find the language line "total_orders"
INFO - 2019-12-09 15:26:04 --> Input Class Initialized
ERROR - 2019-12-09 15:26:04 --> Could not find the language line "Pending"
INFO - 2019-12-09 15:26:04 --> Language Class Initialized
DEBUG - 2019-12-09 15:26:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
INFO - 2019-12-09 15:26:04 --> Language Class Initialized
DEBUG - 2019-12-09 15:26:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 15:26:04 --> blocks MX_Controller Initialized
INFO - 2019-12-09 15:26:04 --> Config Class Initialized
DEBUG - 2019-12-09 15:26:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 15:26:04 --> Loader Class Initialized
INFO - 2019-12-09 15:26:04 --> Model Class Initialized
INFO - 2019-12-09 15:26:04 --> Helper loaded: url_helper
DEBUG - 2019-12-09 15:26:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 15:26:04 --> Helper loaded: common_helper
INFO - 2019-12-09 15:26:04 --> Model Class Initialized
INFO - 2019-12-09 15:26:04 --> Helper loaded: language_helper
INFO - 2019-12-09 15:26:04 --> Helper loaded: cookie_helper
DEBUG - 2019-12-09 15:26:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
INFO - 2019-12-09 15:26:04 --> Helper loaded: email_helper
INFO - 2019-12-09 15:26:04 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:26:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:26:04 --> Parser Class Initialized
DEBUG - 2019-12-09 15:26:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 15:26:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 15:26:04 --> User Agent Class Initialized
INFO - 2019-12-09 15:26:04 --> Final output sent to browser
INFO - 2019-12-09 15:26:04 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:04 --> Total execution time: 0.7592
INFO - 2019-12-09 15:26:04 --> Database Driver Class Initialized
INFO - 2019-12-09 15:26:04 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:05 --> Template Class Initialized
INFO - 2019-12-09 15:26:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:26:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:26:05 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:26:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:26:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:26:05 --> Encryption Class Initialized
INFO - 2019-12-09 15:26:05 --> Controller Class Initialized
DEBUG - 2019-12-09 15:26:05 --> auth MX_Controller Initialized
DEBUG - 2019-12-09 15:26:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-09 15:26:05 --> Model Class Initialized
INFO - 2019-12-09 15:26:07 --> Config Class Initialized
INFO - 2019-12-09 15:26:07 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:26:07 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:26:07 --> Utf8 Class Initialized
INFO - 2019-12-09 15:26:07 --> URI Class Initialized
INFO - 2019-12-09 15:26:07 --> Router Class Initialized
INFO - 2019-12-09 15:26:07 --> Output Class Initialized
INFO - 2019-12-09 15:26:07 --> Security Class Initialized
DEBUG - 2019-12-09 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:26:07 --> CSRF cookie sent
INFO - 2019-12-09 15:26:07 --> Input Class Initialized
INFO - 2019-12-09 15:26:07 --> Language Class Initialized
INFO - 2019-12-09 15:26:07 --> Language Class Initialized
INFO - 2019-12-09 15:26:07 --> Config Class Initialized
INFO - 2019-12-09 15:26:07 --> Loader Class Initialized
INFO - 2019-12-09 15:26:07 --> Helper loaded: url_helper
INFO - 2019-12-09 15:26:07 --> Helper loaded: common_helper
INFO - 2019-12-09 15:26:07 --> Helper loaded: language_helper
INFO - 2019-12-09 15:26:07 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:26:07 --> Helper loaded: email_helper
INFO - 2019-12-09 15:26:07 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:26:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:26:07 --> Parser Class Initialized
INFO - 2019-12-09 15:26:07 --> User Agent Class Initialized
INFO - 2019-12-09 15:26:07 --> Model Class Initialized
INFO - 2019-12-09 15:26:07 --> Database Driver Class Initialized
INFO - 2019-12-09 15:26:07 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:07 --> Template Class Initialized
INFO - 2019-12-09 15:26:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:26:07 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:26:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:26:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:26:07 --> Encryption Class Initialized
INFO - 2019-12-09 15:26:07 --> Controller Class Initialized
DEBUG - 2019-12-09 15:26:07 --> transactions MX_Controller Initialized
DEBUG - 2019-12-09 15:26:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-09 15:26:08 --> Model Class Initialized
ERROR - 2019-12-09 15:26:08 --> Could not find the language line "order_id"
INFO - 2019-12-09 15:26:08 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 15:26:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-09 15:26:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 15:26:08 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 15:26:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 15:26:08 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 15:26:08 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 15:26:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 15:26:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 15:26:08 --> Final output sent to browser
DEBUG - 2019-12-09 15:26:08 --> Total execution time: 1.0565
INFO - 2019-12-09 15:26:47 --> Config Class Initialized
INFO - 2019-12-09 15:26:47 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:26:47 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:26:47 --> Utf8 Class Initialized
INFO - 2019-12-09 15:26:47 --> URI Class Initialized
INFO - 2019-12-09 15:26:47 --> Router Class Initialized
INFO - 2019-12-09 15:26:47 --> Output Class Initialized
INFO - 2019-12-09 15:26:47 --> Security Class Initialized
DEBUG - 2019-12-09 15:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:26:47 --> CSRF cookie sent
INFO - 2019-12-09 15:26:47 --> Input Class Initialized
INFO - 2019-12-09 15:26:47 --> Language Class Initialized
INFO - 2019-12-09 15:26:47 --> Language Class Initialized
INFO - 2019-12-09 15:26:47 --> Config Class Initialized
INFO - 2019-12-09 15:26:47 --> Loader Class Initialized
INFO - 2019-12-09 15:26:47 --> Helper loaded: url_helper
INFO - 2019-12-09 15:26:47 --> Helper loaded: common_helper
INFO - 2019-12-09 15:26:47 --> Helper loaded: language_helper
INFO - 2019-12-09 15:26:47 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:26:47 --> Helper loaded: email_helper
INFO - 2019-12-09 15:26:47 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:26:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:26:47 --> Parser Class Initialized
INFO - 2019-12-09 15:26:47 --> User Agent Class Initialized
DEBUG - 2019-12-09 15:26:47 --> Template Class Initialized
INFO - 2019-12-09 15:26:47 --> Database Driver Class Initialized
INFO - 2019-12-09 15:26:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:26:47 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:26:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:26:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:26:47 --> Encryption Class Initialized
INFO - 2019-12-09 15:26:47 --> Controller Class Initialized
DEBUG - 2019-12-09 15:26:47 --> payop MX_Controller Initialized
INFO - 2019-12-09 15:26:47 --> Model Class Initialized
INFO - 2019-12-09 15:26:47 --> Model Class Initialized
INFO - 2019-12-09 15:26:47 --> Model Class Initialized
INFO - 2019-12-09 15:26:50 --> Final output sent to browser
DEBUG - 2019-12-09 15:26:50 --> Total execution time: 3.5077
ERROR - 2019-12-09 15:26:50 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-09 15:26:50 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-09 15:26:59 --> Config Class Initialized
INFO - 2019-12-09 15:26:59 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:26:59 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:26:59 --> Utf8 Class Initialized
INFO - 2019-12-09 15:26:59 --> URI Class Initialized
INFO - 2019-12-09 15:26:59 --> Router Class Initialized
INFO - 2019-12-09 15:26:59 --> Output Class Initialized
INFO - 2019-12-09 15:26:59 --> Security Class Initialized
DEBUG - 2019-12-09 15:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:26:59 --> CSRF cookie sent
INFO - 2019-12-09 15:26:59 --> Input Class Initialized
INFO - 2019-12-09 15:26:59 --> Language Class Initialized
INFO - 2019-12-09 15:26:59 --> Language Class Initialized
INFO - 2019-12-09 15:26:59 --> Config Class Initialized
INFO - 2019-12-09 15:26:59 --> Loader Class Initialized
INFO - 2019-12-09 15:26:59 --> Helper loaded: url_helper
INFO - 2019-12-09 15:26:59 --> Helper loaded: common_helper
INFO - 2019-12-09 15:26:59 --> Helper loaded: language_helper
INFO - 2019-12-09 15:26:59 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:26:59 --> Helper loaded: email_helper
INFO - 2019-12-09 15:26:59 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:26:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:26:59 --> Parser Class Initialized
INFO - 2019-12-09 15:26:59 --> User Agent Class Initialized
INFO - 2019-12-09 15:26:59 --> Model Class Initialized
INFO - 2019-12-09 15:26:59 --> Database Driver Class Initialized
INFO - 2019-12-09 15:26:59 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:59 --> Template Class Initialized
INFO - 2019-12-09 15:26:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:26:59 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:26:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:26:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:26:59 --> Encryption Class Initialized
INFO - 2019-12-09 15:26:59 --> Controller Class Initialized
DEBUG - 2019-12-09 15:26:59 --> transactions MX_Controller Initialized
DEBUG - 2019-12-09 15:26:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-09 15:26:59 --> Model Class Initialized
ERROR - 2019-12-09 15:26:59 --> Could not find the language line "order_id"
INFO - 2019-12-09 15:26:59 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 15:26:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-09 15:26:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 15:26:59 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 15:26:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 15:26:59 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 15:26:59 --> Model Class Initialized
DEBUG - 2019-12-09 15:26:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 15:26:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 15:27:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 15:27:00 --> Final output sent to browser
DEBUG - 2019-12-09 15:27:00 --> Total execution time: 0.8498
INFO - 2019-12-09 15:59:11 --> Config Class Initialized
INFO - 2019-12-09 15:59:11 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:59:11 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:59:11 --> Utf8 Class Initialized
INFO - 2019-12-09 15:59:11 --> URI Class Initialized
DEBUG - 2019-12-09 15:59:11 --> No URI present. Default controller set.
INFO - 2019-12-09 15:59:11 --> Router Class Initialized
INFO - 2019-12-09 15:59:11 --> Output Class Initialized
INFO - 2019-12-09 15:59:11 --> Security Class Initialized
DEBUG - 2019-12-09 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:59:11 --> CSRF cookie sent
INFO - 2019-12-09 15:59:11 --> Input Class Initialized
INFO - 2019-12-09 15:59:11 --> Language Class Initialized
INFO - 2019-12-09 15:59:11 --> Language Class Initialized
INFO - 2019-12-09 15:59:11 --> Config Class Initialized
INFO - 2019-12-09 15:59:11 --> Loader Class Initialized
INFO - 2019-12-09 15:59:11 --> Helper loaded: url_helper
INFO - 2019-12-09 15:59:11 --> Helper loaded: common_helper
INFO - 2019-12-09 15:59:11 --> Helper loaded: language_helper
INFO - 2019-12-09 15:59:12 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:59:12 --> Helper loaded: email_helper
INFO - 2019-12-09 15:59:12 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:59:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:59:12 --> Parser Class Initialized
INFO - 2019-12-09 15:59:12 --> User Agent Class Initialized
INFO - 2019-12-09 15:59:12 --> Model Class Initialized
INFO - 2019-12-09 15:59:12 --> Database Driver Class Initialized
INFO - 2019-12-09 15:59:12 --> Model Class Initialized
DEBUG - 2019-12-09 15:59:12 --> Template Class Initialized
INFO - 2019-12-09 15:59:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:59:12 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:59:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:59:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:59:12 --> Encryption Class Initialized
DEBUG - 2019-12-09 15:59:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 15:59:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-09 15:59:12 --> Controller Class Initialized
DEBUG - 2019-12-09 15:59:12 --> pergo MX_Controller Initialized
DEBUG - 2019-12-09 15:59:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-09 15:59:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-09 15:59:12 --> Model Class Initialized
INFO - 2019-12-09 15:59:12 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 15:59:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-09 15:59:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-09 15:59:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-09 15:59:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-09 15:59:12 --> Final output sent to browser
DEBUG - 2019-12-09 15:59:12 --> Total execution time: 0.7698
INFO - 2019-12-09 15:59:13 --> Config Class Initialized
INFO - 2019-12-09 15:59:14 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:59:14 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:59:14 --> Utf8 Class Initialized
INFO - 2019-12-09 15:59:14 --> URI Class Initialized
INFO - 2019-12-09 15:59:14 --> Router Class Initialized
INFO - 2019-12-09 15:59:14 --> Output Class Initialized
INFO - 2019-12-09 15:59:14 --> Security Class Initialized
DEBUG - 2019-12-09 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:59:14 --> CSRF cookie sent
INFO - 2019-12-09 15:59:14 --> Input Class Initialized
INFO - 2019-12-09 15:59:14 --> Language Class Initialized
INFO - 2019-12-09 15:59:14 --> Language Class Initialized
INFO - 2019-12-09 15:59:14 --> Config Class Initialized
INFO - 2019-12-09 15:59:14 --> Loader Class Initialized
INFO - 2019-12-09 15:59:14 --> Helper loaded: url_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: common_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: language_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: email_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:59:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:59:14 --> Parser Class Initialized
INFO - 2019-12-09 15:59:14 --> User Agent Class Initialized
INFO - 2019-12-09 15:59:14 --> Model Class Initialized
INFO - 2019-12-09 15:59:14 --> Database Driver Class Initialized
INFO - 2019-12-09 15:59:14 --> Model Class Initialized
DEBUG - 2019-12-09 15:59:14 --> Template Class Initialized
INFO - 2019-12-09 15:59:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:59:14 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:59:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:59:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:59:14 --> Encryption Class Initialized
INFO - 2019-12-09 15:59:14 --> Controller Class Initialized
DEBUG - 2019-12-09 15:59:14 --> auth MX_Controller Initialized
DEBUG - 2019-12-09 15:59:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-09 15:59:14 --> Model Class Initialized
INFO - 2019-12-09 15:59:14 --> Config Class Initialized
INFO - 2019-12-09 15:59:14 --> Hooks Class Initialized
DEBUG - 2019-12-09 15:59:14 --> UTF-8 Support Enabled
INFO - 2019-12-09 15:59:14 --> Utf8 Class Initialized
INFO - 2019-12-09 15:59:14 --> URI Class Initialized
INFO - 2019-12-09 15:59:14 --> Router Class Initialized
INFO - 2019-12-09 15:59:14 --> Output Class Initialized
INFO - 2019-12-09 15:59:14 --> Security Class Initialized
DEBUG - 2019-12-09 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 15:59:14 --> CSRF cookie sent
INFO - 2019-12-09 15:59:14 --> Input Class Initialized
INFO - 2019-12-09 15:59:14 --> Language Class Initialized
INFO - 2019-12-09 15:59:14 --> Language Class Initialized
INFO - 2019-12-09 15:59:14 --> Config Class Initialized
INFO - 2019-12-09 15:59:14 --> Loader Class Initialized
INFO - 2019-12-09 15:59:14 --> Helper loaded: url_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: common_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: language_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: cookie_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: email_helper
INFO - 2019-12-09 15:59:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 15:59:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 15:59:14 --> Parser Class Initialized
INFO - 2019-12-09 15:59:14 --> User Agent Class Initialized
INFO - 2019-12-09 15:59:14 --> Model Class Initialized
INFO - 2019-12-09 15:59:14 --> Database Driver Class Initialized
INFO - 2019-12-09 15:59:14 --> Model Class Initialized
DEBUG - 2019-12-09 15:59:14 --> Template Class Initialized
INFO - 2019-12-09 15:59:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 15:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 15:59:15 --> Pagination Class Initialized
DEBUG - 2019-12-09 15:59:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 15:59:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 15:59:15 --> Encryption Class Initialized
INFO - 2019-12-09 15:59:15 --> Controller Class Initialized
DEBUG - 2019-12-09 15:59:15 --> statistics MX_Controller Initialized
DEBUG - 2019-12-09 15:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-09 15:59:15 --> Model Class Initialized
ERROR - 2019-12-09 15:59:15 --> Could not find the language line "Pending"
ERROR - 2019-12-09 15:59:15 --> Could not find the language line "Pending"
INFO - 2019-12-09 15:59:15 --> Helper loaded: inflector_helper
ERROR - 2019-12-09 15:59:15 --> Could not find the language line "total_orders"
ERROR - 2019-12-09 15:59:15 --> Could not find the language line "total_orders"
ERROR - 2019-12-09 15:59:15 --> Could not find the language line "Pending"
DEBUG - 2019-12-09 15:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-12-09 15:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 15:59:15 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 15:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 15:59:15 --> Model Class Initialized
DEBUG - 2019-12-09 15:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 15:59:15 --> Model Class Initialized
DEBUG - 2019-12-09 15:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 15:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 15:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 15:59:15 --> Final output sent to browser
DEBUG - 2019-12-09 15:59:15 --> Total execution time: 1.0830
INFO - 2019-12-09 16:00:40 --> Config Class Initialized
INFO - 2019-12-09 16:00:40 --> Hooks Class Initialized
DEBUG - 2019-12-09 16:00:40 --> UTF-8 Support Enabled
INFO - 2019-12-09 16:00:40 --> Utf8 Class Initialized
INFO - 2019-12-09 16:00:40 --> URI Class Initialized
INFO - 2019-12-09 16:00:40 --> Router Class Initialized
INFO - 2019-12-09 16:00:40 --> Output Class Initialized
INFO - 2019-12-09 16:00:40 --> Security Class Initialized
DEBUG - 2019-12-09 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 16:00:40 --> CSRF cookie sent
INFO - 2019-12-09 16:00:40 --> Input Class Initialized
INFO - 2019-12-09 16:00:40 --> Language Class Initialized
INFO - 2019-12-09 16:00:40 --> Language Class Initialized
INFO - 2019-12-09 16:00:40 --> Config Class Initialized
INFO - 2019-12-09 16:00:40 --> Loader Class Initialized
INFO - 2019-12-09 16:00:40 --> Helper loaded: url_helper
INFO - 2019-12-09 16:00:40 --> Helper loaded: common_helper
INFO - 2019-12-09 16:00:40 --> Helper loaded: language_helper
INFO - 2019-12-09 16:00:40 --> Helper loaded: cookie_helper
INFO - 2019-12-09 16:00:40 --> Helper loaded: email_helper
INFO - 2019-12-09 16:00:40 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 16:00:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 16:00:40 --> Parser Class Initialized
INFO - 2019-12-09 16:00:40 --> User Agent Class Initialized
INFO - 2019-12-09 16:00:40 --> Model Class Initialized
INFO - 2019-12-09 16:00:40 --> Database Driver Class Initialized
INFO - 2019-12-09 16:00:41 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:41 --> Template Class Initialized
INFO - 2019-12-09 16:00:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 16:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 16:00:41 --> Pagination Class Initialized
DEBUG - 2019-12-09 16:00:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 16:00:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 16:00:41 --> Encryption Class Initialized
INFO - 2019-12-09 16:00:41 --> Controller Class Initialized
DEBUG - 2019-12-09 16:00:41 --> provider MX_Controller Initialized
DEBUG - 2019-12-09 16:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/models/provider_model.php
INFO - 2019-12-09 16:00:41 --> Model Class Initialized
ERROR - 2019-12-09 16:00:41 --> Could not find the language line "Balance"
INFO - 2019-12-09 16:00:41 --> Helper loaded: inflector_helper
ERROR - 2019-12-09 16:00:41 --> Could not find the language line "api_providers"
DEBUG - 2019-12-09 16:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/views/index.php
DEBUG - 2019-12-09 16:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 16:00:41 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 16:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 16:00:41 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 16:00:41 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 16:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 16:00:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 16:00:41 --> Final output sent to browser
DEBUG - 2019-12-09 16:00:41 --> Total execution time: 0.9701
INFO - 2019-12-09 16:00:44 --> Config Class Initialized
INFO - 2019-12-09 16:00:44 --> Hooks Class Initialized
DEBUG - 2019-12-09 16:00:44 --> UTF-8 Support Enabled
INFO - 2019-12-09 16:00:44 --> Utf8 Class Initialized
INFO - 2019-12-09 16:00:44 --> URI Class Initialized
INFO - 2019-12-09 16:00:44 --> Router Class Initialized
INFO - 2019-12-09 16:00:44 --> Output Class Initialized
INFO - 2019-12-09 16:00:44 --> Security Class Initialized
DEBUG - 2019-12-09 16:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 16:00:45 --> CSRF cookie sent
INFO - 2019-12-09 16:00:45 --> Input Class Initialized
INFO - 2019-12-09 16:00:45 --> Language Class Initialized
INFO - 2019-12-09 16:00:45 --> Language Class Initialized
INFO - 2019-12-09 16:00:45 --> Config Class Initialized
INFO - 2019-12-09 16:00:45 --> Loader Class Initialized
INFO - 2019-12-09 16:00:45 --> Helper loaded: url_helper
INFO - 2019-12-09 16:00:45 --> Helper loaded: common_helper
INFO - 2019-12-09 16:00:45 --> Helper loaded: language_helper
INFO - 2019-12-09 16:00:45 --> Helper loaded: cookie_helper
INFO - 2019-12-09 16:00:45 --> Helper loaded: email_helper
INFO - 2019-12-09 16:00:45 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 16:00:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 16:00:45 --> Parser Class Initialized
INFO - 2019-12-09 16:00:45 --> User Agent Class Initialized
INFO - 2019-12-09 16:00:45 --> Model Class Initialized
INFO - 2019-12-09 16:00:45 --> Database Driver Class Initialized
INFO - 2019-12-09 16:00:45 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:45 --> Template Class Initialized
INFO - 2019-12-09 16:00:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 16:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 16:00:45 --> Pagination Class Initialized
DEBUG - 2019-12-09 16:00:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 16:00:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 16:00:45 --> Encryption Class Initialized
INFO - 2019-12-09 16:00:45 --> Controller Class Initialized
DEBUG - 2019-12-09 16:00:45 --> setting MX_Controller Initialized
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-09 16:00:45 --> Model Class Initialized
INFO - 2019-12-09 16:00:45 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 16:00:45 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 16:00:45 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 16:00:45 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 16:00:45 --> Final output sent to browser
DEBUG - 2019-12-09 16:00:45 --> Total execution time: 0.9592
INFO - 2019-12-09 16:00:48 --> Config Class Initialized
INFO - 2019-12-09 16:00:48 --> Hooks Class Initialized
DEBUG - 2019-12-09 16:00:48 --> UTF-8 Support Enabled
INFO - 2019-12-09 16:00:48 --> Utf8 Class Initialized
INFO - 2019-12-09 16:00:48 --> URI Class Initialized
INFO - 2019-12-09 16:00:48 --> Router Class Initialized
INFO - 2019-12-09 16:00:48 --> Output Class Initialized
INFO - 2019-12-09 16:00:48 --> Security Class Initialized
DEBUG - 2019-12-09 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 16:00:48 --> CSRF cookie sent
INFO - 2019-12-09 16:00:48 --> Input Class Initialized
INFO - 2019-12-09 16:00:48 --> Language Class Initialized
INFO - 2019-12-09 16:00:48 --> Language Class Initialized
INFO - 2019-12-09 16:00:48 --> Config Class Initialized
INFO - 2019-12-09 16:00:48 --> Loader Class Initialized
INFO - 2019-12-09 16:00:48 --> Helper loaded: url_helper
INFO - 2019-12-09 16:00:48 --> Helper loaded: common_helper
INFO - 2019-12-09 16:00:48 --> Helper loaded: language_helper
INFO - 2019-12-09 16:00:48 --> Helper loaded: cookie_helper
INFO - 2019-12-09 16:00:48 --> Helper loaded: email_helper
INFO - 2019-12-09 16:00:48 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 16:00:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 16:00:48 --> Parser Class Initialized
INFO - 2019-12-09 16:00:48 --> User Agent Class Initialized
INFO - 2019-12-09 16:00:48 --> Model Class Initialized
INFO - 2019-12-09 16:00:48 --> Database Driver Class Initialized
INFO - 2019-12-09 16:00:48 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:48 --> Template Class Initialized
INFO - 2019-12-09 16:00:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 16:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 16:00:48 --> Pagination Class Initialized
DEBUG - 2019-12-09 16:00:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 16:00:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 16:00:48 --> Encryption Class Initialized
INFO - 2019-12-09 16:00:48 --> Controller Class Initialized
DEBUG - 2019-12-09 16:00:48 --> setting MX_Controller Initialized
DEBUG - 2019-12-09 16:00:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-09 16:00:48 --> Model Class Initialized
INFO - 2019-12-09 16:00:48 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-09 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinbase.php
DEBUG - 2019-12-09 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-09 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 16:00:49 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 16:00:49 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 16:00:49 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 16:00:49 --> Final output sent to browser
DEBUG - 2019-12-09 16:00:49 --> Total execution time: 0.7471
INFO - 2019-12-09 16:00:54 --> Config Class Initialized
INFO - 2019-12-09 16:00:54 --> Hooks Class Initialized
DEBUG - 2019-12-09 16:00:54 --> UTF-8 Support Enabled
INFO - 2019-12-09 16:00:54 --> Utf8 Class Initialized
INFO - 2019-12-09 16:00:54 --> URI Class Initialized
INFO - 2019-12-09 16:00:54 --> Router Class Initialized
INFO - 2019-12-09 16:00:54 --> Output Class Initialized
INFO - 2019-12-09 16:00:54 --> Security Class Initialized
DEBUG - 2019-12-09 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-09 16:00:54 --> CSRF cookie sent
INFO - 2019-12-09 16:00:54 --> Input Class Initialized
INFO - 2019-12-09 16:00:54 --> Language Class Initialized
INFO - 2019-12-09 16:00:54 --> Language Class Initialized
INFO - 2019-12-09 16:00:54 --> Config Class Initialized
INFO - 2019-12-09 16:00:54 --> Loader Class Initialized
INFO - 2019-12-09 16:00:54 --> Helper loaded: url_helper
INFO - 2019-12-09 16:00:54 --> Helper loaded: common_helper
INFO - 2019-12-09 16:00:54 --> Helper loaded: language_helper
INFO - 2019-12-09 16:00:54 --> Helper loaded: cookie_helper
INFO - 2019-12-09 16:00:54 --> Helper loaded: email_helper
INFO - 2019-12-09 16:00:54 --> Helper loaded: file_manager_helper
INFO - 2019-12-09 16:00:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-09 16:00:54 --> Parser Class Initialized
INFO - 2019-12-09 16:00:54 --> User Agent Class Initialized
INFO - 2019-12-09 16:00:54 --> Model Class Initialized
INFO - 2019-12-09 16:00:54 --> Database Driver Class Initialized
INFO - 2019-12-09 16:00:54 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:54 --> Template Class Initialized
INFO - 2019-12-09 16:00:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-09 16:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-09 16:00:54 --> Pagination Class Initialized
DEBUG - 2019-12-09 16:00:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-09 16:00:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-09 16:00:54 --> Encryption Class Initialized
INFO - 2019-12-09 16:00:54 --> Controller Class Initialized
DEBUG - 2019-12-09 16:00:54 --> setting MX_Controller Initialized
DEBUG - 2019-12-09 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-09 16:00:54 --> Model Class Initialized
INFO - 2019-12-09 16:00:54 --> Helper loaded: inflector_helper
DEBUG - 2019-12-09 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-09 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/stripe.php
DEBUG - 2019-12-09 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-09 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-09 16:00:54 --> blocks MX_Controller Initialized
DEBUG - 2019-12-09 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-09 16:00:54 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-09 16:00:54 --> Model Class Initialized
DEBUG - 2019-12-09 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-09 16:00:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-09 16:00:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-09 16:00:55 --> Final output sent to browser
DEBUG - 2019-12-09 16:00:55 --> Total execution time: 0.8959
