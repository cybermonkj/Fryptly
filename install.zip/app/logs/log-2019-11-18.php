<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-18 10:09:38 --> Config Class Initialized
INFO - 2019-11-18 10:09:38 --> Hooks Class Initialized
DEBUG - 2019-11-18 10:09:38 --> UTF-8 Support Enabled
INFO - 2019-11-18 10:09:38 --> Utf8 Class Initialized
INFO - 2019-11-18 10:09:38 --> URI Class Initialized
DEBUG - 2019-11-18 10:09:38 --> No URI present. Default controller set.
INFO - 2019-11-18 10:09:38 --> Router Class Initialized
INFO - 2019-11-18 10:09:38 --> Output Class Initialized
INFO - 2019-11-18 10:09:38 --> Security Class Initialized
DEBUG - 2019-11-18 10:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-18 10:09:38 --> CSRF cookie sent
INFO - 2019-11-18 10:09:38 --> Input Class Initialized
INFO - 2019-11-18 10:09:38 --> Language Class Initialized
INFO - 2019-11-18 10:09:38 --> Language Class Initialized
INFO - 2019-11-18 10:09:38 --> Config Class Initialized
INFO - 2019-11-18 10:09:38 --> Loader Class Initialized
INFO - 2019-11-18 10:09:38 --> Helper loaded: url_helper
INFO - 2019-11-18 10:09:38 --> Helper loaded: common_helper
INFO - 2019-11-18 10:09:38 --> Helper loaded: language_helper
INFO - 2019-11-18 10:09:38 --> Helper loaded: cookie_helper
INFO - 2019-11-18 10:09:38 --> Helper loaded: email_helper
INFO - 2019-11-18 10:09:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-18 10:09:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-18 10:09:39 --> Parser Class Initialized
INFO - 2019-11-18 10:09:39 --> User Agent Class Initialized
INFO - 2019-11-18 10:09:39 --> Model Class Initialized
INFO - 2019-11-18 10:09:39 --> Database Driver Class Initialized
INFO - 2019-11-18 10:09:39 --> Model Class Initialized
DEBUG - 2019-11-18 10:09:39 --> Template Class Initialized
INFO - 2019-11-18 10:09:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-18 10:09:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-18 10:09:39 --> Pagination Class Initialized
DEBUG - 2019-11-18 10:09:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-18 10:09:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-18 10:09:39 --> Encryption Class Initialized
DEBUG - 2019-11-18 10:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-18 10:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-18 10:09:39 --> Controller Class Initialized
DEBUG - 2019-11-18 10:09:39 --> pergo MX_Controller Initialized
DEBUG - 2019-11-18 10:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-18 10:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-18 10:09:39 --> Model Class Initialized
INFO - 2019-11-18 10:09:39 --> Helper loaded: inflector_helper
DEBUG - 2019-11-18 10:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-18 10:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-18 10:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-18 10:09:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-18 10:09:39 --> Final output sent to browser
DEBUG - 2019-11-18 10:09:39 --> Total execution time: 1.5051
INFO - 2019-11-18 10:09:42 --> Config Class Initialized
INFO - 2019-11-18 10:09:42 --> Hooks Class Initialized
DEBUG - 2019-11-18 10:09:42 --> UTF-8 Support Enabled
INFO - 2019-11-18 10:09:42 --> Utf8 Class Initialized
INFO - 2019-11-18 10:09:42 --> URI Class Initialized
INFO - 2019-11-18 10:09:42 --> Router Class Initialized
INFO - 2019-11-18 10:09:42 --> Output Class Initialized
INFO - 2019-11-18 10:09:42 --> Security Class Initialized
DEBUG - 2019-11-18 10:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-18 10:09:42 --> CSRF cookie sent
INFO - 2019-11-18 10:09:42 --> Input Class Initialized
INFO - 2019-11-18 10:09:42 --> Language Class Initialized
INFO - 2019-11-18 10:09:42 --> Language Class Initialized
INFO - 2019-11-18 10:09:42 --> Config Class Initialized
INFO - 2019-11-18 10:09:42 --> Loader Class Initialized
INFO - 2019-11-18 10:09:42 --> Helper loaded: url_helper
INFO - 2019-11-18 10:09:42 --> Helper loaded: common_helper
INFO - 2019-11-18 10:09:42 --> Helper loaded: language_helper
INFO - 2019-11-18 10:09:42 --> Helper loaded: cookie_helper
INFO - 2019-11-18 10:09:42 --> Helper loaded: email_helper
INFO - 2019-11-18 10:09:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-18 10:09:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-18 10:09:42 --> Parser Class Initialized
INFO - 2019-11-18 10:09:42 --> User Agent Class Initialized
INFO - 2019-11-18 10:09:42 --> Model Class Initialized
INFO - 2019-11-18 10:09:42 --> Database Driver Class Initialized
INFO - 2019-11-18 10:09:42 --> Model Class Initialized
DEBUG - 2019-11-18 10:09:43 --> Template Class Initialized
INFO - 2019-11-18 10:09:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-18 10:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-18 10:09:43 --> Pagination Class Initialized
DEBUG - 2019-11-18 10:09:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-18 10:09:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-18 10:09:43 --> Encryption Class Initialized
INFO - 2019-11-18 10:09:43 --> Controller Class Initialized
DEBUG - 2019-11-18 10:09:43 --> package MX_Controller Initialized
DEBUG - 2019-11-18 10:09:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-18 10:09:43 --> Model Class Initialized
INFO - 2019-11-18 10:09:43 --> Helper loaded: inflector_helper
DEBUG - 2019-11-18 10:09:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-18 10:09:43 --> blocks MX_Controller Initialized
DEBUG - 2019-11-18 10:09:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-18 10:09:43 --> Model Class Initialized
DEBUG - 2019-11-18 10:09:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-18 10:09:43 --> Model Class Initialized
DEBUG - 2019-11-18 10:09:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-18 10:09:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-18 10:09:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-18 10:09:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-18 10:09:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-18 10:09:43 --> Final output sent to browser
DEBUG - 2019-11-18 10:09:43 --> Total execution time: 1.1195
INFO - 2019-11-18 10:09:47 --> Config Class Initialized
INFO - 2019-11-18 10:09:47 --> Hooks Class Initialized
DEBUG - 2019-11-18 10:09:47 --> UTF-8 Support Enabled
INFO - 2019-11-18 10:09:47 --> Utf8 Class Initialized
INFO - 2019-11-18 10:09:47 --> URI Class Initialized
INFO - 2019-11-18 10:09:47 --> Router Class Initialized
INFO - 2019-11-18 10:09:47 --> Output Class Initialized
INFO - 2019-11-18 10:09:47 --> Security Class Initialized
DEBUG - 2019-11-18 10:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-18 10:09:47 --> CSRF cookie sent
INFO - 2019-11-18 10:09:47 --> CSRF token verified
INFO - 2019-11-18 10:09:47 --> Input Class Initialized
INFO - 2019-11-18 10:09:47 --> Language Class Initialized
INFO - 2019-11-18 10:09:47 --> Language Class Initialized
INFO - 2019-11-18 10:09:47 --> Config Class Initialized
INFO - 2019-11-18 10:09:47 --> Loader Class Initialized
INFO - 2019-11-18 10:09:47 --> Helper loaded: url_helper
INFO - 2019-11-18 10:09:47 --> Helper loaded: common_helper
INFO - 2019-11-18 10:09:47 --> Helper loaded: language_helper
INFO - 2019-11-18 10:09:47 --> Helper loaded: cookie_helper
INFO - 2019-11-18 10:09:47 --> Helper loaded: email_helper
INFO - 2019-11-18 10:09:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-18 10:09:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-18 10:09:47 --> Parser Class Initialized
INFO - 2019-11-18 10:09:47 --> User Agent Class Initialized
INFO - 2019-11-18 10:09:47 --> Model Class Initialized
INFO - 2019-11-18 10:09:47 --> Database Driver Class Initialized
INFO - 2019-11-18 10:09:47 --> Model Class Initialized
DEBUG - 2019-11-18 10:09:47 --> Template Class Initialized
INFO - 2019-11-18 10:09:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-18 10:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-18 10:09:47 --> Pagination Class Initialized
DEBUG - 2019-11-18 10:09:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-18 10:09:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-18 10:09:47 --> Encryption Class Initialized
INFO - 2019-11-18 10:09:47 --> Controller Class Initialized
DEBUG - 2019-11-18 10:09:47 --> checkout MX_Controller Initialized
DEBUG - 2019-11-18 10:09:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-18 10:09:47 --> Model Class Initialized
INFO - 2019-11-18 10:09:47 --> Helper loaded: inflector_helper
ERROR - 2019-11-18 10:09:47 --> Could not find the language line "shopier"
DEBUG - 2019-11-18 10:09:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-18 10:09:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-18 10:09:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-18 10:09:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-18 10:09:47 --> Model Class Initialized
DEBUG - 2019-11-18 10:09:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-18 10:09:47 --> Model Class Initialized
DEBUG - 2019-11-18 10:09:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-18 10:09:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-18 10:09:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-18 10:09:47 --> Final output sent to browser
DEBUG - 2019-11-18 10:09:47 --> Total execution time: 0.6049
INFO - 2019-11-18 10:09:57 --> Config Class Initialized
INFO - 2019-11-18 10:09:57 --> Hooks Class Initialized
DEBUG - 2019-11-18 10:09:57 --> UTF-8 Support Enabled
INFO - 2019-11-18 10:09:57 --> Utf8 Class Initialized
INFO - 2019-11-18 10:09:57 --> URI Class Initialized
INFO - 2019-11-18 10:09:57 --> Router Class Initialized
INFO - 2019-11-18 10:09:57 --> Output Class Initialized
INFO - 2019-11-18 10:09:57 --> Security Class Initialized
DEBUG - 2019-11-18 10:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-18 10:09:57 --> CSRF cookie sent
INFO - 2019-11-18 10:09:57 --> CSRF token verified
INFO - 2019-11-18 10:09:57 --> Input Class Initialized
INFO - 2019-11-18 10:09:57 --> Language Class Initialized
INFO - 2019-11-18 10:09:57 --> Language Class Initialized
INFO - 2019-11-18 10:09:57 --> Config Class Initialized
INFO - 2019-11-18 10:09:57 --> Loader Class Initialized
INFO - 2019-11-18 10:09:57 --> Helper loaded: url_helper
INFO - 2019-11-18 10:09:57 --> Helper loaded: common_helper
INFO - 2019-11-18 10:09:58 --> Helper loaded: language_helper
INFO - 2019-11-18 10:09:58 --> Helper loaded: cookie_helper
INFO - 2019-11-18 10:09:58 --> Helper loaded: email_helper
INFO - 2019-11-18 10:09:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-18 10:09:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-18 10:09:58 --> Parser Class Initialized
INFO - 2019-11-18 10:09:58 --> User Agent Class Initialized
INFO - 2019-11-18 10:09:58 --> Model Class Initialized
INFO - 2019-11-18 10:09:58 --> Database Driver Class Initialized
INFO - 2019-11-18 10:09:58 --> Model Class Initialized
DEBUG - 2019-11-18 10:09:58 --> Template Class Initialized
INFO - 2019-11-18 10:09:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-18 10:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-18 10:09:58 --> Pagination Class Initialized
DEBUG - 2019-11-18 10:09:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-18 10:09:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-18 10:09:58 --> Encryption Class Initialized
INFO - 2019-11-18 10:09:58 --> Controller Class Initialized
DEBUG - 2019-11-18 10:09:58 --> checkout MX_Controller Initialized
DEBUG - 2019-11-18 10:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-18 10:09:58 --> Model Class Initialized
DEBUG - 2019-11-18 10:09:58 --> shopier MX_Controller Initialized
DEBUG - 2019-11-18 10:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-18 10:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-18 10:09:58 --> Final output sent to browser
DEBUG - 2019-11-18 10:09:58 --> Total execution time: 0.5199
INFO - 2019-11-18 11:13:52 --> Config Class Initialized
INFO - 2019-11-18 11:13:52 --> Hooks Class Initialized
DEBUG - 2019-11-18 11:13:52 --> UTF-8 Support Enabled
INFO - 2019-11-18 11:13:52 --> Utf8 Class Initialized
INFO - 2019-11-18 11:13:52 --> URI Class Initialized
DEBUG - 2019-11-18 11:13:52 --> No URI present. Default controller set.
INFO - 2019-11-18 11:13:52 --> Router Class Initialized
INFO - 2019-11-18 11:13:52 --> Output Class Initialized
INFO - 2019-11-18 11:13:52 --> Security Class Initialized
DEBUG - 2019-11-18 11:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-18 11:13:52 --> CSRF cookie sent
INFO - 2019-11-18 11:13:52 --> Input Class Initialized
INFO - 2019-11-18 11:13:52 --> Language Class Initialized
INFO - 2019-11-18 11:13:52 --> Language Class Initialized
INFO - 2019-11-18 11:13:52 --> Config Class Initialized
INFO - 2019-11-18 11:13:52 --> Loader Class Initialized
INFO - 2019-11-18 11:13:52 --> Helper loaded: url_helper
INFO - 2019-11-18 11:13:52 --> Helper loaded: common_helper
INFO - 2019-11-18 11:13:52 --> Helper loaded: language_helper
INFO - 2019-11-18 11:13:52 --> Helper loaded: cookie_helper
INFO - 2019-11-18 11:13:52 --> Helper loaded: email_helper
INFO - 2019-11-18 11:13:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-18 11:13:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-18 11:13:52 --> Parser Class Initialized
INFO - 2019-11-18 11:13:52 --> User Agent Class Initialized
INFO - 2019-11-18 11:13:52 --> Model Class Initialized
INFO - 2019-11-18 11:13:52 --> Database Driver Class Initialized
INFO - 2019-11-18 11:13:52 --> Model Class Initialized
DEBUG - 2019-11-18 11:13:52 --> Template Class Initialized
INFO - 2019-11-18 11:13:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-18 11:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-18 11:13:52 --> Pagination Class Initialized
DEBUG - 2019-11-18 11:13:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-18 11:13:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-18 11:13:53 --> Encryption Class Initialized
DEBUG - 2019-11-18 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-18 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-18 11:13:53 --> Controller Class Initialized
DEBUG - 2019-11-18 11:13:53 --> pergo MX_Controller Initialized
DEBUG - 2019-11-18 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-18 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-18 11:13:53 --> Model Class Initialized
INFO - 2019-11-18 11:13:53 --> Helper loaded: inflector_helper
DEBUG - 2019-11-18 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-18 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-18 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-18 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-18 11:13:53 --> Final output sent to browser
DEBUG - 2019-11-18 11:13:53 --> Total execution time: 0.6433
