<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-23 16:00:25 --> Config Class Initialized
INFO - 2020-03-23 16:00:25 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:00:25 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:00:25 --> Utf8 Class Initialized
INFO - 2020-03-23 16:00:25 --> URI Class Initialized
DEBUG - 2020-03-23 16:00:25 --> No URI present. Default controller set.
INFO - 2020-03-23 16:00:25 --> Router Class Initialized
INFO - 2020-03-23 16:00:26 --> Output Class Initialized
INFO - 2020-03-23 16:00:26 --> Security Class Initialized
DEBUG - 2020-03-23 16:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:00:26 --> CSRF cookie sent
INFO - 2020-03-23 16:00:26 --> Input Class Initialized
INFO - 2020-03-23 16:00:26 --> Language Class Initialized
INFO - 2020-03-23 16:00:26 --> Language Class Initialized
INFO - 2020-03-23 16:00:26 --> Config Class Initialized
INFO - 2020-03-23 16:00:26 --> Loader Class Initialized
INFO - 2020-03-23 16:00:26 --> Helper loaded: url_helper
INFO - 2020-03-23 16:00:26 --> Helper loaded: common_helper
INFO - 2020-03-23 16:00:26 --> Helper loaded: language_helper
INFO - 2020-03-23 16:00:26 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:00:26 --> Helper loaded: email_helper
INFO - 2020-03-23 16:00:26 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:00:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:00:26 --> Parser Class Initialized
INFO - 2020-03-23 16:00:26 --> User Agent Class Initialized
INFO - 2020-03-23 16:00:26 --> Model Class Initialized
INFO - 2020-03-23 16:00:26 --> Database Driver Class Initialized
INFO - 2020-03-23 16:00:26 --> Model Class Initialized
DEBUG - 2020-03-23 16:00:26 --> Template Class Initialized
INFO - 2020-03-23 16:00:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:00:26 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:00:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:00:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:00:26 --> Encryption Class Initialized
DEBUG - 2020-03-23 16:00:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:00:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 16:00:26 --> Controller Class Initialized
DEBUG - 2020-03-23 16:00:26 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 16:00:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:00:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 16:00:26 --> Model Class Initialized
INFO - 2020-03-23 16:00:27 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 16:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 16:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 16:00:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 16:00:27 --> Final output sent to browser
DEBUG - 2020-03-23 16:00:27 --> Total execution time: 1.7486
INFO - 2020-03-23 16:00:30 --> Config Class Initialized
INFO - 2020-03-23 16:00:30 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:00:30 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:00:30 --> Utf8 Class Initialized
INFO - 2020-03-23 16:00:30 --> URI Class Initialized
INFO - 2020-03-23 16:00:30 --> Router Class Initialized
INFO - 2020-03-23 16:00:30 --> Output Class Initialized
INFO - 2020-03-23 16:00:30 --> Security Class Initialized
DEBUG - 2020-03-23 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:00:30 --> CSRF cookie sent
INFO - 2020-03-23 16:00:30 --> Input Class Initialized
INFO - 2020-03-23 16:00:30 --> Language Class Initialized
INFO - 2020-03-23 16:00:30 --> Language Class Initialized
INFO - 2020-03-23 16:00:30 --> Config Class Initialized
INFO - 2020-03-23 16:00:30 --> Loader Class Initialized
INFO - 2020-03-23 16:00:30 --> Helper loaded: url_helper
INFO - 2020-03-23 16:00:30 --> Helper loaded: common_helper
INFO - 2020-03-23 16:00:30 --> Helper loaded: language_helper
INFO - 2020-03-23 16:00:30 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:00:30 --> Helper loaded: email_helper
INFO - 2020-03-23 16:00:30 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:00:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:00:31 --> Parser Class Initialized
INFO - 2020-03-23 16:00:31 --> User Agent Class Initialized
INFO - 2020-03-23 16:00:31 --> Model Class Initialized
INFO - 2020-03-23 16:00:31 --> Database Driver Class Initialized
INFO - 2020-03-23 16:00:31 --> Model Class Initialized
DEBUG - 2020-03-23 16:00:31 --> Template Class Initialized
INFO - 2020-03-23 16:00:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:00:31 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:00:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:00:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:00:31 --> Encryption Class Initialized
INFO - 2020-03-23 16:00:31 --> Controller Class Initialized
DEBUG - 2020-03-23 16:00:31 --> package MX_Controller Initialized
DEBUG - 2020-03-23 16:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-23 16:00:31 --> Model Class Initialized
INFO - 2020-03-23 16:00:31 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:00:31 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:00:31 --> Model Class Initialized
DEBUG - 2020-03-23 16:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:00:31 --> Model Class Initialized
DEBUG - 2020-03-23 16:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-23 16:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:00:31 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 16:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 16:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 16:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 16:00:31 --> Final output sent to browser
DEBUG - 2020-03-23 16:00:31 --> Total execution time: 1.0331
INFO - 2020-03-23 16:00:54 --> Config Class Initialized
INFO - 2020-03-23 16:00:54 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:00:54 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:00:54 --> Utf8 Class Initialized
INFO - 2020-03-23 16:00:54 --> URI Class Initialized
INFO - 2020-03-23 16:00:54 --> Router Class Initialized
INFO - 2020-03-23 16:00:54 --> Output Class Initialized
INFO - 2020-03-23 16:00:54 --> Security Class Initialized
DEBUG - 2020-03-23 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:00:54 --> CSRF cookie sent
INFO - 2020-03-23 16:00:54 --> Input Class Initialized
INFO - 2020-03-23 16:00:54 --> Language Class Initialized
INFO - 2020-03-23 16:00:54 --> Language Class Initialized
INFO - 2020-03-23 16:00:54 --> Config Class Initialized
INFO - 2020-03-23 16:00:54 --> Loader Class Initialized
INFO - 2020-03-23 16:00:54 --> Helper loaded: url_helper
INFO - 2020-03-23 16:00:54 --> Helper loaded: common_helper
INFO - 2020-03-23 16:00:54 --> Helper loaded: language_helper
INFO - 2020-03-23 16:00:54 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:00:54 --> Helper loaded: email_helper
INFO - 2020-03-23 16:00:54 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:00:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:00:54 --> Parser Class Initialized
INFO - 2020-03-23 16:00:54 --> User Agent Class Initialized
INFO - 2020-03-23 16:00:54 --> Model Class Initialized
INFO - 2020-03-23 16:00:54 --> Database Driver Class Initialized
INFO - 2020-03-23 16:00:54 --> Model Class Initialized
DEBUG - 2020-03-23 16:00:54 --> Template Class Initialized
INFO - 2020-03-23 16:00:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:00:54 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:00:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:00:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:00:54 --> Encryption Class Initialized
INFO - 2020-03-23 16:00:54 --> Controller Class Initialized
DEBUG - 2020-03-23 16:00:54 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 16:00:54 --> Model Class Initialized
DEBUG - 2020-03-23 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 16:00:54 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-23 16:00:54 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-23 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-23 16:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 16:00:54 --> Final output sent to browser
DEBUG - 2020-03-23 16:00:54 --> Total execution time: 0.5236
INFO - 2020-03-23 16:00:56 --> Config Class Initialized
INFO - 2020-03-23 16:00:56 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:00:56 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:00:56 --> Utf8 Class Initialized
INFO - 2020-03-23 16:00:56 --> URI Class Initialized
INFO - 2020-03-23 16:00:56 --> Router Class Initialized
INFO - 2020-03-23 16:00:56 --> Output Class Initialized
INFO - 2020-03-23 16:00:56 --> Security Class Initialized
DEBUG - 2020-03-23 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:00:56 --> CSRF cookie sent
INFO - 2020-03-23 16:00:56 --> CSRF token verified
INFO - 2020-03-23 16:00:56 --> Input Class Initialized
INFO - 2020-03-23 16:00:56 --> Language Class Initialized
INFO - 2020-03-23 16:00:56 --> Language Class Initialized
INFO - 2020-03-23 16:00:56 --> Config Class Initialized
INFO - 2020-03-23 16:00:56 --> Loader Class Initialized
INFO - 2020-03-23 16:00:56 --> Helper loaded: url_helper
INFO - 2020-03-23 16:00:56 --> Helper loaded: common_helper
INFO - 2020-03-23 16:00:56 --> Helper loaded: language_helper
INFO - 2020-03-23 16:00:56 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:00:56 --> Helper loaded: email_helper
INFO - 2020-03-23 16:00:56 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:00:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:00:56 --> Parser Class Initialized
INFO - 2020-03-23 16:00:56 --> User Agent Class Initialized
INFO - 2020-03-23 16:00:56 --> Model Class Initialized
INFO - 2020-03-23 16:00:56 --> Database Driver Class Initialized
INFO - 2020-03-23 16:00:56 --> Model Class Initialized
DEBUG - 2020-03-23 16:00:56 --> Template Class Initialized
INFO - 2020-03-23 16:00:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:00:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:00:56 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:00:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:00:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:00:56 --> Encryption Class Initialized
INFO - 2020-03-23 16:00:56 --> Controller Class Initialized
DEBUG - 2020-03-23 16:00:56 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 16:00:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 16:00:56 --> Model Class Initialized
INFO - 2020-03-23 16:01:05 --> Config Class Initialized
INFO - 2020-03-23 16:01:05 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:01:05 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:01:05 --> Utf8 Class Initialized
INFO - 2020-03-23 16:01:05 --> URI Class Initialized
INFO - 2020-03-23 16:01:05 --> Router Class Initialized
INFO - 2020-03-23 16:01:05 --> Output Class Initialized
INFO - 2020-03-23 16:01:05 --> Security Class Initialized
DEBUG - 2020-03-23 16:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:01:05 --> CSRF cookie sent
INFO - 2020-03-23 16:01:05 --> CSRF token verified
INFO - 2020-03-23 16:01:05 --> Input Class Initialized
INFO - 2020-03-23 16:01:05 --> Language Class Initialized
INFO - 2020-03-23 16:01:05 --> Language Class Initialized
INFO - 2020-03-23 16:01:05 --> Config Class Initialized
INFO - 2020-03-23 16:01:05 --> Loader Class Initialized
INFO - 2020-03-23 16:01:05 --> Helper loaded: url_helper
INFO - 2020-03-23 16:01:05 --> Helper loaded: common_helper
INFO - 2020-03-23 16:01:05 --> Helper loaded: language_helper
INFO - 2020-03-23 16:01:05 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:01:05 --> Helper loaded: email_helper
INFO - 2020-03-23 16:01:05 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:01:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:01:05 --> Parser Class Initialized
INFO - 2020-03-23 16:01:05 --> User Agent Class Initialized
INFO - 2020-03-23 16:01:05 --> Model Class Initialized
INFO - 2020-03-23 16:01:05 --> Database Driver Class Initialized
INFO - 2020-03-23 16:01:05 --> Model Class Initialized
DEBUG - 2020-03-23 16:01:05 --> Template Class Initialized
INFO - 2020-03-23 16:01:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:01:05 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:01:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:01:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:01:05 --> Encryption Class Initialized
INFO - 2020-03-23 16:01:05 --> Controller Class Initialized
DEBUG - 2020-03-23 16:01:05 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 16:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 16:01:05 --> Model Class Initialized
INFO - 2020-03-23 16:01:10 --> Config Class Initialized
INFO - 2020-03-23 16:01:10 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:01:10 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:01:10 --> Utf8 Class Initialized
INFO - 2020-03-23 16:01:10 --> URI Class Initialized
INFO - 2020-03-23 16:01:10 --> Router Class Initialized
INFO - 2020-03-23 16:01:10 --> Output Class Initialized
INFO - 2020-03-23 16:01:10 --> Security Class Initialized
DEBUG - 2020-03-23 16:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:01:10 --> CSRF cookie sent
INFO - 2020-03-23 16:01:10 --> CSRF token verified
INFO - 2020-03-23 16:01:10 --> Input Class Initialized
INFO - 2020-03-23 16:01:10 --> Language Class Initialized
INFO - 2020-03-23 16:01:10 --> Language Class Initialized
INFO - 2020-03-23 16:01:10 --> Config Class Initialized
INFO - 2020-03-23 16:01:10 --> Loader Class Initialized
INFO - 2020-03-23 16:01:10 --> Helper loaded: url_helper
INFO - 2020-03-23 16:01:10 --> Helper loaded: common_helper
INFO - 2020-03-23 16:01:10 --> Helper loaded: language_helper
INFO - 2020-03-23 16:01:10 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:01:10 --> Helper loaded: email_helper
INFO - 2020-03-23 16:01:10 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:01:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:01:10 --> Parser Class Initialized
INFO - 2020-03-23 16:01:10 --> User Agent Class Initialized
INFO - 2020-03-23 16:01:10 --> Model Class Initialized
INFO - 2020-03-23 16:01:10 --> Database Driver Class Initialized
INFO - 2020-03-23 16:01:10 --> Model Class Initialized
DEBUG - 2020-03-23 16:01:10 --> Template Class Initialized
INFO - 2020-03-23 16:01:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:01:10 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:01:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:01:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:01:10 --> Encryption Class Initialized
INFO - 2020-03-23 16:01:10 --> Controller Class Initialized
DEBUG - 2020-03-23 16:01:10 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 16:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 16:01:10 --> Model Class Initialized
INFO - 2020-03-23 16:01:57 --> Config Class Initialized
INFO - 2020-03-23 16:01:57 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:01:57 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:01:57 --> Utf8 Class Initialized
INFO - 2020-03-23 16:01:57 --> URI Class Initialized
INFO - 2020-03-23 16:01:57 --> Router Class Initialized
INFO - 2020-03-23 16:01:57 --> Output Class Initialized
INFO - 2020-03-23 16:01:57 --> Security Class Initialized
DEBUG - 2020-03-23 16:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:01:57 --> CSRF cookie sent
INFO - 2020-03-23 16:01:57 --> CSRF token verified
INFO - 2020-03-23 16:01:57 --> Input Class Initialized
INFO - 2020-03-23 16:01:57 --> Language Class Initialized
INFO - 2020-03-23 16:01:57 --> Language Class Initialized
INFO - 2020-03-23 16:01:57 --> Config Class Initialized
INFO - 2020-03-23 16:01:57 --> Loader Class Initialized
INFO - 2020-03-23 16:01:57 --> Helper loaded: url_helper
INFO - 2020-03-23 16:01:57 --> Helper loaded: common_helper
INFO - 2020-03-23 16:01:57 --> Helper loaded: language_helper
INFO - 2020-03-23 16:01:57 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:01:58 --> Helper loaded: email_helper
INFO - 2020-03-23 16:01:58 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:01:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:01:58 --> Parser Class Initialized
INFO - 2020-03-23 16:01:58 --> User Agent Class Initialized
INFO - 2020-03-23 16:01:58 --> Model Class Initialized
INFO - 2020-03-23 16:01:58 --> Database Driver Class Initialized
INFO - 2020-03-23 16:01:58 --> Model Class Initialized
DEBUG - 2020-03-23 16:01:58 --> Template Class Initialized
INFO - 2020-03-23 16:01:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:01:58 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:01:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:01:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:01:58 --> Encryption Class Initialized
INFO - 2020-03-23 16:01:58 --> Controller Class Initialized
DEBUG - 2020-03-23 16:01:58 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 16:01:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 16:01:58 --> Model Class Initialized
INFO - 2020-03-23 16:02:02 --> Config Class Initialized
INFO - 2020-03-23 16:02:02 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:02:02 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:02:02 --> Utf8 Class Initialized
INFO - 2020-03-23 16:02:02 --> URI Class Initialized
INFO - 2020-03-23 16:02:02 --> Router Class Initialized
INFO - 2020-03-23 16:02:02 --> Output Class Initialized
INFO - 2020-03-23 16:02:02 --> Security Class Initialized
DEBUG - 2020-03-23 16:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:02:02 --> CSRF cookie sent
INFO - 2020-03-23 16:02:02 --> Input Class Initialized
INFO - 2020-03-23 16:02:02 --> Language Class Initialized
INFO - 2020-03-23 16:02:02 --> Language Class Initialized
INFO - 2020-03-23 16:02:02 --> Config Class Initialized
INFO - 2020-03-23 16:02:02 --> Loader Class Initialized
INFO - 2020-03-23 16:02:02 --> Helper loaded: url_helper
INFO - 2020-03-23 16:02:03 --> Helper loaded: common_helper
INFO - 2020-03-23 16:02:03 --> Helper loaded: language_helper
INFO - 2020-03-23 16:02:03 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:02:03 --> Helper loaded: email_helper
INFO - 2020-03-23 16:02:03 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:02:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:02:03 --> Parser Class Initialized
INFO - 2020-03-23 16:02:03 --> User Agent Class Initialized
INFO - 2020-03-23 16:02:03 --> Model Class Initialized
INFO - 2020-03-23 16:02:03 --> Database Driver Class Initialized
INFO - 2020-03-23 16:02:03 --> Model Class Initialized
DEBUG - 2020-03-23 16:02:03 --> Template Class Initialized
INFO - 2020-03-23 16:02:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:02:03 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:02:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:02:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:02:03 --> Encryption Class Initialized
INFO - 2020-03-23 16:02:03 --> Controller Class Initialized
DEBUG - 2020-03-23 16:02:03 --> statistics MX_Controller Initialized
DEBUG - 2020-03-23 16:02:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-23 16:02:03 --> Model Class Initialized
ERROR - 2020-03-23 16:02:03 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:02:03 --> Could not find the language line "Pending"
INFO - 2020-03-23 16:02:03 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 16:02:03 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 16:02:03 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 16:02:03 --> Could not find the language line "Pending"
DEBUG - 2020-03-23 16:02:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-23 16:02:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:02:03 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:02:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:02:03 --> Model Class Initialized
DEBUG - 2020-03-23 16:02:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:02:03 --> Model Class Initialized
DEBUG - 2020-03-23 16:02:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:02:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:02:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:02:03 --> Final output sent to browser
DEBUG - 2020-03-23 16:02:03 --> Total execution time: 0.8781
INFO - 2020-03-23 16:13:22 --> Config Class Initialized
INFO - 2020-03-23 16:13:22 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:13:22 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:13:22 --> Utf8 Class Initialized
INFO - 2020-03-23 16:13:22 --> URI Class Initialized
INFO - 2020-03-23 16:13:22 --> Router Class Initialized
INFO - 2020-03-23 16:13:22 --> Output Class Initialized
INFO - 2020-03-23 16:13:22 --> Security Class Initialized
DEBUG - 2020-03-23 16:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:13:22 --> CSRF cookie sent
INFO - 2020-03-23 16:13:22 --> Input Class Initialized
INFO - 2020-03-23 16:13:22 --> Language Class Initialized
INFO - 2020-03-23 16:13:22 --> Language Class Initialized
INFO - 2020-03-23 16:13:22 --> Config Class Initialized
INFO - 2020-03-23 16:13:22 --> Loader Class Initialized
INFO - 2020-03-23 16:13:22 --> Helper loaded: url_helper
INFO - 2020-03-23 16:13:22 --> Helper loaded: common_helper
INFO - 2020-03-23 16:13:22 --> Helper loaded: language_helper
INFO - 2020-03-23 16:13:22 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:13:22 --> Helper loaded: email_helper
INFO - 2020-03-23 16:13:22 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:13:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:13:22 --> Parser Class Initialized
INFO - 2020-03-23 16:13:22 --> User Agent Class Initialized
INFO - 2020-03-23 16:13:22 --> Model Class Initialized
INFO - 2020-03-23 16:13:22 --> Database Driver Class Initialized
INFO - 2020-03-23 16:13:22 --> Model Class Initialized
DEBUG - 2020-03-23 16:13:22 --> Template Class Initialized
INFO - 2020-03-23 16:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:13:22 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:13:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:13:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:13:22 --> Encryption Class Initialized
INFO - 2020-03-23 16:13:22 --> Controller Class Initialized
DEBUG - 2020-03-23 16:13:22 --> setting MX_Controller Initialized
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-23 16:13:22 --> Model Class Initialized
INFO - 2020-03-23 16:13:22 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:13:22 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:13:22 --> Model Class Initialized
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:13:22 --> Model Class Initialized
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:13:22 --> Final output sent to browser
DEBUG - 2020-03-23 16:13:22 --> Total execution time: 0.7807
INFO - 2020-03-23 16:13:26 --> Config Class Initialized
INFO - 2020-03-23 16:13:26 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:13:26 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:13:26 --> Utf8 Class Initialized
INFO - 2020-03-23 16:13:26 --> URI Class Initialized
INFO - 2020-03-23 16:13:26 --> Router Class Initialized
INFO - 2020-03-23 16:13:26 --> Output Class Initialized
INFO - 2020-03-23 16:13:26 --> Security Class Initialized
DEBUG - 2020-03-23 16:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:13:26 --> CSRF cookie sent
INFO - 2020-03-23 16:13:26 --> Input Class Initialized
INFO - 2020-03-23 16:13:26 --> Language Class Initialized
INFO - 2020-03-23 16:13:26 --> Language Class Initialized
INFO - 2020-03-23 16:13:26 --> Config Class Initialized
INFO - 2020-03-23 16:13:26 --> Loader Class Initialized
INFO - 2020-03-23 16:13:26 --> Helper loaded: url_helper
INFO - 2020-03-23 16:13:26 --> Helper loaded: common_helper
INFO - 2020-03-23 16:13:26 --> Helper loaded: language_helper
INFO - 2020-03-23 16:13:26 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:13:26 --> Helper loaded: email_helper
INFO - 2020-03-23 16:13:26 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:13:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:13:26 --> Parser Class Initialized
INFO - 2020-03-23 16:13:26 --> User Agent Class Initialized
INFO - 2020-03-23 16:13:26 --> Model Class Initialized
INFO - 2020-03-23 16:13:26 --> Database Driver Class Initialized
INFO - 2020-03-23 16:13:26 --> Model Class Initialized
DEBUG - 2020-03-23 16:13:26 --> Template Class Initialized
INFO - 2020-03-23 16:13:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:13:26 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:13:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:13:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:13:26 --> Encryption Class Initialized
INFO - 2020-03-23 16:13:26 --> Controller Class Initialized
DEBUG - 2020-03-23 16:13:26 --> setting MX_Controller Initialized
DEBUG - 2020-03-23 16:13:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-23 16:13:26 --> Model Class Initialized
INFO - 2020-03-23 16:13:26 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:13:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2020-03-23 16:13:26 --> Could not find the language line "Paytm_Integration"
ERROR - 2020-03-23 16:13:26 --> Could not find the language line "Paytm_mid_merchant_id"
ERROR - 2020-03-23 16:13:26 --> Could not find the language line "paytm_merchant_key"
DEBUG - 2020-03-23 16:13:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paytm.php
DEBUG - 2020-03-23 16:13:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-23 16:13:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:13:26 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:13:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:13:26 --> Model Class Initialized
DEBUG - 2020-03-23 16:13:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:13:27 --> Model Class Initialized
DEBUG - 2020-03-23 16:13:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:13:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:13:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:13:27 --> Final output sent to browser
DEBUG - 2020-03-23 16:13:27 --> Total execution time: 0.7132
INFO - 2020-03-23 16:41:40 --> Config Class Initialized
INFO - 2020-03-23 16:41:40 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:41:40 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:41:40 --> Utf8 Class Initialized
INFO - 2020-03-23 16:41:40 --> URI Class Initialized
INFO - 2020-03-23 16:41:40 --> Router Class Initialized
INFO - 2020-03-23 16:41:40 --> Output Class Initialized
INFO - 2020-03-23 16:41:40 --> Security Class Initialized
DEBUG - 2020-03-23 16:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:41:40 --> CSRF cookie sent
INFO - 2020-03-23 16:41:40 --> Input Class Initialized
INFO - 2020-03-23 16:41:40 --> Language Class Initialized
INFO - 2020-03-23 16:41:40 --> Language Class Initialized
INFO - 2020-03-23 16:41:40 --> Config Class Initialized
INFO - 2020-03-23 16:41:40 --> Loader Class Initialized
INFO - 2020-03-23 16:41:40 --> Helper loaded: url_helper
INFO - 2020-03-23 16:41:40 --> Helper loaded: common_helper
INFO - 2020-03-23 16:41:40 --> Helper loaded: language_helper
INFO - 2020-03-23 16:41:40 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:41:40 --> Helper loaded: email_helper
INFO - 2020-03-23 16:41:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:41:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:41:40 --> Parser Class Initialized
INFO - 2020-03-23 16:41:40 --> User Agent Class Initialized
INFO - 2020-03-23 16:41:40 --> Model Class Initialized
INFO - 2020-03-23 16:41:40 --> Database Driver Class Initialized
INFO - 2020-03-23 16:41:40 --> Model Class Initialized
DEBUG - 2020-03-23 16:41:40 --> Template Class Initialized
INFO - 2020-03-23 16:41:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:41:40 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:41:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:41:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:41:40 --> Encryption Class Initialized
INFO - 2020-03-23 16:41:40 --> Controller Class Initialized
DEBUG - 2020-03-23 16:41:40 --> transactions MX_Controller Initialized
DEBUG - 2020-03-23 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-23 16:41:40 --> Model Class Initialized
ERROR - 2020-03-23 16:41:40 --> Could not find the language line "order_id"
INFO - 2020-03-23 16:41:40 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:41:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-23 16:41:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:41:41 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:41:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:41:41 --> Model Class Initialized
DEBUG - 2020-03-23 16:41:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:41:41 --> Model Class Initialized
DEBUG - 2020-03-23 16:41:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:41:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:41:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:41:41 --> Final output sent to browser
DEBUG - 2020-03-23 16:41:41 --> Total execution time: 0.6566
INFO - 2020-03-23 16:41:45 --> Config Class Initialized
INFO - 2020-03-23 16:41:45 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:41:45 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:41:45 --> Utf8 Class Initialized
INFO - 2020-03-23 16:41:45 --> URI Class Initialized
INFO - 2020-03-23 16:41:45 --> Router Class Initialized
INFO - 2020-03-23 16:41:45 --> Output Class Initialized
INFO - 2020-03-23 16:41:45 --> Security Class Initialized
DEBUG - 2020-03-23 16:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:41:45 --> CSRF cookie sent
INFO - 2020-03-23 16:41:45 --> Input Class Initialized
INFO - 2020-03-23 16:41:45 --> Language Class Initialized
INFO - 2020-03-23 16:41:45 --> Language Class Initialized
INFO - 2020-03-23 16:41:45 --> Config Class Initialized
INFO - 2020-03-23 16:41:45 --> Loader Class Initialized
INFO - 2020-03-23 16:41:45 --> Helper loaded: url_helper
INFO - 2020-03-23 16:41:45 --> Helper loaded: common_helper
INFO - 2020-03-23 16:41:45 --> Helper loaded: language_helper
INFO - 2020-03-23 16:41:45 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:41:45 --> Helper loaded: email_helper
INFO - 2020-03-23 16:41:45 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:41:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:41:45 --> Parser Class Initialized
INFO - 2020-03-23 16:41:46 --> User Agent Class Initialized
INFO - 2020-03-23 16:41:46 --> Model Class Initialized
INFO - 2020-03-23 16:41:46 --> Database Driver Class Initialized
INFO - 2020-03-23 16:41:46 --> Model Class Initialized
DEBUG - 2020-03-23 16:41:46 --> Template Class Initialized
INFO - 2020-03-23 16:41:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:41:46 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:41:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:41:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:41:46 --> Encryption Class Initialized
INFO - 2020-03-23 16:41:46 --> Controller Class Initialized
DEBUG - 2020-03-23 16:41:46 --> order MX_Controller Initialized
DEBUG - 2020-03-23 16:41:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2020-03-23 16:41:46 --> Model Class Initialized
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "order_id"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "order_basic_details"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "order_id"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "order_basic_details"
INFO - 2020-03-23 16:41:46 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 16:41:46 --> Could not find the language line "Awaiting"
DEBUG - 2020-03-23 16:41:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2020-03-23 16:41:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:41:46 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:41:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:41:46 --> Model Class Initialized
DEBUG - 2020-03-23 16:41:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:41:46 --> Model Class Initialized
DEBUG - 2020-03-23 16:41:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:41:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:41:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:41:46 --> Final output sent to browser
DEBUG - 2020-03-23 16:41:46 --> Total execution time: 1.1510
INFO - 2020-03-23 16:48:32 --> Config Class Initialized
INFO - 2020-03-23 16:48:32 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:48:32 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:48:33 --> Utf8 Class Initialized
INFO - 2020-03-23 16:48:33 --> URI Class Initialized
INFO - 2020-03-23 16:48:33 --> Router Class Initialized
INFO - 2020-03-23 16:48:33 --> Output Class Initialized
INFO - 2020-03-23 16:48:33 --> Security Class Initialized
DEBUG - 2020-03-23 16:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:48:33 --> CSRF cookie sent
INFO - 2020-03-23 16:48:33 --> CSRF token verified
INFO - 2020-03-23 16:48:33 --> Input Class Initialized
INFO - 2020-03-23 16:48:33 --> Language Class Initialized
INFO - 2020-03-23 16:48:33 --> Language Class Initialized
INFO - 2020-03-23 16:48:33 --> Config Class Initialized
INFO - 2020-03-23 16:48:33 --> Loader Class Initialized
INFO - 2020-03-23 16:48:33 --> Helper loaded: url_helper
INFO - 2020-03-23 16:48:33 --> Helper loaded: common_helper
INFO - 2020-03-23 16:48:33 --> Helper loaded: language_helper
INFO - 2020-03-23 16:48:33 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:48:33 --> Helper loaded: email_helper
INFO - 2020-03-23 16:48:33 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:48:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:48:33 --> Parser Class Initialized
INFO - 2020-03-23 16:48:33 --> User Agent Class Initialized
INFO - 2020-03-23 16:48:33 --> Model Class Initialized
INFO - 2020-03-23 16:48:33 --> Database Driver Class Initialized
INFO - 2020-03-23 16:48:33 --> Model Class Initialized
DEBUG - 2020-03-23 16:48:33 --> Template Class Initialized
INFO - 2020-03-23 16:48:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:48:33 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:48:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:48:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:48:33 --> Encryption Class Initialized
INFO - 2020-03-23 16:48:33 --> Controller Class Initialized
DEBUG - 2020-03-23 16:48:33 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 16:48:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 16:48:33 --> Model Class Initialized
INFO - 2020-03-23 16:48:33 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 16:48:33 --> Could not find the language line "shopier"
DEBUG - 2020-03-23 16:48:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-23 16:48:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:48:33 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:48:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:48:33 --> Model Class Initialized
DEBUG - 2020-03-23 16:48:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:48:33 --> Model Class Initialized
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:48:33 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 16:48:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 16:48:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 16:48:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 16:48:33 --> Final output sent to browser
DEBUG - 2020-03-23 16:48:33 --> Total execution time: 0.8094
INFO - 2020-03-23 16:48:45 --> Config Class Initialized
INFO - 2020-03-23 16:48:45 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:48:45 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:48:45 --> Utf8 Class Initialized
INFO - 2020-03-23 16:48:45 --> URI Class Initialized
INFO - 2020-03-23 16:48:45 --> Router Class Initialized
INFO - 2020-03-23 16:48:45 --> Output Class Initialized
INFO - 2020-03-23 16:48:45 --> Security Class Initialized
DEBUG - 2020-03-23 16:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:48:45 --> CSRF cookie sent
INFO - 2020-03-23 16:48:46 --> CSRF token verified
INFO - 2020-03-23 16:48:46 --> Input Class Initialized
INFO - 2020-03-23 16:48:46 --> Language Class Initialized
INFO - 2020-03-23 16:48:46 --> Language Class Initialized
INFO - 2020-03-23 16:48:46 --> Config Class Initialized
INFO - 2020-03-23 16:48:46 --> Loader Class Initialized
INFO - 2020-03-23 16:48:46 --> Helper loaded: url_helper
INFO - 2020-03-23 16:48:46 --> Helper loaded: common_helper
INFO - 2020-03-23 16:48:46 --> Helper loaded: language_helper
INFO - 2020-03-23 16:48:46 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:48:46 --> Helper loaded: email_helper
INFO - 2020-03-23 16:48:46 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:48:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:48:46 --> Parser Class Initialized
INFO - 2020-03-23 16:48:46 --> User Agent Class Initialized
INFO - 2020-03-23 16:48:46 --> Model Class Initialized
INFO - 2020-03-23 16:48:46 --> Database Driver Class Initialized
INFO - 2020-03-23 16:48:46 --> Model Class Initialized
DEBUG - 2020-03-23 16:48:46 --> Template Class Initialized
INFO - 2020-03-23 16:48:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:48:46 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:48:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:48:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:48:46 --> Encryption Class Initialized
INFO - 2020-03-23 16:48:46 --> Controller Class Initialized
DEBUG - 2020-03-23 16:48:46 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 16:48:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 16:48:46 --> Model Class Initialized
DEBUG - 2020-03-23 16:48:46 --> paytm MX_Controller Initialized
DEBUG - 2020-03-23 16:48:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 16:48:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2020-03-23 16:48:46 --> orders MX_Controller Initialized
DEBUG - 2020-03-23 16:48:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2020-03-23 16:48:46 --> Final output sent to browser
DEBUG - 2020-03-23 16:48:46 --> Total execution time: 0.6217
INFO - 2020-03-23 16:48:55 --> Config Class Initialized
INFO - 2020-03-23 16:48:55 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:48:55 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:48:55 --> Utf8 Class Initialized
INFO - 2020-03-23 16:48:55 --> URI Class Initialized
INFO - 2020-03-23 16:48:55 --> Router Class Initialized
INFO - 2020-03-23 16:48:55 --> Output Class Initialized
INFO - 2020-03-23 16:48:55 --> Security Class Initialized
DEBUG - 2020-03-23 16:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:48:55 --> CSRF cookie sent
INFO - 2020-03-23 16:48:55 --> Input Class Initialized
INFO - 2020-03-23 16:48:55 --> Language Class Initialized
INFO - 2020-03-23 16:48:55 --> Language Class Initialized
INFO - 2020-03-23 16:48:55 --> Config Class Initialized
INFO - 2020-03-23 16:48:55 --> Loader Class Initialized
INFO - 2020-03-23 16:48:55 --> Helper loaded: url_helper
INFO - 2020-03-23 16:48:55 --> Helper loaded: common_helper
INFO - 2020-03-23 16:48:55 --> Helper loaded: language_helper
INFO - 2020-03-23 16:48:55 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:48:55 --> Helper loaded: email_helper
INFO - 2020-03-23 16:48:55 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:48:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:48:55 --> Parser Class Initialized
INFO - 2020-03-23 16:48:55 --> User Agent Class Initialized
INFO - 2020-03-23 16:48:55 --> Model Class Initialized
INFO - 2020-03-23 16:48:55 --> Database Driver Class Initialized
INFO - 2020-03-23 16:48:55 --> Model Class Initialized
DEBUG - 2020-03-23 16:48:55 --> Template Class Initialized
INFO - 2020-03-23 16:48:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:48:55 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:48:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:48:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:48:55 --> Encryption Class Initialized
INFO - 2020-03-23 16:48:55 --> Controller Class Initialized
DEBUG - 2020-03-23 16:48:55 --> order MX_Controller Initialized
DEBUG - 2020-03-23 16:48:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2020-03-23 16:48:55 --> Model Class Initialized
ERROR - 2020-03-23 16:48:55 --> Could not find the language line "order_id"
ERROR - 2020-03-23 16:48:55 --> Could not find the language line "order_basic_details"
ERROR - 2020-03-23 16:48:55 --> Could not find the language line "order_id"
ERROR - 2020-03-23 16:48:55 --> Could not find the language line "order_basic_details"
INFO - 2020-03-23 16:48:56 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:48:56 --> Could not find the language line "Awaiting"
DEBUG - 2020-03-23 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2020-03-23 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:48:56 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:48:56 --> Model Class Initialized
DEBUG - 2020-03-23 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:48:56 --> Model Class Initialized
DEBUG - 2020-03-23 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:48:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:48:56 --> Final output sent to browser
DEBUG - 2020-03-23 16:48:56 --> Total execution time: 1.0784
INFO - 2020-03-23 16:49:01 --> Config Class Initialized
INFO - 2020-03-23 16:49:01 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:49:01 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:49:01 --> Utf8 Class Initialized
INFO - 2020-03-23 16:49:01 --> URI Class Initialized
INFO - 2020-03-23 16:49:01 --> Router Class Initialized
INFO - 2020-03-23 16:49:01 --> Output Class Initialized
INFO - 2020-03-23 16:49:01 --> Security Class Initialized
DEBUG - 2020-03-23 16:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:49:01 --> CSRF cookie sent
INFO - 2020-03-23 16:49:01 --> Input Class Initialized
INFO - 2020-03-23 16:49:01 --> Language Class Initialized
INFO - 2020-03-23 16:49:01 --> Language Class Initialized
INFO - 2020-03-23 16:49:01 --> Config Class Initialized
INFO - 2020-03-23 16:49:01 --> Loader Class Initialized
INFO - 2020-03-23 16:49:01 --> Helper loaded: url_helper
INFO - 2020-03-23 16:49:02 --> Helper loaded: common_helper
INFO - 2020-03-23 16:49:02 --> Helper loaded: language_helper
INFO - 2020-03-23 16:49:02 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:49:02 --> Helper loaded: email_helper
INFO - 2020-03-23 16:49:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:49:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:49:02 --> Parser Class Initialized
INFO - 2020-03-23 16:49:02 --> User Agent Class Initialized
INFO - 2020-03-23 16:49:02 --> Model Class Initialized
INFO - 2020-03-23 16:49:02 --> Database Driver Class Initialized
INFO - 2020-03-23 16:49:02 --> Model Class Initialized
DEBUG - 2020-03-23 16:49:02 --> Template Class Initialized
INFO - 2020-03-23 16:49:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:49:02 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:49:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:49:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:49:02 --> Encryption Class Initialized
INFO - 2020-03-23 16:49:02 --> Controller Class Initialized
DEBUG - 2020-03-23 16:49:02 --> transactions MX_Controller Initialized
DEBUG - 2020-03-23 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-23 16:49:02 --> Model Class Initialized
ERROR - 2020-03-23 16:49:02 --> Could not find the language line "order_id"
INFO - 2020-03-23 16:49:02 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-23 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:49:02 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:49:02 --> Model Class Initialized
DEBUG - 2020-03-23 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:49:02 --> Model Class Initialized
DEBUG - 2020-03-23 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:49:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:49:02 --> Final output sent to browser
DEBUG - 2020-03-23 16:49:02 --> Total execution time: 0.7124
INFO - 2020-03-23 16:49:27 --> Config Class Initialized
INFO - 2020-03-23 16:49:27 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:49:27 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:49:27 --> Utf8 Class Initialized
INFO - 2020-03-23 16:49:27 --> URI Class Initialized
INFO - 2020-03-23 16:49:28 --> Router Class Initialized
INFO - 2020-03-23 16:49:28 --> Output Class Initialized
INFO - 2020-03-23 16:49:28 --> Security Class Initialized
DEBUG - 2020-03-23 16:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:49:28 --> Input Class Initialized
INFO - 2020-03-23 16:49:28 --> Language Class Initialized
INFO - 2020-03-23 16:49:28 --> Language Class Initialized
INFO - 2020-03-23 16:49:28 --> Config Class Initialized
INFO - 2020-03-23 16:49:28 --> Loader Class Initialized
INFO - 2020-03-23 16:49:28 --> Helper loaded: url_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: common_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: language_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: email_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:49:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:49:28 --> Parser Class Initialized
INFO - 2020-03-23 16:49:28 --> User Agent Class Initialized
INFO - 2020-03-23 16:49:28 --> Model Class Initialized
INFO - 2020-03-23 16:49:28 --> Database Driver Class Initialized
INFO - 2020-03-23 16:49:28 --> Model Class Initialized
DEBUG - 2020-03-23 16:49:28 --> Template Class Initialized
INFO - 2020-03-23 16:49:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:49:28 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:49:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:49:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:49:28 --> Encryption Class Initialized
INFO - 2020-03-23 16:49:28 --> Controller Class Initialized
DEBUG - 2020-03-23 16:49:28 --> paytm MX_Controller Initialized
INFO - 2020-03-23 16:49:28 --> Model Class Initialized
DEBUG - 2020-03-23 16:49:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 16:49:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 16:49:28 --> Config Class Initialized
INFO - 2020-03-23 16:49:28 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:49:28 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:49:28 --> Utf8 Class Initialized
INFO - 2020-03-23 16:49:28 --> URI Class Initialized
INFO - 2020-03-23 16:49:28 --> Router Class Initialized
INFO - 2020-03-23 16:49:28 --> Output Class Initialized
INFO - 2020-03-23 16:49:28 --> Security Class Initialized
DEBUG - 2020-03-23 16:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:49:28 --> CSRF cookie sent
INFO - 2020-03-23 16:49:28 --> Input Class Initialized
INFO - 2020-03-23 16:49:28 --> Language Class Initialized
INFO - 2020-03-23 16:49:28 --> Language Class Initialized
INFO - 2020-03-23 16:49:28 --> Config Class Initialized
INFO - 2020-03-23 16:49:28 --> Loader Class Initialized
INFO - 2020-03-23 16:49:28 --> Helper loaded: url_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: common_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: language_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: email_helper
INFO - 2020-03-23 16:49:28 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:49:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:49:28 --> Parser Class Initialized
INFO - 2020-03-23 16:49:28 --> User Agent Class Initialized
INFO - 2020-03-23 16:49:28 --> Model Class Initialized
INFO - 2020-03-23 16:49:28 --> Database Driver Class Initialized
INFO - 2020-03-23 16:49:28 --> Model Class Initialized
DEBUG - 2020-03-23 16:49:28 --> Template Class Initialized
INFO - 2020-03-23 16:49:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:49:28 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:49:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:49:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:49:28 --> Encryption Class Initialized
INFO - 2020-03-23 16:49:28 --> Controller Class Initialized
DEBUG - 2020-03-23 16:49:28 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 16:49:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 16:49:28 --> Model Class Initialized
INFO - 2020-03-23 16:49:28 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:49:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2020-03-23 16:49:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:49:28 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:49:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:49:28 --> Model Class Initialized
DEBUG - 2020-03-23 16:49:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:49:28 --> Model Class Initialized
ERROR - 2020-03-23 16:49:28 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:49:28 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:49:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:49:28 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:49:28 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:49:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:49:28 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:49:29 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:49:29 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:49:29 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:49:29 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:49:29 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:49:29 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:49:29 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:49:29 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:49:29 --> Severity: Notice --> Trying to get property 'categories' of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 16:49:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 16:49:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 16:49:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 16:49:29 --> Final output sent to browser
DEBUG - 2020-03-23 16:49:29 --> Total execution time: 0.7826
INFO - 2020-03-23 16:51:39 --> Config Class Initialized
INFO - 2020-03-23 16:51:39 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:51:39 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:51:39 --> Utf8 Class Initialized
INFO - 2020-03-23 16:51:39 --> URI Class Initialized
INFO - 2020-03-23 16:51:39 --> Router Class Initialized
INFO - 2020-03-23 16:51:40 --> Output Class Initialized
INFO - 2020-03-23 16:51:40 --> Security Class Initialized
DEBUG - 2020-03-23 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:51:40 --> CSRF cookie sent
INFO - 2020-03-23 16:51:40 --> Input Class Initialized
INFO - 2020-03-23 16:51:40 --> Language Class Initialized
INFO - 2020-03-23 16:51:40 --> Language Class Initialized
INFO - 2020-03-23 16:51:40 --> Config Class Initialized
INFO - 2020-03-23 16:51:40 --> Loader Class Initialized
INFO - 2020-03-23 16:51:40 --> Helper loaded: url_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: common_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: language_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: email_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:51:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:51:40 --> Parser Class Initialized
INFO - 2020-03-23 16:51:40 --> User Agent Class Initialized
INFO - 2020-03-23 16:51:40 --> Model Class Initialized
INFO - 2020-03-23 16:51:40 --> Database Driver Class Initialized
INFO - 2020-03-23 16:51:40 --> Model Class Initialized
DEBUG - 2020-03-23 16:51:40 --> Template Class Initialized
INFO - 2020-03-23 16:51:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:51:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:51:40 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:51:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:51:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:51:40 --> Encryption Class Initialized
INFO - 2020-03-23 16:51:40 --> Controller Class Initialized
DEBUG - 2020-03-23 16:51:40 --> transactions MX_Controller Initialized
INFO - 2020-03-23 16:51:40 --> Config Class Initialized
INFO - 2020-03-23 16:51:40 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:51:40 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:51:40 --> Utf8 Class Initialized
INFO - 2020-03-23 16:51:40 --> URI Class Initialized
DEBUG - 2020-03-23 16:51:40 --> No URI present. Default controller set.
INFO - 2020-03-23 16:51:40 --> Router Class Initialized
INFO - 2020-03-23 16:51:40 --> Output Class Initialized
INFO - 2020-03-23 16:51:40 --> Security Class Initialized
DEBUG - 2020-03-23 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:51:40 --> CSRF cookie sent
INFO - 2020-03-23 16:51:40 --> Input Class Initialized
INFO - 2020-03-23 16:51:40 --> Language Class Initialized
INFO - 2020-03-23 16:51:40 --> Language Class Initialized
INFO - 2020-03-23 16:51:40 --> Config Class Initialized
INFO - 2020-03-23 16:51:40 --> Loader Class Initialized
INFO - 2020-03-23 16:51:40 --> Helper loaded: url_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: common_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: language_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: email_helper
INFO - 2020-03-23 16:51:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:51:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:51:40 --> Parser Class Initialized
INFO - 2020-03-23 16:51:40 --> User Agent Class Initialized
INFO - 2020-03-23 16:51:40 --> Model Class Initialized
INFO - 2020-03-23 16:51:40 --> Database Driver Class Initialized
INFO - 2020-03-23 16:51:40 --> Model Class Initialized
DEBUG - 2020-03-23 16:51:40 --> Template Class Initialized
INFO - 2020-03-23 16:51:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:51:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:51:40 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:51:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:51:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:51:40 --> Encryption Class Initialized
DEBUG - 2020-03-23 16:51:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:51:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 16:51:40 --> Controller Class Initialized
DEBUG - 2020-03-23 16:51:40 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 16:51:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:51:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 16:51:40 --> Model Class Initialized
INFO - 2020-03-23 16:51:40 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:51:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 16:51:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 16:51:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 16:51:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 16:51:41 --> Final output sent to browser
DEBUG - 2020-03-23 16:51:41 --> Total execution time: 0.6415
INFO - 2020-03-23 16:57:42 --> Config Class Initialized
INFO - 2020-03-23 16:57:42 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:57:42 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:57:42 --> Utf8 Class Initialized
INFO - 2020-03-23 16:57:42 --> URI Class Initialized
INFO - 2020-03-23 16:57:42 --> Router Class Initialized
INFO - 2020-03-23 16:57:42 --> Output Class Initialized
INFO - 2020-03-23 16:57:42 --> Security Class Initialized
DEBUG - 2020-03-23 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:57:42 --> CSRF cookie sent
INFO - 2020-03-23 16:57:42 --> Input Class Initialized
INFO - 2020-03-23 16:57:42 --> Language Class Initialized
INFO - 2020-03-23 16:57:42 --> Language Class Initialized
INFO - 2020-03-23 16:57:42 --> Config Class Initialized
INFO - 2020-03-23 16:57:42 --> Loader Class Initialized
INFO - 2020-03-23 16:57:42 --> Helper loaded: url_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: common_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: language_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: email_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:57:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:57:42 --> Parser Class Initialized
INFO - 2020-03-23 16:57:42 --> User Agent Class Initialized
INFO - 2020-03-23 16:57:42 --> Model Class Initialized
INFO - 2020-03-23 16:57:42 --> Database Driver Class Initialized
INFO - 2020-03-23 16:57:42 --> Model Class Initialized
DEBUG - 2020-03-23 16:57:42 --> Template Class Initialized
INFO - 2020-03-23 16:57:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:57:42 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:57:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:57:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:57:42 --> Encryption Class Initialized
INFO - 2020-03-23 16:57:42 --> Controller Class Initialized
DEBUG - 2020-03-23 16:57:42 --> order MX_Controller Initialized
INFO - 2020-03-23 16:57:42 --> Config Class Initialized
INFO - 2020-03-23 16:57:42 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:57:42 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:57:42 --> Utf8 Class Initialized
INFO - 2020-03-23 16:57:42 --> URI Class Initialized
DEBUG - 2020-03-23 16:57:42 --> No URI present. Default controller set.
INFO - 2020-03-23 16:57:42 --> Router Class Initialized
INFO - 2020-03-23 16:57:42 --> Output Class Initialized
INFO - 2020-03-23 16:57:42 --> Security Class Initialized
DEBUG - 2020-03-23 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:57:42 --> CSRF cookie sent
INFO - 2020-03-23 16:57:42 --> Input Class Initialized
INFO - 2020-03-23 16:57:42 --> Language Class Initialized
INFO - 2020-03-23 16:57:42 --> Language Class Initialized
INFO - 2020-03-23 16:57:42 --> Config Class Initialized
INFO - 2020-03-23 16:57:42 --> Loader Class Initialized
INFO - 2020-03-23 16:57:42 --> Helper loaded: url_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: common_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: language_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: email_helper
INFO - 2020-03-23 16:57:42 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:57:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:57:42 --> Parser Class Initialized
INFO - 2020-03-23 16:57:42 --> User Agent Class Initialized
INFO - 2020-03-23 16:57:42 --> Model Class Initialized
INFO - 2020-03-23 16:57:42 --> Database Driver Class Initialized
INFO - 2020-03-23 16:57:42 --> Model Class Initialized
DEBUG - 2020-03-23 16:57:42 --> Template Class Initialized
INFO - 2020-03-23 16:57:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:57:42 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:57:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:57:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:57:42 --> Encryption Class Initialized
DEBUG - 2020-03-23 16:57:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:57:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 16:57:42 --> Controller Class Initialized
DEBUG - 2020-03-23 16:57:42 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 16:57:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:57:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 16:57:42 --> Model Class Initialized
INFO - 2020-03-23 16:57:42 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:57:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 16:57:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 16:57:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 16:57:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 16:57:43 --> Final output sent to browser
DEBUG - 2020-03-23 16:57:43 --> Total execution time: 0.6307
INFO - 2020-03-23 16:57:48 --> Config Class Initialized
INFO - 2020-03-23 16:57:48 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:57:48 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:57:48 --> Utf8 Class Initialized
INFO - 2020-03-23 16:57:48 --> URI Class Initialized
INFO - 2020-03-23 16:57:48 --> Router Class Initialized
INFO - 2020-03-23 16:57:48 --> Output Class Initialized
INFO - 2020-03-23 16:57:48 --> Security Class Initialized
DEBUG - 2020-03-23 16:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:57:48 --> CSRF cookie sent
INFO - 2020-03-23 16:57:48 --> Input Class Initialized
INFO - 2020-03-23 16:57:48 --> Language Class Initialized
INFO - 2020-03-23 16:57:48 --> Language Class Initialized
INFO - 2020-03-23 16:57:48 --> Config Class Initialized
INFO - 2020-03-23 16:57:48 --> Loader Class Initialized
INFO - 2020-03-23 16:57:48 --> Helper loaded: url_helper
INFO - 2020-03-23 16:57:48 --> Helper loaded: common_helper
INFO - 2020-03-23 16:57:48 --> Helper loaded: language_helper
INFO - 2020-03-23 16:57:48 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:57:48 --> Helper loaded: email_helper
INFO - 2020-03-23 16:57:48 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:57:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:57:48 --> Parser Class Initialized
INFO - 2020-03-23 16:57:48 --> User Agent Class Initialized
INFO - 2020-03-23 16:57:48 --> Model Class Initialized
INFO - 2020-03-23 16:57:48 --> Database Driver Class Initialized
INFO - 2020-03-23 16:57:48 --> Model Class Initialized
DEBUG - 2020-03-23 16:57:48 --> Template Class Initialized
INFO - 2020-03-23 16:57:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:57:48 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:57:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:57:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:57:48 --> Encryption Class Initialized
INFO - 2020-03-23 16:57:48 --> Controller Class Initialized
DEBUG - 2020-03-23 16:57:48 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 16:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 16:57:48 --> Model Class Initialized
DEBUG - 2020-03-23 16:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 16:57:48 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-23 16:57:48 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 16:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-23 16:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 16:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 16:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-23 16:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 16:57:48 --> Final output sent to browser
DEBUG - 2020-03-23 16:57:48 --> Total execution time: 0.5293
INFO - 2020-03-23 16:57:50 --> Config Class Initialized
INFO - 2020-03-23 16:57:50 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:57:50 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:57:50 --> Utf8 Class Initialized
INFO - 2020-03-23 16:57:50 --> URI Class Initialized
INFO - 2020-03-23 16:57:50 --> Router Class Initialized
INFO - 2020-03-23 16:57:50 --> Output Class Initialized
INFO - 2020-03-23 16:57:50 --> Security Class Initialized
DEBUG - 2020-03-23 16:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:57:50 --> CSRF cookie sent
INFO - 2020-03-23 16:57:50 --> CSRF token verified
INFO - 2020-03-23 16:57:50 --> Input Class Initialized
INFO - 2020-03-23 16:57:50 --> Language Class Initialized
INFO - 2020-03-23 16:57:50 --> Language Class Initialized
INFO - 2020-03-23 16:57:50 --> Config Class Initialized
INFO - 2020-03-23 16:57:50 --> Loader Class Initialized
INFO - 2020-03-23 16:57:50 --> Helper loaded: url_helper
INFO - 2020-03-23 16:57:50 --> Helper loaded: common_helper
INFO - 2020-03-23 16:57:50 --> Helper loaded: language_helper
INFO - 2020-03-23 16:57:50 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:57:50 --> Helper loaded: email_helper
INFO - 2020-03-23 16:57:50 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:57:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:57:50 --> Parser Class Initialized
INFO - 2020-03-23 16:57:50 --> User Agent Class Initialized
INFO - 2020-03-23 16:57:50 --> Model Class Initialized
INFO - 2020-03-23 16:57:50 --> Database Driver Class Initialized
INFO - 2020-03-23 16:57:50 --> Model Class Initialized
DEBUG - 2020-03-23 16:57:50 --> Template Class Initialized
INFO - 2020-03-23 16:57:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:57:50 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:57:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:57:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:57:50 --> Encryption Class Initialized
INFO - 2020-03-23 16:57:50 --> Controller Class Initialized
DEBUG - 2020-03-23 16:57:50 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 16:57:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 16:57:50 --> Model Class Initialized
INFO - 2020-03-23 16:57:55 --> Config Class Initialized
INFO - 2020-03-23 16:57:55 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:57:55 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:57:55 --> Utf8 Class Initialized
INFO - 2020-03-23 16:57:55 --> URI Class Initialized
INFO - 2020-03-23 16:57:55 --> Router Class Initialized
INFO - 2020-03-23 16:57:55 --> Output Class Initialized
INFO - 2020-03-23 16:57:55 --> Security Class Initialized
DEBUG - 2020-03-23 16:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:57:55 --> CSRF cookie sent
INFO - 2020-03-23 16:57:55 --> Input Class Initialized
INFO - 2020-03-23 16:57:55 --> Language Class Initialized
INFO - 2020-03-23 16:57:55 --> Language Class Initialized
INFO - 2020-03-23 16:57:55 --> Config Class Initialized
INFO - 2020-03-23 16:57:55 --> Loader Class Initialized
INFO - 2020-03-23 16:57:55 --> Helper loaded: url_helper
INFO - 2020-03-23 16:57:55 --> Helper loaded: common_helper
INFO - 2020-03-23 16:57:55 --> Helper loaded: language_helper
INFO - 2020-03-23 16:57:55 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:57:55 --> Helper loaded: email_helper
INFO - 2020-03-23 16:57:55 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:57:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:57:55 --> Parser Class Initialized
INFO - 2020-03-23 16:57:55 --> User Agent Class Initialized
INFO - 2020-03-23 16:57:55 --> Model Class Initialized
INFO - 2020-03-23 16:57:55 --> Database Driver Class Initialized
INFO - 2020-03-23 16:57:55 --> Model Class Initialized
DEBUG - 2020-03-23 16:57:55 --> Template Class Initialized
INFO - 2020-03-23 16:57:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:57:55 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:57:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:57:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:57:55 --> Encryption Class Initialized
INFO - 2020-03-23 16:57:55 --> Controller Class Initialized
DEBUG - 2020-03-23 16:57:55 --> statistics MX_Controller Initialized
DEBUG - 2020-03-23 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-23 16:57:55 --> Model Class Initialized
ERROR - 2020-03-23 16:57:55 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:57:55 --> Could not find the language line "Pending"
INFO - 2020-03-23 16:57:55 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 16:57:55 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 16:57:55 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 16:57:55 --> Could not find the language line "Pending"
DEBUG - 2020-03-23 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-23 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:57:55 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:57:55 --> Model Class Initialized
DEBUG - 2020-03-23 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:57:55 --> Model Class Initialized
DEBUG - 2020-03-23 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:57:55 --> Final output sent to browser
DEBUG - 2020-03-23 16:57:55 --> Total execution time: 0.7813
INFO - 2020-03-23 16:57:59 --> Config Class Initialized
INFO - 2020-03-23 16:57:59 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:57:59 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:57:59 --> Utf8 Class Initialized
INFO - 2020-03-23 16:57:59 --> URI Class Initialized
INFO - 2020-03-23 16:57:59 --> Router Class Initialized
INFO - 2020-03-23 16:57:59 --> Output Class Initialized
INFO - 2020-03-23 16:57:59 --> Security Class Initialized
DEBUG - 2020-03-23 16:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:57:59 --> CSRF cookie sent
INFO - 2020-03-23 16:57:59 --> Input Class Initialized
INFO - 2020-03-23 16:57:59 --> Language Class Initialized
INFO - 2020-03-23 16:57:59 --> Language Class Initialized
INFO - 2020-03-23 16:57:59 --> Config Class Initialized
INFO - 2020-03-23 16:57:59 --> Loader Class Initialized
INFO - 2020-03-23 16:57:59 --> Helper loaded: url_helper
INFO - 2020-03-23 16:57:59 --> Helper loaded: common_helper
INFO - 2020-03-23 16:57:59 --> Helper loaded: language_helper
INFO - 2020-03-23 16:57:59 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:57:59 --> Helper loaded: email_helper
INFO - 2020-03-23 16:57:59 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:57:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:57:59 --> Parser Class Initialized
INFO - 2020-03-23 16:57:59 --> User Agent Class Initialized
INFO - 2020-03-23 16:57:59 --> Model Class Initialized
INFO - 2020-03-23 16:57:59 --> Database Driver Class Initialized
INFO - 2020-03-23 16:57:59 --> Model Class Initialized
DEBUG - 2020-03-23 16:57:59 --> Template Class Initialized
INFO - 2020-03-23 16:57:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:57:59 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:57:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:57:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:57:59 --> Encryption Class Initialized
INFO - 2020-03-23 16:57:59 --> Controller Class Initialized
DEBUG - 2020-03-23 16:57:59 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 16:58:00 --> Model Class Initialized
INFO - 2020-03-23 16:58:00 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2020-03-23 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:58:00 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:58:00 --> Model Class Initialized
DEBUG - 2020-03-23 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:58:00 --> Model Class Initialized
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 16:58:00 --> Final output sent to browser
DEBUG - 2020-03-23 16:58:00 --> Total execution time: 0.8934
INFO - 2020-03-23 16:58:08 --> Config Class Initialized
INFO - 2020-03-23 16:58:08 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:58:08 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:58:08 --> Utf8 Class Initialized
INFO - 2020-03-23 16:58:08 --> URI Class Initialized
DEBUG - 2020-03-23 16:58:08 --> No URI present. Default controller set.
INFO - 2020-03-23 16:58:08 --> Router Class Initialized
INFO - 2020-03-23 16:58:08 --> Output Class Initialized
INFO - 2020-03-23 16:58:08 --> Security Class Initialized
DEBUG - 2020-03-23 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:58:08 --> CSRF cookie sent
INFO - 2020-03-23 16:58:08 --> Input Class Initialized
INFO - 2020-03-23 16:58:08 --> Language Class Initialized
INFO - 2020-03-23 16:58:08 --> Language Class Initialized
INFO - 2020-03-23 16:58:08 --> Config Class Initialized
INFO - 2020-03-23 16:58:08 --> Loader Class Initialized
INFO - 2020-03-23 16:58:08 --> Helper loaded: url_helper
INFO - 2020-03-23 16:58:08 --> Helper loaded: common_helper
INFO - 2020-03-23 16:58:08 --> Helper loaded: language_helper
INFO - 2020-03-23 16:58:08 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:58:08 --> Helper loaded: email_helper
INFO - 2020-03-23 16:58:08 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:58:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:58:08 --> Parser Class Initialized
INFO - 2020-03-23 16:58:08 --> User Agent Class Initialized
INFO - 2020-03-23 16:58:08 --> Model Class Initialized
INFO - 2020-03-23 16:58:08 --> Database Driver Class Initialized
INFO - 2020-03-23 16:58:08 --> Model Class Initialized
DEBUG - 2020-03-23 16:58:08 --> Template Class Initialized
INFO - 2020-03-23 16:58:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:58:08 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:58:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:58:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:58:08 --> Encryption Class Initialized
DEBUG - 2020-03-23 16:58:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:58:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 16:58:08 --> Controller Class Initialized
DEBUG - 2020-03-23 16:58:08 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 16:58:09 --> Model Class Initialized
INFO - 2020-03-23 16:58:09 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 16:58:09 --> Final output sent to browser
DEBUG - 2020-03-23 16:58:09 --> Total execution time: 0.7007
INFO - 2020-03-23 16:58:11 --> Config Class Initialized
INFO - 2020-03-23 16:58:11 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:58:11 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:58:11 --> Utf8 Class Initialized
INFO - 2020-03-23 16:58:11 --> URI Class Initialized
INFO - 2020-03-23 16:58:11 --> Router Class Initialized
INFO - 2020-03-23 16:58:11 --> Output Class Initialized
INFO - 2020-03-23 16:58:11 --> Security Class Initialized
DEBUG - 2020-03-23 16:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:58:11 --> CSRF cookie sent
INFO - 2020-03-23 16:58:11 --> Input Class Initialized
INFO - 2020-03-23 16:58:11 --> Language Class Initialized
INFO - 2020-03-23 16:58:11 --> Language Class Initialized
INFO - 2020-03-23 16:58:11 --> Config Class Initialized
INFO - 2020-03-23 16:58:11 --> Loader Class Initialized
INFO - 2020-03-23 16:58:11 --> Helper loaded: url_helper
INFO - 2020-03-23 16:58:11 --> Helper loaded: common_helper
INFO - 2020-03-23 16:58:11 --> Helper loaded: language_helper
INFO - 2020-03-23 16:58:11 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:58:11 --> Helper loaded: email_helper
INFO - 2020-03-23 16:58:11 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:58:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:58:11 --> Parser Class Initialized
INFO - 2020-03-23 16:58:11 --> User Agent Class Initialized
INFO - 2020-03-23 16:58:11 --> Model Class Initialized
INFO - 2020-03-23 16:58:11 --> Database Driver Class Initialized
INFO - 2020-03-23 16:58:11 --> Model Class Initialized
DEBUG - 2020-03-23 16:58:11 --> Template Class Initialized
INFO - 2020-03-23 16:58:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:58:11 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:58:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:58:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:58:11 --> Encryption Class Initialized
INFO - 2020-03-23 16:58:11 --> Controller Class Initialized
DEBUG - 2020-03-23 16:58:11 --> package MX_Controller Initialized
DEBUG - 2020-03-23 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-23 16:58:11 --> Model Class Initialized
INFO - 2020-03-23 16:58:11 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:58:11 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:58:11 --> Model Class Initialized
DEBUG - 2020-03-23 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:58:11 --> Model Class Initialized
DEBUG - 2020-03-23 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-23 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-23 16:58:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 16:58:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 16:58:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 16:58:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 16:58:12 --> Final output sent to browser
DEBUG - 2020-03-23 16:58:12 --> Total execution time: 0.8819
INFO - 2020-03-23 16:58:14 --> Config Class Initialized
INFO - 2020-03-23 16:58:14 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:58:14 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:58:14 --> Utf8 Class Initialized
INFO - 2020-03-23 16:58:14 --> URI Class Initialized
INFO - 2020-03-23 16:58:14 --> Router Class Initialized
INFO - 2020-03-23 16:58:14 --> Output Class Initialized
INFO - 2020-03-23 16:58:14 --> Security Class Initialized
DEBUG - 2020-03-23 16:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:58:14 --> CSRF cookie sent
INFO - 2020-03-23 16:58:14 --> CSRF token verified
INFO - 2020-03-23 16:58:14 --> Input Class Initialized
INFO - 2020-03-23 16:58:14 --> Language Class Initialized
INFO - 2020-03-23 16:58:15 --> Language Class Initialized
INFO - 2020-03-23 16:58:15 --> Config Class Initialized
INFO - 2020-03-23 16:58:15 --> Loader Class Initialized
INFO - 2020-03-23 16:58:15 --> Helper loaded: url_helper
INFO - 2020-03-23 16:58:15 --> Helper loaded: common_helper
INFO - 2020-03-23 16:58:15 --> Helper loaded: language_helper
INFO - 2020-03-23 16:58:15 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:58:15 --> Helper loaded: email_helper
INFO - 2020-03-23 16:58:15 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:58:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:58:15 --> Parser Class Initialized
INFO - 2020-03-23 16:58:15 --> User Agent Class Initialized
INFO - 2020-03-23 16:58:15 --> Model Class Initialized
INFO - 2020-03-23 16:58:15 --> Database Driver Class Initialized
INFO - 2020-03-23 16:58:15 --> Model Class Initialized
DEBUG - 2020-03-23 16:58:15 --> Template Class Initialized
INFO - 2020-03-23 16:58:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:58:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:58:15 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:58:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:58:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:58:15 --> Encryption Class Initialized
INFO - 2020-03-23 16:58:15 --> Controller Class Initialized
DEBUG - 2020-03-23 16:58:15 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 16:58:15 --> Model Class Initialized
INFO - 2020-03-23 16:58:15 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 16:58:15 --> Could not find the language line "shopier"
DEBUG - 2020-03-23 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-23 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:58:15 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:58:15 --> Model Class Initialized
DEBUG - 2020-03-23 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:58:15 --> Model Class Initialized
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:58:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 16:58:15 --> Final output sent to browser
DEBUG - 2020-03-23 16:58:15 --> Total execution time: 1.0760
INFO - 2020-03-23 16:58:23 --> Config Class Initialized
INFO - 2020-03-23 16:58:23 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:58:23 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:58:23 --> Utf8 Class Initialized
INFO - 2020-03-23 16:58:23 --> URI Class Initialized
INFO - 2020-03-23 16:58:23 --> Router Class Initialized
INFO - 2020-03-23 16:58:23 --> Output Class Initialized
INFO - 2020-03-23 16:58:23 --> Security Class Initialized
DEBUG - 2020-03-23 16:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:58:23 --> CSRF cookie sent
INFO - 2020-03-23 16:58:24 --> CSRF token verified
INFO - 2020-03-23 16:58:24 --> Input Class Initialized
INFO - 2020-03-23 16:58:24 --> Language Class Initialized
INFO - 2020-03-23 16:58:24 --> Language Class Initialized
INFO - 2020-03-23 16:58:24 --> Config Class Initialized
INFO - 2020-03-23 16:58:24 --> Loader Class Initialized
INFO - 2020-03-23 16:58:24 --> Helper loaded: url_helper
INFO - 2020-03-23 16:58:24 --> Helper loaded: common_helper
INFO - 2020-03-23 16:58:24 --> Helper loaded: language_helper
INFO - 2020-03-23 16:58:24 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:58:24 --> Helper loaded: email_helper
INFO - 2020-03-23 16:58:24 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:58:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:58:24 --> Parser Class Initialized
INFO - 2020-03-23 16:58:24 --> User Agent Class Initialized
INFO - 2020-03-23 16:58:24 --> Model Class Initialized
INFO - 2020-03-23 16:58:24 --> Database Driver Class Initialized
INFO - 2020-03-23 16:58:24 --> Model Class Initialized
DEBUG - 2020-03-23 16:58:24 --> Template Class Initialized
INFO - 2020-03-23 16:58:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:58:24 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:58:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:58:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:58:24 --> Encryption Class Initialized
INFO - 2020-03-23 16:58:24 --> Controller Class Initialized
DEBUG - 2020-03-23 16:58:24 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 16:58:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 16:58:24 --> Model Class Initialized
DEBUG - 2020-03-23 16:58:24 --> paytm MX_Controller Initialized
DEBUG - 2020-03-23 16:58:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 16:58:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2020-03-23 16:58:24 --> orders MX_Controller Initialized
DEBUG - 2020-03-23 16:58:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2020-03-23 16:58:24 --> Final output sent to browser
DEBUG - 2020-03-23 16:58:24 --> Total execution time: 0.6291
INFO - 2020-03-23 16:59:04 --> Config Class Initialized
INFO - 2020-03-23 16:59:04 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:59:04 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:59:04 --> Utf8 Class Initialized
INFO - 2020-03-23 16:59:04 --> URI Class Initialized
DEBUG - 2020-03-23 16:59:04 --> No URI present. Default controller set.
INFO - 2020-03-23 16:59:04 --> Router Class Initialized
INFO - 2020-03-23 16:59:04 --> Output Class Initialized
INFO - 2020-03-23 16:59:04 --> Security Class Initialized
DEBUG - 2020-03-23 16:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:59:04 --> CSRF cookie sent
INFO - 2020-03-23 16:59:04 --> Input Class Initialized
INFO - 2020-03-23 16:59:04 --> Language Class Initialized
INFO - 2020-03-23 16:59:04 --> Language Class Initialized
INFO - 2020-03-23 16:59:04 --> Config Class Initialized
INFO - 2020-03-23 16:59:04 --> Loader Class Initialized
INFO - 2020-03-23 16:59:04 --> Helper loaded: url_helper
INFO - 2020-03-23 16:59:04 --> Helper loaded: common_helper
INFO - 2020-03-23 16:59:04 --> Helper loaded: language_helper
INFO - 2020-03-23 16:59:04 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:59:04 --> Helper loaded: email_helper
INFO - 2020-03-23 16:59:04 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:59:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:59:04 --> Parser Class Initialized
INFO - 2020-03-23 16:59:04 --> User Agent Class Initialized
INFO - 2020-03-23 16:59:04 --> Model Class Initialized
INFO - 2020-03-23 16:59:04 --> Database Driver Class Initialized
INFO - 2020-03-23 16:59:04 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:04 --> Template Class Initialized
INFO - 2020-03-23 16:59:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:59:04 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:59:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:59:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:59:04 --> Encryption Class Initialized
DEBUG - 2020-03-23 16:59:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:59:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 16:59:04 --> Controller Class Initialized
DEBUG - 2020-03-23 16:59:04 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 16:59:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:59:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 16:59:04 --> Model Class Initialized
INFO - 2020-03-23 16:59:04 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:59:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 16:59:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 16:59:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 16:59:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 16:59:04 --> Final output sent to browser
DEBUG - 2020-03-23 16:59:04 --> Total execution time: 0.6840
INFO - 2020-03-23 16:59:09 --> Config Class Initialized
INFO - 2020-03-23 16:59:09 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:59:09 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:59:09 --> Utf8 Class Initialized
INFO - 2020-03-23 16:59:09 --> URI Class Initialized
INFO - 2020-03-23 16:59:09 --> Router Class Initialized
INFO - 2020-03-23 16:59:09 --> Output Class Initialized
INFO - 2020-03-23 16:59:09 --> Security Class Initialized
DEBUG - 2020-03-23 16:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:59:09 --> CSRF cookie sent
INFO - 2020-03-23 16:59:09 --> Input Class Initialized
INFO - 2020-03-23 16:59:09 --> Language Class Initialized
INFO - 2020-03-23 16:59:09 --> Language Class Initialized
INFO - 2020-03-23 16:59:09 --> Config Class Initialized
INFO - 2020-03-23 16:59:09 --> Loader Class Initialized
INFO - 2020-03-23 16:59:09 --> Helper loaded: url_helper
INFO - 2020-03-23 16:59:09 --> Helper loaded: common_helper
INFO - 2020-03-23 16:59:09 --> Helper loaded: language_helper
INFO - 2020-03-23 16:59:09 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:59:09 --> Helper loaded: email_helper
INFO - 2020-03-23 16:59:09 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:59:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:59:09 --> Parser Class Initialized
INFO - 2020-03-23 16:59:09 --> User Agent Class Initialized
INFO - 2020-03-23 16:59:09 --> Model Class Initialized
INFO - 2020-03-23 16:59:09 --> Database Driver Class Initialized
INFO - 2020-03-23 16:59:09 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:09 --> Template Class Initialized
INFO - 2020-03-23 16:59:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:59:09 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:59:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:59:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:59:09 --> Encryption Class Initialized
INFO - 2020-03-23 16:59:09 --> Controller Class Initialized
DEBUG - 2020-03-23 16:59:09 --> statistics MX_Controller Initialized
DEBUG - 2020-03-23 16:59:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-23 16:59:09 --> Model Class Initialized
ERROR - 2020-03-23 16:59:09 --> Could not find the language line "Pending"
ERROR - 2020-03-23 16:59:09 --> Could not find the language line "Pending"
INFO - 2020-03-23 16:59:09 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 16:59:10 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 16:59:10 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 16:59:10 --> Could not find the language line "Pending"
DEBUG - 2020-03-23 16:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-23 16:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:59:10 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:59:10 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:59:10 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:59:10 --> Final output sent to browser
DEBUG - 2020-03-23 16:59:10 --> Total execution time: 0.8210
INFO - 2020-03-23 16:59:13 --> Config Class Initialized
INFO - 2020-03-23 16:59:13 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:59:13 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:59:13 --> Utf8 Class Initialized
INFO - 2020-03-23 16:59:13 --> URI Class Initialized
INFO - 2020-03-23 16:59:13 --> Router Class Initialized
INFO - 2020-03-23 16:59:13 --> Output Class Initialized
INFO - 2020-03-23 16:59:13 --> Security Class Initialized
DEBUG - 2020-03-23 16:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:59:13 --> CSRF cookie sent
INFO - 2020-03-23 16:59:13 --> Input Class Initialized
INFO - 2020-03-23 16:59:13 --> Language Class Initialized
INFO - 2020-03-23 16:59:13 --> Language Class Initialized
INFO - 2020-03-23 16:59:13 --> Config Class Initialized
INFO - 2020-03-23 16:59:13 --> Loader Class Initialized
INFO - 2020-03-23 16:59:13 --> Helper loaded: url_helper
INFO - 2020-03-23 16:59:13 --> Helper loaded: common_helper
INFO - 2020-03-23 16:59:13 --> Helper loaded: language_helper
INFO - 2020-03-23 16:59:14 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:59:14 --> Helper loaded: email_helper
INFO - 2020-03-23 16:59:14 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:59:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:59:14 --> Parser Class Initialized
INFO - 2020-03-23 16:59:14 --> User Agent Class Initialized
INFO - 2020-03-23 16:59:14 --> Model Class Initialized
INFO - 2020-03-23 16:59:14 --> Database Driver Class Initialized
INFO - 2020-03-23 16:59:14 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:14 --> Template Class Initialized
INFO - 2020-03-23 16:59:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:59:14 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:59:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:59:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:59:14 --> Encryption Class Initialized
INFO - 2020-03-23 16:59:14 --> Controller Class Initialized
DEBUG - 2020-03-23 16:59:14 --> transactions MX_Controller Initialized
DEBUG - 2020-03-23 16:59:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-23 16:59:14 --> Model Class Initialized
ERROR - 2020-03-23 16:59:14 --> Could not find the language line "order_id"
INFO - 2020-03-23 16:59:14 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:59:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-23 16:59:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:59:14 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:59:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:59:14 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:59:14 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 16:59:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 16:59:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 16:59:14 --> Final output sent to browser
DEBUG - 2020-03-23 16:59:14 --> Total execution time: 0.7697
INFO - 2020-03-23 16:59:21 --> Config Class Initialized
INFO - 2020-03-23 16:59:21 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:59:21 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:59:21 --> Utf8 Class Initialized
INFO - 2020-03-23 16:59:21 --> URI Class Initialized
INFO - 2020-03-23 16:59:21 --> Router Class Initialized
INFO - 2020-03-23 16:59:21 --> Output Class Initialized
INFO - 2020-03-23 16:59:21 --> Security Class Initialized
DEBUG - 2020-03-23 16:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:59:21 --> Input Class Initialized
INFO - 2020-03-23 16:59:21 --> Language Class Initialized
INFO - 2020-03-23 16:59:21 --> Language Class Initialized
INFO - 2020-03-23 16:59:21 --> Config Class Initialized
INFO - 2020-03-23 16:59:21 --> Loader Class Initialized
INFO - 2020-03-23 16:59:21 --> Helper loaded: url_helper
INFO - 2020-03-23 16:59:21 --> Helper loaded: common_helper
INFO - 2020-03-23 16:59:21 --> Helper loaded: language_helper
INFO - 2020-03-23 16:59:21 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:59:21 --> Helper loaded: email_helper
INFO - 2020-03-23 16:59:21 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:59:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:59:21 --> Parser Class Initialized
INFO - 2020-03-23 16:59:21 --> User Agent Class Initialized
INFO - 2020-03-23 16:59:21 --> Model Class Initialized
INFO - 2020-03-23 16:59:21 --> Database Driver Class Initialized
INFO - 2020-03-23 16:59:21 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:22 --> Template Class Initialized
INFO - 2020-03-23 16:59:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:59:22 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:59:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:59:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:59:22 --> Encryption Class Initialized
INFO - 2020-03-23 16:59:22 --> Controller Class Initialized
DEBUG - 2020-03-23 16:59:22 --> paytm MX_Controller Initialized
INFO - 2020-03-23 16:59:22 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 16:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 16:59:22 --> Config Class Initialized
INFO - 2020-03-23 16:59:22 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:59:22 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:59:22 --> Utf8 Class Initialized
INFO - 2020-03-23 16:59:22 --> URI Class Initialized
INFO - 2020-03-23 16:59:22 --> Router Class Initialized
INFO - 2020-03-23 16:59:22 --> Output Class Initialized
INFO - 2020-03-23 16:59:22 --> Security Class Initialized
DEBUG - 2020-03-23 16:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:59:22 --> CSRF cookie sent
INFO - 2020-03-23 16:59:22 --> Input Class Initialized
INFO - 2020-03-23 16:59:22 --> Language Class Initialized
INFO - 2020-03-23 16:59:22 --> Language Class Initialized
INFO - 2020-03-23 16:59:22 --> Config Class Initialized
INFO - 2020-03-23 16:59:22 --> Loader Class Initialized
INFO - 2020-03-23 16:59:22 --> Helper loaded: url_helper
INFO - 2020-03-23 16:59:22 --> Helper loaded: common_helper
INFO - 2020-03-23 16:59:22 --> Helper loaded: language_helper
INFO - 2020-03-23 16:59:22 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:59:22 --> Helper loaded: email_helper
INFO - 2020-03-23 16:59:22 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:59:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:59:22 --> Parser Class Initialized
INFO - 2020-03-23 16:59:22 --> User Agent Class Initialized
INFO - 2020-03-23 16:59:22 --> Model Class Initialized
INFO - 2020-03-23 16:59:22 --> Database Driver Class Initialized
INFO - 2020-03-23 16:59:22 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:22 --> Template Class Initialized
INFO - 2020-03-23 16:59:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:59:22 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:59:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:59:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:59:22 --> Encryption Class Initialized
INFO - 2020-03-23 16:59:22 --> Controller Class Initialized
DEBUG - 2020-03-23 16:59:22 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 16:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 16:59:22 --> Model Class Initialized
INFO - 2020-03-23 16:59:22 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2020-03-23 16:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 16:59:22 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 16:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 16:59:22 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 16:59:22 --> Model Class Initialized
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 16:59:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 16:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 16:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 16:59:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 16:59:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 16:59:23 --> Final output sent to browser
DEBUG - 2020-03-23 16:59:23 --> Total execution time: 0.8558
INFO - 2020-03-23 16:59:32 --> Config Class Initialized
INFO - 2020-03-23 16:59:32 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:59:32 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:59:32 --> Utf8 Class Initialized
INFO - 2020-03-23 16:59:32 --> URI Class Initialized
INFO - 2020-03-23 16:59:32 --> Router Class Initialized
INFO - 2020-03-23 16:59:32 --> Output Class Initialized
INFO - 2020-03-23 16:59:32 --> Security Class Initialized
DEBUG - 2020-03-23 16:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:59:32 --> CSRF cookie sent
INFO - 2020-03-23 16:59:32 --> Input Class Initialized
INFO - 2020-03-23 16:59:32 --> Language Class Initialized
INFO - 2020-03-23 16:59:32 --> Language Class Initialized
INFO - 2020-03-23 16:59:32 --> Config Class Initialized
INFO - 2020-03-23 16:59:32 --> Loader Class Initialized
INFO - 2020-03-23 16:59:32 --> Helper loaded: url_helper
INFO - 2020-03-23 16:59:32 --> Helper loaded: common_helper
INFO - 2020-03-23 16:59:32 --> Helper loaded: language_helper
INFO - 2020-03-23 16:59:32 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:59:32 --> Helper loaded: email_helper
INFO - 2020-03-23 16:59:32 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:59:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:59:32 --> Parser Class Initialized
INFO - 2020-03-23 16:59:32 --> User Agent Class Initialized
INFO - 2020-03-23 16:59:32 --> Model Class Initialized
INFO - 2020-03-23 16:59:32 --> Database Driver Class Initialized
INFO - 2020-03-23 16:59:32 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:32 --> Template Class Initialized
INFO - 2020-03-23 16:59:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:59:32 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:59:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:59:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:59:32 --> Encryption Class Initialized
INFO - 2020-03-23 16:59:32 --> Controller Class Initialized
DEBUG - 2020-03-23 16:59:32 --> transactions MX_Controller Initialized
INFO - 2020-03-23 16:59:33 --> Config Class Initialized
INFO - 2020-03-23 16:59:33 --> Hooks Class Initialized
DEBUG - 2020-03-23 16:59:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 16:59:33 --> Utf8 Class Initialized
INFO - 2020-03-23 16:59:33 --> URI Class Initialized
DEBUG - 2020-03-23 16:59:33 --> No URI present. Default controller set.
INFO - 2020-03-23 16:59:33 --> Router Class Initialized
INFO - 2020-03-23 16:59:33 --> Output Class Initialized
INFO - 2020-03-23 16:59:33 --> Security Class Initialized
DEBUG - 2020-03-23 16:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 16:59:33 --> CSRF cookie sent
INFO - 2020-03-23 16:59:33 --> Input Class Initialized
INFO - 2020-03-23 16:59:33 --> Language Class Initialized
INFO - 2020-03-23 16:59:33 --> Language Class Initialized
INFO - 2020-03-23 16:59:33 --> Config Class Initialized
INFO - 2020-03-23 16:59:33 --> Loader Class Initialized
INFO - 2020-03-23 16:59:33 --> Helper loaded: url_helper
INFO - 2020-03-23 16:59:33 --> Helper loaded: common_helper
INFO - 2020-03-23 16:59:33 --> Helper loaded: language_helper
INFO - 2020-03-23 16:59:33 --> Helper loaded: cookie_helper
INFO - 2020-03-23 16:59:33 --> Helper loaded: email_helper
INFO - 2020-03-23 16:59:33 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 16:59:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 16:59:33 --> Parser Class Initialized
INFO - 2020-03-23 16:59:33 --> User Agent Class Initialized
INFO - 2020-03-23 16:59:33 --> Model Class Initialized
INFO - 2020-03-23 16:59:33 --> Database Driver Class Initialized
INFO - 2020-03-23 16:59:33 --> Model Class Initialized
DEBUG - 2020-03-23 16:59:33 --> Template Class Initialized
INFO - 2020-03-23 16:59:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 16:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 16:59:33 --> Pagination Class Initialized
DEBUG - 2020-03-23 16:59:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 16:59:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 16:59:33 --> Encryption Class Initialized
DEBUG - 2020-03-23 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 16:59:33 --> Controller Class Initialized
DEBUG - 2020-03-23 16:59:33 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 16:59:33 --> Model Class Initialized
INFO - 2020-03-23 16:59:33 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 16:59:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 16:59:33 --> Final output sent to browser
DEBUG - 2020-03-23 16:59:33 --> Total execution time: 0.6950
INFO - 2020-03-23 17:00:05 --> Config Class Initialized
INFO - 2020-03-23 17:00:05 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:00:05 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:00:05 --> Utf8 Class Initialized
INFO - 2020-03-23 17:00:05 --> URI Class Initialized
INFO - 2020-03-23 17:00:05 --> Router Class Initialized
INFO - 2020-03-23 17:00:05 --> Output Class Initialized
INFO - 2020-03-23 17:00:05 --> Security Class Initialized
DEBUG - 2020-03-23 17:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:00:05 --> Input Class Initialized
INFO - 2020-03-23 17:00:05 --> Language Class Initialized
INFO - 2020-03-23 17:00:05 --> Language Class Initialized
INFO - 2020-03-23 17:00:05 --> Config Class Initialized
INFO - 2020-03-23 17:00:05 --> Loader Class Initialized
INFO - 2020-03-23 17:00:05 --> Helper loaded: url_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: common_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: language_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: email_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:00:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:00:05 --> Parser Class Initialized
INFO - 2020-03-23 17:00:05 --> User Agent Class Initialized
INFO - 2020-03-23 17:00:05 --> Model Class Initialized
INFO - 2020-03-23 17:00:05 --> Database Driver Class Initialized
INFO - 2020-03-23 17:00:05 --> Model Class Initialized
DEBUG - 2020-03-23 17:00:05 --> Template Class Initialized
INFO - 2020-03-23 17:00:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:00:05 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:00:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:00:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:00:05 --> Encryption Class Initialized
INFO - 2020-03-23 17:00:05 --> Controller Class Initialized
DEBUG - 2020-03-23 17:00:05 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:00:05 --> Model Class Initialized
DEBUG - 2020-03-23 17:00:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:00:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 17:00:05 --> Config Class Initialized
INFO - 2020-03-23 17:00:05 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:00:05 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:00:05 --> Utf8 Class Initialized
INFO - 2020-03-23 17:00:05 --> URI Class Initialized
INFO - 2020-03-23 17:00:05 --> Router Class Initialized
INFO - 2020-03-23 17:00:05 --> Output Class Initialized
INFO - 2020-03-23 17:00:05 --> Security Class Initialized
DEBUG - 2020-03-23 17:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:00:05 --> CSRF cookie sent
INFO - 2020-03-23 17:00:05 --> Input Class Initialized
INFO - 2020-03-23 17:00:05 --> Language Class Initialized
INFO - 2020-03-23 17:00:05 --> Language Class Initialized
INFO - 2020-03-23 17:00:05 --> Config Class Initialized
INFO - 2020-03-23 17:00:05 --> Loader Class Initialized
INFO - 2020-03-23 17:00:05 --> Helper loaded: url_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: common_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: language_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: email_helper
INFO - 2020-03-23 17:00:05 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:00:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:00:05 --> Parser Class Initialized
INFO - 2020-03-23 17:00:05 --> User Agent Class Initialized
INFO - 2020-03-23 17:00:05 --> Model Class Initialized
INFO - 2020-03-23 17:00:05 --> Database Driver Class Initialized
INFO - 2020-03-23 17:00:05 --> Model Class Initialized
DEBUG - 2020-03-23 17:00:05 --> Template Class Initialized
INFO - 2020-03-23 17:00:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:00:06 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:00:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:00:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:00:06 --> Encryption Class Initialized
INFO - 2020-03-23 17:00:06 --> Controller Class Initialized
DEBUG - 2020-03-23 17:00:06 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:00:06 --> Model Class Initialized
INFO - 2020-03-23 17:00:06 --> Config Class Initialized
INFO - 2020-03-23 17:00:06 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:00:06 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:00:06 --> Utf8 Class Initialized
INFO - 2020-03-23 17:00:06 --> URI Class Initialized
DEBUG - 2020-03-23 17:00:06 --> No URI present. Default controller set.
INFO - 2020-03-23 17:00:06 --> Router Class Initialized
INFO - 2020-03-23 17:00:06 --> Output Class Initialized
INFO - 2020-03-23 17:00:06 --> Security Class Initialized
DEBUG - 2020-03-23 17:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:00:06 --> CSRF cookie sent
INFO - 2020-03-23 17:00:06 --> Input Class Initialized
INFO - 2020-03-23 17:00:06 --> Language Class Initialized
INFO - 2020-03-23 17:00:06 --> Language Class Initialized
INFO - 2020-03-23 17:00:06 --> Config Class Initialized
INFO - 2020-03-23 17:00:06 --> Loader Class Initialized
INFO - 2020-03-23 17:00:06 --> Helper loaded: url_helper
INFO - 2020-03-23 17:00:06 --> Helper loaded: common_helper
INFO - 2020-03-23 17:00:06 --> Helper loaded: language_helper
INFO - 2020-03-23 17:00:06 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:00:06 --> Helper loaded: email_helper
INFO - 2020-03-23 17:00:06 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:00:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:00:06 --> Parser Class Initialized
INFO - 2020-03-23 17:00:06 --> User Agent Class Initialized
INFO - 2020-03-23 17:00:06 --> Model Class Initialized
INFO - 2020-03-23 17:00:06 --> Database Driver Class Initialized
INFO - 2020-03-23 17:00:06 --> Model Class Initialized
DEBUG - 2020-03-23 17:00:06 --> Template Class Initialized
INFO - 2020-03-23 17:00:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:00:06 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:00:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:00:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:00:06 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:00:06 --> Controller Class Initialized
DEBUG - 2020-03-23 17:00:06 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:00:06 --> Model Class Initialized
INFO - 2020-03-23 17:00:06 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:00:06 --> Final output sent to browser
DEBUG - 2020-03-23 17:00:06 --> Total execution time: 0.7171
INFO - 2020-03-23 17:01:15 --> Config Class Initialized
INFO - 2020-03-23 17:01:15 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:01:15 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:01:15 --> Utf8 Class Initialized
INFO - 2020-03-23 17:01:15 --> URI Class Initialized
INFO - 2020-03-23 17:01:15 --> Router Class Initialized
INFO - 2020-03-23 17:01:15 --> Output Class Initialized
INFO - 2020-03-23 17:01:15 --> Security Class Initialized
DEBUG - 2020-03-23 17:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:01:15 --> Input Class Initialized
INFO - 2020-03-23 17:01:15 --> Language Class Initialized
INFO - 2020-03-23 17:01:15 --> Language Class Initialized
INFO - 2020-03-23 17:01:15 --> Config Class Initialized
INFO - 2020-03-23 17:01:15 --> Loader Class Initialized
INFO - 2020-03-23 17:01:15 --> Helper loaded: url_helper
INFO - 2020-03-23 17:01:15 --> Helper loaded: common_helper
INFO - 2020-03-23 17:01:15 --> Helper loaded: language_helper
INFO - 2020-03-23 17:01:15 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:01:15 --> Helper loaded: email_helper
INFO - 2020-03-23 17:01:15 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:01:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:01:15 --> Parser Class Initialized
INFO - 2020-03-23 17:01:15 --> User Agent Class Initialized
INFO - 2020-03-23 17:01:15 --> Model Class Initialized
INFO - 2020-03-23 17:01:15 --> Database Driver Class Initialized
INFO - 2020-03-23 17:01:15 --> Model Class Initialized
DEBUG - 2020-03-23 17:01:15 --> Template Class Initialized
INFO - 2020-03-23 17:01:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:01:15 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:01:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:01:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:01:15 --> Encryption Class Initialized
INFO - 2020-03-23 17:01:15 --> Controller Class Initialized
DEBUG - 2020-03-23 17:01:15 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:01:15 --> Model Class Initialized
DEBUG - 2020-03-23 17:01:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:01:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 17:01:15 --> Config Class Initialized
INFO - 2020-03-23 17:01:15 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:01:15 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:01:15 --> Utf8 Class Initialized
INFO - 2020-03-23 17:01:15 --> URI Class Initialized
INFO - 2020-03-23 17:01:15 --> Router Class Initialized
INFO - 2020-03-23 17:01:15 --> Output Class Initialized
INFO - 2020-03-23 17:01:15 --> Security Class Initialized
DEBUG - 2020-03-23 17:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:01:16 --> CSRF cookie sent
INFO - 2020-03-23 17:01:16 --> Input Class Initialized
INFO - 2020-03-23 17:01:16 --> Language Class Initialized
INFO - 2020-03-23 17:01:16 --> Language Class Initialized
INFO - 2020-03-23 17:01:16 --> Config Class Initialized
INFO - 2020-03-23 17:01:16 --> Loader Class Initialized
INFO - 2020-03-23 17:01:16 --> Helper loaded: url_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: common_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: language_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: email_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:01:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:01:16 --> Parser Class Initialized
INFO - 2020-03-23 17:01:16 --> User Agent Class Initialized
INFO - 2020-03-23 17:01:16 --> Model Class Initialized
INFO - 2020-03-23 17:01:16 --> Database Driver Class Initialized
INFO - 2020-03-23 17:01:16 --> Model Class Initialized
DEBUG - 2020-03-23 17:01:16 --> Template Class Initialized
INFO - 2020-03-23 17:01:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:01:16 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:01:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:01:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:01:16 --> Encryption Class Initialized
INFO - 2020-03-23 17:01:16 --> Controller Class Initialized
DEBUG - 2020-03-23 17:01:16 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:01:16 --> Model Class Initialized
INFO - 2020-03-23 17:01:16 --> Config Class Initialized
INFO - 2020-03-23 17:01:16 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:01:16 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:01:16 --> Utf8 Class Initialized
INFO - 2020-03-23 17:01:16 --> URI Class Initialized
DEBUG - 2020-03-23 17:01:16 --> No URI present. Default controller set.
INFO - 2020-03-23 17:01:16 --> Router Class Initialized
INFO - 2020-03-23 17:01:16 --> Output Class Initialized
INFO - 2020-03-23 17:01:16 --> Security Class Initialized
DEBUG - 2020-03-23 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:01:16 --> CSRF cookie sent
INFO - 2020-03-23 17:01:16 --> Input Class Initialized
INFO - 2020-03-23 17:01:16 --> Language Class Initialized
INFO - 2020-03-23 17:01:16 --> Language Class Initialized
INFO - 2020-03-23 17:01:16 --> Config Class Initialized
INFO - 2020-03-23 17:01:16 --> Loader Class Initialized
INFO - 2020-03-23 17:01:16 --> Helper loaded: url_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: common_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: language_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: email_helper
INFO - 2020-03-23 17:01:16 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:01:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:01:16 --> Parser Class Initialized
INFO - 2020-03-23 17:01:16 --> User Agent Class Initialized
INFO - 2020-03-23 17:01:16 --> Model Class Initialized
INFO - 2020-03-23 17:01:16 --> Database Driver Class Initialized
INFO - 2020-03-23 17:01:16 --> Model Class Initialized
DEBUG - 2020-03-23 17:01:16 --> Template Class Initialized
INFO - 2020-03-23 17:01:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:01:16 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:01:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:01:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:01:16 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:01:16 --> Controller Class Initialized
DEBUG - 2020-03-23 17:01:16 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:01:16 --> Model Class Initialized
INFO - 2020-03-23 17:01:16 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:01:16 --> Final output sent to browser
DEBUG - 2020-03-23 17:01:16 --> Total execution time: 0.6253
INFO - 2020-03-23 17:01:29 --> Config Class Initialized
INFO - 2020-03-23 17:01:29 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:01:29 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:01:29 --> Utf8 Class Initialized
INFO - 2020-03-23 17:01:29 --> URI Class Initialized
INFO - 2020-03-23 17:01:29 --> Router Class Initialized
INFO - 2020-03-23 17:01:29 --> Output Class Initialized
INFO - 2020-03-23 17:01:29 --> Security Class Initialized
DEBUG - 2020-03-23 17:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:01:29 --> Input Class Initialized
INFO - 2020-03-23 17:01:29 --> Language Class Initialized
INFO - 2020-03-23 17:01:29 --> Language Class Initialized
INFO - 2020-03-23 17:01:29 --> Config Class Initialized
INFO - 2020-03-23 17:01:29 --> Loader Class Initialized
INFO - 2020-03-23 17:01:29 --> Helper loaded: url_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: common_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: language_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: email_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:01:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:01:29 --> Parser Class Initialized
INFO - 2020-03-23 17:01:29 --> User Agent Class Initialized
INFO - 2020-03-23 17:01:29 --> Model Class Initialized
INFO - 2020-03-23 17:01:29 --> Database Driver Class Initialized
INFO - 2020-03-23 17:01:29 --> Model Class Initialized
DEBUG - 2020-03-23 17:01:29 --> Template Class Initialized
INFO - 2020-03-23 17:01:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:01:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:01:29 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:01:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:01:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:01:29 --> Encryption Class Initialized
INFO - 2020-03-23 17:01:29 --> Controller Class Initialized
DEBUG - 2020-03-23 17:01:29 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:01:29 --> Model Class Initialized
DEBUG - 2020-03-23 17:01:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:01:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 17:01:29 --> Config Class Initialized
INFO - 2020-03-23 17:01:29 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:01:29 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:01:29 --> Utf8 Class Initialized
INFO - 2020-03-23 17:01:29 --> URI Class Initialized
INFO - 2020-03-23 17:01:29 --> Router Class Initialized
INFO - 2020-03-23 17:01:29 --> Output Class Initialized
INFO - 2020-03-23 17:01:29 --> Security Class Initialized
DEBUG - 2020-03-23 17:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:01:29 --> CSRF cookie sent
INFO - 2020-03-23 17:01:29 --> Input Class Initialized
INFO - 2020-03-23 17:01:29 --> Language Class Initialized
INFO - 2020-03-23 17:01:29 --> Language Class Initialized
INFO - 2020-03-23 17:01:29 --> Config Class Initialized
INFO - 2020-03-23 17:01:29 --> Loader Class Initialized
INFO - 2020-03-23 17:01:29 --> Helper loaded: url_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: common_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: language_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: email_helper
INFO - 2020-03-23 17:01:29 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:01:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:01:29 --> Parser Class Initialized
INFO - 2020-03-23 17:01:29 --> User Agent Class Initialized
INFO - 2020-03-23 17:01:29 --> Model Class Initialized
INFO - 2020-03-23 17:01:29 --> Database Driver Class Initialized
INFO - 2020-03-23 17:01:29 --> Model Class Initialized
DEBUG - 2020-03-23 17:01:29 --> Template Class Initialized
INFO - 2020-03-23 17:01:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:01:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:01:29 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:01:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:01:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:01:29 --> Encryption Class Initialized
INFO - 2020-03-23 17:01:29 --> Controller Class Initialized
DEBUG - 2020-03-23 17:01:29 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:01:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:01:29 --> Model Class Initialized
INFO - 2020-03-23 17:01:30 --> Config Class Initialized
INFO - 2020-03-23 17:01:30 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:01:30 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:01:30 --> Utf8 Class Initialized
INFO - 2020-03-23 17:01:30 --> URI Class Initialized
DEBUG - 2020-03-23 17:01:30 --> No URI present. Default controller set.
INFO - 2020-03-23 17:01:30 --> Router Class Initialized
INFO - 2020-03-23 17:01:30 --> Output Class Initialized
INFO - 2020-03-23 17:01:30 --> Security Class Initialized
DEBUG - 2020-03-23 17:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:01:30 --> CSRF cookie sent
INFO - 2020-03-23 17:01:30 --> Input Class Initialized
INFO - 2020-03-23 17:01:30 --> Language Class Initialized
INFO - 2020-03-23 17:01:30 --> Language Class Initialized
INFO - 2020-03-23 17:01:30 --> Config Class Initialized
INFO - 2020-03-23 17:01:30 --> Loader Class Initialized
INFO - 2020-03-23 17:01:30 --> Helper loaded: url_helper
INFO - 2020-03-23 17:01:30 --> Helper loaded: common_helper
INFO - 2020-03-23 17:01:30 --> Helper loaded: language_helper
INFO - 2020-03-23 17:01:30 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:01:30 --> Helper loaded: email_helper
INFO - 2020-03-23 17:01:30 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:01:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:01:30 --> Parser Class Initialized
INFO - 2020-03-23 17:01:30 --> User Agent Class Initialized
INFO - 2020-03-23 17:01:30 --> Model Class Initialized
INFO - 2020-03-23 17:01:30 --> Database Driver Class Initialized
INFO - 2020-03-23 17:01:30 --> Model Class Initialized
DEBUG - 2020-03-23 17:01:30 --> Template Class Initialized
INFO - 2020-03-23 17:01:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:01:30 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:01:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:01:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:01:30 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:01:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:01:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:01:30 --> Controller Class Initialized
DEBUG - 2020-03-23 17:01:30 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:01:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:01:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:01:30 --> Model Class Initialized
INFO - 2020-03-23 17:01:30 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:01:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:01:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:01:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:01:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:01:30 --> Final output sent to browser
DEBUG - 2020-03-23 17:01:30 --> Total execution time: 0.6592
INFO - 2020-03-23 17:02:23 --> Config Class Initialized
INFO - 2020-03-23 17:02:23 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:02:23 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:02:23 --> Utf8 Class Initialized
INFO - 2020-03-23 17:02:23 --> URI Class Initialized
INFO - 2020-03-23 17:02:23 --> Router Class Initialized
INFO - 2020-03-23 17:02:23 --> Output Class Initialized
INFO - 2020-03-23 17:02:23 --> Security Class Initialized
DEBUG - 2020-03-23 17:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:02:23 --> CSRF cookie sent
INFO - 2020-03-23 17:02:23 --> Input Class Initialized
INFO - 2020-03-23 17:02:23 --> Language Class Initialized
INFO - 2020-03-23 17:02:23 --> Language Class Initialized
INFO - 2020-03-23 17:02:23 --> Config Class Initialized
INFO - 2020-03-23 17:02:23 --> Loader Class Initialized
INFO - 2020-03-23 17:02:23 --> Helper loaded: url_helper
INFO - 2020-03-23 17:02:23 --> Helper loaded: common_helper
INFO - 2020-03-23 17:02:23 --> Helper loaded: language_helper
INFO - 2020-03-23 17:02:23 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:02:23 --> Helper loaded: email_helper
INFO - 2020-03-23 17:02:23 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:02:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:02:23 --> Parser Class Initialized
INFO - 2020-03-23 17:02:23 --> User Agent Class Initialized
INFO - 2020-03-23 17:02:23 --> Model Class Initialized
INFO - 2020-03-23 17:02:23 --> Database Driver Class Initialized
INFO - 2020-03-23 17:02:23 --> Model Class Initialized
DEBUG - 2020-03-23 17:02:23 --> Template Class Initialized
INFO - 2020-03-23 17:02:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:02:23 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:02:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:02:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:02:23 --> Encryption Class Initialized
INFO - 2020-03-23 17:02:23 --> Controller Class Initialized
DEBUG - 2020-03-23 17:02:23 --> package MX_Controller Initialized
DEBUG - 2020-03-23 17:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-23 17:02:23 --> Model Class Initialized
INFO - 2020-03-23 17:02:23 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:02:23 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:02:23 --> Model Class Initialized
DEBUG - 2020-03-23 17:02:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:02:24 --> Model Class Initialized
DEBUG - 2020-03-23 17:02:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-23 17:02:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:02:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:02:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:02:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:02:24 --> Final output sent to browser
DEBUG - 2020-03-23 17:02:24 --> Total execution time: 0.9822
INFO - 2020-03-23 17:02:26 --> Config Class Initialized
INFO - 2020-03-23 17:02:26 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:02:26 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:02:26 --> Utf8 Class Initialized
INFO - 2020-03-23 17:02:26 --> URI Class Initialized
INFO - 2020-03-23 17:02:26 --> Router Class Initialized
INFO - 2020-03-23 17:02:26 --> Output Class Initialized
INFO - 2020-03-23 17:02:26 --> Security Class Initialized
DEBUG - 2020-03-23 17:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:02:26 --> CSRF cookie sent
INFO - 2020-03-23 17:02:26 --> CSRF token verified
INFO - 2020-03-23 17:02:26 --> Input Class Initialized
INFO - 2020-03-23 17:02:26 --> Language Class Initialized
INFO - 2020-03-23 17:02:26 --> Language Class Initialized
INFO - 2020-03-23 17:02:26 --> Config Class Initialized
INFO - 2020-03-23 17:02:26 --> Loader Class Initialized
INFO - 2020-03-23 17:02:26 --> Helper loaded: url_helper
INFO - 2020-03-23 17:02:26 --> Helper loaded: common_helper
INFO - 2020-03-23 17:02:26 --> Helper loaded: language_helper
INFO - 2020-03-23 17:02:26 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:02:26 --> Helper loaded: email_helper
INFO - 2020-03-23 17:02:26 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:02:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:02:26 --> Parser Class Initialized
INFO - 2020-03-23 17:02:26 --> User Agent Class Initialized
INFO - 2020-03-23 17:02:26 --> Model Class Initialized
INFO - 2020-03-23 17:02:26 --> Database Driver Class Initialized
INFO - 2020-03-23 17:02:26 --> Model Class Initialized
DEBUG - 2020-03-23 17:02:26 --> Template Class Initialized
INFO - 2020-03-23 17:02:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:02:26 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:02:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:02:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:02:26 --> Encryption Class Initialized
INFO - 2020-03-23 17:02:26 --> Controller Class Initialized
DEBUG - 2020-03-23 17:02:26 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:02:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:02:26 --> Model Class Initialized
INFO - 2020-03-23 17:02:27 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:02:27 --> Could not find the language line "shopier"
DEBUG - 2020-03-23 17:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-23 17:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:02:27 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:02:27 --> Model Class Initialized
DEBUG - 2020-03-23 17:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:02:27 --> Model Class Initialized
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:02:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:02:27 --> Final output sent to browser
DEBUG - 2020-03-23 17:02:27 --> Total execution time: 1.2560
INFO - 2020-03-23 17:02:36 --> Config Class Initialized
INFO - 2020-03-23 17:02:36 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:02:36 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:02:36 --> Utf8 Class Initialized
INFO - 2020-03-23 17:02:36 --> URI Class Initialized
INFO - 2020-03-23 17:02:36 --> Router Class Initialized
INFO - 2020-03-23 17:02:36 --> Output Class Initialized
INFO - 2020-03-23 17:02:36 --> Security Class Initialized
DEBUG - 2020-03-23 17:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:02:36 --> CSRF cookie sent
INFO - 2020-03-23 17:02:36 --> CSRF token verified
INFO - 2020-03-23 17:02:36 --> Input Class Initialized
INFO - 2020-03-23 17:02:36 --> Language Class Initialized
INFO - 2020-03-23 17:02:36 --> Language Class Initialized
INFO - 2020-03-23 17:02:36 --> Config Class Initialized
INFO - 2020-03-23 17:02:36 --> Loader Class Initialized
INFO - 2020-03-23 17:02:36 --> Helper loaded: url_helper
INFO - 2020-03-23 17:02:36 --> Helper loaded: common_helper
INFO - 2020-03-23 17:02:36 --> Helper loaded: language_helper
INFO - 2020-03-23 17:02:36 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:02:36 --> Helper loaded: email_helper
INFO - 2020-03-23 17:02:36 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:02:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:02:36 --> Parser Class Initialized
INFO - 2020-03-23 17:02:36 --> User Agent Class Initialized
INFO - 2020-03-23 17:02:36 --> Model Class Initialized
INFO - 2020-03-23 17:02:36 --> Database Driver Class Initialized
INFO - 2020-03-23 17:02:36 --> Model Class Initialized
DEBUG - 2020-03-23 17:02:36 --> Template Class Initialized
INFO - 2020-03-23 17:02:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:02:36 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:02:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:02:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:02:36 --> Encryption Class Initialized
INFO - 2020-03-23 17:02:36 --> Controller Class Initialized
DEBUG - 2020-03-23 17:02:36 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:02:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:02:36 --> Model Class Initialized
DEBUG - 2020-03-23 17:02:36 --> paytm MX_Controller Initialized
DEBUG - 2020-03-23 17:02:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:02:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2020-03-23 17:02:36 --> orders MX_Controller Initialized
DEBUG - 2020-03-23 17:02:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2020-03-23 17:02:36 --> Final output sent to browser
DEBUG - 2020-03-23 17:02:36 --> Total execution time: 0.6641
INFO - 2020-03-23 17:02:53 --> Config Class Initialized
INFO - 2020-03-23 17:02:53 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:02:53 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:02:53 --> Utf8 Class Initialized
INFO - 2020-03-23 17:02:53 --> URI Class Initialized
INFO - 2020-03-23 17:02:53 --> Router Class Initialized
INFO - 2020-03-23 17:02:53 --> Output Class Initialized
INFO - 2020-03-23 17:02:53 --> Security Class Initialized
DEBUG - 2020-03-23 17:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:02:53 --> Input Class Initialized
INFO - 2020-03-23 17:02:53 --> Language Class Initialized
INFO - 2020-03-23 17:02:53 --> Language Class Initialized
INFO - 2020-03-23 17:02:53 --> Config Class Initialized
INFO - 2020-03-23 17:02:53 --> Loader Class Initialized
INFO - 2020-03-23 17:02:53 --> Helper loaded: url_helper
INFO - 2020-03-23 17:02:53 --> Helper loaded: common_helper
INFO - 2020-03-23 17:02:53 --> Helper loaded: language_helper
INFO - 2020-03-23 17:02:53 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:02:53 --> Helper loaded: email_helper
INFO - 2020-03-23 17:02:53 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:02:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:02:53 --> Parser Class Initialized
INFO - 2020-03-23 17:02:53 --> User Agent Class Initialized
INFO - 2020-03-23 17:02:53 --> Model Class Initialized
INFO - 2020-03-23 17:02:53 --> Database Driver Class Initialized
INFO - 2020-03-23 17:02:54 --> Model Class Initialized
DEBUG - 2020-03-23 17:02:54 --> Template Class Initialized
INFO - 2020-03-23 17:02:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:02:54 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:02:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:02:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:02:54 --> Encryption Class Initialized
INFO - 2020-03-23 17:02:54 --> Controller Class Initialized
DEBUG - 2020-03-23 17:02:54 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:02:54 --> Model Class Initialized
DEBUG - 2020-03-23 17:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:02:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 17:05:44 --> Config Class Initialized
INFO - 2020-03-23 17:05:44 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:05:44 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:05:44 --> Utf8 Class Initialized
INFO - 2020-03-23 17:05:44 --> URI Class Initialized
INFO - 2020-03-23 17:05:44 --> Router Class Initialized
INFO - 2020-03-23 17:05:44 --> Output Class Initialized
INFO - 2020-03-23 17:05:44 --> Security Class Initialized
DEBUG - 2020-03-23 17:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:05:44 --> CSRF cookie sent
INFO - 2020-03-23 17:05:44 --> Input Class Initialized
INFO - 2020-03-23 17:05:44 --> Language Class Initialized
INFO - 2020-03-23 17:05:44 --> Language Class Initialized
INFO - 2020-03-23 17:05:44 --> Config Class Initialized
INFO - 2020-03-23 17:05:44 --> Loader Class Initialized
INFO - 2020-03-23 17:05:44 --> Helper loaded: url_helper
INFO - 2020-03-23 17:05:44 --> Helper loaded: common_helper
INFO - 2020-03-23 17:05:44 --> Helper loaded: language_helper
INFO - 2020-03-23 17:05:44 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:05:44 --> Helper loaded: email_helper
INFO - 2020-03-23 17:05:44 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:05:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:05:44 --> Parser Class Initialized
INFO - 2020-03-23 17:05:44 --> User Agent Class Initialized
INFO - 2020-03-23 17:05:44 --> Model Class Initialized
INFO - 2020-03-23 17:05:44 --> Database Driver Class Initialized
INFO - 2020-03-23 17:05:44 --> Model Class Initialized
DEBUG - 2020-03-23 17:05:44 --> Template Class Initialized
INFO - 2020-03-23 17:05:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:05:44 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:05:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:05:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:05:45 --> Encryption Class Initialized
INFO - 2020-03-23 17:05:45 --> Controller Class Initialized
DEBUG - 2020-03-23 17:05:45 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:05:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:05:45 --> Model Class Initialized
INFO - 2020-03-23 17:05:45 --> Config Class Initialized
INFO - 2020-03-23 17:05:45 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:05:45 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:05:45 --> Utf8 Class Initialized
INFO - 2020-03-23 17:05:45 --> URI Class Initialized
DEBUG - 2020-03-23 17:05:45 --> No URI present. Default controller set.
INFO - 2020-03-23 17:05:45 --> Router Class Initialized
INFO - 2020-03-23 17:05:45 --> Output Class Initialized
INFO - 2020-03-23 17:05:45 --> Security Class Initialized
DEBUG - 2020-03-23 17:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:05:45 --> CSRF cookie sent
INFO - 2020-03-23 17:05:45 --> Input Class Initialized
INFO - 2020-03-23 17:05:45 --> Language Class Initialized
INFO - 2020-03-23 17:05:45 --> Language Class Initialized
INFO - 2020-03-23 17:05:45 --> Config Class Initialized
INFO - 2020-03-23 17:05:45 --> Loader Class Initialized
INFO - 2020-03-23 17:05:45 --> Helper loaded: url_helper
INFO - 2020-03-23 17:05:45 --> Helper loaded: common_helper
INFO - 2020-03-23 17:05:45 --> Helper loaded: language_helper
INFO - 2020-03-23 17:05:45 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:05:45 --> Helper loaded: email_helper
INFO - 2020-03-23 17:05:45 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:05:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:05:45 --> Parser Class Initialized
INFO - 2020-03-23 17:05:45 --> User Agent Class Initialized
INFO - 2020-03-23 17:05:45 --> Model Class Initialized
INFO - 2020-03-23 17:05:45 --> Database Driver Class Initialized
INFO - 2020-03-23 17:05:45 --> Model Class Initialized
DEBUG - 2020-03-23 17:05:45 --> Template Class Initialized
INFO - 2020-03-23 17:05:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:05:45 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:05:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:05:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:05:45 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:05:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:05:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:05:45 --> Controller Class Initialized
DEBUG - 2020-03-23 17:05:45 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:05:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:05:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:05:45 --> Model Class Initialized
INFO - 2020-03-23 17:05:45 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:05:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:05:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:05:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:05:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:05:45 --> Final output sent to browser
DEBUG - 2020-03-23 17:05:45 --> Total execution time: 0.7842
INFO - 2020-03-23 17:05:48 --> Config Class Initialized
INFO - 2020-03-23 17:05:48 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:05:48 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:05:48 --> Utf8 Class Initialized
INFO - 2020-03-23 17:05:48 --> URI Class Initialized
INFO - 2020-03-23 17:05:48 --> Router Class Initialized
INFO - 2020-03-23 17:05:48 --> Output Class Initialized
INFO - 2020-03-23 17:05:48 --> Security Class Initialized
DEBUG - 2020-03-23 17:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:05:48 --> CSRF cookie sent
INFO - 2020-03-23 17:05:48 --> Input Class Initialized
INFO - 2020-03-23 17:05:48 --> Language Class Initialized
INFO - 2020-03-23 17:05:48 --> Language Class Initialized
INFO - 2020-03-23 17:05:48 --> Config Class Initialized
INFO - 2020-03-23 17:05:48 --> Loader Class Initialized
INFO - 2020-03-23 17:05:48 --> Helper loaded: url_helper
INFO - 2020-03-23 17:05:48 --> Helper loaded: common_helper
INFO - 2020-03-23 17:05:48 --> Helper loaded: language_helper
INFO - 2020-03-23 17:05:48 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:05:48 --> Helper loaded: email_helper
INFO - 2020-03-23 17:05:48 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:05:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:05:48 --> Parser Class Initialized
INFO - 2020-03-23 17:05:48 --> User Agent Class Initialized
INFO - 2020-03-23 17:05:48 --> Model Class Initialized
INFO - 2020-03-23 17:05:48 --> Database Driver Class Initialized
INFO - 2020-03-23 17:05:48 --> Model Class Initialized
DEBUG - 2020-03-23 17:05:48 --> Template Class Initialized
INFO - 2020-03-23 17:05:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:05:48 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:05:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:05:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:05:48 --> Encryption Class Initialized
INFO - 2020-03-23 17:05:48 --> Controller Class Initialized
DEBUG - 2020-03-23 17:05:48 --> package MX_Controller Initialized
DEBUG - 2020-03-23 17:05:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-23 17:05:48 --> Model Class Initialized
INFO - 2020-03-23 17:05:48 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:05:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:05:48 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:05:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:05:48 --> Model Class Initialized
DEBUG - 2020-03-23 17:05:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:05:48 --> Model Class Initialized
DEBUG - 2020-03-23 17:05:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-23 17:05:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:05:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:05:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:05:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:05:49 --> Final output sent to browser
DEBUG - 2020-03-23 17:05:49 --> Total execution time: 1.1139
INFO - 2020-03-23 17:05:51 --> Config Class Initialized
INFO - 2020-03-23 17:05:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:05:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:05:51 --> Utf8 Class Initialized
INFO - 2020-03-23 17:05:51 --> URI Class Initialized
INFO - 2020-03-23 17:05:51 --> Router Class Initialized
INFO - 2020-03-23 17:05:51 --> Output Class Initialized
INFO - 2020-03-23 17:05:51 --> Security Class Initialized
DEBUG - 2020-03-23 17:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:05:51 --> CSRF cookie sent
INFO - 2020-03-23 17:05:51 --> CSRF token verified
INFO - 2020-03-23 17:05:51 --> Input Class Initialized
INFO - 2020-03-23 17:05:51 --> Language Class Initialized
INFO - 2020-03-23 17:05:51 --> Language Class Initialized
INFO - 2020-03-23 17:05:51 --> Config Class Initialized
INFO - 2020-03-23 17:05:51 --> Loader Class Initialized
INFO - 2020-03-23 17:05:51 --> Helper loaded: url_helper
INFO - 2020-03-23 17:05:52 --> Helper loaded: common_helper
INFO - 2020-03-23 17:05:52 --> Helper loaded: language_helper
INFO - 2020-03-23 17:05:52 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:05:52 --> Helper loaded: email_helper
INFO - 2020-03-23 17:05:52 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:05:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:05:52 --> Parser Class Initialized
INFO - 2020-03-23 17:05:52 --> User Agent Class Initialized
INFO - 2020-03-23 17:05:52 --> Model Class Initialized
INFO - 2020-03-23 17:05:52 --> Database Driver Class Initialized
INFO - 2020-03-23 17:05:52 --> Model Class Initialized
DEBUG - 2020-03-23 17:05:52 --> Template Class Initialized
INFO - 2020-03-23 17:05:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:05:52 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:05:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:05:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:05:52 --> Encryption Class Initialized
INFO - 2020-03-23 17:05:52 --> Controller Class Initialized
DEBUG - 2020-03-23 17:05:52 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:05:52 --> Model Class Initialized
INFO - 2020-03-23 17:05:52 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:05:52 --> Could not find the language line "shopier"
DEBUG - 2020-03-23 17:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-23 17:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:05:52 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:05:52 --> Model Class Initialized
DEBUG - 2020-03-23 17:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:05:52 --> Model Class Initialized
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:05:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:05:52 --> Final output sent to browser
DEBUG - 2020-03-23 17:05:52 --> Total execution time: 1.0713
INFO - 2020-03-23 17:06:03 --> Config Class Initialized
INFO - 2020-03-23 17:06:03 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:06:03 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:06:03 --> Utf8 Class Initialized
INFO - 2020-03-23 17:06:03 --> URI Class Initialized
INFO - 2020-03-23 17:06:03 --> Router Class Initialized
INFO - 2020-03-23 17:06:03 --> Output Class Initialized
INFO - 2020-03-23 17:06:03 --> Security Class Initialized
DEBUG - 2020-03-23 17:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:06:03 --> CSRF cookie sent
INFO - 2020-03-23 17:06:03 --> CSRF token verified
INFO - 2020-03-23 17:06:03 --> Input Class Initialized
INFO - 2020-03-23 17:06:03 --> Language Class Initialized
INFO - 2020-03-23 17:06:03 --> Language Class Initialized
INFO - 2020-03-23 17:06:03 --> Config Class Initialized
INFO - 2020-03-23 17:06:03 --> Loader Class Initialized
INFO - 2020-03-23 17:06:03 --> Helper loaded: url_helper
INFO - 2020-03-23 17:06:03 --> Helper loaded: common_helper
INFO - 2020-03-23 17:06:03 --> Helper loaded: language_helper
INFO - 2020-03-23 17:06:03 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:06:03 --> Helper loaded: email_helper
INFO - 2020-03-23 17:06:03 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:06:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:06:03 --> Parser Class Initialized
INFO - 2020-03-23 17:06:03 --> User Agent Class Initialized
INFO - 2020-03-23 17:06:03 --> Model Class Initialized
INFO - 2020-03-23 17:06:03 --> Database Driver Class Initialized
INFO - 2020-03-23 17:06:03 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:03 --> Template Class Initialized
INFO - 2020-03-23 17:06:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:06:03 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:06:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:06:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:06:03 --> Encryption Class Initialized
INFO - 2020-03-23 17:06:03 --> Controller Class Initialized
DEBUG - 2020-03-23 17:06:03 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:06:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:06:03 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:03 --> paytm MX_Controller Initialized
DEBUG - 2020-03-23 17:06:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:06:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2020-03-23 17:06:03 --> orders MX_Controller Initialized
DEBUG - 2020-03-23 17:06:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2020-03-23 17:06:03 --> Final output sent to browser
DEBUG - 2020-03-23 17:06:03 --> Total execution time: 0.7332
INFO - 2020-03-23 17:06:20 --> Config Class Initialized
INFO - 2020-03-23 17:06:20 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:06:20 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:06:20 --> Utf8 Class Initialized
INFO - 2020-03-23 17:06:20 --> URI Class Initialized
INFO - 2020-03-23 17:06:20 --> Router Class Initialized
INFO - 2020-03-23 17:06:20 --> Output Class Initialized
INFO - 2020-03-23 17:06:20 --> Security Class Initialized
DEBUG - 2020-03-23 17:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:06:20 --> CSRF cookie sent
INFO - 2020-03-23 17:06:20 --> Input Class Initialized
INFO - 2020-03-23 17:06:20 --> Language Class Initialized
INFO - 2020-03-23 17:06:20 --> Language Class Initialized
INFO - 2020-03-23 17:06:20 --> Config Class Initialized
INFO - 2020-03-23 17:06:20 --> Loader Class Initialized
INFO - 2020-03-23 17:06:20 --> Helper loaded: url_helper
INFO - 2020-03-23 17:06:20 --> Helper loaded: common_helper
INFO - 2020-03-23 17:06:20 --> Helper loaded: language_helper
INFO - 2020-03-23 17:06:20 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:06:20 --> Helper loaded: email_helper
INFO - 2020-03-23 17:06:20 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:06:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:06:20 --> Parser Class Initialized
INFO - 2020-03-23 17:06:20 --> User Agent Class Initialized
INFO - 2020-03-23 17:06:20 --> Model Class Initialized
INFO - 2020-03-23 17:06:20 --> Database Driver Class Initialized
INFO - 2020-03-23 17:06:21 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:21 --> Template Class Initialized
INFO - 2020-03-23 17:06:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:06:21 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:06:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:06:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:06:21 --> Encryption Class Initialized
INFO - 2020-03-23 17:06:21 --> Controller Class Initialized
DEBUG - 2020-03-23 17:06:21 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 17:06:21 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:06:21 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-23 17:06:21 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-23 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-23 17:06:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:06:21 --> Final output sent to browser
DEBUG - 2020-03-23 17:06:21 --> Total execution time: 0.6032
INFO - 2020-03-23 17:06:23 --> Config Class Initialized
INFO - 2020-03-23 17:06:23 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:06:23 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:06:23 --> Utf8 Class Initialized
INFO - 2020-03-23 17:06:23 --> URI Class Initialized
INFO - 2020-03-23 17:06:23 --> Router Class Initialized
INFO - 2020-03-23 17:06:23 --> Output Class Initialized
INFO - 2020-03-23 17:06:23 --> Security Class Initialized
DEBUG - 2020-03-23 17:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:06:23 --> CSRF cookie sent
INFO - 2020-03-23 17:06:23 --> CSRF token verified
INFO - 2020-03-23 17:06:23 --> Input Class Initialized
INFO - 2020-03-23 17:06:23 --> Language Class Initialized
INFO - 2020-03-23 17:06:23 --> Language Class Initialized
INFO - 2020-03-23 17:06:23 --> Config Class Initialized
INFO - 2020-03-23 17:06:23 --> Loader Class Initialized
INFO - 2020-03-23 17:06:23 --> Helper loaded: url_helper
INFO - 2020-03-23 17:06:23 --> Helper loaded: common_helper
INFO - 2020-03-23 17:06:23 --> Helper loaded: language_helper
INFO - 2020-03-23 17:06:23 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:06:23 --> Helper loaded: email_helper
INFO - 2020-03-23 17:06:23 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:06:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:06:23 --> Parser Class Initialized
INFO - 2020-03-23 17:06:23 --> User Agent Class Initialized
INFO - 2020-03-23 17:06:23 --> Model Class Initialized
INFO - 2020-03-23 17:06:23 --> Database Driver Class Initialized
INFO - 2020-03-23 17:06:23 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:23 --> Template Class Initialized
INFO - 2020-03-23 17:06:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:06:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:06:23 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:06:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:06:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:06:23 --> Encryption Class Initialized
INFO - 2020-03-23 17:06:23 --> Controller Class Initialized
DEBUG - 2020-03-23 17:06:23 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 17:06:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 17:06:23 --> Model Class Initialized
INFO - 2020-03-23 17:06:28 --> Config Class Initialized
INFO - 2020-03-23 17:06:28 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:06:28 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:06:28 --> Utf8 Class Initialized
INFO - 2020-03-23 17:06:28 --> URI Class Initialized
INFO - 2020-03-23 17:06:28 --> Router Class Initialized
INFO - 2020-03-23 17:06:28 --> Output Class Initialized
INFO - 2020-03-23 17:06:28 --> Security Class Initialized
DEBUG - 2020-03-23 17:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:06:28 --> CSRF cookie sent
INFO - 2020-03-23 17:06:28 --> Input Class Initialized
INFO - 2020-03-23 17:06:28 --> Language Class Initialized
INFO - 2020-03-23 17:06:28 --> Language Class Initialized
INFO - 2020-03-23 17:06:28 --> Config Class Initialized
INFO - 2020-03-23 17:06:28 --> Loader Class Initialized
INFO - 2020-03-23 17:06:28 --> Helper loaded: url_helper
INFO - 2020-03-23 17:06:28 --> Helper loaded: common_helper
INFO - 2020-03-23 17:06:28 --> Helper loaded: language_helper
INFO - 2020-03-23 17:06:28 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:06:28 --> Helper loaded: email_helper
INFO - 2020-03-23 17:06:28 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:06:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:06:28 --> Parser Class Initialized
INFO - 2020-03-23 17:06:28 --> User Agent Class Initialized
INFO - 2020-03-23 17:06:28 --> Model Class Initialized
INFO - 2020-03-23 17:06:28 --> Database Driver Class Initialized
INFO - 2020-03-23 17:06:28 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:28 --> Template Class Initialized
INFO - 2020-03-23 17:06:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:06:28 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:06:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:06:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:06:28 --> Encryption Class Initialized
INFO - 2020-03-23 17:06:28 --> Controller Class Initialized
DEBUG - 2020-03-23 17:06:28 --> statistics MX_Controller Initialized
DEBUG - 2020-03-23 17:06:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-23 17:06:28 --> Model Class Initialized
ERROR - 2020-03-23 17:06:28 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:28 --> Could not find the language line "Pending"
INFO - 2020-03-23 17:06:28 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:06:28 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 17:06:28 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 17:06:28 --> Could not find the language line "Pending"
DEBUG - 2020-03-23 17:06:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-23 17:06:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:06:28 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:06:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:06:28 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:06:28 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 17:06:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 17:06:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 17:06:29 --> Final output sent to browser
DEBUG - 2020-03-23 17:06:29 --> Total execution time: 0.8657
INFO - 2020-03-23 17:06:32 --> Config Class Initialized
INFO - 2020-03-23 17:06:32 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:06:32 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:06:32 --> Utf8 Class Initialized
INFO - 2020-03-23 17:06:32 --> URI Class Initialized
INFO - 2020-03-23 17:06:32 --> Router Class Initialized
INFO - 2020-03-23 17:06:32 --> Output Class Initialized
INFO - 2020-03-23 17:06:32 --> Security Class Initialized
DEBUG - 2020-03-23 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:06:32 --> CSRF cookie sent
INFO - 2020-03-23 17:06:32 --> Input Class Initialized
INFO - 2020-03-23 17:06:32 --> Language Class Initialized
INFO - 2020-03-23 17:06:32 --> Language Class Initialized
INFO - 2020-03-23 17:06:32 --> Config Class Initialized
INFO - 2020-03-23 17:06:32 --> Loader Class Initialized
INFO - 2020-03-23 17:06:32 --> Helper loaded: url_helper
INFO - 2020-03-23 17:06:32 --> Helper loaded: common_helper
INFO - 2020-03-23 17:06:32 --> Helper loaded: language_helper
INFO - 2020-03-23 17:06:32 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:06:32 --> Helper loaded: email_helper
INFO - 2020-03-23 17:06:32 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:06:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:06:32 --> Parser Class Initialized
INFO - 2020-03-23 17:06:32 --> User Agent Class Initialized
INFO - 2020-03-23 17:06:32 --> Model Class Initialized
INFO - 2020-03-23 17:06:32 --> Database Driver Class Initialized
INFO - 2020-03-23 17:06:32 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:32 --> Template Class Initialized
INFO - 2020-03-23 17:06:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:06:32 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:06:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:06:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:06:32 --> Encryption Class Initialized
INFO - 2020-03-23 17:06:32 --> Controller Class Initialized
DEBUG - 2020-03-23 17:06:32 --> transactions MX_Controller Initialized
DEBUG - 2020-03-23 17:06:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-23 17:06:32 --> Model Class Initialized
ERROR - 2020-03-23 17:06:32 --> Could not find the language line "order_id"
INFO - 2020-03-23 17:06:32 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-23 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:06:33 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:06:33 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:06:33 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 17:06:33 --> Final output sent to browser
DEBUG - 2020-03-23 17:06:33 --> Total execution time: 0.8558
INFO - 2020-03-23 17:06:38 --> Config Class Initialized
INFO - 2020-03-23 17:06:38 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:06:38 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:06:38 --> Utf8 Class Initialized
INFO - 2020-03-23 17:06:38 --> URI Class Initialized
INFO - 2020-03-23 17:06:38 --> Router Class Initialized
INFO - 2020-03-23 17:06:38 --> Output Class Initialized
INFO - 2020-03-23 17:06:38 --> Security Class Initialized
DEBUG - 2020-03-23 17:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:06:38 --> CSRF cookie sent
INFO - 2020-03-23 17:06:38 --> Input Class Initialized
INFO - 2020-03-23 17:06:38 --> Language Class Initialized
INFO - 2020-03-23 17:06:38 --> Language Class Initialized
INFO - 2020-03-23 17:06:38 --> Config Class Initialized
INFO - 2020-03-23 17:06:38 --> Loader Class Initialized
INFO - 2020-03-23 17:06:38 --> Helper loaded: url_helper
INFO - 2020-03-23 17:06:38 --> Helper loaded: common_helper
INFO - 2020-03-23 17:06:38 --> Helper loaded: language_helper
INFO - 2020-03-23 17:06:38 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:06:38 --> Helper loaded: email_helper
INFO - 2020-03-23 17:06:38 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:06:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:06:38 --> Parser Class Initialized
INFO - 2020-03-23 17:06:38 --> User Agent Class Initialized
INFO - 2020-03-23 17:06:38 --> Model Class Initialized
INFO - 2020-03-23 17:06:38 --> Database Driver Class Initialized
INFO - 2020-03-23 17:06:38 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:38 --> Template Class Initialized
INFO - 2020-03-23 17:06:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:06:38 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:06:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:06:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:06:38 --> Encryption Class Initialized
INFO - 2020-03-23 17:06:39 --> Controller Class Initialized
DEBUG - 2020-03-23 17:06:39 --> order MX_Controller Initialized
DEBUG - 2020-03-23 17:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2020-03-23 17:06:39 --> Model Class Initialized
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "order_id"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "order_basic_details"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "order_id"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "order_basic_details"
INFO - 2020-03-23 17:06:39 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:06:39 --> Could not find the language line "Pending"
DEBUG - 2020-03-23 17:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2020-03-23 17:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:06:39 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:06:39 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:06:39 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 17:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 17:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 17:06:39 --> Final output sent to browser
DEBUG - 2020-03-23 17:06:39 --> Total execution time: 1.2470
INFO - 2020-03-23 17:06:47 --> Config Class Initialized
INFO - 2020-03-23 17:06:47 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:06:47 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:06:47 --> Utf8 Class Initialized
INFO - 2020-03-23 17:06:48 --> URI Class Initialized
INFO - 2020-03-23 17:06:48 --> Router Class Initialized
INFO - 2020-03-23 17:06:48 --> Output Class Initialized
INFO - 2020-03-23 17:06:48 --> Security Class Initialized
DEBUG - 2020-03-23 17:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:06:48 --> Input Class Initialized
INFO - 2020-03-23 17:06:48 --> Language Class Initialized
INFO - 2020-03-23 17:06:48 --> Language Class Initialized
INFO - 2020-03-23 17:06:48 --> Config Class Initialized
INFO - 2020-03-23 17:06:48 --> Loader Class Initialized
INFO - 2020-03-23 17:06:48 --> Helper loaded: url_helper
INFO - 2020-03-23 17:06:48 --> Helper loaded: common_helper
INFO - 2020-03-23 17:06:48 --> Helper loaded: language_helper
INFO - 2020-03-23 17:06:48 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:06:48 --> Helper loaded: email_helper
INFO - 2020-03-23 17:06:48 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:06:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:06:48 --> Parser Class Initialized
INFO - 2020-03-23 17:06:48 --> User Agent Class Initialized
INFO - 2020-03-23 17:06:48 --> Model Class Initialized
INFO - 2020-03-23 17:06:48 --> Database Driver Class Initialized
INFO - 2020-03-23 17:06:48 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:48 --> Template Class Initialized
INFO - 2020-03-23 17:06:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:06:48 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:06:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:06:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:06:48 --> Encryption Class Initialized
INFO - 2020-03-23 17:06:48 --> Controller Class Initialized
DEBUG - 2020-03-23 17:06:48 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:06:48 --> Model Class Initialized
DEBUG - 2020-03-23 17:06:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:06:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 17:07:16 --> Config Class Initialized
INFO - 2020-03-23 17:07:16 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:07:16 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:07:16 --> Utf8 Class Initialized
INFO - 2020-03-23 17:07:16 --> URI Class Initialized
INFO - 2020-03-23 17:07:16 --> Router Class Initialized
INFO - 2020-03-23 17:07:16 --> Output Class Initialized
INFO - 2020-03-23 17:07:16 --> Security Class Initialized
DEBUG - 2020-03-23 17:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:07:16 --> Input Class Initialized
INFO - 2020-03-23 17:07:16 --> Language Class Initialized
INFO - 2020-03-23 17:07:16 --> Language Class Initialized
INFO - 2020-03-23 17:07:16 --> Config Class Initialized
INFO - 2020-03-23 17:07:16 --> Loader Class Initialized
INFO - 2020-03-23 17:07:16 --> Helper loaded: url_helper
INFO - 2020-03-23 17:07:16 --> Helper loaded: common_helper
INFO - 2020-03-23 17:07:16 --> Helper loaded: language_helper
INFO - 2020-03-23 17:07:16 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:07:16 --> Helper loaded: email_helper
INFO - 2020-03-23 17:07:16 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:07:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:07:16 --> Parser Class Initialized
INFO - 2020-03-23 17:07:16 --> User Agent Class Initialized
INFO - 2020-03-23 17:07:16 --> Model Class Initialized
INFO - 2020-03-23 17:07:16 --> Database Driver Class Initialized
INFO - 2020-03-23 17:07:16 --> Model Class Initialized
DEBUG - 2020-03-23 17:07:16 --> Template Class Initialized
INFO - 2020-03-23 17:07:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:07:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:07:16 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:07:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:07:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:07:16 --> Encryption Class Initialized
INFO - 2020-03-23 17:07:16 --> Controller Class Initialized
DEBUG - 2020-03-23 17:07:16 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:07:16 --> Model Class Initialized
DEBUG - 2020-03-23 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 17:07:24 --> Config Class Initialized
INFO - 2020-03-23 17:07:24 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:07:24 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:07:24 --> Utf8 Class Initialized
INFO - 2020-03-23 17:07:24 --> URI Class Initialized
INFO - 2020-03-23 17:07:24 --> Router Class Initialized
INFO - 2020-03-23 17:07:24 --> Output Class Initialized
INFO - 2020-03-23 17:07:24 --> Security Class Initialized
DEBUG - 2020-03-23 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:07:24 --> Input Class Initialized
INFO - 2020-03-23 17:07:24 --> Language Class Initialized
INFO - 2020-03-23 17:07:24 --> Language Class Initialized
INFO - 2020-03-23 17:07:24 --> Config Class Initialized
INFO - 2020-03-23 17:07:24 --> Loader Class Initialized
INFO - 2020-03-23 17:07:24 --> Helper loaded: url_helper
INFO - 2020-03-23 17:07:24 --> Helper loaded: common_helper
INFO - 2020-03-23 17:07:24 --> Helper loaded: language_helper
INFO - 2020-03-23 17:07:24 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:07:24 --> Helper loaded: email_helper
INFO - 2020-03-23 17:07:24 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:07:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:07:24 --> Parser Class Initialized
INFO - 2020-03-23 17:07:24 --> User Agent Class Initialized
INFO - 2020-03-23 17:07:25 --> Model Class Initialized
INFO - 2020-03-23 17:07:25 --> Database Driver Class Initialized
INFO - 2020-03-23 17:07:25 --> Model Class Initialized
DEBUG - 2020-03-23 17:07:25 --> Template Class Initialized
INFO - 2020-03-23 17:07:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:07:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:07:25 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:07:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:07:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:07:25 --> Encryption Class Initialized
INFO - 2020-03-23 17:07:25 --> Controller Class Initialized
DEBUG - 2020-03-23 17:07:25 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:07:25 --> Model Class Initialized
DEBUG - 2020-03-23 17:07:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:07:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 17:07:59 --> Config Class Initialized
INFO - 2020-03-23 17:07:59 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:07:59 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:07:59 --> Utf8 Class Initialized
INFO - 2020-03-23 17:07:59 --> URI Class Initialized
INFO - 2020-03-23 17:07:59 --> Router Class Initialized
INFO - 2020-03-23 17:07:59 --> Output Class Initialized
INFO - 2020-03-23 17:07:59 --> Security Class Initialized
DEBUG - 2020-03-23 17:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:07:59 --> Input Class Initialized
INFO - 2020-03-23 17:07:59 --> Language Class Initialized
INFO - 2020-03-23 17:08:00 --> Language Class Initialized
INFO - 2020-03-23 17:08:00 --> Config Class Initialized
INFO - 2020-03-23 17:08:00 --> Loader Class Initialized
INFO - 2020-03-23 17:08:00 --> Helper loaded: url_helper
INFO - 2020-03-23 17:08:00 --> Helper loaded: common_helper
INFO - 2020-03-23 17:08:00 --> Helper loaded: language_helper
INFO - 2020-03-23 17:08:00 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:08:00 --> Helper loaded: email_helper
INFO - 2020-03-23 17:08:00 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:08:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:08:00 --> Parser Class Initialized
INFO - 2020-03-23 17:08:00 --> User Agent Class Initialized
INFO - 2020-03-23 17:08:00 --> Model Class Initialized
INFO - 2020-03-23 17:08:00 --> Database Driver Class Initialized
INFO - 2020-03-23 17:08:00 --> Model Class Initialized
DEBUG - 2020-03-23 17:08:00 --> Template Class Initialized
INFO - 2020-03-23 17:08:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:08:00 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:08:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:08:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:08:00 --> Encryption Class Initialized
INFO - 2020-03-23 17:08:00 --> Controller Class Initialized
DEBUG - 2020-03-23 17:08:00 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:08:00 --> Model Class Initialized
DEBUG - 2020-03-23 17:08:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:08:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
ERROR - 2020-03-23 17:08:00 --> Severity: Notice --> Undefined variable: exists_txnid D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\paytm.php 137
ERROR - 2020-03-23 17:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\paytm.php 137
INFO - 2020-03-23 17:08:00 --> Config Class Initialized
INFO - 2020-03-23 17:08:00 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:08:00 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:08:00 --> Utf8 Class Initialized
INFO - 2020-03-23 17:08:00 --> URI Class Initialized
INFO - 2020-03-23 17:08:00 --> Router Class Initialized
INFO - 2020-03-23 17:08:00 --> Output Class Initialized
INFO - 2020-03-23 17:08:00 --> Security Class Initialized
DEBUG - 2020-03-23 17:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:08:00 --> CSRF cookie sent
INFO - 2020-03-23 17:08:00 --> Input Class Initialized
INFO - 2020-03-23 17:08:00 --> Language Class Initialized
INFO - 2020-03-23 17:08:00 --> Language Class Initialized
INFO - 2020-03-23 17:08:00 --> Config Class Initialized
INFO - 2020-03-23 17:08:00 --> Loader Class Initialized
INFO - 2020-03-23 17:08:00 --> Helper loaded: url_helper
INFO - 2020-03-23 17:08:00 --> Helper loaded: common_helper
INFO - 2020-03-23 17:08:01 --> Helper loaded: language_helper
INFO - 2020-03-23 17:08:01 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:08:01 --> Helper loaded: email_helper
INFO - 2020-03-23 17:08:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:08:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:08:01 --> Parser Class Initialized
INFO - 2020-03-23 17:08:01 --> User Agent Class Initialized
INFO - 2020-03-23 17:08:01 --> Model Class Initialized
INFO - 2020-03-23 17:08:01 --> Database Driver Class Initialized
INFO - 2020-03-23 17:08:01 --> Model Class Initialized
DEBUG - 2020-03-23 17:08:01 --> Template Class Initialized
INFO - 2020-03-23 17:08:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:08:01 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:08:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:08:01 --> Encryption Class Initialized
INFO - 2020-03-23 17:08:01 --> Controller Class Initialized
DEBUG - 2020-03-23 17:08:01 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:08:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:08:01 --> Model Class Initialized
INFO - 2020-03-23 17:08:01 --> Config Class Initialized
INFO - 2020-03-23 17:08:01 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:08:01 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:08:01 --> Utf8 Class Initialized
INFO - 2020-03-23 17:08:01 --> URI Class Initialized
DEBUG - 2020-03-23 17:08:01 --> No URI present. Default controller set.
INFO - 2020-03-23 17:08:01 --> Router Class Initialized
INFO - 2020-03-23 17:08:01 --> Output Class Initialized
INFO - 2020-03-23 17:08:01 --> Security Class Initialized
DEBUG - 2020-03-23 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:08:01 --> CSRF cookie sent
INFO - 2020-03-23 17:08:01 --> Input Class Initialized
INFO - 2020-03-23 17:08:01 --> Language Class Initialized
INFO - 2020-03-23 17:08:01 --> Language Class Initialized
INFO - 2020-03-23 17:08:01 --> Config Class Initialized
INFO - 2020-03-23 17:08:01 --> Loader Class Initialized
INFO - 2020-03-23 17:08:01 --> Helper loaded: url_helper
INFO - 2020-03-23 17:08:01 --> Helper loaded: common_helper
INFO - 2020-03-23 17:08:01 --> Helper loaded: language_helper
INFO - 2020-03-23 17:08:01 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:08:01 --> Helper loaded: email_helper
INFO - 2020-03-23 17:08:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:08:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:08:01 --> Parser Class Initialized
INFO - 2020-03-23 17:08:01 --> User Agent Class Initialized
INFO - 2020-03-23 17:08:01 --> Model Class Initialized
INFO - 2020-03-23 17:08:01 --> Database Driver Class Initialized
INFO - 2020-03-23 17:08:01 --> Model Class Initialized
DEBUG - 2020-03-23 17:08:01 --> Template Class Initialized
INFO - 2020-03-23 17:08:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:08:01 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:08:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:08:01 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:08:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:08:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:08:01 --> Controller Class Initialized
DEBUG - 2020-03-23 17:08:01 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:08:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:08:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:08:01 --> Model Class Initialized
INFO - 2020-03-23 17:08:01 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:08:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:08:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:08:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:08:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:08:02 --> Final output sent to browser
DEBUG - 2020-03-23 17:08:02 --> Total execution time: 0.7108
INFO - 2020-03-23 17:08:13 --> Config Class Initialized
INFO - 2020-03-23 17:08:13 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:08:13 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:08:13 --> Utf8 Class Initialized
INFO - 2020-03-23 17:08:13 --> URI Class Initialized
INFO - 2020-03-23 17:08:13 --> Router Class Initialized
INFO - 2020-03-23 17:08:13 --> Output Class Initialized
INFO - 2020-03-23 17:08:13 --> Security Class Initialized
DEBUG - 2020-03-23 17:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:08:13 --> CSRF cookie sent
INFO - 2020-03-23 17:08:13 --> Input Class Initialized
INFO - 2020-03-23 17:08:13 --> Language Class Initialized
INFO - 2020-03-23 17:08:13 --> Language Class Initialized
INFO - 2020-03-23 17:08:13 --> Config Class Initialized
INFO - 2020-03-23 17:08:13 --> Loader Class Initialized
INFO - 2020-03-23 17:08:13 --> Helper loaded: url_helper
INFO - 2020-03-23 17:08:13 --> Helper loaded: common_helper
INFO - 2020-03-23 17:08:13 --> Helper loaded: language_helper
INFO - 2020-03-23 17:08:13 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:08:13 --> Helper loaded: email_helper
INFO - 2020-03-23 17:08:13 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:08:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:08:13 --> Parser Class Initialized
INFO - 2020-03-23 17:08:13 --> User Agent Class Initialized
INFO - 2020-03-23 17:08:13 --> Model Class Initialized
INFO - 2020-03-23 17:08:13 --> Database Driver Class Initialized
INFO - 2020-03-23 17:08:13 --> Model Class Initialized
DEBUG - 2020-03-23 17:08:13 --> Template Class Initialized
INFO - 2020-03-23 17:08:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:08:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:08:13 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:08:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:08:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:08:13 --> Encryption Class Initialized
INFO - 2020-03-23 17:08:13 --> Controller Class Initialized
DEBUG - 2020-03-23 17:08:13 --> order MX_Controller Initialized
INFO - 2020-03-23 17:08:13 --> Config Class Initialized
INFO - 2020-03-23 17:08:13 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:08:13 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:08:13 --> Utf8 Class Initialized
INFO - 2020-03-23 17:08:13 --> URI Class Initialized
DEBUG - 2020-03-23 17:08:13 --> No URI present. Default controller set.
INFO - 2020-03-23 17:08:13 --> Router Class Initialized
INFO - 2020-03-23 17:08:13 --> Output Class Initialized
INFO - 2020-03-23 17:08:13 --> Security Class Initialized
DEBUG - 2020-03-23 17:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:08:14 --> CSRF cookie sent
INFO - 2020-03-23 17:08:14 --> Input Class Initialized
INFO - 2020-03-23 17:08:14 --> Language Class Initialized
INFO - 2020-03-23 17:08:14 --> Language Class Initialized
INFO - 2020-03-23 17:08:14 --> Config Class Initialized
INFO - 2020-03-23 17:08:14 --> Loader Class Initialized
INFO - 2020-03-23 17:08:14 --> Helper loaded: url_helper
INFO - 2020-03-23 17:08:14 --> Helper loaded: common_helper
INFO - 2020-03-23 17:08:14 --> Helper loaded: language_helper
INFO - 2020-03-23 17:08:14 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:08:14 --> Helper loaded: email_helper
INFO - 2020-03-23 17:08:14 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:08:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:08:14 --> Parser Class Initialized
INFO - 2020-03-23 17:08:14 --> User Agent Class Initialized
INFO - 2020-03-23 17:08:14 --> Model Class Initialized
INFO - 2020-03-23 17:08:14 --> Database Driver Class Initialized
INFO - 2020-03-23 17:08:14 --> Model Class Initialized
DEBUG - 2020-03-23 17:08:14 --> Template Class Initialized
INFO - 2020-03-23 17:08:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:08:14 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:08:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:08:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:08:14 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:08:14 --> Controller Class Initialized
DEBUG - 2020-03-23 17:08:14 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:08:14 --> Model Class Initialized
INFO - 2020-03-23 17:08:14 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:08:14 --> Final output sent to browser
DEBUG - 2020-03-23 17:08:14 --> Total execution time: 0.7008
INFO - 2020-03-23 17:08:58 --> Config Class Initialized
INFO - 2020-03-23 17:08:58 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:08:58 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:08:58 --> Utf8 Class Initialized
INFO - 2020-03-23 17:08:58 --> URI Class Initialized
DEBUG - 2020-03-23 17:08:58 --> No URI present. Default controller set.
INFO - 2020-03-23 17:08:58 --> Router Class Initialized
INFO - 2020-03-23 17:08:58 --> Output Class Initialized
INFO - 2020-03-23 17:08:58 --> Security Class Initialized
DEBUG - 2020-03-23 17:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:08:58 --> CSRF cookie sent
INFO - 2020-03-23 17:08:58 --> Input Class Initialized
INFO - 2020-03-23 17:08:58 --> Language Class Initialized
INFO - 2020-03-23 17:08:58 --> Language Class Initialized
INFO - 2020-03-23 17:08:58 --> Config Class Initialized
INFO - 2020-03-23 17:08:58 --> Loader Class Initialized
INFO - 2020-03-23 17:08:58 --> Helper loaded: url_helper
INFO - 2020-03-23 17:08:58 --> Helper loaded: common_helper
INFO - 2020-03-23 17:08:58 --> Helper loaded: language_helper
INFO - 2020-03-23 17:08:58 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:08:58 --> Helper loaded: email_helper
INFO - 2020-03-23 17:08:58 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:08:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:08:58 --> Parser Class Initialized
INFO - 2020-03-23 17:08:58 --> User Agent Class Initialized
INFO - 2020-03-23 17:08:58 --> Model Class Initialized
INFO - 2020-03-23 17:08:58 --> Database Driver Class Initialized
INFO - 2020-03-23 17:08:58 --> Model Class Initialized
DEBUG - 2020-03-23 17:08:58 --> Template Class Initialized
INFO - 2020-03-23 17:08:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:08:58 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:08:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:08:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:08:58 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:08:58 --> Controller Class Initialized
DEBUG - 2020-03-23 17:08:58 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:08:58 --> Model Class Initialized
INFO - 2020-03-23 17:08:58 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:08:58 --> Final output sent to browser
DEBUG - 2020-03-23 17:08:58 --> Total execution time: 0.8593
INFO - 2020-03-23 17:10:52 --> Config Class Initialized
INFO - 2020-03-23 17:10:52 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:10:52 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:10:52 --> Utf8 Class Initialized
INFO - 2020-03-23 17:10:52 --> URI Class Initialized
INFO - 2020-03-23 17:10:52 --> Router Class Initialized
INFO - 2020-03-23 17:10:52 --> Output Class Initialized
INFO - 2020-03-23 17:10:52 --> Security Class Initialized
DEBUG - 2020-03-23 17:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:10:52 --> CSRF cookie sent
INFO - 2020-03-23 17:10:52 --> Input Class Initialized
INFO - 2020-03-23 17:10:52 --> Language Class Initialized
INFO - 2020-03-23 17:10:52 --> Language Class Initialized
INFO - 2020-03-23 17:10:52 --> Config Class Initialized
INFO - 2020-03-23 17:10:52 --> Loader Class Initialized
INFO - 2020-03-23 17:10:52 --> Helper loaded: url_helper
INFO - 2020-03-23 17:10:52 --> Helper loaded: common_helper
INFO - 2020-03-23 17:10:52 --> Helper loaded: language_helper
INFO - 2020-03-23 17:10:52 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:10:52 --> Helper loaded: email_helper
INFO - 2020-03-23 17:10:52 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:10:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:10:52 --> Parser Class Initialized
INFO - 2020-03-23 17:10:52 --> User Agent Class Initialized
INFO - 2020-03-23 17:10:53 --> Model Class Initialized
INFO - 2020-03-23 17:10:53 --> Database Driver Class Initialized
INFO - 2020-03-23 17:10:53 --> Model Class Initialized
DEBUG - 2020-03-23 17:10:53 --> Template Class Initialized
INFO - 2020-03-23 17:10:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:10:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:10:53 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:10:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:10:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:10:53 --> Encryption Class Initialized
INFO - 2020-03-23 17:10:53 --> Controller Class Initialized
DEBUG - 2020-03-23 17:10:53 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 17:10:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 17:10:53 --> Model Class Initialized
DEBUG - 2020-03-23 17:10:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:10:53 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:10:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-23 17:10:53 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:10:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:10:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-23 17:10:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:10:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:10:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-23 17:10:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:10:53 --> Final output sent to browser
DEBUG - 2020-03-23 17:10:53 --> Total execution time: 0.6164
INFO - 2020-03-23 17:10:56 --> Config Class Initialized
INFO - 2020-03-23 17:10:56 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:10:56 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:10:56 --> Utf8 Class Initialized
INFO - 2020-03-23 17:10:56 --> URI Class Initialized
INFO - 2020-03-23 17:10:56 --> Router Class Initialized
INFO - 2020-03-23 17:10:56 --> Output Class Initialized
INFO - 2020-03-23 17:10:56 --> Security Class Initialized
DEBUG - 2020-03-23 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:10:56 --> CSRF cookie sent
INFO - 2020-03-23 17:10:56 --> CSRF token verified
INFO - 2020-03-23 17:10:56 --> Input Class Initialized
INFO - 2020-03-23 17:10:56 --> Language Class Initialized
INFO - 2020-03-23 17:10:56 --> Language Class Initialized
INFO - 2020-03-23 17:10:56 --> Config Class Initialized
INFO - 2020-03-23 17:10:56 --> Loader Class Initialized
INFO - 2020-03-23 17:10:56 --> Helper loaded: url_helper
INFO - 2020-03-23 17:10:56 --> Helper loaded: common_helper
INFO - 2020-03-23 17:10:56 --> Helper loaded: language_helper
INFO - 2020-03-23 17:10:56 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:10:56 --> Helper loaded: email_helper
INFO - 2020-03-23 17:10:56 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:10:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:10:56 --> Parser Class Initialized
INFO - 2020-03-23 17:10:56 --> User Agent Class Initialized
INFO - 2020-03-23 17:10:56 --> Model Class Initialized
INFO - 2020-03-23 17:10:56 --> Database Driver Class Initialized
INFO - 2020-03-23 17:10:56 --> Model Class Initialized
DEBUG - 2020-03-23 17:10:56 --> Template Class Initialized
INFO - 2020-03-23 17:10:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:10:56 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:10:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:10:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:10:56 --> Encryption Class Initialized
INFO - 2020-03-23 17:10:56 --> Controller Class Initialized
DEBUG - 2020-03-23 17:10:56 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 17:10:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 17:10:56 --> Model Class Initialized
INFO - 2020-03-23 17:11:01 --> Config Class Initialized
INFO - 2020-03-23 17:11:01 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:11:01 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:11:01 --> Utf8 Class Initialized
INFO - 2020-03-23 17:11:01 --> URI Class Initialized
INFO - 2020-03-23 17:11:01 --> Router Class Initialized
INFO - 2020-03-23 17:11:01 --> Output Class Initialized
INFO - 2020-03-23 17:11:01 --> Security Class Initialized
DEBUG - 2020-03-23 17:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:11:01 --> CSRF cookie sent
INFO - 2020-03-23 17:11:01 --> Input Class Initialized
INFO - 2020-03-23 17:11:01 --> Language Class Initialized
INFO - 2020-03-23 17:11:01 --> Language Class Initialized
INFO - 2020-03-23 17:11:01 --> Config Class Initialized
INFO - 2020-03-23 17:11:01 --> Loader Class Initialized
INFO - 2020-03-23 17:11:01 --> Helper loaded: url_helper
INFO - 2020-03-23 17:11:01 --> Helper loaded: common_helper
INFO - 2020-03-23 17:11:01 --> Helper loaded: language_helper
INFO - 2020-03-23 17:11:01 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:11:01 --> Helper loaded: email_helper
INFO - 2020-03-23 17:11:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:11:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:11:01 --> Parser Class Initialized
INFO - 2020-03-23 17:11:01 --> User Agent Class Initialized
INFO - 2020-03-23 17:11:01 --> Model Class Initialized
INFO - 2020-03-23 17:11:01 --> Database Driver Class Initialized
INFO - 2020-03-23 17:11:01 --> Model Class Initialized
DEBUG - 2020-03-23 17:11:01 --> Template Class Initialized
INFO - 2020-03-23 17:11:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:11:01 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:11:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:11:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:11:01 --> Encryption Class Initialized
INFO - 2020-03-23 17:11:01 --> Controller Class Initialized
DEBUG - 2020-03-23 17:11:01 --> statistics MX_Controller Initialized
DEBUG - 2020-03-23 17:11:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-23 17:11:01 --> Model Class Initialized
ERROR - 2020-03-23 17:11:01 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:01 --> Could not find the language line "Pending"
INFO - 2020-03-23 17:11:01 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:11:01 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 17:11:01 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 17:11:02 --> Could not find the language line "Pending"
DEBUG - 2020-03-23 17:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-23 17:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:11:02 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:11:02 --> Model Class Initialized
DEBUG - 2020-03-23 17:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:11:02 --> Model Class Initialized
DEBUG - 2020-03-23 17:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 17:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 17:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 17:11:02 --> Final output sent to browser
DEBUG - 2020-03-23 17:11:02 --> Total execution time: 0.8788
INFO - 2020-03-23 17:11:06 --> Config Class Initialized
INFO - 2020-03-23 17:11:06 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:11:06 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:11:06 --> Utf8 Class Initialized
INFO - 2020-03-23 17:11:06 --> URI Class Initialized
INFO - 2020-03-23 17:11:06 --> Router Class Initialized
INFO - 2020-03-23 17:11:06 --> Output Class Initialized
INFO - 2020-03-23 17:11:06 --> Security Class Initialized
DEBUG - 2020-03-23 17:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:11:06 --> CSRF cookie sent
INFO - 2020-03-23 17:11:06 --> Input Class Initialized
INFO - 2020-03-23 17:11:06 --> Language Class Initialized
INFO - 2020-03-23 17:11:06 --> Language Class Initialized
INFO - 2020-03-23 17:11:06 --> Config Class Initialized
INFO - 2020-03-23 17:11:06 --> Loader Class Initialized
INFO - 2020-03-23 17:11:06 --> Helper loaded: url_helper
INFO - 2020-03-23 17:11:06 --> Helper loaded: common_helper
INFO - 2020-03-23 17:11:06 --> Helper loaded: language_helper
INFO - 2020-03-23 17:11:06 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:11:06 --> Helper loaded: email_helper
INFO - 2020-03-23 17:11:06 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:11:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:11:06 --> Parser Class Initialized
INFO - 2020-03-23 17:11:06 --> User Agent Class Initialized
INFO - 2020-03-23 17:11:06 --> Model Class Initialized
INFO - 2020-03-23 17:11:06 --> Database Driver Class Initialized
INFO - 2020-03-23 17:11:06 --> Model Class Initialized
DEBUG - 2020-03-23 17:11:06 --> Template Class Initialized
INFO - 2020-03-23 17:11:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:11:06 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:11:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:11:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:11:06 --> Encryption Class Initialized
INFO - 2020-03-23 17:11:06 --> Controller Class Initialized
DEBUG - 2020-03-23 17:11:06 --> transactions MX_Controller Initialized
DEBUG - 2020-03-23 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-23 17:11:06 --> Model Class Initialized
ERROR - 2020-03-23 17:11:06 --> Could not find the language line "order_id"
INFO - 2020-03-23 17:11:06 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-23 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:11:06 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:11:06 --> Model Class Initialized
DEBUG - 2020-03-23 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:11:06 --> Model Class Initialized
DEBUG - 2020-03-23 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 17:11:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 17:11:06 --> Final output sent to browser
DEBUG - 2020-03-23 17:11:06 --> Total execution time: 0.8150
INFO - 2020-03-23 17:11:37 --> Config Class Initialized
INFO - 2020-03-23 17:11:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:11:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:11:37 --> Utf8 Class Initialized
INFO - 2020-03-23 17:11:37 --> URI Class Initialized
INFO - 2020-03-23 17:11:37 --> Router Class Initialized
INFO - 2020-03-23 17:11:37 --> Output Class Initialized
INFO - 2020-03-23 17:11:37 --> Security Class Initialized
DEBUG - 2020-03-23 17:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:11:37 --> CSRF cookie sent
INFO - 2020-03-23 17:11:37 --> Input Class Initialized
INFO - 2020-03-23 17:11:37 --> Language Class Initialized
INFO - 2020-03-23 17:11:37 --> Language Class Initialized
INFO - 2020-03-23 17:11:37 --> Config Class Initialized
INFO - 2020-03-23 17:11:37 --> Loader Class Initialized
INFO - 2020-03-23 17:11:37 --> Helper loaded: url_helper
INFO - 2020-03-23 17:11:37 --> Helper loaded: common_helper
INFO - 2020-03-23 17:11:37 --> Helper loaded: language_helper
INFO - 2020-03-23 17:11:37 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:11:37 --> Helper loaded: email_helper
INFO - 2020-03-23 17:11:37 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:11:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:11:37 --> Parser Class Initialized
INFO - 2020-03-23 17:11:37 --> User Agent Class Initialized
INFO - 2020-03-23 17:11:37 --> Model Class Initialized
INFO - 2020-03-23 17:11:37 --> Database Driver Class Initialized
INFO - 2020-03-23 17:11:37 --> Model Class Initialized
DEBUG - 2020-03-23 17:11:37 --> Template Class Initialized
INFO - 2020-03-23 17:11:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:11:37 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:11:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:11:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:11:37 --> Encryption Class Initialized
INFO - 2020-03-23 17:11:37 --> Controller Class Initialized
DEBUG - 2020-03-23 17:11:37 --> order MX_Controller Initialized
DEBUG - 2020-03-23 17:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2020-03-23 17:11:37 --> Model Class Initialized
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "order_id"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "order_basic_details"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "order_id"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "order_basic_details"
INFO - 2020-03-23 17:11:37 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:37 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:38 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:38 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:38 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:38 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:38 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:38 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:11:38 --> Could not find the language line "Awaiting"
ERROR - 2020-03-23 17:11:38 --> Could not find the language line "Pending"
DEBUG - 2020-03-23 17:11:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2020-03-23 17:11:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:11:38 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:11:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:11:38 --> Model Class Initialized
DEBUG - 2020-03-23 17:11:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:11:38 --> Model Class Initialized
DEBUG - 2020-03-23 17:11:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 17:11:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 17:11:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 17:11:38 --> Final output sent to browser
DEBUG - 2020-03-23 17:11:38 --> Total execution time: 1.2724
INFO - 2020-03-23 17:13:00 --> Config Class Initialized
INFO - 2020-03-23 17:13:00 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:13:00 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:13:00 --> Utf8 Class Initialized
INFO - 2020-03-23 17:13:00 --> URI Class Initialized
DEBUG - 2020-03-23 17:13:00 --> No URI present. Default controller set.
INFO - 2020-03-23 17:13:00 --> Router Class Initialized
INFO - 2020-03-23 17:13:00 --> Output Class Initialized
INFO - 2020-03-23 17:13:00 --> Security Class Initialized
DEBUG - 2020-03-23 17:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:13:01 --> CSRF cookie sent
INFO - 2020-03-23 17:13:01 --> Input Class Initialized
INFO - 2020-03-23 17:13:01 --> Language Class Initialized
INFO - 2020-03-23 17:13:01 --> Language Class Initialized
INFO - 2020-03-23 17:13:01 --> Config Class Initialized
INFO - 2020-03-23 17:13:01 --> Loader Class Initialized
INFO - 2020-03-23 17:13:01 --> Helper loaded: url_helper
INFO - 2020-03-23 17:13:01 --> Helper loaded: common_helper
INFO - 2020-03-23 17:13:01 --> Helper loaded: language_helper
INFO - 2020-03-23 17:13:01 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:13:01 --> Helper loaded: email_helper
INFO - 2020-03-23 17:13:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:13:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:13:01 --> Parser Class Initialized
INFO - 2020-03-23 17:13:01 --> User Agent Class Initialized
INFO - 2020-03-23 17:13:01 --> Model Class Initialized
INFO - 2020-03-23 17:13:01 --> Database Driver Class Initialized
INFO - 2020-03-23 17:13:01 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:01 --> Template Class Initialized
INFO - 2020-03-23 17:13:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:13:01 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:13:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:13:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:13:01 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:13:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:13:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:13:01 --> Controller Class Initialized
DEBUG - 2020-03-23 17:13:01 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:13:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:13:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:13:01 --> Model Class Initialized
INFO - 2020-03-23 17:13:01 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:13:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:13:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:13:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:13:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:13:01 --> Final output sent to browser
DEBUG - 2020-03-23 17:13:01 --> Total execution time: 0.8602
INFO - 2020-03-23 17:13:03 --> Config Class Initialized
INFO - 2020-03-23 17:13:03 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:13:03 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:13:03 --> Utf8 Class Initialized
INFO - 2020-03-23 17:13:03 --> URI Class Initialized
INFO - 2020-03-23 17:13:03 --> Router Class Initialized
INFO - 2020-03-23 17:13:03 --> Output Class Initialized
INFO - 2020-03-23 17:13:03 --> Security Class Initialized
DEBUG - 2020-03-23 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:13:04 --> CSRF cookie sent
INFO - 2020-03-23 17:13:04 --> Input Class Initialized
INFO - 2020-03-23 17:13:04 --> Language Class Initialized
INFO - 2020-03-23 17:13:04 --> Language Class Initialized
INFO - 2020-03-23 17:13:04 --> Config Class Initialized
INFO - 2020-03-23 17:13:04 --> Loader Class Initialized
INFO - 2020-03-23 17:13:04 --> Helper loaded: url_helper
INFO - 2020-03-23 17:13:04 --> Helper loaded: common_helper
INFO - 2020-03-23 17:13:04 --> Helper loaded: language_helper
INFO - 2020-03-23 17:13:04 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:13:04 --> Helper loaded: email_helper
INFO - 2020-03-23 17:13:04 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:13:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:13:04 --> Parser Class Initialized
INFO - 2020-03-23 17:13:04 --> User Agent Class Initialized
INFO - 2020-03-23 17:13:04 --> Model Class Initialized
INFO - 2020-03-23 17:13:04 --> Database Driver Class Initialized
INFO - 2020-03-23 17:13:04 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:04 --> Template Class Initialized
INFO - 2020-03-23 17:13:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:13:04 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:13:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:13:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:13:04 --> Encryption Class Initialized
INFO - 2020-03-23 17:13:04 --> Controller Class Initialized
DEBUG - 2020-03-23 17:13:04 --> package MX_Controller Initialized
DEBUG - 2020-03-23 17:13:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-23 17:13:04 --> Model Class Initialized
INFO - 2020-03-23 17:13:04 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:13:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:13:04 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:13:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:13:04 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:13:04 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-23 17:13:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-23 17:13:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:13:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:13:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:13:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:13:05 --> Final output sent to browser
DEBUG - 2020-03-23 17:13:05 --> Total execution time: 1.3733
INFO - 2020-03-23 17:13:07 --> Config Class Initialized
INFO - 2020-03-23 17:13:08 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:13:08 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:13:08 --> Utf8 Class Initialized
INFO - 2020-03-23 17:13:08 --> URI Class Initialized
INFO - 2020-03-23 17:13:08 --> Router Class Initialized
INFO - 2020-03-23 17:13:08 --> Output Class Initialized
INFO - 2020-03-23 17:13:08 --> Security Class Initialized
DEBUG - 2020-03-23 17:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:13:08 --> CSRF cookie sent
INFO - 2020-03-23 17:13:08 --> CSRF token verified
INFO - 2020-03-23 17:13:08 --> Input Class Initialized
INFO - 2020-03-23 17:13:08 --> Language Class Initialized
INFO - 2020-03-23 17:13:08 --> Language Class Initialized
INFO - 2020-03-23 17:13:08 --> Config Class Initialized
INFO - 2020-03-23 17:13:08 --> Loader Class Initialized
INFO - 2020-03-23 17:13:08 --> Helper loaded: url_helper
INFO - 2020-03-23 17:13:08 --> Helper loaded: common_helper
INFO - 2020-03-23 17:13:08 --> Helper loaded: language_helper
INFO - 2020-03-23 17:13:08 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:13:08 --> Helper loaded: email_helper
INFO - 2020-03-23 17:13:08 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:13:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:13:08 --> Parser Class Initialized
INFO - 2020-03-23 17:13:08 --> User Agent Class Initialized
INFO - 2020-03-23 17:13:08 --> Model Class Initialized
INFO - 2020-03-23 17:13:08 --> Database Driver Class Initialized
INFO - 2020-03-23 17:13:08 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:08 --> Template Class Initialized
INFO - 2020-03-23 17:13:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:13:08 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:13:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:13:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:13:08 --> Encryption Class Initialized
INFO - 2020-03-23 17:13:08 --> Controller Class Initialized
DEBUG - 2020-03-23 17:13:08 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:13:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:13:08 --> Model Class Initialized
INFO - 2020-03-23 17:13:08 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:13:08 --> Could not find the language line "shopier"
DEBUG - 2020-03-23 17:13:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-23 17:13:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:13:08 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:13:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:13:08 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:13:08 --> Model Class Initialized
ERROR - 2020-03-23 17:13:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:13:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:13:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:13:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:13:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:13:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:13:09 --> Final output sent to browser
DEBUG - 2020-03-23 17:13:09 --> Total execution time: 1.3433
INFO - 2020-03-23 17:13:18 --> Config Class Initialized
INFO - 2020-03-23 17:13:18 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:13:18 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:13:18 --> Utf8 Class Initialized
INFO - 2020-03-23 17:13:18 --> URI Class Initialized
INFO - 2020-03-23 17:13:18 --> Router Class Initialized
INFO - 2020-03-23 17:13:18 --> Output Class Initialized
INFO - 2020-03-23 17:13:18 --> Security Class Initialized
DEBUG - 2020-03-23 17:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:13:18 --> CSRF cookie sent
INFO - 2020-03-23 17:13:18 --> CSRF token verified
INFO - 2020-03-23 17:13:18 --> Input Class Initialized
INFO - 2020-03-23 17:13:18 --> Language Class Initialized
INFO - 2020-03-23 17:13:18 --> Language Class Initialized
INFO - 2020-03-23 17:13:18 --> Config Class Initialized
INFO - 2020-03-23 17:13:19 --> Loader Class Initialized
INFO - 2020-03-23 17:13:19 --> Helper loaded: url_helper
INFO - 2020-03-23 17:13:19 --> Helper loaded: common_helper
INFO - 2020-03-23 17:13:19 --> Helper loaded: language_helper
INFO - 2020-03-23 17:13:19 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:13:19 --> Helper loaded: email_helper
INFO - 2020-03-23 17:13:19 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:13:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:13:19 --> Parser Class Initialized
INFO - 2020-03-23 17:13:19 --> User Agent Class Initialized
INFO - 2020-03-23 17:13:19 --> Model Class Initialized
INFO - 2020-03-23 17:13:19 --> Database Driver Class Initialized
INFO - 2020-03-23 17:13:19 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:19 --> Template Class Initialized
INFO - 2020-03-23 17:13:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:13:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:13:19 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:13:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:13:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:13:19 --> Encryption Class Initialized
INFO - 2020-03-23 17:13:19 --> Controller Class Initialized
DEBUG - 2020-03-23 17:13:19 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:13:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:13:19 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:19 --> paytm MX_Controller Initialized
DEBUG - 2020-03-23 17:13:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:13:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2020-03-23 17:13:19 --> orders MX_Controller Initialized
DEBUG - 2020-03-23 17:13:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2020-03-23 17:13:19 --> Final output sent to browser
DEBUG - 2020-03-23 17:13:19 --> Total execution time: 0.7686
INFO - 2020-03-23 17:13:36 --> Config Class Initialized
INFO - 2020-03-23 17:13:36 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:13:36 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:13:36 --> Utf8 Class Initialized
INFO - 2020-03-23 17:13:36 --> URI Class Initialized
INFO - 2020-03-23 17:13:36 --> Router Class Initialized
INFO - 2020-03-23 17:13:36 --> Output Class Initialized
INFO - 2020-03-23 17:13:36 --> Security Class Initialized
DEBUG - 2020-03-23 17:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:13:36 --> Input Class Initialized
INFO - 2020-03-23 17:13:36 --> Language Class Initialized
INFO - 2020-03-23 17:13:36 --> Language Class Initialized
INFO - 2020-03-23 17:13:36 --> Config Class Initialized
INFO - 2020-03-23 17:13:36 --> Loader Class Initialized
INFO - 2020-03-23 17:13:36 --> Helper loaded: url_helper
INFO - 2020-03-23 17:13:36 --> Helper loaded: common_helper
INFO - 2020-03-23 17:13:36 --> Helper loaded: language_helper
INFO - 2020-03-23 17:13:36 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:13:36 --> Helper loaded: email_helper
INFO - 2020-03-23 17:13:36 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:13:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:13:36 --> Parser Class Initialized
INFO - 2020-03-23 17:13:36 --> User Agent Class Initialized
INFO - 2020-03-23 17:13:36 --> Model Class Initialized
INFO - 2020-03-23 17:13:36 --> Database Driver Class Initialized
INFO - 2020-03-23 17:13:36 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:36 --> Template Class Initialized
INFO - 2020-03-23 17:13:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:13:36 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:13:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:13:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:13:36 --> Encryption Class Initialized
INFO - 2020-03-23 17:13:36 --> Controller Class Initialized
DEBUG - 2020-03-23 17:13:36 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:13:36 --> Model Class Initialized
DEBUG - 2020-03-23 17:13:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:13:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 17:14:10 --> Config Class Initialized
INFO - 2020-03-23 17:14:10 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:14:10 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:14:10 --> Utf8 Class Initialized
INFO - 2020-03-23 17:14:10 --> URI Class Initialized
INFO - 2020-03-23 17:14:10 --> Router Class Initialized
INFO - 2020-03-23 17:14:10 --> Output Class Initialized
INFO - 2020-03-23 17:14:10 --> Security Class Initialized
DEBUG - 2020-03-23 17:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:14:10 --> CSRF cookie sent
INFO - 2020-03-23 17:14:10 --> Input Class Initialized
INFO - 2020-03-23 17:14:10 --> Language Class Initialized
INFO - 2020-03-23 17:14:10 --> Language Class Initialized
INFO - 2020-03-23 17:14:10 --> Config Class Initialized
INFO - 2020-03-23 17:14:10 --> Loader Class Initialized
INFO - 2020-03-23 17:14:10 --> Helper loaded: url_helper
INFO - 2020-03-23 17:14:10 --> Helper loaded: common_helper
INFO - 2020-03-23 17:14:10 --> Helper loaded: language_helper
INFO - 2020-03-23 17:14:10 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:14:10 --> Helper loaded: email_helper
INFO - 2020-03-23 17:14:10 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:14:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:14:10 --> Parser Class Initialized
INFO - 2020-03-23 17:14:10 --> User Agent Class Initialized
INFO - 2020-03-23 17:14:10 --> Model Class Initialized
INFO - 2020-03-23 17:14:10 --> Database Driver Class Initialized
INFO - 2020-03-23 17:14:10 --> Model Class Initialized
DEBUG - 2020-03-23 17:14:10 --> Template Class Initialized
INFO - 2020-03-23 17:14:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:14:10 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:14:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:14:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:14:11 --> Encryption Class Initialized
INFO - 2020-03-23 17:14:11 --> Controller Class Initialized
DEBUG - 2020-03-23 17:14:11 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:14:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:14:11 --> Model Class Initialized
INFO - 2020-03-23 17:14:11 --> Config Class Initialized
INFO - 2020-03-23 17:14:11 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:14:11 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:14:11 --> Utf8 Class Initialized
INFO - 2020-03-23 17:14:11 --> URI Class Initialized
DEBUG - 2020-03-23 17:14:11 --> No URI present. Default controller set.
INFO - 2020-03-23 17:14:11 --> Router Class Initialized
INFO - 2020-03-23 17:14:11 --> Output Class Initialized
INFO - 2020-03-23 17:14:11 --> Security Class Initialized
DEBUG - 2020-03-23 17:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:14:11 --> CSRF cookie sent
INFO - 2020-03-23 17:14:11 --> Input Class Initialized
INFO - 2020-03-23 17:14:11 --> Language Class Initialized
INFO - 2020-03-23 17:14:11 --> Language Class Initialized
INFO - 2020-03-23 17:14:11 --> Config Class Initialized
INFO - 2020-03-23 17:14:11 --> Loader Class Initialized
INFO - 2020-03-23 17:14:11 --> Helper loaded: url_helper
INFO - 2020-03-23 17:14:11 --> Helper loaded: common_helper
INFO - 2020-03-23 17:14:11 --> Helper loaded: language_helper
INFO - 2020-03-23 17:14:11 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:14:11 --> Helper loaded: email_helper
INFO - 2020-03-23 17:14:11 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:14:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:14:11 --> Parser Class Initialized
INFO - 2020-03-23 17:14:11 --> User Agent Class Initialized
INFO - 2020-03-23 17:14:11 --> Model Class Initialized
INFO - 2020-03-23 17:14:11 --> Database Driver Class Initialized
INFO - 2020-03-23 17:14:11 --> Model Class Initialized
DEBUG - 2020-03-23 17:14:11 --> Template Class Initialized
INFO - 2020-03-23 17:14:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:14:11 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:14:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:14:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:14:11 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:14:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:14:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:14:11 --> Controller Class Initialized
DEBUG - 2020-03-23 17:14:11 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:14:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:14:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:14:11 --> Model Class Initialized
INFO - 2020-03-23 17:14:11 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:14:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:14:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:14:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:14:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:14:11 --> Final output sent to browser
DEBUG - 2020-03-23 17:14:11 --> Total execution time: 0.7550
INFO - 2020-03-23 17:14:28 --> Config Class Initialized
INFO - 2020-03-23 17:14:28 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:14:28 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:14:28 --> Utf8 Class Initialized
INFO - 2020-03-23 17:14:28 --> URI Class Initialized
INFO - 2020-03-23 17:14:28 --> Router Class Initialized
INFO - 2020-03-23 17:14:28 --> Output Class Initialized
INFO - 2020-03-23 17:14:28 --> Security Class Initialized
DEBUG - 2020-03-23 17:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:14:28 --> CSRF cookie sent
INFO - 2020-03-23 17:14:28 --> Input Class Initialized
INFO - 2020-03-23 17:14:28 --> Language Class Initialized
INFO - 2020-03-23 17:14:28 --> Language Class Initialized
INFO - 2020-03-23 17:14:28 --> Config Class Initialized
INFO - 2020-03-23 17:14:28 --> Loader Class Initialized
INFO - 2020-03-23 17:14:28 --> Helper loaded: url_helper
INFO - 2020-03-23 17:14:28 --> Helper loaded: common_helper
INFO - 2020-03-23 17:14:28 --> Helper loaded: language_helper
INFO - 2020-03-23 17:14:28 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:14:28 --> Helper loaded: email_helper
INFO - 2020-03-23 17:14:28 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:14:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:14:28 --> Parser Class Initialized
INFO - 2020-03-23 17:14:28 --> User Agent Class Initialized
INFO - 2020-03-23 17:14:28 --> Model Class Initialized
INFO - 2020-03-23 17:14:28 --> Database Driver Class Initialized
INFO - 2020-03-23 17:14:28 --> Model Class Initialized
DEBUG - 2020-03-23 17:14:28 --> Template Class Initialized
INFO - 2020-03-23 17:14:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:14:28 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:14:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:14:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:14:28 --> Encryption Class Initialized
INFO - 2020-03-23 17:14:28 --> Controller Class Initialized
DEBUG - 2020-03-23 17:14:28 --> package MX_Controller Initialized
DEBUG - 2020-03-23 17:14:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-23 17:14:28 --> Model Class Initialized
INFO - 2020-03-23 17:14:28 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:14:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:14:28 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:14:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:14:28 --> Model Class Initialized
DEBUG - 2020-03-23 17:14:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:14:28 --> Model Class Initialized
DEBUG - 2020-03-23 17:14:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-23 17:14:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:14:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:14:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:14:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:14:29 --> Final output sent to browser
DEBUG - 2020-03-23 17:14:29 --> Total execution time: 1.1045
INFO - 2020-03-23 17:15:46 --> Config Class Initialized
INFO - 2020-03-23 17:15:46 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:15:46 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:15:46 --> Utf8 Class Initialized
INFO - 2020-03-23 17:15:46 --> URI Class Initialized
INFO - 2020-03-23 17:15:46 --> Router Class Initialized
INFO - 2020-03-23 17:15:46 --> Output Class Initialized
INFO - 2020-03-23 17:15:46 --> Security Class Initialized
DEBUG - 2020-03-23 17:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:15:46 --> CSRF cookie sent
INFO - 2020-03-23 17:15:46 --> Input Class Initialized
INFO - 2020-03-23 17:15:46 --> Language Class Initialized
INFO - 2020-03-23 17:15:46 --> Language Class Initialized
INFO - 2020-03-23 17:15:46 --> Config Class Initialized
INFO - 2020-03-23 17:15:46 --> Loader Class Initialized
INFO - 2020-03-23 17:15:46 --> Helper loaded: url_helper
INFO - 2020-03-23 17:15:46 --> Helper loaded: common_helper
INFO - 2020-03-23 17:15:46 --> Helper loaded: language_helper
INFO - 2020-03-23 17:15:46 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:15:46 --> Helper loaded: email_helper
INFO - 2020-03-23 17:15:46 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:15:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:15:47 --> Parser Class Initialized
INFO - 2020-03-23 17:15:47 --> User Agent Class Initialized
INFO - 2020-03-23 17:15:47 --> Model Class Initialized
INFO - 2020-03-23 17:15:47 --> Database Driver Class Initialized
INFO - 2020-03-23 17:15:47 --> Model Class Initialized
DEBUG - 2020-03-23 17:15:47 --> Template Class Initialized
INFO - 2020-03-23 17:15:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:15:47 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:15:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:15:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:15:47 --> Encryption Class Initialized
INFO - 2020-03-23 17:15:47 --> Controller Class Initialized
DEBUG - 2020-03-23 17:15:47 --> package MX_Controller Initialized
DEBUG - 2020-03-23 17:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-23 17:15:47 --> Model Class Initialized
INFO - 2020-03-23 17:15:47 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:15:47 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:15:47 --> Model Class Initialized
DEBUG - 2020-03-23 17:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:15:47 --> Model Class Initialized
DEBUG - 2020-03-23 17:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-23 17:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:15:47 --> Final output sent to browser
DEBUG - 2020-03-23 17:15:47 --> Total execution time: 1.1570
INFO - 2020-03-23 17:15:51 --> Config Class Initialized
INFO - 2020-03-23 17:15:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:15:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:15:51 --> Utf8 Class Initialized
INFO - 2020-03-23 17:15:51 --> URI Class Initialized
INFO - 2020-03-23 17:15:51 --> Router Class Initialized
INFO - 2020-03-23 17:15:51 --> Output Class Initialized
INFO - 2020-03-23 17:15:51 --> Security Class Initialized
DEBUG - 2020-03-23 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:15:51 --> CSRF cookie sent
INFO - 2020-03-23 17:15:51 --> CSRF token verified
INFO - 2020-03-23 17:15:51 --> Input Class Initialized
INFO - 2020-03-23 17:15:51 --> Language Class Initialized
INFO - 2020-03-23 17:15:51 --> Language Class Initialized
INFO - 2020-03-23 17:15:51 --> Config Class Initialized
INFO - 2020-03-23 17:15:51 --> Loader Class Initialized
INFO - 2020-03-23 17:15:51 --> Helper loaded: url_helper
INFO - 2020-03-23 17:15:51 --> Helper loaded: common_helper
INFO - 2020-03-23 17:15:51 --> Helper loaded: language_helper
INFO - 2020-03-23 17:15:51 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:15:51 --> Helper loaded: email_helper
INFO - 2020-03-23 17:15:51 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:15:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:15:51 --> Parser Class Initialized
INFO - 2020-03-23 17:15:51 --> User Agent Class Initialized
INFO - 2020-03-23 17:15:51 --> Model Class Initialized
INFO - 2020-03-23 17:15:51 --> Database Driver Class Initialized
INFO - 2020-03-23 17:15:51 --> Model Class Initialized
DEBUG - 2020-03-23 17:15:51 --> Template Class Initialized
INFO - 2020-03-23 17:15:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:15:51 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:15:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:15:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:15:51 --> Encryption Class Initialized
INFO - 2020-03-23 17:15:51 --> Controller Class Initialized
DEBUG - 2020-03-23 17:15:51 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:15:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:15:51 --> Model Class Initialized
INFO - 2020-03-23 17:15:51 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:15:51 --> Could not find the language line "shopier"
DEBUG - 2020-03-23 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-23 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:15:52 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:15:52 --> Model Class Initialized
DEBUG - 2020-03-23 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:15:52 --> Model Class Initialized
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:15:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:15:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:15:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:15:52 --> Final output sent to browser
DEBUG - 2020-03-23 17:15:52 --> Total execution time: 1.2808
INFO - 2020-03-23 17:16:02 --> Config Class Initialized
INFO - 2020-03-23 17:16:02 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:16:02 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:16:02 --> Utf8 Class Initialized
INFO - 2020-03-23 17:16:02 --> URI Class Initialized
INFO - 2020-03-23 17:16:02 --> Router Class Initialized
INFO - 2020-03-23 17:16:02 --> Output Class Initialized
INFO - 2020-03-23 17:16:02 --> Security Class Initialized
DEBUG - 2020-03-23 17:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:16:02 --> CSRF cookie sent
INFO - 2020-03-23 17:16:02 --> CSRF token verified
INFO - 2020-03-23 17:16:02 --> Input Class Initialized
INFO - 2020-03-23 17:16:02 --> Language Class Initialized
INFO - 2020-03-23 17:16:02 --> Language Class Initialized
INFO - 2020-03-23 17:16:02 --> Config Class Initialized
INFO - 2020-03-23 17:16:02 --> Loader Class Initialized
INFO - 2020-03-23 17:16:02 --> Helper loaded: url_helper
INFO - 2020-03-23 17:16:02 --> Helper loaded: common_helper
INFO - 2020-03-23 17:16:02 --> Helper loaded: language_helper
INFO - 2020-03-23 17:16:02 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:16:02 --> Helper loaded: email_helper
INFO - 2020-03-23 17:16:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:16:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:16:02 --> Parser Class Initialized
INFO - 2020-03-23 17:16:03 --> User Agent Class Initialized
INFO - 2020-03-23 17:16:03 --> Model Class Initialized
INFO - 2020-03-23 17:16:03 --> Database Driver Class Initialized
INFO - 2020-03-23 17:16:03 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:03 --> Template Class Initialized
INFO - 2020-03-23 17:16:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:16:03 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:16:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:16:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:16:03 --> Encryption Class Initialized
INFO - 2020-03-23 17:16:03 --> Controller Class Initialized
DEBUG - 2020-03-23 17:16:03 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:16:03 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:03 --> stripe MX_Controller Initialized
DEBUG - 2020-03-23 17:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
ERROR - 2020-03-23 17:16:03 --> Could not find the language line "Your_name"
DEBUG - 2020-03-23 17:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2020-03-23 17:16:03 --> Final output sent to browser
DEBUG - 2020-03-23 17:16:03 --> Total execution time: 0.8814
INFO - 2020-03-23 17:16:25 --> Config Class Initialized
INFO - 2020-03-23 17:16:25 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:16:25 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:16:25 --> Utf8 Class Initialized
INFO - 2020-03-23 17:16:25 --> URI Class Initialized
DEBUG - 2020-03-23 17:16:25 --> No URI present. Default controller set.
INFO - 2020-03-23 17:16:25 --> Router Class Initialized
INFO - 2020-03-23 17:16:25 --> Output Class Initialized
INFO - 2020-03-23 17:16:25 --> Security Class Initialized
DEBUG - 2020-03-23 17:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:16:25 --> CSRF cookie sent
INFO - 2020-03-23 17:16:25 --> Input Class Initialized
INFO - 2020-03-23 17:16:25 --> Language Class Initialized
INFO - 2020-03-23 17:16:25 --> Language Class Initialized
INFO - 2020-03-23 17:16:25 --> Config Class Initialized
INFO - 2020-03-23 17:16:25 --> Loader Class Initialized
INFO - 2020-03-23 17:16:25 --> Helper loaded: url_helper
INFO - 2020-03-23 17:16:25 --> Helper loaded: common_helper
INFO - 2020-03-23 17:16:25 --> Helper loaded: language_helper
INFO - 2020-03-23 17:16:25 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:16:25 --> Helper loaded: email_helper
INFO - 2020-03-23 17:16:25 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:16:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:16:25 --> Parser Class Initialized
INFO - 2020-03-23 17:16:25 --> User Agent Class Initialized
INFO - 2020-03-23 17:16:25 --> Model Class Initialized
INFO - 2020-03-23 17:16:25 --> Database Driver Class Initialized
INFO - 2020-03-23 17:16:25 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:25 --> Template Class Initialized
INFO - 2020-03-23 17:16:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:16:26 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:16:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:16:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:16:26 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:16:26 --> Controller Class Initialized
DEBUG - 2020-03-23 17:16:26 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:16:26 --> Model Class Initialized
INFO - 2020-03-23 17:16:26 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:16:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:16:26 --> Final output sent to browser
DEBUG - 2020-03-23 17:16:26 --> Total execution time: 0.8006
INFO - 2020-03-23 17:16:29 --> Config Class Initialized
INFO - 2020-03-23 17:16:29 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:16:29 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:16:29 --> Utf8 Class Initialized
INFO - 2020-03-23 17:16:29 --> URI Class Initialized
INFO - 2020-03-23 17:16:29 --> Router Class Initialized
INFO - 2020-03-23 17:16:29 --> Output Class Initialized
INFO - 2020-03-23 17:16:29 --> Security Class Initialized
DEBUG - 2020-03-23 17:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:16:29 --> CSRF cookie sent
INFO - 2020-03-23 17:16:29 --> Input Class Initialized
INFO - 2020-03-23 17:16:29 --> Language Class Initialized
INFO - 2020-03-23 17:16:29 --> Language Class Initialized
INFO - 2020-03-23 17:16:29 --> Config Class Initialized
INFO - 2020-03-23 17:16:29 --> Loader Class Initialized
INFO - 2020-03-23 17:16:29 --> Helper loaded: url_helper
INFO - 2020-03-23 17:16:29 --> Helper loaded: common_helper
INFO - 2020-03-23 17:16:29 --> Helper loaded: language_helper
INFO - 2020-03-23 17:16:29 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:16:29 --> Helper loaded: email_helper
INFO - 2020-03-23 17:16:29 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:16:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:16:29 --> Parser Class Initialized
INFO - 2020-03-23 17:16:29 --> User Agent Class Initialized
INFO - 2020-03-23 17:16:29 --> Model Class Initialized
INFO - 2020-03-23 17:16:29 --> Database Driver Class Initialized
INFO - 2020-03-23 17:16:29 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:29 --> Template Class Initialized
INFO - 2020-03-23 17:16:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:16:30 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:16:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:16:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:16:30 --> Encryption Class Initialized
INFO - 2020-03-23 17:16:30 --> Controller Class Initialized
DEBUG - 2020-03-23 17:16:30 --> package MX_Controller Initialized
DEBUG - 2020-03-23 17:16:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-23 17:16:30 --> Model Class Initialized
INFO - 2020-03-23 17:16:30 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:16:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:16:30 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:16:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:16:30 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:16:30 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-23 17:16:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:16:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:16:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:16:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:16:30 --> Final output sent to browser
DEBUG - 2020-03-23 17:16:30 --> Total execution time: 1.2516
INFO - 2020-03-23 17:16:33 --> Config Class Initialized
INFO - 2020-03-23 17:16:33 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:16:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:16:33 --> Utf8 Class Initialized
INFO - 2020-03-23 17:16:33 --> URI Class Initialized
INFO - 2020-03-23 17:16:33 --> Router Class Initialized
INFO - 2020-03-23 17:16:33 --> Output Class Initialized
INFO - 2020-03-23 17:16:33 --> Security Class Initialized
DEBUG - 2020-03-23 17:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:16:33 --> CSRF cookie sent
INFO - 2020-03-23 17:16:33 --> CSRF token verified
INFO - 2020-03-23 17:16:33 --> Input Class Initialized
INFO - 2020-03-23 17:16:33 --> Language Class Initialized
INFO - 2020-03-23 17:16:33 --> Language Class Initialized
INFO - 2020-03-23 17:16:33 --> Config Class Initialized
INFO - 2020-03-23 17:16:33 --> Loader Class Initialized
INFO - 2020-03-23 17:16:33 --> Helper loaded: url_helper
INFO - 2020-03-23 17:16:33 --> Helper loaded: common_helper
INFO - 2020-03-23 17:16:33 --> Helper loaded: language_helper
INFO - 2020-03-23 17:16:33 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:16:33 --> Helper loaded: email_helper
INFO - 2020-03-23 17:16:33 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:16:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:16:33 --> Parser Class Initialized
INFO - 2020-03-23 17:16:33 --> User Agent Class Initialized
INFO - 2020-03-23 17:16:33 --> Model Class Initialized
INFO - 2020-03-23 17:16:33 --> Database Driver Class Initialized
INFO - 2020-03-23 17:16:33 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:33 --> Template Class Initialized
INFO - 2020-03-23 17:16:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:16:33 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:16:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:16:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:16:33 --> Encryption Class Initialized
INFO - 2020-03-23 17:16:33 --> Controller Class Initialized
DEBUG - 2020-03-23 17:16:33 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:16:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:16:33 --> Model Class Initialized
INFO - 2020-03-23 17:16:33 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:16:33 --> Could not find the language line "shopier"
DEBUG - 2020-03-23 17:16:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-23 17:16:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:16:33 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:16:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:16:33 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:16:33 --> Model Class Initialized
ERROR - 2020-03-23 17:16:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:16:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:16:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:16:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:16:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:16:34 --> Final output sent to browser
DEBUG - 2020-03-23 17:16:34 --> Total execution time: 1.2462
INFO - 2020-03-23 17:16:50 --> Config Class Initialized
INFO - 2020-03-23 17:16:50 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:16:50 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:16:50 --> Utf8 Class Initialized
INFO - 2020-03-23 17:16:50 --> URI Class Initialized
INFO - 2020-03-23 17:16:50 --> Router Class Initialized
INFO - 2020-03-23 17:16:50 --> Output Class Initialized
INFO - 2020-03-23 17:16:50 --> Security Class Initialized
DEBUG - 2020-03-23 17:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:16:50 --> CSRF cookie sent
INFO - 2020-03-23 17:16:50 --> CSRF token verified
INFO - 2020-03-23 17:16:50 --> Input Class Initialized
INFO - 2020-03-23 17:16:50 --> Language Class Initialized
INFO - 2020-03-23 17:16:50 --> Language Class Initialized
INFO - 2020-03-23 17:16:50 --> Config Class Initialized
INFO - 2020-03-23 17:16:50 --> Loader Class Initialized
INFO - 2020-03-23 17:16:50 --> Helper loaded: url_helper
INFO - 2020-03-23 17:16:50 --> Helper loaded: common_helper
INFO - 2020-03-23 17:16:50 --> Helper loaded: language_helper
INFO - 2020-03-23 17:16:50 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:16:50 --> Helper loaded: email_helper
INFO - 2020-03-23 17:16:50 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:16:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:16:50 --> Parser Class Initialized
INFO - 2020-03-23 17:16:50 --> User Agent Class Initialized
INFO - 2020-03-23 17:16:50 --> Model Class Initialized
INFO - 2020-03-23 17:16:50 --> Database Driver Class Initialized
INFO - 2020-03-23 17:16:50 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:50 --> Template Class Initialized
INFO - 2020-03-23 17:16:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:16:50 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:16:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:16:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:16:50 --> Encryption Class Initialized
INFO - 2020-03-23 17:16:50 --> Controller Class Initialized
DEBUG - 2020-03-23 17:16:50 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:16:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:16:50 --> Model Class Initialized
DEBUG - 2020-03-23 17:16:50 --> paytm MX_Controller Initialized
DEBUG - 2020-03-23 17:16:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:16:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2020-03-23 17:16:50 --> orders MX_Controller Initialized
DEBUG - 2020-03-23 17:16:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2020-03-23 17:16:50 --> Final output sent to browser
DEBUG - 2020-03-23 17:16:50 --> Total execution time: 0.7611
INFO - 2020-03-23 17:17:04 --> Config Class Initialized
INFO - 2020-03-23 17:17:04 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:17:04 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:17:04 --> Utf8 Class Initialized
INFO - 2020-03-23 17:17:04 --> URI Class Initialized
INFO - 2020-03-23 17:17:04 --> Router Class Initialized
INFO - 2020-03-23 17:17:04 --> Output Class Initialized
INFO - 2020-03-23 17:17:04 --> Security Class Initialized
DEBUG - 2020-03-23 17:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:17:04 --> Input Class Initialized
INFO - 2020-03-23 17:17:04 --> Language Class Initialized
INFO - 2020-03-23 17:17:04 --> Language Class Initialized
INFO - 2020-03-23 17:17:04 --> Config Class Initialized
INFO - 2020-03-23 17:17:04 --> Loader Class Initialized
INFO - 2020-03-23 17:17:04 --> Helper loaded: url_helper
INFO - 2020-03-23 17:17:04 --> Helper loaded: common_helper
INFO - 2020-03-23 17:17:04 --> Helper loaded: language_helper
INFO - 2020-03-23 17:17:04 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:17:04 --> Helper loaded: email_helper
INFO - 2020-03-23 17:17:04 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:17:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:17:05 --> Parser Class Initialized
INFO - 2020-03-23 17:17:05 --> User Agent Class Initialized
INFO - 2020-03-23 17:17:05 --> Model Class Initialized
INFO - 2020-03-23 17:17:05 --> Database Driver Class Initialized
INFO - 2020-03-23 17:17:05 --> Model Class Initialized
DEBUG - 2020-03-23 17:17:05 --> Template Class Initialized
INFO - 2020-03-23 17:17:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:17:05 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:17:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:17:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:17:05 --> Encryption Class Initialized
INFO - 2020-03-23 17:17:05 --> Controller Class Initialized
DEBUG - 2020-03-23 17:17:05 --> paytm MX_Controller Initialized
INFO - 2020-03-23 17:17:05 --> Model Class Initialized
DEBUG - 2020-03-23 17:17:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2020-03-23 17:17:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2020-03-23 17:17:05 --> Config Class Initialized
INFO - 2020-03-23 17:17:05 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:17:05 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:17:05 --> Utf8 Class Initialized
INFO - 2020-03-23 17:17:05 --> URI Class Initialized
INFO - 2020-03-23 17:17:05 --> Router Class Initialized
INFO - 2020-03-23 17:17:05 --> Output Class Initialized
INFO - 2020-03-23 17:17:05 --> Security Class Initialized
DEBUG - 2020-03-23 17:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:17:05 --> CSRF cookie sent
INFO - 2020-03-23 17:17:06 --> Input Class Initialized
INFO - 2020-03-23 17:17:06 --> Language Class Initialized
INFO - 2020-03-23 17:17:06 --> Language Class Initialized
INFO - 2020-03-23 17:17:06 --> Config Class Initialized
INFO - 2020-03-23 17:17:06 --> Loader Class Initialized
INFO - 2020-03-23 17:17:06 --> Helper loaded: url_helper
INFO - 2020-03-23 17:17:06 --> Helper loaded: common_helper
INFO - 2020-03-23 17:17:06 --> Helper loaded: language_helper
INFO - 2020-03-23 17:17:06 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:17:06 --> Helper loaded: email_helper
INFO - 2020-03-23 17:17:06 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:17:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:17:06 --> Parser Class Initialized
INFO - 2020-03-23 17:17:06 --> User Agent Class Initialized
INFO - 2020-03-23 17:17:06 --> Model Class Initialized
INFO - 2020-03-23 17:17:06 --> Database Driver Class Initialized
INFO - 2020-03-23 17:17:06 --> Model Class Initialized
DEBUG - 2020-03-23 17:17:06 --> Template Class Initialized
INFO - 2020-03-23 17:17:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:17:06 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:17:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:17:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:17:06 --> Encryption Class Initialized
INFO - 2020-03-23 17:17:06 --> Controller Class Initialized
DEBUG - 2020-03-23 17:17:06 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:17:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:17:06 --> Model Class Initialized
INFO - 2020-03-23 17:17:06 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:17:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-23 17:17:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:17:06 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:17:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:17:06 --> Model Class Initialized
DEBUG - 2020-03-23 17:17:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:17:06 --> Model Class Initialized
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:17:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:17:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:17:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:17:07 --> Final output sent to browser
DEBUG - 2020-03-23 17:17:07 --> Total execution time: 1.1912
INFO - 2020-03-23 17:17:20 --> Config Class Initialized
INFO - 2020-03-23 17:17:20 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:17:20 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:17:20 --> Utf8 Class Initialized
INFO - 2020-03-23 17:17:20 --> URI Class Initialized
INFO - 2020-03-23 17:17:20 --> Router Class Initialized
INFO - 2020-03-23 17:17:20 --> Output Class Initialized
INFO - 2020-03-23 17:17:20 --> Security Class Initialized
DEBUG - 2020-03-23 17:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:17:20 --> CSRF cookie sent
INFO - 2020-03-23 17:17:20 --> Input Class Initialized
INFO - 2020-03-23 17:17:20 --> Language Class Initialized
INFO - 2020-03-23 17:17:20 --> Language Class Initialized
INFO - 2020-03-23 17:17:20 --> Config Class Initialized
INFO - 2020-03-23 17:17:20 --> Loader Class Initialized
INFO - 2020-03-23 17:17:20 --> Helper loaded: url_helper
INFO - 2020-03-23 17:17:20 --> Helper loaded: common_helper
INFO - 2020-03-23 17:17:20 --> Helper loaded: language_helper
INFO - 2020-03-23 17:17:20 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:17:20 --> Helper loaded: email_helper
INFO - 2020-03-23 17:17:20 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:17:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:17:20 --> Parser Class Initialized
INFO - 2020-03-23 17:17:20 --> User Agent Class Initialized
INFO - 2020-03-23 17:17:20 --> Model Class Initialized
INFO - 2020-03-23 17:17:20 --> Database Driver Class Initialized
INFO - 2020-03-23 17:17:20 --> Model Class Initialized
DEBUG - 2020-03-23 17:17:20 --> Template Class Initialized
INFO - 2020-03-23 17:17:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:17:20 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:17:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:17:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:17:20 --> Encryption Class Initialized
INFO - 2020-03-23 17:17:20 --> Controller Class Initialized
DEBUG - 2020-03-23 17:17:20 --> checkout MX_Controller Initialized
DEBUG - 2020-03-23 17:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-23 17:17:20 --> Model Class Initialized
INFO - 2020-03-23 17:17:21 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:17:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-23 17:17:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:17:21 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:17:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:17:21 --> Model Class Initialized
DEBUG - 2020-03-23 17:17:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:17:21 --> Model Class Initialized
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-23 17:17:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-23 17:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-23 17:17:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-23 17:17:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-23 17:17:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-23 17:17:21 --> Final output sent to browser
DEBUG - 2020-03-23 17:17:21 --> Total execution time: 1.1831
INFO - 2020-03-23 17:17:58 --> Config Class Initialized
INFO - 2020-03-23 17:17:58 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:17:58 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:17:58 --> Utf8 Class Initialized
INFO - 2020-03-23 17:17:58 --> URI Class Initialized
INFO - 2020-03-23 17:17:58 --> Router Class Initialized
INFO - 2020-03-23 17:17:58 --> Output Class Initialized
INFO - 2020-03-23 17:17:58 --> Security Class Initialized
DEBUG - 2020-03-23 17:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:17:58 --> CSRF cookie sent
INFO - 2020-03-23 17:17:58 --> Input Class Initialized
INFO - 2020-03-23 17:17:58 --> Language Class Initialized
INFO - 2020-03-23 17:17:58 --> Language Class Initialized
INFO - 2020-03-23 17:17:58 --> Config Class Initialized
INFO - 2020-03-23 17:17:58 --> Loader Class Initialized
INFO - 2020-03-23 17:17:58 --> Helper loaded: url_helper
INFO - 2020-03-23 17:17:58 --> Helper loaded: common_helper
INFO - 2020-03-23 17:17:58 --> Helper loaded: language_helper
INFO - 2020-03-23 17:17:58 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:17:58 --> Helper loaded: email_helper
INFO - 2020-03-23 17:17:58 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:17:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:17:58 --> Parser Class Initialized
INFO - 2020-03-23 17:17:58 --> User Agent Class Initialized
INFO - 2020-03-23 17:17:58 --> Model Class Initialized
INFO - 2020-03-23 17:17:59 --> Database Driver Class Initialized
INFO - 2020-03-23 17:17:59 --> Model Class Initialized
DEBUG - 2020-03-23 17:17:59 --> Template Class Initialized
INFO - 2020-03-23 17:17:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:17:59 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:17:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:17:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:17:59 --> Encryption Class Initialized
INFO - 2020-03-23 17:17:59 --> Controller Class Initialized
DEBUG - 2020-03-23 17:17:59 --> order MX_Controller Initialized
INFO - 2020-03-23 17:17:59 --> Config Class Initialized
INFO - 2020-03-23 17:17:59 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:17:59 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:17:59 --> Utf8 Class Initialized
INFO - 2020-03-23 17:17:59 --> URI Class Initialized
DEBUG - 2020-03-23 17:17:59 --> No URI present. Default controller set.
INFO - 2020-03-23 17:17:59 --> Router Class Initialized
INFO - 2020-03-23 17:17:59 --> Output Class Initialized
INFO - 2020-03-23 17:17:59 --> Security Class Initialized
DEBUG - 2020-03-23 17:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:17:59 --> CSRF cookie sent
INFO - 2020-03-23 17:17:59 --> Input Class Initialized
INFO - 2020-03-23 17:17:59 --> Language Class Initialized
INFO - 2020-03-23 17:17:59 --> Language Class Initialized
INFO - 2020-03-23 17:17:59 --> Config Class Initialized
INFO - 2020-03-23 17:17:59 --> Loader Class Initialized
INFO - 2020-03-23 17:17:59 --> Helper loaded: url_helper
INFO - 2020-03-23 17:17:59 --> Helper loaded: common_helper
INFO - 2020-03-23 17:17:59 --> Helper loaded: language_helper
INFO - 2020-03-23 17:17:59 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:17:59 --> Helper loaded: email_helper
INFO - 2020-03-23 17:17:59 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:17:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:17:59 --> Parser Class Initialized
INFO - 2020-03-23 17:17:59 --> User Agent Class Initialized
INFO - 2020-03-23 17:17:59 --> Model Class Initialized
INFO - 2020-03-23 17:17:59 --> Database Driver Class Initialized
INFO - 2020-03-23 17:17:59 --> Model Class Initialized
DEBUG - 2020-03-23 17:17:59 --> Template Class Initialized
INFO - 2020-03-23 17:17:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:17:59 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:17:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:17:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:17:59 --> Encryption Class Initialized
DEBUG - 2020-03-23 17:17:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:17:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:17:59 --> Controller Class Initialized
DEBUG - 2020-03-23 17:17:59 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:17:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:17:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 17:17:59 --> Model Class Initialized
INFO - 2020-03-23 17:17:59 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:17:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:18:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:18:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 17:18:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:18:00 --> Final output sent to browser
DEBUG - 2020-03-23 17:18:00 --> Total execution time: 0.8757
INFO - 2020-03-23 17:18:02 --> Config Class Initialized
INFO - 2020-03-23 17:18:02 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:18:02 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:18:02 --> Utf8 Class Initialized
INFO - 2020-03-23 17:18:02 --> URI Class Initialized
INFO - 2020-03-23 17:18:02 --> Router Class Initialized
INFO - 2020-03-23 17:18:02 --> Output Class Initialized
INFO - 2020-03-23 17:18:02 --> Security Class Initialized
DEBUG - 2020-03-23 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:18:02 --> CSRF cookie sent
INFO - 2020-03-23 17:18:02 --> Input Class Initialized
INFO - 2020-03-23 17:18:02 --> Language Class Initialized
INFO - 2020-03-23 17:18:02 --> Language Class Initialized
INFO - 2020-03-23 17:18:02 --> Config Class Initialized
INFO - 2020-03-23 17:18:02 --> Loader Class Initialized
INFO - 2020-03-23 17:18:02 --> Helper loaded: url_helper
INFO - 2020-03-23 17:18:02 --> Helper loaded: common_helper
INFO - 2020-03-23 17:18:02 --> Helper loaded: language_helper
INFO - 2020-03-23 17:18:02 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:18:02 --> Helper loaded: email_helper
INFO - 2020-03-23 17:18:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:18:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:18:02 --> Parser Class Initialized
INFO - 2020-03-23 17:18:02 --> User Agent Class Initialized
INFO - 2020-03-23 17:18:02 --> Model Class Initialized
INFO - 2020-03-23 17:18:02 --> Database Driver Class Initialized
INFO - 2020-03-23 17:18:02 --> Model Class Initialized
DEBUG - 2020-03-23 17:18:03 --> Template Class Initialized
INFO - 2020-03-23 17:18:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:18:03 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:18:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:18:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:18:03 --> Encryption Class Initialized
INFO - 2020-03-23 17:18:03 --> Controller Class Initialized
DEBUG - 2020-03-23 17:18:03 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 17:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 17:18:03 --> Model Class Initialized
DEBUG - 2020-03-23 17:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 17:18:03 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-23 17:18:03 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 17:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 17:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-23 17:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 17:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 17:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-23 17:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 17:18:03 --> Final output sent to browser
DEBUG - 2020-03-23 17:18:03 --> Total execution time: 0.8183
INFO - 2020-03-23 17:18:05 --> Config Class Initialized
INFO - 2020-03-23 17:18:05 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:18:05 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:18:05 --> Utf8 Class Initialized
INFO - 2020-03-23 17:18:05 --> URI Class Initialized
INFO - 2020-03-23 17:18:05 --> Router Class Initialized
INFO - 2020-03-23 17:18:05 --> Output Class Initialized
INFO - 2020-03-23 17:18:05 --> Security Class Initialized
DEBUG - 2020-03-23 17:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:18:05 --> CSRF cookie sent
INFO - 2020-03-23 17:18:05 --> CSRF token verified
INFO - 2020-03-23 17:18:05 --> Input Class Initialized
INFO - 2020-03-23 17:18:05 --> Language Class Initialized
INFO - 2020-03-23 17:18:05 --> Language Class Initialized
INFO - 2020-03-23 17:18:05 --> Config Class Initialized
INFO - 2020-03-23 17:18:05 --> Loader Class Initialized
INFO - 2020-03-23 17:18:05 --> Helper loaded: url_helper
INFO - 2020-03-23 17:18:05 --> Helper loaded: common_helper
INFO - 2020-03-23 17:18:05 --> Helper loaded: language_helper
INFO - 2020-03-23 17:18:05 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:18:05 --> Helper loaded: email_helper
INFO - 2020-03-23 17:18:05 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:18:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:18:05 --> Parser Class Initialized
INFO - 2020-03-23 17:18:05 --> User Agent Class Initialized
INFO - 2020-03-23 17:18:05 --> Model Class Initialized
INFO - 2020-03-23 17:18:05 --> Database Driver Class Initialized
INFO - 2020-03-23 17:18:05 --> Model Class Initialized
DEBUG - 2020-03-23 17:18:05 --> Template Class Initialized
INFO - 2020-03-23 17:18:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:18:05 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:18:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:18:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:18:05 --> Encryption Class Initialized
INFO - 2020-03-23 17:18:05 --> Controller Class Initialized
DEBUG - 2020-03-23 17:18:05 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 17:18:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 17:18:05 --> Model Class Initialized
INFO - 2020-03-23 17:18:10 --> Config Class Initialized
INFO - 2020-03-23 17:18:10 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:18:10 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:18:10 --> Utf8 Class Initialized
INFO - 2020-03-23 17:18:10 --> URI Class Initialized
INFO - 2020-03-23 17:18:10 --> Router Class Initialized
INFO - 2020-03-23 17:18:10 --> Output Class Initialized
INFO - 2020-03-23 17:18:10 --> Security Class Initialized
DEBUG - 2020-03-23 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:18:10 --> CSRF cookie sent
INFO - 2020-03-23 17:18:10 --> Input Class Initialized
INFO - 2020-03-23 17:18:10 --> Language Class Initialized
INFO - 2020-03-23 17:18:10 --> Language Class Initialized
INFO - 2020-03-23 17:18:10 --> Config Class Initialized
INFO - 2020-03-23 17:18:10 --> Loader Class Initialized
INFO - 2020-03-23 17:18:10 --> Helper loaded: url_helper
INFO - 2020-03-23 17:18:10 --> Helper loaded: common_helper
INFO - 2020-03-23 17:18:10 --> Helper loaded: language_helper
INFO - 2020-03-23 17:18:10 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:18:10 --> Helper loaded: email_helper
INFO - 2020-03-23 17:18:10 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:18:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:18:10 --> Parser Class Initialized
INFO - 2020-03-23 17:18:10 --> User Agent Class Initialized
INFO - 2020-03-23 17:18:10 --> Model Class Initialized
INFO - 2020-03-23 17:18:10 --> Database Driver Class Initialized
INFO - 2020-03-23 17:18:10 --> Model Class Initialized
DEBUG - 2020-03-23 17:18:10 --> Template Class Initialized
INFO - 2020-03-23 17:18:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:18:10 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:18:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:18:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:18:10 --> Encryption Class Initialized
INFO - 2020-03-23 17:18:10 --> Controller Class Initialized
DEBUG - 2020-03-23 17:18:10 --> statistics MX_Controller Initialized
DEBUG - 2020-03-23 17:18:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-23 17:18:11 --> Model Class Initialized
ERROR - 2020-03-23 17:18:11 --> Could not find the language line "Pending"
ERROR - 2020-03-23 17:18:11 --> Could not find the language line "Pending"
INFO - 2020-03-23 17:18:11 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 17:18:11 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 17:18:11 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 17:18:11 --> Could not find the language line "Pending"
DEBUG - 2020-03-23 17:18:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-23 17:18:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:18:11 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:18:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:18:11 --> Model Class Initialized
DEBUG - 2020-03-23 17:18:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:18:11 --> Model Class Initialized
DEBUG - 2020-03-23 17:18:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 17:18:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 17:18:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 17:18:11 --> Final output sent to browser
DEBUG - 2020-03-23 17:18:11 --> Total execution time: 1.0033
INFO - 2020-03-23 17:18:15 --> Config Class Initialized
INFO - 2020-03-23 17:18:15 --> Hooks Class Initialized
DEBUG - 2020-03-23 17:18:15 --> UTF-8 Support Enabled
INFO - 2020-03-23 17:18:15 --> Utf8 Class Initialized
INFO - 2020-03-23 17:18:15 --> URI Class Initialized
INFO - 2020-03-23 17:18:15 --> Router Class Initialized
INFO - 2020-03-23 17:18:15 --> Output Class Initialized
INFO - 2020-03-23 17:18:15 --> Security Class Initialized
DEBUG - 2020-03-23 17:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 17:18:15 --> CSRF cookie sent
INFO - 2020-03-23 17:18:15 --> Input Class Initialized
INFO - 2020-03-23 17:18:15 --> Language Class Initialized
INFO - 2020-03-23 17:18:15 --> Language Class Initialized
INFO - 2020-03-23 17:18:15 --> Config Class Initialized
INFO - 2020-03-23 17:18:15 --> Loader Class Initialized
INFO - 2020-03-23 17:18:15 --> Helper loaded: url_helper
INFO - 2020-03-23 17:18:15 --> Helper loaded: common_helper
INFO - 2020-03-23 17:18:16 --> Helper loaded: language_helper
INFO - 2020-03-23 17:18:16 --> Helper loaded: cookie_helper
INFO - 2020-03-23 17:18:16 --> Helper loaded: email_helper
INFO - 2020-03-23 17:18:16 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 17:18:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 17:18:16 --> Parser Class Initialized
INFO - 2020-03-23 17:18:16 --> User Agent Class Initialized
INFO - 2020-03-23 17:18:16 --> Model Class Initialized
INFO - 2020-03-23 17:18:16 --> Database Driver Class Initialized
INFO - 2020-03-23 17:18:16 --> Model Class Initialized
DEBUG - 2020-03-23 17:18:16 --> Template Class Initialized
INFO - 2020-03-23 17:18:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 17:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 17:18:16 --> Pagination Class Initialized
DEBUG - 2020-03-23 17:18:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 17:18:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 17:18:16 --> Encryption Class Initialized
INFO - 2020-03-23 17:18:16 --> Controller Class Initialized
DEBUG - 2020-03-23 17:18:16 --> transactions MX_Controller Initialized
DEBUG - 2020-03-23 17:18:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-23 17:18:16 --> Model Class Initialized
ERROR - 2020-03-23 17:18:16 --> Could not find the language line "order_id"
INFO - 2020-03-23 17:18:16 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 17:18:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-23 17:18:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 17:18:16 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 17:18:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 17:18:16 --> Model Class Initialized
DEBUG - 2020-03-23 17:18:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 17:18:16 --> Model Class Initialized
DEBUG - 2020-03-23 17:18:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 17:18:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 17:18:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 17:18:16 --> Final output sent to browser
DEBUG - 2020-03-23 17:18:16 --> Total execution time: 0.8880
INFO - 2020-03-23 21:35:58 --> Config Class Initialized
INFO - 2020-03-23 21:35:58 --> Hooks Class Initialized
DEBUG - 2020-03-23 21:35:58 --> UTF-8 Support Enabled
INFO - 2020-03-23 21:35:58 --> Utf8 Class Initialized
INFO - 2020-03-23 21:35:58 --> URI Class Initialized
INFO - 2020-03-23 21:35:59 --> Router Class Initialized
INFO - 2020-03-23 21:35:59 --> Output Class Initialized
INFO - 2020-03-23 21:35:59 --> Security Class Initialized
DEBUG - 2020-03-23 21:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 21:35:59 --> CSRF cookie sent
INFO - 2020-03-23 21:35:59 --> Input Class Initialized
INFO - 2020-03-23 21:35:59 --> Language Class Initialized
INFO - 2020-03-23 21:35:59 --> Language Class Initialized
INFO - 2020-03-23 21:35:59 --> Config Class Initialized
INFO - 2020-03-23 21:35:59 --> Loader Class Initialized
INFO - 2020-03-23 21:35:59 --> Helper loaded: url_helper
INFO - 2020-03-23 21:35:59 --> Helper loaded: common_helper
INFO - 2020-03-23 21:35:59 --> Helper loaded: language_helper
INFO - 2020-03-23 21:35:59 --> Helper loaded: cookie_helper
INFO - 2020-03-23 21:35:59 --> Helper loaded: email_helper
INFO - 2020-03-23 21:35:59 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 21:35:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 21:35:59 --> Parser Class Initialized
INFO - 2020-03-23 21:35:59 --> User Agent Class Initialized
INFO - 2020-03-23 21:35:59 --> Model Class Initialized
INFO - 2020-03-23 21:35:59 --> Database Driver Class Initialized
INFO - 2020-03-23 21:35:59 --> Model Class Initialized
DEBUG - 2020-03-23 21:35:59 --> Template Class Initialized
INFO - 2020-03-23 21:35:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 21:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 21:36:00 --> Pagination Class Initialized
DEBUG - 2020-03-23 21:36:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 21:36:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 21:36:00 --> Encryption Class Initialized
INFO - 2020-03-23 21:36:00 --> Controller Class Initialized
DEBUG - 2020-03-23 21:36:00 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 21:36:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 21:36:00 --> Model Class Initialized
INFO - 2020-03-23 21:36:00 --> Config Class Initialized
INFO - 2020-03-23 21:36:00 --> Config Class Initialized
INFO - 2020-03-23 21:36:00 --> Hooks Class Initialized
INFO - 2020-03-23 21:36:00 --> Hooks Class Initialized
DEBUG - 2020-03-23 21:36:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 21:36:00 --> UTF-8 Support Enabled
INFO - 2020-03-23 21:36:00 --> Utf8 Class Initialized
INFO - 2020-03-23 21:36:00 --> Utf8 Class Initialized
INFO - 2020-03-23 21:36:00 --> URI Class Initialized
INFO - 2020-03-23 21:36:00 --> URI Class Initialized
INFO - 2020-03-23 21:36:00 --> Router Class Initialized
INFO - 2020-03-23 21:36:00 --> Router Class Initialized
INFO - 2020-03-23 21:36:00 --> Output Class Initialized
INFO - 2020-03-23 21:36:00 --> Output Class Initialized
INFO - 2020-03-23 21:36:00 --> Security Class Initialized
INFO - 2020-03-23 21:36:00 --> Security Class Initialized
DEBUG - 2020-03-23 21:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 21:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 21:36:00 --> CSRF cookie sent
INFO - 2020-03-23 21:36:00 --> CSRF cookie sent
INFO - 2020-03-23 21:36:00 --> Input Class Initialized
INFO - 2020-03-23 21:36:00 --> Input Class Initialized
INFO - 2020-03-23 21:36:00 --> Language Class Initialized
INFO - 2020-03-23 21:36:00 --> Language Class Initialized
INFO - 2020-03-23 21:36:00 --> Language Class Initialized
INFO - 2020-03-23 21:36:00 --> Language Class Initialized
INFO - 2020-03-23 21:36:00 --> Config Class Initialized
INFO - 2020-03-23 21:36:00 --> Config Class Initialized
INFO - 2020-03-23 21:36:00 --> Loader Class Initialized
INFO - 2020-03-23 21:36:00 --> Loader Class Initialized
INFO - 2020-03-23 21:36:00 --> Helper loaded: url_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: url_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: common_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: common_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: language_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: language_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: cookie_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: cookie_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: email_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: email_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 21:36:00 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 21:36:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 21:36:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 21:36:00 --> Parser Class Initialized
INFO - 2020-03-23 21:36:00 --> Parser Class Initialized
INFO - 2020-03-23 21:36:00 --> User Agent Class Initialized
INFO - 2020-03-23 21:36:00 --> User Agent Class Initialized
INFO - 2020-03-23 21:36:00 --> Model Class Initialized
INFO - 2020-03-23 21:36:00 --> Model Class Initialized
INFO - 2020-03-23 21:36:00 --> Database Driver Class Initialized
INFO - 2020-03-23 21:36:00 --> Database Driver Class Initialized
INFO - 2020-03-23 21:36:00 --> Model Class Initialized
INFO - 2020-03-23 21:36:00 --> Model Class Initialized
DEBUG - 2020-03-23 21:36:00 --> Template Class Initialized
DEBUG - 2020-03-23 21:36:00 --> Template Class Initialized
INFO - 2020-03-23 21:36:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 21:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 21:36:00 --> Pagination Class Initialized
DEBUG - 2020-03-23 21:36:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 21:36:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 21:36:00 --> Encryption Class Initialized
INFO - 2020-03-23 21:36:00 --> Controller Class Initialized
DEBUG - 2020-03-23 21:36:00 --> statistics MX_Controller Initialized
DEBUG - 2020-03-23 21:36:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-23 21:36:00 --> Model Class Initialized
ERROR - 2020-03-23 21:36:00 --> Could not find the language line "Pending"
ERROR - 2020-03-23 21:36:00 --> Could not find the language line "Pending"
INFO - 2020-03-23 21:36:00 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 21:36:01 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 21:36:01 --> Could not find the language line "total_orders"
ERROR - 2020-03-23 21:36:01 --> Could not find the language line "Pending"
DEBUG - 2020-03-23 21:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-23 21:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 21:36:01 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 21:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 21:36:01 --> Model Class Initialized
DEBUG - 2020-03-23 21:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 21:36:01 --> Model Class Initialized
DEBUG - 2020-03-23 21:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 21:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 21:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 21:36:01 --> Final output sent to browser
DEBUG - 2020-03-23 21:36:01 --> Total execution time: 1.2344
INFO - 2020-03-23 21:36:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 21:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 21:36:01 --> Pagination Class Initialized
DEBUG - 2020-03-23 21:36:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 21:36:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 21:36:01 --> Encryption Class Initialized
INFO - 2020-03-23 21:36:01 --> Controller Class Initialized
DEBUG - 2020-03-23 21:36:01 --> auth MX_Controller Initialized
DEBUG - 2020-03-23 21:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-23 21:36:01 --> Model Class Initialized
INFO - 2020-03-23 21:37:45 --> Config Class Initialized
INFO - 2020-03-23 21:37:45 --> Hooks Class Initialized
DEBUG - 2020-03-23 21:37:45 --> UTF-8 Support Enabled
INFO - 2020-03-23 21:37:45 --> Utf8 Class Initialized
INFO - 2020-03-23 21:37:45 --> URI Class Initialized
INFO - 2020-03-23 21:37:45 --> Router Class Initialized
INFO - 2020-03-23 21:37:45 --> Output Class Initialized
INFO - 2020-03-23 21:37:45 --> Security Class Initialized
DEBUG - 2020-03-23 21:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 21:37:45 --> CSRF cookie sent
INFO - 2020-03-23 21:37:45 --> Input Class Initialized
INFO - 2020-03-23 21:37:45 --> Language Class Initialized
INFO - 2020-03-23 21:37:45 --> Language Class Initialized
INFO - 2020-03-23 21:37:45 --> Config Class Initialized
INFO - 2020-03-23 21:37:45 --> Loader Class Initialized
INFO - 2020-03-23 21:37:45 --> Helper loaded: url_helper
INFO - 2020-03-23 21:37:45 --> Helper loaded: common_helper
INFO - 2020-03-23 21:37:45 --> Helper loaded: language_helper
INFO - 2020-03-23 21:37:45 --> Helper loaded: cookie_helper
INFO - 2020-03-23 21:37:45 --> Helper loaded: email_helper
INFO - 2020-03-23 21:37:45 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 21:37:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 21:37:45 --> Parser Class Initialized
INFO - 2020-03-23 21:37:45 --> User Agent Class Initialized
INFO - 2020-03-23 21:37:45 --> Model Class Initialized
INFO - 2020-03-23 21:37:45 --> Database Driver Class Initialized
INFO - 2020-03-23 21:37:45 --> Model Class Initialized
DEBUG - 2020-03-23 21:37:45 --> Template Class Initialized
INFO - 2020-03-23 21:37:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 21:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 21:37:45 --> Pagination Class Initialized
DEBUG - 2020-03-23 21:37:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 21:37:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 21:37:45 --> Encryption Class Initialized
INFO - 2020-03-23 21:37:45 --> Controller Class Initialized
DEBUG - 2020-03-23 21:37:45 --> category MX_Controller Initialized
DEBUG - 2020-03-23 21:37:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 21:37:45 --> Model Class Initialized
ERROR - 2020-03-23 21:37:45 --> Could not find the language line "Sorting"
INFO - 2020-03-23 21:37:46 --> Helper loaded: inflector_helper
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "Delele"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-23 21:37:46 --> Could not find the language line "View"
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 21:37:46 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 21:37:46 --> Model Class Initialized
DEBUG - 2020-03-23 21:37:46 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 21:37:46 --> Model Class Initialized
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 21:37:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 21:37:46 --> Final output sent to browser
DEBUG - 2020-03-23 21:37:46 --> Total execution time: 1.5181
INFO - 2020-03-23 21:37:51 --> Config Class Initialized
INFO - 2020-03-23 21:37:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 21:37:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 21:37:51 --> Utf8 Class Initialized
INFO - 2020-03-23 21:37:51 --> URI Class Initialized
INFO - 2020-03-23 21:37:51 --> Router Class Initialized
INFO - 2020-03-23 21:37:51 --> Output Class Initialized
INFO - 2020-03-23 21:37:51 --> Security Class Initialized
DEBUG - 2020-03-23 21:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 21:37:51 --> CSRF cookie sent
INFO - 2020-03-23 21:37:51 --> Input Class Initialized
INFO - 2020-03-23 21:37:51 --> Language Class Initialized
INFO - 2020-03-23 21:37:51 --> Language Class Initialized
INFO - 2020-03-23 21:37:51 --> Config Class Initialized
INFO - 2020-03-23 21:37:51 --> Loader Class Initialized
INFO - 2020-03-23 21:37:51 --> Helper loaded: url_helper
INFO - 2020-03-23 21:37:51 --> Helper loaded: common_helper
INFO - 2020-03-23 21:37:51 --> Helper loaded: language_helper
INFO - 2020-03-23 21:37:51 --> Helper loaded: cookie_helper
INFO - 2020-03-23 21:37:51 --> Helper loaded: email_helper
INFO - 2020-03-23 21:37:51 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 21:37:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 21:37:51 --> Parser Class Initialized
INFO - 2020-03-23 21:37:51 --> User Agent Class Initialized
INFO - 2020-03-23 21:37:51 --> Model Class Initialized
INFO - 2020-03-23 21:37:51 --> Database Driver Class Initialized
INFO - 2020-03-23 21:37:51 --> Model Class Initialized
DEBUG - 2020-03-23 21:37:51 --> Template Class Initialized
INFO - 2020-03-23 21:37:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 21:37:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 21:37:51 --> Pagination Class Initialized
DEBUG - 2020-03-23 21:37:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 21:37:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 21:37:51 --> Encryption Class Initialized
INFO - 2020-03-23 21:37:51 --> Controller Class Initialized
DEBUG - 2020-03-23 21:37:51 --> category MX_Controller Initialized
DEBUG - 2020-03-23 21:37:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 21:37:51 --> Model Class Initialized
ERROR - 2020-03-23 21:37:52 --> Could not find the language line "Sorting"
INFO - 2020-03-23 21:37:52 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 21:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-03-23 21:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-23 21:37:52 --> blocks MX_Controller Initialized
DEBUG - 2020-03-23 21:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-23 21:37:52 --> Model Class Initialized
DEBUG - 2020-03-23 21:37:52 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-23 21:37:52 --> Model Class Initialized
DEBUG - 2020-03-23 21:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-23 21:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-23 21:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-23 21:37:52 --> Final output sent to browser
DEBUG - 2020-03-23 21:37:52 --> Total execution time: 0.9678
INFO - 2020-03-23 22:53:44 --> Config Class Initialized
INFO - 2020-03-23 22:53:44 --> Hooks Class Initialized
DEBUG - 2020-03-23 22:53:44 --> UTF-8 Support Enabled
INFO - 2020-03-23 22:53:44 --> Utf8 Class Initialized
INFO - 2020-03-23 22:53:44 --> URI Class Initialized
DEBUG - 2020-03-23 22:53:44 --> No URI present. Default controller set.
INFO - 2020-03-23 22:53:44 --> Router Class Initialized
INFO - 2020-03-23 22:53:44 --> Output Class Initialized
INFO - 2020-03-23 22:53:44 --> Security Class Initialized
DEBUG - 2020-03-23 22:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 22:53:44 --> CSRF cookie sent
INFO - 2020-03-23 22:53:44 --> Input Class Initialized
INFO - 2020-03-23 22:53:44 --> Language Class Initialized
INFO - 2020-03-23 22:53:44 --> Language Class Initialized
INFO - 2020-03-23 22:53:44 --> Config Class Initialized
INFO - 2020-03-23 22:53:44 --> Loader Class Initialized
INFO - 2020-03-23 22:53:44 --> Helper loaded: url_helper
INFO - 2020-03-23 22:53:44 --> Helper loaded: common_helper
INFO - 2020-03-23 22:53:44 --> Helper loaded: language_helper
INFO - 2020-03-23 22:53:44 --> Helper loaded: cookie_helper
INFO - 2020-03-23 22:53:44 --> Helper loaded: email_helper
INFO - 2020-03-23 22:53:44 --> Helper loaded: file_manager_helper
INFO - 2020-03-23 22:53:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-23 22:53:44 --> Parser Class Initialized
INFO - 2020-03-23 22:53:44 --> User Agent Class Initialized
INFO - 2020-03-23 22:53:44 --> Model Class Initialized
INFO - 2020-03-23 22:53:44 --> Database Driver Class Initialized
INFO - 2020-03-23 22:53:44 --> Model Class Initialized
DEBUG - 2020-03-23 22:53:44 --> Template Class Initialized
INFO - 2020-03-23 22:53:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-23 22:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-23 22:53:44 --> Pagination Class Initialized
DEBUG - 2020-03-23 22:53:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-23 22:53:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-23 22:53:44 --> Encryption Class Initialized
DEBUG - 2020-03-23 22:53:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 22:53:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-23 22:53:44 --> Controller Class Initialized
DEBUG - 2020-03-23 22:53:44 --> pergo MX_Controller Initialized
DEBUG - 2020-03-23 22:53:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-23 22:53:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-23 22:53:44 --> Model Class Initialized
INFO - 2020-03-23 22:53:44 --> Helper loaded: inflector_helper
DEBUG - 2020-03-23 22:53:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-23 22:53:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-23 22:53:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-23 22:53:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-23 22:53:45 --> Final output sent to browser
DEBUG - 2020-03-23 22:53:45 --> Total execution time: 1.0624
