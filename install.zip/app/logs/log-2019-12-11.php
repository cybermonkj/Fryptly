<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-11 10:14:35 --> Config Class Initialized
INFO - 2019-12-11 10:14:35 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:14:35 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:14:35 --> Utf8 Class Initialized
INFO - 2019-12-11 10:14:35 --> URI Class Initialized
DEBUG - 2019-12-11 10:14:35 --> No URI present. Default controller set.
INFO - 2019-12-11 10:14:35 --> Router Class Initialized
INFO - 2019-12-11 10:14:35 --> Output Class Initialized
INFO - 2019-12-11 10:14:35 --> Security Class Initialized
DEBUG - 2019-12-11 10:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:14:35 --> CSRF cookie sent
INFO - 2019-12-11 10:14:35 --> Input Class Initialized
INFO - 2019-12-11 10:14:35 --> Language Class Initialized
INFO - 2019-12-11 10:14:35 --> Language Class Initialized
INFO - 2019-12-11 10:14:35 --> Config Class Initialized
INFO - 2019-12-11 10:14:35 --> Loader Class Initialized
INFO - 2019-12-11 10:14:35 --> Helper loaded: url_helper
INFO - 2019-12-11 10:14:35 --> Helper loaded: common_helper
INFO - 2019-12-11 10:14:35 --> Helper loaded: language_helper
INFO - 2019-12-11 10:14:35 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:14:35 --> Helper loaded: email_helper
INFO - 2019-12-11 10:14:35 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:14:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:14:36 --> Parser Class Initialized
INFO - 2019-12-11 10:14:36 --> User Agent Class Initialized
INFO - 2019-12-11 10:14:36 --> Model Class Initialized
INFO - 2019-12-11 10:14:36 --> Database Driver Class Initialized
INFO - 2019-12-11 10:14:36 --> Model Class Initialized
DEBUG - 2019-12-11 10:14:36 --> Template Class Initialized
INFO - 2019-12-11 10:14:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:14:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:14:36 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:14:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:14:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:14:36 --> Encryption Class Initialized
DEBUG - 2019-12-11 10:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-11 10:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-11 10:14:36 --> Controller Class Initialized
DEBUG - 2019-12-11 10:14:36 --> pergo MX_Controller Initialized
DEBUG - 2019-12-11 10:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-11 10:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-11 10:14:36 --> Model Class Initialized
INFO - 2019-12-11 10:14:36 --> Helper loaded: inflector_helper
DEBUG - 2019-12-11 10:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-11 10:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-11 10:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-11 10:14:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-11 10:14:36 --> Final output sent to browser
DEBUG - 2019-12-11 10:14:36 --> Total execution time: 1.5487
INFO - 2019-12-11 10:14:45 --> Config Class Initialized
INFO - 2019-12-11 10:14:45 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:14:45 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:14:46 --> Utf8 Class Initialized
INFO - 2019-12-11 10:14:46 --> URI Class Initialized
INFO - 2019-12-11 10:14:46 --> Router Class Initialized
INFO - 2019-12-11 10:14:46 --> Output Class Initialized
INFO - 2019-12-11 10:14:46 --> Security Class Initialized
DEBUG - 2019-12-11 10:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:14:46 --> CSRF cookie sent
INFO - 2019-12-11 10:14:46 --> Input Class Initialized
INFO - 2019-12-11 10:14:46 --> Language Class Initialized
INFO - 2019-12-11 10:14:46 --> Language Class Initialized
INFO - 2019-12-11 10:14:46 --> Config Class Initialized
INFO - 2019-12-11 10:14:46 --> Loader Class Initialized
INFO - 2019-12-11 10:14:46 --> Helper loaded: url_helper
INFO - 2019-12-11 10:14:46 --> Helper loaded: common_helper
INFO - 2019-12-11 10:14:46 --> Helper loaded: language_helper
INFO - 2019-12-11 10:14:46 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:14:46 --> Helper loaded: email_helper
INFO - 2019-12-11 10:14:46 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:14:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:14:46 --> Parser Class Initialized
INFO - 2019-12-11 10:14:46 --> User Agent Class Initialized
INFO - 2019-12-11 10:14:46 --> Model Class Initialized
INFO - 2019-12-11 10:14:46 --> Database Driver Class Initialized
INFO - 2019-12-11 10:14:46 --> Model Class Initialized
DEBUG - 2019-12-11 10:14:46 --> Template Class Initialized
INFO - 2019-12-11 10:14:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:14:46 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:14:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:14:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:14:46 --> Encryption Class Initialized
INFO - 2019-12-11 10:14:46 --> Controller Class Initialized
DEBUG - 2019-12-11 10:14:46 --> package MX_Controller Initialized
DEBUG - 2019-12-11 10:14:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-11 10:14:46 --> Model Class Initialized
INFO - 2019-12-11 10:14:46 --> Helper loaded: inflector_helper
DEBUG - 2019-12-11 10:14:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-11 10:14:46 --> blocks MX_Controller Initialized
DEBUG - 2019-12-11 10:14:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-11 10:14:46 --> Model Class Initialized
DEBUG - 2019-12-11 10:14:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-11 10:14:46 --> Model Class Initialized
DEBUG - 2019-12-11 10:14:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-11 10:14:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-11 10:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-11 10:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-11 10:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-11 10:14:47 --> Final output sent to browser
DEBUG - 2019-12-11 10:14:47 --> Total execution time: 1.2558
INFO - 2019-12-11 10:17:23 --> Config Class Initialized
INFO - 2019-12-11 10:17:23 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:17:23 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:17:23 --> Utf8 Class Initialized
INFO - 2019-12-11 10:17:23 --> URI Class Initialized
INFO - 2019-12-11 10:17:23 --> Router Class Initialized
INFO - 2019-12-11 10:17:23 --> Output Class Initialized
INFO - 2019-12-11 10:17:23 --> Security Class Initialized
DEBUG - 2019-12-11 10:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:17:23 --> CSRF cookie sent
INFO - 2019-12-11 10:17:23 --> Input Class Initialized
INFO - 2019-12-11 10:17:23 --> Language Class Initialized
INFO - 2019-12-11 10:17:23 --> Language Class Initialized
INFO - 2019-12-11 10:17:23 --> Config Class Initialized
INFO - 2019-12-11 10:17:23 --> Loader Class Initialized
INFO - 2019-12-11 10:17:23 --> Helper loaded: url_helper
INFO - 2019-12-11 10:17:23 --> Helper loaded: common_helper
INFO - 2019-12-11 10:17:23 --> Helper loaded: language_helper
INFO - 2019-12-11 10:17:23 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:17:23 --> Helper loaded: email_helper
INFO - 2019-12-11 10:17:23 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:17:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:17:23 --> Parser Class Initialized
INFO - 2019-12-11 10:17:23 --> User Agent Class Initialized
INFO - 2019-12-11 10:17:23 --> Model Class Initialized
INFO - 2019-12-11 10:17:23 --> Database Driver Class Initialized
INFO - 2019-12-11 10:17:23 --> Model Class Initialized
DEBUG - 2019-12-11 10:17:23 --> Template Class Initialized
INFO - 2019-12-11 10:17:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:17:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:17:23 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:17:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:17:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:17:24 --> Encryption Class Initialized
INFO - 2019-12-11 10:17:24 --> Controller Class Initialized
DEBUG - 2019-12-11 10:17:24 --> package MX_Controller Initialized
DEBUG - 2019-12-11 10:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-11 10:17:24 --> Model Class Initialized
INFO - 2019-12-11 10:17:24 --> Helper loaded: inflector_helper
DEBUG - 2019-12-11 10:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-11 10:17:24 --> blocks MX_Controller Initialized
DEBUG - 2019-12-11 10:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-11 10:17:24 --> Model Class Initialized
DEBUG - 2019-12-11 10:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-11 10:17:24 --> Model Class Initialized
DEBUG - 2019-12-11 10:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-11 10:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-11 10:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-11 10:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-11 10:17:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-11 10:17:24 --> Final output sent to browser
DEBUG - 2019-12-11 10:17:24 --> Total execution time: 0.6826
INFO - 2019-12-11 10:17:28 --> Config Class Initialized
INFO - 2019-12-11 10:17:28 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:17:28 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:17:28 --> Utf8 Class Initialized
INFO - 2019-12-11 10:17:28 --> URI Class Initialized
INFO - 2019-12-11 10:17:28 --> Router Class Initialized
INFO - 2019-12-11 10:17:28 --> Output Class Initialized
INFO - 2019-12-11 10:17:28 --> Security Class Initialized
DEBUG - 2019-12-11 10:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:17:28 --> CSRF cookie sent
INFO - 2019-12-11 10:17:28 --> CSRF token verified
INFO - 2019-12-11 10:17:28 --> Input Class Initialized
INFO - 2019-12-11 10:17:28 --> Language Class Initialized
INFO - 2019-12-11 10:17:28 --> Language Class Initialized
INFO - 2019-12-11 10:17:28 --> Config Class Initialized
INFO - 2019-12-11 10:17:28 --> Loader Class Initialized
INFO - 2019-12-11 10:17:28 --> Helper loaded: url_helper
INFO - 2019-12-11 10:17:28 --> Helper loaded: common_helper
INFO - 2019-12-11 10:17:28 --> Helper loaded: language_helper
INFO - 2019-12-11 10:17:28 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:17:28 --> Helper loaded: email_helper
INFO - 2019-12-11 10:17:28 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:17:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:17:28 --> Parser Class Initialized
INFO - 2019-12-11 10:17:28 --> User Agent Class Initialized
INFO - 2019-12-11 10:17:28 --> Model Class Initialized
INFO - 2019-12-11 10:17:28 --> Database Driver Class Initialized
INFO - 2019-12-11 10:17:28 --> Model Class Initialized
DEBUG - 2019-12-11 10:17:28 --> Template Class Initialized
INFO - 2019-12-11 10:17:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:17:28 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:17:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:17:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:17:28 --> Encryption Class Initialized
INFO - 2019-12-11 10:17:28 --> Controller Class Initialized
DEBUG - 2019-12-11 10:17:28 --> checkout MX_Controller Initialized
DEBUG - 2019-12-11 10:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-11 10:17:28 --> Model Class Initialized
INFO - 2019-12-11 10:17:28 --> Helper loaded: inflector_helper
ERROR - 2019-12-11 10:17:28 --> Could not find the language line "hesabe"
ERROR - 2019-12-11 10:17:28 --> Could not find the language line "payop"
ERROR - 2019-12-11 10:17:28 --> Could not find the language line "shopier"
DEBUG - 2019-12-11 10:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-11 10:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-11 10:17:28 --> blocks MX_Controller Initialized
DEBUG - 2019-12-11 10:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-11 10:17:28 --> Model Class Initialized
DEBUG - 2019-12-11 10:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-11 10:17:28 --> Model Class Initialized
DEBUG - 2019-12-11 10:17:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-11 10:17:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-11 10:17:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-11 10:17:29 --> Final output sent to browser
DEBUG - 2019-12-11 10:17:29 --> Total execution time: 0.9159
INFO - 2019-12-11 10:17:36 --> Config Class Initialized
INFO - 2019-12-11 10:17:36 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:17:36 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:17:36 --> Utf8 Class Initialized
INFO - 2019-12-11 10:17:36 --> URI Class Initialized
INFO - 2019-12-11 10:17:36 --> Router Class Initialized
INFO - 2019-12-11 10:17:36 --> Output Class Initialized
INFO - 2019-12-11 10:17:36 --> Security Class Initialized
DEBUG - 2019-12-11 10:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:17:36 --> CSRF cookie sent
INFO - 2019-12-11 10:17:36 --> CSRF token verified
INFO - 2019-12-11 10:17:36 --> Input Class Initialized
INFO - 2019-12-11 10:17:36 --> Language Class Initialized
INFO - 2019-12-11 10:17:36 --> Language Class Initialized
INFO - 2019-12-11 10:17:36 --> Config Class Initialized
INFO - 2019-12-11 10:17:36 --> Loader Class Initialized
INFO - 2019-12-11 10:17:36 --> Helper loaded: url_helper
INFO - 2019-12-11 10:17:36 --> Helper loaded: common_helper
INFO - 2019-12-11 10:17:36 --> Helper loaded: language_helper
INFO - 2019-12-11 10:17:36 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:17:36 --> Helper loaded: email_helper
INFO - 2019-12-11 10:17:36 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:17:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:17:36 --> Parser Class Initialized
INFO - 2019-12-11 10:17:36 --> User Agent Class Initialized
INFO - 2019-12-11 10:17:36 --> Model Class Initialized
INFO - 2019-12-11 10:17:36 --> Database Driver Class Initialized
INFO - 2019-12-11 10:17:36 --> Model Class Initialized
DEBUG - 2019-12-11 10:17:36 --> Template Class Initialized
INFO - 2019-12-11 10:17:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:17:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:17:36 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:17:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:17:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:17:36 --> Encryption Class Initialized
INFO - 2019-12-11 10:17:36 --> Controller Class Initialized
DEBUG - 2019-12-11 10:17:36 --> checkout MX_Controller Initialized
DEBUG - 2019-12-11 10:17:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-11 10:17:36 --> Model Class Initialized
DEBUG - 2019-12-11 10:17:36 --> dotpay MX_Controller Initialized
DEBUG - 2019-12-11 10:17:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-12-11 10:17:36 --> Final output sent to browser
DEBUG - 2019-12-11 10:17:36 --> Total execution time: 0.5349
INFO - 2019-12-11 10:18:01 --> Config Class Initialized
INFO - 2019-12-11 10:18:01 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:18:01 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:18:01 --> Utf8 Class Initialized
INFO - 2019-12-11 10:18:01 --> URI Class Initialized
INFO - 2019-12-11 10:18:01 --> Router Class Initialized
INFO - 2019-12-11 10:18:01 --> Output Class Initialized
INFO - 2019-12-11 10:18:01 --> Security Class Initialized
DEBUG - 2019-12-11 10:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:18:02 --> Input Class Initialized
INFO - 2019-12-11 10:18:02 --> Language Class Initialized
INFO - 2019-12-11 10:18:02 --> Language Class Initialized
INFO - 2019-12-11 10:18:02 --> Config Class Initialized
INFO - 2019-12-11 10:18:02 --> Loader Class Initialized
INFO - 2019-12-11 10:18:02 --> Helper loaded: url_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: common_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: language_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: email_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:18:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:18:02 --> Parser Class Initialized
INFO - 2019-12-11 10:18:02 --> User Agent Class Initialized
INFO - 2019-12-11 10:18:02 --> Model Class Initialized
INFO - 2019-12-11 10:18:02 --> Database Driver Class Initialized
INFO - 2019-12-11 10:18:02 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:02 --> Template Class Initialized
INFO - 2019-12-11 10:18:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:18:02 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:18:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:18:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:18:02 --> Encryption Class Initialized
INFO - 2019-12-11 10:18:02 --> Controller Class Initialized
DEBUG - 2019-12-11 10:18:02 --> dotpay MX_Controller Initialized
INFO - 2019-12-11 10:18:02 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:02 --> orders MX_Controller Initialized
INFO - 2019-12-11 10:18:02 --> Config Class Initialized
INFO - 2019-12-11 10:18:02 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:18:02 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:18:02 --> Utf8 Class Initialized
INFO - 2019-12-11 10:18:02 --> URI Class Initialized
INFO - 2019-12-11 10:18:02 --> Router Class Initialized
INFO - 2019-12-11 10:18:02 --> Output Class Initialized
INFO - 2019-12-11 10:18:02 --> Security Class Initialized
DEBUG - 2019-12-11 10:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:18:02 --> CSRF cookie sent
INFO - 2019-12-11 10:18:02 --> Input Class Initialized
INFO - 2019-12-11 10:18:02 --> Language Class Initialized
INFO - 2019-12-11 10:18:02 --> Language Class Initialized
INFO - 2019-12-11 10:18:02 --> Config Class Initialized
INFO - 2019-12-11 10:18:02 --> Loader Class Initialized
INFO - 2019-12-11 10:18:02 --> Helper loaded: url_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: common_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: language_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: email_helper
INFO - 2019-12-11 10:18:02 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:18:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:18:02 --> Parser Class Initialized
INFO - 2019-12-11 10:18:02 --> User Agent Class Initialized
INFO - 2019-12-11 10:18:02 --> Model Class Initialized
INFO - 2019-12-11 10:18:02 --> Database Driver Class Initialized
INFO - 2019-12-11 10:18:02 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:02 --> Template Class Initialized
INFO - 2019-12-11 10:18:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:18:02 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:18:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:18:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:18:02 --> Encryption Class Initialized
INFO - 2019-12-11 10:18:02 --> Controller Class Initialized
DEBUG - 2019-12-11 10:18:02 --> checkout MX_Controller Initialized
DEBUG - 2019-12-11 10:18:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-11 10:18:02 --> Model Class Initialized
INFO - 2019-12-11 10:18:02 --> Helper loaded: inflector_helper
DEBUG - 2019-12-11 10:18:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-12-11 10:18:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-11 10:18:02 --> blocks MX_Controller Initialized
DEBUG - 2019-12-11 10:18:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-11 10:18:02 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-11 10:18:02 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-11 10:18:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-11 10:18:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-11 10:18:02 --> Final output sent to browser
DEBUG - 2019-12-11 10:18:02 --> Total execution time: 0.5939
INFO - 2019-12-11 10:18:21 --> Config Class Initialized
INFO - 2019-12-11 10:18:21 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:18:21 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:18:21 --> Utf8 Class Initialized
INFO - 2019-12-11 10:18:21 --> URI Class Initialized
INFO - 2019-12-11 10:18:21 --> Router Class Initialized
INFO - 2019-12-11 10:18:21 --> Output Class Initialized
INFO - 2019-12-11 10:18:21 --> Security Class Initialized
DEBUG - 2019-12-11 10:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:18:21 --> CSRF cookie sent
INFO - 2019-12-11 10:18:21 --> Input Class Initialized
INFO - 2019-12-11 10:18:21 --> Language Class Initialized
INFO - 2019-12-11 10:18:21 --> Language Class Initialized
INFO - 2019-12-11 10:18:21 --> Config Class Initialized
INFO - 2019-12-11 10:18:21 --> Loader Class Initialized
INFO - 2019-12-11 10:18:21 --> Helper loaded: url_helper
INFO - 2019-12-11 10:18:21 --> Helper loaded: common_helper
INFO - 2019-12-11 10:18:21 --> Helper loaded: language_helper
INFO - 2019-12-11 10:18:21 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:18:21 --> Helper loaded: email_helper
INFO - 2019-12-11 10:18:21 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:18:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:18:21 --> Parser Class Initialized
INFO - 2019-12-11 10:18:21 --> User Agent Class Initialized
INFO - 2019-12-11 10:18:21 --> Model Class Initialized
INFO - 2019-12-11 10:18:21 --> Database Driver Class Initialized
INFO - 2019-12-11 10:18:21 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:21 --> Template Class Initialized
INFO - 2019-12-11 10:18:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:18:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:18:21 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:18:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:18:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:18:21 --> Encryption Class Initialized
INFO - 2019-12-11 10:18:21 --> Controller Class Initialized
DEBUG - 2019-12-11 10:18:21 --> auth MX_Controller Initialized
DEBUG - 2019-12-11 10:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-11 10:18:21 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-11 10:18:21 --> Helper loaded: inflector_helper
DEBUG - 2019-12-11 10:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-12-11 10:18:21 --> pergo MX_Controller Initialized
DEBUG - 2019-12-11 10:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-11 10:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-12-11 10:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-11 10:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-11 10:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-12-11 10:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-11 10:18:21 --> Final output sent to browser
DEBUG - 2019-12-11 10:18:21 --> Total execution time: 0.6114
INFO - 2019-12-11 10:18:24 --> Config Class Initialized
INFO - 2019-12-11 10:18:24 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:18:25 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:18:25 --> Utf8 Class Initialized
INFO - 2019-12-11 10:18:25 --> URI Class Initialized
INFO - 2019-12-11 10:18:25 --> Router Class Initialized
INFO - 2019-12-11 10:18:25 --> Output Class Initialized
INFO - 2019-12-11 10:18:25 --> Security Class Initialized
DEBUG - 2019-12-11 10:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:18:25 --> CSRF cookie sent
INFO - 2019-12-11 10:18:25 --> CSRF token verified
INFO - 2019-12-11 10:18:25 --> Input Class Initialized
INFO - 2019-12-11 10:18:25 --> Language Class Initialized
INFO - 2019-12-11 10:18:25 --> Language Class Initialized
INFO - 2019-12-11 10:18:25 --> Config Class Initialized
INFO - 2019-12-11 10:18:25 --> Loader Class Initialized
INFO - 2019-12-11 10:18:25 --> Helper loaded: url_helper
INFO - 2019-12-11 10:18:25 --> Helper loaded: common_helper
INFO - 2019-12-11 10:18:25 --> Helper loaded: language_helper
INFO - 2019-12-11 10:18:25 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:18:25 --> Helper loaded: email_helper
INFO - 2019-12-11 10:18:25 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:18:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:18:25 --> Parser Class Initialized
INFO - 2019-12-11 10:18:25 --> User Agent Class Initialized
INFO - 2019-12-11 10:18:25 --> Model Class Initialized
INFO - 2019-12-11 10:18:25 --> Database Driver Class Initialized
INFO - 2019-12-11 10:18:25 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:25 --> Template Class Initialized
INFO - 2019-12-11 10:18:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:18:25 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:18:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:18:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:18:25 --> Encryption Class Initialized
INFO - 2019-12-11 10:18:25 --> Controller Class Initialized
DEBUG - 2019-12-11 10:18:25 --> auth MX_Controller Initialized
DEBUG - 2019-12-11 10:18:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-11 10:18:25 --> Model Class Initialized
INFO - 2019-12-11 10:18:30 --> Config Class Initialized
INFO - 2019-12-11 10:18:30 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:18:30 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:18:30 --> Utf8 Class Initialized
INFO - 2019-12-11 10:18:30 --> URI Class Initialized
INFO - 2019-12-11 10:18:30 --> Router Class Initialized
INFO - 2019-12-11 10:18:30 --> Output Class Initialized
INFO - 2019-12-11 10:18:30 --> Security Class Initialized
DEBUG - 2019-12-11 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:18:30 --> CSRF cookie sent
INFO - 2019-12-11 10:18:30 --> Input Class Initialized
INFO - 2019-12-11 10:18:30 --> Language Class Initialized
INFO - 2019-12-11 10:18:30 --> Language Class Initialized
INFO - 2019-12-11 10:18:30 --> Config Class Initialized
INFO - 2019-12-11 10:18:30 --> Loader Class Initialized
INFO - 2019-12-11 10:18:30 --> Helper loaded: url_helper
INFO - 2019-12-11 10:18:30 --> Helper loaded: common_helper
INFO - 2019-12-11 10:18:30 --> Helper loaded: language_helper
INFO - 2019-12-11 10:18:30 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:18:30 --> Helper loaded: email_helper
INFO - 2019-12-11 10:18:30 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:18:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:18:30 --> Parser Class Initialized
INFO - 2019-12-11 10:18:30 --> User Agent Class Initialized
INFO - 2019-12-11 10:18:30 --> Model Class Initialized
INFO - 2019-12-11 10:18:30 --> Database Driver Class Initialized
INFO - 2019-12-11 10:18:30 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:30 --> Template Class Initialized
INFO - 2019-12-11 10:18:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:18:30 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:18:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:18:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:18:30 --> Encryption Class Initialized
INFO - 2019-12-11 10:18:30 --> Controller Class Initialized
DEBUG - 2019-12-11 10:18:30 --> statistics MX_Controller Initialized
DEBUG - 2019-12-11 10:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-11 10:18:30 --> Model Class Initialized
ERROR - 2019-12-11 10:18:30 --> Could not find the language line "Pending"
ERROR - 2019-12-11 10:18:30 --> Could not find the language line "Pending"
INFO - 2019-12-11 10:18:30 --> Helper loaded: inflector_helper
ERROR - 2019-12-11 10:18:30 --> Could not find the language line "total_orders"
ERROR - 2019-12-11 10:18:30 --> Could not find the language line "total_orders"
ERROR - 2019-12-11 10:18:30 --> Could not find the language line "Pending"
DEBUG - 2019-12-11 10:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-12-11 10:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-11 10:18:30 --> blocks MX_Controller Initialized
DEBUG - 2019-12-11 10:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-11 10:18:30 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-11 10:18:30 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-11 10:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-11 10:18:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-11 10:18:30 --> Final output sent to browser
DEBUG - 2019-12-11 10:18:30 --> Total execution time: 0.9216
INFO - 2019-12-11 10:18:33 --> Config Class Initialized
INFO - 2019-12-11 10:18:33 --> Hooks Class Initialized
DEBUG - 2019-12-11 10:18:33 --> UTF-8 Support Enabled
INFO - 2019-12-11 10:18:33 --> Utf8 Class Initialized
INFO - 2019-12-11 10:18:33 --> URI Class Initialized
INFO - 2019-12-11 10:18:33 --> Router Class Initialized
INFO - 2019-12-11 10:18:33 --> Output Class Initialized
INFO - 2019-12-11 10:18:33 --> Security Class Initialized
DEBUG - 2019-12-11 10:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-11 10:18:33 --> CSRF cookie sent
INFO - 2019-12-11 10:18:33 --> Input Class Initialized
INFO - 2019-12-11 10:18:33 --> Language Class Initialized
INFO - 2019-12-11 10:18:33 --> Language Class Initialized
INFO - 2019-12-11 10:18:33 --> Config Class Initialized
INFO - 2019-12-11 10:18:34 --> Loader Class Initialized
INFO - 2019-12-11 10:18:34 --> Helper loaded: url_helper
INFO - 2019-12-11 10:18:34 --> Helper loaded: common_helper
INFO - 2019-12-11 10:18:34 --> Helper loaded: language_helper
INFO - 2019-12-11 10:18:34 --> Helper loaded: cookie_helper
INFO - 2019-12-11 10:18:34 --> Helper loaded: email_helper
INFO - 2019-12-11 10:18:34 --> Helper loaded: file_manager_helper
INFO - 2019-12-11 10:18:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-11 10:18:34 --> Parser Class Initialized
INFO - 2019-12-11 10:18:34 --> User Agent Class Initialized
INFO - 2019-12-11 10:18:34 --> Model Class Initialized
INFO - 2019-12-11 10:18:34 --> Database Driver Class Initialized
INFO - 2019-12-11 10:18:34 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:34 --> Template Class Initialized
INFO - 2019-12-11 10:18:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-11 10:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-11 10:18:34 --> Pagination Class Initialized
DEBUG - 2019-12-11 10:18:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-11 10:18:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-11 10:18:34 --> Encryption Class Initialized
INFO - 2019-12-11 10:18:34 --> Controller Class Initialized
DEBUG - 2019-12-11 10:18:34 --> transactions MX_Controller Initialized
DEBUG - 2019-12-11 10:18:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-11 10:18:34 --> Model Class Initialized
ERROR - 2019-12-11 10:18:34 --> Could not find the language line "order_id"
INFO - 2019-12-11 10:18:34 --> Helper loaded: inflector_helper
DEBUG - 2019-12-11 10:18:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-11 10:18:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-11 10:18:34 --> blocks MX_Controller Initialized
DEBUG - 2019-12-11 10:18:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-11 10:18:34 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-11 10:18:34 --> Model Class Initialized
DEBUG - 2019-12-11 10:18:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-11 10:18:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-11 10:18:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-11 10:18:34 --> Final output sent to browser
DEBUG - 2019-12-11 10:18:34 --> Total execution time: 0.6670
