<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-31 11:11:01 --> Config Class Initialized
INFO - 2020-03-31 11:11:01 --> Hooks Class Initialized
DEBUG - 2020-03-31 11:11:01 --> UTF-8 Support Enabled
INFO - 2020-03-31 11:11:01 --> Utf8 Class Initialized
INFO - 2020-03-31 11:11:01 --> URI Class Initialized
DEBUG - 2020-03-31 11:11:01 --> No URI present. Default controller set.
INFO - 2020-03-31 11:11:01 --> Router Class Initialized
INFO - 2020-03-31 11:11:01 --> Output Class Initialized
INFO - 2020-03-31 11:11:01 --> Security Class Initialized
DEBUG - 2020-03-31 11:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 11:11:01 --> CSRF cookie sent
INFO - 2020-03-31 11:11:01 --> Input Class Initialized
INFO - 2020-03-31 11:11:01 --> Language Class Initialized
INFO - 2020-03-31 11:11:02 --> Language Class Initialized
INFO - 2020-03-31 11:11:02 --> Config Class Initialized
INFO - 2020-03-31 11:11:02 --> Loader Class Initialized
INFO - 2020-03-31 11:11:02 --> Helper loaded: url_helper
INFO - 2020-03-31 11:11:02 --> Helper loaded: common_helper
INFO - 2020-03-31 11:11:02 --> Helper loaded: language_helper
INFO - 2020-03-31 11:11:02 --> Helper loaded: cookie_helper
INFO - 2020-03-31 11:11:02 --> Helper loaded: email_helper
INFO - 2020-03-31 11:11:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 11:11:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 11:11:02 --> Parser Class Initialized
INFO - 2020-03-31 11:11:02 --> User Agent Class Initialized
INFO - 2020-03-31 11:11:02 --> Model Class Initialized
INFO - 2020-03-31 11:11:02 --> Database Driver Class Initialized
INFO - 2020-03-31 11:11:02 --> Model Class Initialized
DEBUG - 2020-03-31 11:11:02 --> Template Class Initialized
INFO - 2020-03-31 11:11:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 11:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 11:11:02 --> Pagination Class Initialized
DEBUG - 2020-03-31 11:11:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 11:11:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 11:11:02 --> Encryption Class Initialized
DEBUG - 2020-03-31 11:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 11:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-31 11:11:02 --> Controller Class Initialized
DEBUG - 2020-03-31 11:11:02 --> pergo MX_Controller Initialized
DEBUG - 2020-03-31 11:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 11:11:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-31 11:11:02 --> Model Class Initialized
INFO - 2020-03-31 11:11:02 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 11:11:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-31 11:11:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-31 11:11:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-31 11:11:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-31 11:11:03 --> Final output sent to browser
DEBUG - 2020-03-31 11:11:03 --> Total execution time: 1.8575
INFO - 2020-03-31 11:22:57 --> Config Class Initialized
INFO - 2020-03-31 11:22:57 --> Hooks Class Initialized
DEBUG - 2020-03-31 11:22:57 --> UTF-8 Support Enabled
INFO - 2020-03-31 11:22:57 --> Utf8 Class Initialized
INFO - 2020-03-31 11:22:57 --> URI Class Initialized
DEBUG - 2020-03-31 11:22:57 --> No URI present. Default controller set.
INFO - 2020-03-31 11:22:57 --> Router Class Initialized
INFO - 2020-03-31 11:22:57 --> Output Class Initialized
INFO - 2020-03-31 11:22:57 --> Security Class Initialized
DEBUG - 2020-03-31 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 11:22:57 --> CSRF cookie sent
INFO - 2020-03-31 11:22:57 --> Input Class Initialized
INFO - 2020-03-31 11:22:57 --> Language Class Initialized
INFO - 2020-03-31 11:22:57 --> Language Class Initialized
INFO - 2020-03-31 11:22:57 --> Config Class Initialized
INFO - 2020-03-31 11:22:57 --> Loader Class Initialized
INFO - 2020-03-31 11:22:57 --> Helper loaded: url_helper
INFO - 2020-03-31 11:22:57 --> Helper loaded: common_helper
INFO - 2020-03-31 11:22:57 --> Helper loaded: language_helper
INFO - 2020-03-31 11:22:57 --> Helper loaded: cookie_helper
INFO - 2020-03-31 11:22:57 --> Helper loaded: email_helper
INFO - 2020-03-31 11:22:57 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 11:22:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 11:22:57 --> Parser Class Initialized
INFO - 2020-03-31 11:22:57 --> User Agent Class Initialized
INFO - 2020-03-31 11:22:57 --> Model Class Initialized
INFO - 2020-03-31 11:22:57 --> Database Driver Class Initialized
INFO - 2020-03-31 11:22:57 --> Model Class Initialized
DEBUG - 2020-03-31 11:22:57 --> Template Class Initialized
INFO - 2020-03-31 11:22:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 11:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 11:22:57 --> Pagination Class Initialized
DEBUG - 2020-03-31 11:22:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 11:22:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 11:22:57 --> Encryption Class Initialized
DEBUG - 2020-03-31 11:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 11:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-31 11:22:57 --> Controller Class Initialized
DEBUG - 2020-03-31 11:22:57 --> pergo MX_Controller Initialized
DEBUG - 2020-03-31 11:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 11:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-31 11:22:57 --> Model Class Initialized
INFO - 2020-03-31 11:22:57 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 11:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-31 11:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-31 11:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-31 11:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-31 11:22:57 --> Final output sent to browser
DEBUG - 2020-03-31 11:22:57 --> Total execution time: 0.5887
INFO - 2020-03-31 15:21:02 --> Config Class Initialized
INFO - 2020-03-31 15:21:02 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:21:02 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:21:02 --> Utf8 Class Initialized
INFO - 2020-03-31 15:21:02 --> URI Class Initialized
DEBUG - 2020-03-31 15:21:02 --> No URI present. Default controller set.
INFO - 2020-03-31 15:21:02 --> Router Class Initialized
INFO - 2020-03-31 15:21:02 --> Output Class Initialized
INFO - 2020-03-31 15:21:02 --> Security Class Initialized
DEBUG - 2020-03-31 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:21:02 --> CSRF cookie sent
INFO - 2020-03-31 15:21:02 --> Input Class Initialized
INFO - 2020-03-31 15:21:02 --> Language Class Initialized
INFO - 2020-03-31 15:21:02 --> Language Class Initialized
INFO - 2020-03-31 15:21:02 --> Config Class Initialized
INFO - 2020-03-31 15:21:02 --> Loader Class Initialized
INFO - 2020-03-31 15:21:02 --> Helper loaded: url_helper
INFO - 2020-03-31 15:21:02 --> Helper loaded: common_helper
INFO - 2020-03-31 15:21:02 --> Helper loaded: language_helper
INFO - 2020-03-31 15:21:02 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:21:02 --> Helper loaded: email_helper
INFO - 2020-03-31 15:21:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:21:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:21:02 --> Parser Class Initialized
INFO - 2020-03-31 15:21:02 --> User Agent Class Initialized
INFO - 2020-03-31 15:21:02 --> Model Class Initialized
INFO - 2020-03-31 15:21:02 --> Database Driver Class Initialized
INFO - 2020-03-31 15:21:02 --> Model Class Initialized
DEBUG - 2020-03-31 15:21:02 --> Template Class Initialized
INFO - 2020-03-31 15:21:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:21:02 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:21:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:21:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:21:03 --> Encryption Class Initialized
DEBUG - 2020-03-31 15:21:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 15:21:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-31 15:21:03 --> Controller Class Initialized
DEBUG - 2020-03-31 15:21:03 --> pergo MX_Controller Initialized
DEBUG - 2020-03-31 15:21:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 15:21:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-31 15:21:03 --> Model Class Initialized
INFO - 2020-03-31 15:21:03 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:21:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-31 15:21:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-31 15:21:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-31 15:21:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-31 15:21:03 --> Final output sent to browser
DEBUG - 2020-03-31 15:21:03 --> Total execution time: 1.4959
INFO - 2020-03-31 15:21:08 --> Config Class Initialized
INFO - 2020-03-31 15:21:08 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:21:08 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:21:08 --> Utf8 Class Initialized
INFO - 2020-03-31 15:21:08 --> URI Class Initialized
INFO - 2020-03-31 15:21:08 --> Router Class Initialized
INFO - 2020-03-31 15:21:08 --> Output Class Initialized
INFO - 2020-03-31 15:21:08 --> Security Class Initialized
DEBUG - 2020-03-31 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:21:08 --> CSRF cookie sent
INFO - 2020-03-31 15:21:08 --> Input Class Initialized
INFO - 2020-03-31 15:21:08 --> Language Class Initialized
INFO - 2020-03-31 15:21:08 --> Language Class Initialized
INFO - 2020-03-31 15:21:08 --> Config Class Initialized
INFO - 2020-03-31 15:21:08 --> Loader Class Initialized
INFO - 2020-03-31 15:21:08 --> Helper loaded: url_helper
INFO - 2020-03-31 15:21:08 --> Helper loaded: common_helper
INFO - 2020-03-31 15:21:08 --> Helper loaded: language_helper
INFO - 2020-03-31 15:21:08 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:21:08 --> Helper loaded: email_helper
INFO - 2020-03-31 15:21:08 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:21:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:21:08 --> Parser Class Initialized
INFO - 2020-03-31 15:21:08 --> User Agent Class Initialized
INFO - 2020-03-31 15:21:08 --> Model Class Initialized
INFO - 2020-03-31 15:21:08 --> Database Driver Class Initialized
INFO - 2020-03-31 15:21:08 --> Model Class Initialized
DEBUG - 2020-03-31 15:21:08 --> Template Class Initialized
INFO - 2020-03-31 15:21:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:21:08 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:21:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:21:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:21:08 --> Encryption Class Initialized
INFO - 2020-03-31 15:21:08 --> Controller Class Initialized
DEBUG - 2020-03-31 15:21:08 --> package MX_Controller Initialized
DEBUG - 2020-03-31 15:21:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-31 15:21:08 --> Model Class Initialized
INFO - 2020-03-31 15:21:08 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:21:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:21:08 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:21:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:21:08 --> Model Class Initialized
DEBUG - 2020-03-31 15:21:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:21:08 --> Model Class Initialized
DEBUG - 2020-03-31 15:21:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-31 15:21:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-31 15:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 15:21:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 15:21:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 15:21:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 15:21:09 --> Final output sent to browser
DEBUG - 2020-03-31 15:21:09 --> Total execution time: 1.0788
INFO - 2020-03-31 15:21:13 --> Config Class Initialized
INFO - 2020-03-31 15:21:13 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:21:13 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:21:13 --> Utf8 Class Initialized
INFO - 2020-03-31 15:21:13 --> URI Class Initialized
INFO - 2020-03-31 15:21:13 --> Router Class Initialized
INFO - 2020-03-31 15:21:13 --> Output Class Initialized
INFO - 2020-03-31 15:21:13 --> Security Class Initialized
DEBUG - 2020-03-31 15:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:21:13 --> CSRF cookie sent
INFO - 2020-03-31 15:21:13 --> CSRF token verified
INFO - 2020-03-31 15:21:13 --> Input Class Initialized
INFO - 2020-03-31 15:21:13 --> Language Class Initialized
INFO - 2020-03-31 15:21:14 --> Language Class Initialized
INFO - 2020-03-31 15:21:14 --> Config Class Initialized
INFO - 2020-03-31 15:21:14 --> Loader Class Initialized
INFO - 2020-03-31 15:21:14 --> Helper loaded: url_helper
INFO - 2020-03-31 15:21:14 --> Helper loaded: common_helper
INFO - 2020-03-31 15:21:14 --> Helper loaded: language_helper
INFO - 2020-03-31 15:21:14 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:21:14 --> Helper loaded: email_helper
INFO - 2020-03-31 15:21:14 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:21:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:21:14 --> Parser Class Initialized
INFO - 2020-03-31 15:21:14 --> User Agent Class Initialized
INFO - 2020-03-31 15:21:14 --> Model Class Initialized
INFO - 2020-03-31 15:21:14 --> Database Driver Class Initialized
INFO - 2020-03-31 15:21:14 --> Model Class Initialized
DEBUG - 2020-03-31 15:21:14 --> Template Class Initialized
INFO - 2020-03-31 15:21:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:21:14 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:21:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:21:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:21:14 --> Encryption Class Initialized
INFO - 2020-03-31 15:21:14 --> Controller Class Initialized
DEBUG - 2020-03-31 15:21:14 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 15:21:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 15:21:14 --> Model Class Initialized
INFO - 2020-03-31 15:21:14 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 15:21:14 --> Could not find the language line "shopier"
DEBUG - 2020-03-31 15:21:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-31 15:21:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:21:14 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:21:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:21:14 --> Model Class Initialized
DEBUG - 2020-03-31 15:21:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:21:14 --> Model Class Initialized
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:21:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 15:21:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 15:21:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 15:21:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 15:21:14 --> Final output sent to browser
DEBUG - 2020-03-31 15:21:14 --> Total execution time: 0.8845
INFO - 2020-03-31 15:21:38 --> Config Class Initialized
INFO - 2020-03-31 15:21:38 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:21:39 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:21:39 --> Utf8 Class Initialized
INFO - 2020-03-31 15:21:39 --> URI Class Initialized
INFO - 2020-03-31 15:21:39 --> Router Class Initialized
INFO - 2020-03-31 15:21:39 --> Output Class Initialized
INFO - 2020-03-31 15:21:39 --> Security Class Initialized
DEBUG - 2020-03-31 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:21:39 --> CSRF cookie sent
INFO - 2020-03-31 15:21:39 --> CSRF token verified
INFO - 2020-03-31 15:21:39 --> Input Class Initialized
INFO - 2020-03-31 15:21:39 --> Language Class Initialized
INFO - 2020-03-31 15:21:39 --> Language Class Initialized
INFO - 2020-03-31 15:21:39 --> Config Class Initialized
INFO - 2020-03-31 15:21:39 --> Loader Class Initialized
INFO - 2020-03-31 15:21:39 --> Helper loaded: url_helper
INFO - 2020-03-31 15:21:39 --> Helper loaded: common_helper
INFO - 2020-03-31 15:21:39 --> Helper loaded: language_helper
INFO - 2020-03-31 15:21:39 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:21:39 --> Helper loaded: email_helper
INFO - 2020-03-31 15:21:39 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:21:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:21:39 --> Parser Class Initialized
INFO - 2020-03-31 15:21:39 --> User Agent Class Initialized
INFO - 2020-03-31 15:21:39 --> Model Class Initialized
INFO - 2020-03-31 15:21:39 --> Database Driver Class Initialized
INFO - 2020-03-31 15:21:39 --> Model Class Initialized
DEBUG - 2020-03-31 15:21:39 --> Template Class Initialized
INFO - 2020-03-31 15:21:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:21:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:21:39 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:21:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:21:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:21:39 --> Encryption Class Initialized
INFO - 2020-03-31 15:21:39 --> Controller Class Initialized
DEBUG - 2020-03-31 15:21:39 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 15:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 15:21:39 --> Model Class Initialized
DEBUG - 2020-03-31 15:21:39 --> payop MX_Controller Initialized
DEBUG - 2020-03-31 15:21:40 --> orders MX_Controller Initialized
DEBUG - 2020-03-31 15:21:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payop/index.php
INFO - 2020-03-31 15:21:40 --> Final output sent to browser
DEBUG - 2020-03-31 15:21:40 --> Total execution time: 1.8844
INFO - 2020-03-31 15:22:27 --> Config Class Initialized
INFO - 2020-03-31 15:22:27 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:22:27 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:22:27 --> Utf8 Class Initialized
INFO - 2020-03-31 15:22:27 --> URI Class Initialized
INFO - 2020-03-31 15:22:27 --> Router Class Initialized
INFO - 2020-03-31 15:22:27 --> Output Class Initialized
INFO - 2020-03-31 15:22:27 --> Security Class Initialized
DEBUG - 2020-03-31 15:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:22:27 --> CSRF cookie sent
INFO - 2020-03-31 15:22:27 --> CSRF token verified
INFO - 2020-03-31 15:22:27 --> Input Class Initialized
INFO - 2020-03-31 15:22:27 --> Language Class Initialized
INFO - 2020-03-31 15:22:27 --> Language Class Initialized
INFO - 2020-03-31 15:22:27 --> Config Class Initialized
INFO - 2020-03-31 15:22:27 --> Loader Class Initialized
INFO - 2020-03-31 15:22:27 --> Helper loaded: url_helper
INFO - 2020-03-31 15:22:27 --> Helper loaded: common_helper
INFO - 2020-03-31 15:22:27 --> Helper loaded: language_helper
INFO - 2020-03-31 15:22:27 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:22:27 --> Helper loaded: email_helper
INFO - 2020-03-31 15:22:27 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:22:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:22:27 --> Parser Class Initialized
INFO - 2020-03-31 15:22:27 --> User Agent Class Initialized
INFO - 2020-03-31 15:22:27 --> Model Class Initialized
INFO - 2020-03-31 15:22:27 --> Database Driver Class Initialized
INFO - 2020-03-31 15:22:27 --> Model Class Initialized
DEBUG - 2020-03-31 15:22:27 --> Template Class Initialized
INFO - 2020-03-31 15:22:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:22:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:22:27 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:22:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:22:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:22:27 --> Encryption Class Initialized
INFO - 2020-03-31 15:22:27 --> Controller Class Initialized
DEBUG - 2020-03-31 15:22:27 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 15:22:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 15:22:27 --> Model Class Initialized
DEBUG - 2020-03-31 15:22:27 --> paypal MX_Controller Initialized
DEBUG - 2020-03-31 15:22:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paypalapi.php
DEBUG - 2020-03-31 15:22:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paypal/index.php
INFO - 2020-03-31 15:22:31 --> Final output sent to browser
DEBUG - 2020-03-31 15:22:31 --> Total execution time: 4.2630
INFO - 2020-03-31 15:23:37 --> Config Class Initialized
INFO - 2020-03-31 15:23:37 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:23:37 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:23:37 --> Utf8 Class Initialized
INFO - 2020-03-31 15:23:37 --> URI Class Initialized
INFO - 2020-03-31 15:23:37 --> Router Class Initialized
INFO - 2020-03-31 15:23:37 --> Output Class Initialized
INFO - 2020-03-31 15:23:37 --> Security Class Initialized
DEBUG - 2020-03-31 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:23:37 --> CSRF cookie sent
INFO - 2020-03-31 15:23:37 --> CSRF token verified
INFO - 2020-03-31 15:23:37 --> Input Class Initialized
INFO - 2020-03-31 15:23:38 --> Language Class Initialized
INFO - 2020-03-31 15:23:38 --> Language Class Initialized
INFO - 2020-03-31 15:23:38 --> Config Class Initialized
INFO - 2020-03-31 15:23:38 --> Loader Class Initialized
INFO - 2020-03-31 15:23:38 --> Helper loaded: url_helper
INFO - 2020-03-31 15:23:38 --> Helper loaded: common_helper
INFO - 2020-03-31 15:23:38 --> Helper loaded: language_helper
INFO - 2020-03-31 15:23:38 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:23:38 --> Helper loaded: email_helper
INFO - 2020-03-31 15:23:38 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:23:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:23:38 --> Parser Class Initialized
INFO - 2020-03-31 15:23:38 --> User Agent Class Initialized
INFO - 2020-03-31 15:23:38 --> Model Class Initialized
INFO - 2020-03-31 15:23:38 --> Database Driver Class Initialized
INFO - 2020-03-31 15:23:38 --> Model Class Initialized
DEBUG - 2020-03-31 15:23:38 --> Template Class Initialized
INFO - 2020-03-31 15:23:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:23:38 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:23:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:23:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:23:38 --> Encryption Class Initialized
INFO - 2020-03-31 15:23:38 --> Controller Class Initialized
DEBUG - 2020-03-31 15:23:38 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 15:23:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 15:23:38 --> Model Class Initialized
DEBUG - 2020-03-31 15:23:38 --> cardinity MX_Controller Initialized
DEBUG - 2020-03-31 15:23:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/index.php
INFO - 2020-03-31 15:23:38 --> Final output sent to browser
DEBUG - 2020-03-31 15:23:38 --> Total execution time: 0.5047
INFO - 2020-03-31 15:23:53 --> Config Class Initialized
INFO - 2020-03-31 15:23:53 --> Hooks Class Initialized
INFO - 2020-03-31 15:23:53 --> Config Class Initialized
DEBUG - 2020-03-31 15:23:53 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:23:53 --> Utf8 Class Initialized
INFO - 2020-03-31 15:23:53 --> Hooks Class Initialized
INFO - 2020-03-31 15:23:53 --> URI Class Initialized
DEBUG - 2020-03-31 15:23:53 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:23:53 --> Utf8 Class Initialized
INFO - 2020-03-31 15:23:53 --> Router Class Initialized
INFO - 2020-03-31 15:23:53 --> URI Class Initialized
INFO - 2020-03-31 15:23:53 --> Output Class Initialized
INFO - 2020-03-31 15:23:53 --> Security Class Initialized
INFO - 2020-03-31 15:23:53 --> Router Class Initialized
DEBUG - 2020-03-31 15:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:23:53 --> Output Class Initialized
INFO - 2020-03-31 15:23:53 --> Input Class Initialized
INFO - 2020-03-31 15:23:53 --> Security Class Initialized
INFO - 2020-03-31 15:23:53 --> Language Class Initialized
DEBUG - 2020-03-31 15:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:23:53 --> Input Class Initialized
INFO - 2020-03-31 15:23:53 --> Language Class Initialized
INFO - 2020-03-31 15:23:53 --> Config Class Initialized
INFO - 2020-03-31 15:23:53 --> Language Class Initialized
INFO - 2020-03-31 15:23:53 --> Language Class Initialized
INFO - 2020-03-31 15:23:53 --> Loader Class Initialized
INFO - 2020-03-31 15:23:53 --> Config Class Initialized
INFO - 2020-03-31 15:23:53 --> Helper loaded: url_helper
INFO - 2020-03-31 15:23:53 --> Helper loaded: common_helper
INFO - 2020-03-31 15:23:53 --> Loader Class Initialized
INFO - 2020-03-31 15:23:53 --> Helper loaded: language_helper
INFO - 2020-03-31 15:23:53 --> Helper loaded: url_helper
INFO - 2020-03-31 15:23:54 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:23:54 --> Helper loaded: common_helper
INFO - 2020-03-31 15:23:54 --> Helper loaded: email_helper
INFO - 2020-03-31 15:23:54 --> Helper loaded: language_helper
INFO - 2020-03-31 15:23:54 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:23:54 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:23:54 --> Helper loaded: email_helper
INFO - 2020-03-31 15:23:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:23:54 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:23:54 --> Parser Class Initialized
INFO - 2020-03-31 15:23:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:23:54 --> User Agent Class Initialized
INFO - 2020-03-31 15:23:54 --> Model Class Initialized
INFO - 2020-03-31 15:23:54 --> Parser Class Initialized
INFO - 2020-03-31 15:23:54 --> User Agent Class Initialized
INFO - 2020-03-31 15:23:54 --> Database Driver Class Initialized
INFO - 2020-03-31 15:23:54 --> Model Class Initialized
INFO - 2020-03-31 15:23:54 --> Model Class Initialized
INFO - 2020-03-31 15:23:54 --> Database Driver Class Initialized
DEBUG - 2020-03-31 15:23:54 --> Template Class Initialized
INFO - 2020-03-31 15:23:54 --> Model Class Initialized
DEBUG - 2020-03-31 15:23:54 --> Template Class Initialized
INFO - 2020-03-31 15:23:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:23:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:23:54 --> Pagination Class Initialized
INFO - 2020-03-31 15:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:23:54 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:23:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:23:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-03-31 15:23:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:23:54 --> Encryption Class Initialized
INFO - 2020-03-31 15:23:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:23:54 --> Encryption Class Initialized
INFO - 2020-03-31 15:23:54 --> Controller Class Initialized
DEBUG - 2020-03-31 15:23:54 --> cardinity MX_Controller Initialized
INFO - 2020-03-31 15:23:54 --> Controller Class Initialized
DEBUG - 2020-03-31 15:23:54 --> cardinity MX_Controller Initialized
INFO - 2020-03-31 15:23:54 --> Model Class Initialized
DEBUG - 2020-03-31 15:23:54 --> orders MX_Controller Initialized
INFO - 2020-03-31 15:23:54 --> Model Class Initialized
DEBUG - 2020-03-31 15:23:54 --> orders MX_Controller Initialized
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 69
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 70
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 69
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 71
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 70
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 73
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 71
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 73
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 74
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 74
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 75
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 76
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 75
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 76
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 116
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 116
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 116
ERROR - 2020-03-31 15:23:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 116
ERROR - 2020-03-31 15:23:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\core\Exceptions.php:271) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\helpers\url_helper.php 564
ERROR - 2020-03-31 15:23:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\core\Exceptions.php:271) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\helpers\url_helper.php 564
INFO - 2020-03-31 15:24:59 --> Config Class Initialized
INFO - 2020-03-31 15:24:59 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:24:59 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:24:59 --> Utf8 Class Initialized
INFO - 2020-03-31 15:24:59 --> URI Class Initialized
INFO - 2020-03-31 15:24:59 --> Router Class Initialized
INFO - 2020-03-31 15:24:59 --> Output Class Initialized
INFO - 2020-03-31 15:24:59 --> Security Class Initialized
DEBUG - 2020-03-31 15:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:24:59 --> Input Class Initialized
INFO - 2020-03-31 15:24:59 --> Language Class Initialized
INFO - 2020-03-31 15:24:59 --> Language Class Initialized
INFO - 2020-03-31 15:24:59 --> Config Class Initialized
INFO - 2020-03-31 15:24:59 --> Loader Class Initialized
INFO - 2020-03-31 15:24:59 --> Helper loaded: url_helper
INFO - 2020-03-31 15:24:59 --> Helper loaded: common_helper
INFO - 2020-03-31 15:24:59 --> Helper loaded: language_helper
INFO - 2020-03-31 15:24:59 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:24:59 --> Helper loaded: email_helper
INFO - 2020-03-31 15:24:59 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:24:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:24:59 --> Parser Class Initialized
INFO - 2020-03-31 15:24:59 --> User Agent Class Initialized
INFO - 2020-03-31 15:24:59 --> Model Class Initialized
INFO - 2020-03-31 15:24:59 --> Database Driver Class Initialized
INFO - 2020-03-31 15:24:59 --> Model Class Initialized
DEBUG - 2020-03-31 15:24:59 --> Template Class Initialized
INFO - 2020-03-31 15:24:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:24:59 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:24:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:24:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:24:59 --> Encryption Class Initialized
INFO - 2020-03-31 15:24:59 --> Controller Class Initialized
DEBUG - 2020-03-31 15:24:59 --> cardinity MX_Controller Initialized
INFO - 2020-03-31 15:24:59 --> Model Class Initialized
DEBUG - 2020-03-31 15:24:59 --> orders MX_Controller Initialized
INFO - 2020-03-31 15:25:08 --> Config Class Initialized
INFO - 2020-03-31 15:25:08 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:25:08 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:25:08 --> Utf8 Class Initialized
INFO - 2020-03-31 15:25:08 --> URI Class Initialized
INFO - 2020-03-31 15:25:08 --> Router Class Initialized
INFO - 2020-03-31 15:25:08 --> Output Class Initialized
INFO - 2020-03-31 15:25:08 --> Security Class Initialized
DEBUG - 2020-03-31 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:25:08 --> CSRF cookie sent
INFO - 2020-03-31 15:25:08 --> Input Class Initialized
INFO - 2020-03-31 15:25:08 --> Language Class Initialized
INFO - 2020-03-31 15:25:08 --> Language Class Initialized
INFO - 2020-03-31 15:25:08 --> Config Class Initialized
INFO - 2020-03-31 15:25:08 --> Loader Class Initialized
INFO - 2020-03-31 15:25:08 --> Helper loaded: url_helper
INFO - 2020-03-31 15:25:08 --> Helper loaded: common_helper
INFO - 2020-03-31 15:25:08 --> Helper loaded: language_helper
INFO - 2020-03-31 15:25:08 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:25:09 --> Helper loaded: email_helper
INFO - 2020-03-31 15:25:09 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:25:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:25:09 --> Parser Class Initialized
INFO - 2020-03-31 15:25:09 --> User Agent Class Initialized
INFO - 2020-03-31 15:25:09 --> Model Class Initialized
INFO - 2020-03-31 15:25:09 --> Database Driver Class Initialized
INFO - 2020-03-31 15:25:09 --> Model Class Initialized
DEBUG - 2020-03-31 15:25:09 --> Template Class Initialized
INFO - 2020-03-31 15:25:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:25:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:25:09 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:25:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:25:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:25:09 --> Encryption Class Initialized
INFO - 2020-03-31 15:25:09 --> Controller Class Initialized
DEBUG - 2020-03-31 15:25:09 --> auth MX_Controller Initialized
DEBUG - 2020-03-31 15:25:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-31 15:25:09 --> Model Class Initialized
DEBUG - 2020-03-31 15:25:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-31 15:25:09 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:25:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-31 15:25:09 --> pergo MX_Controller Initialized
DEBUG - 2020-03-31 15:25:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 15:25:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-31 15:25:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-31 15:25:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-31 15:25:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-31 15:25:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-31 15:25:09 --> Final output sent to browser
DEBUG - 2020-03-31 15:25:09 --> Total execution time: 0.5861
INFO - 2020-03-31 15:25:21 --> Config Class Initialized
INFO - 2020-03-31 15:25:21 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:25:21 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:25:21 --> Utf8 Class Initialized
INFO - 2020-03-31 15:25:21 --> URI Class Initialized
INFO - 2020-03-31 15:25:21 --> Router Class Initialized
INFO - 2020-03-31 15:25:21 --> Output Class Initialized
INFO - 2020-03-31 15:25:21 --> Security Class Initialized
DEBUG - 2020-03-31 15:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:25:21 --> CSRF cookie sent
INFO - 2020-03-31 15:25:21 --> CSRF token verified
INFO - 2020-03-31 15:25:21 --> Input Class Initialized
INFO - 2020-03-31 15:25:21 --> Language Class Initialized
INFO - 2020-03-31 15:25:21 --> Language Class Initialized
INFO - 2020-03-31 15:25:21 --> Config Class Initialized
INFO - 2020-03-31 15:25:21 --> Loader Class Initialized
INFO - 2020-03-31 15:25:21 --> Helper loaded: url_helper
INFO - 2020-03-31 15:25:21 --> Helper loaded: common_helper
INFO - 2020-03-31 15:25:21 --> Helper loaded: language_helper
INFO - 2020-03-31 15:25:21 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:25:21 --> Helper loaded: email_helper
INFO - 2020-03-31 15:25:21 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:25:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:25:21 --> Parser Class Initialized
INFO - 2020-03-31 15:25:21 --> User Agent Class Initialized
INFO - 2020-03-31 15:25:21 --> Model Class Initialized
INFO - 2020-03-31 15:25:21 --> Database Driver Class Initialized
INFO - 2020-03-31 15:25:21 --> Model Class Initialized
DEBUG - 2020-03-31 15:25:21 --> Template Class Initialized
INFO - 2020-03-31 15:25:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:25:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:25:21 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:25:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:25:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:25:21 --> Encryption Class Initialized
INFO - 2020-03-31 15:25:21 --> Controller Class Initialized
DEBUG - 2020-03-31 15:25:21 --> auth MX_Controller Initialized
DEBUG - 2020-03-31 15:25:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-31 15:25:21 --> Model Class Initialized
INFO - 2020-03-31 15:25:26 --> Config Class Initialized
INFO - 2020-03-31 15:25:26 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:25:26 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:25:26 --> Utf8 Class Initialized
INFO - 2020-03-31 15:25:26 --> URI Class Initialized
INFO - 2020-03-31 15:25:26 --> Router Class Initialized
INFO - 2020-03-31 15:25:26 --> Output Class Initialized
INFO - 2020-03-31 15:25:26 --> Security Class Initialized
DEBUG - 2020-03-31 15:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:25:26 --> CSRF cookie sent
INFO - 2020-03-31 15:25:26 --> Input Class Initialized
INFO - 2020-03-31 15:25:26 --> Language Class Initialized
INFO - 2020-03-31 15:25:26 --> Language Class Initialized
INFO - 2020-03-31 15:25:26 --> Config Class Initialized
INFO - 2020-03-31 15:25:26 --> Loader Class Initialized
INFO - 2020-03-31 15:25:26 --> Helper loaded: url_helper
INFO - 2020-03-31 15:25:26 --> Helper loaded: common_helper
INFO - 2020-03-31 15:25:26 --> Helper loaded: language_helper
INFO - 2020-03-31 15:25:26 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:25:26 --> Helper loaded: email_helper
INFO - 2020-03-31 15:25:26 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:25:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:25:26 --> Parser Class Initialized
INFO - 2020-03-31 15:25:26 --> User Agent Class Initialized
INFO - 2020-03-31 15:25:26 --> Model Class Initialized
INFO - 2020-03-31 15:25:26 --> Database Driver Class Initialized
INFO - 2020-03-31 15:25:26 --> Model Class Initialized
DEBUG - 2020-03-31 15:25:26 --> Template Class Initialized
INFO - 2020-03-31 15:25:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:25:26 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:25:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:25:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:25:26 --> Encryption Class Initialized
INFO - 2020-03-31 15:25:26 --> Controller Class Initialized
DEBUG - 2020-03-31 15:25:26 --> statistics MX_Controller Initialized
DEBUG - 2020-03-31 15:25:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-31 15:25:26 --> Model Class Initialized
ERROR - 2020-03-31 15:25:26 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:26 --> Could not find the language line "Pending"
INFO - 2020-03-31 15:25:26 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 15:25:26 --> Could not find the language line "total_orders"
ERROR - 2020-03-31 15:25:26 --> Could not find the language line "total_orders"
ERROR - 2020-03-31 15:25:26 --> Could not find the language line "Pending"
DEBUG - 2020-03-31 15:25:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-31 15:25:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:25:27 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:25:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:25:27 --> Model Class Initialized
DEBUG - 2020-03-31 15:25:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:25:27 --> Model Class Initialized
DEBUG - 2020-03-31 15:25:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:25:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:25:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:25:27 --> Final output sent to browser
DEBUG - 2020-03-31 15:25:27 --> Total execution time: 0.9870
INFO - 2020-03-31 15:25:30 --> Config Class Initialized
INFO - 2020-03-31 15:25:30 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:25:30 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:25:30 --> Utf8 Class Initialized
INFO - 2020-03-31 15:25:30 --> URI Class Initialized
INFO - 2020-03-31 15:25:30 --> Router Class Initialized
INFO - 2020-03-31 15:25:30 --> Output Class Initialized
INFO - 2020-03-31 15:25:30 --> Security Class Initialized
DEBUG - 2020-03-31 15:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:25:30 --> CSRF cookie sent
INFO - 2020-03-31 15:25:30 --> Input Class Initialized
INFO - 2020-03-31 15:25:30 --> Language Class Initialized
INFO - 2020-03-31 15:25:30 --> Language Class Initialized
INFO - 2020-03-31 15:25:30 --> Config Class Initialized
INFO - 2020-03-31 15:25:30 --> Loader Class Initialized
INFO - 2020-03-31 15:25:30 --> Helper loaded: url_helper
INFO - 2020-03-31 15:25:30 --> Helper loaded: common_helper
INFO - 2020-03-31 15:25:30 --> Helper loaded: language_helper
INFO - 2020-03-31 15:25:30 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:25:30 --> Helper loaded: email_helper
INFO - 2020-03-31 15:25:30 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:25:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:25:30 --> Parser Class Initialized
INFO - 2020-03-31 15:25:30 --> User Agent Class Initialized
INFO - 2020-03-31 15:25:30 --> Model Class Initialized
INFO - 2020-03-31 15:25:30 --> Database Driver Class Initialized
INFO - 2020-03-31 15:25:30 --> Model Class Initialized
DEBUG - 2020-03-31 15:25:30 --> Template Class Initialized
INFO - 2020-03-31 15:25:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:25:30 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:25:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:25:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:25:30 --> Encryption Class Initialized
INFO - 2020-03-31 15:25:30 --> Controller Class Initialized
DEBUG - 2020-03-31 15:25:30 --> order MX_Controller Initialized
DEBUG - 2020-03-31 15:25:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2020-03-31 15:25:30 --> Model Class Initialized
ERROR - 2020-03-31 15:25:30 --> Could not find the language line "order_id"
ERROR - 2020-03-31 15:25:30 --> Could not find the language line "order_basic_details"
ERROR - 2020-03-31 15:25:30 --> Could not find the language line "order_id"
ERROR - 2020-03-31 15:25:30 --> Could not find the language line "order_basic_details"
INFO - 2020-03-31 15:25:30 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Awaiting"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Awaiting"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Awaiting"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Awaiting"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Awaiting"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:25:31 --> Could not find the language line "Pending"
DEBUG - 2020-03-31 15:25:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2020-03-31 15:25:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:25:31 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:25:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:25:31 --> Model Class Initialized
DEBUG - 2020-03-31 15:25:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:25:31 --> Model Class Initialized
DEBUG - 2020-03-31 15:25:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:25:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:25:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:25:31 --> Final output sent to browser
DEBUG - 2020-03-31 15:25:31 --> Total execution time: 1.0460
INFO - 2020-03-31 15:26:10 --> Config Class Initialized
INFO - 2020-03-31 15:26:11 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:26:11 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:26:11 --> Utf8 Class Initialized
INFO - 2020-03-31 15:26:11 --> URI Class Initialized
INFO - 2020-03-31 15:26:11 --> Router Class Initialized
INFO - 2020-03-31 15:26:11 --> Output Class Initialized
INFO - 2020-03-31 15:26:11 --> Security Class Initialized
DEBUG - 2020-03-31 15:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:26:11 --> CSRF cookie sent
INFO - 2020-03-31 15:26:11 --> Input Class Initialized
INFO - 2020-03-31 15:26:11 --> Language Class Initialized
INFO - 2020-03-31 15:26:11 --> Language Class Initialized
INFO - 2020-03-31 15:26:11 --> Config Class Initialized
INFO - 2020-03-31 15:26:11 --> Loader Class Initialized
INFO - 2020-03-31 15:26:11 --> Helper loaded: url_helper
INFO - 2020-03-31 15:26:11 --> Helper loaded: common_helper
INFO - 2020-03-31 15:26:11 --> Helper loaded: language_helper
INFO - 2020-03-31 15:26:11 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:26:11 --> Helper loaded: email_helper
INFO - 2020-03-31 15:26:11 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:26:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:26:11 --> Parser Class Initialized
INFO - 2020-03-31 15:26:11 --> User Agent Class Initialized
INFO - 2020-03-31 15:26:11 --> Model Class Initialized
INFO - 2020-03-31 15:26:11 --> Database Driver Class Initialized
INFO - 2020-03-31 15:26:11 --> Model Class Initialized
DEBUG - 2020-03-31 15:26:11 --> Template Class Initialized
INFO - 2020-03-31 15:26:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:26:11 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:26:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:26:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:26:11 --> Encryption Class Initialized
INFO - 2020-03-31 15:26:11 --> Controller Class Initialized
DEBUG - 2020-03-31 15:26:11 --> package MX_Controller Initialized
DEBUG - 2020-03-31 15:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-31 15:26:11 --> Model Class Initialized
INFO - 2020-03-31 15:26:11 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:26:11 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:26:11 --> Model Class Initialized
DEBUG - 2020-03-31 15:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:26:11 --> Model Class Initialized
DEBUG - 2020-03-31 15:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-31 15:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:26:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:26:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:26:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:26:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:26:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:26:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:26:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:26:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 15:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 15:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 15:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 15:26:11 --> Final output sent to browser
DEBUG - 2020-03-31 15:26:11 --> Total execution time: 0.8727
INFO - 2020-03-31 15:26:13 --> Config Class Initialized
INFO - 2020-03-31 15:26:13 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:26:13 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:26:13 --> Utf8 Class Initialized
INFO - 2020-03-31 15:26:13 --> URI Class Initialized
INFO - 2020-03-31 15:26:13 --> Router Class Initialized
INFO - 2020-03-31 15:26:13 --> Output Class Initialized
INFO - 2020-03-31 15:26:13 --> Security Class Initialized
DEBUG - 2020-03-31 15:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:26:13 --> CSRF cookie sent
INFO - 2020-03-31 15:26:13 --> Input Class Initialized
INFO - 2020-03-31 15:26:13 --> Language Class Initialized
INFO - 2020-03-31 15:26:13 --> Language Class Initialized
INFO - 2020-03-31 15:26:13 --> Config Class Initialized
INFO - 2020-03-31 15:26:13 --> Loader Class Initialized
INFO - 2020-03-31 15:26:13 --> Helper loaded: url_helper
INFO - 2020-03-31 15:26:13 --> Helper loaded: common_helper
INFO - 2020-03-31 15:26:13 --> Helper loaded: language_helper
INFO - 2020-03-31 15:26:13 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:26:13 --> Helper loaded: email_helper
INFO - 2020-03-31 15:26:13 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:26:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:26:13 --> Parser Class Initialized
INFO - 2020-03-31 15:26:13 --> User Agent Class Initialized
INFO - 2020-03-31 15:26:13 --> Model Class Initialized
INFO - 2020-03-31 15:26:13 --> Database Driver Class Initialized
INFO - 2020-03-31 15:26:13 --> Model Class Initialized
DEBUG - 2020-03-31 15:26:13 --> Template Class Initialized
INFO - 2020-03-31 15:26:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:26:13 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:26:13 --> Encryption Class Initialized
INFO - 2020-03-31 15:26:13 --> Controller Class Initialized
DEBUG - 2020-03-31 15:26:13 --> category MX_Controller Initialized
DEBUG - 2020-03-31 15:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:26:13 --> Model Class Initialized
ERROR - 2020-03-31 15:26:13 --> Could not find the language line "Sorting"
INFO - 2020-03-31 15:26:13 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "Delele"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
ERROR - 2020-03-31 15:26:14 --> Could not find the language line "View"
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:26:14 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:26:14 --> Model Class Initialized
DEBUG - 2020-03-31 15:26:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:26:14 --> Model Class Initialized
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:26:14 --> Final output sent to browser
DEBUG - 2020-03-31 15:26:14 --> Total execution time: 1.0039
INFO - 2020-03-31 15:27:37 --> Config Class Initialized
INFO - 2020-03-31 15:27:37 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:27:37 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:27:37 --> Utf8 Class Initialized
INFO - 2020-03-31 15:27:37 --> URI Class Initialized
INFO - 2020-03-31 15:27:37 --> Router Class Initialized
INFO - 2020-03-31 15:27:37 --> Output Class Initialized
INFO - 2020-03-31 15:27:37 --> Security Class Initialized
DEBUG - 2020-03-31 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:27:37 --> CSRF cookie sent
INFO - 2020-03-31 15:27:37 --> Input Class Initialized
INFO - 2020-03-31 15:27:37 --> Language Class Initialized
INFO - 2020-03-31 15:27:37 --> Language Class Initialized
INFO - 2020-03-31 15:27:37 --> Config Class Initialized
INFO - 2020-03-31 15:27:37 --> Loader Class Initialized
INFO - 2020-03-31 15:27:37 --> Helper loaded: url_helper
INFO - 2020-03-31 15:27:37 --> Helper loaded: common_helper
INFO - 2020-03-31 15:27:37 --> Helper loaded: language_helper
INFO - 2020-03-31 15:27:37 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:27:37 --> Helper loaded: email_helper
INFO - 2020-03-31 15:27:37 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:27:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:27:37 --> Parser Class Initialized
INFO - 2020-03-31 15:27:37 --> User Agent Class Initialized
INFO - 2020-03-31 15:27:37 --> Model Class Initialized
INFO - 2020-03-31 15:27:37 --> Database Driver Class Initialized
INFO - 2020-03-31 15:27:37 --> Model Class Initialized
DEBUG - 2020-03-31 15:27:37 --> Template Class Initialized
INFO - 2020-03-31 15:27:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:27:37 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:27:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:27:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:27:37 --> Encryption Class Initialized
INFO - 2020-03-31 15:27:37 --> Controller Class Initialized
DEBUG - 2020-03-31 15:27:37 --> category MX_Controller Initialized
DEBUG - 2020-03-31 15:27:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:27:37 --> Model Class Initialized
ERROR - 2020-03-31 15:27:37 --> Could not find the language line "Sorting"
INFO - 2020-03-31 15:27:37 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:27:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-03-31 15:27:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:27:37 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:27:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:27:37 --> Model Class Initialized
DEBUG - 2020-03-31 15:27:37 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:27:37 --> Model Class Initialized
DEBUG - 2020-03-31 15:27:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:27:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:27:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:27:37 --> Final output sent to browser
DEBUG - 2020-03-31 15:27:37 --> Total execution time: 0.7309
INFO - 2020-03-31 15:28:23 --> Config Class Initialized
INFO - 2020-03-31 15:28:23 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:28:23 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:28:23 --> Utf8 Class Initialized
INFO - 2020-03-31 15:28:23 --> URI Class Initialized
INFO - 2020-03-31 15:28:23 --> Router Class Initialized
INFO - 2020-03-31 15:28:23 --> Output Class Initialized
INFO - 2020-03-31 15:28:23 --> Security Class Initialized
DEBUG - 2020-03-31 15:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:28:23 --> CSRF cookie sent
INFO - 2020-03-31 15:28:23 --> Input Class Initialized
INFO - 2020-03-31 15:28:23 --> Language Class Initialized
INFO - 2020-03-31 15:28:23 --> Language Class Initialized
INFO - 2020-03-31 15:28:23 --> Config Class Initialized
INFO - 2020-03-31 15:28:23 --> Loader Class Initialized
INFO - 2020-03-31 15:28:23 --> Helper loaded: url_helper
INFO - 2020-03-31 15:28:23 --> Helper loaded: common_helper
INFO - 2020-03-31 15:28:23 --> Helper loaded: language_helper
INFO - 2020-03-31 15:28:23 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:28:23 --> Helper loaded: email_helper
INFO - 2020-03-31 15:28:23 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:28:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:28:24 --> Parser Class Initialized
INFO - 2020-03-31 15:28:24 --> User Agent Class Initialized
INFO - 2020-03-31 15:28:24 --> Model Class Initialized
INFO - 2020-03-31 15:28:24 --> Database Driver Class Initialized
INFO - 2020-03-31 15:28:24 --> Model Class Initialized
DEBUG - 2020-03-31 15:28:24 --> Template Class Initialized
INFO - 2020-03-31 15:28:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:28:24 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:28:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:28:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:28:24 --> Encryption Class Initialized
INFO - 2020-03-31 15:28:24 --> Controller Class Initialized
DEBUG - 2020-03-31 15:28:24 --> services MX_Controller Initialized
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:28:24 --> Model Class Initialized
INFO - 2020-03-31 15:28:24 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 15:28:24 --> Could not find the language line "Delele"
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:28:24 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:28:24 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:28:24 --> Model Class Initialized
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:28:24 --> Model Class Initialized
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:28:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:28:24 --> Final output sent to browser
DEBUG - 2020-03-31 15:28:24 --> Total execution time: 1.0940
INFO - 2020-03-31 15:28:34 --> Config Class Initialized
INFO - 2020-03-31 15:28:34 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:28:34 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:28:34 --> Utf8 Class Initialized
INFO - 2020-03-31 15:28:34 --> URI Class Initialized
INFO - 2020-03-31 15:28:34 --> Router Class Initialized
INFO - 2020-03-31 15:28:34 --> Output Class Initialized
INFO - 2020-03-31 15:28:34 --> Security Class Initialized
DEBUG - 2020-03-31 15:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:28:34 --> CSRF cookie sent
INFO - 2020-03-31 15:28:34 --> Input Class Initialized
INFO - 2020-03-31 15:28:34 --> Language Class Initialized
INFO - 2020-03-31 15:28:34 --> Language Class Initialized
INFO - 2020-03-31 15:28:34 --> Config Class Initialized
INFO - 2020-03-31 15:28:34 --> Loader Class Initialized
INFO - 2020-03-31 15:28:34 --> Helper loaded: url_helper
INFO - 2020-03-31 15:28:34 --> Helper loaded: common_helper
INFO - 2020-03-31 15:28:34 --> Helper loaded: language_helper
INFO - 2020-03-31 15:28:34 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:28:34 --> Helper loaded: email_helper
INFO - 2020-03-31 15:28:34 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:28:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:28:34 --> Parser Class Initialized
INFO - 2020-03-31 15:28:34 --> User Agent Class Initialized
INFO - 2020-03-31 15:28:34 --> Model Class Initialized
INFO - 2020-03-31 15:28:34 --> Database Driver Class Initialized
INFO - 2020-03-31 15:28:34 --> Model Class Initialized
DEBUG - 2020-03-31 15:28:34 --> Template Class Initialized
INFO - 2020-03-31 15:28:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:28:34 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:28:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:28:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:28:34 --> Encryption Class Initialized
INFO - 2020-03-31 15:28:34 --> Controller Class Initialized
DEBUG - 2020-03-31 15:28:34 --> package MX_Controller Initialized
DEBUG - 2020-03-31 15:28:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-31 15:28:34 --> Model Class Initialized
INFO - 2020-03-31 15:28:34 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:28:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:28:34 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:28:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:28:35 --> Model Class Initialized
DEBUG - 2020-03-31 15:28:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:28:35 --> Model Class Initialized
DEBUG - 2020-03-31 15:28:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-31 15:28:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 15:28:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 15:28:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 15:28:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 15:28:35 --> Final output sent to browser
DEBUG - 2020-03-31 15:28:35 --> Total execution time: 0.9288
INFO - 2020-03-31 15:29:01 --> Config Class Initialized
INFO - 2020-03-31 15:29:01 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:29:01 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:29:01 --> Utf8 Class Initialized
INFO - 2020-03-31 15:29:01 --> URI Class Initialized
INFO - 2020-03-31 15:29:01 --> Router Class Initialized
INFO - 2020-03-31 15:29:01 --> Output Class Initialized
INFO - 2020-03-31 15:29:01 --> Security Class Initialized
DEBUG - 2020-03-31 15:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:29:01 --> CSRF cookie sent
INFO - 2020-03-31 15:29:01 --> CSRF token verified
INFO - 2020-03-31 15:29:01 --> Input Class Initialized
INFO - 2020-03-31 15:29:01 --> Language Class Initialized
INFO - 2020-03-31 15:29:02 --> Language Class Initialized
INFO - 2020-03-31 15:29:02 --> Config Class Initialized
INFO - 2020-03-31 15:29:02 --> Loader Class Initialized
INFO - 2020-03-31 15:29:02 --> Helper loaded: url_helper
INFO - 2020-03-31 15:29:02 --> Helper loaded: common_helper
INFO - 2020-03-31 15:29:02 --> Helper loaded: language_helper
INFO - 2020-03-31 15:29:02 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:29:02 --> Helper loaded: email_helper
INFO - 2020-03-31 15:29:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:29:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:29:02 --> Parser Class Initialized
INFO - 2020-03-31 15:29:02 --> User Agent Class Initialized
INFO - 2020-03-31 15:29:02 --> Model Class Initialized
INFO - 2020-03-31 15:29:02 --> Database Driver Class Initialized
INFO - 2020-03-31 15:29:02 --> Model Class Initialized
DEBUG - 2020-03-31 15:29:02 --> Template Class Initialized
INFO - 2020-03-31 15:29:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:29:02 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:29:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:29:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:29:02 --> Encryption Class Initialized
INFO - 2020-03-31 15:29:02 --> Controller Class Initialized
DEBUG - 2020-03-31 15:29:02 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 15:29:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 15:29:02 --> Model Class Initialized
INFO - 2020-03-31 15:29:02 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 15:29:02 --> Could not find the language line "shopier"
DEBUG - 2020-03-31 15:29:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-31 15:29:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:29:02 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:29:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:29:02 --> Model Class Initialized
DEBUG - 2020-03-31 15:29:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:29:02 --> Model Class Initialized
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 15:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 15:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 15:29:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 15:29:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 15:29:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 15:29:02 --> Final output sent to browser
DEBUG - 2020-03-31 15:29:02 --> Total execution time: 0.8848
INFO - 2020-03-31 15:29:07 --> Config Class Initialized
INFO - 2020-03-31 15:29:07 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:29:07 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:29:07 --> Utf8 Class Initialized
INFO - 2020-03-31 15:29:07 --> URI Class Initialized
INFO - 2020-03-31 15:29:07 --> Router Class Initialized
INFO - 2020-03-31 15:29:07 --> Output Class Initialized
INFO - 2020-03-31 15:29:08 --> Security Class Initialized
DEBUG - 2020-03-31 15:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:29:08 --> CSRF cookie sent
INFO - 2020-03-31 15:29:08 --> CSRF token verified
INFO - 2020-03-31 15:29:08 --> Input Class Initialized
INFO - 2020-03-31 15:29:08 --> Language Class Initialized
INFO - 2020-03-31 15:29:08 --> Language Class Initialized
INFO - 2020-03-31 15:29:08 --> Config Class Initialized
INFO - 2020-03-31 15:29:08 --> Loader Class Initialized
INFO - 2020-03-31 15:29:08 --> Helper loaded: url_helper
INFO - 2020-03-31 15:29:08 --> Helper loaded: common_helper
INFO - 2020-03-31 15:29:08 --> Helper loaded: language_helper
INFO - 2020-03-31 15:29:08 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:29:08 --> Helper loaded: email_helper
INFO - 2020-03-31 15:29:08 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:29:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:29:08 --> Parser Class Initialized
INFO - 2020-03-31 15:29:08 --> User Agent Class Initialized
INFO - 2020-03-31 15:29:08 --> Model Class Initialized
INFO - 2020-03-31 15:29:08 --> Database Driver Class Initialized
INFO - 2020-03-31 15:29:08 --> Model Class Initialized
DEBUG - 2020-03-31 15:29:08 --> Template Class Initialized
INFO - 2020-03-31 15:29:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:29:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:29:08 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:29:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:29:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:29:08 --> Encryption Class Initialized
INFO - 2020-03-31 15:29:08 --> Controller Class Initialized
DEBUG - 2020-03-31 15:29:08 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 15:29:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 15:29:08 --> Model Class Initialized
DEBUG - 2020-03-31 15:29:08 --> cardinity MX_Controller Initialized
DEBUG - 2020-03-31 15:29:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/index.php
INFO - 2020-03-31 15:29:08 --> Final output sent to browser
DEBUG - 2020-03-31 15:29:08 --> Total execution time: 0.5539
INFO - 2020-03-31 15:29:18 --> Config Class Initialized
INFO - 2020-03-31 15:29:18 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:29:18 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:29:18 --> Utf8 Class Initialized
INFO - 2020-03-31 15:29:18 --> URI Class Initialized
INFO - 2020-03-31 15:29:18 --> Router Class Initialized
INFO - 2020-03-31 15:29:18 --> Output Class Initialized
INFO - 2020-03-31 15:29:18 --> Security Class Initialized
DEBUG - 2020-03-31 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:29:18 --> Input Class Initialized
INFO - 2020-03-31 15:29:18 --> Language Class Initialized
INFO - 2020-03-31 15:29:18 --> Language Class Initialized
INFO - 2020-03-31 15:29:18 --> Config Class Initialized
INFO - 2020-03-31 15:29:18 --> Loader Class Initialized
INFO - 2020-03-31 15:29:18 --> Helper loaded: url_helper
INFO - 2020-03-31 15:29:18 --> Helper loaded: common_helper
INFO - 2020-03-31 15:29:18 --> Helper loaded: language_helper
INFO - 2020-03-31 15:29:18 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:29:18 --> Helper loaded: email_helper
INFO - 2020-03-31 15:29:18 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:29:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:29:18 --> Parser Class Initialized
INFO - 2020-03-31 15:29:18 --> User Agent Class Initialized
INFO - 2020-03-31 15:29:18 --> Model Class Initialized
INFO - 2020-03-31 15:29:18 --> Database Driver Class Initialized
INFO - 2020-03-31 15:29:18 --> Model Class Initialized
DEBUG - 2020-03-31 15:29:18 --> Template Class Initialized
INFO - 2020-03-31 15:29:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:29:18 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:29:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:29:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:29:18 --> Encryption Class Initialized
INFO - 2020-03-31 15:29:19 --> Controller Class Initialized
DEBUG - 2020-03-31 15:29:19 --> cardinity MX_Controller Initialized
INFO - 2020-03-31 15:29:19 --> Model Class Initialized
DEBUG - 2020-03-31 15:29:19 --> orders MX_Controller Initialized
INFO - 2020-03-31 15:29:36 --> Config Class Initialized
INFO - 2020-03-31 15:29:36 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:29:36 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:29:36 --> Utf8 Class Initialized
INFO - 2020-03-31 15:29:36 --> URI Class Initialized
INFO - 2020-03-31 15:29:36 --> Router Class Initialized
INFO - 2020-03-31 15:29:36 --> Output Class Initialized
INFO - 2020-03-31 15:29:36 --> Security Class Initialized
DEBUG - 2020-03-31 15:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:29:36 --> Input Class Initialized
INFO - 2020-03-31 15:29:36 --> Language Class Initialized
INFO - 2020-03-31 15:29:36 --> Language Class Initialized
INFO - 2020-03-31 15:29:36 --> Config Class Initialized
INFO - 2020-03-31 15:29:36 --> Loader Class Initialized
INFO - 2020-03-31 15:29:36 --> Helper loaded: url_helper
INFO - 2020-03-31 15:29:36 --> Helper loaded: common_helper
INFO - 2020-03-31 15:29:36 --> Helper loaded: language_helper
INFO - 2020-03-31 15:29:36 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:29:36 --> Helper loaded: email_helper
INFO - 2020-03-31 15:29:36 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:29:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:29:36 --> Parser Class Initialized
INFO - 2020-03-31 15:29:36 --> User Agent Class Initialized
INFO - 2020-03-31 15:29:36 --> Model Class Initialized
INFO - 2020-03-31 15:29:36 --> Database Driver Class Initialized
INFO - 2020-03-31 15:29:36 --> Model Class Initialized
DEBUG - 2020-03-31 15:29:36 --> Template Class Initialized
INFO - 2020-03-31 15:29:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:29:36 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:29:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:29:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:29:36 --> Encryption Class Initialized
INFO - 2020-03-31 15:29:36 --> Controller Class Initialized
DEBUG - 2020-03-31 15:29:36 --> cardinity MX_Controller Initialized
INFO - 2020-03-31 15:29:36 --> Model Class Initialized
DEBUG - 2020-03-31 15:29:36 --> orders MX_Controller Initialized
INFO - 2020-03-31 15:32:13 --> Config Class Initialized
INFO - 2020-03-31 15:32:13 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:32:13 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:32:13 --> Utf8 Class Initialized
INFO - 2020-03-31 15:32:13 --> URI Class Initialized
INFO - 2020-03-31 15:32:13 --> Router Class Initialized
INFO - 2020-03-31 15:32:13 --> Output Class Initialized
INFO - 2020-03-31 15:32:13 --> Security Class Initialized
DEBUG - 2020-03-31 15:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:32:13 --> CSRF cookie sent
INFO - 2020-03-31 15:32:13 --> Input Class Initialized
INFO - 2020-03-31 15:32:14 --> Language Class Initialized
INFO - 2020-03-31 15:32:14 --> Language Class Initialized
INFO - 2020-03-31 15:32:14 --> Config Class Initialized
INFO - 2020-03-31 15:32:14 --> Loader Class Initialized
INFO - 2020-03-31 15:32:14 --> Helper loaded: url_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: common_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: language_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: email_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:32:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:32:14 --> Parser Class Initialized
INFO - 2020-03-31 15:32:14 --> User Agent Class Initialized
INFO - 2020-03-31 15:32:14 --> Model Class Initialized
INFO - 2020-03-31 15:32:14 --> Database Driver Class Initialized
INFO - 2020-03-31 15:32:14 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:14 --> Template Class Initialized
INFO - 2020-03-31 15:32:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:32:14 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:32:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:32:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:32:14 --> Encryption Class Initialized
INFO - 2020-03-31 15:32:14 --> Controller Class Initialized
DEBUG - 2020-03-31 15:32:14 --> transactions MX_Controller Initialized
INFO - 2020-03-31 15:32:14 --> Config Class Initialized
INFO - 2020-03-31 15:32:14 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:32:14 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:32:14 --> Utf8 Class Initialized
INFO - 2020-03-31 15:32:14 --> URI Class Initialized
DEBUG - 2020-03-31 15:32:14 --> No URI present. Default controller set.
INFO - 2020-03-31 15:32:14 --> Router Class Initialized
INFO - 2020-03-31 15:32:14 --> Output Class Initialized
INFO - 2020-03-31 15:32:14 --> Security Class Initialized
DEBUG - 2020-03-31 15:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:32:14 --> CSRF cookie sent
INFO - 2020-03-31 15:32:14 --> Input Class Initialized
INFO - 2020-03-31 15:32:14 --> Language Class Initialized
INFO - 2020-03-31 15:32:14 --> Language Class Initialized
INFO - 2020-03-31 15:32:14 --> Config Class Initialized
INFO - 2020-03-31 15:32:14 --> Loader Class Initialized
INFO - 2020-03-31 15:32:14 --> Helper loaded: url_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: common_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: language_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: email_helper
INFO - 2020-03-31 15:32:14 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:32:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:32:14 --> Parser Class Initialized
INFO - 2020-03-31 15:32:14 --> User Agent Class Initialized
INFO - 2020-03-31 15:32:14 --> Model Class Initialized
INFO - 2020-03-31 15:32:14 --> Database Driver Class Initialized
INFO - 2020-03-31 15:32:14 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:14 --> Template Class Initialized
INFO - 2020-03-31 15:32:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:32:14 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:32:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:32:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:32:14 --> Encryption Class Initialized
DEBUG - 2020-03-31 15:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 15:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-31 15:32:14 --> Controller Class Initialized
DEBUG - 2020-03-31 15:32:14 --> pergo MX_Controller Initialized
DEBUG - 2020-03-31 15:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 15:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-31 15:32:14 --> Model Class Initialized
INFO - 2020-03-31 15:32:14 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-31 15:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-31 15:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-31 15:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-31 15:32:15 --> Final output sent to browser
DEBUG - 2020-03-31 15:32:15 --> Total execution time: 0.6672
INFO - 2020-03-31 15:32:18 --> Config Class Initialized
INFO - 2020-03-31 15:32:18 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:32:18 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:32:18 --> Utf8 Class Initialized
INFO - 2020-03-31 15:32:18 --> URI Class Initialized
INFO - 2020-03-31 15:32:18 --> Router Class Initialized
INFO - 2020-03-31 15:32:18 --> Output Class Initialized
INFO - 2020-03-31 15:32:18 --> Security Class Initialized
DEBUG - 2020-03-31 15:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:32:18 --> CSRF cookie sent
INFO - 2020-03-31 15:32:18 --> Input Class Initialized
INFO - 2020-03-31 15:32:18 --> Language Class Initialized
INFO - 2020-03-31 15:32:18 --> Language Class Initialized
INFO - 2020-03-31 15:32:18 --> Config Class Initialized
INFO - 2020-03-31 15:32:18 --> Loader Class Initialized
INFO - 2020-03-31 15:32:18 --> Helper loaded: url_helper
INFO - 2020-03-31 15:32:18 --> Helper loaded: common_helper
INFO - 2020-03-31 15:32:18 --> Helper loaded: language_helper
INFO - 2020-03-31 15:32:18 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:32:18 --> Helper loaded: email_helper
INFO - 2020-03-31 15:32:18 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:32:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:32:18 --> Parser Class Initialized
INFO - 2020-03-31 15:32:18 --> User Agent Class Initialized
INFO - 2020-03-31 15:32:18 --> Model Class Initialized
INFO - 2020-03-31 15:32:18 --> Database Driver Class Initialized
INFO - 2020-03-31 15:32:18 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:18 --> Template Class Initialized
INFO - 2020-03-31 15:32:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:32:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:32:19 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:32:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:32:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:32:19 --> Encryption Class Initialized
INFO - 2020-03-31 15:32:19 --> Controller Class Initialized
DEBUG - 2020-03-31 15:32:19 --> auth MX_Controller Initialized
DEBUG - 2020-03-31 15:32:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-31 15:32:19 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-31 15:32:19 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:32:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2020-03-31 15:32:19 --> pergo MX_Controller Initialized
DEBUG - 2020-03-31 15:32:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 15:32:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2020-03-31 15:32:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-31 15:32:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-31 15:32:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2020-03-31 15:32:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-31 15:32:19 --> Final output sent to browser
DEBUG - 2020-03-31 15:32:19 --> Total execution time: 0.6142
INFO - 2020-03-31 15:32:21 --> Config Class Initialized
INFO - 2020-03-31 15:32:21 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:32:21 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:32:21 --> Utf8 Class Initialized
INFO - 2020-03-31 15:32:21 --> URI Class Initialized
INFO - 2020-03-31 15:32:21 --> Router Class Initialized
INFO - 2020-03-31 15:32:21 --> Output Class Initialized
INFO - 2020-03-31 15:32:21 --> Security Class Initialized
DEBUG - 2020-03-31 15:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:32:21 --> CSRF cookie sent
INFO - 2020-03-31 15:32:21 --> CSRF token verified
INFO - 2020-03-31 15:32:21 --> Input Class Initialized
INFO - 2020-03-31 15:32:21 --> Language Class Initialized
INFO - 2020-03-31 15:32:21 --> Language Class Initialized
INFO - 2020-03-31 15:32:21 --> Config Class Initialized
INFO - 2020-03-31 15:32:21 --> Loader Class Initialized
INFO - 2020-03-31 15:32:21 --> Helper loaded: url_helper
INFO - 2020-03-31 15:32:21 --> Helper loaded: common_helper
INFO - 2020-03-31 15:32:21 --> Helper loaded: language_helper
INFO - 2020-03-31 15:32:21 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:32:21 --> Helper loaded: email_helper
INFO - 2020-03-31 15:32:21 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:32:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:32:21 --> Parser Class Initialized
INFO - 2020-03-31 15:32:21 --> User Agent Class Initialized
INFO - 2020-03-31 15:32:21 --> Model Class Initialized
INFO - 2020-03-31 15:32:21 --> Database Driver Class Initialized
INFO - 2020-03-31 15:32:21 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:21 --> Template Class Initialized
INFO - 2020-03-31 15:32:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:32:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:32:21 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:32:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:32:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:32:21 --> Encryption Class Initialized
INFO - 2020-03-31 15:32:21 --> Controller Class Initialized
DEBUG - 2020-03-31 15:32:21 --> auth MX_Controller Initialized
DEBUG - 2020-03-31 15:32:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-03-31 15:32:21 --> Model Class Initialized
INFO - 2020-03-31 15:32:26 --> Config Class Initialized
INFO - 2020-03-31 15:32:26 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:32:26 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:32:26 --> Utf8 Class Initialized
INFO - 2020-03-31 15:32:26 --> URI Class Initialized
INFO - 2020-03-31 15:32:26 --> Router Class Initialized
INFO - 2020-03-31 15:32:26 --> Output Class Initialized
INFO - 2020-03-31 15:32:26 --> Security Class Initialized
DEBUG - 2020-03-31 15:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:32:26 --> CSRF cookie sent
INFO - 2020-03-31 15:32:26 --> Input Class Initialized
INFO - 2020-03-31 15:32:26 --> Language Class Initialized
INFO - 2020-03-31 15:32:26 --> Language Class Initialized
INFO - 2020-03-31 15:32:26 --> Config Class Initialized
INFO - 2020-03-31 15:32:26 --> Loader Class Initialized
INFO - 2020-03-31 15:32:26 --> Helper loaded: url_helper
INFO - 2020-03-31 15:32:26 --> Helper loaded: common_helper
INFO - 2020-03-31 15:32:26 --> Helper loaded: language_helper
INFO - 2020-03-31 15:32:26 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:32:26 --> Helper loaded: email_helper
INFO - 2020-03-31 15:32:26 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:32:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:32:26 --> Parser Class Initialized
INFO - 2020-03-31 15:32:26 --> User Agent Class Initialized
INFO - 2020-03-31 15:32:26 --> Model Class Initialized
INFO - 2020-03-31 15:32:26 --> Database Driver Class Initialized
INFO - 2020-03-31 15:32:26 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:26 --> Template Class Initialized
INFO - 2020-03-31 15:32:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:32:26 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:32:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:32:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:32:26 --> Encryption Class Initialized
INFO - 2020-03-31 15:32:26 --> Controller Class Initialized
DEBUG - 2020-03-31 15:32:26 --> statistics MX_Controller Initialized
DEBUG - 2020-03-31 15:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-03-31 15:32:26 --> Model Class Initialized
ERROR - 2020-03-31 15:32:26 --> Could not find the language line "Pending"
ERROR - 2020-03-31 15:32:27 --> Could not find the language line "Pending"
INFO - 2020-03-31 15:32:27 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 15:32:27 --> Could not find the language line "total_orders"
ERROR - 2020-03-31 15:32:27 --> Could not find the language line "total_orders"
ERROR - 2020-03-31 15:32:27 --> Could not find the language line "Pending"
DEBUG - 2020-03-31 15:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-03-31 15:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:32:27 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:32:27 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:32:27 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:32:27 --> Final output sent to browser
DEBUG - 2020-03-31 15:32:27 --> Total execution time: 0.7536
INFO - 2020-03-31 15:32:33 --> Config Class Initialized
INFO - 2020-03-31 15:32:33 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:32:33 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:32:33 --> Utf8 Class Initialized
INFO - 2020-03-31 15:32:33 --> URI Class Initialized
INFO - 2020-03-31 15:32:33 --> Router Class Initialized
INFO - 2020-03-31 15:32:33 --> Output Class Initialized
INFO - 2020-03-31 15:32:33 --> Security Class Initialized
DEBUG - 2020-03-31 15:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:32:33 --> CSRF cookie sent
INFO - 2020-03-31 15:32:33 --> Input Class Initialized
INFO - 2020-03-31 15:32:33 --> Language Class Initialized
INFO - 2020-03-31 15:32:33 --> Language Class Initialized
INFO - 2020-03-31 15:32:33 --> Config Class Initialized
INFO - 2020-03-31 15:32:33 --> Loader Class Initialized
INFO - 2020-03-31 15:32:33 --> Helper loaded: url_helper
INFO - 2020-03-31 15:32:33 --> Helper loaded: common_helper
INFO - 2020-03-31 15:32:33 --> Helper loaded: language_helper
INFO - 2020-03-31 15:32:33 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:32:33 --> Helper loaded: email_helper
INFO - 2020-03-31 15:32:33 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:32:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:32:33 --> Parser Class Initialized
INFO - 2020-03-31 15:32:33 --> User Agent Class Initialized
INFO - 2020-03-31 15:32:33 --> Model Class Initialized
INFO - 2020-03-31 15:32:33 --> Database Driver Class Initialized
INFO - 2020-03-31 15:32:33 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:33 --> Template Class Initialized
INFO - 2020-03-31 15:32:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:32:34 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:32:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:32:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:32:34 --> Encryption Class Initialized
INFO - 2020-03-31 15:32:34 --> Controller Class Initialized
DEBUG - 2020-03-31 15:32:34 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:32:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:32:34 --> Model Class Initialized
ERROR - 2020-03-31 15:32:34 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:32:34 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:32:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:32:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:32:34 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:32:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:32:34 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:32:34 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:32:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:32:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:32:34 --> Final output sent to browser
DEBUG - 2020-03-31 15:32:34 --> Total execution time: 0.7154
INFO - 2020-03-31 15:32:46 --> Config Class Initialized
INFO - 2020-03-31 15:32:46 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:32:46 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:32:46 --> Utf8 Class Initialized
INFO - 2020-03-31 15:32:46 --> URI Class Initialized
INFO - 2020-03-31 15:32:46 --> Router Class Initialized
INFO - 2020-03-31 15:32:46 --> Output Class Initialized
INFO - 2020-03-31 15:32:46 --> Security Class Initialized
DEBUG - 2020-03-31 15:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:32:46 --> CSRF cookie sent
INFO - 2020-03-31 15:32:46 --> Input Class Initialized
INFO - 2020-03-31 15:32:46 --> Language Class Initialized
INFO - 2020-03-31 15:32:46 --> Language Class Initialized
INFO - 2020-03-31 15:32:46 --> Config Class Initialized
INFO - 2020-03-31 15:32:46 --> Loader Class Initialized
INFO - 2020-03-31 15:32:46 --> Helper loaded: url_helper
INFO - 2020-03-31 15:32:46 --> Helper loaded: common_helper
INFO - 2020-03-31 15:32:46 --> Helper loaded: language_helper
INFO - 2020-03-31 15:32:46 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:32:46 --> Helper loaded: email_helper
INFO - 2020-03-31 15:32:46 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:32:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:32:46 --> Parser Class Initialized
INFO - 2020-03-31 15:32:46 --> User Agent Class Initialized
INFO - 2020-03-31 15:32:46 --> Model Class Initialized
INFO - 2020-03-31 15:32:46 --> Database Driver Class Initialized
INFO - 2020-03-31 15:32:46 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:46 --> Template Class Initialized
INFO - 2020-03-31 15:32:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:32:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:32:46 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:32:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:32:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:32:46 --> Encryption Class Initialized
INFO - 2020-03-31 15:32:47 --> Controller Class Initialized
DEBUG - 2020-03-31 15:32:47 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:32:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:32:47 --> Model Class Initialized
ERROR - 2020-03-31 15:32:47 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:32:47 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:32:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:32:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:32:47 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:32:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:32:47 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:32:47 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:32:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:32:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:32:47 --> Final output sent to browser
DEBUG - 2020-03-31 15:32:47 --> Total execution time: 0.6815
INFO - 2020-03-31 15:32:51 --> Config Class Initialized
INFO - 2020-03-31 15:32:51 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:32:51 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:32:51 --> Utf8 Class Initialized
INFO - 2020-03-31 15:32:51 --> URI Class Initialized
INFO - 2020-03-31 15:32:51 --> Router Class Initialized
INFO - 2020-03-31 15:32:51 --> Output Class Initialized
INFO - 2020-03-31 15:32:51 --> Security Class Initialized
DEBUG - 2020-03-31 15:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:32:51 --> CSRF cookie sent
INFO - 2020-03-31 15:32:51 --> Input Class Initialized
INFO - 2020-03-31 15:32:51 --> Language Class Initialized
INFO - 2020-03-31 15:32:51 --> Language Class Initialized
INFO - 2020-03-31 15:32:51 --> Config Class Initialized
INFO - 2020-03-31 15:32:51 --> Loader Class Initialized
INFO - 2020-03-31 15:32:51 --> Helper loaded: url_helper
INFO - 2020-03-31 15:32:51 --> Helper loaded: common_helper
INFO - 2020-03-31 15:32:51 --> Helper loaded: language_helper
INFO - 2020-03-31 15:32:51 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:32:51 --> Helper loaded: email_helper
INFO - 2020-03-31 15:32:51 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:32:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:32:51 --> Parser Class Initialized
INFO - 2020-03-31 15:32:51 --> User Agent Class Initialized
INFO - 2020-03-31 15:32:51 --> Model Class Initialized
INFO - 2020-03-31 15:32:51 --> Database Driver Class Initialized
INFO - 2020-03-31 15:32:51 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:51 --> Template Class Initialized
INFO - 2020-03-31 15:32:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:32:51 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:32:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:32:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:32:51 --> Encryption Class Initialized
INFO - 2020-03-31 15:32:51 --> Controller Class Initialized
DEBUG - 2020-03-31 15:32:51 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:32:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:32:51 --> Model Class Initialized
ERROR - 2020-03-31 15:32:51 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:32:51 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:32:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:32:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:32:51 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:32:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:32:51 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:32:51 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:32:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:32:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:32:51 --> Final output sent to browser
DEBUG - 2020-03-31 15:32:51 --> Total execution time: 0.7291
INFO - 2020-03-31 15:32:57 --> Config Class Initialized
INFO - 2020-03-31 15:32:57 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:32:57 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:32:57 --> Utf8 Class Initialized
INFO - 2020-03-31 15:32:57 --> URI Class Initialized
INFO - 2020-03-31 15:32:57 --> Router Class Initialized
INFO - 2020-03-31 15:32:57 --> Output Class Initialized
INFO - 2020-03-31 15:32:57 --> Security Class Initialized
DEBUG - 2020-03-31 15:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:32:57 --> CSRF cookie sent
INFO - 2020-03-31 15:32:57 --> Input Class Initialized
INFO - 2020-03-31 15:32:57 --> Language Class Initialized
INFO - 2020-03-31 15:32:57 --> Language Class Initialized
INFO - 2020-03-31 15:32:57 --> Config Class Initialized
INFO - 2020-03-31 15:32:57 --> Loader Class Initialized
INFO - 2020-03-31 15:32:57 --> Helper loaded: url_helper
INFO - 2020-03-31 15:32:57 --> Helper loaded: common_helper
INFO - 2020-03-31 15:32:57 --> Helper loaded: language_helper
INFO - 2020-03-31 15:32:57 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:32:57 --> Helper loaded: email_helper
INFO - 2020-03-31 15:32:57 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:32:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:32:57 --> Parser Class Initialized
INFO - 2020-03-31 15:32:57 --> User Agent Class Initialized
INFO - 2020-03-31 15:32:57 --> Model Class Initialized
INFO - 2020-03-31 15:32:57 --> Database Driver Class Initialized
INFO - 2020-03-31 15:32:57 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:57 --> Template Class Initialized
INFO - 2020-03-31 15:32:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:32:57 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:32:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:32:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:32:57 --> Encryption Class Initialized
INFO - 2020-03-31 15:32:57 --> Controller Class Initialized
DEBUG - 2020-03-31 15:32:57 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:32:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:32:57 --> Model Class Initialized
ERROR - 2020-03-31 15:32:57 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:32:57 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:32:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:32:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:32:57 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:32:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:32:57 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:32:57 --> Model Class Initialized
DEBUG - 2020-03-31 15:32:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:32:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:32:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:32:57 --> Final output sent to browser
DEBUG - 2020-03-31 15:32:57 --> Total execution time: 0.6683
INFO - 2020-03-31 15:33:01 --> Config Class Initialized
INFO - 2020-03-31 15:33:01 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:33:01 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:33:01 --> Utf8 Class Initialized
INFO - 2020-03-31 15:33:01 --> URI Class Initialized
INFO - 2020-03-31 15:33:01 --> Router Class Initialized
INFO - 2020-03-31 15:33:01 --> Output Class Initialized
INFO - 2020-03-31 15:33:01 --> Security Class Initialized
DEBUG - 2020-03-31 15:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:33:01 --> CSRF cookie sent
INFO - 2020-03-31 15:33:01 --> Input Class Initialized
INFO - 2020-03-31 15:33:01 --> Language Class Initialized
INFO - 2020-03-31 15:33:01 --> Language Class Initialized
INFO - 2020-03-31 15:33:01 --> Config Class Initialized
INFO - 2020-03-31 15:33:01 --> Loader Class Initialized
INFO - 2020-03-31 15:33:01 --> Helper loaded: url_helper
INFO - 2020-03-31 15:33:01 --> Helper loaded: common_helper
INFO - 2020-03-31 15:33:01 --> Helper loaded: language_helper
INFO - 2020-03-31 15:33:01 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:33:01 --> Helper loaded: email_helper
INFO - 2020-03-31 15:33:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:33:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:33:01 --> Parser Class Initialized
INFO - 2020-03-31 15:33:01 --> User Agent Class Initialized
INFO - 2020-03-31 15:33:01 --> Model Class Initialized
INFO - 2020-03-31 15:33:01 --> Database Driver Class Initialized
INFO - 2020-03-31 15:33:01 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:01 --> Template Class Initialized
INFO - 2020-03-31 15:33:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:33:01 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:33:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:33:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:33:01 --> Encryption Class Initialized
INFO - 2020-03-31 15:33:01 --> Controller Class Initialized
DEBUG - 2020-03-31 15:33:01 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:33:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:33:01 --> Model Class Initialized
ERROR - 2020-03-31 15:33:01 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:33:01 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:33:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:33:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:33:02 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:33:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:33:02 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:33:02 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:33:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:33:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:33:02 --> Final output sent to browser
DEBUG - 2020-03-31 15:33:02 --> Total execution time: 0.7091
INFO - 2020-03-31 15:33:08 --> Config Class Initialized
INFO - 2020-03-31 15:33:08 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:33:08 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:33:08 --> Utf8 Class Initialized
INFO - 2020-03-31 15:33:08 --> URI Class Initialized
INFO - 2020-03-31 15:33:08 --> Router Class Initialized
INFO - 2020-03-31 15:33:08 --> Output Class Initialized
INFO - 2020-03-31 15:33:08 --> Security Class Initialized
DEBUG - 2020-03-31 15:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:33:08 --> CSRF cookie sent
INFO - 2020-03-31 15:33:08 --> Input Class Initialized
INFO - 2020-03-31 15:33:08 --> Language Class Initialized
INFO - 2020-03-31 15:33:08 --> Language Class Initialized
INFO - 2020-03-31 15:33:08 --> Config Class Initialized
INFO - 2020-03-31 15:33:08 --> Loader Class Initialized
INFO - 2020-03-31 15:33:08 --> Helper loaded: url_helper
INFO - 2020-03-31 15:33:08 --> Helper loaded: common_helper
INFO - 2020-03-31 15:33:08 --> Helper loaded: language_helper
INFO - 2020-03-31 15:33:08 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:33:08 --> Helper loaded: email_helper
INFO - 2020-03-31 15:33:08 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:33:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:33:08 --> Parser Class Initialized
INFO - 2020-03-31 15:33:08 --> User Agent Class Initialized
INFO - 2020-03-31 15:33:08 --> Model Class Initialized
INFO - 2020-03-31 15:33:08 --> Database Driver Class Initialized
INFO - 2020-03-31 15:33:08 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:08 --> Template Class Initialized
INFO - 2020-03-31 15:33:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:33:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:33:08 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:33:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:33:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:33:08 --> Encryption Class Initialized
INFO - 2020-03-31 15:33:08 --> Controller Class Initialized
DEBUG - 2020-03-31 15:33:08 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:33:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:33:08 --> Model Class Initialized
ERROR - 2020-03-31 15:33:08 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:33:09 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:33:09 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:33:09 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:33:09 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:33:09 --> Final output sent to browser
DEBUG - 2020-03-31 15:33:09 --> Total execution time: 0.6895
INFO - 2020-03-31 15:33:13 --> Config Class Initialized
INFO - 2020-03-31 15:33:13 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:33:13 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:33:13 --> Utf8 Class Initialized
INFO - 2020-03-31 15:33:13 --> URI Class Initialized
INFO - 2020-03-31 15:33:13 --> Router Class Initialized
INFO - 2020-03-31 15:33:13 --> Output Class Initialized
INFO - 2020-03-31 15:33:13 --> Security Class Initialized
DEBUG - 2020-03-31 15:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:33:13 --> CSRF cookie sent
INFO - 2020-03-31 15:33:13 --> Input Class Initialized
INFO - 2020-03-31 15:33:13 --> Language Class Initialized
INFO - 2020-03-31 15:33:13 --> Language Class Initialized
INFO - 2020-03-31 15:33:13 --> Config Class Initialized
INFO - 2020-03-31 15:33:13 --> Loader Class Initialized
INFO - 2020-03-31 15:33:13 --> Helper loaded: url_helper
INFO - 2020-03-31 15:33:13 --> Helper loaded: common_helper
INFO - 2020-03-31 15:33:13 --> Helper loaded: language_helper
INFO - 2020-03-31 15:33:13 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:33:13 --> Helper loaded: email_helper
INFO - 2020-03-31 15:33:13 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:33:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:33:13 --> Parser Class Initialized
INFO - 2020-03-31 15:33:13 --> User Agent Class Initialized
INFO - 2020-03-31 15:33:13 --> Model Class Initialized
INFO - 2020-03-31 15:33:13 --> Database Driver Class Initialized
INFO - 2020-03-31 15:33:13 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:13 --> Template Class Initialized
INFO - 2020-03-31 15:33:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:33:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:33:13 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:33:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:33:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:33:13 --> Encryption Class Initialized
INFO - 2020-03-31 15:33:13 --> Controller Class Initialized
DEBUG - 2020-03-31 15:33:13 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:33:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:33:13 --> Model Class Initialized
ERROR - 2020-03-31 15:33:13 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:33:13 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:33:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:33:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:33:14 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:33:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:33:14 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:33:14 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:33:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:33:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:33:14 --> Final output sent to browser
DEBUG - 2020-03-31 15:33:14 --> Total execution time: 0.7010
INFO - 2020-03-31 15:33:38 --> Config Class Initialized
INFO - 2020-03-31 15:33:38 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:33:38 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:33:38 --> Utf8 Class Initialized
INFO - 2020-03-31 15:33:38 --> URI Class Initialized
INFO - 2020-03-31 15:33:38 --> Router Class Initialized
INFO - 2020-03-31 15:33:38 --> Output Class Initialized
INFO - 2020-03-31 15:33:38 --> Security Class Initialized
DEBUG - 2020-03-31 15:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:33:38 --> CSRF cookie sent
INFO - 2020-03-31 15:33:38 --> Input Class Initialized
INFO - 2020-03-31 15:33:39 --> Language Class Initialized
INFO - 2020-03-31 15:33:39 --> Language Class Initialized
INFO - 2020-03-31 15:33:39 --> Config Class Initialized
INFO - 2020-03-31 15:33:39 --> Loader Class Initialized
INFO - 2020-03-31 15:33:39 --> Helper loaded: url_helper
INFO - 2020-03-31 15:33:39 --> Helper loaded: common_helper
INFO - 2020-03-31 15:33:39 --> Helper loaded: language_helper
INFO - 2020-03-31 15:33:39 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:33:39 --> Helper loaded: email_helper
INFO - 2020-03-31 15:33:39 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:33:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:33:39 --> Parser Class Initialized
INFO - 2020-03-31 15:33:39 --> User Agent Class Initialized
INFO - 2020-03-31 15:33:39 --> Model Class Initialized
INFO - 2020-03-31 15:33:39 --> Database Driver Class Initialized
INFO - 2020-03-31 15:33:39 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:39 --> Template Class Initialized
INFO - 2020-03-31 15:33:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:33:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:33:39 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:33:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:33:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:33:39 --> Encryption Class Initialized
INFO - 2020-03-31 15:33:39 --> Controller Class Initialized
DEBUG - 2020-03-31 15:33:39 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:33:39 --> Model Class Initialized
ERROR - 2020-03-31 15:33:39 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:33:39 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:33:39 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:33:39 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:33:39 --> Model Class Initialized
DEBUG - 2020-03-31 15:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:33:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:33:39 --> Final output sent to browser
DEBUG - 2020-03-31 15:33:39 --> Total execution time: 0.7350
INFO - 2020-03-31 15:40:18 --> Config Class Initialized
INFO - 2020-03-31 15:40:18 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:40:18 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:40:18 --> Utf8 Class Initialized
INFO - 2020-03-31 15:40:18 --> URI Class Initialized
INFO - 2020-03-31 15:40:18 --> Router Class Initialized
INFO - 2020-03-31 15:40:18 --> Output Class Initialized
INFO - 2020-03-31 15:40:18 --> Security Class Initialized
DEBUG - 2020-03-31 15:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:40:18 --> CSRF cookie sent
INFO - 2020-03-31 15:40:18 --> Input Class Initialized
INFO - 2020-03-31 15:40:18 --> Language Class Initialized
INFO - 2020-03-31 15:40:18 --> Language Class Initialized
INFO - 2020-03-31 15:40:18 --> Config Class Initialized
INFO - 2020-03-31 15:40:18 --> Loader Class Initialized
INFO - 2020-03-31 15:40:18 --> Helper loaded: url_helper
INFO - 2020-03-31 15:40:18 --> Helper loaded: common_helper
INFO - 2020-03-31 15:40:18 --> Helper loaded: language_helper
INFO - 2020-03-31 15:40:18 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:40:18 --> Helper loaded: email_helper
INFO - 2020-03-31 15:40:18 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:40:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:40:18 --> Parser Class Initialized
INFO - 2020-03-31 15:40:18 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:40:18 --> Template Class Initialized
INFO - 2020-03-31 15:40:18 --> Database Driver Class Initialized
INFO - 2020-03-31 15:40:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:40:18 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:40:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:40:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:40:18 --> Encryption Class Initialized
INFO - 2020-03-31 15:40:18 --> Controller Class Initialized
DEBUG - 2020-03-31 15:40:18 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:40:18 --> Model Class Initialized
INFO - 2020-03-31 15:40:18 --> Model Class Initialized
INFO - 2020-03-31 15:40:18 --> Model Class Initialized
INFO - 2020-03-31 15:40:19 --> Final output sent to browser
DEBUG - 2020-03-31 15:40:19 --> Total execution time: 1.5828
ERROR - 2020-03-31 15:40:19 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:40:19 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:40:39 --> Config Class Initialized
INFO - 2020-03-31 15:40:39 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:40:39 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:40:39 --> Utf8 Class Initialized
INFO - 2020-03-31 15:40:39 --> URI Class Initialized
INFO - 2020-03-31 15:40:39 --> Router Class Initialized
INFO - 2020-03-31 15:40:39 --> Output Class Initialized
INFO - 2020-03-31 15:40:39 --> Security Class Initialized
DEBUG - 2020-03-31 15:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:40:39 --> CSRF cookie sent
INFO - 2020-03-31 15:40:39 --> Input Class Initialized
INFO - 2020-03-31 15:40:40 --> Language Class Initialized
INFO - 2020-03-31 15:40:40 --> Language Class Initialized
INFO - 2020-03-31 15:40:40 --> Config Class Initialized
INFO - 2020-03-31 15:40:40 --> Loader Class Initialized
INFO - 2020-03-31 15:40:40 --> Helper loaded: url_helper
INFO - 2020-03-31 15:40:40 --> Helper loaded: common_helper
INFO - 2020-03-31 15:40:40 --> Helper loaded: language_helper
INFO - 2020-03-31 15:40:40 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:40:40 --> Helper loaded: email_helper
INFO - 2020-03-31 15:40:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:40:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:40:40 --> Parser Class Initialized
INFO - 2020-03-31 15:40:40 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:40:40 --> Template Class Initialized
INFO - 2020-03-31 15:40:40 --> Database Driver Class Initialized
INFO - 2020-03-31 15:40:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:40:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:40:40 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:40:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:40:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:40:40 --> Encryption Class Initialized
INFO - 2020-03-31 15:40:40 --> Controller Class Initialized
DEBUG - 2020-03-31 15:40:40 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:40:40 --> Model Class Initialized
INFO - 2020-03-31 15:40:40 --> Model Class Initialized
INFO - 2020-03-31 15:40:40 --> Model Class Initialized
ERROR - 2020-03-31 15:40:40 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:40:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:41:02 --> Config Class Initialized
INFO - 2020-03-31 15:41:02 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:41:02 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:41:02 --> Utf8 Class Initialized
INFO - 2020-03-31 15:41:02 --> URI Class Initialized
INFO - 2020-03-31 15:41:02 --> Router Class Initialized
INFO - 2020-03-31 15:41:02 --> Output Class Initialized
INFO - 2020-03-31 15:41:02 --> Security Class Initialized
DEBUG - 2020-03-31 15:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:41:02 --> CSRF cookie sent
INFO - 2020-03-31 15:41:02 --> Input Class Initialized
INFO - 2020-03-31 15:41:02 --> Language Class Initialized
INFO - 2020-03-31 15:41:02 --> Language Class Initialized
INFO - 2020-03-31 15:41:02 --> Config Class Initialized
INFO - 2020-03-31 15:41:02 --> Loader Class Initialized
INFO - 2020-03-31 15:41:02 --> Helper loaded: url_helper
INFO - 2020-03-31 15:41:02 --> Helper loaded: common_helper
INFO - 2020-03-31 15:41:02 --> Helper loaded: language_helper
INFO - 2020-03-31 15:41:02 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:41:02 --> Helper loaded: email_helper
INFO - 2020-03-31 15:41:02 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:41:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:41:02 --> Parser Class Initialized
INFO - 2020-03-31 15:41:02 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:41:02 --> Template Class Initialized
INFO - 2020-03-31 15:41:02 --> Database Driver Class Initialized
INFO - 2020-03-31 15:41:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:41:02 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:41:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:41:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:41:02 --> Encryption Class Initialized
INFO - 2020-03-31 15:41:02 --> Controller Class Initialized
DEBUG - 2020-03-31 15:41:02 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:41:02 --> Model Class Initialized
INFO - 2020-03-31 15:41:02 --> Model Class Initialized
INFO - 2020-03-31 15:41:03 --> Model Class Initialized
ERROR - 2020-03-31 15:41:03 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:41:03 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:41:10 --> Config Class Initialized
INFO - 2020-03-31 15:41:10 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:41:10 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:41:10 --> Utf8 Class Initialized
INFO - 2020-03-31 15:41:10 --> URI Class Initialized
INFO - 2020-03-31 15:41:10 --> Router Class Initialized
INFO - 2020-03-31 15:41:10 --> Output Class Initialized
INFO - 2020-03-31 15:41:10 --> Security Class Initialized
DEBUG - 2020-03-31 15:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:41:10 --> CSRF cookie sent
INFO - 2020-03-31 15:41:10 --> Input Class Initialized
INFO - 2020-03-31 15:41:10 --> Language Class Initialized
INFO - 2020-03-31 15:41:10 --> Language Class Initialized
INFO - 2020-03-31 15:41:10 --> Config Class Initialized
INFO - 2020-03-31 15:41:10 --> Loader Class Initialized
INFO - 2020-03-31 15:41:10 --> Helper loaded: url_helper
INFO - 2020-03-31 15:41:10 --> Helper loaded: common_helper
INFO - 2020-03-31 15:41:10 --> Helper loaded: language_helper
INFO - 2020-03-31 15:41:10 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:41:10 --> Helper loaded: email_helper
INFO - 2020-03-31 15:41:10 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:41:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:41:10 --> Parser Class Initialized
INFO - 2020-03-31 15:41:10 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:41:10 --> Template Class Initialized
INFO - 2020-03-31 15:41:10 --> Database Driver Class Initialized
INFO - 2020-03-31 15:41:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:41:10 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:41:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:41:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:41:10 --> Encryption Class Initialized
INFO - 2020-03-31 15:41:10 --> Controller Class Initialized
DEBUG - 2020-03-31 15:41:10 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:41:10 --> Model Class Initialized
INFO - 2020-03-31 15:41:10 --> Model Class Initialized
INFO - 2020-03-31 15:41:10 --> Model Class Initialized
ERROR - 2020-03-31 15:41:11 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:41:11 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:42:04 --> Config Class Initialized
INFO - 2020-03-31 15:42:04 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:42:04 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:42:04 --> Utf8 Class Initialized
INFO - 2020-03-31 15:42:04 --> URI Class Initialized
INFO - 2020-03-31 15:42:04 --> Router Class Initialized
INFO - 2020-03-31 15:42:04 --> Output Class Initialized
INFO - 2020-03-31 15:42:04 --> Security Class Initialized
DEBUG - 2020-03-31 15:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:42:04 --> CSRF cookie sent
INFO - 2020-03-31 15:42:04 --> Input Class Initialized
INFO - 2020-03-31 15:42:04 --> Language Class Initialized
INFO - 2020-03-31 15:42:04 --> Language Class Initialized
INFO - 2020-03-31 15:42:04 --> Config Class Initialized
INFO - 2020-03-31 15:42:04 --> Loader Class Initialized
INFO - 2020-03-31 15:42:04 --> Helper loaded: url_helper
INFO - 2020-03-31 15:42:04 --> Helper loaded: common_helper
INFO - 2020-03-31 15:42:04 --> Helper loaded: language_helper
INFO - 2020-03-31 15:42:04 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:42:04 --> Helper loaded: email_helper
INFO - 2020-03-31 15:42:04 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:42:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:42:04 --> Parser Class Initialized
INFO - 2020-03-31 15:42:04 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:42:04 --> Template Class Initialized
INFO - 2020-03-31 15:42:04 --> Database Driver Class Initialized
INFO - 2020-03-31 15:42:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:42:05 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:42:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:42:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:42:05 --> Encryption Class Initialized
INFO - 2020-03-31 15:42:05 --> Controller Class Initialized
DEBUG - 2020-03-31 15:42:05 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:42:05 --> Model Class Initialized
INFO - 2020-03-31 15:42:05 --> Model Class Initialized
INFO - 2020-03-31 15:42:05 --> Model Class Initialized
ERROR - 2020-03-31 15:42:06 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:42:06 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:42:35 --> Config Class Initialized
INFO - 2020-03-31 15:42:35 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:42:35 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:42:35 --> Utf8 Class Initialized
INFO - 2020-03-31 15:42:35 --> URI Class Initialized
INFO - 2020-03-31 15:42:35 --> Router Class Initialized
INFO - 2020-03-31 15:42:35 --> Output Class Initialized
INFO - 2020-03-31 15:42:35 --> Security Class Initialized
DEBUG - 2020-03-31 15:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:42:35 --> CSRF cookie sent
INFO - 2020-03-31 15:42:35 --> Input Class Initialized
INFO - 2020-03-31 15:42:35 --> Language Class Initialized
INFO - 2020-03-31 15:42:35 --> Language Class Initialized
INFO - 2020-03-31 15:42:35 --> Config Class Initialized
INFO - 2020-03-31 15:42:35 --> Loader Class Initialized
INFO - 2020-03-31 15:42:35 --> Helper loaded: url_helper
INFO - 2020-03-31 15:42:35 --> Helper loaded: common_helper
INFO - 2020-03-31 15:42:35 --> Helper loaded: language_helper
INFO - 2020-03-31 15:42:35 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:42:35 --> Helper loaded: email_helper
INFO - 2020-03-31 15:42:35 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:42:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:42:35 --> Parser Class Initialized
INFO - 2020-03-31 15:42:35 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:42:35 --> Template Class Initialized
INFO - 2020-03-31 15:42:35 --> Database Driver Class Initialized
INFO - 2020-03-31 15:42:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:42:35 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:42:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:42:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:42:35 --> Encryption Class Initialized
INFO - 2020-03-31 15:42:35 --> Controller Class Initialized
DEBUG - 2020-03-31 15:42:35 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:42:35 --> Model Class Initialized
INFO - 2020-03-31 15:42:35 --> Model Class Initialized
INFO - 2020-03-31 15:42:35 --> Model Class Initialized
ERROR - 2020-03-31 15:42:37 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:42:37 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:43:10 --> Config Class Initialized
INFO - 2020-03-31 15:43:10 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:43:10 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:43:10 --> Utf8 Class Initialized
INFO - 2020-03-31 15:43:10 --> URI Class Initialized
INFO - 2020-03-31 15:43:10 --> Router Class Initialized
INFO - 2020-03-31 15:43:10 --> Output Class Initialized
INFO - 2020-03-31 15:43:10 --> Security Class Initialized
DEBUG - 2020-03-31 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:43:10 --> CSRF cookie sent
INFO - 2020-03-31 15:43:10 --> Input Class Initialized
INFO - 2020-03-31 15:43:10 --> Language Class Initialized
INFO - 2020-03-31 15:43:10 --> Language Class Initialized
INFO - 2020-03-31 15:43:10 --> Config Class Initialized
INFO - 2020-03-31 15:43:10 --> Loader Class Initialized
INFO - 2020-03-31 15:43:10 --> Helper loaded: url_helper
INFO - 2020-03-31 15:43:10 --> Helper loaded: common_helper
INFO - 2020-03-31 15:43:10 --> Helper loaded: language_helper
INFO - 2020-03-31 15:43:10 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:43:10 --> Helper loaded: email_helper
INFO - 2020-03-31 15:43:10 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:43:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:43:10 --> Parser Class Initialized
INFO - 2020-03-31 15:43:10 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:43:10 --> Template Class Initialized
INFO - 2020-03-31 15:43:10 --> Database Driver Class Initialized
INFO - 2020-03-31 15:43:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:43:10 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:43:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:43:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:43:10 --> Encryption Class Initialized
INFO - 2020-03-31 15:43:10 --> Controller Class Initialized
DEBUG - 2020-03-31 15:43:10 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:43:10 --> Model Class Initialized
INFO - 2020-03-31 15:43:10 --> Model Class Initialized
INFO - 2020-03-31 15:43:10 --> Model Class Initialized
ERROR - 2020-03-31 15:43:11 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:43:11 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:43:28 --> Config Class Initialized
INFO - 2020-03-31 15:43:28 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:43:28 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:43:28 --> Utf8 Class Initialized
INFO - 2020-03-31 15:43:28 --> URI Class Initialized
INFO - 2020-03-31 15:43:28 --> Router Class Initialized
INFO - 2020-03-31 15:43:28 --> Output Class Initialized
INFO - 2020-03-31 15:43:28 --> Security Class Initialized
DEBUG - 2020-03-31 15:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:43:28 --> CSRF cookie sent
INFO - 2020-03-31 15:43:28 --> Input Class Initialized
INFO - 2020-03-31 15:43:28 --> Language Class Initialized
INFO - 2020-03-31 15:43:28 --> Language Class Initialized
INFO - 2020-03-31 15:43:28 --> Config Class Initialized
INFO - 2020-03-31 15:43:28 --> Loader Class Initialized
INFO - 2020-03-31 15:43:28 --> Helper loaded: url_helper
INFO - 2020-03-31 15:43:28 --> Helper loaded: common_helper
INFO - 2020-03-31 15:43:28 --> Helper loaded: language_helper
INFO - 2020-03-31 15:43:28 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:43:28 --> Helper loaded: email_helper
INFO - 2020-03-31 15:43:28 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:43:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:43:28 --> Parser Class Initialized
INFO - 2020-03-31 15:43:28 --> User Agent Class Initialized
INFO - 2020-03-31 15:43:28 --> Model Class Initialized
INFO - 2020-03-31 15:43:28 --> Database Driver Class Initialized
INFO - 2020-03-31 15:43:28 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:28 --> Template Class Initialized
INFO - 2020-03-31 15:43:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:43:28 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:43:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:43:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:43:28 --> Encryption Class Initialized
INFO - 2020-03-31 15:43:28 --> Controller Class Initialized
DEBUG - 2020-03-31 15:43:28 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:43:28 --> Model Class Initialized
ERROR - 2020-03-31 15:43:28 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:43:28 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:43:28 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:43:28 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:43:28 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:43:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:43:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:43:29 --> Final output sent to browser
DEBUG - 2020-03-31 15:43:29 --> Total execution time: 0.7645
INFO - 2020-03-31 15:43:32 --> Config Class Initialized
INFO - 2020-03-31 15:43:32 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:43:32 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:43:32 --> Utf8 Class Initialized
INFO - 2020-03-31 15:43:32 --> URI Class Initialized
INFO - 2020-03-31 15:43:32 --> Router Class Initialized
INFO - 2020-03-31 15:43:32 --> Output Class Initialized
INFO - 2020-03-31 15:43:32 --> Security Class Initialized
DEBUG - 2020-03-31 15:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:43:32 --> CSRF cookie sent
INFO - 2020-03-31 15:43:32 --> Input Class Initialized
INFO - 2020-03-31 15:43:32 --> Language Class Initialized
INFO - 2020-03-31 15:43:32 --> Language Class Initialized
INFO - 2020-03-31 15:43:32 --> Config Class Initialized
INFO - 2020-03-31 15:43:32 --> Loader Class Initialized
INFO - 2020-03-31 15:43:32 --> Helper loaded: url_helper
INFO - 2020-03-31 15:43:32 --> Helper loaded: common_helper
INFO - 2020-03-31 15:43:32 --> Helper loaded: language_helper
INFO - 2020-03-31 15:43:32 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:43:32 --> Helper loaded: email_helper
INFO - 2020-03-31 15:43:32 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:43:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:43:32 --> Parser Class Initialized
INFO - 2020-03-31 15:43:32 --> User Agent Class Initialized
INFO - 2020-03-31 15:43:32 --> Model Class Initialized
INFO - 2020-03-31 15:43:33 --> Database Driver Class Initialized
INFO - 2020-03-31 15:43:33 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:33 --> Template Class Initialized
INFO - 2020-03-31 15:43:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:43:33 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:43:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:43:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:43:33 --> Encryption Class Initialized
INFO - 2020-03-31 15:43:33 --> Controller Class Initialized
DEBUG - 2020-03-31 15:43:33 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:43:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:43:33 --> Model Class Initialized
ERROR - 2020-03-31 15:43:33 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:43:33 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:43:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:43:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:43:33 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:43:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:43:33 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:43:33 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:43:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:43:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:43:33 --> Final output sent to browser
DEBUG - 2020-03-31 15:43:33 --> Total execution time: 0.8029
INFO - 2020-03-31 15:43:36 --> Config Class Initialized
INFO - 2020-03-31 15:43:36 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:43:36 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:43:36 --> Utf8 Class Initialized
INFO - 2020-03-31 15:43:36 --> URI Class Initialized
INFO - 2020-03-31 15:43:36 --> Router Class Initialized
INFO - 2020-03-31 15:43:36 --> Output Class Initialized
INFO - 2020-03-31 15:43:36 --> Security Class Initialized
DEBUG - 2020-03-31 15:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:43:36 --> CSRF cookie sent
INFO - 2020-03-31 15:43:36 --> Input Class Initialized
INFO - 2020-03-31 15:43:36 --> Language Class Initialized
INFO - 2020-03-31 15:43:36 --> Language Class Initialized
INFO - 2020-03-31 15:43:36 --> Config Class Initialized
INFO - 2020-03-31 15:43:36 --> Loader Class Initialized
INFO - 2020-03-31 15:43:36 --> Helper loaded: url_helper
INFO - 2020-03-31 15:43:36 --> Helper loaded: common_helper
INFO - 2020-03-31 15:43:36 --> Helper loaded: language_helper
INFO - 2020-03-31 15:43:36 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:43:36 --> Helper loaded: email_helper
INFO - 2020-03-31 15:43:36 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:43:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:43:36 --> Parser Class Initialized
INFO - 2020-03-31 15:43:36 --> User Agent Class Initialized
INFO - 2020-03-31 15:43:36 --> Model Class Initialized
INFO - 2020-03-31 15:43:36 --> Database Driver Class Initialized
INFO - 2020-03-31 15:43:36 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:36 --> Template Class Initialized
INFO - 2020-03-31 15:43:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:43:36 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:43:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:43:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:43:36 --> Encryption Class Initialized
INFO - 2020-03-31 15:43:36 --> Controller Class Initialized
DEBUG - 2020-03-31 15:43:36 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:43:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:43:36 --> Model Class Initialized
ERROR - 2020-03-31 15:43:36 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:43:36 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:43:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:43:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:43:36 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:43:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:43:36 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:43:36 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:43:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:43:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:43:36 --> Final output sent to browser
DEBUG - 2020-03-31 15:43:37 --> Total execution time: 0.7645
INFO - 2020-03-31 15:43:42 --> Config Class Initialized
INFO - 2020-03-31 15:43:42 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:43:42 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:43:42 --> Utf8 Class Initialized
INFO - 2020-03-31 15:43:42 --> URI Class Initialized
INFO - 2020-03-31 15:43:42 --> Router Class Initialized
INFO - 2020-03-31 15:43:42 --> Output Class Initialized
INFO - 2020-03-31 15:43:42 --> Security Class Initialized
DEBUG - 2020-03-31 15:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:43:42 --> CSRF cookie sent
INFO - 2020-03-31 15:43:42 --> Input Class Initialized
INFO - 2020-03-31 15:43:42 --> Language Class Initialized
INFO - 2020-03-31 15:43:43 --> Language Class Initialized
INFO - 2020-03-31 15:43:43 --> Config Class Initialized
INFO - 2020-03-31 15:43:43 --> Loader Class Initialized
INFO - 2020-03-31 15:43:43 --> Helper loaded: url_helper
INFO - 2020-03-31 15:43:43 --> Helper loaded: common_helper
INFO - 2020-03-31 15:43:43 --> Helper loaded: language_helper
INFO - 2020-03-31 15:43:43 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:43:43 --> Helper loaded: email_helper
INFO - 2020-03-31 15:43:43 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:43:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:43:43 --> Parser Class Initialized
INFO - 2020-03-31 15:43:43 --> User Agent Class Initialized
INFO - 2020-03-31 15:43:43 --> Model Class Initialized
INFO - 2020-03-31 15:43:43 --> Database Driver Class Initialized
INFO - 2020-03-31 15:43:43 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:43 --> Template Class Initialized
INFO - 2020-03-31 15:43:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:43:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:43:43 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:43:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:43:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:43:43 --> Encryption Class Initialized
INFO - 2020-03-31 15:43:43 --> Controller Class Initialized
DEBUG - 2020-03-31 15:43:43 --> transactions MX_Controller Initialized
DEBUG - 2020-03-31 15:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2020-03-31 15:43:43 --> Model Class Initialized
ERROR - 2020-03-31 15:43:43 --> Could not find the language line "order_id"
INFO - 2020-03-31 15:43:43 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 15:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2020-03-31 15:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 15:43:43 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 15:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 15:43:43 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 15:43:43 --> Model Class Initialized
DEBUG - 2020-03-31 15:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 15:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 15:43:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 15:43:43 --> Final output sent to browser
DEBUG - 2020-03-31 15:43:43 --> Total execution time: 0.7484
INFO - 2020-03-31 15:44:08 --> Config Class Initialized
INFO - 2020-03-31 15:44:08 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:44:08 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:44:08 --> Utf8 Class Initialized
INFO - 2020-03-31 15:44:08 --> URI Class Initialized
INFO - 2020-03-31 15:44:08 --> Router Class Initialized
INFO - 2020-03-31 15:44:08 --> Output Class Initialized
INFO - 2020-03-31 15:44:08 --> Security Class Initialized
DEBUG - 2020-03-31 15:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:44:08 --> CSRF cookie sent
INFO - 2020-03-31 15:44:08 --> Input Class Initialized
INFO - 2020-03-31 15:44:08 --> Language Class Initialized
INFO - 2020-03-31 15:44:08 --> Language Class Initialized
INFO - 2020-03-31 15:44:08 --> Config Class Initialized
INFO - 2020-03-31 15:44:09 --> Loader Class Initialized
INFO - 2020-03-31 15:44:09 --> Helper loaded: url_helper
INFO - 2020-03-31 15:44:09 --> Helper loaded: common_helper
INFO - 2020-03-31 15:44:09 --> Helper loaded: language_helper
INFO - 2020-03-31 15:44:09 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:44:09 --> Helper loaded: email_helper
INFO - 2020-03-31 15:44:09 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:44:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:44:09 --> Parser Class Initialized
INFO - 2020-03-31 15:44:09 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:44:09 --> Template Class Initialized
INFO - 2020-03-31 15:44:09 --> Database Driver Class Initialized
INFO - 2020-03-31 15:44:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:44:09 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:44:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:44:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:44:09 --> Encryption Class Initialized
INFO - 2020-03-31 15:44:09 --> Controller Class Initialized
DEBUG - 2020-03-31 15:44:09 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:44:09 --> Model Class Initialized
INFO - 2020-03-31 15:44:09 --> Model Class Initialized
INFO - 2020-03-31 15:44:09 --> Model Class Initialized
ERROR - 2020-03-31 15:44:10 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:44:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:45:42 --> Config Class Initialized
INFO - 2020-03-31 15:45:42 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:45:42 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:45:42 --> Utf8 Class Initialized
INFO - 2020-03-31 15:45:42 --> URI Class Initialized
INFO - 2020-03-31 15:45:42 --> Router Class Initialized
INFO - 2020-03-31 15:45:42 --> Output Class Initialized
INFO - 2020-03-31 15:45:42 --> Security Class Initialized
DEBUG - 2020-03-31 15:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:45:42 --> CSRF cookie sent
INFO - 2020-03-31 15:45:42 --> Input Class Initialized
INFO - 2020-03-31 15:45:42 --> Language Class Initialized
INFO - 2020-03-31 15:45:42 --> Language Class Initialized
INFO - 2020-03-31 15:45:42 --> Config Class Initialized
INFO - 2020-03-31 15:45:42 --> Loader Class Initialized
INFO - 2020-03-31 15:45:42 --> Helper loaded: url_helper
INFO - 2020-03-31 15:45:42 --> Helper loaded: common_helper
INFO - 2020-03-31 15:45:42 --> Helper loaded: language_helper
INFO - 2020-03-31 15:45:42 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:45:42 --> Helper loaded: email_helper
INFO - 2020-03-31 15:45:42 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:45:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:45:42 --> Parser Class Initialized
INFO - 2020-03-31 15:45:42 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:45:42 --> Template Class Initialized
INFO - 2020-03-31 15:45:42 --> Database Driver Class Initialized
INFO - 2020-03-31 15:45:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:45:42 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:45:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:45:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:45:42 --> Encryption Class Initialized
INFO - 2020-03-31 15:45:42 --> Controller Class Initialized
DEBUG - 2020-03-31 15:45:42 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:45:42 --> Model Class Initialized
INFO - 2020-03-31 15:45:42 --> Model Class Initialized
INFO - 2020-03-31 15:45:42 --> Model Class Initialized
ERROR - 2020-03-31 15:45:42 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:45:42 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:47:51 --> Config Class Initialized
INFO - 2020-03-31 15:47:51 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:47:51 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:47:51 --> Utf8 Class Initialized
INFO - 2020-03-31 15:47:51 --> URI Class Initialized
INFO - 2020-03-31 15:47:51 --> Router Class Initialized
INFO - 2020-03-31 15:47:51 --> Output Class Initialized
INFO - 2020-03-31 15:47:51 --> Security Class Initialized
DEBUG - 2020-03-31 15:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:47:51 --> CSRF cookie sent
INFO - 2020-03-31 15:47:51 --> Input Class Initialized
INFO - 2020-03-31 15:47:51 --> Language Class Initialized
INFO - 2020-03-31 15:47:51 --> Language Class Initialized
INFO - 2020-03-31 15:47:51 --> Config Class Initialized
INFO - 2020-03-31 15:47:52 --> Loader Class Initialized
INFO - 2020-03-31 15:47:52 --> Helper loaded: url_helper
INFO - 2020-03-31 15:47:52 --> Helper loaded: common_helper
INFO - 2020-03-31 15:47:52 --> Helper loaded: language_helper
INFO - 2020-03-31 15:47:52 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:47:52 --> Helper loaded: email_helper
INFO - 2020-03-31 15:47:52 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:47:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:47:52 --> Parser Class Initialized
INFO - 2020-03-31 15:47:52 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:47:52 --> Template Class Initialized
INFO - 2020-03-31 15:47:52 --> Database Driver Class Initialized
INFO - 2020-03-31 15:47:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:47:52 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:47:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:47:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:47:52 --> Encryption Class Initialized
INFO - 2020-03-31 15:47:52 --> Controller Class Initialized
DEBUG - 2020-03-31 15:47:52 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:47:52 --> Model Class Initialized
INFO - 2020-03-31 15:47:52 --> Model Class Initialized
INFO - 2020-03-31 15:47:52 --> Model Class Initialized
ERROR - 2020-03-31 15:47:52 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:47:52 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:48:07 --> Config Class Initialized
INFO - 2020-03-31 15:48:07 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:48:07 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:48:07 --> Utf8 Class Initialized
INFO - 2020-03-31 15:48:07 --> URI Class Initialized
INFO - 2020-03-31 15:48:07 --> Router Class Initialized
INFO - 2020-03-31 15:48:07 --> Output Class Initialized
INFO - 2020-03-31 15:48:07 --> Security Class Initialized
DEBUG - 2020-03-31 15:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:48:08 --> CSRF cookie sent
INFO - 2020-03-31 15:48:08 --> Input Class Initialized
INFO - 2020-03-31 15:48:08 --> Language Class Initialized
INFO - 2020-03-31 15:48:08 --> Language Class Initialized
INFO - 2020-03-31 15:48:08 --> Config Class Initialized
INFO - 2020-03-31 15:48:08 --> Loader Class Initialized
INFO - 2020-03-31 15:48:08 --> Helper loaded: url_helper
INFO - 2020-03-31 15:48:08 --> Helper loaded: common_helper
INFO - 2020-03-31 15:48:08 --> Helper loaded: language_helper
INFO - 2020-03-31 15:48:08 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:48:08 --> Helper loaded: email_helper
INFO - 2020-03-31 15:48:08 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:48:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:48:08 --> Parser Class Initialized
INFO - 2020-03-31 15:48:08 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:48:08 --> Template Class Initialized
INFO - 2020-03-31 15:48:08 --> Database Driver Class Initialized
INFO - 2020-03-31 15:48:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:48:08 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:48:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:48:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:48:08 --> Encryption Class Initialized
INFO - 2020-03-31 15:48:08 --> Controller Class Initialized
DEBUG - 2020-03-31 15:48:08 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:48:08 --> Model Class Initialized
INFO - 2020-03-31 15:48:08 --> Model Class Initialized
INFO - 2020-03-31 15:48:08 --> Model Class Initialized
ERROR - 2020-03-31 15:48:08 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:48:08 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:48:48 --> Config Class Initialized
INFO - 2020-03-31 15:48:48 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:48:48 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:48:48 --> Utf8 Class Initialized
INFO - 2020-03-31 15:48:48 --> URI Class Initialized
INFO - 2020-03-31 15:48:48 --> Router Class Initialized
INFO - 2020-03-31 15:48:48 --> Output Class Initialized
INFO - 2020-03-31 15:48:48 --> Security Class Initialized
DEBUG - 2020-03-31 15:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:48:48 --> CSRF cookie sent
INFO - 2020-03-31 15:48:48 --> Input Class Initialized
INFO - 2020-03-31 15:48:48 --> Language Class Initialized
INFO - 2020-03-31 15:48:48 --> Language Class Initialized
INFO - 2020-03-31 15:48:48 --> Config Class Initialized
INFO - 2020-03-31 15:48:48 --> Loader Class Initialized
INFO - 2020-03-31 15:48:48 --> Helper loaded: url_helper
INFO - 2020-03-31 15:48:48 --> Helper loaded: common_helper
INFO - 2020-03-31 15:48:48 --> Helper loaded: language_helper
INFO - 2020-03-31 15:48:48 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:48:48 --> Helper loaded: email_helper
INFO - 2020-03-31 15:48:48 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:48:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:48:48 --> Parser Class Initialized
INFO - 2020-03-31 15:48:48 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:48:48 --> Template Class Initialized
INFO - 2020-03-31 15:48:48 --> Database Driver Class Initialized
INFO - 2020-03-31 15:48:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:48:48 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:48:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:48:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:48:48 --> Encryption Class Initialized
INFO - 2020-03-31 15:48:48 --> Controller Class Initialized
DEBUG - 2020-03-31 15:48:48 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:48:48 --> Model Class Initialized
INFO - 2020-03-31 15:48:48 --> Model Class Initialized
INFO - 2020-03-31 15:48:48 --> Model Class Initialized
ERROR - 2020-03-31 15:48:48 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:48:48 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 15:59:01 --> Config Class Initialized
INFO - 2020-03-31 15:59:01 --> Hooks Class Initialized
DEBUG - 2020-03-31 15:59:01 --> UTF-8 Support Enabled
INFO - 2020-03-31 15:59:01 --> Utf8 Class Initialized
INFO - 2020-03-31 15:59:01 --> URI Class Initialized
INFO - 2020-03-31 15:59:01 --> Router Class Initialized
INFO - 2020-03-31 15:59:01 --> Output Class Initialized
INFO - 2020-03-31 15:59:01 --> Security Class Initialized
DEBUG - 2020-03-31 15:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 15:59:01 --> CSRF cookie sent
INFO - 2020-03-31 15:59:01 --> Input Class Initialized
INFO - 2020-03-31 15:59:01 --> Language Class Initialized
INFO - 2020-03-31 15:59:01 --> Language Class Initialized
INFO - 2020-03-31 15:59:01 --> Config Class Initialized
INFO - 2020-03-31 15:59:01 --> Loader Class Initialized
INFO - 2020-03-31 15:59:01 --> Helper loaded: url_helper
INFO - 2020-03-31 15:59:01 --> Helper loaded: common_helper
INFO - 2020-03-31 15:59:01 --> Helper loaded: language_helper
INFO - 2020-03-31 15:59:01 --> Helper loaded: cookie_helper
INFO - 2020-03-31 15:59:01 --> Helper loaded: email_helper
INFO - 2020-03-31 15:59:01 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 15:59:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 15:59:01 --> Parser Class Initialized
INFO - 2020-03-31 15:59:01 --> User Agent Class Initialized
DEBUG - 2020-03-31 15:59:01 --> Template Class Initialized
INFO - 2020-03-31 15:59:01 --> Database Driver Class Initialized
INFO - 2020-03-31 15:59:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 15:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 15:59:01 --> Pagination Class Initialized
DEBUG - 2020-03-31 15:59:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 15:59:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 15:59:01 --> Encryption Class Initialized
INFO - 2020-03-31 15:59:01 --> Controller Class Initialized
DEBUG - 2020-03-31 15:59:01 --> payop MX_Controller Initialized
INFO - 2020-03-31 15:59:01 --> Model Class Initialized
INFO - 2020-03-31 15:59:01 --> Model Class Initialized
INFO - 2020-03-31 15:59:01 --> Model Class Initialized
ERROR - 2020-03-31 15:59:01 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 15:59:01 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 16:00:18 --> Config Class Initialized
INFO - 2020-03-31 16:00:18 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:00:18 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:00:18 --> Utf8 Class Initialized
INFO - 2020-03-31 16:00:18 --> URI Class Initialized
INFO - 2020-03-31 16:00:18 --> Router Class Initialized
INFO - 2020-03-31 16:00:18 --> Output Class Initialized
INFO - 2020-03-31 16:00:18 --> Security Class Initialized
DEBUG - 2020-03-31 16:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:00:18 --> CSRF cookie sent
INFO - 2020-03-31 16:00:18 --> Input Class Initialized
INFO - 2020-03-31 16:00:18 --> Language Class Initialized
INFO - 2020-03-31 16:00:18 --> Language Class Initialized
INFO - 2020-03-31 16:00:18 --> Config Class Initialized
INFO - 2020-03-31 16:00:18 --> Loader Class Initialized
INFO - 2020-03-31 16:00:18 --> Helper loaded: url_helper
INFO - 2020-03-31 16:00:18 --> Helper loaded: common_helper
INFO - 2020-03-31 16:00:18 --> Helper loaded: language_helper
INFO - 2020-03-31 16:00:18 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:00:18 --> Helper loaded: email_helper
INFO - 2020-03-31 16:00:18 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:00:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:00:18 --> Parser Class Initialized
INFO - 2020-03-31 16:00:18 --> User Agent Class Initialized
DEBUG - 2020-03-31 16:00:18 --> Template Class Initialized
INFO - 2020-03-31 16:00:18 --> Database Driver Class Initialized
INFO - 2020-03-31 16:00:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:00:19 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:00:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:00:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:00:19 --> Encryption Class Initialized
INFO - 2020-03-31 16:00:19 --> Controller Class Initialized
DEBUG - 2020-03-31 16:00:19 --> payop MX_Controller Initialized
INFO - 2020-03-31 16:00:19 --> Model Class Initialized
INFO - 2020-03-31 16:00:19 --> Model Class Initialized
INFO - 2020-03-31 16:00:19 --> Model Class Initialized
ERROR - 2020-03-31 16:00:19 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 16:00:19 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 16:00:29 --> Config Class Initialized
INFO - 2020-03-31 16:00:29 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:00:29 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:00:29 --> Utf8 Class Initialized
INFO - 2020-03-31 16:00:29 --> URI Class Initialized
INFO - 2020-03-31 16:00:29 --> Router Class Initialized
INFO - 2020-03-31 16:00:29 --> Output Class Initialized
INFO - 2020-03-31 16:00:29 --> Security Class Initialized
DEBUG - 2020-03-31 16:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:00:29 --> CSRF cookie sent
INFO - 2020-03-31 16:00:29 --> Input Class Initialized
INFO - 2020-03-31 16:00:29 --> Language Class Initialized
INFO - 2020-03-31 16:00:29 --> Language Class Initialized
INFO - 2020-03-31 16:00:29 --> Config Class Initialized
INFO - 2020-03-31 16:00:29 --> Loader Class Initialized
INFO - 2020-03-31 16:00:29 --> Helper loaded: url_helper
INFO - 2020-03-31 16:00:29 --> Helper loaded: common_helper
INFO - 2020-03-31 16:00:29 --> Helper loaded: language_helper
INFO - 2020-03-31 16:00:29 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:00:29 --> Helper loaded: email_helper
INFO - 2020-03-31 16:00:29 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:00:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:00:29 --> Parser Class Initialized
INFO - 2020-03-31 16:00:29 --> User Agent Class Initialized
DEBUG - 2020-03-31 16:00:29 --> Template Class Initialized
INFO - 2020-03-31 16:00:29 --> Database Driver Class Initialized
INFO - 2020-03-31 16:00:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:00:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:00:29 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:00:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:00:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:00:29 --> Encryption Class Initialized
INFO - 2020-03-31 16:00:29 --> Controller Class Initialized
DEBUG - 2020-03-31 16:00:29 --> payop MX_Controller Initialized
INFO - 2020-03-31 16:00:29 --> Model Class Initialized
INFO - 2020-03-31 16:00:29 --> Model Class Initialized
INFO - 2020-03-31 16:00:29 --> Model Class Initialized
ERROR - 2020-03-31 16:00:29 --> Query error: Unknown column 'o.order_id' in 'field list' - Invalid query: SELECT `o`.`order_id`, `u`.`email` as `user_email`, `s`.`name` as `service_name`
FROM `orders` `o`
LEFT JOIN `services` `s` ON `s`.`id` = `o`.`service_id`
LEFT JOIN `general_users` `u` ON `u`.`id` = `o`.`uid`
WHERE `o`.`id` = '48553'
INFO - 2020-03-31 16:00:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-03-31 16:00:29 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 16:00:29 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 16:00:39 --> Config Class Initialized
INFO - 2020-03-31 16:00:39 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:00:39 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:00:39 --> Utf8 Class Initialized
INFO - 2020-03-31 16:00:39 --> URI Class Initialized
INFO - 2020-03-31 16:00:39 --> Router Class Initialized
INFO - 2020-03-31 16:00:39 --> Output Class Initialized
INFO - 2020-03-31 16:00:39 --> Security Class Initialized
DEBUG - 2020-03-31 16:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:00:39 --> CSRF cookie sent
INFO - 2020-03-31 16:00:39 --> Input Class Initialized
INFO - 2020-03-31 16:00:39 --> Language Class Initialized
INFO - 2020-03-31 16:00:39 --> Language Class Initialized
INFO - 2020-03-31 16:00:39 --> Config Class Initialized
INFO - 2020-03-31 16:00:39 --> Loader Class Initialized
INFO - 2020-03-31 16:00:39 --> Helper loaded: url_helper
INFO - 2020-03-31 16:00:39 --> Helper loaded: common_helper
INFO - 2020-03-31 16:00:39 --> Helper loaded: language_helper
INFO - 2020-03-31 16:00:39 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:00:39 --> Helper loaded: email_helper
INFO - 2020-03-31 16:00:39 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:00:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:00:39 --> Parser Class Initialized
INFO - 2020-03-31 16:00:39 --> User Agent Class Initialized
DEBUG - 2020-03-31 16:00:39 --> Template Class Initialized
INFO - 2020-03-31 16:00:39 --> Database Driver Class Initialized
INFO - 2020-03-31 16:00:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:00:40 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:00:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:00:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:00:40 --> Encryption Class Initialized
INFO - 2020-03-31 16:00:40 --> Controller Class Initialized
DEBUG - 2020-03-31 16:00:40 --> payop MX_Controller Initialized
INFO - 2020-03-31 16:00:40 --> Model Class Initialized
INFO - 2020-03-31 16:00:40 --> Model Class Initialized
INFO - 2020-03-31 16:00:40 --> Model Class Initialized
ERROR - 2020-03-31 16:00:40 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 16:00:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 16:03:11 --> Config Class Initialized
INFO - 2020-03-31 16:03:11 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:03:11 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:03:11 --> Utf8 Class Initialized
INFO - 2020-03-31 16:03:11 --> URI Class Initialized
INFO - 2020-03-31 16:03:11 --> Router Class Initialized
INFO - 2020-03-31 16:03:11 --> Output Class Initialized
INFO - 2020-03-31 16:03:11 --> Security Class Initialized
DEBUG - 2020-03-31 16:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:03:11 --> CSRF cookie sent
INFO - 2020-03-31 16:03:11 --> Input Class Initialized
INFO - 2020-03-31 16:03:11 --> Language Class Initialized
INFO - 2020-03-31 16:03:11 --> Language Class Initialized
INFO - 2020-03-31 16:03:11 --> Config Class Initialized
INFO - 2020-03-31 16:03:11 --> Loader Class Initialized
INFO - 2020-03-31 16:03:11 --> Helper loaded: url_helper
INFO - 2020-03-31 16:03:11 --> Helper loaded: common_helper
INFO - 2020-03-31 16:03:11 --> Helper loaded: language_helper
INFO - 2020-03-31 16:03:11 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:03:11 --> Helper loaded: email_helper
INFO - 2020-03-31 16:03:11 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:03:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:03:11 --> Parser Class Initialized
INFO - 2020-03-31 16:03:11 --> User Agent Class Initialized
DEBUG - 2020-03-31 16:03:11 --> Template Class Initialized
INFO - 2020-03-31 16:03:11 --> Database Driver Class Initialized
INFO - 2020-03-31 16:03:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:03:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:03:11 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:03:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:03:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:03:11 --> Encryption Class Initialized
INFO - 2020-03-31 16:03:11 --> Controller Class Initialized
DEBUG - 2020-03-31 16:03:11 --> payop MX_Controller Initialized
INFO - 2020-03-31 16:03:11 --> Model Class Initialized
INFO - 2020-03-31 16:03:12 --> Model Class Initialized
INFO - 2020-03-31 16:03:12 --> Model Class Initialized
ERROR - 2020-03-31 16:03:12 --> Severity: Notice --> Undefined property: stdClass::$email D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 170
DEBUG - 2020-03-31 16:03:12 --> orders MX_Controller Initialized
ERROR - 2020-03-31 16:03:12 --> Severity: Notice --> Undefined variable: send_notice_email D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 177
ERROR - 2020-03-31 16:03:12 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 16:03:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 16:03:31 --> Config Class Initialized
INFO - 2020-03-31 16:03:31 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:03:31 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:03:31 --> Utf8 Class Initialized
INFO - 2020-03-31 16:03:31 --> URI Class Initialized
INFO - 2020-03-31 16:03:31 --> Router Class Initialized
INFO - 2020-03-31 16:03:31 --> Output Class Initialized
INFO - 2020-03-31 16:03:31 --> Security Class Initialized
DEBUG - 2020-03-31 16:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:03:31 --> CSRF cookie sent
INFO - 2020-03-31 16:03:31 --> Input Class Initialized
INFO - 2020-03-31 16:03:31 --> Language Class Initialized
INFO - 2020-03-31 16:03:31 --> Language Class Initialized
INFO - 2020-03-31 16:03:31 --> Config Class Initialized
INFO - 2020-03-31 16:03:31 --> Loader Class Initialized
INFO - 2020-03-31 16:03:31 --> Helper loaded: url_helper
INFO - 2020-03-31 16:03:31 --> Helper loaded: common_helper
INFO - 2020-03-31 16:03:31 --> Helper loaded: language_helper
INFO - 2020-03-31 16:03:31 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:03:31 --> Helper loaded: email_helper
INFO - 2020-03-31 16:03:31 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:03:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:03:31 --> Parser Class Initialized
INFO - 2020-03-31 16:03:31 --> User Agent Class Initialized
DEBUG - 2020-03-31 16:03:31 --> Template Class Initialized
INFO - 2020-03-31 16:03:31 --> Database Driver Class Initialized
INFO - 2020-03-31 16:03:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:03:31 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:03:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:03:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:03:31 --> Encryption Class Initialized
INFO - 2020-03-31 16:03:31 --> Controller Class Initialized
DEBUG - 2020-03-31 16:03:31 --> payop MX_Controller Initialized
INFO - 2020-03-31 16:03:31 --> Model Class Initialized
INFO - 2020-03-31 16:03:31 --> Model Class Initialized
INFO - 2020-03-31 16:03:31 --> Model Class Initialized
DEBUG - 2020-03-31 16:03:31 --> orders MX_Controller Initialized
ERROR - 2020-03-31 16:03:31 --> Severity: Notice --> Undefined variable: send_notice_email D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 177
ERROR - 2020-03-31 16:03:31 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 16:03:31 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 16:03:58 --> Config Class Initialized
INFO - 2020-03-31 16:03:58 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:03:58 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:03:58 --> Utf8 Class Initialized
INFO - 2020-03-31 16:03:58 --> URI Class Initialized
INFO - 2020-03-31 16:03:58 --> Router Class Initialized
INFO - 2020-03-31 16:03:58 --> Output Class Initialized
INFO - 2020-03-31 16:03:58 --> Security Class Initialized
DEBUG - 2020-03-31 16:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:03:58 --> CSRF cookie sent
INFO - 2020-03-31 16:03:58 --> Input Class Initialized
INFO - 2020-03-31 16:03:58 --> Language Class Initialized
INFO - 2020-03-31 16:03:58 --> Language Class Initialized
INFO - 2020-03-31 16:03:58 --> Config Class Initialized
INFO - 2020-03-31 16:03:58 --> Loader Class Initialized
INFO - 2020-03-31 16:03:58 --> Helper loaded: url_helper
INFO - 2020-03-31 16:03:58 --> Helper loaded: common_helper
INFO - 2020-03-31 16:03:58 --> Helper loaded: language_helper
INFO - 2020-03-31 16:03:58 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:03:58 --> Helper loaded: email_helper
INFO - 2020-03-31 16:03:58 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:03:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:03:58 --> Parser Class Initialized
INFO - 2020-03-31 16:03:58 --> User Agent Class Initialized
DEBUG - 2020-03-31 16:03:58 --> Template Class Initialized
INFO - 2020-03-31 16:03:58 --> Database Driver Class Initialized
INFO - 2020-03-31 16:03:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:03:58 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:03:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:03:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:03:58 --> Encryption Class Initialized
INFO - 2020-03-31 16:03:58 --> Controller Class Initialized
DEBUG - 2020-03-31 16:03:58 --> payop MX_Controller Initialized
INFO - 2020-03-31 16:03:58 --> Model Class Initialized
INFO - 2020-03-31 16:03:58 --> Model Class Initialized
INFO - 2020-03-31 16:03:58 --> Model Class Initialized
DEBUG - 2020-03-31 16:03:58 --> orders MX_Controller Initialized
ERROR - 2020-03-31 16:03:58 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 16:03:58 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 16:05:55 --> Config Class Initialized
INFO - 2020-03-31 16:05:55 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:05:55 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:05:55 --> Utf8 Class Initialized
INFO - 2020-03-31 16:05:55 --> URI Class Initialized
INFO - 2020-03-31 16:05:55 --> Router Class Initialized
INFO - 2020-03-31 16:05:55 --> Output Class Initialized
INFO - 2020-03-31 16:05:55 --> Security Class Initialized
DEBUG - 2020-03-31 16:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:05:55 --> CSRF cookie sent
INFO - 2020-03-31 16:05:55 --> Input Class Initialized
INFO - 2020-03-31 16:05:55 --> Language Class Initialized
INFO - 2020-03-31 16:05:55 --> Language Class Initialized
INFO - 2020-03-31 16:05:55 --> Config Class Initialized
INFO - 2020-03-31 16:05:55 --> Loader Class Initialized
INFO - 2020-03-31 16:05:55 --> Helper loaded: url_helper
INFO - 2020-03-31 16:05:55 --> Helper loaded: common_helper
INFO - 2020-03-31 16:05:55 --> Helper loaded: language_helper
INFO - 2020-03-31 16:05:55 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:05:55 --> Helper loaded: email_helper
INFO - 2020-03-31 16:05:55 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:05:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:05:55 --> Parser Class Initialized
INFO - 2020-03-31 16:05:55 --> User Agent Class Initialized
INFO - 2020-03-31 16:05:55 --> Model Class Initialized
INFO - 2020-03-31 16:05:55 --> Database Driver Class Initialized
INFO - 2020-03-31 16:05:55 --> Model Class Initialized
DEBUG - 2020-03-31 16:05:55 --> Template Class Initialized
INFO - 2020-03-31 16:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:05:55 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:05:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:05:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:05:55 --> Encryption Class Initialized
INFO - 2020-03-31 16:05:55 --> Controller Class Initialized
DEBUG - 2020-03-31 16:05:55 --> setting MX_Controller Initialized
DEBUG - 2020-03-31 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-31 16:05:55 --> Model Class Initialized
INFO - 2020-03-31 16:05:55 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-31 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2020-03-31 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-31 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:05:55 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:05:55 --> Model Class Initialized
DEBUG - 2020-03-31 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:05:55 --> Model Class Initialized
DEBUG - 2020-03-31 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 16:05:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 16:05:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 16:05:56 --> Final output sent to browser
DEBUG - 2020-03-31 16:05:56 --> Total execution time: 1.0080
INFO - 2020-03-31 16:05:58 --> Config Class Initialized
INFO - 2020-03-31 16:05:58 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:05:58 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:05:58 --> Utf8 Class Initialized
INFO - 2020-03-31 16:05:58 --> URI Class Initialized
INFO - 2020-03-31 16:05:58 --> Router Class Initialized
INFO - 2020-03-31 16:05:58 --> Output Class Initialized
INFO - 2020-03-31 16:05:58 --> Security Class Initialized
DEBUG - 2020-03-31 16:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:05:58 --> CSRF cookie sent
INFO - 2020-03-31 16:05:58 --> Input Class Initialized
INFO - 2020-03-31 16:05:58 --> Language Class Initialized
INFO - 2020-03-31 16:05:58 --> Language Class Initialized
INFO - 2020-03-31 16:05:58 --> Config Class Initialized
INFO - 2020-03-31 16:05:58 --> Loader Class Initialized
INFO - 2020-03-31 16:05:58 --> Helper loaded: url_helper
INFO - 2020-03-31 16:05:58 --> Helper loaded: common_helper
INFO - 2020-03-31 16:05:58 --> Helper loaded: language_helper
INFO - 2020-03-31 16:05:58 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:05:58 --> Helper loaded: email_helper
INFO - 2020-03-31 16:05:58 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:05:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:05:58 --> Parser Class Initialized
INFO - 2020-03-31 16:05:58 --> User Agent Class Initialized
INFO - 2020-03-31 16:05:58 --> Model Class Initialized
INFO - 2020-03-31 16:05:58 --> Database Driver Class Initialized
INFO - 2020-03-31 16:05:58 --> Model Class Initialized
DEBUG - 2020-03-31 16:05:58 --> Template Class Initialized
INFO - 2020-03-31 16:05:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:05:58 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:05:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:05:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:05:58 --> Encryption Class Initialized
INFO - 2020-03-31 16:05:58 --> Controller Class Initialized
DEBUG - 2020-03-31 16:05:58 --> setting MX_Controller Initialized
DEBUG - 2020-03-31 16:05:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-31 16:05:58 --> Model Class Initialized
INFO - 2020-03-31 16:05:58 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:05:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-31 16:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/email_setting.php
DEBUG - 2020-03-31 16:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-31 16:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:05:59 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:05:59 --> Model Class Initialized
DEBUG - 2020-03-31 16:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:05:59 --> Model Class Initialized
DEBUG - 2020-03-31 16:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 16:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 16:05:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 16:05:59 --> Final output sent to browser
DEBUG - 2020-03-31 16:05:59 --> Total execution time: 0.8408
INFO - 2020-03-31 16:06:03 --> Config Class Initialized
INFO - 2020-03-31 16:06:03 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:06:03 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:06:03 --> Utf8 Class Initialized
INFO - 2020-03-31 16:06:03 --> URI Class Initialized
INFO - 2020-03-31 16:06:03 --> Router Class Initialized
INFO - 2020-03-31 16:06:03 --> Output Class Initialized
INFO - 2020-03-31 16:06:03 --> Security Class Initialized
DEBUG - 2020-03-31 16:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:06:03 --> CSRF cookie sent
INFO - 2020-03-31 16:06:03 --> CSRF token verified
INFO - 2020-03-31 16:06:03 --> Input Class Initialized
INFO - 2020-03-31 16:06:03 --> Language Class Initialized
INFO - 2020-03-31 16:06:03 --> Language Class Initialized
INFO - 2020-03-31 16:06:03 --> Config Class Initialized
INFO - 2020-03-31 16:06:03 --> Loader Class Initialized
INFO - 2020-03-31 16:06:03 --> Helper loaded: url_helper
INFO - 2020-03-31 16:06:03 --> Helper loaded: common_helper
INFO - 2020-03-31 16:06:03 --> Helper loaded: language_helper
INFO - 2020-03-31 16:06:03 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:06:03 --> Helper loaded: email_helper
INFO - 2020-03-31 16:06:03 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:06:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:06:03 --> Parser Class Initialized
INFO - 2020-03-31 16:06:03 --> User Agent Class Initialized
INFO - 2020-03-31 16:06:03 --> Model Class Initialized
INFO - 2020-03-31 16:06:03 --> Database Driver Class Initialized
INFO - 2020-03-31 16:06:03 --> Model Class Initialized
DEBUG - 2020-03-31 16:06:03 --> Template Class Initialized
INFO - 2020-03-31 16:06:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:06:03 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:06:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:06:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:06:03 --> Encryption Class Initialized
INFO - 2020-03-31 16:06:03 --> Controller Class Initialized
DEBUG - 2020-03-31 16:06:03 --> setting MX_Controller Initialized
DEBUG - 2020-03-31 16:06:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-31 16:06:03 --> Model Class Initialized
INFO - 2020-03-31 16:06:08 --> Config Class Initialized
INFO - 2020-03-31 16:06:08 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:06:08 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:06:08 --> Utf8 Class Initialized
INFO - 2020-03-31 16:06:08 --> URI Class Initialized
INFO - 2020-03-31 16:06:08 --> Router Class Initialized
INFO - 2020-03-31 16:06:08 --> Output Class Initialized
INFO - 2020-03-31 16:06:08 --> Security Class Initialized
DEBUG - 2020-03-31 16:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:06:08 --> CSRF cookie sent
INFO - 2020-03-31 16:06:08 --> Input Class Initialized
INFO - 2020-03-31 16:06:08 --> Language Class Initialized
INFO - 2020-03-31 16:06:08 --> Language Class Initialized
INFO - 2020-03-31 16:06:08 --> Config Class Initialized
INFO - 2020-03-31 16:06:08 --> Loader Class Initialized
INFO - 2020-03-31 16:06:08 --> Helper loaded: url_helper
INFO - 2020-03-31 16:06:08 --> Helper loaded: common_helper
INFO - 2020-03-31 16:06:08 --> Helper loaded: language_helper
INFO - 2020-03-31 16:06:08 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:06:08 --> Helper loaded: email_helper
INFO - 2020-03-31 16:06:08 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:06:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:06:08 --> Parser Class Initialized
INFO - 2020-03-31 16:06:08 --> User Agent Class Initialized
INFO - 2020-03-31 16:06:08 --> Model Class Initialized
INFO - 2020-03-31 16:06:08 --> Database Driver Class Initialized
INFO - 2020-03-31 16:06:08 --> Model Class Initialized
DEBUG - 2020-03-31 16:06:08 --> Template Class Initialized
INFO - 2020-03-31 16:06:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:06:08 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:06:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:06:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:06:08 --> Encryption Class Initialized
INFO - 2020-03-31 16:06:08 --> Controller Class Initialized
DEBUG - 2020-03-31 16:06:08 --> setting MX_Controller Initialized
DEBUG - 2020-03-31 16:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-31 16:06:08 --> Model Class Initialized
INFO - 2020-03-31 16:06:08 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-31 16:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/email_setting.php
DEBUG - 2020-03-31 16:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-31 16:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:06:08 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:06:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:06:09 --> Model Class Initialized
DEBUG - 2020-03-31 16:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:06:09 --> Model Class Initialized
DEBUG - 2020-03-31 16:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 16:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 16:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 16:06:09 --> Final output sent to browser
DEBUG - 2020-03-31 16:06:09 --> Total execution time: 0.8817
INFO - 2020-03-31 16:06:54 --> Config Class Initialized
INFO - 2020-03-31 16:06:54 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:06:54 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:06:54 --> Utf8 Class Initialized
INFO - 2020-03-31 16:06:54 --> URI Class Initialized
INFO - 2020-03-31 16:06:55 --> Router Class Initialized
INFO - 2020-03-31 16:06:55 --> Output Class Initialized
INFO - 2020-03-31 16:06:55 --> Security Class Initialized
DEBUG - 2020-03-31 16:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:06:55 --> CSRF cookie sent
INFO - 2020-03-31 16:06:55 --> CSRF token verified
INFO - 2020-03-31 16:06:55 --> Input Class Initialized
INFO - 2020-03-31 16:06:55 --> Language Class Initialized
INFO - 2020-03-31 16:06:55 --> Language Class Initialized
INFO - 2020-03-31 16:06:55 --> Config Class Initialized
INFO - 2020-03-31 16:06:55 --> Loader Class Initialized
INFO - 2020-03-31 16:06:55 --> Helper loaded: url_helper
INFO - 2020-03-31 16:06:55 --> Helper loaded: common_helper
INFO - 2020-03-31 16:06:55 --> Helper loaded: language_helper
INFO - 2020-03-31 16:06:55 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:06:55 --> Helper loaded: email_helper
INFO - 2020-03-31 16:06:55 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:06:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:06:55 --> Parser Class Initialized
INFO - 2020-03-31 16:06:55 --> User Agent Class Initialized
INFO - 2020-03-31 16:06:55 --> Model Class Initialized
INFO - 2020-03-31 16:06:55 --> Database Driver Class Initialized
INFO - 2020-03-31 16:06:55 --> Model Class Initialized
DEBUG - 2020-03-31 16:06:55 --> Template Class Initialized
INFO - 2020-03-31 16:06:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:06:55 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:06:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:06:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:06:55 --> Encryption Class Initialized
INFO - 2020-03-31 16:06:55 --> Controller Class Initialized
DEBUG - 2020-03-31 16:06:55 --> setting MX_Controller Initialized
DEBUG - 2020-03-31 16:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-31 16:06:55 --> Model Class Initialized
INFO - 2020-03-31 16:07:00 --> Config Class Initialized
INFO - 2020-03-31 16:07:00 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:07:00 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:07:00 --> Utf8 Class Initialized
INFO - 2020-03-31 16:07:00 --> URI Class Initialized
INFO - 2020-03-31 16:07:00 --> Router Class Initialized
INFO - 2020-03-31 16:07:00 --> Output Class Initialized
INFO - 2020-03-31 16:07:00 --> Security Class Initialized
DEBUG - 2020-03-31 16:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:07:00 --> CSRF cookie sent
INFO - 2020-03-31 16:07:00 --> Input Class Initialized
INFO - 2020-03-31 16:07:00 --> Language Class Initialized
INFO - 2020-03-31 16:07:00 --> Language Class Initialized
INFO - 2020-03-31 16:07:00 --> Config Class Initialized
INFO - 2020-03-31 16:07:00 --> Loader Class Initialized
INFO - 2020-03-31 16:07:00 --> Helper loaded: url_helper
INFO - 2020-03-31 16:07:00 --> Helper loaded: common_helper
INFO - 2020-03-31 16:07:00 --> Helper loaded: language_helper
INFO - 2020-03-31 16:07:00 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:07:00 --> Helper loaded: email_helper
INFO - 2020-03-31 16:07:00 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:07:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:07:00 --> Parser Class Initialized
INFO - 2020-03-31 16:07:00 --> User Agent Class Initialized
INFO - 2020-03-31 16:07:00 --> Model Class Initialized
INFO - 2020-03-31 16:07:00 --> Database Driver Class Initialized
INFO - 2020-03-31 16:07:00 --> Model Class Initialized
DEBUG - 2020-03-31 16:07:00 --> Template Class Initialized
INFO - 2020-03-31 16:07:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:07:00 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:07:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:07:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:07:00 --> Encryption Class Initialized
INFO - 2020-03-31 16:07:00 --> Controller Class Initialized
DEBUG - 2020-03-31 16:07:00 --> setting MX_Controller Initialized
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-31 16:07:00 --> Model Class Initialized
INFO - 2020-03-31 16:07:00 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/email_setting.php
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:07:00 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:07:00 --> Model Class Initialized
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:07:00 --> Model Class Initialized
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 16:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 16:07:00 --> Final output sent to browser
DEBUG - 2020-03-31 16:07:00 --> Total execution time: 0.8252
INFO - 2020-03-31 16:07:09 --> Config Class Initialized
INFO - 2020-03-31 16:07:09 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:07:10 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:07:10 --> Utf8 Class Initialized
INFO - 2020-03-31 16:07:10 --> URI Class Initialized
INFO - 2020-03-31 16:07:10 --> Router Class Initialized
INFO - 2020-03-31 16:07:10 --> Output Class Initialized
INFO - 2020-03-31 16:07:10 --> Security Class Initialized
DEBUG - 2020-03-31 16:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:07:10 --> CSRF cookie sent
INFO - 2020-03-31 16:07:10 --> CSRF token verified
INFO - 2020-03-31 16:07:10 --> Input Class Initialized
INFO - 2020-03-31 16:07:10 --> Language Class Initialized
INFO - 2020-03-31 16:07:10 --> Language Class Initialized
INFO - 2020-03-31 16:07:10 --> Config Class Initialized
INFO - 2020-03-31 16:07:10 --> Loader Class Initialized
INFO - 2020-03-31 16:07:10 --> Helper loaded: url_helper
INFO - 2020-03-31 16:07:10 --> Helper loaded: common_helper
INFO - 2020-03-31 16:07:10 --> Helper loaded: language_helper
INFO - 2020-03-31 16:07:10 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:07:10 --> Helper loaded: email_helper
INFO - 2020-03-31 16:07:10 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:07:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:07:10 --> Parser Class Initialized
INFO - 2020-03-31 16:07:10 --> User Agent Class Initialized
INFO - 2020-03-31 16:07:10 --> Model Class Initialized
INFO - 2020-03-31 16:07:10 --> Database Driver Class Initialized
INFO - 2020-03-31 16:07:10 --> Model Class Initialized
DEBUG - 2020-03-31 16:07:10 --> Template Class Initialized
INFO - 2020-03-31 16:07:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:07:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:07:10 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:07:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:07:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:07:10 --> Encryption Class Initialized
INFO - 2020-03-31 16:07:10 --> Controller Class Initialized
DEBUG - 2020-03-31 16:07:10 --> setting MX_Controller Initialized
DEBUG - 2020-03-31 16:07:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-31 16:07:10 --> Model Class Initialized
INFO - 2020-03-31 16:07:14 --> Config Class Initialized
INFO - 2020-03-31 16:07:14 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:07:14 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:07:14 --> Utf8 Class Initialized
INFO - 2020-03-31 16:07:14 --> URI Class Initialized
INFO - 2020-03-31 16:07:14 --> Router Class Initialized
INFO - 2020-03-31 16:07:14 --> Output Class Initialized
INFO - 2020-03-31 16:07:14 --> Security Class Initialized
DEBUG - 2020-03-31 16:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:07:14 --> CSRF cookie sent
INFO - 2020-03-31 16:07:14 --> Input Class Initialized
INFO - 2020-03-31 16:07:14 --> Language Class Initialized
INFO - 2020-03-31 16:07:14 --> Language Class Initialized
INFO - 2020-03-31 16:07:14 --> Config Class Initialized
INFO - 2020-03-31 16:07:14 --> Loader Class Initialized
INFO - 2020-03-31 16:07:14 --> Helper loaded: url_helper
INFO - 2020-03-31 16:07:14 --> Helper loaded: common_helper
INFO - 2020-03-31 16:07:14 --> Helper loaded: language_helper
INFO - 2020-03-31 16:07:14 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:07:14 --> Helper loaded: email_helper
INFO - 2020-03-31 16:07:14 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:07:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:07:14 --> Parser Class Initialized
INFO - 2020-03-31 16:07:14 --> User Agent Class Initialized
DEBUG - 2020-03-31 16:07:14 --> Template Class Initialized
INFO - 2020-03-31 16:07:14 --> Database Driver Class Initialized
INFO - 2020-03-31 16:07:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:07:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:07:14 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:07:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:07:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:07:14 --> Encryption Class Initialized
INFO - 2020-03-31 16:07:14 --> Controller Class Initialized
DEBUG - 2020-03-31 16:07:14 --> payop MX_Controller Initialized
INFO - 2020-03-31 16:07:14 --> Model Class Initialized
INFO - 2020-03-31 16:07:14 --> Model Class Initialized
INFO - 2020-03-31 16:07:14 --> Model Class Initialized
DEBUG - 2020-03-31 16:07:14 --> orders MX_Controller Initialized
INFO - 2020-03-31 16:07:15 --> Config Class Initialized
INFO - 2020-03-31 16:07:15 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:07:15 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:07:15 --> Utf8 Class Initialized
INFO - 2020-03-31 16:07:15 --> URI Class Initialized
INFO - 2020-03-31 16:07:15 --> Router Class Initialized
INFO - 2020-03-31 16:07:15 --> Output Class Initialized
INFO - 2020-03-31 16:07:15 --> Security Class Initialized
DEBUG - 2020-03-31 16:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:07:15 --> CSRF cookie sent
INFO - 2020-03-31 16:07:15 --> Input Class Initialized
INFO - 2020-03-31 16:07:15 --> Language Class Initialized
INFO - 2020-03-31 16:07:15 --> Language Class Initialized
INFO - 2020-03-31 16:07:15 --> Config Class Initialized
INFO - 2020-03-31 16:07:15 --> Loader Class Initialized
INFO - 2020-03-31 16:07:16 --> Helper loaded: url_helper
INFO - 2020-03-31 16:07:16 --> Helper loaded: common_helper
INFO - 2020-03-31 16:07:16 --> Helper loaded: language_helper
INFO - 2020-03-31 16:07:16 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:07:16 --> Helper loaded: email_helper
INFO - 2020-03-31 16:07:16 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:07:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:07:16 --> Parser Class Initialized
INFO - 2020-03-31 16:07:16 --> User Agent Class Initialized
INFO - 2020-03-31 16:07:16 --> Model Class Initialized
INFO - 2020-03-31 16:07:16 --> Database Driver Class Initialized
INFO - 2020-03-31 16:07:16 --> Model Class Initialized
DEBUG - 2020-03-31 16:07:16 --> Template Class Initialized
ERROR - 2020-03-31 16:07:24 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-03-31 16:07:24 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-03-31 16:07:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:07:24 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:07:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:07:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:07:24 --> Encryption Class Initialized
INFO - 2020-03-31 16:07:24 --> Controller Class Initialized
DEBUG - 2020-03-31 16:07:24 --> setting MX_Controller Initialized
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-03-31 16:07:24 --> Model Class Initialized
INFO - 2020-03-31 16:07:24 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/email_setting.php
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:07:24 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:07:24 --> Model Class Initialized
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:07:24 --> Model Class Initialized
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-03-31 16:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-03-31 16:07:24 --> Final output sent to browser
DEBUG - 2020-03-31 16:07:24 --> Total execution time: 9.0854
INFO - 2020-03-31 16:12:32 --> Config Class Initialized
INFO - 2020-03-31 16:12:32 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:12:32 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:12:32 --> Utf8 Class Initialized
INFO - 2020-03-31 16:12:32 --> URI Class Initialized
INFO - 2020-03-31 16:12:32 --> Router Class Initialized
INFO - 2020-03-31 16:12:32 --> Output Class Initialized
INFO - 2020-03-31 16:12:33 --> Security Class Initialized
DEBUG - 2020-03-31 16:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:12:33 --> CSRF cookie sent
INFO - 2020-03-31 16:12:33 --> Input Class Initialized
INFO - 2020-03-31 16:12:33 --> Language Class Initialized
INFO - 2020-03-31 16:12:33 --> Language Class Initialized
INFO - 2020-03-31 16:12:33 --> Config Class Initialized
INFO - 2020-03-31 16:12:33 --> Loader Class Initialized
INFO - 2020-03-31 16:12:33 --> Helper loaded: url_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: common_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: language_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: email_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:12:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:12:33 --> Parser Class Initialized
INFO - 2020-03-31 16:12:33 --> User Agent Class Initialized
INFO - 2020-03-31 16:12:33 --> Model Class Initialized
INFO - 2020-03-31 16:12:33 --> Database Driver Class Initialized
INFO - 2020-03-31 16:12:33 --> Model Class Initialized
DEBUG - 2020-03-31 16:12:33 --> Template Class Initialized
INFO - 2020-03-31 16:12:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:12:33 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:12:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:12:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:12:33 --> Encryption Class Initialized
INFO - 2020-03-31 16:12:33 --> Controller Class Initialized
DEBUG - 2020-03-31 16:12:33 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:12:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:12:33 --> Model Class Initialized
INFO - 2020-03-31 16:12:33 --> Config Class Initialized
INFO - 2020-03-31 16:12:33 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:12:33 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:12:33 --> Utf8 Class Initialized
INFO - 2020-03-31 16:12:33 --> URI Class Initialized
DEBUG - 2020-03-31 16:12:33 --> No URI present. Default controller set.
INFO - 2020-03-31 16:12:33 --> Router Class Initialized
INFO - 2020-03-31 16:12:33 --> Output Class Initialized
INFO - 2020-03-31 16:12:33 --> Security Class Initialized
DEBUG - 2020-03-31 16:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:12:33 --> CSRF cookie sent
INFO - 2020-03-31 16:12:33 --> Input Class Initialized
INFO - 2020-03-31 16:12:33 --> Language Class Initialized
INFO - 2020-03-31 16:12:33 --> Language Class Initialized
INFO - 2020-03-31 16:12:33 --> Config Class Initialized
INFO - 2020-03-31 16:12:33 --> Loader Class Initialized
INFO - 2020-03-31 16:12:33 --> Helper loaded: url_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: common_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: language_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: email_helper
INFO - 2020-03-31 16:12:33 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:12:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:12:33 --> Parser Class Initialized
INFO - 2020-03-31 16:12:33 --> User Agent Class Initialized
INFO - 2020-03-31 16:12:33 --> Model Class Initialized
INFO - 2020-03-31 16:12:33 --> Database Driver Class Initialized
INFO - 2020-03-31 16:12:33 --> Model Class Initialized
DEBUG - 2020-03-31 16:12:33 --> Template Class Initialized
INFO - 2020-03-31 16:12:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:12:33 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:12:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:12:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:12:33 --> Encryption Class Initialized
DEBUG - 2020-03-31 16:12:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 16:12:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-31 16:12:34 --> Controller Class Initialized
DEBUG - 2020-03-31 16:12:34 --> pergo MX_Controller Initialized
DEBUG - 2020-03-31 16:12:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 16:12:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-31 16:12:34 --> Model Class Initialized
INFO - 2020-03-31 16:12:34 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:12:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-31 16:12:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-31 16:12:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-31 16:12:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-31 16:12:34 --> Final output sent to browser
DEBUG - 2020-03-31 16:12:34 --> Total execution time: 0.7450
INFO - 2020-03-31 16:13:21 --> Config Class Initialized
INFO - 2020-03-31 16:13:21 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:13:21 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:13:21 --> Utf8 Class Initialized
INFO - 2020-03-31 16:13:21 --> URI Class Initialized
INFO - 2020-03-31 16:13:21 --> Router Class Initialized
INFO - 2020-03-31 16:13:21 --> Output Class Initialized
INFO - 2020-03-31 16:13:21 --> Security Class Initialized
DEBUG - 2020-03-31 16:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:13:21 --> CSRF cookie sent
INFO - 2020-03-31 16:13:21 --> Input Class Initialized
INFO - 2020-03-31 16:13:21 --> Language Class Initialized
INFO - 2020-03-31 16:13:21 --> Language Class Initialized
INFO - 2020-03-31 16:13:21 --> Config Class Initialized
INFO - 2020-03-31 16:13:21 --> Loader Class Initialized
INFO - 2020-03-31 16:13:21 --> Helper loaded: url_helper
INFO - 2020-03-31 16:13:21 --> Helper loaded: common_helper
INFO - 2020-03-31 16:13:21 --> Helper loaded: language_helper
INFO - 2020-03-31 16:13:21 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:13:21 --> Helper loaded: email_helper
INFO - 2020-03-31 16:13:21 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:13:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:13:21 --> Parser Class Initialized
INFO - 2020-03-31 16:13:21 --> User Agent Class Initialized
INFO - 2020-03-31 16:13:21 --> Model Class Initialized
INFO - 2020-03-31 16:13:21 --> Database Driver Class Initialized
INFO - 2020-03-31 16:13:21 --> Model Class Initialized
DEBUG - 2020-03-31 16:13:21 --> Template Class Initialized
INFO - 2020-03-31 16:13:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:13:21 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:13:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:13:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:13:21 --> Encryption Class Initialized
INFO - 2020-03-31 16:13:21 --> Controller Class Initialized
DEBUG - 2020-03-31 16:13:21 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:13:21 --> Model Class Initialized
INFO - 2020-03-31 16:13:21 --> Config Class Initialized
INFO - 2020-03-31 16:13:21 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:13:21 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:13:21 --> Utf8 Class Initialized
INFO - 2020-03-31 16:13:21 --> URI Class Initialized
DEBUG - 2020-03-31 16:13:21 --> No URI present. Default controller set.
INFO - 2020-03-31 16:13:21 --> Router Class Initialized
INFO - 2020-03-31 16:13:21 --> Output Class Initialized
INFO - 2020-03-31 16:13:21 --> Security Class Initialized
DEBUG - 2020-03-31 16:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:13:21 --> CSRF cookie sent
INFO - 2020-03-31 16:13:21 --> Input Class Initialized
INFO - 2020-03-31 16:13:21 --> Language Class Initialized
INFO - 2020-03-31 16:13:21 --> Language Class Initialized
INFO - 2020-03-31 16:13:22 --> Config Class Initialized
INFO - 2020-03-31 16:13:22 --> Loader Class Initialized
INFO - 2020-03-31 16:13:22 --> Helper loaded: url_helper
INFO - 2020-03-31 16:13:22 --> Helper loaded: common_helper
INFO - 2020-03-31 16:13:22 --> Helper loaded: language_helper
INFO - 2020-03-31 16:13:22 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:13:22 --> Helper loaded: email_helper
INFO - 2020-03-31 16:13:22 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:13:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:13:22 --> Parser Class Initialized
INFO - 2020-03-31 16:13:22 --> User Agent Class Initialized
INFO - 2020-03-31 16:13:22 --> Model Class Initialized
INFO - 2020-03-31 16:13:22 --> Database Driver Class Initialized
INFO - 2020-03-31 16:13:22 --> Model Class Initialized
DEBUG - 2020-03-31 16:13:22 --> Template Class Initialized
INFO - 2020-03-31 16:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:13:22 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:13:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:13:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:13:22 --> Encryption Class Initialized
DEBUG - 2020-03-31 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-31 16:13:22 --> Controller Class Initialized
DEBUG - 2020-03-31 16:13:22 --> pergo MX_Controller Initialized
DEBUG - 2020-03-31 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-31 16:13:22 --> Model Class Initialized
INFO - 2020-03-31 16:13:22 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-31 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-31 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-31 16:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-31 16:13:22 --> Final output sent to browser
DEBUG - 2020-03-31 16:13:22 --> Total execution time: 0.7497
INFO - 2020-03-31 16:14:07 --> Config Class Initialized
INFO - 2020-03-31 16:14:07 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:14:07 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:14:07 --> Utf8 Class Initialized
INFO - 2020-03-31 16:14:07 --> URI Class Initialized
INFO - 2020-03-31 16:14:07 --> Router Class Initialized
INFO - 2020-03-31 16:14:07 --> Output Class Initialized
INFO - 2020-03-31 16:14:07 --> Security Class Initialized
DEBUG - 2020-03-31 16:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:14:07 --> CSRF cookie sent
INFO - 2020-03-31 16:14:07 --> Input Class Initialized
INFO - 2020-03-31 16:14:07 --> Language Class Initialized
INFO - 2020-03-31 16:14:07 --> Language Class Initialized
INFO - 2020-03-31 16:14:07 --> Config Class Initialized
INFO - 2020-03-31 16:14:07 --> Loader Class Initialized
INFO - 2020-03-31 16:14:07 --> Helper loaded: url_helper
INFO - 2020-03-31 16:14:07 --> Helper loaded: common_helper
INFO - 2020-03-31 16:14:07 --> Helper loaded: language_helper
INFO - 2020-03-31 16:14:07 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:14:07 --> Helper loaded: email_helper
INFO - 2020-03-31 16:14:07 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:14:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:14:07 --> Parser Class Initialized
INFO - 2020-03-31 16:14:07 --> User Agent Class Initialized
INFO - 2020-03-31 16:14:07 --> Model Class Initialized
INFO - 2020-03-31 16:14:07 --> Database Driver Class Initialized
INFO - 2020-03-31 16:14:07 --> Model Class Initialized
DEBUG - 2020-03-31 16:14:07 --> Template Class Initialized
INFO - 2020-03-31 16:14:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:14:07 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:14:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:14:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:14:07 --> Encryption Class Initialized
INFO - 2020-03-31 16:14:07 --> Controller Class Initialized
DEBUG - 2020-03-31 16:14:07 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:14:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:14:07 --> Model Class Initialized
INFO - 2020-03-31 16:14:15 --> Config Class Initialized
INFO - 2020-03-31 16:14:15 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:14:15 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:14:15 --> Utf8 Class Initialized
INFO - 2020-03-31 16:14:15 --> URI Class Initialized
INFO - 2020-03-31 16:14:15 --> Router Class Initialized
INFO - 2020-03-31 16:14:15 --> Output Class Initialized
INFO - 2020-03-31 16:14:15 --> Security Class Initialized
DEBUG - 2020-03-31 16:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:14:15 --> CSRF cookie sent
INFO - 2020-03-31 16:14:15 --> Input Class Initialized
INFO - 2020-03-31 16:14:15 --> Language Class Initialized
INFO - 2020-03-31 16:14:15 --> Language Class Initialized
INFO - 2020-03-31 16:14:15 --> Config Class Initialized
INFO - 2020-03-31 16:14:15 --> Loader Class Initialized
INFO - 2020-03-31 16:14:15 --> Helper loaded: url_helper
INFO - 2020-03-31 16:14:15 --> Helper loaded: common_helper
INFO - 2020-03-31 16:14:15 --> Helper loaded: language_helper
INFO - 2020-03-31 16:14:15 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:14:15 --> Helper loaded: email_helper
INFO - 2020-03-31 16:14:15 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:14:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:14:15 --> Parser Class Initialized
INFO - 2020-03-31 16:14:15 --> User Agent Class Initialized
INFO - 2020-03-31 16:14:15 --> Model Class Initialized
INFO - 2020-03-31 16:14:15 --> Database Driver Class Initialized
INFO - 2020-03-31 16:14:15 --> Model Class Initialized
DEBUG - 2020-03-31 16:14:15 --> Template Class Initialized
INFO - 2020-03-31 16:14:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:14:15 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:14:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:14:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:14:15 --> Encryption Class Initialized
INFO - 2020-03-31 16:14:15 --> Controller Class Initialized
DEBUG - 2020-03-31 16:14:15 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:14:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:14:15 --> Model Class Initialized
INFO - 2020-03-31 16:14:15 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:14:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:14:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:14:15 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:14:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:14:15 --> Model Class Initialized
DEBUG - 2020-03-31 16:14:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:14:15 --> Model Class Initialized
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:14:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:14:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:14:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:14:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:14:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:14:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:14:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:14:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:14:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:14:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:14:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:14:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:14:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:14:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:14:16 --> Final output sent to browser
DEBUG - 2020-03-31 16:14:16 --> Total execution time: 1.0793
INFO - 2020-03-31 16:15:32 --> Config Class Initialized
INFO - 2020-03-31 16:15:32 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:15:32 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:15:32 --> Utf8 Class Initialized
INFO - 2020-03-31 16:15:32 --> URI Class Initialized
INFO - 2020-03-31 16:15:32 --> Router Class Initialized
INFO - 2020-03-31 16:15:32 --> Output Class Initialized
INFO - 2020-03-31 16:15:32 --> Security Class Initialized
DEBUG - 2020-03-31 16:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:15:32 --> CSRF cookie sent
INFO - 2020-03-31 16:15:32 --> Input Class Initialized
INFO - 2020-03-31 16:15:32 --> Language Class Initialized
INFO - 2020-03-31 16:15:32 --> Language Class Initialized
INFO - 2020-03-31 16:15:32 --> Config Class Initialized
INFO - 2020-03-31 16:15:32 --> Loader Class Initialized
INFO - 2020-03-31 16:15:32 --> Helper loaded: url_helper
INFO - 2020-03-31 16:15:32 --> Helper loaded: common_helper
INFO - 2020-03-31 16:15:32 --> Helper loaded: language_helper
INFO - 2020-03-31 16:15:32 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:15:32 --> Helper loaded: email_helper
INFO - 2020-03-31 16:15:32 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:15:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:15:32 --> Parser Class Initialized
INFO - 2020-03-31 16:15:32 --> User Agent Class Initialized
INFO - 2020-03-31 16:15:32 --> Model Class Initialized
INFO - 2020-03-31 16:15:32 --> Database Driver Class Initialized
INFO - 2020-03-31 16:15:32 --> Model Class Initialized
DEBUG - 2020-03-31 16:15:32 --> Template Class Initialized
INFO - 2020-03-31 16:15:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:15:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:15:32 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:15:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:15:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:15:32 --> Encryption Class Initialized
INFO - 2020-03-31 16:15:32 --> Controller Class Initialized
DEBUG - 2020-03-31 16:15:32 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:15:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:15:32 --> Model Class Initialized
INFO - 2020-03-31 16:15:32 --> Helper loaded: inflector_helper
INFO - 2020-03-31 16:16:44 --> Config Class Initialized
INFO - 2020-03-31 16:16:44 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:16:45 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:16:45 --> Utf8 Class Initialized
INFO - 2020-03-31 16:16:45 --> URI Class Initialized
INFO - 2020-03-31 16:16:45 --> Router Class Initialized
INFO - 2020-03-31 16:16:45 --> Output Class Initialized
INFO - 2020-03-31 16:16:45 --> Security Class Initialized
DEBUG - 2020-03-31 16:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:16:45 --> CSRF cookie sent
INFO - 2020-03-31 16:16:45 --> Input Class Initialized
INFO - 2020-03-31 16:16:45 --> Language Class Initialized
INFO - 2020-03-31 16:16:45 --> Language Class Initialized
INFO - 2020-03-31 16:16:45 --> Config Class Initialized
INFO - 2020-03-31 16:16:45 --> Loader Class Initialized
INFO - 2020-03-31 16:16:45 --> Helper loaded: url_helper
INFO - 2020-03-31 16:16:45 --> Helper loaded: common_helper
INFO - 2020-03-31 16:16:45 --> Helper loaded: language_helper
INFO - 2020-03-31 16:16:45 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:16:45 --> Helper loaded: email_helper
INFO - 2020-03-31 16:16:45 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:16:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:16:45 --> Parser Class Initialized
INFO - 2020-03-31 16:16:45 --> User Agent Class Initialized
INFO - 2020-03-31 16:16:45 --> Model Class Initialized
INFO - 2020-03-31 16:16:45 --> Database Driver Class Initialized
INFO - 2020-03-31 16:16:45 --> Model Class Initialized
DEBUG - 2020-03-31 16:16:45 --> Template Class Initialized
INFO - 2020-03-31 16:16:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:16:45 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:16:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:16:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:16:45 --> Encryption Class Initialized
INFO - 2020-03-31 16:16:45 --> Controller Class Initialized
DEBUG - 2020-03-31 16:16:45 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:16:45 --> Model Class Initialized
INFO - 2020-03-31 16:16:45 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:16:45 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:16:45 --> Model Class Initialized
DEBUG - 2020-03-31 16:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:16:45 --> Model Class Initialized
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:16:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:16:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:16:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:16:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:16:46 --> Final output sent to browser
DEBUG - 2020-03-31 16:16:46 --> Total execution time: 1.0655
INFO - 2020-03-31 16:17:53 --> Config Class Initialized
INFO - 2020-03-31 16:17:53 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:17:53 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:17:53 --> Utf8 Class Initialized
INFO - 2020-03-31 16:17:53 --> URI Class Initialized
INFO - 2020-03-31 16:17:53 --> Router Class Initialized
INFO - 2020-03-31 16:17:53 --> Output Class Initialized
INFO - 2020-03-31 16:17:53 --> Security Class Initialized
DEBUG - 2020-03-31 16:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:17:53 --> CSRF cookie sent
INFO - 2020-03-31 16:17:53 --> Input Class Initialized
INFO - 2020-03-31 16:17:53 --> Language Class Initialized
INFO - 2020-03-31 16:17:53 --> Language Class Initialized
INFO - 2020-03-31 16:17:53 --> Config Class Initialized
INFO - 2020-03-31 16:17:53 --> Loader Class Initialized
INFO - 2020-03-31 16:17:53 --> Helper loaded: url_helper
INFO - 2020-03-31 16:17:53 --> Helper loaded: common_helper
INFO - 2020-03-31 16:17:53 --> Helper loaded: language_helper
INFO - 2020-03-31 16:17:53 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:17:53 --> Helper loaded: email_helper
INFO - 2020-03-31 16:17:53 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:17:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:17:53 --> Parser Class Initialized
INFO - 2020-03-31 16:17:53 --> User Agent Class Initialized
INFO - 2020-03-31 16:17:53 --> Model Class Initialized
INFO - 2020-03-31 16:17:53 --> Database Driver Class Initialized
INFO - 2020-03-31 16:17:53 --> Model Class Initialized
DEBUG - 2020-03-31 16:17:53 --> Template Class Initialized
INFO - 2020-03-31 16:17:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:17:53 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:17:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:17:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:17:53 --> Encryption Class Initialized
INFO - 2020-03-31 16:17:53 --> Controller Class Initialized
DEBUG - 2020-03-31 16:17:53 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:17:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:17:53 --> Model Class Initialized
INFO - 2020-03-31 16:17:53 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:17:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:17:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:17:53 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:17:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:17:53 --> Model Class Initialized
DEBUG - 2020-03-31 16:17:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:17:53 --> Model Class Initialized
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:17:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:17:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:17:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:17:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:17:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:17:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:17:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:17:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:17:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:17:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:17:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:17:54 --> Final output sent to browser
DEBUG - 2020-03-31 16:17:54 --> Total execution time: 1.0497
INFO - 2020-03-31 16:19:14 --> Config Class Initialized
INFO - 2020-03-31 16:19:14 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:19:14 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:19:14 --> Utf8 Class Initialized
INFO - 2020-03-31 16:19:14 --> URI Class Initialized
INFO - 2020-03-31 16:19:14 --> Router Class Initialized
INFO - 2020-03-31 16:19:14 --> Output Class Initialized
INFO - 2020-03-31 16:19:14 --> Security Class Initialized
DEBUG - 2020-03-31 16:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:19:14 --> CSRF cookie sent
INFO - 2020-03-31 16:19:14 --> Input Class Initialized
INFO - 2020-03-31 16:19:14 --> Language Class Initialized
INFO - 2020-03-31 16:19:14 --> Language Class Initialized
INFO - 2020-03-31 16:19:14 --> Config Class Initialized
INFO - 2020-03-31 16:19:14 --> Loader Class Initialized
INFO - 2020-03-31 16:19:14 --> Helper loaded: url_helper
INFO - 2020-03-31 16:19:14 --> Helper loaded: common_helper
INFO - 2020-03-31 16:19:14 --> Helper loaded: language_helper
INFO - 2020-03-31 16:19:14 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:19:14 --> Helper loaded: email_helper
INFO - 2020-03-31 16:19:14 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:19:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:19:14 --> Parser Class Initialized
INFO - 2020-03-31 16:19:14 --> User Agent Class Initialized
INFO - 2020-03-31 16:19:14 --> Model Class Initialized
INFO - 2020-03-31 16:19:14 --> Database Driver Class Initialized
INFO - 2020-03-31 16:19:15 --> Model Class Initialized
DEBUG - 2020-03-31 16:19:15 --> Template Class Initialized
INFO - 2020-03-31 16:19:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:19:15 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:19:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:19:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:19:15 --> Encryption Class Initialized
INFO - 2020-03-31 16:19:15 --> Controller Class Initialized
DEBUG - 2020-03-31 16:19:15 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:19:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:19:15 --> Model Class Initialized
INFO - 2020-03-31 16:19:15 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:19:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:19:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:19:15 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:19:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:19:15 --> Model Class Initialized
DEBUG - 2020-03-31 16:19:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:19:15 --> Model Class Initialized
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:19:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:19:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:19:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:19:15 --> Final output sent to browser
DEBUG - 2020-03-31 16:19:15 --> Total execution time: 1.0710
INFO - 2020-03-31 16:19:51 --> Config Class Initialized
INFO - 2020-03-31 16:19:51 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:19:51 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:19:51 --> Utf8 Class Initialized
INFO - 2020-03-31 16:19:51 --> URI Class Initialized
INFO - 2020-03-31 16:19:51 --> Router Class Initialized
INFO - 2020-03-31 16:19:51 --> Output Class Initialized
INFO - 2020-03-31 16:19:51 --> Security Class Initialized
DEBUG - 2020-03-31 16:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:19:51 --> CSRF cookie sent
INFO - 2020-03-31 16:19:52 --> Input Class Initialized
INFO - 2020-03-31 16:19:52 --> Language Class Initialized
INFO - 2020-03-31 16:19:52 --> Language Class Initialized
INFO - 2020-03-31 16:19:52 --> Config Class Initialized
INFO - 2020-03-31 16:19:52 --> Loader Class Initialized
INFO - 2020-03-31 16:19:52 --> Helper loaded: url_helper
INFO - 2020-03-31 16:19:52 --> Helper loaded: common_helper
INFO - 2020-03-31 16:19:52 --> Helper loaded: language_helper
INFO - 2020-03-31 16:19:52 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:19:52 --> Helper loaded: email_helper
INFO - 2020-03-31 16:19:52 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:19:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:19:52 --> Parser Class Initialized
INFO - 2020-03-31 16:19:52 --> User Agent Class Initialized
INFO - 2020-03-31 16:19:52 --> Model Class Initialized
INFO - 2020-03-31 16:19:52 --> Database Driver Class Initialized
INFO - 2020-03-31 16:19:52 --> Model Class Initialized
DEBUG - 2020-03-31 16:19:52 --> Template Class Initialized
INFO - 2020-03-31 16:19:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:19:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:19:52 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:19:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:19:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:19:52 --> Encryption Class Initialized
INFO - 2020-03-31 16:19:52 --> Controller Class Initialized
DEBUG - 2020-03-31 16:19:52 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:19:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:19:52 --> Model Class Initialized
INFO - 2020-03-31 16:19:52 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:19:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:19:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:19:52 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:19:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:19:52 --> Model Class Initialized
DEBUG - 2020-03-31 16:19:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:19:52 --> Model Class Initialized
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:19:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:19:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:19:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:19:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:19:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:19:52 --> Final output sent to browser
DEBUG - 2020-03-31 16:19:52 --> Total execution time: 1.1173
INFO - 2020-03-31 16:20:22 --> Config Class Initialized
INFO - 2020-03-31 16:20:22 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:20:22 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:20:22 --> Utf8 Class Initialized
INFO - 2020-03-31 16:20:22 --> URI Class Initialized
INFO - 2020-03-31 16:20:22 --> Router Class Initialized
INFO - 2020-03-31 16:20:22 --> Output Class Initialized
INFO - 2020-03-31 16:20:22 --> Security Class Initialized
DEBUG - 2020-03-31 16:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:20:22 --> CSRF cookie sent
INFO - 2020-03-31 16:20:22 --> Input Class Initialized
INFO - 2020-03-31 16:20:22 --> Language Class Initialized
INFO - 2020-03-31 16:20:22 --> Language Class Initialized
INFO - 2020-03-31 16:20:22 --> Config Class Initialized
INFO - 2020-03-31 16:20:22 --> Loader Class Initialized
INFO - 2020-03-31 16:20:22 --> Helper loaded: url_helper
INFO - 2020-03-31 16:20:22 --> Helper loaded: common_helper
INFO - 2020-03-31 16:20:22 --> Helper loaded: language_helper
INFO - 2020-03-31 16:20:22 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:20:22 --> Helper loaded: email_helper
INFO - 2020-03-31 16:20:22 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:20:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:20:22 --> Parser Class Initialized
INFO - 2020-03-31 16:20:23 --> User Agent Class Initialized
INFO - 2020-03-31 16:20:23 --> Model Class Initialized
INFO - 2020-03-31 16:20:23 --> Database Driver Class Initialized
INFO - 2020-03-31 16:20:23 --> Model Class Initialized
DEBUG - 2020-03-31 16:20:23 --> Template Class Initialized
INFO - 2020-03-31 16:20:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:20:23 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:20:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:20:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:20:23 --> Encryption Class Initialized
INFO - 2020-03-31 16:20:23 --> Controller Class Initialized
DEBUG - 2020-03-31 16:20:23 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:20:23 --> Model Class Initialized
INFO - 2020-03-31 16:20:23 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:20:23 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:20:23 --> Model Class Initialized
DEBUG - 2020-03-31 16:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:20:23 --> Model Class Initialized
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:20:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:20:23 --> Final output sent to browser
DEBUG - 2020-03-31 16:20:23 --> Total execution time: 1.1246
INFO - 2020-03-31 16:20:33 --> Config Class Initialized
INFO - 2020-03-31 16:20:33 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:20:33 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:20:33 --> Utf8 Class Initialized
INFO - 2020-03-31 16:20:33 --> URI Class Initialized
INFO - 2020-03-31 16:20:33 --> Router Class Initialized
INFO - 2020-03-31 16:20:33 --> Output Class Initialized
INFO - 2020-03-31 16:20:33 --> Security Class Initialized
DEBUG - 2020-03-31 16:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:20:33 --> CSRF cookie sent
INFO - 2020-03-31 16:20:33 --> Input Class Initialized
INFO - 2020-03-31 16:20:33 --> Language Class Initialized
INFO - 2020-03-31 16:20:33 --> Language Class Initialized
INFO - 2020-03-31 16:20:33 --> Config Class Initialized
INFO - 2020-03-31 16:20:33 --> Loader Class Initialized
INFO - 2020-03-31 16:20:33 --> Helper loaded: url_helper
INFO - 2020-03-31 16:20:33 --> Helper loaded: common_helper
INFO - 2020-03-31 16:20:33 --> Helper loaded: language_helper
INFO - 2020-03-31 16:20:33 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:20:33 --> Helper loaded: email_helper
INFO - 2020-03-31 16:20:33 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:20:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:20:33 --> Parser Class Initialized
INFO - 2020-03-31 16:20:33 --> User Agent Class Initialized
INFO - 2020-03-31 16:20:33 --> Model Class Initialized
INFO - 2020-03-31 16:20:33 --> Database Driver Class Initialized
INFO - 2020-03-31 16:20:33 --> Model Class Initialized
DEBUG - 2020-03-31 16:20:33 --> Template Class Initialized
INFO - 2020-03-31 16:20:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:20:33 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:20:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:20:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:20:33 --> Encryption Class Initialized
INFO - 2020-03-31 16:20:33 --> Controller Class Initialized
DEBUG - 2020-03-31 16:20:33 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:20:34 --> Model Class Initialized
INFO - 2020-03-31 16:20:34 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:20:34 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:20:34 --> Model Class Initialized
DEBUG - 2020-03-31 16:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:20:34 --> Model Class Initialized
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:20:34 --> Final output sent to browser
DEBUG - 2020-03-31 16:20:34 --> Total execution time: 1.1493
INFO - 2020-03-31 16:20:46 --> Config Class Initialized
INFO - 2020-03-31 16:20:46 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:20:46 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:20:46 --> Utf8 Class Initialized
INFO - 2020-03-31 16:20:46 --> URI Class Initialized
INFO - 2020-03-31 16:20:46 --> Router Class Initialized
INFO - 2020-03-31 16:20:46 --> Output Class Initialized
INFO - 2020-03-31 16:20:46 --> Security Class Initialized
DEBUG - 2020-03-31 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:20:46 --> CSRF cookie sent
INFO - 2020-03-31 16:20:46 --> Input Class Initialized
INFO - 2020-03-31 16:20:46 --> Language Class Initialized
INFO - 2020-03-31 16:20:46 --> Language Class Initialized
INFO - 2020-03-31 16:20:46 --> Config Class Initialized
INFO - 2020-03-31 16:20:46 --> Loader Class Initialized
INFO - 2020-03-31 16:20:46 --> Helper loaded: url_helper
INFO - 2020-03-31 16:20:46 --> Helper loaded: common_helper
INFO - 2020-03-31 16:20:46 --> Helper loaded: language_helper
INFO - 2020-03-31 16:20:46 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:20:46 --> Helper loaded: email_helper
INFO - 2020-03-31 16:20:46 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:20:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:20:46 --> Parser Class Initialized
INFO - 2020-03-31 16:20:46 --> User Agent Class Initialized
INFO - 2020-03-31 16:20:46 --> Model Class Initialized
INFO - 2020-03-31 16:20:46 --> Database Driver Class Initialized
INFO - 2020-03-31 16:20:46 --> Model Class Initialized
DEBUG - 2020-03-31 16:20:46 --> Template Class Initialized
INFO - 2020-03-31 16:20:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:20:46 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:20:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:20:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:20:46 --> Encryption Class Initialized
INFO - 2020-03-31 16:20:46 --> Controller Class Initialized
DEBUG - 2020-03-31 16:20:46 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:20:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:20:46 --> Model Class Initialized
INFO - 2020-03-31 16:20:46 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:20:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:20:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:20:47 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:20:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:20:47 --> Model Class Initialized
DEBUG - 2020-03-31 16:20:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:20:47 --> Model Class Initialized
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:20:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:20:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:20:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:20:47 --> Final output sent to browser
DEBUG - 2020-03-31 16:20:47 --> Total execution time: 1.1120
INFO - 2020-03-31 16:20:58 --> Config Class Initialized
INFO - 2020-03-31 16:20:58 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:20:58 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:20:58 --> Utf8 Class Initialized
INFO - 2020-03-31 16:20:58 --> URI Class Initialized
INFO - 2020-03-31 16:20:58 --> Router Class Initialized
INFO - 2020-03-31 16:20:58 --> Output Class Initialized
INFO - 2020-03-31 16:20:58 --> Security Class Initialized
DEBUG - 2020-03-31 16:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:20:58 --> CSRF cookie sent
INFO - 2020-03-31 16:20:58 --> Input Class Initialized
INFO - 2020-03-31 16:20:58 --> Language Class Initialized
INFO - 2020-03-31 16:20:58 --> Language Class Initialized
INFO - 2020-03-31 16:20:58 --> Config Class Initialized
INFO - 2020-03-31 16:20:58 --> Loader Class Initialized
INFO - 2020-03-31 16:20:58 --> Helper loaded: url_helper
INFO - 2020-03-31 16:20:58 --> Helper loaded: common_helper
INFO - 2020-03-31 16:20:58 --> Helper loaded: language_helper
INFO - 2020-03-31 16:20:58 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:20:58 --> Helper loaded: email_helper
INFO - 2020-03-31 16:20:58 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:20:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:20:58 --> Parser Class Initialized
INFO - 2020-03-31 16:20:58 --> User Agent Class Initialized
INFO - 2020-03-31 16:20:58 --> Model Class Initialized
INFO - 2020-03-31 16:20:58 --> Database Driver Class Initialized
INFO - 2020-03-31 16:20:58 --> Model Class Initialized
DEBUG - 2020-03-31 16:20:58 --> Template Class Initialized
INFO - 2020-03-31 16:20:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:20:58 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:20:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:20:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:20:58 --> Encryption Class Initialized
INFO - 2020-03-31 16:20:58 --> Controller Class Initialized
DEBUG - 2020-03-31 16:20:58 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:20:58 --> Model Class Initialized
INFO - 2020-03-31 16:20:58 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:20:58 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:20:58 --> Model Class Initialized
DEBUG - 2020-03-31 16:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:20:58 --> Model Class Initialized
ERROR - 2020-03-31 16:20:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:20:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:20:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:20:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:20:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:20:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:20:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:20:59 --> Final output sent to browser
DEBUG - 2020-03-31 16:20:59 --> Total execution time: 1.1591
INFO - 2020-03-31 16:21:06 --> Config Class Initialized
INFO - 2020-03-31 16:21:06 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:21:06 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:21:06 --> Utf8 Class Initialized
INFO - 2020-03-31 16:21:06 --> URI Class Initialized
INFO - 2020-03-31 16:21:06 --> Router Class Initialized
INFO - 2020-03-31 16:21:06 --> Output Class Initialized
INFO - 2020-03-31 16:21:07 --> Security Class Initialized
DEBUG - 2020-03-31 16:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:21:07 --> CSRF cookie sent
INFO - 2020-03-31 16:21:07 --> Input Class Initialized
INFO - 2020-03-31 16:21:07 --> Language Class Initialized
INFO - 2020-03-31 16:21:07 --> Language Class Initialized
INFO - 2020-03-31 16:21:07 --> Config Class Initialized
INFO - 2020-03-31 16:21:07 --> Loader Class Initialized
INFO - 2020-03-31 16:21:07 --> Helper loaded: url_helper
INFO - 2020-03-31 16:21:07 --> Helper loaded: common_helper
INFO - 2020-03-31 16:21:07 --> Helper loaded: language_helper
INFO - 2020-03-31 16:21:07 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:21:07 --> Helper loaded: email_helper
INFO - 2020-03-31 16:21:07 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:21:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:21:07 --> Parser Class Initialized
INFO - 2020-03-31 16:21:07 --> User Agent Class Initialized
INFO - 2020-03-31 16:21:07 --> Model Class Initialized
INFO - 2020-03-31 16:21:07 --> Database Driver Class Initialized
INFO - 2020-03-31 16:21:07 --> Model Class Initialized
DEBUG - 2020-03-31 16:21:07 --> Template Class Initialized
INFO - 2020-03-31 16:21:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:21:07 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:21:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:21:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:21:07 --> Encryption Class Initialized
INFO - 2020-03-31 16:21:07 --> Controller Class Initialized
DEBUG - 2020-03-31 16:21:07 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:21:07 --> Model Class Initialized
INFO - 2020-03-31 16:21:07 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:21:07 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:21:07 --> Model Class Initialized
DEBUG - 2020-03-31 16:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:21:07 --> Model Class Initialized
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:21:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:21:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:21:08 --> Final output sent to browser
DEBUG - 2020-03-31 16:21:08 --> Total execution time: 1.1206
INFO - 2020-03-31 16:21:51 --> Config Class Initialized
INFO - 2020-03-31 16:21:51 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:21:51 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:21:51 --> Utf8 Class Initialized
INFO - 2020-03-31 16:21:51 --> URI Class Initialized
INFO - 2020-03-31 16:21:51 --> Router Class Initialized
INFO - 2020-03-31 16:21:51 --> Output Class Initialized
INFO - 2020-03-31 16:21:51 --> Security Class Initialized
DEBUG - 2020-03-31 16:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:21:51 --> CSRF cookie sent
INFO - 2020-03-31 16:21:51 --> Input Class Initialized
INFO - 2020-03-31 16:21:51 --> Language Class Initialized
INFO - 2020-03-31 16:21:51 --> Language Class Initialized
INFO - 2020-03-31 16:21:51 --> Config Class Initialized
INFO - 2020-03-31 16:21:51 --> Loader Class Initialized
INFO - 2020-03-31 16:21:51 --> Helper loaded: url_helper
INFO - 2020-03-31 16:21:51 --> Helper loaded: common_helper
INFO - 2020-03-31 16:21:51 --> Helper loaded: language_helper
INFO - 2020-03-31 16:21:51 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:21:51 --> Helper loaded: email_helper
INFO - 2020-03-31 16:21:51 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:21:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:21:51 --> Parser Class Initialized
INFO - 2020-03-31 16:21:51 --> User Agent Class Initialized
INFO - 2020-03-31 16:21:51 --> Model Class Initialized
INFO - 2020-03-31 16:21:51 --> Database Driver Class Initialized
INFO - 2020-03-31 16:21:51 --> Model Class Initialized
DEBUG - 2020-03-31 16:21:51 --> Template Class Initialized
INFO - 2020-03-31 16:21:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:21:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:21:51 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:21:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:21:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:21:51 --> Encryption Class Initialized
INFO - 2020-03-31 16:21:51 --> Controller Class Initialized
DEBUG - 2020-03-31 16:21:51 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:21:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:21:51 --> Model Class Initialized
INFO - 2020-03-31 16:21:51 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:21:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:21:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:21:51 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:21:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:21:51 --> Model Class Initialized
DEBUG - 2020-03-31 16:21:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:21:51 --> Model Class Initialized
ERROR - 2020-03-31 16:21:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:21:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:21:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:21:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:21:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:21:52 --> Final output sent to browser
DEBUG - 2020-03-31 16:21:52 --> Total execution time: 1.1467
INFO - 2020-03-31 16:22:04 --> Config Class Initialized
INFO - 2020-03-31 16:22:04 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:22:04 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:22:04 --> Utf8 Class Initialized
INFO - 2020-03-31 16:22:04 --> URI Class Initialized
INFO - 2020-03-31 16:22:04 --> Router Class Initialized
INFO - 2020-03-31 16:22:04 --> Output Class Initialized
INFO - 2020-03-31 16:22:04 --> Security Class Initialized
DEBUG - 2020-03-31 16:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:22:04 --> CSRF cookie sent
INFO - 2020-03-31 16:22:04 --> Input Class Initialized
INFO - 2020-03-31 16:22:04 --> Language Class Initialized
INFO - 2020-03-31 16:22:04 --> Language Class Initialized
INFO - 2020-03-31 16:22:04 --> Config Class Initialized
INFO - 2020-03-31 16:22:04 --> Loader Class Initialized
INFO - 2020-03-31 16:22:04 --> Helper loaded: url_helper
INFO - 2020-03-31 16:22:04 --> Helper loaded: common_helper
INFO - 2020-03-31 16:22:04 --> Helper loaded: language_helper
INFO - 2020-03-31 16:22:04 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:22:04 --> Helper loaded: email_helper
INFO - 2020-03-31 16:22:05 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:22:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:22:05 --> Parser Class Initialized
INFO - 2020-03-31 16:22:05 --> User Agent Class Initialized
INFO - 2020-03-31 16:22:05 --> Model Class Initialized
INFO - 2020-03-31 16:22:05 --> Database Driver Class Initialized
INFO - 2020-03-31 16:22:05 --> Model Class Initialized
DEBUG - 2020-03-31 16:22:05 --> Template Class Initialized
INFO - 2020-03-31 16:22:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:22:05 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:22:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:22:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:22:05 --> Encryption Class Initialized
INFO - 2020-03-31 16:22:05 --> Controller Class Initialized
DEBUG - 2020-03-31 16:22:05 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:22:05 --> Model Class Initialized
INFO - 2020-03-31 16:22:05 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:22:05 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:22:05 --> Model Class Initialized
DEBUG - 2020-03-31 16:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:22:05 --> Model Class Initialized
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:22:05 --> Final output sent to browser
DEBUG - 2020-03-31 16:22:05 --> Total execution time: 1.1276
INFO - 2020-03-31 16:22:34 --> Config Class Initialized
INFO - 2020-03-31 16:22:34 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:22:34 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:22:34 --> Utf8 Class Initialized
INFO - 2020-03-31 16:22:34 --> URI Class Initialized
INFO - 2020-03-31 16:22:34 --> Router Class Initialized
INFO - 2020-03-31 16:22:34 --> Output Class Initialized
INFO - 2020-03-31 16:22:34 --> Security Class Initialized
DEBUG - 2020-03-31 16:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:22:34 --> CSRF cookie sent
INFO - 2020-03-31 16:22:34 --> Input Class Initialized
INFO - 2020-03-31 16:22:34 --> Language Class Initialized
INFO - 2020-03-31 16:22:34 --> Language Class Initialized
INFO - 2020-03-31 16:22:34 --> Config Class Initialized
INFO - 2020-03-31 16:22:34 --> Loader Class Initialized
INFO - 2020-03-31 16:22:34 --> Helper loaded: url_helper
INFO - 2020-03-31 16:22:34 --> Helper loaded: common_helper
INFO - 2020-03-31 16:22:34 --> Helper loaded: language_helper
INFO - 2020-03-31 16:22:34 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:22:34 --> Helper loaded: email_helper
INFO - 2020-03-31 16:22:34 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:22:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:22:34 --> Parser Class Initialized
INFO - 2020-03-31 16:22:34 --> User Agent Class Initialized
INFO - 2020-03-31 16:22:34 --> Model Class Initialized
INFO - 2020-03-31 16:22:34 --> Database Driver Class Initialized
INFO - 2020-03-31 16:22:34 --> Model Class Initialized
DEBUG - 2020-03-31 16:22:34 --> Template Class Initialized
INFO - 2020-03-31 16:22:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:22:34 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:22:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:22:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:22:34 --> Encryption Class Initialized
INFO - 2020-03-31 16:22:34 --> Controller Class Initialized
DEBUG - 2020-03-31 16:22:34 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:22:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:22:34 --> Model Class Initialized
INFO - 2020-03-31 16:22:34 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:22:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:22:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:22:34 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:22:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:22:34 --> Model Class Initialized
DEBUG - 2020-03-31 16:22:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:22:34 --> Model Class Initialized
ERROR - 2020-03-31 16:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:22:35 --> Final output sent to browser
DEBUG - 2020-03-31 16:22:35 --> Total execution time: 1.1297
INFO - 2020-03-31 16:22:37 --> Config Class Initialized
INFO - 2020-03-31 16:22:37 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:22:37 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:22:37 --> Utf8 Class Initialized
INFO - 2020-03-31 16:22:37 --> URI Class Initialized
INFO - 2020-03-31 16:22:37 --> Router Class Initialized
INFO - 2020-03-31 16:22:37 --> Output Class Initialized
INFO - 2020-03-31 16:22:37 --> Security Class Initialized
DEBUG - 2020-03-31 16:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:22:37 --> CSRF cookie sent
INFO - 2020-03-31 16:22:37 --> Input Class Initialized
INFO - 2020-03-31 16:22:37 --> Language Class Initialized
INFO - 2020-03-31 16:22:37 --> Language Class Initialized
INFO - 2020-03-31 16:22:37 --> Config Class Initialized
INFO - 2020-03-31 16:22:37 --> Loader Class Initialized
INFO - 2020-03-31 16:22:37 --> Helper loaded: url_helper
INFO - 2020-03-31 16:22:37 --> Helper loaded: common_helper
INFO - 2020-03-31 16:22:37 --> Helper loaded: language_helper
INFO - 2020-03-31 16:22:37 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:22:37 --> Helper loaded: email_helper
INFO - 2020-03-31 16:22:37 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:22:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:22:37 --> Parser Class Initialized
INFO - 2020-03-31 16:22:37 --> User Agent Class Initialized
INFO - 2020-03-31 16:22:37 --> Model Class Initialized
INFO - 2020-03-31 16:22:37 --> Database Driver Class Initialized
INFO - 2020-03-31 16:22:37 --> Model Class Initialized
DEBUG - 2020-03-31 16:22:37 --> Template Class Initialized
INFO - 2020-03-31 16:22:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:22:37 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:22:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:22:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:22:37 --> Encryption Class Initialized
INFO - 2020-03-31 16:22:37 --> Controller Class Initialized
DEBUG - 2020-03-31 16:22:37 --> client MX_Controller Initialized
DEBUG - 2020-03-31 16:22:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/models/client_model.php
INFO - 2020-03-31 16:22:37 --> Model Class Initialized
INFO - 2020-03-31 16:22:37 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:22:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:22:37 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:22:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:22:37 --> Model Class Initialized
DEBUG - 2020-03-31 16:22:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:22:37 --> Model Class Initialized
DEBUG - 2020-03-31 16:22:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-31 16:22:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/index.php
ERROR - 2020-03-31 16:22:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:22:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:22:38 --> Final output sent to browser
DEBUG - 2020-03-31 16:22:38 --> Total execution time: 1.1850
INFO - 2020-03-31 16:27:33 --> Config Class Initialized
INFO - 2020-03-31 16:27:33 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:27:33 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:27:33 --> Utf8 Class Initialized
INFO - 2020-03-31 16:27:33 --> URI Class Initialized
INFO - 2020-03-31 16:27:33 --> Router Class Initialized
INFO - 2020-03-31 16:27:33 --> Output Class Initialized
INFO - 2020-03-31 16:27:33 --> Security Class Initialized
DEBUG - 2020-03-31 16:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:27:33 --> CSRF cookie sent
INFO - 2020-03-31 16:27:33 --> Input Class Initialized
INFO - 2020-03-31 16:27:33 --> Language Class Initialized
INFO - 2020-03-31 16:27:33 --> Language Class Initialized
INFO - 2020-03-31 16:27:33 --> Config Class Initialized
INFO - 2020-03-31 16:27:33 --> Loader Class Initialized
INFO - 2020-03-31 16:27:33 --> Helper loaded: url_helper
INFO - 2020-03-31 16:27:33 --> Helper loaded: common_helper
INFO - 2020-03-31 16:27:33 --> Helper loaded: language_helper
INFO - 2020-03-31 16:27:33 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:27:33 --> Helper loaded: email_helper
INFO - 2020-03-31 16:27:33 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:27:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:27:33 --> Parser Class Initialized
INFO - 2020-03-31 16:27:33 --> User Agent Class Initialized
INFO - 2020-03-31 16:27:33 --> Model Class Initialized
INFO - 2020-03-31 16:27:33 --> Database Driver Class Initialized
INFO - 2020-03-31 16:27:33 --> Model Class Initialized
DEBUG - 2020-03-31 16:27:33 --> Template Class Initialized
INFO - 2020-03-31 16:27:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:27:33 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:27:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:27:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:27:33 --> Encryption Class Initialized
INFO - 2020-03-31 16:27:33 --> Controller Class Initialized
DEBUG - 2020-03-31 16:27:33 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:27:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:27:33 --> Model Class Initialized
INFO - 2020-03-31 16:27:33 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:27:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:27:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:27:33 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:27:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:27:33 --> Model Class Initialized
DEBUG - 2020-03-31 16:27:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:27:33 --> Model Class Initialized
ERROR - 2020-03-31 16:27:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:27:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:27:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:27:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:27:34 --> Final output sent to browser
DEBUG - 2020-03-31 16:27:34 --> Total execution time: 1.1509
INFO - 2020-03-31 16:27:49 --> Config Class Initialized
INFO - 2020-03-31 16:27:49 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:27:49 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:27:49 --> Utf8 Class Initialized
INFO - 2020-03-31 16:27:49 --> URI Class Initialized
INFO - 2020-03-31 16:27:49 --> Router Class Initialized
INFO - 2020-03-31 16:27:49 --> Output Class Initialized
INFO - 2020-03-31 16:27:49 --> Security Class Initialized
DEBUG - 2020-03-31 16:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:27:49 --> CSRF cookie sent
INFO - 2020-03-31 16:27:49 --> Input Class Initialized
INFO - 2020-03-31 16:27:49 --> Language Class Initialized
INFO - 2020-03-31 16:27:49 --> Language Class Initialized
INFO - 2020-03-31 16:27:49 --> Config Class Initialized
INFO - 2020-03-31 16:27:49 --> Loader Class Initialized
INFO - 2020-03-31 16:27:49 --> Helper loaded: url_helper
INFO - 2020-03-31 16:27:49 --> Helper loaded: common_helper
INFO - 2020-03-31 16:27:49 --> Helper loaded: language_helper
INFO - 2020-03-31 16:27:49 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:27:49 --> Helper loaded: email_helper
INFO - 2020-03-31 16:27:49 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:27:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:27:49 --> Parser Class Initialized
INFO - 2020-03-31 16:27:49 --> User Agent Class Initialized
INFO - 2020-03-31 16:27:49 --> Model Class Initialized
INFO - 2020-03-31 16:27:49 --> Database Driver Class Initialized
INFO - 2020-03-31 16:27:50 --> Model Class Initialized
DEBUG - 2020-03-31 16:27:50 --> Template Class Initialized
INFO - 2020-03-31 16:27:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:27:50 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:27:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:27:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:27:50 --> Encryption Class Initialized
INFO - 2020-03-31 16:27:50 --> Controller Class Initialized
DEBUG - 2020-03-31 16:27:50 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:27:50 --> Model Class Initialized
INFO - 2020-03-31 16:27:50 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:27:50 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:27:50 --> Model Class Initialized
DEBUG - 2020-03-31 16:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:27:50 --> Model Class Initialized
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:27:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:27:50 --> Final output sent to browser
DEBUG - 2020-03-31 16:27:50 --> Total execution time: 1.2148
INFO - 2020-03-31 16:28:09 --> Config Class Initialized
INFO - 2020-03-31 16:28:09 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:28:09 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:28:09 --> Utf8 Class Initialized
INFO - 2020-03-31 16:28:09 --> URI Class Initialized
INFO - 2020-03-31 16:28:09 --> Router Class Initialized
INFO - 2020-03-31 16:28:09 --> Output Class Initialized
INFO - 2020-03-31 16:28:09 --> Security Class Initialized
DEBUG - 2020-03-31 16:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:28:09 --> CSRF cookie sent
INFO - 2020-03-31 16:28:09 --> Input Class Initialized
INFO - 2020-03-31 16:28:09 --> Language Class Initialized
INFO - 2020-03-31 16:28:09 --> Language Class Initialized
INFO - 2020-03-31 16:28:09 --> Config Class Initialized
INFO - 2020-03-31 16:28:09 --> Loader Class Initialized
INFO - 2020-03-31 16:28:09 --> Helper loaded: url_helper
INFO - 2020-03-31 16:28:09 --> Helper loaded: common_helper
INFO - 2020-03-31 16:28:09 --> Helper loaded: language_helper
INFO - 2020-03-31 16:28:09 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:28:09 --> Helper loaded: email_helper
INFO - 2020-03-31 16:28:09 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:28:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:28:09 --> Parser Class Initialized
INFO - 2020-03-31 16:28:09 --> User Agent Class Initialized
INFO - 2020-03-31 16:28:09 --> Model Class Initialized
INFO - 2020-03-31 16:28:09 --> Database Driver Class Initialized
INFO - 2020-03-31 16:28:09 --> Model Class Initialized
DEBUG - 2020-03-31 16:28:09 --> Template Class Initialized
INFO - 2020-03-31 16:28:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:28:09 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:28:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:28:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:28:09 --> Encryption Class Initialized
INFO - 2020-03-31 16:28:10 --> Controller Class Initialized
DEBUG - 2020-03-31 16:28:10 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:28:10 --> Model Class Initialized
INFO - 2020-03-31 16:28:10 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 16:28:10 --> Could not find the language line "Pending"
DEBUG - 2020-03-31 16:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:28:10 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:28:10 --> Model Class Initialized
DEBUG - 2020-03-31 16:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:28:10 --> Model Class Initialized
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:28:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:28:10 --> Final output sent to browser
DEBUG - 2020-03-31 16:28:10 --> Total execution time: 1.1912
INFO - 2020-03-31 16:29:29 --> Config Class Initialized
INFO - 2020-03-31 16:29:29 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:29:29 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:29:29 --> Utf8 Class Initialized
INFO - 2020-03-31 16:29:29 --> URI Class Initialized
INFO - 2020-03-31 16:29:29 --> Router Class Initialized
INFO - 2020-03-31 16:29:29 --> Output Class Initialized
INFO - 2020-03-31 16:29:29 --> Security Class Initialized
DEBUG - 2020-03-31 16:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:29:29 --> CSRF cookie sent
INFO - 2020-03-31 16:29:29 --> Input Class Initialized
INFO - 2020-03-31 16:29:29 --> Language Class Initialized
INFO - 2020-03-31 16:29:29 --> Language Class Initialized
INFO - 2020-03-31 16:29:29 --> Config Class Initialized
INFO - 2020-03-31 16:29:29 --> Loader Class Initialized
INFO - 2020-03-31 16:29:29 --> Helper loaded: url_helper
INFO - 2020-03-31 16:29:29 --> Helper loaded: common_helper
INFO - 2020-03-31 16:29:29 --> Helper loaded: language_helper
INFO - 2020-03-31 16:29:29 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:29:29 --> Helper loaded: email_helper
INFO - 2020-03-31 16:29:29 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:29:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:29:30 --> Parser Class Initialized
INFO - 2020-03-31 16:29:30 --> User Agent Class Initialized
INFO - 2020-03-31 16:29:30 --> Model Class Initialized
INFO - 2020-03-31 16:29:30 --> Database Driver Class Initialized
INFO - 2020-03-31 16:29:30 --> Model Class Initialized
DEBUG - 2020-03-31 16:29:30 --> Template Class Initialized
INFO - 2020-03-31 16:29:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:29:30 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:29:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:29:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:29:30 --> Encryption Class Initialized
INFO - 2020-03-31 16:29:30 --> Controller Class Initialized
DEBUG - 2020-03-31 16:29:30 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:29:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:29:30 --> Model Class Initialized
INFO - 2020-03-31 16:29:30 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 16:29:30 --> Could not find the language line "Pending"
DEBUG - 2020-03-31 16:29:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:29:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:29:30 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:29:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:29:30 --> Model Class Initialized
DEBUG - 2020-03-31 16:29:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:29:30 --> Model Class Initialized
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:29:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:29:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:29:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:29:30 --> Final output sent to browser
DEBUG - 2020-03-31 16:29:30 --> Total execution time: 1.2371
INFO - 2020-03-31 16:29:37 --> Config Class Initialized
INFO - 2020-03-31 16:29:37 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:29:37 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:29:37 --> Utf8 Class Initialized
INFO - 2020-03-31 16:29:37 --> URI Class Initialized
DEBUG - 2020-03-31 16:29:37 --> No URI present. Default controller set.
INFO - 2020-03-31 16:29:37 --> Router Class Initialized
INFO - 2020-03-31 16:29:37 --> Output Class Initialized
INFO - 2020-03-31 16:29:37 --> Security Class Initialized
DEBUG - 2020-03-31 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:29:37 --> CSRF cookie sent
INFO - 2020-03-31 16:29:37 --> Input Class Initialized
INFO - 2020-03-31 16:29:37 --> Language Class Initialized
INFO - 2020-03-31 16:29:37 --> Language Class Initialized
INFO - 2020-03-31 16:29:37 --> Config Class Initialized
INFO - 2020-03-31 16:29:37 --> Loader Class Initialized
INFO - 2020-03-31 16:29:37 --> Helper loaded: url_helper
INFO - 2020-03-31 16:29:37 --> Helper loaded: common_helper
INFO - 2020-03-31 16:29:37 --> Helper loaded: language_helper
INFO - 2020-03-31 16:29:37 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:29:37 --> Helper loaded: email_helper
INFO - 2020-03-31 16:29:37 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:29:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:29:37 --> Parser Class Initialized
INFO - 2020-03-31 16:29:37 --> User Agent Class Initialized
INFO - 2020-03-31 16:29:37 --> Model Class Initialized
INFO - 2020-03-31 16:29:37 --> Database Driver Class Initialized
INFO - 2020-03-31 16:29:37 --> Model Class Initialized
DEBUG - 2020-03-31 16:29:37 --> Template Class Initialized
INFO - 2020-03-31 16:29:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:29:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:29:37 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:29:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:29:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:29:37 --> Encryption Class Initialized
DEBUG - 2020-03-31 16:29:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 16:29:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-31 16:29:37 --> Controller Class Initialized
DEBUG - 2020-03-31 16:29:37 --> pergo MX_Controller Initialized
DEBUG - 2020-03-31 16:29:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-31 16:29:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-31 16:29:37 --> Model Class Initialized
INFO - 2020-03-31 16:29:37 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:29:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-31 16:29:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-31 16:29:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-31 16:29:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-31 16:29:38 --> Final output sent to browser
DEBUG - 2020-03-31 16:29:38 --> Total execution time: 0.9163
INFO - 2020-03-31 16:29:39 --> Config Class Initialized
INFO - 2020-03-31 16:29:39 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:29:39 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:29:39 --> Utf8 Class Initialized
INFO - 2020-03-31 16:29:39 --> URI Class Initialized
INFO - 2020-03-31 16:29:39 --> Router Class Initialized
INFO - 2020-03-31 16:29:39 --> Output Class Initialized
INFO - 2020-03-31 16:29:39 --> Security Class Initialized
DEBUG - 2020-03-31 16:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:29:39 --> CSRF cookie sent
INFO - 2020-03-31 16:29:39 --> Input Class Initialized
INFO - 2020-03-31 16:29:40 --> Language Class Initialized
INFO - 2020-03-31 16:29:40 --> Language Class Initialized
INFO - 2020-03-31 16:29:40 --> Config Class Initialized
INFO - 2020-03-31 16:29:40 --> Loader Class Initialized
INFO - 2020-03-31 16:29:40 --> Helper loaded: url_helper
INFO - 2020-03-31 16:29:40 --> Helper loaded: common_helper
INFO - 2020-03-31 16:29:40 --> Helper loaded: language_helper
INFO - 2020-03-31 16:29:40 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:29:40 --> Helper loaded: email_helper
INFO - 2020-03-31 16:29:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:29:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:29:40 --> Parser Class Initialized
INFO - 2020-03-31 16:29:40 --> User Agent Class Initialized
INFO - 2020-03-31 16:29:40 --> Model Class Initialized
INFO - 2020-03-31 16:29:40 --> Database Driver Class Initialized
INFO - 2020-03-31 16:29:40 --> Model Class Initialized
DEBUG - 2020-03-31 16:29:40 --> Template Class Initialized
INFO - 2020-03-31 16:29:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:29:40 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:29:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:29:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:29:40 --> Encryption Class Initialized
INFO - 2020-03-31 16:29:40 --> Controller Class Initialized
DEBUG - 2020-03-31 16:29:40 --> package MX_Controller Initialized
DEBUG - 2020-03-31 16:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-03-31 16:29:40 --> Model Class Initialized
INFO - 2020-03-31 16:29:40 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:29:40 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:29:40 --> Model Class Initialized
DEBUG - 2020-03-31 16:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:29:40 --> Model Class Initialized
DEBUG - 2020-03-31 16:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-03-31 16:29:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:29:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:29:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:29:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:29:41 --> Final output sent to browser
DEBUG - 2020-03-31 16:29:41 --> Total execution time: 1.3013
INFO - 2020-03-31 16:29:44 --> Config Class Initialized
INFO - 2020-03-31 16:29:44 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:29:44 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:29:44 --> Utf8 Class Initialized
INFO - 2020-03-31 16:29:44 --> URI Class Initialized
INFO - 2020-03-31 16:29:44 --> Router Class Initialized
INFO - 2020-03-31 16:29:44 --> Output Class Initialized
INFO - 2020-03-31 16:29:44 --> Security Class Initialized
DEBUG - 2020-03-31 16:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:29:44 --> CSRF cookie sent
INFO - 2020-03-31 16:29:44 --> CSRF token verified
INFO - 2020-03-31 16:29:44 --> Input Class Initialized
INFO - 2020-03-31 16:29:44 --> Language Class Initialized
INFO - 2020-03-31 16:29:44 --> Language Class Initialized
INFO - 2020-03-31 16:29:45 --> Config Class Initialized
INFO - 2020-03-31 16:29:45 --> Loader Class Initialized
INFO - 2020-03-31 16:29:45 --> Helper loaded: url_helper
INFO - 2020-03-31 16:29:45 --> Helper loaded: common_helper
INFO - 2020-03-31 16:29:45 --> Helper loaded: language_helper
INFO - 2020-03-31 16:29:45 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:29:45 --> Helper loaded: email_helper
INFO - 2020-03-31 16:29:45 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:29:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:29:45 --> Parser Class Initialized
INFO - 2020-03-31 16:29:45 --> User Agent Class Initialized
INFO - 2020-03-31 16:29:45 --> Model Class Initialized
INFO - 2020-03-31 16:29:45 --> Database Driver Class Initialized
INFO - 2020-03-31 16:29:45 --> Model Class Initialized
DEBUG - 2020-03-31 16:29:45 --> Template Class Initialized
INFO - 2020-03-31 16:29:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:29:45 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:29:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:29:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:29:45 --> Encryption Class Initialized
INFO - 2020-03-31 16:29:45 --> Controller Class Initialized
DEBUG - 2020-03-31 16:29:45 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:29:45 --> Model Class Initialized
INFO - 2020-03-31 16:29:45 --> Helper loaded: inflector_helper
ERROR - 2020-03-31 16:29:45 --> Could not find the language line "shopier"
DEBUG - 2020-03-31 16:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2020-03-31 16:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:29:45 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:29:45 --> Model Class Initialized
DEBUG - 2020-03-31 16:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:29:45 --> Model Class Initialized
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:29:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:29:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:29:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:29:46 --> Final output sent to browser
DEBUG - 2020-03-31 16:29:46 --> Total execution time: 1.2730
INFO - 2020-03-31 16:30:09 --> Config Class Initialized
INFO - 2020-03-31 16:30:09 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:30:09 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:30:09 --> Utf8 Class Initialized
INFO - 2020-03-31 16:30:09 --> URI Class Initialized
INFO - 2020-03-31 16:30:09 --> Router Class Initialized
INFO - 2020-03-31 16:30:09 --> Output Class Initialized
INFO - 2020-03-31 16:30:09 --> Security Class Initialized
DEBUG - 2020-03-31 16:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:30:09 --> CSRF cookie sent
INFO - 2020-03-31 16:30:09 --> CSRF token verified
INFO - 2020-03-31 16:30:09 --> Input Class Initialized
INFO - 2020-03-31 16:30:09 --> Language Class Initialized
INFO - 2020-03-31 16:30:09 --> Language Class Initialized
INFO - 2020-03-31 16:30:09 --> Config Class Initialized
INFO - 2020-03-31 16:30:09 --> Loader Class Initialized
INFO - 2020-03-31 16:30:09 --> Helper loaded: url_helper
INFO - 2020-03-31 16:30:09 --> Helper loaded: common_helper
INFO - 2020-03-31 16:30:09 --> Helper loaded: language_helper
INFO - 2020-03-31 16:30:09 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:30:09 --> Helper loaded: email_helper
INFO - 2020-03-31 16:30:09 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:30:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:30:09 --> Parser Class Initialized
INFO - 2020-03-31 16:30:09 --> User Agent Class Initialized
INFO - 2020-03-31 16:30:09 --> Model Class Initialized
INFO - 2020-03-31 16:30:09 --> Database Driver Class Initialized
INFO - 2020-03-31 16:30:09 --> Model Class Initialized
DEBUG - 2020-03-31 16:30:09 --> Template Class Initialized
INFO - 2020-03-31 16:30:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:30:09 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:30:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:30:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:30:09 --> Encryption Class Initialized
INFO - 2020-03-31 16:30:09 --> Controller Class Initialized
DEBUG - 2020-03-31 16:30:09 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:30:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:30:09 --> Model Class Initialized
DEBUG - 2020-03-31 16:30:09 --> hesabe MX_Controller Initialized
DEBUG - 2020-03-31 16:30:10 --> orders MX_Controller Initialized
DEBUG - 2020-03-31 16:30:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/hesabe/index.php
INFO - 2020-03-31 16:30:17 --> Final output sent to browser
DEBUG - 2020-03-31 16:30:17 --> Total execution time: 8.1864
INFO - 2020-03-31 16:31:03 --> Config Class Initialized
INFO - 2020-03-31 16:31:03 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:31:03 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:31:03 --> Utf8 Class Initialized
INFO - 2020-03-31 16:31:03 --> URI Class Initialized
INFO - 2020-03-31 16:31:03 --> Router Class Initialized
INFO - 2020-03-31 16:31:03 --> Output Class Initialized
INFO - 2020-03-31 16:31:03 --> Security Class Initialized
DEBUG - 2020-03-31 16:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:31:03 --> Input Class Initialized
INFO - 2020-03-31 16:31:03 --> Language Class Initialized
INFO - 2020-03-31 16:31:03 --> Language Class Initialized
INFO - 2020-03-31 16:31:03 --> Config Class Initialized
INFO - 2020-03-31 16:31:03 --> Loader Class Initialized
INFO - 2020-03-31 16:31:03 --> Helper loaded: url_helper
INFO - 2020-03-31 16:31:03 --> Helper loaded: common_helper
INFO - 2020-03-31 16:31:03 --> Helper loaded: language_helper
INFO - 2020-03-31 16:31:03 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:31:03 --> Helper loaded: email_helper
INFO - 2020-03-31 16:31:03 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:31:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:31:03 --> Parser Class Initialized
INFO - 2020-03-31 16:31:03 --> User Agent Class Initialized
INFO - 2020-03-31 16:31:03 --> Model Class Initialized
INFO - 2020-03-31 16:31:03 --> Database Driver Class Initialized
INFO - 2020-03-31 16:31:03 --> Model Class Initialized
DEBUG - 2020-03-31 16:31:03 --> Template Class Initialized
INFO - 2020-03-31 16:31:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:31:03 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:31:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:31:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:31:04 --> Encryption Class Initialized
INFO - 2020-03-31 16:31:04 --> Controller Class Initialized
DEBUG - 2020-03-31 16:31:04 --> hesabe MX_Controller Initialized
INFO - 2020-03-31 16:31:04 --> Model Class Initialized
INFO - 2020-03-31 16:31:04 --> Config Class Initialized
INFO - 2020-03-31 16:31:04 --> Hooks Class Initialized
DEBUG - 2020-03-31 16:31:04 --> UTF-8 Support Enabled
INFO - 2020-03-31 16:31:04 --> Utf8 Class Initialized
INFO - 2020-03-31 16:31:04 --> URI Class Initialized
INFO - 2020-03-31 16:31:04 --> Router Class Initialized
INFO - 2020-03-31 16:31:04 --> Output Class Initialized
INFO - 2020-03-31 16:31:04 --> Security Class Initialized
DEBUG - 2020-03-31 16:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-31 16:31:04 --> CSRF cookie sent
INFO - 2020-03-31 16:31:04 --> Input Class Initialized
INFO - 2020-03-31 16:31:04 --> Language Class Initialized
INFO - 2020-03-31 16:31:04 --> Language Class Initialized
INFO - 2020-03-31 16:31:04 --> Config Class Initialized
INFO - 2020-03-31 16:31:04 --> Loader Class Initialized
INFO - 2020-03-31 16:31:04 --> Helper loaded: url_helper
INFO - 2020-03-31 16:31:04 --> Helper loaded: common_helper
INFO - 2020-03-31 16:31:04 --> Helper loaded: language_helper
INFO - 2020-03-31 16:31:04 --> Helper loaded: cookie_helper
INFO - 2020-03-31 16:31:04 --> Helper loaded: email_helper
INFO - 2020-03-31 16:31:04 --> Helper loaded: file_manager_helper
INFO - 2020-03-31 16:31:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-31 16:31:04 --> Parser Class Initialized
INFO - 2020-03-31 16:31:04 --> User Agent Class Initialized
INFO - 2020-03-31 16:31:04 --> Model Class Initialized
INFO - 2020-03-31 16:31:04 --> Database Driver Class Initialized
INFO - 2020-03-31 16:31:04 --> Model Class Initialized
DEBUG - 2020-03-31 16:31:04 --> Template Class Initialized
INFO - 2020-03-31 16:31:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-31 16:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-31 16:31:04 --> Pagination Class Initialized
DEBUG - 2020-03-31 16:31:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-31 16:31:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-31 16:31:04 --> Encryption Class Initialized
INFO - 2020-03-31 16:31:04 --> Controller Class Initialized
DEBUG - 2020-03-31 16:31:04 --> checkout MX_Controller Initialized
DEBUG - 2020-03-31 16:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2020-03-31 16:31:04 --> Model Class Initialized
INFO - 2020-03-31 16:31:04 --> Helper loaded: inflector_helper
DEBUG - 2020-03-31 16:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2020-03-31 16:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-03-31 16:31:04 --> blocks MX_Controller Initialized
DEBUG - 2020-03-31 16:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-03-31 16:31:04 --> Model Class Initialized
DEBUG - 2020-03-31 16:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-03-31 16:31:04 --> Model Class Initialized
ERROR - 2020-03-31 16:31:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:31:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:31:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:31:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:31:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:31:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:31:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:31:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:31:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:31:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 25
ERROR - 2020-03-31 16:31:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 28
ERROR - 2020-03-31 16:31:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\blocks\views\user\header.php 29
DEBUG - 2020-03-31 16:31:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-03-31 16:31:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-03-31 16:31:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-03-31 16:31:05 --> Final output sent to browser
DEBUG - 2020-03-31 16:31:05 --> Total execution time: 1.2258
