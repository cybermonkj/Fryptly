<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-02 09:32:30 --> Config Class Initialized
INFO - 2019-11-02 09:32:30 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:32:30 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:32:30 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:30 --> URI Class Initialized
INFO - 2019-11-02 09:32:30 --> Router Class Initialized
INFO - 2019-11-02 09:32:30 --> Output Class Initialized
INFO - 2019-11-02 09:32:30 --> Security Class Initialized
DEBUG - 2019-11-02 09:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:32:30 --> CSRF cookie sent
INFO - 2019-11-02 09:32:30 --> Input Class Initialized
INFO - 2019-11-02 09:32:30 --> Language Class Initialized
INFO - 2019-11-02 09:32:30 --> Language Class Initialized
INFO - 2019-11-02 09:32:30 --> Config Class Initialized
INFO - 2019-11-02 09:32:30 --> Loader Class Initialized
INFO - 2019-11-02 09:32:31 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:31 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:31 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:31 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:31 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:31 --> Parser Class Initialized
INFO - 2019-11-02 09:32:31 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:31 --> Model Class Initialized
INFO - 2019-11-02 09:32:31 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:31 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:31 --> Template Class Initialized
INFO - 2019-11-02 09:32:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:31 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:31 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:31 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:31 --> auth MX_Controller Initialized
DEBUG - 2019-11-02 09:32:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-02 09:32:31 --> Model Class Initialized
INFO - 2019-11-02 09:32:31 --> Config Class Initialized
INFO - 2019-11-02 09:32:31 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:32:31 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:32:31 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:31 --> URI Class Initialized
INFO - 2019-11-02 09:32:31 --> Router Class Initialized
INFO - 2019-11-02 09:32:31 --> Output Class Initialized
INFO - 2019-11-02 09:32:31 --> Security Class Initialized
DEBUG - 2019-11-02 09:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:32:32 --> CSRF cookie sent
INFO - 2019-11-02 09:32:32 --> Input Class Initialized
INFO - 2019-11-02 09:32:32 --> Language Class Initialized
INFO - 2019-11-02 09:32:32 --> Language Class Initialized
INFO - 2019-11-02 09:32:32 --> Config Class Initialized
INFO - 2019-11-02 09:32:32 --> Loader Class Initialized
INFO - 2019-11-02 09:32:32 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:32 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:32 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:32 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:32 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:32 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:32 --> Parser Class Initialized
INFO - 2019-11-02 09:32:32 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:32 --> Model Class Initialized
INFO - 2019-11-02 09:32:32 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:32 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:32 --> Template Class Initialized
INFO - 2019-11-02 09:32:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:32 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:32 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:32 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:32 --> statistics MX_Controller Initialized
DEBUG - 2019-11-02 09:32:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-02 09:32:32 --> Model Class Initialized
ERROR - 2019-11-02 09:32:32 --> Could not find the language line "Pending"
ERROR - 2019-11-02 09:32:32 --> Could not find the language line "Pending"
INFO - 2019-11-02 09:32:32 --> Helper loaded: inflector_helper
ERROR - 2019-11-02 09:32:32 --> Could not find the language line "total_orders"
ERROR - 2019-11-02 09:32:32 --> Could not find the language line "total_orders"
ERROR - 2019-11-02 09:32:32 --> Could not find the language line "Pending"
DEBUG - 2019-11-02 09:32:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-02 09:32:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 09:32:32 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 09:32:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 09:32:32 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:32 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 09:32:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 09:32:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 09:32:32 --> Final output sent to browser
DEBUG - 2019-11-02 09:32:32 --> Total execution time: 0.9550
INFO - 2019-11-02 09:32:35 --> Config Class Initialized
INFO - 2019-11-02 09:32:35 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:32:35 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:32:35 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:35 --> URI Class Initialized
INFO - 2019-11-02 09:32:35 --> Router Class Initialized
INFO - 2019-11-02 09:32:35 --> Output Class Initialized
INFO - 2019-11-02 09:32:35 --> Security Class Initialized
DEBUG - 2019-11-02 09:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:32:35 --> CSRF cookie sent
INFO - 2019-11-02 09:32:35 --> Input Class Initialized
INFO - 2019-11-02 09:32:35 --> Language Class Initialized
INFO - 2019-11-02 09:32:35 --> Language Class Initialized
INFO - 2019-11-02 09:32:35 --> Config Class Initialized
INFO - 2019-11-02 09:32:35 --> Loader Class Initialized
INFO - 2019-11-02 09:32:35 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:35 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:35 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:35 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:35 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:35 --> Parser Class Initialized
INFO - 2019-11-02 09:32:35 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:35 --> Model Class Initialized
INFO - 2019-11-02 09:32:35 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:35 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:35 --> Template Class Initialized
INFO - 2019-11-02 09:32:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:35 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:35 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:35 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:35 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:32:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:35 --> Model Class Initialized
ERROR - 2019-11-02 09:32:35 --> Could not find the language line "Sorting"
INFO - 2019-11-02 09:32:35 --> Helper loaded: inflector_helper
ERROR - 2019-11-02 09:32:36 --> Could not find the language line "Delele"
DEBUG - 2019-11-02 09:32:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2019-11-02 09:32:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 09:32:36 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 09:32:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:36 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 09:32:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 09:32:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 09:32:36 --> Final output sent to browser
DEBUG - 2019-11-02 09:32:36 --> Total execution time: 0.8111
INFO - 2019-11-02 09:32:36 --> Config Class Initialized
INFO - 2019-11-02 09:32:36 --> Config Class Initialized
INFO - 2019-11-02 09:32:36 --> Config Class Initialized
INFO - 2019-11-02 09:32:36 --> Config Class Initialized
INFO - 2019-11-02 09:32:36 --> Hooks Class Initialized
INFO - 2019-11-02 09:32:36 --> Hooks Class Initialized
INFO - 2019-11-02 09:32:36 --> Hooks Class Initialized
INFO - 2019-11-02 09:32:36 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:32:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 09:32:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 09:32:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 09:32:36 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:32:36 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:36 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:36 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:36 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:36 --> URI Class Initialized
INFO - 2019-11-02 09:32:36 --> URI Class Initialized
INFO - 2019-11-02 09:32:36 --> URI Class Initialized
INFO - 2019-11-02 09:32:36 --> URI Class Initialized
INFO - 2019-11-02 09:32:36 --> Router Class Initialized
INFO - 2019-11-02 09:32:36 --> Router Class Initialized
INFO - 2019-11-02 09:32:36 --> Router Class Initialized
INFO - 2019-11-02 09:32:36 --> Router Class Initialized
INFO - 2019-11-02 09:32:36 --> Output Class Initialized
INFO - 2019-11-02 09:32:36 --> Output Class Initialized
INFO - 2019-11-02 09:32:36 --> Output Class Initialized
INFO - 2019-11-02 09:32:36 --> Output Class Initialized
INFO - 2019-11-02 09:32:36 --> Security Class Initialized
INFO - 2019-11-02 09:32:36 --> Security Class Initialized
INFO - 2019-11-02 09:32:36 --> Security Class Initialized
INFO - 2019-11-02 09:32:36 --> Security Class Initialized
DEBUG - 2019-11-02 09:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 09:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 09:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 09:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:32:36 --> CSRF cookie sent
INFO - 2019-11-02 09:32:36 --> CSRF cookie sent
INFO - 2019-11-02 09:32:36 --> CSRF cookie sent
INFO - 2019-11-02 09:32:36 --> CSRF cookie sent
INFO - 2019-11-02 09:32:36 --> CSRF token verified
INFO - 2019-11-02 09:32:36 --> CSRF token verified
INFO - 2019-11-02 09:32:36 --> CSRF token verified
INFO - 2019-11-02 09:32:36 --> CSRF token verified
INFO - 2019-11-02 09:32:36 --> Input Class Initialized
INFO - 2019-11-02 09:32:36 --> Input Class Initialized
INFO - 2019-11-02 09:32:36 --> Input Class Initialized
INFO - 2019-11-02 09:32:36 --> Input Class Initialized
INFO - 2019-11-02 09:32:36 --> Language Class Initialized
INFO - 2019-11-02 09:32:36 --> Language Class Initialized
INFO - 2019-11-02 09:32:36 --> Language Class Initialized
INFO - 2019-11-02 09:32:36 --> Language Class Initialized
INFO - 2019-11-02 09:32:36 --> Language Class Initialized
INFO - 2019-11-02 09:32:36 --> Language Class Initialized
INFO - 2019-11-02 09:32:36 --> Language Class Initialized
INFO - 2019-11-02 09:32:36 --> Language Class Initialized
INFO - 2019-11-02 09:32:36 --> Config Class Initialized
INFO - 2019-11-02 09:32:36 --> Config Class Initialized
INFO - 2019-11-02 09:32:36 --> Config Class Initialized
INFO - 2019-11-02 09:32:36 --> Config Class Initialized
INFO - 2019-11-02 09:32:36 --> Loader Class Initialized
INFO - 2019-11-02 09:32:36 --> Loader Class Initialized
INFO - 2019-11-02 09:32:36 --> Loader Class Initialized
INFO - 2019-11-02 09:32:36 --> Loader Class Initialized
INFO - 2019-11-02 09:32:36 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:36 --> Parser Class Initialized
INFO - 2019-11-02 09:32:36 --> Parser Class Initialized
INFO - 2019-11-02 09:32:36 --> Parser Class Initialized
INFO - 2019-11-02 09:32:36 --> Parser Class Initialized
INFO - 2019-11-02 09:32:36 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:36 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:36 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:36 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
INFO - 2019-11-02 09:32:36 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:36 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:36 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:36 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:36 --> Template Class Initialized
DEBUG - 2019-11-02 09:32:36 --> Template Class Initialized
DEBUG - 2019-11-02 09:32:36 --> Template Class Initialized
DEBUG - 2019-11-02 09:32:36 --> Template Class Initialized
INFO - 2019-11-02 09:32:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:36 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:36 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:36 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:36 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:32:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:36 --> Model Class Initialized
ERROR - 2019-11-02 09:32:36 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:32:37 --> Final output sent to browser
DEBUG - 2019-11-02 09:32:37 --> Total execution time: 0.5515
INFO - 2019-11-02 09:32:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:37 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:37 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:37 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:37 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:37 --> Model Class Initialized
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:32:37 --> Final output sent to browser
DEBUG - 2019-11-02 09:32:37 --> Total execution time: 0.7724
INFO - 2019-11-02 09:32:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:37 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:37 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:37 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:37 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:37 --> Model Class Initialized
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:32:37 --> Final output sent to browser
DEBUG - 2019-11-02 09:32:37 --> Total execution time: 0.9804
INFO - 2019-11-02 09:32:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:37 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:37 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:37 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:37 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:37 --> Model Class Initialized
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
ERROR - 2019-11-02 09:32:37 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:32:37 --> Final output sent to browser
DEBUG - 2019-11-02 09:32:37 --> Total execution time: 1.1574
INFO - 2019-11-02 09:32:38 --> Config Class Initialized
INFO - 2019-11-02 09:32:38 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:32:38 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:32:38 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:38 --> URI Class Initialized
INFO - 2019-11-02 09:32:38 --> Router Class Initialized
INFO - 2019-11-02 09:32:38 --> Output Class Initialized
INFO - 2019-11-02 09:32:38 --> Security Class Initialized
DEBUG - 2019-11-02 09:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:32:38 --> CSRF cookie sent
INFO - 2019-11-02 09:32:38 --> Input Class Initialized
INFO - 2019-11-02 09:32:38 --> Language Class Initialized
INFO - 2019-11-02 09:32:38 --> Language Class Initialized
INFO - 2019-11-02 09:32:38 --> Config Class Initialized
INFO - 2019-11-02 09:32:38 --> Loader Class Initialized
INFO - 2019-11-02 09:32:38 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:38 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:38 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:38 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:38 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:38 --> Parser Class Initialized
INFO - 2019-11-02 09:32:38 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:38 --> Model Class Initialized
INFO - 2019-11-02 09:32:38 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:38 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:38 --> Template Class Initialized
INFO - 2019-11-02 09:32:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:38 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:38 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:38 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:38 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:32:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:38 --> Model Class Initialized
ERROR - 2019-11-02 09:32:38 --> Could not find the language line "Sorting"
DEBUG - 2019-11-02 09:32:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-11-02 09:32:38 --> Final output sent to browser
DEBUG - 2019-11-02 09:32:38 --> Total execution time: 0.5500
INFO - 2019-11-02 09:32:42 --> Config Class Initialized
INFO - 2019-11-02 09:32:42 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:32:42 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:32:42 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:42 --> URI Class Initialized
INFO - 2019-11-02 09:32:42 --> Router Class Initialized
INFO - 2019-11-02 09:32:42 --> Output Class Initialized
INFO - 2019-11-02 09:32:42 --> Security Class Initialized
DEBUG - 2019-11-02 09:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:32:42 --> CSRF cookie sent
INFO - 2019-11-02 09:32:42 --> Input Class Initialized
INFO - 2019-11-02 09:32:42 --> Language Class Initialized
INFO - 2019-11-02 09:32:42 --> Language Class Initialized
INFO - 2019-11-02 09:32:42 --> Config Class Initialized
INFO - 2019-11-02 09:32:42 --> Loader Class Initialized
INFO - 2019-11-02 09:32:42 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:42 --> Parser Class Initialized
INFO - 2019-11-02 09:32:42 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:42 --> Model Class Initialized
INFO - 2019-11-02 09:32:42 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:42 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:42 --> Template Class Initialized
INFO - 2019-11-02 09:32:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:42 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:42 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:42 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:42 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:42 --> Model Class Initialized
ERROR - 2019-11-02 09:32:42 --> Could not find the language line "Sorting"
DEBUG - 2019-11-02 09:32:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-11-02 09:32:42 --> Final output sent to browser
DEBUG - 2019-11-02 09:32:42 --> Total execution time: 0.4511
INFO - 2019-11-02 09:32:42 --> Config Class Initialized
INFO - 2019-11-02 09:32:42 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:32:42 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:32:42 --> Utf8 Class Initialized
INFO - 2019-11-02 09:32:42 --> URI Class Initialized
INFO - 2019-11-02 09:32:42 --> Router Class Initialized
INFO - 2019-11-02 09:32:42 --> Output Class Initialized
INFO - 2019-11-02 09:32:42 --> Security Class Initialized
DEBUG - 2019-11-02 09:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:32:42 --> CSRF cookie sent
INFO - 2019-11-02 09:32:42 --> Input Class Initialized
INFO - 2019-11-02 09:32:42 --> Language Class Initialized
INFO - 2019-11-02 09:32:42 --> Language Class Initialized
INFO - 2019-11-02 09:32:42 --> Config Class Initialized
INFO - 2019-11-02 09:32:42 --> Loader Class Initialized
INFO - 2019-11-02 09:32:42 --> Helper loaded: url_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: common_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: language_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: email_helper
INFO - 2019-11-02 09:32:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:32:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:32:42 --> Parser Class Initialized
INFO - 2019-11-02 09:32:42 --> User Agent Class Initialized
INFO - 2019-11-02 09:32:42 --> Model Class Initialized
INFO - 2019-11-02 09:32:42 --> Database Driver Class Initialized
INFO - 2019-11-02 09:32:42 --> Model Class Initialized
DEBUG - 2019-11-02 09:32:42 --> Template Class Initialized
INFO - 2019-11-02 09:32:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:32:42 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:32:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:32:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:32:42 --> Encryption Class Initialized
INFO - 2019-11-02 09:32:43 --> Controller Class Initialized
DEBUG - 2019-11-02 09:32:43 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:32:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:32:43 --> Model Class Initialized
ERROR - 2019-11-02 09:32:43 --> Could not find the language line "Sorting"
DEBUG - 2019-11-02 09:32:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-11-02 09:32:43 --> Final output sent to browser
DEBUG - 2019-11-02 09:32:43 --> Total execution time: 0.6045
INFO - 2019-11-02 09:33:03 --> Config Class Initialized
INFO - 2019-11-02 09:33:04 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:33:04 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:33:04 --> Utf8 Class Initialized
INFO - 2019-11-02 09:33:04 --> URI Class Initialized
INFO - 2019-11-02 09:33:04 --> Router Class Initialized
INFO - 2019-11-02 09:33:04 --> Output Class Initialized
INFO - 2019-11-02 09:33:04 --> Security Class Initialized
DEBUG - 2019-11-02 09:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:33:04 --> CSRF cookie sent
INFO - 2019-11-02 09:33:04 --> Input Class Initialized
INFO - 2019-11-02 09:33:04 --> Language Class Initialized
INFO - 2019-11-02 09:33:04 --> Language Class Initialized
INFO - 2019-11-02 09:33:04 --> Config Class Initialized
INFO - 2019-11-02 09:33:04 --> Loader Class Initialized
INFO - 2019-11-02 09:33:04 --> Helper loaded: url_helper
INFO - 2019-11-02 09:33:04 --> Helper loaded: common_helper
INFO - 2019-11-02 09:33:04 --> Helper loaded: language_helper
INFO - 2019-11-02 09:33:04 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:33:04 --> Helper loaded: email_helper
INFO - 2019-11-02 09:33:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:33:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:33:04 --> Parser Class Initialized
INFO - 2019-11-02 09:33:04 --> User Agent Class Initialized
INFO - 2019-11-02 09:33:04 --> Model Class Initialized
INFO - 2019-11-02 09:33:04 --> Database Driver Class Initialized
INFO - 2019-11-02 09:33:04 --> Model Class Initialized
DEBUG - 2019-11-02 09:33:04 --> Template Class Initialized
INFO - 2019-11-02 09:33:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:33:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:33:04 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:33:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:33:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:33:04 --> Encryption Class Initialized
INFO - 2019-11-02 09:33:04 --> Controller Class Initialized
DEBUG - 2019-11-02 09:33:04 --> profile MX_Controller Initialized
DEBUG - 2019-11-02 09:33:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/profile/models/profile_model.php
INFO - 2019-11-02 09:33:04 --> Model Class Initialized
INFO - 2019-11-02 09:33:04 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 09:33:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/profile/views/index.php
DEBUG - 2019-11-02 09:33:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 09:33:04 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 09:33:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 09:33:04 --> Model Class Initialized
DEBUG - 2019-11-02 09:33:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:33:04 --> Model Class Initialized
DEBUG - 2019-11-02 09:33:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 09:33:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 09:33:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 09:33:04 --> Final output sent to browser
DEBUG - 2019-11-02 09:33:04 --> Total execution time: 0.6865
INFO - 2019-11-02 09:33:16 --> Config Class Initialized
INFO - 2019-11-02 09:33:16 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:33:16 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:33:16 --> Utf8 Class Initialized
INFO - 2019-11-02 09:33:16 --> URI Class Initialized
INFO - 2019-11-02 09:33:16 --> Router Class Initialized
INFO - 2019-11-02 09:33:16 --> Output Class Initialized
INFO - 2019-11-02 09:33:16 --> Security Class Initialized
DEBUG - 2019-11-02 09:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:33:16 --> CSRF cookie sent
INFO - 2019-11-02 09:33:16 --> Input Class Initialized
INFO - 2019-11-02 09:33:16 --> Language Class Initialized
INFO - 2019-11-02 09:33:16 --> Language Class Initialized
INFO - 2019-11-02 09:33:16 --> Config Class Initialized
INFO - 2019-11-02 09:33:16 --> Loader Class Initialized
INFO - 2019-11-02 09:33:16 --> Helper loaded: url_helper
INFO - 2019-11-02 09:33:16 --> Helper loaded: common_helper
INFO - 2019-11-02 09:33:16 --> Helper loaded: language_helper
INFO - 2019-11-02 09:33:16 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:33:16 --> Helper loaded: email_helper
INFO - 2019-11-02 09:33:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:33:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:33:16 --> Parser Class Initialized
INFO - 2019-11-02 09:33:16 --> User Agent Class Initialized
INFO - 2019-11-02 09:33:16 --> Model Class Initialized
INFO - 2019-11-02 09:33:16 --> Database Driver Class Initialized
INFO - 2019-11-02 09:33:16 --> Model Class Initialized
DEBUG - 2019-11-02 09:33:16 --> Template Class Initialized
INFO - 2019-11-02 09:33:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:33:16 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:33:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:33:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:33:16 --> Encryption Class Initialized
INFO - 2019-11-02 09:33:16 --> Controller Class Initialized
DEBUG - 2019-11-02 09:33:16 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:33:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:33:16 --> Model Class Initialized
ERROR - 2019-11-02 09:33:16 --> Could not find the language line "Sorting"
INFO - 2019-11-02 09:33:16 --> Helper loaded: inflector_helper
ERROR - 2019-11-02 09:33:16 --> Could not find the language line "Delele"
DEBUG - 2019-11-02 09:33:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2019-11-02 09:33:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 09:33:16 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 09:33:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 09:33:16 --> Model Class Initialized
DEBUG - 2019-11-02 09:33:16 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:33:16 --> Model Class Initialized
DEBUG - 2019-11-02 09:33:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 09:33:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 09:33:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 09:33:16 --> Final output sent to browser
DEBUG - 2019-11-02 09:33:16 --> Total execution time: 0.6441
INFO - 2019-11-02 09:33:17 --> Config Class Initialized
INFO - 2019-11-02 09:33:17 --> Config Class Initialized
INFO - 2019-11-02 09:33:17 --> Config Class Initialized
INFO - 2019-11-02 09:33:17 --> Config Class Initialized
INFO - 2019-11-02 09:33:17 --> Hooks Class Initialized
INFO - 2019-11-02 09:33:17 --> Hooks Class Initialized
INFO - 2019-11-02 09:33:17 --> Hooks Class Initialized
INFO - 2019-11-02 09:33:17 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 09:33:17 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:33:17 --> Utf8 Class Initialized
INFO - 2019-11-02 09:33:17 --> Utf8 Class Initialized
INFO - 2019-11-02 09:33:17 --> Utf8 Class Initialized
INFO - 2019-11-02 09:33:17 --> Utf8 Class Initialized
INFO - 2019-11-02 09:33:17 --> URI Class Initialized
INFO - 2019-11-02 09:33:17 --> URI Class Initialized
INFO - 2019-11-02 09:33:17 --> URI Class Initialized
INFO - 2019-11-02 09:33:17 --> URI Class Initialized
INFO - 2019-11-02 09:33:17 --> Router Class Initialized
INFO - 2019-11-02 09:33:17 --> Router Class Initialized
INFO - 2019-11-02 09:33:17 --> Router Class Initialized
INFO - 2019-11-02 09:33:17 --> Router Class Initialized
INFO - 2019-11-02 09:33:17 --> Output Class Initialized
INFO - 2019-11-02 09:33:17 --> Output Class Initialized
INFO - 2019-11-02 09:33:17 --> Output Class Initialized
INFO - 2019-11-02 09:33:17 --> Output Class Initialized
INFO - 2019-11-02 09:33:17 --> Security Class Initialized
INFO - 2019-11-02 09:33:17 --> Security Class Initialized
INFO - 2019-11-02 09:33:17 --> Security Class Initialized
INFO - 2019-11-02 09:33:17 --> Security Class Initialized
DEBUG - 2019-11-02 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 09:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:33:17 --> CSRF cookie sent
INFO - 2019-11-02 09:33:17 --> CSRF cookie sent
INFO - 2019-11-02 09:33:17 --> CSRF cookie sent
INFO - 2019-11-02 09:33:17 --> CSRF cookie sent
INFO - 2019-11-02 09:33:17 --> CSRF token verified
INFO - 2019-11-02 09:33:17 --> CSRF token verified
INFO - 2019-11-02 09:33:17 --> CSRF token verified
INFO - 2019-11-02 09:33:17 --> CSRF token verified
INFO - 2019-11-02 09:33:17 --> Input Class Initialized
INFO - 2019-11-02 09:33:17 --> Input Class Initialized
INFO - 2019-11-02 09:33:17 --> Input Class Initialized
INFO - 2019-11-02 09:33:17 --> Input Class Initialized
INFO - 2019-11-02 09:33:17 --> Language Class Initialized
INFO - 2019-11-02 09:33:17 --> Language Class Initialized
INFO - 2019-11-02 09:33:17 --> Language Class Initialized
INFO - 2019-11-02 09:33:17 --> Language Class Initialized
INFO - 2019-11-02 09:33:17 --> Language Class Initialized
INFO - 2019-11-02 09:33:17 --> Language Class Initialized
INFO - 2019-11-02 09:33:17 --> Language Class Initialized
INFO - 2019-11-02 09:33:17 --> Language Class Initialized
INFO - 2019-11-02 09:33:17 --> Config Class Initialized
INFO - 2019-11-02 09:33:17 --> Config Class Initialized
INFO - 2019-11-02 09:33:17 --> Config Class Initialized
INFO - 2019-11-02 09:33:17 --> Config Class Initialized
INFO - 2019-11-02 09:33:17 --> Loader Class Initialized
INFO - 2019-11-02 09:33:17 --> Loader Class Initialized
INFO - 2019-11-02 09:33:17 --> Loader Class Initialized
INFO - 2019-11-02 09:33:17 --> Loader Class Initialized
INFO - 2019-11-02 09:33:17 --> Helper loaded: url_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: url_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: url_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: url_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: common_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: common_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: common_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: common_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: language_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: language_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: language_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: language_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: email_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: email_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: email_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: email_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:33:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:33:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:33:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:33:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:33:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:33:18 --> Parser Class Initialized
INFO - 2019-11-02 09:33:18 --> Parser Class Initialized
INFO - 2019-11-02 09:33:18 --> Parser Class Initialized
INFO - 2019-11-02 09:33:18 --> Parser Class Initialized
INFO - 2019-11-02 09:33:18 --> User Agent Class Initialized
INFO - 2019-11-02 09:33:18 --> User Agent Class Initialized
INFO - 2019-11-02 09:33:18 --> User Agent Class Initialized
INFO - 2019-11-02 09:33:18 --> User Agent Class Initialized
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
INFO - 2019-11-02 09:33:18 --> Database Driver Class Initialized
INFO - 2019-11-02 09:33:18 --> Database Driver Class Initialized
INFO - 2019-11-02 09:33:18 --> Database Driver Class Initialized
INFO - 2019-11-02 09:33:18 --> Database Driver Class Initialized
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
DEBUG - 2019-11-02 09:33:18 --> Template Class Initialized
DEBUG - 2019-11-02 09:33:18 --> Template Class Initialized
DEBUG - 2019-11-02 09:33:18 --> Template Class Initialized
DEBUG - 2019-11-02 09:33:18 --> Template Class Initialized
INFO - 2019-11-02 09:33:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:33:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:33:18 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:33:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:33:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:33:18 --> Encryption Class Initialized
INFO - 2019-11-02 09:33:18 --> Controller Class Initialized
DEBUG - 2019-11-02 09:33:18 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:33:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "View"
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "View"
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "View"
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "View"
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:33:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:33:18 --> Final output sent to browser
DEBUG - 2019-11-02 09:33:18 --> Total execution time: 0.8135
INFO - 2019-11-02 09:33:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:33:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:33:18 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:33:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:33:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:33:18 --> Encryption Class Initialized
INFO - 2019-11-02 09:33:18 --> Controller Class Initialized
DEBUG - 2019-11-02 09:33:18 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:33:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:33:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:33:18 --> Final output sent to browser
DEBUG - 2019-11-02 09:33:18 --> Total execution time: 1.0692
INFO - 2019-11-02 09:33:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:33:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:33:18 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:33:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:33:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:33:18 --> Encryption Class Initialized
INFO - 2019-11-02 09:33:18 --> Controller Class Initialized
DEBUG - 2019-11-02 09:33:18 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:33:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:33:18 --> Model Class Initialized
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "View"
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "View"
ERROR - 2019-11-02 09:33:18 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:33:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:33:19 --> Final output sent to browser
DEBUG - 2019-11-02 09:33:19 --> Total execution time: 1.4134
INFO - 2019-11-02 09:33:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:33:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:33:19 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:33:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:33:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:33:19 --> Encryption Class Initialized
INFO - 2019-11-02 09:33:19 --> Controller Class Initialized
DEBUG - 2019-11-02 09:33:19 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:33:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:33:19 --> Model Class Initialized
ERROR - 2019-11-02 09:33:19 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:33:19 --> Could not find the language line "View"
ERROR - 2019-11-02 09:33:19 --> Could not find the language line "View"
ERROR - 2019-11-02 09:33:19 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:33:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:33:19 --> Final output sent to browser
DEBUG - 2019-11-02 09:33:19 --> Total execution time: 1.7458
INFO - 2019-11-02 09:37:18 --> Config Class Initialized
INFO - 2019-11-02 09:37:18 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:37:18 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:37:18 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:18 --> URI Class Initialized
INFO - 2019-11-02 09:37:18 --> Router Class Initialized
INFO - 2019-11-02 09:37:18 --> Output Class Initialized
INFO - 2019-11-02 09:37:18 --> Security Class Initialized
DEBUG - 2019-11-02 09:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:37:18 --> CSRF cookie sent
INFO - 2019-11-02 09:37:18 --> Input Class Initialized
INFO - 2019-11-02 09:37:18 --> Language Class Initialized
INFO - 2019-11-02 09:37:18 --> Language Class Initialized
INFO - 2019-11-02 09:37:18 --> Config Class Initialized
INFO - 2019-11-02 09:37:18 --> Loader Class Initialized
INFO - 2019-11-02 09:37:18 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:18 --> Helper loaded: common_helper
INFO - 2019-11-02 09:37:18 --> Helper loaded: language_helper
INFO - 2019-11-02 09:37:18 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:37:18 --> Helper loaded: email_helper
INFO - 2019-11-02 09:37:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:37:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:37:18 --> Parser Class Initialized
INFO - 2019-11-02 09:37:18 --> User Agent Class Initialized
INFO - 2019-11-02 09:37:18 --> Model Class Initialized
INFO - 2019-11-02 09:37:18 --> Database Driver Class Initialized
INFO - 2019-11-02 09:37:18 --> Model Class Initialized
DEBUG - 2019-11-02 09:37:18 --> Template Class Initialized
INFO - 2019-11-02 09:37:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:37:18 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:37:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:37:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:37:18 --> Encryption Class Initialized
INFO - 2019-11-02 09:37:18 --> Controller Class Initialized
DEBUG - 2019-11-02 09:37:18 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:37:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:37:18 --> Model Class Initialized
ERROR - 2019-11-02 09:37:18 --> Could not find the language line "Sorting"
DEBUG - 2019-11-02 09:37:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-11-02 09:37:18 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:18 --> Total execution time: 0.5043
INFO - 2019-11-02 09:37:33 --> Config Class Initialized
INFO - 2019-11-02 09:37:33 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:37:33 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:37:33 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:34 --> URI Class Initialized
INFO - 2019-11-02 09:37:34 --> Router Class Initialized
INFO - 2019-11-02 09:37:34 --> Output Class Initialized
INFO - 2019-11-02 09:37:34 --> Security Class Initialized
DEBUG - 2019-11-02 09:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:37:34 --> CSRF cookie sent
INFO - 2019-11-02 09:37:34 --> Input Class Initialized
INFO - 2019-11-02 09:37:34 --> Language Class Initialized
INFO - 2019-11-02 09:37:34 --> Language Class Initialized
INFO - 2019-11-02 09:37:34 --> Config Class Initialized
INFO - 2019-11-02 09:37:34 --> Loader Class Initialized
INFO - 2019-11-02 09:37:34 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:34 --> Helper loaded: common_helper
INFO - 2019-11-02 09:37:34 --> Helper loaded: language_helper
INFO - 2019-11-02 09:37:34 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:37:34 --> Helper loaded: email_helper
INFO - 2019-11-02 09:37:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:37:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:37:34 --> Parser Class Initialized
INFO - 2019-11-02 09:37:34 --> User Agent Class Initialized
INFO - 2019-11-02 09:37:34 --> Model Class Initialized
INFO - 2019-11-02 09:37:34 --> Database Driver Class Initialized
INFO - 2019-11-02 09:37:34 --> Model Class Initialized
DEBUG - 2019-11-02 09:37:34 --> Template Class Initialized
INFO - 2019-11-02 09:37:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:37:34 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:37:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:37:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:37:34 --> Encryption Class Initialized
INFO - 2019-11-02 09:37:34 --> Controller Class Initialized
DEBUG - 2019-11-02 09:37:34 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:37:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:37:34 --> Model Class Initialized
ERROR - 2019-11-02 09:37:34 --> Could not find the language line "Sorting"
INFO - 2019-11-02 09:37:34 --> Helper loaded: inflector_helper
ERROR - 2019-11-02 09:37:34 --> Could not find the language line "Delele"
DEBUG - 2019-11-02 09:37:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2019-11-02 09:37:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 09:37:34 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 09:37:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 09:37:34 --> Model Class Initialized
DEBUG - 2019-11-02 09:37:34 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:37:34 --> Model Class Initialized
DEBUG - 2019-11-02 09:37:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 09:37:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 09:37:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 09:37:34 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:34 --> Total execution time: 0.7913
INFO - 2019-11-02 09:37:35 --> Config Class Initialized
INFO - 2019-11-02 09:37:35 --> Config Class Initialized
INFO - 2019-11-02 09:37:35 --> Config Class Initialized
INFO - 2019-11-02 09:37:35 --> Config Class Initialized
INFO - 2019-11-02 09:37:35 --> Hooks Class Initialized
INFO - 2019-11-02 09:37:35 --> Hooks Class Initialized
INFO - 2019-11-02 09:37:35 --> Hooks Class Initialized
INFO - 2019-11-02 09:37:35 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:37:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 09:37:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 09:37:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 09:37:35 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:37:35 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:35 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:35 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:35 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:35 --> URI Class Initialized
INFO - 2019-11-02 09:37:35 --> URI Class Initialized
INFO - 2019-11-02 09:37:35 --> URI Class Initialized
INFO - 2019-11-02 09:37:35 --> URI Class Initialized
INFO - 2019-11-02 09:37:35 --> Router Class Initialized
INFO - 2019-11-02 09:37:35 --> Router Class Initialized
INFO - 2019-11-02 09:37:35 --> Router Class Initialized
INFO - 2019-11-02 09:37:35 --> Router Class Initialized
INFO - 2019-11-02 09:37:35 --> Output Class Initialized
INFO - 2019-11-02 09:37:35 --> Output Class Initialized
INFO - 2019-11-02 09:37:35 --> Output Class Initialized
INFO - 2019-11-02 09:37:35 --> Output Class Initialized
INFO - 2019-11-02 09:37:35 --> Security Class Initialized
INFO - 2019-11-02 09:37:35 --> Security Class Initialized
INFO - 2019-11-02 09:37:35 --> Security Class Initialized
INFO - 2019-11-02 09:37:35 --> Security Class Initialized
DEBUG - 2019-11-02 09:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 09:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 09:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 09:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:37:35 --> CSRF cookie sent
INFO - 2019-11-02 09:37:35 --> CSRF cookie sent
INFO - 2019-11-02 09:37:35 --> CSRF cookie sent
INFO - 2019-11-02 09:37:35 --> CSRF cookie sent
INFO - 2019-11-02 09:37:35 --> CSRF token verified
INFO - 2019-11-02 09:37:35 --> CSRF token verified
INFO - 2019-11-02 09:37:35 --> CSRF token verified
INFO - 2019-11-02 09:37:35 --> CSRF token verified
INFO - 2019-11-02 09:37:35 --> Input Class Initialized
INFO - 2019-11-02 09:37:35 --> Input Class Initialized
INFO - 2019-11-02 09:37:35 --> Input Class Initialized
INFO - 2019-11-02 09:37:35 --> Input Class Initialized
INFO - 2019-11-02 09:37:35 --> Language Class Initialized
INFO - 2019-11-02 09:37:35 --> Language Class Initialized
INFO - 2019-11-02 09:37:35 --> Language Class Initialized
INFO - 2019-11-02 09:37:35 --> Language Class Initialized
INFO - 2019-11-02 09:37:35 --> Language Class Initialized
INFO - 2019-11-02 09:37:35 --> Language Class Initialized
INFO - 2019-11-02 09:37:35 --> Language Class Initialized
INFO - 2019-11-02 09:37:35 --> Language Class Initialized
INFO - 2019-11-02 09:37:35 --> Config Class Initialized
INFO - 2019-11-02 09:37:35 --> Config Class Initialized
INFO - 2019-11-02 09:37:35 --> Config Class Initialized
INFO - 2019-11-02 09:37:35 --> Config Class Initialized
INFO - 2019-11-02 09:37:35 --> Loader Class Initialized
INFO - 2019-11-02 09:37:35 --> Loader Class Initialized
INFO - 2019-11-02 09:37:35 --> Loader Class Initialized
INFO - 2019-11-02 09:37:35 --> Loader Class Initialized
INFO - 2019-11-02 09:37:35 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: common_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: common_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: common_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: common_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: language_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: language_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: language_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: language_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: email_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: email_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: email_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: email_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:37:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:37:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:37:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:37:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:37:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:37:35 --> Parser Class Initialized
INFO - 2019-11-02 09:37:35 --> Parser Class Initialized
INFO - 2019-11-02 09:37:35 --> Parser Class Initialized
INFO - 2019-11-02 09:37:35 --> Parser Class Initialized
INFO - 2019-11-02 09:37:35 --> User Agent Class Initialized
INFO - 2019-11-02 09:37:35 --> User Agent Class Initialized
INFO - 2019-11-02 09:37:35 --> User Agent Class Initialized
INFO - 2019-11-02 09:37:35 --> User Agent Class Initialized
INFO - 2019-11-02 09:37:35 --> Model Class Initialized
INFO - 2019-11-02 09:37:35 --> Model Class Initialized
INFO - 2019-11-02 09:37:35 --> Model Class Initialized
INFO - 2019-11-02 09:37:35 --> Model Class Initialized
INFO - 2019-11-02 09:37:36 --> Database Driver Class Initialized
INFO - 2019-11-02 09:37:36 --> Database Driver Class Initialized
INFO - 2019-11-02 09:37:36 --> Database Driver Class Initialized
INFO - 2019-11-02 09:37:36 --> Database Driver Class Initialized
INFO - 2019-11-02 09:37:36 --> Model Class Initialized
INFO - 2019-11-02 09:37:36 --> Model Class Initialized
INFO - 2019-11-02 09:37:36 --> Model Class Initialized
INFO - 2019-11-02 09:37:36 --> Model Class Initialized
DEBUG - 2019-11-02 09:37:36 --> Template Class Initialized
DEBUG - 2019-11-02 09:37:36 --> Template Class Initialized
DEBUG - 2019-11-02 09:37:36 --> Template Class Initialized
DEBUG - 2019-11-02 09:37:36 --> Template Class Initialized
INFO - 2019-11-02 09:37:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:37:36 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:37:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:37:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:37:36 --> Encryption Class Initialized
INFO - 2019-11-02 09:37:36 --> Controller Class Initialized
DEBUG - 2019-11-02 09:37:36 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:37:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:37:36 --> Model Class Initialized
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:37:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:37:36 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:36 --> Total execution time: 0.7372
INFO - 2019-11-02 09:37:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:37:36 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:37:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:37:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:37:36 --> Encryption Class Initialized
INFO - 2019-11-02 09:37:36 --> Controller Class Initialized
DEBUG - 2019-11-02 09:37:36 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:37:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:37:36 --> Model Class Initialized
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:37:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:37:36 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:36 --> Total execution time: 0.9710
INFO - 2019-11-02 09:37:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:37:36 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:37:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:37:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:37:36 --> Encryption Class Initialized
INFO - 2019-11-02 09:37:36 --> Controller Class Initialized
DEBUG - 2019-11-02 09:37:36 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:37:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:37:36 --> Model Class Initialized
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:37:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:37:36 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:36 --> Total execution time: 1.1672
INFO - 2019-11-02 09:37:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:37:36 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:37:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:37:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:37:36 --> Encryption Class Initialized
INFO - 2019-11-02 09:37:36 --> Controller Class Initialized
DEBUG - 2019-11-02 09:37:36 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:37:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:37:36 --> Model Class Initialized
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "Sorting"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
ERROR - 2019-11-02 09:37:36 --> Could not find the language line "View"
DEBUG - 2019-11-02 09:37:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-11-02 09:37:36 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:36 --> Total execution time: 1.3675
INFO - 2019-11-02 09:37:38 --> Config Class Initialized
INFO - 2019-11-02 09:37:38 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:37:38 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:37:38 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:38 --> URI Class Initialized
INFO - 2019-11-02 09:37:38 --> Router Class Initialized
INFO - 2019-11-02 09:37:38 --> Output Class Initialized
INFO - 2019-11-02 09:37:38 --> Security Class Initialized
DEBUG - 2019-11-02 09:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:37:38 --> CSRF cookie sent
INFO - 2019-11-02 09:37:38 --> Input Class Initialized
INFO - 2019-11-02 09:37:38 --> Language Class Initialized
INFO - 2019-11-02 09:37:38 --> Language Class Initialized
INFO - 2019-11-02 09:37:38 --> Config Class Initialized
INFO - 2019-11-02 09:37:38 --> Loader Class Initialized
INFO - 2019-11-02 09:37:38 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:38 --> Helper loaded: common_helper
INFO - 2019-11-02 09:37:38 --> Helper loaded: language_helper
INFO - 2019-11-02 09:37:38 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:37:38 --> Helper loaded: email_helper
INFO - 2019-11-02 09:37:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:37:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:37:38 --> Parser Class Initialized
INFO - 2019-11-02 09:37:38 --> User Agent Class Initialized
INFO - 2019-11-02 09:37:38 --> Model Class Initialized
INFO - 2019-11-02 09:37:38 --> Database Driver Class Initialized
INFO - 2019-11-02 09:37:38 --> Model Class Initialized
DEBUG - 2019-11-02 09:37:38 --> Template Class Initialized
INFO - 2019-11-02 09:37:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:37:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:37:38 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:37:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:37:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:37:38 --> Encryption Class Initialized
INFO - 2019-11-02 09:37:38 --> Controller Class Initialized
DEBUG - 2019-11-02 09:37:38 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:37:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:37:38 --> Model Class Initialized
ERROR - 2019-11-02 09:37:38 --> Could not find the language line "Sorting"
DEBUG - 2019-11-02 09:37:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-11-02 09:37:38 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:38 --> Total execution time: 0.5207
INFO - 2019-11-02 09:37:44 --> Config Class Initialized
INFO - 2019-11-02 09:37:44 --> Hooks Class Initialized
DEBUG - 2019-11-02 09:37:44 --> UTF-8 Support Enabled
INFO - 2019-11-02 09:37:44 --> Utf8 Class Initialized
INFO - 2019-11-02 09:37:44 --> URI Class Initialized
INFO - 2019-11-02 09:37:44 --> Router Class Initialized
INFO - 2019-11-02 09:37:44 --> Output Class Initialized
INFO - 2019-11-02 09:37:44 --> Security Class Initialized
DEBUG - 2019-11-02 09:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 09:37:44 --> CSRF cookie sent
INFO - 2019-11-02 09:37:44 --> Input Class Initialized
INFO - 2019-11-02 09:37:44 --> Language Class Initialized
INFO - 2019-11-02 09:37:44 --> Language Class Initialized
INFO - 2019-11-02 09:37:44 --> Config Class Initialized
INFO - 2019-11-02 09:37:44 --> Loader Class Initialized
INFO - 2019-11-02 09:37:44 --> Helper loaded: url_helper
INFO - 2019-11-02 09:37:44 --> Helper loaded: common_helper
INFO - 2019-11-02 09:37:44 --> Helper loaded: language_helper
INFO - 2019-11-02 09:37:44 --> Helper loaded: cookie_helper
INFO - 2019-11-02 09:37:44 --> Helper loaded: email_helper
INFO - 2019-11-02 09:37:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 09:37:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 09:37:44 --> Parser Class Initialized
INFO - 2019-11-02 09:37:44 --> User Agent Class Initialized
INFO - 2019-11-02 09:37:44 --> Model Class Initialized
INFO - 2019-11-02 09:37:44 --> Database Driver Class Initialized
INFO - 2019-11-02 09:37:44 --> Model Class Initialized
DEBUG - 2019-11-02 09:37:44 --> Template Class Initialized
INFO - 2019-11-02 09:37:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 09:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 09:37:44 --> Pagination Class Initialized
DEBUG - 2019-11-02 09:37:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 09:37:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 09:37:44 --> Encryption Class Initialized
INFO - 2019-11-02 09:37:44 --> Controller Class Initialized
DEBUG - 2019-11-02 09:37:44 --> category MX_Controller Initialized
DEBUG - 2019-11-02 09:37:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 09:37:44 --> Model Class Initialized
ERROR - 2019-11-02 09:37:44 --> Could not find the language line "Sorting"
DEBUG - 2019-11-02 09:37:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-11-02 09:37:44 --> Final output sent to browser
DEBUG - 2019-11-02 09:37:44 --> Total execution time: 0.6910
INFO - 2019-11-02 13:56:13 --> Config Class Initialized
INFO - 2019-11-02 13:56:13 --> Hooks Class Initialized
DEBUG - 2019-11-02 13:56:13 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:56:13 --> Utf8 Class Initialized
INFO - 2019-11-02 13:56:13 --> URI Class Initialized
INFO - 2019-11-02 13:56:14 --> Router Class Initialized
INFO - 2019-11-02 13:56:14 --> Output Class Initialized
INFO - 2019-11-02 13:56:14 --> Security Class Initialized
DEBUG - 2019-11-02 13:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 13:56:14 --> CSRF cookie sent
INFO - 2019-11-02 13:56:14 --> Input Class Initialized
INFO - 2019-11-02 13:56:14 --> Language Class Initialized
INFO - 2019-11-02 13:56:14 --> Language Class Initialized
INFO - 2019-11-02 13:56:14 --> Config Class Initialized
INFO - 2019-11-02 13:56:14 --> Loader Class Initialized
INFO - 2019-11-02 13:56:14 --> Helper loaded: url_helper
INFO - 2019-11-02 13:56:14 --> Helper loaded: common_helper
INFO - 2019-11-02 13:56:14 --> Helper loaded: language_helper
INFO - 2019-11-02 13:56:14 --> Helper loaded: cookie_helper
INFO - 2019-11-02 13:56:14 --> Helper loaded: email_helper
INFO - 2019-11-02 13:56:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:56:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:56:14 --> Parser Class Initialized
INFO - 2019-11-02 13:56:14 --> User Agent Class Initialized
INFO - 2019-11-02 13:56:14 --> Model Class Initialized
INFO - 2019-11-02 13:56:14 --> Database Driver Class Initialized
INFO - 2019-11-02 13:56:14 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:14 --> Template Class Initialized
INFO - 2019-11-02 13:56:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:56:15 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:56:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:56:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:56:15 --> Encryption Class Initialized
INFO - 2019-11-02 13:56:15 --> Controller Class Initialized
DEBUG - 2019-11-02 13:56:15 --> auth MX_Controller Initialized
DEBUG - 2019-11-02 13:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-02 13:56:15 --> Model Class Initialized
INFO - 2019-11-02 13:56:15 --> Config Class Initialized
INFO - 2019-11-02 13:56:15 --> Hooks Class Initialized
DEBUG - 2019-11-02 13:56:15 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:56:15 --> Utf8 Class Initialized
INFO - 2019-11-02 13:56:15 --> URI Class Initialized
INFO - 2019-11-02 13:56:15 --> Router Class Initialized
INFO - 2019-11-02 13:56:15 --> Output Class Initialized
INFO - 2019-11-02 13:56:15 --> Security Class Initialized
DEBUG - 2019-11-02 13:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 13:56:15 --> CSRF cookie sent
INFO - 2019-11-02 13:56:15 --> Input Class Initialized
INFO - 2019-11-02 13:56:15 --> Language Class Initialized
INFO - 2019-11-02 13:56:15 --> Language Class Initialized
INFO - 2019-11-02 13:56:15 --> Config Class Initialized
INFO - 2019-11-02 13:56:15 --> Loader Class Initialized
INFO - 2019-11-02 13:56:15 --> Helper loaded: url_helper
INFO - 2019-11-02 13:56:15 --> Helper loaded: common_helper
INFO - 2019-11-02 13:56:15 --> Helper loaded: language_helper
INFO - 2019-11-02 13:56:15 --> Helper loaded: cookie_helper
INFO - 2019-11-02 13:56:15 --> Helper loaded: email_helper
INFO - 2019-11-02 13:56:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:56:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:56:15 --> Parser Class Initialized
INFO - 2019-11-02 13:56:15 --> User Agent Class Initialized
INFO - 2019-11-02 13:56:15 --> Model Class Initialized
INFO - 2019-11-02 13:56:15 --> Database Driver Class Initialized
INFO - 2019-11-02 13:56:15 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:15 --> Template Class Initialized
INFO - 2019-11-02 13:56:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:56:15 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:56:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:56:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:56:15 --> Encryption Class Initialized
INFO - 2019-11-02 13:56:15 --> Controller Class Initialized
DEBUG - 2019-11-02 13:56:15 --> statistics MX_Controller Initialized
DEBUG - 2019-11-02 13:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-02 13:56:15 --> Model Class Initialized
ERROR - 2019-11-02 13:56:15 --> Could not find the language line "Pending"
ERROR - 2019-11-02 13:56:15 --> Could not find the language line "Pending"
INFO - 2019-11-02 13:56:15 --> Helper loaded: inflector_helper
ERROR - 2019-11-02 13:56:15 --> Could not find the language line "total_orders"
ERROR - 2019-11-02 13:56:15 --> Could not find the language line "total_orders"
ERROR - 2019-11-02 13:56:15 --> Could not find the language line "Pending"
DEBUG - 2019-11-02 13:56:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-02 13:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 13:56:16 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 13:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 13:56:16 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 13:56:16 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 13:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 13:56:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 13:56:16 --> Final output sent to browser
DEBUG - 2019-11-02 13:56:16 --> Total execution time: 1.0736
INFO - 2019-11-02 13:56:26 --> Config Class Initialized
INFO - 2019-11-02 13:56:26 --> Hooks Class Initialized
DEBUG - 2019-11-02 13:56:26 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:56:26 --> Utf8 Class Initialized
INFO - 2019-11-02 13:56:26 --> URI Class Initialized
INFO - 2019-11-02 13:56:26 --> Router Class Initialized
INFO - 2019-11-02 13:56:26 --> Output Class Initialized
INFO - 2019-11-02 13:56:26 --> Security Class Initialized
DEBUG - 2019-11-02 13:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 13:56:26 --> CSRF cookie sent
INFO - 2019-11-02 13:56:26 --> Input Class Initialized
INFO - 2019-11-02 13:56:26 --> Language Class Initialized
INFO - 2019-11-02 13:56:26 --> Language Class Initialized
INFO - 2019-11-02 13:56:26 --> Config Class Initialized
INFO - 2019-11-02 13:56:26 --> Loader Class Initialized
INFO - 2019-11-02 13:56:26 --> Helper loaded: url_helper
INFO - 2019-11-02 13:56:26 --> Helper loaded: common_helper
INFO - 2019-11-02 13:56:26 --> Helper loaded: language_helper
INFO - 2019-11-02 13:56:26 --> Helper loaded: cookie_helper
INFO - 2019-11-02 13:56:26 --> Helper loaded: email_helper
INFO - 2019-11-02 13:56:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:56:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:56:26 --> Parser Class Initialized
INFO - 2019-11-02 13:56:26 --> User Agent Class Initialized
INFO - 2019-11-02 13:56:26 --> Model Class Initialized
INFO - 2019-11-02 13:56:26 --> Database Driver Class Initialized
INFO - 2019-11-02 13:56:26 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:26 --> Template Class Initialized
INFO - 2019-11-02 13:56:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:56:26 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:56:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:56:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:56:26 --> Encryption Class Initialized
INFO - 2019-11-02 13:56:26 --> Controller Class Initialized
DEBUG - 2019-11-02 13:56:26 --> setting MX_Controller Initialized
DEBUG - 2019-11-02 13:56:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-02 13:56:26 --> Model Class Initialized
INFO - 2019-11-02 13:56:26 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 13:56:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-02 13:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-02 13:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-02 13:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 13:56:27 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 13:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 13:56:27 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 13:56:27 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 13:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 13:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 13:56:27 --> Final output sent to browser
DEBUG - 2019-11-02 13:56:27 --> Total execution time: 0.8055
INFO - 2019-11-02 13:56:28 --> Config Class Initialized
INFO - 2019-11-02 13:56:28 --> Hooks Class Initialized
DEBUG - 2019-11-02 13:56:28 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:56:29 --> Utf8 Class Initialized
INFO - 2019-11-02 13:56:29 --> URI Class Initialized
INFO - 2019-11-02 13:56:29 --> Router Class Initialized
INFO - 2019-11-02 13:56:29 --> Output Class Initialized
INFO - 2019-11-02 13:56:29 --> Security Class Initialized
DEBUG - 2019-11-02 13:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 13:56:29 --> CSRF cookie sent
INFO - 2019-11-02 13:56:29 --> Input Class Initialized
INFO - 2019-11-02 13:56:29 --> Language Class Initialized
INFO - 2019-11-02 13:56:29 --> Language Class Initialized
INFO - 2019-11-02 13:56:29 --> Config Class Initialized
INFO - 2019-11-02 13:56:29 --> Loader Class Initialized
INFO - 2019-11-02 13:56:29 --> Helper loaded: url_helper
INFO - 2019-11-02 13:56:29 --> Helper loaded: common_helper
INFO - 2019-11-02 13:56:29 --> Helper loaded: language_helper
INFO - 2019-11-02 13:56:29 --> Helper loaded: cookie_helper
INFO - 2019-11-02 13:56:29 --> Helper loaded: email_helper
INFO - 2019-11-02 13:56:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:56:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:56:29 --> Parser Class Initialized
INFO - 2019-11-02 13:56:29 --> User Agent Class Initialized
INFO - 2019-11-02 13:56:29 --> Model Class Initialized
INFO - 2019-11-02 13:56:29 --> Database Driver Class Initialized
INFO - 2019-11-02 13:56:29 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:29 --> Template Class Initialized
INFO - 2019-11-02 13:56:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:56:29 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:56:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:56:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:56:29 --> Encryption Class Initialized
INFO - 2019-11-02 13:56:29 --> Controller Class Initialized
DEBUG - 2019-11-02 13:56:29 --> setting MX_Controller Initialized
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-02 13:56:29 --> Model Class Initialized
INFO - 2019-11-02 13:56:29 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-02 13:56:29 --> Could not find the language line "Default_Homepage"
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/default_setting.php
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 13:56:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 13:56:29 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 13:56:29 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 13:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 13:56:29 --> Final output sent to browser
DEBUG - 2019-11-02 13:56:29 --> Total execution time: 0.7396
INFO - 2019-11-02 13:56:36 --> Config Class Initialized
INFO - 2019-11-02 13:56:36 --> Hooks Class Initialized
DEBUG - 2019-11-02 13:56:36 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:56:36 --> Utf8 Class Initialized
INFO - 2019-11-02 13:56:36 --> URI Class Initialized
INFO - 2019-11-02 13:56:36 --> Router Class Initialized
INFO - 2019-11-02 13:56:36 --> Output Class Initialized
INFO - 2019-11-02 13:56:36 --> Security Class Initialized
DEBUG - 2019-11-02 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 13:56:36 --> CSRF cookie sent
INFO - 2019-11-02 13:56:36 --> CSRF token verified
INFO - 2019-11-02 13:56:36 --> Input Class Initialized
INFO - 2019-11-02 13:56:36 --> Language Class Initialized
INFO - 2019-11-02 13:56:36 --> Language Class Initialized
INFO - 2019-11-02 13:56:36 --> Config Class Initialized
INFO - 2019-11-02 13:56:36 --> Loader Class Initialized
INFO - 2019-11-02 13:56:36 --> Helper loaded: url_helper
INFO - 2019-11-02 13:56:36 --> Helper loaded: common_helper
INFO - 2019-11-02 13:56:36 --> Helper loaded: language_helper
INFO - 2019-11-02 13:56:36 --> Helper loaded: cookie_helper
INFO - 2019-11-02 13:56:36 --> Helper loaded: email_helper
INFO - 2019-11-02 13:56:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:56:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:56:36 --> Parser Class Initialized
INFO - 2019-11-02 13:56:36 --> User Agent Class Initialized
INFO - 2019-11-02 13:56:36 --> Model Class Initialized
INFO - 2019-11-02 13:56:36 --> Database Driver Class Initialized
INFO - 2019-11-02 13:56:36 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:36 --> Template Class Initialized
INFO - 2019-11-02 13:56:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:56:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:56:36 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:56:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:56:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:56:36 --> Encryption Class Initialized
INFO - 2019-11-02 13:56:36 --> Controller Class Initialized
DEBUG - 2019-11-02 13:56:36 --> setting MX_Controller Initialized
DEBUG - 2019-11-02 13:56:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-02 13:56:36 --> Model Class Initialized
INFO - 2019-11-02 13:56:41 --> Config Class Initialized
INFO - 2019-11-02 13:56:41 --> Hooks Class Initialized
DEBUG - 2019-11-02 13:56:41 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:56:41 --> Utf8 Class Initialized
INFO - 2019-11-02 13:56:41 --> URI Class Initialized
INFO - 2019-11-02 13:56:41 --> Router Class Initialized
INFO - 2019-11-02 13:56:41 --> Output Class Initialized
INFO - 2019-11-02 13:56:41 --> Security Class Initialized
DEBUG - 2019-11-02 13:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 13:56:41 --> CSRF cookie sent
INFO - 2019-11-02 13:56:41 --> Input Class Initialized
INFO - 2019-11-02 13:56:41 --> Language Class Initialized
INFO - 2019-11-02 13:56:41 --> Language Class Initialized
INFO - 2019-11-02 13:56:41 --> Config Class Initialized
INFO - 2019-11-02 13:56:41 --> Loader Class Initialized
INFO - 2019-11-02 13:56:41 --> Helper loaded: url_helper
INFO - 2019-11-02 13:56:41 --> Helper loaded: common_helper
INFO - 2019-11-02 13:56:41 --> Helper loaded: language_helper
INFO - 2019-11-02 13:56:41 --> Helper loaded: cookie_helper
INFO - 2019-11-02 13:56:41 --> Helper loaded: email_helper
INFO - 2019-11-02 13:56:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:56:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:56:41 --> Parser Class Initialized
INFO - 2019-11-02 13:56:41 --> User Agent Class Initialized
INFO - 2019-11-02 13:56:41 --> Model Class Initialized
INFO - 2019-11-02 13:56:41 --> Database Driver Class Initialized
INFO - 2019-11-02 13:56:41 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:41 --> Template Class Initialized
INFO - 2019-11-02 13:56:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:56:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:56:42 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:56:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:56:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:56:42 --> Encryption Class Initialized
INFO - 2019-11-02 13:56:42 --> Controller Class Initialized
DEBUG - 2019-11-02 13:56:42 --> setting MX_Controller Initialized
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-02 13:56:42 --> Model Class Initialized
INFO - 2019-11-02 13:56:42 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-02 13:56:42 --> Could not find the language line "Default_Homepage"
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/default_setting.php
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 13:56:42 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 13:56:42 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 13:56:42 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 13:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 13:56:42 --> Final output sent to browser
DEBUG - 2019-11-02 13:56:42 --> Total execution time: 0.8293
INFO - 2019-11-02 13:56:51 --> Config Class Initialized
INFO - 2019-11-02 13:56:51 --> Hooks Class Initialized
DEBUG - 2019-11-02 13:56:51 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:56:51 --> Utf8 Class Initialized
INFO - 2019-11-02 13:56:51 --> URI Class Initialized
DEBUG - 2019-11-02 13:56:51 --> No URI present. Default controller set.
INFO - 2019-11-02 13:56:51 --> Router Class Initialized
INFO - 2019-11-02 13:56:51 --> Output Class Initialized
INFO - 2019-11-02 13:56:51 --> Security Class Initialized
DEBUG - 2019-11-02 13:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 13:56:51 --> CSRF cookie sent
INFO - 2019-11-02 13:56:51 --> Input Class Initialized
INFO - 2019-11-02 13:56:51 --> Language Class Initialized
INFO - 2019-11-02 13:56:51 --> Language Class Initialized
INFO - 2019-11-02 13:56:51 --> Config Class Initialized
INFO - 2019-11-02 13:56:51 --> Loader Class Initialized
INFO - 2019-11-02 13:56:51 --> Helper loaded: url_helper
INFO - 2019-11-02 13:56:51 --> Helper loaded: common_helper
INFO - 2019-11-02 13:56:51 --> Helper loaded: language_helper
INFO - 2019-11-02 13:56:51 --> Helper loaded: cookie_helper
INFO - 2019-11-02 13:56:51 --> Helper loaded: email_helper
INFO - 2019-11-02 13:56:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:56:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:56:52 --> Parser Class Initialized
INFO - 2019-11-02 13:56:52 --> User Agent Class Initialized
INFO - 2019-11-02 13:56:52 --> Model Class Initialized
INFO - 2019-11-02 13:56:52 --> Database Driver Class Initialized
INFO - 2019-11-02 13:56:52 --> Model Class Initialized
DEBUG - 2019-11-02 13:56:52 --> Template Class Initialized
INFO - 2019-11-02 13:56:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:56:52 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:56:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:56:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:56:52 --> Encryption Class Initialized
DEBUG - 2019-11-02 13:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-11-02 13:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/language/english/regular_lang.php
INFO - 2019-11-02 13:56:52 --> Controller Class Initialized
DEBUG - 2019-11-02 13:56:52 --> regular MX_Controller Initialized
DEBUG - 2019-11-02 13:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-11-02 13:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/models/regular_model.php
INFO - 2019-11-02 13:56:52 --> Model Class Initialized
INFO - 2019-11-02 13:56:52 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 13:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/header.php
DEBUG - 2019-11-02 13:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/footer.php
DEBUG - 2019-11-02 13:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/index.php
DEBUG - 2019-11-02 13:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-02 13:56:52 --> Final output sent to browser
DEBUG - 2019-11-02 13:56:52 --> Total execution time: 0.9682
INFO - 2019-11-02 13:57:12 --> Config Class Initialized
INFO - 2019-11-02 13:57:12 --> Hooks Class Initialized
DEBUG - 2019-11-02 13:57:12 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:57:12 --> Utf8 Class Initialized
INFO - 2019-11-02 13:57:12 --> URI Class Initialized
INFO - 2019-11-02 13:57:12 --> Router Class Initialized
INFO - 2019-11-02 13:57:12 --> Output Class Initialized
INFO - 2019-11-02 13:57:12 --> Security Class Initialized
DEBUG - 2019-11-02 13:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 13:57:12 --> CSRF cookie sent
INFO - 2019-11-02 13:57:12 --> CSRF token verified
INFO - 2019-11-02 13:57:12 --> Input Class Initialized
INFO - 2019-11-02 13:57:12 --> Language Class Initialized
INFO - 2019-11-02 13:57:12 --> Language Class Initialized
INFO - 2019-11-02 13:57:12 --> Config Class Initialized
INFO - 2019-11-02 13:57:12 --> Loader Class Initialized
INFO - 2019-11-02 13:57:12 --> Helper loaded: url_helper
INFO - 2019-11-02 13:57:12 --> Helper loaded: common_helper
INFO - 2019-11-02 13:57:12 --> Helper loaded: language_helper
INFO - 2019-11-02 13:57:12 --> Helper loaded: cookie_helper
INFO - 2019-11-02 13:57:12 --> Helper loaded: email_helper
INFO - 2019-11-02 13:57:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:57:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:57:12 --> Parser Class Initialized
INFO - 2019-11-02 13:57:12 --> User Agent Class Initialized
INFO - 2019-11-02 13:57:12 --> Model Class Initialized
INFO - 2019-11-02 13:57:12 --> Database Driver Class Initialized
INFO - 2019-11-02 13:57:12 --> Model Class Initialized
DEBUG - 2019-11-02 13:57:12 --> Template Class Initialized
INFO - 2019-11-02 13:57:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:57:12 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:57:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:57:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:57:12 --> Encryption Class Initialized
INFO - 2019-11-02 13:57:12 --> Controller Class Initialized
DEBUG - 2019-11-02 13:57:12 --> setting MX_Controller Initialized
DEBUG - 2019-11-02 13:57:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-02 13:57:12 --> Model Class Initialized
INFO - 2019-11-02 13:57:17 --> Config Class Initialized
INFO - 2019-11-02 13:57:17 --> Hooks Class Initialized
DEBUG - 2019-11-02 13:57:17 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:57:17 --> Utf8 Class Initialized
INFO - 2019-11-02 13:57:17 --> URI Class Initialized
INFO - 2019-11-02 13:57:18 --> Router Class Initialized
INFO - 2019-11-02 13:57:18 --> Output Class Initialized
INFO - 2019-11-02 13:57:18 --> Security Class Initialized
DEBUG - 2019-11-02 13:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 13:57:18 --> CSRF cookie sent
INFO - 2019-11-02 13:57:18 --> Input Class Initialized
INFO - 2019-11-02 13:57:18 --> Language Class Initialized
INFO - 2019-11-02 13:57:18 --> Language Class Initialized
INFO - 2019-11-02 13:57:18 --> Config Class Initialized
INFO - 2019-11-02 13:57:18 --> Loader Class Initialized
INFO - 2019-11-02 13:57:18 --> Helper loaded: url_helper
INFO - 2019-11-02 13:57:18 --> Helper loaded: common_helper
INFO - 2019-11-02 13:57:18 --> Helper loaded: language_helper
INFO - 2019-11-02 13:57:18 --> Helper loaded: cookie_helper
INFO - 2019-11-02 13:57:18 --> Helper loaded: email_helper
INFO - 2019-11-02 13:57:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:57:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:57:18 --> Parser Class Initialized
INFO - 2019-11-02 13:57:18 --> User Agent Class Initialized
INFO - 2019-11-02 13:57:18 --> Model Class Initialized
INFO - 2019-11-02 13:57:18 --> Database Driver Class Initialized
INFO - 2019-11-02 13:57:18 --> Model Class Initialized
DEBUG - 2019-11-02 13:57:18 --> Template Class Initialized
INFO - 2019-11-02 13:57:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:57:18 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:57:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:57:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:57:18 --> Encryption Class Initialized
INFO - 2019-11-02 13:57:18 --> Controller Class Initialized
DEBUG - 2019-11-02 13:57:18 --> setting MX_Controller Initialized
DEBUG - 2019-11-02 13:57:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-02 13:57:18 --> Config Class Initialized
INFO - 2019-11-02 13:57:18 --> Hooks Class Initialized
INFO - 2019-11-02 13:57:18 --> Model Class Initialized
INFO - 2019-11-02 13:57:18 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 13:57:18 --> UTF-8 Support Enabled
INFO - 2019-11-02 13:57:18 --> Utf8 Class Initialized
DEBUG - 2019-11-02 13:57:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
INFO - 2019-11-02 13:57:19 --> URI Class Initialized
ERROR - 2019-11-02 13:57:19 --> Could not find the language line "Default_Homepage"
DEBUG - 2019-11-02 13:57:19 --> No URI present. Default controller set.
INFO - 2019-11-02 13:57:19 --> Router Class Initialized
INFO - 2019-11-02 13:57:19 --> Output Class Initialized
DEBUG - 2019-11-02 13:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/default_setting.php
DEBUG - 2019-11-02 13:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
INFO - 2019-11-02 13:57:19 --> Security Class Initialized
DEBUG - 2019-11-02 13:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 13:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
INFO - 2019-11-02 13:57:19 --> CSRF cookie sent
DEBUG - 2019-11-02 13:57:19 --> blocks MX_Controller Initialized
INFO - 2019-11-02 13:57:19 --> Input Class Initialized
DEBUG - 2019-11-02 13:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 13:57:19 --> Model Class Initialized
INFO - 2019-11-02 13:57:19 --> Language Class Initialized
DEBUG - 2019-11-02 13:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 13:57:19 --> Model Class Initialized
INFO - 2019-11-02 13:57:19 --> Language Class Initialized
INFO - 2019-11-02 13:57:19 --> Config Class Initialized
DEBUG - 2019-11-02 13:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
INFO - 2019-11-02 13:57:19 --> Loader Class Initialized
INFO - 2019-11-02 13:57:19 --> Helper loaded: url_helper
INFO - 2019-11-02 13:57:19 --> Helper loaded: common_helper
DEBUG - 2019-11-02 13:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 13:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 13:57:19 --> Helper loaded: language_helper
INFO - 2019-11-02 13:57:19 --> Final output sent to browser
INFO - 2019-11-02 13:57:19 --> Helper loaded: cookie_helper
DEBUG - 2019-11-02 13:57:19 --> Total execution time: 1.6431
INFO - 2019-11-02 13:57:19 --> Helper loaded: email_helper
INFO - 2019-11-02 13:57:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 13:57:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 13:57:19 --> Parser Class Initialized
INFO - 2019-11-02 13:57:19 --> User Agent Class Initialized
INFO - 2019-11-02 13:57:19 --> Model Class Initialized
INFO - 2019-11-02 13:57:19 --> Database Driver Class Initialized
INFO - 2019-11-02 13:57:19 --> Model Class Initialized
DEBUG - 2019-11-02 13:57:19 --> Template Class Initialized
INFO - 2019-11-02 13:57:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 13:57:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 13:57:19 --> Pagination Class Initialized
DEBUG - 2019-11-02 13:57:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 13:57:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 13:57:19 --> Encryption Class Initialized
DEBUG - 2019-11-02 13:57:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-02 13:57:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-02 13:57:20 --> Controller Class Initialized
DEBUG - 2019-11-02 13:57:20 --> pergo MX_Controller Initialized
DEBUG - 2019-11-02 13:57:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-02 13:57:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-02 13:57:20 --> Model Class Initialized
INFO - 2019-11-02 13:57:20 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 13:57:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-02 13:57:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-02 13:57:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-02 13:57:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-02 13:57:20 --> Final output sent to browser
DEBUG - 2019-11-02 13:57:20 --> Total execution time: 2.0275
INFO - 2019-11-02 14:11:35 --> Config Class Initialized
INFO - 2019-11-02 14:11:35 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:11:35 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:11:35 --> Utf8 Class Initialized
INFO - 2019-11-02 14:11:35 --> URI Class Initialized
INFO - 2019-11-02 14:11:35 --> Router Class Initialized
INFO - 2019-11-02 14:11:35 --> Output Class Initialized
INFO - 2019-11-02 14:11:35 --> Security Class Initialized
DEBUG - 2019-11-02 14:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:11:35 --> CSRF cookie sent
INFO - 2019-11-02 14:11:35 --> Input Class Initialized
INFO - 2019-11-02 14:11:35 --> Language Class Initialized
INFO - 2019-11-02 14:11:35 --> Language Class Initialized
INFO - 2019-11-02 14:11:35 --> Config Class Initialized
INFO - 2019-11-02 14:11:35 --> Loader Class Initialized
INFO - 2019-11-02 14:11:35 --> Helper loaded: url_helper
INFO - 2019-11-02 14:11:35 --> Helper loaded: common_helper
INFO - 2019-11-02 14:11:35 --> Helper loaded: language_helper
INFO - 2019-11-02 14:11:35 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:11:35 --> Helper loaded: email_helper
INFO - 2019-11-02 14:11:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:11:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:11:36 --> Parser Class Initialized
INFO - 2019-11-02 14:11:36 --> User Agent Class Initialized
INFO - 2019-11-02 14:11:36 --> Model Class Initialized
INFO - 2019-11-02 14:11:36 --> Database Driver Class Initialized
INFO - 2019-11-02 14:11:36 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:36 --> Template Class Initialized
INFO - 2019-11-02 14:11:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:11:36 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:11:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:11:36 --> Encryption Class Initialized
INFO - 2019-11-02 14:11:36 --> Controller Class Initialized
DEBUG - 2019-11-02 14:11:36 --> auth MX_Controller Initialized
DEBUG - 2019-11-02 14:11:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-02 14:11:36 --> Model Class Initialized
INFO - 2019-11-02 14:11:36 --> Config Class Initialized
INFO - 2019-11-02 14:11:36 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:11:36 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:11:36 --> Utf8 Class Initialized
INFO - 2019-11-02 14:11:36 --> URI Class Initialized
INFO - 2019-11-02 14:11:36 --> Router Class Initialized
INFO - 2019-11-02 14:11:36 --> Output Class Initialized
INFO - 2019-11-02 14:11:36 --> Security Class Initialized
DEBUG - 2019-11-02 14:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:11:36 --> CSRF cookie sent
INFO - 2019-11-02 14:11:36 --> Input Class Initialized
INFO - 2019-11-02 14:11:36 --> Language Class Initialized
INFO - 2019-11-02 14:11:36 --> Language Class Initialized
INFO - 2019-11-02 14:11:36 --> Config Class Initialized
INFO - 2019-11-02 14:11:36 --> Loader Class Initialized
INFO - 2019-11-02 14:11:36 --> Helper loaded: url_helper
INFO - 2019-11-02 14:11:36 --> Helper loaded: common_helper
INFO - 2019-11-02 14:11:36 --> Helper loaded: language_helper
INFO - 2019-11-02 14:11:36 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:11:36 --> Helper loaded: email_helper
INFO - 2019-11-02 14:11:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:11:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:11:36 --> Parser Class Initialized
INFO - 2019-11-02 14:11:36 --> User Agent Class Initialized
INFO - 2019-11-02 14:11:36 --> Model Class Initialized
INFO - 2019-11-02 14:11:36 --> Database Driver Class Initialized
INFO - 2019-11-02 14:11:36 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:37 --> Template Class Initialized
INFO - 2019-11-02 14:11:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:11:37 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:11:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:11:37 --> Encryption Class Initialized
INFO - 2019-11-02 14:11:37 --> Controller Class Initialized
DEBUG - 2019-11-02 14:11:37 --> statistics MX_Controller Initialized
DEBUG - 2019-11-02 14:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-02 14:11:37 --> Model Class Initialized
ERROR - 2019-11-02 14:11:37 --> Could not find the language line "Pending"
ERROR - 2019-11-02 14:11:37 --> Could not find the language line "Pending"
INFO - 2019-11-02 14:11:37 --> Helper loaded: inflector_helper
ERROR - 2019-11-02 14:11:37 --> Could not find the language line "total_orders"
ERROR - 2019-11-02 14:11:37 --> Could not find the language line "total_orders"
ERROR - 2019-11-02 14:11:37 --> Could not find the language line "Pending"
DEBUG - 2019-11-02 14:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-02 14:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 14:11:37 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 14:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 14:11:37 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 14:11:37 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 14:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 14:11:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 14:11:37 --> Final output sent to browser
DEBUG - 2019-11-02 14:11:37 --> Total execution time: 1.0648
INFO - 2019-11-02 14:11:45 --> Config Class Initialized
INFO - 2019-11-02 14:11:45 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:11:45 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:11:45 --> Utf8 Class Initialized
INFO - 2019-11-02 14:11:45 --> URI Class Initialized
INFO - 2019-11-02 14:11:46 --> Router Class Initialized
INFO - 2019-11-02 14:11:46 --> Output Class Initialized
INFO - 2019-11-02 14:11:46 --> Security Class Initialized
DEBUG - 2019-11-02 14:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:11:46 --> CSRF cookie sent
INFO - 2019-11-02 14:11:46 --> Input Class Initialized
INFO - 2019-11-02 14:11:46 --> Language Class Initialized
INFO - 2019-11-02 14:11:46 --> Language Class Initialized
INFO - 2019-11-02 14:11:46 --> Config Class Initialized
INFO - 2019-11-02 14:11:46 --> Loader Class Initialized
INFO - 2019-11-02 14:11:46 --> Helper loaded: url_helper
INFO - 2019-11-02 14:11:46 --> Helper loaded: common_helper
INFO - 2019-11-02 14:11:46 --> Helper loaded: language_helper
INFO - 2019-11-02 14:11:46 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:11:46 --> Helper loaded: email_helper
INFO - 2019-11-02 14:11:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:11:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:11:46 --> Parser Class Initialized
INFO - 2019-11-02 14:11:46 --> User Agent Class Initialized
INFO - 2019-11-02 14:11:46 --> Model Class Initialized
INFO - 2019-11-02 14:11:46 --> Database Driver Class Initialized
INFO - 2019-11-02 14:11:46 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:46 --> Template Class Initialized
INFO - 2019-11-02 14:11:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:11:46 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:11:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:11:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:11:46 --> Encryption Class Initialized
INFO - 2019-11-02 14:11:46 --> Controller Class Initialized
DEBUG - 2019-11-02 14:11:46 --> setting MX_Controller Initialized
DEBUG - 2019-11-02 14:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-02 14:11:46 --> Model Class Initialized
INFO - 2019-11-02 14:11:46 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 14:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-02 14:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-02 14:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-02 14:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 14:11:46 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 14:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 14:11:46 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 14:11:46 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 14:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 14:11:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 14:11:47 --> Final output sent to browser
DEBUG - 2019-11-02 14:11:47 --> Total execution time: 1.1240
INFO - 2019-11-02 14:11:50 --> Config Class Initialized
INFO - 2019-11-02 14:11:50 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:11:50 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:11:50 --> Utf8 Class Initialized
INFO - 2019-11-02 14:11:50 --> URI Class Initialized
INFO - 2019-11-02 14:11:50 --> Router Class Initialized
INFO - 2019-11-02 14:11:50 --> Output Class Initialized
INFO - 2019-11-02 14:11:50 --> Security Class Initialized
DEBUG - 2019-11-02 14:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:11:50 --> CSRF cookie sent
INFO - 2019-11-02 14:11:50 --> Input Class Initialized
INFO - 2019-11-02 14:11:50 --> Language Class Initialized
INFO - 2019-11-02 14:11:50 --> Language Class Initialized
INFO - 2019-11-02 14:11:50 --> Config Class Initialized
INFO - 2019-11-02 14:11:50 --> Loader Class Initialized
INFO - 2019-11-02 14:11:50 --> Helper loaded: url_helper
INFO - 2019-11-02 14:11:50 --> Helper loaded: common_helper
INFO - 2019-11-02 14:11:50 --> Helper loaded: language_helper
INFO - 2019-11-02 14:11:50 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:11:50 --> Helper loaded: email_helper
INFO - 2019-11-02 14:11:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:11:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:11:50 --> Parser Class Initialized
INFO - 2019-11-02 14:11:50 --> User Agent Class Initialized
INFO - 2019-11-02 14:11:50 --> Model Class Initialized
INFO - 2019-11-02 14:11:50 --> Database Driver Class Initialized
INFO - 2019-11-02 14:11:50 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:50 --> Template Class Initialized
INFO - 2019-11-02 14:11:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:11:50 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:11:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:11:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:11:50 --> Encryption Class Initialized
INFO - 2019-11-02 14:11:50 --> Controller Class Initialized
DEBUG - 2019-11-02 14:11:50 --> setting MX_Controller Initialized
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-02 14:11:50 --> Model Class Initialized
INFO - 2019-11-02 14:11:50 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-02 14:11:50 --> Could not find the language line "Default_Homepage"
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/default_setting.php
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 14:11:50 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 14:11:50 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 14:11:50 --> Model Class Initialized
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 14:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 14:11:50 --> Final output sent to browser
DEBUG - 2019-11-02 14:11:50 --> Total execution time: 0.7697
INFO - 2019-11-02 14:30:18 --> Config Class Initialized
INFO - 2019-11-02 14:30:18 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:30:18 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:30:18 --> Utf8 Class Initialized
INFO - 2019-11-02 14:30:18 --> URI Class Initialized
INFO - 2019-11-02 14:30:18 --> Router Class Initialized
INFO - 2019-11-02 14:30:18 --> Output Class Initialized
INFO - 2019-11-02 14:30:18 --> Security Class Initialized
DEBUG - 2019-11-02 14:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:30:18 --> CSRF cookie sent
INFO - 2019-11-02 14:30:18 --> Input Class Initialized
INFO - 2019-11-02 14:30:18 --> Language Class Initialized
INFO - 2019-11-02 14:30:18 --> Language Class Initialized
INFO - 2019-11-02 14:30:18 --> Config Class Initialized
INFO - 2019-11-02 14:30:18 --> Loader Class Initialized
INFO - 2019-11-02 14:30:18 --> Helper loaded: url_helper
INFO - 2019-11-02 14:30:18 --> Helper loaded: common_helper
INFO - 2019-11-02 14:30:18 --> Helper loaded: language_helper
INFO - 2019-11-02 14:30:18 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:30:18 --> Helper loaded: email_helper
INFO - 2019-11-02 14:30:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:30:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:30:18 --> Parser Class Initialized
INFO - 2019-11-02 14:30:18 --> User Agent Class Initialized
INFO - 2019-11-02 14:30:19 --> Model Class Initialized
INFO - 2019-11-02 14:30:19 --> Database Driver Class Initialized
INFO - 2019-11-02 14:30:19 --> Model Class Initialized
DEBUG - 2019-11-02 14:30:19 --> Template Class Initialized
INFO - 2019-11-02 14:30:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:30:19 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:30:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:30:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:30:19 --> Encryption Class Initialized
INFO - 2019-11-02 14:30:19 --> Controller Class Initialized
DEBUG - 2019-11-02 14:30:19 --> language MX_Controller Initialized
DEBUG - 2019-11-02 14:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-02 14:30:19 --> Model Class Initialized
INFO - 2019-11-02 14:30:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 14:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-11-02 14:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 14:30:19 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 14:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 14:30:19 --> Model Class Initialized
DEBUG - 2019-11-02 14:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 14:30:19 --> Model Class Initialized
DEBUG - 2019-11-02 14:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 14:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 14:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 14:30:19 --> Final output sent to browser
DEBUG - 2019-11-02 14:30:19 --> Total execution time: 0.6993
INFO - 2019-11-02 14:30:21 --> Config Class Initialized
INFO - 2019-11-02 14:30:21 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:30:21 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:30:21 --> Utf8 Class Initialized
INFO - 2019-11-02 14:30:21 --> URI Class Initialized
INFO - 2019-11-02 14:30:21 --> Router Class Initialized
INFO - 2019-11-02 14:30:21 --> Output Class Initialized
INFO - 2019-11-02 14:30:21 --> Security Class Initialized
DEBUG - 2019-11-02 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:30:21 --> CSRF cookie sent
INFO - 2019-11-02 14:30:21 --> Input Class Initialized
INFO - 2019-11-02 14:30:21 --> Language Class Initialized
INFO - 2019-11-02 14:30:21 --> Language Class Initialized
INFO - 2019-11-02 14:30:21 --> Config Class Initialized
INFO - 2019-11-02 14:30:21 --> Loader Class Initialized
INFO - 2019-11-02 14:30:21 --> Helper loaded: url_helper
INFO - 2019-11-02 14:30:21 --> Helper loaded: common_helper
INFO - 2019-11-02 14:30:21 --> Helper loaded: language_helper
INFO - 2019-11-02 14:30:21 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:30:21 --> Helper loaded: email_helper
INFO - 2019-11-02 14:30:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:30:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:30:21 --> Parser Class Initialized
INFO - 2019-11-02 14:30:21 --> User Agent Class Initialized
INFO - 2019-11-02 14:30:21 --> Model Class Initialized
INFO - 2019-11-02 14:30:21 --> Database Driver Class Initialized
INFO - 2019-11-02 14:30:21 --> Model Class Initialized
DEBUG - 2019-11-02 14:30:21 --> Template Class Initialized
INFO - 2019-11-02 14:30:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:30:21 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:30:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:30:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:30:21 --> Encryption Class Initialized
INFO - 2019-11-02 14:30:21 --> Controller Class Initialized
DEBUG - 2019-11-02 14:30:21 --> language MX_Controller Initialized
DEBUG - 2019-11-02 14:30:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-02 14:30:21 --> Model Class Initialized
INFO - 2019-11-02 14:30:23 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 14:30:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2019-11-02 14:30:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 14:30:23 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 14:30:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 14:30:23 --> Model Class Initialized
DEBUG - 2019-11-02 14:30:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 14:30:23 --> Model Class Initialized
DEBUG - 2019-11-02 14:30:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 14:30:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 14:30:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 14:30:23 --> Final output sent to browser
DEBUG - 2019-11-02 14:30:23 --> Total execution time: 2.1094
INFO - 2019-11-02 14:31:59 --> Config Class Initialized
INFO - 2019-11-02 14:31:59 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:31:59 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:31:59 --> Utf8 Class Initialized
INFO - 2019-11-02 14:31:59 --> URI Class Initialized
INFO - 2019-11-02 14:31:59 --> Router Class Initialized
INFO - 2019-11-02 14:31:59 --> Output Class Initialized
INFO - 2019-11-02 14:31:59 --> Security Class Initialized
DEBUG - 2019-11-02 14:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:31:59 --> CSRF cookie sent
INFO - 2019-11-02 14:31:59 --> CSRF token verified
INFO - 2019-11-02 14:31:59 --> Input Class Initialized
INFO - 2019-11-02 14:31:59 --> Language Class Initialized
INFO - 2019-11-02 14:31:59 --> Language Class Initialized
INFO - 2019-11-02 14:31:59 --> Config Class Initialized
INFO - 2019-11-02 14:31:59 --> Loader Class Initialized
INFO - 2019-11-02 14:31:59 --> Helper loaded: url_helper
INFO - 2019-11-02 14:31:59 --> Helper loaded: common_helper
INFO - 2019-11-02 14:31:59 --> Helper loaded: language_helper
INFO - 2019-11-02 14:31:59 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:31:59 --> Helper loaded: email_helper
INFO - 2019-11-02 14:31:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:31:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:31:59 --> Parser Class Initialized
INFO - 2019-11-02 14:31:59 --> User Agent Class Initialized
INFO - 2019-11-02 14:31:59 --> Model Class Initialized
INFO - 2019-11-02 14:31:59 --> Database Driver Class Initialized
INFO - 2019-11-02 14:31:59 --> Model Class Initialized
DEBUG - 2019-11-02 14:31:59 --> Template Class Initialized
INFO - 2019-11-02 14:31:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:31:59 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:31:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:31:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:31:59 --> Encryption Class Initialized
INFO - 2019-11-02 14:31:59 --> Controller Class Initialized
DEBUG - 2019-11-02 14:31:59 --> language MX_Controller Initialized
DEBUG - 2019-11-02 14:31:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-02 14:31:59 --> Model Class Initialized
INFO - 2019-11-02 14:32:06 --> Config Class Initialized
INFO - 2019-11-02 14:32:06 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:32:06 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:32:06 --> Utf8 Class Initialized
INFO - 2019-11-02 14:32:06 --> URI Class Initialized
INFO - 2019-11-02 14:32:06 --> Router Class Initialized
INFO - 2019-11-02 14:32:06 --> Output Class Initialized
INFO - 2019-11-02 14:32:06 --> Security Class Initialized
DEBUG - 2019-11-02 14:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:32:06 --> CSRF cookie sent
INFO - 2019-11-02 14:32:06 --> Input Class Initialized
INFO - 2019-11-02 14:32:06 --> Language Class Initialized
INFO - 2019-11-02 14:32:06 --> Language Class Initialized
INFO - 2019-11-02 14:32:06 --> Config Class Initialized
INFO - 2019-11-02 14:32:06 --> Loader Class Initialized
INFO - 2019-11-02 14:32:06 --> Helper loaded: url_helper
INFO - 2019-11-02 14:32:06 --> Helper loaded: common_helper
INFO - 2019-11-02 14:32:06 --> Helper loaded: language_helper
INFO - 2019-11-02 14:32:06 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:32:06 --> Helper loaded: email_helper
INFO - 2019-11-02 14:32:06 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:32:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:32:06 --> Parser Class Initialized
INFO - 2019-11-02 14:32:06 --> User Agent Class Initialized
INFO - 2019-11-02 14:32:06 --> Model Class Initialized
INFO - 2019-11-02 14:32:06 --> Database Driver Class Initialized
INFO - 2019-11-02 14:32:06 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:06 --> Template Class Initialized
INFO - 2019-11-02 14:32:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:32:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:32:06 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:32:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:32:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:32:06 --> Encryption Class Initialized
INFO - 2019-11-02 14:32:06 --> Controller Class Initialized
DEBUG - 2019-11-02 14:32:06 --> language MX_Controller Initialized
DEBUG - 2019-11-02 14:32:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-02 14:32:06 --> Model Class Initialized
INFO - 2019-11-02 14:32:06 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 14:32:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-11-02 14:32:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 14:32:07 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 14:32:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 14:32:07 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 14:32:07 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 14:32:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 14:32:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 14:32:07 --> Final output sent to browser
DEBUG - 2019-11-02 14:32:07 --> Total execution time: 0.9587
INFO - 2019-11-02 14:32:11 --> Config Class Initialized
INFO - 2019-11-02 14:32:11 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:32:11 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:32:11 --> Utf8 Class Initialized
INFO - 2019-11-02 14:32:11 --> URI Class Initialized
INFO - 2019-11-02 14:32:11 --> Router Class Initialized
INFO - 2019-11-02 14:32:11 --> Output Class Initialized
INFO - 2019-11-02 14:32:11 --> Security Class Initialized
DEBUG - 2019-11-02 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:32:11 --> CSRF cookie sent
INFO - 2019-11-02 14:32:11 --> CSRF token verified
INFO - 2019-11-02 14:32:11 --> Input Class Initialized
INFO - 2019-11-02 14:32:12 --> Language Class Initialized
INFO - 2019-11-02 14:32:12 --> Language Class Initialized
INFO - 2019-11-02 14:32:12 --> Config Class Initialized
INFO - 2019-11-02 14:32:12 --> Loader Class Initialized
INFO - 2019-11-02 14:32:12 --> Helper loaded: url_helper
INFO - 2019-11-02 14:32:12 --> Helper loaded: common_helper
INFO - 2019-11-02 14:32:12 --> Helper loaded: language_helper
INFO - 2019-11-02 14:32:12 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:32:12 --> Helper loaded: email_helper
INFO - 2019-11-02 14:32:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:32:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:32:12 --> Parser Class Initialized
INFO - 2019-11-02 14:32:12 --> User Agent Class Initialized
INFO - 2019-11-02 14:32:12 --> Model Class Initialized
INFO - 2019-11-02 14:32:12 --> Database Driver Class Initialized
INFO - 2019-11-02 14:32:12 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:12 --> Template Class Initialized
INFO - 2019-11-02 14:32:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:32:12 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:32:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:32:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:32:12 --> Encryption Class Initialized
INFO - 2019-11-02 14:32:12 --> Controller Class Initialized
DEBUG - 2019-11-02 14:32:12 --> language MX_Controller Initialized
DEBUG - 2019-11-02 14:32:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-02 14:32:12 --> Model Class Initialized
INFO - 2019-11-02 14:32:13 --> Config Class Initialized
INFO - 2019-11-02 14:32:13 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:32:13 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:32:13 --> Utf8 Class Initialized
INFO - 2019-11-02 14:32:13 --> URI Class Initialized
INFO - 2019-11-02 14:32:13 --> Router Class Initialized
INFO - 2019-11-02 14:32:13 --> Output Class Initialized
INFO - 2019-11-02 14:32:13 --> Security Class Initialized
DEBUG - 2019-11-02 14:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:32:13 --> CSRF cookie sent
INFO - 2019-11-02 14:32:14 --> Input Class Initialized
INFO - 2019-11-02 14:32:14 --> Language Class Initialized
INFO - 2019-11-02 14:32:14 --> Language Class Initialized
INFO - 2019-11-02 14:32:14 --> Config Class Initialized
INFO - 2019-11-02 14:32:14 --> Loader Class Initialized
INFO - 2019-11-02 14:32:14 --> Helper loaded: url_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: common_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: language_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: email_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:32:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:32:14 --> Parser Class Initialized
INFO - 2019-11-02 14:32:14 --> User Agent Class Initialized
INFO - 2019-11-02 14:32:14 --> Model Class Initialized
INFO - 2019-11-02 14:32:14 --> Database Driver Class Initialized
INFO - 2019-11-02 14:32:14 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:14 --> Template Class Initialized
INFO - 2019-11-02 14:32:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:32:14 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:32:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:32:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:32:14 --> Encryption Class Initialized
INFO - 2019-11-02 14:32:14 --> Controller Class Initialized
DEBUG - 2019-11-02 14:32:14 --> language MX_Controller Initialized
DEBUG - 2019-11-02 14:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-02 14:32:14 --> Model Class Initialized
INFO - 2019-11-02 14:32:14 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 14:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-11-02 14:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
INFO - 2019-11-02 14:32:14 --> Config Class Initialized
DEBUG - 2019-11-02 14:32:14 --> blocks MX_Controller Initialized
INFO - 2019-11-02 14:32:14 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
DEBUG - 2019-11-02 14:32:14 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:32:14 --> Utf8 Class Initialized
INFO - 2019-11-02 14:32:14 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 14:32:14 --> URI Class Initialized
INFO - 2019-11-02 14:32:14 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:14 --> No URI present. Default controller set.
INFO - 2019-11-02 14:32:14 --> Router Class Initialized
INFO - 2019-11-02 14:32:14 --> Output Class Initialized
DEBUG - 2019-11-02 14:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
INFO - 2019-11-02 14:32:14 --> Security Class Initialized
DEBUG - 2019-11-02 14:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:32:14 --> CSRF cookie sent
INFO - 2019-11-02 14:32:14 --> Input Class Initialized
DEBUG - 2019-11-02 14:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 14:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 14:32:14 --> Language Class Initialized
INFO - 2019-11-02 14:32:14 --> Final output sent to browser
INFO - 2019-11-02 14:32:14 --> Language Class Initialized
DEBUG - 2019-11-02 14:32:14 --> Total execution time: 0.9406
INFO - 2019-11-02 14:32:14 --> Config Class Initialized
INFO - 2019-11-02 14:32:14 --> Loader Class Initialized
INFO - 2019-11-02 14:32:14 --> Helper loaded: url_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: common_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: language_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: email_helper
INFO - 2019-11-02 14:32:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:32:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:32:14 --> Parser Class Initialized
INFO - 2019-11-02 14:32:15 --> User Agent Class Initialized
INFO - 2019-11-02 14:32:15 --> Model Class Initialized
INFO - 2019-11-02 14:32:15 --> Database Driver Class Initialized
INFO - 2019-11-02 14:32:15 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:15 --> Template Class Initialized
INFO - 2019-11-02 14:32:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:32:15 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:32:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:32:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:32:15 --> Encryption Class Initialized
DEBUG - 2019-11-02 14:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-02 14:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-02 14:32:15 --> Controller Class Initialized
DEBUG - 2019-11-02 14:32:15 --> pergo MX_Controller Initialized
DEBUG - 2019-11-02 14:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-02 14:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-02 14:32:15 --> Model Class Initialized
INFO - 2019-11-02 14:32:15 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 14:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-02 14:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-02 14:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-02 14:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-02 14:32:15 --> Final output sent to browser
DEBUG - 2019-11-02 14:32:15 --> Total execution time: 1.1619
INFO - 2019-11-02 14:32:42 --> Config Class Initialized
INFO - 2019-11-02 14:32:42 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:32:42 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:32:42 --> Utf8 Class Initialized
INFO - 2019-11-02 14:32:42 --> URI Class Initialized
INFO - 2019-11-02 14:32:43 --> Router Class Initialized
INFO - 2019-11-02 14:32:43 --> Output Class Initialized
INFO - 2019-11-02 14:32:43 --> Security Class Initialized
DEBUG - 2019-11-02 14:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:32:43 --> CSRF cookie sent
INFO - 2019-11-02 14:32:43 --> CSRF token verified
INFO - 2019-11-02 14:32:43 --> Input Class Initialized
INFO - 2019-11-02 14:32:43 --> Language Class Initialized
INFO - 2019-11-02 14:32:43 --> Language Class Initialized
INFO - 2019-11-02 14:32:43 --> Config Class Initialized
INFO - 2019-11-02 14:32:43 --> Loader Class Initialized
INFO - 2019-11-02 14:32:43 --> Helper loaded: url_helper
INFO - 2019-11-02 14:32:43 --> Helper loaded: common_helper
INFO - 2019-11-02 14:32:43 --> Helper loaded: language_helper
INFO - 2019-11-02 14:32:43 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:32:43 --> Helper loaded: email_helper
INFO - 2019-11-02 14:32:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:32:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:32:43 --> Parser Class Initialized
INFO - 2019-11-02 14:32:43 --> User Agent Class Initialized
INFO - 2019-11-02 14:32:43 --> Model Class Initialized
INFO - 2019-11-02 14:32:43 --> Database Driver Class Initialized
INFO - 2019-11-02 14:32:43 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:43 --> Template Class Initialized
INFO - 2019-11-02 14:32:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:32:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:32:43 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:32:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:32:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:32:43 --> Encryption Class Initialized
INFO - 2019-11-02 14:32:43 --> Controller Class Initialized
DEBUG - 2019-11-02 14:32:43 --> language MX_Controller Initialized
DEBUG - 2019-11-02 14:32:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-02 14:32:43 --> Model Class Initialized
INFO - 2019-11-02 14:32:44 --> Config Class Initialized
INFO - 2019-11-02 14:32:44 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:32:44 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:32:44 --> Utf8 Class Initialized
INFO - 2019-11-02 14:32:44 --> URI Class Initialized
DEBUG - 2019-11-02 14:32:44 --> No URI present. Default controller set.
INFO - 2019-11-02 14:32:44 --> Router Class Initialized
INFO - 2019-11-02 14:32:44 --> Output Class Initialized
INFO - 2019-11-02 14:32:44 --> Security Class Initialized
DEBUG - 2019-11-02 14:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:32:44 --> CSRF cookie sent
INFO - 2019-11-02 14:32:44 --> Input Class Initialized
INFO - 2019-11-02 14:32:44 --> Language Class Initialized
INFO - 2019-11-02 14:32:44 --> Language Class Initialized
INFO - 2019-11-02 14:32:44 --> Config Class Initialized
INFO - 2019-11-02 14:32:44 --> Loader Class Initialized
INFO - 2019-11-02 14:32:44 --> Helper loaded: url_helper
INFO - 2019-11-02 14:32:44 --> Helper loaded: common_helper
INFO - 2019-11-02 14:32:44 --> Helper loaded: language_helper
INFO - 2019-11-02 14:32:44 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:32:44 --> Helper loaded: email_helper
INFO - 2019-11-02 14:32:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:32:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:32:44 --> Parser Class Initialized
INFO - 2019-11-02 14:32:44 --> User Agent Class Initialized
INFO - 2019-11-02 14:32:44 --> Model Class Initialized
INFO - 2019-11-02 14:32:44 --> Database Driver Class Initialized
INFO - 2019-11-02 14:32:44 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:44 --> Template Class Initialized
INFO - 2019-11-02 14:32:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:32:45 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:32:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:32:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:32:45 --> Encryption Class Initialized
DEBUG - 2019-11-02 14:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-02 14:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-02 14:32:45 --> Controller Class Initialized
DEBUG - 2019-11-02 14:32:45 --> pergo MX_Controller Initialized
DEBUG - 2019-11-02 14:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-02 14:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-02 14:32:45 --> Model Class Initialized
INFO - 2019-11-02 14:32:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 14:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-02 14:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-02 14:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-02 14:32:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-02 14:32:45 --> Final output sent to browser
DEBUG - 2019-11-02 14:32:45 --> Total execution time: 0.8776
INFO - 2019-11-02 14:32:56 --> Config Class Initialized
INFO - 2019-11-02 14:32:56 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:32:56 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:32:56 --> Utf8 Class Initialized
INFO - 2019-11-02 14:32:56 --> URI Class Initialized
INFO - 2019-11-02 14:32:56 --> Router Class Initialized
INFO - 2019-11-02 14:32:56 --> Output Class Initialized
INFO - 2019-11-02 14:32:56 --> Security Class Initialized
DEBUG - 2019-11-02 14:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:32:56 --> CSRF cookie sent
INFO - 2019-11-02 14:32:56 --> CSRF token verified
INFO - 2019-11-02 14:32:56 --> Input Class Initialized
INFO - 2019-11-02 14:32:56 --> Language Class Initialized
INFO - 2019-11-02 14:32:56 --> Language Class Initialized
INFO - 2019-11-02 14:32:56 --> Config Class Initialized
INFO - 2019-11-02 14:32:56 --> Loader Class Initialized
INFO - 2019-11-02 14:32:56 --> Helper loaded: url_helper
INFO - 2019-11-02 14:32:56 --> Helper loaded: common_helper
INFO - 2019-11-02 14:32:56 --> Helper loaded: language_helper
INFO - 2019-11-02 14:32:56 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:32:56 --> Helper loaded: email_helper
INFO - 2019-11-02 14:32:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:32:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:32:56 --> Parser Class Initialized
INFO - 2019-11-02 14:32:56 --> User Agent Class Initialized
INFO - 2019-11-02 14:32:56 --> Model Class Initialized
INFO - 2019-11-02 14:32:56 --> Database Driver Class Initialized
INFO - 2019-11-02 14:32:56 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:56 --> Template Class Initialized
INFO - 2019-11-02 14:32:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:32:56 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:32:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:32:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:32:56 --> Encryption Class Initialized
INFO - 2019-11-02 14:32:56 --> Controller Class Initialized
DEBUG - 2019-11-02 14:32:56 --> language MX_Controller Initialized
DEBUG - 2019-11-02 14:32:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-02 14:32:56 --> Model Class Initialized
INFO - 2019-11-02 14:32:58 --> Config Class Initialized
INFO - 2019-11-02 14:32:58 --> Hooks Class Initialized
DEBUG - 2019-11-02 14:32:58 --> UTF-8 Support Enabled
INFO - 2019-11-02 14:32:58 --> Utf8 Class Initialized
INFO - 2019-11-02 14:32:58 --> URI Class Initialized
DEBUG - 2019-11-02 14:32:58 --> No URI present. Default controller set.
INFO - 2019-11-02 14:32:58 --> Router Class Initialized
INFO - 2019-11-02 14:32:58 --> Output Class Initialized
INFO - 2019-11-02 14:32:58 --> Security Class Initialized
DEBUG - 2019-11-02 14:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 14:32:58 --> CSRF cookie sent
INFO - 2019-11-02 14:32:58 --> Input Class Initialized
INFO - 2019-11-02 14:32:58 --> Language Class Initialized
INFO - 2019-11-02 14:32:58 --> Language Class Initialized
INFO - 2019-11-02 14:32:58 --> Config Class Initialized
INFO - 2019-11-02 14:32:58 --> Loader Class Initialized
INFO - 2019-11-02 14:32:58 --> Helper loaded: url_helper
INFO - 2019-11-02 14:32:58 --> Helper loaded: common_helper
INFO - 2019-11-02 14:32:58 --> Helper loaded: language_helper
INFO - 2019-11-02 14:32:58 --> Helper loaded: cookie_helper
INFO - 2019-11-02 14:32:58 --> Helper loaded: email_helper
INFO - 2019-11-02 14:32:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 14:32:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 14:32:58 --> Parser Class Initialized
INFO - 2019-11-02 14:32:58 --> User Agent Class Initialized
INFO - 2019-11-02 14:32:58 --> Model Class Initialized
INFO - 2019-11-02 14:32:58 --> Database Driver Class Initialized
INFO - 2019-11-02 14:32:58 --> Model Class Initialized
DEBUG - 2019-11-02 14:32:58 --> Template Class Initialized
INFO - 2019-11-02 14:32:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 14:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 14:32:58 --> Pagination Class Initialized
DEBUG - 2019-11-02 14:32:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 14:32:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 14:32:58 --> Encryption Class Initialized
DEBUG - 2019-11-02 14:32:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-02 14:32:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-02 14:32:58 --> Controller Class Initialized
DEBUG - 2019-11-02 14:32:58 --> pergo MX_Controller Initialized
DEBUG - 2019-11-02 14:32:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-02 14:32:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-02 14:32:58 --> Model Class Initialized
INFO - 2019-11-02 14:32:58 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 14:32:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-02 14:32:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-02 14:32:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-02 14:32:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-02 14:32:58 --> Final output sent to browser
DEBUG - 2019-11-02 14:32:58 --> Total execution time: 0.9171
INFO - 2019-11-02 16:29:02 --> Config Class Initialized
INFO - 2019-11-02 16:29:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 16:29:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 16:29:02 --> Utf8 Class Initialized
INFO - 2019-11-02 16:29:02 --> URI Class Initialized
INFO - 2019-11-02 16:29:02 --> Router Class Initialized
INFO - 2019-11-02 16:29:02 --> Output Class Initialized
INFO - 2019-11-02 16:29:02 --> Security Class Initialized
DEBUG - 2019-11-02 16:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 16:29:02 --> CSRF cookie sent
INFO - 2019-11-02 16:29:02 --> Input Class Initialized
INFO - 2019-11-02 16:29:02 --> Language Class Initialized
INFO - 2019-11-02 16:29:02 --> Language Class Initialized
INFO - 2019-11-02 16:29:02 --> Config Class Initialized
INFO - 2019-11-02 16:29:02 --> Loader Class Initialized
INFO - 2019-11-02 16:29:02 --> Helper loaded: url_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: common_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: language_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: cookie_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: email_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 16:29:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 16:29:02 --> Parser Class Initialized
INFO - 2019-11-02 16:29:02 --> User Agent Class Initialized
INFO - 2019-11-02 16:29:02 --> Model Class Initialized
INFO - 2019-11-02 16:29:02 --> Database Driver Class Initialized
INFO - 2019-11-02 16:29:02 --> Model Class Initialized
DEBUG - 2019-11-02 16:29:02 --> Template Class Initialized
INFO - 2019-11-02 16:29:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 16:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 16:29:02 --> Pagination Class Initialized
DEBUG - 2019-11-02 16:29:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 16:29:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 16:29:02 --> Encryption Class Initialized
INFO - 2019-11-02 16:29:02 --> Controller Class Initialized
DEBUG - 2019-11-02 16:29:02 --> auth MX_Controller Initialized
DEBUG - 2019-11-02 16:29:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-02 16:29:02 --> Model Class Initialized
INFO - 2019-11-02 16:29:02 --> Config Class Initialized
INFO - 2019-11-02 16:29:02 --> Hooks Class Initialized
DEBUG - 2019-11-02 16:29:02 --> UTF-8 Support Enabled
INFO - 2019-11-02 16:29:02 --> Utf8 Class Initialized
INFO - 2019-11-02 16:29:02 --> URI Class Initialized
INFO - 2019-11-02 16:29:02 --> Router Class Initialized
INFO - 2019-11-02 16:29:02 --> Output Class Initialized
INFO - 2019-11-02 16:29:02 --> Security Class Initialized
DEBUG - 2019-11-02 16:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 16:29:02 --> CSRF cookie sent
INFO - 2019-11-02 16:29:02 --> Input Class Initialized
INFO - 2019-11-02 16:29:02 --> Language Class Initialized
INFO - 2019-11-02 16:29:02 --> Language Class Initialized
INFO - 2019-11-02 16:29:02 --> Config Class Initialized
INFO - 2019-11-02 16:29:02 --> Loader Class Initialized
INFO - 2019-11-02 16:29:02 --> Helper loaded: url_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: common_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: language_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: cookie_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: email_helper
INFO - 2019-11-02 16:29:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 16:29:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 16:29:02 --> Parser Class Initialized
INFO - 2019-11-02 16:29:02 --> User Agent Class Initialized
INFO - 2019-11-02 16:29:02 --> Model Class Initialized
INFO - 2019-11-02 16:29:02 --> Database Driver Class Initialized
INFO - 2019-11-02 16:29:02 --> Model Class Initialized
DEBUG - 2019-11-02 16:29:03 --> Template Class Initialized
INFO - 2019-11-02 16:29:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 16:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 16:29:03 --> Pagination Class Initialized
DEBUG - 2019-11-02 16:29:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 16:29:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 16:29:03 --> Encryption Class Initialized
INFO - 2019-11-02 16:29:03 --> Controller Class Initialized
DEBUG - 2019-11-02 16:29:03 --> statistics MX_Controller Initialized
DEBUG - 2019-11-02 16:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-02 16:29:03 --> Model Class Initialized
ERROR - 2019-11-02 16:29:03 --> Could not find the language line "Pending"
ERROR - 2019-11-02 16:29:03 --> Could not find the language line "Pending"
INFO - 2019-11-02 16:29:03 --> Helper loaded: inflector_helper
ERROR - 2019-11-02 16:29:03 --> Could not find the language line "total_orders"
ERROR - 2019-11-02 16:29:03 --> Could not find the language line "total_orders"
ERROR - 2019-11-02 16:29:03 --> Could not find the language line "Pending"
DEBUG - 2019-11-02 16:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-02 16:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 16:29:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 16:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 16:29:03 --> Model Class Initialized
DEBUG - 2019-11-02 16:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 16:29:03 --> Model Class Initialized
DEBUG - 2019-11-02 16:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 16:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 16:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 16:29:03 --> Final output sent to browser
DEBUG - 2019-11-02 16:29:03 --> Total execution time: 0.9174
INFO - 2019-11-02 16:29:05 --> Config Class Initialized
INFO - 2019-11-02 16:29:05 --> Hooks Class Initialized
DEBUG - 2019-11-02 16:29:05 --> UTF-8 Support Enabled
INFO - 2019-11-02 16:29:05 --> Utf8 Class Initialized
INFO - 2019-11-02 16:29:05 --> URI Class Initialized
INFO - 2019-11-02 16:29:05 --> Router Class Initialized
INFO - 2019-11-02 16:29:05 --> Output Class Initialized
INFO - 2019-11-02 16:29:05 --> Security Class Initialized
DEBUG - 2019-11-02 16:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 16:29:05 --> CSRF cookie sent
INFO - 2019-11-02 16:29:05 --> Input Class Initialized
INFO - 2019-11-02 16:29:05 --> Language Class Initialized
INFO - 2019-11-02 16:29:05 --> Language Class Initialized
INFO - 2019-11-02 16:29:05 --> Config Class Initialized
INFO - 2019-11-02 16:29:05 --> Loader Class Initialized
INFO - 2019-11-02 16:29:05 --> Helper loaded: url_helper
INFO - 2019-11-02 16:29:05 --> Helper loaded: common_helper
INFO - 2019-11-02 16:29:05 --> Helper loaded: language_helper
INFO - 2019-11-02 16:29:05 --> Helper loaded: cookie_helper
INFO - 2019-11-02 16:29:05 --> Helper loaded: email_helper
INFO - 2019-11-02 16:29:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 16:29:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 16:29:05 --> Parser Class Initialized
INFO - 2019-11-02 16:29:05 --> User Agent Class Initialized
INFO - 2019-11-02 16:29:05 --> Model Class Initialized
INFO - 2019-11-02 16:29:05 --> Database Driver Class Initialized
INFO - 2019-11-02 16:29:05 --> Model Class Initialized
DEBUG - 2019-11-02 16:29:05 --> Template Class Initialized
INFO - 2019-11-02 16:29:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 16:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 16:29:05 --> Pagination Class Initialized
DEBUG - 2019-11-02 16:29:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 16:29:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 16:29:06 --> Encryption Class Initialized
INFO - 2019-11-02 16:29:06 --> Controller Class Initialized
DEBUG - 2019-11-02 16:29:06 --> module MX_Controller Initialized
DEBUG - 2019-11-02 16:29:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/module/models/module_model.php
INFO - 2019-11-02 16:29:06 --> Model Class Initialized
INFO - 2019-11-02 16:29:07 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 16:29:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/module/views/index.php
DEBUG - 2019-11-02 16:29:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 16:29:07 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 16:29:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 16:29:07 --> Model Class Initialized
DEBUG - 2019-11-02 16:29:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 16:29:08 --> Model Class Initialized
DEBUG - 2019-11-02 16:29:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 16:29:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 16:29:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 16:29:08 --> Final output sent to browser
DEBUG - 2019-11-02 16:29:08 --> Total execution time: 2.6470
INFO - 2019-11-02 16:31:15 --> Config Class Initialized
INFO - 2019-11-02 16:31:15 --> Hooks Class Initialized
DEBUG - 2019-11-02 16:31:15 --> UTF-8 Support Enabled
INFO - 2019-11-02 16:31:15 --> Utf8 Class Initialized
INFO - 2019-11-02 16:31:15 --> URI Class Initialized
INFO - 2019-11-02 16:31:15 --> Router Class Initialized
INFO - 2019-11-02 16:31:15 --> Output Class Initialized
INFO - 2019-11-02 16:31:15 --> Security Class Initialized
DEBUG - 2019-11-02 16:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-02 16:31:15 --> CSRF cookie sent
INFO - 2019-11-02 16:31:15 --> Input Class Initialized
INFO - 2019-11-02 16:31:15 --> Language Class Initialized
INFO - 2019-11-02 16:31:15 --> Language Class Initialized
INFO - 2019-11-02 16:31:15 --> Config Class Initialized
INFO - 2019-11-02 16:31:15 --> Loader Class Initialized
INFO - 2019-11-02 16:31:15 --> Helper loaded: url_helper
INFO - 2019-11-02 16:31:15 --> Helper loaded: common_helper
INFO - 2019-11-02 16:31:15 --> Helper loaded: language_helper
INFO - 2019-11-02 16:31:15 --> Helper loaded: cookie_helper
INFO - 2019-11-02 16:31:15 --> Helper loaded: email_helper
INFO - 2019-11-02 16:31:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-02 16:31:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-02 16:31:15 --> Parser Class Initialized
INFO - 2019-11-02 16:31:15 --> User Agent Class Initialized
INFO - 2019-11-02 16:31:15 --> Model Class Initialized
INFO - 2019-11-02 16:31:15 --> Database Driver Class Initialized
INFO - 2019-11-02 16:31:15 --> Model Class Initialized
DEBUG - 2019-11-02 16:31:15 --> Template Class Initialized
INFO - 2019-11-02 16:31:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-02 16:31:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-02 16:31:16 --> Pagination Class Initialized
DEBUG - 2019-11-02 16:31:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-02 16:31:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-02 16:31:16 --> Encryption Class Initialized
INFO - 2019-11-02 16:31:16 --> Controller Class Initialized
DEBUG - 2019-11-02 16:31:16 --> module MX_Controller Initialized
DEBUG - 2019-11-02 16:31:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/module/models/module_model.php
INFO - 2019-11-02 16:31:16 --> Model Class Initialized
INFO - 2019-11-02 16:31:17 --> Helper loaded: inflector_helper
DEBUG - 2019-11-02 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/module/views/index.php
DEBUG - 2019-11-02 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-02 16:31:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-02 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-02 16:31:17 --> Model Class Initialized
DEBUG - 2019-11-02 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-02 16:31:17 --> Model Class Initialized
DEBUG - 2019-11-02 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-02 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-02 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-02 16:31:17 --> Final output sent to browser
DEBUG - 2019-11-02 16:31:17 --> Total execution time: 2.3111
