<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-20 10:47:32 --> Config Class Initialized
INFO - 2020-02-20 10:47:32 --> Hooks Class Initialized
DEBUG - 2020-02-20 10:47:32 --> UTF-8 Support Enabled
INFO - 2020-02-20 10:47:32 --> Utf8 Class Initialized
INFO - 2020-02-20 10:47:32 --> URI Class Initialized
DEBUG - 2020-02-20 10:47:32 --> No URI present. Default controller set.
INFO - 2020-02-20 10:47:32 --> Router Class Initialized
INFO - 2020-02-20 10:47:32 --> Output Class Initialized
INFO - 2020-02-20 10:47:32 --> Security Class Initialized
DEBUG - 2020-02-20 10:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 10:47:32 --> CSRF cookie sent
INFO - 2020-02-20 10:47:32 --> Input Class Initialized
INFO - 2020-02-20 10:47:32 --> Language Class Initialized
INFO - 2020-02-20 10:47:32 --> Language Class Initialized
INFO - 2020-02-20 10:47:32 --> Config Class Initialized
INFO - 2020-02-20 10:47:32 --> Loader Class Initialized
INFO - 2020-02-20 10:47:32 --> Helper loaded: url_helper
INFO - 2020-02-20 10:47:32 --> Helper loaded: common_helper
INFO - 2020-02-20 10:47:32 --> Helper loaded: language_helper
INFO - 2020-02-20 10:47:32 --> Helper loaded: cookie_helper
INFO - 2020-02-20 10:47:32 --> Helper loaded: email_helper
INFO - 2020-02-20 10:47:32 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 10:47:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 10:47:32 --> Parser Class Initialized
INFO - 2020-02-20 10:47:32 --> User Agent Class Initialized
INFO - 2020-02-20 10:47:32 --> Model Class Initialized
INFO - 2020-02-20 10:47:33 --> Database Driver Class Initialized
INFO - 2020-02-20 10:47:33 --> Model Class Initialized
DEBUG - 2020-02-20 10:47:33 --> Template Class Initialized
INFO - 2020-02-20 10:47:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 10:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 10:47:33 --> Pagination Class Initialized
DEBUG - 2020-02-20 10:47:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 10:47:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 10:47:33 --> Encryption Class Initialized
DEBUG - 2020-02-20 10:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-20 10:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-02-20 10:47:33 --> Controller Class Initialized
DEBUG - 2020-02-20 10:47:33 --> pergo MX_Controller Initialized
DEBUG - 2020-02-20 10:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-20 10:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-02-20 10:47:33 --> Model Class Initialized
INFO - 2020-02-20 10:47:33 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 10:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-02-20 10:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-02-20 10:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-02-20 10:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-02-20 10:47:34 --> Final output sent to browser
DEBUG - 2020-02-20 10:47:34 --> Total execution time: 1.9828
INFO - 2020-02-20 11:24:47 --> Config Class Initialized
INFO - 2020-02-20 11:24:47 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:24:47 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:24:47 --> Utf8 Class Initialized
INFO - 2020-02-20 11:24:47 --> URI Class Initialized
INFO - 2020-02-20 11:24:47 --> Router Class Initialized
INFO - 2020-02-20 11:24:47 --> Output Class Initialized
INFO - 2020-02-20 11:24:47 --> Security Class Initialized
DEBUG - 2020-02-20 11:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:24:47 --> CSRF cookie sent
INFO - 2020-02-20 11:24:47 --> Input Class Initialized
INFO - 2020-02-20 11:24:47 --> Language Class Initialized
INFO - 2020-02-20 11:24:47 --> Language Class Initialized
INFO - 2020-02-20 11:24:47 --> Config Class Initialized
INFO - 2020-02-20 11:24:47 --> Loader Class Initialized
INFO - 2020-02-20 11:24:47 --> Helper loaded: url_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: common_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: language_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: email_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:24:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:24:47 --> Parser Class Initialized
INFO - 2020-02-20 11:24:47 --> User Agent Class Initialized
INFO - 2020-02-20 11:24:47 --> Model Class Initialized
INFO - 2020-02-20 11:24:47 --> Database Driver Class Initialized
INFO - 2020-02-20 11:24:47 --> Model Class Initialized
DEBUG - 2020-02-20 11:24:47 --> Template Class Initialized
INFO - 2020-02-20 11:24:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:24:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:24:47 --> Encryption Class Initialized
INFO - 2020-02-20 11:24:47 --> Controller Class Initialized
DEBUG - 2020-02-20 11:24:47 --> auth MX_Controller Initialized
DEBUG - 2020-02-20 11:24:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-02-20 11:24:47 --> Model Class Initialized
INFO - 2020-02-20 11:24:47 --> Config Class Initialized
INFO - 2020-02-20 11:24:47 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:24:47 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:24:47 --> Utf8 Class Initialized
INFO - 2020-02-20 11:24:47 --> URI Class Initialized
INFO - 2020-02-20 11:24:47 --> Router Class Initialized
INFO - 2020-02-20 11:24:47 --> Output Class Initialized
INFO - 2020-02-20 11:24:47 --> Security Class Initialized
DEBUG - 2020-02-20 11:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:24:47 --> CSRF cookie sent
INFO - 2020-02-20 11:24:47 --> Input Class Initialized
INFO - 2020-02-20 11:24:47 --> Language Class Initialized
INFO - 2020-02-20 11:24:47 --> Language Class Initialized
INFO - 2020-02-20 11:24:47 --> Config Class Initialized
INFO - 2020-02-20 11:24:47 --> Loader Class Initialized
INFO - 2020-02-20 11:24:47 --> Helper loaded: url_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: common_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: language_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: email_helper
INFO - 2020-02-20 11:24:47 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:24:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:24:48 --> Parser Class Initialized
INFO - 2020-02-20 11:24:48 --> User Agent Class Initialized
INFO - 2020-02-20 11:24:48 --> Model Class Initialized
INFO - 2020-02-20 11:24:48 --> Database Driver Class Initialized
INFO - 2020-02-20 11:24:48 --> Model Class Initialized
DEBUG - 2020-02-20 11:24:48 --> Template Class Initialized
INFO - 2020-02-20 11:24:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:24:48 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:24:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:24:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:24:48 --> Encryption Class Initialized
INFO - 2020-02-20 11:24:48 --> Controller Class Initialized
DEBUG - 2020-02-20 11:24:48 --> statistics MX_Controller Initialized
DEBUG - 2020-02-20 11:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-02-20 11:24:48 --> Model Class Initialized
ERROR - 2020-02-20 11:24:48 --> Could not find the language line "Pending"
ERROR - 2020-02-20 11:24:48 --> Could not find the language line "Pending"
INFO - 2020-02-20 11:24:48 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 11:24:48 --> Could not find the language line "total_orders"
ERROR - 2020-02-20 11:24:48 --> Could not find the language line "total_orders"
ERROR - 2020-02-20 11:24:48 --> Could not find the language line "Pending"
DEBUG - 2020-02-20 11:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-02-20 11:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 11:24:48 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 11:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 11:24:48 --> Model Class Initialized
DEBUG - 2020-02-20 11:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:24:48 --> Model Class Initialized
DEBUG - 2020-02-20 11:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 11:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 11:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 11:24:48 --> Final output sent to browser
DEBUG - 2020-02-20 11:24:48 --> Total execution time: 0.9577
INFO - 2020-02-20 11:24:53 --> Config Class Initialized
INFO - 2020-02-20 11:24:53 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:24:53 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:24:53 --> Utf8 Class Initialized
INFO - 2020-02-20 11:24:53 --> URI Class Initialized
INFO - 2020-02-20 11:24:53 --> Router Class Initialized
INFO - 2020-02-20 11:24:53 --> Output Class Initialized
INFO - 2020-02-20 11:24:53 --> Security Class Initialized
DEBUG - 2020-02-20 11:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:24:54 --> CSRF cookie sent
INFO - 2020-02-20 11:24:54 --> Input Class Initialized
INFO - 2020-02-20 11:24:54 --> Language Class Initialized
INFO - 2020-02-20 11:24:54 --> Language Class Initialized
INFO - 2020-02-20 11:24:54 --> Config Class Initialized
INFO - 2020-02-20 11:24:54 --> Loader Class Initialized
INFO - 2020-02-20 11:24:54 --> Helper loaded: url_helper
INFO - 2020-02-20 11:24:54 --> Helper loaded: common_helper
INFO - 2020-02-20 11:24:54 --> Helper loaded: language_helper
INFO - 2020-02-20 11:24:54 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:24:54 --> Helper loaded: email_helper
INFO - 2020-02-20 11:24:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:24:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:24:54 --> Parser Class Initialized
INFO - 2020-02-20 11:24:54 --> User Agent Class Initialized
INFO - 2020-02-20 11:24:54 --> Model Class Initialized
INFO - 2020-02-20 11:24:54 --> Database Driver Class Initialized
INFO - 2020-02-20 11:24:54 --> Model Class Initialized
DEBUG - 2020-02-20 11:24:54 --> Template Class Initialized
INFO - 2020-02-20 11:24:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:24:54 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:24:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:24:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:24:54 --> Encryption Class Initialized
INFO - 2020-02-20 11:24:54 --> Controller Class Initialized
DEBUG - 2020-02-20 11:24:54 --> language MX_Controller Initialized
DEBUG - 2020-02-20 11:24:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2020-02-20 11:24:54 --> Model Class Initialized
INFO - 2020-02-20 11:24:54 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 11:24:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2020-02-20 11:24:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 11:24:54 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 11:24:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 11:24:54 --> Model Class Initialized
DEBUG - 2020-02-20 11:24:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:24:54 --> Model Class Initialized
DEBUG - 2020-02-20 11:24:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 11:24:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 11:24:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 11:24:54 --> Final output sent to browser
DEBUG - 2020-02-20 11:24:54 --> Total execution time: 0.8384
INFO - 2020-02-20 11:25:08 --> Config Class Initialized
INFO - 2020-02-20 11:25:08 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:25:08 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:25:08 --> Utf8 Class Initialized
INFO - 2020-02-20 11:25:08 --> URI Class Initialized
INFO - 2020-02-20 11:25:08 --> Router Class Initialized
INFO - 2020-02-20 11:25:08 --> Output Class Initialized
INFO - 2020-02-20 11:25:08 --> Security Class Initialized
DEBUG - 2020-02-20 11:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:25:08 --> CSRF cookie sent
INFO - 2020-02-20 11:25:08 --> Input Class Initialized
INFO - 2020-02-20 11:25:08 --> Language Class Initialized
INFO - 2020-02-20 11:25:08 --> Language Class Initialized
INFO - 2020-02-20 11:25:08 --> Config Class Initialized
INFO - 2020-02-20 11:25:08 --> Loader Class Initialized
INFO - 2020-02-20 11:25:08 --> Helper loaded: url_helper
INFO - 2020-02-20 11:25:08 --> Helper loaded: common_helper
INFO - 2020-02-20 11:25:08 --> Helper loaded: language_helper
INFO - 2020-02-20 11:25:08 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:25:08 --> Helper loaded: email_helper
INFO - 2020-02-20 11:25:08 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:25:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:25:08 --> Parser Class Initialized
INFO - 2020-02-20 11:25:08 --> User Agent Class Initialized
INFO - 2020-02-20 11:25:08 --> Model Class Initialized
INFO - 2020-02-20 11:25:08 --> Database Driver Class Initialized
INFO - 2020-02-20 11:25:08 --> Model Class Initialized
DEBUG - 2020-02-20 11:25:08 --> Template Class Initialized
INFO - 2020-02-20 11:25:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:25:08 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:25:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:25:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:25:08 --> Encryption Class Initialized
INFO - 2020-02-20 11:25:08 --> Controller Class Initialized
DEBUG - 2020-02-20 11:25:08 --> language MX_Controller Initialized
DEBUG - 2020-02-20 11:25:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2020-02-20 11:25:08 --> Model Class Initialized
INFO - 2020-02-20 11:25:13 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 11:25:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2020-02-20 11:25:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 11:25:13 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 11:25:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 11:25:13 --> Model Class Initialized
DEBUG - 2020-02-20 11:25:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:25:13 --> Model Class Initialized
DEBUG - 2020-02-20 11:25:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 11:25:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 11:25:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 11:25:13 --> Final output sent to browser
DEBUG - 2020-02-20 11:25:13 --> Total execution time: 5.5097
INFO - 2020-02-20 11:32:13 --> Config Class Initialized
INFO - 2020-02-20 11:32:13 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:32:13 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:32:13 --> Utf8 Class Initialized
INFO - 2020-02-20 11:32:13 --> URI Class Initialized
INFO - 2020-02-20 11:32:13 --> Router Class Initialized
INFO - 2020-02-20 11:32:13 --> Output Class Initialized
INFO - 2020-02-20 11:32:14 --> Security Class Initialized
DEBUG - 2020-02-20 11:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:32:14 --> CSRF cookie sent
INFO - 2020-02-20 11:32:14 --> Input Class Initialized
INFO - 2020-02-20 11:32:14 --> Language Class Initialized
INFO - 2020-02-20 11:32:14 --> Language Class Initialized
INFO - 2020-02-20 11:32:14 --> Config Class Initialized
INFO - 2020-02-20 11:32:14 --> Loader Class Initialized
INFO - 2020-02-20 11:32:14 --> Helper loaded: url_helper
INFO - 2020-02-20 11:32:14 --> Helper loaded: common_helper
INFO - 2020-02-20 11:32:14 --> Helper loaded: language_helper
INFO - 2020-02-20 11:32:14 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:32:14 --> Helper loaded: email_helper
INFO - 2020-02-20 11:32:14 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:32:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:32:14 --> Parser Class Initialized
INFO - 2020-02-20 11:32:14 --> User Agent Class Initialized
INFO - 2020-02-20 11:32:14 --> Model Class Initialized
INFO - 2020-02-20 11:32:14 --> Database Driver Class Initialized
INFO - 2020-02-20 11:32:14 --> Model Class Initialized
DEBUG - 2020-02-20 11:32:14 --> Template Class Initialized
INFO - 2020-02-20 11:32:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:32:14 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:32:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:32:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:32:14 --> Encryption Class Initialized
INFO - 2020-02-20 11:32:14 --> Controller Class Initialized
DEBUG - 2020-02-20 11:32:14 --> category MX_Controller Initialized
DEBUG - 2020-02-20 11:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:14 --> Model Class Initialized
ERROR - 2020-02-20 11:32:14 --> Could not find the language line "Sorting"
INFO - 2020-02-20 11:32:14 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 11:32:14 --> Could not find the language line "Delele"
DEBUG - 2020-02-20 11:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-20 11:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 11:32:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 11:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 11:32:14 --> Model Class Initialized
DEBUG - 2020-02-20 11:32:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:14 --> Model Class Initialized
DEBUG - 2020-02-20 11:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 11:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 11:32:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 11:32:14 --> Final output sent to browser
DEBUG - 2020-02-20 11:32:14 --> Total execution time: 0.7903
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Hooks Class Initialized
INFO - 2020-02-20 11:32:15 --> Hooks Class Initialized
INFO - 2020-02-20 11:32:15 --> Hooks Class Initialized
INFO - 2020-02-20 11:32:15 --> Hooks Class Initialized
INFO - 2020-02-20 11:32:15 --> Hooks Class Initialized
INFO - 2020-02-20 11:32:15 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:32:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:32:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:32:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:32:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:32:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 11:32:15 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:32:15 --> Utf8 Class Initialized
INFO - 2020-02-20 11:32:15 --> Utf8 Class Initialized
INFO - 2020-02-20 11:32:15 --> Utf8 Class Initialized
INFO - 2020-02-20 11:32:15 --> Utf8 Class Initialized
INFO - 2020-02-20 11:32:15 --> Utf8 Class Initialized
INFO - 2020-02-20 11:32:15 --> Utf8 Class Initialized
INFO - 2020-02-20 11:32:15 --> URI Class Initialized
INFO - 2020-02-20 11:32:15 --> URI Class Initialized
INFO - 2020-02-20 11:32:15 --> URI Class Initialized
INFO - 2020-02-20 11:32:15 --> URI Class Initialized
INFO - 2020-02-20 11:32:15 --> URI Class Initialized
INFO - 2020-02-20 11:32:15 --> URI Class Initialized
INFO - 2020-02-20 11:32:15 --> Router Class Initialized
INFO - 2020-02-20 11:32:15 --> Router Class Initialized
INFO - 2020-02-20 11:32:15 --> Router Class Initialized
INFO - 2020-02-20 11:32:15 --> Router Class Initialized
INFO - 2020-02-20 11:32:15 --> Router Class Initialized
INFO - 2020-02-20 11:32:15 --> Router Class Initialized
INFO - 2020-02-20 11:32:15 --> Output Class Initialized
INFO - 2020-02-20 11:32:15 --> Output Class Initialized
INFO - 2020-02-20 11:32:15 --> Output Class Initialized
INFO - 2020-02-20 11:32:15 --> Output Class Initialized
INFO - 2020-02-20 11:32:15 --> Output Class Initialized
INFO - 2020-02-20 11:32:15 --> Output Class Initialized
INFO - 2020-02-20 11:32:15 --> Security Class Initialized
INFO - 2020-02-20 11:32:15 --> Security Class Initialized
INFO - 2020-02-20 11:32:15 --> Security Class Initialized
INFO - 2020-02-20 11:32:15 --> Security Class Initialized
INFO - 2020-02-20 11:32:15 --> Security Class Initialized
INFO - 2020-02-20 11:32:15 --> Security Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 11:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:32:15 --> CSRF cookie sent
INFO - 2020-02-20 11:32:15 --> CSRF cookie sent
INFO - 2020-02-20 11:32:15 --> CSRF cookie sent
INFO - 2020-02-20 11:32:15 --> CSRF cookie sent
INFO - 2020-02-20 11:32:15 --> CSRF cookie sent
INFO - 2020-02-20 11:32:15 --> CSRF cookie sent
INFO - 2020-02-20 11:32:15 --> CSRF token verified
INFO - 2020-02-20 11:32:15 --> CSRF token verified
INFO - 2020-02-20 11:32:15 --> CSRF token verified
INFO - 2020-02-20 11:32:15 --> CSRF token verified
INFO - 2020-02-20 11:32:15 --> CSRF token verified
INFO - 2020-02-20 11:32:15 --> CSRF token verified
INFO - 2020-02-20 11:32:15 --> Input Class Initialized
INFO - 2020-02-20 11:32:15 --> Input Class Initialized
INFO - 2020-02-20 11:32:15 --> Input Class Initialized
INFO - 2020-02-20 11:32:15 --> Input Class Initialized
INFO - 2020-02-20 11:32:15 --> Input Class Initialized
INFO - 2020-02-20 11:32:15 --> Input Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Loader Class Initialized
INFO - 2020-02-20 11:32:15 --> Loader Class Initialized
INFO - 2020-02-20 11:32:15 --> Loader Class Initialized
INFO - 2020-02-20 11:32:15 --> Loader Class Initialized
INFO - 2020-02-20 11:32:15 --> Loader Class Initialized
INFO - 2020-02-20 11:32:15 --> Loader Class Initialized
INFO - 2020-02-20 11:32:15 --> Helper loaded: url_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: url_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: url_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: url_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: url_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: url_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: common_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: common_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: common_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: common_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: common_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: common_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: language_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: language_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: language_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: language_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: language_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: language_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: email_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: email_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: email_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: email_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: email_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: email_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:32:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:32:15 --> Parser Class Initialized
INFO - 2020-02-20 11:32:15 --> Parser Class Initialized
INFO - 2020-02-20 11:32:15 --> Parser Class Initialized
INFO - 2020-02-20 11:32:15 --> Parser Class Initialized
INFO - 2020-02-20 11:32:15 --> Parser Class Initialized
INFO - 2020-02-20 11:32:15 --> Parser Class Initialized
INFO - 2020-02-20 11:32:15 --> User Agent Class Initialized
INFO - 2020-02-20 11:32:15 --> User Agent Class Initialized
INFO - 2020-02-20 11:32:15 --> User Agent Class Initialized
INFO - 2020-02-20 11:32:15 --> User Agent Class Initialized
INFO - 2020-02-20 11:32:15 --> User Agent Class Initialized
INFO - 2020-02-20 11:32:15 --> User Agent Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Database Driver Class Initialized
INFO - 2020-02-20 11:32:15 --> Database Driver Class Initialized
INFO - 2020-02-20 11:32:15 --> Database Driver Class Initialized
INFO - 2020-02-20 11:32:15 --> Database Driver Class Initialized
INFO - 2020-02-20 11:32:15 --> Database Driver Class Initialized
INFO - 2020-02-20 11:32:15 --> Database Driver Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Template Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Template Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Template Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Template Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Template Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Template Class Initialized
INFO - 2020-02-20 11:32:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:32:15 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:32:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:32:15 --> Encryption Class Initialized
INFO - 2020-02-20 11:32:15 --> Controller Class Initialized
DEBUG - 2020-02-20 11:32:15 --> category MX_Controller Initialized
DEBUG - 2020-02-20 11:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
ERROR - 2020-02-20 11:32:15 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 11:32:15 --> Could not find the language line "View"
ERROR - 2020-02-20 11:32:15 --> Could not find the language line "View"
ERROR - 2020-02-20 11:32:15 --> Could not find the language line "View"
DEBUG - 2020-02-20 11:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 11:32:15 --> Final output sent to browser
DEBUG - 2020-02-20 11:32:15 --> Total execution time: 0.5776
INFO - 2020-02-20 11:32:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:32:15 --> Pagination Class Initialized
INFO - 2020-02-20 11:32:15 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-02-20 11:32:15 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:32:15 --> Utf8 Class Initialized
INFO - 2020-02-20 11:32:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:32:15 --> Encryption Class Initialized
INFO - 2020-02-20 11:32:15 --> URI Class Initialized
INFO - 2020-02-20 11:32:15 --> Controller Class Initialized
INFO - 2020-02-20 11:32:15 --> Router Class Initialized
DEBUG - 2020-02-20 11:32:15 --> category MX_Controller Initialized
INFO - 2020-02-20 11:32:15 --> Output Class Initialized
INFO - 2020-02-20 11:32:15 --> Security Class Initialized
DEBUG - 2020-02-20 11:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:32:15 --> CSRF cookie sent
ERROR - 2020-02-20 11:32:15 --> Could not find the language line "Sorting"
INFO - 2020-02-20 11:32:15 --> CSRF token verified
ERROR - 2020-02-20 11:32:15 --> Could not find the language line "View"
INFO - 2020-02-20 11:32:15 --> Input Class Initialized
DEBUG - 2020-02-20 11:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 11:32:15 --> Final output sent to browser
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
DEBUG - 2020-02-20 11:32:15 --> Total execution time: 0.7210
INFO - 2020-02-20 11:32:15 --> Language Class Initialized
INFO - 2020-02-20 11:32:15 --> Config Class Initialized
INFO - 2020-02-20 11:32:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:32:15 --> Loader Class Initialized
INFO - 2020-02-20 11:32:15 --> Pagination Class Initialized
INFO - 2020-02-20 11:32:15 --> Helper loaded: url_helper
DEBUG - 2020-02-20 11:32:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:32:15 --> Helper loaded: common_helper
INFO - 2020-02-20 11:32:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:32:15 --> Helper loaded: language_helper
INFO - 2020-02-20 11:32:15 --> Encryption Class Initialized
INFO - 2020-02-20 11:32:15 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:32:15 --> Controller Class Initialized
INFO - 2020-02-20 11:32:15 --> Helper loaded: email_helper
DEBUG - 2020-02-20 11:32:15 --> category MX_Controller Initialized
INFO - 2020-02-20 11:32:15 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-20 11:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:15 --> Parser Class Initialized
INFO - 2020-02-20 11:32:15 --> User Agent Class Initialized
ERROR - 2020-02-20 11:32:15 --> Could not find the language line "Sorting"
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
ERROR - 2020-02-20 11:32:15 --> Could not find the language line "View"
DEBUG - 2020-02-20 11:32:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 11:32:15 --> Database Driver Class Initialized
INFO - 2020-02-20 11:32:15 --> Final output sent to browser
DEBUG - 2020-02-20 11:32:15 --> Total execution time: 0.8734
INFO - 2020-02-20 11:32:15 --> Model Class Initialized
INFO - 2020-02-20 11:32:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2020-02-20 11:32:16 --> Template Class Initialized
INFO - 2020-02-20 11:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:32:16 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:32:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:32:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:32:16 --> Encryption Class Initialized
INFO - 2020-02-20 11:32:16 --> Controller Class Initialized
DEBUG - 2020-02-20 11:32:16 --> category MX_Controller Initialized
DEBUG - 2020-02-20 11:32:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:16 --> Model Class Initialized
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
DEBUG - 2020-02-20 11:32:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 11:32:16 --> Final output sent to browser
DEBUG - 2020-02-20 11:32:16 --> Total execution time: 1.0807
INFO - 2020-02-20 11:32:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:32:16 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:32:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:32:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:32:16 --> Encryption Class Initialized
INFO - 2020-02-20 11:32:16 --> Controller Class Initialized
DEBUG - 2020-02-20 11:32:16 --> category MX_Controller Initialized
DEBUG - 2020-02-20 11:32:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:16 --> Model Class Initialized
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
DEBUG - 2020-02-20 11:32:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 11:32:16 --> Final output sent to browser
DEBUG - 2020-02-20 11:32:16 --> Total execution time: 1.2503
INFO - 2020-02-20 11:32:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:32:16 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:32:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:32:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:32:16 --> Encryption Class Initialized
INFO - 2020-02-20 11:32:16 --> Controller Class Initialized
DEBUG - 2020-02-20 11:32:16 --> category MX_Controller Initialized
DEBUG - 2020-02-20 11:32:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:16 --> Model Class Initialized
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
DEBUG - 2020-02-20 11:32:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 11:32:16 --> Final output sent to browser
DEBUG - 2020-02-20 11:32:16 --> Total execution time: 1.4007
INFO - 2020-02-20 11:32:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:32:16 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:32:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:32:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:32:16 --> Encryption Class Initialized
INFO - 2020-02-20 11:32:16 --> Controller Class Initialized
DEBUG - 2020-02-20 11:32:16 --> category MX_Controller Initialized
DEBUG - 2020-02-20 11:32:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:16 --> Model Class Initialized
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 11:32:16 --> Could not find the language line "View"
DEBUG - 2020-02-20 11:32:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 11:32:16 --> Final output sent to browser
DEBUG - 2020-02-20 11:32:16 --> Total execution time: 0.9463
INFO - 2020-02-20 11:32:18 --> Config Class Initialized
INFO - 2020-02-20 11:32:18 --> Hooks Class Initialized
DEBUG - 2020-02-20 11:32:18 --> UTF-8 Support Enabled
INFO - 2020-02-20 11:32:18 --> Utf8 Class Initialized
INFO - 2020-02-20 11:32:18 --> URI Class Initialized
INFO - 2020-02-20 11:32:18 --> Router Class Initialized
INFO - 2020-02-20 11:32:18 --> Output Class Initialized
INFO - 2020-02-20 11:32:18 --> Security Class Initialized
DEBUG - 2020-02-20 11:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 11:32:18 --> CSRF cookie sent
INFO - 2020-02-20 11:32:18 --> Input Class Initialized
INFO - 2020-02-20 11:32:18 --> Language Class Initialized
INFO - 2020-02-20 11:32:18 --> Language Class Initialized
INFO - 2020-02-20 11:32:18 --> Config Class Initialized
INFO - 2020-02-20 11:32:18 --> Loader Class Initialized
INFO - 2020-02-20 11:32:18 --> Helper loaded: url_helper
INFO - 2020-02-20 11:32:18 --> Helper loaded: common_helper
INFO - 2020-02-20 11:32:18 --> Helper loaded: language_helper
INFO - 2020-02-20 11:32:18 --> Helper loaded: cookie_helper
INFO - 2020-02-20 11:32:18 --> Helper loaded: email_helper
INFO - 2020-02-20 11:32:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 11:32:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 11:32:18 --> Parser Class Initialized
INFO - 2020-02-20 11:32:18 --> User Agent Class Initialized
INFO - 2020-02-20 11:32:18 --> Model Class Initialized
INFO - 2020-02-20 11:32:18 --> Database Driver Class Initialized
INFO - 2020-02-20 11:32:18 --> Model Class Initialized
DEBUG - 2020-02-20 11:32:18 --> Template Class Initialized
INFO - 2020-02-20 11:32:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 11:32:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 11:32:18 --> Pagination Class Initialized
DEBUG - 2020-02-20 11:32:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 11:32:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 11:32:18 --> Encryption Class Initialized
INFO - 2020-02-20 11:32:18 --> Controller Class Initialized
DEBUG - 2020-02-20 11:32:18 --> category MX_Controller Initialized
DEBUG - 2020-02-20 11:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:18 --> Model Class Initialized
ERROR - 2020-02-20 11:32:18 --> Could not find the language line "Sorting"
INFO - 2020-02-20 11:32:18 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 11:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 11:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 11:32:18 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 11:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 11:32:18 --> Model Class Initialized
DEBUG - 2020-02-20 11:32:18 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 11:32:18 --> Model Class Initialized
DEBUG - 2020-02-20 11:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 11:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 11:32:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 11:32:18 --> Final output sent to browser
DEBUG - 2020-02-20 11:32:18 --> Total execution time: 0.7934
INFO - 2020-02-20 15:21:44 --> Config Class Initialized
INFO - 2020-02-20 15:21:44 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:21:44 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:21:44 --> Utf8 Class Initialized
INFO - 2020-02-20 15:21:44 --> URI Class Initialized
INFO - 2020-02-20 15:21:44 --> Router Class Initialized
INFO - 2020-02-20 15:21:44 --> Output Class Initialized
INFO - 2020-02-20 15:21:44 --> Security Class Initialized
DEBUG - 2020-02-20 15:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:21:44 --> CSRF cookie sent
INFO - 2020-02-20 15:21:46 --> Config Class Initialized
INFO - 2020-02-20 15:21:46 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:21:46 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:21:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:21:46 --> URI Class Initialized
INFO - 2020-02-20 15:21:46 --> Router Class Initialized
INFO - 2020-02-20 15:21:46 --> Output Class Initialized
INFO - 2020-02-20 15:21:46 --> Security Class Initialized
DEBUG - 2020-02-20 15:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:21:47 --> CSRF cookie sent
INFO - 2020-02-20 15:22:11 --> Config Class Initialized
INFO - 2020-02-20 15:22:11 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:22:11 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:22:11 --> Utf8 Class Initialized
INFO - 2020-02-20 15:22:11 --> URI Class Initialized
INFO - 2020-02-20 15:22:11 --> Router Class Initialized
INFO - 2020-02-20 15:22:11 --> Output Class Initialized
INFO - 2020-02-20 15:22:11 --> Security Class Initialized
DEBUG - 2020-02-20 15:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:22:11 --> CSRF cookie sent
INFO - 2020-02-20 15:22:11 --> Input Class Initialized
INFO - 2020-02-20 15:22:11 --> Language Class Initialized
INFO - 2020-02-20 15:22:11 --> Language Class Initialized
INFO - 2020-02-20 15:22:11 --> Config Class Initialized
INFO - 2020-02-20 15:22:11 --> Loader Class Initialized
INFO - 2020-02-20 15:22:11 --> Helper loaded: url_helper
INFO - 2020-02-20 15:22:11 --> Helper loaded: common_helper
INFO - 2020-02-20 15:22:11 --> Helper loaded: language_helper
INFO - 2020-02-20 15:22:11 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:22:11 --> Helper loaded: email_helper
INFO - 2020-02-20 15:22:11 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:22:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:22:11 --> Parser Class Initialized
INFO - 2020-02-20 15:22:11 --> User Agent Class Initialized
INFO - 2020-02-20 15:22:11 --> Model Class Initialized
INFO - 2020-02-20 15:22:11 --> Database Driver Class Initialized
INFO - 2020-02-20 15:22:11 --> Model Class Initialized
DEBUG - 2020-02-20 15:22:11 --> Template Class Initialized
INFO - 2020-02-20 15:22:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:22:11 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:22:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:22:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:22:11 --> Encryption Class Initialized
INFO - 2020-02-20 15:22:11 --> Controller Class Initialized
DEBUG - 2020-02-20 15:22:11 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:22:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:22:11 --> Model Class Initialized
ERROR - 2020-02-20 15:22:11 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:22:11 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:22:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:22:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:22:11 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:22:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:22:11 --> Model Class Initialized
DEBUG - 2020-02-20 15:22:11 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:22:11 --> Model Class Initialized
DEBUG - 2020-02-20 15:22:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:22:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:22:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:22:11 --> Final output sent to browser
DEBUG - 2020-02-20 15:22:12 --> Total execution time: 0.6695
INFO - 2020-02-20 15:22:14 --> Config Class Initialized
INFO - 2020-02-20 15:22:14 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:22:14 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:22:15 --> Utf8 Class Initialized
INFO - 2020-02-20 15:22:15 --> URI Class Initialized
INFO - 2020-02-20 15:22:15 --> Router Class Initialized
INFO - 2020-02-20 15:22:15 --> Output Class Initialized
INFO - 2020-02-20 15:22:15 --> Security Class Initialized
DEBUG - 2020-02-20 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:22:15 --> CSRF cookie sent
INFO - 2020-02-20 15:22:15 --> CSRF token verified
INFO - 2020-02-20 15:22:15 --> Input Class Initialized
INFO - 2020-02-20 15:22:15 --> Language Class Initialized
INFO - 2020-02-20 15:22:15 --> Language Class Initialized
INFO - 2020-02-20 15:22:15 --> Config Class Initialized
INFO - 2020-02-20 15:22:15 --> Loader Class Initialized
INFO - 2020-02-20 15:22:15 --> Helper loaded: url_helper
INFO - 2020-02-20 15:22:15 --> Helper loaded: common_helper
INFO - 2020-02-20 15:22:15 --> Helper loaded: language_helper
INFO - 2020-02-20 15:22:15 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:22:15 --> Helper loaded: email_helper
INFO - 2020-02-20 15:22:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:22:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:22:15 --> Parser Class Initialized
INFO - 2020-02-20 15:22:15 --> User Agent Class Initialized
INFO - 2020-02-20 15:22:15 --> Model Class Initialized
INFO - 2020-02-20 15:22:15 --> Database Driver Class Initialized
INFO - 2020-02-20 15:22:15 --> Model Class Initialized
DEBUG - 2020-02-20 15:22:15 --> Template Class Initialized
INFO - 2020-02-20 15:22:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:22:15 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:22:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:22:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:22:15 --> Encryption Class Initialized
INFO - 2020-02-20 15:22:15 --> Controller Class Initialized
DEBUG - 2020-02-20 15:22:15 --> language MX_Controller Initialized
DEBUG - 2020-02-20 15:22:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2020-02-20 15:22:15 --> Model Class Initialized
INFO - 2020-02-20 15:22:16 --> Config Class Initialized
INFO - 2020-02-20 15:22:16 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:22:16 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:22:16 --> Utf8 Class Initialized
INFO - 2020-02-20 15:22:16 --> URI Class Initialized
INFO - 2020-02-20 15:22:16 --> Router Class Initialized
INFO - 2020-02-20 15:22:16 --> Output Class Initialized
INFO - 2020-02-20 15:22:16 --> Security Class Initialized
DEBUG - 2020-02-20 15:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:22:16 --> CSRF cookie sent
INFO - 2020-02-20 15:22:16 --> Input Class Initialized
INFO - 2020-02-20 15:22:16 --> Language Class Initialized
INFO - 2020-02-20 15:22:16 --> Language Class Initialized
INFO - 2020-02-20 15:22:16 --> Config Class Initialized
INFO - 2020-02-20 15:22:16 --> Loader Class Initialized
INFO - 2020-02-20 15:22:16 --> Helper loaded: url_helper
INFO - 2020-02-20 15:22:16 --> Helper loaded: common_helper
INFO - 2020-02-20 15:22:16 --> Helper loaded: language_helper
INFO - 2020-02-20 15:22:16 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:22:16 --> Helper loaded: email_helper
INFO - 2020-02-20 15:22:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:22:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:22:16 --> Parser Class Initialized
INFO - 2020-02-20 15:22:16 --> User Agent Class Initialized
INFO - 2020-02-20 15:22:16 --> Model Class Initialized
INFO - 2020-02-20 15:22:16 --> Database Driver Class Initialized
INFO - 2020-02-20 15:22:16 --> Model Class Initialized
DEBUG - 2020-02-20 15:22:16 --> Template Class Initialized
INFO - 2020-02-20 15:22:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:22:16 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:22:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:22:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:22:16 --> Encryption Class Initialized
INFO - 2020-02-20 15:22:16 --> Controller Class Initialized
DEBUG - 2020-02-20 15:22:16 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:22:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:22:16 --> Model Class Initialized
ERROR - 2020-02-20 15:22:16 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:22:16 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:22:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:22:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:22:17 --> Model Class Initialized
DEBUG - 2020-02-20 15:22:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:22:17 --> Model Class Initialized
DEBUG - 2020-02-20 15:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:22:17 --> Final output sent to browser
DEBUG - 2020-02-20 15:22:17 --> Total execution time: 0.7220
INFO - 2020-02-20 15:29:45 --> Config Class Initialized
INFO - 2020-02-20 15:29:45 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:29:45 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:29:45 --> Utf8 Class Initialized
INFO - 2020-02-20 15:29:45 --> URI Class Initialized
INFO - 2020-02-20 15:29:45 --> Router Class Initialized
INFO - 2020-02-20 15:29:45 --> Output Class Initialized
INFO - 2020-02-20 15:29:45 --> Security Class Initialized
DEBUG - 2020-02-20 15:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:29:45 --> CSRF cookie sent
INFO - 2020-02-20 15:29:45 --> Input Class Initialized
INFO - 2020-02-20 15:29:45 --> Language Class Initialized
INFO - 2020-02-20 15:29:45 --> Language Class Initialized
INFO - 2020-02-20 15:29:45 --> Config Class Initialized
INFO - 2020-02-20 15:29:45 --> Loader Class Initialized
INFO - 2020-02-20 15:29:45 --> Helper loaded: url_helper
INFO - 2020-02-20 15:29:45 --> Helper loaded: common_helper
INFO - 2020-02-20 15:29:45 --> Helper loaded: language_helper
INFO - 2020-02-20 15:29:45 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:29:45 --> Helper loaded: email_helper
INFO - 2020-02-20 15:29:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:29:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:29:45 --> Parser Class Initialized
INFO - 2020-02-20 15:29:45 --> User Agent Class Initialized
INFO - 2020-02-20 15:29:45 --> Model Class Initialized
INFO - 2020-02-20 15:29:45 --> Database Driver Class Initialized
INFO - 2020-02-20 15:29:45 --> Model Class Initialized
DEBUG - 2020-02-20 15:29:45 --> Template Class Initialized
INFO - 2020-02-20 15:29:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:29:45 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:29:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:29:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:29:45 --> Encryption Class Initialized
INFO - 2020-02-20 15:29:45 --> Controller Class Initialized
DEBUG - 2020-02-20 15:29:45 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:29:45 --> Model Class Initialized
ERROR - 2020-02-20 15:29:45 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:29:45 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 15:29:45 --> Could not find the language line "Delele"
DEBUG - 2020-02-20 15:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-20 15:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:29:45 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:29:45 --> Model Class Initialized
DEBUG - 2020-02-20 15:29:45 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:29:45 --> Model Class Initialized
DEBUG - 2020-02-20 15:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:29:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:29:45 --> Final output sent to browser
DEBUG - 2020-02-20 15:29:45 --> Total execution time: 0.7323
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:29:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:29:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:29:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:29:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:29:46 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:29:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:29:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:29:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:29:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:29:46 --> Utf8 Class Initialized
DEBUG - 2020-02-20 15:29:46 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:29:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:29:46 --> URI Class Initialized
INFO - 2020-02-20 15:29:46 --> URI Class Initialized
INFO - 2020-02-20 15:29:46 --> URI Class Initialized
INFO - 2020-02-20 15:29:46 --> URI Class Initialized
INFO - 2020-02-20 15:29:46 --> URI Class Initialized
INFO - 2020-02-20 15:29:46 --> URI Class Initialized
INFO - 2020-02-20 15:29:46 --> Router Class Initialized
INFO - 2020-02-20 15:29:46 --> Router Class Initialized
INFO - 2020-02-20 15:29:46 --> Router Class Initialized
INFO - 2020-02-20 15:29:46 --> Router Class Initialized
INFO - 2020-02-20 15:29:46 --> Router Class Initialized
INFO - 2020-02-20 15:29:46 --> Output Class Initialized
INFO - 2020-02-20 15:29:46 --> Output Class Initialized
INFO - 2020-02-20 15:29:46 --> Output Class Initialized
INFO - 2020-02-20 15:29:46 --> Output Class Initialized
INFO - 2020-02-20 15:29:46 --> Output Class Initialized
INFO - 2020-02-20 15:29:46 --> Router Class Initialized
INFO - 2020-02-20 15:29:46 --> Security Class Initialized
INFO - 2020-02-20 15:29:46 --> Security Class Initialized
INFO - 2020-02-20 15:29:46 --> Security Class Initialized
INFO - 2020-02-20 15:29:46 --> Security Class Initialized
INFO - 2020-02-20 15:29:46 --> Output Class Initialized
INFO - 2020-02-20 15:29:46 --> Security Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:29:46 --> Security Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:29:46 --> CSRF cookie sent
INFO - 2020-02-20 15:29:46 --> CSRF cookie sent
INFO - 2020-02-20 15:29:46 --> CSRF cookie sent
INFO - 2020-02-20 15:29:46 --> CSRF cookie sent
INFO - 2020-02-20 15:29:46 --> CSRF cookie sent
DEBUG - 2020-02-20 15:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:29:46 --> CSRF token verified
INFO - 2020-02-20 15:29:46 --> CSRF token verified
INFO - 2020-02-20 15:29:46 --> CSRF token verified
INFO - 2020-02-20 15:29:46 --> CSRF cookie sent
INFO - 2020-02-20 15:29:46 --> CSRF token verified
INFO - 2020-02-20 15:29:46 --> CSRF token verified
INFO - 2020-02-20 15:29:46 --> Input Class Initialized
INFO - 2020-02-20 15:29:46 --> CSRF token verified
INFO - 2020-02-20 15:29:46 --> Input Class Initialized
INFO - 2020-02-20 15:29:46 --> Input Class Initialized
INFO - 2020-02-20 15:29:46 --> Input Class Initialized
INFO - 2020-02-20 15:29:46 --> Input Class Initialized
INFO - 2020-02-20 15:29:46 --> Input Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Loader Class Initialized
INFO - 2020-02-20 15:29:46 --> Loader Class Initialized
INFO - 2020-02-20 15:29:46 --> Loader Class Initialized
INFO - 2020-02-20 15:29:46 --> Loader Class Initialized
INFO - 2020-02-20 15:29:46 --> Loader Class Initialized
INFO - 2020-02-20 15:29:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:29:46 --> Loader Class Initialized
INFO - 2020-02-20 15:29:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:29:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:29:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:29:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:29:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:29:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:29:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:29:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:29:46 --> Parser Class Initialized
INFO - 2020-02-20 15:29:46 --> Parser Class Initialized
INFO - 2020-02-20 15:29:46 --> Parser Class Initialized
INFO - 2020-02-20 15:29:46 --> Parser Class Initialized
INFO - 2020-02-20 15:29:46 --> Parser Class Initialized
INFO - 2020-02-20 15:29:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:29:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:29:46 --> Parser Class Initialized
INFO - 2020-02-20 15:29:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:29:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:29:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:29:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:29:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:29:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:29:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
INFO - 2020-02-20 15:29:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Template Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Template Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Template Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Template Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Template Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Template Class Initialized
INFO - 2020-02-20 15:29:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:29:46 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:29:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:29:46 --> Encryption Class Initialized
INFO - 2020-02-20 15:29:46 --> Controller Class Initialized
DEBUG - 2020-02-20 15:29:46 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:29:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "View"
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "View"
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:29:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:29:46 --> Final output sent to browser
DEBUG - 2020-02-20 15:29:46 --> Total execution time: 0.5720
INFO - 2020-02-20 15:29:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
INFO - 2020-02-20 15:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:29:46 --> Pagination Class Initialized
INFO - 2020-02-20 15:29:46 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-02-20 15:29:46 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:29:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:29:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:29:46 --> Encryption Class Initialized
INFO - 2020-02-20 15:29:46 --> URI Class Initialized
INFO - 2020-02-20 15:29:46 --> Controller Class Initialized
INFO - 2020-02-20 15:29:46 --> Router Class Initialized
DEBUG - 2020-02-20 15:29:46 --> category MX_Controller Initialized
INFO - 2020-02-20 15:29:46 --> Output Class Initialized
INFO - 2020-02-20 15:29:46 --> Security Class Initialized
DEBUG - 2020-02-20 15:29:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:29:46 --> Model Class Initialized
DEBUG - 2020-02-20 15:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:29:46 --> CSRF cookie sent
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:29:46 --> CSRF token verified
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "View"
INFO - 2020-02-20 15:29:46 --> Input Class Initialized
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "View"
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "View"
INFO - 2020-02-20 15:29:46 --> Language Class Initialized
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "View"
INFO - 2020-02-20 15:29:46 --> Config Class Initialized
ERROR - 2020-02-20 15:29:46 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:29:47 --> Loader Class Initialized
INFO - 2020-02-20 15:29:47 --> Final output sent to browser
INFO - 2020-02-20 15:29:47 --> Helper loaded: url_helper
DEBUG - 2020-02-20 15:29:47 --> Total execution time: 0.8060
INFO - 2020-02-20 15:29:47 --> Helper loaded: common_helper
INFO - 2020-02-20 15:29:47 --> Helper loaded: language_helper
INFO - 2020-02-20 15:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:29:47 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:29:47 --> Pagination Class Initialized
INFO - 2020-02-20 15:29:47 --> Helper loaded: email_helper
INFO - 2020-02-20 15:29:47 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-20 15:29:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:29:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:29:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:29:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:29:47 --> Parser Class Initialized
INFO - 2020-02-20 15:29:47 --> Controller Class Initialized
INFO - 2020-02-20 15:29:47 --> User Agent Class Initialized
DEBUG - 2020-02-20 15:29:47 --> category MX_Controller Initialized
INFO - 2020-02-20 15:29:47 --> Model Class Initialized
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:29:47 --> Database Driver Class Initialized
INFO - 2020-02-20 15:29:47 --> Model Class Initialized
INFO - 2020-02-20 15:29:47 --> Model Class Initialized
DEBUG - 2020-02-20 15:29:47 --> Template Class Initialized
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:29:47 --> Final output sent to browser
DEBUG - 2020-02-20 15:29:47 --> Total execution time: 0.9696
INFO - 2020-02-20 15:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:29:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:29:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:29:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:29:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:29:47 --> Controller Class Initialized
DEBUG - 2020-02-20 15:29:47 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:29:47 --> Model Class Initialized
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:29:47 --> Final output sent to browser
DEBUG - 2020-02-20 15:29:47 --> Total execution time: 1.1411
INFO - 2020-02-20 15:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:29:47 --> Config Class Initialized
INFO - 2020-02-20 15:29:47 --> Hooks Class Initialized
INFO - 2020-02-20 15:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:29:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:29:47 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:29:47 --> Utf8 Class Initialized
DEBUG - 2020-02-20 15:29:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:29:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:29:47 --> URI Class Initialized
INFO - 2020-02-20 15:29:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:29:47 --> Router Class Initialized
INFO - 2020-02-20 15:29:47 --> Controller Class Initialized
INFO - 2020-02-20 15:29:47 --> Output Class Initialized
DEBUG - 2020-02-20 15:29:47 --> category MX_Controller Initialized
INFO - 2020-02-20 15:29:47 --> Security Class Initialized
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
DEBUG - 2020-02-20 15:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:29:47 --> CSRF cookie sent
INFO - 2020-02-20 15:29:47 --> Model Class Initialized
INFO - 2020-02-20 15:29:47 --> Input Class Initialized
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:29:47 --> Language Class Initialized
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "View"
INFO - 2020-02-20 15:29:47 --> Language Class Initialized
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "View"
INFO - 2020-02-20 15:29:47 --> Config Class Initialized
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:29:47 --> Loader Class Initialized
INFO - 2020-02-20 15:29:47 --> Final output sent to browser
INFO - 2020-02-20 15:29:47 --> Helper loaded: url_helper
DEBUG - 2020-02-20 15:29:47 --> Total execution time: 1.3241
INFO - 2020-02-20 15:29:47 --> Helper loaded: common_helper
INFO - 2020-02-20 15:29:47 --> Helper loaded: language_helper
INFO - 2020-02-20 15:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:29:47 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:29:47 --> Pagination Class Initialized
INFO - 2020-02-20 15:29:47 --> Helper loaded: email_helper
INFO - 2020-02-20 15:29:47 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-20 15:29:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:29:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:29:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:29:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:29:47 --> Parser Class Initialized
INFO - 2020-02-20 15:29:47 --> Controller Class Initialized
INFO - 2020-02-20 15:29:47 --> User Agent Class Initialized
DEBUG - 2020-02-20 15:29:47 --> category MX_Controller Initialized
INFO - 2020-02-20 15:29:47 --> Model Class Initialized
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:29:47 --> Database Driver Class Initialized
INFO - 2020-02-20 15:29:47 --> Model Class Initialized
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:29:47 --> Model Class Initialized
DEBUG - 2020-02-20 15:29:47 --> Template Class Initialized
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:29:47 --> Final output sent to browser
DEBUG - 2020-02-20 15:29:47 --> Total execution time: 1.4776
INFO - 2020-02-20 15:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:29:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:29:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:29:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:29:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:29:47 --> Controller Class Initialized
DEBUG - 2020-02-20 15:29:47 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:29:47 --> Model Class Initialized
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:29:47 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:29:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:29:47 --> Final output sent to browser
DEBUG - 2020-02-20 15:29:47 --> Total execution time: 1.0483
INFO - 2020-02-20 15:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:29:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:29:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:29:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:29:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:29:47 --> Controller Class Initialized
ERROR - 2020-02-20 15:29:47 --> 404 Page Not Found: ../modules/category/controllers/category/add
INFO - 2020-02-20 15:30:25 --> Config Class Initialized
INFO - 2020-02-20 15:30:25 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:30:25 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:30:25 --> Utf8 Class Initialized
INFO - 2020-02-20 15:30:25 --> URI Class Initialized
INFO - 2020-02-20 15:30:25 --> Router Class Initialized
INFO - 2020-02-20 15:30:25 --> Output Class Initialized
INFO - 2020-02-20 15:30:25 --> Security Class Initialized
DEBUG - 2020-02-20 15:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:30:25 --> CSRF cookie sent
INFO - 2020-02-20 15:30:25 --> Input Class Initialized
INFO - 2020-02-20 15:30:25 --> Language Class Initialized
INFO - 2020-02-20 15:30:25 --> Language Class Initialized
INFO - 2020-02-20 15:30:25 --> Config Class Initialized
INFO - 2020-02-20 15:30:25 --> Loader Class Initialized
INFO - 2020-02-20 15:30:25 --> Helper loaded: url_helper
INFO - 2020-02-20 15:30:25 --> Helper loaded: common_helper
INFO - 2020-02-20 15:30:25 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:25 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:25 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:30:25 --> Parser Class Initialized
INFO - 2020-02-20 15:30:25 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:25 --> Model Class Initialized
INFO - 2020-02-20 15:30:25 --> Database Driver Class Initialized
INFO - 2020-02-20 15:30:25 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:25 --> Template Class Initialized
INFO - 2020-02-20 15:30:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:25 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:30:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:25 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:25 --> Controller Class Initialized
DEBUG - 2020-02-20 15:30:25 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:30:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:25 --> Model Class Initialized
ERROR - 2020-02-20 15:30:26 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:30:26 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 15:30:26 --> Could not find the language line "Delele"
DEBUG - 2020-02-20 15:30:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-20 15:30:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:30:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:30:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:30:26 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:26 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:30:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:30:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:30:26 --> Final output sent to browser
DEBUG - 2020-02-20 15:30:26 --> Total execution time: 0.7312
INFO - 2020-02-20 15:30:26 --> Config Class Initialized
INFO - 2020-02-20 15:30:26 --> Config Class Initialized
INFO - 2020-02-20 15:30:26 --> Config Class Initialized
INFO - 2020-02-20 15:30:26 --> Config Class Initialized
INFO - 2020-02-20 15:30:26 --> Config Class Initialized
INFO - 2020-02-20 15:30:27 --> Config Class Initialized
INFO - 2020-02-20 15:30:27 --> Hooks Class Initialized
INFO - 2020-02-20 15:30:27 --> Hooks Class Initialized
INFO - 2020-02-20 15:30:27 --> Hooks Class Initialized
INFO - 2020-02-20 15:30:27 --> Hooks Class Initialized
INFO - 2020-02-20 15:30:27 --> Hooks Class Initialized
INFO - 2020-02-20 15:30:27 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:30:27 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:30:27 --> Utf8 Class Initialized
INFO - 2020-02-20 15:30:27 --> Utf8 Class Initialized
INFO - 2020-02-20 15:30:27 --> Utf8 Class Initialized
INFO - 2020-02-20 15:30:27 --> Utf8 Class Initialized
INFO - 2020-02-20 15:30:27 --> Utf8 Class Initialized
INFO - 2020-02-20 15:30:27 --> Utf8 Class Initialized
INFO - 2020-02-20 15:30:27 --> URI Class Initialized
INFO - 2020-02-20 15:30:27 --> URI Class Initialized
INFO - 2020-02-20 15:30:27 --> URI Class Initialized
INFO - 2020-02-20 15:30:27 --> URI Class Initialized
INFO - 2020-02-20 15:30:27 --> URI Class Initialized
INFO - 2020-02-20 15:30:27 --> URI Class Initialized
INFO - 2020-02-20 15:30:27 --> Router Class Initialized
INFO - 2020-02-20 15:30:27 --> Router Class Initialized
INFO - 2020-02-20 15:30:27 --> Router Class Initialized
INFO - 2020-02-20 15:30:27 --> Router Class Initialized
INFO - 2020-02-20 15:30:27 --> Router Class Initialized
INFO - 2020-02-20 15:30:27 --> Router Class Initialized
INFO - 2020-02-20 15:30:27 --> Output Class Initialized
INFO - 2020-02-20 15:30:27 --> Output Class Initialized
INFO - 2020-02-20 15:30:27 --> Output Class Initialized
INFO - 2020-02-20 15:30:27 --> Output Class Initialized
INFO - 2020-02-20 15:30:27 --> Output Class Initialized
INFO - 2020-02-20 15:30:27 --> Output Class Initialized
INFO - 2020-02-20 15:30:27 --> Security Class Initialized
INFO - 2020-02-20 15:30:27 --> Security Class Initialized
INFO - 2020-02-20 15:30:27 --> Security Class Initialized
INFO - 2020-02-20 15:30:27 --> Security Class Initialized
INFO - 2020-02-20 15:30:27 --> Security Class Initialized
INFO - 2020-02-20 15:30:27 --> Security Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:30:27 --> CSRF cookie sent
INFO - 2020-02-20 15:30:27 --> CSRF cookie sent
INFO - 2020-02-20 15:30:27 --> CSRF cookie sent
INFO - 2020-02-20 15:30:27 --> CSRF cookie sent
INFO - 2020-02-20 15:30:27 --> CSRF cookie sent
INFO - 2020-02-20 15:30:27 --> CSRF cookie sent
INFO - 2020-02-20 15:30:27 --> CSRF token verified
INFO - 2020-02-20 15:30:27 --> CSRF token verified
INFO - 2020-02-20 15:30:27 --> CSRF token verified
INFO - 2020-02-20 15:30:27 --> CSRF token verified
INFO - 2020-02-20 15:30:27 --> CSRF token verified
INFO - 2020-02-20 15:30:27 --> CSRF token verified
INFO - 2020-02-20 15:30:27 --> Input Class Initialized
INFO - 2020-02-20 15:30:27 --> Input Class Initialized
INFO - 2020-02-20 15:30:27 --> Input Class Initialized
INFO - 2020-02-20 15:30:27 --> Input Class Initialized
INFO - 2020-02-20 15:30:27 --> Input Class Initialized
INFO - 2020-02-20 15:30:27 --> Input Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
INFO - 2020-02-20 15:30:27 --> Config Class Initialized
INFO - 2020-02-20 15:30:27 --> Config Class Initialized
INFO - 2020-02-20 15:30:27 --> Config Class Initialized
INFO - 2020-02-20 15:30:27 --> Config Class Initialized
INFO - 2020-02-20 15:30:27 --> Config Class Initialized
INFO - 2020-02-20 15:30:27 --> Config Class Initialized
INFO - 2020-02-20 15:30:27 --> Loader Class Initialized
INFO - 2020-02-20 15:30:27 --> Loader Class Initialized
INFO - 2020-02-20 15:30:27 --> Loader Class Initialized
INFO - 2020-02-20 15:30:27 --> Loader Class Initialized
INFO - 2020-02-20 15:30:27 --> Loader Class Initialized
INFO - 2020-02-20 15:30:27 --> Loader Class Initialized
INFO - 2020-02-20 15:30:27 --> Helper loaded: url_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: url_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: url_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: url_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: url_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: url_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: common_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: common_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: common_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: common_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: common_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: common_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:30:27 --> Parser Class Initialized
INFO - 2020-02-20 15:30:27 --> Parser Class Initialized
INFO - 2020-02-20 15:30:27 --> Parser Class Initialized
INFO - 2020-02-20 15:30:27 --> Parser Class Initialized
INFO - 2020-02-20 15:30:27 --> Parser Class Initialized
INFO - 2020-02-20 15:30:27 --> Parser Class Initialized
INFO - 2020-02-20 15:30:27 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:27 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:27 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:27 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:27 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:27 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Database Driver Class Initialized
INFO - 2020-02-20 15:30:27 --> Database Driver Class Initialized
INFO - 2020-02-20 15:30:27 --> Database Driver Class Initialized
INFO - 2020-02-20 15:30:27 --> Database Driver Class Initialized
INFO - 2020-02-20 15:30:27 --> Database Driver Class Initialized
INFO - 2020-02-20 15:30:27 --> Database Driver Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Template Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Template Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Template Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Template Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Template Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Template Class Initialized
INFO - 2020-02-20 15:30:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:27 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:27 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:27 --> Controller Class Initialized
DEBUG - 2020-02-20 15:30:27 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:30:27 --> Final output sent to browser
DEBUG - 2020-02-20 15:30:27 --> Total execution time: 0.6101
INFO - 2020-02-20 15:30:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:27 --> Config Class Initialized
INFO - 2020-02-20 15:30:27 --> Hooks Class Initialized
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:27 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:30:27 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:30:27 --> Utf8 Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:27 --> URI Class Initialized
INFO - 2020-02-20 15:30:27 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:27 --> Router Class Initialized
INFO - 2020-02-20 15:30:27 --> Controller Class Initialized
INFO - 2020-02-20 15:30:27 --> Output Class Initialized
DEBUG - 2020-02-20 15:30:27 --> category MX_Controller Initialized
INFO - 2020-02-20 15:30:27 --> Security Class Initialized
DEBUG - 2020-02-20 15:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
DEBUG - 2020-02-20 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> CSRF cookie sent
INFO - 2020-02-20 15:30:27 --> CSRF token verified
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:30:27 --> Input Class Initialized
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "View"
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "View"
INFO - 2020-02-20 15:30:27 --> Language Class Initialized
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "View"
INFO - 2020-02-20 15:30:27 --> Config Class Initialized
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "View"
INFO - 2020-02-20 15:30:27 --> Loader Class Initialized
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "View"
INFO - 2020-02-20 15:30:27 --> Helper loaded: url_helper
DEBUG - 2020-02-20 15:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:30:27 --> Final output sent to browser
INFO - 2020-02-20 15:30:27 --> Helper loaded: common_helper
DEBUG - 2020-02-20 15:30:27 --> Total execution time: 0.8286
INFO - 2020-02-20 15:30:27 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:27 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:27 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:27 --> Pagination Class Initialized
INFO - 2020-02-20 15:30:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:27 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-20 15:30:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:27 --> Parser Class Initialized
INFO - 2020-02-20 15:30:27 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:27 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:27 --> Controller Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:27 --> category MX_Controller Initialized
INFO - 2020-02-20 15:30:27 --> Database Driver Class Initialized
DEBUG - 2020-02-20 15:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
INFO - 2020-02-20 15:30:27 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:27 --> Template Class Initialized
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:30:27 --> Could not find the language line "View"
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "View"
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:30:28 --> Final output sent to browser
DEBUG - 2020-02-20 15:30:28 --> Total execution time: 1.0740
INFO - 2020-02-20 15:30:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:28 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:30:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:28 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:28 --> Controller Class Initialized
DEBUG - 2020-02-20 15:30:28 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:28 --> Model Class Initialized
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:30:28 --> Final output sent to browser
DEBUG - 2020-02-20 15:30:28 --> Total execution time: 1.2672
INFO - 2020-02-20 15:30:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:28 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:30:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:28 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:28 --> Controller Class Initialized
DEBUG - 2020-02-20 15:30:28 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:28 --> Model Class Initialized
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "View"
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "View"
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:30:28 --> Final output sent to browser
DEBUG - 2020-02-20 15:30:28 --> Total execution time: 1.4873
INFO - 2020-02-20 15:30:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:28 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:30:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:28 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:28 --> Controller Class Initialized
DEBUG - 2020-02-20 15:30:28 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:28 --> Model Class Initialized
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:30:28 --> Final output sent to browser
DEBUG - 2020-02-20 15:30:28 --> Total execution time: 1.6796
INFO - 2020-02-20 15:30:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:28 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:30:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:28 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:28 --> Controller Class Initialized
DEBUG - 2020-02-20 15:30:28 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:28 --> Model Class Initialized
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:30:28 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:30:28 --> Final output sent to browser
DEBUG - 2020-02-20 15:30:28 --> Total execution time: 1.2339
INFO - 2020-02-20 15:30:29 --> Config Class Initialized
INFO - 2020-02-20 15:30:29 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:30:29 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:30:29 --> Utf8 Class Initialized
INFO - 2020-02-20 15:30:29 --> URI Class Initialized
INFO - 2020-02-20 15:30:29 --> Router Class Initialized
INFO - 2020-02-20 15:30:29 --> Output Class Initialized
INFO - 2020-02-20 15:30:29 --> Security Class Initialized
DEBUG - 2020-02-20 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:30:29 --> CSRF cookie sent
INFO - 2020-02-20 15:30:29 --> Input Class Initialized
INFO - 2020-02-20 15:30:29 --> Language Class Initialized
INFO - 2020-02-20 15:30:29 --> Language Class Initialized
INFO - 2020-02-20 15:30:29 --> Config Class Initialized
INFO - 2020-02-20 15:30:29 --> Loader Class Initialized
INFO - 2020-02-20 15:30:29 --> Helper loaded: url_helper
INFO - 2020-02-20 15:30:29 --> Helper loaded: common_helper
INFO - 2020-02-20 15:30:29 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:29 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:29 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:29 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:30:29 --> Parser Class Initialized
INFO - 2020-02-20 15:30:29 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:29 --> Model Class Initialized
INFO - 2020-02-20 15:30:29 --> Database Driver Class Initialized
INFO - 2020-02-20 15:30:29 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:29 --> Template Class Initialized
INFO - 2020-02-20 15:30:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:29 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:30:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:29 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:29 --> Controller Class Initialized
DEBUG - 2020-02-20 15:30:29 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:30:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:29 --> Model Class Initialized
ERROR - 2020-02-20 15:30:29 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:30:29 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:30:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:30:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:30:29 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:30:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:30:29 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:29 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:29 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:30:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:30:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:30:29 --> Final output sent to browser
DEBUG - 2020-02-20 15:30:29 --> Total execution time: 0.6769
INFO - 2020-02-20 15:30:58 --> Config Class Initialized
INFO - 2020-02-20 15:30:58 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:30:58 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:30:58 --> Utf8 Class Initialized
INFO - 2020-02-20 15:30:58 --> URI Class Initialized
INFO - 2020-02-20 15:30:58 --> Router Class Initialized
INFO - 2020-02-20 15:30:58 --> Output Class Initialized
INFO - 2020-02-20 15:30:58 --> Security Class Initialized
DEBUG - 2020-02-20 15:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:30:58 --> CSRF cookie sent
INFO - 2020-02-20 15:30:58 --> Input Class Initialized
INFO - 2020-02-20 15:30:58 --> Language Class Initialized
INFO - 2020-02-20 15:30:58 --> Language Class Initialized
INFO - 2020-02-20 15:30:58 --> Config Class Initialized
INFO - 2020-02-20 15:30:58 --> Loader Class Initialized
INFO - 2020-02-20 15:30:58 --> Helper loaded: url_helper
INFO - 2020-02-20 15:30:58 --> Helper loaded: common_helper
INFO - 2020-02-20 15:30:58 --> Helper loaded: language_helper
INFO - 2020-02-20 15:30:58 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:30:58 --> Helper loaded: email_helper
INFO - 2020-02-20 15:30:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:30:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:30:59 --> Parser Class Initialized
INFO - 2020-02-20 15:30:59 --> User Agent Class Initialized
INFO - 2020-02-20 15:30:59 --> Model Class Initialized
INFO - 2020-02-20 15:30:59 --> Database Driver Class Initialized
INFO - 2020-02-20 15:30:59 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:59 --> Template Class Initialized
INFO - 2020-02-20 15:30:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:30:59 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:30:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:30:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:30:59 --> Encryption Class Initialized
INFO - 2020-02-20 15:30:59 --> Controller Class Initialized
DEBUG - 2020-02-20 15:30:59 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:30:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:59 --> Model Class Initialized
ERROR - 2020-02-20 15:30:59 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:30:59 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 15:30:59 --> Could not find the language line "Delele"
DEBUG - 2020-02-20 15:30:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-20 15:30:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:30:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:30:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:30:59 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:59 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:30:59 --> Model Class Initialized
DEBUG - 2020-02-20 15:30:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:30:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:30:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:30:59 --> Final output sent to browser
DEBUG - 2020-02-20 15:30:59 --> Total execution time: 0.7835
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Hooks Class Initialized
INFO - 2020-02-20 15:31:00 --> Hooks Class Initialized
INFO - 2020-02-20 15:31:00 --> Hooks Class Initialized
INFO - 2020-02-20 15:31:00 --> Hooks Class Initialized
INFO - 2020-02-20 15:31:00 --> Hooks Class Initialized
INFO - 2020-02-20 15:31:00 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:31:00 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:31:00 --> Utf8 Class Initialized
INFO - 2020-02-20 15:31:00 --> Utf8 Class Initialized
INFO - 2020-02-20 15:31:00 --> Utf8 Class Initialized
INFO - 2020-02-20 15:31:00 --> Utf8 Class Initialized
INFO - 2020-02-20 15:31:00 --> Utf8 Class Initialized
INFO - 2020-02-20 15:31:00 --> Utf8 Class Initialized
INFO - 2020-02-20 15:31:00 --> URI Class Initialized
INFO - 2020-02-20 15:31:00 --> URI Class Initialized
INFO - 2020-02-20 15:31:00 --> URI Class Initialized
INFO - 2020-02-20 15:31:00 --> URI Class Initialized
INFO - 2020-02-20 15:31:00 --> URI Class Initialized
INFO - 2020-02-20 15:31:00 --> URI Class Initialized
INFO - 2020-02-20 15:31:00 --> Router Class Initialized
INFO - 2020-02-20 15:31:00 --> Output Class Initialized
INFO - 2020-02-20 15:31:00 --> Router Class Initialized
INFO - 2020-02-20 15:31:00 --> Router Class Initialized
INFO - 2020-02-20 15:31:00 --> Router Class Initialized
INFO - 2020-02-20 15:31:00 --> Router Class Initialized
INFO - 2020-02-20 15:31:00 --> Router Class Initialized
INFO - 2020-02-20 15:31:00 --> Security Class Initialized
INFO - 2020-02-20 15:31:00 --> Output Class Initialized
INFO - 2020-02-20 15:31:00 --> Output Class Initialized
INFO - 2020-02-20 15:31:00 --> Output Class Initialized
INFO - 2020-02-20 15:31:00 --> Output Class Initialized
INFO - 2020-02-20 15:31:00 --> Output Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:31:00 --> Security Class Initialized
INFO - 2020-02-20 15:31:00 --> Security Class Initialized
INFO - 2020-02-20 15:31:00 --> Security Class Initialized
INFO - 2020-02-20 15:31:00 --> Security Class Initialized
INFO - 2020-02-20 15:31:00 --> Security Class Initialized
INFO - 2020-02-20 15:31:00 --> CSRF cookie sent
DEBUG - 2020-02-20 15:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:31:00 --> CSRF cookie sent
INFO - 2020-02-20 15:31:00 --> CSRF cookie sent
INFO - 2020-02-20 15:31:00 --> CSRF cookie sent
INFO - 2020-02-20 15:31:00 --> CSRF cookie sent
INFO - 2020-02-20 15:31:00 --> CSRF token verified
INFO - 2020-02-20 15:31:00 --> CSRF cookie sent
INFO - 2020-02-20 15:31:00 --> CSRF token verified
INFO - 2020-02-20 15:31:00 --> CSRF token verified
INFO - 2020-02-20 15:31:00 --> Input Class Initialized
INFO - 2020-02-20 15:31:00 --> CSRF token verified
INFO - 2020-02-20 15:31:00 --> CSRF token verified
INFO - 2020-02-20 15:31:00 --> CSRF token verified
INFO - 2020-02-20 15:31:00 --> Input Class Initialized
INFO - 2020-02-20 15:31:00 --> Input Class Initialized
INFO - 2020-02-20 15:31:00 --> Input Class Initialized
INFO - 2020-02-20 15:31:00 --> Input Class Initialized
INFO - 2020-02-20 15:31:00 --> Input Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Loader Class Initialized
INFO - 2020-02-20 15:31:00 --> Helper loaded: url_helper
INFO - 2020-02-20 15:31:00 --> Loader Class Initialized
INFO - 2020-02-20 15:31:00 --> Loader Class Initialized
INFO - 2020-02-20 15:31:00 --> Loader Class Initialized
INFO - 2020-02-20 15:31:00 --> Loader Class Initialized
INFO - 2020-02-20 15:31:00 --> Loader Class Initialized
INFO - 2020-02-20 15:31:00 --> Helper loaded: url_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: url_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: url_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: url_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: url_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: common_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: language_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: common_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: common_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: common_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: common_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: common_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: language_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: language_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: language_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: language_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: language_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: email_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: email_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: email_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: email_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: email_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: email_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:31:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:31:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:31:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:31:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:31:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:31:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:31:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:31:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:31:00 --> Parser Class Initialized
INFO - 2020-02-20 15:31:00 --> Parser Class Initialized
INFO - 2020-02-20 15:31:00 --> User Agent Class Initialized
INFO - 2020-02-20 15:31:00 --> Parser Class Initialized
INFO - 2020-02-20 15:31:00 --> Parser Class Initialized
INFO - 2020-02-20 15:31:00 --> Parser Class Initialized
INFO - 2020-02-20 15:31:00 --> Parser Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> User Agent Class Initialized
INFO - 2020-02-20 15:31:00 --> User Agent Class Initialized
INFO - 2020-02-20 15:31:00 --> User Agent Class Initialized
INFO - 2020-02-20 15:31:00 --> User Agent Class Initialized
INFO - 2020-02-20 15:31:00 --> User Agent Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Database Driver Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Database Driver Class Initialized
INFO - 2020-02-20 15:31:00 --> Database Driver Class Initialized
INFO - 2020-02-20 15:31:00 --> Database Driver Class Initialized
INFO - 2020-02-20 15:31:00 --> Database Driver Class Initialized
INFO - 2020-02-20 15:31:00 --> Database Driver Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Template Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Template Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Template Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Template Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Template Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Template Class Initialized
INFO - 2020-02-20 15:31:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:31:00 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:31:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:31:00 --> Encryption Class Initialized
INFO - 2020-02-20 15:31:00 --> Controller Class Initialized
DEBUG - 2020-02-20 15:31:00 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:31:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
ERROR - 2020-02-20 15:31:00 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:31:00 --> Could not find the language line "View"
ERROR - 2020-02-20 15:31:00 --> Could not find the language line "View"
ERROR - 2020-02-20 15:31:00 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:31:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:31:00 --> Final output sent to browser
DEBUG - 2020-02-20 15:31:00 --> Total execution time: 0.7447
INFO - 2020-02-20 15:31:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
INFO - 2020-02-20 15:31:00 --> Hooks Class Initialized
INFO - 2020-02-20 15:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:31:00 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:31:00 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:31:00 --> Utf8 Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:31:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:31:00 --> URI Class Initialized
INFO - 2020-02-20 15:31:00 --> Encryption Class Initialized
INFO - 2020-02-20 15:31:00 --> Router Class Initialized
INFO - 2020-02-20 15:31:00 --> Controller Class Initialized
INFO - 2020-02-20 15:31:00 --> Output Class Initialized
DEBUG - 2020-02-20 15:31:00 --> category MX_Controller Initialized
INFO - 2020-02-20 15:31:00 --> Security Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:31:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:31:00 --> Model Class Initialized
INFO - 2020-02-20 15:31:00 --> CSRF cookie sent
INFO - 2020-02-20 15:31:00 --> CSRF token verified
ERROR - 2020-02-20 15:31:00 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:31:00 --> Input Class Initialized
ERROR - 2020-02-20 15:31:00 --> Could not find the language line "View"
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
DEBUG - 2020-02-20 15:31:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:31:00 --> Final output sent to browser
INFO - 2020-02-20 15:31:00 --> Language Class Initialized
INFO - 2020-02-20 15:31:00 --> Config Class Initialized
DEBUG - 2020-02-20 15:31:00 --> Total execution time: 0.9176
INFO - 2020-02-20 15:31:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:31:00 --> Loader Class Initialized
INFO - 2020-02-20 15:31:00 --> Helper loaded: url_helper
INFO - 2020-02-20 15:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:31:01 --> Pagination Class Initialized
INFO - 2020-02-20 15:31:01 --> Helper loaded: common_helper
INFO - 2020-02-20 15:31:01 --> Helper loaded: language_helper
DEBUG - 2020-02-20 15:31:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:31:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:31:01 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:31:01 --> Encryption Class Initialized
INFO - 2020-02-20 15:31:01 --> Helper loaded: email_helper
INFO - 2020-02-20 15:31:01 --> Controller Class Initialized
INFO - 2020-02-20 15:31:01 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-20 15:31:01 --> category MX_Controller Initialized
INFO - 2020-02-20 15:31:01 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-20 15:31:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:31:01 --> Parser Class Initialized
INFO - 2020-02-20 15:31:01 --> Model Class Initialized
INFO - 2020-02-20 15:31:01 --> User Agent Class Initialized
INFO - 2020-02-20 15:31:01 --> Model Class Initialized
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:31:01 --> Database Driver Class Initialized
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:31:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:31:01 --> Model Class Initialized
INFO - 2020-02-20 15:31:01 --> Final output sent to browser
DEBUG - 2020-02-20 15:31:01 --> Template Class Initialized
DEBUG - 2020-02-20 15:31:01 --> Total execution time: 1.1295
INFO - 2020-02-20 15:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:31:01 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:31:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:31:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:31:01 --> Encryption Class Initialized
INFO - 2020-02-20 15:31:01 --> Controller Class Initialized
DEBUG - 2020-02-20 15:31:01 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:31:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:31:01 --> Model Class Initialized
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:31:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:31:01 --> Final output sent to browser
DEBUG - 2020-02-20 15:31:01 --> Total execution time: 1.4078
INFO - 2020-02-20 15:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:31:01 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:31:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:31:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:31:01 --> Encryption Class Initialized
INFO - 2020-02-20 15:31:01 --> Controller Class Initialized
DEBUG - 2020-02-20 15:31:01 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:31:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:31:01 --> Model Class Initialized
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:31:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:31:01 --> Final output sent to browser
DEBUG - 2020-02-20 15:31:01 --> Total execution time: 1.6027
INFO - 2020-02-20 15:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:31:01 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:31:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:31:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:31:01 --> Encryption Class Initialized
INFO - 2020-02-20 15:31:01 --> Controller Class Initialized
DEBUG - 2020-02-20 15:31:01 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:31:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:31:01 --> Model Class Initialized
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:31:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:31:01 --> Final output sent to browser
DEBUG - 2020-02-20 15:31:01 --> Total execution time: 1.8245
INFO - 2020-02-20 15:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:31:01 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:31:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:31:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:31:01 --> Encryption Class Initialized
INFO - 2020-02-20 15:31:01 --> Controller Class Initialized
DEBUG - 2020-02-20 15:31:01 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:31:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:31:01 --> Model Class Initialized
ERROR - 2020-02-20 15:31:01 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:31:02 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:31:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:31:02 --> Final output sent to browser
DEBUG - 2020-02-20 15:31:02 --> Total execution time: 1.2300
INFO - 2020-02-20 15:31:03 --> Config Class Initialized
INFO - 2020-02-20 15:31:03 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:31:03 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:31:03 --> Utf8 Class Initialized
INFO - 2020-02-20 15:31:03 --> URI Class Initialized
INFO - 2020-02-20 15:31:03 --> Router Class Initialized
INFO - 2020-02-20 15:31:03 --> Output Class Initialized
INFO - 2020-02-20 15:31:03 --> Security Class Initialized
DEBUG - 2020-02-20 15:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:31:03 --> CSRF cookie sent
INFO - 2020-02-20 15:31:03 --> Input Class Initialized
INFO - 2020-02-20 15:31:03 --> Language Class Initialized
INFO - 2020-02-20 15:31:03 --> Language Class Initialized
INFO - 2020-02-20 15:31:03 --> Config Class Initialized
INFO - 2020-02-20 15:31:03 --> Loader Class Initialized
INFO - 2020-02-20 15:31:03 --> Helper loaded: url_helper
INFO - 2020-02-20 15:31:03 --> Helper loaded: common_helper
INFO - 2020-02-20 15:31:03 --> Helper loaded: language_helper
INFO - 2020-02-20 15:31:03 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:31:03 --> Helper loaded: email_helper
INFO - 2020-02-20 15:31:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:31:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:31:03 --> Parser Class Initialized
INFO - 2020-02-20 15:31:03 --> User Agent Class Initialized
INFO - 2020-02-20 15:31:03 --> Model Class Initialized
INFO - 2020-02-20 15:31:03 --> Database Driver Class Initialized
INFO - 2020-02-20 15:31:03 --> Model Class Initialized
DEBUG - 2020-02-20 15:31:03 --> Template Class Initialized
INFO - 2020-02-20 15:31:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:31:03 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:31:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:31:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:31:03 --> Encryption Class Initialized
INFO - 2020-02-20 15:31:03 --> Controller Class Initialized
DEBUG - 2020-02-20 15:31:03 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:31:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:31:03 --> Model Class Initialized
ERROR - 2020-02-20 15:31:03 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:31:04 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:31:04 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:31:04 --> Model Class Initialized
DEBUG - 2020-02-20 15:31:04 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:31:04 --> Model Class Initialized
DEBUG - 2020-02-20 15:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:31:04 --> Final output sent to browser
DEBUG - 2020-02-20 15:31:04 --> Total execution time: 1.1132
INFO - 2020-02-20 15:37:16 --> Config Class Initialized
INFO - 2020-02-20 15:37:16 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:37:16 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:37:16 --> Utf8 Class Initialized
INFO - 2020-02-20 15:37:16 --> URI Class Initialized
INFO - 2020-02-20 15:37:16 --> Router Class Initialized
INFO - 2020-02-20 15:37:16 --> Output Class Initialized
INFO - 2020-02-20 15:37:16 --> Security Class Initialized
DEBUG - 2020-02-20 15:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:37:16 --> CSRF cookie sent
INFO - 2020-02-20 15:37:16 --> Input Class Initialized
INFO - 2020-02-20 15:37:16 --> Language Class Initialized
INFO - 2020-02-20 15:37:16 --> Language Class Initialized
INFO - 2020-02-20 15:37:16 --> Config Class Initialized
INFO - 2020-02-20 15:37:16 --> Loader Class Initialized
INFO - 2020-02-20 15:37:16 --> Helper loaded: url_helper
INFO - 2020-02-20 15:37:16 --> Helper loaded: common_helper
INFO - 2020-02-20 15:37:16 --> Helper loaded: language_helper
INFO - 2020-02-20 15:37:16 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:37:16 --> Helper loaded: email_helper
INFO - 2020-02-20 15:37:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:37:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:37:16 --> Parser Class Initialized
INFO - 2020-02-20 15:37:16 --> User Agent Class Initialized
INFO - 2020-02-20 15:37:16 --> Model Class Initialized
INFO - 2020-02-20 15:37:16 --> Database Driver Class Initialized
INFO - 2020-02-20 15:37:16 --> Model Class Initialized
DEBUG - 2020-02-20 15:37:16 --> Template Class Initialized
INFO - 2020-02-20 15:37:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:37:16 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:37:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:37:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:37:16 --> Encryption Class Initialized
INFO - 2020-02-20 15:37:16 --> Controller Class Initialized
DEBUG - 2020-02-20 15:37:16 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:37:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:37:16 --> Model Class Initialized
ERROR - 2020-02-20 15:37:16 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:37:16 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:37:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:37:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:37:16 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:37:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:37:16 --> Model Class Initialized
DEBUG - 2020-02-20 15:37:16 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:37:16 --> Model Class Initialized
DEBUG - 2020-02-20 15:37:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:37:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:37:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:37:17 --> Final output sent to browser
DEBUG - 2020-02-20 15:37:17 --> Total execution time: 0.7714
INFO - 2020-02-20 15:42:17 --> Config Class Initialized
INFO - 2020-02-20 15:42:17 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:42:17 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:42:17 --> Utf8 Class Initialized
INFO - 2020-02-20 15:42:17 --> URI Class Initialized
INFO - 2020-02-20 15:42:17 --> Router Class Initialized
INFO - 2020-02-20 15:42:17 --> Output Class Initialized
INFO - 2020-02-20 15:42:17 --> Security Class Initialized
DEBUG - 2020-02-20 15:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:42:17 --> CSRF cookie sent
INFO - 2020-02-20 15:42:17 --> Input Class Initialized
INFO - 2020-02-20 15:42:17 --> Language Class Initialized
INFO - 2020-02-20 15:42:17 --> Language Class Initialized
INFO - 2020-02-20 15:42:17 --> Config Class Initialized
INFO - 2020-02-20 15:42:17 --> Loader Class Initialized
INFO - 2020-02-20 15:42:17 --> Helper loaded: url_helper
INFO - 2020-02-20 15:42:17 --> Helper loaded: common_helper
INFO - 2020-02-20 15:42:17 --> Helper loaded: language_helper
INFO - 2020-02-20 15:42:17 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:42:17 --> Helper loaded: email_helper
INFO - 2020-02-20 15:42:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:42:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:42:17 --> Parser Class Initialized
INFO - 2020-02-20 15:42:17 --> User Agent Class Initialized
INFO - 2020-02-20 15:42:17 --> Model Class Initialized
INFO - 2020-02-20 15:42:17 --> Database Driver Class Initialized
INFO - 2020-02-20 15:42:17 --> Model Class Initialized
DEBUG - 2020-02-20 15:42:17 --> Template Class Initialized
INFO - 2020-02-20 15:42:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:42:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:42:17 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:42:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:42:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:42:17 --> Encryption Class Initialized
INFO - 2020-02-20 15:42:17 --> Controller Class Initialized
DEBUG - 2020-02-20 15:42:17 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:42:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:42:17 --> Model Class Initialized
ERROR - 2020-02-20 15:42:17 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:42:18 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:42:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:42:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:42:18 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:42:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:42:18 --> Model Class Initialized
DEBUG - 2020-02-20 15:42:18 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:42:18 --> Model Class Initialized
DEBUG - 2020-02-20 15:42:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:42:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:42:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:42:18 --> Final output sent to browser
DEBUG - 2020-02-20 15:42:18 --> Total execution time: 0.7496
INFO - 2020-02-20 15:43:27 --> Config Class Initialized
INFO - 2020-02-20 15:43:27 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:43:27 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:43:27 --> Utf8 Class Initialized
INFO - 2020-02-20 15:43:27 --> URI Class Initialized
INFO - 2020-02-20 15:43:27 --> Router Class Initialized
INFO - 2020-02-20 15:43:27 --> Output Class Initialized
INFO - 2020-02-20 15:43:28 --> Security Class Initialized
DEBUG - 2020-02-20 15:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:43:28 --> CSRF cookie sent
INFO - 2020-02-20 15:43:28 --> Input Class Initialized
INFO - 2020-02-20 15:43:28 --> Language Class Initialized
INFO - 2020-02-20 15:43:28 --> Language Class Initialized
INFO - 2020-02-20 15:43:28 --> Config Class Initialized
INFO - 2020-02-20 15:43:28 --> Loader Class Initialized
INFO - 2020-02-20 15:43:28 --> Helper loaded: url_helper
INFO - 2020-02-20 15:43:28 --> Helper loaded: common_helper
INFO - 2020-02-20 15:43:28 --> Helper loaded: language_helper
INFO - 2020-02-20 15:43:28 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:43:28 --> Helper loaded: email_helper
INFO - 2020-02-20 15:43:28 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:43:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:43:28 --> Parser Class Initialized
INFO - 2020-02-20 15:43:28 --> User Agent Class Initialized
INFO - 2020-02-20 15:43:28 --> Model Class Initialized
INFO - 2020-02-20 15:43:28 --> Database Driver Class Initialized
INFO - 2020-02-20 15:43:28 --> Model Class Initialized
DEBUG - 2020-02-20 15:43:28 --> Template Class Initialized
INFO - 2020-02-20 15:43:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:43:28 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:43:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:43:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:43:28 --> Encryption Class Initialized
INFO - 2020-02-20 15:43:28 --> Controller Class Initialized
DEBUG - 2020-02-20 15:43:28 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:43:28 --> Model Class Initialized
ERROR - 2020-02-20 15:43:28 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:43:28 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:43:28 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:43:28 --> Model Class Initialized
DEBUG - 2020-02-20 15:43:28 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:43:28 --> Model Class Initialized
DEBUG - 2020-02-20 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:43:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:43:28 --> Final output sent to browser
DEBUG - 2020-02-20 15:43:28 --> Total execution time: 0.7364
INFO - 2020-02-20 15:43:54 --> Config Class Initialized
INFO - 2020-02-20 15:43:54 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:43:54 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:43:54 --> Utf8 Class Initialized
INFO - 2020-02-20 15:43:54 --> URI Class Initialized
INFO - 2020-02-20 15:43:54 --> Router Class Initialized
INFO - 2020-02-20 15:43:54 --> Output Class Initialized
INFO - 2020-02-20 15:43:54 --> Security Class Initialized
DEBUG - 2020-02-20 15:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:43:54 --> CSRF cookie sent
INFO - 2020-02-20 15:43:54 --> Input Class Initialized
INFO - 2020-02-20 15:43:54 --> Language Class Initialized
INFO - 2020-02-20 15:43:54 --> Language Class Initialized
INFO - 2020-02-20 15:43:54 --> Config Class Initialized
INFO - 2020-02-20 15:43:54 --> Loader Class Initialized
INFO - 2020-02-20 15:43:54 --> Helper loaded: url_helper
INFO - 2020-02-20 15:43:54 --> Helper loaded: common_helper
INFO - 2020-02-20 15:43:54 --> Helper loaded: language_helper
INFO - 2020-02-20 15:43:54 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:43:54 --> Helper loaded: email_helper
INFO - 2020-02-20 15:43:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:43:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:43:54 --> Parser Class Initialized
INFO - 2020-02-20 15:43:54 --> User Agent Class Initialized
INFO - 2020-02-20 15:43:54 --> Model Class Initialized
INFO - 2020-02-20 15:43:54 --> Database Driver Class Initialized
INFO - 2020-02-20 15:43:54 --> Model Class Initialized
DEBUG - 2020-02-20 15:43:54 --> Template Class Initialized
INFO - 2020-02-20 15:43:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:43:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:43:54 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:43:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:43:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:43:54 --> Encryption Class Initialized
INFO - 2020-02-20 15:43:54 --> Controller Class Initialized
DEBUG - 2020-02-20 15:43:54 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:43:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:43:54 --> Model Class Initialized
ERROR - 2020-02-20 15:43:54 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:43:55 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:43:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:43:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:43:55 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:43:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:43:55 --> Model Class Initialized
DEBUG - 2020-02-20 15:43:55 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:43:55 --> Model Class Initialized
DEBUG - 2020-02-20 15:43:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:43:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:43:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:43:55 --> Final output sent to browser
DEBUG - 2020-02-20 15:43:55 --> Total execution time: 0.7233
INFO - 2020-02-20 15:44:21 --> Config Class Initialized
INFO - 2020-02-20 15:44:21 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:44:21 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:44:21 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:21 --> URI Class Initialized
INFO - 2020-02-20 15:44:21 --> Router Class Initialized
INFO - 2020-02-20 15:44:21 --> Output Class Initialized
INFO - 2020-02-20 15:44:21 --> Security Class Initialized
DEBUG - 2020-02-20 15:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:44:21 --> CSRF cookie sent
INFO - 2020-02-20 15:44:21 --> Input Class Initialized
INFO - 2020-02-20 15:44:21 --> Language Class Initialized
INFO - 2020-02-20 15:44:21 --> Language Class Initialized
INFO - 2020-02-20 15:44:21 --> Config Class Initialized
INFO - 2020-02-20 15:44:21 --> Loader Class Initialized
INFO - 2020-02-20 15:44:21 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:21 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:21 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:21 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:21 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:21 --> Parser Class Initialized
INFO - 2020-02-20 15:44:21 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:21 --> Model Class Initialized
INFO - 2020-02-20 15:44:21 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:21 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:21 --> Template Class Initialized
INFO - 2020-02-20 15:44:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:21 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:21 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:21 --> Controller Class Initialized
DEBUG - 2020-02-20 15:44:21 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:44:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:21 --> Model Class Initialized
ERROR - 2020-02-20 15:44:21 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:44:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:44:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:44:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:44:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:44:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:44:21 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:21 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:44:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:44:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:44:21 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:21 --> Total execution time: 0.7711
INFO - 2020-02-20 15:44:42 --> Config Class Initialized
INFO - 2020-02-20 15:44:42 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:44:42 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:44:42 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:42 --> URI Class Initialized
INFO - 2020-02-20 15:44:42 --> Router Class Initialized
INFO - 2020-02-20 15:44:42 --> Output Class Initialized
INFO - 2020-02-20 15:44:42 --> Security Class Initialized
DEBUG - 2020-02-20 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:44:42 --> CSRF cookie sent
INFO - 2020-02-20 15:44:42 --> Input Class Initialized
INFO - 2020-02-20 15:44:42 --> Language Class Initialized
INFO - 2020-02-20 15:44:42 --> Language Class Initialized
INFO - 2020-02-20 15:44:42 --> Config Class Initialized
INFO - 2020-02-20 15:44:42 --> Loader Class Initialized
INFO - 2020-02-20 15:44:42 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:42 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:42 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:42 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:42 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:42 --> Parser Class Initialized
INFO - 2020-02-20 15:44:42 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:42 --> Model Class Initialized
INFO - 2020-02-20 15:44:42 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:42 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:42 --> Template Class Initialized
INFO - 2020-02-20 15:44:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:42 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:42 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:42 --> Controller Class Initialized
DEBUG - 2020-02-20 15:44:42 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:44:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:42 --> Model Class Initialized
ERROR - 2020-02-20 15:44:42 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:44:42 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:44:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/add.php
DEBUG - 2020-02-20 15:44:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:44:42 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:44:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:44:42 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:42 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:42 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:44:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:44:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:44:43 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:43 --> Total execution time: 0.8101
INFO - 2020-02-20 15:44:45 --> Config Class Initialized
INFO - 2020-02-20 15:44:45 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:44:45 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:44:45 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:45 --> URI Class Initialized
INFO - 2020-02-20 15:44:45 --> Router Class Initialized
INFO - 2020-02-20 15:44:45 --> Output Class Initialized
INFO - 2020-02-20 15:44:45 --> Security Class Initialized
DEBUG - 2020-02-20 15:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:44:45 --> CSRF cookie sent
INFO - 2020-02-20 15:44:45 --> Input Class Initialized
INFO - 2020-02-20 15:44:45 --> Language Class Initialized
INFO - 2020-02-20 15:44:45 --> Language Class Initialized
INFO - 2020-02-20 15:44:45 --> Config Class Initialized
INFO - 2020-02-20 15:44:45 --> Loader Class Initialized
INFO - 2020-02-20 15:44:45 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:45 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:45 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:45 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:45 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:45 --> Parser Class Initialized
INFO - 2020-02-20 15:44:45 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:45 --> Model Class Initialized
INFO - 2020-02-20 15:44:45 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:45 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:45 --> Template Class Initialized
INFO - 2020-02-20 15:44:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:46 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:46 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:46 --> Controller Class Initialized
DEBUG - 2020-02-20 15:44:46 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:44:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:46 --> Model Class Initialized
ERROR - 2020-02-20 15:44:46 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:44:46 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 15:44:46 --> Could not find the language line "Delele"
DEBUG - 2020-02-20 15:44:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-20 15:44:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:44:46 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:44:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:44:46 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:46 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:46 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:44:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:44:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:44:46 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:46 --> Total execution time: 0.7449
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:44:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:44:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:44:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:44:46 --> Hooks Class Initialized
INFO - 2020-02-20 15:44:46 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 15:44:46 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:44:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:46 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:46 --> URI Class Initialized
INFO - 2020-02-20 15:44:46 --> URI Class Initialized
INFO - 2020-02-20 15:44:46 --> URI Class Initialized
INFO - 2020-02-20 15:44:46 --> URI Class Initialized
INFO - 2020-02-20 15:44:46 --> URI Class Initialized
INFO - 2020-02-20 15:44:46 --> URI Class Initialized
INFO - 2020-02-20 15:44:46 --> Router Class Initialized
INFO - 2020-02-20 15:44:46 --> Router Class Initialized
INFO - 2020-02-20 15:44:46 --> Router Class Initialized
INFO - 2020-02-20 15:44:46 --> Router Class Initialized
INFO - 2020-02-20 15:44:46 --> Router Class Initialized
INFO - 2020-02-20 15:44:46 --> Router Class Initialized
INFO - 2020-02-20 15:44:46 --> Output Class Initialized
INFO - 2020-02-20 15:44:46 --> Output Class Initialized
INFO - 2020-02-20 15:44:46 --> Output Class Initialized
INFO - 2020-02-20 15:44:46 --> Output Class Initialized
INFO - 2020-02-20 15:44:46 --> Output Class Initialized
INFO - 2020-02-20 15:44:46 --> Output Class Initialized
INFO - 2020-02-20 15:44:46 --> Security Class Initialized
INFO - 2020-02-20 15:44:46 --> Security Class Initialized
INFO - 2020-02-20 15:44:46 --> Security Class Initialized
INFO - 2020-02-20 15:44:46 --> Security Class Initialized
INFO - 2020-02-20 15:44:46 --> Security Class Initialized
INFO - 2020-02-20 15:44:46 --> Security Class Initialized
DEBUG - 2020-02-20 15:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:44:46 --> CSRF cookie sent
INFO - 2020-02-20 15:44:46 --> CSRF cookie sent
INFO - 2020-02-20 15:44:46 --> CSRF cookie sent
INFO - 2020-02-20 15:44:46 --> CSRF cookie sent
INFO - 2020-02-20 15:44:46 --> CSRF cookie sent
INFO - 2020-02-20 15:44:46 --> CSRF cookie sent
INFO - 2020-02-20 15:44:46 --> CSRF token verified
INFO - 2020-02-20 15:44:46 --> CSRF token verified
INFO - 2020-02-20 15:44:46 --> CSRF token verified
INFO - 2020-02-20 15:44:46 --> CSRF token verified
INFO - 2020-02-20 15:44:46 --> CSRF token verified
INFO - 2020-02-20 15:44:46 --> CSRF token verified
INFO - 2020-02-20 15:44:46 --> Input Class Initialized
INFO - 2020-02-20 15:44:46 --> Input Class Initialized
INFO - 2020-02-20 15:44:46 --> Input Class Initialized
INFO - 2020-02-20 15:44:46 --> Input Class Initialized
INFO - 2020-02-20 15:44:46 --> Input Class Initialized
INFO - 2020-02-20 15:44:46 --> Input Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Language Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Config Class Initialized
INFO - 2020-02-20 15:44:46 --> Loader Class Initialized
INFO - 2020-02-20 15:44:46 --> Loader Class Initialized
INFO - 2020-02-20 15:44:46 --> Loader Class Initialized
INFO - 2020-02-20 15:44:46 --> Loader Class Initialized
INFO - 2020-02-20 15:44:46 --> Loader Class Initialized
INFO - 2020-02-20 15:44:46 --> Loader Class Initialized
INFO - 2020-02-20 15:44:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:46 --> Parser Class Initialized
INFO - 2020-02-20 15:44:46 --> Parser Class Initialized
INFO - 2020-02-20 15:44:46 --> Parser Class Initialized
INFO - 2020-02-20 15:44:46 --> Parser Class Initialized
INFO - 2020-02-20 15:44:46 --> Parser Class Initialized
INFO - 2020-02-20 15:44:46 --> Parser Class Initialized
INFO - 2020-02-20 15:44:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:46 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:46 --> Model Class Initialized
INFO - 2020-02-20 15:44:46 --> Model Class Initialized
INFO - 2020-02-20 15:44:46 --> Model Class Initialized
INFO - 2020-02-20 15:44:46 --> Model Class Initialized
INFO - 2020-02-20 15:44:46 --> Model Class Initialized
INFO - 2020-02-20 15:44:46 --> Model Class Initialized
INFO - 2020-02-20 15:44:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:46 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Template Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Template Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Template Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Template Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Template Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Template Class Initialized
INFO - 2020-02-20 15:44:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:47 --> Controller Class Initialized
DEBUG - 2020-02-20 15:44:47 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:44:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:44:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:44:47 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:47 --> Total execution time: 0.6295
INFO - 2020-02-20 15:44:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:47 --> Config Class Initialized
INFO - 2020-02-20 15:44:47 --> Hooks Class Initialized
INFO - 2020-02-20 15:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:47 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:44:47 --> Utf8 Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:47 --> URI Class Initialized
INFO - 2020-02-20 15:44:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:47 --> Router Class Initialized
INFO - 2020-02-20 15:44:47 --> Controller Class Initialized
INFO - 2020-02-20 15:44:47 --> Output Class Initialized
DEBUG - 2020-02-20 15:44:47 --> category MX_Controller Initialized
INFO - 2020-02-20 15:44:47 --> Security Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 15:44:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
INFO - 2020-02-20 15:44:47 --> CSRF cookie sent
INFO - 2020-02-20 15:44:47 --> CSRF token verified
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:44:47 --> Input Class Initialized
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "View"
INFO - 2020-02-20 15:44:47 --> Language Class Initialized
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "View"
INFO - 2020-02-20 15:44:47 --> Language Class Initialized
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "View"
INFO - 2020-02-20 15:44:47 --> Config Class Initialized
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "View"
INFO - 2020-02-20 15:44:47 --> Loader Class Initialized
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "View"
INFO - 2020-02-20 15:44:47 --> Helper loaded: url_helper
DEBUG - 2020-02-20 15:44:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:44:47 --> Final output sent to browser
INFO - 2020-02-20 15:44:47 --> Helper loaded: common_helper
DEBUG - 2020-02-20 15:44:47 --> Total execution time: 0.8583
INFO - 2020-02-20 15:44:47 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:47 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:47 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:47 --> Pagination Class Initialized
INFO - 2020-02-20 15:44:47 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:47 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-20 15:44:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:47 --> Parser Class Initialized
INFO - 2020-02-20 15:44:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:47 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:47 --> Controller Class Initialized
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:47 --> category MX_Controller Initialized
INFO - 2020-02-20 15:44:47 --> Database Driver Class Initialized
DEBUG - 2020-02-20 15:44:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Template Class Initialized
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:44:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:44:47 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:47 --> Total execution time: 1.0352
INFO - 2020-02-20 15:44:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:47 --> Controller Class Initialized
DEBUG - 2020-02-20 15:44:47 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:44:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:44:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:44:47 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:47 --> Total execution time: 1.2462
INFO - 2020-02-20 15:44:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:47 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:47 --> Controller Class Initialized
DEBUG - 2020-02-20 15:44:47 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:44:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:47 --> Model Class Initialized
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:44:47 --> Could not find the language line "View"
ERROR - 2020-02-20 15:44:48 --> Could not find the language line "View"
ERROR - 2020-02-20 15:44:48 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:44:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:44:48 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:48 --> Total execution time: 1.4676
INFO - 2020-02-20 15:44:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:48 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:48 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:48 --> Controller Class Initialized
DEBUG - 2020-02-20 15:44:48 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:44:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:48 --> Model Class Initialized
ERROR - 2020-02-20 15:44:48 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:44:48 --> Could not find the language line "View"
ERROR - 2020-02-20 15:44:48 --> Could not find the language line "View"
ERROR - 2020-02-20 15:44:48 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:44:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:44:48 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:48 --> Total execution time: 1.7016
INFO - 2020-02-20 15:44:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:48 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:48 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:48 --> Controller Class Initialized
DEBUG - 2020-02-20 15:44:48 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:44:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:48 --> Model Class Initialized
ERROR - 2020-02-20 15:44:48 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 15:44:48 --> Could not find the language line "View"
DEBUG - 2020-02-20 15:44:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 15:44:48 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:48 --> Total execution time: 1.2534
INFO - 2020-02-20 15:44:49 --> Config Class Initialized
INFO - 2020-02-20 15:44:49 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:44:49 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:44:49 --> Utf8 Class Initialized
INFO - 2020-02-20 15:44:49 --> URI Class Initialized
INFO - 2020-02-20 15:44:49 --> Router Class Initialized
INFO - 2020-02-20 15:44:49 --> Output Class Initialized
INFO - 2020-02-20 15:44:49 --> Security Class Initialized
DEBUG - 2020-02-20 15:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:44:49 --> CSRF cookie sent
INFO - 2020-02-20 15:44:49 --> Input Class Initialized
INFO - 2020-02-20 15:44:49 --> Language Class Initialized
INFO - 2020-02-20 15:44:49 --> Language Class Initialized
INFO - 2020-02-20 15:44:49 --> Config Class Initialized
INFO - 2020-02-20 15:44:49 --> Loader Class Initialized
INFO - 2020-02-20 15:44:49 --> Helper loaded: url_helper
INFO - 2020-02-20 15:44:49 --> Helper loaded: common_helper
INFO - 2020-02-20 15:44:49 --> Helper loaded: language_helper
INFO - 2020-02-20 15:44:49 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:44:49 --> Helper loaded: email_helper
INFO - 2020-02-20 15:44:49 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:44:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:44:49 --> Parser Class Initialized
INFO - 2020-02-20 15:44:49 --> User Agent Class Initialized
INFO - 2020-02-20 15:44:49 --> Model Class Initialized
INFO - 2020-02-20 15:44:49 --> Database Driver Class Initialized
INFO - 2020-02-20 15:44:49 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:49 --> Template Class Initialized
INFO - 2020-02-20 15:44:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:44:49 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:44:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:44:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:44:49 --> Encryption Class Initialized
INFO - 2020-02-20 15:44:49 --> Controller Class Initialized
DEBUG - 2020-02-20 15:44:49 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:44:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:49 --> Model Class Initialized
ERROR - 2020-02-20 15:44:49 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:44:49 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:44:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:44:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:44:49 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:44:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:44:49 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:49 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:44:49 --> Model Class Initialized
DEBUG - 2020-02-20 15:44:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:44:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:44:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:44:49 --> Final output sent to browser
DEBUG - 2020-02-20 15:44:49 --> Total execution time: 0.7653
INFO - 2020-02-20 15:45:40 --> Config Class Initialized
INFO - 2020-02-20 15:45:40 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:45:40 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:45:40 --> Utf8 Class Initialized
INFO - 2020-02-20 15:45:40 --> URI Class Initialized
INFO - 2020-02-20 15:45:40 --> Router Class Initialized
INFO - 2020-02-20 15:45:40 --> Output Class Initialized
INFO - 2020-02-20 15:45:40 --> Security Class Initialized
DEBUG - 2020-02-20 15:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:45:40 --> CSRF cookie sent
INFO - 2020-02-20 15:45:40 --> Input Class Initialized
INFO - 2020-02-20 15:45:40 --> Language Class Initialized
INFO - 2020-02-20 15:45:40 --> Language Class Initialized
INFO - 2020-02-20 15:45:40 --> Config Class Initialized
INFO - 2020-02-20 15:45:40 --> Loader Class Initialized
INFO - 2020-02-20 15:45:40 --> Helper loaded: url_helper
INFO - 2020-02-20 15:45:40 --> Helper loaded: common_helper
INFO - 2020-02-20 15:45:40 --> Helper loaded: language_helper
INFO - 2020-02-20 15:45:40 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:45:40 --> Helper loaded: email_helper
INFO - 2020-02-20 15:45:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:45:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:45:40 --> Parser Class Initialized
INFO - 2020-02-20 15:45:40 --> User Agent Class Initialized
INFO - 2020-02-20 15:45:40 --> Model Class Initialized
INFO - 2020-02-20 15:45:40 --> Database Driver Class Initialized
INFO - 2020-02-20 15:45:40 --> Model Class Initialized
DEBUG - 2020-02-20 15:45:40 --> Template Class Initialized
INFO - 2020-02-20 15:45:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:45:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:45:40 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:45:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:45:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:45:40 --> Encryption Class Initialized
INFO - 2020-02-20 15:45:40 --> Controller Class Initialized
DEBUG - 2020-02-20 15:45:40 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:45:41 --> Model Class Initialized
ERROR - 2020-02-20 15:45:41 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:45:41 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:45:41 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:45:41 --> Model Class Initialized
DEBUG - 2020-02-20 15:45:41 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:45:41 --> Model Class Initialized
DEBUG - 2020-02-20 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:45:41 --> Final output sent to browser
DEBUG - 2020-02-20 15:45:41 --> Total execution time: 0.7437
INFO - 2020-02-20 15:46:13 --> Config Class Initialized
INFO - 2020-02-20 15:46:13 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:46:13 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:46:13 --> Utf8 Class Initialized
INFO - 2020-02-20 15:46:13 --> URI Class Initialized
INFO - 2020-02-20 15:46:13 --> Router Class Initialized
INFO - 2020-02-20 15:46:13 --> Output Class Initialized
INFO - 2020-02-20 15:46:13 --> Security Class Initialized
DEBUG - 2020-02-20 15:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:46:13 --> CSRF cookie sent
INFO - 2020-02-20 15:46:13 --> Input Class Initialized
INFO - 2020-02-20 15:46:13 --> Language Class Initialized
INFO - 2020-02-20 15:46:13 --> Language Class Initialized
INFO - 2020-02-20 15:46:13 --> Config Class Initialized
INFO - 2020-02-20 15:46:13 --> Loader Class Initialized
INFO - 2020-02-20 15:46:13 --> Helper loaded: url_helper
INFO - 2020-02-20 15:46:13 --> Helper loaded: common_helper
INFO - 2020-02-20 15:46:13 --> Helper loaded: language_helper
INFO - 2020-02-20 15:46:13 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:46:13 --> Helper loaded: email_helper
INFO - 2020-02-20 15:46:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:46:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:46:13 --> Parser Class Initialized
INFO - 2020-02-20 15:46:13 --> User Agent Class Initialized
INFO - 2020-02-20 15:46:13 --> Model Class Initialized
INFO - 2020-02-20 15:46:14 --> Database Driver Class Initialized
INFO - 2020-02-20 15:46:14 --> Model Class Initialized
DEBUG - 2020-02-20 15:46:14 --> Template Class Initialized
INFO - 2020-02-20 15:46:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:46:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:46:14 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:46:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:46:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:46:14 --> Encryption Class Initialized
INFO - 2020-02-20 15:46:14 --> Controller Class Initialized
DEBUG - 2020-02-20 15:46:14 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:46:14 --> Model Class Initialized
ERROR - 2020-02-20 15:46:14 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:46:14 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:46:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:46:14 --> Model Class Initialized
DEBUG - 2020-02-20 15:46:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:46:14 --> Model Class Initialized
DEBUG - 2020-02-20 15:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:46:14 --> Final output sent to browser
DEBUG - 2020-02-20 15:46:14 --> Total execution time: 0.7922
INFO - 2020-02-20 15:47:32 --> Config Class Initialized
INFO - 2020-02-20 15:47:32 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:47:32 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:47:32 --> Utf8 Class Initialized
INFO - 2020-02-20 15:47:32 --> URI Class Initialized
INFO - 2020-02-20 15:47:32 --> Router Class Initialized
INFO - 2020-02-20 15:47:32 --> Output Class Initialized
INFO - 2020-02-20 15:47:33 --> Security Class Initialized
DEBUG - 2020-02-20 15:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:47:33 --> CSRF cookie sent
INFO - 2020-02-20 15:47:33 --> Input Class Initialized
INFO - 2020-02-20 15:47:33 --> Language Class Initialized
INFO - 2020-02-20 15:47:33 --> Language Class Initialized
INFO - 2020-02-20 15:47:33 --> Config Class Initialized
INFO - 2020-02-20 15:47:33 --> Loader Class Initialized
INFO - 2020-02-20 15:47:33 --> Helper loaded: url_helper
INFO - 2020-02-20 15:47:33 --> Helper loaded: common_helper
INFO - 2020-02-20 15:47:33 --> Helper loaded: language_helper
INFO - 2020-02-20 15:47:33 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:47:33 --> Helper loaded: email_helper
INFO - 2020-02-20 15:47:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:47:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:47:33 --> Parser Class Initialized
INFO - 2020-02-20 15:47:33 --> User Agent Class Initialized
INFO - 2020-02-20 15:47:33 --> Model Class Initialized
INFO - 2020-02-20 15:47:33 --> Database Driver Class Initialized
INFO - 2020-02-20 15:47:33 --> Model Class Initialized
DEBUG - 2020-02-20 15:47:33 --> Template Class Initialized
INFO - 2020-02-20 15:47:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:47:33 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:47:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:47:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:47:33 --> Encryption Class Initialized
INFO - 2020-02-20 15:47:33 --> Controller Class Initialized
DEBUG - 2020-02-20 15:47:33 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:47:33 --> Model Class Initialized
ERROR - 2020-02-20 15:47:33 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:47:33 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:47:33 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:47:33 --> Model Class Initialized
DEBUG - 2020-02-20 15:47:33 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:47:33 --> Model Class Initialized
DEBUG - 2020-02-20 15:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:47:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:47:33 --> Final output sent to browser
DEBUG - 2020-02-20 15:47:33 --> Total execution time: 0.8580
INFO - 2020-02-20 15:48:10 --> Config Class Initialized
INFO - 2020-02-20 15:48:10 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:48:10 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:48:10 --> Utf8 Class Initialized
INFO - 2020-02-20 15:48:10 --> URI Class Initialized
INFO - 2020-02-20 15:48:10 --> Router Class Initialized
INFO - 2020-02-20 15:48:10 --> Output Class Initialized
INFO - 2020-02-20 15:48:10 --> Security Class Initialized
DEBUG - 2020-02-20 15:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:48:10 --> CSRF cookie sent
INFO - 2020-02-20 15:48:10 --> Input Class Initialized
INFO - 2020-02-20 15:48:10 --> Language Class Initialized
INFO - 2020-02-20 15:48:10 --> Language Class Initialized
INFO - 2020-02-20 15:48:10 --> Config Class Initialized
INFO - 2020-02-20 15:48:10 --> Loader Class Initialized
INFO - 2020-02-20 15:48:10 --> Helper loaded: url_helper
INFO - 2020-02-20 15:48:10 --> Helper loaded: common_helper
INFO - 2020-02-20 15:48:10 --> Helper loaded: language_helper
INFO - 2020-02-20 15:48:10 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:48:10 --> Helper loaded: email_helper
INFO - 2020-02-20 15:48:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:48:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:48:10 --> Parser Class Initialized
INFO - 2020-02-20 15:48:10 --> User Agent Class Initialized
INFO - 2020-02-20 15:48:10 --> Model Class Initialized
INFO - 2020-02-20 15:48:10 --> Database Driver Class Initialized
INFO - 2020-02-20 15:48:10 --> Model Class Initialized
DEBUG - 2020-02-20 15:48:10 --> Template Class Initialized
INFO - 2020-02-20 15:48:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:48:10 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:48:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:48:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:48:10 --> Encryption Class Initialized
INFO - 2020-02-20 15:48:10 --> Controller Class Initialized
DEBUG - 2020-02-20 15:48:10 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:48:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:48:10 --> Model Class Initialized
ERROR - 2020-02-20 15:48:10 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:48:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:48:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:48:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:48:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:48:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:48:10 --> Model Class Initialized
DEBUG - 2020-02-20 15:48:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:48:10 --> Model Class Initialized
DEBUG - 2020-02-20 15:48:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:48:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:48:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:48:10 --> Final output sent to browser
DEBUG - 2020-02-20 15:48:10 --> Total execution time: 0.7496
INFO - 2020-02-20 15:49:13 --> Config Class Initialized
INFO - 2020-02-20 15:49:13 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:49:13 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:49:13 --> Utf8 Class Initialized
INFO - 2020-02-20 15:49:13 --> URI Class Initialized
INFO - 2020-02-20 15:49:13 --> Router Class Initialized
INFO - 2020-02-20 15:49:13 --> Output Class Initialized
INFO - 2020-02-20 15:49:13 --> Security Class Initialized
DEBUG - 2020-02-20 15:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:49:13 --> CSRF cookie sent
INFO - 2020-02-20 15:49:13 --> Input Class Initialized
INFO - 2020-02-20 15:49:13 --> Language Class Initialized
INFO - 2020-02-20 15:49:13 --> Language Class Initialized
INFO - 2020-02-20 15:49:13 --> Config Class Initialized
INFO - 2020-02-20 15:49:13 --> Loader Class Initialized
INFO - 2020-02-20 15:49:13 --> Helper loaded: url_helper
INFO - 2020-02-20 15:49:13 --> Helper loaded: common_helper
INFO - 2020-02-20 15:49:13 --> Helper loaded: language_helper
INFO - 2020-02-20 15:49:13 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:49:13 --> Helper loaded: email_helper
INFO - 2020-02-20 15:49:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:49:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:49:13 --> Parser Class Initialized
INFO - 2020-02-20 15:49:13 --> User Agent Class Initialized
INFO - 2020-02-20 15:49:13 --> Model Class Initialized
INFO - 2020-02-20 15:49:13 --> Database Driver Class Initialized
INFO - 2020-02-20 15:49:13 --> Model Class Initialized
DEBUG - 2020-02-20 15:49:13 --> Template Class Initialized
INFO - 2020-02-20 15:49:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:49:13 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:49:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:49:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:49:13 --> Encryption Class Initialized
INFO - 2020-02-20 15:49:13 --> Controller Class Initialized
DEBUG - 2020-02-20 15:49:13 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:49:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:49:13 --> Model Class Initialized
ERROR - 2020-02-20 15:49:13 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:49:13 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:49:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:49:14 --> Model Class Initialized
DEBUG - 2020-02-20 15:49:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:49:14 --> Model Class Initialized
DEBUG - 2020-02-20 15:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:49:14 --> Final output sent to browser
DEBUG - 2020-02-20 15:49:14 --> Total execution time: 0.8271
INFO - 2020-02-20 15:50:36 --> Config Class Initialized
INFO - 2020-02-20 15:50:36 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:50:36 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:50:36 --> Utf8 Class Initialized
INFO - 2020-02-20 15:50:36 --> URI Class Initialized
INFO - 2020-02-20 15:50:36 --> Router Class Initialized
INFO - 2020-02-20 15:50:37 --> Output Class Initialized
INFO - 2020-02-20 15:50:37 --> Security Class Initialized
DEBUG - 2020-02-20 15:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:50:37 --> CSRF cookie sent
INFO - 2020-02-20 15:50:37 --> Input Class Initialized
INFO - 2020-02-20 15:50:37 --> Language Class Initialized
INFO - 2020-02-20 15:50:37 --> Language Class Initialized
INFO - 2020-02-20 15:50:37 --> Config Class Initialized
INFO - 2020-02-20 15:50:37 --> Loader Class Initialized
INFO - 2020-02-20 15:50:37 --> Helper loaded: url_helper
INFO - 2020-02-20 15:50:37 --> Helper loaded: common_helper
INFO - 2020-02-20 15:50:37 --> Helper loaded: language_helper
INFO - 2020-02-20 15:50:37 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:50:37 --> Helper loaded: email_helper
INFO - 2020-02-20 15:50:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:50:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:50:37 --> Parser Class Initialized
INFO - 2020-02-20 15:50:37 --> User Agent Class Initialized
INFO - 2020-02-20 15:50:37 --> Model Class Initialized
INFO - 2020-02-20 15:50:37 --> Database Driver Class Initialized
INFO - 2020-02-20 15:50:37 --> Model Class Initialized
DEBUG - 2020-02-20 15:50:37 --> Template Class Initialized
INFO - 2020-02-20 15:50:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:50:37 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:50:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:50:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:50:37 --> Encryption Class Initialized
INFO - 2020-02-20 15:50:37 --> Controller Class Initialized
DEBUG - 2020-02-20 15:50:37 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:50:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:50:37 --> Model Class Initialized
ERROR - 2020-02-20 15:50:37 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:50:37 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:50:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:50:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:50:37 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:50:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:50:37 --> Model Class Initialized
DEBUG - 2020-02-20 15:50:37 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:50:37 --> Model Class Initialized
DEBUG - 2020-02-20 15:50:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:50:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:50:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:50:37 --> Final output sent to browser
DEBUG - 2020-02-20 15:50:37 --> Total execution time: 0.7312
INFO - 2020-02-20 15:54:05 --> Config Class Initialized
INFO - 2020-02-20 15:54:05 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:54:05 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:54:05 --> Utf8 Class Initialized
INFO - 2020-02-20 15:54:05 --> URI Class Initialized
INFO - 2020-02-20 15:54:05 --> Router Class Initialized
INFO - 2020-02-20 15:54:05 --> Output Class Initialized
INFO - 2020-02-20 15:54:05 --> Security Class Initialized
DEBUG - 2020-02-20 15:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:54:05 --> CSRF cookie sent
INFO - 2020-02-20 15:54:05 --> Input Class Initialized
INFO - 2020-02-20 15:54:05 --> Language Class Initialized
INFO - 2020-02-20 15:54:05 --> Language Class Initialized
INFO - 2020-02-20 15:54:05 --> Config Class Initialized
INFO - 2020-02-20 15:54:05 --> Loader Class Initialized
INFO - 2020-02-20 15:54:05 --> Helper loaded: url_helper
INFO - 2020-02-20 15:54:05 --> Helper loaded: common_helper
INFO - 2020-02-20 15:54:05 --> Helper loaded: language_helper
INFO - 2020-02-20 15:54:05 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:54:05 --> Helper loaded: email_helper
INFO - 2020-02-20 15:54:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:54:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:54:05 --> Parser Class Initialized
INFO - 2020-02-20 15:54:05 --> User Agent Class Initialized
INFO - 2020-02-20 15:54:05 --> Model Class Initialized
INFO - 2020-02-20 15:54:05 --> Database Driver Class Initialized
INFO - 2020-02-20 15:54:05 --> Model Class Initialized
DEBUG - 2020-02-20 15:54:05 --> Template Class Initialized
INFO - 2020-02-20 15:54:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:54:05 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:54:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:54:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:54:06 --> Encryption Class Initialized
INFO - 2020-02-20 15:54:06 --> Controller Class Initialized
DEBUG - 2020-02-20 15:54:06 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:54:06 --> Model Class Initialized
ERROR - 2020-02-20 15:54:06 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:54:06 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:54:06 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:54:06 --> Model Class Initialized
DEBUG - 2020-02-20 15:54:06 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:54:06 --> Model Class Initialized
DEBUG - 2020-02-20 15:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:54:06 --> Final output sent to browser
DEBUG - 2020-02-20 15:54:06 --> Total execution time: 0.7568
INFO - 2020-02-20 15:55:56 --> Config Class Initialized
INFO - 2020-02-20 15:55:56 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:55:56 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:55:56 --> Utf8 Class Initialized
INFO - 2020-02-20 15:55:56 --> URI Class Initialized
INFO - 2020-02-20 15:55:56 --> Router Class Initialized
INFO - 2020-02-20 15:55:56 --> Output Class Initialized
INFO - 2020-02-20 15:55:56 --> Security Class Initialized
DEBUG - 2020-02-20 15:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:55:56 --> CSRF cookie sent
INFO - 2020-02-20 15:55:56 --> Input Class Initialized
INFO - 2020-02-20 15:55:56 --> Language Class Initialized
INFO - 2020-02-20 15:55:56 --> Language Class Initialized
INFO - 2020-02-20 15:55:56 --> Config Class Initialized
INFO - 2020-02-20 15:55:56 --> Loader Class Initialized
INFO - 2020-02-20 15:55:56 --> Helper loaded: url_helper
INFO - 2020-02-20 15:55:56 --> Helper loaded: common_helper
INFO - 2020-02-20 15:55:56 --> Helper loaded: language_helper
INFO - 2020-02-20 15:55:56 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:55:56 --> Helper loaded: email_helper
INFO - 2020-02-20 15:55:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:55:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:55:56 --> Parser Class Initialized
INFO - 2020-02-20 15:55:56 --> User Agent Class Initialized
INFO - 2020-02-20 15:55:56 --> Model Class Initialized
INFO - 2020-02-20 15:55:56 --> Database Driver Class Initialized
INFO - 2020-02-20 15:55:56 --> Model Class Initialized
DEBUG - 2020-02-20 15:55:56 --> Template Class Initialized
INFO - 2020-02-20 15:55:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:55:57 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:55:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:55:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:55:57 --> Encryption Class Initialized
INFO - 2020-02-20 15:55:57 --> Controller Class Initialized
DEBUG - 2020-02-20 15:55:57 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:55:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:55:57 --> Model Class Initialized
ERROR - 2020-02-20 15:55:57 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:55:57 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:55:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:55:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:55:57 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:55:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:55:57 --> Model Class Initialized
DEBUG - 2020-02-20 15:55:57 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:55:57 --> Model Class Initialized
DEBUG - 2020-02-20 15:55:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:55:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:55:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:55:57 --> Final output sent to browser
DEBUG - 2020-02-20 15:55:57 --> Total execution time: 0.8424
INFO - 2020-02-20 15:56:04 --> Config Class Initialized
INFO - 2020-02-20 15:56:04 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:56:04 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:56:04 --> Utf8 Class Initialized
INFO - 2020-02-20 15:56:04 --> URI Class Initialized
INFO - 2020-02-20 15:56:04 --> Router Class Initialized
INFO - 2020-02-20 15:56:04 --> Output Class Initialized
INFO - 2020-02-20 15:56:05 --> Security Class Initialized
DEBUG - 2020-02-20 15:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:56:05 --> CSRF cookie sent
INFO - 2020-02-20 15:56:05 --> Input Class Initialized
INFO - 2020-02-20 15:56:05 --> Language Class Initialized
INFO - 2020-02-20 15:56:05 --> Language Class Initialized
INFO - 2020-02-20 15:56:05 --> Config Class Initialized
INFO - 2020-02-20 15:56:05 --> Loader Class Initialized
INFO - 2020-02-20 15:56:05 --> Helper loaded: url_helper
INFO - 2020-02-20 15:56:05 --> Helper loaded: common_helper
INFO - 2020-02-20 15:56:05 --> Helper loaded: language_helper
INFO - 2020-02-20 15:56:05 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:56:05 --> Helper loaded: email_helper
INFO - 2020-02-20 15:56:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:56:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:56:05 --> Parser Class Initialized
INFO - 2020-02-20 15:56:05 --> User Agent Class Initialized
INFO - 2020-02-20 15:56:05 --> Model Class Initialized
INFO - 2020-02-20 15:56:05 --> Database Driver Class Initialized
INFO - 2020-02-20 15:56:05 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:05 --> Template Class Initialized
INFO - 2020-02-20 15:56:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:56:05 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:56:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:56:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:56:05 --> Encryption Class Initialized
INFO - 2020-02-20 15:56:05 --> Controller Class Initialized
DEBUG - 2020-02-20 15:56:05 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:56:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:56:05 --> Model Class Initialized
ERROR - 2020-02-20 15:56:05 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:56:05 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:56:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:56:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:56:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:56:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:56:05 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:56:05 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:56:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:56:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:56:05 --> Final output sent to browser
DEBUG - 2020-02-20 15:56:05 --> Total execution time: 0.8140
INFO - 2020-02-20 15:56:29 --> Config Class Initialized
INFO - 2020-02-20 15:56:30 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:56:30 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:56:30 --> Utf8 Class Initialized
INFO - 2020-02-20 15:56:30 --> URI Class Initialized
INFO - 2020-02-20 15:56:30 --> Router Class Initialized
INFO - 2020-02-20 15:56:30 --> Output Class Initialized
INFO - 2020-02-20 15:56:30 --> Security Class Initialized
DEBUG - 2020-02-20 15:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:56:30 --> CSRF cookie sent
INFO - 2020-02-20 15:56:30 --> Input Class Initialized
INFO - 2020-02-20 15:56:30 --> Language Class Initialized
INFO - 2020-02-20 15:56:30 --> Language Class Initialized
INFO - 2020-02-20 15:56:30 --> Config Class Initialized
INFO - 2020-02-20 15:56:30 --> Loader Class Initialized
INFO - 2020-02-20 15:56:30 --> Helper loaded: url_helper
INFO - 2020-02-20 15:56:30 --> Helper loaded: common_helper
INFO - 2020-02-20 15:56:30 --> Helper loaded: language_helper
INFO - 2020-02-20 15:56:30 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:56:30 --> Helper loaded: email_helper
INFO - 2020-02-20 15:56:30 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:56:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:56:30 --> Parser Class Initialized
INFO - 2020-02-20 15:56:30 --> User Agent Class Initialized
INFO - 2020-02-20 15:56:30 --> Model Class Initialized
INFO - 2020-02-20 15:56:30 --> Database Driver Class Initialized
INFO - 2020-02-20 15:56:30 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:30 --> Template Class Initialized
INFO - 2020-02-20 15:56:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:56:30 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:56:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:56:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:56:30 --> Encryption Class Initialized
INFO - 2020-02-20 15:56:30 --> Controller Class Initialized
DEBUG - 2020-02-20 15:56:30 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:56:30 --> Model Class Initialized
ERROR - 2020-02-20 15:56:30 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:56:30 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:56:30 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:56:30 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:30 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:56:30 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:56:30 --> Final output sent to browser
DEBUG - 2020-02-20 15:56:30 --> Total execution time: 0.8428
INFO - 2020-02-20 15:56:50 --> Config Class Initialized
INFO - 2020-02-20 15:56:50 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:56:50 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:56:50 --> Utf8 Class Initialized
INFO - 2020-02-20 15:56:50 --> URI Class Initialized
INFO - 2020-02-20 15:56:50 --> Router Class Initialized
INFO - 2020-02-20 15:56:50 --> Output Class Initialized
INFO - 2020-02-20 15:56:50 --> Security Class Initialized
DEBUG - 2020-02-20 15:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:56:50 --> CSRF cookie sent
INFO - 2020-02-20 15:56:50 --> Input Class Initialized
INFO - 2020-02-20 15:56:50 --> Language Class Initialized
INFO - 2020-02-20 15:56:50 --> Language Class Initialized
INFO - 2020-02-20 15:56:50 --> Config Class Initialized
INFO - 2020-02-20 15:56:50 --> Loader Class Initialized
INFO - 2020-02-20 15:56:50 --> Helper loaded: url_helper
INFO - 2020-02-20 15:56:50 --> Helper loaded: common_helper
INFO - 2020-02-20 15:56:50 --> Helper loaded: language_helper
INFO - 2020-02-20 15:56:50 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:56:50 --> Helper loaded: email_helper
INFO - 2020-02-20 15:56:50 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:56:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:56:50 --> Parser Class Initialized
INFO - 2020-02-20 15:56:50 --> User Agent Class Initialized
INFO - 2020-02-20 15:56:50 --> Model Class Initialized
INFO - 2020-02-20 15:56:50 --> Database Driver Class Initialized
INFO - 2020-02-20 15:56:50 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:50 --> Template Class Initialized
INFO - 2020-02-20 15:56:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:56:50 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:56:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:56:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:56:50 --> Encryption Class Initialized
INFO - 2020-02-20 15:56:50 --> Controller Class Initialized
DEBUG - 2020-02-20 15:56:50 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:56:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:56:50 --> Model Class Initialized
ERROR - 2020-02-20 15:56:50 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:56:50 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:56:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:56:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:56:50 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:56:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:56:50 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:50 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:56:50 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:56:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:56:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:56:51 --> Final output sent to browser
DEBUG - 2020-02-20 15:56:51 --> Total execution time: 0.8103
INFO - 2020-02-20 15:56:59 --> Config Class Initialized
INFO - 2020-02-20 15:56:59 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:56:59 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:56:59 --> Utf8 Class Initialized
INFO - 2020-02-20 15:56:59 --> URI Class Initialized
INFO - 2020-02-20 15:56:59 --> Router Class Initialized
INFO - 2020-02-20 15:56:59 --> Output Class Initialized
INFO - 2020-02-20 15:56:59 --> Security Class Initialized
DEBUG - 2020-02-20 15:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:56:59 --> CSRF cookie sent
INFO - 2020-02-20 15:56:59 --> Input Class Initialized
INFO - 2020-02-20 15:56:59 --> Language Class Initialized
INFO - 2020-02-20 15:56:59 --> Language Class Initialized
INFO - 2020-02-20 15:56:59 --> Config Class Initialized
INFO - 2020-02-20 15:56:59 --> Loader Class Initialized
INFO - 2020-02-20 15:56:59 --> Helper loaded: url_helper
INFO - 2020-02-20 15:56:59 --> Helper loaded: common_helper
INFO - 2020-02-20 15:56:59 --> Helper loaded: language_helper
INFO - 2020-02-20 15:56:59 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:56:59 --> Helper loaded: email_helper
INFO - 2020-02-20 15:56:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:56:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:56:59 --> Parser Class Initialized
INFO - 2020-02-20 15:56:59 --> User Agent Class Initialized
INFO - 2020-02-20 15:56:59 --> Model Class Initialized
INFO - 2020-02-20 15:56:59 --> Database Driver Class Initialized
INFO - 2020-02-20 15:56:59 --> Model Class Initialized
DEBUG - 2020-02-20 15:56:59 --> Template Class Initialized
INFO - 2020-02-20 15:56:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:56:59 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:56:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:56:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:56:59 --> Encryption Class Initialized
INFO - 2020-02-20 15:56:59 --> Controller Class Initialized
DEBUG - 2020-02-20 15:56:59 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:56:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:57:00 --> Model Class Initialized
ERROR - 2020-02-20 15:57:00 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:57:00 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:57:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:57:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:57:00 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:57:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:57:00 --> Model Class Initialized
DEBUG - 2020-02-20 15:57:00 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:57:00 --> Model Class Initialized
DEBUG - 2020-02-20 15:57:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:57:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:57:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:57:00 --> Final output sent to browser
DEBUG - 2020-02-20 15:57:00 --> Total execution time: 0.8197
INFO - 2020-02-20 15:57:32 --> Config Class Initialized
INFO - 2020-02-20 15:57:32 --> Hooks Class Initialized
DEBUG - 2020-02-20 15:57:32 --> UTF-8 Support Enabled
INFO - 2020-02-20 15:57:32 --> Utf8 Class Initialized
INFO - 2020-02-20 15:57:32 --> URI Class Initialized
INFO - 2020-02-20 15:57:32 --> Router Class Initialized
INFO - 2020-02-20 15:57:32 --> Output Class Initialized
INFO - 2020-02-20 15:57:32 --> Security Class Initialized
DEBUG - 2020-02-20 15:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 15:57:32 --> CSRF cookie sent
INFO - 2020-02-20 15:57:32 --> Input Class Initialized
INFO - 2020-02-20 15:57:32 --> Language Class Initialized
INFO - 2020-02-20 15:57:32 --> Language Class Initialized
INFO - 2020-02-20 15:57:32 --> Config Class Initialized
INFO - 2020-02-20 15:57:32 --> Loader Class Initialized
INFO - 2020-02-20 15:57:32 --> Helper loaded: url_helper
INFO - 2020-02-20 15:57:32 --> Helper loaded: common_helper
INFO - 2020-02-20 15:57:32 --> Helper loaded: language_helper
INFO - 2020-02-20 15:57:32 --> Helper loaded: cookie_helper
INFO - 2020-02-20 15:57:32 --> Helper loaded: email_helper
INFO - 2020-02-20 15:57:32 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 15:57:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 15:57:32 --> Parser Class Initialized
INFO - 2020-02-20 15:57:32 --> User Agent Class Initialized
INFO - 2020-02-20 15:57:32 --> Model Class Initialized
INFO - 2020-02-20 15:57:32 --> Database Driver Class Initialized
INFO - 2020-02-20 15:57:32 --> Model Class Initialized
DEBUG - 2020-02-20 15:57:32 --> Template Class Initialized
INFO - 2020-02-20 15:57:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 15:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 15:57:32 --> Pagination Class Initialized
DEBUG - 2020-02-20 15:57:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 15:57:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 15:57:32 --> Encryption Class Initialized
INFO - 2020-02-20 15:57:32 --> Controller Class Initialized
DEBUG - 2020-02-20 15:57:32 --> category MX_Controller Initialized
DEBUG - 2020-02-20 15:57:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:57:32 --> Model Class Initialized
ERROR - 2020-02-20 15:57:32 --> Could not find the language line "Sorting"
INFO - 2020-02-20 15:57:32 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 15:57:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 15:57:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 15:57:32 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 15:57:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 15:57:32 --> Model Class Initialized
DEBUG - 2020-02-20 15:57:32 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 15:57:32 --> Model Class Initialized
DEBUG - 2020-02-20 15:57:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 15:57:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 15:57:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 15:57:32 --> Final output sent to browser
DEBUG - 2020-02-20 15:57:33 --> Total execution time: 0.7685
INFO - 2020-02-20 16:02:56 --> Config Class Initialized
INFO - 2020-02-20 16:02:56 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:02:56 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:02:56 --> Utf8 Class Initialized
INFO - 2020-02-20 16:02:56 --> URI Class Initialized
INFO - 2020-02-20 16:02:56 --> Router Class Initialized
INFO - 2020-02-20 16:02:56 --> Output Class Initialized
INFO - 2020-02-20 16:02:56 --> Security Class Initialized
DEBUG - 2020-02-20 16:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:02:56 --> CSRF cookie sent
INFO - 2020-02-20 16:02:56 --> Input Class Initialized
INFO - 2020-02-20 16:02:56 --> Language Class Initialized
INFO - 2020-02-20 16:02:56 --> Language Class Initialized
INFO - 2020-02-20 16:02:56 --> Config Class Initialized
INFO - 2020-02-20 16:02:56 --> Loader Class Initialized
INFO - 2020-02-20 16:02:56 --> Helper loaded: url_helper
INFO - 2020-02-20 16:02:56 --> Helper loaded: common_helper
INFO - 2020-02-20 16:02:56 --> Helper loaded: language_helper
INFO - 2020-02-20 16:02:56 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:02:56 --> Helper loaded: email_helper
INFO - 2020-02-20 16:02:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:02:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:02:56 --> Parser Class Initialized
INFO - 2020-02-20 16:02:56 --> User Agent Class Initialized
INFO - 2020-02-20 16:02:56 --> Model Class Initialized
INFO - 2020-02-20 16:02:56 --> Database Driver Class Initialized
INFO - 2020-02-20 16:02:56 --> Model Class Initialized
DEBUG - 2020-02-20 16:02:56 --> Template Class Initialized
INFO - 2020-02-20 16:02:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:02:56 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:02:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:02:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:02:56 --> Encryption Class Initialized
INFO - 2020-02-20 16:02:56 --> Controller Class Initialized
DEBUG - 2020-02-20 16:02:56 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:02:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:02:56 --> Model Class Initialized
ERROR - 2020-02-20 16:02:56 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:02:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:02:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:02:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:02:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:02:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:02:56 --> Model Class Initialized
DEBUG - 2020-02-20 16:02:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:02:56 --> Model Class Initialized
DEBUG - 2020-02-20 16:02:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:02:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:02:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:02:57 --> Final output sent to browser
DEBUG - 2020-02-20 16:02:57 --> Total execution time: 0.8001
INFO - 2020-02-20 16:05:54 --> Config Class Initialized
INFO - 2020-02-20 16:05:54 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:05:55 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:05:55 --> Utf8 Class Initialized
INFO - 2020-02-20 16:05:55 --> URI Class Initialized
INFO - 2020-02-20 16:05:55 --> Router Class Initialized
INFO - 2020-02-20 16:05:55 --> Output Class Initialized
INFO - 2020-02-20 16:05:55 --> Security Class Initialized
DEBUG - 2020-02-20 16:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:05:55 --> CSRF cookie sent
INFO - 2020-02-20 16:05:55 --> Input Class Initialized
INFO - 2020-02-20 16:05:55 --> Language Class Initialized
INFO - 2020-02-20 16:05:55 --> Language Class Initialized
INFO - 2020-02-20 16:05:55 --> Config Class Initialized
INFO - 2020-02-20 16:05:55 --> Loader Class Initialized
INFO - 2020-02-20 16:05:55 --> Helper loaded: url_helper
INFO - 2020-02-20 16:05:55 --> Helper loaded: common_helper
INFO - 2020-02-20 16:05:55 --> Helper loaded: language_helper
INFO - 2020-02-20 16:05:55 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:05:55 --> Helper loaded: email_helper
INFO - 2020-02-20 16:05:55 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:05:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:05:55 --> Parser Class Initialized
INFO - 2020-02-20 16:05:55 --> User Agent Class Initialized
INFO - 2020-02-20 16:05:55 --> Model Class Initialized
INFO - 2020-02-20 16:05:55 --> Database Driver Class Initialized
INFO - 2020-02-20 16:05:55 --> Model Class Initialized
DEBUG - 2020-02-20 16:05:55 --> Template Class Initialized
INFO - 2020-02-20 16:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:05:55 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:05:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:05:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:05:55 --> Encryption Class Initialized
INFO - 2020-02-20 16:05:55 --> Controller Class Initialized
DEBUG - 2020-02-20 16:05:55 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:05:55 --> Model Class Initialized
ERROR - 2020-02-20 16:05:55 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:05:55 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:05:55 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:05:55 --> Model Class Initialized
DEBUG - 2020-02-20 16:05:55 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:05:55 --> Model Class Initialized
DEBUG - 2020-02-20 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:05:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:05:55 --> Final output sent to browser
DEBUG - 2020-02-20 16:05:55 --> Total execution time: 0.8428
INFO - 2020-02-20 16:06:16 --> Config Class Initialized
INFO - 2020-02-20 16:06:16 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:06:16 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:06:16 --> Utf8 Class Initialized
INFO - 2020-02-20 16:06:16 --> URI Class Initialized
INFO - 2020-02-20 16:06:16 --> Router Class Initialized
INFO - 2020-02-20 16:06:16 --> Output Class Initialized
INFO - 2020-02-20 16:06:16 --> Security Class Initialized
DEBUG - 2020-02-20 16:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:06:16 --> CSRF cookie sent
INFO - 2020-02-20 16:06:16 --> Input Class Initialized
INFO - 2020-02-20 16:06:16 --> Language Class Initialized
INFO - 2020-02-20 16:06:16 --> Language Class Initialized
INFO - 2020-02-20 16:06:16 --> Config Class Initialized
INFO - 2020-02-20 16:06:16 --> Loader Class Initialized
INFO - 2020-02-20 16:06:16 --> Helper loaded: url_helper
INFO - 2020-02-20 16:06:16 --> Helper loaded: common_helper
INFO - 2020-02-20 16:06:16 --> Helper loaded: language_helper
INFO - 2020-02-20 16:06:16 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:06:16 --> Helper loaded: email_helper
INFO - 2020-02-20 16:06:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:06:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:06:16 --> Parser Class Initialized
INFO - 2020-02-20 16:06:16 --> User Agent Class Initialized
INFO - 2020-02-20 16:06:16 --> Model Class Initialized
INFO - 2020-02-20 16:06:16 --> Database Driver Class Initialized
INFO - 2020-02-20 16:06:16 --> Model Class Initialized
DEBUG - 2020-02-20 16:06:16 --> Template Class Initialized
INFO - 2020-02-20 16:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:06:17 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:06:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:06:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:06:17 --> Encryption Class Initialized
INFO - 2020-02-20 16:06:17 --> Controller Class Initialized
DEBUG - 2020-02-20 16:06:17 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:06:17 --> Model Class Initialized
ERROR - 2020-02-20 16:06:17 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:06:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:06:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:06:17 --> Model Class Initialized
DEBUG - 2020-02-20 16:06:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:06:17 --> Model Class Initialized
DEBUG - 2020-02-20 16:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:06:17 --> Final output sent to browser
DEBUG - 2020-02-20 16:06:17 --> Total execution time: 0.8449
INFO - 2020-02-20 16:06:39 --> Config Class Initialized
INFO - 2020-02-20 16:06:39 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:06:39 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:06:39 --> Utf8 Class Initialized
INFO - 2020-02-20 16:06:39 --> URI Class Initialized
INFO - 2020-02-20 16:06:39 --> Router Class Initialized
INFO - 2020-02-20 16:06:39 --> Output Class Initialized
INFO - 2020-02-20 16:06:39 --> Security Class Initialized
DEBUG - 2020-02-20 16:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:06:39 --> CSRF cookie sent
INFO - 2020-02-20 16:06:39 --> Input Class Initialized
INFO - 2020-02-20 16:06:39 --> Language Class Initialized
INFO - 2020-02-20 16:06:39 --> Language Class Initialized
INFO - 2020-02-20 16:06:39 --> Config Class Initialized
INFO - 2020-02-20 16:06:39 --> Loader Class Initialized
INFO - 2020-02-20 16:06:39 --> Helper loaded: url_helper
INFO - 2020-02-20 16:06:39 --> Helper loaded: common_helper
INFO - 2020-02-20 16:06:39 --> Helper loaded: language_helper
INFO - 2020-02-20 16:06:39 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:06:39 --> Helper loaded: email_helper
INFO - 2020-02-20 16:06:39 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:06:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:06:39 --> Parser Class Initialized
INFO - 2020-02-20 16:06:39 --> User Agent Class Initialized
INFO - 2020-02-20 16:06:39 --> Model Class Initialized
INFO - 2020-02-20 16:06:39 --> Database Driver Class Initialized
INFO - 2020-02-20 16:06:39 --> Model Class Initialized
DEBUG - 2020-02-20 16:06:39 --> Template Class Initialized
INFO - 2020-02-20 16:06:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:06:39 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:06:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:06:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:06:39 --> Encryption Class Initialized
INFO - 2020-02-20 16:06:39 --> Controller Class Initialized
DEBUG - 2020-02-20 16:06:39 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:06:39 --> Model Class Initialized
ERROR - 2020-02-20 16:06:39 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:06:39 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:06:39 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:06:39 --> Model Class Initialized
DEBUG - 2020-02-20 16:06:39 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:06:39 --> Model Class Initialized
DEBUG - 2020-02-20 16:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:06:39 --> Final output sent to browser
DEBUG - 2020-02-20 16:06:40 --> Total execution time: 0.8790
INFO - 2020-02-20 16:08:31 --> Config Class Initialized
INFO - 2020-02-20 16:08:31 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:08:31 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:08:31 --> Utf8 Class Initialized
INFO - 2020-02-20 16:08:31 --> URI Class Initialized
INFO - 2020-02-20 16:08:31 --> Router Class Initialized
INFO - 2020-02-20 16:08:31 --> Output Class Initialized
INFO - 2020-02-20 16:08:31 --> Security Class Initialized
DEBUG - 2020-02-20 16:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:08:31 --> CSRF cookie sent
INFO - 2020-02-20 16:08:31 --> Input Class Initialized
INFO - 2020-02-20 16:08:31 --> Language Class Initialized
INFO - 2020-02-20 16:08:31 --> Language Class Initialized
INFO - 2020-02-20 16:08:31 --> Config Class Initialized
INFO - 2020-02-20 16:08:31 --> Loader Class Initialized
INFO - 2020-02-20 16:08:31 --> Helper loaded: url_helper
INFO - 2020-02-20 16:08:31 --> Helper loaded: common_helper
INFO - 2020-02-20 16:08:31 --> Helper loaded: language_helper
INFO - 2020-02-20 16:08:31 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:08:31 --> Helper loaded: email_helper
INFO - 2020-02-20 16:08:31 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:08:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:08:31 --> Parser Class Initialized
INFO - 2020-02-20 16:08:31 --> User Agent Class Initialized
INFO - 2020-02-20 16:08:31 --> Model Class Initialized
INFO - 2020-02-20 16:08:31 --> Database Driver Class Initialized
INFO - 2020-02-20 16:08:31 --> Model Class Initialized
DEBUG - 2020-02-20 16:08:31 --> Template Class Initialized
INFO - 2020-02-20 16:08:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:08:31 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:08:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:08:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:08:31 --> Encryption Class Initialized
INFO - 2020-02-20 16:08:32 --> Controller Class Initialized
DEBUG - 2020-02-20 16:08:32 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:08:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:32 --> Model Class Initialized
ERROR - 2020-02-20 16:08:32 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:08:32 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:08:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:08:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:08:32 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:08:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:08:32 --> Model Class Initialized
DEBUG - 2020-02-20 16:08:32 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:32 --> Model Class Initialized
DEBUG - 2020-02-20 16:08:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:08:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:08:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:08:32 --> Final output sent to browser
DEBUG - 2020-02-20 16:08:32 --> Total execution time: 0.8292
INFO - 2020-02-20 16:08:33 --> Config Class Initialized
INFO - 2020-02-20 16:08:33 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:08:33 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:08:33 --> Utf8 Class Initialized
INFO - 2020-02-20 16:08:33 --> URI Class Initialized
INFO - 2020-02-20 16:08:33 --> Router Class Initialized
INFO - 2020-02-20 16:08:33 --> Output Class Initialized
INFO - 2020-02-20 16:08:33 --> Security Class Initialized
DEBUG - 2020-02-20 16:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:08:33 --> CSRF cookie sent
INFO - 2020-02-20 16:08:33 --> Input Class Initialized
INFO - 2020-02-20 16:08:34 --> Language Class Initialized
INFO - 2020-02-20 16:08:34 --> Language Class Initialized
INFO - 2020-02-20 16:08:34 --> Config Class Initialized
INFO - 2020-02-20 16:08:34 --> Loader Class Initialized
INFO - 2020-02-20 16:08:34 --> Helper loaded: url_helper
INFO - 2020-02-20 16:08:34 --> Helper loaded: common_helper
INFO - 2020-02-20 16:08:34 --> Helper loaded: language_helper
INFO - 2020-02-20 16:08:34 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:08:34 --> Helper loaded: email_helper
INFO - 2020-02-20 16:08:34 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:08:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:08:34 --> Parser Class Initialized
INFO - 2020-02-20 16:08:34 --> User Agent Class Initialized
INFO - 2020-02-20 16:08:34 --> Model Class Initialized
INFO - 2020-02-20 16:08:34 --> Database Driver Class Initialized
INFO - 2020-02-20 16:08:34 --> Model Class Initialized
DEBUG - 2020-02-20 16:08:34 --> Template Class Initialized
INFO - 2020-02-20 16:08:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:08:34 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:08:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:08:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:08:34 --> Encryption Class Initialized
INFO - 2020-02-20 16:08:34 --> Controller Class Initialized
DEBUG - 2020-02-20 16:08:34 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:08:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:34 --> Model Class Initialized
ERROR - 2020-02-20 16:08:34 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:08:34 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:08:34 --> Could not find the language line "Delele"
DEBUG - 2020-02-20 16:08:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-20 16:08:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:08:34 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:08:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:08:34 --> Model Class Initialized
DEBUG - 2020-02-20 16:08:34 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:34 --> Model Class Initialized
DEBUG - 2020-02-20 16:08:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:08:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:08:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:08:34 --> Final output sent to browser
DEBUG - 2020-02-20 16:08:34 --> Total execution time: 0.8899
INFO - 2020-02-20 16:08:34 --> Config Class Initialized
INFO - 2020-02-20 16:08:34 --> Config Class Initialized
INFO - 2020-02-20 16:08:34 --> Config Class Initialized
INFO - 2020-02-20 16:08:34 --> Config Class Initialized
INFO - 2020-02-20 16:08:34 --> Config Class Initialized
INFO - 2020-02-20 16:08:34 --> Config Class Initialized
INFO - 2020-02-20 16:08:34 --> Hooks Class Initialized
INFO - 2020-02-20 16:08:34 --> Hooks Class Initialized
INFO - 2020-02-20 16:08:34 --> Hooks Class Initialized
INFO - 2020-02-20 16:08:34 --> Hooks Class Initialized
INFO - 2020-02-20 16:08:34 --> Hooks Class Initialized
INFO - 2020-02-20 16:08:34 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:08:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:08:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:08:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:08:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:08:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:08:34 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:08:34 --> Utf8 Class Initialized
INFO - 2020-02-20 16:08:34 --> Utf8 Class Initialized
INFO - 2020-02-20 16:08:34 --> Utf8 Class Initialized
INFO - 2020-02-20 16:08:34 --> Utf8 Class Initialized
INFO - 2020-02-20 16:08:34 --> Utf8 Class Initialized
INFO - 2020-02-20 16:08:34 --> Utf8 Class Initialized
INFO - 2020-02-20 16:08:35 --> URI Class Initialized
INFO - 2020-02-20 16:08:35 --> URI Class Initialized
INFO - 2020-02-20 16:08:35 --> URI Class Initialized
INFO - 2020-02-20 16:08:35 --> URI Class Initialized
INFO - 2020-02-20 16:08:35 --> URI Class Initialized
INFO - 2020-02-20 16:08:35 --> URI Class Initialized
INFO - 2020-02-20 16:08:35 --> Router Class Initialized
INFO - 2020-02-20 16:08:35 --> Router Class Initialized
INFO - 2020-02-20 16:08:35 --> Router Class Initialized
INFO - 2020-02-20 16:08:35 --> Router Class Initialized
INFO - 2020-02-20 16:08:35 --> Router Class Initialized
INFO - 2020-02-20 16:08:35 --> Router Class Initialized
INFO - 2020-02-20 16:08:35 --> Output Class Initialized
INFO - 2020-02-20 16:08:35 --> Output Class Initialized
INFO - 2020-02-20 16:08:35 --> Output Class Initialized
INFO - 2020-02-20 16:08:35 --> Output Class Initialized
INFO - 2020-02-20 16:08:35 --> Output Class Initialized
INFO - 2020-02-20 16:08:35 --> Output Class Initialized
INFO - 2020-02-20 16:08:35 --> Security Class Initialized
INFO - 2020-02-20 16:08:35 --> Security Class Initialized
INFO - 2020-02-20 16:08:35 --> Security Class Initialized
INFO - 2020-02-20 16:08:35 --> Security Class Initialized
INFO - 2020-02-20 16:08:35 --> Security Class Initialized
INFO - 2020-02-20 16:08:35 --> Security Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:08:35 --> CSRF cookie sent
INFO - 2020-02-20 16:08:35 --> CSRF cookie sent
INFO - 2020-02-20 16:08:35 --> CSRF cookie sent
INFO - 2020-02-20 16:08:35 --> CSRF cookie sent
INFO - 2020-02-20 16:08:35 --> CSRF cookie sent
INFO - 2020-02-20 16:08:35 --> CSRF cookie sent
INFO - 2020-02-20 16:08:35 --> CSRF token verified
INFO - 2020-02-20 16:08:35 --> CSRF token verified
INFO - 2020-02-20 16:08:35 --> CSRF token verified
INFO - 2020-02-20 16:08:35 --> CSRF token verified
INFO - 2020-02-20 16:08:35 --> CSRF token verified
INFO - 2020-02-20 16:08:35 --> CSRF token verified
INFO - 2020-02-20 16:08:35 --> Input Class Initialized
INFO - 2020-02-20 16:08:35 --> Input Class Initialized
INFO - 2020-02-20 16:08:35 --> Input Class Initialized
INFO - 2020-02-20 16:08:35 --> Input Class Initialized
INFO - 2020-02-20 16:08:35 --> Input Class Initialized
INFO - 2020-02-20 16:08:35 --> Input Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
INFO - 2020-02-20 16:08:35 --> Config Class Initialized
INFO - 2020-02-20 16:08:35 --> Config Class Initialized
INFO - 2020-02-20 16:08:35 --> Config Class Initialized
INFO - 2020-02-20 16:08:35 --> Config Class Initialized
INFO - 2020-02-20 16:08:35 --> Config Class Initialized
INFO - 2020-02-20 16:08:35 --> Config Class Initialized
INFO - 2020-02-20 16:08:35 --> Loader Class Initialized
INFO - 2020-02-20 16:08:35 --> Loader Class Initialized
INFO - 2020-02-20 16:08:35 --> Loader Class Initialized
INFO - 2020-02-20 16:08:35 --> Loader Class Initialized
INFO - 2020-02-20 16:08:35 --> Loader Class Initialized
INFO - 2020-02-20 16:08:35 --> Loader Class Initialized
INFO - 2020-02-20 16:08:35 --> Helper loaded: url_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: url_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: url_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: url_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: url_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: url_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: common_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: common_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: common_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: common_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: common_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: common_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: language_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: language_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: language_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: language_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: language_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: language_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: email_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: email_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: email_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: email_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: email_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: email_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:08:35 --> Parser Class Initialized
INFO - 2020-02-20 16:08:35 --> Parser Class Initialized
INFO - 2020-02-20 16:08:35 --> Parser Class Initialized
INFO - 2020-02-20 16:08:35 --> Parser Class Initialized
INFO - 2020-02-20 16:08:35 --> Parser Class Initialized
INFO - 2020-02-20 16:08:35 --> Parser Class Initialized
INFO - 2020-02-20 16:08:35 --> User Agent Class Initialized
INFO - 2020-02-20 16:08:35 --> User Agent Class Initialized
INFO - 2020-02-20 16:08:35 --> User Agent Class Initialized
INFO - 2020-02-20 16:08:35 --> User Agent Class Initialized
INFO - 2020-02-20 16:08:35 --> User Agent Class Initialized
INFO - 2020-02-20 16:08:35 --> User Agent Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Database Driver Class Initialized
INFO - 2020-02-20 16:08:35 --> Database Driver Class Initialized
INFO - 2020-02-20 16:08:35 --> Database Driver Class Initialized
INFO - 2020-02-20 16:08:35 --> Database Driver Class Initialized
INFO - 2020-02-20 16:08:35 --> Database Driver Class Initialized
INFO - 2020-02-20 16:08:35 --> Database Driver Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Template Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Template Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Template Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Template Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Template Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Template Class Initialized
INFO - 2020-02-20 16:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:08:35 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:08:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:08:35 --> Encryption Class Initialized
INFO - 2020-02-20 16:08:35 --> Controller Class Initialized
DEBUG - 2020-02-20 16:08:35 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:08:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
ERROR - 2020-02-20 16:08:35 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:08:35 --> Could not find the language line "View"
ERROR - 2020-02-20 16:08:35 --> Could not find the language line "View"
ERROR - 2020-02-20 16:08:35 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:08:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:08:35 --> Final output sent to browser
DEBUG - 2020-02-20 16:08:35 --> Total execution time: 0.7143
INFO - 2020-02-20 16:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:08:35 --> Config Class Initialized
INFO - 2020-02-20 16:08:35 --> Hooks Class Initialized
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:08:35 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:08:35 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:08:35 --> Utf8 Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:08:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:08:35 --> URI Class Initialized
INFO - 2020-02-20 16:08:35 --> Encryption Class Initialized
INFO - 2020-02-20 16:08:35 --> Router Class Initialized
INFO - 2020-02-20 16:08:35 --> Controller Class Initialized
INFO - 2020-02-20 16:08:35 --> Output Class Initialized
DEBUG - 2020-02-20 16:08:35 --> category MX_Controller Initialized
INFO - 2020-02-20 16:08:35 --> Security Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:08:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:35 --> CSRF cookie sent
INFO - 2020-02-20 16:08:35 --> CSRF token verified
ERROR - 2020-02-20 16:08:35 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:08:35 --> Input Class Initialized
ERROR - 2020-02-20 16:08:35 --> Could not find the language line "View"
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
ERROR - 2020-02-20 16:08:35 --> Could not find the language line "View"
INFO - 2020-02-20 16:08:35 --> Language Class Initialized
ERROR - 2020-02-20 16:08:35 --> Could not find the language line "View"
INFO - 2020-02-20 16:08:35 --> Config Class Initialized
DEBUG - 2020-02-20 16:08:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:08:35 --> Final output sent to browser
INFO - 2020-02-20 16:08:35 --> Loader Class Initialized
DEBUG - 2020-02-20 16:08:35 --> Total execution time: 0.9362
INFO - 2020-02-20 16:08:35 --> Helper loaded: url_helper
INFO - 2020-02-20 16:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:08:35 --> Helper loaded: common_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: language_helper
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:08:35 --> Pagination Class Initialized
INFO - 2020-02-20 16:08:35 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:08:35 --> Helper loaded: email_helper
DEBUG - 2020-02-20 16:08:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:08:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:08:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:08:35 --> Encryption Class Initialized
INFO - 2020-02-20 16:08:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:08:35 --> Controller Class Initialized
INFO - 2020-02-20 16:08:35 --> Parser Class Initialized
DEBUG - 2020-02-20 16:08:35 --> category MX_Controller Initialized
INFO - 2020-02-20 16:08:35 --> User Agent Class Initialized
DEBUG - 2020-02-20 16:08:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:35 --> Model Class Initialized
INFO - 2020-02-20 16:08:36 --> Model Class Initialized
INFO - 2020-02-20 16:08:36 --> Database Driver Class Initialized
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:08:36 --> Model Class Initialized
DEBUG - 2020-02-20 16:08:36 --> Template Class Initialized
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "View"
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "View"
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "View"
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "View"
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:08:36 --> Final output sent to browser
DEBUG - 2020-02-20 16:08:36 --> Total execution time: 1.2256
INFO - 2020-02-20 16:08:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:08:36 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:08:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:08:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:08:36 --> Encryption Class Initialized
INFO - 2020-02-20 16:08:36 --> Controller Class Initialized
DEBUG - 2020-02-20 16:08:36 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:36 --> Model Class Initialized
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:08:36 --> Final output sent to browser
DEBUG - 2020-02-20 16:08:36 --> Total execution time: 1.4515
INFO - 2020-02-20 16:08:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:08:36 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:08:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:08:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:08:36 --> Encryption Class Initialized
INFO - 2020-02-20 16:08:36 --> Controller Class Initialized
DEBUG - 2020-02-20 16:08:36 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:36 --> Model Class Initialized
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:08:36 --> Final output sent to browser
DEBUG - 2020-02-20 16:08:36 --> Total execution time: 1.6718
INFO - 2020-02-20 16:08:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:08:36 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:08:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:08:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:08:36 --> Encryption Class Initialized
INFO - 2020-02-20 16:08:36 --> Controller Class Initialized
DEBUG - 2020-02-20 16:08:36 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:36 --> Model Class Initialized
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:08:36 --> Final output sent to browser
DEBUG - 2020-02-20 16:08:36 --> Total execution time: 1.8835
INFO - 2020-02-20 16:08:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:08:36 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:08:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:08:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:08:36 --> Encryption Class Initialized
INFO - 2020-02-20 16:08:36 --> Controller Class Initialized
DEBUG - 2020-02-20 16:08:36 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:08:36 --> Model Class Initialized
ERROR - 2020-02-20 16:08:36 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:08:37 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:08:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:08:37 --> Final output sent to browser
DEBUG - 2020-02-20 16:08:37 --> Total execution time: 1.3753
INFO - 2020-02-20 16:09:16 --> Config Class Initialized
INFO - 2020-02-20 16:09:16 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:09:16 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:09:16 --> Utf8 Class Initialized
INFO - 2020-02-20 16:09:16 --> URI Class Initialized
INFO - 2020-02-20 16:09:16 --> Router Class Initialized
INFO - 2020-02-20 16:09:16 --> Output Class Initialized
INFO - 2020-02-20 16:09:16 --> Security Class Initialized
DEBUG - 2020-02-20 16:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:09:16 --> CSRF cookie sent
INFO - 2020-02-20 16:09:16 --> Input Class Initialized
INFO - 2020-02-20 16:09:16 --> Language Class Initialized
INFO - 2020-02-20 16:09:16 --> Language Class Initialized
INFO - 2020-02-20 16:09:16 --> Config Class Initialized
INFO - 2020-02-20 16:09:16 --> Loader Class Initialized
INFO - 2020-02-20 16:09:16 --> Helper loaded: url_helper
INFO - 2020-02-20 16:09:16 --> Helper loaded: common_helper
INFO - 2020-02-20 16:09:17 --> Helper loaded: language_helper
INFO - 2020-02-20 16:09:17 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:09:17 --> Helper loaded: email_helper
INFO - 2020-02-20 16:09:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:09:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:09:17 --> Parser Class Initialized
INFO - 2020-02-20 16:09:17 --> User Agent Class Initialized
INFO - 2020-02-20 16:09:17 --> Model Class Initialized
INFO - 2020-02-20 16:09:17 --> Database Driver Class Initialized
INFO - 2020-02-20 16:09:17 --> Model Class Initialized
DEBUG - 2020-02-20 16:09:17 --> Template Class Initialized
INFO - 2020-02-20 16:09:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:09:17 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:09:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:09:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:09:17 --> Encryption Class Initialized
INFO - 2020-02-20 16:09:17 --> Controller Class Initialized
DEBUG - 2020-02-20 16:09:17 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:09:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:09:17 --> Model Class Initialized
ERROR - 2020-02-20 16:09:17 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:09:17 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:09:17 --> Could not find the language line "Delele"
DEBUG - 2020-02-20 16:09:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-20 16:09:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:09:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:09:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:09:17 --> Model Class Initialized
DEBUG - 2020-02-20 16:09:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:09:17 --> Model Class Initialized
DEBUG - 2020-02-20 16:09:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:09:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:09:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:09:17 --> Final output sent to browser
DEBUG - 2020-02-20 16:09:17 --> Total execution time: 0.9041
INFO - 2020-02-20 16:09:17 --> Config Class Initialized
INFO - 2020-02-20 16:09:17 --> Config Class Initialized
INFO - 2020-02-20 16:09:17 --> Config Class Initialized
INFO - 2020-02-20 16:09:17 --> Config Class Initialized
INFO - 2020-02-20 16:09:17 --> Config Class Initialized
INFO - 2020-02-20 16:09:17 --> Config Class Initialized
INFO - 2020-02-20 16:09:18 --> Hooks Class Initialized
INFO - 2020-02-20 16:09:18 --> Hooks Class Initialized
INFO - 2020-02-20 16:09:18 --> Hooks Class Initialized
INFO - 2020-02-20 16:09:18 --> Hooks Class Initialized
INFO - 2020-02-20 16:09:18 --> Hooks Class Initialized
INFO - 2020-02-20 16:09:18 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:09:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:09:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:09:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:09:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:09:18 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:09:18 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:09:18 --> Utf8 Class Initialized
INFO - 2020-02-20 16:09:18 --> Utf8 Class Initialized
INFO - 2020-02-20 16:09:18 --> Utf8 Class Initialized
INFO - 2020-02-20 16:09:18 --> Utf8 Class Initialized
INFO - 2020-02-20 16:09:18 --> Utf8 Class Initialized
INFO - 2020-02-20 16:09:18 --> Utf8 Class Initialized
INFO - 2020-02-20 16:09:18 --> URI Class Initialized
INFO - 2020-02-20 16:09:18 --> URI Class Initialized
INFO - 2020-02-20 16:09:18 --> URI Class Initialized
INFO - 2020-02-20 16:09:18 --> URI Class Initialized
INFO - 2020-02-20 16:09:18 --> URI Class Initialized
INFO - 2020-02-20 16:09:18 --> URI Class Initialized
INFO - 2020-02-20 16:09:18 --> Router Class Initialized
INFO - 2020-02-20 16:09:18 --> Router Class Initialized
INFO - 2020-02-20 16:09:18 --> Router Class Initialized
INFO - 2020-02-20 16:09:18 --> Router Class Initialized
INFO - 2020-02-20 16:09:18 --> Router Class Initialized
INFO - 2020-02-20 16:09:18 --> Router Class Initialized
INFO - 2020-02-20 16:09:18 --> Output Class Initialized
INFO - 2020-02-20 16:09:18 --> Output Class Initialized
INFO - 2020-02-20 16:09:18 --> Output Class Initialized
INFO - 2020-02-20 16:09:18 --> Output Class Initialized
INFO - 2020-02-20 16:09:18 --> Output Class Initialized
INFO - 2020-02-20 16:09:18 --> Output Class Initialized
INFO - 2020-02-20 16:09:18 --> Security Class Initialized
INFO - 2020-02-20 16:09:18 --> Security Class Initialized
INFO - 2020-02-20 16:09:18 --> Security Class Initialized
INFO - 2020-02-20 16:09:18 --> Security Class Initialized
INFO - 2020-02-20 16:09:18 --> Security Class Initialized
INFO - 2020-02-20 16:09:18 --> Security Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:09:18 --> CSRF cookie sent
INFO - 2020-02-20 16:09:18 --> CSRF cookie sent
INFO - 2020-02-20 16:09:18 --> CSRF cookie sent
INFO - 2020-02-20 16:09:18 --> CSRF cookie sent
INFO - 2020-02-20 16:09:18 --> CSRF cookie sent
INFO - 2020-02-20 16:09:18 --> CSRF cookie sent
INFO - 2020-02-20 16:09:18 --> CSRF token verified
INFO - 2020-02-20 16:09:18 --> CSRF token verified
INFO - 2020-02-20 16:09:18 --> CSRF token verified
INFO - 2020-02-20 16:09:18 --> CSRF token verified
INFO - 2020-02-20 16:09:18 --> CSRF token verified
INFO - 2020-02-20 16:09:18 --> CSRF token verified
INFO - 2020-02-20 16:09:18 --> Input Class Initialized
INFO - 2020-02-20 16:09:18 --> Input Class Initialized
INFO - 2020-02-20 16:09:18 --> Input Class Initialized
INFO - 2020-02-20 16:09:18 --> Input Class Initialized
INFO - 2020-02-20 16:09:18 --> Input Class Initialized
INFO - 2020-02-20 16:09:18 --> Input Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Config Class Initialized
INFO - 2020-02-20 16:09:18 --> Config Class Initialized
INFO - 2020-02-20 16:09:18 --> Config Class Initialized
INFO - 2020-02-20 16:09:18 --> Config Class Initialized
INFO - 2020-02-20 16:09:18 --> Config Class Initialized
INFO - 2020-02-20 16:09:18 --> Config Class Initialized
INFO - 2020-02-20 16:09:18 --> Loader Class Initialized
INFO - 2020-02-20 16:09:18 --> Loader Class Initialized
INFO - 2020-02-20 16:09:18 --> Loader Class Initialized
INFO - 2020-02-20 16:09:18 --> Loader Class Initialized
INFO - 2020-02-20 16:09:18 --> Loader Class Initialized
INFO - 2020-02-20 16:09:18 --> Loader Class Initialized
INFO - 2020-02-20 16:09:18 --> Helper loaded: url_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: url_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: url_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: url_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: url_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: url_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: common_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: common_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: common_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: common_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: common_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: common_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: language_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: language_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: language_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: language_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: language_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: language_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: email_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: email_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: email_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: email_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: email_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: email_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:09:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:09:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:09:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:09:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:09:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:09:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:09:18 --> Parser Class Initialized
INFO - 2020-02-20 16:09:18 --> Parser Class Initialized
INFO - 2020-02-20 16:09:18 --> Parser Class Initialized
INFO - 2020-02-20 16:09:18 --> Parser Class Initialized
INFO - 2020-02-20 16:09:18 --> Parser Class Initialized
INFO - 2020-02-20 16:09:18 --> Parser Class Initialized
INFO - 2020-02-20 16:09:18 --> User Agent Class Initialized
INFO - 2020-02-20 16:09:18 --> User Agent Class Initialized
INFO - 2020-02-20 16:09:18 --> User Agent Class Initialized
INFO - 2020-02-20 16:09:18 --> User Agent Class Initialized
INFO - 2020-02-20 16:09:18 --> User Agent Class Initialized
INFO - 2020-02-20 16:09:18 --> User Agent Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Database Driver Class Initialized
INFO - 2020-02-20 16:09:18 --> Database Driver Class Initialized
INFO - 2020-02-20 16:09:18 --> Database Driver Class Initialized
INFO - 2020-02-20 16:09:18 --> Database Driver Class Initialized
INFO - 2020-02-20 16:09:18 --> Database Driver Class Initialized
INFO - 2020-02-20 16:09:18 --> Database Driver Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Template Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Template Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Template Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Template Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Template Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Template Class Initialized
INFO - 2020-02-20 16:09:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:09:18 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:09:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:09:18 --> Encryption Class Initialized
INFO - 2020-02-20 16:09:18 --> Controller Class Initialized
DEBUG - 2020-02-20 16:09:18 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:09:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
ERROR - 2020-02-20 16:09:18 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:09:18 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:09:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:09:18 --> Final output sent to browser
DEBUG - 2020-02-20 16:09:18 --> Total execution time: 0.6876
INFO - 2020-02-20 16:09:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:09:18 --> Config Class Initialized
INFO - 2020-02-20 16:09:18 --> Hooks Class Initialized
INFO - 2020-02-20 16:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:09:18 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:09:18 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:09:18 --> Utf8 Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:09:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:09:18 --> URI Class Initialized
INFO - 2020-02-20 16:09:18 --> Encryption Class Initialized
INFO - 2020-02-20 16:09:18 --> Router Class Initialized
INFO - 2020-02-20 16:09:18 --> Controller Class Initialized
INFO - 2020-02-20 16:09:18 --> Output Class Initialized
DEBUG - 2020-02-20 16:09:18 --> category MX_Controller Initialized
INFO - 2020-02-20 16:09:18 --> Security Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:09:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:09:18 --> Model Class Initialized
INFO - 2020-02-20 16:09:18 --> CSRF cookie sent
INFO - 2020-02-20 16:09:18 --> CSRF token verified
ERROR - 2020-02-20 16:09:18 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:09:18 --> Input Class Initialized
ERROR - 2020-02-20 16:09:18 --> Could not find the language line "View"
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
DEBUG - 2020-02-20 16:09:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:09:18 --> Final output sent to browser
INFO - 2020-02-20 16:09:18 --> Language Class Initialized
INFO - 2020-02-20 16:09:18 --> Config Class Initialized
DEBUG - 2020-02-20 16:09:18 --> Total execution time: 0.9226
INFO - 2020-02-20 16:09:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:09:18 --> Loader Class Initialized
INFO - 2020-02-20 16:09:18 --> Helper loaded: url_helper
INFO - 2020-02-20 16:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:09:18 --> Pagination Class Initialized
INFO - 2020-02-20 16:09:18 --> Helper loaded: common_helper
INFO - 2020-02-20 16:09:18 --> Helper loaded: language_helper
DEBUG - 2020-02-20 16:09:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:09:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:09:18 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:09:19 --> Encryption Class Initialized
INFO - 2020-02-20 16:09:19 --> Helper loaded: email_helper
INFO - 2020-02-20 16:09:19 --> Controller Class Initialized
INFO - 2020-02-20 16:09:19 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-20 16:09:19 --> category MX_Controller Initialized
INFO - 2020-02-20 16:09:19 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-20 16:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:09:19 --> Parser Class Initialized
INFO - 2020-02-20 16:09:19 --> Model Class Initialized
INFO - 2020-02-20 16:09:19 --> User Agent Class Initialized
INFO - 2020-02-20 16:09:19 --> Model Class Initialized
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:09:19 --> Database Driver Class Initialized
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:09:19 --> Model Class Initialized
INFO - 2020-02-20 16:09:19 --> Final output sent to browser
DEBUG - 2020-02-20 16:09:19 --> Template Class Initialized
DEBUG - 2020-02-20 16:09:19 --> Total execution time: 1.1537
INFO - 2020-02-20 16:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:09:19 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:09:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:09:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:09:19 --> Encryption Class Initialized
INFO - 2020-02-20 16:09:19 --> Controller Class Initialized
DEBUG - 2020-02-20 16:09:19 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:09:19 --> Model Class Initialized
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:09:19 --> Final output sent to browser
DEBUG - 2020-02-20 16:09:19 --> Total execution time: 1.4333
INFO - 2020-02-20 16:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:09:19 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:09:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:09:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:09:19 --> Encryption Class Initialized
INFO - 2020-02-20 16:09:19 --> Controller Class Initialized
DEBUG - 2020-02-20 16:09:19 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:09:19 --> Model Class Initialized
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:09:19 --> Final output sent to browser
DEBUG - 2020-02-20 16:09:19 --> Total execution time: 1.7002
INFO - 2020-02-20 16:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:09:19 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:09:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:09:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:09:19 --> Encryption Class Initialized
INFO - 2020-02-20 16:09:19 --> Controller Class Initialized
DEBUG - 2020-02-20 16:09:19 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:09:19 --> Model Class Initialized
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
ERROR - 2020-02-20 16:09:19 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:09:19 --> Final output sent to browser
DEBUG - 2020-02-20 16:09:19 --> Total execution time: 1.9752
INFO - 2020-02-20 16:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:09:20 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:09:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:09:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:09:20 --> Encryption Class Initialized
INFO - 2020-02-20 16:09:20 --> Controller Class Initialized
DEBUG - 2020-02-20 16:09:20 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:09:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:09:20 --> Model Class Initialized
ERROR - 2020-02-20 16:09:20 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:09:20 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:09:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:09:20 --> Final output sent to browser
DEBUG - 2020-02-20 16:09:20 --> Total execution time: 1.4865
INFO - 2020-02-20 16:10:46 --> Config Class Initialized
INFO - 2020-02-20 16:10:46 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:10:46 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:10:46 --> Utf8 Class Initialized
INFO - 2020-02-20 16:10:46 --> URI Class Initialized
INFO - 2020-02-20 16:10:46 --> Router Class Initialized
INFO - 2020-02-20 16:10:46 --> Output Class Initialized
INFO - 2020-02-20 16:10:46 --> Security Class Initialized
DEBUG - 2020-02-20 16:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:10:46 --> CSRF cookie sent
INFO - 2020-02-20 16:10:46 --> Input Class Initialized
INFO - 2020-02-20 16:10:46 --> Language Class Initialized
INFO - 2020-02-20 16:10:46 --> Language Class Initialized
INFO - 2020-02-20 16:10:46 --> Config Class Initialized
INFO - 2020-02-20 16:10:46 --> Loader Class Initialized
INFO - 2020-02-20 16:10:46 --> Helper loaded: url_helper
INFO - 2020-02-20 16:10:46 --> Helper loaded: common_helper
INFO - 2020-02-20 16:10:46 --> Helper loaded: language_helper
INFO - 2020-02-20 16:10:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:10:46 --> Helper loaded: email_helper
INFO - 2020-02-20 16:10:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:10:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:10:46 --> Parser Class Initialized
INFO - 2020-02-20 16:10:46 --> User Agent Class Initialized
INFO - 2020-02-20 16:10:47 --> Model Class Initialized
INFO - 2020-02-20 16:10:47 --> Database Driver Class Initialized
INFO - 2020-02-20 16:10:47 --> Model Class Initialized
DEBUG - 2020-02-20 16:10:47 --> Template Class Initialized
INFO - 2020-02-20 16:10:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:10:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:10:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:10:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:10:47 --> Encryption Class Initialized
INFO - 2020-02-20 16:10:47 --> Controller Class Initialized
DEBUG - 2020-02-20 16:10:47 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:10:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:47 --> Model Class Initialized
ERROR - 2020-02-20 16:10:47 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:10:47 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:10:47 --> Could not find the language line "Delele"
DEBUG - 2020-02-20 16:10:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-20 16:10:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:10:47 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:10:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:10:47 --> Model Class Initialized
DEBUG - 2020-02-20 16:10:47 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:47 --> Model Class Initialized
DEBUG - 2020-02-20 16:10:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:10:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:10:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:10:47 --> Final output sent to browser
DEBUG - 2020-02-20 16:10:47 --> Total execution time: 0.9377
INFO - 2020-02-20 16:10:47 --> Config Class Initialized
INFO - 2020-02-20 16:10:47 --> Config Class Initialized
INFO - 2020-02-20 16:10:47 --> Config Class Initialized
INFO - 2020-02-20 16:10:47 --> Config Class Initialized
INFO - 2020-02-20 16:10:47 --> Config Class Initialized
INFO - 2020-02-20 16:10:47 --> Config Class Initialized
INFO - 2020-02-20 16:10:47 --> Hooks Class Initialized
INFO - 2020-02-20 16:10:47 --> Hooks Class Initialized
INFO - 2020-02-20 16:10:47 --> Hooks Class Initialized
INFO - 2020-02-20 16:10:47 --> Hooks Class Initialized
INFO - 2020-02-20 16:10:47 --> Hooks Class Initialized
INFO - 2020-02-20 16:10:47 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:10:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:10:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:10:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:10:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:10:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:10:47 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:10:47 --> Utf8 Class Initialized
INFO - 2020-02-20 16:10:47 --> Utf8 Class Initialized
INFO - 2020-02-20 16:10:47 --> Utf8 Class Initialized
INFO - 2020-02-20 16:10:47 --> Utf8 Class Initialized
INFO - 2020-02-20 16:10:47 --> Utf8 Class Initialized
INFO - 2020-02-20 16:10:47 --> Utf8 Class Initialized
INFO - 2020-02-20 16:10:47 --> URI Class Initialized
INFO - 2020-02-20 16:10:47 --> URI Class Initialized
INFO - 2020-02-20 16:10:47 --> URI Class Initialized
INFO - 2020-02-20 16:10:47 --> URI Class Initialized
INFO - 2020-02-20 16:10:47 --> URI Class Initialized
INFO - 2020-02-20 16:10:47 --> URI Class Initialized
INFO - 2020-02-20 16:10:47 --> Router Class Initialized
INFO - 2020-02-20 16:10:47 --> Router Class Initialized
INFO - 2020-02-20 16:10:47 --> Router Class Initialized
INFO - 2020-02-20 16:10:47 --> Router Class Initialized
INFO - 2020-02-20 16:10:47 --> Router Class Initialized
INFO - 2020-02-20 16:10:47 --> Router Class Initialized
INFO - 2020-02-20 16:10:47 --> Output Class Initialized
INFO - 2020-02-20 16:10:47 --> Output Class Initialized
INFO - 2020-02-20 16:10:47 --> Output Class Initialized
INFO - 2020-02-20 16:10:47 --> Output Class Initialized
INFO - 2020-02-20 16:10:47 --> Output Class Initialized
INFO - 2020-02-20 16:10:47 --> Output Class Initialized
INFO - 2020-02-20 16:10:47 --> Security Class Initialized
INFO - 2020-02-20 16:10:47 --> Security Class Initialized
INFO - 2020-02-20 16:10:47 --> Security Class Initialized
INFO - 2020-02-20 16:10:47 --> Security Class Initialized
INFO - 2020-02-20 16:10:47 --> Security Class Initialized
INFO - 2020-02-20 16:10:47 --> Security Class Initialized
DEBUG - 2020-02-20 16:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:10:48 --> CSRF cookie sent
INFO - 2020-02-20 16:10:48 --> CSRF cookie sent
INFO - 2020-02-20 16:10:48 --> CSRF cookie sent
INFO - 2020-02-20 16:10:48 --> CSRF cookie sent
INFO - 2020-02-20 16:10:48 --> CSRF cookie sent
INFO - 2020-02-20 16:10:48 --> CSRF cookie sent
INFO - 2020-02-20 16:10:48 --> CSRF token verified
INFO - 2020-02-20 16:10:48 --> CSRF token verified
INFO - 2020-02-20 16:10:48 --> CSRF token verified
INFO - 2020-02-20 16:10:48 --> CSRF token verified
INFO - 2020-02-20 16:10:48 --> CSRF token verified
INFO - 2020-02-20 16:10:48 --> CSRF token verified
INFO - 2020-02-20 16:10:48 --> Input Class Initialized
INFO - 2020-02-20 16:10:48 --> Input Class Initialized
INFO - 2020-02-20 16:10:48 --> Input Class Initialized
INFO - 2020-02-20 16:10:48 --> Input Class Initialized
INFO - 2020-02-20 16:10:48 --> Input Class Initialized
INFO - 2020-02-20 16:10:48 --> Input Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
INFO - 2020-02-20 16:10:48 --> Config Class Initialized
INFO - 2020-02-20 16:10:48 --> Config Class Initialized
INFO - 2020-02-20 16:10:48 --> Config Class Initialized
INFO - 2020-02-20 16:10:48 --> Config Class Initialized
INFO - 2020-02-20 16:10:48 --> Config Class Initialized
INFO - 2020-02-20 16:10:48 --> Config Class Initialized
INFO - 2020-02-20 16:10:48 --> Loader Class Initialized
INFO - 2020-02-20 16:10:48 --> Loader Class Initialized
INFO - 2020-02-20 16:10:48 --> Loader Class Initialized
INFO - 2020-02-20 16:10:48 --> Loader Class Initialized
INFO - 2020-02-20 16:10:48 --> Loader Class Initialized
INFO - 2020-02-20 16:10:48 --> Loader Class Initialized
INFO - 2020-02-20 16:10:48 --> Helper loaded: url_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: url_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: url_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: url_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: url_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: url_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: common_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: common_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: common_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: common_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: common_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: common_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: language_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: language_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: language_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: language_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: language_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: language_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: email_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: email_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: email_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: email_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: email_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: email_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:10:48 --> Parser Class Initialized
INFO - 2020-02-20 16:10:48 --> Parser Class Initialized
INFO - 2020-02-20 16:10:48 --> Parser Class Initialized
INFO - 2020-02-20 16:10:48 --> Parser Class Initialized
INFO - 2020-02-20 16:10:48 --> Parser Class Initialized
INFO - 2020-02-20 16:10:48 --> Parser Class Initialized
INFO - 2020-02-20 16:10:48 --> User Agent Class Initialized
INFO - 2020-02-20 16:10:48 --> User Agent Class Initialized
INFO - 2020-02-20 16:10:48 --> User Agent Class Initialized
INFO - 2020-02-20 16:10:48 --> User Agent Class Initialized
INFO - 2020-02-20 16:10:48 --> User Agent Class Initialized
INFO - 2020-02-20 16:10:48 --> User Agent Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Database Driver Class Initialized
INFO - 2020-02-20 16:10:48 --> Database Driver Class Initialized
INFO - 2020-02-20 16:10:48 --> Database Driver Class Initialized
INFO - 2020-02-20 16:10:48 --> Database Driver Class Initialized
INFO - 2020-02-20 16:10:48 --> Database Driver Class Initialized
INFO - 2020-02-20 16:10:48 --> Database Driver Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Template Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Template Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Template Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Template Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Template Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Template Class Initialized
INFO - 2020-02-20 16:10:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:10:48 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:10:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:10:48 --> Encryption Class Initialized
INFO - 2020-02-20 16:10:48 --> Controller Class Initialized
DEBUG - 2020-02-20 16:10:48 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
ERROR - 2020-02-20 16:10:48 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:10:48 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:10:48 --> Final output sent to browser
DEBUG - 2020-02-20 16:10:48 --> Total execution time: 0.6876
INFO - 2020-02-20 16:10:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:10:48 --> Config Class Initialized
INFO - 2020-02-20 16:10:48 --> Hooks Class Initialized
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:10:48 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:10:48 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:10:48 --> Utf8 Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:10:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:10:48 --> URI Class Initialized
INFO - 2020-02-20 16:10:48 --> Encryption Class Initialized
INFO - 2020-02-20 16:10:48 --> Router Class Initialized
INFO - 2020-02-20 16:10:48 --> Controller Class Initialized
INFO - 2020-02-20 16:10:48 --> Output Class Initialized
DEBUG - 2020-02-20 16:10:48 --> category MX_Controller Initialized
INFO - 2020-02-20 16:10:48 --> Security Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> CSRF cookie sent
INFO - 2020-02-20 16:10:48 --> CSRF token verified
ERROR - 2020-02-20 16:10:48 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:10:48 --> Input Class Initialized
ERROR - 2020-02-20 16:10:48 --> Could not find the language line "View"
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
ERROR - 2020-02-20 16:10:48 --> Could not find the language line "View"
INFO - 2020-02-20 16:10:48 --> Language Class Initialized
ERROR - 2020-02-20 16:10:48 --> Could not find the language line "View"
INFO - 2020-02-20 16:10:48 --> Config Class Initialized
DEBUG - 2020-02-20 16:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:10:48 --> Final output sent to browser
INFO - 2020-02-20 16:10:48 --> Loader Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Total execution time: 0.9270
INFO - 2020-02-20 16:10:48 --> Helper loaded: url_helper
INFO - 2020-02-20 16:10:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:10:48 --> Helper loaded: common_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: language_helper
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:10:48 --> Pagination Class Initialized
INFO - 2020-02-20 16:10:48 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:10:48 --> Helper loaded: email_helper
DEBUG - 2020-02-20 16:10:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:10:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:10:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:10:48 --> Encryption Class Initialized
INFO - 2020-02-20 16:10:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:10:48 --> Controller Class Initialized
INFO - 2020-02-20 16:10:48 --> Parser Class Initialized
DEBUG - 2020-02-20 16:10:48 --> category MX_Controller Initialized
INFO - 2020-02-20 16:10:48 --> User Agent Class Initialized
DEBUG - 2020-02-20 16:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
INFO - 2020-02-20 16:10:48 --> Database Driver Class Initialized
ERROR - 2020-02-20 16:10:48 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:10:48 --> Model Class Initialized
DEBUG - 2020-02-20 16:10:48 --> Template Class Initialized
ERROR - 2020-02-20 16:10:48 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:10:48 --> Final output sent to browser
DEBUG - 2020-02-20 16:10:48 --> Total execution time: 1.1367
INFO - 2020-02-20 16:10:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:10:49 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:10:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:10:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:10:49 --> Encryption Class Initialized
INFO - 2020-02-20 16:10:49 --> Controller Class Initialized
DEBUG - 2020-02-20 16:10:49 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:49 --> Model Class Initialized
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:10:49 --> Final output sent to browser
DEBUG - 2020-02-20 16:10:49 --> Total execution time: 1.4086
INFO - 2020-02-20 16:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:10:49 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:10:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:10:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:10:49 --> Encryption Class Initialized
INFO - 2020-02-20 16:10:49 --> Controller Class Initialized
DEBUG - 2020-02-20 16:10:49 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:49 --> Model Class Initialized
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:10:49 --> Final output sent to browser
DEBUG - 2020-02-20 16:10:49 --> Total execution time: 1.7245
INFO - 2020-02-20 16:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:10:49 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:10:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:10:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:10:49 --> Encryption Class Initialized
INFO - 2020-02-20 16:10:49 --> Controller Class Initialized
DEBUG - 2020-02-20 16:10:49 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:49 --> Model Class Initialized
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:10:49 --> Final output sent to browser
DEBUG - 2020-02-20 16:10:49 --> Total execution time: 1.9477
INFO - 2020-02-20 16:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:10:49 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:10:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:10:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:10:49 --> Encryption Class Initialized
INFO - 2020-02-20 16:10:49 --> Controller Class Initialized
DEBUG - 2020-02-20 16:10:49 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:49 --> Model Class Initialized
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:10:49 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:10:49 --> Final output sent to browser
DEBUG - 2020-02-20 16:10:50 --> Total execution time: 1.4453
INFO - 2020-02-20 16:10:50 --> Config Class Initialized
INFO - 2020-02-20 16:10:50 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:10:50 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:10:50 --> Utf8 Class Initialized
INFO - 2020-02-20 16:10:50 --> URI Class Initialized
INFO - 2020-02-20 16:10:50 --> Router Class Initialized
INFO - 2020-02-20 16:10:50 --> Output Class Initialized
INFO - 2020-02-20 16:10:50 --> Security Class Initialized
DEBUG - 2020-02-20 16:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:10:50 --> CSRF cookie sent
INFO - 2020-02-20 16:10:51 --> Input Class Initialized
INFO - 2020-02-20 16:10:51 --> Language Class Initialized
INFO - 2020-02-20 16:10:51 --> Language Class Initialized
INFO - 2020-02-20 16:10:51 --> Config Class Initialized
INFO - 2020-02-20 16:10:51 --> Loader Class Initialized
INFO - 2020-02-20 16:10:51 --> Helper loaded: url_helper
INFO - 2020-02-20 16:10:51 --> Helper loaded: common_helper
INFO - 2020-02-20 16:10:51 --> Helper loaded: language_helper
INFO - 2020-02-20 16:10:51 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:10:51 --> Helper loaded: email_helper
INFO - 2020-02-20 16:10:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:10:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:10:51 --> Parser Class Initialized
INFO - 2020-02-20 16:10:51 --> User Agent Class Initialized
INFO - 2020-02-20 16:10:51 --> Model Class Initialized
INFO - 2020-02-20 16:10:51 --> Database Driver Class Initialized
INFO - 2020-02-20 16:10:51 --> Model Class Initialized
DEBUG - 2020-02-20 16:10:51 --> Template Class Initialized
INFO - 2020-02-20 16:10:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:10:51 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:10:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:10:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:10:51 --> Encryption Class Initialized
INFO - 2020-02-20 16:10:51 --> Controller Class Initialized
DEBUG - 2020-02-20 16:10:51 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:10:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:51 --> Model Class Initialized
ERROR - 2020-02-20 16:10:51 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:10:51 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:10:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:10:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:10:51 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:10:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:10:51 --> Model Class Initialized
DEBUG - 2020-02-20 16:10:51 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:10:51 --> Model Class Initialized
DEBUG - 2020-02-20 16:10:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:10:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:10:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:10:51 --> Final output sent to browser
DEBUG - 2020-02-20 16:10:51 --> Total execution time: 0.8694
INFO - 2020-02-20 16:16:35 --> Config Class Initialized
INFO - 2020-02-20 16:16:36 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:16:36 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:16:36 --> Utf8 Class Initialized
INFO - 2020-02-20 16:16:36 --> URI Class Initialized
INFO - 2020-02-20 16:16:36 --> Router Class Initialized
INFO - 2020-02-20 16:16:36 --> Output Class Initialized
INFO - 2020-02-20 16:16:36 --> Security Class Initialized
DEBUG - 2020-02-20 16:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:16:36 --> CSRF cookie sent
INFO - 2020-02-20 16:16:36 --> Input Class Initialized
INFO - 2020-02-20 16:16:36 --> Language Class Initialized
INFO - 2020-02-20 16:16:36 --> Language Class Initialized
INFO - 2020-02-20 16:16:36 --> Config Class Initialized
INFO - 2020-02-20 16:16:36 --> Loader Class Initialized
INFO - 2020-02-20 16:16:36 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:36 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:36 --> Helper loaded: language_helper
INFO - 2020-02-20 16:16:36 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:36 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:36 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:16:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:16:36 --> Parser Class Initialized
INFO - 2020-02-20 16:16:36 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:36 --> Model Class Initialized
INFO - 2020-02-20 16:16:36 --> Database Driver Class Initialized
INFO - 2020-02-20 16:16:36 --> Model Class Initialized
DEBUG - 2020-02-20 16:16:36 --> Template Class Initialized
INFO - 2020-02-20 16:16:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:16:36 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:16:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:16:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:16:36 --> Encryption Class Initialized
INFO - 2020-02-20 16:16:36 --> Controller Class Initialized
DEBUG - 2020-02-20 16:16:36 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:16:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:36 --> Model Class Initialized
ERROR - 2020-02-20 16:16:36 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:16:36 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:16:36 --> Could not find the language line "Delele"
DEBUG - 2020-02-20 16:16:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-20 16:16:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:16:36 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:16:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:16:36 --> Model Class Initialized
DEBUG - 2020-02-20 16:16:36 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:36 --> Model Class Initialized
DEBUG - 2020-02-20 16:16:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:16:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:16:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:16:36 --> Final output sent to browser
DEBUG - 2020-02-20 16:16:36 --> Total execution time: 0.9529
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Hooks Class Initialized
INFO - 2020-02-20 16:16:37 --> Hooks Class Initialized
INFO - 2020-02-20 16:16:37 --> Hooks Class Initialized
INFO - 2020-02-20 16:16:37 --> Hooks Class Initialized
INFO - 2020-02-20 16:16:37 --> Hooks Class Initialized
INFO - 2020-02-20 16:16:37 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:16:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:16:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:16:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:16:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:16:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:16:37 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:16:37 --> Utf8 Class Initialized
INFO - 2020-02-20 16:16:37 --> Utf8 Class Initialized
INFO - 2020-02-20 16:16:37 --> Utf8 Class Initialized
INFO - 2020-02-20 16:16:37 --> Utf8 Class Initialized
INFO - 2020-02-20 16:16:37 --> Utf8 Class Initialized
INFO - 2020-02-20 16:16:37 --> Utf8 Class Initialized
INFO - 2020-02-20 16:16:37 --> URI Class Initialized
INFO - 2020-02-20 16:16:37 --> URI Class Initialized
INFO - 2020-02-20 16:16:37 --> URI Class Initialized
INFO - 2020-02-20 16:16:37 --> URI Class Initialized
INFO - 2020-02-20 16:16:37 --> URI Class Initialized
INFO - 2020-02-20 16:16:37 --> URI Class Initialized
INFO - 2020-02-20 16:16:37 --> Router Class Initialized
INFO - 2020-02-20 16:16:37 --> Router Class Initialized
INFO - 2020-02-20 16:16:37 --> Router Class Initialized
INFO - 2020-02-20 16:16:37 --> Router Class Initialized
INFO - 2020-02-20 16:16:37 --> Router Class Initialized
INFO - 2020-02-20 16:16:37 --> Router Class Initialized
INFO - 2020-02-20 16:16:37 --> Output Class Initialized
INFO - 2020-02-20 16:16:37 --> Output Class Initialized
INFO - 2020-02-20 16:16:37 --> Output Class Initialized
INFO - 2020-02-20 16:16:37 --> Output Class Initialized
INFO - 2020-02-20 16:16:37 --> Output Class Initialized
INFO - 2020-02-20 16:16:37 --> Output Class Initialized
INFO - 2020-02-20 16:16:37 --> Security Class Initialized
INFO - 2020-02-20 16:16:37 --> Security Class Initialized
INFO - 2020-02-20 16:16:37 --> Security Class Initialized
INFO - 2020-02-20 16:16:37 --> Security Class Initialized
INFO - 2020-02-20 16:16:37 --> Security Class Initialized
INFO - 2020-02-20 16:16:37 --> Security Class Initialized
DEBUG - 2020-02-20 16:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:16:37 --> CSRF cookie sent
INFO - 2020-02-20 16:16:37 --> CSRF cookie sent
INFO - 2020-02-20 16:16:37 --> CSRF cookie sent
INFO - 2020-02-20 16:16:37 --> CSRF cookie sent
INFO - 2020-02-20 16:16:37 --> CSRF cookie sent
INFO - 2020-02-20 16:16:37 --> CSRF cookie sent
INFO - 2020-02-20 16:16:37 --> CSRF token verified
INFO - 2020-02-20 16:16:37 --> CSRF token verified
INFO - 2020-02-20 16:16:37 --> CSRF token verified
INFO - 2020-02-20 16:16:37 --> CSRF token verified
INFO - 2020-02-20 16:16:37 --> CSRF token verified
INFO - 2020-02-20 16:16:37 --> CSRF token verified
INFO - 2020-02-20 16:16:37 --> Input Class Initialized
INFO - 2020-02-20 16:16:37 --> Input Class Initialized
INFO - 2020-02-20 16:16:37 --> Input Class Initialized
INFO - 2020-02-20 16:16:37 --> Input Class Initialized
INFO - 2020-02-20 16:16:37 --> Input Class Initialized
INFO - 2020-02-20 16:16:37 --> Input Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Language Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Config Class Initialized
INFO - 2020-02-20 16:16:37 --> Loader Class Initialized
INFO - 2020-02-20 16:16:37 --> Loader Class Initialized
INFO - 2020-02-20 16:16:37 --> Loader Class Initialized
INFO - 2020-02-20 16:16:37 --> Loader Class Initialized
INFO - 2020-02-20 16:16:37 --> Loader Class Initialized
INFO - 2020-02-20 16:16:37 --> Loader Class Initialized
INFO - 2020-02-20 16:16:37 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: language_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: language_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: language_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: language_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: language_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: language_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:16:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:16:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:16:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:16:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:16:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:16:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:16:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:16:37 --> Parser Class Initialized
INFO - 2020-02-20 16:16:37 --> Parser Class Initialized
INFO - 2020-02-20 16:16:37 --> Parser Class Initialized
INFO - 2020-02-20 16:16:37 --> Parser Class Initialized
INFO - 2020-02-20 16:16:37 --> Parser Class Initialized
INFO - 2020-02-20 16:16:37 --> Parser Class Initialized
INFO - 2020-02-20 16:16:37 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:37 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:37 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:37 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:37 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:37 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Database Driver Class Initialized
INFO - 2020-02-20 16:16:37 --> Database Driver Class Initialized
INFO - 2020-02-20 16:16:37 --> Database Driver Class Initialized
INFO - 2020-02-20 16:16:37 --> Database Driver Class Initialized
INFO - 2020-02-20 16:16:37 --> Database Driver Class Initialized
INFO - 2020-02-20 16:16:37 --> Database Driver Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
INFO - 2020-02-20 16:16:37 --> Model Class Initialized
DEBUG - 2020-02-20 16:16:37 --> Template Class Initialized
DEBUG - 2020-02-20 16:16:37 --> Template Class Initialized
DEBUG - 2020-02-20 16:16:37 --> Template Class Initialized
DEBUG - 2020-02-20 16:16:37 --> Template Class Initialized
DEBUG - 2020-02-20 16:16:37 --> Template Class Initialized
DEBUG - 2020-02-20 16:16:37 --> Template Class Initialized
INFO - 2020-02-20 16:16:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:16:37 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:16:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:16:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:16:37 --> Encryption Class Initialized
INFO - 2020-02-20 16:16:37 --> Controller Class Initialized
DEBUG - 2020-02-20 16:16:37 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:16:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:38 --> Model Class Initialized
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "View"
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "View"
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:16:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:16:38 --> Final output sent to browser
DEBUG - 2020-02-20 16:16:38 --> Total execution time: 0.8449
INFO - 2020-02-20 16:16:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:16:38 --> Config Class Initialized
INFO - 2020-02-20 16:16:38 --> Hooks Class Initialized
INFO - 2020-02-20 16:16:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:16:38 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:16:38 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:16:38 --> Utf8 Class Initialized
DEBUG - 2020-02-20 16:16:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:16:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:16:38 --> URI Class Initialized
INFO - 2020-02-20 16:16:38 --> Encryption Class Initialized
INFO - 2020-02-20 16:16:38 --> Router Class Initialized
INFO - 2020-02-20 16:16:38 --> Controller Class Initialized
INFO - 2020-02-20 16:16:38 --> Output Class Initialized
DEBUG - 2020-02-20 16:16:38 --> category MX_Controller Initialized
INFO - 2020-02-20 16:16:38 --> Security Class Initialized
DEBUG - 2020-02-20 16:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-20 16:16:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:38 --> CSRF cookie sent
INFO - 2020-02-20 16:16:38 --> Model Class Initialized
INFO - 2020-02-20 16:16:38 --> CSRF token verified
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:16:38 --> Input Class Initialized
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "View"
INFO - 2020-02-20 16:16:38 --> Language Class Initialized
DEBUG - 2020-02-20 16:16:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:16:38 --> Final output sent to browser
INFO - 2020-02-20 16:16:38 --> Language Class Initialized
DEBUG - 2020-02-20 16:16:38 --> Total execution time: 1.1132
INFO - 2020-02-20 16:16:38 --> Config Class Initialized
INFO - 2020-02-20 16:16:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:16:38 --> Loader Class Initialized
INFO - 2020-02-20 16:16:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:16:38 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:38 --> Pagination Class Initialized
INFO - 2020-02-20 16:16:38 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:38 --> Helper loaded: language_helper
DEBUG - 2020-02-20 16:16:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:16:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:16:38 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:38 --> Encryption Class Initialized
INFO - 2020-02-20 16:16:38 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:38 --> Controller Class Initialized
INFO - 2020-02-20 16:16:38 --> Helper loaded: file_manager_helper
DEBUG - 2020-02-20 16:16:38 --> category MX_Controller Initialized
INFO - 2020-02-20 16:16:38 --> Language file loaded: language/english/common_lang.php
DEBUG - 2020-02-20 16:16:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:38 --> Parser Class Initialized
INFO - 2020-02-20 16:16:38 --> Model Class Initialized
INFO - 2020-02-20 16:16:38 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:38 --> Model Class Initialized
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:16:38 --> Database Driver Class Initialized
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:16:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:16:38 --> Model Class Initialized
INFO - 2020-02-20 16:16:38 --> Final output sent to browser
DEBUG - 2020-02-20 16:16:38 --> Template Class Initialized
DEBUG - 2020-02-20 16:16:38 --> Total execution time: 1.4045
INFO - 2020-02-20 16:16:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:16:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:16:38 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:16:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:16:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:16:38 --> Encryption Class Initialized
INFO - 2020-02-20 16:16:38 --> Controller Class Initialized
DEBUG - 2020-02-20 16:16:38 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:16:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:38 --> Model Class Initialized
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "View"
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "View"
ERROR - 2020-02-20 16:16:38 --> Could not find the language line "View"
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "View"
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:16:39 --> Final output sent to browser
DEBUG - 2020-02-20 16:16:39 --> Total execution time: 1.7598
INFO - 2020-02-20 16:16:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:16:39 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:16:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:16:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:16:39 --> Encryption Class Initialized
INFO - 2020-02-20 16:16:39 --> Controller Class Initialized
DEBUG - 2020-02-20 16:16:39 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:39 --> Model Class Initialized
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:16:39 --> Final output sent to browser
DEBUG - 2020-02-20 16:16:39 --> Total execution time: 1.9841
INFO - 2020-02-20 16:16:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:16:39 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:16:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:16:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:16:39 --> Encryption Class Initialized
INFO - 2020-02-20 16:16:39 --> Controller Class Initialized
DEBUG - 2020-02-20 16:16:39 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:39 --> Model Class Initialized
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "View"
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "View"
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:16:39 --> Final output sent to browser
DEBUG - 2020-02-20 16:16:39 --> Total execution time: 2.2369
INFO - 2020-02-20 16:16:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:16:39 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:16:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:16:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:16:39 --> Encryption Class Initialized
INFO - 2020-02-20 16:16:39 --> Controller Class Initialized
DEBUG - 2020-02-20 16:16:39 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:39 --> Model Class Initialized
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:16:39 --> Could not find the language line "View"
DEBUG - 2020-02-20 16:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-20 16:16:39 --> Final output sent to browser
DEBUG - 2020-02-20 16:16:39 --> Total execution time: 1.6109
INFO - 2020-02-20 16:16:40 --> Config Class Initialized
INFO - 2020-02-20 16:16:40 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:16:40 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:16:40 --> Utf8 Class Initialized
INFO - 2020-02-20 16:16:40 --> URI Class Initialized
INFO - 2020-02-20 16:16:40 --> Router Class Initialized
INFO - 2020-02-20 16:16:40 --> Output Class Initialized
INFO - 2020-02-20 16:16:40 --> Security Class Initialized
DEBUG - 2020-02-20 16:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:16:40 --> CSRF cookie sent
INFO - 2020-02-20 16:16:40 --> Input Class Initialized
INFO - 2020-02-20 16:16:40 --> Language Class Initialized
INFO - 2020-02-20 16:16:40 --> Language Class Initialized
INFO - 2020-02-20 16:16:40 --> Config Class Initialized
INFO - 2020-02-20 16:16:40 --> Loader Class Initialized
INFO - 2020-02-20 16:16:40 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:40 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:40 --> Helper loaded: language_helper
INFO - 2020-02-20 16:16:40 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:40 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:16:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:16:40 --> Parser Class Initialized
INFO - 2020-02-20 16:16:40 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:40 --> Model Class Initialized
INFO - 2020-02-20 16:16:40 --> Database Driver Class Initialized
INFO - 2020-02-20 16:16:40 --> Model Class Initialized
DEBUG - 2020-02-20 16:16:40 --> Template Class Initialized
INFO - 2020-02-20 16:16:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:16:40 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:16:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:16:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:16:40 --> Encryption Class Initialized
INFO - 2020-02-20 16:16:40 --> Controller Class Initialized
DEBUG - 2020-02-20 16:16:40 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:16:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:16:40 --> Model Class Initialized
ERROR - 2020-02-20 16:16:40 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:16:40 --> Query error: Unknown column 'sort' in 'order clause' - Invalid query: SELECT `code`, `country_code`, `is_default`
FROM `general_lang_list`
WHERE `status` = 1
ORDER BY `sort` ASC
INFO - 2020-02-20 16:16:40 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-20 16:16:59 --> Config Class Initialized
INFO - 2020-02-20 16:16:59 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:16:59 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:16:59 --> Utf8 Class Initialized
INFO - 2020-02-20 16:16:59 --> URI Class Initialized
INFO - 2020-02-20 16:16:59 --> Router Class Initialized
INFO - 2020-02-20 16:16:59 --> Output Class Initialized
INFO - 2020-02-20 16:16:59 --> Security Class Initialized
DEBUG - 2020-02-20 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:16:59 --> CSRF cookie sent
INFO - 2020-02-20 16:16:59 --> Input Class Initialized
INFO - 2020-02-20 16:16:59 --> Language Class Initialized
INFO - 2020-02-20 16:16:59 --> Language Class Initialized
INFO - 2020-02-20 16:16:59 --> Config Class Initialized
INFO - 2020-02-20 16:16:59 --> Loader Class Initialized
INFO - 2020-02-20 16:16:59 --> Helper loaded: url_helper
INFO - 2020-02-20 16:16:59 --> Helper loaded: common_helper
INFO - 2020-02-20 16:16:59 --> Helper loaded: language_helper
INFO - 2020-02-20 16:16:59 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:16:59 --> Helper loaded: email_helper
INFO - 2020-02-20 16:16:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:16:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:16:59 --> Parser Class Initialized
INFO - 2020-02-20 16:16:59 --> User Agent Class Initialized
INFO - 2020-02-20 16:16:59 --> Model Class Initialized
INFO - 2020-02-20 16:17:00 --> Database Driver Class Initialized
INFO - 2020-02-20 16:17:00 --> Model Class Initialized
DEBUG - 2020-02-20 16:17:00 --> Template Class Initialized
INFO - 2020-02-20 16:17:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:17:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:17:00 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:17:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:17:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:17:00 --> Encryption Class Initialized
INFO - 2020-02-20 16:17:00 --> Controller Class Initialized
DEBUG - 2020-02-20 16:17:00 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:17:00 --> Model Class Initialized
ERROR - 2020-02-20 16:17:00 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:17:00 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:17:00 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:17:00 --> Model Class Initialized
DEBUG - 2020-02-20 16:17:00 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:17:00 --> Model Class Initialized
DEBUG - 2020-02-20 16:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:17:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:17:00 --> Final output sent to browser
DEBUG - 2020-02-20 16:17:00 --> Total execution time: 0.9616
INFO - 2020-02-20 16:18:20 --> Config Class Initialized
INFO - 2020-02-20 16:18:20 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:18:20 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:18:20 --> Utf8 Class Initialized
INFO - 2020-02-20 16:18:20 --> URI Class Initialized
INFO - 2020-02-20 16:18:20 --> Router Class Initialized
INFO - 2020-02-20 16:18:20 --> Output Class Initialized
INFO - 2020-02-20 16:18:20 --> Security Class Initialized
DEBUG - 2020-02-20 16:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:18:20 --> CSRF cookie sent
INFO - 2020-02-20 16:18:20 --> Input Class Initialized
INFO - 2020-02-20 16:18:20 --> Language Class Initialized
INFO - 2020-02-20 16:18:20 --> Language Class Initialized
INFO - 2020-02-20 16:18:20 --> Config Class Initialized
INFO - 2020-02-20 16:18:20 --> Loader Class Initialized
INFO - 2020-02-20 16:18:20 --> Helper loaded: url_helper
INFO - 2020-02-20 16:18:20 --> Helper loaded: common_helper
INFO - 2020-02-20 16:18:20 --> Helper loaded: language_helper
INFO - 2020-02-20 16:18:20 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:18:20 --> Helper loaded: email_helper
INFO - 2020-02-20 16:18:20 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:18:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:18:20 --> Parser Class Initialized
INFO - 2020-02-20 16:18:20 --> User Agent Class Initialized
INFO - 2020-02-20 16:18:20 --> Model Class Initialized
INFO - 2020-02-20 16:18:20 --> Database Driver Class Initialized
INFO - 2020-02-20 16:18:20 --> Model Class Initialized
DEBUG - 2020-02-20 16:18:20 --> Template Class Initialized
INFO - 2020-02-20 16:18:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:18:20 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:18:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:18:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:18:21 --> Encryption Class Initialized
INFO - 2020-02-20 16:18:21 --> Controller Class Initialized
DEBUG - 2020-02-20 16:18:21 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:18:21 --> Model Class Initialized
ERROR - 2020-02-20 16:18:21 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:18:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:18:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:18:21 --> Model Class Initialized
DEBUG - 2020-02-20 16:18:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:18:21 --> Model Class Initialized
DEBUG - 2020-02-20 16:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:18:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:18:21 --> Final output sent to browser
DEBUG - 2020-02-20 16:18:21 --> Total execution time: 0.9727
INFO - 2020-02-20 16:22:37 --> Config Class Initialized
INFO - 2020-02-20 16:22:37 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:22:37 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:22:37 --> Utf8 Class Initialized
INFO - 2020-02-20 16:22:37 --> URI Class Initialized
INFO - 2020-02-20 16:22:37 --> Router Class Initialized
INFO - 2020-02-20 16:22:37 --> Output Class Initialized
INFO - 2020-02-20 16:22:37 --> Security Class Initialized
DEBUG - 2020-02-20 16:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:22:37 --> CSRF cookie sent
INFO - 2020-02-20 16:22:37 --> Input Class Initialized
INFO - 2020-02-20 16:22:37 --> Language Class Initialized
INFO - 2020-02-20 16:22:38 --> Language Class Initialized
INFO - 2020-02-20 16:22:38 --> Config Class Initialized
INFO - 2020-02-20 16:22:38 --> Loader Class Initialized
INFO - 2020-02-20 16:22:38 --> Helper loaded: url_helper
INFO - 2020-02-20 16:22:38 --> Helper loaded: common_helper
INFO - 2020-02-20 16:22:38 --> Helper loaded: language_helper
INFO - 2020-02-20 16:22:38 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:22:38 --> Helper loaded: email_helper
INFO - 2020-02-20 16:22:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:22:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:22:38 --> Parser Class Initialized
INFO - 2020-02-20 16:22:38 --> User Agent Class Initialized
INFO - 2020-02-20 16:22:38 --> Model Class Initialized
INFO - 2020-02-20 16:22:38 --> Database Driver Class Initialized
INFO - 2020-02-20 16:22:38 --> Model Class Initialized
DEBUG - 2020-02-20 16:22:38 --> Template Class Initialized
INFO - 2020-02-20 16:22:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:22:38 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:22:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:22:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:22:38 --> Encryption Class Initialized
INFO - 2020-02-20 16:22:38 --> Controller Class Initialized
DEBUG - 2020-02-20 16:22:38 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:22:38 --> Model Class Initialized
ERROR - 2020-02-20 16:22:38 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:26:26 --> Config Class Initialized
INFO - 2020-02-20 16:26:26 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:26:26 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:26:26 --> Utf8 Class Initialized
INFO - 2020-02-20 16:26:26 --> URI Class Initialized
INFO - 2020-02-20 16:26:26 --> Router Class Initialized
INFO - 2020-02-20 16:26:26 --> Output Class Initialized
INFO - 2020-02-20 16:26:26 --> Security Class Initialized
DEBUG - 2020-02-20 16:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:26:26 --> CSRF cookie sent
INFO - 2020-02-20 16:26:26 --> Input Class Initialized
INFO - 2020-02-20 16:26:26 --> Language Class Initialized
INFO - 2020-02-20 16:26:26 --> Language Class Initialized
INFO - 2020-02-20 16:26:26 --> Config Class Initialized
INFO - 2020-02-20 16:26:26 --> Loader Class Initialized
INFO - 2020-02-20 16:26:26 --> Helper loaded: url_helper
INFO - 2020-02-20 16:26:26 --> Helper loaded: common_helper
INFO - 2020-02-20 16:26:26 --> Helper loaded: language_helper
INFO - 2020-02-20 16:26:26 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:26:26 --> Helper loaded: email_helper
INFO - 2020-02-20 16:26:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:26:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:26:26 --> Parser Class Initialized
INFO - 2020-02-20 16:26:26 --> User Agent Class Initialized
INFO - 2020-02-20 16:26:26 --> Model Class Initialized
INFO - 2020-02-20 16:26:26 --> Database Driver Class Initialized
INFO - 2020-02-20 16:26:26 --> Model Class Initialized
DEBUG - 2020-02-20 16:26:26 --> Template Class Initialized
INFO - 2020-02-20 16:26:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:26:26 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:26:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:26:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:26:26 --> Encryption Class Initialized
INFO - 2020-02-20 16:26:26 --> Controller Class Initialized
DEBUG - 2020-02-20 16:26:26 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:26:26 --> Model Class Initialized
ERROR - 2020-02-20 16:26:26 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:26:26 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:26:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:26:26 --> Model Class Initialized
DEBUG - 2020-02-20 16:26:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:26:26 --> Model Class Initialized
DEBUG - 2020-02-20 16:26:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:26:27 --> Final output sent to browser
DEBUG - 2020-02-20 16:26:27 --> Total execution time: 1.0364
INFO - 2020-02-20 16:26:39 --> Config Class Initialized
INFO - 2020-02-20 16:26:39 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:26:39 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:26:39 --> Utf8 Class Initialized
INFO - 2020-02-20 16:26:39 --> URI Class Initialized
INFO - 2020-02-20 16:26:39 --> Router Class Initialized
INFO - 2020-02-20 16:26:39 --> Output Class Initialized
INFO - 2020-02-20 16:26:39 --> Security Class Initialized
DEBUG - 2020-02-20 16:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:26:39 --> CSRF cookie sent
INFO - 2020-02-20 16:26:39 --> Input Class Initialized
INFO - 2020-02-20 16:26:39 --> Language Class Initialized
INFO - 2020-02-20 16:26:39 --> Language Class Initialized
INFO - 2020-02-20 16:26:39 --> Config Class Initialized
INFO - 2020-02-20 16:26:39 --> Loader Class Initialized
INFO - 2020-02-20 16:26:39 --> Helper loaded: url_helper
INFO - 2020-02-20 16:26:39 --> Helper loaded: common_helper
INFO - 2020-02-20 16:26:39 --> Helper loaded: language_helper
INFO - 2020-02-20 16:26:39 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:26:39 --> Helper loaded: email_helper
INFO - 2020-02-20 16:26:39 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:26:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:26:39 --> Parser Class Initialized
INFO - 2020-02-20 16:26:39 --> User Agent Class Initialized
INFO - 2020-02-20 16:26:39 --> Model Class Initialized
INFO - 2020-02-20 16:26:39 --> Database Driver Class Initialized
INFO - 2020-02-20 16:26:39 --> Model Class Initialized
DEBUG - 2020-02-20 16:26:39 --> Template Class Initialized
INFO - 2020-02-20 16:26:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:26:39 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:26:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:26:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:26:39 --> Encryption Class Initialized
INFO - 2020-02-20 16:26:39 --> Controller Class Initialized
DEBUG - 2020-02-20 16:26:40 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:26:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:26:40 --> Model Class Initialized
ERROR - 2020-02-20 16:26:40 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:26:40 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:26:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:26:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:26:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:26:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:26:40 --> Model Class Initialized
DEBUG - 2020-02-20 16:26:40 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:26:40 --> Model Class Initialized
DEBUG - 2020-02-20 16:26:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:26:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:26:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:26:40 --> Final output sent to browser
DEBUG - 2020-02-20 16:26:40 --> Total execution time: 0.9492
INFO - 2020-02-20 16:26:43 --> Config Class Initialized
INFO - 2020-02-20 16:26:43 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:26:43 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:26:43 --> Utf8 Class Initialized
INFO - 2020-02-20 16:26:43 --> URI Class Initialized
INFO - 2020-02-20 16:26:43 --> Router Class Initialized
INFO - 2020-02-20 16:26:43 --> Output Class Initialized
INFO - 2020-02-20 16:26:43 --> Security Class Initialized
DEBUG - 2020-02-20 16:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:26:43 --> CSRF cookie sent
INFO - 2020-02-20 16:26:43 --> Input Class Initialized
INFO - 2020-02-20 16:26:43 --> Language Class Initialized
INFO - 2020-02-20 16:26:43 --> Language Class Initialized
INFO - 2020-02-20 16:26:43 --> Config Class Initialized
INFO - 2020-02-20 16:26:43 --> Loader Class Initialized
INFO - 2020-02-20 16:26:43 --> Helper loaded: url_helper
INFO - 2020-02-20 16:26:43 --> Helper loaded: common_helper
INFO - 2020-02-20 16:26:43 --> Helper loaded: language_helper
INFO - 2020-02-20 16:26:43 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:26:43 --> Helper loaded: email_helper
INFO - 2020-02-20 16:26:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:26:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:26:43 --> Parser Class Initialized
INFO - 2020-02-20 16:26:43 --> User Agent Class Initialized
INFO - 2020-02-20 16:26:43 --> Model Class Initialized
INFO - 2020-02-20 16:26:43 --> Database Driver Class Initialized
INFO - 2020-02-20 16:26:43 --> Model Class Initialized
DEBUG - 2020-02-20 16:26:43 --> Template Class Initialized
INFO - 2020-02-20 16:26:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:26:43 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:26:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:26:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:26:43 --> Encryption Class Initialized
INFO - 2020-02-20 16:26:43 --> Controller Class Initialized
DEBUG - 2020-02-20 16:26:43 --> language MX_Controller Initialized
DEBUG - 2020-02-20 16:26:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2020-02-20 16:26:43 --> Model Class Initialized
INFO - 2020-02-20 16:26:43 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:26:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2020-02-20 16:26:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:26:43 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:26:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:26:44 --> Model Class Initialized
DEBUG - 2020-02-20 16:26:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:26:44 --> Model Class Initialized
DEBUG - 2020-02-20 16:26:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:26:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:26:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:26:44 --> Final output sent to browser
DEBUG - 2020-02-20 16:26:44 --> Total execution time: 1.0154
INFO - 2020-02-20 16:28:04 --> Config Class Initialized
INFO - 2020-02-20 16:28:04 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:28:04 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:28:04 --> Utf8 Class Initialized
INFO - 2020-02-20 16:28:04 --> URI Class Initialized
INFO - 2020-02-20 16:28:04 --> Router Class Initialized
INFO - 2020-02-20 16:28:04 --> Output Class Initialized
INFO - 2020-02-20 16:28:04 --> Security Class Initialized
DEBUG - 2020-02-20 16:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:28:04 --> CSRF cookie sent
INFO - 2020-02-20 16:28:04 --> Input Class Initialized
INFO - 2020-02-20 16:28:04 --> Language Class Initialized
INFO - 2020-02-20 16:28:04 --> Language Class Initialized
INFO - 2020-02-20 16:28:04 --> Config Class Initialized
INFO - 2020-02-20 16:28:04 --> Loader Class Initialized
INFO - 2020-02-20 16:28:04 --> Helper loaded: url_helper
INFO - 2020-02-20 16:28:04 --> Helper loaded: common_helper
INFO - 2020-02-20 16:28:04 --> Helper loaded: language_helper
INFO - 2020-02-20 16:28:04 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:28:04 --> Helper loaded: email_helper
INFO - 2020-02-20 16:28:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:28:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:28:04 --> Parser Class Initialized
INFO - 2020-02-20 16:28:04 --> User Agent Class Initialized
INFO - 2020-02-20 16:28:04 --> Model Class Initialized
INFO - 2020-02-20 16:28:04 --> Database Driver Class Initialized
INFO - 2020-02-20 16:28:04 --> Model Class Initialized
DEBUG - 2020-02-20 16:28:04 --> Template Class Initialized
INFO - 2020-02-20 16:28:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:28:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:28:04 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:28:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:28:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:28:04 --> Encryption Class Initialized
INFO - 2020-02-20 16:28:04 --> Controller Class Initialized
DEBUG - 2020-02-20 16:28:05 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:28:05 --> Model Class Initialized
ERROR - 2020-02-20 16:28:05 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:28:05 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:28:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:28:05 --> Model Class Initialized
DEBUG - 2020-02-20 16:28:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:28:05 --> Model Class Initialized
DEBUG - 2020-02-20 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:28:05 --> Final output sent to browser
DEBUG - 2020-02-20 16:28:05 --> Total execution time: 0.9830
INFO - 2020-02-20 16:28:29 --> Config Class Initialized
INFO - 2020-02-20 16:28:29 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:28:29 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:28:29 --> Utf8 Class Initialized
INFO - 2020-02-20 16:28:29 --> URI Class Initialized
INFO - 2020-02-20 16:28:29 --> Router Class Initialized
INFO - 2020-02-20 16:28:29 --> Output Class Initialized
INFO - 2020-02-20 16:28:29 --> Security Class Initialized
DEBUG - 2020-02-20 16:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:28:29 --> CSRF cookie sent
INFO - 2020-02-20 16:28:29 --> Input Class Initialized
INFO - 2020-02-20 16:28:29 --> Language Class Initialized
INFO - 2020-02-20 16:28:29 --> Language Class Initialized
INFO - 2020-02-20 16:28:29 --> Config Class Initialized
INFO - 2020-02-20 16:28:29 --> Loader Class Initialized
INFO - 2020-02-20 16:28:29 --> Helper loaded: url_helper
INFO - 2020-02-20 16:28:29 --> Helper loaded: common_helper
INFO - 2020-02-20 16:28:29 --> Helper loaded: language_helper
INFO - 2020-02-20 16:28:29 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:28:29 --> Helper loaded: email_helper
INFO - 2020-02-20 16:28:29 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:28:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:28:29 --> Parser Class Initialized
INFO - 2020-02-20 16:28:29 --> User Agent Class Initialized
INFO - 2020-02-20 16:28:29 --> Model Class Initialized
INFO - 2020-02-20 16:28:29 --> Database Driver Class Initialized
INFO - 2020-02-20 16:28:29 --> Model Class Initialized
DEBUG - 2020-02-20 16:28:29 --> Template Class Initialized
INFO - 2020-02-20 16:28:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:28:29 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:28:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:28:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:28:29 --> Encryption Class Initialized
INFO - 2020-02-20 16:28:29 --> Controller Class Initialized
DEBUG - 2020-02-20 16:28:29 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:28:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:28:29 --> Model Class Initialized
ERROR - 2020-02-20 16:28:29 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:28:29 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:28:29 --> Severity: Notice --> Undefined variable: lang_current D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
ERROR - 2020-02-20 16:28:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
ERROR - 2020-02-20 16:28:29 --> Severity: Notice --> Undefined variable: lang_current D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
ERROR - 2020-02-20 16:28:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
DEBUG - 2020-02-20 16:28:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:28:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:28:30 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:28:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:28:30 --> Model Class Initialized
DEBUG - 2020-02-20 16:28:30 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:28:30 --> Model Class Initialized
DEBUG - 2020-02-20 16:28:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:28:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:28:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:28:30 --> Final output sent to browser
DEBUG - 2020-02-20 16:28:30 --> Total execution time: 1.0346
INFO - 2020-02-20 16:28:44 --> Config Class Initialized
INFO - 2020-02-20 16:28:44 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:28:44 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:28:44 --> Utf8 Class Initialized
INFO - 2020-02-20 16:28:44 --> URI Class Initialized
INFO - 2020-02-20 16:28:44 --> Router Class Initialized
INFO - 2020-02-20 16:28:44 --> Output Class Initialized
INFO - 2020-02-20 16:28:44 --> Security Class Initialized
DEBUG - 2020-02-20 16:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:28:44 --> CSRF cookie sent
INFO - 2020-02-20 16:28:44 --> Input Class Initialized
INFO - 2020-02-20 16:28:44 --> Language Class Initialized
INFO - 2020-02-20 16:28:44 --> Language Class Initialized
INFO - 2020-02-20 16:28:44 --> Config Class Initialized
INFO - 2020-02-20 16:28:44 --> Loader Class Initialized
INFO - 2020-02-20 16:28:45 --> Helper loaded: url_helper
INFO - 2020-02-20 16:28:45 --> Helper loaded: common_helper
INFO - 2020-02-20 16:28:45 --> Helper loaded: language_helper
INFO - 2020-02-20 16:28:45 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:28:45 --> Helper loaded: email_helper
INFO - 2020-02-20 16:28:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:28:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:28:45 --> Parser Class Initialized
INFO - 2020-02-20 16:28:45 --> User Agent Class Initialized
INFO - 2020-02-20 16:28:45 --> Model Class Initialized
INFO - 2020-02-20 16:28:45 --> Database Driver Class Initialized
INFO - 2020-02-20 16:28:45 --> Model Class Initialized
DEBUG - 2020-02-20 16:28:45 --> Template Class Initialized
INFO - 2020-02-20 16:28:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:28:45 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:28:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:28:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:28:45 --> Encryption Class Initialized
INFO - 2020-02-20 16:28:45 --> Controller Class Initialized
DEBUG - 2020-02-20 16:28:45 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:28:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:28:45 --> Model Class Initialized
ERROR - 2020-02-20 16:28:45 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:28:45 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:28:45 --> Severity: Notice --> Undefined variable: lang_current D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
ERROR - 2020-02-20 16:28:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
ERROR - 2020-02-20 16:28:45 --> Severity: Notice --> Undefined variable: lang_current D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
ERROR - 2020-02-20 16:28:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
DEBUG - 2020-02-20 16:28:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:28:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:28:45 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:28:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:28:45 --> Model Class Initialized
DEBUG - 2020-02-20 16:28:45 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:28:45 --> Model Class Initialized
DEBUG - 2020-02-20 16:28:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:28:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:28:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:28:45 --> Final output sent to browser
DEBUG - 2020-02-20 16:28:45 --> Total execution time: 0.9792
INFO - 2020-02-20 16:29:10 --> Config Class Initialized
INFO - 2020-02-20 16:29:10 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:29:10 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:29:10 --> Utf8 Class Initialized
INFO - 2020-02-20 16:29:10 --> URI Class Initialized
INFO - 2020-02-20 16:29:10 --> Router Class Initialized
INFO - 2020-02-20 16:29:10 --> Output Class Initialized
INFO - 2020-02-20 16:29:10 --> Security Class Initialized
DEBUG - 2020-02-20 16:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:29:10 --> CSRF cookie sent
INFO - 2020-02-20 16:29:10 --> Input Class Initialized
INFO - 2020-02-20 16:29:10 --> Language Class Initialized
INFO - 2020-02-20 16:29:10 --> Language Class Initialized
INFO - 2020-02-20 16:29:10 --> Config Class Initialized
INFO - 2020-02-20 16:29:10 --> Loader Class Initialized
INFO - 2020-02-20 16:29:10 --> Helper loaded: url_helper
INFO - 2020-02-20 16:29:10 --> Helper loaded: common_helper
INFO - 2020-02-20 16:29:10 --> Helper loaded: language_helper
INFO - 2020-02-20 16:29:10 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:29:10 --> Helper loaded: email_helper
INFO - 2020-02-20 16:29:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:29:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:29:10 --> Parser Class Initialized
INFO - 2020-02-20 16:29:10 --> User Agent Class Initialized
INFO - 2020-02-20 16:29:10 --> Model Class Initialized
INFO - 2020-02-20 16:29:10 --> Database Driver Class Initialized
INFO - 2020-02-20 16:29:10 --> Model Class Initialized
DEBUG - 2020-02-20 16:29:10 --> Template Class Initialized
INFO - 2020-02-20 16:29:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:29:10 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:29:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:29:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:29:10 --> Encryption Class Initialized
INFO - 2020-02-20 16:29:10 --> Controller Class Initialized
DEBUG - 2020-02-20 16:29:10 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:29:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:29:10 --> Model Class Initialized
ERROR - 2020-02-20 16:29:10 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:29:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:29:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:29:11 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:29:11 --> Model Class Initialized
DEBUG - 2020-02-20 16:29:11 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:29:11 --> Model Class Initialized
DEBUG - 2020-02-20 16:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:29:11 --> Final output sent to browser
DEBUG - 2020-02-20 16:29:11 --> Total execution time: 0.9174
INFO - 2020-02-20 16:30:53 --> Config Class Initialized
INFO - 2020-02-20 16:30:53 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:30:53 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:30:53 --> Utf8 Class Initialized
INFO - 2020-02-20 16:30:53 --> URI Class Initialized
INFO - 2020-02-20 16:30:53 --> Router Class Initialized
INFO - 2020-02-20 16:30:53 --> Output Class Initialized
INFO - 2020-02-20 16:30:53 --> Security Class Initialized
DEBUG - 2020-02-20 16:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:30:53 --> CSRF cookie sent
INFO - 2020-02-20 16:30:53 --> Input Class Initialized
INFO - 2020-02-20 16:30:53 --> Language Class Initialized
INFO - 2020-02-20 16:30:53 --> Language Class Initialized
INFO - 2020-02-20 16:30:54 --> Config Class Initialized
INFO - 2020-02-20 16:30:54 --> Loader Class Initialized
INFO - 2020-02-20 16:30:54 --> Helper loaded: url_helper
INFO - 2020-02-20 16:30:54 --> Helper loaded: common_helper
INFO - 2020-02-20 16:30:54 --> Helper loaded: language_helper
INFO - 2020-02-20 16:30:54 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:30:54 --> Helper loaded: email_helper
INFO - 2020-02-20 16:30:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:30:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:30:54 --> Parser Class Initialized
INFO - 2020-02-20 16:30:54 --> User Agent Class Initialized
INFO - 2020-02-20 16:30:54 --> Model Class Initialized
INFO - 2020-02-20 16:30:54 --> Database Driver Class Initialized
INFO - 2020-02-20 16:30:54 --> Model Class Initialized
DEBUG - 2020-02-20 16:30:54 --> Template Class Initialized
INFO - 2020-02-20 16:30:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:30:54 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:30:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:30:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:30:54 --> Encryption Class Initialized
INFO - 2020-02-20 16:30:54 --> Controller Class Initialized
DEBUG - 2020-02-20 16:30:54 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:30:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:30:54 --> Model Class Initialized
ERROR - 2020-02-20 16:30:54 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:30:54 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:30:54 --> Severity: error --> Exception: syntax error, unexpected '$language' (T_VARIABLE), expecting ',' or ')' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
INFO - 2020-02-20 16:31:16 --> Config Class Initialized
INFO - 2020-02-20 16:31:16 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:31:16 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:31:16 --> Utf8 Class Initialized
INFO - 2020-02-20 16:31:16 --> URI Class Initialized
INFO - 2020-02-20 16:31:16 --> Router Class Initialized
INFO - 2020-02-20 16:31:16 --> Output Class Initialized
INFO - 2020-02-20 16:31:16 --> Security Class Initialized
DEBUG - 2020-02-20 16:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:31:16 --> CSRF cookie sent
INFO - 2020-02-20 16:31:16 --> Input Class Initialized
INFO - 2020-02-20 16:31:16 --> Language Class Initialized
INFO - 2020-02-20 16:31:16 --> Language Class Initialized
INFO - 2020-02-20 16:31:16 --> Config Class Initialized
INFO - 2020-02-20 16:31:17 --> Loader Class Initialized
INFO - 2020-02-20 16:31:17 --> Helper loaded: url_helper
INFO - 2020-02-20 16:31:17 --> Helper loaded: common_helper
INFO - 2020-02-20 16:31:17 --> Helper loaded: language_helper
INFO - 2020-02-20 16:31:17 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:31:17 --> Helper loaded: email_helper
INFO - 2020-02-20 16:31:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:31:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:31:17 --> Parser Class Initialized
INFO - 2020-02-20 16:31:17 --> User Agent Class Initialized
INFO - 2020-02-20 16:31:17 --> Model Class Initialized
INFO - 2020-02-20 16:31:17 --> Database Driver Class Initialized
INFO - 2020-02-20 16:31:17 --> Model Class Initialized
DEBUG - 2020-02-20 16:31:17 --> Template Class Initialized
INFO - 2020-02-20 16:31:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:31:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:31:17 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:31:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:31:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:31:17 --> Encryption Class Initialized
INFO - 2020-02-20 16:31:17 --> Controller Class Initialized
DEBUG - 2020-02-20 16:31:17 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:31:17 --> Model Class Initialized
ERROR - 2020-02-20 16:31:17 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:31:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:31:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:31:17 --> Model Class Initialized
DEBUG - 2020-02-20 16:31:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:31:17 --> Model Class Initialized
DEBUG - 2020-02-20 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:31:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:31:17 --> Final output sent to browser
DEBUG - 2020-02-20 16:31:17 --> Total execution time: 0.9165
INFO - 2020-02-20 16:32:04 --> Config Class Initialized
INFO - 2020-02-20 16:32:04 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:32:04 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:32:04 --> Utf8 Class Initialized
INFO - 2020-02-20 16:32:04 --> URI Class Initialized
INFO - 2020-02-20 16:32:04 --> Router Class Initialized
INFO - 2020-02-20 16:32:04 --> Output Class Initialized
INFO - 2020-02-20 16:32:04 --> Security Class Initialized
DEBUG - 2020-02-20 16:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:32:04 --> CSRF cookie sent
INFO - 2020-02-20 16:32:04 --> Input Class Initialized
INFO - 2020-02-20 16:32:04 --> Language Class Initialized
INFO - 2020-02-20 16:32:04 --> Language Class Initialized
INFO - 2020-02-20 16:32:04 --> Config Class Initialized
INFO - 2020-02-20 16:32:04 --> Loader Class Initialized
INFO - 2020-02-20 16:32:04 --> Helper loaded: url_helper
INFO - 2020-02-20 16:32:04 --> Helper loaded: common_helper
INFO - 2020-02-20 16:32:04 --> Helper loaded: language_helper
INFO - 2020-02-20 16:32:04 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:32:04 --> Helper loaded: email_helper
INFO - 2020-02-20 16:32:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:32:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:32:04 --> Parser Class Initialized
INFO - 2020-02-20 16:32:04 --> User Agent Class Initialized
INFO - 2020-02-20 16:32:04 --> Model Class Initialized
INFO - 2020-02-20 16:32:04 --> Database Driver Class Initialized
INFO - 2020-02-20 16:32:04 --> Model Class Initialized
DEBUG - 2020-02-20 16:32:04 --> Template Class Initialized
INFO - 2020-02-20 16:32:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:32:04 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:32:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:32:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:32:04 --> Encryption Class Initialized
INFO - 2020-02-20 16:32:04 --> Controller Class Initialized
DEBUG - 2020-02-20 16:32:04 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:32:04 --> Model Class Initialized
ERROR - 2020-02-20 16:32:04 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:32:04 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:32:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:32:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:32:05 --> Model Class Initialized
DEBUG - 2020-02-20 16:32:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:32:05 --> Model Class Initialized
DEBUG - 2020-02-20 16:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:32:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:32:05 --> Final output sent to browser
DEBUG - 2020-02-20 16:32:05 --> Total execution time: 0.9593
INFO - 2020-02-20 16:34:01 --> Config Class Initialized
INFO - 2020-02-20 16:34:01 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:34:01 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:34:01 --> Utf8 Class Initialized
INFO - 2020-02-20 16:34:01 --> URI Class Initialized
INFO - 2020-02-20 16:34:01 --> Router Class Initialized
INFO - 2020-02-20 16:34:01 --> Output Class Initialized
INFO - 2020-02-20 16:34:01 --> Security Class Initialized
DEBUG - 2020-02-20 16:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:34:01 --> CSRF cookie sent
INFO - 2020-02-20 16:34:01 --> Input Class Initialized
INFO - 2020-02-20 16:34:01 --> Language Class Initialized
INFO - 2020-02-20 16:34:01 --> Language Class Initialized
INFO - 2020-02-20 16:34:01 --> Config Class Initialized
INFO - 2020-02-20 16:34:01 --> Loader Class Initialized
INFO - 2020-02-20 16:34:01 --> Helper loaded: url_helper
INFO - 2020-02-20 16:34:01 --> Helper loaded: common_helper
INFO - 2020-02-20 16:34:01 --> Helper loaded: language_helper
INFO - 2020-02-20 16:34:01 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:34:01 --> Helper loaded: email_helper
INFO - 2020-02-20 16:34:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:34:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:34:01 --> Parser Class Initialized
INFO - 2020-02-20 16:34:01 --> User Agent Class Initialized
INFO - 2020-02-20 16:34:01 --> Model Class Initialized
INFO - 2020-02-20 16:34:01 --> Database Driver Class Initialized
INFO - 2020-02-20 16:34:01 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:01 --> Template Class Initialized
INFO - 2020-02-20 16:34:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:34:02 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:34:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:34:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:34:02 --> Encryption Class Initialized
INFO - 2020-02-20 16:34:02 --> Controller Class Initialized
DEBUG - 2020-02-20 16:34:02 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:34:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:02 --> Model Class Initialized
ERROR - 2020-02-20 16:34:02 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:34:02 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:34:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:34:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:34:02 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:34:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:34:02 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:02 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:02 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:34:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:34:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:34:02 --> Final output sent to browser
DEBUG - 2020-02-20 16:34:02 --> Total execution time: 0.9885
INFO - 2020-02-20 16:34:08 --> Config Class Initialized
INFO - 2020-02-20 16:34:08 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:34:09 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:34:09 --> Utf8 Class Initialized
INFO - 2020-02-20 16:34:09 --> URI Class Initialized
INFO - 2020-02-20 16:34:09 --> Router Class Initialized
INFO - 2020-02-20 16:34:09 --> Output Class Initialized
INFO - 2020-02-20 16:34:09 --> Security Class Initialized
DEBUG - 2020-02-20 16:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:34:09 --> CSRF cookie sent
INFO - 2020-02-20 16:34:09 --> Input Class Initialized
INFO - 2020-02-20 16:34:09 --> Language Class Initialized
INFO - 2020-02-20 16:34:09 --> Language Class Initialized
INFO - 2020-02-20 16:34:09 --> Config Class Initialized
INFO - 2020-02-20 16:34:09 --> Loader Class Initialized
INFO - 2020-02-20 16:34:09 --> Helper loaded: url_helper
INFO - 2020-02-20 16:34:09 --> Helper loaded: common_helper
INFO - 2020-02-20 16:34:09 --> Helper loaded: language_helper
INFO - 2020-02-20 16:34:09 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:34:09 --> Helper loaded: email_helper
INFO - 2020-02-20 16:34:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:34:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:34:09 --> Parser Class Initialized
INFO - 2020-02-20 16:34:09 --> User Agent Class Initialized
INFO - 2020-02-20 16:34:09 --> Model Class Initialized
INFO - 2020-02-20 16:34:09 --> Database Driver Class Initialized
INFO - 2020-02-20 16:34:09 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:09 --> Template Class Initialized
INFO - 2020-02-20 16:34:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:34:09 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:34:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:34:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:34:09 --> Encryption Class Initialized
INFO - 2020-02-20 16:34:09 --> Controller Class Initialized
DEBUG - 2020-02-20 16:34:09 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:09 --> Model Class Initialized
ERROR - 2020-02-20 16:34:09 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:34:09 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:34:09 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:34:09 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:09 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:09 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:34:09 --> Final output sent to browser
DEBUG - 2020-02-20 16:34:09 --> Total execution time: 0.8660
INFO - 2020-02-20 16:34:11 --> Config Class Initialized
INFO - 2020-02-20 16:34:11 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:34:11 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:34:11 --> Utf8 Class Initialized
INFO - 2020-02-20 16:34:11 --> URI Class Initialized
INFO - 2020-02-20 16:34:11 --> Router Class Initialized
INFO - 2020-02-20 16:34:11 --> Output Class Initialized
INFO - 2020-02-20 16:34:11 --> Security Class Initialized
DEBUG - 2020-02-20 16:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:34:11 --> CSRF cookie sent
INFO - 2020-02-20 16:34:11 --> Input Class Initialized
INFO - 2020-02-20 16:34:11 --> Language Class Initialized
INFO - 2020-02-20 16:34:11 --> Language Class Initialized
INFO - 2020-02-20 16:34:11 --> Config Class Initialized
INFO - 2020-02-20 16:34:11 --> Loader Class Initialized
INFO - 2020-02-20 16:34:11 --> Helper loaded: url_helper
INFO - 2020-02-20 16:34:11 --> Helper loaded: common_helper
INFO - 2020-02-20 16:34:11 --> Helper loaded: language_helper
INFO - 2020-02-20 16:34:11 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:34:11 --> Helper loaded: email_helper
INFO - 2020-02-20 16:34:11 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:34:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:34:11 --> Parser Class Initialized
INFO - 2020-02-20 16:34:11 --> User Agent Class Initialized
INFO - 2020-02-20 16:34:11 --> Model Class Initialized
INFO - 2020-02-20 16:34:11 --> Database Driver Class Initialized
INFO - 2020-02-20 16:34:11 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:11 --> Template Class Initialized
INFO - 2020-02-20 16:34:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:34:11 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:34:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:34:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:34:12 --> Encryption Class Initialized
INFO - 2020-02-20 16:34:12 --> Controller Class Initialized
DEBUG - 2020-02-20 16:34:12 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:12 --> Model Class Initialized
ERROR - 2020-02-20 16:34:12 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:34:12 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:34:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:34:12 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:12 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:34:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:34:12 --> Final output sent to browser
DEBUG - 2020-02-20 16:34:12 --> Total execution time: 0.8731
INFO - 2020-02-20 16:34:13 --> Config Class Initialized
INFO - 2020-02-20 16:34:13 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:34:13 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:34:13 --> Utf8 Class Initialized
INFO - 2020-02-20 16:34:13 --> URI Class Initialized
INFO - 2020-02-20 16:34:13 --> Router Class Initialized
INFO - 2020-02-20 16:34:13 --> Output Class Initialized
INFO - 2020-02-20 16:34:13 --> Security Class Initialized
DEBUG - 2020-02-20 16:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:34:13 --> CSRF cookie sent
INFO - 2020-02-20 16:34:13 --> Input Class Initialized
INFO - 2020-02-20 16:34:13 --> Language Class Initialized
INFO - 2020-02-20 16:34:13 --> Language Class Initialized
INFO - 2020-02-20 16:34:13 --> Config Class Initialized
INFO - 2020-02-20 16:34:13 --> Loader Class Initialized
INFO - 2020-02-20 16:34:13 --> Helper loaded: url_helper
INFO - 2020-02-20 16:34:13 --> Helper loaded: common_helper
INFO - 2020-02-20 16:34:13 --> Helper loaded: language_helper
INFO - 2020-02-20 16:34:13 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:34:13 --> Helper loaded: email_helper
INFO - 2020-02-20 16:34:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:34:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:34:13 --> Parser Class Initialized
INFO - 2020-02-20 16:34:13 --> User Agent Class Initialized
INFO - 2020-02-20 16:34:14 --> Model Class Initialized
INFO - 2020-02-20 16:34:14 --> Database Driver Class Initialized
INFO - 2020-02-20 16:34:14 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:14 --> Template Class Initialized
INFO - 2020-02-20 16:34:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:34:14 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:34:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:34:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:34:14 --> Encryption Class Initialized
INFO - 2020-02-20 16:34:14 --> Controller Class Initialized
DEBUG - 2020-02-20 16:34:14 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:34:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:14 --> Model Class Initialized
ERROR - 2020-02-20 16:34:14 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:34:14 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:34:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:34:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:34:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:34:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:34:14 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:14 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:14 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:34:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:34:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:34:14 --> Final output sent to browser
DEBUG - 2020-02-20 16:34:14 --> Total execution time: 0.8799
INFO - 2020-02-20 16:34:15 --> Config Class Initialized
INFO - 2020-02-20 16:34:15 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:34:15 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:34:15 --> Utf8 Class Initialized
INFO - 2020-02-20 16:34:15 --> URI Class Initialized
INFO - 2020-02-20 16:34:15 --> Router Class Initialized
INFO - 2020-02-20 16:34:15 --> Output Class Initialized
INFO - 2020-02-20 16:34:15 --> Security Class Initialized
DEBUG - 2020-02-20 16:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:34:15 --> CSRF cookie sent
INFO - 2020-02-20 16:34:15 --> Input Class Initialized
INFO - 2020-02-20 16:34:15 --> Language Class Initialized
INFO - 2020-02-20 16:34:15 --> Language Class Initialized
INFO - 2020-02-20 16:34:15 --> Config Class Initialized
INFO - 2020-02-20 16:34:15 --> Loader Class Initialized
INFO - 2020-02-20 16:34:15 --> Helper loaded: url_helper
INFO - 2020-02-20 16:34:15 --> Helper loaded: common_helper
INFO - 2020-02-20 16:34:15 --> Helper loaded: language_helper
INFO - 2020-02-20 16:34:15 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:34:15 --> Helper loaded: email_helper
INFO - 2020-02-20 16:34:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:34:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:34:15 --> Parser Class Initialized
INFO - 2020-02-20 16:34:15 --> User Agent Class Initialized
INFO - 2020-02-20 16:34:15 --> Model Class Initialized
INFO - 2020-02-20 16:34:15 --> Database Driver Class Initialized
INFO - 2020-02-20 16:34:15 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:16 --> Template Class Initialized
INFO - 2020-02-20 16:34:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:34:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:34:16 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:34:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:34:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:34:16 --> Encryption Class Initialized
INFO - 2020-02-20 16:34:16 --> Controller Class Initialized
DEBUG - 2020-02-20 16:34:16 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:16 --> Model Class Initialized
ERROR - 2020-02-20 16:34:16 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:34:16 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:34:16 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:34:16 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:16 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:16 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:34:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:34:16 --> Final output sent to browser
DEBUG - 2020-02-20 16:34:16 --> Total execution time: 0.8813
INFO - 2020-02-20 16:34:17 --> Config Class Initialized
INFO - 2020-02-20 16:34:17 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:34:17 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:34:17 --> Utf8 Class Initialized
INFO - 2020-02-20 16:34:17 --> URI Class Initialized
INFO - 2020-02-20 16:34:17 --> Router Class Initialized
INFO - 2020-02-20 16:34:17 --> Output Class Initialized
INFO - 2020-02-20 16:34:17 --> Security Class Initialized
DEBUG - 2020-02-20 16:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:34:18 --> CSRF cookie sent
INFO - 2020-02-20 16:34:18 --> Input Class Initialized
INFO - 2020-02-20 16:34:18 --> Language Class Initialized
INFO - 2020-02-20 16:34:18 --> Language Class Initialized
INFO - 2020-02-20 16:34:18 --> Config Class Initialized
INFO - 2020-02-20 16:34:18 --> Loader Class Initialized
INFO - 2020-02-20 16:34:18 --> Helper loaded: url_helper
INFO - 2020-02-20 16:34:18 --> Helper loaded: common_helper
INFO - 2020-02-20 16:34:18 --> Helper loaded: language_helper
INFO - 2020-02-20 16:34:18 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:34:18 --> Helper loaded: email_helper
INFO - 2020-02-20 16:34:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:34:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:34:18 --> Parser Class Initialized
INFO - 2020-02-20 16:34:18 --> User Agent Class Initialized
INFO - 2020-02-20 16:34:18 --> Model Class Initialized
INFO - 2020-02-20 16:34:18 --> Database Driver Class Initialized
INFO - 2020-02-20 16:34:18 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:18 --> Template Class Initialized
INFO - 2020-02-20 16:34:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:34:18 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:34:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:34:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:34:18 --> Encryption Class Initialized
INFO - 2020-02-20 16:34:18 --> Controller Class Initialized
DEBUG - 2020-02-20 16:34:18 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:18 --> Model Class Initialized
ERROR - 2020-02-20 16:34:18 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:34:18 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:34:18 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:34:18 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:18 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:18 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:34:18 --> Final output sent to browser
DEBUG - 2020-02-20 16:34:18 --> Total execution time: 0.9056
INFO - 2020-02-20 16:34:19 --> Config Class Initialized
INFO - 2020-02-20 16:34:19 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:34:19 --> Utf8 Class Initialized
INFO - 2020-02-20 16:34:19 --> URI Class Initialized
INFO - 2020-02-20 16:34:19 --> Router Class Initialized
INFO - 2020-02-20 16:34:19 --> Output Class Initialized
INFO - 2020-02-20 16:34:19 --> Security Class Initialized
DEBUG - 2020-02-20 16:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:34:19 --> CSRF cookie sent
INFO - 2020-02-20 16:34:19 --> Input Class Initialized
INFO - 2020-02-20 16:34:19 --> Language Class Initialized
INFO - 2020-02-20 16:34:19 --> Language Class Initialized
INFO - 2020-02-20 16:34:19 --> Config Class Initialized
INFO - 2020-02-20 16:34:19 --> Loader Class Initialized
INFO - 2020-02-20 16:34:19 --> Helper loaded: url_helper
INFO - 2020-02-20 16:34:19 --> Helper loaded: common_helper
INFO - 2020-02-20 16:34:19 --> Helper loaded: language_helper
INFO - 2020-02-20 16:34:19 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:34:19 --> Helper loaded: email_helper
INFO - 2020-02-20 16:34:20 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:34:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:34:20 --> Parser Class Initialized
INFO - 2020-02-20 16:34:20 --> User Agent Class Initialized
INFO - 2020-02-20 16:34:20 --> Model Class Initialized
INFO - 2020-02-20 16:34:20 --> Database Driver Class Initialized
INFO - 2020-02-20 16:34:20 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:20 --> Template Class Initialized
INFO - 2020-02-20 16:34:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:34:20 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:34:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:34:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:34:20 --> Encryption Class Initialized
INFO - 2020-02-20 16:34:20 --> Controller Class Initialized
DEBUG - 2020-02-20 16:34:20 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:34:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:20 --> Model Class Initialized
ERROR - 2020-02-20 16:34:20 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:34:20 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:34:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:34:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:34:20 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:34:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:34:20 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:20 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:20 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:34:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:34:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:34:20 --> Final output sent to browser
DEBUG - 2020-02-20 16:34:20 --> Total execution time: 0.8736
INFO - 2020-02-20 16:34:21 --> Config Class Initialized
INFO - 2020-02-20 16:34:21 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:34:21 --> Utf8 Class Initialized
INFO - 2020-02-20 16:34:21 --> URI Class Initialized
INFO - 2020-02-20 16:34:21 --> Router Class Initialized
INFO - 2020-02-20 16:34:21 --> Output Class Initialized
INFO - 2020-02-20 16:34:21 --> Security Class Initialized
DEBUG - 2020-02-20 16:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:34:21 --> CSRF cookie sent
INFO - 2020-02-20 16:34:21 --> Input Class Initialized
INFO - 2020-02-20 16:34:21 --> Language Class Initialized
INFO - 2020-02-20 16:34:21 --> Language Class Initialized
INFO - 2020-02-20 16:34:21 --> Config Class Initialized
INFO - 2020-02-20 16:34:21 --> Loader Class Initialized
INFO - 2020-02-20 16:34:21 --> Helper loaded: url_helper
INFO - 2020-02-20 16:34:21 --> Helper loaded: common_helper
INFO - 2020-02-20 16:34:21 --> Helper loaded: language_helper
INFO - 2020-02-20 16:34:21 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:34:21 --> Helper loaded: email_helper
INFO - 2020-02-20 16:34:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:34:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:34:21 --> Parser Class Initialized
INFO - 2020-02-20 16:34:21 --> User Agent Class Initialized
INFO - 2020-02-20 16:34:21 --> Model Class Initialized
INFO - 2020-02-20 16:34:21 --> Database Driver Class Initialized
INFO - 2020-02-20 16:34:21 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:21 --> Template Class Initialized
INFO - 2020-02-20 16:34:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:34:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:34:22 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:34:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:34:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:34:22 --> Encryption Class Initialized
INFO - 2020-02-20 16:34:22 --> Controller Class Initialized
DEBUG - 2020-02-20 16:34:22 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:34:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:22 --> Model Class Initialized
ERROR - 2020-02-20 16:34:22 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:34:22 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:34:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:34:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:34:22 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:34:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:34:22 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:22 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:22 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:34:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:34:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:34:22 --> Final output sent to browser
DEBUG - 2020-02-20 16:34:22 --> Total execution time: 0.8768
INFO - 2020-02-20 16:34:23 --> Config Class Initialized
INFO - 2020-02-20 16:34:23 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:34:23 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:34:23 --> Utf8 Class Initialized
INFO - 2020-02-20 16:34:23 --> URI Class Initialized
INFO - 2020-02-20 16:34:23 --> Router Class Initialized
INFO - 2020-02-20 16:34:23 --> Output Class Initialized
INFO - 2020-02-20 16:34:23 --> Security Class Initialized
DEBUG - 2020-02-20 16:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:34:23 --> CSRF cookie sent
INFO - 2020-02-20 16:34:23 --> Input Class Initialized
INFO - 2020-02-20 16:34:23 --> Language Class Initialized
INFO - 2020-02-20 16:34:23 --> Language Class Initialized
INFO - 2020-02-20 16:34:23 --> Config Class Initialized
INFO - 2020-02-20 16:34:23 --> Loader Class Initialized
INFO - 2020-02-20 16:34:23 --> Helper loaded: url_helper
INFO - 2020-02-20 16:34:23 --> Helper loaded: common_helper
INFO - 2020-02-20 16:34:23 --> Helper loaded: language_helper
INFO - 2020-02-20 16:34:23 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:34:23 --> Helper loaded: email_helper
INFO - 2020-02-20 16:34:23 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:34:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:34:23 --> Parser Class Initialized
INFO - 2020-02-20 16:34:23 --> User Agent Class Initialized
INFO - 2020-02-20 16:34:23 --> Model Class Initialized
INFO - 2020-02-20 16:34:23 --> Database Driver Class Initialized
INFO - 2020-02-20 16:34:23 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:23 --> Template Class Initialized
INFO - 2020-02-20 16:34:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:34:23 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:34:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:34:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:34:23 --> Encryption Class Initialized
INFO - 2020-02-20 16:34:23 --> Controller Class Initialized
DEBUG - 2020-02-20 16:34:23 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:34:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:23 --> Model Class Initialized
ERROR - 2020-02-20 16:34:24 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:34:24 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:34:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:34:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:34:24 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:34:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:34:24 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:24 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:34:24 --> Model Class Initialized
DEBUG - 2020-02-20 16:34:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:34:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:34:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:34:24 --> Final output sent to browser
DEBUG - 2020-02-20 16:34:24 --> Total execution time: 0.9277
INFO - 2020-02-20 16:36:18 --> Config Class Initialized
INFO - 2020-02-20 16:36:18 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:36:18 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:36:19 --> Utf8 Class Initialized
INFO - 2020-02-20 16:36:19 --> URI Class Initialized
INFO - 2020-02-20 16:36:19 --> Router Class Initialized
INFO - 2020-02-20 16:36:19 --> Output Class Initialized
INFO - 2020-02-20 16:36:19 --> Security Class Initialized
DEBUG - 2020-02-20 16:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:36:19 --> CSRF cookie sent
INFO - 2020-02-20 16:36:19 --> Input Class Initialized
INFO - 2020-02-20 16:36:19 --> Language Class Initialized
INFO - 2020-02-20 16:36:19 --> Language Class Initialized
INFO - 2020-02-20 16:36:19 --> Config Class Initialized
INFO - 2020-02-20 16:36:19 --> Loader Class Initialized
INFO - 2020-02-20 16:36:19 --> Helper loaded: url_helper
INFO - 2020-02-20 16:36:19 --> Helper loaded: common_helper
INFO - 2020-02-20 16:36:19 --> Helper loaded: language_helper
INFO - 2020-02-20 16:36:19 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:36:19 --> Helper loaded: email_helper
INFO - 2020-02-20 16:36:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:36:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:36:19 --> Parser Class Initialized
INFO - 2020-02-20 16:36:19 --> User Agent Class Initialized
INFO - 2020-02-20 16:36:19 --> Model Class Initialized
INFO - 2020-02-20 16:36:19 --> Database Driver Class Initialized
INFO - 2020-02-20 16:36:19 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:19 --> Template Class Initialized
INFO - 2020-02-20 16:36:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:36:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:36:19 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:36:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:36:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:36:19 --> Encryption Class Initialized
INFO - 2020-02-20 16:36:19 --> Controller Class Initialized
DEBUG - 2020-02-20 16:36:19 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:36:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:36:19 --> Model Class Initialized
ERROR - 2020-02-20 16:36:19 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:36:19 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:36:19 --> Severity: Notice --> Undefined property: stdClass::$language_code D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 33
ERROR - 2020-02-20 16:36:19 --> Severity: Notice --> Undefined property: stdClass::$language_code D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 33
DEBUG - 2020-02-20 16:36:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:36:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:36:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:36:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:36:19 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:19 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:36:19 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:36:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:36:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:36:19 --> Final output sent to browser
DEBUG - 2020-02-20 16:36:19 --> Total execution time: 0.9836
INFO - 2020-02-20 16:36:34 --> Config Class Initialized
INFO - 2020-02-20 16:36:34 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:36:34 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:36:35 --> Utf8 Class Initialized
INFO - 2020-02-20 16:36:35 --> URI Class Initialized
INFO - 2020-02-20 16:36:35 --> Router Class Initialized
INFO - 2020-02-20 16:36:35 --> Output Class Initialized
INFO - 2020-02-20 16:36:35 --> Security Class Initialized
DEBUG - 2020-02-20 16:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:36:35 --> CSRF cookie sent
INFO - 2020-02-20 16:36:35 --> Input Class Initialized
INFO - 2020-02-20 16:36:35 --> Language Class Initialized
INFO - 2020-02-20 16:36:35 --> Language Class Initialized
INFO - 2020-02-20 16:36:35 --> Config Class Initialized
INFO - 2020-02-20 16:36:35 --> Loader Class Initialized
INFO - 2020-02-20 16:36:35 --> Helper loaded: url_helper
INFO - 2020-02-20 16:36:35 --> Helper loaded: common_helper
INFO - 2020-02-20 16:36:35 --> Helper loaded: language_helper
INFO - 2020-02-20 16:36:35 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:36:35 --> Helper loaded: email_helper
INFO - 2020-02-20 16:36:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:36:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:36:35 --> Parser Class Initialized
INFO - 2020-02-20 16:36:35 --> User Agent Class Initialized
INFO - 2020-02-20 16:36:35 --> Model Class Initialized
INFO - 2020-02-20 16:36:35 --> Database Driver Class Initialized
INFO - 2020-02-20 16:36:35 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:35 --> Template Class Initialized
INFO - 2020-02-20 16:36:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:36:35 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:36:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:36:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:36:35 --> Encryption Class Initialized
INFO - 2020-02-20 16:36:35 --> Controller Class Initialized
DEBUG - 2020-02-20 16:36:35 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:36:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:36:35 --> Model Class Initialized
ERROR - 2020-02-20 16:36:35 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:36:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:36:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:36:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:36:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:36:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:36:35 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:35 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:36:35 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:36:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:36:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:36:36 --> Final output sent to browser
DEBUG - 2020-02-20 16:36:36 --> Total execution time: 1.0966
INFO - 2020-02-20 16:36:41 --> Config Class Initialized
INFO - 2020-02-20 16:36:42 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:36:42 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:36:42 --> Utf8 Class Initialized
INFO - 2020-02-20 16:36:42 --> URI Class Initialized
INFO - 2020-02-20 16:36:42 --> Router Class Initialized
INFO - 2020-02-20 16:36:42 --> Output Class Initialized
INFO - 2020-02-20 16:36:42 --> Security Class Initialized
DEBUG - 2020-02-20 16:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:36:42 --> CSRF cookie sent
INFO - 2020-02-20 16:36:42 --> Input Class Initialized
INFO - 2020-02-20 16:36:42 --> Language Class Initialized
INFO - 2020-02-20 16:36:42 --> Language Class Initialized
INFO - 2020-02-20 16:36:42 --> Config Class Initialized
INFO - 2020-02-20 16:36:42 --> Loader Class Initialized
INFO - 2020-02-20 16:36:42 --> Helper loaded: url_helper
INFO - 2020-02-20 16:36:42 --> Helper loaded: common_helper
INFO - 2020-02-20 16:36:42 --> Helper loaded: language_helper
INFO - 2020-02-20 16:36:42 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:36:42 --> Helper loaded: email_helper
INFO - 2020-02-20 16:36:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:36:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:36:42 --> Parser Class Initialized
INFO - 2020-02-20 16:36:42 --> User Agent Class Initialized
INFO - 2020-02-20 16:36:42 --> Model Class Initialized
INFO - 2020-02-20 16:36:42 --> Database Driver Class Initialized
INFO - 2020-02-20 16:36:42 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:42 --> Template Class Initialized
INFO - 2020-02-20 16:36:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:36:42 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:36:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:36:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:36:42 --> Encryption Class Initialized
INFO - 2020-02-20 16:36:42 --> Controller Class Initialized
DEBUG - 2020-02-20 16:36:42 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:36:42 --> Model Class Initialized
ERROR - 2020-02-20 16:36:42 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:36:42 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:36:42 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:36:42 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:42 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:36:42 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:36:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:36:42 --> Final output sent to browser
DEBUG - 2020-02-20 16:36:42 --> Total execution time: 0.9544
INFO - 2020-02-20 16:36:43 --> Config Class Initialized
INFO - 2020-02-20 16:36:43 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:36:43 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:36:43 --> Utf8 Class Initialized
INFO - 2020-02-20 16:36:43 --> URI Class Initialized
INFO - 2020-02-20 16:36:43 --> Router Class Initialized
INFO - 2020-02-20 16:36:43 --> Output Class Initialized
INFO - 2020-02-20 16:36:43 --> Security Class Initialized
DEBUG - 2020-02-20 16:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:36:43 --> CSRF cookie sent
INFO - 2020-02-20 16:36:43 --> Input Class Initialized
INFO - 2020-02-20 16:36:43 --> Language Class Initialized
INFO - 2020-02-20 16:36:43 --> Language Class Initialized
INFO - 2020-02-20 16:36:43 --> Config Class Initialized
INFO - 2020-02-20 16:36:43 --> Loader Class Initialized
INFO - 2020-02-20 16:36:43 --> Helper loaded: url_helper
INFO - 2020-02-20 16:36:44 --> Helper loaded: common_helper
INFO - 2020-02-20 16:36:44 --> Helper loaded: language_helper
INFO - 2020-02-20 16:36:44 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:36:44 --> Helper loaded: email_helper
INFO - 2020-02-20 16:36:44 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:36:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:36:44 --> Parser Class Initialized
INFO - 2020-02-20 16:36:44 --> User Agent Class Initialized
INFO - 2020-02-20 16:36:44 --> Model Class Initialized
INFO - 2020-02-20 16:36:44 --> Database Driver Class Initialized
INFO - 2020-02-20 16:36:44 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:44 --> Template Class Initialized
INFO - 2020-02-20 16:36:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:36:44 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:36:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:36:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:36:44 --> Encryption Class Initialized
INFO - 2020-02-20 16:36:44 --> Controller Class Initialized
DEBUG - 2020-02-20 16:36:44 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:36:44 --> Model Class Initialized
ERROR - 2020-02-20 16:36:44 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:36:44 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:36:44 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:36:44 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:44 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:36:44 --> Model Class Initialized
DEBUG - 2020-02-20 16:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:36:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:36:44 --> Final output sent to browser
DEBUG - 2020-02-20 16:36:44 --> Total execution time: 0.9529
INFO - 2020-02-20 16:37:04 --> Config Class Initialized
INFO - 2020-02-20 16:37:04 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:37:04 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:37:04 --> Utf8 Class Initialized
INFO - 2020-02-20 16:37:04 --> URI Class Initialized
INFO - 2020-02-20 16:37:04 --> Router Class Initialized
INFO - 2020-02-20 16:37:04 --> Output Class Initialized
INFO - 2020-02-20 16:37:04 --> Security Class Initialized
DEBUG - 2020-02-20 16:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:37:04 --> CSRF cookie sent
INFO - 2020-02-20 16:37:04 --> Input Class Initialized
INFO - 2020-02-20 16:37:04 --> Language Class Initialized
INFO - 2020-02-20 16:37:04 --> Language Class Initialized
INFO - 2020-02-20 16:37:04 --> Config Class Initialized
INFO - 2020-02-20 16:37:04 --> Loader Class Initialized
INFO - 2020-02-20 16:37:04 --> Helper loaded: url_helper
INFO - 2020-02-20 16:37:04 --> Helper loaded: common_helper
INFO - 2020-02-20 16:37:04 --> Helper loaded: language_helper
INFO - 2020-02-20 16:37:04 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:37:04 --> Helper loaded: email_helper
INFO - 2020-02-20 16:37:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:37:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:37:04 --> Parser Class Initialized
INFO - 2020-02-20 16:37:05 --> User Agent Class Initialized
INFO - 2020-02-20 16:37:05 --> Model Class Initialized
INFO - 2020-02-20 16:37:05 --> Database Driver Class Initialized
INFO - 2020-02-20 16:37:05 --> Model Class Initialized
DEBUG - 2020-02-20 16:37:05 --> Template Class Initialized
INFO - 2020-02-20 16:37:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:37:05 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:37:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:37:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:37:05 --> Encryption Class Initialized
INFO - 2020-02-20 16:37:05 --> Controller Class Initialized
DEBUG - 2020-02-20 16:37:05 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:37:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:37:05 --> Model Class Initialized
ERROR - 2020-02-20 16:37:05 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:37:05 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:37:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:37:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:37:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:37:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:37:05 --> Model Class Initialized
DEBUG - 2020-02-20 16:37:05 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:37:05 --> Model Class Initialized
DEBUG - 2020-02-20 16:37:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:37:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:37:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:37:05 --> Final output sent to browser
DEBUG - 2020-02-20 16:37:05 --> Total execution time: 1.0031
INFO - 2020-02-20 16:38:46 --> Config Class Initialized
INFO - 2020-02-20 16:38:46 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:38:46 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:38:46 --> Utf8 Class Initialized
INFO - 2020-02-20 16:38:46 --> URI Class Initialized
INFO - 2020-02-20 16:38:46 --> Router Class Initialized
INFO - 2020-02-20 16:38:46 --> Output Class Initialized
INFO - 2020-02-20 16:38:46 --> Security Class Initialized
DEBUG - 2020-02-20 16:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:38:47 --> CSRF cookie sent
INFO - 2020-02-20 16:38:47 --> Input Class Initialized
INFO - 2020-02-20 16:38:47 --> Language Class Initialized
INFO - 2020-02-20 16:38:47 --> Language Class Initialized
INFO - 2020-02-20 16:38:47 --> Config Class Initialized
INFO - 2020-02-20 16:38:47 --> Loader Class Initialized
INFO - 2020-02-20 16:38:47 --> Helper loaded: url_helper
INFO - 2020-02-20 16:38:47 --> Helper loaded: common_helper
INFO - 2020-02-20 16:38:47 --> Helper loaded: language_helper
INFO - 2020-02-20 16:38:47 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:38:47 --> Helper loaded: email_helper
INFO - 2020-02-20 16:38:47 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:38:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:38:47 --> Parser Class Initialized
INFO - 2020-02-20 16:38:47 --> User Agent Class Initialized
INFO - 2020-02-20 16:38:47 --> Model Class Initialized
INFO - 2020-02-20 16:38:47 --> Database Driver Class Initialized
INFO - 2020-02-20 16:38:47 --> Model Class Initialized
DEBUG - 2020-02-20 16:38:47 --> Template Class Initialized
INFO - 2020-02-20 16:38:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:38:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:38:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:38:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:38:47 --> Encryption Class Initialized
INFO - 2020-02-20 16:38:47 --> Controller Class Initialized
DEBUG - 2020-02-20 16:38:47 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:38:47 --> Model Class Initialized
ERROR - 2020-02-20 16:38:47 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:38:47 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:38:47 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:38:47 --> Model Class Initialized
DEBUG - 2020-02-20 16:38:47 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:38:47 --> Model Class Initialized
DEBUG - 2020-02-20 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:38:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:38:47 --> Final output sent to browser
DEBUG - 2020-02-20 16:38:47 --> Total execution time: 0.9796
INFO - 2020-02-20 16:38:54 --> Config Class Initialized
INFO - 2020-02-20 16:38:54 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:38:54 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:38:54 --> Utf8 Class Initialized
INFO - 2020-02-20 16:38:54 --> URI Class Initialized
INFO - 2020-02-20 16:38:54 --> Router Class Initialized
INFO - 2020-02-20 16:38:54 --> Output Class Initialized
INFO - 2020-02-20 16:38:54 --> Security Class Initialized
DEBUG - 2020-02-20 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:38:54 --> CSRF cookie sent
INFO - 2020-02-20 16:38:54 --> Input Class Initialized
INFO - 2020-02-20 16:38:54 --> Language Class Initialized
INFO - 2020-02-20 16:38:54 --> Language Class Initialized
INFO - 2020-02-20 16:38:54 --> Config Class Initialized
INFO - 2020-02-20 16:38:54 --> Loader Class Initialized
INFO - 2020-02-20 16:38:54 --> Helper loaded: url_helper
INFO - 2020-02-20 16:38:54 --> Helper loaded: common_helper
INFO - 2020-02-20 16:38:54 --> Helper loaded: language_helper
INFO - 2020-02-20 16:38:54 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:38:54 --> Helper loaded: email_helper
INFO - 2020-02-20 16:38:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:38:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:38:54 --> Parser Class Initialized
INFO - 2020-02-20 16:38:54 --> User Agent Class Initialized
INFO - 2020-02-20 16:38:54 --> Model Class Initialized
INFO - 2020-02-20 16:38:54 --> Database Driver Class Initialized
INFO - 2020-02-20 16:38:54 --> Model Class Initialized
DEBUG - 2020-02-20 16:38:54 --> Template Class Initialized
INFO - 2020-02-20 16:38:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:38:54 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:38:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:38:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:38:55 --> Encryption Class Initialized
INFO - 2020-02-20 16:38:55 --> Controller Class Initialized
DEBUG - 2020-02-20 16:38:55 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:38:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:38:55 --> Model Class Initialized
ERROR - 2020-02-20 16:38:55 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:38:55 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:38:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:38:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:38:55 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:38:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:38:55 --> Model Class Initialized
DEBUG - 2020-02-20 16:38:55 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:38:55 --> Model Class Initialized
DEBUG - 2020-02-20 16:38:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:38:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:38:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:38:55 --> Final output sent to browser
DEBUG - 2020-02-20 16:38:55 --> Total execution time: 1.0021
INFO - 2020-02-20 16:40:36 --> Config Class Initialized
INFO - 2020-02-20 16:40:36 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:40:36 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:40:36 --> Utf8 Class Initialized
INFO - 2020-02-20 16:40:36 --> URI Class Initialized
INFO - 2020-02-20 16:40:36 --> Router Class Initialized
INFO - 2020-02-20 16:40:36 --> Output Class Initialized
INFO - 2020-02-20 16:40:36 --> Security Class Initialized
DEBUG - 2020-02-20 16:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:40:36 --> CSRF cookie sent
INFO - 2020-02-20 16:40:36 --> Input Class Initialized
INFO - 2020-02-20 16:40:36 --> Language Class Initialized
INFO - 2020-02-20 16:40:36 --> Language Class Initialized
INFO - 2020-02-20 16:40:36 --> Config Class Initialized
INFO - 2020-02-20 16:40:36 --> Loader Class Initialized
INFO - 2020-02-20 16:40:36 --> Helper loaded: url_helper
INFO - 2020-02-20 16:40:36 --> Helper loaded: common_helper
INFO - 2020-02-20 16:40:36 --> Helper loaded: language_helper
INFO - 2020-02-20 16:40:36 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:40:36 --> Helper loaded: email_helper
INFO - 2020-02-20 16:40:36 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:40:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:40:36 --> Parser Class Initialized
INFO - 2020-02-20 16:40:36 --> User Agent Class Initialized
INFO - 2020-02-20 16:40:36 --> Model Class Initialized
INFO - 2020-02-20 16:40:36 --> Database Driver Class Initialized
INFO - 2020-02-20 16:40:36 --> Model Class Initialized
DEBUG - 2020-02-20 16:40:36 --> Template Class Initialized
INFO - 2020-02-20 16:40:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:40:37 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:40:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:40:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:40:37 --> Encryption Class Initialized
INFO - 2020-02-20 16:40:37 --> Controller Class Initialized
DEBUG - 2020-02-20 16:40:37 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:40:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:40:37 --> Model Class Initialized
ERROR - 2020-02-20 16:40:37 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:40:37 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:40:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:40:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:40:37 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:40:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:40:37 --> Model Class Initialized
DEBUG - 2020-02-20 16:40:37 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:40:37 --> Model Class Initialized
DEBUG - 2020-02-20 16:40:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:40:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:40:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:40:37 --> Final output sent to browser
DEBUG - 2020-02-20 16:40:37 --> Total execution time: 0.9811
INFO - 2020-02-20 16:40:47 --> Config Class Initialized
INFO - 2020-02-20 16:40:47 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:40:47 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:40:47 --> Utf8 Class Initialized
INFO - 2020-02-20 16:40:47 --> URI Class Initialized
INFO - 2020-02-20 16:40:47 --> Router Class Initialized
INFO - 2020-02-20 16:40:47 --> Output Class Initialized
INFO - 2020-02-20 16:40:47 --> Security Class Initialized
DEBUG - 2020-02-20 16:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:40:47 --> CSRF cookie sent
INFO - 2020-02-20 16:40:47 --> Input Class Initialized
INFO - 2020-02-20 16:40:47 --> Language Class Initialized
INFO - 2020-02-20 16:40:47 --> Language Class Initialized
INFO - 2020-02-20 16:40:47 --> Config Class Initialized
INFO - 2020-02-20 16:40:47 --> Loader Class Initialized
INFO - 2020-02-20 16:40:47 --> Helper loaded: url_helper
INFO - 2020-02-20 16:40:48 --> Helper loaded: common_helper
INFO - 2020-02-20 16:40:48 --> Helper loaded: language_helper
INFO - 2020-02-20 16:40:48 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:40:48 --> Helper loaded: email_helper
INFO - 2020-02-20 16:40:48 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:40:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:40:48 --> Parser Class Initialized
INFO - 2020-02-20 16:40:48 --> User Agent Class Initialized
INFO - 2020-02-20 16:40:48 --> Model Class Initialized
INFO - 2020-02-20 16:40:48 --> Database Driver Class Initialized
INFO - 2020-02-20 16:40:48 --> Model Class Initialized
DEBUG - 2020-02-20 16:40:48 --> Template Class Initialized
INFO - 2020-02-20 16:40:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:40:48 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:40:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:40:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:40:48 --> Encryption Class Initialized
INFO - 2020-02-20 16:40:48 --> Controller Class Initialized
DEBUG - 2020-02-20 16:40:48 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:40:48 --> Model Class Initialized
ERROR - 2020-02-20 16:40:48 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:40:48 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:40:48 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:40:48 --> Model Class Initialized
DEBUG - 2020-02-20 16:40:48 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:40:48 --> Model Class Initialized
DEBUG - 2020-02-20 16:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:40:48 --> Final output sent to browser
DEBUG - 2020-02-20 16:40:48 --> Total execution time: 1.0362
INFO - 2020-02-20 16:42:30 --> Config Class Initialized
INFO - 2020-02-20 16:42:30 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:42:30 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:42:30 --> Utf8 Class Initialized
INFO - 2020-02-20 16:42:30 --> URI Class Initialized
INFO - 2020-02-20 16:42:30 --> Router Class Initialized
INFO - 2020-02-20 16:42:30 --> Output Class Initialized
INFO - 2020-02-20 16:42:30 --> Security Class Initialized
DEBUG - 2020-02-20 16:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:42:30 --> CSRF cookie sent
INFO - 2020-02-20 16:42:30 --> Input Class Initialized
INFO - 2020-02-20 16:42:30 --> Language Class Initialized
INFO - 2020-02-20 16:42:30 --> Language Class Initialized
INFO - 2020-02-20 16:42:30 --> Config Class Initialized
INFO - 2020-02-20 16:42:30 --> Loader Class Initialized
INFO - 2020-02-20 16:42:30 --> Helper loaded: url_helper
INFO - 2020-02-20 16:42:30 --> Helper loaded: common_helper
INFO - 2020-02-20 16:42:30 --> Helper loaded: language_helper
INFO - 2020-02-20 16:42:30 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:42:30 --> Helper loaded: email_helper
INFO - 2020-02-20 16:42:30 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:42:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:42:30 --> Parser Class Initialized
INFO - 2020-02-20 16:42:30 --> User Agent Class Initialized
INFO - 2020-02-20 16:42:30 --> Model Class Initialized
INFO - 2020-02-20 16:42:30 --> Database Driver Class Initialized
INFO - 2020-02-20 16:42:30 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:30 --> Template Class Initialized
INFO - 2020-02-20 16:42:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:42:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:42:30 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:42:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:42:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:42:30 --> Encryption Class Initialized
INFO - 2020-02-20 16:42:30 --> Controller Class Initialized
DEBUG - 2020-02-20 16:42:30 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:42:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:42:30 --> Model Class Initialized
ERROR - 2020-02-20 16:42:30 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:42:30 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:42:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:42:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:42:31 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:42:31 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:31 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:42:31 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:42:31 --> Final output sent to browser
DEBUG - 2020-02-20 16:42:31 --> Total execution time: 0.9099
INFO - 2020-02-20 16:42:46 --> Config Class Initialized
INFO - 2020-02-20 16:42:46 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:42:46 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:42:46 --> Utf8 Class Initialized
INFO - 2020-02-20 16:42:46 --> URI Class Initialized
INFO - 2020-02-20 16:42:46 --> Router Class Initialized
INFO - 2020-02-20 16:42:46 --> Output Class Initialized
INFO - 2020-02-20 16:42:46 --> Security Class Initialized
DEBUG - 2020-02-20 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:42:46 --> CSRF cookie sent
INFO - 2020-02-20 16:42:46 --> CSRF token verified
INFO - 2020-02-20 16:42:46 --> Input Class Initialized
INFO - 2020-02-20 16:42:46 --> Language Class Initialized
INFO - 2020-02-20 16:42:46 --> Language Class Initialized
INFO - 2020-02-20 16:42:46 --> Config Class Initialized
INFO - 2020-02-20 16:42:46 --> Loader Class Initialized
INFO - 2020-02-20 16:42:46 --> Helper loaded: url_helper
INFO - 2020-02-20 16:42:46 --> Helper loaded: common_helper
INFO - 2020-02-20 16:42:46 --> Helper loaded: language_helper
INFO - 2020-02-20 16:42:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:42:46 --> Helper loaded: email_helper
INFO - 2020-02-20 16:42:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:42:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:42:46 --> Parser Class Initialized
INFO - 2020-02-20 16:42:46 --> User Agent Class Initialized
INFO - 2020-02-20 16:42:46 --> Model Class Initialized
INFO - 2020-02-20 16:42:46 --> Database Driver Class Initialized
INFO - 2020-02-20 16:42:46 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:46 --> Template Class Initialized
INFO - 2020-02-20 16:42:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:42:46 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:42:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:42:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:42:46 --> Encryption Class Initialized
INFO - 2020-02-20 16:42:46 --> Controller Class Initialized
DEBUG - 2020-02-20 16:42:46 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:42:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:42:46 --> Model Class Initialized
ERROR - 2020-02-20 16:42:46 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:42:55 --> Config Class Initialized
INFO - 2020-02-20 16:42:55 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:42:55 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:42:55 --> Utf8 Class Initialized
INFO - 2020-02-20 16:42:55 --> URI Class Initialized
INFO - 2020-02-20 16:42:55 --> Router Class Initialized
INFO - 2020-02-20 16:42:55 --> Output Class Initialized
INFO - 2020-02-20 16:42:55 --> Security Class Initialized
DEBUG - 2020-02-20 16:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:42:55 --> CSRF cookie sent
INFO - 2020-02-20 16:42:55 --> Input Class Initialized
INFO - 2020-02-20 16:42:55 --> Language Class Initialized
INFO - 2020-02-20 16:42:55 --> Language Class Initialized
INFO - 2020-02-20 16:42:55 --> Config Class Initialized
INFO - 2020-02-20 16:42:55 --> Loader Class Initialized
INFO - 2020-02-20 16:42:55 --> Helper loaded: url_helper
INFO - 2020-02-20 16:42:55 --> Helper loaded: common_helper
INFO - 2020-02-20 16:42:55 --> Helper loaded: language_helper
INFO - 2020-02-20 16:42:55 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:42:55 --> Helper loaded: email_helper
INFO - 2020-02-20 16:42:55 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:42:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:42:55 --> Parser Class Initialized
INFO - 2020-02-20 16:42:55 --> User Agent Class Initialized
INFO - 2020-02-20 16:42:55 --> Model Class Initialized
INFO - 2020-02-20 16:42:55 --> Database Driver Class Initialized
INFO - 2020-02-20 16:42:55 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:55 --> Template Class Initialized
INFO - 2020-02-20 16:42:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:42:55 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:42:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:42:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:42:55 --> Encryption Class Initialized
INFO - 2020-02-20 16:42:55 --> Controller Class Initialized
DEBUG - 2020-02-20 16:42:55 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:42:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:42:55 --> Model Class Initialized
ERROR - 2020-02-20 16:42:55 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:42:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:42:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:42:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:42:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:42:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:42:56 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:42:56 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:42:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:42:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:42:56 --> Final output sent to browser
DEBUG - 2020-02-20 16:42:56 --> Total execution time: 0.9576
INFO - 2020-02-20 16:42:56 --> Config Class Initialized
INFO - 2020-02-20 16:42:56 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:42:56 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:42:56 --> Utf8 Class Initialized
INFO - 2020-02-20 16:42:56 --> URI Class Initialized
INFO - 2020-02-20 16:42:56 --> Router Class Initialized
INFO - 2020-02-20 16:42:56 --> Output Class Initialized
INFO - 2020-02-20 16:42:56 --> Security Class Initialized
DEBUG - 2020-02-20 16:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:42:56 --> CSRF cookie sent
INFO - 2020-02-20 16:42:56 --> Input Class Initialized
INFO - 2020-02-20 16:42:56 --> Language Class Initialized
INFO - 2020-02-20 16:42:56 --> Language Class Initialized
INFO - 2020-02-20 16:42:56 --> Config Class Initialized
INFO - 2020-02-20 16:42:57 --> Loader Class Initialized
INFO - 2020-02-20 16:42:57 --> Helper loaded: url_helper
INFO - 2020-02-20 16:42:57 --> Helper loaded: common_helper
INFO - 2020-02-20 16:42:57 --> Helper loaded: language_helper
INFO - 2020-02-20 16:42:57 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:42:57 --> Helper loaded: email_helper
INFO - 2020-02-20 16:42:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:42:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:42:57 --> Parser Class Initialized
INFO - 2020-02-20 16:42:57 --> User Agent Class Initialized
INFO - 2020-02-20 16:42:57 --> Model Class Initialized
INFO - 2020-02-20 16:42:57 --> Database Driver Class Initialized
INFO - 2020-02-20 16:42:57 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:57 --> Template Class Initialized
INFO - 2020-02-20 16:42:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:42:57 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:42:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:42:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:42:57 --> Encryption Class Initialized
INFO - 2020-02-20 16:42:57 --> Controller Class Initialized
DEBUG - 2020-02-20 16:42:57 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:42:57 --> Model Class Initialized
ERROR - 2020-02-20 16:42:57 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:42:57 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:42:57 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:42:57 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:57 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:42:57 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:42:57 --> Final output sent to browser
DEBUG - 2020-02-20 16:42:57 --> Total execution time: 1.0712
INFO - 2020-02-20 16:42:58 --> Config Class Initialized
INFO - 2020-02-20 16:42:58 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:42:58 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:42:58 --> Utf8 Class Initialized
INFO - 2020-02-20 16:42:58 --> URI Class Initialized
INFO - 2020-02-20 16:42:58 --> Router Class Initialized
INFO - 2020-02-20 16:42:58 --> Output Class Initialized
INFO - 2020-02-20 16:42:58 --> Security Class Initialized
DEBUG - 2020-02-20 16:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:42:58 --> CSRF cookie sent
INFO - 2020-02-20 16:42:58 --> Input Class Initialized
INFO - 2020-02-20 16:42:58 --> Language Class Initialized
INFO - 2020-02-20 16:42:58 --> Language Class Initialized
INFO - 2020-02-20 16:42:58 --> Config Class Initialized
INFO - 2020-02-20 16:42:58 --> Loader Class Initialized
INFO - 2020-02-20 16:42:58 --> Helper loaded: url_helper
INFO - 2020-02-20 16:42:58 --> Helper loaded: common_helper
INFO - 2020-02-20 16:42:58 --> Helper loaded: language_helper
INFO - 2020-02-20 16:42:58 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:42:58 --> Helper loaded: email_helper
INFO - 2020-02-20 16:42:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:42:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:42:58 --> Parser Class Initialized
INFO - 2020-02-20 16:42:58 --> User Agent Class Initialized
INFO - 2020-02-20 16:42:58 --> Model Class Initialized
INFO - 2020-02-20 16:42:58 --> Database Driver Class Initialized
INFO - 2020-02-20 16:42:58 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:58 --> Template Class Initialized
INFO - 2020-02-20 16:42:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:42:58 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:42:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:42:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:42:58 --> Encryption Class Initialized
INFO - 2020-02-20 16:42:58 --> Controller Class Initialized
DEBUG - 2020-02-20 16:42:58 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:42:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:42:58 --> Model Class Initialized
ERROR - 2020-02-20 16:42:58 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:42:58 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:42:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:42:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:42:59 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:59 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:42:59 --> Model Class Initialized
DEBUG - 2020-02-20 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:42:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:42:59 --> Final output sent to browser
DEBUG - 2020-02-20 16:42:59 --> Total execution time: 0.9849
INFO - 2020-02-20 16:43:00 --> Config Class Initialized
INFO - 2020-02-20 16:43:00 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:43:00 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:43:00 --> Utf8 Class Initialized
INFO - 2020-02-20 16:43:00 --> URI Class Initialized
INFO - 2020-02-20 16:43:00 --> Router Class Initialized
INFO - 2020-02-20 16:43:00 --> Output Class Initialized
INFO - 2020-02-20 16:43:00 --> Security Class Initialized
DEBUG - 2020-02-20 16:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:43:00 --> CSRF cookie sent
INFO - 2020-02-20 16:43:00 --> Input Class Initialized
INFO - 2020-02-20 16:43:00 --> Language Class Initialized
INFO - 2020-02-20 16:43:00 --> Language Class Initialized
INFO - 2020-02-20 16:43:00 --> Config Class Initialized
INFO - 2020-02-20 16:43:00 --> Loader Class Initialized
INFO - 2020-02-20 16:43:00 --> Helper loaded: url_helper
INFO - 2020-02-20 16:43:00 --> Helper loaded: common_helper
INFO - 2020-02-20 16:43:00 --> Helper loaded: language_helper
INFO - 2020-02-20 16:43:00 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:43:00 --> Helper loaded: email_helper
INFO - 2020-02-20 16:43:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:43:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:43:01 --> Parser Class Initialized
INFO - 2020-02-20 16:43:01 --> User Agent Class Initialized
INFO - 2020-02-20 16:43:01 --> Model Class Initialized
INFO - 2020-02-20 16:43:01 --> Database Driver Class Initialized
INFO - 2020-02-20 16:43:01 --> Model Class Initialized
DEBUG - 2020-02-20 16:43:01 --> Template Class Initialized
INFO - 2020-02-20 16:43:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:43:01 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:43:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:43:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:43:01 --> Encryption Class Initialized
INFO - 2020-02-20 16:43:01 --> Controller Class Initialized
DEBUG - 2020-02-20 16:43:01 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:43:01 --> Model Class Initialized
ERROR - 2020-02-20 16:43:01 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:43:01 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:43:01 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:43:01 --> Model Class Initialized
DEBUG - 2020-02-20 16:43:01 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:43:01 --> Model Class Initialized
DEBUG - 2020-02-20 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
INFO - 2020-02-20 16:43:01 --> Config Class Initialized
INFO - 2020-02-20 16:43:01 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:43:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-20 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
INFO - 2020-02-20 16:43:01 --> Utf8 Class Initialized
DEBUG - 2020-02-20 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:43:01 --> Final output sent to browser
INFO - 2020-02-20 16:43:01 --> URI Class Initialized
DEBUG - 2020-02-20 16:43:01 --> Total execution time: 1.1560
INFO - 2020-02-20 16:43:01 --> Router Class Initialized
INFO - 2020-02-20 16:43:01 --> Output Class Initialized
INFO - 2020-02-20 16:43:01 --> Security Class Initialized
DEBUG - 2020-02-20 16:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:43:01 --> CSRF cookie sent
INFO - 2020-02-20 16:43:02 --> Input Class Initialized
INFO - 2020-02-20 16:43:02 --> Language Class Initialized
INFO - 2020-02-20 16:43:02 --> Language Class Initialized
INFO - 2020-02-20 16:43:02 --> Config Class Initialized
INFO - 2020-02-20 16:43:02 --> Loader Class Initialized
INFO - 2020-02-20 16:43:02 --> Helper loaded: url_helper
INFO - 2020-02-20 16:43:02 --> Helper loaded: common_helper
INFO - 2020-02-20 16:43:02 --> Helper loaded: language_helper
INFO - 2020-02-20 16:43:02 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:43:02 --> Helper loaded: email_helper
INFO - 2020-02-20 16:43:02 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:43:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:43:02 --> Parser Class Initialized
INFO - 2020-02-20 16:43:02 --> User Agent Class Initialized
INFO - 2020-02-20 16:43:02 --> Model Class Initialized
INFO - 2020-02-20 16:43:02 --> Database Driver Class Initialized
INFO - 2020-02-20 16:43:02 --> Model Class Initialized
DEBUG - 2020-02-20 16:43:02 --> Template Class Initialized
INFO - 2020-02-20 16:43:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:43:02 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:43:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:43:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:43:02 --> Encryption Class Initialized
INFO - 2020-02-20 16:43:02 --> Controller Class Initialized
DEBUG - 2020-02-20 16:43:02 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:43:02 --> Model Class Initialized
ERROR - 2020-02-20 16:43:02 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:43:02 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:43:02 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:43:02 --> Model Class Initialized
DEBUG - 2020-02-20 16:43:02 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:43:02 --> Model Class Initialized
DEBUG - 2020-02-20 16:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:43:03 --> Final output sent to browser
DEBUG - 2020-02-20 16:43:03 --> Total execution time: 1.3979
INFO - 2020-02-20 16:45:40 --> Config Class Initialized
INFO - 2020-02-20 16:45:40 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:45:40 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:45:40 --> Utf8 Class Initialized
INFO - 2020-02-20 16:45:40 --> URI Class Initialized
INFO - 2020-02-20 16:45:40 --> Router Class Initialized
INFO - 2020-02-20 16:45:40 --> Output Class Initialized
INFO - 2020-02-20 16:45:40 --> Security Class Initialized
DEBUG - 2020-02-20 16:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:45:40 --> CSRF cookie sent
INFO - 2020-02-20 16:45:40 --> Input Class Initialized
INFO - 2020-02-20 16:45:40 --> Language Class Initialized
INFO - 2020-02-20 16:45:40 --> Language Class Initialized
INFO - 2020-02-20 16:45:40 --> Config Class Initialized
INFO - 2020-02-20 16:45:40 --> Loader Class Initialized
INFO - 2020-02-20 16:45:40 --> Helper loaded: url_helper
INFO - 2020-02-20 16:45:40 --> Helper loaded: common_helper
INFO - 2020-02-20 16:45:40 --> Helper loaded: language_helper
INFO - 2020-02-20 16:45:41 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:45:41 --> Helper loaded: email_helper
INFO - 2020-02-20 16:45:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:45:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:45:41 --> Parser Class Initialized
INFO - 2020-02-20 16:45:41 --> User Agent Class Initialized
INFO - 2020-02-20 16:45:41 --> Model Class Initialized
INFO - 2020-02-20 16:45:41 --> Database Driver Class Initialized
INFO - 2020-02-20 16:45:41 --> Model Class Initialized
DEBUG - 2020-02-20 16:45:41 --> Template Class Initialized
INFO - 2020-02-20 16:45:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:45:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:45:41 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:45:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:45:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:45:41 --> Encryption Class Initialized
INFO - 2020-02-20 16:45:41 --> Controller Class Initialized
DEBUG - 2020-02-20 16:45:41 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:45:41 --> Model Class Initialized
ERROR - 2020-02-20 16:45:41 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:45:41 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:45:41 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:45:41 --> Model Class Initialized
DEBUG - 2020-02-20 16:45:41 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:45:41 --> Model Class Initialized
DEBUG - 2020-02-20 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:45:41 --> Final output sent to browser
DEBUG - 2020-02-20 16:45:41 --> Total execution time: 1.0143
INFO - 2020-02-20 16:45:47 --> Config Class Initialized
INFO - 2020-02-20 16:45:47 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:45:47 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:45:47 --> Utf8 Class Initialized
INFO - 2020-02-20 16:45:47 --> URI Class Initialized
INFO - 2020-02-20 16:45:47 --> Router Class Initialized
INFO - 2020-02-20 16:45:47 --> Output Class Initialized
INFO - 2020-02-20 16:45:47 --> Security Class Initialized
DEBUG - 2020-02-20 16:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:45:47 --> CSRF cookie sent
INFO - 2020-02-20 16:45:47 --> CSRF token verified
INFO - 2020-02-20 16:45:47 --> Input Class Initialized
INFO - 2020-02-20 16:45:47 --> Language Class Initialized
INFO - 2020-02-20 16:45:47 --> Language Class Initialized
INFO - 2020-02-20 16:45:47 --> Config Class Initialized
INFO - 2020-02-20 16:45:47 --> Loader Class Initialized
INFO - 2020-02-20 16:45:47 --> Helper loaded: url_helper
INFO - 2020-02-20 16:45:47 --> Helper loaded: common_helper
INFO - 2020-02-20 16:45:47 --> Helper loaded: language_helper
INFO - 2020-02-20 16:45:47 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:45:47 --> Helper loaded: email_helper
INFO - 2020-02-20 16:45:47 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:45:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:45:47 --> Parser Class Initialized
INFO - 2020-02-20 16:45:47 --> User Agent Class Initialized
INFO - 2020-02-20 16:45:47 --> Model Class Initialized
INFO - 2020-02-20 16:45:47 --> Database Driver Class Initialized
INFO - 2020-02-20 16:45:47 --> Model Class Initialized
DEBUG - 2020-02-20 16:45:47 --> Template Class Initialized
INFO - 2020-02-20 16:45:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:45:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:45:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:45:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:45:48 --> Encryption Class Initialized
INFO - 2020-02-20 16:45:48 --> Controller Class Initialized
DEBUG - 2020-02-20 16:45:48 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:45:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:45:48 --> Model Class Initialized
ERROR - 2020-02-20 16:45:48 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:45:52 --> Config Class Initialized
INFO - 2020-02-20 16:45:52 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:45:52 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:45:52 --> Utf8 Class Initialized
INFO - 2020-02-20 16:45:52 --> URI Class Initialized
INFO - 2020-02-20 16:45:52 --> Router Class Initialized
INFO - 2020-02-20 16:45:52 --> Output Class Initialized
INFO - 2020-02-20 16:45:52 --> Security Class Initialized
DEBUG - 2020-02-20 16:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:45:52 --> CSRF cookie sent
INFO - 2020-02-20 16:45:52 --> Input Class Initialized
INFO - 2020-02-20 16:45:52 --> Language Class Initialized
INFO - 2020-02-20 16:45:52 --> Language Class Initialized
INFO - 2020-02-20 16:45:52 --> Config Class Initialized
INFO - 2020-02-20 16:45:52 --> Loader Class Initialized
INFO - 2020-02-20 16:45:52 --> Helper loaded: url_helper
INFO - 2020-02-20 16:45:53 --> Helper loaded: common_helper
INFO - 2020-02-20 16:45:53 --> Helper loaded: language_helper
INFO - 2020-02-20 16:45:53 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:45:53 --> Helper loaded: email_helper
INFO - 2020-02-20 16:45:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:45:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:45:53 --> Parser Class Initialized
INFO - 2020-02-20 16:45:53 --> User Agent Class Initialized
INFO - 2020-02-20 16:45:53 --> Model Class Initialized
INFO - 2020-02-20 16:45:53 --> Database Driver Class Initialized
INFO - 2020-02-20 16:45:53 --> Model Class Initialized
DEBUG - 2020-02-20 16:45:53 --> Template Class Initialized
INFO - 2020-02-20 16:45:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:45:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:45:53 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:45:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:45:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:45:53 --> Encryption Class Initialized
INFO - 2020-02-20 16:45:53 --> Controller Class Initialized
DEBUG - 2020-02-20 16:45:53 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:45:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:45:53 --> Model Class Initialized
ERROR - 2020-02-20 16:45:53 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:45:53 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:45:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:45:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:45:53 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:45:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:45:53 --> Model Class Initialized
DEBUG - 2020-02-20 16:45:53 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:45:53 --> Model Class Initialized
DEBUG - 2020-02-20 16:45:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:45:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:45:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:45:53 --> Final output sent to browser
DEBUG - 2020-02-20 16:45:53 --> Total execution time: 0.9956
INFO - 2020-02-20 16:53:11 --> Config Class Initialized
INFO - 2020-02-20 16:53:11 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:53:11 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:53:11 --> Utf8 Class Initialized
INFO - 2020-02-20 16:53:11 --> URI Class Initialized
INFO - 2020-02-20 16:53:11 --> Router Class Initialized
INFO - 2020-02-20 16:53:11 --> Output Class Initialized
INFO - 2020-02-20 16:53:11 --> Security Class Initialized
DEBUG - 2020-02-20 16:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:53:11 --> CSRF cookie sent
INFO - 2020-02-20 16:53:11 --> Input Class Initialized
INFO - 2020-02-20 16:53:11 --> Language Class Initialized
INFO - 2020-02-20 16:53:11 --> Language Class Initialized
INFO - 2020-02-20 16:53:11 --> Config Class Initialized
INFO - 2020-02-20 16:53:11 --> Loader Class Initialized
INFO - 2020-02-20 16:53:11 --> Helper loaded: url_helper
INFO - 2020-02-20 16:53:11 --> Helper loaded: common_helper
INFO - 2020-02-20 16:53:12 --> Helper loaded: language_helper
INFO - 2020-02-20 16:53:12 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:53:12 --> Helper loaded: email_helper
INFO - 2020-02-20 16:53:12 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:53:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:53:12 --> Parser Class Initialized
INFO - 2020-02-20 16:53:12 --> User Agent Class Initialized
INFO - 2020-02-20 16:53:12 --> Model Class Initialized
INFO - 2020-02-20 16:53:12 --> Database Driver Class Initialized
INFO - 2020-02-20 16:53:12 --> Model Class Initialized
DEBUG - 2020-02-20 16:53:12 --> Template Class Initialized
INFO - 2020-02-20 16:53:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:53:12 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:53:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:53:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:53:12 --> Encryption Class Initialized
INFO - 2020-02-20 16:53:12 --> Controller Class Initialized
DEBUG - 2020-02-20 16:53:12 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:53:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:53:12 --> Model Class Initialized
ERROR - 2020-02-20 16:53:12 --> Could not find the language line "Sorting"
ERROR - 2020-02-20 16:53:12 --> Query error: Unknown column 'is_parent' in 'where clause' - Invalid query: SELECT *
FROM `categories`
WHERE `id` = '13'
AND `is_parent` = 1
INFO - 2020-02-20 16:53:12 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-20 16:54:31 --> Config Class Initialized
INFO - 2020-02-20 16:54:31 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:54:31 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:54:31 --> Utf8 Class Initialized
INFO - 2020-02-20 16:54:31 --> URI Class Initialized
INFO - 2020-02-20 16:54:31 --> Router Class Initialized
INFO - 2020-02-20 16:54:31 --> Output Class Initialized
INFO - 2020-02-20 16:54:31 --> Security Class Initialized
DEBUG - 2020-02-20 16:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:54:31 --> CSRF cookie sent
INFO - 2020-02-20 16:54:32 --> Input Class Initialized
INFO - 2020-02-20 16:54:32 --> Language Class Initialized
INFO - 2020-02-20 16:54:32 --> Language Class Initialized
INFO - 2020-02-20 16:54:32 --> Config Class Initialized
INFO - 2020-02-20 16:54:32 --> Loader Class Initialized
INFO - 2020-02-20 16:54:32 --> Helper loaded: url_helper
INFO - 2020-02-20 16:54:32 --> Helper loaded: common_helper
INFO - 2020-02-20 16:54:32 --> Helper loaded: language_helper
INFO - 2020-02-20 16:54:32 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:54:32 --> Helper loaded: email_helper
INFO - 2020-02-20 16:54:32 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:54:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:54:32 --> Parser Class Initialized
INFO - 2020-02-20 16:54:32 --> User Agent Class Initialized
INFO - 2020-02-20 16:54:32 --> Model Class Initialized
INFO - 2020-02-20 16:54:32 --> Database Driver Class Initialized
INFO - 2020-02-20 16:54:32 --> Model Class Initialized
DEBUG - 2020-02-20 16:54:32 --> Template Class Initialized
INFO - 2020-02-20 16:54:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:54:32 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:54:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:54:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:54:32 --> Encryption Class Initialized
INFO - 2020-02-20 16:54:32 --> Controller Class Initialized
DEBUG - 2020-02-20 16:54:32 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:54:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:54:32 --> Model Class Initialized
ERROR - 2020-02-20 16:54:32 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:54:32 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:54:32 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 43
INFO - 2020-02-20 16:54:58 --> Config Class Initialized
INFO - 2020-02-20 16:54:58 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:54:58 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:54:58 --> Utf8 Class Initialized
INFO - 2020-02-20 16:54:58 --> URI Class Initialized
INFO - 2020-02-20 16:54:58 --> Router Class Initialized
INFO - 2020-02-20 16:54:58 --> Output Class Initialized
INFO - 2020-02-20 16:54:58 --> Security Class Initialized
DEBUG - 2020-02-20 16:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:54:58 --> CSRF cookie sent
INFO - 2020-02-20 16:54:58 --> Input Class Initialized
INFO - 2020-02-20 16:54:58 --> Language Class Initialized
INFO - 2020-02-20 16:54:58 --> Language Class Initialized
INFO - 2020-02-20 16:54:58 --> Config Class Initialized
INFO - 2020-02-20 16:54:58 --> Loader Class Initialized
INFO - 2020-02-20 16:54:58 --> Helper loaded: url_helper
INFO - 2020-02-20 16:54:58 --> Helper loaded: common_helper
INFO - 2020-02-20 16:54:58 --> Helper loaded: language_helper
INFO - 2020-02-20 16:54:58 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:54:58 --> Helper loaded: email_helper
INFO - 2020-02-20 16:54:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:54:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:54:58 --> Parser Class Initialized
INFO - 2020-02-20 16:54:58 --> User Agent Class Initialized
INFO - 2020-02-20 16:54:58 --> Model Class Initialized
INFO - 2020-02-20 16:54:58 --> Database Driver Class Initialized
INFO - 2020-02-20 16:54:58 --> Model Class Initialized
DEBUG - 2020-02-20 16:54:58 --> Template Class Initialized
INFO - 2020-02-20 16:54:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:54:58 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:54:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:54:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:54:59 --> Encryption Class Initialized
INFO - 2020-02-20 16:54:59 --> Controller Class Initialized
DEBUG - 2020-02-20 16:54:59 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:54:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:54:59 --> Model Class Initialized
ERROR - 2020-02-20 16:54:59 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:54:59 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:54:59 --> Severity: error --> Exception: syntax error, unexpected ')', expecting end of file D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 43
INFO - 2020-02-20 16:55:09 --> Config Class Initialized
INFO - 2020-02-20 16:55:09 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:55:09 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:55:10 --> Utf8 Class Initialized
INFO - 2020-02-20 16:55:10 --> URI Class Initialized
INFO - 2020-02-20 16:55:10 --> Router Class Initialized
INFO - 2020-02-20 16:55:10 --> Output Class Initialized
INFO - 2020-02-20 16:55:10 --> Security Class Initialized
DEBUG - 2020-02-20 16:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:55:10 --> CSRF cookie sent
INFO - 2020-02-20 16:55:10 --> Input Class Initialized
INFO - 2020-02-20 16:55:10 --> Language Class Initialized
INFO - 2020-02-20 16:55:10 --> Language Class Initialized
INFO - 2020-02-20 16:55:10 --> Config Class Initialized
INFO - 2020-02-20 16:55:10 --> Loader Class Initialized
INFO - 2020-02-20 16:55:10 --> Helper loaded: url_helper
INFO - 2020-02-20 16:55:10 --> Helper loaded: common_helper
INFO - 2020-02-20 16:55:10 --> Helper loaded: language_helper
INFO - 2020-02-20 16:55:10 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:55:10 --> Helper loaded: email_helper
INFO - 2020-02-20 16:55:10 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:55:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:55:10 --> Parser Class Initialized
INFO - 2020-02-20 16:55:10 --> User Agent Class Initialized
INFO - 2020-02-20 16:55:10 --> Model Class Initialized
INFO - 2020-02-20 16:55:10 --> Database Driver Class Initialized
INFO - 2020-02-20 16:55:10 --> Model Class Initialized
DEBUG - 2020-02-20 16:55:10 --> Template Class Initialized
INFO - 2020-02-20 16:55:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:55:10 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:55:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:55:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:55:10 --> Encryption Class Initialized
INFO - 2020-02-20 16:55:10 --> Controller Class Initialized
DEBUG - 2020-02-20 16:55:10 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:55:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:55:10 --> Model Class Initialized
ERROR - 2020-02-20 16:55:10 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:55:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:55:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:55:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:55:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:55:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:55:10 --> Model Class Initialized
DEBUG - 2020-02-20 16:55:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:55:10 --> Model Class Initialized
DEBUG - 2020-02-20 16:55:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:55:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:55:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:55:10 --> Final output sent to browser
DEBUG - 2020-02-20 16:55:10 --> Total execution time: 1.0191
INFO - 2020-02-20 16:55:22 --> Config Class Initialized
INFO - 2020-02-20 16:55:22 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:55:22 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:55:22 --> Utf8 Class Initialized
INFO - 2020-02-20 16:55:22 --> URI Class Initialized
INFO - 2020-02-20 16:55:22 --> Router Class Initialized
INFO - 2020-02-20 16:55:22 --> Output Class Initialized
INFO - 2020-02-20 16:55:22 --> Security Class Initialized
DEBUG - 2020-02-20 16:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:55:22 --> CSRF cookie sent
INFO - 2020-02-20 16:55:22 --> Input Class Initialized
INFO - 2020-02-20 16:55:22 --> Language Class Initialized
INFO - 2020-02-20 16:55:22 --> Language Class Initialized
INFO - 2020-02-20 16:55:22 --> Config Class Initialized
INFO - 2020-02-20 16:55:22 --> Loader Class Initialized
INFO - 2020-02-20 16:55:22 --> Helper loaded: url_helper
INFO - 2020-02-20 16:55:22 --> Helper loaded: common_helper
INFO - 2020-02-20 16:55:22 --> Helper loaded: language_helper
INFO - 2020-02-20 16:55:22 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:55:22 --> Helper loaded: email_helper
INFO - 2020-02-20 16:55:22 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:55:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:55:22 --> Parser Class Initialized
INFO - 2020-02-20 16:55:22 --> User Agent Class Initialized
INFO - 2020-02-20 16:55:23 --> Model Class Initialized
INFO - 2020-02-20 16:55:23 --> Database Driver Class Initialized
INFO - 2020-02-20 16:55:23 --> Model Class Initialized
DEBUG - 2020-02-20 16:55:23 --> Template Class Initialized
INFO - 2020-02-20 16:55:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:55:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:55:23 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:55:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:55:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:55:23 --> Encryption Class Initialized
INFO - 2020-02-20 16:55:23 --> Controller Class Initialized
DEBUG - 2020-02-20 16:55:23 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:55:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:55:23 --> Model Class Initialized
ERROR - 2020-02-20 16:55:23 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:55:23 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:55:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:55:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:55:23 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:55:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:55:23 --> Model Class Initialized
DEBUG - 2020-02-20 16:55:23 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:55:23 --> Model Class Initialized
DEBUG - 2020-02-20 16:55:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:55:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:55:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:55:23 --> Final output sent to browser
DEBUG - 2020-02-20 16:55:23 --> Total execution time: 0.9915
INFO - 2020-02-20 16:55:26 --> Config Class Initialized
INFO - 2020-02-20 16:55:26 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:55:26 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:55:26 --> Utf8 Class Initialized
INFO - 2020-02-20 16:55:26 --> URI Class Initialized
INFO - 2020-02-20 16:55:26 --> Router Class Initialized
INFO - 2020-02-20 16:55:26 --> Output Class Initialized
INFO - 2020-02-20 16:55:26 --> Security Class Initialized
DEBUG - 2020-02-20 16:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:55:26 --> CSRF cookie sent
INFO - 2020-02-20 16:55:26 --> Input Class Initialized
INFO - 2020-02-20 16:55:26 --> Language Class Initialized
INFO - 2020-02-20 16:55:26 --> Language Class Initialized
INFO - 2020-02-20 16:55:26 --> Config Class Initialized
INFO - 2020-02-20 16:55:26 --> Loader Class Initialized
INFO - 2020-02-20 16:55:26 --> Helper loaded: url_helper
INFO - 2020-02-20 16:55:26 --> Helper loaded: common_helper
INFO - 2020-02-20 16:55:26 --> Helper loaded: language_helper
INFO - 2020-02-20 16:55:26 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:55:26 --> Helper loaded: email_helper
INFO - 2020-02-20 16:55:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:55:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:55:26 --> Parser Class Initialized
INFO - 2020-02-20 16:55:26 --> User Agent Class Initialized
INFO - 2020-02-20 16:55:26 --> Model Class Initialized
INFO - 2020-02-20 16:55:26 --> Database Driver Class Initialized
INFO - 2020-02-20 16:55:26 --> Model Class Initialized
DEBUG - 2020-02-20 16:55:26 --> Template Class Initialized
INFO - 2020-02-20 16:55:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:55:26 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:55:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:55:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:55:26 --> Encryption Class Initialized
INFO - 2020-02-20 16:55:26 --> Controller Class Initialized
DEBUG - 2020-02-20 16:55:26 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:55:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:55:26 --> Model Class Initialized
ERROR - 2020-02-20 16:55:26 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:55:26 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:55:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:55:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:55:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:55:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:55:26 --> Model Class Initialized
DEBUG - 2020-02-20 16:55:26 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:55:26 --> Model Class Initialized
DEBUG - 2020-02-20 16:55:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:55:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:55:27 --> Final output sent to browser
DEBUG - 2020-02-20 16:55:27 --> Total execution time: 0.9582
INFO - 2020-02-20 16:55:59 --> Config Class Initialized
INFO - 2020-02-20 16:55:59 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:55:59 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:55:59 --> Utf8 Class Initialized
INFO - 2020-02-20 16:55:59 --> URI Class Initialized
INFO - 2020-02-20 16:55:59 --> Router Class Initialized
INFO - 2020-02-20 16:55:59 --> Output Class Initialized
INFO - 2020-02-20 16:55:59 --> Security Class Initialized
DEBUG - 2020-02-20 16:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:55:59 --> CSRF cookie sent
INFO - 2020-02-20 16:55:59 --> Input Class Initialized
INFO - 2020-02-20 16:55:59 --> Language Class Initialized
INFO - 2020-02-20 16:55:59 --> Language Class Initialized
INFO - 2020-02-20 16:55:59 --> Config Class Initialized
INFO - 2020-02-20 16:55:59 --> Loader Class Initialized
INFO - 2020-02-20 16:55:59 --> Helper loaded: url_helper
INFO - 2020-02-20 16:55:59 --> Helper loaded: common_helper
INFO - 2020-02-20 16:55:59 --> Helper loaded: language_helper
INFO - 2020-02-20 16:55:59 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:55:59 --> Helper loaded: email_helper
INFO - 2020-02-20 16:55:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:55:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:56:00 --> Parser Class Initialized
INFO - 2020-02-20 16:56:00 --> User Agent Class Initialized
INFO - 2020-02-20 16:56:00 --> Model Class Initialized
INFO - 2020-02-20 16:56:00 --> Database Driver Class Initialized
INFO - 2020-02-20 16:56:00 --> Model Class Initialized
DEBUG - 2020-02-20 16:56:00 --> Template Class Initialized
INFO - 2020-02-20 16:56:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:56:00 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:56:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:56:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:56:00 --> Encryption Class Initialized
INFO - 2020-02-20 16:56:00 --> Controller Class Initialized
DEBUG - 2020-02-20 16:56:00 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:56:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:56:00 --> Model Class Initialized
ERROR - 2020-02-20 16:56:00 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:56:00 --> Helper loaded: inflector_helper
ERROR - 2020-02-20 16:56:00 --> Severity: Notice --> Undefined variable: get D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
ERROR - 2020-02-20 16:56:00 --> Severity: error --> Exception: Function name must be a string D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 32
INFO - 2020-02-20 16:56:27 --> Config Class Initialized
INFO - 2020-02-20 16:56:27 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:56:27 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:56:27 --> Utf8 Class Initialized
INFO - 2020-02-20 16:56:27 --> URI Class Initialized
INFO - 2020-02-20 16:56:27 --> Router Class Initialized
INFO - 2020-02-20 16:56:27 --> Output Class Initialized
INFO - 2020-02-20 16:56:27 --> Security Class Initialized
DEBUG - 2020-02-20 16:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:56:27 --> CSRF cookie sent
INFO - 2020-02-20 16:56:27 --> Input Class Initialized
INFO - 2020-02-20 16:56:27 --> Language Class Initialized
INFO - 2020-02-20 16:56:27 --> Language Class Initialized
INFO - 2020-02-20 16:56:27 --> Config Class Initialized
INFO - 2020-02-20 16:56:27 --> Loader Class Initialized
INFO - 2020-02-20 16:56:27 --> Helper loaded: url_helper
INFO - 2020-02-20 16:56:27 --> Helper loaded: common_helper
INFO - 2020-02-20 16:56:27 --> Helper loaded: language_helper
INFO - 2020-02-20 16:56:27 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:56:27 --> Helper loaded: email_helper
INFO - 2020-02-20 16:56:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:56:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:56:27 --> Parser Class Initialized
INFO - 2020-02-20 16:56:27 --> User Agent Class Initialized
INFO - 2020-02-20 16:56:27 --> Model Class Initialized
INFO - 2020-02-20 16:56:27 --> Database Driver Class Initialized
INFO - 2020-02-20 16:56:27 --> Model Class Initialized
DEBUG - 2020-02-20 16:56:27 --> Template Class Initialized
INFO - 2020-02-20 16:56:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:56:27 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:56:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:56:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:56:27 --> Encryption Class Initialized
INFO - 2020-02-20 16:56:27 --> Controller Class Initialized
DEBUG - 2020-02-20 16:56:27 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:56:27 --> Model Class Initialized
ERROR - 2020-02-20 16:56:27 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:56:27 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:56:27 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:56:27 --> Model Class Initialized
DEBUG - 2020-02-20 16:56:27 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:56:27 --> Model Class Initialized
DEBUG - 2020-02-20 16:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:56:28 --> Final output sent to browser
DEBUG - 2020-02-20 16:56:28 --> Total execution time: 0.9946
INFO - 2020-02-20 16:56:34 --> Config Class Initialized
INFO - 2020-02-20 16:56:34 --> Hooks Class Initialized
DEBUG - 2020-02-20 16:56:34 --> UTF-8 Support Enabled
INFO - 2020-02-20 16:56:34 --> Utf8 Class Initialized
INFO - 2020-02-20 16:56:34 --> URI Class Initialized
INFO - 2020-02-20 16:56:34 --> Router Class Initialized
INFO - 2020-02-20 16:56:34 --> Output Class Initialized
INFO - 2020-02-20 16:56:34 --> Security Class Initialized
DEBUG - 2020-02-20 16:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 16:56:34 --> CSRF cookie sent
INFO - 2020-02-20 16:56:34 --> Input Class Initialized
INFO - 2020-02-20 16:56:34 --> Language Class Initialized
INFO - 2020-02-20 16:56:34 --> Language Class Initialized
INFO - 2020-02-20 16:56:34 --> Config Class Initialized
INFO - 2020-02-20 16:56:34 --> Loader Class Initialized
INFO - 2020-02-20 16:56:34 --> Helper loaded: url_helper
INFO - 2020-02-20 16:56:34 --> Helper loaded: common_helper
INFO - 2020-02-20 16:56:34 --> Helper loaded: language_helper
INFO - 2020-02-20 16:56:34 --> Helper loaded: cookie_helper
INFO - 2020-02-20 16:56:34 --> Helper loaded: email_helper
INFO - 2020-02-20 16:56:34 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 16:56:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 16:56:34 --> Parser Class Initialized
INFO - 2020-02-20 16:56:34 --> User Agent Class Initialized
INFO - 2020-02-20 16:56:34 --> Model Class Initialized
INFO - 2020-02-20 16:56:34 --> Database Driver Class Initialized
INFO - 2020-02-20 16:56:34 --> Model Class Initialized
DEBUG - 2020-02-20 16:56:34 --> Template Class Initialized
INFO - 2020-02-20 16:56:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 16:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 16:56:34 --> Pagination Class Initialized
DEBUG - 2020-02-20 16:56:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 16:56:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 16:56:35 --> Encryption Class Initialized
INFO - 2020-02-20 16:56:35 --> Controller Class Initialized
DEBUG - 2020-02-20 16:56:35 --> category MX_Controller Initialized
DEBUG - 2020-02-20 16:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:56:35 --> Model Class Initialized
ERROR - 2020-02-20 16:56:35 --> Could not find the language line "Sorting"
INFO - 2020-02-20 16:56:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 16:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 16:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 16:56:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 16:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 16:56:35 --> Model Class Initialized
DEBUG - 2020-02-20 16:56:35 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 16:56:35 --> Model Class Initialized
DEBUG - 2020-02-20 16:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 16:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 16:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 16:56:35 --> Final output sent to browser
DEBUG - 2020-02-20 16:56:35 --> Total execution time: 0.9930
INFO - 2020-02-20 18:15:46 --> Config Class Initialized
INFO - 2020-02-20 18:15:46 --> Hooks Class Initialized
DEBUG - 2020-02-20 18:15:46 --> UTF-8 Support Enabled
INFO - 2020-02-20 18:15:46 --> Utf8 Class Initialized
INFO - 2020-02-20 18:15:46 --> URI Class Initialized
INFO - 2020-02-20 18:15:46 --> Router Class Initialized
INFO - 2020-02-20 18:15:46 --> Output Class Initialized
INFO - 2020-02-20 18:15:46 --> Security Class Initialized
DEBUG - 2020-02-20 18:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-20 18:15:46 --> CSRF cookie sent
INFO - 2020-02-20 18:15:46 --> Input Class Initialized
INFO - 2020-02-20 18:15:46 --> Language Class Initialized
INFO - 2020-02-20 18:15:46 --> Language Class Initialized
INFO - 2020-02-20 18:15:46 --> Config Class Initialized
INFO - 2020-02-20 18:15:46 --> Loader Class Initialized
INFO - 2020-02-20 18:15:46 --> Helper loaded: url_helper
INFO - 2020-02-20 18:15:46 --> Helper loaded: common_helper
INFO - 2020-02-20 18:15:46 --> Helper loaded: language_helper
INFO - 2020-02-20 18:15:46 --> Helper loaded: cookie_helper
INFO - 2020-02-20 18:15:46 --> Helper loaded: email_helper
INFO - 2020-02-20 18:15:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-20 18:15:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-20 18:15:46 --> Parser Class Initialized
INFO - 2020-02-20 18:15:46 --> User Agent Class Initialized
INFO - 2020-02-20 18:15:46 --> Model Class Initialized
INFO - 2020-02-20 18:15:46 --> Database Driver Class Initialized
INFO - 2020-02-20 18:15:46 --> Model Class Initialized
DEBUG - 2020-02-20 18:15:46 --> Template Class Initialized
INFO - 2020-02-20 18:15:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-20 18:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-20 18:15:47 --> Pagination Class Initialized
DEBUG - 2020-02-20 18:15:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-20 18:15:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-20 18:15:47 --> Encryption Class Initialized
INFO - 2020-02-20 18:15:47 --> Controller Class Initialized
DEBUG - 2020-02-20 18:15:47 --> category MX_Controller Initialized
DEBUG - 2020-02-20 18:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 18:15:47 --> Model Class Initialized
ERROR - 2020-02-20 18:15:47 --> Could not find the language line "Sorting"
INFO - 2020-02-20 18:15:47 --> Helper loaded: inflector_helper
DEBUG - 2020-02-20 18:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-20 18:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-20 18:15:47 --> blocks MX_Controller Initialized
DEBUG - 2020-02-20 18:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-20 18:15:47 --> Model Class Initialized
DEBUG - 2020-02-20 18:15:47 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-20 18:15:47 --> Model Class Initialized
DEBUG - 2020-02-20 18:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-20 18:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-20 18:15:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-20 18:15:47 --> Final output sent to browser
DEBUG - 2020-02-20 18:15:47 --> Total execution time: 1.1007
