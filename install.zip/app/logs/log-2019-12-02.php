<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-02 16:08:26 --> Config Class Initialized
INFO - 2019-12-02 16:08:26 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:08:26 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:08:26 --> Utf8 Class Initialized
INFO - 2019-12-02 16:08:26 --> URI Class Initialized
DEBUG - 2019-12-02 16:08:27 --> No URI present. Default controller set.
INFO - 2019-12-02 16:08:27 --> Router Class Initialized
INFO - 2019-12-02 16:08:27 --> Output Class Initialized
INFO - 2019-12-02 16:08:27 --> Security Class Initialized
DEBUG - 2019-12-02 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:08:27 --> CSRF cookie sent
INFO - 2019-12-02 16:08:27 --> Input Class Initialized
INFO - 2019-12-02 16:08:27 --> Language Class Initialized
INFO - 2019-12-02 16:08:27 --> Language Class Initialized
INFO - 2019-12-02 16:08:27 --> Config Class Initialized
INFO - 2019-12-02 16:08:27 --> Loader Class Initialized
INFO - 2019-12-02 16:08:27 --> Helper loaded: url_helper
INFO - 2019-12-02 16:08:27 --> Helper loaded: common_helper
INFO - 2019-12-02 16:08:27 --> Helper loaded: language_helper
INFO - 2019-12-02 16:08:27 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:08:27 --> Helper loaded: email_helper
INFO - 2019-12-02 16:08:27 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:08:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:08:27 --> Parser Class Initialized
INFO - 2019-12-02 16:08:27 --> User Agent Class Initialized
INFO - 2019-12-02 16:08:27 --> Model Class Initialized
INFO - 2019-12-02 16:08:27 --> Database Driver Class Initialized
INFO - 2019-12-02 16:08:27 --> Model Class Initialized
DEBUG - 2019-12-02 16:08:27 --> Template Class Initialized
INFO - 2019-12-02 16:08:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:08:28 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:08:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:08:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:08:28 --> Encryption Class Initialized
DEBUG - 2019-12-02 16:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-02 16:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-02 16:08:28 --> Controller Class Initialized
DEBUG - 2019-12-02 16:08:28 --> pergo MX_Controller Initialized
DEBUG - 2019-12-02 16:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-02 16:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-02 16:08:28 --> Model Class Initialized
INFO - 2019-12-02 16:08:28 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-02 16:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-02 16:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-02 16:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-02 16:08:28 --> Final output sent to browser
DEBUG - 2019-12-02 16:08:28 --> Total execution time: 1.9659
INFO - 2019-12-02 16:08:37 --> Config Class Initialized
INFO - 2019-12-02 16:08:37 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:08:37 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:08:37 --> Utf8 Class Initialized
INFO - 2019-12-02 16:08:37 --> URI Class Initialized
INFO - 2019-12-02 16:08:37 --> Router Class Initialized
INFO - 2019-12-02 16:08:37 --> Output Class Initialized
INFO - 2019-12-02 16:08:37 --> Security Class Initialized
DEBUG - 2019-12-02 16:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:08:37 --> CSRF cookie sent
INFO - 2019-12-02 16:08:37 --> Input Class Initialized
INFO - 2019-12-02 16:08:37 --> Language Class Initialized
INFO - 2019-12-02 16:08:37 --> Language Class Initialized
INFO - 2019-12-02 16:08:37 --> Config Class Initialized
INFO - 2019-12-02 16:08:37 --> Loader Class Initialized
INFO - 2019-12-02 16:08:37 --> Helper loaded: url_helper
INFO - 2019-12-02 16:08:37 --> Helper loaded: common_helper
INFO - 2019-12-02 16:08:37 --> Helper loaded: language_helper
INFO - 2019-12-02 16:08:37 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:08:37 --> Helper loaded: email_helper
INFO - 2019-12-02 16:08:37 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:08:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:08:37 --> Parser Class Initialized
INFO - 2019-12-02 16:08:37 --> User Agent Class Initialized
INFO - 2019-12-02 16:08:37 --> Model Class Initialized
INFO - 2019-12-02 16:08:37 --> Database Driver Class Initialized
INFO - 2019-12-02 16:08:37 --> Model Class Initialized
DEBUG - 2019-12-02 16:08:37 --> Template Class Initialized
INFO - 2019-12-02 16:08:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:08:37 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:08:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:08:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:08:37 --> Encryption Class Initialized
INFO - 2019-12-02 16:08:37 --> Controller Class Initialized
DEBUG - 2019-12-02 16:08:37 --> auth MX_Controller Initialized
DEBUG - 2019-12-02 16:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-02 16:08:38 --> Model Class Initialized
DEBUG - 2019-12-02 16:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-02 16:08:38 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-12-02 16:08:38 --> pergo MX_Controller Initialized
DEBUG - 2019-12-02 16:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-02 16:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-12-02 16:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-02 16:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-02 16:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-12-02 16:08:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-02 16:08:38 --> Final output sent to browser
DEBUG - 2019-12-02 16:08:38 --> Total execution time: 0.5385
INFO - 2019-12-02 16:08:39 --> Config Class Initialized
INFO - 2019-12-02 16:08:39 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:08:39 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:08:39 --> Utf8 Class Initialized
INFO - 2019-12-02 16:08:39 --> URI Class Initialized
INFO - 2019-12-02 16:08:39 --> Router Class Initialized
INFO - 2019-12-02 16:08:39 --> Output Class Initialized
INFO - 2019-12-02 16:08:39 --> Security Class Initialized
DEBUG - 2019-12-02 16:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:08:39 --> CSRF cookie sent
INFO - 2019-12-02 16:08:45 --> Config Class Initialized
INFO - 2019-12-02 16:08:45 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:08:45 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:08:45 --> Utf8 Class Initialized
INFO - 2019-12-02 16:08:45 --> URI Class Initialized
INFO - 2019-12-02 16:08:45 --> Router Class Initialized
INFO - 2019-12-02 16:08:45 --> Output Class Initialized
INFO - 2019-12-02 16:08:45 --> Security Class Initialized
DEBUG - 2019-12-02 16:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:08:45 --> CSRF cookie sent
INFO - 2019-12-02 16:08:45 --> CSRF token verified
INFO - 2019-12-02 16:08:45 --> Input Class Initialized
INFO - 2019-12-02 16:08:45 --> Language Class Initialized
INFO - 2019-12-02 16:08:45 --> Language Class Initialized
INFO - 2019-12-02 16:08:45 --> Config Class Initialized
INFO - 2019-12-02 16:08:45 --> Loader Class Initialized
INFO - 2019-12-02 16:08:45 --> Helper loaded: url_helper
INFO - 2019-12-02 16:08:45 --> Helper loaded: common_helper
INFO - 2019-12-02 16:08:45 --> Helper loaded: language_helper
INFO - 2019-12-02 16:08:45 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:08:45 --> Helper loaded: email_helper
INFO - 2019-12-02 16:08:45 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:08:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:08:45 --> Parser Class Initialized
INFO - 2019-12-02 16:08:45 --> User Agent Class Initialized
INFO - 2019-12-02 16:08:45 --> Model Class Initialized
INFO - 2019-12-02 16:08:45 --> Database Driver Class Initialized
INFO - 2019-12-02 16:08:45 --> Model Class Initialized
DEBUG - 2019-12-02 16:08:45 --> Template Class Initialized
INFO - 2019-12-02 16:08:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:08:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:08:45 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:08:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:08:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:08:45 --> Encryption Class Initialized
INFO - 2019-12-02 16:08:45 --> Controller Class Initialized
DEBUG - 2019-12-02 16:08:45 --> auth MX_Controller Initialized
DEBUG - 2019-12-02 16:08:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-02 16:08:45 --> Model Class Initialized
INFO - 2019-12-02 16:08:50 --> Config Class Initialized
INFO - 2019-12-02 16:08:50 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:08:50 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:08:50 --> Utf8 Class Initialized
INFO - 2019-12-02 16:08:50 --> URI Class Initialized
INFO - 2019-12-02 16:08:50 --> Router Class Initialized
INFO - 2019-12-02 16:08:50 --> Output Class Initialized
INFO - 2019-12-02 16:08:50 --> Security Class Initialized
DEBUG - 2019-12-02 16:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:08:50 --> CSRF cookie sent
INFO - 2019-12-02 16:08:50 --> Input Class Initialized
INFO - 2019-12-02 16:08:50 --> Language Class Initialized
INFO - 2019-12-02 16:08:50 --> Language Class Initialized
INFO - 2019-12-02 16:08:50 --> Config Class Initialized
INFO - 2019-12-02 16:08:50 --> Loader Class Initialized
INFO - 2019-12-02 16:08:50 --> Helper loaded: url_helper
INFO - 2019-12-02 16:08:50 --> Helper loaded: common_helper
INFO - 2019-12-02 16:08:50 --> Helper loaded: language_helper
INFO - 2019-12-02 16:08:50 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:08:50 --> Helper loaded: email_helper
INFO - 2019-12-02 16:08:50 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:08:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:08:50 --> Parser Class Initialized
INFO - 2019-12-02 16:08:50 --> User Agent Class Initialized
INFO - 2019-12-02 16:08:50 --> Model Class Initialized
INFO - 2019-12-02 16:08:50 --> Database Driver Class Initialized
INFO - 2019-12-02 16:08:50 --> Model Class Initialized
DEBUG - 2019-12-02 16:08:50 --> Template Class Initialized
INFO - 2019-12-02 16:08:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:08:50 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:08:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:08:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:08:50 --> Encryption Class Initialized
INFO - 2019-12-02 16:08:50 --> Controller Class Initialized
DEBUG - 2019-12-02 16:08:50 --> statistics MX_Controller Initialized
DEBUG - 2019-12-02 16:08:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-02 16:08:50 --> Model Class Initialized
ERROR - 2019-12-02 16:08:50 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:08:51 --> Could not find the language line "Pending"
INFO - 2019-12-02 16:08:51 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:08:51 --> Could not find the language line "total_orders"
ERROR - 2019-12-02 16:08:51 --> Could not find the language line "total_orders"
ERROR - 2019-12-02 16:08:51 --> Could not find the language line "Pending"
DEBUG - 2019-12-02 16:08:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-12-02 16:08:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:08:51 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:08:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:08:51 --> Model Class Initialized
DEBUG - 2019-12-02 16:08:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:08:51 --> Model Class Initialized
DEBUG - 2019-12-02 16:08:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:08:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:08:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:08:51 --> Final output sent to browser
DEBUG - 2019-12-02 16:08:51 --> Total execution time: 0.9831
INFO - 2019-12-02 16:09:29 --> Config Class Initialized
INFO - 2019-12-02 16:09:29 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:09:29 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:09:29 --> Utf8 Class Initialized
INFO - 2019-12-02 16:09:29 --> URI Class Initialized
INFO - 2019-12-02 16:09:29 --> Router Class Initialized
INFO - 2019-12-02 16:09:29 --> Output Class Initialized
INFO - 2019-12-02 16:09:29 --> Security Class Initialized
DEBUG - 2019-12-02 16:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:09:29 --> CSRF cookie sent
INFO - 2019-12-02 16:09:29 --> Input Class Initialized
INFO - 2019-12-02 16:09:29 --> Language Class Initialized
INFO - 2019-12-02 16:09:29 --> Language Class Initialized
INFO - 2019-12-02 16:09:29 --> Config Class Initialized
INFO - 2019-12-02 16:09:29 --> Loader Class Initialized
INFO - 2019-12-02 16:09:29 --> Helper loaded: url_helper
INFO - 2019-12-02 16:09:29 --> Helper loaded: common_helper
INFO - 2019-12-02 16:09:29 --> Helper loaded: language_helper
INFO - 2019-12-02 16:09:29 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:09:29 --> Helper loaded: email_helper
INFO - 2019-12-02 16:09:29 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:09:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:09:29 --> Parser Class Initialized
INFO - 2019-12-02 16:09:29 --> User Agent Class Initialized
INFO - 2019-12-02 16:09:29 --> Model Class Initialized
INFO - 2019-12-02 16:09:29 --> Database Driver Class Initialized
INFO - 2019-12-02 16:09:29 --> Model Class Initialized
DEBUG - 2019-12-02 16:09:29 --> Template Class Initialized
INFO - 2019-12-02 16:09:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:09:29 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:09:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:09:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:09:29 --> Encryption Class Initialized
INFO - 2019-12-02 16:09:29 --> Controller Class Initialized
DEBUG - 2019-12-02 16:09:29 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:09:29 --> Model Class Initialized
INFO - 2019-12-02 16:09:29 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-02 16:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-12-02 16:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-02 16:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:09:29 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:09:29 --> Model Class Initialized
DEBUG - 2019-12-02 16:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:09:29 --> Model Class Initialized
DEBUG - 2019-12-02 16:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:09:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:09:30 --> Final output sent to browser
DEBUG - 2019-12-02 16:09:30 --> Total execution time: 0.7687
INFO - 2019-12-02 16:09:33 --> Config Class Initialized
INFO - 2019-12-02 16:09:33 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:09:33 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:09:33 --> Utf8 Class Initialized
INFO - 2019-12-02 16:09:33 --> URI Class Initialized
INFO - 2019-12-02 16:09:33 --> Router Class Initialized
INFO - 2019-12-02 16:09:33 --> Output Class Initialized
INFO - 2019-12-02 16:09:33 --> Security Class Initialized
DEBUG - 2019-12-02 16:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:09:33 --> CSRF cookie sent
INFO - 2019-12-02 16:09:33 --> Input Class Initialized
INFO - 2019-12-02 16:09:33 --> Language Class Initialized
INFO - 2019-12-02 16:09:33 --> Language Class Initialized
INFO - 2019-12-02 16:09:33 --> Config Class Initialized
INFO - 2019-12-02 16:09:33 --> Loader Class Initialized
INFO - 2019-12-02 16:09:33 --> Helper loaded: url_helper
INFO - 2019-12-02 16:09:33 --> Helper loaded: common_helper
INFO - 2019-12-02 16:09:33 --> Helper loaded: language_helper
INFO - 2019-12-02 16:09:33 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:09:33 --> Helper loaded: email_helper
INFO - 2019-12-02 16:09:33 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:09:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:09:33 --> Parser Class Initialized
INFO - 2019-12-02 16:09:33 --> User Agent Class Initialized
INFO - 2019-12-02 16:09:33 --> Model Class Initialized
INFO - 2019-12-02 16:09:33 --> Database Driver Class Initialized
INFO - 2019-12-02 16:09:33 --> Model Class Initialized
DEBUG - 2019-12-02 16:09:33 --> Template Class Initialized
INFO - 2019-12-02 16:09:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:09:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:09:33 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:09:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:09:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:09:33 --> Encryption Class Initialized
INFO - 2019-12-02 16:09:33 --> Controller Class Initialized
DEBUG - 2019-12-02 16:09:33 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:09:33 --> Model Class Initialized
INFO - 2019-12-02 16:09:33 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-12-02 16:09:33 --> Could not find the language line "currency_rate"
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/hesabe.php
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:09:33 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:09:33 --> Model Class Initialized
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:09:33 --> Model Class Initialized
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:09:33 --> Final output sent to browser
DEBUG - 2019-12-02 16:09:33 --> Total execution time: 0.6091
INFO - 2019-12-02 16:10:16 --> Config Class Initialized
INFO - 2019-12-02 16:10:16 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:10:16 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:10:16 --> Utf8 Class Initialized
INFO - 2019-12-02 16:10:16 --> URI Class Initialized
INFO - 2019-12-02 16:10:16 --> Router Class Initialized
INFO - 2019-12-02 16:10:16 --> Output Class Initialized
INFO - 2019-12-02 16:10:16 --> Security Class Initialized
DEBUG - 2019-12-02 16:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:10:16 --> CSRF cookie sent
INFO - 2019-12-02 16:10:16 --> CSRF token verified
INFO - 2019-12-02 16:10:16 --> Input Class Initialized
INFO - 2019-12-02 16:10:16 --> Language Class Initialized
INFO - 2019-12-02 16:10:16 --> Language Class Initialized
INFO - 2019-12-02 16:10:16 --> Config Class Initialized
INFO - 2019-12-02 16:10:16 --> Loader Class Initialized
INFO - 2019-12-02 16:10:16 --> Helper loaded: url_helper
INFO - 2019-12-02 16:10:16 --> Helper loaded: common_helper
INFO - 2019-12-02 16:10:16 --> Helper loaded: language_helper
INFO - 2019-12-02 16:10:16 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:10:16 --> Helper loaded: email_helper
INFO - 2019-12-02 16:10:16 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:10:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:10:16 --> Parser Class Initialized
INFO - 2019-12-02 16:10:16 --> User Agent Class Initialized
INFO - 2019-12-02 16:10:16 --> Model Class Initialized
INFO - 2019-12-02 16:10:16 --> Database Driver Class Initialized
INFO - 2019-12-02 16:10:16 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:16 --> Template Class Initialized
INFO - 2019-12-02 16:10:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:10:16 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:10:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:10:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:10:16 --> Encryption Class Initialized
INFO - 2019-12-02 16:10:16 --> Controller Class Initialized
DEBUG - 2019-12-02 16:10:16 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:10:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:10:16 --> Model Class Initialized
INFO - 2019-12-02 16:10:19 --> Config Class Initialized
INFO - 2019-12-02 16:10:19 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:10:19 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:10:19 --> Utf8 Class Initialized
INFO - 2019-12-02 16:10:19 --> URI Class Initialized
INFO - 2019-12-02 16:10:19 --> Router Class Initialized
INFO - 2019-12-02 16:10:19 --> Output Class Initialized
INFO - 2019-12-02 16:10:19 --> Security Class Initialized
DEBUG - 2019-12-02 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:10:19 --> CSRF cookie sent
INFO - 2019-12-02 16:10:19 --> CSRF token verified
INFO - 2019-12-02 16:10:20 --> Input Class Initialized
INFO - 2019-12-02 16:10:20 --> Language Class Initialized
INFO - 2019-12-02 16:10:20 --> Language Class Initialized
INFO - 2019-12-02 16:10:20 --> Config Class Initialized
INFO - 2019-12-02 16:10:20 --> Loader Class Initialized
INFO - 2019-12-02 16:10:20 --> Helper loaded: url_helper
INFO - 2019-12-02 16:10:20 --> Helper loaded: common_helper
INFO - 2019-12-02 16:10:20 --> Helper loaded: language_helper
INFO - 2019-12-02 16:10:20 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:10:20 --> Helper loaded: email_helper
INFO - 2019-12-02 16:10:20 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:10:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:10:20 --> Parser Class Initialized
INFO - 2019-12-02 16:10:20 --> User Agent Class Initialized
INFO - 2019-12-02 16:10:20 --> Model Class Initialized
INFO - 2019-12-02 16:10:20 --> Database Driver Class Initialized
INFO - 2019-12-02 16:10:20 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:20 --> Template Class Initialized
INFO - 2019-12-02 16:10:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:10:20 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:10:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:10:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:10:20 --> Encryption Class Initialized
INFO - 2019-12-02 16:10:20 --> Controller Class Initialized
DEBUG - 2019-12-02 16:10:20 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:10:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:10:20 --> Model Class Initialized
INFO - 2019-12-02 16:10:21 --> Config Class Initialized
INFO - 2019-12-02 16:10:21 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:10:21 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:10:21 --> Utf8 Class Initialized
INFO - 2019-12-02 16:10:21 --> URI Class Initialized
INFO - 2019-12-02 16:10:21 --> Router Class Initialized
INFO - 2019-12-02 16:10:21 --> Output Class Initialized
INFO - 2019-12-02 16:10:21 --> Security Class Initialized
DEBUG - 2019-12-02 16:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:10:21 --> CSRF cookie sent
INFO - 2019-12-02 16:10:21 --> Input Class Initialized
INFO - 2019-12-02 16:10:21 --> Language Class Initialized
INFO - 2019-12-02 16:10:21 --> Language Class Initialized
INFO - 2019-12-02 16:10:21 --> Config Class Initialized
INFO - 2019-12-02 16:10:21 --> Loader Class Initialized
INFO - 2019-12-02 16:10:21 --> Helper loaded: url_helper
INFO - 2019-12-02 16:10:21 --> Helper loaded: common_helper
INFO - 2019-12-02 16:10:21 --> Helper loaded: language_helper
INFO - 2019-12-02 16:10:21 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:10:21 --> Helper loaded: email_helper
INFO - 2019-12-02 16:10:21 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:10:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:10:21 --> Parser Class Initialized
INFO - 2019-12-02 16:10:21 --> User Agent Class Initialized
INFO - 2019-12-02 16:10:21 --> Model Class Initialized
INFO - 2019-12-02 16:10:21 --> Database Driver Class Initialized
INFO - 2019-12-02 16:10:21 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:21 --> Template Class Initialized
INFO - 2019-12-02 16:10:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:10:21 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:10:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:10:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:10:21 --> Encryption Class Initialized
INFO - 2019-12-02 16:10:21 --> Controller Class Initialized
DEBUG - 2019-12-02 16:10:21 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:10:21 --> Model Class Initialized
INFO - 2019-12-02 16:10:21 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:10:21 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:10:21 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:10:21 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:10:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:10:21 --> Final output sent to browser
DEBUG - 2019-12-02 16:10:21 --> Total execution time: 0.7627
INFO - 2019-12-02 16:10:25 --> Config Class Initialized
INFO - 2019-12-02 16:10:25 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:10:25 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:10:25 --> Utf8 Class Initialized
INFO - 2019-12-02 16:10:25 --> URI Class Initialized
INFO - 2019-12-02 16:10:25 --> Router Class Initialized
INFO - 2019-12-02 16:10:25 --> Output Class Initialized
INFO - 2019-12-02 16:10:25 --> Security Class Initialized
DEBUG - 2019-12-02 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:10:25 --> CSRF cookie sent
INFO - 2019-12-02 16:10:25 --> Input Class Initialized
INFO - 2019-12-02 16:10:26 --> Language Class Initialized
INFO - 2019-12-02 16:10:26 --> Language Class Initialized
INFO - 2019-12-02 16:10:26 --> Config Class Initialized
INFO - 2019-12-02 16:10:26 --> Loader Class Initialized
INFO - 2019-12-02 16:10:26 --> Helper loaded: url_helper
INFO - 2019-12-02 16:10:26 --> Helper loaded: common_helper
INFO - 2019-12-02 16:10:26 --> Helper loaded: language_helper
INFO - 2019-12-02 16:10:26 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:10:26 --> Helper loaded: email_helper
INFO - 2019-12-02 16:10:26 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:10:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:10:26 --> Parser Class Initialized
INFO - 2019-12-02 16:10:26 --> User Agent Class Initialized
INFO - 2019-12-02 16:10:26 --> Model Class Initialized
INFO - 2019-12-02 16:10:26 --> Database Driver Class Initialized
INFO - 2019-12-02 16:10:26 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:26 --> Template Class Initialized
INFO - 2019-12-02 16:10:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:10:26 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:10:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:10:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:10:26 --> Encryption Class Initialized
INFO - 2019-12-02 16:10:26 --> Controller Class Initialized
DEBUG - 2019-12-02 16:10:26 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:10:26 --> Model Class Initialized
INFO - 2019-12-02 16:10:26 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-12-02 16:10:26 --> Could not find the language line "currency_rate"
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paystack.php
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:10:26 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:10:26 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:10:26 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:10:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:10:26 --> Final output sent to browser
DEBUG - 2019-12-02 16:10:26 --> Total execution time: 0.6092
INFO - 2019-12-02 16:10:31 --> Config Class Initialized
INFO - 2019-12-02 16:10:31 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:10:31 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:10:31 --> Utf8 Class Initialized
INFO - 2019-12-02 16:10:31 --> URI Class Initialized
INFO - 2019-12-02 16:10:31 --> Router Class Initialized
INFO - 2019-12-02 16:10:31 --> Output Class Initialized
INFO - 2019-12-02 16:10:31 --> Security Class Initialized
DEBUG - 2019-12-02 16:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:10:31 --> CSRF cookie sent
INFO - 2019-12-02 16:10:31 --> Input Class Initialized
INFO - 2019-12-02 16:10:31 --> Language Class Initialized
INFO - 2019-12-02 16:10:31 --> Language Class Initialized
INFO - 2019-12-02 16:10:32 --> Config Class Initialized
INFO - 2019-12-02 16:10:32 --> Loader Class Initialized
INFO - 2019-12-02 16:10:32 --> Helper loaded: url_helper
INFO - 2019-12-02 16:10:32 --> Helper loaded: common_helper
INFO - 2019-12-02 16:10:32 --> Helper loaded: language_helper
INFO - 2019-12-02 16:10:32 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:10:32 --> Helper loaded: email_helper
INFO - 2019-12-02 16:10:32 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:10:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:10:32 --> Parser Class Initialized
INFO - 2019-12-02 16:10:32 --> User Agent Class Initialized
INFO - 2019-12-02 16:10:32 --> Model Class Initialized
INFO - 2019-12-02 16:10:32 --> Database Driver Class Initialized
INFO - 2019-12-02 16:10:32 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:32 --> Template Class Initialized
INFO - 2019-12-02 16:10:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:10:32 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:10:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:10:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:10:32 --> Encryption Class Initialized
INFO - 2019-12-02 16:10:32 --> Controller Class Initialized
DEBUG - 2019-12-02 16:10:32 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:10:32 --> Model Class Initialized
INFO - 2019-12-02 16:10:32 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-12-02 16:10:32 --> Could not find the language line "currency_rate"
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/hesabe.php
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:10:32 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:10:32 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:10:32 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:10:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:10:32 --> Final output sent to browser
DEBUG - 2019-12-02 16:10:32 --> Total execution time: 0.6951
INFO - 2019-12-02 16:10:53 --> Config Class Initialized
INFO - 2019-12-02 16:10:53 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:10:53 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:10:53 --> Utf8 Class Initialized
INFO - 2019-12-02 16:10:53 --> URI Class Initialized
INFO - 2019-12-02 16:10:53 --> Router Class Initialized
INFO - 2019-12-02 16:10:53 --> Output Class Initialized
INFO - 2019-12-02 16:10:53 --> Security Class Initialized
DEBUG - 2019-12-02 16:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:10:53 --> CSRF cookie sent
INFO - 2019-12-02 16:10:53 --> Input Class Initialized
INFO - 2019-12-02 16:10:53 --> Language Class Initialized
INFO - 2019-12-02 16:10:53 --> Language Class Initialized
INFO - 2019-12-02 16:10:53 --> Config Class Initialized
INFO - 2019-12-02 16:10:53 --> Loader Class Initialized
INFO - 2019-12-02 16:10:53 --> Helper loaded: url_helper
INFO - 2019-12-02 16:10:53 --> Helper loaded: common_helper
INFO - 2019-12-02 16:10:53 --> Helper loaded: language_helper
INFO - 2019-12-02 16:10:53 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:10:53 --> Helper loaded: email_helper
INFO - 2019-12-02 16:10:53 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:10:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:10:53 --> Parser Class Initialized
INFO - 2019-12-02 16:10:53 --> User Agent Class Initialized
INFO - 2019-12-02 16:10:53 --> Model Class Initialized
INFO - 2019-12-02 16:10:54 --> Database Driver Class Initialized
INFO - 2019-12-02 16:10:54 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:54 --> Template Class Initialized
INFO - 2019-12-02 16:10:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:10:54 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:10:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:10:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:10:54 --> Encryption Class Initialized
INFO - 2019-12-02 16:10:54 --> Controller Class Initialized
DEBUG - 2019-12-02 16:10:54 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:10:54 --> Model Class Initialized
INFO - 2019-12-02 16:10:54 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-12-02 16:10:54 --> Could not find the language line "currency_rate"
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/hesabe.php
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:10:54 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:10:54 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:10:54 --> Model Class Initialized
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:10:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:10:54 --> Final output sent to browser
DEBUG - 2019-12-02 16:10:54 --> Total execution time: 0.6186
INFO - 2019-12-02 16:11:11 --> Config Class Initialized
INFO - 2019-12-02 16:11:11 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:11:11 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:11:11 --> Utf8 Class Initialized
INFO - 2019-12-02 16:11:11 --> URI Class Initialized
INFO - 2019-12-02 16:11:11 --> Router Class Initialized
INFO - 2019-12-02 16:11:11 --> Output Class Initialized
INFO - 2019-12-02 16:11:11 --> Security Class Initialized
DEBUG - 2019-12-02 16:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:11:11 --> CSRF cookie sent
INFO - 2019-12-02 16:11:11 --> Input Class Initialized
INFO - 2019-12-02 16:11:11 --> Language Class Initialized
INFO - 2019-12-02 16:11:11 --> Language Class Initialized
INFO - 2019-12-02 16:11:11 --> Config Class Initialized
INFO - 2019-12-02 16:11:11 --> Loader Class Initialized
INFO - 2019-12-02 16:11:11 --> Helper loaded: url_helper
INFO - 2019-12-02 16:11:11 --> Helper loaded: common_helper
INFO - 2019-12-02 16:11:11 --> Helper loaded: language_helper
INFO - 2019-12-02 16:11:11 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:11:11 --> Helper loaded: email_helper
INFO - 2019-12-02 16:11:11 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:11:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:11:11 --> Parser Class Initialized
INFO - 2019-12-02 16:11:11 --> User Agent Class Initialized
INFO - 2019-12-02 16:11:11 --> Model Class Initialized
INFO - 2019-12-02 16:11:11 --> Database Driver Class Initialized
INFO - 2019-12-02 16:11:11 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:11 --> Template Class Initialized
INFO - 2019-12-02 16:11:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:11:11 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:11:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:11:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:11:11 --> Encryption Class Initialized
INFO - 2019-12-02 16:11:11 --> Controller Class Initialized
DEBUG - 2019-12-02 16:11:11 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:11:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:11:11 --> Model Class Initialized
INFO - 2019-12-02 16:11:11 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:11:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-12-02 16:11:11 --> Could not find the language line "currency_rate"
DEBUG - 2019-12-02 16:11:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/hesabe.php
DEBUG - 2019-12-02 16:11:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-02 16:11:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:11:11 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:11:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:11:11 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:11:11 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:11:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:11:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:11:12 --> Final output sent to browser
DEBUG - 2019-12-02 16:11:12 --> Total execution time: 0.6860
INFO - 2019-12-02 16:11:32 --> Config Class Initialized
INFO - 2019-12-02 16:11:32 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:11:32 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:11:32 --> Utf8 Class Initialized
INFO - 2019-12-02 16:11:32 --> URI Class Initialized
INFO - 2019-12-02 16:11:32 --> Router Class Initialized
INFO - 2019-12-02 16:11:32 --> Output Class Initialized
INFO - 2019-12-02 16:11:32 --> Security Class Initialized
DEBUG - 2019-12-02 16:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:11:32 --> CSRF cookie sent
INFO - 2019-12-02 16:11:32 --> Input Class Initialized
INFO - 2019-12-02 16:11:32 --> Language Class Initialized
INFO - 2019-12-02 16:11:32 --> Language Class Initialized
INFO - 2019-12-02 16:11:32 --> Config Class Initialized
INFO - 2019-12-02 16:11:32 --> Loader Class Initialized
INFO - 2019-12-02 16:11:32 --> Helper loaded: url_helper
INFO - 2019-12-02 16:11:32 --> Helper loaded: common_helper
INFO - 2019-12-02 16:11:32 --> Helper loaded: language_helper
INFO - 2019-12-02 16:11:32 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:11:32 --> Helper loaded: email_helper
INFO - 2019-12-02 16:11:32 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:11:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:11:33 --> Parser Class Initialized
INFO - 2019-12-02 16:11:33 --> User Agent Class Initialized
INFO - 2019-12-02 16:11:33 --> Model Class Initialized
INFO - 2019-12-02 16:11:33 --> Database Driver Class Initialized
INFO - 2019-12-02 16:11:33 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:33 --> Template Class Initialized
INFO - 2019-12-02 16:11:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:11:33 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:11:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:11:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:11:33 --> Encryption Class Initialized
INFO - 2019-12-02 16:11:33 --> Controller Class Initialized
DEBUG - 2019-12-02 16:11:33 --> setting MX_Controller Initialized
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-02 16:11:33 --> Model Class Initialized
INFO - 2019-12-02 16:11:33 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-12-02 16:11:33 --> Could not find the language line "currency_rate"
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/hesabe.php
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:11:33 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:11:33 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:11:33 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:11:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:11:33 --> Final output sent to browser
DEBUG - 2019-12-02 16:11:33 --> Total execution time: 0.7432
INFO - 2019-12-02 16:11:45 --> Config Class Initialized
INFO - 2019-12-02 16:11:45 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:11:45 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:11:45 --> Utf8 Class Initialized
INFO - 2019-12-02 16:11:45 --> URI Class Initialized
INFO - 2019-12-02 16:11:45 --> Router Class Initialized
INFO - 2019-12-02 16:11:45 --> Output Class Initialized
INFO - 2019-12-02 16:11:45 --> Security Class Initialized
DEBUG - 2019-12-02 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:11:45 --> CSRF cookie sent
INFO - 2019-12-02 16:11:45 --> Input Class Initialized
INFO - 2019-12-02 16:11:45 --> Language Class Initialized
INFO - 2019-12-02 16:11:45 --> Language Class Initialized
INFO - 2019-12-02 16:11:45 --> Config Class Initialized
INFO - 2019-12-02 16:11:45 --> Loader Class Initialized
INFO - 2019-12-02 16:11:46 --> Helper loaded: url_helper
INFO - 2019-12-02 16:11:46 --> Helper loaded: common_helper
INFO - 2019-12-02 16:11:46 --> Helper loaded: language_helper
INFO - 2019-12-02 16:11:46 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:11:46 --> Helper loaded: email_helper
INFO - 2019-12-02 16:11:46 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:11:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:11:46 --> Parser Class Initialized
INFO - 2019-12-02 16:11:46 --> User Agent Class Initialized
INFO - 2019-12-02 16:11:46 --> Model Class Initialized
INFO - 2019-12-02 16:11:46 --> Database Driver Class Initialized
INFO - 2019-12-02 16:11:46 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:46 --> Template Class Initialized
INFO - 2019-12-02 16:11:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:11:46 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:11:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:11:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:11:46 --> Encryption Class Initialized
INFO - 2019-12-02 16:11:46 --> Controller Class Initialized
DEBUG - 2019-12-02 16:11:46 --> package MX_Controller Initialized
DEBUG - 2019-12-02 16:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-02 16:11:46 --> Model Class Initialized
INFO - 2019-12-02 16:11:46 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:11:46 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:11:46 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:11:46 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-02 16:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-02 16:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:11:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:11:46 --> Final output sent to browser
DEBUG - 2019-12-02 16:11:46 --> Total execution time: 1.1646
INFO - 2019-12-02 16:11:50 --> Config Class Initialized
INFO - 2019-12-02 16:11:50 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:11:50 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:11:50 --> Utf8 Class Initialized
INFO - 2019-12-02 16:11:50 --> URI Class Initialized
INFO - 2019-12-02 16:11:50 --> Router Class Initialized
INFO - 2019-12-02 16:11:50 --> Output Class Initialized
INFO - 2019-12-02 16:11:50 --> Security Class Initialized
DEBUG - 2019-12-02 16:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:11:50 --> CSRF cookie sent
INFO - 2019-12-02 16:11:50 --> CSRF token verified
INFO - 2019-12-02 16:11:50 --> Input Class Initialized
INFO - 2019-12-02 16:11:50 --> Language Class Initialized
INFO - 2019-12-02 16:11:50 --> Language Class Initialized
INFO - 2019-12-02 16:11:50 --> Config Class Initialized
INFO - 2019-12-02 16:11:50 --> Loader Class Initialized
INFO - 2019-12-02 16:11:50 --> Helper loaded: url_helper
INFO - 2019-12-02 16:11:50 --> Helper loaded: common_helper
INFO - 2019-12-02 16:11:50 --> Helper loaded: language_helper
INFO - 2019-12-02 16:11:50 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:11:50 --> Helper loaded: email_helper
INFO - 2019-12-02 16:11:50 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:11:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:11:50 --> Parser Class Initialized
INFO - 2019-12-02 16:11:50 --> User Agent Class Initialized
INFO - 2019-12-02 16:11:50 --> Model Class Initialized
INFO - 2019-12-02 16:11:50 --> Database Driver Class Initialized
INFO - 2019-12-02 16:11:50 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:50 --> Template Class Initialized
INFO - 2019-12-02 16:11:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:11:50 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:11:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:11:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:11:50 --> Encryption Class Initialized
INFO - 2019-12-02 16:11:50 --> Controller Class Initialized
DEBUG - 2019-12-02 16:11:50 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:11:50 --> Model Class Initialized
INFO - 2019-12-02 16:11:50 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:11:50 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:11:50 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:11:50 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:11:50 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:11:50 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:11:50 --> Model Class Initialized
DEBUG - 2019-12-02 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:11:50 --> Final output sent to browser
DEBUG - 2019-12-02 16:11:50 --> Total execution time: 0.7816
INFO - 2019-12-02 16:27:27 --> Config Class Initialized
INFO - 2019-12-02 16:27:27 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:27:27 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:27:27 --> Utf8 Class Initialized
INFO - 2019-12-02 16:27:27 --> URI Class Initialized
INFO - 2019-12-02 16:27:27 --> Router Class Initialized
INFO - 2019-12-02 16:27:27 --> Output Class Initialized
INFO - 2019-12-02 16:27:27 --> Security Class Initialized
DEBUG - 2019-12-02 16:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:27:27 --> CSRF cookie sent
INFO - 2019-12-02 16:27:27 --> CSRF token verified
INFO - 2019-12-02 16:27:27 --> Input Class Initialized
INFO - 2019-12-02 16:27:27 --> Language Class Initialized
INFO - 2019-12-02 16:27:27 --> Language Class Initialized
INFO - 2019-12-02 16:27:27 --> Config Class Initialized
INFO - 2019-12-02 16:27:27 --> Loader Class Initialized
INFO - 2019-12-02 16:27:27 --> Helper loaded: url_helper
INFO - 2019-12-02 16:27:27 --> Helper loaded: common_helper
INFO - 2019-12-02 16:27:27 --> Helper loaded: language_helper
INFO - 2019-12-02 16:27:27 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:27:27 --> Helper loaded: email_helper
INFO - 2019-12-02 16:27:27 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:27:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:27:27 --> Parser Class Initialized
INFO - 2019-12-02 16:27:27 --> User Agent Class Initialized
INFO - 2019-12-02 16:27:27 --> Model Class Initialized
INFO - 2019-12-02 16:27:27 --> Database Driver Class Initialized
INFO - 2019-12-02 16:27:27 --> Model Class Initialized
DEBUG - 2019-12-02 16:27:27 --> Template Class Initialized
INFO - 2019-12-02 16:27:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:27:27 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:27:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:27:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:27:27 --> Encryption Class Initialized
INFO - 2019-12-02 16:27:27 --> Controller Class Initialized
DEBUG - 2019-12-02 16:27:27 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:27:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:27:27 --> Model Class Initialized
INFO - 2019-12-02 16:27:27 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:27:27 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:27:27 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:27:27 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:27:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:27:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:27:28 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:27:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:27:28 --> Model Class Initialized
DEBUG - 2019-12-02 16:27:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:27:28 --> Model Class Initialized
DEBUG - 2019-12-02 16:27:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:27:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:27:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:27:28 --> Final output sent to browser
DEBUG - 2019-12-02 16:27:28 --> Total execution time: 0.6778
INFO - 2019-12-02 16:27:35 --> Config Class Initialized
INFO - 2019-12-02 16:27:35 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:27:35 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:27:35 --> Utf8 Class Initialized
INFO - 2019-12-02 16:27:35 --> URI Class Initialized
INFO - 2019-12-02 16:27:35 --> Router Class Initialized
INFO - 2019-12-02 16:27:35 --> Output Class Initialized
INFO - 2019-12-02 16:27:35 --> Security Class Initialized
DEBUG - 2019-12-02 16:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:27:35 --> CSRF cookie sent
INFO - 2019-12-02 16:27:35 --> CSRF token verified
INFO - 2019-12-02 16:27:35 --> Input Class Initialized
INFO - 2019-12-02 16:27:35 --> Language Class Initialized
INFO - 2019-12-02 16:27:35 --> Language Class Initialized
INFO - 2019-12-02 16:27:35 --> Config Class Initialized
INFO - 2019-12-02 16:27:35 --> Loader Class Initialized
INFO - 2019-12-02 16:27:35 --> Helper loaded: url_helper
INFO - 2019-12-02 16:27:35 --> Helper loaded: common_helper
INFO - 2019-12-02 16:27:35 --> Helper loaded: language_helper
INFO - 2019-12-02 16:27:35 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:27:35 --> Helper loaded: email_helper
INFO - 2019-12-02 16:27:35 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:27:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:27:35 --> Parser Class Initialized
INFO - 2019-12-02 16:27:35 --> User Agent Class Initialized
INFO - 2019-12-02 16:27:35 --> Model Class Initialized
INFO - 2019-12-02 16:27:35 --> Database Driver Class Initialized
INFO - 2019-12-02 16:27:35 --> Model Class Initialized
DEBUG - 2019-12-02 16:27:35 --> Template Class Initialized
INFO - 2019-12-02 16:27:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:27:35 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:27:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:27:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:27:35 --> Encryption Class Initialized
INFO - 2019-12-02 16:27:35 --> Controller Class Initialized
DEBUG - 2019-12-02 16:27:35 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:27:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:27:35 --> Model Class Initialized
ERROR - 2019-12-02 16:27:35 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ']' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\hesabe.php 136
INFO - 2019-12-02 16:27:41 --> Config Class Initialized
INFO - 2019-12-02 16:27:41 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:27:41 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:27:41 --> Utf8 Class Initialized
INFO - 2019-12-02 16:27:41 --> URI Class Initialized
INFO - 2019-12-02 16:27:41 --> Router Class Initialized
INFO - 2019-12-02 16:27:41 --> Output Class Initialized
INFO - 2019-12-02 16:27:41 --> Security Class Initialized
DEBUG - 2019-12-02 16:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:27:41 --> CSRF cookie sent
INFO - 2019-12-02 16:27:41 --> CSRF token verified
INFO - 2019-12-02 16:27:41 --> Input Class Initialized
INFO - 2019-12-02 16:27:41 --> Language Class Initialized
INFO - 2019-12-02 16:27:41 --> Language Class Initialized
INFO - 2019-12-02 16:27:41 --> Config Class Initialized
INFO - 2019-12-02 16:27:41 --> Loader Class Initialized
INFO - 2019-12-02 16:27:41 --> Helper loaded: url_helper
INFO - 2019-12-02 16:27:41 --> Helper loaded: common_helper
INFO - 2019-12-02 16:27:41 --> Helper loaded: language_helper
INFO - 2019-12-02 16:27:41 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:27:41 --> Helper loaded: email_helper
INFO - 2019-12-02 16:27:41 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:27:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:27:41 --> Parser Class Initialized
INFO - 2019-12-02 16:27:41 --> User Agent Class Initialized
INFO - 2019-12-02 16:27:41 --> Model Class Initialized
INFO - 2019-12-02 16:27:41 --> Database Driver Class Initialized
INFO - 2019-12-02 16:27:41 --> Model Class Initialized
DEBUG - 2019-12-02 16:27:41 --> Template Class Initialized
INFO - 2019-12-02 16:27:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:27:41 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:27:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:27:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:27:41 --> Encryption Class Initialized
INFO - 2019-12-02 16:27:41 --> Controller Class Initialized
DEBUG - 2019-12-02 16:27:41 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:27:41 --> Model Class Initialized
INFO - 2019-12-02 16:27:41 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:27:41 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:27:41 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:27:41 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:27:41 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:27:41 --> Model Class Initialized
DEBUG - 2019-12-02 16:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:27:41 --> Model Class Initialized
DEBUG - 2019-12-02 16:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:27:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:27:41 --> Final output sent to browser
DEBUG - 2019-12-02 16:27:41 --> Total execution time: 0.7195
INFO - 2019-12-02 16:27:48 --> Config Class Initialized
INFO - 2019-12-02 16:27:48 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:27:48 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:27:48 --> Utf8 Class Initialized
INFO - 2019-12-02 16:27:48 --> URI Class Initialized
INFO - 2019-12-02 16:27:48 --> Router Class Initialized
INFO - 2019-12-02 16:27:48 --> Output Class Initialized
INFO - 2019-12-02 16:27:48 --> Security Class Initialized
DEBUG - 2019-12-02 16:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:27:48 --> CSRF cookie sent
INFO - 2019-12-02 16:27:49 --> CSRF token verified
INFO - 2019-12-02 16:27:49 --> Input Class Initialized
INFO - 2019-12-02 16:27:49 --> Language Class Initialized
INFO - 2019-12-02 16:27:49 --> Language Class Initialized
INFO - 2019-12-02 16:27:49 --> Config Class Initialized
INFO - 2019-12-02 16:27:49 --> Loader Class Initialized
INFO - 2019-12-02 16:27:49 --> Helper loaded: url_helper
INFO - 2019-12-02 16:27:49 --> Helper loaded: common_helper
INFO - 2019-12-02 16:27:49 --> Helper loaded: language_helper
INFO - 2019-12-02 16:27:49 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:27:49 --> Helper loaded: email_helper
INFO - 2019-12-02 16:27:49 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:27:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:27:49 --> Parser Class Initialized
INFO - 2019-12-02 16:27:49 --> User Agent Class Initialized
INFO - 2019-12-02 16:27:49 --> Model Class Initialized
INFO - 2019-12-02 16:27:49 --> Database Driver Class Initialized
INFO - 2019-12-02 16:27:49 --> Model Class Initialized
DEBUG - 2019-12-02 16:27:49 --> Template Class Initialized
INFO - 2019-12-02 16:27:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:27:49 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:27:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:27:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:27:49 --> Encryption Class Initialized
INFO - 2019-12-02 16:27:49 --> Controller Class Initialized
DEBUG - 2019-12-02 16:27:49 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:27:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:27:49 --> Model Class Initialized
ERROR - 2019-12-02 16:27:49 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ']' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\hesabe.php 136
INFO - 2019-12-02 16:30:47 --> Config Class Initialized
INFO - 2019-12-02 16:30:47 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:30:47 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:30:47 --> Utf8 Class Initialized
INFO - 2019-12-02 16:30:47 --> URI Class Initialized
INFO - 2019-12-02 16:30:47 --> Router Class Initialized
INFO - 2019-12-02 16:30:47 --> Output Class Initialized
INFO - 2019-12-02 16:30:47 --> Security Class Initialized
DEBUG - 2019-12-02 16:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:30:47 --> CSRF cookie sent
INFO - 2019-12-02 16:30:47 --> CSRF token verified
INFO - 2019-12-02 16:30:47 --> Input Class Initialized
INFO - 2019-12-02 16:30:47 --> Language Class Initialized
INFO - 2019-12-02 16:30:47 --> Language Class Initialized
INFO - 2019-12-02 16:30:47 --> Config Class Initialized
INFO - 2019-12-02 16:30:47 --> Loader Class Initialized
INFO - 2019-12-02 16:30:47 --> Helper loaded: url_helper
INFO - 2019-12-02 16:30:47 --> Helper loaded: common_helper
INFO - 2019-12-02 16:30:47 --> Helper loaded: language_helper
INFO - 2019-12-02 16:30:47 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:30:47 --> Helper loaded: email_helper
INFO - 2019-12-02 16:30:47 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:30:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:30:47 --> Parser Class Initialized
INFO - 2019-12-02 16:30:47 --> User Agent Class Initialized
INFO - 2019-12-02 16:30:47 --> Model Class Initialized
INFO - 2019-12-02 16:30:47 --> Database Driver Class Initialized
INFO - 2019-12-02 16:30:47 --> Model Class Initialized
DEBUG - 2019-12-02 16:30:47 --> Template Class Initialized
INFO - 2019-12-02 16:30:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:30:47 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:30:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:30:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:30:47 --> Encryption Class Initialized
INFO - 2019-12-02 16:30:47 --> Controller Class Initialized
DEBUG - 2019-12-02 16:30:47 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:30:47 --> Model Class Initialized
INFO - 2019-12-02 16:30:47 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:30:47 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:30:47 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:30:47 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:30:47 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:30:47 --> Model Class Initialized
DEBUG - 2019-12-02 16:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:30:47 --> Model Class Initialized
DEBUG - 2019-12-02 16:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:30:47 --> Final output sent to browser
DEBUG - 2019-12-02 16:30:47 --> Total execution time: 0.7350
INFO - 2019-12-02 16:30:58 --> Config Class Initialized
INFO - 2019-12-02 16:30:58 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:30:58 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:30:58 --> Utf8 Class Initialized
INFO - 2019-12-02 16:30:58 --> URI Class Initialized
INFO - 2019-12-02 16:30:58 --> Router Class Initialized
INFO - 2019-12-02 16:30:58 --> Output Class Initialized
INFO - 2019-12-02 16:30:58 --> Security Class Initialized
DEBUG - 2019-12-02 16:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:30:58 --> CSRF cookie sent
INFO - 2019-12-02 16:30:58 --> CSRF token verified
INFO - 2019-12-02 16:30:58 --> Input Class Initialized
INFO - 2019-12-02 16:30:58 --> Language Class Initialized
INFO - 2019-12-02 16:30:58 --> Language Class Initialized
INFO - 2019-12-02 16:30:58 --> Config Class Initialized
INFO - 2019-12-02 16:30:58 --> Loader Class Initialized
INFO - 2019-12-02 16:30:58 --> Helper loaded: url_helper
INFO - 2019-12-02 16:30:58 --> Helper loaded: common_helper
INFO - 2019-12-02 16:30:58 --> Helper loaded: language_helper
INFO - 2019-12-02 16:30:58 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:30:58 --> Helper loaded: email_helper
INFO - 2019-12-02 16:30:58 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:30:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:30:58 --> Parser Class Initialized
INFO - 2019-12-02 16:30:58 --> User Agent Class Initialized
INFO - 2019-12-02 16:30:58 --> Model Class Initialized
INFO - 2019-12-02 16:30:58 --> Database Driver Class Initialized
INFO - 2019-12-02 16:30:58 --> Model Class Initialized
DEBUG - 2019-12-02 16:30:58 --> Template Class Initialized
INFO - 2019-12-02 16:30:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:30:58 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:30:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:30:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:30:58 --> Encryption Class Initialized
INFO - 2019-12-02 16:30:58 --> Controller Class Initialized
DEBUG - 2019-12-02 16:30:58 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:30:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:30:58 --> Model Class Initialized
DEBUG - 2019-12-02 16:30:58 --> hesabe MX_Controller Initialized
ERROR - 2019-12-02 16:30:58 --> Severity: Notice --> Undefined variable: users D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\hesabe.php 58
DEBUG - 2019-12-02 16:30:59 --> orders MX_Controller Initialized
DEBUG - 2019-12-02 16:30:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/hesabe/index.php
INFO - 2019-12-02 16:30:59 --> Final output sent to browser
DEBUG - 2019-12-02 16:30:59 --> Total execution time: 1.2142
INFO - 2019-12-02 16:31:26 --> Config Class Initialized
INFO - 2019-12-02 16:31:26 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:31:26 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:31:26 --> Utf8 Class Initialized
INFO - 2019-12-02 16:31:26 --> URI Class Initialized
INFO - 2019-12-02 16:31:26 --> Router Class Initialized
INFO - 2019-12-02 16:31:26 --> Output Class Initialized
INFO - 2019-12-02 16:31:26 --> Security Class Initialized
DEBUG - 2019-12-02 16:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:31:26 --> CSRF cookie sent
INFO - 2019-12-02 16:31:26 --> Input Class Initialized
INFO - 2019-12-02 16:31:26 --> Language Class Initialized
INFO - 2019-12-02 16:31:26 --> Language Class Initialized
INFO - 2019-12-02 16:31:26 --> Config Class Initialized
INFO - 2019-12-02 16:31:26 --> Loader Class Initialized
INFO - 2019-12-02 16:31:26 --> Helper loaded: url_helper
INFO - 2019-12-02 16:31:26 --> Helper loaded: common_helper
INFO - 2019-12-02 16:31:26 --> Helper loaded: language_helper
INFO - 2019-12-02 16:31:26 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:31:26 --> Helper loaded: email_helper
INFO - 2019-12-02 16:31:26 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:31:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:31:26 --> Parser Class Initialized
INFO - 2019-12-02 16:31:26 --> User Agent Class Initialized
INFO - 2019-12-02 16:31:26 --> Model Class Initialized
INFO - 2019-12-02 16:31:26 --> Database Driver Class Initialized
INFO - 2019-12-02 16:31:26 --> Model Class Initialized
DEBUG - 2019-12-02 16:31:26 --> Template Class Initialized
INFO - 2019-12-02 16:31:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:31:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:31:26 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:31:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:31:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:31:26 --> Encryption Class Initialized
INFO - 2019-12-02 16:31:26 --> Controller Class Initialized
DEBUG - 2019-12-02 16:31:26 --> transactions MX_Controller Initialized
DEBUG - 2019-12-02 16:31:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-02 16:31:26 --> Model Class Initialized
ERROR - 2019-12-02 16:31:26 --> Could not find the language line "order_id"
INFO - 2019-12-02 16:31:26 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:31:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-02 16:31:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:31:27 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:31:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:31:27 --> Model Class Initialized
DEBUG - 2019-12-02 16:31:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:31:27 --> Model Class Initialized
DEBUG - 2019-12-02 16:31:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:31:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:31:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:31:27 --> Final output sent to browser
DEBUG - 2019-12-02 16:31:27 --> Total execution time: 0.7313
INFO - 2019-12-02 16:32:54 --> Config Class Initialized
INFO - 2019-12-02 16:32:54 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:32:54 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:32:54 --> Utf8 Class Initialized
INFO - 2019-12-02 16:32:54 --> URI Class Initialized
INFO - 2019-12-02 16:32:54 --> Router Class Initialized
INFO - 2019-12-02 16:32:54 --> Output Class Initialized
INFO - 2019-12-02 16:32:54 --> Security Class Initialized
DEBUG - 2019-12-02 16:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:32:54 --> CSRF cookie sent
INFO - 2019-12-02 16:32:54 --> Input Class Initialized
INFO - 2019-12-02 16:32:54 --> Language Class Initialized
INFO - 2019-12-02 16:32:54 --> Language Class Initialized
INFO - 2019-12-02 16:32:54 --> Config Class Initialized
INFO - 2019-12-02 16:32:54 --> Loader Class Initialized
INFO - 2019-12-02 16:32:54 --> Helper loaded: url_helper
INFO - 2019-12-02 16:32:54 --> Helper loaded: common_helper
INFO - 2019-12-02 16:32:54 --> Helper loaded: language_helper
INFO - 2019-12-02 16:32:54 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:32:54 --> Helper loaded: email_helper
INFO - 2019-12-02 16:32:54 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:32:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:32:54 --> Parser Class Initialized
INFO - 2019-12-02 16:32:54 --> User Agent Class Initialized
INFO - 2019-12-02 16:32:54 --> Model Class Initialized
INFO - 2019-12-02 16:32:54 --> Database Driver Class Initialized
INFO - 2019-12-02 16:32:54 --> Model Class Initialized
DEBUG - 2019-12-02 16:32:54 --> Template Class Initialized
INFO - 2019-12-02 16:32:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:32:54 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:32:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:32:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:32:55 --> Encryption Class Initialized
INFO - 2019-12-02 16:32:55 --> Controller Class Initialized
DEBUG - 2019-12-02 16:32:55 --> package MX_Controller Initialized
DEBUG - 2019-12-02 16:32:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-02 16:32:55 --> Model Class Initialized
INFO - 2019-12-02 16:32:55 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:32:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:32:55 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:32:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:32:55 --> Model Class Initialized
DEBUG - 2019-12-02 16:32:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:32:55 --> Model Class Initialized
DEBUG - 2019-12-02 16:32:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-02 16:32:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-02 16:32:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:32:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:32:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:32:55 --> Final output sent to browser
DEBUG - 2019-12-02 16:32:55 --> Total execution time: 0.8538
INFO - 2019-12-02 16:33:00 --> Config Class Initialized
INFO - 2019-12-02 16:33:00 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:33:00 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:33:00 --> Utf8 Class Initialized
INFO - 2019-12-02 16:33:00 --> URI Class Initialized
INFO - 2019-12-02 16:33:00 --> Router Class Initialized
INFO - 2019-12-02 16:33:00 --> Output Class Initialized
INFO - 2019-12-02 16:33:00 --> Security Class Initialized
DEBUG - 2019-12-02 16:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:33:00 --> CSRF cookie sent
INFO - 2019-12-02 16:33:00 --> Input Class Initialized
INFO - 2019-12-02 16:33:00 --> Language Class Initialized
INFO - 2019-12-02 16:33:00 --> Language Class Initialized
INFO - 2019-12-02 16:33:00 --> Config Class Initialized
INFO - 2019-12-02 16:33:00 --> Loader Class Initialized
INFO - 2019-12-02 16:33:00 --> Helper loaded: url_helper
INFO - 2019-12-02 16:33:00 --> Helper loaded: common_helper
INFO - 2019-12-02 16:33:00 --> Helper loaded: language_helper
INFO - 2019-12-02 16:33:00 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:33:00 --> Helper loaded: email_helper
INFO - 2019-12-02 16:33:00 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:33:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:33:00 --> Parser Class Initialized
INFO - 2019-12-02 16:33:00 --> User Agent Class Initialized
INFO - 2019-12-02 16:33:00 --> Model Class Initialized
INFO - 2019-12-02 16:33:00 --> Database Driver Class Initialized
INFO - 2019-12-02 16:33:00 --> Model Class Initialized
DEBUG - 2019-12-02 16:33:00 --> Template Class Initialized
INFO - 2019-12-02 16:33:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:33:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:33:00 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:33:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:33:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:33:00 --> Encryption Class Initialized
INFO - 2019-12-02 16:33:00 --> Controller Class Initialized
DEBUG - 2019-12-02 16:33:00 --> order MX_Controller Initialized
DEBUG - 2019-12-02 16:33:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-02 16:33:00 --> Model Class Initialized
ERROR - 2019-12-02 16:33:00 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:33:00 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-02 16:33:00 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:33:00 --> Could not find the language line "order_basic_details"
INFO - 2019-12-02 16:33:00 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:33:01 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:33:01 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:33:01 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:33:01 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:33:01 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:33:01 --> Could not find the language line "Pending"
DEBUG - 2019-12-02 16:33:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-02 16:33:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:33:01 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:33:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:33:01 --> Model Class Initialized
DEBUG - 2019-12-02 16:33:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:33:01 --> Model Class Initialized
DEBUG - 2019-12-02 16:33:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:33:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:33:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:33:01 --> Final output sent to browser
DEBUG - 2019-12-02 16:33:01 --> Total execution time: 0.9934
INFO - 2019-12-02 16:33:08 --> Config Class Initialized
INFO - 2019-12-02 16:33:08 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:33:08 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:33:08 --> Utf8 Class Initialized
INFO - 2019-12-02 16:33:08 --> URI Class Initialized
INFO - 2019-12-02 16:33:08 --> Router Class Initialized
INFO - 2019-12-02 16:33:08 --> Output Class Initialized
INFO - 2019-12-02 16:33:08 --> Security Class Initialized
DEBUG - 2019-12-02 16:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:33:08 --> CSRF cookie sent
INFO - 2019-12-02 16:33:08 --> CSRF token verified
INFO - 2019-12-02 16:33:08 --> Input Class Initialized
INFO - 2019-12-02 16:33:08 --> Language Class Initialized
INFO - 2019-12-02 16:33:08 --> Language Class Initialized
INFO - 2019-12-02 16:33:09 --> Config Class Initialized
INFO - 2019-12-02 16:33:09 --> Loader Class Initialized
INFO - 2019-12-02 16:33:09 --> Helper loaded: url_helper
INFO - 2019-12-02 16:33:09 --> Helper loaded: common_helper
INFO - 2019-12-02 16:33:09 --> Helper loaded: language_helper
INFO - 2019-12-02 16:33:09 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:33:09 --> Helper loaded: email_helper
INFO - 2019-12-02 16:33:09 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:33:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:33:09 --> Parser Class Initialized
INFO - 2019-12-02 16:33:09 --> User Agent Class Initialized
INFO - 2019-12-02 16:33:09 --> Model Class Initialized
INFO - 2019-12-02 16:33:09 --> Database Driver Class Initialized
INFO - 2019-12-02 16:33:09 --> Model Class Initialized
DEBUG - 2019-12-02 16:33:09 --> Template Class Initialized
INFO - 2019-12-02 16:33:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:33:09 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:33:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:33:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:33:09 --> Encryption Class Initialized
INFO - 2019-12-02 16:33:09 --> Controller Class Initialized
DEBUG - 2019-12-02 16:33:09 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:33:09 --> Model Class Initialized
INFO - 2019-12-02 16:33:09 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:33:09 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:33:09 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:33:09 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:33:09 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:33:09 --> Model Class Initialized
DEBUG - 2019-12-02 16:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:33:09 --> Model Class Initialized
DEBUG - 2019-12-02 16:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:33:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:33:09 --> Final output sent to browser
DEBUG - 2019-12-02 16:33:09 --> Total execution time: 0.7464
INFO - 2019-12-02 16:35:54 --> Config Class Initialized
INFO - 2019-12-02 16:35:54 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:35:54 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:35:54 --> Utf8 Class Initialized
INFO - 2019-12-02 16:35:54 --> URI Class Initialized
INFO - 2019-12-02 16:35:54 --> Router Class Initialized
INFO - 2019-12-02 16:35:54 --> Output Class Initialized
INFO - 2019-12-02 16:35:54 --> Security Class Initialized
DEBUG - 2019-12-02 16:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:35:54 --> CSRF cookie sent
INFO - 2019-12-02 16:35:54 --> CSRF token verified
INFO - 2019-12-02 16:35:54 --> Input Class Initialized
INFO - 2019-12-02 16:35:54 --> Language Class Initialized
INFO - 2019-12-02 16:35:54 --> Language Class Initialized
INFO - 2019-12-02 16:35:54 --> Config Class Initialized
INFO - 2019-12-02 16:35:54 --> Loader Class Initialized
INFO - 2019-12-02 16:35:54 --> Helper loaded: url_helper
INFO - 2019-12-02 16:35:54 --> Helper loaded: common_helper
INFO - 2019-12-02 16:35:54 --> Helper loaded: language_helper
INFO - 2019-12-02 16:35:54 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:35:54 --> Helper loaded: email_helper
INFO - 2019-12-02 16:35:54 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:35:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:35:54 --> Parser Class Initialized
INFO - 2019-12-02 16:35:54 --> User Agent Class Initialized
INFO - 2019-12-02 16:35:54 --> Model Class Initialized
INFO - 2019-12-02 16:35:54 --> Database Driver Class Initialized
INFO - 2019-12-02 16:35:54 --> Model Class Initialized
DEBUG - 2019-12-02 16:35:54 --> Template Class Initialized
INFO - 2019-12-02 16:35:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:35:54 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:35:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:35:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:35:54 --> Encryption Class Initialized
INFO - 2019-12-02 16:35:54 --> Controller Class Initialized
DEBUG - 2019-12-02 16:35:54 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:35:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:35:54 --> Model Class Initialized
INFO - 2019-12-02 16:35:54 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:35:54 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:35:54 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:35:54 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:35:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:35:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:35:55 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:35:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:35:55 --> Model Class Initialized
DEBUG - 2019-12-02 16:35:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:35:55 --> Model Class Initialized
DEBUG - 2019-12-02 16:35:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:35:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:35:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:35:55 --> Final output sent to browser
DEBUG - 2019-12-02 16:35:55 --> Total execution time: 0.6761
INFO - 2019-12-02 16:36:03 --> Config Class Initialized
INFO - 2019-12-02 16:36:03 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:36:03 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:36:03 --> Utf8 Class Initialized
INFO - 2019-12-02 16:36:03 --> URI Class Initialized
INFO - 2019-12-02 16:36:03 --> Router Class Initialized
INFO - 2019-12-02 16:36:03 --> Output Class Initialized
INFO - 2019-12-02 16:36:03 --> Security Class Initialized
DEBUG - 2019-12-02 16:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:36:03 --> CSRF cookie sent
INFO - 2019-12-02 16:36:03 --> CSRF token verified
INFO - 2019-12-02 16:36:03 --> Input Class Initialized
INFO - 2019-12-02 16:36:03 --> Language Class Initialized
INFO - 2019-12-02 16:36:03 --> Language Class Initialized
INFO - 2019-12-02 16:36:03 --> Config Class Initialized
INFO - 2019-12-02 16:36:03 --> Loader Class Initialized
INFO - 2019-12-02 16:36:03 --> Helper loaded: url_helper
INFO - 2019-12-02 16:36:03 --> Helper loaded: common_helper
INFO - 2019-12-02 16:36:03 --> Helper loaded: language_helper
INFO - 2019-12-02 16:36:03 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:36:03 --> Helper loaded: email_helper
INFO - 2019-12-02 16:36:03 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:36:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:36:03 --> Parser Class Initialized
INFO - 2019-12-02 16:36:03 --> User Agent Class Initialized
INFO - 2019-12-02 16:36:03 --> Model Class Initialized
INFO - 2019-12-02 16:36:03 --> Database Driver Class Initialized
INFO - 2019-12-02 16:36:03 --> Model Class Initialized
DEBUG - 2019-12-02 16:36:03 --> Template Class Initialized
INFO - 2019-12-02 16:36:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:36:03 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:36:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:36:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:36:03 --> Encryption Class Initialized
INFO - 2019-12-02 16:36:03 --> Controller Class Initialized
DEBUG - 2019-12-02 16:36:03 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:36:03 --> Model Class Initialized
DEBUG - 2019-12-02 16:36:03 --> cardinity MX_Controller Initialized
DEBUG - 2019-12-02 16:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/index.php
INFO - 2019-12-02 16:36:03 --> Final output sent to browser
DEBUG - 2019-12-02 16:36:03 --> Total execution time: 0.5607
INFO - 2019-12-02 16:36:21 --> Config Class Initialized
INFO - 2019-12-02 16:36:21 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:36:21 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:36:21 --> Utf8 Class Initialized
INFO - 2019-12-02 16:36:21 --> URI Class Initialized
INFO - 2019-12-02 16:36:21 --> Router Class Initialized
INFO - 2019-12-02 16:36:21 --> Output Class Initialized
INFO - 2019-12-02 16:36:21 --> Security Class Initialized
DEBUG - 2019-12-02 16:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:36:22 --> CSRF cookie sent
INFO - 2019-12-02 16:36:22 --> CSRF token verified
INFO - 2019-12-02 16:36:22 --> Input Class Initialized
INFO - 2019-12-02 16:36:22 --> Language Class Initialized
INFO - 2019-12-02 16:36:22 --> Language Class Initialized
INFO - 2019-12-02 16:36:22 --> Config Class Initialized
INFO - 2019-12-02 16:36:22 --> Loader Class Initialized
INFO - 2019-12-02 16:36:22 --> Helper loaded: url_helper
INFO - 2019-12-02 16:36:22 --> Helper loaded: common_helper
INFO - 2019-12-02 16:36:22 --> Helper loaded: language_helper
INFO - 2019-12-02 16:36:22 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:36:22 --> Helper loaded: email_helper
INFO - 2019-12-02 16:36:22 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:36:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:36:22 --> Parser Class Initialized
INFO - 2019-12-02 16:36:22 --> User Agent Class Initialized
INFO - 2019-12-02 16:36:22 --> Model Class Initialized
INFO - 2019-12-02 16:36:22 --> Database Driver Class Initialized
INFO - 2019-12-02 16:36:22 --> Model Class Initialized
DEBUG - 2019-12-02 16:36:22 --> Template Class Initialized
INFO - 2019-12-02 16:36:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:36:22 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:36:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:36:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:36:22 --> Encryption Class Initialized
INFO - 2019-12-02 16:36:22 --> Controller Class Initialized
DEBUG - 2019-12-02 16:36:22 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:36:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:36:22 --> Model Class Initialized
DEBUG - 2019-12-02 16:36:22 --> hesabe MX_Controller Initialized
ERROR - 2019-12-02 16:36:22 --> Severity: Notice --> Undefined variable: users D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\hesabe.php 61
DEBUG - 2019-12-02 16:36:22 --> orders MX_Controller Initialized
DEBUG - 2019-12-02 16:36:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/hesabe/index.php
INFO - 2019-12-02 16:36:23 --> Final output sent to browser
DEBUG - 2019-12-02 16:36:23 --> Total execution time: 1.1628
INFO - 2019-12-02 16:39:07 --> Config Class Initialized
INFO - 2019-12-02 16:39:07 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:39:07 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:39:07 --> Utf8 Class Initialized
INFO - 2019-12-02 16:39:07 --> URI Class Initialized
INFO - 2019-12-02 16:39:07 --> Router Class Initialized
INFO - 2019-12-02 16:39:07 --> Output Class Initialized
INFO - 2019-12-02 16:39:07 --> Security Class Initialized
DEBUG - 2019-12-02 16:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:39:07 --> CSRF cookie sent
INFO - 2019-12-02 16:39:07 --> CSRF token verified
INFO - 2019-12-02 16:39:07 --> Input Class Initialized
INFO - 2019-12-02 16:39:07 --> Language Class Initialized
INFO - 2019-12-02 16:39:07 --> Language Class Initialized
INFO - 2019-12-02 16:39:07 --> Config Class Initialized
INFO - 2019-12-02 16:39:07 --> Loader Class Initialized
INFO - 2019-12-02 16:39:07 --> Helper loaded: url_helper
INFO - 2019-12-02 16:39:07 --> Helper loaded: common_helper
INFO - 2019-12-02 16:39:07 --> Helper loaded: language_helper
INFO - 2019-12-02 16:39:07 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:39:07 --> Helper loaded: email_helper
INFO - 2019-12-02 16:39:07 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:39:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:39:07 --> Parser Class Initialized
INFO - 2019-12-02 16:39:07 --> User Agent Class Initialized
INFO - 2019-12-02 16:39:07 --> Model Class Initialized
INFO - 2019-12-02 16:39:07 --> Database Driver Class Initialized
INFO - 2019-12-02 16:39:07 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:07 --> Template Class Initialized
INFO - 2019-12-02 16:39:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:39:07 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:39:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:39:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:39:07 --> Encryption Class Initialized
INFO - 2019-12-02 16:39:07 --> Controller Class Initialized
DEBUG - 2019-12-02 16:39:07 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:39:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:39:07 --> Model Class Initialized
INFO - 2019-12-02 16:39:07 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:39:08 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:39:08 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:39:08 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:39:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:39:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:39:08 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:39:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:39:08 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:39:08 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:39:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:39:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:39:08 --> Final output sent to browser
DEBUG - 2019-12-02 16:39:08 --> Total execution time: 0.7430
INFO - 2019-12-02 16:39:10 --> Config Class Initialized
INFO - 2019-12-02 16:39:10 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:39:10 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:39:10 --> Utf8 Class Initialized
INFO - 2019-12-02 16:39:10 --> URI Class Initialized
INFO - 2019-12-02 16:39:10 --> Router Class Initialized
INFO - 2019-12-02 16:39:10 --> Output Class Initialized
INFO - 2019-12-02 16:39:10 --> Security Class Initialized
DEBUG - 2019-12-02 16:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:39:10 --> CSRF cookie sent
INFO - 2019-12-02 16:39:10 --> Input Class Initialized
INFO - 2019-12-02 16:39:10 --> Language Class Initialized
INFO - 2019-12-02 16:39:10 --> Language Class Initialized
INFO - 2019-12-02 16:39:10 --> Config Class Initialized
INFO - 2019-12-02 16:39:10 --> Loader Class Initialized
INFO - 2019-12-02 16:39:10 --> Helper loaded: url_helper
INFO - 2019-12-02 16:39:10 --> Helper loaded: common_helper
INFO - 2019-12-02 16:39:10 --> Helper loaded: language_helper
INFO - 2019-12-02 16:39:10 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:39:10 --> Helper loaded: email_helper
INFO - 2019-12-02 16:39:10 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:39:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:39:10 --> Parser Class Initialized
INFO - 2019-12-02 16:39:10 --> User Agent Class Initialized
INFO - 2019-12-02 16:39:10 --> Model Class Initialized
INFO - 2019-12-02 16:39:10 --> Database Driver Class Initialized
INFO - 2019-12-02 16:39:10 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:10 --> Template Class Initialized
INFO - 2019-12-02 16:39:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:39:10 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:39:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:39:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:39:10 --> Encryption Class Initialized
INFO - 2019-12-02 16:39:10 --> Controller Class Initialized
DEBUG - 2019-12-02 16:39:10 --> order MX_Controller Initialized
DEBUG - 2019-12-02 16:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-02 16:39:10 --> Model Class Initialized
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "order_basic_details"
INFO - 2019-12-02 16:39:11 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:39:11 --> Could not find the language line "Pending"
DEBUG - 2019-12-02 16:39:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-02 16:39:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:39:11 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:39:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:39:11 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:39:11 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:39:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:39:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:39:11 --> Final output sent to browser
DEBUG - 2019-12-02 16:39:11 --> Total execution time: 0.9510
INFO - 2019-12-02 16:39:14 --> Config Class Initialized
INFO - 2019-12-02 16:39:14 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:39:14 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:39:14 --> Utf8 Class Initialized
INFO - 2019-12-02 16:39:14 --> URI Class Initialized
INFO - 2019-12-02 16:39:14 --> Router Class Initialized
INFO - 2019-12-02 16:39:14 --> Output Class Initialized
INFO - 2019-12-02 16:39:14 --> Security Class Initialized
DEBUG - 2019-12-02 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:39:14 --> CSRF cookie sent
INFO - 2019-12-02 16:39:14 --> Input Class Initialized
INFO - 2019-12-02 16:39:14 --> Language Class Initialized
INFO - 2019-12-02 16:39:14 --> Language Class Initialized
INFO - 2019-12-02 16:39:14 --> Config Class Initialized
INFO - 2019-12-02 16:39:14 --> Loader Class Initialized
INFO - 2019-12-02 16:39:14 --> Helper loaded: url_helper
INFO - 2019-12-02 16:39:14 --> Helper loaded: common_helper
INFO - 2019-12-02 16:39:14 --> Helper loaded: language_helper
INFO - 2019-12-02 16:39:14 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:39:14 --> Helper loaded: email_helper
INFO - 2019-12-02 16:39:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:39:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:39:14 --> Parser Class Initialized
INFO - 2019-12-02 16:39:14 --> User Agent Class Initialized
INFO - 2019-12-02 16:39:14 --> Model Class Initialized
INFO - 2019-12-02 16:39:14 --> Database Driver Class Initialized
INFO - 2019-12-02 16:39:14 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:14 --> Template Class Initialized
INFO - 2019-12-02 16:39:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:39:14 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:39:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:39:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:39:14 --> Encryption Class Initialized
INFO - 2019-12-02 16:39:14 --> Controller Class Initialized
DEBUG - 2019-12-02 16:39:14 --> transactions MX_Controller Initialized
DEBUG - 2019-12-02 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-02 16:39:14 --> Model Class Initialized
ERROR - 2019-12-02 16:39:14 --> Could not find the language line "order_id"
INFO - 2019-12-02 16:39:14 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-02 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:39:14 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:39:14 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:39:14 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:39:15 --> Final output sent to browser
DEBUG - 2019-12-02 16:39:15 --> Total execution time: 0.6854
INFO - 2019-12-02 16:39:38 --> Config Class Initialized
INFO - 2019-12-02 16:39:38 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:39:38 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:39:38 --> Utf8 Class Initialized
INFO - 2019-12-02 16:39:38 --> URI Class Initialized
INFO - 2019-12-02 16:39:38 --> Router Class Initialized
INFO - 2019-12-02 16:39:38 --> Output Class Initialized
INFO - 2019-12-02 16:39:38 --> Security Class Initialized
DEBUG - 2019-12-02 16:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:39:38 --> CSRF cookie sent
INFO - 2019-12-02 16:39:38 --> CSRF token verified
INFO - 2019-12-02 16:39:38 --> Input Class Initialized
INFO - 2019-12-02 16:39:38 --> Language Class Initialized
INFO - 2019-12-02 16:39:38 --> Language Class Initialized
INFO - 2019-12-02 16:39:38 --> Config Class Initialized
INFO - 2019-12-02 16:39:38 --> Loader Class Initialized
INFO - 2019-12-02 16:39:38 --> Helper loaded: url_helper
INFO - 2019-12-02 16:39:38 --> Helper loaded: common_helper
INFO - 2019-12-02 16:39:38 --> Helper loaded: language_helper
INFO - 2019-12-02 16:39:38 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:39:38 --> Helper loaded: email_helper
INFO - 2019-12-02 16:39:38 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:39:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:39:38 --> Parser Class Initialized
INFO - 2019-12-02 16:39:38 --> User Agent Class Initialized
INFO - 2019-12-02 16:39:38 --> Model Class Initialized
INFO - 2019-12-02 16:39:38 --> Database Driver Class Initialized
INFO - 2019-12-02 16:39:38 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:38 --> Template Class Initialized
INFO - 2019-12-02 16:39:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:39:38 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:39:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:39:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:39:38 --> Encryption Class Initialized
INFO - 2019-12-02 16:39:38 --> Controller Class Initialized
DEBUG - 2019-12-02 16:39:38 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:39:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:39:38 --> Model Class Initialized
INFO - 2019-12-02 16:39:43 --> Config Class Initialized
INFO - 2019-12-02 16:39:43 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:39:43 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:39:43 --> Utf8 Class Initialized
INFO - 2019-12-02 16:39:44 --> URI Class Initialized
INFO - 2019-12-02 16:39:44 --> Router Class Initialized
INFO - 2019-12-02 16:39:44 --> Output Class Initialized
INFO - 2019-12-02 16:39:44 --> Security Class Initialized
DEBUG - 2019-12-02 16:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:39:44 --> CSRF cookie sent
INFO - 2019-12-02 16:39:44 --> CSRF token verified
INFO - 2019-12-02 16:39:44 --> Input Class Initialized
INFO - 2019-12-02 16:39:44 --> Language Class Initialized
INFO - 2019-12-02 16:39:44 --> Language Class Initialized
INFO - 2019-12-02 16:39:44 --> Config Class Initialized
INFO - 2019-12-02 16:39:44 --> Loader Class Initialized
INFO - 2019-12-02 16:39:44 --> Helper loaded: url_helper
INFO - 2019-12-02 16:39:44 --> Helper loaded: common_helper
INFO - 2019-12-02 16:39:44 --> Helper loaded: language_helper
INFO - 2019-12-02 16:39:44 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:39:44 --> Helper loaded: email_helper
INFO - 2019-12-02 16:39:44 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:39:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:39:44 --> Parser Class Initialized
INFO - 2019-12-02 16:39:44 --> User Agent Class Initialized
INFO - 2019-12-02 16:39:44 --> Model Class Initialized
INFO - 2019-12-02 16:39:44 --> Database Driver Class Initialized
INFO - 2019-12-02 16:39:44 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:44 --> Template Class Initialized
INFO - 2019-12-02 16:39:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:39:44 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:39:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:39:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:39:44 --> Encryption Class Initialized
INFO - 2019-12-02 16:39:44 --> Controller Class Initialized
DEBUG - 2019-12-02 16:39:44 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:39:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:39:44 --> Model Class Initialized
DEBUG - 2019-12-02 16:39:44 --> hesabe MX_Controller Initialized
ERROR - 2019-12-02 16:39:44 --> Severity: Notice --> Undefined variable: users D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\hesabe.php 61
DEBUG - 2019-12-02 16:39:45 --> orders MX_Controller Initialized
DEBUG - 2019-12-02 16:39:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/hesabe/index.php
INFO - 2019-12-02 16:39:45 --> Final output sent to browser
DEBUG - 2019-12-02 16:39:45 --> Total execution time: 1.2778
INFO - 2019-12-02 16:40:19 --> Config Class Initialized
INFO - 2019-12-02 16:40:19 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:40:19 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:40:19 --> Utf8 Class Initialized
INFO - 2019-12-02 16:40:19 --> URI Class Initialized
INFO - 2019-12-02 16:40:19 --> Router Class Initialized
INFO - 2019-12-02 16:40:19 --> Output Class Initialized
INFO - 2019-12-02 16:40:19 --> Security Class Initialized
DEBUG - 2019-12-02 16:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:40:19 --> CSRF cookie sent
INFO - 2019-12-02 16:40:19 --> Input Class Initialized
INFO - 2019-12-02 16:40:19 --> Language Class Initialized
INFO - 2019-12-02 16:40:19 --> Language Class Initialized
INFO - 2019-12-02 16:40:19 --> Config Class Initialized
INFO - 2019-12-02 16:40:19 --> Loader Class Initialized
INFO - 2019-12-02 16:40:19 --> Helper loaded: url_helper
INFO - 2019-12-02 16:40:19 --> Helper loaded: common_helper
INFO - 2019-12-02 16:40:19 --> Helper loaded: language_helper
INFO - 2019-12-02 16:40:19 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:40:19 --> Helper loaded: email_helper
INFO - 2019-12-02 16:40:19 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:40:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:40:19 --> Parser Class Initialized
INFO - 2019-12-02 16:40:20 --> User Agent Class Initialized
INFO - 2019-12-02 16:40:20 --> Model Class Initialized
INFO - 2019-12-02 16:40:20 --> Database Driver Class Initialized
INFO - 2019-12-02 16:40:20 --> Model Class Initialized
DEBUG - 2019-12-02 16:40:20 --> Template Class Initialized
INFO - 2019-12-02 16:40:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:40:20 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:40:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:40:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:40:20 --> Encryption Class Initialized
INFO - 2019-12-02 16:40:20 --> Controller Class Initialized
DEBUG - 2019-12-02 16:40:20 --> transactions MX_Controller Initialized
DEBUG - 2019-12-02 16:40:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-02 16:40:20 --> Model Class Initialized
ERROR - 2019-12-02 16:40:20 --> Could not find the language line "order_id"
INFO - 2019-12-02 16:40:20 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:40:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-02 16:40:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:40:20 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:40:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:40:20 --> Model Class Initialized
DEBUG - 2019-12-02 16:40:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:40:20 --> Model Class Initialized
DEBUG - 2019-12-02 16:40:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:40:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:40:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:40:20 --> Final output sent to browser
DEBUG - 2019-12-02 16:40:20 --> Total execution time: 0.7154
INFO - 2019-12-02 16:40:23 --> Config Class Initialized
INFO - 2019-12-02 16:40:23 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:40:23 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:40:23 --> Utf8 Class Initialized
INFO - 2019-12-02 16:40:23 --> URI Class Initialized
INFO - 2019-12-02 16:40:23 --> Router Class Initialized
INFO - 2019-12-02 16:40:23 --> Output Class Initialized
INFO - 2019-12-02 16:40:23 --> Security Class Initialized
DEBUG - 2019-12-02 16:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:40:23 --> CSRF cookie sent
INFO - 2019-12-02 16:40:23 --> CSRF token verified
INFO - 2019-12-02 16:40:23 --> Input Class Initialized
INFO - 2019-12-02 16:40:23 --> Language Class Initialized
INFO - 2019-12-02 16:40:23 --> Language Class Initialized
INFO - 2019-12-02 16:40:23 --> Config Class Initialized
INFO - 2019-12-02 16:40:23 --> Loader Class Initialized
INFO - 2019-12-02 16:40:23 --> Helper loaded: url_helper
INFO - 2019-12-02 16:40:23 --> Helper loaded: common_helper
INFO - 2019-12-02 16:40:23 --> Helper loaded: language_helper
INFO - 2019-12-02 16:40:23 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:40:23 --> Helper loaded: email_helper
INFO - 2019-12-02 16:40:23 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:40:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:40:23 --> Parser Class Initialized
INFO - 2019-12-02 16:40:23 --> User Agent Class Initialized
INFO - 2019-12-02 16:40:23 --> Model Class Initialized
INFO - 2019-12-02 16:40:23 --> Database Driver Class Initialized
INFO - 2019-12-02 16:40:23 --> Model Class Initialized
DEBUG - 2019-12-02 16:40:23 --> Template Class Initialized
INFO - 2019-12-02 16:40:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:40:23 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:40:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:40:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:40:23 --> Encryption Class Initialized
INFO - 2019-12-02 16:40:23 --> Controller Class Initialized
DEBUG - 2019-12-02 16:40:23 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:40:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:40:23 --> Model Class Initialized
INFO - 2019-12-02 16:40:23 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:40:23 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:40:23 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:40:23 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:40:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:40:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:40:23 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:40:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:40:24 --> Model Class Initialized
DEBUG - 2019-12-02 16:40:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:40:24 --> Model Class Initialized
DEBUG - 2019-12-02 16:40:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:40:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:40:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:40:24 --> Final output sent to browser
DEBUG - 2019-12-02 16:40:24 --> Total execution time: 0.7606
INFO - 2019-12-02 16:40:31 --> Config Class Initialized
INFO - 2019-12-02 16:40:31 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:40:31 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:40:31 --> Utf8 Class Initialized
INFO - 2019-12-02 16:40:31 --> URI Class Initialized
INFO - 2019-12-02 16:40:31 --> Router Class Initialized
INFO - 2019-12-02 16:40:31 --> Output Class Initialized
INFO - 2019-12-02 16:40:31 --> Security Class Initialized
DEBUG - 2019-12-02 16:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:40:31 --> CSRF cookie sent
INFO - 2019-12-02 16:40:31 --> CSRF token verified
INFO - 2019-12-02 16:40:31 --> Input Class Initialized
INFO - 2019-12-02 16:40:31 --> Language Class Initialized
INFO - 2019-12-02 16:40:31 --> Language Class Initialized
INFO - 2019-12-02 16:40:31 --> Config Class Initialized
INFO - 2019-12-02 16:40:31 --> Loader Class Initialized
INFO - 2019-12-02 16:40:31 --> Helper loaded: url_helper
INFO - 2019-12-02 16:40:31 --> Helper loaded: common_helper
INFO - 2019-12-02 16:40:31 --> Helper loaded: language_helper
INFO - 2019-12-02 16:40:31 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:40:31 --> Helper loaded: email_helper
INFO - 2019-12-02 16:40:31 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:40:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:40:31 --> Parser Class Initialized
INFO - 2019-12-02 16:40:31 --> User Agent Class Initialized
INFO - 2019-12-02 16:40:31 --> Model Class Initialized
INFO - 2019-12-02 16:40:31 --> Database Driver Class Initialized
INFO - 2019-12-02 16:40:31 --> Model Class Initialized
DEBUG - 2019-12-02 16:40:31 --> Template Class Initialized
INFO - 2019-12-02 16:40:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:40:31 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:40:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:40:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:40:31 --> Encryption Class Initialized
INFO - 2019-12-02 16:40:31 --> Controller Class Initialized
DEBUG - 2019-12-02 16:40:31 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:40:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:40:31 --> Model Class Initialized
DEBUG - 2019-12-02 16:40:32 --> hesabe MX_Controller Initialized
DEBUG - 2019-12-02 16:40:32 --> orders MX_Controller Initialized
DEBUG - 2019-12-02 16:40:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/hesabe/index.php
INFO - 2019-12-02 16:40:32 --> Final output sent to browser
DEBUG - 2019-12-02 16:40:32 --> Total execution time: 1.1888
INFO - 2019-12-02 16:41:08 --> Config Class Initialized
INFO - 2019-12-02 16:41:08 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:41:08 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:41:08 --> Utf8 Class Initialized
INFO - 2019-12-02 16:41:08 --> URI Class Initialized
INFO - 2019-12-02 16:41:08 --> Router Class Initialized
INFO - 2019-12-02 16:41:08 --> Output Class Initialized
INFO - 2019-12-02 16:41:08 --> Security Class Initialized
DEBUG - 2019-12-02 16:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:41:08 --> Input Class Initialized
INFO - 2019-12-02 16:41:08 --> Language Class Initialized
INFO - 2019-12-02 16:41:08 --> Language Class Initialized
INFO - 2019-12-02 16:41:08 --> Config Class Initialized
INFO - 2019-12-02 16:41:08 --> Loader Class Initialized
INFO - 2019-12-02 16:41:08 --> Helper loaded: url_helper
INFO - 2019-12-02 16:41:08 --> Helper loaded: common_helper
INFO - 2019-12-02 16:41:08 --> Helper loaded: language_helper
INFO - 2019-12-02 16:41:08 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:41:08 --> Helper loaded: email_helper
INFO - 2019-12-02 16:41:08 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:41:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:41:08 --> Parser Class Initialized
INFO - 2019-12-02 16:41:08 --> User Agent Class Initialized
INFO - 2019-12-02 16:41:08 --> Model Class Initialized
INFO - 2019-12-02 16:41:08 --> Database Driver Class Initialized
INFO - 2019-12-02 16:41:08 --> Model Class Initialized
DEBUG - 2019-12-02 16:41:08 --> Template Class Initialized
INFO - 2019-12-02 16:41:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:41:08 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:41:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:41:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:41:08 --> Encryption Class Initialized
INFO - 2019-12-02 16:41:08 --> Controller Class Initialized
DEBUG - 2019-12-02 16:41:08 --> custom_page MX_Controller Initialized
DEBUG - 2019-12-02 16:41:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-12-02 16:41:08 --> Model Class Initialized
INFO - 2019-12-02 16:41:08 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:41:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-12-02 16:41:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-12-02 16:41:08 --> Final output sent to browser
DEBUG - 2019-12-02 16:41:08 --> Total execution time: 0.5010
INFO - 2019-12-02 16:41:08 --> Config Class Initialized
INFO - 2019-12-02 16:41:08 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:41:08 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:41:08 --> Utf8 Class Initialized
INFO - 2019-12-02 16:41:08 --> URI Class Initialized
INFO - 2019-12-02 16:41:08 --> Router Class Initialized
INFO - 2019-12-02 16:41:09 --> Output Class Initialized
INFO - 2019-12-02 16:41:09 --> Security Class Initialized
DEBUG - 2019-12-02 16:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:41:09 --> CSRF cookie sent
INFO - 2019-12-02 16:41:09 --> Input Class Initialized
INFO - 2019-12-02 16:41:09 --> Language Class Initialized
INFO - 2019-12-02 16:41:09 --> Language Class Initialized
INFO - 2019-12-02 16:41:09 --> Config Class Initialized
INFO - 2019-12-02 16:41:09 --> Loader Class Initialized
INFO - 2019-12-02 16:41:09 --> Helper loaded: url_helper
INFO - 2019-12-02 16:41:09 --> Helper loaded: common_helper
INFO - 2019-12-02 16:41:09 --> Helper loaded: language_helper
INFO - 2019-12-02 16:41:09 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:41:09 --> Helper loaded: email_helper
INFO - 2019-12-02 16:41:09 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:41:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:41:09 --> Parser Class Initialized
INFO - 2019-12-02 16:41:09 --> User Agent Class Initialized
INFO - 2019-12-02 16:41:09 --> Model Class Initialized
INFO - 2019-12-02 16:41:09 --> Database Driver Class Initialized
INFO - 2019-12-02 16:41:09 --> Model Class Initialized
DEBUG - 2019-12-02 16:41:09 --> Template Class Initialized
INFO - 2019-12-02 16:41:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:41:09 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:41:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:41:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:41:09 --> Encryption Class Initialized
INFO - 2019-12-02 16:41:09 --> Controller Class Initialized
DEBUG - 2019-12-02 16:41:09 --> custom_page MX_Controller Initialized
DEBUG - 2019-12-02 16:41:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-12-02 16:41:09 --> Model Class Initialized
INFO - 2019-12-02 16:41:09 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:41:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-12-02 16:41:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-12-02 16:41:09 --> Final output sent to browser
DEBUG - 2019-12-02 16:41:09 --> Total execution time: 0.5046
INFO - 2019-12-02 16:41:24 --> Config Class Initialized
INFO - 2019-12-02 16:41:24 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:41:24 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:41:24 --> Utf8 Class Initialized
INFO - 2019-12-02 16:41:24 --> URI Class Initialized
INFO - 2019-12-02 16:41:24 --> Router Class Initialized
INFO - 2019-12-02 16:41:24 --> Output Class Initialized
INFO - 2019-12-02 16:41:24 --> Security Class Initialized
DEBUG - 2019-12-02 16:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:41:24 --> Input Class Initialized
INFO - 2019-12-02 16:41:24 --> Language Class Initialized
INFO - 2019-12-02 16:41:24 --> Language Class Initialized
INFO - 2019-12-02 16:41:24 --> Config Class Initialized
INFO - 2019-12-02 16:41:24 --> Loader Class Initialized
INFO - 2019-12-02 16:41:24 --> Helper loaded: url_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: common_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: language_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: email_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:41:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:41:24 --> Parser Class Initialized
INFO - 2019-12-02 16:41:24 --> User Agent Class Initialized
INFO - 2019-12-02 16:41:24 --> Model Class Initialized
INFO - 2019-12-02 16:41:24 --> Database Driver Class Initialized
INFO - 2019-12-02 16:41:24 --> Model Class Initialized
DEBUG - 2019-12-02 16:41:24 --> Template Class Initialized
INFO - 2019-12-02 16:41:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:41:24 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:41:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:41:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:41:24 --> Encryption Class Initialized
INFO - 2019-12-02 16:41:24 --> Controller Class Initialized
DEBUG - 2019-12-02 16:41:24 --> hesabe MX_Controller Initialized
INFO - 2019-12-02 16:41:24 --> Model Class Initialized
INFO - 2019-12-02 16:41:24 --> Config Class Initialized
INFO - 2019-12-02 16:41:24 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:41:24 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:41:24 --> Utf8 Class Initialized
INFO - 2019-12-02 16:41:24 --> URI Class Initialized
INFO - 2019-12-02 16:41:24 --> Router Class Initialized
INFO - 2019-12-02 16:41:24 --> Output Class Initialized
INFO - 2019-12-02 16:41:24 --> Security Class Initialized
DEBUG - 2019-12-02 16:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:41:24 --> CSRF cookie sent
INFO - 2019-12-02 16:41:24 --> Input Class Initialized
INFO - 2019-12-02 16:41:24 --> Language Class Initialized
INFO - 2019-12-02 16:41:24 --> Language Class Initialized
INFO - 2019-12-02 16:41:24 --> Config Class Initialized
INFO - 2019-12-02 16:41:24 --> Loader Class Initialized
INFO - 2019-12-02 16:41:24 --> Helper loaded: url_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: common_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: language_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: email_helper
INFO - 2019-12-02 16:41:24 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:41:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:41:25 --> Parser Class Initialized
INFO - 2019-12-02 16:41:25 --> User Agent Class Initialized
INFO - 2019-12-02 16:41:25 --> Model Class Initialized
INFO - 2019-12-02 16:41:25 --> Database Driver Class Initialized
INFO - 2019-12-02 16:41:25 --> Model Class Initialized
DEBUG - 2019-12-02 16:41:25 --> Template Class Initialized
INFO - 2019-12-02 16:41:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:41:25 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:41:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:41:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:41:25 --> Encryption Class Initialized
INFO - 2019-12-02 16:41:25 --> Controller Class Initialized
DEBUG - 2019-12-02 16:41:25 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:41:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:41:25 --> Model Class Initialized
INFO - 2019-12-02 16:41:25 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:41:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-12-02 16:41:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:41:25 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:41:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:41:25 --> Model Class Initialized
DEBUG - 2019-12-02 16:41:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:41:25 --> Model Class Initialized
DEBUG - 2019-12-02 16:41:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:41:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:41:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:41:25 --> Final output sent to browser
DEBUG - 2019-12-02 16:41:25 --> Total execution time: 0.6648
INFO - 2019-12-02 16:43:01 --> Config Class Initialized
INFO - 2019-12-02 16:43:01 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:43:01 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:43:01 --> Utf8 Class Initialized
INFO - 2019-12-02 16:43:01 --> URI Class Initialized
INFO - 2019-12-02 16:43:01 --> Router Class Initialized
INFO - 2019-12-02 16:43:01 --> Output Class Initialized
INFO - 2019-12-02 16:43:01 --> Security Class Initialized
DEBUG - 2019-12-02 16:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:43:01 --> CSRF cookie sent
INFO - 2019-12-02 16:43:01 --> Input Class Initialized
INFO - 2019-12-02 16:43:01 --> Language Class Initialized
INFO - 2019-12-02 16:43:01 --> Language Class Initialized
INFO - 2019-12-02 16:43:01 --> Config Class Initialized
INFO - 2019-12-02 16:43:01 --> Loader Class Initialized
INFO - 2019-12-02 16:43:01 --> Helper loaded: url_helper
INFO - 2019-12-02 16:43:01 --> Helper loaded: common_helper
INFO - 2019-12-02 16:43:01 --> Helper loaded: language_helper
INFO - 2019-12-02 16:43:01 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:43:01 --> Helper loaded: email_helper
INFO - 2019-12-02 16:43:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:43:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:43:01 --> Parser Class Initialized
INFO - 2019-12-02 16:43:01 --> User Agent Class Initialized
INFO - 2019-12-02 16:43:01 --> Model Class Initialized
INFO - 2019-12-02 16:43:01 --> Database Driver Class Initialized
INFO - 2019-12-02 16:43:01 --> Model Class Initialized
DEBUG - 2019-12-02 16:43:01 --> Template Class Initialized
INFO - 2019-12-02 16:43:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:43:01 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:43:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:43:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:43:01 --> Encryption Class Initialized
INFO - 2019-12-02 16:43:01 --> Controller Class Initialized
DEBUG - 2019-12-02 16:43:01 --> transactions MX_Controller Initialized
DEBUG - 2019-12-02 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-02 16:43:01 --> Model Class Initialized
ERROR - 2019-12-02 16:43:01 --> Could not find the language line "order_id"
INFO - 2019-12-02 16:43:01 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-02 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:43:01 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:43:01 --> Model Class Initialized
DEBUG - 2019-12-02 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:43:01 --> Model Class Initialized
DEBUG - 2019-12-02 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:43:01 --> Final output sent to browser
DEBUG - 2019-12-02 16:43:01 --> Total execution time: 0.7281
INFO - 2019-12-02 16:43:04 --> Config Class Initialized
INFO - 2019-12-02 16:43:04 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:43:04 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:43:04 --> Utf8 Class Initialized
INFO - 2019-12-02 16:43:04 --> URI Class Initialized
INFO - 2019-12-02 16:43:04 --> Router Class Initialized
INFO - 2019-12-02 16:43:04 --> Output Class Initialized
INFO - 2019-12-02 16:43:04 --> Security Class Initialized
DEBUG - 2019-12-02 16:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:43:04 --> CSRF cookie sent
INFO - 2019-12-02 16:43:04 --> Input Class Initialized
INFO - 2019-12-02 16:43:04 --> Language Class Initialized
INFO - 2019-12-02 16:43:04 --> Language Class Initialized
INFO - 2019-12-02 16:43:04 --> Config Class Initialized
INFO - 2019-12-02 16:43:04 --> Loader Class Initialized
INFO - 2019-12-02 16:43:04 --> Helper loaded: url_helper
INFO - 2019-12-02 16:43:04 --> Helper loaded: common_helper
INFO - 2019-12-02 16:43:04 --> Helper loaded: language_helper
INFO - 2019-12-02 16:43:04 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:43:04 --> Helper loaded: email_helper
INFO - 2019-12-02 16:43:04 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:43:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:43:04 --> Parser Class Initialized
INFO - 2019-12-02 16:43:04 --> User Agent Class Initialized
INFO - 2019-12-02 16:43:05 --> Model Class Initialized
INFO - 2019-12-02 16:43:05 --> Database Driver Class Initialized
INFO - 2019-12-02 16:43:05 --> Model Class Initialized
DEBUG - 2019-12-02 16:43:05 --> Template Class Initialized
INFO - 2019-12-02 16:43:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:43:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:43:05 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:43:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:43:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:43:05 --> Encryption Class Initialized
INFO - 2019-12-02 16:43:05 --> Controller Class Initialized
DEBUG - 2019-12-02 16:43:05 --> order MX_Controller Initialized
DEBUG - 2019-12-02 16:43:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-02 16:43:05 --> Model Class Initialized
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "order_basic_details"
INFO - 2019-12-02 16:43:05 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:43:05 --> Could not find the language line "Pending"
DEBUG - 2019-12-02 16:43:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-02 16:43:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:43:05 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:43:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:43:05 --> Model Class Initialized
DEBUG - 2019-12-02 16:43:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:43:05 --> Model Class Initialized
DEBUG - 2019-12-02 16:43:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:43:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:43:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:43:05 --> Final output sent to browser
DEBUG - 2019-12-02 16:43:05 --> Total execution time: 0.9264
INFO - 2019-12-02 16:46:08 --> Config Class Initialized
INFO - 2019-12-02 16:46:08 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:46:08 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:46:08 --> Utf8 Class Initialized
INFO - 2019-12-02 16:46:08 --> URI Class Initialized
INFO - 2019-12-02 16:46:08 --> Router Class Initialized
INFO - 2019-12-02 16:46:08 --> Output Class Initialized
INFO - 2019-12-02 16:46:08 --> Security Class Initialized
DEBUG - 2019-12-02 16:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:46:08 --> CSRF cookie sent
INFO - 2019-12-02 16:46:08 --> Input Class Initialized
INFO - 2019-12-02 16:46:08 --> Language Class Initialized
INFO - 2019-12-02 16:46:08 --> Language Class Initialized
INFO - 2019-12-02 16:46:08 --> Config Class Initialized
INFO - 2019-12-02 16:46:08 --> Loader Class Initialized
INFO - 2019-12-02 16:46:08 --> Helper loaded: url_helper
INFO - 2019-12-02 16:46:08 --> Helper loaded: common_helper
INFO - 2019-12-02 16:46:08 --> Helper loaded: language_helper
INFO - 2019-12-02 16:46:08 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:46:08 --> Helper loaded: email_helper
INFO - 2019-12-02 16:46:08 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:46:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:46:09 --> Parser Class Initialized
INFO - 2019-12-02 16:46:09 --> User Agent Class Initialized
INFO - 2019-12-02 16:46:09 --> Model Class Initialized
INFO - 2019-12-02 16:46:09 --> Database Driver Class Initialized
INFO - 2019-12-02 16:46:09 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:09 --> Template Class Initialized
INFO - 2019-12-02 16:46:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:46:09 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:46:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:46:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:46:09 --> Encryption Class Initialized
INFO - 2019-12-02 16:46:09 --> Controller Class Initialized
DEBUG - 2019-12-02 16:46:09 --> package MX_Controller Initialized
DEBUG - 2019-12-02 16:46:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-02 16:46:09 --> Model Class Initialized
INFO - 2019-12-02 16:46:09 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:46:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:46:09 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:46:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:46:09 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:46:09 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-02 16:46:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-02 16:46:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:46:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:46:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:46:09 --> Final output sent to browser
DEBUG - 2019-12-02 16:46:09 --> Total execution time: 0.6970
INFO - 2019-12-02 16:46:13 --> Config Class Initialized
INFO - 2019-12-02 16:46:13 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:46:13 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:46:13 --> Utf8 Class Initialized
INFO - 2019-12-02 16:46:13 --> URI Class Initialized
INFO - 2019-12-02 16:46:13 --> Router Class Initialized
INFO - 2019-12-02 16:46:13 --> Output Class Initialized
INFO - 2019-12-02 16:46:13 --> Security Class Initialized
DEBUG - 2019-12-02 16:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:46:13 --> CSRF cookie sent
INFO - 2019-12-02 16:46:13 --> CSRF token verified
INFO - 2019-12-02 16:46:13 --> Input Class Initialized
INFO - 2019-12-02 16:46:13 --> Language Class Initialized
INFO - 2019-12-02 16:46:13 --> Language Class Initialized
INFO - 2019-12-02 16:46:13 --> Config Class Initialized
INFO - 2019-12-02 16:46:13 --> Loader Class Initialized
INFO - 2019-12-02 16:46:13 --> Helper loaded: url_helper
INFO - 2019-12-02 16:46:13 --> Helper loaded: common_helper
INFO - 2019-12-02 16:46:13 --> Helper loaded: language_helper
INFO - 2019-12-02 16:46:13 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:46:13 --> Helper loaded: email_helper
INFO - 2019-12-02 16:46:13 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:46:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:46:13 --> Parser Class Initialized
INFO - 2019-12-02 16:46:13 --> User Agent Class Initialized
INFO - 2019-12-02 16:46:13 --> Model Class Initialized
INFO - 2019-12-02 16:46:13 --> Database Driver Class Initialized
INFO - 2019-12-02 16:46:13 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:13 --> Template Class Initialized
INFO - 2019-12-02 16:46:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:46:13 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:46:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:46:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:46:13 --> Encryption Class Initialized
INFO - 2019-12-02 16:46:13 --> Controller Class Initialized
DEBUG - 2019-12-02 16:46:13 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:46:13 --> Model Class Initialized
INFO - 2019-12-02 16:46:13 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:46:13 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:46:13 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:46:13 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:46:13 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:46:13 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:46:13 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:46:14 --> Final output sent to browser
DEBUG - 2019-12-02 16:46:14 --> Total execution time: 0.8394
INFO - 2019-12-02 16:46:20 --> Config Class Initialized
INFO - 2019-12-02 16:46:20 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:46:21 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:46:21 --> Utf8 Class Initialized
INFO - 2019-12-02 16:46:21 --> URI Class Initialized
INFO - 2019-12-02 16:46:21 --> Router Class Initialized
INFO - 2019-12-02 16:46:21 --> Output Class Initialized
INFO - 2019-12-02 16:46:21 --> Security Class Initialized
DEBUG - 2019-12-02 16:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:46:21 --> CSRF cookie sent
INFO - 2019-12-02 16:46:21 --> CSRF token verified
INFO - 2019-12-02 16:46:21 --> Input Class Initialized
INFO - 2019-12-02 16:46:21 --> Language Class Initialized
INFO - 2019-12-02 16:46:21 --> Language Class Initialized
INFO - 2019-12-02 16:46:21 --> Config Class Initialized
INFO - 2019-12-02 16:46:21 --> Loader Class Initialized
INFO - 2019-12-02 16:46:21 --> Helper loaded: url_helper
INFO - 2019-12-02 16:46:21 --> Helper loaded: common_helper
INFO - 2019-12-02 16:46:21 --> Helper loaded: language_helper
INFO - 2019-12-02 16:46:21 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:46:21 --> Helper loaded: email_helper
INFO - 2019-12-02 16:46:21 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:46:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:46:21 --> Parser Class Initialized
INFO - 2019-12-02 16:46:21 --> User Agent Class Initialized
INFO - 2019-12-02 16:46:21 --> Model Class Initialized
INFO - 2019-12-02 16:46:21 --> Database Driver Class Initialized
INFO - 2019-12-02 16:46:21 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:21 --> Template Class Initialized
INFO - 2019-12-02 16:46:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:46:21 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:46:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:46:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:46:21 --> Encryption Class Initialized
INFO - 2019-12-02 16:46:21 --> Controller Class Initialized
DEBUG - 2019-12-02 16:46:21 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:46:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:46:21 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:21 --> hesabe MX_Controller Initialized
DEBUG - 2019-12-02 16:46:22 --> orders MX_Controller Initialized
DEBUG - 2019-12-02 16:46:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/hesabe/index.php
INFO - 2019-12-02 16:46:22 --> Final output sent to browser
DEBUG - 2019-12-02 16:46:22 --> Total execution time: 1.1567
INFO - 2019-12-02 16:46:53 --> Config Class Initialized
INFO - 2019-12-02 16:46:53 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:46:53 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:46:53 --> Utf8 Class Initialized
INFO - 2019-12-02 16:46:53 --> URI Class Initialized
INFO - 2019-12-02 16:46:53 --> Router Class Initialized
INFO - 2019-12-02 16:46:53 --> Output Class Initialized
INFO - 2019-12-02 16:46:53 --> Security Class Initialized
DEBUG - 2019-12-02 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:46:53 --> CSRF cookie sent
INFO - 2019-12-02 16:46:53 --> Input Class Initialized
INFO - 2019-12-02 16:46:53 --> Language Class Initialized
INFO - 2019-12-02 16:46:53 --> Language Class Initialized
INFO - 2019-12-02 16:46:53 --> Config Class Initialized
INFO - 2019-12-02 16:46:53 --> Loader Class Initialized
INFO - 2019-12-02 16:46:53 --> Helper loaded: url_helper
INFO - 2019-12-02 16:46:53 --> Helper loaded: common_helper
INFO - 2019-12-02 16:46:53 --> Helper loaded: language_helper
INFO - 2019-12-02 16:46:53 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:46:53 --> Helper loaded: email_helper
INFO - 2019-12-02 16:46:53 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:46:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:46:54 --> Parser Class Initialized
INFO - 2019-12-02 16:46:54 --> User Agent Class Initialized
INFO - 2019-12-02 16:46:54 --> Model Class Initialized
INFO - 2019-12-02 16:46:54 --> Database Driver Class Initialized
INFO - 2019-12-02 16:46:54 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:54 --> Template Class Initialized
INFO - 2019-12-02 16:46:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:46:54 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:46:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:46:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:46:54 --> Encryption Class Initialized
INFO - 2019-12-02 16:46:54 --> Controller Class Initialized
DEBUG - 2019-12-02 16:46:54 --> order MX_Controller Initialized
DEBUG - 2019-12-02 16:46:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-02 16:46:54 --> Model Class Initialized
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "order_basic_details"
INFO - 2019-12-02 16:46:54 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:46:54 --> Could not find the language line "Awaiting"
DEBUG - 2019-12-02 16:46:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-02 16:46:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:46:54 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:46:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:46:54 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:46:54 --> Model Class Initialized
DEBUG - 2019-12-02 16:46:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:46:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:46:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:46:54 --> Final output sent to browser
DEBUG - 2019-12-02 16:46:54 --> Total execution time: 0.9379
INFO - 2019-12-02 16:47:05 --> Config Class Initialized
INFO - 2019-12-02 16:47:05 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:47:05 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:47:05 --> Utf8 Class Initialized
INFO - 2019-12-02 16:47:05 --> URI Class Initialized
INFO - 2019-12-02 16:47:05 --> Router Class Initialized
INFO - 2019-12-02 16:47:05 --> Output Class Initialized
INFO - 2019-12-02 16:47:05 --> Security Class Initialized
DEBUG - 2019-12-02 16:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:47:05 --> Input Class Initialized
INFO - 2019-12-02 16:47:05 --> Language Class Initialized
INFO - 2019-12-02 16:47:05 --> Language Class Initialized
INFO - 2019-12-02 16:47:05 --> Config Class Initialized
INFO - 2019-12-02 16:47:05 --> Loader Class Initialized
INFO - 2019-12-02 16:47:05 --> Helper loaded: url_helper
INFO - 2019-12-02 16:47:05 --> Helper loaded: common_helper
INFO - 2019-12-02 16:47:05 --> Helper loaded: language_helper
INFO - 2019-12-02 16:47:05 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:47:05 --> Helper loaded: email_helper
INFO - 2019-12-02 16:47:05 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:47:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:47:05 --> Parser Class Initialized
INFO - 2019-12-02 16:47:05 --> User Agent Class Initialized
INFO - 2019-12-02 16:47:05 --> Model Class Initialized
INFO - 2019-12-02 16:47:05 --> Database Driver Class Initialized
INFO - 2019-12-02 16:47:05 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:05 --> Template Class Initialized
INFO - 2019-12-02 16:47:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:47:05 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:47:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:47:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:47:05 --> Encryption Class Initialized
INFO - 2019-12-02 16:47:05 --> Controller Class Initialized
DEBUG - 2019-12-02 16:47:05 --> custom_page MX_Controller Initialized
DEBUG - 2019-12-02 16:47:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-12-02 16:47:05 --> Model Class Initialized
INFO - 2019-12-02 16:47:05 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:47:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-12-02 16:47:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-12-02 16:47:05 --> Final output sent to browser
DEBUG - 2019-12-02 16:47:05 --> Total execution time: 0.5022
INFO - 2019-12-02 16:47:05 --> Config Class Initialized
INFO - 2019-12-02 16:47:05 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:47:05 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:47:05 --> Utf8 Class Initialized
INFO - 2019-12-02 16:47:05 --> URI Class Initialized
INFO - 2019-12-02 16:47:05 --> Router Class Initialized
INFO - 2019-12-02 16:47:05 --> Output Class Initialized
INFO - 2019-12-02 16:47:05 --> Security Class Initialized
DEBUG - 2019-12-02 16:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:47:05 --> CSRF cookie sent
INFO - 2019-12-02 16:47:05 --> Input Class Initialized
INFO - 2019-12-02 16:47:06 --> Language Class Initialized
INFO - 2019-12-02 16:47:06 --> Language Class Initialized
INFO - 2019-12-02 16:47:06 --> Config Class Initialized
INFO - 2019-12-02 16:47:06 --> Loader Class Initialized
INFO - 2019-12-02 16:47:06 --> Helper loaded: url_helper
INFO - 2019-12-02 16:47:06 --> Helper loaded: common_helper
INFO - 2019-12-02 16:47:06 --> Helper loaded: language_helper
INFO - 2019-12-02 16:47:06 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:47:06 --> Helper loaded: email_helper
INFO - 2019-12-02 16:47:06 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:47:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:47:06 --> Parser Class Initialized
INFO - 2019-12-02 16:47:06 --> User Agent Class Initialized
INFO - 2019-12-02 16:47:06 --> Model Class Initialized
INFO - 2019-12-02 16:47:06 --> Database Driver Class Initialized
INFO - 2019-12-02 16:47:06 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:06 --> Template Class Initialized
INFO - 2019-12-02 16:47:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:47:06 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:47:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:47:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:47:06 --> Encryption Class Initialized
INFO - 2019-12-02 16:47:06 --> Controller Class Initialized
DEBUG - 2019-12-02 16:47:06 --> custom_page MX_Controller Initialized
DEBUG - 2019-12-02 16:47:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-12-02 16:47:06 --> Model Class Initialized
INFO - 2019-12-02 16:47:06 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:47:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-12-02 16:47:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-12-02 16:47:06 --> Final output sent to browser
DEBUG - 2019-12-02 16:47:06 --> Total execution time: 0.5220
INFO - 2019-12-02 16:47:33 --> Config Class Initialized
INFO - 2019-12-02 16:47:33 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:47:33 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:47:33 --> Utf8 Class Initialized
INFO - 2019-12-02 16:47:33 --> URI Class Initialized
INFO - 2019-12-02 16:47:33 --> Router Class Initialized
INFO - 2019-12-02 16:47:33 --> Output Class Initialized
INFO - 2019-12-02 16:47:33 --> Security Class Initialized
DEBUG - 2019-12-02 16:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:47:33 --> Input Class Initialized
INFO - 2019-12-02 16:47:33 --> Language Class Initialized
INFO - 2019-12-02 16:47:33 --> Language Class Initialized
INFO - 2019-12-02 16:47:33 --> Config Class Initialized
INFO - 2019-12-02 16:47:33 --> Loader Class Initialized
INFO - 2019-12-02 16:47:33 --> Helper loaded: url_helper
INFO - 2019-12-02 16:47:33 --> Helper loaded: common_helper
INFO - 2019-12-02 16:47:33 --> Helper loaded: language_helper
INFO - 2019-12-02 16:47:33 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:47:33 --> Helper loaded: email_helper
INFO - 2019-12-02 16:47:33 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:47:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:47:33 --> Parser Class Initialized
INFO - 2019-12-02 16:47:33 --> User Agent Class Initialized
INFO - 2019-12-02 16:47:33 --> Model Class Initialized
INFO - 2019-12-02 16:47:34 --> Database Driver Class Initialized
INFO - 2019-12-02 16:47:34 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:34 --> Template Class Initialized
INFO - 2019-12-02 16:47:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:47:34 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:47:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:47:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:47:34 --> Encryption Class Initialized
INFO - 2019-12-02 16:47:34 --> Controller Class Initialized
DEBUG - 2019-12-02 16:47:34 --> hesabe MX_Controller Initialized
INFO - 2019-12-02 16:47:34 --> Model Class Initialized
INFO - 2019-12-02 16:47:34 --> Config Class Initialized
INFO - 2019-12-02 16:47:34 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:47:34 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:47:34 --> Utf8 Class Initialized
INFO - 2019-12-02 16:47:34 --> URI Class Initialized
INFO - 2019-12-02 16:47:34 --> Router Class Initialized
INFO - 2019-12-02 16:47:34 --> Output Class Initialized
INFO - 2019-12-02 16:47:34 --> Security Class Initialized
DEBUG - 2019-12-02 16:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:47:34 --> CSRF cookie sent
INFO - 2019-12-02 16:47:34 --> Input Class Initialized
INFO - 2019-12-02 16:47:34 --> Language Class Initialized
INFO - 2019-12-02 16:47:34 --> Language Class Initialized
INFO - 2019-12-02 16:47:34 --> Config Class Initialized
INFO - 2019-12-02 16:47:34 --> Loader Class Initialized
INFO - 2019-12-02 16:47:34 --> Helper loaded: url_helper
INFO - 2019-12-02 16:47:34 --> Helper loaded: common_helper
INFO - 2019-12-02 16:47:34 --> Helper loaded: language_helper
INFO - 2019-12-02 16:47:34 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:47:34 --> Helper loaded: email_helper
INFO - 2019-12-02 16:47:34 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:47:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:47:34 --> Parser Class Initialized
INFO - 2019-12-02 16:47:34 --> User Agent Class Initialized
INFO - 2019-12-02 16:47:34 --> Model Class Initialized
INFO - 2019-12-02 16:47:34 --> Database Driver Class Initialized
INFO - 2019-12-02 16:47:34 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:34 --> Template Class Initialized
INFO - 2019-12-02 16:47:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:47:34 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:47:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:47:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:47:34 --> Encryption Class Initialized
INFO - 2019-12-02 16:47:34 --> Controller Class Initialized
DEBUG - 2019-12-02 16:47:34 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:47:34 --> Model Class Initialized
INFO - 2019-12-02 16:47:34 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-12-02 16:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:47:34 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:47:34 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:47:34 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:47:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:47:34 --> Final output sent to browser
DEBUG - 2019-12-02 16:47:34 --> Total execution time: 0.6509
INFO - 2019-12-02 16:47:39 --> Config Class Initialized
INFO - 2019-12-02 16:47:39 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:47:39 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:47:39 --> Utf8 Class Initialized
INFO - 2019-12-02 16:47:39 --> URI Class Initialized
INFO - 2019-12-02 16:47:39 --> Router Class Initialized
INFO - 2019-12-02 16:47:39 --> Output Class Initialized
INFO - 2019-12-02 16:47:40 --> Security Class Initialized
DEBUG - 2019-12-02 16:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:47:40 --> CSRF cookie sent
INFO - 2019-12-02 16:47:40 --> Input Class Initialized
INFO - 2019-12-02 16:47:40 --> Language Class Initialized
INFO - 2019-12-02 16:47:40 --> Language Class Initialized
INFO - 2019-12-02 16:47:40 --> Config Class Initialized
INFO - 2019-12-02 16:47:40 --> Loader Class Initialized
INFO - 2019-12-02 16:47:40 --> Helper loaded: url_helper
INFO - 2019-12-02 16:47:40 --> Helper loaded: common_helper
INFO - 2019-12-02 16:47:40 --> Helper loaded: language_helper
INFO - 2019-12-02 16:47:40 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:47:40 --> Helper loaded: email_helper
INFO - 2019-12-02 16:47:40 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:47:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:47:40 --> Parser Class Initialized
INFO - 2019-12-02 16:47:40 --> User Agent Class Initialized
INFO - 2019-12-02 16:47:40 --> Model Class Initialized
INFO - 2019-12-02 16:47:40 --> Database Driver Class Initialized
INFO - 2019-12-02 16:47:40 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:40 --> Template Class Initialized
INFO - 2019-12-02 16:47:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:47:40 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:47:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:47:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:47:40 --> Encryption Class Initialized
INFO - 2019-12-02 16:47:40 --> Controller Class Initialized
DEBUG - 2019-12-02 16:47:40 --> order MX_Controller Initialized
DEBUG - 2019-12-02 16:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-02 16:47:40 --> Model Class Initialized
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "order_id"
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "order_basic_details"
INFO - 2019-12-02 16:47:40 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "Pending"
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "Awaiting"
ERROR - 2019-12-02 16:47:40 --> Could not find the language line "Awaiting"
DEBUG - 2019-12-02 16:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-02 16:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:47:40 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:47:40 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:47:40 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:47:40 --> Final output sent to browser
DEBUG - 2019-12-02 16:47:40 --> Total execution time: 0.9419
INFO - 2019-12-02 16:47:45 --> Config Class Initialized
INFO - 2019-12-02 16:47:45 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:47:45 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:47:45 --> Utf8 Class Initialized
INFO - 2019-12-02 16:47:45 --> URI Class Initialized
INFO - 2019-12-02 16:47:45 --> Router Class Initialized
INFO - 2019-12-02 16:47:45 --> Output Class Initialized
INFO - 2019-12-02 16:47:45 --> Security Class Initialized
DEBUG - 2019-12-02 16:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:47:45 --> CSRF cookie sent
INFO - 2019-12-02 16:47:45 --> Input Class Initialized
INFO - 2019-12-02 16:47:45 --> Language Class Initialized
INFO - 2019-12-02 16:47:45 --> Language Class Initialized
INFO - 2019-12-02 16:47:45 --> Config Class Initialized
INFO - 2019-12-02 16:47:45 --> Loader Class Initialized
INFO - 2019-12-02 16:47:45 --> Helper loaded: url_helper
INFO - 2019-12-02 16:47:45 --> Helper loaded: common_helper
INFO - 2019-12-02 16:47:45 --> Helper loaded: language_helper
INFO - 2019-12-02 16:47:45 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:47:45 --> Helper loaded: email_helper
INFO - 2019-12-02 16:47:45 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:47:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:47:45 --> Parser Class Initialized
INFO - 2019-12-02 16:47:45 --> User Agent Class Initialized
INFO - 2019-12-02 16:47:45 --> Model Class Initialized
INFO - 2019-12-02 16:47:45 --> Database Driver Class Initialized
INFO - 2019-12-02 16:47:45 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:45 --> Template Class Initialized
INFO - 2019-12-02 16:47:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:47:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:47:45 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:47:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:47:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:47:45 --> Encryption Class Initialized
INFO - 2019-12-02 16:47:45 --> Controller Class Initialized
DEBUG - 2019-12-02 16:47:45 --> transactions MX_Controller Initialized
DEBUG - 2019-12-02 16:47:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-02 16:47:45 --> Model Class Initialized
ERROR - 2019-12-02 16:47:45 --> Could not find the language line "order_id"
INFO - 2019-12-02 16:47:45 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:47:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-02 16:47:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:47:45 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:47:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:47:45 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:47:45 --> Model Class Initialized
DEBUG - 2019-12-02 16:47:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-02 16:47:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-02 16:47:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-02 16:47:45 --> Final output sent to browser
DEBUG - 2019-12-02 16:47:45 --> Total execution time: 0.7125
INFO - 2019-12-02 16:51:20 --> Config Class Initialized
INFO - 2019-12-02 16:51:20 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:51:20 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:51:20 --> Utf8 Class Initialized
INFO - 2019-12-02 16:51:20 --> URI Class Initialized
INFO - 2019-12-02 16:51:20 --> Router Class Initialized
INFO - 2019-12-02 16:51:20 --> Output Class Initialized
INFO - 2019-12-02 16:51:20 --> Security Class Initialized
DEBUG - 2019-12-02 16:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:51:20 --> CSRF cookie sent
INFO - 2019-12-02 16:51:20 --> Input Class Initialized
INFO - 2019-12-02 16:51:20 --> Language Class Initialized
INFO - 2019-12-02 16:51:20 --> Language Class Initialized
INFO - 2019-12-02 16:51:20 --> Config Class Initialized
INFO - 2019-12-02 16:51:20 --> Loader Class Initialized
INFO - 2019-12-02 16:51:20 --> Helper loaded: url_helper
INFO - 2019-12-02 16:51:20 --> Helper loaded: common_helper
INFO - 2019-12-02 16:51:20 --> Helper loaded: language_helper
INFO - 2019-12-02 16:51:20 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:51:20 --> Helper loaded: email_helper
INFO - 2019-12-02 16:51:20 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:51:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:51:20 --> Parser Class Initialized
INFO - 2019-12-02 16:51:20 --> User Agent Class Initialized
INFO - 2019-12-02 16:51:20 --> Model Class Initialized
INFO - 2019-12-02 16:51:20 --> Database Driver Class Initialized
INFO - 2019-12-02 16:51:21 --> Model Class Initialized
DEBUG - 2019-12-02 16:51:21 --> Template Class Initialized
INFO - 2019-12-02 16:51:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:51:21 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:51:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:51:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:51:21 --> Encryption Class Initialized
INFO - 2019-12-02 16:51:21 --> Controller Class Initialized
DEBUG - 2019-12-02 16:51:21 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:51:21 --> Model Class Initialized
ERROR - 2019-12-02 16:51:21 --> Severity: Notice --> Undefined variable: ids D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\checkout.php 133
INFO - 2019-12-02 16:51:21 --> Config Class Initialized
INFO - 2019-12-02 16:51:21 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:51:21 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:51:21 --> Utf8 Class Initialized
INFO - 2019-12-02 16:51:21 --> URI Class Initialized
DEBUG - 2019-12-02 16:51:21 --> No URI present. Default controller set.
INFO - 2019-12-02 16:51:21 --> Router Class Initialized
INFO - 2019-12-02 16:51:21 --> Output Class Initialized
INFO - 2019-12-02 16:51:21 --> Security Class Initialized
DEBUG - 2019-12-02 16:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:51:21 --> CSRF cookie sent
INFO - 2019-12-02 16:51:21 --> Input Class Initialized
INFO - 2019-12-02 16:51:21 --> Language Class Initialized
INFO - 2019-12-02 16:51:21 --> Language Class Initialized
INFO - 2019-12-02 16:51:21 --> Config Class Initialized
INFO - 2019-12-02 16:51:21 --> Loader Class Initialized
INFO - 2019-12-02 16:51:21 --> Helper loaded: url_helper
INFO - 2019-12-02 16:51:21 --> Helper loaded: common_helper
INFO - 2019-12-02 16:51:21 --> Helper loaded: language_helper
INFO - 2019-12-02 16:51:21 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:51:21 --> Helper loaded: email_helper
INFO - 2019-12-02 16:51:21 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:51:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:51:21 --> Parser Class Initialized
INFO - 2019-12-02 16:51:21 --> User Agent Class Initialized
INFO - 2019-12-02 16:51:21 --> Model Class Initialized
INFO - 2019-12-02 16:51:21 --> Database Driver Class Initialized
INFO - 2019-12-02 16:51:21 --> Model Class Initialized
DEBUG - 2019-12-02 16:51:21 --> Template Class Initialized
INFO - 2019-12-02 16:51:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:51:21 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:51:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:51:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:51:21 --> Encryption Class Initialized
DEBUG - 2019-12-02 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-02 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-02 16:51:21 --> Controller Class Initialized
DEBUG - 2019-12-02 16:51:21 --> pergo MX_Controller Initialized
DEBUG - 2019-12-02 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-02 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-02 16:51:21 --> Model Class Initialized
INFO - 2019-12-02 16:51:21 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-02 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-02 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-02 16:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-02 16:51:21 --> Final output sent to browser
DEBUG - 2019-12-02 16:51:21 --> Total execution time: 0.7032
INFO - 2019-12-02 16:51:24 --> Config Class Initialized
INFO - 2019-12-02 16:51:24 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:51:24 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:51:24 --> Utf8 Class Initialized
INFO - 2019-12-02 16:51:24 --> URI Class Initialized
INFO - 2019-12-02 16:51:24 --> Router Class Initialized
INFO - 2019-12-02 16:51:24 --> Output Class Initialized
INFO - 2019-12-02 16:51:24 --> Security Class Initialized
DEBUG - 2019-12-02 16:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:51:24 --> CSRF cookie sent
INFO - 2019-12-02 16:51:24 --> Input Class Initialized
INFO - 2019-12-02 16:51:24 --> Language Class Initialized
INFO - 2019-12-02 16:51:24 --> Language Class Initialized
INFO - 2019-12-02 16:51:24 --> Config Class Initialized
INFO - 2019-12-02 16:51:24 --> Loader Class Initialized
INFO - 2019-12-02 16:51:24 --> Helper loaded: url_helper
INFO - 2019-12-02 16:51:24 --> Helper loaded: common_helper
INFO - 2019-12-02 16:51:24 --> Helper loaded: language_helper
INFO - 2019-12-02 16:51:24 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:51:24 --> Helper loaded: email_helper
INFO - 2019-12-02 16:51:24 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:51:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:51:24 --> Parser Class Initialized
INFO - 2019-12-02 16:51:24 --> User Agent Class Initialized
INFO - 2019-12-02 16:51:24 --> Model Class Initialized
INFO - 2019-12-02 16:51:24 --> Database Driver Class Initialized
INFO - 2019-12-02 16:51:24 --> Model Class Initialized
DEBUG - 2019-12-02 16:51:24 --> Template Class Initialized
INFO - 2019-12-02 16:51:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:51:24 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:51:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:51:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:51:24 --> Encryption Class Initialized
INFO - 2019-12-02 16:51:24 --> Controller Class Initialized
DEBUG - 2019-12-02 16:51:24 --> package MX_Controller Initialized
DEBUG - 2019-12-02 16:51:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-02 16:51:24 --> Model Class Initialized
INFO - 2019-12-02 16:51:24 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 16:51:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:51:24 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:51:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:51:24 --> Model Class Initialized
DEBUG - 2019-12-02 16:51:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:51:24 --> Model Class Initialized
DEBUG - 2019-12-02 16:51:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-02 16:51:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-02 16:51:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:51:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:51:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:51:25 --> Final output sent to browser
DEBUG - 2019-12-02 16:51:25 --> Total execution time: 0.8992
INFO - 2019-12-02 16:51:27 --> Config Class Initialized
INFO - 2019-12-02 16:51:27 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:51:27 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:51:27 --> Utf8 Class Initialized
INFO - 2019-12-02 16:51:27 --> URI Class Initialized
INFO - 2019-12-02 16:51:27 --> Router Class Initialized
INFO - 2019-12-02 16:51:27 --> Output Class Initialized
INFO - 2019-12-02 16:51:27 --> Security Class Initialized
DEBUG - 2019-12-02 16:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:51:27 --> CSRF cookie sent
INFO - 2019-12-02 16:51:27 --> CSRF token verified
INFO - 2019-12-02 16:51:27 --> Input Class Initialized
INFO - 2019-12-02 16:51:27 --> Language Class Initialized
INFO - 2019-12-02 16:51:27 --> Language Class Initialized
INFO - 2019-12-02 16:51:27 --> Config Class Initialized
INFO - 2019-12-02 16:51:27 --> Loader Class Initialized
INFO - 2019-12-02 16:51:27 --> Helper loaded: url_helper
INFO - 2019-12-02 16:51:27 --> Helper loaded: common_helper
INFO - 2019-12-02 16:51:28 --> Helper loaded: language_helper
INFO - 2019-12-02 16:51:28 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:51:28 --> Helper loaded: email_helper
INFO - 2019-12-02 16:51:28 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:51:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:51:28 --> Parser Class Initialized
INFO - 2019-12-02 16:51:28 --> User Agent Class Initialized
INFO - 2019-12-02 16:51:28 --> Model Class Initialized
INFO - 2019-12-02 16:51:28 --> Database Driver Class Initialized
INFO - 2019-12-02 16:51:28 --> Model Class Initialized
DEBUG - 2019-12-02 16:51:28 --> Template Class Initialized
INFO - 2019-12-02 16:51:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:51:28 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:51:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:51:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:51:28 --> Encryption Class Initialized
INFO - 2019-12-02 16:51:28 --> Controller Class Initialized
DEBUG - 2019-12-02 16:51:28 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:51:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:51:28 --> Model Class Initialized
INFO - 2019-12-02 16:51:28 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:51:28 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:51:28 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:51:28 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:51:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:51:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:51:28 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:51:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:51:28 --> Model Class Initialized
DEBUG - 2019-12-02 16:51:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:51:28 --> Model Class Initialized
DEBUG - 2019-12-02 16:51:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:51:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:51:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:51:28 --> Final output sent to browser
DEBUG - 2019-12-02 16:51:28 --> Total execution time: 0.8317
INFO - 2019-12-02 16:52:09 --> Config Class Initialized
INFO - 2019-12-02 16:52:09 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:52:09 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:52:09 --> Utf8 Class Initialized
INFO - 2019-12-02 16:52:09 --> URI Class Initialized
INFO - 2019-12-02 16:52:09 --> Router Class Initialized
INFO - 2019-12-02 16:52:09 --> Output Class Initialized
INFO - 2019-12-02 16:52:09 --> Security Class Initialized
DEBUG - 2019-12-02 16:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:52:09 --> CSRF cookie sent
INFO - 2019-12-02 16:52:09 --> CSRF token verified
INFO - 2019-12-02 16:52:09 --> Input Class Initialized
INFO - 2019-12-02 16:52:09 --> Language Class Initialized
INFO - 2019-12-02 16:52:09 --> Language Class Initialized
INFO - 2019-12-02 16:52:09 --> Config Class Initialized
INFO - 2019-12-02 16:52:10 --> Loader Class Initialized
INFO - 2019-12-02 16:52:10 --> Helper loaded: url_helper
INFO - 2019-12-02 16:52:10 --> Helper loaded: common_helper
INFO - 2019-12-02 16:52:10 --> Helper loaded: language_helper
INFO - 2019-12-02 16:52:10 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:52:10 --> Helper loaded: email_helper
INFO - 2019-12-02 16:52:10 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:52:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:52:10 --> Parser Class Initialized
INFO - 2019-12-02 16:52:10 --> User Agent Class Initialized
INFO - 2019-12-02 16:52:10 --> Model Class Initialized
INFO - 2019-12-02 16:52:10 --> Database Driver Class Initialized
INFO - 2019-12-02 16:52:10 --> Model Class Initialized
DEBUG - 2019-12-02 16:52:10 --> Template Class Initialized
INFO - 2019-12-02 16:52:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:52:10 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:52:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:52:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:52:10 --> Encryption Class Initialized
INFO - 2019-12-02 16:52:10 --> Controller Class Initialized
DEBUG - 2019-12-02 16:52:10 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:52:10 --> Model Class Initialized
INFO - 2019-12-02 16:52:10 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:52:10 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:52:10 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:52:10 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:52:10 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:52:10 --> Model Class Initialized
DEBUG - 2019-12-02 16:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:52:10 --> Model Class Initialized
DEBUG - 2019-12-02 16:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:52:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:52:10 --> Final output sent to browser
DEBUG - 2019-12-02 16:52:10 --> Total execution time: 0.7929
INFO - 2019-12-02 16:52:55 --> Config Class Initialized
INFO - 2019-12-02 16:52:55 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:52:55 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:52:55 --> Utf8 Class Initialized
INFO - 2019-12-02 16:52:55 --> URI Class Initialized
INFO - 2019-12-02 16:52:55 --> Router Class Initialized
INFO - 2019-12-02 16:52:55 --> Output Class Initialized
INFO - 2019-12-02 16:52:55 --> Security Class Initialized
DEBUG - 2019-12-02 16:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:52:55 --> CSRF cookie sent
INFO - 2019-12-02 16:52:55 --> CSRF token verified
INFO - 2019-12-02 16:52:55 --> Input Class Initialized
INFO - 2019-12-02 16:52:55 --> Language Class Initialized
INFO - 2019-12-02 16:52:55 --> Language Class Initialized
INFO - 2019-12-02 16:52:55 --> Config Class Initialized
INFO - 2019-12-02 16:52:55 --> Loader Class Initialized
INFO - 2019-12-02 16:52:55 --> Helper loaded: url_helper
INFO - 2019-12-02 16:52:55 --> Helper loaded: common_helper
INFO - 2019-12-02 16:52:55 --> Helper loaded: language_helper
INFO - 2019-12-02 16:52:55 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:52:55 --> Helper loaded: email_helper
INFO - 2019-12-02 16:52:55 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:52:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:52:55 --> Parser Class Initialized
INFO - 2019-12-02 16:52:55 --> User Agent Class Initialized
INFO - 2019-12-02 16:52:55 --> Model Class Initialized
INFO - 2019-12-02 16:52:55 --> Database Driver Class Initialized
INFO - 2019-12-02 16:52:55 --> Model Class Initialized
DEBUG - 2019-12-02 16:52:55 --> Template Class Initialized
INFO - 2019-12-02 16:52:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:52:55 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:52:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:52:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:52:55 --> Encryption Class Initialized
INFO - 2019-12-02 16:52:55 --> Controller Class Initialized
DEBUG - 2019-12-02 16:52:55 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:52:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:52:55 --> Model Class Initialized
INFO - 2019-12-02 16:52:55 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:52:55 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:52:55 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:52:55 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:52:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:52:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:52:55 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:52:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:52:55 --> Model Class Initialized
DEBUG - 2019-12-02 16:52:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:52:55 --> Model Class Initialized
DEBUG - 2019-12-02 16:52:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:52:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:52:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:52:55 --> Final output sent to browser
DEBUG - 2019-12-02 16:52:55 --> Total execution time: 0.7595
INFO - 2019-12-02 16:53:52 --> Config Class Initialized
INFO - 2019-12-02 16:53:52 --> Hooks Class Initialized
DEBUG - 2019-12-02 16:53:52 --> UTF-8 Support Enabled
INFO - 2019-12-02 16:53:52 --> Utf8 Class Initialized
INFO - 2019-12-02 16:53:52 --> URI Class Initialized
INFO - 2019-12-02 16:53:52 --> Router Class Initialized
INFO - 2019-12-02 16:53:52 --> Output Class Initialized
INFO - 2019-12-02 16:53:52 --> Security Class Initialized
DEBUG - 2019-12-02 16:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 16:53:52 --> CSRF cookie sent
INFO - 2019-12-02 16:53:52 --> CSRF token verified
INFO - 2019-12-02 16:53:52 --> Input Class Initialized
INFO - 2019-12-02 16:53:52 --> Language Class Initialized
INFO - 2019-12-02 16:53:52 --> Language Class Initialized
INFO - 2019-12-02 16:53:52 --> Config Class Initialized
INFO - 2019-12-02 16:53:52 --> Loader Class Initialized
INFO - 2019-12-02 16:53:52 --> Helper loaded: url_helper
INFO - 2019-12-02 16:53:52 --> Helper loaded: common_helper
INFO - 2019-12-02 16:53:52 --> Helper loaded: language_helper
INFO - 2019-12-02 16:53:52 --> Helper loaded: cookie_helper
INFO - 2019-12-02 16:53:52 --> Helper loaded: email_helper
INFO - 2019-12-02 16:53:52 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 16:53:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 16:53:52 --> Parser Class Initialized
INFO - 2019-12-02 16:53:52 --> User Agent Class Initialized
INFO - 2019-12-02 16:53:52 --> Model Class Initialized
INFO - 2019-12-02 16:53:52 --> Database Driver Class Initialized
INFO - 2019-12-02 16:53:52 --> Model Class Initialized
DEBUG - 2019-12-02 16:53:52 --> Template Class Initialized
INFO - 2019-12-02 16:53:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 16:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 16:53:52 --> Pagination Class Initialized
DEBUG - 2019-12-02 16:53:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 16:53:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 16:53:52 --> Encryption Class Initialized
INFO - 2019-12-02 16:53:52 --> Controller Class Initialized
DEBUG - 2019-12-02 16:53:52 --> checkout MX_Controller Initialized
DEBUG - 2019-12-02 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-02 16:53:52 --> Model Class Initialized
INFO - 2019-12-02 16:53:52 --> Helper loaded: inflector_helper
ERROR - 2019-12-02 16:53:52 --> Could not find the language line "hesabe"
ERROR - 2019-12-02 16:53:52 --> Could not find the language line "payop"
ERROR - 2019-12-02 16:53:52 --> Could not find the language line "shopier"
DEBUG - 2019-12-02 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-02 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-02 16:53:52 --> blocks MX_Controller Initialized
DEBUG - 2019-12-02 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-02 16:53:52 --> Model Class Initialized
DEBUG - 2019-12-02 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-02 16:53:52 --> Model Class Initialized
DEBUG - 2019-12-02 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-02 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-02 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-02 16:53:52 --> Final output sent to browser
DEBUG - 2019-12-02 16:53:52 --> Total execution time: 0.8042
INFO - 2019-12-02 19:59:51 --> Config Class Initialized
INFO - 2019-12-02 19:59:51 --> Hooks Class Initialized
DEBUG - 2019-12-02 19:59:51 --> UTF-8 Support Enabled
INFO - 2019-12-02 19:59:51 --> Utf8 Class Initialized
INFO - 2019-12-02 19:59:51 --> URI Class Initialized
DEBUG - 2019-12-02 19:59:51 --> No URI present. Default controller set.
INFO - 2019-12-02 19:59:51 --> Router Class Initialized
INFO - 2019-12-02 19:59:51 --> Output Class Initialized
INFO - 2019-12-02 19:59:51 --> Security Class Initialized
DEBUG - 2019-12-02 19:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-02 19:59:51 --> CSRF cookie sent
INFO - 2019-12-02 19:59:51 --> Input Class Initialized
INFO - 2019-12-02 19:59:51 --> Language Class Initialized
INFO - 2019-12-02 19:59:51 --> Language Class Initialized
INFO - 2019-12-02 19:59:51 --> Config Class Initialized
INFO - 2019-12-02 19:59:51 --> Loader Class Initialized
INFO - 2019-12-02 19:59:51 --> Helper loaded: url_helper
INFO - 2019-12-02 19:59:51 --> Helper loaded: common_helper
INFO - 2019-12-02 19:59:52 --> Helper loaded: language_helper
INFO - 2019-12-02 19:59:52 --> Helper loaded: cookie_helper
INFO - 2019-12-02 19:59:52 --> Helper loaded: email_helper
INFO - 2019-12-02 19:59:52 --> Helper loaded: file_manager_helper
INFO - 2019-12-02 19:59:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-02 19:59:52 --> Parser Class Initialized
INFO - 2019-12-02 19:59:52 --> User Agent Class Initialized
INFO - 2019-12-02 19:59:52 --> Model Class Initialized
INFO - 2019-12-02 19:59:52 --> Database Driver Class Initialized
INFO - 2019-12-02 19:59:52 --> Model Class Initialized
DEBUG - 2019-12-02 19:59:52 --> Template Class Initialized
INFO - 2019-12-02 19:59:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-02 19:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-02 19:59:52 --> Pagination Class Initialized
DEBUG - 2019-12-02 19:59:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-02 19:59:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-02 19:59:52 --> Encryption Class Initialized
DEBUG - 2019-12-02 19:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-02 19:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-02 19:59:52 --> Controller Class Initialized
DEBUG - 2019-12-02 19:59:52 --> pergo MX_Controller Initialized
DEBUG - 2019-12-02 19:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-02 19:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-02 19:59:52 --> Model Class Initialized
INFO - 2019-12-02 19:59:52 --> Helper loaded: inflector_helper
DEBUG - 2019-12-02 19:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-02 19:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-02 19:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-02 19:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-02 19:59:52 --> Final output sent to browser
DEBUG - 2019-12-02 19:59:53 --> Total execution time: 1.4953
