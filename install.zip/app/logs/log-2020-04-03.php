<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-03 17:34:55 --> Config Class Initialized
INFO - 2020-04-03 17:34:55 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:34:56 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:34:56 --> Utf8 Class Initialized
INFO - 2020-04-03 17:34:56 --> URI Class Initialized
INFO - 2020-04-03 17:34:56 --> Router Class Initialized
INFO - 2020-04-03 17:34:56 --> Output Class Initialized
INFO - 2020-04-03 17:34:56 --> Security Class Initialized
DEBUG - 2020-04-03 17:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:34:56 --> CSRF cookie sent
INFO - 2020-04-03 17:34:56 --> Input Class Initialized
INFO - 2020-04-03 17:34:56 --> Language Class Initialized
INFO - 2020-04-03 17:34:56 --> Language Class Initialized
INFO - 2020-04-03 17:34:56 --> Config Class Initialized
INFO - 2020-04-03 17:34:56 --> Loader Class Initialized
INFO - 2020-04-03 17:34:56 --> Helper loaded: url_helper
INFO - 2020-04-03 17:34:56 --> Helper loaded: file_helper
INFO - 2020-04-03 17:34:56 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:34:56 --> Helper loaded: common_helper
INFO - 2020-04-03 17:34:56 --> Helper loaded: language_helper
INFO - 2020-04-03 17:34:56 --> Helper loaded: email_helper
INFO - 2020-04-03 17:34:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:34:56 --> Database Driver Class Initialized
INFO - 2020-04-03 17:34:56 --> Parser Class Initialized
INFO - 2020-04-03 17:34:56 --> User Agent Class Initialized
INFO - 2020-04-03 17:34:56 --> Model Class Initialized
INFO - 2020-04-03 17:34:56 --> Model Class Initialized
DEBUG - 2020-04-03 17:34:56 --> Template Class Initialized
INFO - 2020-04-03 17:34:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:34:56 --> Email Class Initialized
INFO - 2020-04-03 17:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:34:56 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:34:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:34:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:34:57 --> Encryption Class Initialized
INFO - 2020-04-03 17:34:57 --> Controller Class Initialized
DEBUG - 2020-04-03 17:34:57 --> follow MX_Controller Initialized
ERROR - 2020-04-03 17:34:57 --> Query error: Table 'tuyen_twitter.general_options' doesn't exist - Invalid query: SELECT `value`
FROM `general_options`
WHERE `name` = 'is_maintenance_mode'
INFO - 2020-04-03 17:34:57 --> Language file loaded: language/english/db_lang.php
INFO - 2020-04-03 17:35:43 --> Config Class Initialized
INFO - 2020-04-03 17:35:43 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:35:43 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:35:43 --> Utf8 Class Initialized
INFO - 2020-04-03 17:35:43 --> URI Class Initialized
INFO - 2020-04-03 17:35:43 --> Router Class Initialized
INFO - 2020-04-03 17:35:43 --> Output Class Initialized
INFO - 2020-04-03 17:35:43 --> Security Class Initialized
DEBUG - 2020-04-03 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:35:43 --> CSRF cookie sent
INFO - 2020-04-03 17:35:43 --> Input Class Initialized
INFO - 2020-04-03 17:35:43 --> Language Class Initialized
INFO - 2020-04-03 17:35:43 --> Language Class Initialized
INFO - 2020-04-03 17:35:43 --> Config Class Initialized
INFO - 2020-04-03 17:35:43 --> Loader Class Initialized
INFO - 2020-04-03 17:35:43 --> Helper loaded: url_helper
INFO - 2020-04-03 17:35:43 --> Helper loaded: file_helper
INFO - 2020-04-03 17:35:43 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:35:43 --> Helper loaded: common_helper
INFO - 2020-04-03 17:35:43 --> Helper loaded: language_helper
INFO - 2020-04-03 17:35:43 --> Helper loaded: email_helper
INFO - 2020-04-03 17:35:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:35:43 --> Database Driver Class Initialized
INFO - 2020-04-03 17:35:43 --> Parser Class Initialized
INFO - 2020-04-03 17:35:43 --> User Agent Class Initialized
INFO - 2020-04-03 17:35:43 --> Model Class Initialized
INFO - 2020-04-03 17:35:43 --> Model Class Initialized
DEBUG - 2020-04-03 17:35:43 --> Template Class Initialized
INFO - 2020-04-03 17:35:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:35:43 --> Email Class Initialized
INFO - 2020-04-03 17:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:35:43 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:35:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:35:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:35:43 --> Encryption Class Initialized
INFO - 2020-04-03 17:35:43 --> Controller Class Initialized
DEBUG - 2020-04-03 17:35:43 --> follow MX_Controller Initialized
ERROR - 2020-04-03 17:35:43 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT `value`
FROM `options`
WHERE `name` = 'is_maintenance_mode'
INFO - 2020-04-03 17:35:43 --> Language file loaded: language/english/db_lang.php
INFO - 2020-04-03 17:37:52 --> Config Class Initialized
INFO - 2020-04-03 17:37:52 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:37:52 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:37:52 --> Utf8 Class Initialized
INFO - 2020-04-03 17:37:52 --> URI Class Initialized
INFO - 2020-04-03 17:37:52 --> Router Class Initialized
INFO - 2020-04-03 17:37:52 --> Output Class Initialized
INFO - 2020-04-03 17:37:52 --> Security Class Initialized
DEBUG - 2020-04-03 17:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:37:52 --> CSRF cookie sent
INFO - 2020-04-03 17:37:52 --> Input Class Initialized
INFO - 2020-04-03 17:37:52 --> Language Class Initialized
INFO - 2020-04-03 17:37:52 --> Language Class Initialized
INFO - 2020-04-03 17:37:52 --> Config Class Initialized
INFO - 2020-04-03 17:37:52 --> Loader Class Initialized
INFO - 2020-04-03 17:37:52 --> Helper loaded: url_helper
INFO - 2020-04-03 17:37:52 --> Helper loaded: file_helper
INFO - 2020-04-03 17:37:52 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:37:52 --> Helper loaded: common_helper
INFO - 2020-04-03 17:37:52 --> Helper loaded: language_helper
INFO - 2020-04-03 17:37:52 --> Helper loaded: email_helper
INFO - 2020-04-03 17:37:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:37:52 --> Database Driver Class Initialized
INFO - 2020-04-03 17:37:52 --> Parser Class Initialized
INFO - 2020-04-03 17:37:52 --> User Agent Class Initialized
INFO - 2020-04-03 17:37:52 --> Model Class Initialized
INFO - 2020-04-03 17:37:52 --> Model Class Initialized
DEBUG - 2020-04-03 17:37:52 --> Template Class Initialized
INFO - 2020-04-03 17:37:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:37:52 --> Email Class Initialized
INFO - 2020-04-03 17:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:37:52 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:37:52 --> Encryption Class Initialized
INFO - 2020-04-03 17:37:52 --> Controller Class Initialized
DEBUG - 2020-04-03 17:37:52 --> follow MX_Controller Initialized
INFO - 2020-04-03 17:37:52 --> Model Class Initialized
ERROR - 2020-04-03 17:37:52 --> Severity: error --> Exception: Call to undefined method follow::__get_current_user_data() D:\xampp\htdocs\projects\tuyen\twitter\code\app\third_party\MX\Controller.php 76
INFO - 2020-04-03 17:38:14 --> Config Class Initialized
INFO - 2020-04-03 17:38:14 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:38:14 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:38:14 --> Utf8 Class Initialized
INFO - 2020-04-03 17:38:14 --> URI Class Initialized
INFO - 2020-04-03 17:38:14 --> Router Class Initialized
INFO - 2020-04-03 17:38:14 --> Output Class Initialized
INFO - 2020-04-03 17:38:14 --> Security Class Initialized
DEBUG - 2020-04-03 17:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:38:14 --> CSRF cookie sent
INFO - 2020-04-03 17:38:14 --> Input Class Initialized
INFO - 2020-04-03 17:38:14 --> Language Class Initialized
INFO - 2020-04-03 17:38:14 --> Language Class Initialized
INFO - 2020-04-03 17:38:14 --> Config Class Initialized
INFO - 2020-04-03 17:38:14 --> Loader Class Initialized
INFO - 2020-04-03 17:38:14 --> Helper loaded: url_helper
INFO - 2020-04-03 17:38:14 --> Helper loaded: file_helper
INFO - 2020-04-03 17:38:14 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:38:14 --> Helper loaded: common_helper
INFO - 2020-04-03 17:38:14 --> Helper loaded: language_helper
INFO - 2020-04-03 17:38:14 --> Helper loaded: email_helper
INFO - 2020-04-03 17:38:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:38:14 --> Database Driver Class Initialized
INFO - 2020-04-03 17:38:14 --> Parser Class Initialized
INFO - 2020-04-03 17:38:14 --> User Agent Class Initialized
INFO - 2020-04-03 17:38:14 --> Model Class Initialized
INFO - 2020-04-03 17:38:14 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:14 --> Template Class Initialized
INFO - 2020-04-03 17:38:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:38:14 --> Email Class Initialized
INFO - 2020-04-03 17:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:38:14 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:38:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:38:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:38:14 --> Encryption Class Initialized
INFO - 2020-04-03 17:38:14 --> Controller Class Initialized
DEBUG - 2020-04-03 17:38:14 --> follow MX_Controller Initialized
INFO - 2020-04-03 17:38:14 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-03 17:38:14 --> Model Class Initialized
INFO - 2020-04-03 17:38:14 --> Helper loaded: inflector_helper
DEBUG - 2020-04-03 17:38:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/setting.php
DEBUG - 2020-04-03 17:38:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/content.php
DEBUG - 2020-04-03 17:38:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-03 17:38:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-03 17:38:15 --> blocks MX_Controller Initialized
DEBUG - 2020-04-03 17:38:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-03 17:38:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-03 17:38:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-03 17:38:15 --> Final output sent to browser
DEBUG - 2020-04-03 17:38:15 --> Total execution time: 0.6464
INFO - 2020-04-03 17:38:18 --> Config Class Initialized
INFO - 2020-04-03 17:38:18 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:38:18 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:38:18 --> Utf8 Class Initialized
INFO - 2020-04-03 17:38:18 --> URI Class Initialized
INFO - 2020-04-03 17:38:18 --> Router Class Initialized
INFO - 2020-04-03 17:38:18 --> Output Class Initialized
INFO - 2020-04-03 17:38:18 --> Security Class Initialized
DEBUG - 2020-04-03 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:38:18 --> CSRF cookie sent
INFO - 2020-04-03 17:38:18 --> Input Class Initialized
INFO - 2020-04-03 17:38:18 --> Language Class Initialized
INFO - 2020-04-03 17:38:18 --> Language Class Initialized
INFO - 2020-04-03 17:38:18 --> Config Class Initialized
INFO - 2020-04-03 17:38:18 --> Loader Class Initialized
INFO - 2020-04-03 17:38:18 --> Helper loaded: url_helper
INFO - 2020-04-03 17:38:18 --> Helper loaded: file_helper
INFO - 2020-04-03 17:38:18 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:38:18 --> Helper loaded: common_helper
INFO - 2020-04-03 17:38:18 --> Helper loaded: language_helper
INFO - 2020-04-03 17:38:18 --> Helper loaded: email_helper
INFO - 2020-04-03 17:38:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:38:18 --> Database Driver Class Initialized
INFO - 2020-04-03 17:38:18 --> Parser Class Initialized
INFO - 2020-04-03 17:38:19 --> User Agent Class Initialized
INFO - 2020-04-03 17:38:19 --> Model Class Initialized
INFO - 2020-04-03 17:38:19 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:19 --> Template Class Initialized
INFO - 2020-04-03 17:38:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:38:19 --> Email Class Initialized
INFO - 2020-04-03 17:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:38:19 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:38:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:38:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:38:19 --> Encryption Class Initialized
INFO - 2020-04-03 17:38:19 --> Controller Class Initialized
DEBUG - 2020-04-03 17:38:19 --> profile MX_Controller Initialized
INFO - 2020-04-03 17:38:19 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/profile/models/profile_model.php
INFO - 2020-04-03 17:38:19 --> Model Class Initialized
INFO - 2020-04-03 17:38:19 --> Helper loaded: inflector_helper
DEBUG - 2020-04-03 17:38:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/profile/views/index.php
DEBUG - 2020-04-03 17:38:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-03 17:38:19 --> blocks MX_Controller Initialized
DEBUG - 2020-04-03 17:38:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-03 17:38:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-03 17:38:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-03 17:38:19 --> Final output sent to browser
DEBUG - 2020-04-03 17:38:19 --> Total execution time: 0.6751
INFO - 2020-04-03 17:38:22 --> Config Class Initialized
INFO - 2020-04-03 17:38:22 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:38:22 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:38:22 --> Utf8 Class Initialized
INFO - 2020-04-03 17:38:22 --> URI Class Initialized
INFO - 2020-04-03 17:38:22 --> Router Class Initialized
INFO - 2020-04-03 17:38:22 --> Output Class Initialized
INFO - 2020-04-03 17:38:22 --> Security Class Initialized
DEBUG - 2020-04-03 17:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:38:22 --> CSRF cookie sent
INFO - 2020-04-03 17:38:22 --> Input Class Initialized
INFO - 2020-04-03 17:38:22 --> Language Class Initialized
INFO - 2020-04-03 17:38:22 --> Language Class Initialized
INFO - 2020-04-03 17:38:22 --> Config Class Initialized
INFO - 2020-04-03 17:38:22 --> Loader Class Initialized
INFO - 2020-04-03 17:38:22 --> Helper loaded: url_helper
INFO - 2020-04-03 17:38:22 --> Helper loaded: file_helper
INFO - 2020-04-03 17:38:22 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:38:22 --> Helper loaded: common_helper
INFO - 2020-04-03 17:38:22 --> Helper loaded: language_helper
INFO - 2020-04-03 17:38:22 --> Helper loaded: email_helper
INFO - 2020-04-03 17:38:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:38:22 --> Database Driver Class Initialized
INFO - 2020-04-03 17:38:22 --> Parser Class Initialized
INFO - 2020-04-03 17:38:22 --> User Agent Class Initialized
INFO - 2020-04-03 17:38:22 --> Model Class Initialized
INFO - 2020-04-03 17:38:22 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:22 --> Template Class Initialized
INFO - 2020-04-03 17:38:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:38:22 --> Email Class Initialized
INFO - 2020-04-03 17:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:38:22 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:38:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:38:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:38:22 --> Encryption Class Initialized
INFO - 2020-04-03 17:38:22 --> Controller Class Initialized
DEBUG - 2020-04-03 17:38:22 --> dashboard MX_Controller Initialized
INFO - 2020-04-03 17:38:22 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-03 17:38:22 --> Model Class Initialized
INFO - 2020-04-03 17:38:22 --> Helper loaded: inflector_helper
DEBUG - 2020-04-03 17:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-03 17:38:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-03 17:38:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-03 17:38:23 --> blocks MX_Controller Initialized
DEBUG - 2020-04-03 17:38:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-03 17:38:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-03 17:38:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-03 17:38:23 --> Final output sent to browser
DEBUG - 2020-04-03 17:38:23 --> Total execution time: 0.6060
INFO - 2020-04-03 17:38:24 --> Config Class Initialized
INFO - 2020-04-03 17:38:24 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:38:24 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:38:24 --> Utf8 Class Initialized
INFO - 2020-04-03 17:38:24 --> URI Class Initialized
INFO - 2020-04-03 17:38:24 --> Router Class Initialized
INFO - 2020-04-03 17:38:24 --> Output Class Initialized
INFO - 2020-04-03 17:38:24 --> Security Class Initialized
DEBUG - 2020-04-03 17:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:38:24 --> CSRF cookie sent
INFO - 2020-04-03 17:38:24 --> Input Class Initialized
INFO - 2020-04-03 17:38:24 --> Language Class Initialized
INFO - 2020-04-03 17:38:24 --> Language Class Initialized
INFO - 2020-04-03 17:38:24 --> Config Class Initialized
INFO - 2020-04-03 17:38:24 --> Loader Class Initialized
INFO - 2020-04-03 17:38:24 --> Helper loaded: url_helper
INFO - 2020-04-03 17:38:24 --> Helper loaded: file_helper
INFO - 2020-04-03 17:38:24 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:38:24 --> Helper loaded: common_helper
INFO - 2020-04-03 17:38:24 --> Helper loaded: language_helper
INFO - 2020-04-03 17:38:24 --> Helper loaded: email_helper
INFO - 2020-04-03 17:38:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:38:24 --> Database Driver Class Initialized
INFO - 2020-04-03 17:38:24 --> Parser Class Initialized
INFO - 2020-04-03 17:38:24 --> User Agent Class Initialized
INFO - 2020-04-03 17:38:24 --> Model Class Initialized
INFO - 2020-04-03 17:38:24 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:24 --> Template Class Initialized
INFO - 2020-04-03 17:38:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:38:24 --> Email Class Initialized
INFO - 2020-04-03 17:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:38:24 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:38:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:38:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:38:24 --> Encryption Class Initialized
INFO - 2020-04-03 17:38:24 --> Controller Class Initialized
DEBUG - 2020-04-03 17:38:24 --> post MX_Controller Initialized
INFO - 2020-04-03 17:38:24 --> Model Class Initialized
ERROR - 2020-04-03 17:38:25 --> Could not find the language line ""
ERROR - 2020-04-03 17:38:25 --> Could not find the language line ""
ERROR - 2020-04-03 17:38:25 --> Could not find the language line ""
DEBUG - 2020-04-03 17:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-03 17:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-03 17:38:25 --> blocks MX_Controller Initialized
DEBUG - 2020-04-03 17:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-03 17:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-03 17:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-03 17:38:25 --> Final output sent to browser
DEBUG - 2020-04-03 17:38:25 --> Total execution time: 0.5213
INFO - 2020-04-03 17:38:26 --> Config Class Initialized
INFO - 2020-04-03 17:38:26 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:38:26 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:38:26 --> Utf8 Class Initialized
INFO - 2020-04-03 17:38:26 --> URI Class Initialized
INFO - 2020-04-03 17:38:26 --> Router Class Initialized
INFO - 2020-04-03 17:38:26 --> Output Class Initialized
INFO - 2020-04-03 17:38:26 --> Security Class Initialized
DEBUG - 2020-04-03 17:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:38:26 --> CSRF cookie sent
INFO - 2020-04-03 17:38:26 --> Input Class Initialized
INFO - 2020-04-03 17:38:26 --> Language Class Initialized
INFO - 2020-04-03 17:38:26 --> Language Class Initialized
INFO - 2020-04-03 17:38:26 --> Config Class Initialized
INFO - 2020-04-03 17:38:26 --> Loader Class Initialized
INFO - 2020-04-03 17:38:26 --> Helper loaded: url_helper
INFO - 2020-04-03 17:38:26 --> Helper loaded: file_helper
INFO - 2020-04-03 17:38:26 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:38:26 --> Helper loaded: common_helper
INFO - 2020-04-03 17:38:26 --> Helper loaded: language_helper
INFO - 2020-04-03 17:38:26 --> Helper loaded: email_helper
INFO - 2020-04-03 17:38:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:38:26 --> Database Driver Class Initialized
INFO - 2020-04-03 17:38:26 --> Parser Class Initialized
INFO - 2020-04-03 17:38:26 --> User Agent Class Initialized
INFO - 2020-04-03 17:38:26 --> Model Class Initialized
INFO - 2020-04-03 17:38:26 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:26 --> Template Class Initialized
INFO - 2020-04-03 17:38:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:38:26 --> Email Class Initialized
INFO - 2020-04-03 17:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:38:26 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:38:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:38:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:38:26 --> Encryption Class Initialized
INFO - 2020-04-03 17:38:26 --> Controller Class Initialized
DEBUG - 2020-04-03 17:38:26 --> dashboard MX_Controller Initialized
INFO - 2020-04-03 17:38:26 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-03 17:38:26 --> Model Class Initialized
INFO - 2020-04-03 17:38:26 --> Helper loaded: inflector_helper
DEBUG - 2020-04-03 17:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-03 17:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-03 17:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-03 17:38:26 --> blocks MX_Controller Initialized
DEBUG - 2020-04-03 17:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-03 17:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-03 17:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-03 17:38:26 --> Final output sent to browser
DEBUG - 2020-04-03 17:38:26 --> Total execution time: 0.5832
INFO - 2020-04-03 17:38:28 --> Config Class Initialized
INFO - 2020-04-03 17:38:28 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:38:28 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:38:28 --> Utf8 Class Initialized
INFO - 2020-04-03 17:38:28 --> URI Class Initialized
INFO - 2020-04-03 17:38:28 --> Router Class Initialized
INFO - 2020-04-03 17:38:28 --> Output Class Initialized
INFO - 2020-04-03 17:38:28 --> Security Class Initialized
DEBUG - 2020-04-03 17:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:38:28 --> CSRF cookie sent
INFO - 2020-04-03 17:38:28 --> Input Class Initialized
INFO - 2020-04-03 17:38:28 --> Language Class Initialized
INFO - 2020-04-03 17:38:28 --> Language Class Initialized
INFO - 2020-04-03 17:38:28 --> Config Class Initialized
INFO - 2020-04-03 17:38:28 --> Loader Class Initialized
INFO - 2020-04-03 17:38:28 --> Helper loaded: url_helper
INFO - 2020-04-03 17:38:28 --> Helper loaded: file_helper
INFO - 2020-04-03 17:38:28 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:38:28 --> Helper loaded: common_helper
INFO - 2020-04-03 17:38:28 --> Helper loaded: language_helper
INFO - 2020-04-03 17:38:28 --> Helper loaded: email_helper
INFO - 2020-04-03 17:38:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:38:28 --> Database Driver Class Initialized
INFO - 2020-04-03 17:38:28 --> Parser Class Initialized
INFO - 2020-04-03 17:38:28 --> User Agent Class Initialized
INFO - 2020-04-03 17:38:28 --> Model Class Initialized
INFO - 2020-04-03 17:38:28 --> Model Class Initialized
DEBUG - 2020-04-03 17:38:28 --> Template Class Initialized
INFO - 2020-04-03 17:38:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:38:28 --> Email Class Initialized
INFO - 2020-04-03 17:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:38:28 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:38:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:38:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:38:28 --> Encryption Class Initialized
INFO - 2020-04-03 17:38:28 --> Controller Class Initialized
DEBUG - 2020-04-03 17:38:28 --> post MX_Controller Initialized
INFO - 2020-04-03 17:38:28 --> Model Class Initialized
ERROR - 2020-04-03 17:38:28 --> Could not find the language line ""
ERROR - 2020-04-03 17:38:28 --> Could not find the language line ""
ERROR - 2020-04-03 17:38:28 --> Could not find the language line ""
DEBUG - 2020-04-03 17:38:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-03 17:38:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-03 17:38:28 --> blocks MX_Controller Initialized
DEBUG - 2020-04-03 17:38:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-03 17:38:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-03 17:38:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-03 17:38:28 --> Final output sent to browser
DEBUG - 2020-04-03 17:38:28 --> Total execution time: 0.5243
INFO - 2020-04-03 17:40:04 --> Config Class Initialized
INFO - 2020-04-03 17:40:04 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:40:04 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:40:04 --> Utf8 Class Initialized
INFO - 2020-04-03 17:40:04 --> URI Class Initialized
INFO - 2020-04-03 17:40:04 --> Router Class Initialized
INFO - 2020-04-03 17:40:04 --> Output Class Initialized
INFO - 2020-04-03 17:40:04 --> Security Class Initialized
DEBUG - 2020-04-03 17:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:40:04 --> CSRF cookie sent
INFO - 2020-04-03 17:40:04 --> Input Class Initialized
INFO - 2020-04-03 17:40:04 --> Language Class Initialized
INFO - 2020-04-03 17:40:04 --> Language Class Initialized
INFO - 2020-04-03 17:40:04 --> Config Class Initialized
INFO - 2020-04-03 17:40:04 --> Loader Class Initialized
INFO - 2020-04-03 17:40:04 --> Helper loaded: url_helper
INFO - 2020-04-03 17:40:04 --> Helper loaded: file_helper
INFO - 2020-04-03 17:40:04 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:40:04 --> Helper loaded: common_helper
INFO - 2020-04-03 17:40:04 --> Helper loaded: language_helper
INFO - 2020-04-03 17:40:04 --> Helper loaded: email_helper
INFO - 2020-04-03 17:40:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:40:04 --> Database Driver Class Initialized
INFO - 2020-04-03 17:40:04 --> Parser Class Initialized
INFO - 2020-04-03 17:40:04 --> User Agent Class Initialized
INFO - 2020-04-03 17:40:04 --> Model Class Initialized
INFO - 2020-04-03 17:40:04 --> Model Class Initialized
DEBUG - 2020-04-03 17:40:04 --> Template Class Initialized
INFO - 2020-04-03 17:40:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:40:04 --> Email Class Initialized
INFO - 2020-04-03 17:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:40:04 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:40:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:40:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:40:04 --> Encryption Class Initialized
INFO - 2020-04-03 17:40:04 --> Controller Class Initialized
DEBUG - 2020-04-03 17:40:05 --> schedule MX_Controller Initialized
INFO - 2020-04-03 17:40:05 --> Model Class Initialized
DEBUG - 2020-04-03 17:40:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/models/schedule_model.php
INFO - 2020-04-03 17:40:05 --> Model Class Initialized
DEBUG - 2020-04-03 17:40:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/views/index.php
DEBUG - 2020-04-03 17:40:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-03 17:40:05 --> blocks MX_Controller Initialized
DEBUG - 2020-04-03 17:40:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-03 17:40:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-03 17:40:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-03 17:40:05 --> Final output sent to browser
DEBUG - 2020-04-03 17:40:05 --> Total execution time: 0.5497
INFO - 2020-04-03 17:40:07 --> Config Class Initialized
INFO - 2020-04-03 17:40:07 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:40:07 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:40:07 --> Utf8 Class Initialized
INFO - 2020-04-03 17:40:07 --> URI Class Initialized
INFO - 2020-04-03 17:40:07 --> Router Class Initialized
INFO - 2020-04-03 17:40:07 --> Output Class Initialized
INFO - 2020-04-03 17:40:07 --> Security Class Initialized
DEBUG - 2020-04-03 17:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:40:07 --> CSRF cookie sent
INFO - 2020-04-03 17:40:07 --> Input Class Initialized
INFO - 2020-04-03 17:40:07 --> Language Class Initialized
INFO - 2020-04-03 17:40:07 --> Language Class Initialized
INFO - 2020-04-03 17:40:07 --> Config Class Initialized
INFO - 2020-04-03 17:40:07 --> Loader Class Initialized
INFO - 2020-04-03 17:40:07 --> Helper loaded: url_helper
INFO - 2020-04-03 17:40:07 --> Helper loaded: file_helper
INFO - 2020-04-03 17:40:07 --> Helper loaded: cookie_helper
INFO - 2020-04-03 17:40:07 --> Helper loaded: common_helper
INFO - 2020-04-03 17:40:07 --> Helper loaded: language_helper
INFO - 2020-04-03 17:40:07 --> Helper loaded: email_helper
INFO - 2020-04-03 17:40:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-03 17:40:07 --> Database Driver Class Initialized
INFO - 2020-04-03 17:40:07 --> Parser Class Initialized
INFO - 2020-04-03 17:40:07 --> User Agent Class Initialized
INFO - 2020-04-03 17:40:07 --> Model Class Initialized
INFO - 2020-04-03 17:40:07 --> Model Class Initialized
DEBUG - 2020-04-03 17:40:07 --> Template Class Initialized
INFO - 2020-04-03 17:40:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-03 17:40:07 --> Email Class Initialized
INFO - 2020-04-03 17:40:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-03 17:40:07 --> Pagination Class Initialized
DEBUG - 2020-04-03 17:40:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-03 17:40:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-03 17:40:07 --> Encryption Class Initialized
INFO - 2020-04-03 17:40:07 --> Controller Class Initialized
DEBUG - 2020-04-03 17:40:07 --> follow MX_Controller Initialized
INFO - 2020-04-03 17:40:07 --> Model Class Initialized
DEBUG - 2020-04-03 17:40:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-03 17:40:07 --> Model Class Initialized
INFO - 2020-04-03 17:40:07 --> Helper loaded: inflector_helper
DEBUG - 2020-04-03 17:40:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-03 17:40:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-03 17:40:07 --> blocks MX_Controller Initialized
DEBUG - 2020-04-03 17:40:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-03 17:40:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-03 17:40:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-03 17:40:07 --> Final output sent to browser
DEBUG - 2020-04-03 17:40:07 --> Total execution time: 0.5133
INFO - 2020-04-03 17:40:10 --> Config Class Initialized
INFO - 2020-04-03 17:40:10 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:40:10 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:40:10 --> Utf8 Class Initialized
INFO - 2020-04-03 17:40:10 --> URI Class Initialized
INFO - 2020-04-03 17:40:10 --> Router Class Initialized
INFO - 2020-04-03 17:40:10 --> Output Class Initialized
INFO - 2020-04-03 17:40:10 --> Security Class Initialized
DEBUG - 2020-04-03 17:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:40:10 --> CSRF cookie sent
INFO - 2020-04-03 17:40:10 --> Input Class Initialized
INFO - 2020-04-03 17:40:10 --> Language Class Initialized
ERROR - 2020-04-03 17:40:10 --> 404 Page Not Found: /index
INFO - 2020-04-03 17:40:10 --> Config Class Initialized
INFO - 2020-04-03 17:40:10 --> Config Class Initialized
INFO - 2020-04-03 17:40:10 --> Config Class Initialized
INFO - 2020-04-03 17:40:10 --> Config Class Initialized
INFO - 2020-04-03 17:40:10 --> Hooks Class Initialized
INFO - 2020-04-03 17:40:10 --> Hooks Class Initialized
INFO - 2020-04-03 17:40:10 --> Hooks Class Initialized
INFO - 2020-04-03 17:40:10 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:40:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-03 17:40:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-03 17:40:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-03 17:40:10 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:40:10 --> Utf8 Class Initialized
INFO - 2020-04-03 17:40:10 --> Utf8 Class Initialized
INFO - 2020-04-03 17:40:10 --> Utf8 Class Initialized
INFO - 2020-04-03 17:40:10 --> Utf8 Class Initialized
INFO - 2020-04-03 17:40:10 --> URI Class Initialized
INFO - 2020-04-03 17:40:10 --> URI Class Initialized
INFO - 2020-04-03 17:40:10 --> URI Class Initialized
INFO - 2020-04-03 17:40:10 --> URI Class Initialized
INFO - 2020-04-03 17:40:10 --> Router Class Initialized
INFO - 2020-04-03 17:40:10 --> Router Class Initialized
INFO - 2020-04-03 17:40:10 --> Router Class Initialized
INFO - 2020-04-03 17:40:10 --> Router Class Initialized
INFO - 2020-04-03 17:40:10 --> Output Class Initialized
INFO - 2020-04-03 17:40:10 --> Output Class Initialized
INFO - 2020-04-03 17:40:10 --> Output Class Initialized
INFO - 2020-04-03 17:40:10 --> Output Class Initialized
INFO - 2020-04-03 17:40:10 --> Security Class Initialized
INFO - 2020-04-03 17:40:10 --> Security Class Initialized
INFO - 2020-04-03 17:40:10 --> Security Class Initialized
INFO - 2020-04-03 17:40:10 --> Security Class Initialized
DEBUG - 2020-04-03 17:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-03 17:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-03 17:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-03 17:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:40:10 --> CSRF cookie sent
INFO - 2020-04-03 17:40:10 --> CSRF cookie sent
INFO - 2020-04-03 17:40:10 --> CSRF cookie sent
INFO - 2020-04-03 17:40:10 --> CSRF cookie sent
INFO - 2020-04-03 17:40:10 --> Input Class Initialized
INFO - 2020-04-03 17:40:10 --> Input Class Initialized
INFO - 2020-04-03 17:40:10 --> Input Class Initialized
INFO - 2020-04-03 17:40:10 --> Input Class Initialized
INFO - 2020-04-03 17:40:10 --> Language Class Initialized
INFO - 2020-04-03 17:40:10 --> Language Class Initialized
INFO - 2020-04-03 17:40:10 --> Language Class Initialized
INFO - 2020-04-03 17:40:10 --> Language Class Initialized
ERROR - 2020-04-03 17:40:10 --> 404 Page Not Found: /index
ERROR - 2020-04-03 17:40:10 --> 404 Page Not Found: /index
ERROR - 2020-04-03 17:40:10 --> 404 Page Not Found: /index
ERROR - 2020-04-03 17:40:10 --> 404 Page Not Found: /index
INFO - 2020-04-03 17:40:26 --> Config Class Initialized
INFO - 2020-04-03 17:40:26 --> Config Class Initialized
INFO - 2020-04-03 17:40:26 --> Hooks Class Initialized
INFO - 2020-04-03 17:40:26 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:40:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-03 17:40:26 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:40:26 --> Utf8 Class Initialized
INFO - 2020-04-03 17:40:26 --> Utf8 Class Initialized
INFO - 2020-04-03 17:40:26 --> URI Class Initialized
INFO - 2020-04-03 17:40:26 --> URI Class Initialized
INFO - 2020-04-03 17:40:26 --> Router Class Initialized
INFO - 2020-04-03 17:40:26 --> Router Class Initialized
INFO - 2020-04-03 17:40:26 --> Output Class Initialized
INFO - 2020-04-03 17:40:26 --> Output Class Initialized
INFO - 2020-04-03 17:40:26 --> Security Class Initialized
INFO - 2020-04-03 17:40:26 --> Security Class Initialized
DEBUG - 2020-04-03 17:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-03 17:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:40:26 --> CSRF cookie sent
INFO - 2020-04-03 17:40:26 --> CSRF cookie sent
INFO - 2020-04-03 17:40:26 --> Input Class Initialized
INFO - 2020-04-03 17:40:26 --> Input Class Initialized
INFO - 2020-04-03 17:40:26 --> Language Class Initialized
INFO - 2020-04-03 17:40:26 --> Language Class Initialized
ERROR - 2020-04-03 17:40:26 --> 404 Page Not Found: /index
ERROR - 2020-04-03 17:40:26 --> 404 Page Not Found: /index
INFO - 2020-04-03 17:41:06 --> Config Class Initialized
INFO - 2020-04-03 17:41:06 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:41:06 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:41:06 --> Utf8 Class Initialized
INFO - 2020-04-03 17:41:06 --> URI Class Initialized
INFO - 2020-04-03 17:41:06 --> Router Class Initialized
INFO - 2020-04-03 17:41:06 --> Output Class Initialized
INFO - 2020-04-03 17:41:06 --> Security Class Initialized
DEBUG - 2020-04-03 17:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:41:06 --> CSRF cookie sent
INFO - 2020-04-03 17:41:06 --> Input Class Initialized
INFO - 2020-04-03 17:41:06 --> Language Class Initialized
ERROR - 2020-04-03 17:41:06 --> 404 Page Not Found: /index
INFO - 2020-04-03 17:41:07 --> Config Class Initialized
INFO - 2020-04-03 17:41:07 --> Config Class Initialized
INFO - 2020-04-03 17:41:07 --> Config Class Initialized
INFO - 2020-04-03 17:41:07 --> Hooks Class Initialized
INFO - 2020-04-03 17:41:07 --> Hooks Class Initialized
INFO - 2020-04-03 17:41:07 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:41:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-03 17:41:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-03 17:41:07 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:41:07 --> Utf8 Class Initialized
INFO - 2020-04-03 17:41:07 --> Utf8 Class Initialized
INFO - 2020-04-03 17:41:07 --> Utf8 Class Initialized
INFO - 2020-04-03 17:41:07 --> URI Class Initialized
INFO - 2020-04-03 17:41:07 --> URI Class Initialized
INFO - 2020-04-03 17:41:07 --> URI Class Initialized
INFO - 2020-04-03 17:41:07 --> Router Class Initialized
INFO - 2020-04-03 17:41:07 --> Router Class Initialized
INFO - 2020-04-03 17:41:07 --> Router Class Initialized
INFO - 2020-04-03 17:41:07 --> Output Class Initialized
INFO - 2020-04-03 17:41:07 --> Output Class Initialized
INFO - 2020-04-03 17:41:07 --> Output Class Initialized
INFO - 2020-04-03 17:41:07 --> Security Class Initialized
INFO - 2020-04-03 17:41:07 --> Security Class Initialized
INFO - 2020-04-03 17:41:07 --> Security Class Initialized
DEBUG - 2020-04-03 17:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-03 17:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-03 17:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:41:07 --> CSRF cookie sent
INFO - 2020-04-03 17:41:07 --> CSRF cookie sent
INFO - 2020-04-03 17:41:07 --> CSRF cookie sent
INFO - 2020-04-03 17:41:07 --> Input Class Initialized
INFO - 2020-04-03 17:41:07 --> Input Class Initialized
INFO - 2020-04-03 17:41:07 --> Input Class Initialized
INFO - 2020-04-03 17:41:07 --> Language Class Initialized
INFO - 2020-04-03 17:41:07 --> Language Class Initialized
INFO - 2020-04-03 17:41:07 --> Language Class Initialized
ERROR - 2020-04-03 17:41:07 --> 404 Page Not Found: /index
ERROR - 2020-04-03 17:41:07 --> 404 Page Not Found: /index
ERROR - 2020-04-03 17:41:07 --> 404 Page Not Found: /index
INFO - 2020-04-03 17:41:12 --> Config Class Initialized
INFO - 2020-04-03 17:41:12 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:41:12 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:41:12 --> Utf8 Class Initialized
INFO - 2020-04-03 17:41:12 --> URI Class Initialized
INFO - 2020-04-03 17:41:12 --> Router Class Initialized
INFO - 2020-04-03 17:41:12 --> Output Class Initialized
INFO - 2020-04-03 17:41:12 --> Security Class Initialized
DEBUG - 2020-04-03 17:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:41:12 --> CSRF cookie sent
INFO - 2020-04-03 17:41:12 --> Input Class Initialized
INFO - 2020-04-03 17:41:12 --> Language Class Initialized
ERROR - 2020-04-03 17:41:12 --> 404 Page Not Found: /index
INFO - 2020-04-03 17:41:12 --> Config Class Initialized
INFO - 2020-04-03 17:41:12 --> Config Class Initialized
INFO - 2020-04-03 17:41:12 --> Config Class Initialized
INFO - 2020-04-03 17:41:12 --> Hooks Class Initialized
INFO - 2020-04-03 17:41:12 --> Hooks Class Initialized
INFO - 2020-04-03 17:41:12 --> Hooks Class Initialized
DEBUG - 2020-04-03 17:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-03 17:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-03 17:41:12 --> UTF-8 Support Enabled
INFO - 2020-04-03 17:41:12 --> Utf8 Class Initialized
INFO - 2020-04-03 17:41:12 --> Utf8 Class Initialized
INFO - 2020-04-03 17:41:12 --> Utf8 Class Initialized
INFO - 2020-04-03 17:41:12 --> URI Class Initialized
INFO - 2020-04-03 17:41:12 --> URI Class Initialized
INFO - 2020-04-03 17:41:12 --> URI Class Initialized
INFO - 2020-04-03 17:41:12 --> Router Class Initialized
INFO - 2020-04-03 17:41:12 --> Router Class Initialized
INFO - 2020-04-03 17:41:12 --> Router Class Initialized
INFO - 2020-04-03 17:41:12 --> Output Class Initialized
INFO - 2020-04-03 17:41:12 --> Output Class Initialized
INFO - 2020-04-03 17:41:12 --> Output Class Initialized
INFO - 2020-04-03 17:41:12 --> Security Class Initialized
INFO - 2020-04-03 17:41:12 --> Security Class Initialized
INFO - 2020-04-03 17:41:12 --> Security Class Initialized
DEBUG - 2020-04-03 17:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-03 17:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-03 17:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-03 17:41:12 --> CSRF cookie sent
INFO - 2020-04-03 17:41:12 --> CSRF cookie sent
INFO - 2020-04-03 17:41:12 --> CSRF cookie sent
INFO - 2020-04-03 17:41:12 --> Input Class Initialized
INFO - 2020-04-03 17:41:12 --> Input Class Initialized
INFO - 2020-04-03 17:41:12 --> Input Class Initialized
INFO - 2020-04-03 17:41:12 --> Language Class Initialized
INFO - 2020-04-03 17:41:12 --> Language Class Initialized
INFO - 2020-04-03 17:41:12 --> Language Class Initialized
ERROR - 2020-04-03 17:41:12 --> 404 Page Not Found: /index
ERROR - 2020-04-03 17:41:12 --> 404 Page Not Found: /index
ERROR - 2020-04-03 17:41:12 --> 404 Page Not Found: /index
