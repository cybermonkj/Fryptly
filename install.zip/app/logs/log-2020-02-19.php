<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-19 15:15:54 --> Config Class Initialized
INFO - 2020-02-19 15:15:54 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:15:54 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:15:54 --> Utf8 Class Initialized
INFO - 2020-02-19 15:15:54 --> URI Class Initialized
DEBUG - 2020-02-19 15:15:54 --> No URI present. Default controller set.
INFO - 2020-02-19 15:15:54 --> Router Class Initialized
INFO - 2020-02-19 15:15:54 --> Output Class Initialized
INFO - 2020-02-19 15:15:54 --> Security Class Initialized
DEBUG - 2020-02-19 15:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:15:54 --> CSRF cookie sent
INFO - 2020-02-19 15:15:54 --> Input Class Initialized
INFO - 2020-02-19 15:15:54 --> Language Class Initialized
INFO - 2020-02-19 15:15:54 --> Language Class Initialized
INFO - 2020-02-19 15:15:54 --> Config Class Initialized
INFO - 2020-02-19 15:15:54 --> Loader Class Initialized
INFO - 2020-02-19 15:15:54 --> Helper loaded: url_helper
INFO - 2020-02-19 15:15:54 --> Helper loaded: common_helper
INFO - 2020-02-19 15:15:54 --> Helper loaded: language_helper
INFO - 2020-02-19 15:15:54 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:15:54 --> Helper loaded: email_helper
INFO - 2020-02-19 15:15:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:15:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:15:54 --> Parser Class Initialized
INFO - 2020-02-19 15:15:55 --> User Agent Class Initialized
INFO - 2020-02-19 15:15:55 --> Model Class Initialized
INFO - 2020-02-19 15:15:55 --> Database Driver Class Initialized
INFO - 2020-02-19 15:15:55 --> Model Class Initialized
DEBUG - 2020-02-19 15:15:55 --> Template Class Initialized
INFO - 2020-02-19 15:15:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:15:55 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:15:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:15:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:15:55 --> Encryption Class Initialized
DEBUG - 2020-02-19 15:15:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-19 15:15:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-02-19 15:15:55 --> Controller Class Initialized
DEBUG - 2020-02-19 15:15:55 --> pergo MX_Controller Initialized
DEBUG - 2020-02-19 15:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-02-19 15:15:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-02-19 15:15:58 --> Model Class Initialized
INFO - 2020-02-19 15:15:58 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:15:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-02-19 15:15:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-02-19 15:15:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-02-19 15:15:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-02-19 15:15:58 --> Final output sent to browser
DEBUG - 2020-02-19 15:15:58 --> Total execution time: 4.2680
INFO - 2020-02-19 15:16:02 --> Config Class Initialized
INFO - 2020-02-19 15:16:02 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:16:02 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:16:02 --> Utf8 Class Initialized
INFO - 2020-02-19 15:16:03 --> URI Class Initialized
INFO - 2020-02-19 15:16:03 --> Router Class Initialized
INFO - 2020-02-19 15:16:03 --> Output Class Initialized
INFO - 2020-02-19 15:16:03 --> Security Class Initialized
DEBUG - 2020-02-19 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:16:03 --> CSRF cookie sent
INFO - 2020-02-19 15:16:03 --> Input Class Initialized
INFO - 2020-02-19 15:16:03 --> Language Class Initialized
INFO - 2020-02-19 15:16:03 --> Language Class Initialized
INFO - 2020-02-19 15:16:03 --> Config Class Initialized
INFO - 2020-02-19 15:16:03 --> Loader Class Initialized
INFO - 2020-02-19 15:16:03 --> Helper loaded: url_helper
INFO - 2020-02-19 15:16:03 --> Helper loaded: common_helper
INFO - 2020-02-19 15:16:03 --> Helper loaded: language_helper
INFO - 2020-02-19 15:16:03 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:16:03 --> Helper loaded: email_helper
INFO - 2020-02-19 15:16:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:16:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:16:03 --> Parser Class Initialized
INFO - 2020-02-19 15:16:03 --> User Agent Class Initialized
INFO - 2020-02-19 15:16:03 --> Model Class Initialized
INFO - 2020-02-19 15:16:03 --> Database Driver Class Initialized
INFO - 2020-02-19 15:16:03 --> Model Class Initialized
DEBUG - 2020-02-19 15:16:03 --> Template Class Initialized
INFO - 2020-02-19 15:16:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:16:03 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:16:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:16:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:16:03 --> Encryption Class Initialized
INFO - 2020-02-19 15:16:03 --> Controller Class Initialized
DEBUG - 2020-02-19 15:16:03 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:16:03 --> Model Class Initialized
INFO - 2020-02-19 15:16:03 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:16:03 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:16:03 --> Model Class Initialized
DEBUG - 2020-02-19 15:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:16:03 --> Model Class Initialized
DEBUG - 2020-02-19 15:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:16:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:16:03 --> Final output sent to browser
DEBUG - 2020-02-19 15:16:03 --> Total execution time: 0.9235
INFO - 2020-02-19 15:26:35 --> Config Class Initialized
INFO - 2020-02-19 15:26:35 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:26:35 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:26:35 --> Utf8 Class Initialized
INFO - 2020-02-19 15:26:35 --> URI Class Initialized
INFO - 2020-02-19 15:26:35 --> Router Class Initialized
INFO - 2020-02-19 15:26:35 --> Output Class Initialized
INFO - 2020-02-19 15:26:35 --> Security Class Initialized
DEBUG - 2020-02-19 15:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:26:35 --> CSRF cookie sent
INFO - 2020-02-19 15:26:35 --> Input Class Initialized
INFO - 2020-02-19 15:26:35 --> Language Class Initialized
INFO - 2020-02-19 15:26:35 --> Language Class Initialized
INFO - 2020-02-19 15:26:35 --> Config Class Initialized
INFO - 2020-02-19 15:26:35 --> Loader Class Initialized
INFO - 2020-02-19 15:26:35 --> Helper loaded: url_helper
INFO - 2020-02-19 15:26:35 --> Helper loaded: common_helper
INFO - 2020-02-19 15:26:35 --> Helper loaded: language_helper
INFO - 2020-02-19 15:26:35 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:26:35 --> Helper loaded: email_helper
INFO - 2020-02-19 15:26:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:26:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:26:35 --> Parser Class Initialized
INFO - 2020-02-19 15:26:35 --> User Agent Class Initialized
INFO - 2020-02-19 15:26:35 --> Model Class Initialized
INFO - 2020-02-19 15:26:35 --> Database Driver Class Initialized
INFO - 2020-02-19 15:26:35 --> Model Class Initialized
DEBUG - 2020-02-19 15:26:35 --> Template Class Initialized
INFO - 2020-02-19 15:26:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:26:35 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:26:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:26:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:26:35 --> Encryption Class Initialized
INFO - 2020-02-19 15:26:35 --> Controller Class Initialized
DEBUG - 2020-02-19 15:26:35 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:26:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:26:35 --> Model Class Initialized
INFO - 2020-02-19 15:26:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:26:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:26:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:26:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:26:35 --> Model Class Initialized
DEBUG - 2020-02-19 15:26:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:26:35 --> Model Class Initialized
DEBUG - 2020-02-19 15:26:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:26:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:26:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:26:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:26:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:26:36 --> Final output sent to browser
DEBUG - 2020-02-19 15:26:36 --> Total execution time: 0.5946
INFO - 2020-02-19 15:26:41 --> Config Class Initialized
INFO - 2020-02-19 15:26:41 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:26:41 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:26:41 --> Utf8 Class Initialized
INFO - 2020-02-19 15:26:41 --> URI Class Initialized
INFO - 2020-02-19 15:26:41 --> Router Class Initialized
INFO - 2020-02-19 15:26:41 --> Output Class Initialized
INFO - 2020-02-19 15:26:41 --> Security Class Initialized
DEBUG - 2020-02-19 15:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:26:41 --> CSRF cookie sent
INFO - 2020-02-19 15:26:41 --> Input Class Initialized
INFO - 2020-02-19 15:26:41 --> Language Class Initialized
INFO - 2020-02-19 15:26:41 --> Language Class Initialized
INFO - 2020-02-19 15:26:41 --> Config Class Initialized
INFO - 2020-02-19 15:26:41 --> Loader Class Initialized
INFO - 2020-02-19 15:26:41 --> Helper loaded: url_helper
INFO - 2020-02-19 15:26:41 --> Helper loaded: common_helper
INFO - 2020-02-19 15:26:41 --> Helper loaded: language_helper
INFO - 2020-02-19 15:26:41 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:26:41 --> Helper loaded: email_helper
INFO - 2020-02-19 15:26:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:26:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:26:41 --> Parser Class Initialized
INFO - 2020-02-19 15:26:41 --> User Agent Class Initialized
INFO - 2020-02-19 15:26:41 --> Model Class Initialized
INFO - 2020-02-19 15:26:41 --> Database Driver Class Initialized
INFO - 2020-02-19 15:26:41 --> Model Class Initialized
DEBUG - 2020-02-19 15:26:41 --> Template Class Initialized
INFO - 2020-02-19 15:26:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:26:41 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:26:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:26:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:26:41 --> Encryption Class Initialized
INFO - 2020-02-19 15:26:41 --> Controller Class Initialized
DEBUG - 2020-02-19 15:26:41 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:26:41 --> Model Class Initialized
INFO - 2020-02-19 15:26:41 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:26:41 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:26:41 --> Model Class Initialized
DEBUG - 2020-02-19 15:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:26:41 --> Model Class Initialized
DEBUG - 2020-02-19 15:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:26:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:26:41 --> Final output sent to browser
DEBUG - 2020-02-19 15:26:41 --> Total execution time: 0.6486
INFO - 2020-02-19 15:26:55 --> Config Class Initialized
INFO - 2020-02-19 15:26:55 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:26:55 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:26:56 --> Utf8 Class Initialized
INFO - 2020-02-19 15:26:56 --> URI Class Initialized
INFO - 2020-02-19 15:26:56 --> Router Class Initialized
INFO - 2020-02-19 15:26:56 --> Output Class Initialized
INFO - 2020-02-19 15:26:56 --> Security Class Initialized
DEBUG - 2020-02-19 15:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:26:56 --> CSRF cookie sent
INFO - 2020-02-19 15:26:56 --> Input Class Initialized
INFO - 2020-02-19 15:26:56 --> Language Class Initialized
INFO - 2020-02-19 15:26:56 --> Language Class Initialized
INFO - 2020-02-19 15:26:56 --> Config Class Initialized
INFO - 2020-02-19 15:26:56 --> Loader Class Initialized
INFO - 2020-02-19 15:26:56 --> Helper loaded: url_helper
INFO - 2020-02-19 15:26:56 --> Helper loaded: common_helper
INFO - 2020-02-19 15:26:56 --> Helper loaded: language_helper
INFO - 2020-02-19 15:26:56 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:26:56 --> Helper loaded: email_helper
INFO - 2020-02-19 15:26:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:26:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:26:56 --> Parser Class Initialized
INFO - 2020-02-19 15:26:56 --> User Agent Class Initialized
INFO - 2020-02-19 15:26:56 --> Model Class Initialized
INFO - 2020-02-19 15:26:56 --> Database Driver Class Initialized
INFO - 2020-02-19 15:26:56 --> Model Class Initialized
DEBUG - 2020-02-19 15:26:56 --> Template Class Initialized
INFO - 2020-02-19 15:26:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:26:56 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:26:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:26:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:26:56 --> Encryption Class Initialized
INFO - 2020-02-19 15:26:56 --> Controller Class Initialized
DEBUG - 2020-02-19 15:26:56 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:26:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:26:56 --> Model Class Initialized
INFO - 2020-02-19 15:26:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:26:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:26:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:26:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:26:56 --> Model Class Initialized
DEBUG - 2020-02-19 15:26:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:26:56 --> Model Class Initialized
DEBUG - 2020-02-19 15:26:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:26:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:26:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:26:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:26:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:26:56 --> Final output sent to browser
DEBUG - 2020-02-19 15:26:56 --> Total execution time: 0.6754
INFO - 2020-02-19 15:27:08 --> Config Class Initialized
INFO - 2020-02-19 15:27:08 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:27:08 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:27:08 --> Utf8 Class Initialized
INFO - 2020-02-19 15:27:08 --> URI Class Initialized
INFO - 2020-02-19 15:27:08 --> Router Class Initialized
INFO - 2020-02-19 15:27:08 --> Output Class Initialized
INFO - 2020-02-19 15:27:08 --> Security Class Initialized
DEBUG - 2020-02-19 15:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:27:08 --> CSRF cookie sent
INFO - 2020-02-19 15:27:08 --> Input Class Initialized
INFO - 2020-02-19 15:27:08 --> Language Class Initialized
INFO - 2020-02-19 15:27:08 --> Language Class Initialized
INFO - 2020-02-19 15:27:08 --> Config Class Initialized
INFO - 2020-02-19 15:27:08 --> Loader Class Initialized
INFO - 2020-02-19 15:27:08 --> Helper loaded: url_helper
INFO - 2020-02-19 15:27:08 --> Helper loaded: common_helper
INFO - 2020-02-19 15:27:08 --> Helper loaded: language_helper
INFO - 2020-02-19 15:27:08 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:27:08 --> Helper loaded: email_helper
INFO - 2020-02-19 15:27:08 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:27:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:27:08 --> Parser Class Initialized
INFO - 2020-02-19 15:27:08 --> User Agent Class Initialized
INFO - 2020-02-19 15:27:08 --> Model Class Initialized
INFO - 2020-02-19 15:27:08 --> Database Driver Class Initialized
INFO - 2020-02-19 15:27:08 --> Model Class Initialized
DEBUG - 2020-02-19 15:27:08 --> Template Class Initialized
INFO - 2020-02-19 15:27:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:27:08 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:27:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:27:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:27:08 --> Encryption Class Initialized
INFO - 2020-02-19 15:27:08 --> Controller Class Initialized
DEBUG - 2020-02-19 15:27:08 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:27:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:27:08 --> Model Class Initialized
INFO - 2020-02-19 15:27:08 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:27:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:27:08 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:27:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:27:08 --> Model Class Initialized
DEBUG - 2020-02-19 15:27:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:27:08 --> Model Class Initialized
DEBUG - 2020-02-19 15:27:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:27:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:27:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:27:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:27:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:27:08 --> Final output sent to browser
DEBUG - 2020-02-19 15:27:08 --> Total execution time: 0.6718
INFO - 2020-02-19 15:34:00 --> Config Class Initialized
INFO - 2020-02-19 15:34:00 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:34:00 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:34:00 --> Utf8 Class Initialized
INFO - 2020-02-19 15:34:00 --> URI Class Initialized
INFO - 2020-02-19 15:34:00 --> Router Class Initialized
INFO - 2020-02-19 15:34:00 --> Output Class Initialized
INFO - 2020-02-19 15:34:00 --> Security Class Initialized
DEBUG - 2020-02-19 15:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:34:00 --> CSRF cookie sent
INFO - 2020-02-19 15:34:00 --> Input Class Initialized
INFO - 2020-02-19 15:34:00 --> Language Class Initialized
INFO - 2020-02-19 15:34:00 --> Language Class Initialized
INFO - 2020-02-19 15:34:00 --> Config Class Initialized
INFO - 2020-02-19 15:34:01 --> Loader Class Initialized
INFO - 2020-02-19 15:34:01 --> Helper loaded: url_helper
INFO - 2020-02-19 15:34:01 --> Helper loaded: common_helper
INFO - 2020-02-19 15:34:01 --> Helper loaded: language_helper
INFO - 2020-02-19 15:34:01 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:34:01 --> Helper loaded: email_helper
INFO - 2020-02-19 15:34:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:34:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:34:01 --> Parser Class Initialized
INFO - 2020-02-19 15:34:01 --> User Agent Class Initialized
INFO - 2020-02-19 15:34:01 --> Model Class Initialized
INFO - 2020-02-19 15:34:01 --> Database Driver Class Initialized
INFO - 2020-02-19 15:34:01 --> Model Class Initialized
DEBUG - 2020-02-19 15:34:01 --> Template Class Initialized
INFO - 2020-02-19 15:34:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:34:01 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:34:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:34:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:34:01 --> Encryption Class Initialized
INFO - 2020-02-19 15:34:01 --> Controller Class Initialized
DEBUG - 2020-02-19 15:34:01 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:34:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:34:01 --> Model Class Initialized
INFO - 2020-02-19 15:34:01 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:34:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:34:01 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:34:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:34:01 --> Model Class Initialized
DEBUG - 2020-02-19 15:34:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:34:01 --> Model Class Initialized
DEBUG - 2020-02-19 15:34:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:34:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:34:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:34:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:34:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:34:01 --> Final output sent to browser
DEBUG - 2020-02-19 15:34:01 --> Total execution time: 0.6572
INFO - 2020-02-19 15:37:07 --> Config Class Initialized
INFO - 2020-02-19 15:37:07 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:37:07 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:37:07 --> Utf8 Class Initialized
INFO - 2020-02-19 15:37:07 --> URI Class Initialized
INFO - 2020-02-19 15:37:07 --> Router Class Initialized
INFO - 2020-02-19 15:37:07 --> Output Class Initialized
INFO - 2020-02-19 15:37:07 --> Security Class Initialized
DEBUG - 2020-02-19 15:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:37:07 --> CSRF cookie sent
INFO - 2020-02-19 15:37:07 --> Input Class Initialized
INFO - 2020-02-19 15:37:07 --> Language Class Initialized
INFO - 2020-02-19 15:37:07 --> Language Class Initialized
INFO - 2020-02-19 15:37:07 --> Config Class Initialized
INFO - 2020-02-19 15:37:07 --> Loader Class Initialized
INFO - 2020-02-19 15:37:07 --> Helper loaded: url_helper
INFO - 2020-02-19 15:37:07 --> Helper loaded: common_helper
INFO - 2020-02-19 15:37:07 --> Helper loaded: language_helper
INFO - 2020-02-19 15:37:07 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:37:07 --> Helper loaded: email_helper
INFO - 2020-02-19 15:37:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:37:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:37:07 --> Parser Class Initialized
INFO - 2020-02-19 15:37:07 --> User Agent Class Initialized
INFO - 2020-02-19 15:37:07 --> Model Class Initialized
INFO - 2020-02-19 15:37:07 --> Database Driver Class Initialized
INFO - 2020-02-19 15:37:07 --> Model Class Initialized
DEBUG - 2020-02-19 15:37:07 --> Template Class Initialized
INFO - 2020-02-19 15:37:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:37:07 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:37:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:37:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:37:07 --> Encryption Class Initialized
INFO - 2020-02-19 15:37:07 --> Controller Class Initialized
DEBUG - 2020-02-19 15:37:07 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:37:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:37:07 --> Model Class Initialized
INFO - 2020-02-19 15:37:07 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:37:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:37:07 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:37:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:37:07 --> Model Class Initialized
DEBUG - 2020-02-19 15:37:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:37:07 --> Model Class Initialized
DEBUG - 2020-02-19 15:37:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:37:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:37:08 --> Final output sent to browser
DEBUG - 2020-02-19 15:37:08 --> Total execution time: 0.6745
INFO - 2020-02-19 15:42:37 --> Config Class Initialized
INFO - 2020-02-19 15:42:37 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:42:37 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:42:37 --> Utf8 Class Initialized
INFO - 2020-02-19 15:42:37 --> URI Class Initialized
INFO - 2020-02-19 15:42:38 --> Router Class Initialized
INFO - 2020-02-19 15:42:38 --> Output Class Initialized
INFO - 2020-02-19 15:42:38 --> Security Class Initialized
DEBUG - 2020-02-19 15:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:42:38 --> CSRF cookie sent
INFO - 2020-02-19 15:42:38 --> Input Class Initialized
INFO - 2020-02-19 15:42:38 --> Language Class Initialized
INFO - 2020-02-19 15:42:38 --> Language Class Initialized
INFO - 2020-02-19 15:42:38 --> Config Class Initialized
INFO - 2020-02-19 15:42:38 --> Loader Class Initialized
INFO - 2020-02-19 15:42:38 --> Helper loaded: url_helper
INFO - 2020-02-19 15:42:38 --> Helper loaded: common_helper
INFO - 2020-02-19 15:42:38 --> Helper loaded: language_helper
INFO - 2020-02-19 15:42:38 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:42:38 --> Helper loaded: email_helper
INFO - 2020-02-19 15:42:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:42:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:42:38 --> Parser Class Initialized
INFO - 2020-02-19 15:42:38 --> User Agent Class Initialized
INFO - 2020-02-19 15:42:38 --> Model Class Initialized
INFO - 2020-02-19 15:42:38 --> Database Driver Class Initialized
INFO - 2020-02-19 15:42:38 --> Model Class Initialized
DEBUG - 2020-02-19 15:42:38 --> Template Class Initialized
INFO - 2020-02-19 15:42:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:42:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:42:38 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:42:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:42:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:42:38 --> Encryption Class Initialized
INFO - 2020-02-19 15:42:38 --> Controller Class Initialized
DEBUG - 2020-02-19 15:42:38 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:42:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:42:38 --> Model Class Initialized
INFO - 2020-02-19 15:42:38 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:42:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:42:38 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:42:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:42:38 --> Model Class Initialized
DEBUG - 2020-02-19 15:42:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:42:38 --> Model Class Initialized
DEBUG - 2020-02-19 15:42:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:42:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:42:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:42:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:42:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:42:38 --> Final output sent to browser
DEBUG - 2020-02-19 15:42:38 --> Total execution time: 0.6578
INFO - 2020-02-19 15:43:57 --> Config Class Initialized
INFO - 2020-02-19 15:43:57 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:43:57 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:43:57 --> Utf8 Class Initialized
INFO - 2020-02-19 15:43:57 --> URI Class Initialized
INFO - 2020-02-19 15:43:57 --> Router Class Initialized
INFO - 2020-02-19 15:43:57 --> Output Class Initialized
INFO - 2020-02-19 15:43:57 --> Security Class Initialized
DEBUG - 2020-02-19 15:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:43:57 --> CSRF cookie sent
INFO - 2020-02-19 15:43:57 --> Input Class Initialized
INFO - 2020-02-19 15:43:57 --> Language Class Initialized
INFO - 2020-02-19 15:43:57 --> Language Class Initialized
INFO - 2020-02-19 15:43:57 --> Config Class Initialized
INFO - 2020-02-19 15:43:57 --> Loader Class Initialized
INFO - 2020-02-19 15:43:57 --> Helper loaded: url_helper
INFO - 2020-02-19 15:43:57 --> Helper loaded: common_helper
INFO - 2020-02-19 15:43:57 --> Helper loaded: language_helper
INFO - 2020-02-19 15:43:57 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:43:57 --> Helper loaded: email_helper
INFO - 2020-02-19 15:43:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:43:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:43:57 --> Parser Class Initialized
INFO - 2020-02-19 15:43:58 --> User Agent Class Initialized
INFO - 2020-02-19 15:43:58 --> Model Class Initialized
INFO - 2020-02-19 15:43:58 --> Database Driver Class Initialized
INFO - 2020-02-19 15:43:58 --> Model Class Initialized
DEBUG - 2020-02-19 15:43:58 --> Template Class Initialized
INFO - 2020-02-19 15:43:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:43:58 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:43:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:43:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:43:58 --> Encryption Class Initialized
INFO - 2020-02-19 15:43:58 --> Controller Class Initialized
DEBUG - 2020-02-19 15:43:58 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:43:58 --> Model Class Initialized
INFO - 2020-02-19 15:43:58 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:43:58 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:43:58 --> Model Class Initialized
DEBUG - 2020-02-19 15:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:43:58 --> Model Class Initialized
DEBUG - 2020-02-19 15:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:43:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:43:58 --> Final output sent to browser
DEBUG - 2020-02-19 15:43:58 --> Total execution time: 0.6886
INFO - 2020-02-19 15:44:25 --> Config Class Initialized
INFO - 2020-02-19 15:44:25 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:44:25 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:44:25 --> Utf8 Class Initialized
INFO - 2020-02-19 15:44:25 --> URI Class Initialized
INFO - 2020-02-19 15:44:25 --> Router Class Initialized
INFO - 2020-02-19 15:44:25 --> Output Class Initialized
INFO - 2020-02-19 15:44:25 --> Security Class Initialized
DEBUG - 2020-02-19 15:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:44:25 --> CSRF cookie sent
INFO - 2020-02-19 15:44:25 --> Input Class Initialized
INFO - 2020-02-19 15:44:25 --> Language Class Initialized
INFO - 2020-02-19 15:44:25 --> Language Class Initialized
INFO - 2020-02-19 15:44:25 --> Config Class Initialized
INFO - 2020-02-19 15:44:25 --> Loader Class Initialized
INFO - 2020-02-19 15:44:25 --> Helper loaded: url_helper
INFO - 2020-02-19 15:44:25 --> Helper loaded: common_helper
INFO - 2020-02-19 15:44:25 --> Helper loaded: language_helper
INFO - 2020-02-19 15:44:25 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:44:25 --> Helper loaded: email_helper
INFO - 2020-02-19 15:44:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:44:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:44:25 --> Parser Class Initialized
INFO - 2020-02-19 15:44:25 --> User Agent Class Initialized
INFO - 2020-02-19 15:44:25 --> Model Class Initialized
INFO - 2020-02-19 15:44:25 --> Database Driver Class Initialized
INFO - 2020-02-19 15:44:25 --> Model Class Initialized
DEBUG - 2020-02-19 15:44:25 --> Template Class Initialized
INFO - 2020-02-19 15:44:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:44:25 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:44:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:44:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:44:25 --> Encryption Class Initialized
INFO - 2020-02-19 15:44:25 --> Controller Class Initialized
DEBUG - 2020-02-19 15:44:26 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:44:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:44:26 --> Model Class Initialized
INFO - 2020-02-19 15:44:26 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:44:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:44:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:44:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:44:26 --> Model Class Initialized
DEBUG - 2020-02-19 15:44:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:44:26 --> Model Class Initialized
DEBUG - 2020-02-19 15:44:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:44:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:44:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:44:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:44:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:44:26 --> Final output sent to browser
DEBUG - 2020-02-19 15:44:26 --> Total execution time: 0.6813
INFO - 2020-02-19 15:44:56 --> Config Class Initialized
INFO - 2020-02-19 15:44:56 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:44:56 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:44:56 --> Utf8 Class Initialized
INFO - 2020-02-19 15:44:56 --> URI Class Initialized
INFO - 2020-02-19 15:44:56 --> Router Class Initialized
INFO - 2020-02-19 15:44:56 --> Output Class Initialized
INFO - 2020-02-19 15:44:56 --> Security Class Initialized
DEBUG - 2020-02-19 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:44:56 --> CSRF cookie sent
INFO - 2020-02-19 15:44:56 --> Input Class Initialized
INFO - 2020-02-19 15:44:56 --> Language Class Initialized
INFO - 2020-02-19 15:44:56 --> Language Class Initialized
INFO - 2020-02-19 15:44:56 --> Config Class Initialized
INFO - 2020-02-19 15:44:56 --> Loader Class Initialized
INFO - 2020-02-19 15:44:56 --> Helper loaded: url_helper
INFO - 2020-02-19 15:44:56 --> Helper loaded: common_helper
INFO - 2020-02-19 15:44:56 --> Helper loaded: language_helper
INFO - 2020-02-19 15:44:56 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:44:56 --> Helper loaded: email_helper
INFO - 2020-02-19 15:44:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:44:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:44:56 --> Parser Class Initialized
INFO - 2020-02-19 15:44:56 --> User Agent Class Initialized
INFO - 2020-02-19 15:44:56 --> Model Class Initialized
INFO - 2020-02-19 15:44:56 --> Database Driver Class Initialized
INFO - 2020-02-19 15:44:56 --> Model Class Initialized
DEBUG - 2020-02-19 15:44:56 --> Template Class Initialized
INFO - 2020-02-19 15:44:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:44:56 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:44:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:44:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:44:56 --> Encryption Class Initialized
INFO - 2020-02-19 15:44:56 --> Controller Class Initialized
DEBUG - 2020-02-19 15:44:56 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:44:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:44:56 --> Model Class Initialized
INFO - 2020-02-19 15:44:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:44:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:44:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:44:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:44:56 --> Model Class Initialized
DEBUG - 2020-02-19 15:44:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:44:56 --> Model Class Initialized
DEBUG - 2020-02-19 15:44:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:44:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:44:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:44:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:44:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:44:56 --> Final output sent to browser
DEBUG - 2020-02-19 15:44:56 --> Total execution time: 0.6926
INFO - 2020-02-19 15:45:03 --> Config Class Initialized
INFO - 2020-02-19 15:45:03 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:45:03 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:45:03 --> Utf8 Class Initialized
INFO - 2020-02-19 15:45:03 --> URI Class Initialized
INFO - 2020-02-19 15:45:03 --> Router Class Initialized
INFO - 2020-02-19 15:45:03 --> Output Class Initialized
INFO - 2020-02-19 15:45:03 --> Security Class Initialized
DEBUG - 2020-02-19 15:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:45:03 --> CSRF cookie sent
INFO - 2020-02-19 15:45:03 --> Input Class Initialized
INFO - 2020-02-19 15:45:03 --> Language Class Initialized
INFO - 2020-02-19 15:45:03 --> Language Class Initialized
INFO - 2020-02-19 15:45:03 --> Config Class Initialized
INFO - 2020-02-19 15:45:03 --> Loader Class Initialized
INFO - 2020-02-19 15:45:03 --> Helper loaded: url_helper
INFO - 2020-02-19 15:45:03 --> Helper loaded: common_helper
INFO - 2020-02-19 15:45:03 --> Helper loaded: language_helper
INFO - 2020-02-19 15:45:03 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:45:03 --> Helper loaded: email_helper
INFO - 2020-02-19 15:45:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:45:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:45:03 --> Parser Class Initialized
INFO - 2020-02-19 15:45:03 --> User Agent Class Initialized
INFO - 2020-02-19 15:45:03 --> Model Class Initialized
INFO - 2020-02-19 15:45:03 --> Database Driver Class Initialized
INFO - 2020-02-19 15:45:03 --> Model Class Initialized
DEBUG - 2020-02-19 15:45:03 --> Template Class Initialized
INFO - 2020-02-19 15:45:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:45:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:45:03 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:45:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:45:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:45:03 --> Encryption Class Initialized
INFO - 2020-02-19 15:45:03 --> Controller Class Initialized
DEBUG - 2020-02-19 15:45:03 --> client MX_Controller Initialized
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/models/client_model.php
INFO - 2020-02-19 15:45:03 --> Model Class Initialized
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/models/faqs_model.php
INFO - 2020-02-19 15:45:03 --> Model Class Initialized
INFO - 2020-02-19 15:45:03 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:45:03 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:45:03 --> Model Class Initialized
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:45:03 --> Model Class Initialized
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/faq/index.php
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:45:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:45:03 --> Final output sent to browser
DEBUG - 2020-02-19 15:45:03 --> Total execution time: 0.8097
INFO - 2020-02-19 15:45:34 --> Config Class Initialized
INFO - 2020-02-19 15:45:34 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:45:34 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:45:34 --> Utf8 Class Initialized
INFO - 2020-02-19 15:45:34 --> URI Class Initialized
INFO - 2020-02-19 15:45:34 --> Router Class Initialized
INFO - 2020-02-19 15:45:34 --> Output Class Initialized
INFO - 2020-02-19 15:45:34 --> Security Class Initialized
DEBUG - 2020-02-19 15:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:45:34 --> CSRF cookie sent
INFO - 2020-02-19 15:45:34 --> Input Class Initialized
INFO - 2020-02-19 15:45:34 --> Language Class Initialized
INFO - 2020-02-19 15:45:34 --> Language Class Initialized
INFO - 2020-02-19 15:45:34 --> Config Class Initialized
INFO - 2020-02-19 15:45:34 --> Loader Class Initialized
INFO - 2020-02-19 15:45:34 --> Helper loaded: url_helper
INFO - 2020-02-19 15:45:34 --> Helper loaded: common_helper
INFO - 2020-02-19 15:45:34 --> Helper loaded: language_helper
INFO - 2020-02-19 15:45:34 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:45:34 --> Helper loaded: email_helper
INFO - 2020-02-19 15:45:34 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:45:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:45:34 --> Parser Class Initialized
INFO - 2020-02-19 15:45:34 --> User Agent Class Initialized
INFO - 2020-02-19 15:45:34 --> Model Class Initialized
INFO - 2020-02-19 15:45:34 --> Database Driver Class Initialized
INFO - 2020-02-19 15:45:34 --> Model Class Initialized
DEBUG - 2020-02-19 15:45:34 --> Template Class Initialized
INFO - 2020-02-19 15:45:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:45:34 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:45:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:45:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:45:34 --> Encryption Class Initialized
INFO - 2020-02-19 15:45:34 --> Controller Class Initialized
DEBUG - 2020-02-19 15:45:34 --> client MX_Controller Initialized
DEBUG - 2020-02-19 15:45:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/models/client_model.php
INFO - 2020-02-19 15:45:35 --> Model Class Initialized
DEBUG - 2020-02-19 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/models/faqs_model.php
INFO - 2020-02-19 15:45:35 --> Model Class Initialized
INFO - 2020-02-19 15:45:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:45:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:45:35 --> Model Class Initialized
DEBUG - 2020-02-19 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:45:35 --> Model Class Initialized
DEBUG - 2020-02-19 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/faq/index.php
DEBUG - 2020-02-19 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:45:35 --> Final output sent to browser
DEBUG - 2020-02-19 15:45:35 --> Total execution time: 0.6236
INFO - 2020-02-19 15:48:59 --> Config Class Initialized
INFO - 2020-02-19 15:48:59 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:48:59 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:48:59 --> Utf8 Class Initialized
INFO - 2020-02-19 15:48:59 --> URI Class Initialized
INFO - 2020-02-19 15:48:59 --> Router Class Initialized
INFO - 2020-02-19 15:48:59 --> Output Class Initialized
INFO - 2020-02-19 15:48:59 --> Security Class Initialized
DEBUG - 2020-02-19 15:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:48:59 --> CSRF cookie sent
INFO - 2020-02-19 15:48:59 --> Input Class Initialized
INFO - 2020-02-19 15:48:59 --> Language Class Initialized
INFO - 2020-02-19 15:48:59 --> Language Class Initialized
INFO - 2020-02-19 15:48:59 --> Config Class Initialized
INFO - 2020-02-19 15:48:59 --> Loader Class Initialized
INFO - 2020-02-19 15:48:59 --> Helper loaded: url_helper
INFO - 2020-02-19 15:48:59 --> Helper loaded: common_helper
INFO - 2020-02-19 15:48:59 --> Helper loaded: language_helper
INFO - 2020-02-19 15:48:59 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:48:59 --> Helper loaded: email_helper
INFO - 2020-02-19 15:48:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:48:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:48:59 --> Parser Class Initialized
INFO - 2020-02-19 15:48:59 --> User Agent Class Initialized
INFO - 2020-02-19 15:48:59 --> Model Class Initialized
INFO - 2020-02-19 15:48:59 --> Database Driver Class Initialized
INFO - 2020-02-19 15:48:59 --> Model Class Initialized
DEBUG - 2020-02-19 15:48:59 --> Template Class Initialized
INFO - 2020-02-19 15:48:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:48:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:48:59 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:48:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:48:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:49:00 --> Encryption Class Initialized
INFO - 2020-02-19 15:49:00 --> Controller Class Initialized
DEBUG - 2020-02-19 15:49:00 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:49:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:49:00 --> Model Class Initialized
INFO - 2020-02-19 15:49:00 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:49:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:49:00 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:49:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:49:00 --> Model Class Initialized
DEBUG - 2020-02-19 15:49:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:49:00 --> Model Class Initialized
DEBUG - 2020-02-19 15:49:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:49:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:49:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:49:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:49:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:49:00 --> Final output sent to browser
DEBUG - 2020-02-19 15:49:00 --> Total execution time: 0.7095
INFO - 2020-02-19 15:49:45 --> Config Class Initialized
INFO - 2020-02-19 15:49:45 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:49:45 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:49:45 --> Utf8 Class Initialized
INFO - 2020-02-19 15:49:45 --> URI Class Initialized
INFO - 2020-02-19 15:49:45 --> Router Class Initialized
INFO - 2020-02-19 15:49:45 --> Output Class Initialized
INFO - 2020-02-19 15:49:45 --> Security Class Initialized
DEBUG - 2020-02-19 15:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:49:45 --> CSRF cookie sent
INFO - 2020-02-19 15:49:45 --> Input Class Initialized
INFO - 2020-02-19 15:49:45 --> Language Class Initialized
INFO - 2020-02-19 15:49:45 --> Language Class Initialized
INFO - 2020-02-19 15:49:45 --> Config Class Initialized
INFO - 2020-02-19 15:49:45 --> Loader Class Initialized
INFO - 2020-02-19 15:49:45 --> Helper loaded: url_helper
INFO - 2020-02-19 15:49:45 --> Helper loaded: common_helper
INFO - 2020-02-19 15:49:45 --> Helper loaded: language_helper
INFO - 2020-02-19 15:49:45 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:49:45 --> Helper loaded: email_helper
INFO - 2020-02-19 15:49:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:49:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:49:45 --> Parser Class Initialized
INFO - 2020-02-19 15:49:45 --> User Agent Class Initialized
INFO - 2020-02-19 15:49:45 --> Model Class Initialized
INFO - 2020-02-19 15:49:45 --> Database Driver Class Initialized
INFO - 2020-02-19 15:49:45 --> Model Class Initialized
DEBUG - 2020-02-19 15:49:45 --> Template Class Initialized
INFO - 2020-02-19 15:49:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:49:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:49:45 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:49:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:49:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:49:45 --> Encryption Class Initialized
INFO - 2020-02-19 15:49:45 --> Controller Class Initialized
DEBUG - 2020-02-19 15:49:45 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:49:45 --> Model Class Initialized
INFO - 2020-02-19 15:49:45 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:49:45 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:49:45 --> Model Class Initialized
DEBUG - 2020-02-19 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:49:45 --> Model Class Initialized
DEBUG - 2020-02-19 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:49:45 --> Final output sent to browser
DEBUG - 2020-02-19 15:49:45 --> Total execution time: 0.6321
INFO - 2020-02-19 15:50:52 --> Config Class Initialized
INFO - 2020-02-19 15:50:52 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:50:52 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:50:52 --> Utf8 Class Initialized
INFO - 2020-02-19 15:50:52 --> URI Class Initialized
INFO - 2020-02-19 15:50:52 --> Router Class Initialized
INFO - 2020-02-19 15:50:52 --> Output Class Initialized
INFO - 2020-02-19 15:50:52 --> Security Class Initialized
DEBUG - 2020-02-19 15:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:50:52 --> CSRF cookie sent
INFO - 2020-02-19 15:50:52 --> Input Class Initialized
INFO - 2020-02-19 15:50:52 --> Language Class Initialized
INFO - 2020-02-19 15:50:52 --> Language Class Initialized
INFO - 2020-02-19 15:50:52 --> Config Class Initialized
INFO - 2020-02-19 15:50:52 --> Loader Class Initialized
INFO - 2020-02-19 15:50:52 --> Helper loaded: url_helper
INFO - 2020-02-19 15:50:52 --> Helper loaded: common_helper
INFO - 2020-02-19 15:50:52 --> Helper loaded: language_helper
INFO - 2020-02-19 15:50:52 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:50:52 --> Helper loaded: email_helper
INFO - 2020-02-19 15:50:52 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:50:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:50:52 --> Parser Class Initialized
INFO - 2020-02-19 15:50:52 --> User Agent Class Initialized
INFO - 2020-02-19 15:50:52 --> Model Class Initialized
INFO - 2020-02-19 15:50:52 --> Database Driver Class Initialized
INFO - 2020-02-19 15:50:52 --> Model Class Initialized
DEBUG - 2020-02-19 15:50:52 --> Template Class Initialized
INFO - 2020-02-19 15:50:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:50:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:50:52 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:50:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:50:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:50:52 --> Encryption Class Initialized
INFO - 2020-02-19 15:50:52 --> Controller Class Initialized
DEBUG - 2020-02-19 15:50:53 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:50:53 --> Model Class Initialized
INFO - 2020-02-19 15:50:53 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:50:53 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:50:53 --> Model Class Initialized
DEBUG - 2020-02-19 15:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:50:53 --> Model Class Initialized
DEBUG - 2020-02-19 15:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:50:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:50:53 --> Final output sent to browser
DEBUG - 2020-02-19 15:50:53 --> Total execution time: 0.7047
INFO - 2020-02-19 15:51:19 --> Config Class Initialized
INFO - 2020-02-19 15:51:19 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:51:19 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:51:19 --> Utf8 Class Initialized
INFO - 2020-02-19 15:51:19 --> URI Class Initialized
INFO - 2020-02-19 15:51:19 --> Router Class Initialized
INFO - 2020-02-19 15:51:19 --> Output Class Initialized
INFO - 2020-02-19 15:51:19 --> Security Class Initialized
DEBUG - 2020-02-19 15:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:51:19 --> CSRF cookie sent
INFO - 2020-02-19 15:51:19 --> Input Class Initialized
INFO - 2020-02-19 15:51:19 --> Language Class Initialized
INFO - 2020-02-19 15:51:19 --> Language Class Initialized
INFO - 2020-02-19 15:51:19 --> Config Class Initialized
INFO - 2020-02-19 15:51:19 --> Loader Class Initialized
INFO - 2020-02-19 15:51:19 --> Helper loaded: url_helper
INFO - 2020-02-19 15:51:19 --> Helper loaded: common_helper
INFO - 2020-02-19 15:51:19 --> Helper loaded: language_helper
INFO - 2020-02-19 15:51:19 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:51:19 --> Helper loaded: email_helper
INFO - 2020-02-19 15:51:19 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:51:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:51:19 --> Parser Class Initialized
INFO - 2020-02-19 15:51:19 --> User Agent Class Initialized
INFO - 2020-02-19 15:51:19 --> Model Class Initialized
INFO - 2020-02-19 15:51:19 --> Database Driver Class Initialized
INFO - 2020-02-19 15:51:19 --> Model Class Initialized
DEBUG - 2020-02-19 15:51:19 --> Template Class Initialized
INFO - 2020-02-19 15:51:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:51:19 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:51:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:51:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:51:19 --> Encryption Class Initialized
INFO - 2020-02-19 15:51:19 --> Controller Class Initialized
DEBUG - 2020-02-19 15:51:19 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:51:19 --> Model Class Initialized
INFO - 2020-02-19 15:51:19 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:51:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:51:19 --> Model Class Initialized
DEBUG - 2020-02-19 15:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:51:19 --> Model Class Initialized
DEBUG - 2020-02-19 15:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:51:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:51:19 --> Final output sent to browser
DEBUG - 2020-02-19 15:51:19 --> Total execution time: 0.6281
INFO - 2020-02-19 15:51:35 --> Config Class Initialized
INFO - 2020-02-19 15:51:35 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:51:35 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:51:35 --> Utf8 Class Initialized
INFO - 2020-02-19 15:51:35 --> URI Class Initialized
INFO - 2020-02-19 15:51:35 --> Router Class Initialized
INFO - 2020-02-19 15:51:35 --> Output Class Initialized
INFO - 2020-02-19 15:51:36 --> Security Class Initialized
DEBUG - 2020-02-19 15:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:51:36 --> CSRF cookie sent
INFO - 2020-02-19 15:51:36 --> Input Class Initialized
INFO - 2020-02-19 15:51:36 --> Language Class Initialized
INFO - 2020-02-19 15:51:36 --> Language Class Initialized
INFO - 2020-02-19 15:51:36 --> Config Class Initialized
INFO - 2020-02-19 15:51:36 --> Loader Class Initialized
INFO - 2020-02-19 15:51:36 --> Helper loaded: url_helper
INFO - 2020-02-19 15:51:36 --> Helper loaded: common_helper
INFO - 2020-02-19 15:51:36 --> Helper loaded: language_helper
INFO - 2020-02-19 15:51:36 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:51:36 --> Helper loaded: email_helper
INFO - 2020-02-19 15:51:36 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:51:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:51:36 --> Parser Class Initialized
INFO - 2020-02-19 15:51:36 --> User Agent Class Initialized
INFO - 2020-02-19 15:51:36 --> Model Class Initialized
INFO - 2020-02-19 15:51:36 --> Database Driver Class Initialized
INFO - 2020-02-19 15:51:36 --> Model Class Initialized
DEBUG - 2020-02-19 15:51:36 --> Template Class Initialized
INFO - 2020-02-19 15:51:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:51:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:51:36 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:51:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:51:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:51:36 --> Encryption Class Initialized
INFO - 2020-02-19 15:51:36 --> Controller Class Initialized
DEBUG - 2020-02-19 15:51:36 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:51:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:51:36 --> Model Class Initialized
INFO - 2020-02-19 15:51:36 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:51:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:51:36 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:51:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:51:36 --> Model Class Initialized
DEBUG - 2020-02-19 15:51:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:51:36 --> Model Class Initialized
DEBUG - 2020-02-19 15:51:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:51:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:51:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:51:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:51:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:51:36 --> Final output sent to browser
DEBUG - 2020-02-19 15:51:36 --> Total execution time: 0.6576
INFO - 2020-02-19 15:53:02 --> Config Class Initialized
INFO - 2020-02-19 15:53:02 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:53:02 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:53:02 --> Utf8 Class Initialized
INFO - 2020-02-19 15:53:02 --> URI Class Initialized
INFO - 2020-02-19 15:53:02 --> Router Class Initialized
INFO - 2020-02-19 15:53:02 --> Output Class Initialized
INFO - 2020-02-19 15:53:02 --> Security Class Initialized
DEBUG - 2020-02-19 15:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:53:02 --> CSRF cookie sent
INFO - 2020-02-19 15:53:02 --> Input Class Initialized
INFO - 2020-02-19 15:53:02 --> Language Class Initialized
INFO - 2020-02-19 15:53:02 --> Language Class Initialized
INFO - 2020-02-19 15:53:02 --> Config Class Initialized
INFO - 2020-02-19 15:53:02 --> Loader Class Initialized
INFO - 2020-02-19 15:53:02 --> Helper loaded: url_helper
INFO - 2020-02-19 15:53:02 --> Helper loaded: common_helper
INFO - 2020-02-19 15:53:02 --> Helper loaded: language_helper
INFO - 2020-02-19 15:53:02 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:53:02 --> Helper loaded: email_helper
INFO - 2020-02-19 15:53:02 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:53:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:53:02 --> Parser Class Initialized
INFO - 2020-02-19 15:53:02 --> User Agent Class Initialized
INFO - 2020-02-19 15:53:02 --> Model Class Initialized
INFO - 2020-02-19 15:53:02 --> Database Driver Class Initialized
INFO - 2020-02-19 15:53:02 --> Model Class Initialized
DEBUG - 2020-02-19 15:53:02 --> Template Class Initialized
INFO - 2020-02-19 15:53:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:53:02 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:53:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:53:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:53:02 --> Encryption Class Initialized
INFO - 2020-02-19 15:53:02 --> Controller Class Initialized
DEBUG - 2020-02-19 15:53:02 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:53:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:53:02 --> Model Class Initialized
INFO - 2020-02-19 15:53:02 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:53:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:53:02 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:53:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:53:02 --> Model Class Initialized
DEBUG - 2020-02-19 15:53:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:53:02 --> Model Class Initialized
DEBUG - 2020-02-19 15:53:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:53:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:53:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:53:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:53:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:53:02 --> Final output sent to browser
DEBUG - 2020-02-19 15:53:02 --> Total execution time: 0.7277
INFO - 2020-02-19 15:56:00 --> Config Class Initialized
INFO - 2020-02-19 15:56:00 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:56:00 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:56:00 --> Utf8 Class Initialized
INFO - 2020-02-19 15:56:00 --> URI Class Initialized
INFO - 2020-02-19 15:56:00 --> Router Class Initialized
INFO - 2020-02-19 15:56:00 --> Output Class Initialized
INFO - 2020-02-19 15:56:00 --> Security Class Initialized
DEBUG - 2020-02-19 15:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:56:00 --> CSRF cookie sent
INFO - 2020-02-19 15:56:00 --> Input Class Initialized
INFO - 2020-02-19 15:56:00 --> Language Class Initialized
INFO - 2020-02-19 15:56:00 --> Language Class Initialized
INFO - 2020-02-19 15:56:00 --> Config Class Initialized
INFO - 2020-02-19 15:56:00 --> Loader Class Initialized
INFO - 2020-02-19 15:56:00 --> Helper loaded: url_helper
INFO - 2020-02-19 15:56:00 --> Helper loaded: common_helper
INFO - 2020-02-19 15:56:00 --> Helper loaded: language_helper
INFO - 2020-02-19 15:56:00 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:56:00 --> Helper loaded: email_helper
INFO - 2020-02-19 15:56:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:56:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:56:00 --> Parser Class Initialized
INFO - 2020-02-19 15:56:00 --> User Agent Class Initialized
INFO - 2020-02-19 15:56:00 --> Model Class Initialized
INFO - 2020-02-19 15:56:00 --> Database Driver Class Initialized
INFO - 2020-02-19 15:56:00 --> Model Class Initialized
DEBUG - 2020-02-19 15:56:00 --> Template Class Initialized
INFO - 2020-02-19 15:56:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:56:00 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:56:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:56:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:56:00 --> Encryption Class Initialized
INFO - 2020-02-19 15:56:00 --> Controller Class Initialized
DEBUG - 2020-02-19 15:56:00 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:56:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:56:00 --> Model Class Initialized
INFO - 2020-02-19 15:56:00 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:56:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:56:00 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:56:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:56:00 --> Model Class Initialized
DEBUG - 2020-02-19 15:56:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:56:00 --> Model Class Initialized
DEBUG - 2020-02-19 15:56:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:56:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:56:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:56:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:56:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:56:01 --> Final output sent to browser
DEBUG - 2020-02-19 15:56:01 --> Total execution time: 0.6485
INFO - 2020-02-19 15:58:03 --> Config Class Initialized
INFO - 2020-02-19 15:58:03 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:58:03 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:58:04 --> Utf8 Class Initialized
INFO - 2020-02-19 15:58:04 --> URI Class Initialized
INFO - 2020-02-19 15:58:04 --> Router Class Initialized
INFO - 2020-02-19 15:58:04 --> Output Class Initialized
INFO - 2020-02-19 15:58:04 --> Security Class Initialized
DEBUG - 2020-02-19 15:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:58:04 --> CSRF cookie sent
INFO - 2020-02-19 15:58:04 --> Input Class Initialized
INFO - 2020-02-19 15:58:04 --> Language Class Initialized
INFO - 2020-02-19 15:58:04 --> Language Class Initialized
INFO - 2020-02-19 15:58:04 --> Config Class Initialized
INFO - 2020-02-19 15:58:04 --> Loader Class Initialized
INFO - 2020-02-19 15:58:04 --> Helper loaded: url_helper
INFO - 2020-02-19 15:58:04 --> Helper loaded: common_helper
INFO - 2020-02-19 15:58:04 --> Helper loaded: language_helper
INFO - 2020-02-19 15:58:04 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:58:04 --> Helper loaded: email_helper
INFO - 2020-02-19 15:58:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:58:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:58:04 --> Parser Class Initialized
INFO - 2020-02-19 15:58:04 --> User Agent Class Initialized
INFO - 2020-02-19 15:58:04 --> Model Class Initialized
INFO - 2020-02-19 15:58:04 --> Database Driver Class Initialized
INFO - 2020-02-19 15:58:04 --> Model Class Initialized
DEBUG - 2020-02-19 15:58:04 --> Template Class Initialized
INFO - 2020-02-19 15:58:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:58:04 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:58:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:58:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:58:04 --> Encryption Class Initialized
INFO - 2020-02-19 15:58:04 --> Controller Class Initialized
DEBUG - 2020-02-19 15:58:04 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:58:04 --> Model Class Initialized
INFO - 2020-02-19 15:58:04 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:58:04 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:58:04 --> Model Class Initialized
DEBUG - 2020-02-19 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:58:04 --> Model Class Initialized
DEBUG - 2020-02-19 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:58:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:58:04 --> Final output sent to browser
DEBUG - 2020-02-19 15:58:04 --> Total execution time: 0.6946
INFO - 2020-02-19 15:59:50 --> Config Class Initialized
INFO - 2020-02-19 15:59:50 --> Hooks Class Initialized
DEBUG - 2020-02-19 15:59:50 --> UTF-8 Support Enabled
INFO - 2020-02-19 15:59:50 --> Utf8 Class Initialized
INFO - 2020-02-19 15:59:50 --> URI Class Initialized
INFO - 2020-02-19 15:59:50 --> Router Class Initialized
INFO - 2020-02-19 15:59:50 --> Output Class Initialized
INFO - 2020-02-19 15:59:50 --> Security Class Initialized
DEBUG - 2020-02-19 15:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 15:59:50 --> CSRF cookie sent
INFO - 2020-02-19 15:59:50 --> Input Class Initialized
INFO - 2020-02-19 15:59:50 --> Language Class Initialized
INFO - 2020-02-19 15:59:51 --> Language Class Initialized
INFO - 2020-02-19 15:59:51 --> Config Class Initialized
INFO - 2020-02-19 15:59:51 --> Loader Class Initialized
INFO - 2020-02-19 15:59:51 --> Helper loaded: url_helper
INFO - 2020-02-19 15:59:51 --> Helper loaded: common_helper
INFO - 2020-02-19 15:59:51 --> Helper loaded: language_helper
INFO - 2020-02-19 15:59:51 --> Helper loaded: cookie_helper
INFO - 2020-02-19 15:59:51 --> Helper loaded: email_helper
INFO - 2020-02-19 15:59:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 15:59:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 15:59:51 --> Parser Class Initialized
INFO - 2020-02-19 15:59:51 --> User Agent Class Initialized
INFO - 2020-02-19 15:59:51 --> Model Class Initialized
INFO - 2020-02-19 15:59:51 --> Database Driver Class Initialized
INFO - 2020-02-19 15:59:51 --> Model Class Initialized
DEBUG - 2020-02-19 15:59:51 --> Template Class Initialized
INFO - 2020-02-19 15:59:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 15:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 15:59:51 --> Pagination Class Initialized
DEBUG - 2020-02-19 15:59:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 15:59:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 15:59:51 --> Encryption Class Initialized
INFO - 2020-02-19 15:59:51 --> Controller Class Initialized
DEBUG - 2020-02-19 15:59:51 --> package MX_Controller Initialized
DEBUG - 2020-02-19 15:59:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 15:59:51 --> Model Class Initialized
INFO - 2020-02-19 15:59:51 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 15:59:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 15:59:51 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 15:59:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 15:59:51 --> Model Class Initialized
DEBUG - 2020-02-19 15:59:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 15:59:51 --> Model Class Initialized
DEBUG - 2020-02-19 15:59:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 15:59:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 15:59:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 15:59:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 15:59:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 15:59:51 --> Final output sent to browser
DEBUG - 2020-02-19 15:59:51 --> Total execution time: 0.7134
INFO - 2020-02-19 16:00:45 --> Config Class Initialized
INFO - 2020-02-19 16:00:45 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:00:45 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:00:45 --> Utf8 Class Initialized
INFO - 2020-02-19 16:00:45 --> URI Class Initialized
INFO - 2020-02-19 16:00:45 --> Router Class Initialized
INFO - 2020-02-19 16:00:45 --> Output Class Initialized
INFO - 2020-02-19 16:00:45 --> Security Class Initialized
DEBUG - 2020-02-19 16:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:00:45 --> CSRF cookie sent
INFO - 2020-02-19 16:00:45 --> Input Class Initialized
INFO - 2020-02-19 16:00:45 --> Language Class Initialized
INFO - 2020-02-19 16:00:45 --> Language Class Initialized
INFO - 2020-02-19 16:00:45 --> Config Class Initialized
INFO - 2020-02-19 16:00:46 --> Loader Class Initialized
INFO - 2020-02-19 16:00:46 --> Helper loaded: url_helper
INFO - 2020-02-19 16:00:46 --> Helper loaded: common_helper
INFO - 2020-02-19 16:00:46 --> Helper loaded: language_helper
INFO - 2020-02-19 16:00:46 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:00:46 --> Helper loaded: email_helper
INFO - 2020-02-19 16:00:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:00:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:00:46 --> Parser Class Initialized
INFO - 2020-02-19 16:00:46 --> User Agent Class Initialized
INFO - 2020-02-19 16:00:46 --> Model Class Initialized
INFO - 2020-02-19 16:00:46 --> Database Driver Class Initialized
INFO - 2020-02-19 16:00:46 --> Model Class Initialized
DEBUG - 2020-02-19 16:00:46 --> Template Class Initialized
INFO - 2020-02-19 16:00:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:00:46 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:00:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:00:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:00:46 --> Encryption Class Initialized
INFO - 2020-02-19 16:00:46 --> Controller Class Initialized
DEBUG - 2020-02-19 16:00:46 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:00:46 --> Model Class Initialized
INFO - 2020-02-19 16:00:46 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:00:46 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:00:46 --> Model Class Initialized
DEBUG - 2020-02-19 16:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:00:46 --> Model Class Initialized
DEBUG - 2020-02-19 16:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:00:46 --> Final output sent to browser
DEBUG - 2020-02-19 16:00:46 --> Total execution time: 0.6738
INFO - 2020-02-19 16:03:57 --> Config Class Initialized
INFO - 2020-02-19 16:03:57 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:03:57 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:03:57 --> Utf8 Class Initialized
INFO - 2020-02-19 16:03:57 --> URI Class Initialized
INFO - 2020-02-19 16:03:57 --> Router Class Initialized
INFO - 2020-02-19 16:03:57 --> Output Class Initialized
INFO - 2020-02-19 16:03:57 --> Security Class Initialized
DEBUG - 2020-02-19 16:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:03:57 --> CSRF cookie sent
INFO - 2020-02-19 16:03:57 --> Input Class Initialized
INFO - 2020-02-19 16:03:57 --> Language Class Initialized
INFO - 2020-02-19 16:03:57 --> Language Class Initialized
INFO - 2020-02-19 16:03:57 --> Config Class Initialized
INFO - 2020-02-19 16:03:57 --> Loader Class Initialized
INFO - 2020-02-19 16:03:57 --> Helper loaded: url_helper
INFO - 2020-02-19 16:03:57 --> Helper loaded: common_helper
INFO - 2020-02-19 16:03:57 --> Helper loaded: language_helper
INFO - 2020-02-19 16:03:57 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:03:57 --> Helper loaded: email_helper
INFO - 2020-02-19 16:03:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:03:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:03:57 --> Parser Class Initialized
INFO - 2020-02-19 16:03:57 --> User Agent Class Initialized
INFO - 2020-02-19 16:03:57 --> Model Class Initialized
INFO - 2020-02-19 16:03:57 --> Database Driver Class Initialized
INFO - 2020-02-19 16:03:57 --> Model Class Initialized
DEBUG - 2020-02-19 16:03:57 --> Template Class Initialized
INFO - 2020-02-19 16:03:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:03:57 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:03:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:03:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:03:57 --> Encryption Class Initialized
INFO - 2020-02-19 16:03:57 --> Controller Class Initialized
DEBUG - 2020-02-19 16:03:57 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:03:57 --> Model Class Initialized
INFO - 2020-02-19 16:03:57 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:03:57 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:03:57 --> Model Class Initialized
DEBUG - 2020-02-19 16:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:03:57 --> Model Class Initialized
DEBUG - 2020-02-19 16:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:03:57 --> Final output sent to browser
DEBUG - 2020-02-19 16:03:57 --> Total execution time: 0.7218
INFO - 2020-02-19 16:05:00 --> Config Class Initialized
INFO - 2020-02-19 16:05:00 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:05:00 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:05:00 --> Utf8 Class Initialized
INFO - 2020-02-19 16:05:01 --> URI Class Initialized
INFO - 2020-02-19 16:05:01 --> Router Class Initialized
INFO - 2020-02-19 16:05:01 --> Output Class Initialized
INFO - 2020-02-19 16:05:01 --> Security Class Initialized
DEBUG - 2020-02-19 16:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:05:01 --> CSRF cookie sent
INFO - 2020-02-19 16:05:01 --> Input Class Initialized
INFO - 2020-02-19 16:05:01 --> Language Class Initialized
INFO - 2020-02-19 16:05:01 --> Language Class Initialized
INFO - 2020-02-19 16:05:01 --> Config Class Initialized
INFO - 2020-02-19 16:05:01 --> Loader Class Initialized
INFO - 2020-02-19 16:05:01 --> Helper loaded: url_helper
INFO - 2020-02-19 16:05:01 --> Helper loaded: common_helper
INFO - 2020-02-19 16:05:01 --> Helper loaded: language_helper
INFO - 2020-02-19 16:05:01 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:05:01 --> Helper loaded: email_helper
INFO - 2020-02-19 16:05:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:05:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:05:01 --> Parser Class Initialized
INFO - 2020-02-19 16:05:01 --> User Agent Class Initialized
INFO - 2020-02-19 16:05:01 --> Model Class Initialized
INFO - 2020-02-19 16:05:01 --> Database Driver Class Initialized
INFO - 2020-02-19 16:05:01 --> Model Class Initialized
DEBUG - 2020-02-19 16:05:01 --> Template Class Initialized
INFO - 2020-02-19 16:05:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:05:01 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:05:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:05:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:05:01 --> Encryption Class Initialized
INFO - 2020-02-19 16:05:01 --> Controller Class Initialized
DEBUG - 2020-02-19 16:05:01 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:05:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:05:01 --> Model Class Initialized
INFO - 2020-02-19 16:05:01 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:05:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:05:01 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:05:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:05:01 --> Model Class Initialized
DEBUG - 2020-02-19 16:05:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:05:01 --> Model Class Initialized
DEBUG - 2020-02-19 16:05:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:05:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:05:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:05:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:05:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:05:01 --> Final output sent to browser
DEBUG - 2020-02-19 16:05:01 --> Total execution time: 0.6845
INFO - 2020-02-19 16:06:25 --> Config Class Initialized
INFO - 2020-02-19 16:06:25 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:06:25 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:06:25 --> Utf8 Class Initialized
INFO - 2020-02-19 16:06:25 --> URI Class Initialized
INFO - 2020-02-19 16:06:25 --> Router Class Initialized
INFO - 2020-02-19 16:06:25 --> Output Class Initialized
INFO - 2020-02-19 16:06:25 --> Security Class Initialized
DEBUG - 2020-02-19 16:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:06:25 --> CSRF cookie sent
INFO - 2020-02-19 16:06:25 --> Input Class Initialized
INFO - 2020-02-19 16:06:25 --> Language Class Initialized
INFO - 2020-02-19 16:06:25 --> Language Class Initialized
INFO - 2020-02-19 16:06:25 --> Config Class Initialized
INFO - 2020-02-19 16:06:25 --> Loader Class Initialized
INFO - 2020-02-19 16:06:25 --> Helper loaded: url_helper
INFO - 2020-02-19 16:06:25 --> Helper loaded: common_helper
INFO - 2020-02-19 16:06:25 --> Helper loaded: language_helper
INFO - 2020-02-19 16:06:25 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:06:25 --> Helper loaded: email_helper
INFO - 2020-02-19 16:06:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:06:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:06:25 --> Parser Class Initialized
INFO - 2020-02-19 16:06:25 --> User Agent Class Initialized
INFO - 2020-02-19 16:06:25 --> Model Class Initialized
INFO - 2020-02-19 16:06:25 --> Database Driver Class Initialized
INFO - 2020-02-19 16:06:25 --> Model Class Initialized
DEBUG - 2020-02-19 16:06:25 --> Template Class Initialized
INFO - 2020-02-19 16:06:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:06:25 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:06:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:06:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:06:25 --> Encryption Class Initialized
INFO - 2020-02-19 16:06:25 --> Controller Class Initialized
DEBUG - 2020-02-19 16:06:25 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:06:25 --> Model Class Initialized
INFO - 2020-02-19 16:06:25 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:06:25 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:06:25 --> Model Class Initialized
DEBUG - 2020-02-19 16:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:06:25 --> Model Class Initialized
DEBUG - 2020-02-19 16:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:06:26 --> Final output sent to browser
DEBUG - 2020-02-19 16:06:26 --> Total execution time: 0.7390
INFO - 2020-02-19 16:06:44 --> Config Class Initialized
INFO - 2020-02-19 16:06:44 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:06:44 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:06:44 --> Utf8 Class Initialized
INFO - 2020-02-19 16:06:44 --> URI Class Initialized
INFO - 2020-02-19 16:06:44 --> Router Class Initialized
INFO - 2020-02-19 16:06:44 --> Output Class Initialized
INFO - 2020-02-19 16:06:44 --> Security Class Initialized
DEBUG - 2020-02-19 16:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:06:44 --> CSRF cookie sent
INFO - 2020-02-19 16:06:44 --> Input Class Initialized
INFO - 2020-02-19 16:06:44 --> Language Class Initialized
INFO - 2020-02-19 16:06:44 --> Language Class Initialized
INFO - 2020-02-19 16:06:44 --> Config Class Initialized
INFO - 2020-02-19 16:06:44 --> Loader Class Initialized
INFO - 2020-02-19 16:06:44 --> Helper loaded: url_helper
INFO - 2020-02-19 16:06:44 --> Helper loaded: common_helper
INFO - 2020-02-19 16:06:44 --> Helper loaded: language_helper
INFO - 2020-02-19 16:06:44 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:06:44 --> Helper loaded: email_helper
INFO - 2020-02-19 16:06:44 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:06:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:06:44 --> Parser Class Initialized
INFO - 2020-02-19 16:06:44 --> User Agent Class Initialized
INFO - 2020-02-19 16:06:44 --> Model Class Initialized
INFO - 2020-02-19 16:06:44 --> Database Driver Class Initialized
INFO - 2020-02-19 16:06:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:06:44 --> Template Class Initialized
INFO - 2020-02-19 16:06:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:06:44 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:06:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:06:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:06:44 --> Encryption Class Initialized
INFO - 2020-02-19 16:06:44 --> Controller Class Initialized
DEBUG - 2020-02-19 16:06:45 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:06:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:06:45 --> Model Class Initialized
INFO - 2020-02-19 16:06:45 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:06:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:06:45 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:06:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:06:45 --> Model Class Initialized
DEBUG - 2020-02-19 16:06:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:06:45 --> Model Class Initialized
DEBUG - 2020-02-19 16:06:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:06:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:06:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:06:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:06:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:06:45 --> Final output sent to browser
DEBUG - 2020-02-19 16:06:45 --> Total execution time: 0.8147
INFO - 2020-02-19 16:07:26 --> Config Class Initialized
INFO - 2020-02-19 16:07:26 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:07:26 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:07:26 --> Utf8 Class Initialized
INFO - 2020-02-19 16:07:26 --> URI Class Initialized
INFO - 2020-02-19 16:07:26 --> Router Class Initialized
INFO - 2020-02-19 16:07:26 --> Output Class Initialized
INFO - 2020-02-19 16:07:26 --> Security Class Initialized
DEBUG - 2020-02-19 16:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:07:26 --> CSRF cookie sent
INFO - 2020-02-19 16:07:26 --> Input Class Initialized
INFO - 2020-02-19 16:07:26 --> Language Class Initialized
INFO - 2020-02-19 16:07:26 --> Language Class Initialized
INFO - 2020-02-19 16:07:26 --> Config Class Initialized
INFO - 2020-02-19 16:07:26 --> Loader Class Initialized
INFO - 2020-02-19 16:07:26 --> Helper loaded: url_helper
INFO - 2020-02-19 16:07:26 --> Helper loaded: common_helper
INFO - 2020-02-19 16:07:26 --> Helper loaded: language_helper
INFO - 2020-02-19 16:07:26 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:07:26 --> Helper loaded: email_helper
INFO - 2020-02-19 16:07:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:07:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:07:26 --> Parser Class Initialized
INFO - 2020-02-19 16:07:26 --> User Agent Class Initialized
INFO - 2020-02-19 16:07:26 --> Model Class Initialized
INFO - 2020-02-19 16:07:26 --> Database Driver Class Initialized
INFO - 2020-02-19 16:07:26 --> Model Class Initialized
DEBUG - 2020-02-19 16:07:26 --> Template Class Initialized
INFO - 2020-02-19 16:07:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:07:26 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:07:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:07:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:07:26 --> Encryption Class Initialized
INFO - 2020-02-19 16:07:26 --> Controller Class Initialized
DEBUG - 2020-02-19 16:07:26 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:07:26 --> Model Class Initialized
INFO - 2020-02-19 16:07:26 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:07:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:07:26 --> Model Class Initialized
DEBUG - 2020-02-19 16:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:07:26 --> Model Class Initialized
DEBUG - 2020-02-19 16:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:07:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:07:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:07:27 --> Final output sent to browser
DEBUG - 2020-02-19 16:07:27 --> Total execution time: 0.7907
INFO - 2020-02-19 16:07:31 --> Config Class Initialized
INFO - 2020-02-19 16:07:31 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:07:31 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:07:31 --> Utf8 Class Initialized
INFO - 2020-02-19 16:07:31 --> URI Class Initialized
INFO - 2020-02-19 16:07:31 --> Router Class Initialized
INFO - 2020-02-19 16:07:31 --> Output Class Initialized
INFO - 2020-02-19 16:07:31 --> Security Class Initialized
DEBUG - 2020-02-19 16:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:07:31 --> CSRF cookie sent
INFO - 2020-02-19 16:07:31 --> Input Class Initialized
INFO - 2020-02-19 16:07:31 --> Language Class Initialized
INFO - 2020-02-19 16:07:31 --> Language Class Initialized
INFO - 2020-02-19 16:07:31 --> Config Class Initialized
INFO - 2020-02-19 16:07:31 --> Loader Class Initialized
INFO - 2020-02-19 16:07:31 --> Helper loaded: url_helper
INFO - 2020-02-19 16:07:31 --> Helper loaded: common_helper
INFO - 2020-02-19 16:07:31 --> Helper loaded: language_helper
INFO - 2020-02-19 16:07:31 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:07:31 --> Helper loaded: email_helper
INFO - 2020-02-19 16:07:31 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:07:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:07:31 --> Parser Class Initialized
INFO - 2020-02-19 16:07:31 --> User Agent Class Initialized
INFO - 2020-02-19 16:07:31 --> Model Class Initialized
INFO - 2020-02-19 16:07:31 --> Database Driver Class Initialized
INFO - 2020-02-19 16:07:31 --> Model Class Initialized
DEBUG - 2020-02-19 16:07:31 --> Template Class Initialized
INFO - 2020-02-19 16:07:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:07:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:07:31 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:07:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:07:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:07:31 --> Encryption Class Initialized
INFO - 2020-02-19 16:07:31 --> Controller Class Initialized
DEBUG - 2020-02-19 16:07:31 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:07:31 --> Model Class Initialized
INFO - 2020-02-19 16:07:31 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:07:31 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:07:31 --> Model Class Initialized
DEBUG - 2020-02-19 16:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:07:31 --> Model Class Initialized
DEBUG - 2020-02-19 16:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:07:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:07:32 --> Final output sent to browser
DEBUG - 2020-02-19 16:07:32 --> Total execution time: 0.6952
INFO - 2020-02-19 16:08:05 --> Config Class Initialized
INFO - 2020-02-19 16:08:05 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:08:05 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:08:05 --> Utf8 Class Initialized
INFO - 2020-02-19 16:08:05 --> URI Class Initialized
INFO - 2020-02-19 16:08:05 --> Router Class Initialized
INFO - 2020-02-19 16:08:05 --> Output Class Initialized
INFO - 2020-02-19 16:08:05 --> Security Class Initialized
DEBUG - 2020-02-19 16:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:08:05 --> CSRF cookie sent
INFO - 2020-02-19 16:08:05 --> Input Class Initialized
INFO - 2020-02-19 16:08:05 --> Language Class Initialized
INFO - 2020-02-19 16:08:05 --> Language Class Initialized
INFO - 2020-02-19 16:08:05 --> Config Class Initialized
INFO - 2020-02-19 16:08:05 --> Loader Class Initialized
INFO - 2020-02-19 16:08:05 --> Helper loaded: url_helper
INFO - 2020-02-19 16:08:05 --> Helper loaded: common_helper
INFO - 2020-02-19 16:08:05 --> Helper loaded: language_helper
INFO - 2020-02-19 16:08:05 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:08:05 --> Helper loaded: email_helper
INFO - 2020-02-19 16:08:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:08:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:08:05 --> Parser Class Initialized
INFO - 2020-02-19 16:08:05 --> User Agent Class Initialized
INFO - 2020-02-19 16:08:05 --> Model Class Initialized
INFO - 2020-02-19 16:08:05 --> Database Driver Class Initialized
INFO - 2020-02-19 16:08:05 --> Model Class Initialized
DEBUG - 2020-02-19 16:08:05 --> Template Class Initialized
INFO - 2020-02-19 16:08:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:08:05 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:08:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:08:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:08:05 --> Encryption Class Initialized
INFO - 2020-02-19 16:08:05 --> Controller Class Initialized
DEBUG - 2020-02-19 16:08:05 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:08:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:08:05 --> Model Class Initialized
INFO - 2020-02-19 16:08:05 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:08:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:08:06 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:08:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:08:06 --> Model Class Initialized
DEBUG - 2020-02-19 16:08:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:08:06 --> Model Class Initialized
DEBUG - 2020-02-19 16:08:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:08:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:08:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:08:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:08:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:08:06 --> Final output sent to browser
DEBUG - 2020-02-19 16:08:06 --> Total execution time: 0.6710
INFO - 2020-02-19 16:08:24 --> Config Class Initialized
INFO - 2020-02-19 16:08:24 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:08:24 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:08:24 --> Utf8 Class Initialized
INFO - 2020-02-19 16:08:24 --> URI Class Initialized
INFO - 2020-02-19 16:08:24 --> Router Class Initialized
INFO - 2020-02-19 16:08:24 --> Output Class Initialized
INFO - 2020-02-19 16:08:24 --> Security Class Initialized
DEBUG - 2020-02-19 16:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:08:24 --> CSRF cookie sent
INFO - 2020-02-19 16:08:24 --> Input Class Initialized
INFO - 2020-02-19 16:08:24 --> Language Class Initialized
INFO - 2020-02-19 16:08:24 --> Language Class Initialized
INFO - 2020-02-19 16:08:24 --> Config Class Initialized
INFO - 2020-02-19 16:08:25 --> Loader Class Initialized
INFO - 2020-02-19 16:08:25 --> Helper loaded: url_helper
INFO - 2020-02-19 16:08:25 --> Helper loaded: common_helper
INFO - 2020-02-19 16:08:25 --> Helper loaded: language_helper
INFO - 2020-02-19 16:08:25 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:08:25 --> Helper loaded: email_helper
INFO - 2020-02-19 16:08:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:08:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:08:25 --> Parser Class Initialized
INFO - 2020-02-19 16:08:25 --> User Agent Class Initialized
INFO - 2020-02-19 16:08:25 --> Model Class Initialized
INFO - 2020-02-19 16:08:25 --> Database Driver Class Initialized
INFO - 2020-02-19 16:08:25 --> Model Class Initialized
DEBUG - 2020-02-19 16:08:25 --> Template Class Initialized
INFO - 2020-02-19 16:08:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:08:25 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:08:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:08:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:08:25 --> Encryption Class Initialized
INFO - 2020-02-19 16:08:25 --> Controller Class Initialized
DEBUG - 2020-02-19 16:08:25 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:08:25 --> Model Class Initialized
INFO - 2020-02-19 16:08:25 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:08:25 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:08:25 --> Model Class Initialized
DEBUG - 2020-02-19 16:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:08:25 --> Model Class Initialized
DEBUG - 2020-02-19 16:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:08:25 --> Final output sent to browser
DEBUG - 2020-02-19 16:08:25 --> Total execution time: 0.6868
INFO - 2020-02-19 16:09:01 --> Config Class Initialized
INFO - 2020-02-19 16:09:01 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:09:01 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:09:01 --> Utf8 Class Initialized
INFO - 2020-02-19 16:09:01 --> URI Class Initialized
INFO - 2020-02-19 16:09:01 --> Router Class Initialized
INFO - 2020-02-19 16:09:01 --> Output Class Initialized
INFO - 2020-02-19 16:09:01 --> Security Class Initialized
DEBUG - 2020-02-19 16:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:09:01 --> CSRF cookie sent
INFO - 2020-02-19 16:09:01 --> Input Class Initialized
INFO - 2020-02-19 16:09:01 --> Language Class Initialized
INFO - 2020-02-19 16:09:01 --> Language Class Initialized
INFO - 2020-02-19 16:09:01 --> Config Class Initialized
INFO - 2020-02-19 16:09:01 --> Loader Class Initialized
INFO - 2020-02-19 16:09:01 --> Helper loaded: url_helper
INFO - 2020-02-19 16:09:01 --> Helper loaded: common_helper
INFO - 2020-02-19 16:09:01 --> Helper loaded: language_helper
INFO - 2020-02-19 16:09:02 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:09:02 --> Helper loaded: email_helper
INFO - 2020-02-19 16:09:02 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:09:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:09:02 --> Parser Class Initialized
INFO - 2020-02-19 16:09:02 --> User Agent Class Initialized
INFO - 2020-02-19 16:09:02 --> Model Class Initialized
INFO - 2020-02-19 16:09:02 --> Database Driver Class Initialized
INFO - 2020-02-19 16:09:02 --> Model Class Initialized
DEBUG - 2020-02-19 16:09:02 --> Template Class Initialized
INFO - 2020-02-19 16:09:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:09:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:09:02 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:09:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:09:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:09:02 --> Encryption Class Initialized
INFO - 2020-02-19 16:09:02 --> Controller Class Initialized
DEBUG - 2020-02-19 16:09:02 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:09:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:09:02 --> Model Class Initialized
INFO - 2020-02-19 16:09:02 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:09:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:09:02 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:09:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:09:02 --> Model Class Initialized
DEBUG - 2020-02-19 16:09:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:09:02 --> Model Class Initialized
DEBUG - 2020-02-19 16:09:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:09:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:09:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:09:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:09:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:09:02 --> Final output sent to browser
DEBUG - 2020-02-19 16:09:02 --> Total execution time: 0.7166
INFO - 2020-02-19 16:09:44 --> Config Class Initialized
INFO - 2020-02-19 16:09:44 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:09:44 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:09:44 --> Utf8 Class Initialized
INFO - 2020-02-19 16:09:44 --> URI Class Initialized
INFO - 2020-02-19 16:09:44 --> Router Class Initialized
INFO - 2020-02-19 16:09:44 --> Output Class Initialized
INFO - 2020-02-19 16:09:44 --> Security Class Initialized
DEBUG - 2020-02-19 16:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:09:44 --> CSRF cookie sent
INFO - 2020-02-19 16:09:44 --> Input Class Initialized
INFO - 2020-02-19 16:09:44 --> Language Class Initialized
INFO - 2020-02-19 16:09:44 --> Language Class Initialized
INFO - 2020-02-19 16:09:44 --> Config Class Initialized
INFO - 2020-02-19 16:09:44 --> Loader Class Initialized
INFO - 2020-02-19 16:09:44 --> Helper loaded: url_helper
INFO - 2020-02-19 16:09:44 --> Helper loaded: common_helper
INFO - 2020-02-19 16:09:44 --> Helper loaded: language_helper
INFO - 2020-02-19 16:09:44 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:09:44 --> Helper loaded: email_helper
INFO - 2020-02-19 16:09:44 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:09:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:09:44 --> Parser Class Initialized
INFO - 2020-02-19 16:09:44 --> User Agent Class Initialized
INFO - 2020-02-19 16:09:44 --> Model Class Initialized
INFO - 2020-02-19 16:09:44 --> Database Driver Class Initialized
INFO - 2020-02-19 16:09:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:09:44 --> Template Class Initialized
INFO - 2020-02-19 16:09:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:09:44 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:09:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:09:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:09:44 --> Encryption Class Initialized
INFO - 2020-02-19 16:09:44 --> Controller Class Initialized
DEBUG - 2020-02-19 16:09:44 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:09:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:09:44 --> Model Class Initialized
INFO - 2020-02-19 16:09:44 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:09:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:09:44 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:09:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:09:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:09:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:09:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:09:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:09:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:09:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:09:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:09:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:09:45 --> Final output sent to browser
DEBUG - 2020-02-19 16:09:45 --> Total execution time: 0.6834
INFO - 2020-02-19 16:09:59 --> Config Class Initialized
INFO - 2020-02-19 16:09:59 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:09:59 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:09:59 --> Utf8 Class Initialized
INFO - 2020-02-19 16:09:59 --> URI Class Initialized
INFO - 2020-02-19 16:09:59 --> Router Class Initialized
INFO - 2020-02-19 16:09:59 --> Output Class Initialized
INFO - 2020-02-19 16:09:59 --> Security Class Initialized
DEBUG - 2020-02-19 16:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:09:59 --> CSRF cookie sent
INFO - 2020-02-19 16:09:59 --> Input Class Initialized
INFO - 2020-02-19 16:09:59 --> Language Class Initialized
INFO - 2020-02-19 16:09:59 --> Language Class Initialized
INFO - 2020-02-19 16:09:59 --> Config Class Initialized
INFO - 2020-02-19 16:09:59 --> Loader Class Initialized
INFO - 2020-02-19 16:09:59 --> Helper loaded: url_helper
INFO - 2020-02-19 16:09:59 --> Helper loaded: common_helper
INFO - 2020-02-19 16:09:59 --> Helper loaded: language_helper
INFO - 2020-02-19 16:09:59 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:09:59 --> Helper loaded: email_helper
INFO - 2020-02-19 16:09:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:09:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:09:59 --> Parser Class Initialized
INFO - 2020-02-19 16:09:59 --> User Agent Class Initialized
INFO - 2020-02-19 16:09:59 --> Model Class Initialized
INFO - 2020-02-19 16:09:59 --> Database Driver Class Initialized
INFO - 2020-02-19 16:09:59 --> Model Class Initialized
DEBUG - 2020-02-19 16:09:59 --> Template Class Initialized
INFO - 2020-02-19 16:09:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:09:59 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:09:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:09:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:09:59 --> Encryption Class Initialized
INFO - 2020-02-19 16:09:59 --> Controller Class Initialized
DEBUG - 2020-02-19 16:09:59 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:09:59 --> Model Class Initialized
INFO - 2020-02-19 16:09:59 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:09:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:09:59 --> Model Class Initialized
DEBUG - 2020-02-19 16:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:09:59 --> Model Class Initialized
DEBUG - 2020-02-19 16:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:09:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:09:59 --> Final output sent to browser
DEBUG - 2020-02-19 16:09:59 --> Total execution time: 0.6784
INFO - 2020-02-19 16:11:51 --> Config Class Initialized
INFO - 2020-02-19 16:11:51 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:11:52 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:11:52 --> Utf8 Class Initialized
INFO - 2020-02-19 16:11:52 --> URI Class Initialized
INFO - 2020-02-19 16:11:52 --> Router Class Initialized
INFO - 2020-02-19 16:11:52 --> Output Class Initialized
INFO - 2020-02-19 16:11:52 --> Security Class Initialized
DEBUG - 2020-02-19 16:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:11:52 --> CSRF cookie sent
INFO - 2020-02-19 16:11:52 --> Input Class Initialized
INFO - 2020-02-19 16:11:52 --> Language Class Initialized
INFO - 2020-02-19 16:11:52 --> Language Class Initialized
INFO - 2020-02-19 16:11:52 --> Config Class Initialized
INFO - 2020-02-19 16:11:52 --> Loader Class Initialized
INFO - 2020-02-19 16:11:52 --> Helper loaded: url_helper
INFO - 2020-02-19 16:11:52 --> Helper loaded: common_helper
INFO - 2020-02-19 16:11:52 --> Helper loaded: language_helper
INFO - 2020-02-19 16:11:52 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:11:52 --> Helper loaded: email_helper
INFO - 2020-02-19 16:11:52 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:11:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:11:52 --> Parser Class Initialized
INFO - 2020-02-19 16:11:52 --> User Agent Class Initialized
INFO - 2020-02-19 16:11:52 --> Model Class Initialized
INFO - 2020-02-19 16:11:52 --> Database Driver Class Initialized
INFO - 2020-02-19 16:11:52 --> Model Class Initialized
DEBUG - 2020-02-19 16:11:52 --> Template Class Initialized
INFO - 2020-02-19 16:11:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:11:53 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:11:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:11:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:11:53 --> Encryption Class Initialized
INFO - 2020-02-19 16:11:53 --> Controller Class Initialized
DEBUG - 2020-02-19 16:11:53 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:11:53 --> Model Class Initialized
INFO - 2020-02-19 16:11:53 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:11:53 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:11:53 --> Model Class Initialized
DEBUG - 2020-02-19 16:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:11:53 --> Model Class Initialized
DEBUG - 2020-02-19 16:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:11:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:11:53 --> Final output sent to browser
DEBUG - 2020-02-19 16:11:53 --> Total execution time: 1.6862
INFO - 2020-02-19 16:12:29 --> Config Class Initialized
INFO - 2020-02-19 16:12:29 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:12:29 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:12:29 --> Utf8 Class Initialized
INFO - 2020-02-19 16:12:29 --> URI Class Initialized
INFO - 2020-02-19 16:12:29 --> Router Class Initialized
INFO - 2020-02-19 16:12:29 --> Output Class Initialized
INFO - 2020-02-19 16:12:29 --> Security Class Initialized
DEBUG - 2020-02-19 16:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:12:29 --> CSRF cookie sent
INFO - 2020-02-19 16:12:29 --> Input Class Initialized
INFO - 2020-02-19 16:12:29 --> Language Class Initialized
INFO - 2020-02-19 16:12:29 --> Language Class Initialized
INFO - 2020-02-19 16:12:29 --> Config Class Initialized
INFO - 2020-02-19 16:12:29 --> Loader Class Initialized
INFO - 2020-02-19 16:12:29 --> Helper loaded: url_helper
INFO - 2020-02-19 16:12:29 --> Helper loaded: common_helper
INFO - 2020-02-19 16:12:29 --> Helper loaded: language_helper
INFO - 2020-02-19 16:12:29 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:12:29 --> Helper loaded: email_helper
INFO - 2020-02-19 16:12:29 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:12:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:12:29 --> Parser Class Initialized
INFO - 2020-02-19 16:12:29 --> User Agent Class Initialized
INFO - 2020-02-19 16:12:29 --> Model Class Initialized
INFO - 2020-02-19 16:12:29 --> Database Driver Class Initialized
INFO - 2020-02-19 16:12:29 --> Model Class Initialized
DEBUG - 2020-02-19 16:12:29 --> Template Class Initialized
INFO - 2020-02-19 16:12:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:12:29 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:12:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:12:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:12:29 --> Encryption Class Initialized
INFO - 2020-02-19 16:12:29 --> Controller Class Initialized
DEBUG - 2020-02-19 16:12:29 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:12:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:12:29 --> Model Class Initialized
INFO - 2020-02-19 16:12:29 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:12:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:12:29 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:12:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:12:30 --> Model Class Initialized
DEBUG - 2020-02-19 16:12:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:12:30 --> Model Class Initialized
DEBUG - 2020-02-19 16:12:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:12:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:12:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:12:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:12:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:12:30 --> Final output sent to browser
DEBUG - 2020-02-19 16:12:30 --> Total execution time: 0.7554
INFO - 2020-02-19 16:14:25 --> Config Class Initialized
INFO - 2020-02-19 16:14:25 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:14:25 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:14:25 --> Utf8 Class Initialized
INFO - 2020-02-19 16:14:25 --> URI Class Initialized
INFO - 2020-02-19 16:14:25 --> Router Class Initialized
INFO - 2020-02-19 16:14:25 --> Output Class Initialized
INFO - 2020-02-19 16:14:25 --> Security Class Initialized
DEBUG - 2020-02-19 16:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:14:25 --> CSRF cookie sent
INFO - 2020-02-19 16:14:25 --> Input Class Initialized
INFO - 2020-02-19 16:14:25 --> Language Class Initialized
INFO - 2020-02-19 16:14:25 --> Language Class Initialized
INFO - 2020-02-19 16:14:25 --> Config Class Initialized
INFO - 2020-02-19 16:14:25 --> Loader Class Initialized
INFO - 2020-02-19 16:14:25 --> Helper loaded: url_helper
INFO - 2020-02-19 16:14:25 --> Helper loaded: common_helper
INFO - 2020-02-19 16:14:25 --> Helper loaded: language_helper
INFO - 2020-02-19 16:14:25 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:14:25 --> Helper loaded: email_helper
INFO - 2020-02-19 16:14:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:14:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:14:25 --> Parser Class Initialized
INFO - 2020-02-19 16:14:25 --> User Agent Class Initialized
INFO - 2020-02-19 16:14:25 --> Model Class Initialized
INFO - 2020-02-19 16:14:25 --> Database Driver Class Initialized
INFO - 2020-02-19 16:14:25 --> Model Class Initialized
DEBUG - 2020-02-19 16:14:25 --> Template Class Initialized
INFO - 2020-02-19 16:14:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:14:25 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:14:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:14:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:14:25 --> Encryption Class Initialized
INFO - 2020-02-19 16:14:25 --> Controller Class Initialized
DEBUG - 2020-02-19 16:14:25 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:14:25 --> Model Class Initialized
INFO - 2020-02-19 16:14:25 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:14:25 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:14:25 --> Model Class Initialized
DEBUG - 2020-02-19 16:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:14:25 --> Model Class Initialized
DEBUG - 2020-02-19 16:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:14:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:14:25 --> Final output sent to browser
DEBUG - 2020-02-19 16:14:25 --> Total execution time: 0.8408
INFO - 2020-02-19 16:14:40 --> Config Class Initialized
INFO - 2020-02-19 16:14:40 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:14:40 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:14:40 --> Utf8 Class Initialized
INFO - 2020-02-19 16:14:40 --> URI Class Initialized
INFO - 2020-02-19 16:14:40 --> Router Class Initialized
INFO - 2020-02-19 16:14:40 --> Output Class Initialized
INFO - 2020-02-19 16:14:40 --> Security Class Initialized
DEBUG - 2020-02-19 16:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:14:40 --> CSRF cookie sent
INFO - 2020-02-19 16:14:40 --> Input Class Initialized
INFO - 2020-02-19 16:14:40 --> Language Class Initialized
INFO - 2020-02-19 16:14:40 --> Language Class Initialized
INFO - 2020-02-19 16:14:40 --> Config Class Initialized
INFO - 2020-02-19 16:14:40 --> Loader Class Initialized
INFO - 2020-02-19 16:14:40 --> Helper loaded: url_helper
INFO - 2020-02-19 16:14:40 --> Helper loaded: common_helper
INFO - 2020-02-19 16:14:40 --> Helper loaded: language_helper
INFO - 2020-02-19 16:14:40 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:14:40 --> Helper loaded: email_helper
INFO - 2020-02-19 16:14:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:14:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:14:40 --> Parser Class Initialized
INFO - 2020-02-19 16:14:40 --> User Agent Class Initialized
INFO - 2020-02-19 16:14:40 --> Model Class Initialized
INFO - 2020-02-19 16:14:40 --> Database Driver Class Initialized
INFO - 2020-02-19 16:14:40 --> Model Class Initialized
DEBUG - 2020-02-19 16:14:40 --> Template Class Initialized
INFO - 2020-02-19 16:14:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:14:40 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:14:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:14:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:14:40 --> Encryption Class Initialized
INFO - 2020-02-19 16:14:40 --> Controller Class Initialized
DEBUG - 2020-02-19 16:14:40 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:14:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:14:40 --> Model Class Initialized
INFO - 2020-02-19 16:14:40 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:14:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:14:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:14:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:14:40 --> Model Class Initialized
DEBUG - 2020-02-19 16:14:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:14:41 --> Model Class Initialized
DEBUG - 2020-02-19 16:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:14:41 --> Final output sent to browser
DEBUG - 2020-02-19 16:14:41 --> Total execution time: 0.7695
INFO - 2020-02-19 16:16:17 --> Config Class Initialized
INFO - 2020-02-19 16:16:17 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:16:17 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:16:17 --> Utf8 Class Initialized
INFO - 2020-02-19 16:16:17 --> URI Class Initialized
INFO - 2020-02-19 16:16:17 --> Router Class Initialized
INFO - 2020-02-19 16:16:17 --> Output Class Initialized
INFO - 2020-02-19 16:16:17 --> Security Class Initialized
DEBUG - 2020-02-19 16:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:16:18 --> CSRF cookie sent
INFO - 2020-02-19 16:16:18 --> Input Class Initialized
INFO - 2020-02-19 16:16:18 --> Language Class Initialized
INFO - 2020-02-19 16:16:18 --> Language Class Initialized
INFO - 2020-02-19 16:16:18 --> Config Class Initialized
INFO - 2020-02-19 16:16:18 --> Loader Class Initialized
INFO - 2020-02-19 16:16:18 --> Helper loaded: url_helper
INFO - 2020-02-19 16:16:18 --> Helper loaded: common_helper
INFO - 2020-02-19 16:16:18 --> Helper loaded: language_helper
INFO - 2020-02-19 16:16:18 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:16:18 --> Helper loaded: email_helper
INFO - 2020-02-19 16:16:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:16:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:16:18 --> Parser Class Initialized
INFO - 2020-02-19 16:16:18 --> User Agent Class Initialized
INFO - 2020-02-19 16:16:18 --> Model Class Initialized
INFO - 2020-02-19 16:16:18 --> Database Driver Class Initialized
INFO - 2020-02-19 16:16:18 --> Model Class Initialized
DEBUG - 2020-02-19 16:16:18 --> Template Class Initialized
INFO - 2020-02-19 16:16:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:16:18 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:16:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:16:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:16:18 --> Encryption Class Initialized
INFO - 2020-02-19 16:16:18 --> Controller Class Initialized
DEBUG - 2020-02-19 16:16:18 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:16:18 --> Model Class Initialized
INFO - 2020-02-19 16:16:18 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:16:18 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:16:18 --> Model Class Initialized
DEBUG - 2020-02-19 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:16:18 --> Model Class Initialized
DEBUG - 2020-02-19 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:16:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:16:18 --> Final output sent to browser
DEBUG - 2020-02-19 16:16:18 --> Total execution time: 0.7372
INFO - 2020-02-19 16:17:44 --> Config Class Initialized
INFO - 2020-02-19 16:17:44 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:17:44 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:17:44 --> Utf8 Class Initialized
INFO - 2020-02-19 16:17:44 --> URI Class Initialized
INFO - 2020-02-19 16:17:44 --> Router Class Initialized
INFO - 2020-02-19 16:17:44 --> Output Class Initialized
INFO - 2020-02-19 16:17:44 --> Security Class Initialized
DEBUG - 2020-02-19 16:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:17:44 --> CSRF cookie sent
INFO - 2020-02-19 16:17:44 --> Input Class Initialized
INFO - 2020-02-19 16:17:44 --> Language Class Initialized
INFO - 2020-02-19 16:17:44 --> Language Class Initialized
INFO - 2020-02-19 16:17:44 --> Config Class Initialized
INFO - 2020-02-19 16:17:44 --> Loader Class Initialized
INFO - 2020-02-19 16:17:44 --> Helper loaded: url_helper
INFO - 2020-02-19 16:17:44 --> Helper loaded: common_helper
INFO - 2020-02-19 16:17:44 --> Helper loaded: language_helper
INFO - 2020-02-19 16:17:44 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:17:44 --> Helper loaded: email_helper
INFO - 2020-02-19 16:17:44 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:17:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:17:44 --> Parser Class Initialized
INFO - 2020-02-19 16:17:44 --> User Agent Class Initialized
INFO - 2020-02-19 16:17:44 --> Model Class Initialized
INFO - 2020-02-19 16:17:44 --> Database Driver Class Initialized
INFO - 2020-02-19 16:17:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:17:44 --> Template Class Initialized
INFO - 2020-02-19 16:17:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:17:44 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:17:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:17:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:17:44 --> Encryption Class Initialized
INFO - 2020-02-19 16:17:44 --> Controller Class Initialized
DEBUG - 2020-02-19 16:17:44 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:17:44 --> Model Class Initialized
INFO - 2020-02-19 16:17:44 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:17:44 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:17:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:17:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:17:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:17:44 --> Final output sent to browser
DEBUG - 2020-02-19 16:17:44 --> Total execution time: 0.7029
INFO - 2020-02-19 16:19:47 --> Config Class Initialized
INFO - 2020-02-19 16:19:47 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:19:47 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:19:47 --> Utf8 Class Initialized
INFO - 2020-02-19 16:19:47 --> URI Class Initialized
INFO - 2020-02-19 16:19:47 --> Router Class Initialized
INFO - 2020-02-19 16:19:47 --> Output Class Initialized
INFO - 2020-02-19 16:19:47 --> Security Class Initialized
DEBUG - 2020-02-19 16:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:19:47 --> CSRF cookie sent
INFO - 2020-02-19 16:19:47 --> Input Class Initialized
INFO - 2020-02-19 16:19:47 --> Language Class Initialized
INFO - 2020-02-19 16:19:47 --> Language Class Initialized
INFO - 2020-02-19 16:19:47 --> Config Class Initialized
INFO - 2020-02-19 16:19:47 --> Loader Class Initialized
INFO - 2020-02-19 16:19:47 --> Helper loaded: url_helper
INFO - 2020-02-19 16:19:47 --> Helper loaded: common_helper
INFO - 2020-02-19 16:19:47 --> Helper loaded: language_helper
INFO - 2020-02-19 16:19:47 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:19:47 --> Helper loaded: email_helper
INFO - 2020-02-19 16:19:47 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:19:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:19:47 --> Parser Class Initialized
INFO - 2020-02-19 16:19:47 --> User Agent Class Initialized
INFO - 2020-02-19 16:19:47 --> Model Class Initialized
INFO - 2020-02-19 16:19:47 --> Database Driver Class Initialized
INFO - 2020-02-19 16:19:47 --> Model Class Initialized
DEBUG - 2020-02-19 16:19:47 --> Template Class Initialized
INFO - 2020-02-19 16:19:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:19:47 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:19:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:19:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:19:47 --> Encryption Class Initialized
INFO - 2020-02-19 16:19:47 --> Controller Class Initialized
DEBUG - 2020-02-19 16:19:47 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:19:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:19:47 --> Model Class Initialized
INFO - 2020-02-19 16:19:47 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:19:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:19:47 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:19:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:19:47 --> Model Class Initialized
DEBUG - 2020-02-19 16:19:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:19:47 --> Model Class Initialized
DEBUG - 2020-02-19 16:19:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:19:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:19:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:19:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:19:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:19:47 --> Final output sent to browser
DEBUG - 2020-02-19 16:19:47 --> Total execution time: 0.6995
INFO - 2020-02-19 16:22:00 --> Config Class Initialized
INFO - 2020-02-19 16:22:00 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:22:00 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:22:00 --> Utf8 Class Initialized
INFO - 2020-02-19 16:22:00 --> URI Class Initialized
INFO - 2020-02-19 16:22:00 --> Router Class Initialized
INFO - 2020-02-19 16:22:00 --> Output Class Initialized
INFO - 2020-02-19 16:22:00 --> Security Class Initialized
DEBUG - 2020-02-19 16:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:22:00 --> CSRF cookie sent
INFO - 2020-02-19 16:22:00 --> Input Class Initialized
INFO - 2020-02-19 16:22:00 --> Language Class Initialized
INFO - 2020-02-19 16:22:00 --> Language Class Initialized
INFO - 2020-02-19 16:22:00 --> Config Class Initialized
INFO - 2020-02-19 16:22:00 --> Loader Class Initialized
INFO - 2020-02-19 16:22:00 --> Helper loaded: url_helper
INFO - 2020-02-19 16:22:00 --> Helper loaded: common_helper
INFO - 2020-02-19 16:22:00 --> Helper loaded: language_helper
INFO - 2020-02-19 16:22:00 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:22:00 --> Helper loaded: email_helper
INFO - 2020-02-19 16:22:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:22:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:22:00 --> Parser Class Initialized
INFO - 2020-02-19 16:22:00 --> User Agent Class Initialized
INFO - 2020-02-19 16:22:00 --> Model Class Initialized
INFO - 2020-02-19 16:22:00 --> Database Driver Class Initialized
INFO - 2020-02-19 16:22:00 --> Model Class Initialized
DEBUG - 2020-02-19 16:22:00 --> Template Class Initialized
INFO - 2020-02-19 16:22:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:22:01 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:22:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:22:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:22:01 --> Encryption Class Initialized
INFO - 2020-02-19 16:22:01 --> Controller Class Initialized
DEBUG - 2020-02-19 16:22:01 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:22:01 --> Model Class Initialized
INFO - 2020-02-19 16:22:01 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:22:01 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:22:01 --> Model Class Initialized
DEBUG - 2020-02-19 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:22:01 --> Model Class Initialized
DEBUG - 2020-02-19 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:22:01 --> Final output sent to browser
DEBUG - 2020-02-19 16:22:01 --> Total execution time: 0.7893
INFO - 2020-02-19 16:22:55 --> Config Class Initialized
INFO - 2020-02-19 16:22:55 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:22:55 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:22:55 --> Utf8 Class Initialized
INFO - 2020-02-19 16:22:56 --> URI Class Initialized
INFO - 2020-02-19 16:22:56 --> Router Class Initialized
INFO - 2020-02-19 16:22:56 --> Output Class Initialized
INFO - 2020-02-19 16:22:56 --> Security Class Initialized
DEBUG - 2020-02-19 16:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:22:56 --> CSRF cookie sent
INFO - 2020-02-19 16:22:56 --> Input Class Initialized
INFO - 2020-02-19 16:22:56 --> Language Class Initialized
INFO - 2020-02-19 16:22:56 --> Language Class Initialized
INFO - 2020-02-19 16:22:56 --> Config Class Initialized
INFO - 2020-02-19 16:22:56 --> Loader Class Initialized
INFO - 2020-02-19 16:22:56 --> Helper loaded: url_helper
INFO - 2020-02-19 16:22:56 --> Helper loaded: common_helper
INFO - 2020-02-19 16:22:56 --> Helper loaded: language_helper
INFO - 2020-02-19 16:22:56 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:22:56 --> Helper loaded: email_helper
INFO - 2020-02-19 16:22:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:22:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:22:56 --> Parser Class Initialized
INFO - 2020-02-19 16:22:56 --> User Agent Class Initialized
INFO - 2020-02-19 16:22:56 --> Model Class Initialized
INFO - 2020-02-19 16:22:56 --> Database Driver Class Initialized
INFO - 2020-02-19 16:22:56 --> Model Class Initialized
DEBUG - 2020-02-19 16:22:56 --> Template Class Initialized
INFO - 2020-02-19 16:22:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:22:56 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:22:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:22:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:22:56 --> Encryption Class Initialized
INFO - 2020-02-19 16:22:56 --> Controller Class Initialized
DEBUG - 2020-02-19 16:22:56 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:22:56 --> Model Class Initialized
INFO - 2020-02-19 16:22:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:22:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:22:56 --> Model Class Initialized
DEBUG - 2020-02-19 16:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:22:56 --> Model Class Initialized
DEBUG - 2020-02-19 16:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:22:56 --> Final output sent to browser
DEBUG - 2020-02-19 16:22:56 --> Total execution time: 0.7654
INFO - 2020-02-19 16:23:26 --> Config Class Initialized
INFO - 2020-02-19 16:23:26 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:23:26 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:23:26 --> Utf8 Class Initialized
INFO - 2020-02-19 16:23:26 --> URI Class Initialized
INFO - 2020-02-19 16:23:26 --> Router Class Initialized
INFO - 2020-02-19 16:23:26 --> Output Class Initialized
INFO - 2020-02-19 16:23:26 --> Security Class Initialized
DEBUG - 2020-02-19 16:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:23:26 --> CSRF cookie sent
INFO - 2020-02-19 16:23:26 --> Input Class Initialized
INFO - 2020-02-19 16:23:26 --> Language Class Initialized
INFO - 2020-02-19 16:23:26 --> Language Class Initialized
INFO - 2020-02-19 16:23:26 --> Config Class Initialized
INFO - 2020-02-19 16:23:26 --> Loader Class Initialized
INFO - 2020-02-19 16:23:26 --> Helper loaded: url_helper
INFO - 2020-02-19 16:23:26 --> Helper loaded: common_helper
INFO - 2020-02-19 16:23:26 --> Helper loaded: language_helper
INFO - 2020-02-19 16:23:26 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:23:26 --> Helper loaded: email_helper
INFO - 2020-02-19 16:23:26 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:23:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:23:26 --> Parser Class Initialized
INFO - 2020-02-19 16:23:26 --> User Agent Class Initialized
INFO - 2020-02-19 16:23:26 --> Model Class Initialized
INFO - 2020-02-19 16:23:26 --> Database Driver Class Initialized
INFO - 2020-02-19 16:23:26 --> Model Class Initialized
DEBUG - 2020-02-19 16:23:26 --> Template Class Initialized
INFO - 2020-02-19 16:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:23:26 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:23:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:23:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:23:26 --> Encryption Class Initialized
INFO - 2020-02-19 16:23:26 --> Controller Class Initialized
DEBUG - 2020-02-19 16:23:26 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:23:26 --> Model Class Initialized
INFO - 2020-02-19 16:23:26 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:23:26 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:23:26 --> Model Class Initialized
DEBUG - 2020-02-19 16:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:23:26 --> Model Class Initialized
DEBUG - 2020-02-19 16:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:23:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:23:26 --> Final output sent to browser
DEBUG - 2020-02-19 16:23:26 --> Total execution time: 0.7113
INFO - 2020-02-19 16:23:59 --> Config Class Initialized
INFO - 2020-02-19 16:23:59 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:23:59 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:23:59 --> Utf8 Class Initialized
INFO - 2020-02-19 16:23:59 --> URI Class Initialized
INFO - 2020-02-19 16:23:59 --> Router Class Initialized
INFO - 2020-02-19 16:23:59 --> Output Class Initialized
INFO - 2020-02-19 16:23:59 --> Security Class Initialized
DEBUG - 2020-02-19 16:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:23:59 --> CSRF cookie sent
INFO - 2020-02-19 16:23:59 --> Input Class Initialized
INFO - 2020-02-19 16:23:59 --> Language Class Initialized
INFO - 2020-02-19 16:23:59 --> Language Class Initialized
INFO - 2020-02-19 16:23:59 --> Config Class Initialized
INFO - 2020-02-19 16:23:59 --> Loader Class Initialized
INFO - 2020-02-19 16:23:59 --> Helper loaded: url_helper
INFO - 2020-02-19 16:23:59 --> Helper loaded: common_helper
INFO - 2020-02-19 16:23:59 --> Helper loaded: language_helper
INFO - 2020-02-19 16:23:59 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:23:59 --> Helper loaded: email_helper
INFO - 2020-02-19 16:23:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:23:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:23:59 --> Parser Class Initialized
INFO - 2020-02-19 16:23:59 --> User Agent Class Initialized
INFO - 2020-02-19 16:23:59 --> Model Class Initialized
INFO - 2020-02-19 16:23:59 --> Database Driver Class Initialized
INFO - 2020-02-19 16:23:59 --> Model Class Initialized
DEBUG - 2020-02-19 16:23:59 --> Template Class Initialized
INFO - 2020-02-19 16:23:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:23:59 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:23:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:23:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:23:59 --> Encryption Class Initialized
INFO - 2020-02-19 16:23:59 --> Controller Class Initialized
DEBUG - 2020-02-19 16:23:59 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:23:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:23:59 --> Model Class Initialized
INFO - 2020-02-19 16:23:59 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:23:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:23:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:23:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:23:59 --> Model Class Initialized
DEBUG - 2020-02-19 16:23:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:23:59 --> Model Class Initialized
DEBUG - 2020-02-19 16:23:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:23:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:23:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:24:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:24:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:24:00 --> Final output sent to browser
DEBUG - 2020-02-19 16:24:00 --> Total execution time: 0.8372
INFO - 2020-02-19 16:24:38 --> Config Class Initialized
INFO - 2020-02-19 16:24:38 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:24:38 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:24:38 --> Utf8 Class Initialized
INFO - 2020-02-19 16:24:38 --> URI Class Initialized
INFO - 2020-02-19 16:24:38 --> Router Class Initialized
INFO - 2020-02-19 16:24:38 --> Output Class Initialized
INFO - 2020-02-19 16:24:38 --> Security Class Initialized
DEBUG - 2020-02-19 16:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:24:38 --> CSRF cookie sent
INFO - 2020-02-19 16:24:38 --> Input Class Initialized
INFO - 2020-02-19 16:24:38 --> Language Class Initialized
INFO - 2020-02-19 16:24:38 --> Language Class Initialized
INFO - 2020-02-19 16:24:38 --> Config Class Initialized
INFO - 2020-02-19 16:24:38 --> Loader Class Initialized
INFO - 2020-02-19 16:24:38 --> Helper loaded: url_helper
INFO - 2020-02-19 16:24:38 --> Helper loaded: common_helper
INFO - 2020-02-19 16:24:38 --> Helper loaded: language_helper
INFO - 2020-02-19 16:24:38 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:24:38 --> Helper loaded: email_helper
INFO - 2020-02-19 16:24:38 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:24:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:24:38 --> Parser Class Initialized
INFO - 2020-02-19 16:24:38 --> User Agent Class Initialized
INFO - 2020-02-19 16:24:38 --> Model Class Initialized
INFO - 2020-02-19 16:24:38 --> Database Driver Class Initialized
INFO - 2020-02-19 16:24:38 --> Model Class Initialized
DEBUG - 2020-02-19 16:24:38 --> Template Class Initialized
INFO - 2020-02-19 16:24:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:24:38 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:24:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:24:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:24:38 --> Encryption Class Initialized
INFO - 2020-02-19 16:24:38 --> Controller Class Initialized
DEBUG - 2020-02-19 16:24:38 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:24:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:24:38 --> Model Class Initialized
INFO - 2020-02-19 16:24:38 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:24:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:24:38 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:24:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:24:38 --> Model Class Initialized
DEBUG - 2020-02-19 16:24:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:24:38 --> Model Class Initialized
DEBUG - 2020-02-19 16:24:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:24:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:24:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:24:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:24:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:24:39 --> Final output sent to browser
DEBUG - 2020-02-19 16:24:39 --> Total execution time: 0.7854
INFO - 2020-02-19 16:25:07 --> Config Class Initialized
INFO - 2020-02-19 16:25:07 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:25:07 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:25:07 --> Utf8 Class Initialized
INFO - 2020-02-19 16:25:07 --> URI Class Initialized
INFO - 2020-02-19 16:25:07 --> Router Class Initialized
INFO - 2020-02-19 16:25:07 --> Output Class Initialized
INFO - 2020-02-19 16:25:07 --> Security Class Initialized
DEBUG - 2020-02-19 16:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:25:07 --> CSRF cookie sent
INFO - 2020-02-19 16:25:07 --> Input Class Initialized
INFO - 2020-02-19 16:25:07 --> Language Class Initialized
INFO - 2020-02-19 16:25:07 --> Language Class Initialized
INFO - 2020-02-19 16:25:07 --> Config Class Initialized
INFO - 2020-02-19 16:25:07 --> Loader Class Initialized
INFO - 2020-02-19 16:25:07 --> Helper loaded: url_helper
INFO - 2020-02-19 16:25:07 --> Helper loaded: common_helper
INFO - 2020-02-19 16:25:07 --> Helper loaded: language_helper
INFO - 2020-02-19 16:25:07 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:25:07 --> Helper loaded: email_helper
INFO - 2020-02-19 16:25:07 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:25:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:25:07 --> Parser Class Initialized
INFO - 2020-02-19 16:25:07 --> User Agent Class Initialized
INFO - 2020-02-19 16:25:07 --> Model Class Initialized
INFO - 2020-02-19 16:25:07 --> Database Driver Class Initialized
INFO - 2020-02-19 16:25:07 --> Model Class Initialized
DEBUG - 2020-02-19 16:25:07 --> Template Class Initialized
INFO - 2020-02-19 16:25:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:25:07 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:25:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:25:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:25:07 --> Encryption Class Initialized
INFO - 2020-02-19 16:25:07 --> Controller Class Initialized
DEBUG - 2020-02-19 16:25:07 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:25:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:25:07 --> Model Class Initialized
INFO - 2020-02-19 16:25:07 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:25:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:25:07 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:25:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:25:07 --> Model Class Initialized
DEBUG - 2020-02-19 16:25:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:25:07 --> Model Class Initialized
DEBUG - 2020-02-19 16:25:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:25:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:25:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:25:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:25:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:25:08 --> Final output sent to browser
DEBUG - 2020-02-19 16:25:08 --> Total execution time: 0.7819
INFO - 2020-02-19 16:27:35 --> Config Class Initialized
INFO - 2020-02-19 16:27:35 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:27:35 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:27:35 --> Utf8 Class Initialized
INFO - 2020-02-19 16:27:35 --> URI Class Initialized
INFO - 2020-02-19 16:27:35 --> Router Class Initialized
INFO - 2020-02-19 16:27:35 --> Output Class Initialized
INFO - 2020-02-19 16:27:35 --> Security Class Initialized
DEBUG - 2020-02-19 16:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:27:35 --> CSRF cookie sent
INFO - 2020-02-19 16:27:35 --> Input Class Initialized
INFO - 2020-02-19 16:27:35 --> Language Class Initialized
INFO - 2020-02-19 16:27:35 --> Language Class Initialized
INFO - 2020-02-19 16:27:35 --> Config Class Initialized
INFO - 2020-02-19 16:27:35 --> Loader Class Initialized
INFO - 2020-02-19 16:27:35 --> Helper loaded: url_helper
INFO - 2020-02-19 16:27:35 --> Helper loaded: common_helper
INFO - 2020-02-19 16:27:35 --> Helper loaded: language_helper
INFO - 2020-02-19 16:27:35 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:27:35 --> Helper loaded: email_helper
INFO - 2020-02-19 16:27:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:27:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:27:35 --> Parser Class Initialized
INFO - 2020-02-19 16:27:35 --> User Agent Class Initialized
INFO - 2020-02-19 16:27:35 --> Model Class Initialized
INFO - 2020-02-19 16:27:35 --> Database Driver Class Initialized
INFO - 2020-02-19 16:27:35 --> Model Class Initialized
DEBUG - 2020-02-19 16:27:35 --> Template Class Initialized
INFO - 2020-02-19 16:27:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:27:35 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:27:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:27:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:27:35 --> Encryption Class Initialized
INFO - 2020-02-19 16:27:35 --> Controller Class Initialized
DEBUG - 2020-02-19 16:27:35 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:27:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:27:35 --> Model Class Initialized
INFO - 2020-02-19 16:27:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:27:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:27:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:27:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:27:35 --> Model Class Initialized
DEBUG - 2020-02-19 16:27:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:27:35 --> Model Class Initialized
DEBUG - 2020-02-19 16:27:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:27:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:27:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:27:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:27:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:27:36 --> Final output sent to browser
DEBUG - 2020-02-19 16:27:36 --> Total execution time: 0.7887
INFO - 2020-02-19 16:28:04 --> Config Class Initialized
INFO - 2020-02-19 16:28:04 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:28:04 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:28:04 --> Utf8 Class Initialized
INFO - 2020-02-19 16:28:04 --> URI Class Initialized
INFO - 2020-02-19 16:28:04 --> Router Class Initialized
INFO - 2020-02-19 16:28:04 --> Output Class Initialized
INFO - 2020-02-19 16:28:04 --> Security Class Initialized
DEBUG - 2020-02-19 16:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:28:04 --> CSRF cookie sent
INFO - 2020-02-19 16:28:04 --> Input Class Initialized
INFO - 2020-02-19 16:28:04 --> Language Class Initialized
INFO - 2020-02-19 16:28:04 --> Language Class Initialized
INFO - 2020-02-19 16:28:04 --> Config Class Initialized
INFO - 2020-02-19 16:28:04 --> Loader Class Initialized
INFO - 2020-02-19 16:28:04 --> Helper loaded: url_helper
INFO - 2020-02-19 16:28:04 --> Helper loaded: common_helper
INFO - 2020-02-19 16:28:04 --> Helper loaded: language_helper
INFO - 2020-02-19 16:28:04 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:28:04 --> Helper loaded: email_helper
INFO - 2020-02-19 16:28:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:28:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:28:04 --> Parser Class Initialized
INFO - 2020-02-19 16:28:05 --> User Agent Class Initialized
INFO - 2020-02-19 16:28:05 --> Model Class Initialized
INFO - 2020-02-19 16:28:05 --> Database Driver Class Initialized
INFO - 2020-02-19 16:28:05 --> Model Class Initialized
DEBUG - 2020-02-19 16:28:05 --> Template Class Initialized
INFO - 2020-02-19 16:28:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:28:05 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:28:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:28:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:28:05 --> Encryption Class Initialized
INFO - 2020-02-19 16:28:05 --> Controller Class Initialized
DEBUG - 2020-02-19 16:28:05 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:28:05 --> Model Class Initialized
INFO - 2020-02-19 16:28:05 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:28:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:28:05 --> Model Class Initialized
DEBUG - 2020-02-19 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:28:05 --> Model Class Initialized
DEBUG - 2020-02-19 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:28:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:28:05 --> Final output sent to browser
DEBUG - 2020-02-19 16:28:05 --> Total execution time: 0.7448
INFO - 2020-02-19 16:31:34 --> Config Class Initialized
INFO - 2020-02-19 16:31:34 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:31:34 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:31:34 --> Utf8 Class Initialized
INFO - 2020-02-19 16:31:34 --> URI Class Initialized
INFO - 2020-02-19 16:31:34 --> Router Class Initialized
INFO - 2020-02-19 16:31:34 --> Output Class Initialized
INFO - 2020-02-19 16:31:34 --> Security Class Initialized
DEBUG - 2020-02-19 16:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:31:34 --> CSRF cookie sent
INFO - 2020-02-19 16:31:34 --> Input Class Initialized
INFO - 2020-02-19 16:31:34 --> Language Class Initialized
INFO - 2020-02-19 16:31:34 --> Language Class Initialized
INFO - 2020-02-19 16:31:34 --> Config Class Initialized
INFO - 2020-02-19 16:31:34 --> Loader Class Initialized
INFO - 2020-02-19 16:31:34 --> Helper loaded: url_helper
INFO - 2020-02-19 16:31:34 --> Helper loaded: common_helper
INFO - 2020-02-19 16:31:34 --> Helper loaded: language_helper
INFO - 2020-02-19 16:31:34 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:31:34 --> Helper loaded: email_helper
INFO - 2020-02-19 16:31:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:31:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:31:35 --> Parser Class Initialized
INFO - 2020-02-19 16:31:35 --> User Agent Class Initialized
INFO - 2020-02-19 16:31:35 --> Model Class Initialized
INFO - 2020-02-19 16:31:35 --> Database Driver Class Initialized
INFO - 2020-02-19 16:31:35 --> Model Class Initialized
DEBUG - 2020-02-19 16:31:35 --> Template Class Initialized
INFO - 2020-02-19 16:31:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:31:35 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:31:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:31:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:31:35 --> Encryption Class Initialized
INFO - 2020-02-19 16:31:35 --> Controller Class Initialized
DEBUG - 2020-02-19 16:31:35 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:31:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:31:35 --> Model Class Initialized
INFO - 2020-02-19 16:31:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:31:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:31:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:31:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:31:35 --> Model Class Initialized
DEBUG - 2020-02-19 16:31:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:31:35 --> Model Class Initialized
DEBUG - 2020-02-19 16:31:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:31:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:31:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:31:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:31:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:31:35 --> Final output sent to browser
DEBUG - 2020-02-19 16:31:35 --> Total execution time: 0.8352
INFO - 2020-02-19 16:32:01 --> Config Class Initialized
INFO - 2020-02-19 16:32:01 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:32:01 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:32:01 --> Utf8 Class Initialized
INFO - 2020-02-19 16:32:01 --> URI Class Initialized
INFO - 2020-02-19 16:32:01 --> Router Class Initialized
INFO - 2020-02-19 16:32:01 --> Output Class Initialized
INFO - 2020-02-19 16:32:01 --> Security Class Initialized
DEBUG - 2020-02-19 16:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:32:01 --> CSRF cookie sent
INFO - 2020-02-19 16:32:01 --> Input Class Initialized
INFO - 2020-02-19 16:32:01 --> Language Class Initialized
INFO - 2020-02-19 16:32:01 --> Language Class Initialized
INFO - 2020-02-19 16:32:01 --> Config Class Initialized
INFO - 2020-02-19 16:32:01 --> Loader Class Initialized
INFO - 2020-02-19 16:32:02 --> Helper loaded: url_helper
INFO - 2020-02-19 16:32:02 --> Helper loaded: common_helper
INFO - 2020-02-19 16:32:02 --> Helper loaded: language_helper
INFO - 2020-02-19 16:32:02 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:32:02 --> Helper loaded: email_helper
INFO - 2020-02-19 16:32:02 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:32:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:32:02 --> Parser Class Initialized
INFO - 2020-02-19 16:32:02 --> User Agent Class Initialized
INFO - 2020-02-19 16:32:02 --> Model Class Initialized
INFO - 2020-02-19 16:32:02 --> Database Driver Class Initialized
INFO - 2020-02-19 16:32:02 --> Model Class Initialized
DEBUG - 2020-02-19 16:32:02 --> Template Class Initialized
INFO - 2020-02-19 16:32:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:32:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:32:02 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:32:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:32:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:32:02 --> Encryption Class Initialized
INFO - 2020-02-19 16:32:02 --> Controller Class Initialized
DEBUG - 2020-02-19 16:32:02 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:32:02 --> Model Class Initialized
INFO - 2020-02-19 16:32:02 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:32:02 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:32:02 --> Model Class Initialized
DEBUG - 2020-02-19 16:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:32:02 --> Model Class Initialized
DEBUG - 2020-02-19 16:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:32:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:32:02 --> Final output sent to browser
DEBUG - 2020-02-19 16:32:02 --> Total execution time: 0.7456
INFO - 2020-02-19 16:33:20 --> Config Class Initialized
INFO - 2020-02-19 16:33:20 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:33:20 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:33:20 --> Utf8 Class Initialized
INFO - 2020-02-19 16:33:20 --> URI Class Initialized
INFO - 2020-02-19 16:33:20 --> Router Class Initialized
INFO - 2020-02-19 16:33:20 --> Output Class Initialized
INFO - 2020-02-19 16:33:20 --> Security Class Initialized
DEBUG - 2020-02-19 16:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:33:20 --> CSRF cookie sent
INFO - 2020-02-19 16:33:20 --> Input Class Initialized
INFO - 2020-02-19 16:33:20 --> Language Class Initialized
INFO - 2020-02-19 16:33:20 --> Language Class Initialized
INFO - 2020-02-19 16:33:20 --> Config Class Initialized
INFO - 2020-02-19 16:33:20 --> Loader Class Initialized
INFO - 2020-02-19 16:33:20 --> Helper loaded: url_helper
INFO - 2020-02-19 16:33:20 --> Helper loaded: common_helper
INFO - 2020-02-19 16:33:20 --> Helper loaded: language_helper
INFO - 2020-02-19 16:33:20 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:33:20 --> Helper loaded: email_helper
INFO - 2020-02-19 16:33:20 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:33:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:33:20 --> Parser Class Initialized
INFO - 2020-02-19 16:33:20 --> User Agent Class Initialized
INFO - 2020-02-19 16:33:20 --> Model Class Initialized
INFO - 2020-02-19 16:33:20 --> Database Driver Class Initialized
INFO - 2020-02-19 16:33:20 --> Model Class Initialized
DEBUG - 2020-02-19 16:33:20 --> Template Class Initialized
INFO - 2020-02-19 16:33:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:33:20 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:33:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:33:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:33:20 --> Encryption Class Initialized
INFO - 2020-02-19 16:33:20 --> Controller Class Initialized
DEBUG - 2020-02-19 16:33:20 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:33:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:33:20 --> Model Class Initialized
INFO - 2020-02-19 16:33:20 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:33:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:33:20 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:33:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:33:20 --> Model Class Initialized
DEBUG - 2020-02-19 16:33:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:33:20 --> Model Class Initialized
DEBUG - 2020-02-19 16:33:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:33:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:33:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:33:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:33:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:33:20 --> Final output sent to browser
DEBUG - 2020-02-19 16:33:20 --> Total execution time: 0.7471
INFO - 2020-02-19 16:34:18 --> Config Class Initialized
INFO - 2020-02-19 16:34:18 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:34:18 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:34:18 --> Utf8 Class Initialized
INFO - 2020-02-19 16:34:18 --> URI Class Initialized
INFO - 2020-02-19 16:34:18 --> Router Class Initialized
INFO - 2020-02-19 16:34:18 --> Output Class Initialized
INFO - 2020-02-19 16:34:18 --> Security Class Initialized
DEBUG - 2020-02-19 16:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:34:18 --> CSRF cookie sent
INFO - 2020-02-19 16:34:18 --> Input Class Initialized
INFO - 2020-02-19 16:34:18 --> Language Class Initialized
INFO - 2020-02-19 16:34:18 --> Language Class Initialized
INFO - 2020-02-19 16:34:18 --> Config Class Initialized
INFO - 2020-02-19 16:34:18 --> Loader Class Initialized
INFO - 2020-02-19 16:34:18 --> Helper loaded: url_helper
INFO - 2020-02-19 16:34:18 --> Helper loaded: common_helper
INFO - 2020-02-19 16:34:18 --> Helper loaded: language_helper
INFO - 2020-02-19 16:34:18 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:34:18 --> Helper loaded: email_helper
INFO - 2020-02-19 16:34:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:34:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:34:18 --> Parser Class Initialized
INFO - 2020-02-19 16:34:18 --> User Agent Class Initialized
INFO - 2020-02-19 16:34:18 --> Model Class Initialized
INFO - 2020-02-19 16:34:18 --> Database Driver Class Initialized
INFO - 2020-02-19 16:34:18 --> Model Class Initialized
DEBUG - 2020-02-19 16:34:18 --> Template Class Initialized
INFO - 2020-02-19 16:34:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:34:18 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:34:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:34:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:34:18 --> Encryption Class Initialized
INFO - 2020-02-19 16:34:18 --> Controller Class Initialized
DEBUG - 2020-02-19 16:34:18 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:34:18 --> Model Class Initialized
INFO - 2020-02-19 16:34:18 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:34:18 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:34:18 --> Model Class Initialized
DEBUG - 2020-02-19 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:34:18 --> Model Class Initialized
DEBUG - 2020-02-19 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:34:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:34:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:34:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:34:19 --> Final output sent to browser
DEBUG - 2020-02-19 16:34:19 --> Total execution time: 0.7447
INFO - 2020-02-19 16:37:34 --> Config Class Initialized
INFO - 2020-02-19 16:37:34 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:37:34 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:37:34 --> Utf8 Class Initialized
INFO - 2020-02-19 16:37:35 --> URI Class Initialized
INFO - 2020-02-19 16:37:35 --> Router Class Initialized
INFO - 2020-02-19 16:37:35 --> Output Class Initialized
INFO - 2020-02-19 16:37:35 --> Security Class Initialized
DEBUG - 2020-02-19 16:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:37:35 --> CSRF cookie sent
INFO - 2020-02-19 16:37:35 --> Input Class Initialized
INFO - 2020-02-19 16:37:35 --> Language Class Initialized
INFO - 2020-02-19 16:37:35 --> Language Class Initialized
INFO - 2020-02-19 16:37:35 --> Config Class Initialized
INFO - 2020-02-19 16:37:35 --> Loader Class Initialized
INFO - 2020-02-19 16:37:35 --> Helper loaded: url_helper
INFO - 2020-02-19 16:37:35 --> Helper loaded: common_helper
INFO - 2020-02-19 16:37:35 --> Helper loaded: language_helper
INFO - 2020-02-19 16:37:35 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:37:35 --> Helper loaded: email_helper
INFO - 2020-02-19 16:37:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:37:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:37:35 --> Parser Class Initialized
INFO - 2020-02-19 16:37:35 --> User Agent Class Initialized
INFO - 2020-02-19 16:37:35 --> Model Class Initialized
INFO - 2020-02-19 16:37:35 --> Database Driver Class Initialized
INFO - 2020-02-19 16:37:35 --> Model Class Initialized
DEBUG - 2020-02-19 16:37:35 --> Template Class Initialized
INFO - 2020-02-19 16:37:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:37:35 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:37:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:37:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:37:35 --> Encryption Class Initialized
INFO - 2020-02-19 16:37:35 --> Controller Class Initialized
DEBUG - 2020-02-19 16:37:35 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:37:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:37:35 --> Model Class Initialized
INFO - 2020-02-19 16:37:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:37:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:37:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:37:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:37:35 --> Model Class Initialized
DEBUG - 2020-02-19 16:37:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:37:35 --> Model Class Initialized
DEBUG - 2020-02-19 16:37:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:37:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:37:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:37:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:37:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:37:35 --> Final output sent to browser
DEBUG - 2020-02-19 16:37:35 --> Total execution time: 0.7876
INFO - 2020-02-19 16:39:56 --> Config Class Initialized
INFO - 2020-02-19 16:39:56 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:39:56 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:39:56 --> Utf8 Class Initialized
INFO - 2020-02-19 16:39:56 --> URI Class Initialized
INFO - 2020-02-19 16:39:56 --> Router Class Initialized
INFO - 2020-02-19 16:39:56 --> Output Class Initialized
INFO - 2020-02-19 16:39:56 --> Security Class Initialized
DEBUG - 2020-02-19 16:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:39:56 --> CSRF cookie sent
INFO - 2020-02-19 16:39:56 --> Input Class Initialized
INFO - 2020-02-19 16:39:56 --> Language Class Initialized
INFO - 2020-02-19 16:39:56 --> Language Class Initialized
INFO - 2020-02-19 16:39:56 --> Config Class Initialized
INFO - 2020-02-19 16:39:56 --> Loader Class Initialized
INFO - 2020-02-19 16:39:56 --> Helper loaded: url_helper
INFO - 2020-02-19 16:39:56 --> Helper loaded: common_helper
INFO - 2020-02-19 16:39:56 --> Helper loaded: language_helper
INFO - 2020-02-19 16:39:56 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:39:56 --> Helper loaded: email_helper
INFO - 2020-02-19 16:39:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:39:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:39:56 --> Parser Class Initialized
INFO - 2020-02-19 16:39:56 --> User Agent Class Initialized
INFO - 2020-02-19 16:39:56 --> Model Class Initialized
INFO - 2020-02-19 16:39:56 --> Database Driver Class Initialized
INFO - 2020-02-19 16:39:56 --> Model Class Initialized
DEBUG - 2020-02-19 16:39:56 --> Template Class Initialized
INFO - 2020-02-19 16:39:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:39:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:39:56 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:39:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:39:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:39:56 --> Encryption Class Initialized
INFO - 2020-02-19 16:39:56 --> Controller Class Initialized
DEBUG - 2020-02-19 16:39:56 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:39:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:39:56 --> Model Class Initialized
INFO - 2020-02-19 16:39:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:39:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:39:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:39:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:39:56 --> Model Class Initialized
DEBUG - 2020-02-19 16:39:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:39:56 --> Model Class Initialized
DEBUG - 2020-02-19 16:39:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:39:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:39:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:39:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:39:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:39:56 --> Final output sent to browser
DEBUG - 2020-02-19 16:39:56 --> Total execution time: 0.8177
INFO - 2020-02-19 16:41:03 --> Config Class Initialized
INFO - 2020-02-19 16:41:04 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:41:04 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:41:04 --> Utf8 Class Initialized
INFO - 2020-02-19 16:41:04 --> URI Class Initialized
INFO - 2020-02-19 16:41:04 --> Router Class Initialized
INFO - 2020-02-19 16:41:04 --> Output Class Initialized
INFO - 2020-02-19 16:41:04 --> Security Class Initialized
DEBUG - 2020-02-19 16:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:41:04 --> CSRF cookie sent
INFO - 2020-02-19 16:41:04 --> Input Class Initialized
INFO - 2020-02-19 16:41:04 --> Language Class Initialized
INFO - 2020-02-19 16:41:04 --> Language Class Initialized
INFO - 2020-02-19 16:41:04 --> Config Class Initialized
INFO - 2020-02-19 16:41:04 --> Loader Class Initialized
INFO - 2020-02-19 16:41:04 --> Helper loaded: url_helper
INFO - 2020-02-19 16:41:04 --> Helper loaded: common_helper
INFO - 2020-02-19 16:41:04 --> Helper loaded: language_helper
INFO - 2020-02-19 16:41:04 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:41:04 --> Helper loaded: email_helper
INFO - 2020-02-19 16:41:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:41:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:41:04 --> Parser Class Initialized
INFO - 2020-02-19 16:41:04 --> User Agent Class Initialized
INFO - 2020-02-19 16:41:04 --> Model Class Initialized
INFO - 2020-02-19 16:41:04 --> Database Driver Class Initialized
INFO - 2020-02-19 16:41:04 --> Model Class Initialized
DEBUG - 2020-02-19 16:41:04 --> Template Class Initialized
INFO - 2020-02-19 16:41:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:41:04 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:41:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:41:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:41:04 --> Encryption Class Initialized
INFO - 2020-02-19 16:41:04 --> Controller Class Initialized
DEBUG - 2020-02-19 16:41:04 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:41:04 --> Model Class Initialized
INFO - 2020-02-19 16:41:04 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:41:04 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:41:04 --> Model Class Initialized
DEBUG - 2020-02-19 16:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:41:04 --> Model Class Initialized
DEBUG - 2020-02-19 16:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:41:04 --> Final output sent to browser
DEBUG - 2020-02-19 16:41:04 --> Total execution time: 0.8289
INFO - 2020-02-19 16:41:40 --> Config Class Initialized
INFO - 2020-02-19 16:41:40 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:41:40 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:41:40 --> Utf8 Class Initialized
INFO - 2020-02-19 16:41:40 --> URI Class Initialized
INFO - 2020-02-19 16:41:40 --> Router Class Initialized
INFO - 2020-02-19 16:41:40 --> Output Class Initialized
INFO - 2020-02-19 16:41:40 --> Security Class Initialized
DEBUG - 2020-02-19 16:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:41:40 --> CSRF cookie sent
INFO - 2020-02-19 16:41:40 --> Input Class Initialized
INFO - 2020-02-19 16:41:40 --> Language Class Initialized
INFO - 2020-02-19 16:41:40 --> Language Class Initialized
INFO - 2020-02-19 16:41:40 --> Config Class Initialized
INFO - 2020-02-19 16:41:40 --> Loader Class Initialized
INFO - 2020-02-19 16:41:40 --> Helper loaded: url_helper
INFO - 2020-02-19 16:41:40 --> Helper loaded: common_helper
INFO - 2020-02-19 16:41:40 --> Helper loaded: language_helper
INFO - 2020-02-19 16:41:40 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:41:40 --> Helper loaded: email_helper
INFO - 2020-02-19 16:41:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:41:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:41:40 --> Parser Class Initialized
INFO - 2020-02-19 16:41:40 --> User Agent Class Initialized
INFO - 2020-02-19 16:41:40 --> Model Class Initialized
INFO - 2020-02-19 16:41:40 --> Database Driver Class Initialized
INFO - 2020-02-19 16:41:40 --> Model Class Initialized
DEBUG - 2020-02-19 16:41:40 --> Template Class Initialized
INFO - 2020-02-19 16:41:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:41:40 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:41:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:41:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:41:40 --> Encryption Class Initialized
INFO - 2020-02-19 16:41:40 --> Controller Class Initialized
DEBUG - 2020-02-19 16:41:40 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:41:40 --> Model Class Initialized
INFO - 2020-02-19 16:41:40 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:41:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:41:40 --> Model Class Initialized
DEBUG - 2020-02-19 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:41:40 --> Model Class Initialized
DEBUG - 2020-02-19 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:41:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:41:40 --> Final output sent to browser
DEBUG - 2020-02-19 16:41:40 --> Total execution time: 0.7400
INFO - 2020-02-19 16:43:39 --> Config Class Initialized
INFO - 2020-02-19 16:43:39 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:43:39 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:43:39 --> Utf8 Class Initialized
INFO - 2020-02-19 16:43:39 --> URI Class Initialized
INFO - 2020-02-19 16:43:39 --> Router Class Initialized
INFO - 2020-02-19 16:43:39 --> Output Class Initialized
INFO - 2020-02-19 16:43:39 --> Security Class Initialized
DEBUG - 2020-02-19 16:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:43:39 --> CSRF cookie sent
INFO - 2020-02-19 16:43:39 --> Input Class Initialized
INFO - 2020-02-19 16:43:39 --> Language Class Initialized
INFO - 2020-02-19 16:43:39 --> Language Class Initialized
INFO - 2020-02-19 16:43:39 --> Config Class Initialized
INFO - 2020-02-19 16:43:39 --> Loader Class Initialized
INFO - 2020-02-19 16:43:39 --> Helper loaded: url_helper
INFO - 2020-02-19 16:43:39 --> Helper loaded: common_helper
INFO - 2020-02-19 16:43:39 --> Helper loaded: language_helper
INFO - 2020-02-19 16:43:39 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:43:39 --> Helper loaded: email_helper
INFO - 2020-02-19 16:43:39 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:43:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:43:39 --> Parser Class Initialized
INFO - 2020-02-19 16:43:39 --> User Agent Class Initialized
INFO - 2020-02-19 16:43:39 --> Model Class Initialized
INFO - 2020-02-19 16:43:39 --> Database Driver Class Initialized
INFO - 2020-02-19 16:43:39 --> Model Class Initialized
DEBUG - 2020-02-19 16:43:39 --> Template Class Initialized
INFO - 2020-02-19 16:43:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:43:39 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:43:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:43:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:43:39 --> Encryption Class Initialized
INFO - 2020-02-19 16:43:39 --> Controller Class Initialized
DEBUG - 2020-02-19 16:43:39 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:43:39 --> Model Class Initialized
INFO - 2020-02-19 16:43:39 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:43:39 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:43:39 --> Model Class Initialized
DEBUG - 2020-02-19 16:43:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:43:39 --> Model Class Initialized
DEBUG - 2020-02-19 16:43:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:43:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:43:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:43:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:43:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:43:40 --> Final output sent to browser
DEBUG - 2020-02-19 16:43:40 --> Total execution time: 0.7336
INFO - 2020-02-19 16:44:40 --> Config Class Initialized
INFO - 2020-02-19 16:44:40 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:44:40 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:44:40 --> Utf8 Class Initialized
INFO - 2020-02-19 16:44:40 --> URI Class Initialized
INFO - 2020-02-19 16:44:40 --> Router Class Initialized
INFO - 2020-02-19 16:44:40 --> Output Class Initialized
INFO - 2020-02-19 16:44:40 --> Security Class Initialized
DEBUG - 2020-02-19 16:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:44:40 --> CSRF cookie sent
INFO - 2020-02-19 16:44:40 --> Input Class Initialized
INFO - 2020-02-19 16:44:40 --> Language Class Initialized
INFO - 2020-02-19 16:44:40 --> Language Class Initialized
INFO - 2020-02-19 16:44:40 --> Config Class Initialized
INFO - 2020-02-19 16:44:40 --> Loader Class Initialized
INFO - 2020-02-19 16:44:40 --> Helper loaded: url_helper
INFO - 2020-02-19 16:44:40 --> Helper loaded: common_helper
INFO - 2020-02-19 16:44:40 --> Helper loaded: language_helper
INFO - 2020-02-19 16:44:40 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:44:40 --> Helper loaded: email_helper
INFO - 2020-02-19 16:44:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:44:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:44:40 --> Parser Class Initialized
INFO - 2020-02-19 16:44:40 --> User Agent Class Initialized
INFO - 2020-02-19 16:44:40 --> Model Class Initialized
INFO - 2020-02-19 16:44:40 --> Database Driver Class Initialized
INFO - 2020-02-19 16:44:40 --> Model Class Initialized
DEBUG - 2020-02-19 16:44:40 --> Template Class Initialized
INFO - 2020-02-19 16:44:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:44:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:44:40 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:44:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:44:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:44:40 --> Encryption Class Initialized
INFO - 2020-02-19 16:44:40 --> Controller Class Initialized
DEBUG - 2020-02-19 16:44:40 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:44:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:44:40 --> Model Class Initialized
INFO - 2020-02-19 16:44:40 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:44:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:44:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:44:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:44:40 --> Model Class Initialized
DEBUG - 2020-02-19 16:44:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:44:40 --> Model Class Initialized
DEBUG - 2020-02-19 16:44:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:44:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:44:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:44:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:44:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:44:40 --> Final output sent to browser
DEBUG - 2020-02-19 16:44:40 --> Total execution time: 0.7852
INFO - 2020-02-19 16:45:43 --> Config Class Initialized
INFO - 2020-02-19 16:45:43 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:45:43 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:45:44 --> Utf8 Class Initialized
INFO - 2020-02-19 16:45:44 --> URI Class Initialized
INFO - 2020-02-19 16:45:44 --> Router Class Initialized
INFO - 2020-02-19 16:45:44 --> Output Class Initialized
INFO - 2020-02-19 16:45:44 --> Security Class Initialized
DEBUG - 2020-02-19 16:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:45:44 --> CSRF cookie sent
INFO - 2020-02-19 16:45:44 --> Input Class Initialized
INFO - 2020-02-19 16:45:44 --> Language Class Initialized
INFO - 2020-02-19 16:45:44 --> Language Class Initialized
INFO - 2020-02-19 16:45:44 --> Config Class Initialized
INFO - 2020-02-19 16:45:44 --> Loader Class Initialized
INFO - 2020-02-19 16:45:44 --> Helper loaded: url_helper
INFO - 2020-02-19 16:45:44 --> Helper loaded: common_helper
INFO - 2020-02-19 16:45:44 --> Helper loaded: language_helper
INFO - 2020-02-19 16:45:44 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:45:44 --> Helper loaded: email_helper
INFO - 2020-02-19 16:45:44 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:45:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:45:44 --> Parser Class Initialized
INFO - 2020-02-19 16:45:44 --> User Agent Class Initialized
INFO - 2020-02-19 16:45:44 --> Model Class Initialized
INFO - 2020-02-19 16:45:44 --> Database Driver Class Initialized
INFO - 2020-02-19 16:45:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:45:44 --> Template Class Initialized
INFO - 2020-02-19 16:45:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:45:44 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:45:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:45:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:45:44 --> Encryption Class Initialized
INFO - 2020-02-19 16:45:44 --> Controller Class Initialized
DEBUG - 2020-02-19 16:45:44 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:45:44 --> Model Class Initialized
INFO - 2020-02-19 16:45:44 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:45:44 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:45:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:45:44 --> Model Class Initialized
DEBUG - 2020-02-19 16:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:45:44 --> Final output sent to browser
DEBUG - 2020-02-19 16:45:44 --> Total execution time: 0.7756
INFO - 2020-02-19 16:46:33 --> Config Class Initialized
INFO - 2020-02-19 16:46:33 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:46:33 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:46:33 --> Utf8 Class Initialized
INFO - 2020-02-19 16:46:33 --> URI Class Initialized
INFO - 2020-02-19 16:46:33 --> Router Class Initialized
INFO - 2020-02-19 16:46:33 --> Output Class Initialized
INFO - 2020-02-19 16:46:33 --> Security Class Initialized
DEBUG - 2020-02-19 16:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:46:34 --> CSRF cookie sent
INFO - 2020-02-19 16:46:34 --> Input Class Initialized
INFO - 2020-02-19 16:46:34 --> Language Class Initialized
INFO - 2020-02-19 16:46:34 --> Language Class Initialized
INFO - 2020-02-19 16:46:34 --> Config Class Initialized
INFO - 2020-02-19 16:46:34 --> Loader Class Initialized
INFO - 2020-02-19 16:46:34 --> Helper loaded: url_helper
INFO - 2020-02-19 16:46:34 --> Helper loaded: common_helper
INFO - 2020-02-19 16:46:34 --> Helper loaded: language_helper
INFO - 2020-02-19 16:46:34 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:46:34 --> Helper loaded: email_helper
INFO - 2020-02-19 16:46:34 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:46:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:46:34 --> Parser Class Initialized
INFO - 2020-02-19 16:46:34 --> User Agent Class Initialized
INFO - 2020-02-19 16:46:34 --> Model Class Initialized
INFO - 2020-02-19 16:46:34 --> Database Driver Class Initialized
INFO - 2020-02-19 16:46:34 --> Model Class Initialized
DEBUG - 2020-02-19 16:46:34 --> Template Class Initialized
INFO - 2020-02-19 16:46:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:46:34 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:46:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:46:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:46:34 --> Encryption Class Initialized
INFO - 2020-02-19 16:46:34 --> Controller Class Initialized
DEBUG - 2020-02-19 16:46:34 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:46:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:46:34 --> Model Class Initialized
INFO - 2020-02-19 16:46:34 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:46:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:46:34 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:46:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:46:34 --> Model Class Initialized
DEBUG - 2020-02-19 16:46:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:46:34 --> Model Class Initialized
DEBUG - 2020-02-19 16:46:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:46:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:46:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:46:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:46:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:46:34 --> Final output sent to browser
DEBUG - 2020-02-19 16:46:34 --> Total execution time: 0.7961
INFO - 2020-02-19 16:47:51 --> Config Class Initialized
INFO - 2020-02-19 16:47:51 --> Hooks Class Initialized
DEBUG - 2020-02-19 16:47:51 --> UTF-8 Support Enabled
INFO - 2020-02-19 16:47:51 --> Utf8 Class Initialized
INFO - 2020-02-19 16:47:51 --> URI Class Initialized
INFO - 2020-02-19 16:47:51 --> Router Class Initialized
INFO - 2020-02-19 16:47:51 --> Output Class Initialized
INFO - 2020-02-19 16:47:51 --> Security Class Initialized
DEBUG - 2020-02-19 16:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 16:47:51 --> CSRF cookie sent
INFO - 2020-02-19 16:47:51 --> Input Class Initialized
INFO - 2020-02-19 16:47:51 --> Language Class Initialized
INFO - 2020-02-19 16:47:51 --> Language Class Initialized
INFO - 2020-02-19 16:47:51 --> Config Class Initialized
INFO - 2020-02-19 16:47:51 --> Loader Class Initialized
INFO - 2020-02-19 16:47:51 --> Helper loaded: url_helper
INFO - 2020-02-19 16:47:51 --> Helper loaded: common_helper
INFO - 2020-02-19 16:47:51 --> Helper loaded: language_helper
INFO - 2020-02-19 16:47:51 --> Helper loaded: cookie_helper
INFO - 2020-02-19 16:47:51 --> Helper loaded: email_helper
INFO - 2020-02-19 16:47:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 16:47:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 16:47:51 --> Parser Class Initialized
INFO - 2020-02-19 16:47:51 --> User Agent Class Initialized
INFO - 2020-02-19 16:47:51 --> Model Class Initialized
INFO - 2020-02-19 16:47:52 --> Database Driver Class Initialized
INFO - 2020-02-19 16:47:52 --> Model Class Initialized
DEBUG - 2020-02-19 16:47:52 --> Template Class Initialized
INFO - 2020-02-19 16:47:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 16:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 16:47:52 --> Pagination Class Initialized
DEBUG - 2020-02-19 16:47:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 16:47:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 16:47:52 --> Encryption Class Initialized
INFO - 2020-02-19 16:47:52 --> Controller Class Initialized
DEBUG - 2020-02-19 16:47:52 --> package MX_Controller Initialized
DEBUG - 2020-02-19 16:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 16:47:52 --> Model Class Initialized
INFO - 2020-02-19 16:47:52 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 16:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 16:47:52 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 16:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 16:47:52 --> Model Class Initialized
DEBUG - 2020-02-19 16:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 16:47:52 --> Model Class Initialized
DEBUG - 2020-02-19 16:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 16:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 16:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 16:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 16:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 16:47:52 --> Final output sent to browser
DEBUG - 2020-02-19 16:47:52 --> Total execution time: 0.7417
INFO - 2020-02-19 17:02:44 --> Config Class Initialized
INFO - 2020-02-19 17:02:44 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:02:44 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:02:44 --> Utf8 Class Initialized
INFO - 2020-02-19 17:02:44 --> URI Class Initialized
INFO - 2020-02-19 17:02:44 --> Router Class Initialized
INFO - 2020-02-19 17:02:44 --> Output Class Initialized
INFO - 2020-02-19 17:02:44 --> Security Class Initialized
DEBUG - 2020-02-19 17:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:02:44 --> CSRF cookie sent
INFO - 2020-02-19 17:02:44 --> Input Class Initialized
INFO - 2020-02-19 17:02:44 --> Language Class Initialized
INFO - 2020-02-19 17:02:44 --> Language Class Initialized
INFO - 2020-02-19 17:02:44 --> Config Class Initialized
INFO - 2020-02-19 17:02:44 --> Loader Class Initialized
INFO - 2020-02-19 17:02:44 --> Helper loaded: url_helper
INFO - 2020-02-19 17:02:44 --> Helper loaded: common_helper
INFO - 2020-02-19 17:02:44 --> Helper loaded: language_helper
INFO - 2020-02-19 17:02:44 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:02:44 --> Helper loaded: email_helper
INFO - 2020-02-19 17:02:44 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:02:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:02:44 --> Parser Class Initialized
INFO - 2020-02-19 17:02:44 --> User Agent Class Initialized
INFO - 2020-02-19 17:02:44 --> Model Class Initialized
INFO - 2020-02-19 17:02:44 --> Database Driver Class Initialized
INFO - 2020-02-19 17:02:44 --> Model Class Initialized
DEBUG - 2020-02-19 17:02:44 --> Template Class Initialized
INFO - 2020-02-19 17:02:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:02:44 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:02:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:02:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:02:45 --> Encryption Class Initialized
INFO - 2020-02-19 17:02:45 --> Controller Class Initialized
DEBUG - 2020-02-19 17:02:45 --> package MX_Controller Initialized
DEBUG - 2020-02-19 17:02:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 17:02:45 --> Model Class Initialized
INFO - 2020-02-19 17:02:45 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:02:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:02:45 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:02:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:02:45 --> Model Class Initialized
DEBUG - 2020-02-19 17:02:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:02:45 --> Model Class Initialized
DEBUG - 2020-02-19 17:02:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:02:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 17:02:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:02:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:02:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:02:45 --> Final output sent to browser
DEBUG - 2020-02-19 17:02:45 --> Total execution time: 0.8179
INFO - 2020-02-19 17:03:01 --> Config Class Initialized
INFO - 2020-02-19 17:03:01 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:01 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:01 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:01 --> URI Class Initialized
INFO - 2020-02-19 17:03:01 --> Router Class Initialized
INFO - 2020-02-19 17:03:01 --> Output Class Initialized
INFO - 2020-02-19 17:03:01 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:01 --> CSRF cookie sent
INFO - 2020-02-19 17:03:01 --> Input Class Initialized
INFO - 2020-02-19 17:03:01 --> Language Class Initialized
INFO - 2020-02-19 17:03:01 --> Language Class Initialized
INFO - 2020-02-19 17:03:02 --> Config Class Initialized
INFO - 2020-02-19 17:03:02 --> Loader Class Initialized
INFO - 2020-02-19 17:03:02 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:02 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:02 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:02 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:02 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:02 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:02 --> Parser Class Initialized
INFO - 2020-02-19 17:03:02 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:02 --> Model Class Initialized
INFO - 2020-02-19 17:03:02 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:02 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:02 --> Template Class Initialized
INFO - 2020-02-19 17:03:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:02 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:02 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:02 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:02 --> client MX_Controller Initialized
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/models/client_model.php
INFO - 2020-02-19 17:03:02 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/models/faqs_model.php
INFO - 2020-02-19 17:03:02 --> Model Class Initialized
INFO - 2020-02-19 17:03:02 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:02 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:02 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:02 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/faq/index.php
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:02 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:02 --> Total execution time: 0.8490
INFO - 2020-02-19 17:03:04 --> Config Class Initialized
INFO - 2020-02-19 17:03:04 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:04 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:04 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:04 --> URI Class Initialized
INFO - 2020-02-19 17:03:04 --> Router Class Initialized
INFO - 2020-02-19 17:03:04 --> Output Class Initialized
INFO - 2020-02-19 17:03:04 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:04 --> CSRF cookie sent
INFO - 2020-02-19 17:03:04 --> Input Class Initialized
INFO - 2020-02-19 17:03:04 --> Language Class Initialized
INFO - 2020-02-19 17:03:04 --> Language Class Initialized
INFO - 2020-02-19 17:03:04 --> Config Class Initialized
INFO - 2020-02-19 17:03:04 --> Loader Class Initialized
INFO - 2020-02-19 17:03:04 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:04 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:04 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:04 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:04 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:04 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:04 --> Parser Class Initialized
INFO - 2020-02-19 17:03:04 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:04 --> Model Class Initialized
INFO - 2020-02-19 17:03:04 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:04 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:04 --> Template Class Initialized
INFO - 2020-02-19 17:03:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:04 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:04 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:04 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:04 --> blog MX_Controller Initialized
INFO - 2020-02-19 17:03:04 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/models/blogs_model.php
INFO - 2020-02-19 17:03:04 --> Model Class Initialized
INFO - 2020-02-19 17:03:05 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:05 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:05 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:05 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/blog/index.php
DEBUG - 2020-02-19 17:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:05 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:05 --> Total execution time: 0.8801
INFO - 2020-02-19 17:03:14 --> Config Class Initialized
INFO - 2020-02-19 17:03:14 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:14 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:14 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:14 --> URI Class Initialized
INFO - 2020-02-19 17:03:14 --> Router Class Initialized
INFO - 2020-02-19 17:03:14 --> Output Class Initialized
INFO - 2020-02-19 17:03:14 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:14 --> CSRF cookie sent
INFO - 2020-02-19 17:03:14 --> Input Class Initialized
INFO - 2020-02-19 17:03:14 --> Language Class Initialized
INFO - 2020-02-19 17:03:14 --> Language Class Initialized
INFO - 2020-02-19 17:03:14 --> Config Class Initialized
INFO - 2020-02-19 17:03:14 --> Loader Class Initialized
INFO - 2020-02-19 17:03:14 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:14 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:14 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:14 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:14 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:14 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:14 --> Parser Class Initialized
INFO - 2020-02-19 17:03:14 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:14 --> Model Class Initialized
INFO - 2020-02-19 17:03:14 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:14 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:14 --> Template Class Initialized
INFO - 2020-02-19 17:03:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:14 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:14 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:14 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:14 --> blog MX_Controller Initialized
INFO - 2020-02-19 17:03:14 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/models/blogs_model.php
INFO - 2020-02-19 17:03:14 --> Model Class Initialized
INFO - 2020-02-19 17:03:14 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:14 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:14 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:14 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/blog/blog_detail.php
DEBUG - 2020-02-19 17:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:14 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:14 --> Total execution time: 0.8629
INFO - 2020-02-19 17:03:23 --> Config Class Initialized
INFO - 2020-02-19 17:03:23 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:23 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:23 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:23 --> URI Class Initialized
INFO - 2020-02-19 17:03:23 --> Router Class Initialized
INFO - 2020-02-19 17:03:23 --> Output Class Initialized
INFO - 2020-02-19 17:03:23 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:23 --> CSRF cookie sent
INFO - 2020-02-19 17:03:23 --> Input Class Initialized
INFO - 2020-02-19 17:03:23 --> Language Class Initialized
INFO - 2020-02-19 17:03:23 --> Language Class Initialized
INFO - 2020-02-19 17:03:23 --> Config Class Initialized
INFO - 2020-02-19 17:03:23 --> Loader Class Initialized
INFO - 2020-02-19 17:03:23 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:23 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:23 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:23 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:23 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:23 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:23 --> Parser Class Initialized
INFO - 2020-02-19 17:03:23 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:23 --> Model Class Initialized
INFO - 2020-02-19 17:03:23 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:23 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:23 --> Template Class Initialized
INFO - 2020-02-19 17:03:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:23 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:23 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:23 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:23 --> blog MX_Controller Initialized
INFO - 2020-02-19 17:03:23 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/models/blogs_model.php
INFO - 2020-02-19 17:03:24 --> Model Class Initialized
INFO - 2020-02-19 17:03:24 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:24 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:24 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:24 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/blog/index.php
DEBUG - 2020-02-19 17:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:24 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:24 --> Total execution time: 0.8920
INFO - 2020-02-19 17:03:32 --> Config Class Initialized
INFO - 2020-02-19 17:03:32 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:32 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:32 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:32 --> URI Class Initialized
INFO - 2020-02-19 17:03:33 --> Router Class Initialized
INFO - 2020-02-19 17:03:33 --> Output Class Initialized
INFO - 2020-02-19 17:03:33 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:33 --> CSRF cookie sent
INFO - 2020-02-19 17:03:33 --> Input Class Initialized
INFO - 2020-02-19 17:03:33 --> Language Class Initialized
INFO - 2020-02-19 17:03:33 --> Language Class Initialized
INFO - 2020-02-19 17:03:33 --> Config Class Initialized
INFO - 2020-02-19 17:03:33 --> Loader Class Initialized
INFO - 2020-02-19 17:03:33 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:33 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:33 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:33 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:33 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:33 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:33 --> Parser Class Initialized
INFO - 2020-02-19 17:03:33 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:33 --> Model Class Initialized
INFO - 2020-02-19 17:03:33 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:33 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:33 --> Template Class Initialized
INFO - 2020-02-19 17:03:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:33 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:33 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:33 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:33 --> blog MX_Controller Initialized
INFO - 2020-02-19 17:03:33 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/models/blogs_model.php
INFO - 2020-02-19 17:03:33 --> Model Class Initialized
INFO - 2020-02-19 17:03:33 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:33 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:33 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:33 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:03:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/blog/index.php
DEBUG - 2020-02-19 17:03:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:33 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:33 --> Total execution time: 0.8011
INFO - 2020-02-19 17:03:41 --> Config Class Initialized
INFO - 2020-02-19 17:03:41 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:41 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:41 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:41 --> URI Class Initialized
INFO - 2020-02-19 17:03:41 --> Router Class Initialized
INFO - 2020-02-19 17:03:41 --> Output Class Initialized
INFO - 2020-02-19 17:03:41 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:41 --> CSRF cookie sent
INFO - 2020-02-19 17:03:41 --> Input Class Initialized
INFO - 2020-02-19 17:03:41 --> Language Class Initialized
INFO - 2020-02-19 17:03:41 --> Language Class Initialized
INFO - 2020-02-19 17:03:41 --> Config Class Initialized
INFO - 2020-02-19 17:03:41 --> Loader Class Initialized
INFO - 2020-02-19 17:03:41 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:41 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:41 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:41 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:41 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:41 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:41 --> Parser Class Initialized
INFO - 2020-02-19 17:03:41 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:41 --> Model Class Initialized
INFO - 2020-02-19 17:03:41 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:41 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:41 --> Template Class Initialized
INFO - 2020-02-19 17:03:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:42 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:42 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:42 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:42 --> blog MX_Controller Initialized
INFO - 2020-02-19 17:03:42 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/models/blogs_model.php
INFO - 2020-02-19 17:03:42 --> Model Class Initialized
INFO - 2020-02-19 17:03:42 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:42 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:42 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:42 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/blog/blog_detail.php
DEBUG - 2020-02-19 17:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:42 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:42 --> Total execution time: 0.7597
INFO - 2020-02-19 17:03:45 --> Config Class Initialized
INFO - 2020-02-19 17:03:45 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:45 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:45 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:45 --> URI Class Initialized
INFO - 2020-02-19 17:03:45 --> Router Class Initialized
INFO - 2020-02-19 17:03:45 --> Output Class Initialized
INFO - 2020-02-19 17:03:45 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:45 --> CSRF cookie sent
INFO - 2020-02-19 17:03:45 --> Input Class Initialized
INFO - 2020-02-19 17:03:45 --> Language Class Initialized
INFO - 2020-02-19 17:03:45 --> Language Class Initialized
INFO - 2020-02-19 17:03:45 --> Config Class Initialized
INFO - 2020-02-19 17:03:45 --> Loader Class Initialized
INFO - 2020-02-19 17:03:45 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:45 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:45 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:45 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:45 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:45 --> Parser Class Initialized
INFO - 2020-02-19 17:03:45 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:45 --> Model Class Initialized
INFO - 2020-02-19 17:03:45 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:45 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:45 --> Template Class Initialized
INFO - 2020-02-19 17:03:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:45 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:45 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:45 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:45 --> blog MX_Controller Initialized
INFO - 2020-02-19 17:03:46 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/models/blogs_model.php
INFO - 2020-02-19 17:03:46 --> Model Class Initialized
INFO - 2020-02-19 17:03:46 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:46 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:46 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:46 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:03:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/blog/index.php
DEBUG - 2020-02-19 17:03:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:46 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:46 --> Total execution time: 0.7825
INFO - 2020-02-19 17:03:54 --> Config Class Initialized
INFO - 2020-02-19 17:03:54 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:54 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:54 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:54 --> URI Class Initialized
INFO - 2020-02-19 17:03:54 --> Router Class Initialized
INFO - 2020-02-19 17:03:54 --> Output Class Initialized
INFO - 2020-02-19 17:03:54 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:55 --> CSRF cookie sent
INFO - 2020-02-19 17:03:55 --> Input Class Initialized
INFO - 2020-02-19 17:03:55 --> Language Class Initialized
INFO - 2020-02-19 17:03:55 --> Language Class Initialized
INFO - 2020-02-19 17:03:55 --> Config Class Initialized
INFO - 2020-02-19 17:03:55 --> Loader Class Initialized
INFO - 2020-02-19 17:03:55 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:55 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:55 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:55 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:55 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:55 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:55 --> Parser Class Initialized
INFO - 2020-02-19 17:03:55 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:55 --> Model Class Initialized
INFO - 2020-02-19 17:03:55 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:55 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:55 --> Template Class Initialized
INFO - 2020-02-19 17:03:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:55 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:55 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:55 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:55 --> client MX_Controller Initialized
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/models/client_model.php
INFO - 2020-02-19 17:03:55 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/models/faqs_model.php
INFO - 2020-02-19 17:03:55 --> Model Class Initialized
INFO - 2020-02-19 17:03:55 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:55 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:55 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:55 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/faq/index.php
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:55 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:55 --> Total execution time: 0.8137
INFO - 2020-02-19 17:03:56 --> Config Class Initialized
INFO - 2020-02-19 17:03:56 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:56 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:56 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:56 --> URI Class Initialized
INFO - 2020-02-19 17:03:56 --> Router Class Initialized
INFO - 2020-02-19 17:03:56 --> Output Class Initialized
INFO - 2020-02-19 17:03:57 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:57 --> CSRF cookie sent
INFO - 2020-02-19 17:03:57 --> Input Class Initialized
INFO - 2020-02-19 17:03:57 --> Language Class Initialized
INFO - 2020-02-19 17:03:57 --> Language Class Initialized
INFO - 2020-02-19 17:03:57 --> Config Class Initialized
INFO - 2020-02-19 17:03:57 --> Loader Class Initialized
INFO - 2020-02-19 17:03:57 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:57 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:57 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:57 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:57 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:57 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:57 --> Parser Class Initialized
INFO - 2020-02-19 17:03:57 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:57 --> Model Class Initialized
INFO - 2020-02-19 17:03:57 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:57 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:57 --> Template Class Initialized
INFO - 2020-02-19 17:03:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:57 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:57 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:57 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:57 --> contact MX_Controller Initialized
DEBUG - 2020-02-19 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/contact/models/contact_model.php
INFO - 2020-02-19 17:03:57 --> Model Class Initialized
INFO - 2020-02-19 17:03:57 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:57 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:57 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:57 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
ERROR - 2020-02-19 17:03:57 --> Could not find the language line "order_id"
ERROR - 2020-02-19 17:03:57 --> Could not find the language line "enter_the_transaction_id"
DEBUG - 2020-02-19 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/contact/views/index.php
DEBUG - 2020-02-19 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:57 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:57 --> Total execution time: 0.8673
INFO - 2020-02-19 17:03:58 --> Config Class Initialized
INFO - 2020-02-19 17:03:58 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:03:58 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:03:59 --> Utf8 Class Initialized
INFO - 2020-02-19 17:03:59 --> URI Class Initialized
INFO - 2020-02-19 17:03:59 --> Router Class Initialized
INFO - 2020-02-19 17:03:59 --> Output Class Initialized
INFO - 2020-02-19 17:03:59 --> Security Class Initialized
DEBUG - 2020-02-19 17:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:03:59 --> CSRF cookie sent
INFO - 2020-02-19 17:03:59 --> Input Class Initialized
INFO - 2020-02-19 17:03:59 --> Language Class Initialized
INFO - 2020-02-19 17:03:59 --> Language Class Initialized
INFO - 2020-02-19 17:03:59 --> Config Class Initialized
INFO - 2020-02-19 17:03:59 --> Loader Class Initialized
INFO - 2020-02-19 17:03:59 --> Helper loaded: url_helper
INFO - 2020-02-19 17:03:59 --> Helper loaded: common_helper
INFO - 2020-02-19 17:03:59 --> Helper loaded: language_helper
INFO - 2020-02-19 17:03:59 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:03:59 --> Helper loaded: email_helper
INFO - 2020-02-19 17:03:59 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:03:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:03:59 --> Parser Class Initialized
INFO - 2020-02-19 17:03:59 --> User Agent Class Initialized
INFO - 2020-02-19 17:03:59 --> Model Class Initialized
INFO - 2020-02-19 17:03:59 --> Database Driver Class Initialized
INFO - 2020-02-19 17:03:59 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:59 --> Template Class Initialized
INFO - 2020-02-19 17:03:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:03:59 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:03:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:03:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:03:59 --> Encryption Class Initialized
INFO - 2020-02-19 17:03:59 --> Controller Class Initialized
DEBUG - 2020-02-19 17:03:59 --> client MX_Controller Initialized
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/models/client_model.php
INFO - 2020-02-19 17:03:59 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/models/faqs_model.php
INFO - 2020-02-19 17:03:59 --> Model Class Initialized
INFO - 2020-02-19 17:03:59 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:03:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:03:59 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:03:59 --> Model Class Initialized
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/client/views/faq/index.php
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:03:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:03:59 --> Final output sent to browser
DEBUG - 2020-02-19 17:03:59 --> Total execution time: 0.7926
INFO - 2020-02-19 17:04:01 --> Config Class Initialized
INFO - 2020-02-19 17:04:02 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:04:02 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:04:02 --> Utf8 Class Initialized
INFO - 2020-02-19 17:04:02 --> URI Class Initialized
INFO - 2020-02-19 17:04:02 --> Router Class Initialized
INFO - 2020-02-19 17:04:02 --> Output Class Initialized
INFO - 2020-02-19 17:04:02 --> Security Class Initialized
DEBUG - 2020-02-19 17:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:04:02 --> CSRF cookie sent
INFO - 2020-02-19 17:04:02 --> Input Class Initialized
INFO - 2020-02-19 17:04:02 --> Language Class Initialized
INFO - 2020-02-19 17:04:02 --> Language Class Initialized
INFO - 2020-02-19 17:04:02 --> Config Class Initialized
INFO - 2020-02-19 17:04:02 --> Loader Class Initialized
INFO - 2020-02-19 17:04:02 --> Helper loaded: url_helper
INFO - 2020-02-19 17:04:02 --> Helper loaded: common_helper
INFO - 2020-02-19 17:04:02 --> Helper loaded: language_helper
INFO - 2020-02-19 17:04:02 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:04:02 --> Helper loaded: email_helper
INFO - 2020-02-19 17:04:02 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:04:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:04:02 --> Parser Class Initialized
INFO - 2020-02-19 17:04:02 --> User Agent Class Initialized
INFO - 2020-02-19 17:04:02 --> Model Class Initialized
INFO - 2020-02-19 17:04:02 --> Database Driver Class Initialized
INFO - 2020-02-19 17:04:02 --> Model Class Initialized
DEBUG - 2020-02-19 17:04:02 --> Template Class Initialized
INFO - 2020-02-19 17:04:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:04:02 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:04:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:04:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:04:02 --> Encryption Class Initialized
INFO - 2020-02-19 17:04:02 --> Controller Class Initialized
DEBUG - 2020-02-19 17:04:02 --> package MX_Controller Initialized
DEBUG - 2020-02-19 17:04:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 17:04:02 --> Model Class Initialized
INFO - 2020-02-19 17:04:02 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:04:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:04:02 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:04:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:04:02 --> Model Class Initialized
DEBUG - 2020-02-19 17:04:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:04:02 --> Model Class Initialized
DEBUG - 2020-02-19 17:04:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 17:04:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 17:04:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 17:04:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 17:04:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 17:04:02 --> Final output sent to browser
DEBUG - 2020-02-19 17:04:02 --> Total execution time: 0.9578
INFO - 2020-02-19 17:06:24 --> Config Class Initialized
INFO - 2020-02-19 17:06:24 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:06:24 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:06:24 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:24 --> URI Class Initialized
INFO - 2020-02-19 17:06:24 --> Router Class Initialized
INFO - 2020-02-19 17:06:24 --> Output Class Initialized
INFO - 2020-02-19 17:06:24 --> Security Class Initialized
DEBUG - 2020-02-19 17:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:06:24 --> CSRF cookie sent
INFO - 2020-02-19 17:06:24 --> Input Class Initialized
INFO - 2020-02-19 17:06:24 --> Language Class Initialized
INFO - 2020-02-19 17:06:24 --> Language Class Initialized
INFO - 2020-02-19 17:06:24 --> Config Class Initialized
INFO - 2020-02-19 17:06:24 --> Loader Class Initialized
INFO - 2020-02-19 17:06:24 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:24 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:24 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:24 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:24 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:24 --> Parser Class Initialized
INFO - 2020-02-19 17:06:24 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:24 --> Model Class Initialized
INFO - 2020-02-19 17:06:24 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:25 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:25 --> Template Class Initialized
INFO - 2020-02-19 17:06:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:25 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:25 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:25 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:25 --> auth MX_Controller Initialized
DEBUG - 2020-02-19 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2020-02-19 17:06:25 --> Model Class Initialized
INFO - 2020-02-19 17:06:25 --> Config Class Initialized
INFO - 2020-02-19 17:06:25 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:06:25 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:06:25 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:25 --> URI Class Initialized
INFO - 2020-02-19 17:06:25 --> Router Class Initialized
INFO - 2020-02-19 17:06:25 --> Output Class Initialized
INFO - 2020-02-19 17:06:25 --> Security Class Initialized
DEBUG - 2020-02-19 17:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:06:25 --> CSRF cookie sent
INFO - 2020-02-19 17:06:25 --> Input Class Initialized
INFO - 2020-02-19 17:06:25 --> Language Class Initialized
INFO - 2020-02-19 17:06:25 --> Language Class Initialized
INFO - 2020-02-19 17:06:25 --> Config Class Initialized
INFO - 2020-02-19 17:06:25 --> Loader Class Initialized
INFO - 2020-02-19 17:06:25 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:25 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:25 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:25 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:25 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:25 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:25 --> Parser Class Initialized
INFO - 2020-02-19 17:06:25 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:25 --> Model Class Initialized
INFO - 2020-02-19 17:06:25 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:25 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:25 --> Template Class Initialized
INFO - 2020-02-19 17:06:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:25 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:25 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:25 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:25 --> statistics MX_Controller Initialized
DEBUG - 2020-02-19 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2020-02-19 17:06:25 --> Model Class Initialized
ERROR - 2020-02-19 17:06:25 --> Could not find the language line "Pending"
ERROR - 2020-02-19 17:06:25 --> Could not find the language line "Pending"
INFO - 2020-02-19 17:06:25 --> Helper loaded: inflector_helper
ERROR - 2020-02-19 17:06:25 --> Could not find the language line "total_orders"
ERROR - 2020-02-19 17:06:25 --> Could not find the language line "total_orders"
ERROR - 2020-02-19 17:06:25 --> Could not find the language line "Pending"
DEBUG - 2020-02-19 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2020-02-19 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:06:25 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:06:26 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:26 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:06:26 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:26 --> Total execution time: 1.0200
INFO - 2020-02-19 17:06:32 --> Config Class Initialized
INFO - 2020-02-19 17:06:32 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:06:32 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:06:32 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:32 --> URI Class Initialized
INFO - 2020-02-19 17:06:32 --> Router Class Initialized
INFO - 2020-02-19 17:06:32 --> Output Class Initialized
INFO - 2020-02-19 17:06:32 --> Security Class Initialized
DEBUG - 2020-02-19 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:06:32 --> CSRF cookie sent
INFO - 2020-02-19 17:06:32 --> Input Class Initialized
INFO - 2020-02-19 17:06:32 --> Language Class Initialized
INFO - 2020-02-19 17:06:32 --> Language Class Initialized
INFO - 2020-02-19 17:06:32 --> Config Class Initialized
INFO - 2020-02-19 17:06:32 --> Loader Class Initialized
INFO - 2020-02-19 17:06:32 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:32 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:32 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:32 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:32 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:32 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:32 --> Parser Class Initialized
INFO - 2020-02-19 17:06:32 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:32 --> Model Class Initialized
INFO - 2020-02-19 17:06:32 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:32 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:32 --> Template Class Initialized
INFO - 2020-02-19 17:06:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:32 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:32 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:32 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:32 --> setting MX_Controller Initialized
DEBUG - 2020-02-19 17:06:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2020-02-19 17:06:32 --> Model Class Initialized
INFO - 2020-02-19 17:06:32 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2020-02-19 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2020-02-19 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2020-02-19 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:06:33 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:06:33 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:33 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:06:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:06:33 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:33 --> Total execution time: 1.2261
INFO - 2020-02-19 17:06:40 --> Config Class Initialized
INFO - 2020-02-19 17:06:40 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:06:40 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:06:40 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:40 --> URI Class Initialized
INFO - 2020-02-19 17:06:40 --> Router Class Initialized
INFO - 2020-02-19 17:06:40 --> Output Class Initialized
INFO - 2020-02-19 17:06:40 --> Security Class Initialized
DEBUG - 2020-02-19 17:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:06:40 --> CSRF cookie sent
INFO - 2020-02-19 17:06:40 --> Input Class Initialized
INFO - 2020-02-19 17:06:40 --> Language Class Initialized
INFO - 2020-02-19 17:06:40 --> Language Class Initialized
INFO - 2020-02-19 17:06:40 --> Config Class Initialized
INFO - 2020-02-19 17:06:40 --> Loader Class Initialized
INFO - 2020-02-19 17:06:40 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:40 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:40 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:40 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:40 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:40 --> Parser Class Initialized
INFO - 2020-02-19 17:06:40 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:40 --> Model Class Initialized
INFO - 2020-02-19 17:06:40 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:41 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:41 --> Template Class Initialized
INFO - 2020-02-19 17:06:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:41 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:41 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:41 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:41 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:06:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:41 --> Model Class Initialized
ERROR - 2020-02-19 17:06:41 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:06:41 --> Helper loaded: inflector_helper
ERROR - 2020-02-19 17:06:41 --> Could not find the language line "Delele"
DEBUG - 2020-02-19 17:06:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2020-02-19 17:06:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:06:41 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:06:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:06:41 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:41 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:41 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:06:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:06:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:06:41 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:41 --> Total execution time: 0.8978
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Hooks Class Initialized
INFO - 2020-02-19 17:06:41 --> Hooks Class Initialized
INFO - 2020-02-19 17:06:41 --> Hooks Class Initialized
INFO - 2020-02-19 17:06:41 --> Hooks Class Initialized
INFO - 2020-02-19 17:06:41 --> Hooks Class Initialized
INFO - 2020-02-19 17:06:41 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:06:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 17:06:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 17:06:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 17:06:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 17:06:41 --> UTF-8 Support Enabled
DEBUG - 2020-02-19 17:06:41 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:06:41 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:41 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:41 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:41 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:41 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:41 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:41 --> URI Class Initialized
INFO - 2020-02-19 17:06:41 --> URI Class Initialized
INFO - 2020-02-19 17:06:41 --> URI Class Initialized
INFO - 2020-02-19 17:06:41 --> URI Class Initialized
INFO - 2020-02-19 17:06:41 --> URI Class Initialized
INFO - 2020-02-19 17:06:41 --> URI Class Initialized
INFO - 2020-02-19 17:06:41 --> Router Class Initialized
INFO - 2020-02-19 17:06:41 --> Router Class Initialized
INFO - 2020-02-19 17:06:41 --> Router Class Initialized
INFO - 2020-02-19 17:06:41 --> Router Class Initialized
INFO - 2020-02-19 17:06:41 --> Router Class Initialized
INFO - 2020-02-19 17:06:41 --> Router Class Initialized
INFO - 2020-02-19 17:06:41 --> Output Class Initialized
INFO - 2020-02-19 17:06:41 --> Output Class Initialized
INFO - 2020-02-19 17:06:41 --> Output Class Initialized
INFO - 2020-02-19 17:06:41 --> Output Class Initialized
INFO - 2020-02-19 17:06:41 --> Output Class Initialized
INFO - 2020-02-19 17:06:41 --> Output Class Initialized
INFO - 2020-02-19 17:06:41 --> Security Class Initialized
INFO - 2020-02-19 17:06:41 --> Security Class Initialized
INFO - 2020-02-19 17:06:41 --> Security Class Initialized
INFO - 2020-02-19 17:06:41 --> Security Class Initialized
INFO - 2020-02-19 17:06:41 --> Security Class Initialized
INFO - 2020-02-19 17:06:41 --> Security Class Initialized
DEBUG - 2020-02-19 17:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 17:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 17:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 17:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 17:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 17:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:06:41 --> CSRF cookie sent
INFO - 2020-02-19 17:06:41 --> CSRF cookie sent
INFO - 2020-02-19 17:06:41 --> CSRF cookie sent
INFO - 2020-02-19 17:06:41 --> CSRF cookie sent
INFO - 2020-02-19 17:06:41 --> CSRF cookie sent
INFO - 2020-02-19 17:06:41 --> CSRF cookie sent
INFO - 2020-02-19 17:06:41 --> CSRF token verified
INFO - 2020-02-19 17:06:41 --> CSRF token verified
INFO - 2020-02-19 17:06:41 --> CSRF token verified
INFO - 2020-02-19 17:06:41 --> CSRF token verified
INFO - 2020-02-19 17:06:41 --> CSRF token verified
INFO - 2020-02-19 17:06:41 --> CSRF token verified
INFO - 2020-02-19 17:06:41 --> Input Class Initialized
INFO - 2020-02-19 17:06:41 --> Input Class Initialized
INFO - 2020-02-19 17:06:41 --> Input Class Initialized
INFO - 2020-02-19 17:06:41 --> Input Class Initialized
INFO - 2020-02-19 17:06:41 --> Input Class Initialized
INFO - 2020-02-19 17:06:41 --> Input Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Language Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Config Class Initialized
INFO - 2020-02-19 17:06:41 --> Loader Class Initialized
INFO - 2020-02-19 17:06:41 --> Loader Class Initialized
INFO - 2020-02-19 17:06:41 --> Loader Class Initialized
INFO - 2020-02-19 17:06:41 --> Loader Class Initialized
INFO - 2020-02-19 17:06:41 --> Loader Class Initialized
INFO - 2020-02-19 17:06:41 --> Loader Class Initialized
INFO - 2020-02-19 17:06:41 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:41 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:42 --> Parser Class Initialized
INFO - 2020-02-19 17:06:42 --> Parser Class Initialized
INFO - 2020-02-19 17:06:42 --> Parser Class Initialized
INFO - 2020-02-19 17:06:42 --> Parser Class Initialized
INFO - 2020-02-19 17:06:42 --> Parser Class Initialized
INFO - 2020-02-19 17:06:42 --> Parser Class Initialized
INFO - 2020-02-19 17:06:42 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:42 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:42 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:42 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:42 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:42 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:42 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:42 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:42 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:42 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:42 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Template Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Template Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Template Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Template Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Template Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Template Class Initialized
INFO - 2020-02-19 17:06:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:42 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:42 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:42 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:42 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "Sorting"
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "View"
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "View"
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "View"
DEBUG - 2020-02-19 17:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-19 17:06:42 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:42 --> Total execution time: 0.7279
INFO - 2020-02-19 17:06:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:42 --> Config Class Initialized
INFO - 2020-02-19 17:06:42 --> Hooks Class Initialized
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:42 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:42 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:06:42 --> Utf8 Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:42 --> URI Class Initialized
INFO - 2020-02-19 17:06:42 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:42 --> Router Class Initialized
INFO - 2020-02-19 17:06:42 --> Controller Class Initialized
INFO - 2020-02-19 17:06:42 --> Output Class Initialized
DEBUG - 2020-02-19 17:06:42 --> category MX_Controller Initialized
INFO - 2020-02-19 17:06:42 --> Security Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-19 17:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> CSRF cookie sent
INFO - 2020-02-19 17:06:42 --> CSRF token verified
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:06:42 --> Input Class Initialized
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "View"
INFO - 2020-02-19 17:06:42 --> Language Class Initialized
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "View"
INFO - 2020-02-19 17:06:42 --> Language Class Initialized
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "View"
INFO - 2020-02-19 17:06:42 --> Config Class Initialized
DEBUG - 2020-02-19 17:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-19 17:06:42 --> Final output sent to browser
INFO - 2020-02-19 17:06:42 --> Loader Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Total execution time: 0.9478
INFO - 2020-02-19 17:06:42 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:42 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:42 --> Pagination Class Initialized
INFO - 2020-02-19 17:06:42 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:42 --> Helper loaded: email_helper
DEBUG - 2020-02-19 17:06:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:42 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:42 --> Controller Class Initialized
INFO - 2020-02-19 17:06:42 --> Parser Class Initialized
DEBUG - 2020-02-19 17:06:42 --> category MX_Controller Initialized
INFO - 2020-02-19 17:06:42 --> User Agent Class Initialized
DEBUG - 2020-02-19 17:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
INFO - 2020-02-19 17:06:42 --> Database Driver Class Initialized
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Template Class Initialized
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "View"
DEBUG - 2020-02-19 17:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-19 17:06:42 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:42 --> Total execution time: 1.1579
INFO - 2020-02-19 17:06:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:42 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:42 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:42 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:42 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:42 --> Model Class Initialized
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "Sorting"
ERROR - 2020-02-19 17:06:42 --> Could not find the language line "View"
DEBUG - 2020-02-19 17:06:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-19 17:06:43 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:43 --> Total execution time: 1.3501
INFO - 2020-02-19 17:06:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:43 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:43 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:43 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:43 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:06:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:43 --> Model Class Initialized
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "Sorting"
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "View"
DEBUG - 2020-02-19 17:06:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-19 17:06:43 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:43 --> Total execution time: 1.5599
INFO - 2020-02-19 17:06:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:43 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:43 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:43 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:43 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:06:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:43 --> Model Class Initialized
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "Sorting"
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "View"
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "View"
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "View"
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "View"
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "View"
DEBUG - 2020-02-19 17:06:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-19 17:06:43 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:43 --> Total execution time: 1.8607
INFO - 2020-02-19 17:06:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:43 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:43 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:43 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:43 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:06:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:43 --> Model Class Initialized
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "Sorting"
ERROR - 2020-02-19 17:06:43 --> Could not find the language line "View"
DEBUG - 2020-02-19 17:06:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2020-02-19 17:06:43 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:43 --> Total execution time: 1.3052
INFO - 2020-02-19 17:06:45 --> Config Class Initialized
INFO - 2020-02-19 17:06:45 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:06:45 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:06:45 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:46 --> URI Class Initialized
INFO - 2020-02-19 17:06:46 --> Router Class Initialized
INFO - 2020-02-19 17:06:46 --> Output Class Initialized
INFO - 2020-02-19 17:06:46 --> Security Class Initialized
DEBUG - 2020-02-19 17:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:06:46 --> CSRF cookie sent
INFO - 2020-02-19 17:06:46 --> Input Class Initialized
INFO - 2020-02-19 17:06:46 --> Language Class Initialized
INFO - 2020-02-19 17:06:46 --> Language Class Initialized
INFO - 2020-02-19 17:06:46 --> Config Class Initialized
INFO - 2020-02-19 17:06:46 --> Loader Class Initialized
INFO - 2020-02-19 17:06:46 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:46 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:46 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:46 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:46 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:46 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:46 --> Parser Class Initialized
INFO - 2020-02-19 17:06:46 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:46 --> Model Class Initialized
INFO - 2020-02-19 17:06:46 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:46 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:46 --> Template Class Initialized
INFO - 2020-02-19 17:06:52 --> Config Class Initialized
INFO - 2020-02-19 17:06:52 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:06:52 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:06:52 --> Utf8 Class Initialized
INFO - 2020-02-19 17:06:52 --> URI Class Initialized
INFO - 2020-02-19 17:06:52 --> Router Class Initialized
INFO - 2020-02-19 17:06:52 --> Output Class Initialized
INFO - 2020-02-19 17:06:52 --> Security Class Initialized
DEBUG - 2020-02-19 17:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:06:52 --> CSRF cookie sent
INFO - 2020-02-19 17:06:52 --> Input Class Initialized
INFO - 2020-02-19 17:06:52 --> Language Class Initialized
INFO - 2020-02-19 17:06:52 --> Language Class Initialized
INFO - 2020-02-19 17:06:52 --> Config Class Initialized
INFO - 2020-02-19 17:06:53 --> Loader Class Initialized
INFO - 2020-02-19 17:06:53 --> Helper loaded: url_helper
INFO - 2020-02-19 17:06:53 --> Helper loaded: common_helper
INFO - 2020-02-19 17:06:53 --> Helper loaded: language_helper
INFO - 2020-02-19 17:06:53 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:06:53 --> Helper loaded: email_helper
INFO - 2020-02-19 17:06:53 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:06:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:06:53 --> Parser Class Initialized
INFO - 2020-02-19 17:06:53 --> User Agent Class Initialized
INFO - 2020-02-19 17:06:53 --> Model Class Initialized
INFO - 2020-02-19 17:06:53 --> Database Driver Class Initialized
INFO - 2020-02-19 17:06:53 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:53 --> Template Class Initialized
INFO - 2020-02-19 17:06:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:06:53 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:06:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:06:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:06:53 --> Encryption Class Initialized
INFO - 2020-02-19 17:06:53 --> Controller Class Initialized
DEBUG - 2020-02-19 17:06:53 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:53 --> Model Class Initialized
ERROR - 2020-02-19 17:06:53 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:06:53 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:06:53 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:06:53 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:53 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:06:53 --> Model Class Initialized
DEBUG - 2020-02-19 17:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:06:53 --> Final output sent to browser
DEBUG - 2020-02-19 17:06:53 --> Total execution time: 1.0928
INFO - 2020-02-19 17:10:32 --> Config Class Initialized
INFO - 2020-02-19 17:10:32 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:10:32 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:10:32 --> Utf8 Class Initialized
INFO - 2020-02-19 17:10:32 --> URI Class Initialized
INFO - 2020-02-19 17:10:32 --> Router Class Initialized
INFO - 2020-02-19 17:10:32 --> Output Class Initialized
INFO - 2020-02-19 17:10:32 --> Security Class Initialized
DEBUG - 2020-02-19 17:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:10:32 --> CSRF cookie sent
INFO - 2020-02-19 17:10:32 --> Input Class Initialized
INFO - 2020-02-19 17:10:32 --> Language Class Initialized
INFO - 2020-02-19 17:10:32 --> Language Class Initialized
INFO - 2020-02-19 17:10:32 --> Config Class Initialized
INFO - 2020-02-19 17:10:32 --> Loader Class Initialized
INFO - 2020-02-19 17:10:32 --> Helper loaded: url_helper
INFO - 2020-02-19 17:10:32 --> Helper loaded: common_helper
INFO - 2020-02-19 17:10:32 --> Helper loaded: language_helper
INFO - 2020-02-19 17:10:32 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:10:32 --> Helper loaded: email_helper
INFO - 2020-02-19 17:10:32 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:10:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:10:32 --> Parser Class Initialized
INFO - 2020-02-19 17:10:32 --> User Agent Class Initialized
INFO - 2020-02-19 17:10:32 --> Model Class Initialized
INFO - 2020-02-19 17:10:32 --> Database Driver Class Initialized
INFO - 2020-02-19 17:10:32 --> Model Class Initialized
DEBUG - 2020-02-19 17:10:32 --> Template Class Initialized
INFO - 2020-02-19 17:10:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:10:33 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:10:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:10:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:10:33 --> Encryption Class Initialized
INFO - 2020-02-19 17:10:33 --> Controller Class Initialized
DEBUG - 2020-02-19 17:10:33 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:10:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:10:33 --> Model Class Initialized
ERROR - 2020-02-19 17:10:33 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:10:33 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:10:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:10:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:10:33 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:10:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:10:33 --> Model Class Initialized
DEBUG - 2020-02-19 17:10:33 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:10:33 --> Model Class Initialized
DEBUG - 2020-02-19 17:10:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:10:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:10:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:10:33 --> Final output sent to browser
DEBUG - 2020-02-19 17:10:33 --> Total execution time: 0.8549
INFO - 2020-02-19 17:12:34 --> Config Class Initialized
INFO - 2020-02-19 17:12:34 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:12:34 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:12:34 --> Utf8 Class Initialized
INFO - 2020-02-19 17:12:34 --> URI Class Initialized
INFO - 2020-02-19 17:12:34 --> Router Class Initialized
INFO - 2020-02-19 17:12:34 --> Output Class Initialized
INFO - 2020-02-19 17:12:34 --> Security Class Initialized
DEBUG - 2020-02-19 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:12:34 --> CSRF cookie sent
INFO - 2020-02-19 17:12:34 --> Input Class Initialized
INFO - 2020-02-19 17:12:34 --> Language Class Initialized
INFO - 2020-02-19 17:12:34 --> Language Class Initialized
INFO - 2020-02-19 17:12:34 --> Config Class Initialized
INFO - 2020-02-19 17:12:34 --> Loader Class Initialized
INFO - 2020-02-19 17:12:34 --> Helper loaded: url_helper
INFO - 2020-02-19 17:12:34 --> Helper loaded: common_helper
INFO - 2020-02-19 17:12:34 --> Helper loaded: language_helper
INFO - 2020-02-19 17:12:34 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:12:34 --> Helper loaded: email_helper
INFO - 2020-02-19 17:12:34 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:12:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:12:34 --> Parser Class Initialized
INFO - 2020-02-19 17:12:34 --> User Agent Class Initialized
INFO - 2020-02-19 17:12:34 --> Model Class Initialized
INFO - 2020-02-19 17:12:34 --> Database Driver Class Initialized
INFO - 2020-02-19 17:12:34 --> Model Class Initialized
DEBUG - 2020-02-19 17:12:34 --> Template Class Initialized
INFO - 2020-02-19 17:12:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:12:35 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:12:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:12:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:12:35 --> Encryption Class Initialized
INFO - 2020-02-19 17:12:35 --> Controller Class Initialized
DEBUG - 2020-02-19 17:12:35 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:12:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:12:35 --> Model Class Initialized
ERROR - 2020-02-19 17:12:35 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:12:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:12:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:12:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:12:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:12:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:12:35 --> Model Class Initialized
DEBUG - 2020-02-19 17:12:35 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:12:35 --> Model Class Initialized
DEBUG - 2020-02-19 17:12:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:12:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:12:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:12:35 --> Final output sent to browser
DEBUG - 2020-02-19 17:12:35 --> Total execution time: 0.8715
INFO - 2020-02-19 17:13:42 --> Config Class Initialized
INFO - 2020-02-19 17:13:42 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:13:42 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:13:42 --> Utf8 Class Initialized
INFO - 2020-02-19 17:13:42 --> URI Class Initialized
INFO - 2020-02-19 17:13:43 --> Router Class Initialized
INFO - 2020-02-19 17:13:43 --> Output Class Initialized
INFO - 2020-02-19 17:13:43 --> Security Class Initialized
DEBUG - 2020-02-19 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:13:43 --> CSRF cookie sent
INFO - 2020-02-19 17:13:43 --> Input Class Initialized
INFO - 2020-02-19 17:13:43 --> Language Class Initialized
INFO - 2020-02-19 17:13:43 --> Language Class Initialized
INFO - 2020-02-19 17:13:43 --> Config Class Initialized
INFO - 2020-02-19 17:13:43 --> Loader Class Initialized
INFO - 2020-02-19 17:13:43 --> Helper loaded: url_helper
INFO - 2020-02-19 17:13:43 --> Helper loaded: common_helper
INFO - 2020-02-19 17:13:43 --> Helper loaded: language_helper
INFO - 2020-02-19 17:13:43 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:13:43 --> Helper loaded: email_helper
INFO - 2020-02-19 17:13:43 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:13:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:13:43 --> Parser Class Initialized
INFO - 2020-02-19 17:13:43 --> User Agent Class Initialized
INFO - 2020-02-19 17:13:43 --> Model Class Initialized
INFO - 2020-02-19 17:13:43 --> Database Driver Class Initialized
INFO - 2020-02-19 17:13:43 --> Model Class Initialized
DEBUG - 2020-02-19 17:13:43 --> Template Class Initialized
INFO - 2020-02-19 17:13:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:13:43 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:13:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:13:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:13:43 --> Encryption Class Initialized
INFO - 2020-02-19 17:13:43 --> Controller Class Initialized
DEBUG - 2020-02-19 17:13:43 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:13:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:13:43 --> Model Class Initialized
ERROR - 2020-02-19 17:13:43 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:13:43 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:13:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:13:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:13:43 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:13:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:13:43 --> Model Class Initialized
DEBUG - 2020-02-19 17:13:43 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:13:43 --> Model Class Initialized
DEBUG - 2020-02-19 17:13:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:13:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:13:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:13:43 --> Final output sent to browser
DEBUG - 2020-02-19 17:13:43 --> Total execution time: 0.7745
INFO - 2020-02-19 17:15:15 --> Config Class Initialized
INFO - 2020-02-19 17:15:15 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:15:15 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:15:15 --> Utf8 Class Initialized
INFO - 2020-02-19 17:15:15 --> URI Class Initialized
INFO - 2020-02-19 17:15:15 --> Router Class Initialized
INFO - 2020-02-19 17:15:15 --> Output Class Initialized
INFO - 2020-02-19 17:15:15 --> Security Class Initialized
DEBUG - 2020-02-19 17:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:15:15 --> CSRF cookie sent
INFO - 2020-02-19 17:15:15 --> Input Class Initialized
INFO - 2020-02-19 17:15:15 --> Language Class Initialized
INFO - 2020-02-19 17:15:15 --> Language Class Initialized
INFO - 2020-02-19 17:15:15 --> Config Class Initialized
INFO - 2020-02-19 17:15:15 --> Loader Class Initialized
INFO - 2020-02-19 17:15:15 --> Helper loaded: url_helper
INFO - 2020-02-19 17:15:15 --> Helper loaded: common_helper
INFO - 2020-02-19 17:15:15 --> Helper loaded: language_helper
INFO - 2020-02-19 17:15:15 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:15:15 --> Helper loaded: email_helper
INFO - 2020-02-19 17:15:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:15:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:15:15 --> Parser Class Initialized
INFO - 2020-02-19 17:15:15 --> User Agent Class Initialized
INFO - 2020-02-19 17:15:15 --> Model Class Initialized
INFO - 2020-02-19 17:15:15 --> Database Driver Class Initialized
INFO - 2020-02-19 17:15:15 --> Model Class Initialized
DEBUG - 2020-02-19 17:15:15 --> Template Class Initialized
INFO - 2020-02-19 17:15:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:15:15 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:15:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:15:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:15:15 --> Encryption Class Initialized
INFO - 2020-02-19 17:15:15 --> Controller Class Initialized
DEBUG - 2020-02-19 17:15:15 --> language MX_Controller Initialized
DEBUG - 2020-02-19 17:15:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2020-02-19 17:15:15 --> Model Class Initialized
INFO - 2020-02-19 17:15:15 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:15:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2020-02-19 17:15:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:15:15 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:15:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:15:15 --> Model Class Initialized
DEBUG - 2020-02-19 17:15:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:15:15 --> Model Class Initialized
DEBUG - 2020-02-19 17:15:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:15:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:15:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:15:16 --> Final output sent to browser
DEBUG - 2020-02-19 17:15:16 --> Total execution time: 1.0586
INFO - 2020-02-19 17:15:18 --> Config Class Initialized
INFO - 2020-02-19 17:15:18 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:15:18 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:15:18 --> Utf8 Class Initialized
INFO - 2020-02-19 17:15:18 --> URI Class Initialized
INFO - 2020-02-19 17:15:18 --> Router Class Initialized
INFO - 2020-02-19 17:15:18 --> Output Class Initialized
INFO - 2020-02-19 17:15:18 --> Security Class Initialized
DEBUG - 2020-02-19 17:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:15:18 --> CSRF cookie sent
INFO - 2020-02-19 17:15:18 --> Input Class Initialized
INFO - 2020-02-19 17:15:18 --> Language Class Initialized
INFO - 2020-02-19 17:15:18 --> Language Class Initialized
INFO - 2020-02-19 17:15:18 --> Config Class Initialized
INFO - 2020-02-19 17:15:18 --> Loader Class Initialized
INFO - 2020-02-19 17:15:18 --> Helper loaded: url_helper
INFO - 2020-02-19 17:15:18 --> Helper loaded: common_helper
INFO - 2020-02-19 17:15:18 --> Helper loaded: language_helper
INFO - 2020-02-19 17:15:18 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:15:18 --> Helper loaded: email_helper
INFO - 2020-02-19 17:15:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:15:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:15:18 --> Parser Class Initialized
INFO - 2020-02-19 17:15:18 --> User Agent Class Initialized
INFO - 2020-02-19 17:15:18 --> Model Class Initialized
INFO - 2020-02-19 17:15:18 --> Database Driver Class Initialized
INFO - 2020-02-19 17:15:18 --> Model Class Initialized
DEBUG - 2020-02-19 17:15:18 --> Template Class Initialized
INFO - 2020-02-19 17:15:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:15:18 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:15:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:15:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:15:18 --> Encryption Class Initialized
INFO - 2020-02-19 17:15:18 --> Controller Class Initialized
DEBUG - 2020-02-19 17:15:18 --> language MX_Controller Initialized
DEBUG - 2020-02-19 17:15:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2020-02-19 17:15:18 --> Model Class Initialized
INFO - 2020-02-19 17:15:22 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2020-02-19 17:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:15:22 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:15:22 --> Model Class Initialized
DEBUG - 2020-02-19 17:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:15:22 --> Model Class Initialized
DEBUG - 2020-02-19 17:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:15:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:15:22 --> Final output sent to browser
DEBUG - 2020-02-19 17:15:22 --> Total execution time: 4.6956
INFO - 2020-02-19 17:21:16 --> Config Class Initialized
INFO - 2020-02-19 17:21:16 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:21:16 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:21:16 --> Utf8 Class Initialized
INFO - 2020-02-19 17:21:16 --> URI Class Initialized
INFO - 2020-02-19 17:21:16 --> Router Class Initialized
INFO - 2020-02-19 17:21:16 --> Output Class Initialized
INFO - 2020-02-19 17:21:16 --> Security Class Initialized
DEBUG - 2020-02-19 17:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:21:16 --> CSRF cookie sent
INFO - 2020-02-19 17:21:16 --> Input Class Initialized
INFO - 2020-02-19 17:21:16 --> Language Class Initialized
INFO - 2020-02-19 17:21:16 --> Language Class Initialized
INFO - 2020-02-19 17:21:16 --> Config Class Initialized
INFO - 2020-02-19 17:21:16 --> Loader Class Initialized
INFO - 2020-02-19 17:21:16 --> Helper loaded: url_helper
INFO - 2020-02-19 17:21:16 --> Helper loaded: common_helper
INFO - 2020-02-19 17:21:16 --> Helper loaded: language_helper
INFO - 2020-02-19 17:21:16 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:21:16 --> Helper loaded: email_helper
INFO - 2020-02-19 17:21:16 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:21:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:21:16 --> Parser Class Initialized
INFO - 2020-02-19 17:21:17 --> User Agent Class Initialized
INFO - 2020-02-19 17:21:17 --> Model Class Initialized
INFO - 2020-02-19 17:21:17 --> Database Driver Class Initialized
INFO - 2020-02-19 17:21:17 --> Model Class Initialized
DEBUG - 2020-02-19 17:21:17 --> Template Class Initialized
INFO - 2020-02-19 17:21:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:21:17 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:21:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:21:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:21:17 --> Encryption Class Initialized
INFO - 2020-02-19 17:21:17 --> Controller Class Initialized
DEBUG - 2020-02-19 17:21:17 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:21:17 --> Model Class Initialized
ERROR - 2020-02-19 17:21:17 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:21:17 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:21:17 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:21:17 --> Model Class Initialized
DEBUG - 2020-02-19 17:21:17 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:21:17 --> Model Class Initialized
DEBUG - 2020-02-19 17:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:21:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:21:17 --> Final output sent to browser
DEBUG - 2020-02-19 17:21:17 --> Total execution time: 0.8248
INFO - 2020-02-19 17:22:35 --> Config Class Initialized
INFO - 2020-02-19 17:22:35 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:22:35 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:22:35 --> Utf8 Class Initialized
INFO - 2020-02-19 17:22:35 --> URI Class Initialized
INFO - 2020-02-19 17:22:35 --> Router Class Initialized
INFO - 2020-02-19 17:22:35 --> Output Class Initialized
INFO - 2020-02-19 17:22:35 --> Security Class Initialized
DEBUG - 2020-02-19 17:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:22:35 --> CSRF cookie sent
INFO - 2020-02-19 17:22:35 --> Input Class Initialized
INFO - 2020-02-19 17:22:35 --> Language Class Initialized
INFO - 2020-02-19 17:22:35 --> Language Class Initialized
INFO - 2020-02-19 17:22:35 --> Config Class Initialized
INFO - 2020-02-19 17:22:35 --> Loader Class Initialized
INFO - 2020-02-19 17:22:35 --> Helper loaded: url_helper
INFO - 2020-02-19 17:22:35 --> Helper loaded: common_helper
INFO - 2020-02-19 17:22:35 --> Helper loaded: language_helper
INFO - 2020-02-19 17:22:35 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:22:35 --> Helper loaded: email_helper
INFO - 2020-02-19 17:22:35 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:22:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:22:35 --> Parser Class Initialized
INFO - 2020-02-19 17:22:35 --> User Agent Class Initialized
INFO - 2020-02-19 17:22:35 --> Model Class Initialized
INFO - 2020-02-19 17:22:35 --> Database Driver Class Initialized
INFO - 2020-02-19 17:22:35 --> Model Class Initialized
DEBUG - 2020-02-19 17:22:35 --> Template Class Initialized
INFO - 2020-02-19 17:22:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:22:35 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:22:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:22:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:22:35 --> Encryption Class Initialized
INFO - 2020-02-19 17:22:35 --> Controller Class Initialized
DEBUG - 2020-02-19 17:22:35 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:22:35 --> Model Class Initialized
ERROR - 2020-02-19 17:22:35 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:22:35 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:22:35 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:22:35 --> Model Class Initialized
DEBUG - 2020-02-19 17:22:35 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:22:35 --> Model Class Initialized
DEBUG - 2020-02-19 17:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:22:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:22:36 --> Final output sent to browser
DEBUG - 2020-02-19 17:22:36 --> Total execution time: 0.8345
INFO - 2020-02-19 17:24:40 --> Config Class Initialized
INFO - 2020-02-19 17:24:40 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:24:40 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:24:40 --> Utf8 Class Initialized
INFO - 2020-02-19 17:24:40 --> URI Class Initialized
INFO - 2020-02-19 17:24:40 --> Router Class Initialized
INFO - 2020-02-19 17:24:40 --> Output Class Initialized
INFO - 2020-02-19 17:24:40 --> Security Class Initialized
DEBUG - 2020-02-19 17:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:24:40 --> CSRF cookie sent
INFO - 2020-02-19 17:24:40 --> Input Class Initialized
INFO - 2020-02-19 17:24:40 --> Language Class Initialized
INFO - 2020-02-19 17:24:40 --> Language Class Initialized
INFO - 2020-02-19 17:24:40 --> Config Class Initialized
INFO - 2020-02-19 17:24:40 --> Loader Class Initialized
INFO - 2020-02-19 17:24:40 --> Helper loaded: url_helper
INFO - 2020-02-19 17:24:40 --> Helper loaded: common_helper
INFO - 2020-02-19 17:24:40 --> Helper loaded: language_helper
INFO - 2020-02-19 17:24:40 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:24:40 --> Helper loaded: email_helper
INFO - 2020-02-19 17:24:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:24:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:24:40 --> Parser Class Initialized
INFO - 2020-02-19 17:24:40 --> User Agent Class Initialized
INFO - 2020-02-19 17:24:40 --> Model Class Initialized
INFO - 2020-02-19 17:24:40 --> Database Driver Class Initialized
INFO - 2020-02-19 17:24:40 --> Model Class Initialized
DEBUG - 2020-02-19 17:24:40 --> Template Class Initialized
INFO - 2020-02-19 17:24:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:24:40 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:24:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:24:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:24:40 --> Encryption Class Initialized
INFO - 2020-02-19 17:24:40 --> Controller Class Initialized
DEBUG - 2020-02-19 17:24:40 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:24:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:24:40 --> Model Class Initialized
ERROR - 2020-02-19 17:24:40 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:24:40 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:24:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:24:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:24:40 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:24:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:24:40 --> Model Class Initialized
DEBUG - 2020-02-19 17:24:40 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:24:40 --> Model Class Initialized
DEBUG - 2020-02-19 17:24:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:24:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:24:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:24:40 --> Final output sent to browser
DEBUG - 2020-02-19 17:24:40 --> Total execution time: 0.8491
INFO - 2020-02-19 17:25:01 --> Config Class Initialized
INFO - 2020-02-19 17:25:01 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:25:01 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:25:01 --> Utf8 Class Initialized
INFO - 2020-02-19 17:25:01 --> URI Class Initialized
INFO - 2020-02-19 17:25:01 --> Router Class Initialized
INFO - 2020-02-19 17:25:01 --> Output Class Initialized
INFO - 2020-02-19 17:25:01 --> Security Class Initialized
DEBUG - 2020-02-19 17:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:25:01 --> CSRF cookie sent
INFO - 2020-02-19 17:25:01 --> Input Class Initialized
INFO - 2020-02-19 17:25:01 --> Language Class Initialized
INFO - 2020-02-19 17:25:01 --> Language Class Initialized
INFO - 2020-02-19 17:25:01 --> Config Class Initialized
INFO - 2020-02-19 17:25:01 --> Loader Class Initialized
INFO - 2020-02-19 17:25:01 --> Helper loaded: url_helper
INFO - 2020-02-19 17:25:01 --> Helper loaded: common_helper
INFO - 2020-02-19 17:25:01 --> Helper loaded: language_helper
INFO - 2020-02-19 17:25:01 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:25:01 --> Helper loaded: email_helper
INFO - 2020-02-19 17:25:01 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:25:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:25:01 --> Parser Class Initialized
INFO - 2020-02-19 17:25:01 --> User Agent Class Initialized
INFO - 2020-02-19 17:25:01 --> Model Class Initialized
INFO - 2020-02-19 17:25:01 --> Database Driver Class Initialized
INFO - 2020-02-19 17:25:01 --> Model Class Initialized
DEBUG - 2020-02-19 17:25:01 --> Template Class Initialized
INFO - 2020-02-19 17:25:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:25:01 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:25:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:25:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:25:01 --> Encryption Class Initialized
INFO - 2020-02-19 17:25:01 --> Controller Class Initialized
DEBUG - 2020-02-19 17:25:01 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:25:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:25:01 --> Model Class Initialized
ERROR - 2020-02-19 17:25:01 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:25:01 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:25:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:25:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:25:01 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:25:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:25:01 --> Model Class Initialized
DEBUG - 2020-02-19 17:25:01 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:25:01 --> Model Class Initialized
DEBUG - 2020-02-19 17:25:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:25:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:25:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:25:02 --> Final output sent to browser
DEBUG - 2020-02-19 17:25:02 --> Total execution time: 0.8088
INFO - 2020-02-19 17:25:11 --> Config Class Initialized
INFO - 2020-02-19 17:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:25:11 --> Utf8 Class Initialized
INFO - 2020-02-19 17:25:11 --> URI Class Initialized
INFO - 2020-02-19 17:25:11 --> Router Class Initialized
INFO - 2020-02-19 17:25:11 --> Output Class Initialized
INFO - 2020-02-19 17:25:11 --> Security Class Initialized
DEBUG - 2020-02-19 17:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:25:11 --> CSRF cookie sent
INFO - 2020-02-19 17:25:11 --> Input Class Initialized
INFO - 2020-02-19 17:25:11 --> Language Class Initialized
INFO - 2020-02-19 17:25:11 --> Language Class Initialized
INFO - 2020-02-19 17:25:11 --> Config Class Initialized
INFO - 2020-02-19 17:25:11 --> Loader Class Initialized
INFO - 2020-02-19 17:25:11 --> Helper loaded: url_helper
INFO - 2020-02-19 17:25:11 --> Helper loaded: common_helper
INFO - 2020-02-19 17:25:11 --> Helper loaded: language_helper
INFO - 2020-02-19 17:25:11 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:25:11 --> Helper loaded: email_helper
INFO - 2020-02-19 17:25:11 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:25:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:25:11 --> Parser Class Initialized
INFO - 2020-02-19 17:25:11 --> User Agent Class Initialized
INFO - 2020-02-19 17:25:11 --> Model Class Initialized
INFO - 2020-02-19 17:25:11 --> Database Driver Class Initialized
INFO - 2020-02-19 17:25:11 --> Model Class Initialized
DEBUG - 2020-02-19 17:25:11 --> Template Class Initialized
INFO - 2020-02-19 17:25:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:25:11 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:25:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:25:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:25:11 --> Encryption Class Initialized
INFO - 2020-02-19 17:25:11 --> Controller Class Initialized
DEBUG - 2020-02-19 17:25:11 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:25:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:25:11 --> Model Class Initialized
ERROR - 2020-02-19 17:25:11 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:25:11 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:25:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:25:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:25:11 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:25:12 --> Model Class Initialized
DEBUG - 2020-02-19 17:25:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:25:12 --> Model Class Initialized
DEBUG - 2020-02-19 17:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:25:12 --> Final output sent to browser
DEBUG - 2020-02-19 17:25:12 --> Total execution time: 0.8280
INFO - 2020-02-19 17:26:13 --> Config Class Initialized
INFO - 2020-02-19 17:26:13 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:26:13 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:26:13 --> Utf8 Class Initialized
INFO - 2020-02-19 17:26:13 --> URI Class Initialized
INFO - 2020-02-19 17:26:13 --> Router Class Initialized
INFO - 2020-02-19 17:26:13 --> Output Class Initialized
INFO - 2020-02-19 17:26:13 --> Security Class Initialized
DEBUG - 2020-02-19 17:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:26:13 --> CSRF cookie sent
INFO - 2020-02-19 17:26:13 --> Input Class Initialized
INFO - 2020-02-19 17:26:13 --> Language Class Initialized
INFO - 2020-02-19 17:26:13 --> Language Class Initialized
INFO - 2020-02-19 17:26:13 --> Config Class Initialized
INFO - 2020-02-19 17:26:13 --> Loader Class Initialized
INFO - 2020-02-19 17:26:13 --> Helper loaded: url_helper
INFO - 2020-02-19 17:26:13 --> Helper loaded: common_helper
INFO - 2020-02-19 17:26:13 --> Helper loaded: language_helper
INFO - 2020-02-19 17:26:13 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:26:13 --> Helper loaded: email_helper
INFO - 2020-02-19 17:26:13 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:26:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:26:13 --> Parser Class Initialized
INFO - 2020-02-19 17:26:13 --> User Agent Class Initialized
INFO - 2020-02-19 17:26:13 --> Model Class Initialized
INFO - 2020-02-19 17:26:13 --> Database Driver Class Initialized
INFO - 2020-02-19 17:26:13 --> Model Class Initialized
DEBUG - 2020-02-19 17:26:13 --> Template Class Initialized
INFO - 2020-02-19 17:26:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:26:13 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:26:13 --> Encryption Class Initialized
INFO - 2020-02-19 17:26:13 --> Controller Class Initialized
DEBUG - 2020-02-19 17:26:13 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:26:13 --> Model Class Initialized
ERROR - 2020-02-19 17:26:13 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:26:13 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:26:13 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:26:13 --> Model Class Initialized
DEBUG - 2020-02-19 17:26:13 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:26:14 --> Model Class Initialized
DEBUG - 2020-02-19 17:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:26:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:26:14 --> Final output sent to browser
DEBUG - 2020-02-19 17:26:14 --> Total execution time: 0.8068
INFO - 2020-02-19 17:27:09 --> Config Class Initialized
INFO - 2020-02-19 17:27:09 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:27:09 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:27:09 --> Utf8 Class Initialized
INFO - 2020-02-19 17:27:09 --> URI Class Initialized
INFO - 2020-02-19 17:27:09 --> Router Class Initialized
INFO - 2020-02-19 17:27:09 --> Output Class Initialized
INFO - 2020-02-19 17:27:09 --> Security Class Initialized
DEBUG - 2020-02-19 17:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:27:09 --> CSRF cookie sent
INFO - 2020-02-19 17:27:09 --> Input Class Initialized
INFO - 2020-02-19 17:27:09 --> Language Class Initialized
INFO - 2020-02-19 17:27:09 --> Language Class Initialized
INFO - 2020-02-19 17:27:09 --> Config Class Initialized
INFO - 2020-02-19 17:27:09 --> Loader Class Initialized
INFO - 2020-02-19 17:27:09 --> Helper loaded: url_helper
INFO - 2020-02-19 17:27:09 --> Helper loaded: common_helper
INFO - 2020-02-19 17:27:09 --> Helper loaded: language_helper
INFO - 2020-02-19 17:27:09 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:27:09 --> Helper loaded: email_helper
INFO - 2020-02-19 17:27:09 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:27:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:27:09 --> Parser Class Initialized
INFO - 2020-02-19 17:27:09 --> User Agent Class Initialized
INFO - 2020-02-19 17:27:09 --> Model Class Initialized
INFO - 2020-02-19 17:27:09 --> Database Driver Class Initialized
INFO - 2020-02-19 17:27:09 --> Model Class Initialized
DEBUG - 2020-02-19 17:27:09 --> Template Class Initialized
INFO - 2020-02-19 17:27:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:27:10 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:27:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:27:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:27:10 --> Encryption Class Initialized
INFO - 2020-02-19 17:27:10 --> Controller Class Initialized
DEBUG - 2020-02-19 17:27:10 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:27:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:27:10 --> Model Class Initialized
ERROR - 2020-02-19 17:27:10 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:27:10 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:27:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:27:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:27:10 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:27:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:27:10 --> Model Class Initialized
DEBUG - 2020-02-19 17:27:10 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:27:10 --> Model Class Initialized
DEBUG - 2020-02-19 17:27:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:27:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:27:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:27:10 --> Final output sent to browser
DEBUG - 2020-02-19 17:27:10 --> Total execution time: 0.8644
INFO - 2020-02-19 17:29:03 --> Config Class Initialized
INFO - 2020-02-19 17:29:03 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:29:03 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:29:03 --> Utf8 Class Initialized
INFO - 2020-02-19 17:29:03 --> URI Class Initialized
INFO - 2020-02-19 17:29:03 --> Router Class Initialized
INFO - 2020-02-19 17:29:03 --> Output Class Initialized
INFO - 2020-02-19 17:29:03 --> Security Class Initialized
DEBUG - 2020-02-19 17:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:29:03 --> CSRF cookie sent
INFO - 2020-02-19 17:29:03 --> Input Class Initialized
INFO - 2020-02-19 17:29:03 --> Language Class Initialized
INFO - 2020-02-19 17:29:03 --> Language Class Initialized
INFO - 2020-02-19 17:29:03 --> Config Class Initialized
INFO - 2020-02-19 17:29:03 --> Loader Class Initialized
INFO - 2020-02-19 17:29:03 --> Helper loaded: url_helper
INFO - 2020-02-19 17:29:03 --> Helper loaded: common_helper
INFO - 2020-02-19 17:29:03 --> Helper loaded: language_helper
INFO - 2020-02-19 17:29:03 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:29:03 --> Helper loaded: email_helper
INFO - 2020-02-19 17:29:03 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:29:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:29:03 --> Parser Class Initialized
INFO - 2020-02-19 17:29:03 --> User Agent Class Initialized
INFO - 2020-02-19 17:29:03 --> Model Class Initialized
INFO - 2020-02-19 17:29:03 --> Database Driver Class Initialized
INFO - 2020-02-19 17:29:03 --> Model Class Initialized
DEBUG - 2020-02-19 17:29:03 --> Template Class Initialized
INFO - 2020-02-19 17:29:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:29:03 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:29:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:29:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:29:03 --> Encryption Class Initialized
INFO - 2020-02-19 17:29:03 --> Controller Class Initialized
DEBUG - 2020-02-19 17:29:03 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:29:03 --> Model Class Initialized
ERROR - 2020-02-19 17:29:03 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:29:03 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:29:03 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:29:03 --> Model Class Initialized
DEBUG - 2020-02-19 17:29:03 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:29:03 --> Model Class Initialized
DEBUG - 2020-02-19 17:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:29:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:29:03 --> Final output sent to browser
DEBUG - 2020-02-19 17:29:03 --> Total execution time: 0.8964
INFO - 2020-02-19 17:30:27 --> Config Class Initialized
INFO - 2020-02-19 17:30:27 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:30:27 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:30:27 --> Utf8 Class Initialized
INFO - 2020-02-19 17:30:27 --> URI Class Initialized
INFO - 2020-02-19 17:30:27 --> Router Class Initialized
INFO - 2020-02-19 17:30:27 --> Output Class Initialized
INFO - 2020-02-19 17:30:27 --> Security Class Initialized
DEBUG - 2020-02-19 17:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:30:27 --> CSRF cookie sent
INFO - 2020-02-19 17:30:27 --> Input Class Initialized
INFO - 2020-02-19 17:30:27 --> Language Class Initialized
INFO - 2020-02-19 17:30:27 --> Language Class Initialized
INFO - 2020-02-19 17:30:27 --> Config Class Initialized
INFO - 2020-02-19 17:30:27 --> Loader Class Initialized
INFO - 2020-02-19 17:30:27 --> Helper loaded: url_helper
INFO - 2020-02-19 17:30:27 --> Helper loaded: common_helper
INFO - 2020-02-19 17:30:27 --> Helper loaded: language_helper
INFO - 2020-02-19 17:30:27 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:30:27 --> Helper loaded: email_helper
INFO - 2020-02-19 17:30:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:30:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:30:27 --> Parser Class Initialized
INFO - 2020-02-19 17:30:27 --> User Agent Class Initialized
INFO - 2020-02-19 17:30:27 --> Model Class Initialized
INFO - 2020-02-19 17:30:27 --> Database Driver Class Initialized
INFO - 2020-02-19 17:30:27 --> Model Class Initialized
DEBUG - 2020-02-19 17:30:27 --> Template Class Initialized
INFO - 2020-02-19 17:30:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:30:27 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:30:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:30:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:30:27 --> Encryption Class Initialized
INFO - 2020-02-19 17:30:27 --> Controller Class Initialized
DEBUG - 2020-02-19 17:30:27 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:30:27 --> Model Class Initialized
ERROR - 2020-02-19 17:30:27 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:30:27 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:30:27 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:30:27 --> Model Class Initialized
DEBUG - 2020-02-19 17:30:27 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:30:27 --> Model Class Initialized
DEBUG - 2020-02-19 17:30:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:30:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:30:28 --> Final output sent to browser
DEBUG - 2020-02-19 17:30:28 --> Total execution time: 0.8070
INFO - 2020-02-19 17:31:55 --> Config Class Initialized
INFO - 2020-02-19 17:31:55 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:31:55 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:31:55 --> Utf8 Class Initialized
INFO - 2020-02-19 17:31:55 --> URI Class Initialized
INFO - 2020-02-19 17:31:55 --> Router Class Initialized
INFO - 2020-02-19 17:31:55 --> Output Class Initialized
INFO - 2020-02-19 17:31:55 --> Security Class Initialized
DEBUG - 2020-02-19 17:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:31:55 --> CSRF cookie sent
INFO - 2020-02-19 17:31:55 --> Input Class Initialized
INFO - 2020-02-19 17:31:55 --> Language Class Initialized
INFO - 2020-02-19 17:31:55 --> Language Class Initialized
INFO - 2020-02-19 17:31:55 --> Config Class Initialized
INFO - 2020-02-19 17:31:55 --> Loader Class Initialized
INFO - 2020-02-19 17:31:55 --> Helper loaded: url_helper
INFO - 2020-02-19 17:31:55 --> Helper loaded: common_helper
INFO - 2020-02-19 17:31:56 --> Helper loaded: language_helper
INFO - 2020-02-19 17:31:56 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:31:56 --> Helper loaded: email_helper
INFO - 2020-02-19 17:31:56 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:31:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:31:56 --> Parser Class Initialized
INFO - 2020-02-19 17:31:56 --> User Agent Class Initialized
INFO - 2020-02-19 17:31:56 --> Model Class Initialized
INFO - 2020-02-19 17:31:56 --> Database Driver Class Initialized
INFO - 2020-02-19 17:31:56 --> Model Class Initialized
DEBUG - 2020-02-19 17:31:56 --> Template Class Initialized
INFO - 2020-02-19 17:31:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:31:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:31:56 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:31:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:31:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:31:56 --> Encryption Class Initialized
INFO - 2020-02-19 17:31:56 --> Controller Class Initialized
DEBUG - 2020-02-19 17:31:56 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:31:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:31:56 --> Model Class Initialized
ERROR - 2020-02-19 17:31:56 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:31:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:31:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:31:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:31:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:31:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:31:56 --> Model Class Initialized
DEBUG - 2020-02-19 17:31:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:31:56 --> Model Class Initialized
DEBUG - 2020-02-19 17:31:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:31:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:31:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:31:56 --> Final output sent to browser
DEBUG - 2020-02-19 17:31:56 --> Total execution time: 0.8513
INFO - 2020-02-19 17:32:26 --> Config Class Initialized
INFO - 2020-02-19 17:32:26 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:32:26 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:32:26 --> Utf8 Class Initialized
INFO - 2020-02-19 17:32:26 --> URI Class Initialized
INFO - 2020-02-19 17:32:26 --> Router Class Initialized
INFO - 2020-02-19 17:32:26 --> Output Class Initialized
INFO - 2020-02-19 17:32:26 --> Security Class Initialized
DEBUG - 2020-02-19 17:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:32:26 --> CSRF cookie sent
INFO - 2020-02-19 17:32:26 --> Input Class Initialized
INFO - 2020-02-19 17:32:26 --> Language Class Initialized
INFO - 2020-02-19 17:32:26 --> Language Class Initialized
INFO - 2020-02-19 17:32:26 --> Config Class Initialized
INFO - 2020-02-19 17:32:26 --> Loader Class Initialized
INFO - 2020-02-19 17:32:26 --> Helper loaded: url_helper
INFO - 2020-02-19 17:32:27 --> Helper loaded: common_helper
INFO - 2020-02-19 17:32:27 --> Helper loaded: language_helper
INFO - 2020-02-19 17:32:27 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:32:27 --> Helper loaded: email_helper
INFO - 2020-02-19 17:32:27 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:32:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:32:27 --> Parser Class Initialized
INFO - 2020-02-19 17:32:27 --> User Agent Class Initialized
INFO - 2020-02-19 17:32:27 --> Model Class Initialized
INFO - 2020-02-19 17:32:27 --> Database Driver Class Initialized
INFO - 2020-02-19 17:32:27 --> Model Class Initialized
DEBUG - 2020-02-19 17:32:27 --> Template Class Initialized
INFO - 2020-02-19 17:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:32:27 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:32:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:32:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:32:27 --> Encryption Class Initialized
INFO - 2020-02-19 17:32:27 --> Controller Class Initialized
DEBUG - 2020-02-19 17:32:27 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:32:27 --> Model Class Initialized
ERROR - 2020-02-19 17:32:27 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:32:27 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:32:27 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:32:27 --> Model Class Initialized
DEBUG - 2020-02-19 17:32:27 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:32:27 --> Model Class Initialized
DEBUG - 2020-02-19 17:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:32:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:32:27 --> Final output sent to browser
DEBUG - 2020-02-19 17:32:27 --> Total execution time: 0.8825
INFO - 2020-02-19 17:32:37 --> Config Class Initialized
INFO - 2020-02-19 17:32:37 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:32:37 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:32:37 --> Utf8 Class Initialized
INFO - 2020-02-19 17:32:37 --> URI Class Initialized
INFO - 2020-02-19 17:32:37 --> Router Class Initialized
INFO - 2020-02-19 17:32:37 --> Output Class Initialized
INFO - 2020-02-19 17:32:37 --> Security Class Initialized
DEBUG - 2020-02-19 17:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:32:37 --> CSRF cookie sent
INFO - 2020-02-19 17:32:37 --> Input Class Initialized
INFO - 2020-02-19 17:32:37 --> Language Class Initialized
INFO - 2020-02-19 17:32:37 --> Language Class Initialized
INFO - 2020-02-19 17:32:37 --> Config Class Initialized
INFO - 2020-02-19 17:32:37 --> Loader Class Initialized
INFO - 2020-02-19 17:32:37 --> Helper loaded: url_helper
INFO - 2020-02-19 17:32:37 --> Helper loaded: common_helper
INFO - 2020-02-19 17:32:37 --> Helper loaded: language_helper
INFO - 2020-02-19 17:32:37 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:32:37 --> Helper loaded: email_helper
INFO - 2020-02-19 17:32:37 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:32:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:32:37 --> Parser Class Initialized
INFO - 2020-02-19 17:32:37 --> User Agent Class Initialized
INFO - 2020-02-19 17:32:37 --> Model Class Initialized
INFO - 2020-02-19 17:32:37 --> Database Driver Class Initialized
INFO - 2020-02-19 17:32:37 --> Model Class Initialized
DEBUG - 2020-02-19 17:32:37 --> Template Class Initialized
INFO - 2020-02-19 17:32:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:32:37 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:32:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:32:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:32:37 --> Encryption Class Initialized
INFO - 2020-02-19 17:32:37 --> Controller Class Initialized
DEBUG - 2020-02-19 17:32:37 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:32:37 --> Model Class Initialized
ERROR - 2020-02-19 17:32:37 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:32:37 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:32:37 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:32:37 --> Model Class Initialized
DEBUG - 2020-02-19 17:32:37 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:32:37 --> Model Class Initialized
DEBUG - 2020-02-19 17:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:32:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:32:37 --> Final output sent to browser
DEBUG - 2020-02-19 17:32:37 --> Total execution time: 0.9176
INFO - 2020-02-19 17:33:20 --> Config Class Initialized
INFO - 2020-02-19 17:33:20 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:33:20 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:33:20 --> Utf8 Class Initialized
INFO - 2020-02-19 17:33:20 --> URI Class Initialized
INFO - 2020-02-19 17:33:20 --> Router Class Initialized
INFO - 2020-02-19 17:33:20 --> Output Class Initialized
INFO - 2020-02-19 17:33:20 --> Security Class Initialized
DEBUG - 2020-02-19 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:33:21 --> CSRF cookie sent
INFO - 2020-02-19 17:33:21 --> Input Class Initialized
INFO - 2020-02-19 17:33:21 --> Language Class Initialized
INFO - 2020-02-19 17:33:21 --> Language Class Initialized
INFO - 2020-02-19 17:33:21 --> Config Class Initialized
INFO - 2020-02-19 17:33:21 --> Loader Class Initialized
INFO - 2020-02-19 17:33:21 --> Helper loaded: url_helper
INFO - 2020-02-19 17:33:21 --> Helper loaded: common_helper
INFO - 2020-02-19 17:33:21 --> Helper loaded: language_helper
INFO - 2020-02-19 17:33:21 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:33:21 --> Helper loaded: email_helper
INFO - 2020-02-19 17:33:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:33:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:33:21 --> Parser Class Initialized
INFO - 2020-02-19 17:33:21 --> User Agent Class Initialized
INFO - 2020-02-19 17:33:21 --> Model Class Initialized
INFO - 2020-02-19 17:33:21 --> Database Driver Class Initialized
INFO - 2020-02-19 17:33:21 --> Model Class Initialized
DEBUG - 2020-02-19 17:33:21 --> Template Class Initialized
INFO - 2020-02-19 17:33:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:33:21 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:33:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:33:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:33:21 --> Encryption Class Initialized
INFO - 2020-02-19 17:33:21 --> Controller Class Initialized
DEBUG - 2020-02-19 17:33:21 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:33:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:33:21 --> Model Class Initialized
ERROR - 2020-02-19 17:33:21 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:33:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:33:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:33:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:33:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:33:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:33:21 --> Model Class Initialized
DEBUG - 2020-02-19 17:33:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:33:21 --> Model Class Initialized
DEBUG - 2020-02-19 17:33:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:33:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:33:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:33:21 --> Final output sent to browser
DEBUG - 2020-02-19 17:33:21 --> Total execution time: 0.8319
INFO - 2020-02-19 17:33:45 --> Config Class Initialized
INFO - 2020-02-19 17:33:45 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:33:45 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:33:45 --> Utf8 Class Initialized
INFO - 2020-02-19 17:33:45 --> URI Class Initialized
INFO - 2020-02-19 17:33:45 --> Router Class Initialized
INFO - 2020-02-19 17:33:45 --> Output Class Initialized
INFO - 2020-02-19 17:33:45 --> Security Class Initialized
DEBUG - 2020-02-19 17:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:33:45 --> CSRF cookie sent
INFO - 2020-02-19 17:33:45 --> Input Class Initialized
INFO - 2020-02-19 17:33:45 --> Language Class Initialized
INFO - 2020-02-19 17:33:45 --> Language Class Initialized
INFO - 2020-02-19 17:33:45 --> Config Class Initialized
INFO - 2020-02-19 17:33:45 --> Loader Class Initialized
INFO - 2020-02-19 17:33:45 --> Helper loaded: url_helper
INFO - 2020-02-19 17:33:45 --> Helper loaded: common_helper
INFO - 2020-02-19 17:33:45 --> Helper loaded: language_helper
INFO - 2020-02-19 17:33:45 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:33:45 --> Helper loaded: email_helper
INFO - 2020-02-19 17:33:45 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:33:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:33:45 --> Parser Class Initialized
INFO - 2020-02-19 17:33:45 --> User Agent Class Initialized
INFO - 2020-02-19 17:33:45 --> Model Class Initialized
INFO - 2020-02-19 17:33:45 --> Database Driver Class Initialized
INFO - 2020-02-19 17:33:45 --> Model Class Initialized
DEBUG - 2020-02-19 17:33:45 --> Template Class Initialized
INFO - 2020-02-19 17:33:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:33:45 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:33:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:33:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:33:46 --> Encryption Class Initialized
INFO - 2020-02-19 17:33:46 --> Controller Class Initialized
DEBUG - 2020-02-19 17:33:46 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:33:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:33:46 --> Model Class Initialized
ERROR - 2020-02-19 17:33:46 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:33:46 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:33:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:33:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:33:46 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:33:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:33:46 --> Model Class Initialized
DEBUG - 2020-02-19 17:33:46 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:33:46 --> Model Class Initialized
DEBUG - 2020-02-19 17:33:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:33:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:33:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:33:46 --> Final output sent to browser
DEBUG - 2020-02-19 17:33:46 --> Total execution time: 0.8189
INFO - 2020-02-19 17:33:55 --> Config Class Initialized
INFO - 2020-02-19 17:33:55 --> Hooks Class Initialized
DEBUG - 2020-02-19 17:33:55 --> UTF-8 Support Enabled
INFO - 2020-02-19 17:33:55 --> Utf8 Class Initialized
INFO - 2020-02-19 17:33:55 --> URI Class Initialized
INFO - 2020-02-19 17:33:55 --> Router Class Initialized
INFO - 2020-02-19 17:33:55 --> Output Class Initialized
INFO - 2020-02-19 17:33:55 --> Security Class Initialized
DEBUG - 2020-02-19 17:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 17:33:55 --> CSRF cookie sent
INFO - 2020-02-19 17:33:55 --> Input Class Initialized
INFO - 2020-02-19 17:33:55 --> Language Class Initialized
INFO - 2020-02-19 17:33:55 --> Language Class Initialized
INFO - 2020-02-19 17:33:55 --> Config Class Initialized
INFO - 2020-02-19 17:33:55 --> Loader Class Initialized
INFO - 2020-02-19 17:33:55 --> Helper loaded: url_helper
INFO - 2020-02-19 17:33:55 --> Helper loaded: common_helper
INFO - 2020-02-19 17:33:55 --> Helper loaded: language_helper
INFO - 2020-02-19 17:33:55 --> Helper loaded: cookie_helper
INFO - 2020-02-19 17:33:55 --> Helper loaded: email_helper
INFO - 2020-02-19 17:33:55 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 17:33:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 17:33:55 --> Parser Class Initialized
INFO - 2020-02-19 17:33:55 --> User Agent Class Initialized
INFO - 2020-02-19 17:33:55 --> Model Class Initialized
INFO - 2020-02-19 17:33:55 --> Database Driver Class Initialized
INFO - 2020-02-19 17:33:55 --> Model Class Initialized
DEBUG - 2020-02-19 17:33:55 --> Template Class Initialized
INFO - 2020-02-19 17:33:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 17:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 17:33:55 --> Pagination Class Initialized
DEBUG - 2020-02-19 17:33:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 17:33:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 17:33:55 --> Encryption Class Initialized
INFO - 2020-02-19 17:33:55 --> Controller Class Initialized
DEBUG - 2020-02-19 17:33:55 --> category MX_Controller Initialized
DEBUG - 2020-02-19 17:33:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:33:56 --> Model Class Initialized
ERROR - 2020-02-19 17:33:56 --> Could not find the language line "Sorting"
INFO - 2020-02-19 17:33:56 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 17:33:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 17:33:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 17:33:56 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 17:33:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 17:33:56 --> Model Class Initialized
DEBUG - 2020-02-19 17:33:56 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 17:33:56 --> Model Class Initialized
DEBUG - 2020-02-19 17:33:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 17:33:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 17:33:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 17:33:56 --> Final output sent to browser
DEBUG - 2020-02-19 17:33:56 --> Total execution time: 0.8525
INFO - 2020-02-19 20:46:33 --> Config Class Initialized
INFO - 2020-02-19 20:46:33 --> Hooks Class Initialized
DEBUG - 2020-02-19 20:46:33 --> UTF-8 Support Enabled
INFO - 2020-02-19 20:46:33 --> Utf8 Class Initialized
INFO - 2020-02-19 20:46:33 --> URI Class Initialized
INFO - 2020-02-19 20:46:33 --> Router Class Initialized
INFO - 2020-02-19 20:46:33 --> Output Class Initialized
INFO - 2020-02-19 20:46:33 --> Security Class Initialized
DEBUG - 2020-02-19 20:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 20:46:33 --> CSRF cookie sent
INFO - 2020-02-19 20:46:42 --> Config Class Initialized
INFO - 2020-02-19 20:46:42 --> Hooks Class Initialized
DEBUG - 2020-02-19 20:46:42 --> UTF-8 Support Enabled
INFO - 2020-02-19 20:46:42 --> Utf8 Class Initialized
INFO - 2020-02-19 20:46:42 --> URI Class Initialized
INFO - 2020-02-19 20:46:42 --> Router Class Initialized
INFO - 2020-02-19 20:46:42 --> Output Class Initialized
INFO - 2020-02-19 20:46:42 --> Security Class Initialized
DEBUG - 2020-02-19 20:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 20:46:42 --> CSRF cookie sent
INFO - 2020-02-19 20:46:42 --> Input Class Initialized
INFO - 2020-02-19 20:46:42 --> Language Class Initialized
INFO - 2020-02-19 20:46:42 --> Language Class Initialized
INFO - 2020-02-19 20:46:42 --> Config Class Initialized
INFO - 2020-02-19 20:46:42 --> Loader Class Initialized
INFO - 2020-02-19 20:46:42 --> Helper loaded: url_helper
INFO - 2020-02-19 20:46:42 --> Helper loaded: common_helper
INFO - 2020-02-19 20:46:42 --> Helper loaded: language_helper
INFO - 2020-02-19 20:46:42 --> Helper loaded: cookie_helper
INFO - 2020-02-19 20:46:42 --> Helper loaded: email_helper
INFO - 2020-02-19 20:46:42 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 20:46:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 20:46:42 --> Parser Class Initialized
INFO - 2020-02-19 20:46:42 --> User Agent Class Initialized
INFO - 2020-02-19 20:46:42 --> Model Class Initialized
INFO - 2020-02-19 20:46:42 --> Database Driver Class Initialized
INFO - 2020-02-19 20:46:42 --> Model Class Initialized
DEBUG - 2020-02-19 20:46:42 --> Template Class Initialized
INFO - 2020-02-19 20:46:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 20:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 20:46:42 --> Pagination Class Initialized
DEBUG - 2020-02-19 20:46:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 20:46:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 20:46:42 --> Encryption Class Initialized
INFO - 2020-02-19 20:46:42 --> Controller Class Initialized
DEBUG - 2020-02-19 20:46:42 --> language MX_Controller Initialized
DEBUG - 2020-02-19 20:46:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2020-02-19 20:46:42 --> Model Class Initialized
INFO - 2020-02-19 20:46:47 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 20:46:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2020-02-19 20:46:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 20:46:47 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 20:46:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 20:46:47 --> Model Class Initialized
DEBUG - 2020-02-19 20:46:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 20:46:47 --> Model Class Initialized
DEBUG - 2020-02-19 20:46:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 20:46:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 20:46:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 20:46:47 --> Final output sent to browser
DEBUG - 2020-02-19 20:46:47 --> Total execution time: 5.3907
INFO - 2020-02-19 20:46:50 --> Config Class Initialized
INFO - 2020-02-19 20:46:50 --> Hooks Class Initialized
DEBUG - 2020-02-19 20:46:50 --> UTF-8 Support Enabled
INFO - 2020-02-19 20:46:50 --> Utf8 Class Initialized
INFO - 2020-02-19 20:46:50 --> URI Class Initialized
INFO - 2020-02-19 20:46:50 --> Router Class Initialized
INFO - 2020-02-19 20:46:50 --> Output Class Initialized
INFO - 2020-02-19 20:46:50 --> Security Class Initialized
DEBUG - 2020-02-19 20:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 20:46:51 --> CSRF cookie sent
INFO - 2020-02-19 20:46:51 --> CSRF token verified
INFO - 2020-02-19 20:46:51 --> Input Class Initialized
INFO - 2020-02-19 20:46:51 --> Language Class Initialized
INFO - 2020-02-19 20:46:51 --> Language Class Initialized
INFO - 2020-02-19 20:46:51 --> Config Class Initialized
INFO - 2020-02-19 20:46:51 --> Loader Class Initialized
INFO - 2020-02-19 20:46:51 --> Helper loaded: url_helper
INFO - 2020-02-19 20:46:51 --> Helper loaded: common_helper
INFO - 2020-02-19 20:46:51 --> Helper loaded: language_helper
INFO - 2020-02-19 20:46:51 --> Helper loaded: cookie_helper
INFO - 2020-02-19 20:46:51 --> Helper loaded: email_helper
INFO - 2020-02-19 20:46:51 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 20:46:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 20:46:51 --> Parser Class Initialized
INFO - 2020-02-19 20:46:51 --> User Agent Class Initialized
INFO - 2020-02-19 20:46:51 --> Model Class Initialized
INFO - 2020-02-19 20:46:51 --> Database Driver Class Initialized
INFO - 2020-02-19 20:46:51 --> Model Class Initialized
DEBUG - 2020-02-19 20:46:51 --> Template Class Initialized
INFO - 2020-02-19 20:46:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 20:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 20:46:51 --> Pagination Class Initialized
DEBUG - 2020-02-19 20:46:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 20:46:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 20:46:51 --> Encryption Class Initialized
INFO - 2020-02-19 20:46:51 --> Controller Class Initialized
DEBUG - 2020-02-19 20:46:51 --> language MX_Controller Initialized
DEBUG - 2020-02-19 20:46:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2020-02-19 20:46:51 --> Model Class Initialized
INFO - 2020-02-19 20:46:58 --> Config Class Initialized
INFO - 2020-02-19 20:46:58 --> Hooks Class Initialized
DEBUG - 2020-02-19 20:46:58 --> UTF-8 Support Enabled
INFO - 2020-02-19 20:46:58 --> Utf8 Class Initialized
INFO - 2020-02-19 20:46:58 --> URI Class Initialized
INFO - 2020-02-19 20:46:58 --> Router Class Initialized
INFO - 2020-02-19 20:46:58 --> Output Class Initialized
INFO - 2020-02-19 20:46:58 --> Security Class Initialized
DEBUG - 2020-02-19 20:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 20:46:58 --> CSRF cookie sent
INFO - 2020-02-19 20:46:58 --> Input Class Initialized
INFO - 2020-02-19 20:46:58 --> Language Class Initialized
INFO - 2020-02-19 20:46:58 --> Language Class Initialized
INFO - 2020-02-19 20:46:58 --> Config Class Initialized
INFO - 2020-02-19 20:46:58 --> Loader Class Initialized
INFO - 2020-02-19 20:46:58 --> Helper loaded: url_helper
INFO - 2020-02-19 20:46:58 --> Helper loaded: common_helper
INFO - 2020-02-19 20:46:58 --> Helper loaded: language_helper
INFO - 2020-02-19 20:46:58 --> Helper loaded: cookie_helper
INFO - 2020-02-19 20:46:58 --> Helper loaded: email_helper
INFO - 2020-02-19 20:46:58 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 20:46:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 20:46:58 --> Parser Class Initialized
INFO - 2020-02-19 20:46:58 --> User Agent Class Initialized
INFO - 2020-02-19 20:46:58 --> Model Class Initialized
INFO - 2020-02-19 20:46:59 --> Database Driver Class Initialized
INFO - 2020-02-19 20:46:59 --> Model Class Initialized
DEBUG - 2020-02-19 20:46:59 --> Template Class Initialized
INFO - 2020-02-19 20:46:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 20:46:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 20:46:59 --> Pagination Class Initialized
DEBUG - 2020-02-19 20:46:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 20:46:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 20:46:59 --> Encryption Class Initialized
INFO - 2020-02-19 20:46:59 --> Controller Class Initialized
DEBUG - 2020-02-19 20:46:59 --> language MX_Controller Initialized
DEBUG - 2020-02-19 20:46:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2020-02-19 20:46:59 --> Model Class Initialized
INFO - 2020-02-19 20:46:59 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 20:46:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2020-02-19 20:46:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 20:46:59 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 20:46:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 20:46:59 --> Model Class Initialized
DEBUG - 2020-02-19 20:46:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 20:46:59 --> Model Class Initialized
DEBUG - 2020-02-19 20:46:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 20:46:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 20:46:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 20:46:59 --> Final output sent to browser
DEBUG - 2020-02-19 20:46:59 --> Total execution time: 0.9044
INFO - 2020-02-19 20:47:18 --> Config Class Initialized
INFO - 2020-02-19 20:47:18 --> Hooks Class Initialized
DEBUG - 2020-02-19 20:47:18 --> UTF-8 Support Enabled
INFO - 2020-02-19 20:47:18 --> Utf8 Class Initialized
INFO - 2020-02-19 20:47:18 --> URI Class Initialized
INFO - 2020-02-19 20:47:18 --> Router Class Initialized
INFO - 2020-02-19 20:47:18 --> Output Class Initialized
INFO - 2020-02-19 20:47:18 --> Security Class Initialized
DEBUG - 2020-02-19 20:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 20:47:18 --> CSRF cookie sent
INFO - 2020-02-19 20:47:18 --> Input Class Initialized
INFO - 2020-02-19 20:47:18 --> Language Class Initialized
INFO - 2020-02-19 20:47:18 --> Language Class Initialized
INFO - 2020-02-19 20:47:18 --> Config Class Initialized
INFO - 2020-02-19 20:47:18 --> Loader Class Initialized
INFO - 2020-02-19 20:47:18 --> Helper loaded: url_helper
INFO - 2020-02-19 20:47:18 --> Helper loaded: common_helper
INFO - 2020-02-19 20:47:18 --> Helper loaded: language_helper
INFO - 2020-02-19 20:47:18 --> Helper loaded: cookie_helper
INFO - 2020-02-19 20:47:18 --> Helper loaded: email_helper
INFO - 2020-02-19 20:47:18 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 20:47:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 20:47:18 --> Parser Class Initialized
INFO - 2020-02-19 20:47:18 --> User Agent Class Initialized
INFO - 2020-02-19 20:47:18 --> Model Class Initialized
INFO - 2020-02-19 20:47:18 --> Database Driver Class Initialized
INFO - 2020-02-19 20:47:18 --> Model Class Initialized
DEBUG - 2020-02-19 20:47:18 --> Template Class Initialized
INFO - 2020-02-19 20:47:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 20:47:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 20:47:18 --> Pagination Class Initialized
DEBUG - 2020-02-19 20:47:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 20:47:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 20:47:18 --> Encryption Class Initialized
INFO - 2020-02-19 20:47:19 --> Controller Class Initialized
DEBUG - 2020-02-19 20:47:19 --> package MX_Controller Initialized
DEBUG - 2020-02-19 20:47:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 20:47:19 --> Model Class Initialized
INFO - 2020-02-19 20:47:19 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 20:47:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 20:47:19 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 20:47:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 20:47:19 --> Model Class Initialized
DEBUG - 2020-02-19 20:47:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 20:47:19 --> Model Class Initialized
DEBUG - 2020-02-19 20:47:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 20:47:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 20:47:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 20:47:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 20:47:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 20:47:19 --> Final output sent to browser
DEBUG - 2020-02-19 20:47:19 --> Total execution time: 1.1445
INFO - 2020-02-19 20:47:24 --> Config Class Initialized
INFO - 2020-02-19 20:47:24 --> Hooks Class Initialized
DEBUG - 2020-02-19 20:47:24 --> UTF-8 Support Enabled
INFO - 2020-02-19 20:47:24 --> Utf8 Class Initialized
INFO - 2020-02-19 20:47:24 --> URI Class Initialized
INFO - 2020-02-19 20:47:24 --> Router Class Initialized
INFO - 2020-02-19 20:47:24 --> Output Class Initialized
INFO - 2020-02-19 20:47:24 --> Security Class Initialized
DEBUG - 2020-02-19 20:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 20:47:24 --> CSRF cookie sent
INFO - 2020-02-19 20:47:24 --> Input Class Initialized
INFO - 2020-02-19 20:47:24 --> Language Class Initialized
INFO - 2020-02-19 20:47:24 --> Language Class Initialized
INFO - 2020-02-19 20:47:24 --> Config Class Initialized
INFO - 2020-02-19 20:47:24 --> Loader Class Initialized
INFO - 2020-02-19 20:47:24 --> Helper loaded: url_helper
INFO - 2020-02-19 20:47:24 --> Helper loaded: common_helper
INFO - 2020-02-19 20:47:24 --> Helper loaded: language_helper
INFO - 2020-02-19 20:47:24 --> Helper loaded: cookie_helper
INFO - 2020-02-19 20:47:24 --> Helper loaded: email_helper
INFO - 2020-02-19 20:47:24 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 20:47:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 20:47:24 --> Parser Class Initialized
INFO - 2020-02-19 20:47:24 --> User Agent Class Initialized
INFO - 2020-02-19 20:47:24 --> Model Class Initialized
INFO - 2020-02-19 20:47:24 --> Database Driver Class Initialized
INFO - 2020-02-19 20:47:24 --> Model Class Initialized
DEBUG - 2020-02-19 20:47:24 --> Template Class Initialized
INFO - 2020-02-19 20:47:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 20:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 20:47:24 --> Pagination Class Initialized
DEBUG - 2020-02-19 20:47:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 20:47:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 20:47:24 --> Encryption Class Initialized
INFO - 2020-02-19 20:47:24 --> Controller Class Initialized
DEBUG - 2020-02-19 20:47:24 --> package MX_Controller Initialized
DEBUG - 2020-02-19 20:47:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2020-02-19 20:47:24 --> Model Class Initialized
INFO - 2020-02-19 20:47:24 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 20:47:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 20:47:24 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 20:47:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 20:47:24 --> Model Class Initialized
DEBUG - 2020-02-19 20:47:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 20:47:24 --> Model Class Initialized
DEBUG - 2020-02-19 20:47:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2020-02-19 20:47:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2020-02-19 20:47:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2020-02-19 20:47:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2020-02-19 20:47:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2020-02-19 20:47:24 --> Final output sent to browser
DEBUG - 2020-02-19 20:47:25 --> Total execution time: 0.9503
INFO - 2020-02-19 22:51:00 --> Config Class Initialized
INFO - 2020-02-19 22:51:00 --> Hooks Class Initialized
DEBUG - 2020-02-19 22:51:00 --> UTF-8 Support Enabled
INFO - 2020-02-19 22:51:00 --> Utf8 Class Initialized
INFO - 2020-02-19 22:51:00 --> URI Class Initialized
INFO - 2020-02-19 22:51:00 --> Router Class Initialized
INFO - 2020-02-19 22:51:01 --> Output Class Initialized
INFO - 2020-02-19 22:51:01 --> Security Class Initialized
DEBUG - 2020-02-19 22:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 22:51:01 --> CSRF cookie sent
INFO - 2020-02-19 22:51:01 --> Input Class Initialized
INFO - 2020-02-19 22:51:01 --> Language Class Initialized
INFO - 2020-02-19 22:51:01 --> Language Class Initialized
INFO - 2020-02-19 22:51:01 --> Config Class Initialized
INFO - 2020-02-19 22:51:01 --> Loader Class Initialized
INFO - 2020-02-19 22:51:01 --> Helper loaded: url_helper
INFO - 2020-02-19 22:51:01 --> Helper loaded: common_helper
INFO - 2020-02-19 22:51:01 --> Helper loaded: language_helper
INFO - 2020-02-19 22:51:02 --> Helper loaded: cookie_helper
INFO - 2020-02-19 22:51:02 --> Helper loaded: email_helper
INFO - 2020-02-19 22:51:02 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 22:51:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 22:51:02 --> Parser Class Initialized
INFO - 2020-02-19 22:51:02 --> User Agent Class Initialized
INFO - 2020-02-19 22:51:02 --> Model Class Initialized
INFO - 2020-02-19 22:51:02 --> Database Driver Class Initialized
INFO - 2020-02-19 22:51:02 --> Model Class Initialized
DEBUG - 2020-02-19 22:51:02 --> Template Class Initialized
INFO - 2020-02-19 22:51:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 22:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 22:51:03 --> Pagination Class Initialized
DEBUG - 2020-02-19 22:51:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 22:51:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 22:51:03 --> Encryption Class Initialized
INFO - 2020-02-19 22:51:03 --> Controller Class Initialized
DEBUG - 2020-02-19 22:51:03 --> category MX_Controller Initialized
DEBUG - 2020-02-19 22:51:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 22:51:03 --> Model Class Initialized
ERROR - 2020-02-19 22:51:03 --> Could not find the language line "Sorting"
INFO - 2020-02-19 22:51:03 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 22:51:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 22:51:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 22:51:04 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 22:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 22:51:04 --> Model Class Initialized
DEBUG - 2020-02-19 22:51:04 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 22:51:04 --> Model Class Initialized
DEBUG - 2020-02-19 22:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 22:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 22:51:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 22:51:04 --> Final output sent to browser
DEBUG - 2020-02-19 22:51:04 --> Total execution time: 4.3183
INFO - 2020-02-19 23:22:17 --> Config Class Initialized
INFO - 2020-02-19 23:22:17 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:22:17 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:22:17 --> Utf8 Class Initialized
INFO - 2020-02-19 23:22:17 --> URI Class Initialized
INFO - 2020-02-19 23:22:17 --> Router Class Initialized
INFO - 2020-02-19 23:22:17 --> Output Class Initialized
INFO - 2020-02-19 23:22:17 --> Security Class Initialized
DEBUG - 2020-02-19 23:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:22:17 --> CSRF cookie sent
INFO - 2020-02-19 23:22:17 --> Input Class Initialized
INFO - 2020-02-19 23:22:17 --> Language Class Initialized
INFO - 2020-02-19 23:22:17 --> Language Class Initialized
INFO - 2020-02-19 23:22:17 --> Config Class Initialized
INFO - 2020-02-19 23:22:17 --> Loader Class Initialized
INFO - 2020-02-19 23:22:17 --> Helper loaded: url_helper
INFO - 2020-02-19 23:22:17 --> Helper loaded: common_helper
INFO - 2020-02-19 23:22:17 --> Helper loaded: language_helper
INFO - 2020-02-19 23:22:17 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:22:17 --> Helper loaded: email_helper
INFO - 2020-02-19 23:22:17 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:22:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:22:17 --> Parser Class Initialized
INFO - 2020-02-19 23:22:17 --> User Agent Class Initialized
INFO - 2020-02-19 23:22:17 --> Model Class Initialized
INFO - 2020-02-19 23:22:17 --> Database Driver Class Initialized
INFO - 2020-02-19 23:22:18 --> Model Class Initialized
DEBUG - 2020-02-19 23:22:18 --> Template Class Initialized
INFO - 2020-02-19 23:22:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:22:18 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:22:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:22:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:22:18 --> Encryption Class Initialized
INFO - 2020-02-19 23:22:18 --> Controller Class Initialized
DEBUG - 2020-02-19 23:22:18 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:22:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:22:18 --> Model Class Initialized
ERROR - 2020-02-19 23:22:18 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:22:18 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:22:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:22:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:22:18 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:22:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:22:18 --> Model Class Initialized
DEBUG - 2020-02-19 23:22:18 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:22:18 --> Model Class Initialized
DEBUG - 2020-02-19 23:22:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:22:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:22:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:22:18 --> Final output sent to browser
DEBUG - 2020-02-19 23:22:18 --> Total execution time: 1.8143
INFO - 2020-02-19 23:23:22 --> Config Class Initialized
INFO - 2020-02-19 23:23:22 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:23:22 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:23:22 --> Utf8 Class Initialized
INFO - 2020-02-19 23:23:22 --> URI Class Initialized
INFO - 2020-02-19 23:23:22 --> Router Class Initialized
INFO - 2020-02-19 23:23:22 --> Output Class Initialized
INFO - 2020-02-19 23:23:22 --> Security Class Initialized
DEBUG - 2020-02-19 23:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:23:22 --> CSRF cookie sent
INFO - 2020-02-19 23:23:22 --> Input Class Initialized
INFO - 2020-02-19 23:23:22 --> Language Class Initialized
INFO - 2020-02-19 23:23:22 --> Language Class Initialized
INFO - 2020-02-19 23:23:22 --> Config Class Initialized
INFO - 2020-02-19 23:23:22 --> Loader Class Initialized
INFO - 2020-02-19 23:23:22 --> Helper loaded: url_helper
INFO - 2020-02-19 23:23:22 --> Helper loaded: common_helper
INFO - 2020-02-19 23:23:22 --> Helper loaded: language_helper
INFO - 2020-02-19 23:23:23 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:23:23 --> Helper loaded: email_helper
INFO - 2020-02-19 23:23:23 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:23:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:23:23 --> Parser Class Initialized
INFO - 2020-02-19 23:23:23 --> User Agent Class Initialized
INFO - 2020-02-19 23:23:23 --> Model Class Initialized
INFO - 2020-02-19 23:23:23 --> Database Driver Class Initialized
INFO - 2020-02-19 23:23:23 --> Model Class Initialized
DEBUG - 2020-02-19 23:23:23 --> Template Class Initialized
INFO - 2020-02-19 23:23:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:23:23 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:23:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:23:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:23:23 --> Encryption Class Initialized
INFO - 2020-02-19 23:23:23 --> Controller Class Initialized
DEBUG - 2020-02-19 23:23:23 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:23:23 --> Model Class Initialized
ERROR - 2020-02-19 23:23:23 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:23:23 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:23:23 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:23:23 --> Model Class Initialized
DEBUG - 2020-02-19 23:23:23 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:23:23 --> Model Class Initialized
DEBUG - 2020-02-19 23:23:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:23:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:23:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:23:24 --> Final output sent to browser
DEBUG - 2020-02-19 23:23:24 --> Total execution time: 1.6691
INFO - 2020-02-19 23:25:19 --> Config Class Initialized
INFO - 2020-02-19 23:25:19 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:25:19 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:25:20 --> Utf8 Class Initialized
INFO - 2020-02-19 23:25:20 --> URI Class Initialized
INFO - 2020-02-19 23:25:20 --> Router Class Initialized
INFO - 2020-02-19 23:25:20 --> Output Class Initialized
INFO - 2020-02-19 23:25:20 --> Security Class Initialized
DEBUG - 2020-02-19 23:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:25:20 --> CSRF cookie sent
INFO - 2020-02-19 23:25:20 --> Input Class Initialized
INFO - 2020-02-19 23:25:20 --> Language Class Initialized
INFO - 2020-02-19 23:25:20 --> Language Class Initialized
INFO - 2020-02-19 23:25:20 --> Config Class Initialized
INFO - 2020-02-19 23:25:20 --> Loader Class Initialized
INFO - 2020-02-19 23:25:20 --> Helper loaded: url_helper
INFO - 2020-02-19 23:25:20 --> Helper loaded: common_helper
INFO - 2020-02-19 23:25:20 --> Helper loaded: language_helper
INFO - 2020-02-19 23:25:20 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:25:20 --> Helper loaded: email_helper
INFO - 2020-02-19 23:25:20 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:25:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:25:20 --> Parser Class Initialized
INFO - 2020-02-19 23:25:20 --> User Agent Class Initialized
INFO - 2020-02-19 23:25:20 --> Model Class Initialized
INFO - 2020-02-19 23:25:20 --> Database Driver Class Initialized
INFO - 2020-02-19 23:25:20 --> Model Class Initialized
DEBUG - 2020-02-19 23:25:20 --> Template Class Initialized
INFO - 2020-02-19 23:25:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:25:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:25:20 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:25:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:25:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:25:20 --> Encryption Class Initialized
INFO - 2020-02-19 23:25:20 --> Controller Class Initialized
DEBUG - 2020-02-19 23:25:20 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:25:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:25:21 --> Model Class Initialized
ERROR - 2020-02-19 23:25:21 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:25:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:25:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:25:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:25:21 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:25:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:25:21 --> Model Class Initialized
DEBUG - 2020-02-19 23:25:21 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:25:21 --> Model Class Initialized
DEBUG - 2020-02-19 23:25:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:25:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:25:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:25:21 --> Final output sent to browser
DEBUG - 2020-02-19 23:25:21 --> Total execution time: 1.6384
INFO - 2020-02-19 23:29:27 --> Config Class Initialized
INFO - 2020-02-19 23:29:27 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:29:27 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:29:27 --> Utf8 Class Initialized
INFO - 2020-02-19 23:29:27 --> URI Class Initialized
INFO - 2020-02-19 23:29:27 --> Router Class Initialized
INFO - 2020-02-19 23:29:27 --> Output Class Initialized
INFO - 2020-02-19 23:29:27 --> Security Class Initialized
DEBUG - 2020-02-19 23:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:29:27 --> CSRF cookie sent
INFO - 2020-02-19 23:29:27 --> Input Class Initialized
INFO - 2020-02-19 23:29:27 --> Language Class Initialized
INFO - 2020-02-19 23:29:27 --> Language Class Initialized
INFO - 2020-02-19 23:29:27 --> Config Class Initialized
INFO - 2020-02-19 23:29:27 --> Loader Class Initialized
INFO - 2020-02-19 23:29:28 --> Helper loaded: url_helper
INFO - 2020-02-19 23:29:28 --> Helper loaded: common_helper
INFO - 2020-02-19 23:29:28 --> Helper loaded: language_helper
INFO - 2020-02-19 23:29:28 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:29:28 --> Helper loaded: email_helper
INFO - 2020-02-19 23:29:28 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:29:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:29:28 --> Parser Class Initialized
INFO - 2020-02-19 23:29:28 --> User Agent Class Initialized
INFO - 2020-02-19 23:29:28 --> Model Class Initialized
INFO - 2020-02-19 23:29:28 --> Database Driver Class Initialized
INFO - 2020-02-19 23:29:28 --> Model Class Initialized
DEBUG - 2020-02-19 23:29:28 --> Template Class Initialized
INFO - 2020-02-19 23:29:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:29:28 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:29:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:29:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:29:28 --> Encryption Class Initialized
INFO - 2020-02-19 23:29:28 --> Controller Class Initialized
DEBUG - 2020-02-19 23:29:28 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:29:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:29:28 --> Model Class Initialized
ERROR - 2020-02-19 23:29:28 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:29:28 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:29:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:29:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:29:28 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:29:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:29:28 --> Model Class Initialized
DEBUG - 2020-02-19 23:29:29 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:29:29 --> Model Class Initialized
DEBUG - 2020-02-19 23:29:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:29:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:29:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:29:29 --> Final output sent to browser
DEBUG - 2020-02-19 23:29:29 --> Total execution time: 1.7063
INFO - 2020-02-19 23:29:48 --> Config Class Initialized
INFO - 2020-02-19 23:29:48 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:29:48 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:29:48 --> Utf8 Class Initialized
INFO - 2020-02-19 23:29:48 --> URI Class Initialized
INFO - 2020-02-19 23:29:48 --> Router Class Initialized
INFO - 2020-02-19 23:29:48 --> Output Class Initialized
INFO - 2020-02-19 23:29:48 --> Security Class Initialized
DEBUG - 2020-02-19 23:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:29:48 --> CSRF cookie sent
INFO - 2020-02-19 23:29:48 --> Input Class Initialized
INFO - 2020-02-19 23:29:48 --> Language Class Initialized
INFO - 2020-02-19 23:29:48 --> Language Class Initialized
INFO - 2020-02-19 23:29:48 --> Config Class Initialized
INFO - 2020-02-19 23:29:48 --> Loader Class Initialized
INFO - 2020-02-19 23:29:48 --> Helper loaded: url_helper
INFO - 2020-02-19 23:29:49 --> Helper loaded: common_helper
INFO - 2020-02-19 23:29:49 --> Helper loaded: language_helper
INFO - 2020-02-19 23:29:49 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:29:49 --> Helper loaded: email_helper
INFO - 2020-02-19 23:29:49 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:29:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:29:49 --> Parser Class Initialized
INFO - 2020-02-19 23:29:49 --> User Agent Class Initialized
INFO - 2020-02-19 23:29:49 --> Model Class Initialized
INFO - 2020-02-19 23:29:49 --> Database Driver Class Initialized
INFO - 2020-02-19 23:29:49 --> Model Class Initialized
DEBUG - 2020-02-19 23:29:49 --> Template Class Initialized
INFO - 2020-02-19 23:29:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:29:49 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:29:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:29:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:29:49 --> Encryption Class Initialized
INFO - 2020-02-19 23:29:49 --> Controller Class Initialized
DEBUG - 2020-02-19 23:29:49 --> profile MX_Controller Initialized
DEBUG - 2020-02-19 23:29:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/profile/models/profile_model.php
INFO - 2020-02-19 23:29:49 --> Model Class Initialized
INFO - 2020-02-19 23:29:49 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:29:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/profile/views/index.php
DEBUG - 2020-02-19 23:29:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:29:50 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:29:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:29:50 --> Model Class Initialized
DEBUG - 2020-02-19 23:29:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:29:50 --> Model Class Initialized
DEBUG - 2020-02-19 23:29:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:29:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:29:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:29:50 --> Final output sent to browser
DEBUG - 2020-02-19 23:29:50 --> Total execution time: 2.1853
INFO - 2020-02-19 23:30:40 --> Config Class Initialized
INFO - 2020-02-19 23:30:40 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:30:40 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:30:40 --> Utf8 Class Initialized
INFO - 2020-02-19 23:30:40 --> URI Class Initialized
INFO - 2020-02-19 23:30:40 --> Router Class Initialized
INFO - 2020-02-19 23:30:40 --> Output Class Initialized
INFO - 2020-02-19 23:30:40 --> Security Class Initialized
DEBUG - 2020-02-19 23:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:30:40 --> CSRF cookie sent
INFO - 2020-02-19 23:30:40 --> Input Class Initialized
INFO - 2020-02-19 23:30:40 --> Language Class Initialized
INFO - 2020-02-19 23:30:40 --> Language Class Initialized
INFO - 2020-02-19 23:30:40 --> Config Class Initialized
INFO - 2020-02-19 23:30:40 --> Loader Class Initialized
INFO - 2020-02-19 23:30:40 --> Helper loaded: url_helper
INFO - 2020-02-19 23:30:40 --> Helper loaded: common_helper
INFO - 2020-02-19 23:30:40 --> Helper loaded: language_helper
INFO - 2020-02-19 23:30:40 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:30:40 --> Helper loaded: email_helper
INFO - 2020-02-19 23:30:40 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:30:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:30:41 --> Parser Class Initialized
INFO - 2020-02-19 23:30:41 --> User Agent Class Initialized
INFO - 2020-02-19 23:30:41 --> Model Class Initialized
INFO - 2020-02-19 23:30:41 --> Database Driver Class Initialized
INFO - 2020-02-19 23:30:41 --> Model Class Initialized
DEBUG - 2020-02-19 23:30:41 --> Template Class Initialized
INFO - 2020-02-19 23:30:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:30:41 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:30:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:30:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:30:41 --> Encryption Class Initialized
INFO - 2020-02-19 23:30:41 --> Controller Class Initialized
DEBUG - 2020-02-19 23:30:41 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:30:41 --> Model Class Initialized
ERROR - 2020-02-19 23:30:41 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:30:41 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:30:41 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:30:41 --> Model Class Initialized
DEBUG - 2020-02-19 23:30:41 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:30:41 --> Model Class Initialized
DEBUG - 2020-02-19 23:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:30:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:30:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:30:42 --> Final output sent to browser
DEBUG - 2020-02-19 23:30:42 --> Total execution time: 1.7474
INFO - 2020-02-19 23:32:11 --> Config Class Initialized
INFO - 2020-02-19 23:32:11 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:32:11 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:32:11 --> Utf8 Class Initialized
INFO - 2020-02-19 23:32:11 --> URI Class Initialized
INFO - 2020-02-19 23:32:11 --> Router Class Initialized
INFO - 2020-02-19 23:32:11 --> Output Class Initialized
INFO - 2020-02-19 23:32:11 --> Security Class Initialized
DEBUG - 2020-02-19 23:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:32:11 --> CSRF cookie sent
INFO - 2020-02-19 23:32:11 --> Input Class Initialized
INFO - 2020-02-19 23:32:11 --> Language Class Initialized
INFO - 2020-02-19 23:32:11 --> Language Class Initialized
INFO - 2020-02-19 23:32:11 --> Config Class Initialized
INFO - 2020-02-19 23:32:12 --> Loader Class Initialized
INFO - 2020-02-19 23:32:12 --> Helper loaded: url_helper
INFO - 2020-02-19 23:32:12 --> Helper loaded: common_helper
INFO - 2020-02-19 23:32:12 --> Helper loaded: language_helper
INFO - 2020-02-19 23:32:12 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:32:12 --> Helper loaded: email_helper
INFO - 2020-02-19 23:32:12 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:32:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:32:12 --> Parser Class Initialized
INFO - 2020-02-19 23:32:12 --> User Agent Class Initialized
INFO - 2020-02-19 23:32:12 --> Model Class Initialized
INFO - 2020-02-19 23:32:12 --> Database Driver Class Initialized
INFO - 2020-02-19 23:32:12 --> Model Class Initialized
DEBUG - 2020-02-19 23:32:12 --> Template Class Initialized
INFO - 2020-02-19 23:32:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:32:12 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:32:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:32:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:32:12 --> Encryption Class Initialized
INFO - 2020-02-19 23:32:12 --> Controller Class Initialized
DEBUG - 2020-02-19 23:32:12 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:32:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:32:12 --> Model Class Initialized
ERROR - 2020-02-19 23:32:12 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:32:12 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:32:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:32:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:32:12 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:32:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:32:12 --> Model Class Initialized
DEBUG - 2020-02-19 23:32:12 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:32:13 --> Model Class Initialized
DEBUG - 2020-02-19 23:32:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:32:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:32:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:32:13 --> Final output sent to browser
DEBUG - 2020-02-19 23:32:13 --> Total execution time: 1.6777
INFO - 2020-02-19 23:33:04 --> Config Class Initialized
INFO - 2020-02-19 23:33:04 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:33:04 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:33:04 --> Utf8 Class Initialized
INFO - 2020-02-19 23:33:04 --> URI Class Initialized
INFO - 2020-02-19 23:33:04 --> Router Class Initialized
INFO - 2020-02-19 23:33:05 --> Output Class Initialized
INFO - 2020-02-19 23:33:05 --> Security Class Initialized
DEBUG - 2020-02-19 23:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:33:05 --> CSRF cookie sent
INFO - 2020-02-19 23:33:05 --> Input Class Initialized
INFO - 2020-02-19 23:33:05 --> Language Class Initialized
INFO - 2020-02-19 23:33:05 --> Language Class Initialized
INFO - 2020-02-19 23:33:05 --> Config Class Initialized
INFO - 2020-02-19 23:33:05 --> Loader Class Initialized
INFO - 2020-02-19 23:33:05 --> Helper loaded: url_helper
INFO - 2020-02-19 23:33:05 --> Helper loaded: common_helper
INFO - 2020-02-19 23:33:05 --> Helper loaded: language_helper
INFO - 2020-02-19 23:33:05 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:33:05 --> Helper loaded: email_helper
INFO - 2020-02-19 23:33:05 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:33:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:33:05 --> Parser Class Initialized
INFO - 2020-02-19 23:33:05 --> User Agent Class Initialized
INFO - 2020-02-19 23:33:05 --> Model Class Initialized
INFO - 2020-02-19 23:33:05 --> Database Driver Class Initialized
INFO - 2020-02-19 23:33:05 --> Model Class Initialized
DEBUG - 2020-02-19 23:33:05 --> Template Class Initialized
INFO - 2020-02-19 23:33:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:33:05 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:33:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:33:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:33:05 --> Encryption Class Initialized
INFO - 2020-02-19 23:33:05 --> Controller Class Initialized
DEBUG - 2020-02-19 23:33:05 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:33:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:33:05 --> Model Class Initialized
ERROR - 2020-02-19 23:33:06 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:33:06 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:33:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:33:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:33:06 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:33:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:33:06 --> Model Class Initialized
DEBUG - 2020-02-19 23:33:06 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:33:06 --> Model Class Initialized
DEBUG - 2020-02-19 23:33:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:33:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:33:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:33:06 --> Final output sent to browser
DEBUG - 2020-02-19 23:33:06 --> Total execution time: 1.7416
INFO - 2020-02-19 23:33:53 --> Config Class Initialized
INFO - 2020-02-19 23:33:53 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:33:53 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:33:53 --> Utf8 Class Initialized
INFO - 2020-02-19 23:33:53 --> URI Class Initialized
INFO - 2020-02-19 23:33:53 --> Router Class Initialized
INFO - 2020-02-19 23:33:54 --> Output Class Initialized
INFO - 2020-02-19 23:33:54 --> Security Class Initialized
DEBUG - 2020-02-19 23:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:33:54 --> CSRF cookie sent
INFO - 2020-02-19 23:33:54 --> Input Class Initialized
INFO - 2020-02-19 23:33:54 --> Language Class Initialized
INFO - 2020-02-19 23:33:54 --> Language Class Initialized
INFO - 2020-02-19 23:33:54 --> Config Class Initialized
INFO - 2020-02-19 23:33:54 --> Loader Class Initialized
INFO - 2020-02-19 23:33:54 --> Helper loaded: url_helper
INFO - 2020-02-19 23:33:54 --> Helper loaded: common_helper
INFO - 2020-02-19 23:33:54 --> Helper loaded: language_helper
INFO - 2020-02-19 23:33:54 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:33:54 --> Helper loaded: email_helper
INFO - 2020-02-19 23:33:54 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:33:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:33:54 --> Parser Class Initialized
INFO - 2020-02-19 23:33:54 --> User Agent Class Initialized
INFO - 2020-02-19 23:33:54 --> Model Class Initialized
INFO - 2020-02-19 23:33:54 --> Database Driver Class Initialized
INFO - 2020-02-19 23:33:54 --> Model Class Initialized
DEBUG - 2020-02-19 23:33:54 --> Template Class Initialized
INFO - 2020-02-19 23:33:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:33:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:33:54 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:33:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:33:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:33:55 --> Encryption Class Initialized
INFO - 2020-02-19 23:33:55 --> Controller Class Initialized
DEBUG - 2020-02-19 23:33:55 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:33:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:33:55 --> Model Class Initialized
ERROR - 2020-02-19 23:33:55 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:33:55 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:33:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:33:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:33:55 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:33:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:33:55 --> Model Class Initialized
DEBUG - 2020-02-19 23:33:55 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:33:55 --> Model Class Initialized
DEBUG - 2020-02-19 23:33:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:33:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:33:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:33:55 --> Final output sent to browser
DEBUG - 2020-02-19 23:33:55 --> Total execution time: 1.8762
INFO - 2020-02-19 23:42:20 --> Config Class Initialized
INFO - 2020-02-19 23:42:20 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:42:20 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:42:20 --> Utf8 Class Initialized
INFO - 2020-02-19 23:42:20 --> URI Class Initialized
INFO - 2020-02-19 23:42:20 --> Router Class Initialized
INFO - 2020-02-19 23:42:20 --> Output Class Initialized
INFO - 2020-02-19 23:42:20 --> Security Class Initialized
DEBUG - 2020-02-19 23:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:42:20 --> CSRF cookie sent
INFO - 2020-02-19 23:42:20 --> Input Class Initialized
INFO - 2020-02-19 23:42:20 --> Language Class Initialized
INFO - 2020-02-19 23:42:20 --> Language Class Initialized
INFO - 2020-02-19 23:42:20 --> Config Class Initialized
INFO - 2020-02-19 23:42:21 --> Loader Class Initialized
INFO - 2020-02-19 23:42:21 --> Helper loaded: url_helper
INFO - 2020-02-19 23:42:21 --> Helper loaded: common_helper
INFO - 2020-02-19 23:42:21 --> Helper loaded: language_helper
INFO - 2020-02-19 23:42:21 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:42:21 --> Helper loaded: email_helper
INFO - 2020-02-19 23:42:21 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:42:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:42:21 --> Parser Class Initialized
INFO - 2020-02-19 23:42:21 --> User Agent Class Initialized
INFO - 2020-02-19 23:42:21 --> Model Class Initialized
INFO - 2020-02-19 23:42:21 --> Database Driver Class Initialized
INFO - 2020-02-19 23:42:21 --> Model Class Initialized
DEBUG - 2020-02-19 23:42:21 --> Template Class Initialized
INFO - 2020-02-19 23:42:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:42:21 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:42:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:42:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:42:21 --> Encryption Class Initialized
INFO - 2020-02-19 23:42:21 --> Controller Class Initialized
DEBUG - 2020-02-19 23:42:21 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:42:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:42:21 --> Model Class Initialized
ERROR - 2020-02-19 23:42:21 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:42:21 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:42:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:42:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:42:22 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:42:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:42:22 --> Model Class Initialized
DEBUG - 2020-02-19 23:42:22 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:42:22 --> Model Class Initialized
DEBUG - 2020-02-19 23:42:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:42:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:42:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:42:22 --> Final output sent to browser
DEBUG - 2020-02-19 23:42:22 --> Total execution time: 1.9940
INFO - 2020-02-19 23:43:00 --> Config Class Initialized
INFO - 2020-02-19 23:43:00 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:43:00 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:43:00 --> Utf8 Class Initialized
INFO - 2020-02-19 23:43:00 --> URI Class Initialized
INFO - 2020-02-19 23:43:00 --> Router Class Initialized
INFO - 2020-02-19 23:43:00 --> Output Class Initialized
INFO - 2020-02-19 23:43:00 --> Security Class Initialized
DEBUG - 2020-02-19 23:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:43:00 --> CSRF cookie sent
INFO - 2020-02-19 23:43:00 --> Input Class Initialized
INFO - 2020-02-19 23:43:00 --> Language Class Initialized
INFO - 2020-02-19 23:43:00 --> Language Class Initialized
INFO - 2020-02-19 23:43:00 --> Config Class Initialized
INFO - 2020-02-19 23:43:00 --> Loader Class Initialized
INFO - 2020-02-19 23:43:00 --> Helper loaded: url_helper
INFO - 2020-02-19 23:43:00 --> Helper loaded: common_helper
INFO - 2020-02-19 23:43:00 --> Helper loaded: language_helper
INFO - 2020-02-19 23:43:00 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:43:00 --> Helper loaded: email_helper
INFO - 2020-02-19 23:43:00 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:43:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:43:00 --> Parser Class Initialized
INFO - 2020-02-19 23:43:01 --> User Agent Class Initialized
INFO - 2020-02-19 23:43:01 --> Model Class Initialized
INFO - 2020-02-19 23:43:01 --> Database Driver Class Initialized
INFO - 2020-02-19 23:43:01 --> Model Class Initialized
DEBUG - 2020-02-19 23:43:01 --> Template Class Initialized
INFO - 2020-02-19 23:43:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:43:01 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:43:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:43:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:43:01 --> Encryption Class Initialized
INFO - 2020-02-19 23:43:01 --> Controller Class Initialized
DEBUG - 2020-02-19 23:43:01 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:43:01 --> Model Class Initialized
ERROR - 2020-02-19 23:43:01 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:43:01 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:43:01 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:43:01 --> Model Class Initialized
DEBUG - 2020-02-19 23:43:01 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:43:01 --> Model Class Initialized
DEBUG - 2020-02-19 23:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:43:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:43:01 --> Final output sent to browser
DEBUG - 2020-02-19 23:43:02 --> Total execution time: 1.7685
INFO - 2020-02-19 23:43:14 --> Config Class Initialized
INFO - 2020-02-19 23:43:14 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:43:14 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:43:14 --> Utf8 Class Initialized
INFO - 2020-02-19 23:43:14 --> URI Class Initialized
INFO - 2020-02-19 23:43:14 --> Router Class Initialized
INFO - 2020-02-19 23:43:14 --> Output Class Initialized
INFO - 2020-02-19 23:43:14 --> Security Class Initialized
DEBUG - 2020-02-19 23:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:43:14 --> CSRF cookie sent
INFO - 2020-02-19 23:43:14 --> Input Class Initialized
INFO - 2020-02-19 23:43:14 --> Language Class Initialized
INFO - 2020-02-19 23:43:14 --> Language Class Initialized
INFO - 2020-02-19 23:43:14 --> Config Class Initialized
INFO - 2020-02-19 23:43:14 --> Loader Class Initialized
INFO - 2020-02-19 23:43:14 --> Helper loaded: url_helper
INFO - 2020-02-19 23:43:14 --> Helper loaded: common_helper
INFO - 2020-02-19 23:43:14 --> Helper loaded: language_helper
INFO - 2020-02-19 23:43:14 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:43:14 --> Helper loaded: email_helper
INFO - 2020-02-19 23:43:15 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:43:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:43:15 --> Parser Class Initialized
INFO - 2020-02-19 23:43:15 --> User Agent Class Initialized
INFO - 2020-02-19 23:43:15 --> Model Class Initialized
INFO - 2020-02-19 23:43:15 --> Database Driver Class Initialized
INFO - 2020-02-19 23:43:15 --> Model Class Initialized
DEBUG - 2020-02-19 23:43:15 --> Template Class Initialized
INFO - 2020-02-19 23:43:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:43:15 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:43:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:43:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:43:15 --> Encryption Class Initialized
INFO - 2020-02-19 23:43:15 --> Controller Class Initialized
DEBUG - 2020-02-19 23:43:15 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:43:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:43:15 --> Model Class Initialized
ERROR - 2020-02-19 23:43:15 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:43:15 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:43:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:43:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:43:15 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:43:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:43:15 --> Model Class Initialized
DEBUG - 2020-02-19 23:43:15 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:43:15 --> Model Class Initialized
DEBUG - 2020-02-19 23:43:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:43:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:43:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:43:16 --> Final output sent to browser
DEBUG - 2020-02-19 23:43:16 --> Total execution time: 1.7120
INFO - 2020-02-19 23:43:35 --> Config Class Initialized
INFO - 2020-02-19 23:43:35 --> Hooks Class Initialized
DEBUG - 2020-02-19 23:43:35 --> UTF-8 Support Enabled
INFO - 2020-02-19 23:43:35 --> Utf8 Class Initialized
INFO - 2020-02-19 23:43:35 --> URI Class Initialized
INFO - 2020-02-19 23:43:35 --> Router Class Initialized
INFO - 2020-02-19 23:43:35 --> Output Class Initialized
INFO - 2020-02-19 23:43:35 --> Security Class Initialized
DEBUG - 2020-02-19 23:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-19 23:43:36 --> CSRF cookie sent
INFO - 2020-02-19 23:43:36 --> Input Class Initialized
INFO - 2020-02-19 23:43:36 --> Language Class Initialized
INFO - 2020-02-19 23:43:36 --> Language Class Initialized
INFO - 2020-02-19 23:43:36 --> Config Class Initialized
INFO - 2020-02-19 23:43:36 --> Loader Class Initialized
INFO - 2020-02-19 23:43:36 --> Helper loaded: url_helper
INFO - 2020-02-19 23:43:36 --> Helper loaded: common_helper
INFO - 2020-02-19 23:43:36 --> Helper loaded: language_helper
INFO - 2020-02-19 23:43:36 --> Helper loaded: cookie_helper
INFO - 2020-02-19 23:43:36 --> Helper loaded: email_helper
INFO - 2020-02-19 23:43:36 --> Helper loaded: file_manager_helper
INFO - 2020-02-19 23:43:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-02-19 23:43:36 --> Parser Class Initialized
INFO - 2020-02-19 23:43:36 --> User Agent Class Initialized
INFO - 2020-02-19 23:43:36 --> Model Class Initialized
INFO - 2020-02-19 23:43:36 --> Database Driver Class Initialized
INFO - 2020-02-19 23:43:36 --> Model Class Initialized
DEBUG - 2020-02-19 23:43:36 --> Template Class Initialized
INFO - 2020-02-19 23:43:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-02-19 23:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-19 23:43:36 --> Pagination Class Initialized
DEBUG - 2020-02-19 23:43:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-02-19 23:43:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-02-19 23:43:36 --> Encryption Class Initialized
INFO - 2020-02-19 23:43:36 --> Controller Class Initialized
DEBUG - 2020-02-19 23:43:36 --> category MX_Controller Initialized
DEBUG - 2020-02-19 23:43:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:43:37 --> Model Class Initialized
ERROR - 2020-02-19 23:43:37 --> Could not find the language line "Sorting"
INFO - 2020-02-19 23:43:37 --> Helper loaded: inflector_helper
DEBUG - 2020-02-19 23:43:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
DEBUG - 2020-02-19 23:43:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-02-19 23:43:37 --> blocks MX_Controller Initialized
DEBUG - 2020-02-19 23:43:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2020-02-19 23:43:37 --> Model Class Initialized
DEBUG - 2020-02-19 23:43:37 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2020-02-19 23:43:37 --> Model Class Initialized
DEBUG - 2020-02-19 23:43:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2020-02-19 23:43:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-02-19 23:43:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2020-02-19 23:43:37 --> Final output sent to browser
DEBUG - 2020-02-19 23:43:37 --> Total execution time: 2.0238
