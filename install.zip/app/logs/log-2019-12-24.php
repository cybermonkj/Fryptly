<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-24 16:22:00 --> Config Class Initialized
INFO - 2019-12-24 16:22:00 --> Hooks Class Initialized
DEBUG - 2019-12-24 16:22:00 --> UTF-8 Support Enabled
INFO - 2019-12-24 16:22:00 --> Utf8 Class Initialized
INFO - 2019-12-24 16:22:00 --> URI Class Initialized
DEBUG - 2019-12-24 16:22:00 --> No URI present. Default controller set.
INFO - 2019-12-24 16:22:00 --> Router Class Initialized
INFO - 2019-12-24 16:22:00 --> Output Class Initialized
INFO - 2019-12-24 16:22:00 --> Security Class Initialized
DEBUG - 2019-12-24 16:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-24 16:22:00 --> CSRF cookie sent
INFO - 2019-12-24 16:22:00 --> Input Class Initialized
INFO - 2019-12-24 16:22:00 --> Language Class Initialized
INFO - 2019-12-24 16:22:00 --> Language Class Initialized
INFO - 2019-12-24 16:22:00 --> Config Class Initialized
INFO - 2019-12-24 16:22:01 --> Loader Class Initialized
INFO - 2019-12-24 16:22:01 --> Helper loaded: url_helper
INFO - 2019-12-24 16:22:01 --> Helper loaded: common_helper
INFO - 2019-12-24 16:22:01 --> Helper loaded: language_helper
INFO - 2019-12-24 16:22:01 --> Helper loaded: cookie_helper
INFO - 2019-12-24 16:22:01 --> Helper loaded: email_helper
INFO - 2019-12-24 16:22:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-24 16:22:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-24 16:22:01 --> Parser Class Initialized
INFO - 2019-12-24 16:22:01 --> User Agent Class Initialized
INFO - 2019-12-24 16:22:01 --> Model Class Initialized
INFO - 2019-12-24 16:22:01 --> Database Driver Class Initialized
INFO - 2019-12-24 16:22:01 --> Model Class Initialized
DEBUG - 2019-12-24 16:22:01 --> Template Class Initialized
INFO - 2019-12-24 16:22:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-24 16:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-24 16:22:01 --> Pagination Class Initialized
DEBUG - 2019-12-24 16:22:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-24 16:22:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-24 16:22:01 --> Encryption Class Initialized
DEBUG - 2019-12-24 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-24 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-24 16:22:01 --> Controller Class Initialized
DEBUG - 2019-12-24 16:22:01 --> pergo MX_Controller Initialized
DEBUG - 2019-12-24 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-24 16:22:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-24 16:22:01 --> Model Class Initialized
INFO - 2019-12-24 16:22:01 --> Helper loaded: inflector_helper
DEBUG - 2019-12-24 16:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-24 16:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-24 16:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-24 16:22:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-24 16:22:02 --> Final output sent to browser
DEBUG - 2019-12-24 16:22:02 --> Total execution time: 1.8510
