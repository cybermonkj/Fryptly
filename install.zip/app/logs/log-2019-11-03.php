<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-03 21:25:14 --> Config Class Initialized
INFO - 2019-11-03 21:25:14 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:25:14 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:25:14 --> Utf8 Class Initialized
INFO - 2019-11-03 21:25:14 --> URI Class Initialized
INFO - 2019-11-03 21:25:14 --> Router Class Initialized
INFO - 2019-11-03 21:25:14 --> Output Class Initialized
INFO - 2019-11-03 21:25:14 --> Security Class Initialized
DEBUG - 2019-11-03 21:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:25:14 --> CSRF cookie sent
INFO - 2019-11-03 21:25:14 --> Input Class Initialized
INFO - 2019-11-03 21:25:14 --> Language Class Initialized
INFO - 2019-11-03 21:25:14 --> Language Class Initialized
INFO - 2019-11-03 21:25:14 --> Config Class Initialized
INFO - 2019-11-03 21:25:15 --> Loader Class Initialized
INFO - 2019-11-03 21:25:15 --> Helper loaded: url_helper
INFO - 2019-11-03 21:25:15 --> Helper loaded: common_helper
INFO - 2019-11-03 21:25:15 --> Helper loaded: language_helper
INFO - 2019-11-03 21:25:15 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:25:15 --> Helper loaded: email_helper
INFO - 2019-11-03 21:25:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:25:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:25:15 --> Parser Class Initialized
INFO - 2019-11-03 21:25:15 --> User Agent Class Initialized
INFO - 2019-11-03 21:25:15 --> Model Class Initialized
INFO - 2019-11-03 21:25:15 --> Database Driver Class Initialized
INFO - 2019-11-03 21:25:15 --> Model Class Initialized
DEBUG - 2019-11-03 21:25:15 --> Template Class Initialized
INFO - 2019-11-03 21:25:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:25:15 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:25:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:25:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:25:15 --> Encryption Class Initialized
INFO - 2019-11-03 21:25:15 --> Controller Class Initialized
DEBUG - 2019-11-03 21:25:15 --> auth MX_Controller Initialized
DEBUG - 2019-11-03 21:25:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-03 21:25:15 --> Model Class Initialized
DEBUG - 2019-11-03 21:25:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-03 21:25:15 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 21:25:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-03 21:25:15 --> pergo MX_Controller Initialized
DEBUG - 2019-11-03 21:25:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-03 21:25:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-03 21:25:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-03 21:25:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-03 21:25:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-03 21:25:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-03 21:25:16 --> Final output sent to browser
DEBUG - 2019-11-03 21:25:16 --> Total execution time: 1.5812
INFO - 2019-11-03 21:25:18 --> Config Class Initialized
INFO - 2019-11-03 21:25:18 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:25:18 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:25:18 --> Utf8 Class Initialized
INFO - 2019-11-03 21:25:18 --> URI Class Initialized
INFO - 2019-11-03 21:25:18 --> Router Class Initialized
INFO - 2019-11-03 21:25:18 --> Output Class Initialized
INFO - 2019-11-03 21:25:18 --> Security Class Initialized
DEBUG - 2019-11-03 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:25:18 --> CSRF cookie sent
INFO - 2019-11-03 21:25:18 --> CSRF token verified
INFO - 2019-11-03 21:25:18 --> Input Class Initialized
INFO - 2019-11-03 21:25:18 --> Language Class Initialized
INFO - 2019-11-03 21:25:18 --> Language Class Initialized
INFO - 2019-11-03 21:25:18 --> Config Class Initialized
INFO - 2019-11-03 21:25:18 --> Loader Class Initialized
INFO - 2019-11-03 21:25:18 --> Helper loaded: url_helper
INFO - 2019-11-03 21:25:18 --> Helper loaded: common_helper
INFO - 2019-11-03 21:25:18 --> Helper loaded: language_helper
INFO - 2019-11-03 21:25:18 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:25:18 --> Helper loaded: email_helper
INFO - 2019-11-03 21:25:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:25:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:25:18 --> Parser Class Initialized
INFO - 2019-11-03 21:25:18 --> User Agent Class Initialized
INFO - 2019-11-03 21:25:18 --> Model Class Initialized
INFO - 2019-11-03 21:25:18 --> Database Driver Class Initialized
INFO - 2019-11-03 21:25:18 --> Model Class Initialized
DEBUG - 2019-11-03 21:25:18 --> Template Class Initialized
INFO - 2019-11-03 21:25:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:25:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:25:18 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:25:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:25:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:25:18 --> Encryption Class Initialized
INFO - 2019-11-03 21:25:18 --> Controller Class Initialized
DEBUG - 2019-11-03 21:25:18 --> auth MX_Controller Initialized
DEBUG - 2019-11-03 21:25:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-03 21:25:18 --> Model Class Initialized
INFO - 2019-11-03 21:25:24 --> Config Class Initialized
INFO - 2019-11-03 21:25:24 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:25:24 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:25:24 --> Utf8 Class Initialized
INFO - 2019-11-03 21:25:24 --> URI Class Initialized
INFO - 2019-11-03 21:25:24 --> Router Class Initialized
INFO - 2019-11-03 21:25:24 --> Output Class Initialized
INFO - 2019-11-03 21:25:24 --> Security Class Initialized
DEBUG - 2019-11-03 21:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:25:24 --> CSRF cookie sent
INFO - 2019-11-03 21:25:24 --> Input Class Initialized
INFO - 2019-11-03 21:25:24 --> Language Class Initialized
INFO - 2019-11-03 21:25:24 --> Language Class Initialized
INFO - 2019-11-03 21:25:24 --> Config Class Initialized
INFO - 2019-11-03 21:25:24 --> Loader Class Initialized
INFO - 2019-11-03 21:25:24 --> Helper loaded: url_helper
INFO - 2019-11-03 21:25:24 --> Helper loaded: common_helper
INFO - 2019-11-03 21:25:24 --> Helper loaded: language_helper
INFO - 2019-11-03 21:25:24 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:25:24 --> Helper loaded: email_helper
INFO - 2019-11-03 21:25:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:25:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:25:24 --> Parser Class Initialized
INFO - 2019-11-03 21:25:24 --> User Agent Class Initialized
INFO - 2019-11-03 21:25:24 --> Model Class Initialized
INFO - 2019-11-03 21:25:24 --> Database Driver Class Initialized
INFO - 2019-11-03 21:25:24 --> Model Class Initialized
DEBUG - 2019-11-03 21:25:24 --> Template Class Initialized
INFO - 2019-11-03 21:25:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:25:24 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:25:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:25:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:25:24 --> Encryption Class Initialized
INFO - 2019-11-03 21:25:24 --> Controller Class Initialized
DEBUG - 2019-11-03 21:25:24 --> statistics MX_Controller Initialized
DEBUG - 2019-11-03 21:25:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-03 21:25:24 --> Model Class Initialized
ERROR - 2019-11-03 21:25:25 --> Could not find the language line "Pending"
ERROR - 2019-11-03 21:25:25 --> Could not find the language line "Pending"
INFO - 2019-11-03 21:25:25 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 21:25:25 --> Could not find the language line "total_orders"
ERROR - 2019-11-03 21:25:25 --> Could not find the language line "total_orders"
ERROR - 2019-11-03 21:25:25 --> Could not find the language line "Pending"
DEBUG - 2019-11-03 21:25:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-03 21:25:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 21:25:25 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 21:25:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 21:25:25 --> Model Class Initialized
DEBUG - 2019-11-03 21:25:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 21:25:25 --> Model Class Initialized
DEBUG - 2019-11-03 21:25:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 21:25:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 21:25:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 21:25:25 --> Final output sent to browser
DEBUG - 2019-11-03 21:25:25 --> Total execution time: 1.2950
INFO - 2019-11-03 21:38:42 --> Config Class Initialized
INFO - 2019-11-03 21:38:42 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:38:42 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:38:42 --> Utf8 Class Initialized
INFO - 2019-11-03 21:38:42 --> URI Class Initialized
INFO - 2019-11-03 21:38:42 --> Router Class Initialized
INFO - 2019-11-03 21:38:42 --> Output Class Initialized
INFO - 2019-11-03 21:38:42 --> Security Class Initialized
DEBUG - 2019-11-03 21:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:38:42 --> CSRF cookie sent
INFO - 2019-11-03 21:38:42 --> Input Class Initialized
INFO - 2019-11-03 21:38:42 --> Language Class Initialized
INFO - 2019-11-03 21:38:42 --> Language Class Initialized
INFO - 2019-11-03 21:38:42 --> Config Class Initialized
INFO - 2019-11-03 21:38:42 --> Loader Class Initialized
INFO - 2019-11-03 21:38:42 --> Helper loaded: url_helper
INFO - 2019-11-03 21:38:42 --> Helper loaded: common_helper
INFO - 2019-11-03 21:38:42 --> Helper loaded: language_helper
INFO - 2019-11-03 21:38:42 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:38:42 --> Helper loaded: email_helper
INFO - 2019-11-03 21:38:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:38:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:38:42 --> Parser Class Initialized
INFO - 2019-11-03 21:38:42 --> User Agent Class Initialized
INFO - 2019-11-03 21:38:42 --> Model Class Initialized
INFO - 2019-11-03 21:38:42 --> Database Driver Class Initialized
INFO - 2019-11-03 21:38:42 --> Model Class Initialized
DEBUG - 2019-11-03 21:38:42 --> Template Class Initialized
INFO - 2019-11-03 21:38:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:38:42 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:38:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:38:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:38:42 --> Encryption Class Initialized
INFO - 2019-11-03 21:38:42 --> Controller Class Initialized
DEBUG - 2019-11-03 21:38:42 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 21:38:42 --> Model Class Initialized
INFO - 2019-11-03 21:38:42 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 21:38:42 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 21:38:42 --> Model Class Initialized
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 21:38:42 --> Model Class Initialized
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 21:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 21:38:42 --> Final output sent to browser
DEBUG - 2019-11-03 21:38:42 --> Total execution time: 0.8063
INFO - 2019-11-03 21:58:50 --> Config Class Initialized
INFO - 2019-11-03 21:58:50 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:58:50 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:58:50 --> Utf8 Class Initialized
INFO - 2019-11-03 21:58:50 --> URI Class Initialized
INFO - 2019-11-03 21:58:50 --> Router Class Initialized
INFO - 2019-11-03 21:58:50 --> Output Class Initialized
INFO - 2019-11-03 21:58:50 --> Security Class Initialized
DEBUG - 2019-11-03 21:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:58:50 --> CSRF cookie sent
INFO - 2019-11-03 21:58:50 --> Input Class Initialized
INFO - 2019-11-03 21:58:50 --> Language Class Initialized
INFO - 2019-11-03 21:58:50 --> Language Class Initialized
INFO - 2019-11-03 21:58:50 --> Config Class Initialized
INFO - 2019-11-03 21:58:50 --> Loader Class Initialized
INFO - 2019-11-03 21:58:50 --> Helper loaded: url_helper
INFO - 2019-11-03 21:58:50 --> Helper loaded: common_helper
INFO - 2019-11-03 21:58:50 --> Helper loaded: language_helper
INFO - 2019-11-03 21:58:50 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:58:50 --> Helper loaded: email_helper
INFO - 2019-11-03 21:58:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:58:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:58:50 --> Parser Class Initialized
INFO - 2019-11-03 21:58:50 --> User Agent Class Initialized
INFO - 2019-11-03 21:58:50 --> Model Class Initialized
INFO - 2019-11-03 21:58:50 --> Database Driver Class Initialized
INFO - 2019-11-03 21:58:50 --> Model Class Initialized
DEBUG - 2019-11-03 21:58:50 --> Template Class Initialized
INFO - 2019-11-03 21:58:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:58:50 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:58:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:58:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:58:50 --> Encryption Class Initialized
INFO - 2019-11-03 21:58:50 --> Controller Class Initialized
DEBUG - 2019-11-03 21:58:50 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 21:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 21:58:50 --> Model Class Initialized
INFO - 2019-11-03 21:58:50 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 21:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 21:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-03 21:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 21:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 21:58:50 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 21:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 21:58:50 --> Model Class Initialized
DEBUG - 2019-11-03 21:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 21:58:50 --> Model Class Initialized
DEBUG - 2019-11-03 21:58:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 21:58:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 21:58:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 21:58:51 --> Final output sent to browser
DEBUG - 2019-11-03 21:58:51 --> Total execution time: 0.6603
INFO - 2019-11-03 21:59:00 --> Config Class Initialized
INFO - 2019-11-03 21:59:00 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:59:00 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:59:01 --> Utf8 Class Initialized
INFO - 2019-11-03 21:59:01 --> URI Class Initialized
INFO - 2019-11-03 21:59:01 --> Router Class Initialized
INFO - 2019-11-03 21:59:01 --> Output Class Initialized
INFO - 2019-11-03 21:59:01 --> Security Class Initialized
DEBUG - 2019-11-03 21:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:59:01 --> CSRF cookie sent
INFO - 2019-11-03 21:59:01 --> CSRF token verified
INFO - 2019-11-03 21:59:01 --> Input Class Initialized
INFO - 2019-11-03 21:59:01 --> Language Class Initialized
INFO - 2019-11-03 21:59:01 --> Language Class Initialized
INFO - 2019-11-03 21:59:01 --> Config Class Initialized
INFO - 2019-11-03 21:59:01 --> Loader Class Initialized
INFO - 2019-11-03 21:59:01 --> Helper loaded: url_helper
INFO - 2019-11-03 21:59:01 --> Helper loaded: common_helper
INFO - 2019-11-03 21:59:01 --> Helper loaded: language_helper
INFO - 2019-11-03 21:59:01 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:59:01 --> Helper loaded: email_helper
INFO - 2019-11-03 21:59:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:59:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:59:01 --> Parser Class Initialized
INFO - 2019-11-03 21:59:01 --> User Agent Class Initialized
INFO - 2019-11-03 21:59:01 --> Model Class Initialized
INFO - 2019-11-03 21:59:01 --> Database Driver Class Initialized
INFO - 2019-11-03 21:59:01 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:01 --> Template Class Initialized
INFO - 2019-11-03 21:59:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:59:01 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:59:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:59:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:59:01 --> Encryption Class Initialized
INFO - 2019-11-03 21:59:01 --> Controller Class Initialized
DEBUG - 2019-11-03 21:59:01 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 21:59:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 21:59:01 --> Model Class Initialized
INFO - 2019-11-03 21:59:05 --> Config Class Initialized
INFO - 2019-11-03 21:59:05 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:59:05 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:59:05 --> Utf8 Class Initialized
INFO - 2019-11-03 21:59:05 --> URI Class Initialized
INFO - 2019-11-03 21:59:06 --> Router Class Initialized
INFO - 2019-11-03 21:59:06 --> Output Class Initialized
INFO - 2019-11-03 21:59:06 --> Security Class Initialized
DEBUG - 2019-11-03 21:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:59:06 --> CSRF cookie sent
INFO - 2019-11-03 21:59:06 --> Input Class Initialized
INFO - 2019-11-03 21:59:06 --> Language Class Initialized
INFO - 2019-11-03 21:59:06 --> Language Class Initialized
INFO - 2019-11-03 21:59:06 --> Config Class Initialized
INFO - 2019-11-03 21:59:06 --> Loader Class Initialized
INFO - 2019-11-03 21:59:06 --> Helper loaded: url_helper
INFO - 2019-11-03 21:59:06 --> Helper loaded: common_helper
INFO - 2019-11-03 21:59:06 --> Helper loaded: language_helper
INFO - 2019-11-03 21:59:06 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:59:06 --> Helper loaded: email_helper
INFO - 2019-11-03 21:59:06 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:59:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:59:06 --> Parser Class Initialized
INFO - 2019-11-03 21:59:06 --> User Agent Class Initialized
INFO - 2019-11-03 21:59:06 --> Model Class Initialized
INFO - 2019-11-03 21:59:06 --> Database Driver Class Initialized
INFO - 2019-11-03 21:59:06 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:06 --> Template Class Initialized
INFO - 2019-11-03 21:59:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:59:06 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:59:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:59:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:59:06 --> Encryption Class Initialized
INFO - 2019-11-03 21:59:06 --> Controller Class Initialized
DEBUG - 2019-11-03 21:59:06 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 21:59:06 --> Model Class Initialized
INFO - 2019-11-03 21:59:06 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 21:59:06 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 21:59:06 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 21:59:06 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 21:59:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 21:59:06 --> Final output sent to browser
DEBUG - 2019-11-03 21:59:06 --> Total execution time: 0.7799
INFO - 2019-11-03 21:59:09 --> Config Class Initialized
INFO - 2019-11-03 21:59:09 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:59:09 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:59:09 --> Utf8 Class Initialized
INFO - 2019-11-03 21:59:09 --> URI Class Initialized
DEBUG - 2019-11-03 21:59:09 --> No URI present. Default controller set.
INFO - 2019-11-03 21:59:09 --> Router Class Initialized
INFO - 2019-11-03 21:59:09 --> Output Class Initialized
INFO - 2019-11-03 21:59:09 --> Security Class Initialized
DEBUG - 2019-11-03 21:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:59:09 --> CSRF cookie sent
INFO - 2019-11-03 21:59:09 --> Input Class Initialized
INFO - 2019-11-03 21:59:09 --> Language Class Initialized
INFO - 2019-11-03 21:59:09 --> Language Class Initialized
INFO - 2019-11-03 21:59:09 --> Config Class Initialized
INFO - 2019-11-03 21:59:09 --> Loader Class Initialized
INFO - 2019-11-03 21:59:09 --> Helper loaded: url_helper
INFO - 2019-11-03 21:59:09 --> Helper loaded: common_helper
INFO - 2019-11-03 21:59:09 --> Helper loaded: language_helper
INFO - 2019-11-03 21:59:09 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:59:09 --> Helper loaded: email_helper
INFO - 2019-11-03 21:59:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:59:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:59:09 --> Parser Class Initialized
INFO - 2019-11-03 21:59:09 --> User Agent Class Initialized
INFO - 2019-11-03 21:59:09 --> Model Class Initialized
INFO - 2019-11-03 21:59:09 --> Database Driver Class Initialized
INFO - 2019-11-03 21:59:09 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:09 --> Template Class Initialized
INFO - 2019-11-03 21:59:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:59:09 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:59:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:59:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:59:09 --> Encryption Class Initialized
DEBUG - 2019-11-03 21:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-03 21:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-03 21:59:10 --> Controller Class Initialized
DEBUG - 2019-11-03 21:59:10 --> pergo MX_Controller Initialized
DEBUG - 2019-11-03 21:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-03 21:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-03 21:59:10 --> Model Class Initialized
INFO - 2019-11-03 21:59:10 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 21:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-03 21:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-03 21:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-03 21:59:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-03 21:59:10 --> Final output sent to browser
DEBUG - 2019-11-03 21:59:10 --> Total execution time: 1.0002
INFO - 2019-11-03 21:59:18 --> Config Class Initialized
INFO - 2019-11-03 21:59:18 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:59:18 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:59:19 --> Utf8 Class Initialized
INFO - 2019-11-03 21:59:19 --> URI Class Initialized
INFO - 2019-11-03 21:59:19 --> Router Class Initialized
INFO - 2019-11-03 21:59:19 --> Output Class Initialized
INFO - 2019-11-03 21:59:19 --> Security Class Initialized
DEBUG - 2019-11-03 21:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:59:19 --> CSRF cookie sent
INFO - 2019-11-03 21:59:19 --> Input Class Initialized
INFO - 2019-11-03 21:59:19 --> Language Class Initialized
INFO - 2019-11-03 21:59:19 --> Language Class Initialized
INFO - 2019-11-03 21:59:19 --> Config Class Initialized
INFO - 2019-11-03 21:59:19 --> Loader Class Initialized
INFO - 2019-11-03 21:59:19 --> Helper loaded: url_helper
INFO - 2019-11-03 21:59:19 --> Helper loaded: common_helper
INFO - 2019-11-03 21:59:19 --> Helper loaded: language_helper
INFO - 2019-11-03 21:59:19 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:59:19 --> Helper loaded: email_helper
INFO - 2019-11-03 21:59:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:59:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:59:19 --> Parser Class Initialized
INFO - 2019-11-03 21:59:19 --> User Agent Class Initialized
INFO - 2019-11-03 21:59:19 --> Model Class Initialized
INFO - 2019-11-03 21:59:19 --> Database Driver Class Initialized
INFO - 2019-11-03 21:59:19 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:19 --> Template Class Initialized
INFO - 2019-11-03 21:59:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:59:19 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:59:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:59:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:59:19 --> Encryption Class Initialized
INFO - 2019-11-03 21:59:19 --> Controller Class Initialized
DEBUG - 2019-11-03 21:59:19 --> package MX_Controller Initialized
DEBUG - 2019-11-03 21:59:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-03 21:59:19 --> Model Class Initialized
INFO - 2019-11-03 21:59:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 21:59:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 21:59:19 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 21:59:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 21:59:19 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 21:59:19 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-03 21:59:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-03 21:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 21:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 21:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 21:59:20 --> Final output sent to browser
DEBUG - 2019-11-03 21:59:20 --> Total execution time: 1.2421
INFO - 2019-11-03 21:59:34 --> Config Class Initialized
INFO - 2019-11-03 21:59:34 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:59:34 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:59:34 --> Utf8 Class Initialized
INFO - 2019-11-03 21:59:34 --> URI Class Initialized
INFO - 2019-11-03 21:59:34 --> Router Class Initialized
INFO - 2019-11-03 21:59:34 --> Output Class Initialized
INFO - 2019-11-03 21:59:34 --> Security Class Initialized
DEBUG - 2019-11-03 21:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:59:34 --> CSRF cookie sent
INFO - 2019-11-03 21:59:34 --> CSRF token verified
INFO - 2019-11-03 21:59:34 --> Input Class Initialized
INFO - 2019-11-03 21:59:34 --> Language Class Initialized
INFO - 2019-11-03 21:59:34 --> Language Class Initialized
INFO - 2019-11-03 21:59:34 --> Config Class Initialized
INFO - 2019-11-03 21:59:34 --> Loader Class Initialized
INFO - 2019-11-03 21:59:34 --> Helper loaded: url_helper
INFO - 2019-11-03 21:59:34 --> Helper loaded: common_helper
INFO - 2019-11-03 21:59:34 --> Helper loaded: language_helper
INFO - 2019-11-03 21:59:34 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:59:34 --> Helper loaded: email_helper
INFO - 2019-11-03 21:59:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:59:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:59:34 --> Parser Class Initialized
INFO - 2019-11-03 21:59:34 --> User Agent Class Initialized
INFO - 2019-11-03 21:59:34 --> Model Class Initialized
INFO - 2019-11-03 21:59:34 --> Database Driver Class Initialized
INFO - 2019-11-03 21:59:34 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:34 --> Template Class Initialized
INFO - 2019-11-03 21:59:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:59:34 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:59:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:59:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:59:34 --> Encryption Class Initialized
INFO - 2019-11-03 21:59:34 --> Controller Class Initialized
DEBUG - 2019-11-03 21:59:34 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 21:59:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 21:59:35 --> Model Class Initialized
INFO - 2019-11-03 21:59:35 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 21:59:35 --> Could not find the language line "dotpay"
DEBUG - 2019-11-03 21:59:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-03 21:59:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 21:59:35 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 21:59:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 21:59:35 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 21:59:35 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 21:59:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 21:59:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 21:59:35 --> Final output sent to browser
DEBUG - 2019-11-03 21:59:35 --> Total execution time: 0.8727
INFO - 2019-11-03 21:59:44 --> Config Class Initialized
INFO - 2019-11-03 21:59:44 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:59:44 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:59:44 --> Utf8 Class Initialized
INFO - 2019-11-03 21:59:45 --> URI Class Initialized
INFO - 2019-11-03 21:59:45 --> Router Class Initialized
INFO - 2019-11-03 21:59:45 --> Output Class Initialized
INFO - 2019-11-03 21:59:45 --> Security Class Initialized
DEBUG - 2019-11-03 21:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:59:45 --> CSRF cookie sent
INFO - 2019-11-03 21:59:45 --> CSRF token verified
INFO - 2019-11-03 21:59:45 --> Input Class Initialized
INFO - 2019-11-03 21:59:45 --> Language Class Initialized
INFO - 2019-11-03 21:59:45 --> Language Class Initialized
INFO - 2019-11-03 21:59:45 --> Config Class Initialized
INFO - 2019-11-03 21:59:45 --> Loader Class Initialized
INFO - 2019-11-03 21:59:45 --> Helper loaded: url_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: common_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: language_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: email_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:59:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:59:45 --> Parser Class Initialized
INFO - 2019-11-03 21:59:45 --> User Agent Class Initialized
INFO - 2019-11-03 21:59:45 --> Model Class Initialized
INFO - 2019-11-03 21:59:45 --> Database Driver Class Initialized
INFO - 2019-11-03 21:59:45 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:45 --> Template Class Initialized
INFO - 2019-11-03 21:59:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:59:45 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:59:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:59:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:59:45 --> Encryption Class Initialized
INFO - 2019-11-03 21:59:45 --> Controller Class Initialized
DEBUG - 2019-11-03 21:59:45 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 21:59:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 21:59:45 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 21:59:45 --> Final output sent to browser
DEBUG - 2019-11-03 21:59:45 --> Total execution time: 0.4800
INFO - 2019-11-03 21:59:45 --> Config Class Initialized
INFO - 2019-11-03 21:59:45 --> Hooks Class Initialized
DEBUG - 2019-11-03 21:59:45 --> UTF-8 Support Enabled
INFO - 2019-11-03 21:59:45 --> Utf8 Class Initialized
INFO - 2019-11-03 21:59:45 --> URI Class Initialized
INFO - 2019-11-03 21:59:45 --> Router Class Initialized
INFO - 2019-11-03 21:59:45 --> Output Class Initialized
INFO - 2019-11-03 21:59:45 --> Security Class Initialized
DEBUG - 2019-11-03 21:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 21:59:45 --> Input Class Initialized
INFO - 2019-11-03 21:59:45 --> Language Class Initialized
INFO - 2019-11-03 21:59:45 --> Language Class Initialized
INFO - 2019-11-03 21:59:45 --> Config Class Initialized
INFO - 2019-11-03 21:59:45 --> Loader Class Initialized
INFO - 2019-11-03 21:59:45 --> Helper loaded: url_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: common_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: language_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: cookie_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: email_helper
INFO - 2019-11-03 21:59:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 21:59:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 21:59:45 --> Parser Class Initialized
INFO - 2019-11-03 21:59:45 --> User Agent Class Initialized
INFO - 2019-11-03 21:59:45 --> Model Class Initialized
INFO - 2019-11-03 21:59:45 --> Database Driver Class Initialized
INFO - 2019-11-03 21:59:45 --> Model Class Initialized
DEBUG - 2019-11-03 21:59:45 --> Template Class Initialized
INFO - 2019-11-03 21:59:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 21:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 21:59:45 --> Pagination Class Initialized
DEBUG - 2019-11-03 21:59:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 21:59:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 21:59:46 --> Encryption Class Initialized
INFO - 2019-11-03 21:59:46 --> Controller Class Initialized
DEBUG - 2019-11-03 21:59:46 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 21:59:46 --> Model Class Initialized
INFO - 2019-11-03 21:59:46 --> Final output sent to browser
DEBUG - 2019-11-03 21:59:46 --> Total execution time: 0.5595
INFO - 2019-11-03 22:00:04 --> Config Class Initialized
INFO - 2019-11-03 22:00:04 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:00:04 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:00:04 --> Utf8 Class Initialized
INFO - 2019-11-03 22:00:04 --> URI Class Initialized
INFO - 2019-11-03 22:00:04 --> Router Class Initialized
INFO - 2019-11-03 22:00:04 --> Output Class Initialized
INFO - 2019-11-03 22:00:04 --> Security Class Initialized
DEBUG - 2019-11-03 22:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:00:04 --> Input Class Initialized
INFO - 2019-11-03 22:00:04 --> Language Class Initialized
INFO - 2019-11-03 22:00:04 --> Language Class Initialized
INFO - 2019-11-03 22:00:04 --> Config Class Initialized
INFO - 2019-11-03 22:00:04 --> Loader Class Initialized
INFO - 2019-11-03 22:00:04 --> Helper loaded: url_helper
INFO - 2019-11-03 22:00:04 --> Helper loaded: common_helper
INFO - 2019-11-03 22:00:04 --> Helper loaded: language_helper
INFO - 2019-11-03 22:00:04 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:00:04 --> Helper loaded: email_helper
INFO - 2019-11-03 22:00:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:00:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:00:04 --> Parser Class Initialized
INFO - 2019-11-03 22:00:04 --> User Agent Class Initialized
INFO - 2019-11-03 22:00:04 --> Model Class Initialized
INFO - 2019-11-03 22:00:04 --> Database Driver Class Initialized
INFO - 2019-11-03 22:00:04 --> Model Class Initialized
DEBUG - 2019-11-03 22:00:04 --> Template Class Initialized
INFO - 2019-11-03 22:00:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:00:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:00:04 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:00:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:00:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:00:04 --> Encryption Class Initialized
INFO - 2019-11-03 22:00:04 --> Controller Class Initialized
DEBUG - 2019-11-03 22:00:04 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:00:04 --> Model Class Initialized
INFO - 2019-11-03 22:02:33 --> Config Class Initialized
INFO - 2019-11-03 22:02:33 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:02:33 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:02:33 --> Utf8 Class Initialized
INFO - 2019-11-03 22:02:33 --> URI Class Initialized
INFO - 2019-11-03 22:02:33 --> Router Class Initialized
INFO - 2019-11-03 22:02:33 --> Output Class Initialized
INFO - 2019-11-03 22:02:33 --> Security Class Initialized
DEBUG - 2019-11-03 22:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:02:33 --> Input Class Initialized
INFO - 2019-11-03 22:02:33 --> Language Class Initialized
INFO - 2019-11-03 22:02:33 --> Language Class Initialized
INFO - 2019-11-03 22:02:33 --> Config Class Initialized
INFO - 2019-11-03 22:02:33 --> Loader Class Initialized
INFO - 2019-11-03 22:02:33 --> Helper loaded: url_helper
INFO - 2019-11-03 22:02:33 --> Helper loaded: common_helper
INFO - 2019-11-03 22:02:33 --> Helper loaded: language_helper
INFO - 2019-11-03 22:02:33 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:02:33 --> Helper loaded: email_helper
INFO - 2019-11-03 22:02:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:02:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:02:33 --> Parser Class Initialized
INFO - 2019-11-03 22:02:33 --> User Agent Class Initialized
INFO - 2019-11-03 22:02:33 --> Model Class Initialized
INFO - 2019-11-03 22:02:33 --> Database Driver Class Initialized
INFO - 2019-11-03 22:02:33 --> Model Class Initialized
DEBUG - 2019-11-03 22:02:33 --> Template Class Initialized
INFO - 2019-11-03 22:02:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:02:33 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:02:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:02:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:02:33 --> Encryption Class Initialized
INFO - 2019-11-03 22:02:33 --> Controller Class Initialized
DEBUG - 2019-11-03 22:02:33 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:02:33 --> Model Class Initialized
INFO - 2019-11-03 22:02:33 --> Final output sent to browser
DEBUG - 2019-11-03 22:02:33 --> Total execution time: 0.5032
INFO - 2019-11-03 22:02:42 --> Config Class Initialized
INFO - 2019-11-03 22:02:42 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:02:42 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:02:42 --> Utf8 Class Initialized
INFO - 2019-11-03 22:02:42 --> URI Class Initialized
INFO - 2019-11-03 22:02:42 --> Router Class Initialized
INFO - 2019-11-03 22:02:42 --> Output Class Initialized
INFO - 2019-11-03 22:02:42 --> Security Class Initialized
DEBUG - 2019-11-03 22:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:02:42 --> CSRF cookie sent
INFO - 2019-11-03 22:02:42 --> CSRF token verified
INFO - 2019-11-03 22:02:42 --> Input Class Initialized
INFO - 2019-11-03 22:02:42 --> Language Class Initialized
INFO - 2019-11-03 22:02:42 --> Language Class Initialized
INFO - 2019-11-03 22:02:42 --> Config Class Initialized
INFO - 2019-11-03 22:02:42 --> Loader Class Initialized
INFO - 2019-11-03 22:02:42 --> Helper loaded: url_helper
INFO - 2019-11-03 22:02:42 --> Helper loaded: common_helper
INFO - 2019-11-03 22:02:42 --> Helper loaded: language_helper
INFO - 2019-11-03 22:02:42 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:02:42 --> Helper loaded: email_helper
INFO - 2019-11-03 22:02:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:02:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:02:42 --> Parser Class Initialized
INFO - 2019-11-03 22:02:42 --> User Agent Class Initialized
INFO - 2019-11-03 22:02:42 --> Model Class Initialized
INFO - 2019-11-03 22:02:42 --> Database Driver Class Initialized
INFO - 2019-11-03 22:02:42 --> Model Class Initialized
DEBUG - 2019-11-03 22:02:42 --> Template Class Initialized
INFO - 2019-11-03 22:02:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:02:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:02:42 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:02:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:02:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:02:43 --> Encryption Class Initialized
INFO - 2019-11-03 22:02:43 --> Controller Class Initialized
DEBUG - 2019-11-03 22:02:43 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:02:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:02:43 --> Model Class Initialized
INFO - 2019-11-03 22:02:43 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 22:02:43 --> Could not find the language line "dotpay"
DEBUG - 2019-11-03 22:02:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-03 22:02:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:02:43 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:02:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:02:43 --> Model Class Initialized
DEBUG - 2019-11-03 22:02:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:02:43 --> Model Class Initialized
DEBUG - 2019-11-03 22:02:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 22:02:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 22:02:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 22:02:43 --> Final output sent to browser
DEBUG - 2019-11-03 22:02:43 --> Total execution time: 0.8518
INFO - 2019-11-03 22:02:57 --> Config Class Initialized
INFO - 2019-11-03 22:02:57 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:02:57 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:02:57 --> Utf8 Class Initialized
INFO - 2019-11-03 22:02:57 --> URI Class Initialized
INFO - 2019-11-03 22:02:57 --> Router Class Initialized
INFO - 2019-11-03 22:02:57 --> Output Class Initialized
INFO - 2019-11-03 22:02:57 --> Security Class Initialized
DEBUG - 2019-11-03 22:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:02:57 --> CSRF cookie sent
INFO - 2019-11-03 22:02:57 --> CSRF token verified
INFO - 2019-11-03 22:02:57 --> Input Class Initialized
INFO - 2019-11-03 22:02:57 --> Language Class Initialized
INFO - 2019-11-03 22:02:57 --> Language Class Initialized
INFO - 2019-11-03 22:02:57 --> Config Class Initialized
INFO - 2019-11-03 22:02:57 --> Loader Class Initialized
INFO - 2019-11-03 22:02:57 --> Helper loaded: url_helper
INFO - 2019-11-03 22:02:57 --> Helper loaded: common_helper
INFO - 2019-11-03 22:02:57 --> Helper loaded: language_helper
INFO - 2019-11-03 22:02:57 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:02:57 --> Helper loaded: email_helper
INFO - 2019-11-03 22:02:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:02:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:02:57 --> Parser Class Initialized
INFO - 2019-11-03 22:02:57 --> User Agent Class Initialized
INFO - 2019-11-03 22:02:57 --> Model Class Initialized
INFO - 2019-11-03 22:02:57 --> Database Driver Class Initialized
INFO - 2019-11-03 22:02:57 --> Model Class Initialized
DEBUG - 2019-11-03 22:02:57 --> Template Class Initialized
INFO - 2019-11-03 22:02:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:02:57 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:02:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:02:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:02:57 --> Encryption Class Initialized
INFO - 2019-11-03 22:02:57 --> Controller Class Initialized
DEBUG - 2019-11-03 22:02:57 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:02:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:02:57 --> Model Class Initialized
DEBUG - 2019-11-03 22:02:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 22:02:57 --> Final output sent to browser
DEBUG - 2019-11-03 22:02:57 --> Total execution time: 0.4486
INFO - 2019-11-03 22:02:57 --> Config Class Initialized
INFO - 2019-11-03 22:02:57 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:02:57 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:02:57 --> Utf8 Class Initialized
INFO - 2019-11-03 22:02:58 --> URI Class Initialized
INFO - 2019-11-03 22:02:58 --> Router Class Initialized
INFO - 2019-11-03 22:02:58 --> Output Class Initialized
INFO - 2019-11-03 22:02:58 --> Security Class Initialized
DEBUG - 2019-11-03 22:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:02:58 --> Input Class Initialized
INFO - 2019-11-03 22:02:58 --> Language Class Initialized
INFO - 2019-11-03 22:02:58 --> Language Class Initialized
INFO - 2019-11-03 22:02:58 --> Config Class Initialized
INFO - 2019-11-03 22:02:58 --> Loader Class Initialized
INFO - 2019-11-03 22:02:58 --> Helper loaded: url_helper
INFO - 2019-11-03 22:02:58 --> Helper loaded: common_helper
INFO - 2019-11-03 22:02:58 --> Helper loaded: language_helper
INFO - 2019-11-03 22:02:58 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:02:58 --> Helper loaded: email_helper
INFO - 2019-11-03 22:02:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:02:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:02:58 --> Parser Class Initialized
INFO - 2019-11-03 22:02:58 --> User Agent Class Initialized
INFO - 2019-11-03 22:02:58 --> Model Class Initialized
INFO - 2019-11-03 22:02:58 --> Database Driver Class Initialized
INFO - 2019-11-03 22:02:58 --> Model Class Initialized
DEBUG - 2019-11-03 22:02:58 --> Template Class Initialized
INFO - 2019-11-03 22:02:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:02:58 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:02:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:02:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:02:58 --> Encryption Class Initialized
INFO - 2019-11-03 22:02:58 --> Controller Class Initialized
DEBUG - 2019-11-03 22:02:58 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:02:58 --> Model Class Initialized
INFO - 2019-11-03 22:02:58 --> Final output sent to browser
DEBUG - 2019-11-03 22:02:58 --> Total execution time: 0.4360
INFO - 2019-11-03 22:05:08 --> Config Class Initialized
INFO - 2019-11-03 22:05:09 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:05:09 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:05:09 --> Utf8 Class Initialized
INFO - 2019-11-03 22:05:09 --> URI Class Initialized
INFO - 2019-11-03 22:05:09 --> Router Class Initialized
INFO - 2019-11-03 22:05:09 --> Output Class Initialized
INFO - 2019-11-03 22:05:09 --> Security Class Initialized
DEBUG - 2019-11-03 22:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:05:09 --> Input Class Initialized
INFO - 2019-11-03 22:05:09 --> Language Class Initialized
INFO - 2019-11-03 22:05:09 --> Language Class Initialized
INFO - 2019-11-03 22:05:09 --> Config Class Initialized
INFO - 2019-11-03 22:05:09 --> Loader Class Initialized
INFO - 2019-11-03 22:05:09 --> Helper loaded: url_helper
INFO - 2019-11-03 22:05:09 --> Helper loaded: common_helper
INFO - 2019-11-03 22:05:09 --> Helper loaded: language_helper
INFO - 2019-11-03 22:05:09 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:05:09 --> Helper loaded: email_helper
INFO - 2019-11-03 22:05:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:05:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:05:09 --> Parser Class Initialized
INFO - 2019-11-03 22:05:09 --> User Agent Class Initialized
INFO - 2019-11-03 22:05:09 --> Model Class Initialized
INFO - 2019-11-03 22:05:09 --> Database Driver Class Initialized
INFO - 2019-11-03 22:05:09 --> Model Class Initialized
DEBUG - 2019-11-03 22:05:09 --> Template Class Initialized
INFO - 2019-11-03 22:05:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:05:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:05:09 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:05:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:05:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:05:09 --> Encryption Class Initialized
INFO - 2019-11-03 22:05:09 --> Controller Class Initialized
DEBUG - 2019-11-03 22:05:09 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:05:09 --> Model Class Initialized
INFO - 2019-11-03 22:05:09 --> Final output sent to browser
DEBUG - 2019-11-03 22:05:09 --> Total execution time: 0.5226
INFO - 2019-11-03 22:06:00 --> Config Class Initialized
INFO - 2019-11-03 22:06:00 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:06:00 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:06:00 --> Utf8 Class Initialized
INFO - 2019-11-03 22:06:00 --> URI Class Initialized
INFO - 2019-11-03 22:06:00 --> Router Class Initialized
INFO - 2019-11-03 22:06:00 --> Output Class Initialized
INFO - 2019-11-03 22:06:00 --> Security Class Initialized
DEBUG - 2019-11-03 22:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:06:00 --> CSRF cookie sent
INFO - 2019-11-03 22:06:00 --> CSRF token verified
INFO - 2019-11-03 22:06:00 --> Input Class Initialized
INFO - 2019-11-03 22:06:00 --> Language Class Initialized
INFO - 2019-11-03 22:06:00 --> Language Class Initialized
INFO - 2019-11-03 22:06:00 --> Config Class Initialized
INFO - 2019-11-03 22:06:00 --> Loader Class Initialized
INFO - 2019-11-03 22:06:00 --> Helper loaded: url_helper
INFO - 2019-11-03 22:06:00 --> Helper loaded: common_helper
INFO - 2019-11-03 22:06:00 --> Helper loaded: language_helper
INFO - 2019-11-03 22:06:00 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:06:00 --> Helper loaded: email_helper
INFO - 2019-11-03 22:06:00 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:06:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:06:00 --> Parser Class Initialized
INFO - 2019-11-03 22:06:00 --> User Agent Class Initialized
INFO - 2019-11-03 22:06:00 --> Model Class Initialized
INFO - 2019-11-03 22:06:00 --> Database Driver Class Initialized
INFO - 2019-11-03 22:06:00 --> Model Class Initialized
DEBUG - 2019-11-03 22:06:00 --> Template Class Initialized
INFO - 2019-11-03 22:06:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:06:00 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:06:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:06:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:06:01 --> Encryption Class Initialized
INFO - 2019-11-03 22:06:01 --> Controller Class Initialized
DEBUG - 2019-11-03 22:06:01 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:06:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:06:01 --> Model Class Initialized
DEBUG - 2019-11-03 22:06:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 22:06:01 --> Final output sent to browser
DEBUG - 2019-11-03 22:06:01 --> Total execution time: 0.4504
INFO - 2019-11-03 22:06:01 --> Config Class Initialized
INFO - 2019-11-03 22:06:01 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:06:01 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:06:01 --> Utf8 Class Initialized
INFO - 2019-11-03 22:06:01 --> URI Class Initialized
INFO - 2019-11-03 22:06:01 --> Router Class Initialized
INFO - 2019-11-03 22:06:01 --> Output Class Initialized
INFO - 2019-11-03 22:06:01 --> Security Class Initialized
DEBUG - 2019-11-03 22:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:06:01 --> Input Class Initialized
INFO - 2019-11-03 22:06:01 --> Language Class Initialized
INFO - 2019-11-03 22:06:01 --> Language Class Initialized
INFO - 2019-11-03 22:06:01 --> Config Class Initialized
INFO - 2019-11-03 22:06:01 --> Loader Class Initialized
INFO - 2019-11-03 22:06:01 --> Helper loaded: url_helper
INFO - 2019-11-03 22:06:01 --> Helper loaded: common_helper
INFO - 2019-11-03 22:06:01 --> Helper loaded: language_helper
INFO - 2019-11-03 22:06:01 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:06:01 --> Helper loaded: email_helper
INFO - 2019-11-03 22:06:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:06:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:06:01 --> Parser Class Initialized
INFO - 2019-11-03 22:06:01 --> User Agent Class Initialized
INFO - 2019-11-03 22:06:01 --> Model Class Initialized
INFO - 2019-11-03 22:06:01 --> Database Driver Class Initialized
INFO - 2019-11-03 22:06:01 --> Model Class Initialized
DEBUG - 2019-11-03 22:06:01 --> Template Class Initialized
INFO - 2019-11-03 22:06:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:06:01 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:06:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:06:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:06:01 --> Encryption Class Initialized
INFO - 2019-11-03 22:06:01 --> Controller Class Initialized
DEBUG - 2019-11-03 22:06:01 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:06:01 --> Model Class Initialized
INFO - 2019-11-03 22:06:01 --> Final output sent to browser
DEBUG - 2019-11-03 22:06:01 --> Total execution time: 0.4678
INFO - 2019-11-03 22:06:42 --> Config Class Initialized
INFO - 2019-11-03 22:06:42 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:06:42 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:06:42 --> Utf8 Class Initialized
INFO - 2019-11-03 22:06:42 --> URI Class Initialized
INFO - 2019-11-03 22:06:42 --> Router Class Initialized
INFO - 2019-11-03 22:06:42 --> Output Class Initialized
INFO - 2019-11-03 22:06:42 --> Security Class Initialized
DEBUG - 2019-11-03 22:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:06:42 --> Input Class Initialized
INFO - 2019-11-03 22:06:42 --> Language Class Initialized
INFO - 2019-11-03 22:06:42 --> Language Class Initialized
INFO - 2019-11-03 22:06:42 --> Config Class Initialized
INFO - 2019-11-03 22:06:42 --> Loader Class Initialized
INFO - 2019-11-03 22:06:42 --> Helper loaded: url_helper
INFO - 2019-11-03 22:06:42 --> Helper loaded: common_helper
INFO - 2019-11-03 22:06:42 --> Helper loaded: language_helper
INFO - 2019-11-03 22:06:42 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:06:42 --> Helper loaded: email_helper
INFO - 2019-11-03 22:06:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:06:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:06:42 --> Parser Class Initialized
INFO - 2019-11-03 22:06:42 --> User Agent Class Initialized
INFO - 2019-11-03 22:06:42 --> Model Class Initialized
INFO - 2019-11-03 22:06:42 --> Database Driver Class Initialized
INFO - 2019-11-03 22:06:42 --> Model Class Initialized
DEBUG - 2019-11-03 22:06:42 --> Template Class Initialized
INFO - 2019-11-03 22:06:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:06:42 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:06:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:06:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:06:42 --> Encryption Class Initialized
INFO - 2019-11-03 22:06:42 --> Controller Class Initialized
DEBUG - 2019-11-03 22:06:42 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:06:42 --> Model Class Initialized
INFO - 2019-11-03 22:14:19 --> Config Class Initialized
INFO - 2019-11-03 22:14:19 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:14:19 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:14:19 --> Utf8 Class Initialized
INFO - 2019-11-03 22:14:19 --> URI Class Initialized
INFO - 2019-11-03 22:14:19 --> Router Class Initialized
INFO - 2019-11-03 22:14:20 --> Output Class Initialized
INFO - 2019-11-03 22:14:20 --> Security Class Initialized
DEBUG - 2019-11-03 22:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:14:20 --> Input Class Initialized
INFO - 2019-11-03 22:14:20 --> Language Class Initialized
INFO - 2019-11-03 22:14:20 --> Language Class Initialized
INFO - 2019-11-03 22:14:20 --> Config Class Initialized
INFO - 2019-11-03 22:14:20 --> Loader Class Initialized
INFO - 2019-11-03 22:14:20 --> Helper loaded: url_helper
INFO - 2019-11-03 22:14:20 --> Helper loaded: common_helper
INFO - 2019-11-03 22:14:20 --> Helper loaded: language_helper
INFO - 2019-11-03 22:14:20 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:14:20 --> Helper loaded: email_helper
INFO - 2019-11-03 22:14:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:14:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:14:20 --> Parser Class Initialized
INFO - 2019-11-03 22:14:20 --> User Agent Class Initialized
INFO - 2019-11-03 22:14:20 --> Model Class Initialized
INFO - 2019-11-03 22:14:20 --> Database Driver Class Initialized
INFO - 2019-11-03 22:14:20 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:20 --> Template Class Initialized
INFO - 2019-11-03 22:14:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:14:20 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:14:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:14:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:14:20 --> Encryption Class Initialized
INFO - 2019-11-03 22:14:20 --> Controller Class Initialized
DEBUG - 2019-11-03 22:14:20 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:14:20 --> Model Class Initialized
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Undefined variable: attributes D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 6
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 6
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Undefined variable: attributes D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 7
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 7
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Undefined variable: attributes D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 8
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 8
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Undefined variable: attributes D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 9
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 9
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Undefined variable: attributes D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 10
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 10
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Undefined variable: attributes D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 11
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 11
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Undefined variable: attributes D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 12
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 12
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Undefined variable: attributes D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 13
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 13
ERROR - 2019-11-03 22:14:20 --> Severity: Notice --> Undefined variable: signature D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\cardinity\cardinity_form.php 14
DEBUG - 2019-11-03 22:14:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/cardinity_form.php
INFO - 2019-11-03 22:14:20 --> Final output sent to browser
DEBUG - 2019-11-03 22:14:20 --> Total execution time: 0.6476
INFO - 2019-11-03 22:14:43 --> Config Class Initialized
INFO - 2019-11-03 22:14:43 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:14:43 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:14:43 --> Utf8 Class Initialized
INFO - 2019-11-03 22:14:43 --> URI Class Initialized
INFO - 2019-11-03 22:14:43 --> Router Class Initialized
INFO - 2019-11-03 22:14:43 --> Output Class Initialized
INFO - 2019-11-03 22:14:43 --> Security Class Initialized
DEBUG - 2019-11-03 22:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:14:43 --> CSRF cookie sent
INFO - 2019-11-03 22:14:43 --> Input Class Initialized
INFO - 2019-11-03 22:14:43 --> Language Class Initialized
INFO - 2019-11-03 22:14:43 --> Language Class Initialized
INFO - 2019-11-03 22:14:43 --> Config Class Initialized
INFO - 2019-11-03 22:14:43 --> Loader Class Initialized
INFO - 2019-11-03 22:14:43 --> Helper loaded: url_helper
INFO - 2019-11-03 22:14:43 --> Helper loaded: common_helper
INFO - 2019-11-03 22:14:43 --> Helper loaded: language_helper
INFO - 2019-11-03 22:14:43 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:14:43 --> Helper loaded: email_helper
INFO - 2019-11-03 22:14:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:14:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:14:43 --> Parser Class Initialized
INFO - 2019-11-03 22:14:43 --> User Agent Class Initialized
INFO - 2019-11-03 22:14:43 --> Model Class Initialized
INFO - 2019-11-03 22:14:43 --> Database Driver Class Initialized
INFO - 2019-11-03 22:14:43 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:43 --> Template Class Initialized
INFO - 2019-11-03 22:14:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:14:43 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:14:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:14:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:14:43 --> Encryption Class Initialized
INFO - 2019-11-03 22:14:43 --> Controller Class Initialized
DEBUG - 2019-11-03 22:14:43 --> package MX_Controller Initialized
DEBUG - 2019-11-03 22:14:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-03 22:14:43 --> Model Class Initialized
INFO - 2019-11-03 22:14:43 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:14:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:14:43 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:14:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:14:43 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:14:43 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-03 22:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-03 22:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 22:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 22:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 22:14:44 --> Final output sent to browser
DEBUG - 2019-11-03 22:14:44 --> Total execution time: 0.8219
INFO - 2019-11-03 22:14:46 --> Config Class Initialized
INFO - 2019-11-03 22:14:46 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:14:46 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:14:46 --> Utf8 Class Initialized
INFO - 2019-11-03 22:14:46 --> URI Class Initialized
INFO - 2019-11-03 22:14:46 --> Router Class Initialized
INFO - 2019-11-03 22:14:46 --> Output Class Initialized
INFO - 2019-11-03 22:14:46 --> Security Class Initialized
DEBUG - 2019-11-03 22:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:14:46 --> CSRF cookie sent
INFO - 2019-11-03 22:14:46 --> CSRF token verified
INFO - 2019-11-03 22:14:46 --> Input Class Initialized
INFO - 2019-11-03 22:14:47 --> Language Class Initialized
INFO - 2019-11-03 22:14:47 --> Language Class Initialized
INFO - 2019-11-03 22:14:47 --> Config Class Initialized
INFO - 2019-11-03 22:14:47 --> Loader Class Initialized
INFO - 2019-11-03 22:14:47 --> Helper loaded: url_helper
INFO - 2019-11-03 22:14:47 --> Helper loaded: common_helper
INFO - 2019-11-03 22:14:47 --> Helper loaded: language_helper
INFO - 2019-11-03 22:14:47 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:14:47 --> Helper loaded: email_helper
INFO - 2019-11-03 22:14:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:14:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:14:47 --> Parser Class Initialized
INFO - 2019-11-03 22:14:47 --> User Agent Class Initialized
INFO - 2019-11-03 22:14:47 --> Model Class Initialized
INFO - 2019-11-03 22:14:47 --> Database Driver Class Initialized
INFO - 2019-11-03 22:14:47 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:47 --> Template Class Initialized
INFO - 2019-11-03 22:14:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:14:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:14:47 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:14:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:14:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:14:47 --> Encryption Class Initialized
INFO - 2019-11-03 22:14:47 --> Controller Class Initialized
DEBUG - 2019-11-03 22:14:47 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:14:47 --> Model Class Initialized
INFO - 2019-11-03 22:14:47 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 22:14:47 --> Could not find the language line "dotpay"
DEBUG - 2019-11-03 22:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-03 22:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:14:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:14:47 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:14:47 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 22:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 22:14:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 22:14:47 --> Final output sent to browser
DEBUG - 2019-11-03 22:14:47 --> Total execution time: 0.7482
INFO - 2019-11-03 22:14:53 --> Config Class Initialized
INFO - 2019-11-03 22:14:53 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:14:53 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:14:53 --> Utf8 Class Initialized
INFO - 2019-11-03 22:14:53 --> URI Class Initialized
INFO - 2019-11-03 22:14:53 --> Router Class Initialized
INFO - 2019-11-03 22:14:53 --> Output Class Initialized
INFO - 2019-11-03 22:14:53 --> Security Class Initialized
DEBUG - 2019-11-03 22:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:14:53 --> CSRF cookie sent
INFO - 2019-11-03 22:14:53 --> CSRF token verified
INFO - 2019-11-03 22:14:53 --> Input Class Initialized
INFO - 2019-11-03 22:14:53 --> Language Class Initialized
INFO - 2019-11-03 22:14:53 --> Language Class Initialized
INFO - 2019-11-03 22:14:53 --> Config Class Initialized
INFO - 2019-11-03 22:14:53 --> Loader Class Initialized
INFO - 2019-11-03 22:14:53 --> Helper loaded: url_helper
INFO - 2019-11-03 22:14:53 --> Helper loaded: common_helper
INFO - 2019-11-03 22:14:53 --> Helper loaded: language_helper
INFO - 2019-11-03 22:14:53 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:14:53 --> Helper loaded: email_helper
INFO - 2019-11-03 22:14:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:14:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:14:53 --> Parser Class Initialized
INFO - 2019-11-03 22:14:53 --> User Agent Class Initialized
INFO - 2019-11-03 22:14:53 --> Model Class Initialized
INFO - 2019-11-03 22:14:53 --> Database Driver Class Initialized
INFO - 2019-11-03 22:14:53 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:53 --> Template Class Initialized
INFO - 2019-11-03 22:14:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:14:53 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:14:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:14:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:14:53 --> Encryption Class Initialized
INFO - 2019-11-03 22:14:53 --> Controller Class Initialized
DEBUG - 2019-11-03 22:14:54 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:14:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:14:54 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 22:14:54 --> Final output sent to browser
DEBUG - 2019-11-03 22:14:54 --> Total execution time: 0.4877
INFO - 2019-11-03 22:14:54 --> Config Class Initialized
INFO - 2019-11-03 22:14:54 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:14:54 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:14:54 --> Utf8 Class Initialized
INFO - 2019-11-03 22:14:54 --> URI Class Initialized
INFO - 2019-11-03 22:14:54 --> Router Class Initialized
INFO - 2019-11-03 22:14:54 --> Output Class Initialized
INFO - 2019-11-03 22:14:54 --> Security Class Initialized
DEBUG - 2019-11-03 22:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:14:54 --> Input Class Initialized
INFO - 2019-11-03 22:14:54 --> Language Class Initialized
INFO - 2019-11-03 22:14:54 --> Language Class Initialized
INFO - 2019-11-03 22:14:54 --> Config Class Initialized
INFO - 2019-11-03 22:14:54 --> Loader Class Initialized
INFO - 2019-11-03 22:14:54 --> Helper loaded: url_helper
INFO - 2019-11-03 22:14:54 --> Helper loaded: common_helper
INFO - 2019-11-03 22:14:54 --> Helper loaded: language_helper
INFO - 2019-11-03 22:14:54 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:14:54 --> Helper loaded: email_helper
INFO - 2019-11-03 22:14:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:14:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:14:54 --> Parser Class Initialized
INFO - 2019-11-03 22:14:54 --> User Agent Class Initialized
INFO - 2019-11-03 22:14:54 --> Model Class Initialized
INFO - 2019-11-03 22:14:54 --> Database Driver Class Initialized
INFO - 2019-11-03 22:14:54 --> Model Class Initialized
DEBUG - 2019-11-03 22:14:54 --> Template Class Initialized
INFO - 2019-11-03 22:14:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:14:54 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:14:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:14:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:14:54 --> Encryption Class Initialized
INFO - 2019-11-03 22:14:54 --> Controller Class Initialized
DEBUG - 2019-11-03 22:14:54 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:14:54 --> Model Class Initialized
ERROR - 2019-11-03 22:14:54 --> Severity: Notice --> Undefined variable: form_html D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\dotpay\dotpay_form.php 4
DEBUG - 2019-11-03 22:14:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 22:14:54 --> Final output sent to browser
DEBUG - 2019-11-03 22:14:54 --> Total execution time: 0.5067
INFO - 2019-11-03 22:15:13 --> Config Class Initialized
INFO - 2019-11-03 22:15:13 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:15:13 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:15:13 --> Utf8 Class Initialized
INFO - 2019-11-03 22:15:13 --> URI Class Initialized
INFO - 2019-11-03 22:15:13 --> Router Class Initialized
INFO - 2019-11-03 22:15:13 --> Output Class Initialized
INFO - 2019-11-03 22:15:13 --> Security Class Initialized
DEBUG - 2019-11-03 22:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:15:13 --> Input Class Initialized
INFO - 2019-11-03 22:15:13 --> Language Class Initialized
INFO - 2019-11-03 22:15:13 --> Language Class Initialized
INFO - 2019-11-03 22:15:13 --> Config Class Initialized
INFO - 2019-11-03 22:15:13 --> Loader Class Initialized
INFO - 2019-11-03 22:15:13 --> Helper loaded: url_helper
INFO - 2019-11-03 22:15:13 --> Helper loaded: common_helper
INFO - 2019-11-03 22:15:13 --> Helper loaded: language_helper
INFO - 2019-11-03 22:15:13 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:15:13 --> Helper loaded: email_helper
INFO - 2019-11-03 22:15:13 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:15:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:15:13 --> Parser Class Initialized
INFO - 2019-11-03 22:15:13 --> User Agent Class Initialized
INFO - 2019-11-03 22:15:13 --> Model Class Initialized
INFO - 2019-11-03 22:15:13 --> Database Driver Class Initialized
INFO - 2019-11-03 22:15:13 --> Model Class Initialized
DEBUG - 2019-11-03 22:15:13 --> Template Class Initialized
INFO - 2019-11-03 22:15:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:15:14 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:15:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:15:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:15:14 --> Encryption Class Initialized
INFO - 2019-11-03 22:15:14 --> Controller Class Initialized
DEBUG - 2019-11-03 22:15:14 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:15:14 --> Model Class Initialized
DEBUG - 2019-11-03 22:15:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 22:15:14 --> Final output sent to browser
DEBUG - 2019-11-03 22:15:14 --> Total execution time: 0.4727
INFO - 2019-11-03 22:15:28 --> Config Class Initialized
INFO - 2019-11-03 22:15:28 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:15:28 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:15:28 --> Utf8 Class Initialized
INFO - 2019-11-03 22:15:28 --> URI Class Initialized
INFO - 2019-11-03 22:15:28 --> Router Class Initialized
INFO - 2019-11-03 22:15:28 --> Output Class Initialized
INFO - 2019-11-03 22:15:28 --> Security Class Initialized
DEBUG - 2019-11-03 22:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:15:28 --> CSRF cookie sent
INFO - 2019-11-03 22:15:28 --> CSRF token verified
INFO - 2019-11-03 22:15:28 --> Input Class Initialized
INFO - 2019-11-03 22:15:28 --> Language Class Initialized
INFO - 2019-11-03 22:15:28 --> Language Class Initialized
INFO - 2019-11-03 22:15:28 --> Config Class Initialized
INFO - 2019-11-03 22:15:28 --> Loader Class Initialized
INFO - 2019-11-03 22:15:28 --> Helper loaded: url_helper
INFO - 2019-11-03 22:15:28 --> Helper loaded: common_helper
INFO - 2019-11-03 22:15:28 --> Helper loaded: language_helper
INFO - 2019-11-03 22:15:28 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:15:28 --> Helper loaded: email_helper
INFO - 2019-11-03 22:15:28 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:15:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:15:28 --> Parser Class Initialized
INFO - 2019-11-03 22:15:28 --> User Agent Class Initialized
INFO - 2019-11-03 22:15:28 --> Model Class Initialized
INFO - 2019-11-03 22:15:28 --> Database Driver Class Initialized
INFO - 2019-11-03 22:15:28 --> Model Class Initialized
DEBUG - 2019-11-03 22:15:28 --> Template Class Initialized
INFO - 2019-11-03 22:15:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:15:28 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:15:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:15:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:15:28 --> Encryption Class Initialized
INFO - 2019-11-03 22:15:29 --> Controller Class Initialized
DEBUG - 2019-11-03 22:15:29 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:15:29 --> Model Class Initialized
INFO - 2019-11-03 22:15:29 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 22:15:29 --> Could not find the language line "dotpay"
DEBUG - 2019-11-03 22:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-03 22:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:15:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:15:29 --> Model Class Initialized
DEBUG - 2019-11-03 22:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:15:29 --> Model Class Initialized
DEBUG - 2019-11-03 22:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 22:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 22:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 22:15:29 --> Final output sent to browser
DEBUG - 2019-11-03 22:15:29 --> Total execution time: 0.7035
INFO - 2019-11-03 22:15:38 --> Config Class Initialized
INFO - 2019-11-03 22:15:38 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:15:38 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:15:38 --> Utf8 Class Initialized
INFO - 2019-11-03 22:15:38 --> URI Class Initialized
INFO - 2019-11-03 22:15:38 --> Router Class Initialized
INFO - 2019-11-03 22:15:38 --> Output Class Initialized
INFO - 2019-11-03 22:15:38 --> Security Class Initialized
DEBUG - 2019-11-03 22:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:15:38 --> CSRF cookie sent
INFO - 2019-11-03 22:15:38 --> CSRF token verified
INFO - 2019-11-03 22:15:38 --> Input Class Initialized
INFO - 2019-11-03 22:15:38 --> Language Class Initialized
INFO - 2019-11-03 22:15:38 --> Language Class Initialized
INFO - 2019-11-03 22:15:38 --> Config Class Initialized
INFO - 2019-11-03 22:15:38 --> Loader Class Initialized
INFO - 2019-11-03 22:15:38 --> Helper loaded: url_helper
INFO - 2019-11-03 22:15:38 --> Helper loaded: common_helper
INFO - 2019-11-03 22:15:38 --> Helper loaded: language_helper
INFO - 2019-11-03 22:15:38 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:15:38 --> Helper loaded: email_helper
INFO - 2019-11-03 22:15:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:15:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:15:38 --> Parser Class Initialized
INFO - 2019-11-03 22:15:38 --> User Agent Class Initialized
INFO - 2019-11-03 22:15:38 --> Model Class Initialized
INFO - 2019-11-03 22:15:38 --> Database Driver Class Initialized
INFO - 2019-11-03 22:15:38 --> Model Class Initialized
DEBUG - 2019-11-03 22:15:38 --> Template Class Initialized
INFO - 2019-11-03 22:15:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:15:38 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:15:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:15:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:15:38 --> Encryption Class Initialized
INFO - 2019-11-03 22:15:38 --> Controller Class Initialized
DEBUG - 2019-11-03 22:15:38 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:15:38 --> Model Class Initialized
DEBUG - 2019-11-03 22:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 22:15:38 --> Final output sent to browser
DEBUG - 2019-11-03 22:15:38 --> Total execution time: 0.5061
INFO - 2019-11-03 22:15:38 --> Config Class Initialized
INFO - 2019-11-03 22:15:38 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:15:38 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:15:38 --> Utf8 Class Initialized
INFO - 2019-11-03 22:15:38 --> URI Class Initialized
INFO - 2019-11-03 22:15:38 --> Router Class Initialized
INFO - 2019-11-03 22:15:38 --> Output Class Initialized
INFO - 2019-11-03 22:15:38 --> Security Class Initialized
DEBUG - 2019-11-03 22:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:15:38 --> Input Class Initialized
INFO - 2019-11-03 22:15:38 --> Language Class Initialized
INFO - 2019-11-03 22:15:38 --> Language Class Initialized
INFO - 2019-11-03 22:15:38 --> Config Class Initialized
INFO - 2019-11-03 22:15:38 --> Loader Class Initialized
INFO - 2019-11-03 22:15:38 --> Helper loaded: url_helper
INFO - 2019-11-03 22:15:38 --> Helper loaded: common_helper
INFO - 2019-11-03 22:15:38 --> Helper loaded: language_helper
INFO - 2019-11-03 22:15:39 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:15:39 --> Helper loaded: email_helper
INFO - 2019-11-03 22:15:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:15:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:15:39 --> Parser Class Initialized
INFO - 2019-11-03 22:15:39 --> User Agent Class Initialized
INFO - 2019-11-03 22:15:39 --> Model Class Initialized
INFO - 2019-11-03 22:15:39 --> Database Driver Class Initialized
INFO - 2019-11-03 22:15:39 --> Model Class Initialized
DEBUG - 2019-11-03 22:15:39 --> Template Class Initialized
INFO - 2019-11-03 22:15:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:15:39 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:15:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:15:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:15:39 --> Encryption Class Initialized
INFO - 2019-11-03 22:15:39 --> Controller Class Initialized
DEBUG - 2019-11-03 22:15:39 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:15:39 --> Model Class Initialized
DEBUG - 2019-11-03 22:15:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 22:15:39 --> Final output sent to browser
DEBUG - 2019-11-03 22:15:39 --> Total execution time: 0.5057
INFO - 2019-11-03 22:16:53 --> Config Class Initialized
INFO - 2019-11-03 22:16:53 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:16:53 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:16:53 --> Utf8 Class Initialized
INFO - 2019-11-03 22:16:53 --> URI Class Initialized
INFO - 2019-11-03 22:16:53 --> Router Class Initialized
INFO - 2019-11-03 22:16:53 --> Output Class Initialized
INFO - 2019-11-03 22:16:53 --> Security Class Initialized
DEBUG - 2019-11-03 22:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:16:53 --> CSRF cookie sent
INFO - 2019-11-03 22:16:53 --> CSRF token verified
INFO - 2019-11-03 22:16:53 --> Input Class Initialized
INFO - 2019-11-03 22:16:53 --> Language Class Initialized
INFO - 2019-11-03 22:16:53 --> Language Class Initialized
INFO - 2019-11-03 22:16:53 --> Config Class Initialized
INFO - 2019-11-03 22:16:53 --> Loader Class Initialized
INFO - 2019-11-03 22:16:53 --> Helper loaded: url_helper
INFO - 2019-11-03 22:16:53 --> Helper loaded: common_helper
INFO - 2019-11-03 22:16:53 --> Helper loaded: language_helper
INFO - 2019-11-03 22:16:53 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:16:53 --> Helper loaded: email_helper
INFO - 2019-11-03 22:16:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:16:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:16:53 --> Parser Class Initialized
INFO - 2019-11-03 22:16:53 --> User Agent Class Initialized
INFO - 2019-11-03 22:16:53 --> Model Class Initialized
INFO - 2019-11-03 22:16:53 --> Database Driver Class Initialized
INFO - 2019-11-03 22:16:53 --> Model Class Initialized
DEBUG - 2019-11-03 22:16:53 --> Template Class Initialized
INFO - 2019-11-03 22:16:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:16:53 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:16:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:16:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:16:54 --> Encryption Class Initialized
INFO - 2019-11-03 22:16:54 --> Controller Class Initialized
DEBUG - 2019-11-03 22:16:54 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:16:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:16:54 --> Model Class Initialized
DEBUG - 2019-11-03 22:16:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 22:16:54 --> Final output sent to browser
DEBUG - 2019-11-03 22:16:54 --> Total execution time: 0.4869
INFO - 2019-11-03 22:16:54 --> Config Class Initialized
INFO - 2019-11-03 22:16:54 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:16:54 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:16:54 --> Utf8 Class Initialized
INFO - 2019-11-03 22:16:54 --> URI Class Initialized
INFO - 2019-11-03 22:16:54 --> Router Class Initialized
INFO - 2019-11-03 22:16:54 --> Output Class Initialized
INFO - 2019-11-03 22:16:54 --> Security Class Initialized
DEBUG - 2019-11-03 22:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:16:54 --> Input Class Initialized
INFO - 2019-11-03 22:16:54 --> Language Class Initialized
INFO - 2019-11-03 22:16:54 --> Language Class Initialized
INFO - 2019-11-03 22:16:54 --> Config Class Initialized
INFO - 2019-11-03 22:16:54 --> Loader Class Initialized
INFO - 2019-11-03 22:16:54 --> Helper loaded: url_helper
INFO - 2019-11-03 22:16:54 --> Helper loaded: common_helper
INFO - 2019-11-03 22:16:54 --> Helper loaded: language_helper
INFO - 2019-11-03 22:16:54 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:16:54 --> Helper loaded: email_helper
INFO - 2019-11-03 22:16:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:16:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:16:54 --> Parser Class Initialized
INFO - 2019-11-03 22:16:54 --> User Agent Class Initialized
INFO - 2019-11-03 22:16:54 --> Model Class Initialized
INFO - 2019-11-03 22:16:54 --> Database Driver Class Initialized
INFO - 2019-11-03 22:16:54 --> Model Class Initialized
DEBUG - 2019-11-03 22:16:54 --> Template Class Initialized
INFO - 2019-11-03 22:16:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:16:54 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:16:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:16:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:16:54 --> Encryption Class Initialized
INFO - 2019-11-03 22:16:54 --> Controller Class Initialized
DEBUG - 2019-11-03 22:16:54 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:16:54 --> Model Class Initialized
DEBUG - 2019-11-03 22:16:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 22:16:54 --> Final output sent to browser
DEBUG - 2019-11-03 22:16:54 --> Total execution time: 0.5116
INFO - 2019-11-03 22:17:45 --> Config Class Initialized
INFO - 2019-11-03 22:17:45 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:17:45 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:17:45 --> Utf8 Class Initialized
INFO - 2019-11-03 22:17:45 --> URI Class Initialized
INFO - 2019-11-03 22:17:45 --> Router Class Initialized
INFO - 2019-11-03 22:17:45 --> Output Class Initialized
INFO - 2019-11-03 22:17:45 --> Security Class Initialized
DEBUG - 2019-11-03 22:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:17:45 --> CSRF cookie sent
INFO - 2019-11-03 22:17:45 --> CSRF token verified
INFO - 2019-11-03 22:17:45 --> Input Class Initialized
INFO - 2019-11-03 22:17:45 --> Language Class Initialized
INFO - 2019-11-03 22:17:45 --> Language Class Initialized
INFO - 2019-11-03 22:17:45 --> Config Class Initialized
INFO - 2019-11-03 22:17:45 --> Loader Class Initialized
INFO - 2019-11-03 22:17:45 --> Helper loaded: url_helper
INFO - 2019-11-03 22:17:45 --> Helper loaded: common_helper
INFO - 2019-11-03 22:17:45 --> Helper loaded: language_helper
INFO - 2019-11-03 22:17:45 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:17:45 --> Helper loaded: email_helper
INFO - 2019-11-03 22:17:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:17:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:17:45 --> Parser Class Initialized
INFO - 2019-11-03 22:17:45 --> User Agent Class Initialized
INFO - 2019-11-03 22:17:45 --> Model Class Initialized
INFO - 2019-11-03 22:17:45 --> Database Driver Class Initialized
INFO - 2019-11-03 22:17:45 --> Model Class Initialized
DEBUG - 2019-11-03 22:17:45 --> Template Class Initialized
INFO - 2019-11-03 22:17:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:17:45 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:17:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:17:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:17:45 --> Encryption Class Initialized
INFO - 2019-11-03 22:17:45 --> Controller Class Initialized
DEBUG - 2019-11-03 22:17:45 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:17:45 --> Model Class Initialized
INFO - 2019-11-03 22:17:45 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 22:17:45 --> Could not find the language line "dotpay"
DEBUG - 2019-11-03 22:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-03 22:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:17:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:17:45 --> Model Class Initialized
DEBUG - 2019-11-03 22:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:17:45 --> Model Class Initialized
DEBUG - 2019-11-03 22:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 22:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 22:17:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 22:17:45 --> Final output sent to browser
DEBUG - 2019-11-03 22:17:45 --> Total execution time: 0.7336
INFO - 2019-11-03 22:17:53 --> Config Class Initialized
INFO - 2019-11-03 22:17:53 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:17:53 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:17:53 --> Utf8 Class Initialized
INFO - 2019-11-03 22:17:53 --> URI Class Initialized
INFO - 2019-11-03 22:17:53 --> Router Class Initialized
INFO - 2019-11-03 22:17:53 --> Output Class Initialized
INFO - 2019-11-03 22:17:53 --> Security Class Initialized
DEBUG - 2019-11-03 22:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:17:53 --> CSRF cookie sent
INFO - 2019-11-03 22:17:53 --> CSRF token verified
INFO - 2019-11-03 22:17:53 --> Input Class Initialized
INFO - 2019-11-03 22:17:53 --> Language Class Initialized
INFO - 2019-11-03 22:17:53 --> Language Class Initialized
INFO - 2019-11-03 22:17:53 --> Config Class Initialized
INFO - 2019-11-03 22:17:53 --> Loader Class Initialized
INFO - 2019-11-03 22:17:53 --> Helper loaded: url_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: common_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: language_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: email_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:17:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:17:53 --> Parser Class Initialized
INFO - 2019-11-03 22:17:53 --> User Agent Class Initialized
INFO - 2019-11-03 22:17:53 --> Model Class Initialized
INFO - 2019-11-03 22:17:53 --> Database Driver Class Initialized
INFO - 2019-11-03 22:17:53 --> Model Class Initialized
DEBUG - 2019-11-03 22:17:53 --> Template Class Initialized
INFO - 2019-11-03 22:17:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:17:53 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:17:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:17:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:17:53 --> Encryption Class Initialized
INFO - 2019-11-03 22:17:53 --> Controller Class Initialized
DEBUG - 2019-11-03 22:17:53 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:17:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:17:53 --> Model Class Initialized
DEBUG - 2019-11-03 22:17:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 22:17:53 --> Final output sent to browser
DEBUG - 2019-11-03 22:17:53 --> Total execution time: 0.4780
INFO - 2019-11-03 22:17:53 --> Config Class Initialized
INFO - 2019-11-03 22:17:53 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:17:53 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:17:53 --> Utf8 Class Initialized
INFO - 2019-11-03 22:17:53 --> URI Class Initialized
INFO - 2019-11-03 22:17:53 --> Router Class Initialized
INFO - 2019-11-03 22:17:53 --> Output Class Initialized
INFO - 2019-11-03 22:17:53 --> Security Class Initialized
DEBUG - 2019-11-03 22:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:17:53 --> Input Class Initialized
INFO - 2019-11-03 22:17:53 --> Language Class Initialized
INFO - 2019-11-03 22:17:53 --> Language Class Initialized
INFO - 2019-11-03 22:17:53 --> Config Class Initialized
INFO - 2019-11-03 22:17:53 --> Loader Class Initialized
INFO - 2019-11-03 22:17:53 --> Helper loaded: url_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: common_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: language_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: email_helper
INFO - 2019-11-03 22:17:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:17:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:17:53 --> Parser Class Initialized
INFO - 2019-11-03 22:17:53 --> User Agent Class Initialized
INFO - 2019-11-03 22:17:53 --> Model Class Initialized
INFO - 2019-11-03 22:17:53 --> Database Driver Class Initialized
INFO - 2019-11-03 22:17:53 --> Model Class Initialized
DEBUG - 2019-11-03 22:17:53 --> Template Class Initialized
INFO - 2019-11-03 22:17:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:17:53 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:17:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:17:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:17:54 --> Encryption Class Initialized
INFO - 2019-11-03 22:17:54 --> Controller Class Initialized
DEBUG - 2019-11-03 22:17:54 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:17:54 --> Model Class Initialized
DEBUG - 2019-11-03 22:17:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 22:17:54 --> Final output sent to browser
DEBUG - 2019-11-03 22:17:54 --> Total execution time: 0.5068
INFO - 2019-11-03 22:17:59 --> Config Class Initialized
INFO - 2019-11-03 22:17:59 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:17:59 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:17:59 --> Utf8 Class Initialized
INFO - 2019-11-03 22:17:59 --> URI Class Initialized
INFO - 2019-11-03 22:17:59 --> Router Class Initialized
INFO - 2019-11-03 22:17:59 --> Output Class Initialized
INFO - 2019-11-03 22:17:59 --> Security Class Initialized
DEBUG - 2019-11-03 22:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:17:59 --> Input Class Initialized
INFO - 2019-11-03 22:17:59 --> Language Class Initialized
INFO - 2019-11-03 22:17:59 --> Language Class Initialized
INFO - 2019-11-03 22:17:59 --> Config Class Initialized
INFO - 2019-11-03 22:17:59 --> Loader Class Initialized
INFO - 2019-11-03 22:17:59 --> Helper loaded: url_helper
INFO - 2019-11-03 22:17:59 --> Helper loaded: common_helper
INFO - 2019-11-03 22:17:59 --> Helper loaded: language_helper
INFO - 2019-11-03 22:17:59 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:17:59 --> Helper loaded: email_helper
INFO - 2019-11-03 22:17:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:17:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:17:59 --> Parser Class Initialized
INFO - 2019-11-03 22:17:59 --> User Agent Class Initialized
INFO - 2019-11-03 22:17:59 --> Model Class Initialized
INFO - 2019-11-03 22:17:59 --> Database Driver Class Initialized
INFO - 2019-11-03 22:17:59 --> Model Class Initialized
DEBUG - 2019-11-03 22:17:59 --> Template Class Initialized
INFO - 2019-11-03 22:17:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:17:59 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:17:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:17:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:17:59 --> Encryption Class Initialized
INFO - 2019-11-03 22:17:59 --> Controller Class Initialized
DEBUG - 2019-11-03 22:17:59 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:17:59 --> Model Class Initialized
INFO - 2019-11-03 22:20:29 --> Config Class Initialized
INFO - 2019-11-03 22:20:29 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:20:29 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:20:29 --> Utf8 Class Initialized
INFO - 2019-11-03 22:20:29 --> URI Class Initialized
INFO - 2019-11-03 22:20:29 --> Router Class Initialized
INFO - 2019-11-03 22:20:29 --> Output Class Initialized
INFO - 2019-11-03 22:20:29 --> Security Class Initialized
DEBUG - 2019-11-03 22:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:20:29 --> CSRF cookie sent
INFO - 2019-11-03 22:20:29 --> Input Class Initialized
INFO - 2019-11-03 22:20:29 --> Language Class Initialized
INFO - 2019-11-03 22:20:29 --> Language Class Initialized
INFO - 2019-11-03 22:20:29 --> Config Class Initialized
INFO - 2019-11-03 22:20:29 --> Loader Class Initialized
INFO - 2019-11-03 22:20:29 --> Helper loaded: url_helper
INFO - 2019-11-03 22:20:29 --> Helper loaded: common_helper
INFO - 2019-11-03 22:20:29 --> Helper loaded: language_helper
INFO - 2019-11-03 22:20:29 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:20:29 --> Helper loaded: email_helper
INFO - 2019-11-03 22:20:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:20:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:20:29 --> Parser Class Initialized
INFO - 2019-11-03 22:20:29 --> User Agent Class Initialized
INFO - 2019-11-03 22:20:29 --> Model Class Initialized
INFO - 2019-11-03 22:20:29 --> Database Driver Class Initialized
INFO - 2019-11-03 22:20:29 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:29 --> Template Class Initialized
INFO - 2019-11-03 22:20:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:20:29 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:20:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:20:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:20:29 --> Encryption Class Initialized
INFO - 2019-11-03 22:20:29 --> Controller Class Initialized
DEBUG - 2019-11-03 22:20:29 --> provider MX_Controller Initialized
DEBUG - 2019-11-03 22:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/models/provider_model.php
INFO - 2019-11-03 22:20:29 --> Model Class Initialized
ERROR - 2019-11-03 22:20:29 --> Could not find the language line "Balance"
INFO - 2019-11-03 22:20:29 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 22:20:29 --> Could not find the language line "api_providers"
DEBUG - 2019-11-03 22:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/views/index.php
DEBUG - 2019-11-03 22:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:20:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:20:29 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:20:29 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 22:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 22:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 22:20:29 --> Final output sent to browser
DEBUG - 2019-11-03 22:20:29 --> Total execution time: 0.7205
INFO - 2019-11-03 22:20:31 --> Config Class Initialized
INFO - 2019-11-03 22:20:31 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:20:31 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:20:31 --> Utf8 Class Initialized
INFO - 2019-11-03 22:20:31 --> URI Class Initialized
INFO - 2019-11-03 22:20:31 --> Router Class Initialized
INFO - 2019-11-03 22:20:31 --> Output Class Initialized
INFO - 2019-11-03 22:20:31 --> Security Class Initialized
DEBUG - 2019-11-03 22:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:20:31 --> CSRF cookie sent
INFO - 2019-11-03 22:20:31 --> Input Class Initialized
INFO - 2019-11-03 22:20:31 --> Language Class Initialized
INFO - 2019-11-03 22:20:31 --> Language Class Initialized
INFO - 2019-11-03 22:20:31 --> Config Class Initialized
INFO - 2019-11-03 22:20:31 --> Loader Class Initialized
INFO - 2019-11-03 22:20:31 --> Helper loaded: url_helper
INFO - 2019-11-03 22:20:31 --> Helper loaded: common_helper
INFO - 2019-11-03 22:20:31 --> Helper loaded: language_helper
INFO - 2019-11-03 22:20:31 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:20:31 --> Helper loaded: email_helper
INFO - 2019-11-03 22:20:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:20:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:20:32 --> Parser Class Initialized
INFO - 2019-11-03 22:20:32 --> User Agent Class Initialized
INFO - 2019-11-03 22:20:32 --> Model Class Initialized
INFO - 2019-11-03 22:20:32 --> Database Driver Class Initialized
INFO - 2019-11-03 22:20:32 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:32 --> Template Class Initialized
INFO - 2019-11-03 22:20:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:20:32 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:20:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:20:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:20:32 --> Encryption Class Initialized
INFO - 2019-11-03 22:20:32 --> Controller Class Initialized
DEBUG - 2019-11-03 22:20:32 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 22:20:32 --> Model Class Initialized
INFO - 2019-11-03 22:20:32 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:20:32 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:20:32 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:20:32 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 22:20:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 22:20:32 --> Final output sent to browser
DEBUG - 2019-11-03 22:20:32 --> Total execution time: 0.7812
INFO - 2019-11-03 22:20:34 --> Config Class Initialized
INFO - 2019-11-03 22:20:34 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:20:34 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:20:34 --> Utf8 Class Initialized
INFO - 2019-11-03 22:20:34 --> URI Class Initialized
INFO - 2019-11-03 22:20:34 --> Router Class Initialized
INFO - 2019-11-03 22:20:34 --> Output Class Initialized
INFO - 2019-11-03 22:20:34 --> Security Class Initialized
DEBUG - 2019-11-03 22:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:20:34 --> CSRF cookie sent
INFO - 2019-11-03 22:20:34 --> Input Class Initialized
INFO - 2019-11-03 22:20:34 --> Language Class Initialized
INFO - 2019-11-03 22:20:34 --> Language Class Initialized
INFO - 2019-11-03 22:20:34 --> Config Class Initialized
INFO - 2019-11-03 22:20:34 --> Loader Class Initialized
INFO - 2019-11-03 22:20:34 --> Helper loaded: url_helper
INFO - 2019-11-03 22:20:34 --> Helper loaded: common_helper
INFO - 2019-11-03 22:20:34 --> Helper loaded: language_helper
INFO - 2019-11-03 22:20:34 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:20:34 --> Helper loaded: email_helper
INFO - 2019-11-03 22:20:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:20:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:20:34 --> Parser Class Initialized
INFO - 2019-11-03 22:20:34 --> User Agent Class Initialized
INFO - 2019-11-03 22:20:34 --> Model Class Initialized
INFO - 2019-11-03 22:20:34 --> Database Driver Class Initialized
INFO - 2019-11-03 22:20:34 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:34 --> Template Class Initialized
INFO - 2019-11-03 22:20:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:20:34 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:20:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:20:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:20:34 --> Encryption Class Initialized
INFO - 2019-11-03 22:20:34 --> Controller Class Initialized
DEBUG - 2019-11-03 22:20:34 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 22:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 22:20:34 --> Model Class Initialized
INFO - 2019-11-03 22:20:34 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 22:20:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinbase.php
DEBUG - 2019-11-03 22:20:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 22:20:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:20:35 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:20:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:20:35 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:20:35 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 22:20:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 22:20:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 22:20:35 --> Final output sent to browser
DEBUG - 2019-11-03 22:20:35 --> Total execution time: 0.6613
INFO - 2019-11-03 22:20:39 --> Config Class Initialized
INFO - 2019-11-03 22:20:39 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:20:39 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:20:39 --> Utf8 Class Initialized
INFO - 2019-11-03 22:20:39 --> URI Class Initialized
INFO - 2019-11-03 22:20:39 --> Router Class Initialized
INFO - 2019-11-03 22:20:39 --> Output Class Initialized
INFO - 2019-11-03 22:20:39 --> Security Class Initialized
DEBUG - 2019-11-03 22:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:20:39 --> CSRF cookie sent
INFO - 2019-11-03 22:20:39 --> Input Class Initialized
INFO - 2019-11-03 22:20:39 --> Language Class Initialized
INFO - 2019-11-03 22:20:39 --> Language Class Initialized
INFO - 2019-11-03 22:20:39 --> Config Class Initialized
INFO - 2019-11-03 22:20:39 --> Loader Class Initialized
INFO - 2019-11-03 22:20:39 --> Helper loaded: url_helper
INFO - 2019-11-03 22:20:39 --> Helper loaded: common_helper
INFO - 2019-11-03 22:20:39 --> Helper loaded: language_helper
INFO - 2019-11-03 22:20:39 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:20:39 --> Helper loaded: email_helper
INFO - 2019-11-03 22:20:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:20:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:20:39 --> Parser Class Initialized
INFO - 2019-11-03 22:20:39 --> User Agent Class Initialized
INFO - 2019-11-03 22:20:39 --> Model Class Initialized
INFO - 2019-11-03 22:20:39 --> Database Driver Class Initialized
INFO - 2019-11-03 22:20:39 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:39 --> Template Class Initialized
INFO - 2019-11-03 22:20:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:20:39 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:20:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:20:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:20:39 --> Encryption Class Initialized
INFO - 2019-11-03 22:20:39 --> Controller Class Initialized
DEBUG - 2019-11-03 22:20:39 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 22:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 22:20:39 --> Model Class Initialized
INFO - 2019-11-03 22:20:39 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 22:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/stripe.php
DEBUG - 2019-11-03 22:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 22:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:20:39 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:20:39 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:20:40 --> Model Class Initialized
DEBUG - 2019-11-03 22:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 22:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 22:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 22:20:40 --> Final output sent to browser
DEBUG - 2019-11-03 22:20:40 --> Total execution time: 0.7190
INFO - 2019-11-03 22:23:17 --> Config Class Initialized
INFO - 2019-11-03 22:23:17 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:23:17 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:23:17 --> Utf8 Class Initialized
INFO - 2019-11-03 22:23:17 --> URI Class Initialized
INFO - 2019-11-03 22:23:17 --> Router Class Initialized
INFO - 2019-11-03 22:23:17 --> Output Class Initialized
INFO - 2019-11-03 22:23:17 --> Security Class Initialized
DEBUG - 2019-11-03 22:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:23:17 --> CSRF cookie sent
INFO - 2019-11-03 22:23:17 --> Input Class Initialized
INFO - 2019-11-03 22:23:17 --> Language Class Initialized
INFO - 2019-11-03 22:23:17 --> Language Class Initialized
INFO - 2019-11-03 22:23:17 --> Config Class Initialized
INFO - 2019-11-03 22:23:17 --> Loader Class Initialized
INFO - 2019-11-03 22:23:17 --> Helper loaded: url_helper
INFO - 2019-11-03 22:23:17 --> Helper loaded: common_helper
INFO - 2019-11-03 22:23:17 --> Helper loaded: language_helper
INFO - 2019-11-03 22:23:17 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:23:17 --> Helper loaded: email_helper
INFO - 2019-11-03 22:23:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:23:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:23:17 --> Parser Class Initialized
INFO - 2019-11-03 22:23:17 --> User Agent Class Initialized
INFO - 2019-11-03 22:23:17 --> Model Class Initialized
INFO - 2019-11-03 22:23:17 --> Database Driver Class Initialized
INFO - 2019-11-03 22:23:17 --> Model Class Initialized
DEBUG - 2019-11-03 22:23:17 --> Template Class Initialized
INFO - 2019-11-03 22:23:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:23:17 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:23:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:23:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:23:17 --> Encryption Class Initialized
INFO - 2019-11-03 22:23:17 --> Controller Class Initialized
DEBUG - 2019-11-03 22:23:17 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 22:23:17 --> Model Class Initialized
INFO - 2019-11-03 22:23:17 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:23:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:23:17 --> Model Class Initialized
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:23:17 --> Model Class Initialized
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 22:23:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 22:23:17 --> Final output sent to browser
DEBUG - 2019-11-03 22:23:18 --> Total execution time: 0.8077
INFO - 2019-11-03 22:27:29 --> Config Class Initialized
INFO - 2019-11-03 22:27:29 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:27:29 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:27:29 --> Utf8 Class Initialized
INFO - 2019-11-03 22:27:29 --> URI Class Initialized
INFO - 2019-11-03 22:27:29 --> Router Class Initialized
INFO - 2019-11-03 22:27:29 --> Output Class Initialized
INFO - 2019-11-03 22:27:29 --> Security Class Initialized
DEBUG - 2019-11-03 22:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:27:29 --> CSRF cookie sent
INFO - 2019-11-03 22:27:29 --> Input Class Initialized
INFO - 2019-11-03 22:27:29 --> Language Class Initialized
INFO - 2019-11-03 22:27:29 --> Language Class Initialized
INFO - 2019-11-03 22:27:29 --> Config Class Initialized
INFO - 2019-11-03 22:27:29 --> Loader Class Initialized
INFO - 2019-11-03 22:27:29 --> Helper loaded: url_helper
INFO - 2019-11-03 22:27:29 --> Helper loaded: common_helper
INFO - 2019-11-03 22:27:29 --> Helper loaded: language_helper
INFO - 2019-11-03 22:27:29 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:27:29 --> Helper loaded: email_helper
INFO - 2019-11-03 22:27:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:27:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:27:29 --> Parser Class Initialized
INFO - 2019-11-03 22:27:29 --> User Agent Class Initialized
INFO - 2019-11-03 22:27:29 --> Model Class Initialized
INFO - 2019-11-03 22:27:29 --> Database Driver Class Initialized
INFO - 2019-11-03 22:27:29 --> Model Class Initialized
DEBUG - 2019-11-03 22:27:29 --> Template Class Initialized
INFO - 2019-11-03 22:27:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:27:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:27:29 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:27:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:27:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:27:29 --> Encryption Class Initialized
INFO - 2019-11-03 22:27:29 --> Controller Class Initialized
DEBUG - 2019-11-03 22:27:29 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 22:27:30 --> Model Class Initialized
INFO - 2019-11-03 22:27:30 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:27:30 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:27:30 --> Model Class Initialized
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:27:30 --> Model Class Initialized
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 22:27:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 22:27:30 --> Final output sent to browser
DEBUG - 2019-11-03 22:27:30 --> Total execution time: 0.7053
INFO - 2019-11-03 22:27:55 --> Config Class Initialized
INFO - 2019-11-03 22:27:55 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:27:56 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:27:56 --> Utf8 Class Initialized
INFO - 2019-11-03 22:27:56 --> URI Class Initialized
INFO - 2019-11-03 22:27:56 --> Router Class Initialized
INFO - 2019-11-03 22:27:56 --> Output Class Initialized
INFO - 2019-11-03 22:27:56 --> Security Class Initialized
DEBUG - 2019-11-03 22:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:27:56 --> CSRF cookie sent
INFO - 2019-11-03 22:27:56 --> CSRF token verified
INFO - 2019-11-03 22:27:56 --> Input Class Initialized
INFO - 2019-11-03 22:27:56 --> Language Class Initialized
INFO - 2019-11-03 22:27:56 --> Language Class Initialized
INFO - 2019-11-03 22:27:56 --> Config Class Initialized
INFO - 2019-11-03 22:27:56 --> Loader Class Initialized
INFO - 2019-11-03 22:27:56 --> Helper loaded: url_helper
INFO - 2019-11-03 22:27:56 --> Helper loaded: common_helper
INFO - 2019-11-03 22:27:56 --> Helper loaded: language_helper
INFO - 2019-11-03 22:27:56 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:27:56 --> Helper loaded: email_helper
INFO - 2019-11-03 22:27:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:27:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:27:56 --> Parser Class Initialized
INFO - 2019-11-03 22:27:56 --> User Agent Class Initialized
INFO - 2019-11-03 22:27:56 --> Model Class Initialized
INFO - 2019-11-03 22:27:56 --> Database Driver Class Initialized
INFO - 2019-11-03 22:27:56 --> Model Class Initialized
DEBUG - 2019-11-03 22:27:56 --> Template Class Initialized
INFO - 2019-11-03 22:27:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:27:56 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:27:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:27:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:27:56 --> Encryption Class Initialized
INFO - 2019-11-03 22:27:56 --> Controller Class Initialized
DEBUG - 2019-11-03 22:27:56 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 22:27:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 22:27:56 --> Model Class Initialized
INFO - 2019-11-03 22:28:00 --> Config Class Initialized
INFO - 2019-11-03 22:28:00 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:28:01 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:28:01 --> Utf8 Class Initialized
INFO - 2019-11-03 22:28:01 --> URI Class Initialized
INFO - 2019-11-03 22:28:01 --> Router Class Initialized
INFO - 2019-11-03 22:28:01 --> Output Class Initialized
INFO - 2019-11-03 22:28:01 --> Security Class Initialized
DEBUG - 2019-11-03 22:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:28:01 --> CSRF cookie sent
INFO - 2019-11-03 22:28:01 --> Input Class Initialized
INFO - 2019-11-03 22:28:01 --> Language Class Initialized
INFO - 2019-11-03 22:28:01 --> Language Class Initialized
INFO - 2019-11-03 22:28:01 --> Config Class Initialized
INFO - 2019-11-03 22:28:01 --> Loader Class Initialized
INFO - 2019-11-03 22:28:01 --> Helper loaded: url_helper
INFO - 2019-11-03 22:28:01 --> Helper loaded: common_helper
INFO - 2019-11-03 22:28:01 --> Helper loaded: language_helper
INFO - 2019-11-03 22:28:01 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:28:01 --> Helper loaded: email_helper
INFO - 2019-11-03 22:28:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:28:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:28:01 --> Parser Class Initialized
INFO - 2019-11-03 22:28:01 --> User Agent Class Initialized
INFO - 2019-11-03 22:28:01 --> Model Class Initialized
INFO - 2019-11-03 22:28:01 --> Database Driver Class Initialized
INFO - 2019-11-03 22:28:01 --> Model Class Initialized
DEBUG - 2019-11-03 22:28:01 --> Template Class Initialized
INFO - 2019-11-03 22:28:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:28:01 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:28:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:28:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:28:01 --> Encryption Class Initialized
INFO - 2019-11-03 22:28:01 --> Controller Class Initialized
DEBUG - 2019-11-03 22:28:01 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 22:28:01 --> Model Class Initialized
INFO - 2019-11-03 22:28:01 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:28:01 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:28:01 --> Model Class Initialized
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:28:01 --> Model Class Initialized
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 22:28:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 22:28:01 --> Final output sent to browser
DEBUG - 2019-11-03 22:28:01 --> Total execution time: 0.7545
INFO - 2019-11-03 22:28:10 --> Config Class Initialized
INFO - 2019-11-03 22:28:10 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:28:10 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:28:10 --> Utf8 Class Initialized
INFO - 2019-11-03 22:28:10 --> URI Class Initialized
INFO - 2019-11-03 22:28:10 --> Router Class Initialized
INFO - 2019-11-03 22:28:10 --> Output Class Initialized
INFO - 2019-11-03 22:28:10 --> Security Class Initialized
DEBUG - 2019-11-03 22:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:28:10 --> CSRF cookie sent
INFO - 2019-11-03 22:28:10 --> Input Class Initialized
INFO - 2019-11-03 22:28:10 --> Language Class Initialized
INFO - 2019-11-03 22:28:10 --> Language Class Initialized
INFO - 2019-11-03 22:28:10 --> Config Class Initialized
INFO - 2019-11-03 22:28:10 --> Loader Class Initialized
INFO - 2019-11-03 22:28:10 --> Helper loaded: url_helper
INFO - 2019-11-03 22:28:10 --> Helper loaded: common_helper
INFO - 2019-11-03 22:28:10 --> Helper loaded: language_helper
INFO - 2019-11-03 22:28:10 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:28:10 --> Helper loaded: email_helper
INFO - 2019-11-03 22:28:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:28:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:28:10 --> Parser Class Initialized
INFO - 2019-11-03 22:28:10 --> User Agent Class Initialized
INFO - 2019-11-03 22:28:10 --> Model Class Initialized
INFO - 2019-11-03 22:28:10 --> Database Driver Class Initialized
INFO - 2019-11-03 22:28:10 --> Model Class Initialized
DEBUG - 2019-11-03 22:28:10 --> Template Class Initialized
INFO - 2019-11-03 22:28:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:28:10 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:28:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:28:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:28:10 --> Encryption Class Initialized
INFO - 2019-11-03 22:28:10 --> Controller Class Initialized
DEBUG - 2019-11-03 22:28:10 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 22:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 22:28:10 --> Model Class Initialized
INFO - 2019-11-03 22:28:10 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 22:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-03 22:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 22:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:28:10 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:28:10 --> Model Class Initialized
DEBUG - 2019-11-03 22:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:28:10 --> Model Class Initialized
DEBUG - 2019-11-03 22:28:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 22:28:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 22:28:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 22:28:11 --> Final output sent to browser
DEBUG - 2019-11-03 22:28:11 --> Total execution time: 0.7409
INFO - 2019-11-03 22:29:16 --> Config Class Initialized
INFO - 2019-11-03 22:29:16 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:29:16 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:29:16 --> Utf8 Class Initialized
INFO - 2019-11-03 22:29:16 --> URI Class Initialized
INFO - 2019-11-03 22:29:16 --> Router Class Initialized
INFO - 2019-11-03 22:29:16 --> Output Class Initialized
INFO - 2019-11-03 22:29:16 --> Security Class Initialized
DEBUG - 2019-11-03 22:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:29:16 --> CSRF cookie sent
INFO - 2019-11-03 22:29:16 --> Input Class Initialized
INFO - 2019-11-03 22:29:16 --> Language Class Initialized
INFO - 2019-11-03 22:29:16 --> Language Class Initialized
INFO - 2019-11-03 22:29:16 --> Config Class Initialized
INFO - 2019-11-03 22:29:16 --> Loader Class Initialized
INFO - 2019-11-03 22:29:16 --> Helper loaded: url_helper
INFO - 2019-11-03 22:29:16 --> Helper loaded: common_helper
INFO - 2019-11-03 22:29:16 --> Helper loaded: language_helper
INFO - 2019-11-03 22:29:16 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:29:16 --> Helper loaded: email_helper
INFO - 2019-11-03 22:29:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:29:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:29:16 --> Parser Class Initialized
INFO - 2019-11-03 22:29:16 --> User Agent Class Initialized
INFO - 2019-11-03 22:29:16 --> Model Class Initialized
INFO - 2019-11-03 22:29:16 --> Database Driver Class Initialized
INFO - 2019-11-03 22:29:16 --> Model Class Initialized
DEBUG - 2019-11-03 22:29:16 --> Template Class Initialized
INFO - 2019-11-03 22:29:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:29:16 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:29:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:29:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:29:16 --> Encryption Class Initialized
INFO - 2019-11-03 22:29:16 --> Controller Class Initialized
DEBUG - 2019-11-03 22:29:16 --> setting MX_Controller Initialized
DEBUG - 2019-11-03 22:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-03 22:29:16 --> Model Class Initialized
INFO - 2019-11-03 22:29:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-03 22:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-03 22:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-03 22:29:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:29:16 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:29:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:29:17 --> Model Class Initialized
DEBUG - 2019-11-03 22:29:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:29:17 --> Model Class Initialized
DEBUG - 2019-11-03 22:29:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 22:29:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 22:29:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 22:29:17 --> Final output sent to browser
DEBUG - 2019-11-03 22:29:17 --> Total execution time: 0.7179
INFO - 2019-11-03 22:49:12 --> Config Class Initialized
INFO - 2019-11-03 22:49:12 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:49:12 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:49:12 --> Utf8 Class Initialized
INFO - 2019-11-03 22:49:12 --> URI Class Initialized
INFO - 2019-11-03 22:49:12 --> Router Class Initialized
INFO - 2019-11-03 22:49:12 --> Output Class Initialized
INFO - 2019-11-03 22:49:12 --> Security Class Initialized
DEBUG - 2019-11-03 22:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:49:12 --> CSRF cookie sent
INFO - 2019-11-03 22:49:12 --> Input Class Initialized
INFO - 2019-11-03 22:49:12 --> Language Class Initialized
INFO - 2019-11-03 22:49:12 --> Language Class Initialized
INFO - 2019-11-03 22:49:12 --> Config Class Initialized
INFO - 2019-11-03 22:49:12 --> Loader Class Initialized
INFO - 2019-11-03 22:49:12 --> Helper loaded: url_helper
INFO - 2019-11-03 22:49:12 --> Helper loaded: common_helper
INFO - 2019-11-03 22:49:12 --> Helper loaded: language_helper
INFO - 2019-11-03 22:49:12 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:49:12 --> Helper loaded: email_helper
INFO - 2019-11-03 22:49:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:49:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:49:12 --> Parser Class Initialized
INFO - 2019-11-03 22:49:12 --> User Agent Class Initialized
INFO - 2019-11-03 22:49:12 --> Model Class Initialized
INFO - 2019-11-03 22:49:12 --> Database Driver Class Initialized
INFO - 2019-11-03 22:49:12 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:12 --> Template Class Initialized
INFO - 2019-11-03 22:49:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:49:12 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:49:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:49:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:49:12 --> Encryption Class Initialized
INFO - 2019-11-03 22:49:12 --> Controller Class Initialized
DEBUG - 2019-11-03 22:49:12 --> package MX_Controller Initialized
DEBUG - 2019-11-03 22:49:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-03 22:49:12 --> Model Class Initialized
INFO - 2019-11-03 22:49:12 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 22:49:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:49:12 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:49:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:49:12 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:49:12 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-03 22:49:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-03 22:49:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 22:49:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 22:49:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 22:49:12 --> Final output sent to browser
DEBUG - 2019-11-03 22:49:12 --> Total execution time: 0.7094
INFO - 2019-11-03 22:49:18 --> Config Class Initialized
INFO - 2019-11-03 22:49:18 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:49:18 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:49:18 --> Utf8 Class Initialized
INFO - 2019-11-03 22:49:18 --> URI Class Initialized
INFO - 2019-11-03 22:49:18 --> Router Class Initialized
INFO - 2019-11-03 22:49:18 --> Output Class Initialized
INFO - 2019-11-03 22:49:18 --> Security Class Initialized
DEBUG - 2019-11-03 22:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:49:18 --> CSRF cookie sent
INFO - 2019-11-03 22:49:18 --> CSRF token verified
INFO - 2019-11-03 22:49:18 --> Input Class Initialized
INFO - 2019-11-03 22:49:18 --> Language Class Initialized
INFO - 2019-11-03 22:49:18 --> Language Class Initialized
INFO - 2019-11-03 22:49:18 --> Config Class Initialized
INFO - 2019-11-03 22:49:18 --> Loader Class Initialized
INFO - 2019-11-03 22:49:18 --> Helper loaded: url_helper
INFO - 2019-11-03 22:49:18 --> Helper loaded: common_helper
INFO - 2019-11-03 22:49:18 --> Helper loaded: language_helper
INFO - 2019-11-03 22:49:18 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:49:18 --> Helper loaded: email_helper
INFO - 2019-11-03 22:49:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:49:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:49:18 --> Parser Class Initialized
INFO - 2019-11-03 22:49:18 --> User Agent Class Initialized
INFO - 2019-11-03 22:49:18 --> Model Class Initialized
INFO - 2019-11-03 22:49:18 --> Database Driver Class Initialized
INFO - 2019-11-03 22:49:18 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:18 --> Template Class Initialized
INFO - 2019-11-03 22:49:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:49:18 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:49:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:49:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:49:18 --> Encryption Class Initialized
INFO - 2019-11-03 22:49:18 --> Controller Class Initialized
DEBUG - 2019-11-03 22:49:18 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:49:18 --> Model Class Initialized
INFO - 2019-11-03 22:49:18 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 22:49:18 --> Could not find the language line "dotpay"
DEBUG - 2019-11-03 22:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-03 22:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 22:49:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 22:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 22:49:18 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 22:49:18 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 22:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 22:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 22:49:18 --> Final output sent to browser
DEBUG - 2019-11-03 22:49:18 --> Total execution time: 0.7984
INFO - 2019-11-03 22:49:27 --> Config Class Initialized
INFO - 2019-11-03 22:49:27 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:49:27 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:49:27 --> Utf8 Class Initialized
INFO - 2019-11-03 22:49:27 --> URI Class Initialized
INFO - 2019-11-03 22:49:27 --> Router Class Initialized
INFO - 2019-11-03 22:49:27 --> Output Class Initialized
INFO - 2019-11-03 22:49:27 --> Security Class Initialized
DEBUG - 2019-11-03 22:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:49:27 --> CSRF cookie sent
INFO - 2019-11-03 22:49:27 --> CSRF token verified
INFO - 2019-11-03 22:49:27 --> Input Class Initialized
INFO - 2019-11-03 22:49:27 --> Language Class Initialized
INFO - 2019-11-03 22:49:27 --> Language Class Initialized
INFO - 2019-11-03 22:49:27 --> Config Class Initialized
INFO - 2019-11-03 22:49:27 --> Loader Class Initialized
INFO - 2019-11-03 22:49:27 --> Helper loaded: url_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: common_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: language_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: email_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:49:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:49:27 --> Parser Class Initialized
INFO - 2019-11-03 22:49:27 --> User Agent Class Initialized
INFO - 2019-11-03 22:49:27 --> Model Class Initialized
INFO - 2019-11-03 22:49:27 --> Database Driver Class Initialized
INFO - 2019-11-03 22:49:27 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:27 --> Template Class Initialized
INFO - 2019-11-03 22:49:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:49:27 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:49:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:49:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:49:27 --> Encryption Class Initialized
INFO - 2019-11-03 22:49:27 --> Controller Class Initialized
DEBUG - 2019-11-03 22:49:27 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:49:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:49:27 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 22:49:27 --> Final output sent to browser
DEBUG - 2019-11-03 22:49:27 --> Total execution time: 0.5388
INFO - 2019-11-03 22:49:27 --> Config Class Initialized
INFO - 2019-11-03 22:49:27 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:49:27 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:49:27 --> Utf8 Class Initialized
INFO - 2019-11-03 22:49:27 --> URI Class Initialized
INFO - 2019-11-03 22:49:27 --> Router Class Initialized
INFO - 2019-11-03 22:49:27 --> Output Class Initialized
INFO - 2019-11-03 22:49:27 --> Security Class Initialized
DEBUG - 2019-11-03 22:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:49:27 --> Input Class Initialized
INFO - 2019-11-03 22:49:27 --> Language Class Initialized
INFO - 2019-11-03 22:49:27 --> Language Class Initialized
INFO - 2019-11-03 22:49:27 --> Config Class Initialized
INFO - 2019-11-03 22:49:27 --> Loader Class Initialized
INFO - 2019-11-03 22:49:27 --> Helper loaded: url_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: common_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: language_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: email_helper
INFO - 2019-11-03 22:49:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:49:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:49:27 --> Parser Class Initialized
INFO - 2019-11-03 22:49:27 --> User Agent Class Initialized
INFO - 2019-11-03 22:49:27 --> Model Class Initialized
INFO - 2019-11-03 22:49:27 --> Database Driver Class Initialized
INFO - 2019-11-03 22:49:27 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:27 --> Template Class Initialized
INFO - 2019-11-03 22:49:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:49:27 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:49:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:49:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:49:28 --> Encryption Class Initialized
INFO - 2019-11-03 22:49:28 --> Controller Class Initialized
DEBUG - 2019-11-03 22:49:28 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:49:28 --> Model Class Initialized
DEBUG - 2019-11-03 22:49:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 22:49:28 --> Final output sent to browser
DEBUG - 2019-11-03 22:49:28 --> Total execution time: 0.5029
INFO - 2019-11-03 22:51:22 --> Config Class Initialized
INFO - 2019-11-03 22:51:22 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:51:23 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:51:23 --> Utf8 Class Initialized
INFO - 2019-11-03 22:51:23 --> URI Class Initialized
INFO - 2019-11-03 22:51:23 --> Router Class Initialized
INFO - 2019-11-03 22:51:23 --> Output Class Initialized
INFO - 2019-11-03 22:51:23 --> Security Class Initialized
DEBUG - 2019-11-03 22:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:51:23 --> CSRF cookie sent
INFO - 2019-11-03 22:51:23 --> CSRF token verified
INFO - 2019-11-03 22:51:23 --> Input Class Initialized
INFO - 2019-11-03 22:51:23 --> Language Class Initialized
INFO - 2019-11-03 22:51:23 --> Language Class Initialized
INFO - 2019-11-03 22:51:23 --> Config Class Initialized
INFO - 2019-11-03 22:51:23 --> Loader Class Initialized
INFO - 2019-11-03 22:51:23 --> Helper loaded: url_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: common_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: language_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: email_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:51:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:51:23 --> Parser Class Initialized
INFO - 2019-11-03 22:51:23 --> User Agent Class Initialized
INFO - 2019-11-03 22:51:23 --> Model Class Initialized
INFO - 2019-11-03 22:51:23 --> Database Driver Class Initialized
INFO - 2019-11-03 22:51:23 --> Model Class Initialized
DEBUG - 2019-11-03 22:51:23 --> Template Class Initialized
INFO - 2019-11-03 22:51:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:51:23 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:51:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:51:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:51:23 --> Encryption Class Initialized
INFO - 2019-11-03 22:51:23 --> Controller Class Initialized
DEBUG - 2019-11-03 22:51:23 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 22:51:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 22:51:23 --> Model Class Initialized
DEBUG - 2019-11-03 22:51:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 22:51:23 --> Final output sent to browser
DEBUG - 2019-11-03 22:51:23 --> Total execution time: 0.5284
INFO - 2019-11-03 22:51:23 --> Config Class Initialized
INFO - 2019-11-03 22:51:23 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:51:23 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:51:23 --> Utf8 Class Initialized
INFO - 2019-11-03 22:51:23 --> URI Class Initialized
INFO - 2019-11-03 22:51:23 --> Router Class Initialized
INFO - 2019-11-03 22:51:23 --> Output Class Initialized
INFO - 2019-11-03 22:51:23 --> Security Class Initialized
DEBUG - 2019-11-03 22:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:51:23 --> Input Class Initialized
INFO - 2019-11-03 22:51:23 --> Language Class Initialized
INFO - 2019-11-03 22:51:23 --> Language Class Initialized
INFO - 2019-11-03 22:51:23 --> Config Class Initialized
INFO - 2019-11-03 22:51:23 --> Loader Class Initialized
INFO - 2019-11-03 22:51:23 --> Helper loaded: url_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: common_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: language_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: email_helper
INFO - 2019-11-03 22:51:23 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:51:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:51:23 --> Parser Class Initialized
INFO - 2019-11-03 22:51:23 --> User Agent Class Initialized
INFO - 2019-11-03 22:51:23 --> Model Class Initialized
INFO - 2019-11-03 22:51:23 --> Database Driver Class Initialized
INFO - 2019-11-03 22:51:23 --> Model Class Initialized
DEBUG - 2019-11-03 22:51:23 --> Template Class Initialized
INFO - 2019-11-03 22:51:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:51:23 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:51:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:51:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:51:24 --> Encryption Class Initialized
INFO - 2019-11-03 22:51:24 --> Controller Class Initialized
DEBUG - 2019-11-03 22:51:24 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:51:24 --> Model Class Initialized
DEBUG - 2019-11-03 22:51:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 22:51:24 --> Final output sent to browser
DEBUG - 2019-11-03 22:51:24 --> Total execution time: 0.5371
INFO - 2019-11-03 22:52:02 --> Config Class Initialized
INFO - 2019-11-03 22:52:02 --> Hooks Class Initialized
DEBUG - 2019-11-03 22:52:02 --> UTF-8 Support Enabled
INFO - 2019-11-03 22:52:02 --> Utf8 Class Initialized
INFO - 2019-11-03 22:52:02 --> URI Class Initialized
INFO - 2019-11-03 22:52:02 --> Router Class Initialized
INFO - 2019-11-03 22:52:02 --> Output Class Initialized
INFO - 2019-11-03 22:52:02 --> Security Class Initialized
DEBUG - 2019-11-03 22:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 22:52:02 --> Input Class Initialized
INFO - 2019-11-03 22:52:02 --> Language Class Initialized
INFO - 2019-11-03 22:52:02 --> Language Class Initialized
INFO - 2019-11-03 22:52:02 --> Config Class Initialized
INFO - 2019-11-03 22:52:02 --> Loader Class Initialized
INFO - 2019-11-03 22:52:02 --> Helper loaded: url_helper
INFO - 2019-11-03 22:52:02 --> Helper loaded: common_helper
INFO - 2019-11-03 22:52:02 --> Helper loaded: language_helper
INFO - 2019-11-03 22:52:02 --> Helper loaded: cookie_helper
INFO - 2019-11-03 22:52:02 --> Helper loaded: email_helper
INFO - 2019-11-03 22:52:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 22:52:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 22:52:02 --> Parser Class Initialized
INFO - 2019-11-03 22:52:02 --> User Agent Class Initialized
INFO - 2019-11-03 22:52:02 --> Model Class Initialized
INFO - 2019-11-03 22:52:02 --> Database Driver Class Initialized
INFO - 2019-11-03 22:52:02 --> Model Class Initialized
DEBUG - 2019-11-03 22:52:02 --> Template Class Initialized
INFO - 2019-11-03 22:52:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 22:52:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 22:52:02 --> Pagination Class Initialized
DEBUG - 2019-11-03 22:52:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 22:52:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 22:52:02 --> Encryption Class Initialized
INFO - 2019-11-03 22:52:02 --> Controller Class Initialized
DEBUG - 2019-11-03 22:52:02 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 22:52:02 --> Model Class Initialized
INFO - 2019-11-03 23:09:54 --> Config Class Initialized
INFO - 2019-11-03 23:09:54 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:09:54 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:09:54 --> Utf8 Class Initialized
INFO - 2019-11-03 23:09:54 --> URI Class Initialized
INFO - 2019-11-03 23:09:54 --> Router Class Initialized
INFO - 2019-11-03 23:09:54 --> Output Class Initialized
INFO - 2019-11-03 23:09:54 --> Security Class Initialized
DEBUG - 2019-11-03 23:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:09:54 --> CSRF cookie sent
INFO - 2019-11-03 23:09:54 --> CSRF token verified
INFO - 2019-11-03 23:09:54 --> Input Class Initialized
INFO - 2019-11-03 23:09:54 --> Language Class Initialized
INFO - 2019-11-03 23:09:54 --> Language Class Initialized
INFO - 2019-11-03 23:09:54 --> Config Class Initialized
INFO - 2019-11-03 23:09:54 --> Loader Class Initialized
INFO - 2019-11-03 23:09:54 --> Helper loaded: url_helper
INFO - 2019-11-03 23:09:54 --> Helper loaded: common_helper
INFO - 2019-11-03 23:09:54 --> Helper loaded: language_helper
INFO - 2019-11-03 23:09:54 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:09:54 --> Helper loaded: email_helper
INFO - 2019-11-03 23:09:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:09:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:09:54 --> Parser Class Initialized
INFO - 2019-11-03 23:09:54 --> User Agent Class Initialized
INFO - 2019-11-03 23:09:54 --> Model Class Initialized
INFO - 2019-11-03 23:09:54 --> Database Driver Class Initialized
INFO - 2019-11-03 23:09:55 --> Model Class Initialized
DEBUG - 2019-11-03 23:09:55 --> Template Class Initialized
INFO - 2019-11-03 23:09:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:09:55 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:09:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:09:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:09:55 --> Encryption Class Initialized
INFO - 2019-11-03 23:09:55 --> Controller Class Initialized
DEBUG - 2019-11-03 23:09:55 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:09:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:09:55 --> Model Class Initialized
DEBUG - 2019-11-03 23:09:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 23:09:55 --> Final output sent to browser
DEBUG - 2019-11-03 23:09:55 --> Total execution time: 0.5587
INFO - 2019-11-03 23:09:55 --> Config Class Initialized
INFO - 2019-11-03 23:09:55 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:09:55 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:09:55 --> Utf8 Class Initialized
INFO - 2019-11-03 23:09:55 --> URI Class Initialized
INFO - 2019-11-03 23:09:55 --> Router Class Initialized
INFO - 2019-11-03 23:09:55 --> Output Class Initialized
INFO - 2019-11-03 23:09:55 --> Security Class Initialized
DEBUG - 2019-11-03 23:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:09:55 --> Input Class Initialized
INFO - 2019-11-03 23:09:55 --> Language Class Initialized
ERROR - 2019-11-03 23:09:55 --> Severity: error --> Exception: syntax error, unexpected ')' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\dotpay.php 113
INFO - 2019-11-03 23:10:16 --> Config Class Initialized
INFO - 2019-11-03 23:10:16 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:10:16 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:10:16 --> Utf8 Class Initialized
INFO - 2019-11-03 23:10:16 --> URI Class Initialized
INFO - 2019-11-03 23:10:16 --> Router Class Initialized
INFO - 2019-11-03 23:10:16 --> Output Class Initialized
INFO - 2019-11-03 23:10:16 --> Security Class Initialized
DEBUG - 2019-11-03 23:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:10:16 --> Input Class Initialized
INFO - 2019-11-03 23:10:16 --> Language Class Initialized
INFO - 2019-11-03 23:10:16 --> Language Class Initialized
INFO - 2019-11-03 23:10:16 --> Config Class Initialized
INFO - 2019-11-03 23:10:16 --> Loader Class Initialized
INFO - 2019-11-03 23:10:16 --> Helper loaded: url_helper
INFO - 2019-11-03 23:10:16 --> Helper loaded: common_helper
INFO - 2019-11-03 23:10:16 --> Helper loaded: language_helper
INFO - 2019-11-03 23:10:16 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:10:16 --> Helper loaded: email_helper
INFO - 2019-11-03 23:10:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:10:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:10:16 --> Parser Class Initialized
INFO - 2019-11-03 23:10:16 --> User Agent Class Initialized
INFO - 2019-11-03 23:10:16 --> Model Class Initialized
INFO - 2019-11-03 23:10:16 --> Database Driver Class Initialized
INFO - 2019-11-03 23:10:16 --> Model Class Initialized
DEBUG - 2019-11-03 23:10:16 --> Template Class Initialized
INFO - 2019-11-03 23:10:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:10:16 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:10:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:10:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:10:17 --> Encryption Class Initialized
INFO - 2019-11-03 23:10:17 --> Controller Class Initialized
DEBUG - 2019-11-03 23:10:17 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 23:10:17 --> Model Class Initialized
DEBUG - 2019-11-03 23:10:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 23:10:17 --> Final output sent to browser
DEBUG - 2019-11-03 23:10:17 --> Total execution time: 0.5159
INFO - 2019-11-03 23:10:33 --> Config Class Initialized
INFO - 2019-11-03 23:10:33 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:10:33 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:10:33 --> Utf8 Class Initialized
INFO - 2019-11-03 23:10:33 --> URI Class Initialized
INFO - 2019-11-03 23:10:33 --> Router Class Initialized
INFO - 2019-11-03 23:10:33 --> Output Class Initialized
INFO - 2019-11-03 23:10:33 --> Security Class Initialized
DEBUG - 2019-11-03 23:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:10:33 --> Input Class Initialized
INFO - 2019-11-03 23:10:33 --> Language Class Initialized
INFO - 2019-11-03 23:10:33 --> Language Class Initialized
INFO - 2019-11-03 23:10:33 --> Config Class Initialized
INFO - 2019-11-03 23:10:33 --> Loader Class Initialized
INFO - 2019-11-03 23:10:33 --> Helper loaded: url_helper
INFO - 2019-11-03 23:10:33 --> Helper loaded: common_helper
INFO - 2019-11-03 23:10:33 --> Helper loaded: language_helper
INFO - 2019-11-03 23:10:33 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:10:33 --> Helper loaded: email_helper
INFO - 2019-11-03 23:10:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:10:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:10:33 --> Parser Class Initialized
INFO - 2019-11-03 23:10:33 --> User Agent Class Initialized
INFO - 2019-11-03 23:10:33 --> Model Class Initialized
INFO - 2019-11-03 23:10:33 --> Database Driver Class Initialized
INFO - 2019-11-03 23:10:33 --> Model Class Initialized
DEBUG - 2019-11-03 23:10:33 --> Template Class Initialized
INFO - 2019-11-03 23:10:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:10:33 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:10:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:10:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:10:33 --> Encryption Class Initialized
INFO - 2019-11-03 23:10:33 --> Controller Class Initialized
DEBUG - 2019-11-03 23:10:33 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 23:10:33 --> Model Class Initialized
INFO - 2019-11-03 23:10:33 --> Config Class Initialized
INFO - 2019-11-03 23:10:33 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:10:33 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:10:33 --> Utf8 Class Initialized
INFO - 2019-11-03 23:10:33 --> URI Class Initialized
INFO - 2019-11-03 23:10:34 --> Router Class Initialized
INFO - 2019-11-03 23:10:34 --> Output Class Initialized
INFO - 2019-11-03 23:10:34 --> Security Class Initialized
DEBUG - 2019-11-03 23:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:10:34 --> CSRF cookie sent
INFO - 2019-11-03 23:10:34 --> Input Class Initialized
INFO - 2019-11-03 23:10:34 --> Language Class Initialized
INFO - 2019-11-03 23:10:34 --> Language Class Initialized
INFO - 2019-11-03 23:10:34 --> Config Class Initialized
INFO - 2019-11-03 23:10:34 --> Loader Class Initialized
INFO - 2019-11-03 23:10:34 --> Helper loaded: url_helper
INFO - 2019-11-03 23:10:34 --> Helper loaded: common_helper
INFO - 2019-11-03 23:10:34 --> Helper loaded: language_helper
INFO - 2019-11-03 23:10:34 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:10:34 --> Helper loaded: email_helper
INFO - 2019-11-03 23:10:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:10:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:10:34 --> Parser Class Initialized
INFO - 2019-11-03 23:10:34 --> User Agent Class Initialized
INFO - 2019-11-03 23:10:34 --> Model Class Initialized
INFO - 2019-11-03 23:10:34 --> Database Driver Class Initialized
INFO - 2019-11-03 23:10:34 --> Model Class Initialized
DEBUG - 2019-11-03 23:10:34 --> Template Class Initialized
INFO - 2019-11-03 23:10:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:10:34 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:10:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:10:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:10:34 --> Encryption Class Initialized
INFO - 2019-11-03 23:10:34 --> Controller Class Initialized
DEBUG - 2019-11-03 23:10:34 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:10:34 --> Model Class Initialized
INFO - 2019-11-03 23:10:34 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-11-03 23:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:10:34 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:10:34 --> Model Class Initialized
DEBUG - 2019-11-03 23:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:10:34 --> Model Class Initialized
DEBUG - 2019-11-03 23:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:10:34 --> Final output sent to browser
DEBUG - 2019-11-03 23:10:34 --> Total execution time: 0.6835
INFO - 2019-11-03 23:11:19 --> Config Class Initialized
INFO - 2019-11-03 23:11:19 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:11:19 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:11:19 --> Utf8 Class Initialized
INFO - 2019-11-03 23:11:19 --> URI Class Initialized
INFO - 2019-11-03 23:11:19 --> Router Class Initialized
INFO - 2019-11-03 23:11:19 --> Output Class Initialized
INFO - 2019-11-03 23:11:19 --> Security Class Initialized
DEBUG - 2019-11-03 23:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:11:19 --> CSRF cookie sent
INFO - 2019-11-03 23:11:19 --> Input Class Initialized
INFO - 2019-11-03 23:11:19 --> Language Class Initialized
INFO - 2019-11-03 23:11:19 --> Language Class Initialized
INFO - 2019-11-03 23:11:19 --> Config Class Initialized
INFO - 2019-11-03 23:11:19 --> Loader Class Initialized
INFO - 2019-11-03 23:11:19 --> Helper loaded: url_helper
INFO - 2019-11-03 23:11:19 --> Helper loaded: common_helper
INFO - 2019-11-03 23:11:19 --> Helper loaded: language_helper
INFO - 2019-11-03 23:11:19 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:11:19 --> Helper loaded: email_helper
INFO - 2019-11-03 23:11:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:11:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:11:19 --> Parser Class Initialized
INFO - 2019-11-03 23:11:19 --> User Agent Class Initialized
INFO - 2019-11-03 23:11:19 --> Model Class Initialized
INFO - 2019-11-03 23:11:19 --> Database Driver Class Initialized
INFO - 2019-11-03 23:11:19 --> Model Class Initialized
DEBUG - 2019-11-03 23:11:19 --> Template Class Initialized
INFO - 2019-11-03 23:11:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:11:19 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:11:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:11:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:11:19 --> Encryption Class Initialized
INFO - 2019-11-03 23:11:19 --> Controller Class Initialized
DEBUG - 2019-11-03 23:11:19 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:11:19 --> Model Class Initialized
INFO - 2019-11-03 23:11:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-11-03 23:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:11:19 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:11:19 --> Model Class Initialized
DEBUG - 2019-11-03 23:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:11:19 --> Model Class Initialized
DEBUG - 2019-11-03 23:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:11:20 --> Final output sent to browser
DEBUG - 2019-11-03 23:11:20 --> Total execution time: 0.8089
INFO - 2019-11-03 23:11:22 --> Config Class Initialized
INFO - 2019-11-03 23:11:22 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:11:22 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:11:22 --> Utf8 Class Initialized
INFO - 2019-11-03 23:11:22 --> URI Class Initialized
INFO - 2019-11-03 23:11:22 --> Router Class Initialized
INFO - 2019-11-03 23:11:22 --> Output Class Initialized
INFO - 2019-11-03 23:11:22 --> Security Class Initialized
DEBUG - 2019-11-03 23:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:11:23 --> CSRF cookie sent
INFO - 2019-11-03 23:11:23 --> Input Class Initialized
INFO - 2019-11-03 23:11:23 --> Language Class Initialized
INFO - 2019-11-03 23:11:23 --> Language Class Initialized
INFO - 2019-11-03 23:11:23 --> Config Class Initialized
INFO - 2019-11-03 23:11:23 --> Loader Class Initialized
INFO - 2019-11-03 23:11:23 --> Helper loaded: url_helper
INFO - 2019-11-03 23:11:23 --> Helper loaded: common_helper
INFO - 2019-11-03 23:11:23 --> Helper loaded: language_helper
INFO - 2019-11-03 23:11:23 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:11:23 --> Helper loaded: email_helper
INFO - 2019-11-03 23:11:23 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:11:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:11:23 --> Parser Class Initialized
INFO - 2019-11-03 23:11:23 --> User Agent Class Initialized
INFO - 2019-11-03 23:11:23 --> Model Class Initialized
INFO - 2019-11-03 23:11:23 --> Database Driver Class Initialized
INFO - 2019-11-03 23:11:23 --> Model Class Initialized
DEBUG - 2019-11-03 23:11:23 --> Template Class Initialized
INFO - 2019-11-03 23:11:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:11:23 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:11:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:11:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:11:23 --> Encryption Class Initialized
INFO - 2019-11-03 23:11:23 --> Controller Class Initialized
DEBUG - 2019-11-03 23:11:23 --> package MX_Controller Initialized
DEBUG - 2019-11-03 23:11:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-03 23:11:23 --> Model Class Initialized
INFO - 2019-11-03 23:11:23 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:11:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:11:23 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:11:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:11:23 --> Model Class Initialized
DEBUG - 2019-11-03 23:11:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:11:23 --> Model Class Initialized
DEBUG - 2019-11-03 23:11:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-03 23:11:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-03 23:11:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:11:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:11:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:11:23 --> Final output sent to browser
DEBUG - 2019-11-03 23:11:23 --> Total execution time: 0.8823
INFO - 2019-11-03 23:18:53 --> Config Class Initialized
INFO - 2019-11-03 23:18:53 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:18:54 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:18:54 --> Utf8 Class Initialized
INFO - 2019-11-03 23:18:54 --> URI Class Initialized
INFO - 2019-11-03 23:18:54 --> Router Class Initialized
INFO - 2019-11-03 23:18:54 --> Output Class Initialized
INFO - 2019-11-03 23:18:54 --> Security Class Initialized
DEBUG - 2019-11-03 23:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:18:54 --> CSRF cookie sent
INFO - 2019-11-03 23:18:54 --> CSRF token verified
INFO - 2019-11-03 23:18:54 --> Input Class Initialized
INFO - 2019-11-03 23:18:54 --> Language Class Initialized
INFO - 2019-11-03 23:18:54 --> Language Class Initialized
INFO - 2019-11-03 23:18:54 --> Config Class Initialized
INFO - 2019-11-03 23:18:54 --> Loader Class Initialized
INFO - 2019-11-03 23:18:54 --> Helper loaded: url_helper
INFO - 2019-11-03 23:18:54 --> Helper loaded: common_helper
INFO - 2019-11-03 23:18:54 --> Helper loaded: language_helper
INFO - 2019-11-03 23:18:54 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:18:54 --> Helper loaded: email_helper
INFO - 2019-11-03 23:18:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:18:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:18:54 --> Parser Class Initialized
INFO - 2019-11-03 23:18:54 --> User Agent Class Initialized
INFO - 2019-11-03 23:18:54 --> Model Class Initialized
INFO - 2019-11-03 23:18:54 --> Database Driver Class Initialized
INFO - 2019-11-03 23:18:54 --> Model Class Initialized
DEBUG - 2019-11-03 23:18:54 --> Template Class Initialized
INFO - 2019-11-03 23:18:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:18:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:18:54 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:18:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:18:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:18:54 --> Encryption Class Initialized
INFO - 2019-11-03 23:18:54 --> Controller Class Initialized
DEBUG - 2019-11-03 23:18:54 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:18:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:18:54 --> Model Class Initialized
INFO - 2019-11-03 23:18:54 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 23:18:54 --> Could not find the language line "dotpay"
DEBUG - 2019-11-03 23:18:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-03 23:18:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:18:54 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:18:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:18:54 --> Model Class Initialized
DEBUG - 2019-11-03 23:18:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:18:54 --> Model Class Initialized
DEBUG - 2019-11-03 23:18:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:18:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:18:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:18:54 --> Final output sent to browser
DEBUG - 2019-11-03 23:18:54 --> Total execution time: 0.7115
INFO - 2019-11-03 23:19:04 --> Config Class Initialized
INFO - 2019-11-03 23:19:04 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:19:04 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:19:04 --> Utf8 Class Initialized
INFO - 2019-11-03 23:19:04 --> URI Class Initialized
INFO - 2019-11-03 23:19:04 --> Router Class Initialized
INFO - 2019-11-03 23:19:04 --> Output Class Initialized
INFO - 2019-11-03 23:19:04 --> Security Class Initialized
DEBUG - 2019-11-03 23:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:19:04 --> CSRF cookie sent
INFO - 2019-11-03 23:19:04 --> CSRF token verified
INFO - 2019-11-03 23:19:05 --> Input Class Initialized
INFO - 2019-11-03 23:19:05 --> Language Class Initialized
INFO - 2019-11-03 23:19:05 --> Language Class Initialized
INFO - 2019-11-03 23:19:05 --> Config Class Initialized
INFO - 2019-11-03 23:19:05 --> Loader Class Initialized
INFO - 2019-11-03 23:19:05 --> Helper loaded: url_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: common_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: language_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: email_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:19:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:19:05 --> Parser Class Initialized
INFO - 2019-11-03 23:19:05 --> User Agent Class Initialized
INFO - 2019-11-03 23:19:05 --> Model Class Initialized
INFO - 2019-11-03 23:19:05 --> Database Driver Class Initialized
INFO - 2019-11-03 23:19:05 --> Model Class Initialized
DEBUG - 2019-11-03 23:19:05 --> Template Class Initialized
INFO - 2019-11-03 23:19:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:19:05 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:19:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:19:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:19:05 --> Encryption Class Initialized
INFO - 2019-11-03 23:19:05 --> Controller Class Initialized
DEBUG - 2019-11-03 23:19:05 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:19:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:19:05 --> Model Class Initialized
DEBUG - 2019-11-03 23:19:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 23:19:05 --> Final output sent to browser
DEBUG - 2019-11-03 23:19:05 --> Total execution time: 0.5772
INFO - 2019-11-03 23:19:05 --> Config Class Initialized
INFO - 2019-11-03 23:19:05 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:19:05 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:19:05 --> Utf8 Class Initialized
INFO - 2019-11-03 23:19:05 --> URI Class Initialized
INFO - 2019-11-03 23:19:05 --> Router Class Initialized
INFO - 2019-11-03 23:19:05 --> Output Class Initialized
INFO - 2019-11-03 23:19:05 --> Security Class Initialized
DEBUG - 2019-11-03 23:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:19:05 --> Input Class Initialized
INFO - 2019-11-03 23:19:05 --> Language Class Initialized
INFO - 2019-11-03 23:19:05 --> Language Class Initialized
INFO - 2019-11-03 23:19:05 --> Config Class Initialized
INFO - 2019-11-03 23:19:05 --> Loader Class Initialized
INFO - 2019-11-03 23:19:05 --> Helper loaded: url_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: common_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: language_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: email_helper
INFO - 2019-11-03 23:19:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:19:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:19:05 --> Parser Class Initialized
INFO - 2019-11-03 23:19:05 --> User Agent Class Initialized
INFO - 2019-11-03 23:19:05 --> Model Class Initialized
INFO - 2019-11-03 23:19:05 --> Database Driver Class Initialized
INFO - 2019-11-03 23:19:05 --> Model Class Initialized
DEBUG - 2019-11-03 23:19:05 --> Template Class Initialized
INFO - 2019-11-03 23:19:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:19:05 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:19:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:19:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:19:05 --> Encryption Class Initialized
INFO - 2019-11-03 23:19:05 --> Controller Class Initialized
DEBUG - 2019-11-03 23:19:05 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 23:19:05 --> Model Class Initialized
DEBUG - 2019-11-03 23:19:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 23:19:05 --> Final output sent to browser
DEBUG - 2019-11-03 23:19:06 --> Total execution time: 0.5417
INFO - 2019-11-03 23:19:21 --> Config Class Initialized
INFO - 2019-11-03 23:19:21 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:19:21 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:19:21 --> Utf8 Class Initialized
INFO - 2019-11-03 23:19:21 --> URI Class Initialized
INFO - 2019-11-03 23:19:21 --> Router Class Initialized
INFO - 2019-11-03 23:19:21 --> Output Class Initialized
INFO - 2019-11-03 23:19:21 --> Security Class Initialized
DEBUG - 2019-11-03 23:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:19:21 --> Input Class Initialized
INFO - 2019-11-03 23:19:21 --> Language Class Initialized
INFO - 2019-11-03 23:19:21 --> Language Class Initialized
INFO - 2019-11-03 23:19:21 --> Config Class Initialized
INFO - 2019-11-03 23:19:21 --> Loader Class Initialized
INFO - 2019-11-03 23:19:21 --> Helper loaded: url_helper
INFO - 2019-11-03 23:19:21 --> Helper loaded: common_helper
INFO - 2019-11-03 23:19:21 --> Helper loaded: language_helper
INFO - 2019-11-03 23:19:21 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:19:21 --> Helper loaded: email_helper
INFO - 2019-11-03 23:19:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:19:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:19:21 --> Parser Class Initialized
INFO - 2019-11-03 23:19:21 --> User Agent Class Initialized
INFO - 2019-11-03 23:19:21 --> Model Class Initialized
INFO - 2019-11-03 23:19:21 --> Database Driver Class Initialized
INFO - 2019-11-03 23:19:21 --> Model Class Initialized
DEBUG - 2019-11-03 23:19:21 --> Template Class Initialized
INFO - 2019-11-03 23:19:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:19:21 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:19:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:19:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:19:21 --> Encryption Class Initialized
INFO - 2019-11-03 23:19:21 --> Controller Class Initialized
DEBUG - 2019-11-03 23:19:21 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 23:19:21 --> Model Class Initialized
INFO - 2019-11-03 23:20:52 --> Config Class Initialized
INFO - 2019-11-03 23:20:52 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:20:52 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:20:52 --> Utf8 Class Initialized
INFO - 2019-11-03 23:20:52 --> URI Class Initialized
INFO - 2019-11-03 23:20:52 --> Router Class Initialized
INFO - 2019-11-03 23:20:52 --> Output Class Initialized
INFO - 2019-11-03 23:20:52 --> Security Class Initialized
DEBUG - 2019-11-03 23:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:20:52 --> Input Class Initialized
INFO - 2019-11-03 23:20:52 --> Language Class Initialized
INFO - 2019-11-03 23:20:52 --> Language Class Initialized
INFO - 2019-11-03 23:20:52 --> Config Class Initialized
INFO - 2019-11-03 23:20:52 --> Loader Class Initialized
INFO - 2019-11-03 23:20:52 --> Helper loaded: url_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: common_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: language_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: email_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:20:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:20:52 --> Parser Class Initialized
INFO - 2019-11-03 23:20:52 --> User Agent Class Initialized
INFO - 2019-11-03 23:20:52 --> Model Class Initialized
INFO - 2019-11-03 23:20:52 --> Database Driver Class Initialized
INFO - 2019-11-03 23:20:52 --> Model Class Initialized
DEBUG - 2019-11-03 23:20:52 --> Template Class Initialized
INFO - 2019-11-03 23:20:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:20:52 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:20:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:20:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:20:52 --> Encryption Class Initialized
INFO - 2019-11-03 23:20:52 --> Controller Class Initialized
DEBUG - 2019-11-03 23:20:52 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 23:20:52 --> Model Class Initialized
INFO - 2019-11-03 23:20:52 --> Config Class Initialized
INFO - 2019-11-03 23:20:52 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:20:52 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:20:52 --> Utf8 Class Initialized
INFO - 2019-11-03 23:20:52 --> URI Class Initialized
DEBUG - 2019-11-03 23:20:52 --> No URI present. Default controller set.
INFO - 2019-11-03 23:20:52 --> Router Class Initialized
INFO - 2019-11-03 23:20:52 --> Output Class Initialized
INFO - 2019-11-03 23:20:52 --> Security Class Initialized
DEBUG - 2019-11-03 23:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:20:52 --> CSRF cookie sent
INFO - 2019-11-03 23:20:52 --> Input Class Initialized
INFO - 2019-11-03 23:20:52 --> Language Class Initialized
INFO - 2019-11-03 23:20:52 --> Language Class Initialized
INFO - 2019-11-03 23:20:52 --> Config Class Initialized
INFO - 2019-11-03 23:20:52 --> Loader Class Initialized
INFO - 2019-11-03 23:20:52 --> Helper loaded: url_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: common_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: language_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: email_helper
INFO - 2019-11-03 23:20:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:20:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:20:53 --> Parser Class Initialized
INFO - 2019-11-03 23:20:53 --> User Agent Class Initialized
INFO - 2019-11-03 23:20:53 --> Model Class Initialized
INFO - 2019-11-03 23:20:53 --> Database Driver Class Initialized
INFO - 2019-11-03 23:20:53 --> Model Class Initialized
DEBUG - 2019-11-03 23:20:53 --> Template Class Initialized
INFO - 2019-11-03 23:20:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:20:53 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:20:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:20:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:20:53 --> Encryption Class Initialized
DEBUG - 2019-11-03 23:20:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-03 23:20:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-03 23:20:53 --> Controller Class Initialized
DEBUG - 2019-11-03 23:20:53 --> pergo MX_Controller Initialized
DEBUG - 2019-11-03 23:20:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-03 23:20:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-03 23:20:53 --> Model Class Initialized
INFO - 2019-11-03 23:20:53 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:20:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-03 23:20:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-03 23:20:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-03 23:20:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-03 23:20:53 --> Final output sent to browser
DEBUG - 2019-11-03 23:20:53 --> Total execution time: 0.6880
INFO - 2019-11-03 23:20:57 --> Config Class Initialized
INFO - 2019-11-03 23:20:57 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:20:57 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:20:57 --> Utf8 Class Initialized
INFO - 2019-11-03 23:20:57 --> URI Class Initialized
INFO - 2019-11-03 23:20:57 --> Router Class Initialized
INFO - 2019-11-03 23:20:57 --> Output Class Initialized
INFO - 2019-11-03 23:20:57 --> Security Class Initialized
DEBUG - 2019-11-03 23:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:20:57 --> CSRF cookie sent
INFO - 2019-11-03 23:20:57 --> Input Class Initialized
INFO - 2019-11-03 23:20:57 --> Language Class Initialized
INFO - 2019-11-03 23:20:57 --> Language Class Initialized
INFO - 2019-11-03 23:20:57 --> Config Class Initialized
INFO - 2019-11-03 23:20:57 --> Loader Class Initialized
INFO - 2019-11-03 23:20:57 --> Helper loaded: url_helper
INFO - 2019-11-03 23:20:57 --> Helper loaded: common_helper
INFO - 2019-11-03 23:20:57 --> Helper loaded: language_helper
INFO - 2019-11-03 23:20:57 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:20:57 --> Helper loaded: email_helper
INFO - 2019-11-03 23:20:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:20:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:20:57 --> Parser Class Initialized
INFO - 2019-11-03 23:20:57 --> User Agent Class Initialized
INFO - 2019-11-03 23:20:57 --> Model Class Initialized
INFO - 2019-11-03 23:20:57 --> Database Driver Class Initialized
INFO - 2019-11-03 23:20:57 --> Model Class Initialized
DEBUG - 2019-11-03 23:20:58 --> Template Class Initialized
INFO - 2019-11-03 23:20:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:20:58 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:20:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:20:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:20:58 --> Encryption Class Initialized
INFO - 2019-11-03 23:20:58 --> Controller Class Initialized
DEBUG - 2019-11-03 23:20:58 --> package MX_Controller Initialized
DEBUG - 2019-11-03 23:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-03 23:20:58 --> Model Class Initialized
INFO - 2019-11-03 23:20:58 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:20:58 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:20:58 --> Model Class Initialized
DEBUG - 2019-11-03 23:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:20:58 --> Model Class Initialized
DEBUG - 2019-11-03 23:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-03 23:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-03 23:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:20:58 --> Final output sent to browser
DEBUG - 2019-11-03 23:20:58 --> Total execution time: 0.8993
INFO - 2019-11-03 23:21:01 --> Config Class Initialized
INFO - 2019-11-03 23:21:01 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:21:01 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:21:01 --> Utf8 Class Initialized
INFO - 2019-11-03 23:21:01 --> URI Class Initialized
INFO - 2019-11-03 23:21:01 --> Router Class Initialized
INFO - 2019-11-03 23:21:01 --> Output Class Initialized
INFO - 2019-11-03 23:21:01 --> Security Class Initialized
DEBUG - 2019-11-03 23:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:21:01 --> CSRF cookie sent
INFO - 2019-11-03 23:21:01 --> CSRF token verified
INFO - 2019-11-03 23:21:01 --> Input Class Initialized
INFO - 2019-11-03 23:21:01 --> Language Class Initialized
INFO - 2019-11-03 23:21:01 --> Language Class Initialized
INFO - 2019-11-03 23:21:01 --> Config Class Initialized
INFO - 2019-11-03 23:21:01 --> Loader Class Initialized
INFO - 2019-11-03 23:21:01 --> Helper loaded: url_helper
INFO - 2019-11-03 23:21:01 --> Helper loaded: common_helper
INFO - 2019-11-03 23:21:01 --> Helper loaded: language_helper
INFO - 2019-11-03 23:21:01 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:21:01 --> Helper loaded: email_helper
INFO - 2019-11-03 23:21:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:21:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:21:01 --> Parser Class Initialized
INFO - 2019-11-03 23:21:01 --> User Agent Class Initialized
INFO - 2019-11-03 23:21:01 --> Model Class Initialized
INFO - 2019-11-03 23:21:01 --> Database Driver Class Initialized
INFO - 2019-11-03 23:21:01 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:01 --> Template Class Initialized
INFO - 2019-11-03 23:21:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:21:01 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:21:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:21:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:21:01 --> Encryption Class Initialized
INFO - 2019-11-03 23:21:01 --> Controller Class Initialized
DEBUG - 2019-11-03 23:21:01 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:21:01 --> Model Class Initialized
INFO - 2019-11-03 23:21:01 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 23:21:01 --> Could not find the language line "dotpay"
DEBUG - 2019-11-03 23:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-03 23:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:21:01 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:21:01 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:21:01 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:21:01 --> Final output sent to browser
DEBUG - 2019-11-03 23:21:01 --> Total execution time: 0.8361
INFO - 2019-11-03 23:21:08 --> Config Class Initialized
INFO - 2019-11-03 23:21:08 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:21:08 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:21:08 --> Utf8 Class Initialized
INFO - 2019-11-03 23:21:08 --> URI Class Initialized
INFO - 2019-11-03 23:21:08 --> Router Class Initialized
INFO - 2019-11-03 23:21:08 --> Output Class Initialized
INFO - 2019-11-03 23:21:09 --> Security Class Initialized
DEBUG - 2019-11-03 23:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:21:09 --> CSRF cookie sent
INFO - 2019-11-03 23:21:09 --> CSRF token verified
INFO - 2019-11-03 23:21:09 --> Input Class Initialized
INFO - 2019-11-03 23:21:09 --> Language Class Initialized
INFO - 2019-11-03 23:21:09 --> Language Class Initialized
INFO - 2019-11-03 23:21:09 --> Config Class Initialized
INFO - 2019-11-03 23:21:09 --> Loader Class Initialized
INFO - 2019-11-03 23:21:09 --> Helper loaded: url_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: common_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: language_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: email_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:21:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:21:09 --> Parser Class Initialized
INFO - 2019-11-03 23:21:09 --> User Agent Class Initialized
INFO - 2019-11-03 23:21:09 --> Model Class Initialized
INFO - 2019-11-03 23:21:09 --> Database Driver Class Initialized
INFO - 2019-11-03 23:21:09 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:09 --> Template Class Initialized
INFO - 2019-11-03 23:21:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:21:09 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:21:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:21:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:21:09 --> Encryption Class Initialized
INFO - 2019-11-03 23:21:09 --> Controller Class Initialized
DEBUG - 2019-11-03 23:21:09 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:21:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:21:09 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 23:21:09 --> Final output sent to browser
DEBUG - 2019-11-03 23:21:09 --> Total execution time: 0.5366
INFO - 2019-11-03 23:21:09 --> Config Class Initialized
INFO - 2019-11-03 23:21:09 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:21:09 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:21:09 --> Utf8 Class Initialized
INFO - 2019-11-03 23:21:09 --> URI Class Initialized
INFO - 2019-11-03 23:21:09 --> Router Class Initialized
INFO - 2019-11-03 23:21:09 --> Output Class Initialized
INFO - 2019-11-03 23:21:09 --> Security Class Initialized
DEBUG - 2019-11-03 23:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:21:09 --> Input Class Initialized
INFO - 2019-11-03 23:21:09 --> Language Class Initialized
INFO - 2019-11-03 23:21:09 --> Language Class Initialized
INFO - 2019-11-03 23:21:09 --> Config Class Initialized
INFO - 2019-11-03 23:21:09 --> Loader Class Initialized
INFO - 2019-11-03 23:21:09 --> Helper loaded: url_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: common_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: language_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: email_helper
INFO - 2019-11-03 23:21:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:21:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:21:09 --> Parser Class Initialized
INFO - 2019-11-03 23:21:09 --> User Agent Class Initialized
INFO - 2019-11-03 23:21:09 --> Model Class Initialized
INFO - 2019-11-03 23:21:09 --> Database Driver Class Initialized
INFO - 2019-11-03 23:21:09 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:09 --> Template Class Initialized
INFO - 2019-11-03 23:21:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:21:09 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:21:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:21:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:21:09 --> Encryption Class Initialized
INFO - 2019-11-03 23:21:09 --> Controller Class Initialized
DEBUG - 2019-11-03 23:21:09 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 23:21:09 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 23:21:10 --> Final output sent to browser
DEBUG - 2019-11-03 23:21:10 --> Total execution time: 0.5227
INFO - 2019-11-03 23:21:29 --> Config Class Initialized
INFO - 2019-11-03 23:21:29 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:21:29 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:21:29 --> Utf8 Class Initialized
INFO - 2019-11-03 23:21:29 --> URI Class Initialized
INFO - 2019-11-03 23:21:29 --> Router Class Initialized
INFO - 2019-11-03 23:21:29 --> Output Class Initialized
INFO - 2019-11-03 23:21:29 --> Security Class Initialized
DEBUG - 2019-11-03 23:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:21:29 --> Input Class Initialized
INFO - 2019-11-03 23:21:29 --> Language Class Initialized
INFO - 2019-11-03 23:21:29 --> Language Class Initialized
INFO - 2019-11-03 23:21:29 --> Config Class Initialized
INFO - 2019-11-03 23:21:29 --> Loader Class Initialized
INFO - 2019-11-03 23:21:29 --> Helper loaded: url_helper
INFO - 2019-11-03 23:21:29 --> Helper loaded: common_helper
INFO - 2019-11-03 23:21:29 --> Helper loaded: language_helper
INFO - 2019-11-03 23:21:29 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:21:29 --> Helper loaded: email_helper
INFO - 2019-11-03 23:21:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:21:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:21:29 --> Parser Class Initialized
INFO - 2019-11-03 23:21:29 --> User Agent Class Initialized
INFO - 2019-11-03 23:21:29 --> Model Class Initialized
INFO - 2019-11-03 23:21:29 --> Database Driver Class Initialized
INFO - 2019-11-03 23:21:29 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:29 --> Template Class Initialized
INFO - 2019-11-03 23:21:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:21:29 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:21:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:21:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:21:29 --> Encryption Class Initialized
INFO - 2019-11-03 23:21:29 --> Controller Class Initialized
DEBUG - 2019-11-03 23:21:29 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 23:21:29 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:29 --> orders MX_Controller Initialized
ERROR - 2019-11-03 23:21:29 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\dotpay.php 129
ERROR - 2019-11-03 23:21:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\dotpay.php 129
INFO - 2019-11-03 23:21:29 --> Config Class Initialized
INFO - 2019-11-03 23:21:29 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:21:29 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:21:29 --> Utf8 Class Initialized
INFO - 2019-11-03 23:21:29 --> URI Class Initialized
DEBUG - 2019-11-03 23:21:29 --> No URI present. Default controller set.
INFO - 2019-11-03 23:21:29 --> Router Class Initialized
INFO - 2019-11-03 23:21:29 --> Output Class Initialized
INFO - 2019-11-03 23:21:29 --> Security Class Initialized
DEBUG - 2019-11-03 23:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:21:30 --> CSRF cookie sent
INFO - 2019-11-03 23:21:30 --> Input Class Initialized
INFO - 2019-11-03 23:21:30 --> Language Class Initialized
INFO - 2019-11-03 23:21:30 --> Language Class Initialized
INFO - 2019-11-03 23:21:30 --> Config Class Initialized
INFO - 2019-11-03 23:21:30 --> Loader Class Initialized
INFO - 2019-11-03 23:21:30 --> Helper loaded: url_helper
INFO - 2019-11-03 23:21:30 --> Helper loaded: common_helper
INFO - 2019-11-03 23:21:30 --> Helper loaded: language_helper
INFO - 2019-11-03 23:21:30 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:21:30 --> Helper loaded: email_helper
INFO - 2019-11-03 23:21:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:21:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:21:30 --> Parser Class Initialized
INFO - 2019-11-03 23:21:30 --> User Agent Class Initialized
INFO - 2019-11-03 23:21:30 --> Model Class Initialized
INFO - 2019-11-03 23:21:30 --> Database Driver Class Initialized
INFO - 2019-11-03 23:21:30 --> Model Class Initialized
DEBUG - 2019-11-03 23:21:30 --> Template Class Initialized
INFO - 2019-11-03 23:21:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:21:30 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:21:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:21:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:21:30 --> Encryption Class Initialized
DEBUG - 2019-11-03 23:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-03 23:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-03 23:21:30 --> Controller Class Initialized
DEBUG - 2019-11-03 23:21:30 --> pergo MX_Controller Initialized
DEBUG - 2019-11-03 23:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-03 23:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-03 23:21:30 --> Model Class Initialized
INFO - 2019-11-03 23:21:30 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-03 23:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-03 23:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-03 23:21:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-03 23:21:30 --> Final output sent to browser
DEBUG - 2019-11-03 23:21:30 --> Total execution time: 0.6659
INFO - 2019-11-03 23:24:03 --> Config Class Initialized
INFO - 2019-11-03 23:24:03 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:24:03 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:24:03 --> Utf8 Class Initialized
INFO - 2019-11-03 23:24:03 --> URI Class Initialized
INFO - 2019-11-03 23:24:03 --> Router Class Initialized
INFO - 2019-11-03 23:24:03 --> Output Class Initialized
INFO - 2019-11-03 23:24:03 --> Security Class Initialized
DEBUG - 2019-11-03 23:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:24:03 --> CSRF cookie sent
INFO - 2019-11-03 23:24:03 --> Input Class Initialized
INFO - 2019-11-03 23:24:03 --> Language Class Initialized
INFO - 2019-11-03 23:24:03 --> Language Class Initialized
INFO - 2019-11-03 23:24:03 --> Config Class Initialized
INFO - 2019-11-03 23:24:03 --> Loader Class Initialized
INFO - 2019-11-03 23:24:03 --> Helper loaded: url_helper
INFO - 2019-11-03 23:24:03 --> Helper loaded: common_helper
INFO - 2019-11-03 23:24:03 --> Helper loaded: language_helper
INFO - 2019-11-03 23:24:03 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:24:03 --> Helper loaded: email_helper
INFO - 2019-11-03 23:24:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:24:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:24:03 --> Parser Class Initialized
INFO - 2019-11-03 23:24:03 --> User Agent Class Initialized
INFO - 2019-11-03 23:24:03 --> Model Class Initialized
INFO - 2019-11-03 23:24:03 --> Database Driver Class Initialized
INFO - 2019-11-03 23:24:03 --> Model Class Initialized
DEBUG - 2019-11-03 23:24:03 --> Template Class Initialized
INFO - 2019-11-03 23:24:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:24:03 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:24:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:24:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:24:03 --> Encryption Class Initialized
INFO - 2019-11-03 23:24:03 --> Controller Class Initialized
DEBUG - 2019-11-03 23:24:03 --> transactions MX_Controller Initialized
DEBUG - 2019-11-03 23:24:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-03 23:24:03 --> Model Class Initialized
ERROR - 2019-11-03 23:24:03 --> Could not find the language line "order_id"
INFO - 2019-11-03 23:24:03 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:24:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-03 23:24:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:24:04 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:24:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:24:04 --> Model Class Initialized
DEBUG - 2019-11-03 23:24:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:24:04 --> Model Class Initialized
DEBUG - 2019-11-03 23:24:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 23:24:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 23:24:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 23:24:04 --> Final output sent to browser
DEBUG - 2019-11-03 23:24:04 --> Total execution time: 0.8539
INFO - 2019-11-03 23:24:12 --> Config Class Initialized
INFO - 2019-11-03 23:24:12 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:24:12 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:24:12 --> Utf8 Class Initialized
INFO - 2019-11-03 23:24:12 --> URI Class Initialized
INFO - 2019-11-03 23:24:12 --> Router Class Initialized
INFO - 2019-11-03 23:24:12 --> Output Class Initialized
INFO - 2019-11-03 23:24:12 --> Security Class Initialized
DEBUG - 2019-11-03 23:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:24:12 --> CSRF cookie sent
INFO - 2019-11-03 23:24:12 --> Input Class Initialized
INFO - 2019-11-03 23:24:12 --> Language Class Initialized
INFO - 2019-11-03 23:24:12 --> Language Class Initialized
INFO - 2019-11-03 23:24:12 --> Config Class Initialized
INFO - 2019-11-03 23:24:12 --> Loader Class Initialized
INFO - 2019-11-03 23:24:12 --> Helper loaded: url_helper
INFO - 2019-11-03 23:24:12 --> Helper loaded: common_helper
INFO - 2019-11-03 23:24:12 --> Helper loaded: language_helper
INFO - 2019-11-03 23:24:12 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:24:12 --> Helper loaded: email_helper
INFO - 2019-11-03 23:24:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:24:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:24:12 --> Parser Class Initialized
INFO - 2019-11-03 23:24:12 --> User Agent Class Initialized
INFO - 2019-11-03 23:24:12 --> Model Class Initialized
INFO - 2019-11-03 23:24:12 --> Database Driver Class Initialized
INFO - 2019-11-03 23:24:12 --> Model Class Initialized
DEBUG - 2019-11-03 23:24:12 --> Template Class Initialized
INFO - 2019-11-03 23:24:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:24:12 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:24:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:24:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:24:12 --> Encryption Class Initialized
INFO - 2019-11-03 23:24:12 --> Controller Class Initialized
DEBUG - 2019-11-03 23:24:12 --> order MX_Controller Initialized
DEBUG - 2019-11-03 23:24:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-03 23:24:12 --> Model Class Initialized
ERROR - 2019-11-03 23:24:12 --> Could not find the language line "order_id"
ERROR - 2019-11-03 23:24:12 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-03 23:24:12 --> Could not find the language line "order_id"
ERROR - 2019-11-03 23:24:12 --> Could not find the language line "order_basic_details"
INFO - 2019-11-03 23:24:12 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 23:24:12 --> Could not find the language line "Awaiting"
ERROR - 2019-11-03 23:24:12 --> Could not find the language line "Pending"
ERROR - 2019-11-03 23:24:12 --> Could not find the language line "Pending"
ERROR - 2019-11-03 23:24:13 --> Could not find the language line "Awaiting"
ERROR - 2019-11-03 23:24:13 --> Could not find the language line "Awaiting"
ERROR - 2019-11-03 23:24:13 --> Could not find the language line "Pending"
ERROR - 2019-11-03 23:24:13 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-03 23:24:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-03 23:24:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:24:13 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:24:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:24:13 --> Model Class Initialized
DEBUG - 2019-11-03 23:24:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:24:13 --> Model Class Initialized
DEBUG - 2019-11-03 23:24:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-03 23:24:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-03 23:24:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-03 23:24:13 --> Final output sent to browser
DEBUG - 2019-11-03 23:24:13 --> Total execution time: 1.0591
INFO - 2019-11-03 23:30:18 --> Config Class Initialized
INFO - 2019-11-03 23:30:18 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:30:18 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:30:18 --> Utf8 Class Initialized
INFO - 2019-11-03 23:30:18 --> URI Class Initialized
INFO - 2019-11-03 23:30:18 --> Router Class Initialized
INFO - 2019-11-03 23:30:18 --> Output Class Initialized
INFO - 2019-11-03 23:30:18 --> Security Class Initialized
DEBUG - 2019-11-03 23:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:30:18 --> CSRF cookie sent
INFO - 2019-11-03 23:30:18 --> Input Class Initialized
INFO - 2019-11-03 23:30:18 --> Language Class Initialized
INFO - 2019-11-03 23:30:18 --> Language Class Initialized
INFO - 2019-11-03 23:30:18 --> Config Class Initialized
INFO - 2019-11-03 23:30:18 --> Loader Class Initialized
INFO - 2019-11-03 23:30:18 --> Helper loaded: url_helper
INFO - 2019-11-03 23:30:18 --> Helper loaded: common_helper
INFO - 2019-11-03 23:30:18 --> Helper loaded: language_helper
INFO - 2019-11-03 23:30:18 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:30:18 --> Helper loaded: email_helper
INFO - 2019-11-03 23:30:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:30:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:30:18 --> Parser Class Initialized
INFO - 2019-11-03 23:30:19 --> User Agent Class Initialized
INFO - 2019-11-03 23:30:19 --> Model Class Initialized
INFO - 2019-11-03 23:30:19 --> Database Driver Class Initialized
INFO - 2019-11-03 23:30:19 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:19 --> Template Class Initialized
INFO - 2019-11-03 23:30:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:30:19 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:30:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:30:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:30:19 --> Encryption Class Initialized
INFO - 2019-11-03 23:30:19 --> Controller Class Initialized
DEBUG - 2019-11-03 23:30:19 --> package MX_Controller Initialized
DEBUG - 2019-11-03 23:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-03 23:30:19 --> Model Class Initialized
INFO - 2019-11-03 23:30:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:30:19 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:30:19 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:30:19 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-03 23:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-03 23:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:30:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:30:19 --> Final output sent to browser
DEBUG - 2019-11-03 23:30:19 --> Total execution time: 0.8480
INFO - 2019-11-03 23:30:24 --> Config Class Initialized
INFO - 2019-11-03 23:30:24 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:30:24 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:30:24 --> Utf8 Class Initialized
INFO - 2019-11-03 23:30:24 --> URI Class Initialized
INFO - 2019-11-03 23:30:24 --> Router Class Initialized
INFO - 2019-11-03 23:30:24 --> Output Class Initialized
INFO - 2019-11-03 23:30:24 --> Security Class Initialized
DEBUG - 2019-11-03 23:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:30:24 --> CSRF cookie sent
INFO - 2019-11-03 23:30:24 --> Input Class Initialized
INFO - 2019-11-03 23:30:24 --> Language Class Initialized
INFO - 2019-11-03 23:30:24 --> Language Class Initialized
INFO - 2019-11-03 23:30:24 --> Config Class Initialized
INFO - 2019-11-03 23:30:24 --> Loader Class Initialized
INFO - 2019-11-03 23:30:24 --> Helper loaded: url_helper
INFO - 2019-11-03 23:30:24 --> Helper loaded: common_helper
INFO - 2019-11-03 23:30:24 --> Helper loaded: language_helper
INFO - 2019-11-03 23:30:24 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:30:24 --> Helper loaded: email_helper
INFO - 2019-11-03 23:30:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:30:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:30:24 --> Parser Class Initialized
INFO - 2019-11-03 23:30:24 --> User Agent Class Initialized
INFO - 2019-11-03 23:30:24 --> Model Class Initialized
INFO - 2019-11-03 23:30:24 --> Database Driver Class Initialized
INFO - 2019-11-03 23:30:24 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:24 --> Template Class Initialized
INFO - 2019-11-03 23:30:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:30:24 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:30:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:30:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:30:24 --> Encryption Class Initialized
INFO - 2019-11-03 23:30:24 --> Controller Class Initialized
DEBUG - 2019-11-03 23:30:24 --> package MX_Controller Initialized
DEBUG - 2019-11-03 23:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-03 23:30:24 --> Model Class Initialized
INFO - 2019-11-03 23:30:24 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:30:24 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:30:24 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:30:24 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-03 23:30:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-03 23:30:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:30:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:30:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:30:25 --> Final output sent to browser
DEBUG - 2019-11-03 23:30:25 --> Total execution time: 0.7886
INFO - 2019-11-03 23:30:29 --> Config Class Initialized
INFO - 2019-11-03 23:30:29 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:30:29 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:30:29 --> Utf8 Class Initialized
INFO - 2019-11-03 23:30:29 --> URI Class Initialized
INFO - 2019-11-03 23:30:29 --> Router Class Initialized
INFO - 2019-11-03 23:30:29 --> Output Class Initialized
INFO - 2019-11-03 23:30:29 --> Security Class Initialized
DEBUG - 2019-11-03 23:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:30:29 --> CSRF cookie sent
INFO - 2019-11-03 23:30:29 --> CSRF token verified
INFO - 2019-11-03 23:30:29 --> Input Class Initialized
INFO - 2019-11-03 23:30:29 --> Language Class Initialized
INFO - 2019-11-03 23:30:29 --> Language Class Initialized
INFO - 2019-11-03 23:30:29 --> Config Class Initialized
INFO - 2019-11-03 23:30:29 --> Loader Class Initialized
INFO - 2019-11-03 23:30:29 --> Helper loaded: url_helper
INFO - 2019-11-03 23:30:29 --> Helper loaded: common_helper
INFO - 2019-11-03 23:30:29 --> Helper loaded: language_helper
INFO - 2019-11-03 23:30:29 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:30:29 --> Helper loaded: email_helper
INFO - 2019-11-03 23:30:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:30:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:30:29 --> Parser Class Initialized
INFO - 2019-11-03 23:30:29 --> User Agent Class Initialized
INFO - 2019-11-03 23:30:29 --> Model Class Initialized
INFO - 2019-11-03 23:30:29 --> Database Driver Class Initialized
INFO - 2019-11-03 23:30:29 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:29 --> Template Class Initialized
INFO - 2019-11-03 23:30:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:30:29 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:30:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:30:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:30:29 --> Encryption Class Initialized
INFO - 2019-11-03 23:30:29 --> Controller Class Initialized
DEBUG - 2019-11-03 23:30:29 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:30:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:30:29 --> Model Class Initialized
INFO - 2019-11-03 23:30:29 --> Helper loaded: inflector_helper
ERROR - 2019-11-03 23:30:30 --> Could not find the language line "dotpay"
DEBUG - 2019-11-03 23:30:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-03 23:30:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:30:30 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:30:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:30:30 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:30:30 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:30:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:30:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:30:30 --> Final output sent to browser
DEBUG - 2019-11-03 23:30:30 --> Total execution time: 0.8436
INFO - 2019-11-03 23:30:47 --> Config Class Initialized
INFO - 2019-11-03 23:30:47 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:30:47 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:30:47 --> Utf8 Class Initialized
INFO - 2019-11-03 23:30:47 --> URI Class Initialized
INFO - 2019-11-03 23:30:47 --> Router Class Initialized
INFO - 2019-11-03 23:30:47 --> Output Class Initialized
INFO - 2019-11-03 23:30:47 --> Security Class Initialized
DEBUG - 2019-11-03 23:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:30:47 --> CSRF cookie sent
INFO - 2019-11-03 23:30:47 --> CSRF token verified
INFO - 2019-11-03 23:30:47 --> Input Class Initialized
INFO - 2019-11-03 23:30:47 --> Language Class Initialized
INFO - 2019-11-03 23:30:47 --> Language Class Initialized
INFO - 2019-11-03 23:30:47 --> Config Class Initialized
INFO - 2019-11-03 23:30:47 --> Loader Class Initialized
INFO - 2019-11-03 23:30:47 --> Helper loaded: url_helper
INFO - 2019-11-03 23:30:47 --> Helper loaded: common_helper
INFO - 2019-11-03 23:30:47 --> Helper loaded: language_helper
INFO - 2019-11-03 23:30:47 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:30:47 --> Helper loaded: email_helper
INFO - 2019-11-03 23:30:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:30:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:30:47 --> Parser Class Initialized
INFO - 2019-11-03 23:30:47 --> User Agent Class Initialized
INFO - 2019-11-03 23:30:47 --> Model Class Initialized
INFO - 2019-11-03 23:30:47 --> Database Driver Class Initialized
INFO - 2019-11-03 23:30:47 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:47 --> Template Class Initialized
INFO - 2019-11-03 23:30:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:30:47 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:30:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:30:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:30:47 --> Encryption Class Initialized
INFO - 2019-11-03 23:30:47 --> Controller Class Initialized
DEBUG - 2019-11-03 23:30:47 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:30:47 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-03 23:30:47 --> Final output sent to browser
DEBUG - 2019-11-03 23:30:47 --> Total execution time: 0.5728
INFO - 2019-11-03 23:30:47 --> Config Class Initialized
INFO - 2019-11-03 23:30:47 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:30:47 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:30:47 --> Utf8 Class Initialized
INFO - 2019-11-03 23:30:47 --> URI Class Initialized
INFO - 2019-11-03 23:30:47 --> Router Class Initialized
INFO - 2019-11-03 23:30:47 --> Output Class Initialized
INFO - 2019-11-03 23:30:47 --> Security Class Initialized
DEBUG - 2019-11-03 23:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:30:47 --> Input Class Initialized
INFO - 2019-11-03 23:30:47 --> Language Class Initialized
INFO - 2019-11-03 23:30:47 --> Language Class Initialized
INFO - 2019-11-03 23:30:47 --> Config Class Initialized
INFO - 2019-11-03 23:30:48 --> Loader Class Initialized
INFO - 2019-11-03 23:30:48 --> Helper loaded: url_helper
INFO - 2019-11-03 23:30:48 --> Helper loaded: common_helper
INFO - 2019-11-03 23:30:48 --> Helper loaded: language_helper
INFO - 2019-11-03 23:30:48 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:30:48 --> Helper loaded: email_helper
INFO - 2019-11-03 23:30:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:30:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:30:48 --> Parser Class Initialized
INFO - 2019-11-03 23:30:48 --> User Agent Class Initialized
INFO - 2019-11-03 23:30:48 --> Model Class Initialized
INFO - 2019-11-03 23:30:48 --> Database Driver Class Initialized
INFO - 2019-11-03 23:30:48 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:48 --> Template Class Initialized
INFO - 2019-11-03 23:30:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:30:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:30:48 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:30:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:30:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:30:48 --> Encryption Class Initialized
INFO - 2019-11-03 23:30:48 --> Controller Class Initialized
DEBUG - 2019-11-03 23:30:48 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 23:30:48 --> Model Class Initialized
DEBUG - 2019-11-03 23:30:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-03 23:30:48 --> Final output sent to browser
DEBUG - 2019-11-03 23:30:48 --> Total execution time: 0.5419
INFO - 2019-11-03 23:31:06 --> Config Class Initialized
INFO - 2019-11-03 23:31:06 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:31:06 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:31:06 --> Utf8 Class Initialized
INFO - 2019-11-03 23:31:06 --> URI Class Initialized
INFO - 2019-11-03 23:31:06 --> Router Class Initialized
INFO - 2019-11-03 23:31:06 --> Output Class Initialized
INFO - 2019-11-03 23:31:06 --> Security Class Initialized
DEBUG - 2019-11-03 23:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:31:06 --> Input Class Initialized
INFO - 2019-11-03 23:31:06 --> Language Class Initialized
INFO - 2019-11-03 23:31:06 --> Language Class Initialized
INFO - 2019-11-03 23:31:06 --> Config Class Initialized
INFO - 2019-11-03 23:31:06 --> Loader Class Initialized
INFO - 2019-11-03 23:31:06 --> Helper loaded: url_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: common_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: language_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: email_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:31:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:31:06 --> Parser Class Initialized
INFO - 2019-11-03 23:31:06 --> User Agent Class Initialized
INFO - 2019-11-03 23:31:06 --> Model Class Initialized
INFO - 2019-11-03 23:31:06 --> Database Driver Class Initialized
INFO - 2019-11-03 23:31:06 --> Model Class Initialized
DEBUG - 2019-11-03 23:31:06 --> Template Class Initialized
INFO - 2019-11-03 23:31:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:31:06 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:31:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:31:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:31:06 --> Encryption Class Initialized
INFO - 2019-11-03 23:31:06 --> Controller Class Initialized
DEBUG - 2019-11-03 23:31:06 --> dotpay MX_Controller Initialized
INFO - 2019-11-03 23:31:06 --> Model Class Initialized
DEBUG - 2019-11-03 23:31:06 --> orders MX_Controller Initialized
INFO - 2019-11-03 23:31:06 --> Config Class Initialized
INFO - 2019-11-03 23:31:06 --> Hooks Class Initialized
DEBUG - 2019-11-03 23:31:06 --> UTF-8 Support Enabled
INFO - 2019-11-03 23:31:06 --> Utf8 Class Initialized
INFO - 2019-11-03 23:31:06 --> URI Class Initialized
INFO - 2019-11-03 23:31:06 --> Router Class Initialized
INFO - 2019-11-03 23:31:06 --> Output Class Initialized
INFO - 2019-11-03 23:31:06 --> Security Class Initialized
DEBUG - 2019-11-03 23:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-03 23:31:06 --> CSRF cookie sent
INFO - 2019-11-03 23:31:06 --> Input Class Initialized
INFO - 2019-11-03 23:31:06 --> Language Class Initialized
INFO - 2019-11-03 23:31:06 --> Language Class Initialized
INFO - 2019-11-03 23:31:06 --> Config Class Initialized
INFO - 2019-11-03 23:31:06 --> Loader Class Initialized
INFO - 2019-11-03 23:31:06 --> Helper loaded: url_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: common_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: language_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: cookie_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: email_helper
INFO - 2019-11-03 23:31:06 --> Helper loaded: file_manager_helper
INFO - 2019-11-03 23:31:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-03 23:31:06 --> Parser Class Initialized
INFO - 2019-11-03 23:31:06 --> User Agent Class Initialized
INFO - 2019-11-03 23:31:07 --> Model Class Initialized
INFO - 2019-11-03 23:31:07 --> Database Driver Class Initialized
INFO - 2019-11-03 23:31:07 --> Model Class Initialized
DEBUG - 2019-11-03 23:31:07 --> Template Class Initialized
INFO - 2019-11-03 23:31:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-03 23:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-03 23:31:07 --> Pagination Class Initialized
DEBUG - 2019-11-03 23:31:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-03 23:31:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-03 23:31:07 --> Encryption Class Initialized
INFO - 2019-11-03 23:31:07 --> Controller Class Initialized
DEBUG - 2019-11-03 23:31:07 --> checkout MX_Controller Initialized
DEBUG - 2019-11-03 23:31:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-03 23:31:07 --> Model Class Initialized
INFO - 2019-11-03 23:31:07 --> Helper loaded: inflector_helper
DEBUG - 2019-11-03 23:31:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-03 23:31:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-03 23:31:07 --> blocks MX_Controller Initialized
DEBUG - 2019-11-03 23:31:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-03 23:31:07 --> Model Class Initialized
DEBUG - 2019-11-03 23:31:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-03 23:31:07 --> Model Class Initialized
DEBUG - 2019-11-03 23:31:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-03 23:31:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-03 23:31:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-03 23:31:07 --> Final output sent to browser
DEBUG - 2019-11-03 23:31:07 --> Total execution time: 0.7502
