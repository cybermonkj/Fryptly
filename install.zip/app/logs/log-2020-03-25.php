<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-25 11:08:26 --> Config Class Initialized
INFO - 2020-03-25 11:08:26 --> Hooks Class Initialized
DEBUG - 2020-03-25 11:08:26 --> UTF-8 Support Enabled
INFO - 2020-03-25 11:08:26 --> Utf8 Class Initialized
INFO - 2020-03-25 11:08:26 --> URI Class Initialized
DEBUG - 2020-03-25 11:08:26 --> No URI present. Default controller set.
INFO - 2020-03-25 11:08:26 --> Router Class Initialized
INFO - 2020-03-25 11:08:26 --> Output Class Initialized
INFO - 2020-03-25 11:08:26 --> Security Class Initialized
DEBUG - 2020-03-25 11:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-25 11:08:26 --> CSRF cookie sent
INFO - 2020-03-25 11:08:26 --> Input Class Initialized
INFO - 2020-03-25 11:08:26 --> Language Class Initialized
INFO - 2020-03-25 11:08:27 --> Language Class Initialized
INFO - 2020-03-25 11:08:27 --> Config Class Initialized
INFO - 2020-03-25 11:08:27 --> Loader Class Initialized
INFO - 2020-03-25 11:08:27 --> Helper loaded: url_helper
INFO - 2020-03-25 11:08:27 --> Helper loaded: common_helper
INFO - 2020-03-25 11:08:27 --> Helper loaded: language_helper
INFO - 2020-03-25 11:08:27 --> Helper loaded: cookie_helper
INFO - 2020-03-25 11:08:27 --> Helper loaded: email_helper
INFO - 2020-03-25 11:08:27 --> Helper loaded: file_manager_helper
INFO - 2020-03-25 11:08:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-25 11:08:27 --> Parser Class Initialized
INFO - 2020-03-25 11:08:27 --> User Agent Class Initialized
INFO - 2020-03-25 11:08:27 --> Model Class Initialized
INFO - 2020-03-25 11:08:27 --> Database Driver Class Initialized
INFO - 2020-03-25 11:08:27 --> Model Class Initialized
DEBUG - 2020-03-25 11:08:27 --> Template Class Initialized
INFO - 2020-03-25 11:08:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-25 11:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-25 11:08:27 --> Pagination Class Initialized
DEBUG - 2020-03-25 11:08:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-25 11:08:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-25 11:08:27 --> Encryption Class Initialized
DEBUG - 2020-03-25 11:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-25 11:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-25 11:08:27 --> Controller Class Initialized
DEBUG - 2020-03-25 11:08:27 --> pergo MX_Controller Initialized
DEBUG - 2020-03-25 11:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-25 11:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-25 11:08:27 --> Model Class Initialized
INFO - 2020-03-25 11:08:27 --> Helper loaded: inflector_helper
DEBUG - 2020-03-25 11:08:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-25 11:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-25 11:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-25 11:08:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-25 11:08:28 --> Final output sent to browser
DEBUG - 2020-03-25 11:08:28 --> Total execution time: 1.5336
INFO - 2020-03-25 15:20:53 --> Config Class Initialized
INFO - 2020-03-25 15:20:53 --> Hooks Class Initialized
DEBUG - 2020-03-25 15:20:53 --> UTF-8 Support Enabled
INFO - 2020-03-25 15:20:53 --> Utf8 Class Initialized
INFO - 2020-03-25 15:20:53 --> URI Class Initialized
DEBUG - 2020-03-25 15:20:53 --> No URI present. Default controller set.
INFO - 2020-03-25 15:20:53 --> Router Class Initialized
INFO - 2020-03-25 15:20:53 --> Output Class Initialized
INFO - 2020-03-25 15:20:53 --> Security Class Initialized
DEBUG - 2020-03-25 15:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-25 15:20:53 --> CSRF cookie sent
INFO - 2020-03-25 15:20:53 --> Input Class Initialized
INFO - 2020-03-25 15:20:53 --> Language Class Initialized
INFO - 2020-03-25 15:20:53 --> Language Class Initialized
INFO - 2020-03-25 15:20:53 --> Config Class Initialized
INFO - 2020-03-25 15:20:53 --> Loader Class Initialized
INFO - 2020-03-25 15:20:53 --> Helper loaded: url_helper
INFO - 2020-03-25 15:20:53 --> Helper loaded: common_helper
INFO - 2020-03-25 15:20:54 --> Helper loaded: language_helper
INFO - 2020-03-25 15:20:54 --> Helper loaded: cookie_helper
INFO - 2020-03-25 15:20:54 --> Helper loaded: email_helper
INFO - 2020-03-25 15:20:54 --> Helper loaded: file_manager_helper
INFO - 2020-03-25 15:20:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-25 15:20:54 --> Parser Class Initialized
INFO - 2020-03-25 15:20:54 --> User Agent Class Initialized
INFO - 2020-03-25 15:20:54 --> Model Class Initialized
INFO - 2020-03-25 15:20:54 --> Database Driver Class Initialized
INFO - 2020-03-25 15:20:54 --> Model Class Initialized
DEBUG - 2020-03-25 15:20:54 --> Template Class Initialized
INFO - 2020-03-25 15:20:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-25 15:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-25 15:20:54 --> Pagination Class Initialized
DEBUG - 2020-03-25 15:20:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-25 15:20:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-25 15:20:54 --> Encryption Class Initialized
DEBUG - 2020-03-25 15:20:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-25 15:20:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-25 15:20:54 --> Controller Class Initialized
DEBUG - 2020-03-25 15:20:54 --> pergo MX_Controller Initialized
DEBUG - 2020-03-25 15:20:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-25 15:20:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-25 15:20:54 --> Model Class Initialized
INFO - 2020-03-25 15:20:54 --> Helper loaded: inflector_helper
DEBUG - 2020-03-25 15:20:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-25 15:20:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-25 15:20:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-25 15:20:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-25 15:20:54 --> Final output sent to browser
DEBUG - 2020-03-25 15:20:54 --> Total execution time: 1.3730
INFO - 2020-03-25 16:18:40 --> Config Class Initialized
INFO - 2020-03-25 16:18:40 --> Hooks Class Initialized
DEBUG - 2020-03-25 16:18:40 --> UTF-8 Support Enabled
INFO - 2020-03-25 16:18:40 --> Utf8 Class Initialized
INFO - 2020-03-25 16:18:40 --> URI Class Initialized
DEBUG - 2020-03-25 16:18:40 --> No URI present. Default controller set.
INFO - 2020-03-25 16:18:40 --> Router Class Initialized
INFO - 2020-03-25 16:18:40 --> Output Class Initialized
INFO - 2020-03-25 16:18:40 --> Security Class Initialized
DEBUG - 2020-03-25 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-25 16:18:40 --> CSRF cookie sent
INFO - 2020-03-25 16:18:40 --> Input Class Initialized
INFO - 2020-03-25 16:18:40 --> Language Class Initialized
INFO - 2020-03-25 16:18:40 --> Language Class Initialized
INFO - 2020-03-25 16:18:40 --> Config Class Initialized
INFO - 2020-03-25 16:18:40 --> Loader Class Initialized
INFO - 2020-03-25 16:18:40 --> Helper loaded: url_helper
INFO - 2020-03-25 16:18:40 --> Helper loaded: common_helper
INFO - 2020-03-25 16:18:40 --> Helper loaded: language_helper
INFO - 2020-03-25 16:18:40 --> Helper loaded: cookie_helper
INFO - 2020-03-25 16:18:40 --> Helper loaded: email_helper
INFO - 2020-03-25 16:18:40 --> Helper loaded: file_manager_helper
INFO - 2020-03-25 16:18:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-03-25 16:18:40 --> Parser Class Initialized
INFO - 2020-03-25 16:18:40 --> User Agent Class Initialized
INFO - 2020-03-25 16:18:40 --> Model Class Initialized
INFO - 2020-03-25 16:18:40 --> Database Driver Class Initialized
INFO - 2020-03-25 16:18:40 --> Model Class Initialized
DEBUG - 2020-03-25 16:18:40 --> Template Class Initialized
INFO - 2020-03-25 16:18:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-03-25 16:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-25 16:18:40 --> Pagination Class Initialized
DEBUG - 2020-03-25 16:18:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-03-25 16:18:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-03-25 16:18:40 --> Encryption Class Initialized
DEBUG - 2020-03-25 16:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-25 16:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2020-03-25 16:18:40 --> Controller Class Initialized
DEBUG - 2020-03-25 16:18:40 --> pergo MX_Controller Initialized
DEBUG - 2020-03-25 16:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2020-03-25 16:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2020-03-25 16:18:40 --> Model Class Initialized
INFO - 2020-03-25 16:18:40 --> Helper loaded: inflector_helper
DEBUG - 2020-03-25 16:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2020-03-25 16:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2020-03-25 16:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2020-03-25 16:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2020-03-25 16:18:41 --> Final output sent to browser
DEBUG - 2020-03-25 16:18:41 --> Total execution time: 0.6101
