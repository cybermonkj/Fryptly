<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-04 10:18:23 --> Config Class Initialized
INFO - 2020-04-04 10:18:23 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:18:23 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:18:23 --> Utf8 Class Initialized
INFO - 2020-04-04 10:18:23 --> URI Class Initialized
DEBUG - 2020-04-04 10:18:23 --> No URI present. Default controller set.
INFO - 2020-04-04 10:18:23 --> Router Class Initialized
INFO - 2020-04-04 10:18:23 --> Output Class Initialized
INFO - 2020-04-04 10:18:23 --> Security Class Initialized
DEBUG - 2020-04-04 10:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:18:24 --> CSRF cookie sent
INFO - 2020-04-04 10:18:24 --> Input Class Initialized
INFO - 2020-04-04 10:18:24 --> Language Class Initialized
INFO - 2020-04-04 10:18:24 --> Language Class Initialized
INFO - 2020-04-04 10:18:24 --> Config Class Initialized
INFO - 2020-04-04 10:18:24 --> Loader Class Initialized
INFO - 2020-04-04 10:18:24 --> Helper loaded: url_helper
INFO - 2020-04-04 10:18:24 --> Helper loaded: file_helper
INFO - 2020-04-04 10:18:24 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:18:24 --> Helper loaded: common_helper
INFO - 2020-04-04 10:18:24 --> Helper loaded: language_helper
INFO - 2020-04-04 10:18:24 --> Helper loaded: email_helper
INFO - 2020-04-04 10:18:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:18:24 --> Database Driver Class Initialized
INFO - 2020-04-04 10:18:24 --> Parser Class Initialized
INFO - 2020-04-04 10:18:24 --> User Agent Class Initialized
INFO - 2020-04-04 10:18:24 --> Model Class Initialized
INFO - 2020-04-04 10:18:24 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:24 --> Template Class Initialized
INFO - 2020-04-04 10:18:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:18:24 --> Email Class Initialized
INFO - 2020-04-04 10:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:18:24 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:18:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:18:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:18:24 --> Encryption Class Initialized
INFO - 2020-04-04 10:18:24 --> Controller Class Initialized
DEBUG - 2020-04-04 10:18:24 --> home MX_Controller Initialized
INFO - 2020-04-04 10:18:24 --> Model Class Initialized
INFO - 2020-04-04 10:18:25 --> Config Class Initialized
INFO - 2020-04-04 10:18:25 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:18:25 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:18:25 --> Utf8 Class Initialized
INFO - 2020-04-04 10:18:25 --> URI Class Initialized
INFO - 2020-04-04 10:18:25 --> Router Class Initialized
INFO - 2020-04-04 10:18:25 --> Output Class Initialized
INFO - 2020-04-04 10:18:25 --> Security Class Initialized
DEBUG - 2020-04-04 10:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:18:25 --> CSRF cookie sent
INFO - 2020-04-04 10:18:25 --> Input Class Initialized
INFO - 2020-04-04 10:18:25 --> Language Class Initialized
INFO - 2020-04-04 10:18:25 --> Language Class Initialized
INFO - 2020-04-04 10:18:25 --> Config Class Initialized
INFO - 2020-04-04 10:18:25 --> Loader Class Initialized
INFO - 2020-04-04 10:18:25 --> Helper loaded: url_helper
INFO - 2020-04-04 10:18:25 --> Helper loaded: file_helper
INFO - 2020-04-04 10:18:25 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:18:25 --> Helper loaded: common_helper
INFO - 2020-04-04 10:18:25 --> Helper loaded: language_helper
INFO - 2020-04-04 10:18:25 --> Helper loaded: email_helper
INFO - 2020-04-04 10:18:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:18:25 --> Database Driver Class Initialized
INFO - 2020-04-04 10:18:25 --> Parser Class Initialized
INFO - 2020-04-04 10:18:25 --> User Agent Class Initialized
INFO - 2020-04-04 10:18:25 --> Model Class Initialized
INFO - 2020-04-04 10:18:25 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:25 --> Template Class Initialized
INFO - 2020-04-04 10:18:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:18:25 --> Email Class Initialized
INFO - 2020-04-04 10:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:18:25 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:18:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:18:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:18:25 --> Encryption Class Initialized
INFO - 2020-04-04 10:18:25 --> Controller Class Initialized
DEBUG - 2020-04-04 10:18:25 --> twitter MX_Controller Initialized
INFO - 2020-04-04 10:18:25 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-04 10:18:25 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-04 10:18:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:18:25 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:18:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:18:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:18:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:18:25 --> Final output sent to browser
DEBUG - 2020-04-04 10:18:25 --> Total execution time: 0.6322
INFO - 2020-04-04 10:18:29 --> Config Class Initialized
INFO - 2020-04-04 10:18:29 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:18:29 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:18:29 --> Utf8 Class Initialized
INFO - 2020-04-04 10:18:29 --> URI Class Initialized
INFO - 2020-04-04 10:18:29 --> Router Class Initialized
INFO - 2020-04-04 10:18:29 --> Output Class Initialized
INFO - 2020-04-04 10:18:29 --> Security Class Initialized
DEBUG - 2020-04-04 10:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:18:29 --> CSRF cookie sent
INFO - 2020-04-04 10:18:29 --> CSRF token verified
INFO - 2020-04-04 10:18:29 --> Input Class Initialized
INFO - 2020-04-04 10:18:29 --> Language Class Initialized
INFO - 2020-04-04 10:18:29 --> Language Class Initialized
INFO - 2020-04-04 10:18:29 --> Config Class Initialized
INFO - 2020-04-04 10:18:29 --> Loader Class Initialized
INFO - 2020-04-04 10:18:29 --> Helper loaded: url_helper
INFO - 2020-04-04 10:18:29 --> Helper loaded: file_helper
INFO - 2020-04-04 10:18:29 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:18:29 --> Helper loaded: common_helper
INFO - 2020-04-04 10:18:29 --> Helper loaded: language_helper
INFO - 2020-04-04 10:18:29 --> Helper loaded: email_helper
INFO - 2020-04-04 10:18:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:18:29 --> Database Driver Class Initialized
INFO - 2020-04-04 10:18:29 --> Parser Class Initialized
INFO - 2020-04-04 10:18:29 --> User Agent Class Initialized
INFO - 2020-04-04 10:18:29 --> Model Class Initialized
INFO - 2020-04-04 10:18:29 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:29 --> Template Class Initialized
INFO - 2020-04-04 10:18:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:18:29 --> Email Class Initialized
INFO - 2020-04-04 10:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:18:29 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:18:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:18:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:18:29 --> Encryption Class Initialized
INFO - 2020-04-04 10:18:29 --> Controller Class Initialized
DEBUG - 2020-04-04 10:18:29 --> twitter MX_Controller Initialized
INFO - 2020-04-04 10:18:29 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-04 10:18:29 --> Model Class Initialized
INFO - 2020-04-04 10:18:32 --> Config Class Initialized
INFO - 2020-04-04 10:18:32 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:18:32 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:18:32 --> Utf8 Class Initialized
INFO - 2020-04-04 10:18:32 --> URI Class Initialized
INFO - 2020-04-04 10:18:32 --> Router Class Initialized
INFO - 2020-04-04 10:18:32 --> Output Class Initialized
INFO - 2020-04-04 10:18:32 --> Security Class Initialized
DEBUG - 2020-04-04 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:18:32 --> CSRF cookie sent
INFO - 2020-04-04 10:18:32 --> Input Class Initialized
INFO - 2020-04-04 10:18:32 --> Language Class Initialized
INFO - 2020-04-04 10:18:32 --> Language Class Initialized
INFO - 2020-04-04 10:18:32 --> Config Class Initialized
INFO - 2020-04-04 10:18:32 --> Loader Class Initialized
INFO - 2020-04-04 10:18:32 --> Helper loaded: url_helper
INFO - 2020-04-04 10:18:32 --> Helper loaded: file_helper
INFO - 2020-04-04 10:18:32 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:18:32 --> Helper loaded: common_helper
INFO - 2020-04-04 10:18:32 --> Helper loaded: language_helper
INFO - 2020-04-04 10:18:32 --> Helper loaded: email_helper
INFO - 2020-04-04 10:18:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:18:32 --> Database Driver Class Initialized
INFO - 2020-04-04 10:18:32 --> Parser Class Initialized
INFO - 2020-04-04 10:18:32 --> User Agent Class Initialized
INFO - 2020-04-04 10:18:32 --> Model Class Initialized
INFO - 2020-04-04 10:18:32 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:32 --> Template Class Initialized
INFO - 2020-04-04 10:18:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:18:32 --> Email Class Initialized
INFO - 2020-04-04 10:18:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:18:32 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:18:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:18:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:18:33 --> Encryption Class Initialized
INFO - 2020-04-04 10:18:33 --> Controller Class Initialized
DEBUG - 2020-04-04 10:18:33 --> twitter MX_Controller Initialized
INFO - 2020-04-04 10:18:33 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-04 10:18:33 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-04 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:18:33 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:18:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:18:33 --> Final output sent to browser
DEBUG - 2020-04-04 10:18:33 --> Total execution time: 0.5645
INFO - 2020-04-04 10:18:35 --> Config Class Initialized
INFO - 2020-04-04 10:18:35 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:18:35 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:18:35 --> Utf8 Class Initialized
INFO - 2020-04-04 10:18:35 --> URI Class Initialized
INFO - 2020-04-04 10:18:35 --> Router Class Initialized
INFO - 2020-04-04 10:18:35 --> Output Class Initialized
INFO - 2020-04-04 10:18:35 --> Security Class Initialized
DEBUG - 2020-04-04 10:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:18:35 --> CSRF cookie sent
INFO - 2020-04-04 10:18:35 --> Input Class Initialized
INFO - 2020-04-04 10:18:35 --> Language Class Initialized
INFO - 2020-04-04 10:18:36 --> Language Class Initialized
INFO - 2020-04-04 10:18:36 --> Config Class Initialized
INFO - 2020-04-04 10:18:36 --> Loader Class Initialized
INFO - 2020-04-04 10:18:36 --> Helper loaded: url_helper
INFO - 2020-04-04 10:18:36 --> Helper loaded: file_helper
INFO - 2020-04-04 10:18:36 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:18:36 --> Helper loaded: common_helper
INFO - 2020-04-04 10:18:36 --> Helper loaded: language_helper
INFO - 2020-04-04 10:18:36 --> Helper loaded: email_helper
INFO - 2020-04-04 10:18:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:18:36 --> Database Driver Class Initialized
INFO - 2020-04-04 10:18:36 --> Parser Class Initialized
INFO - 2020-04-04 10:18:36 --> User Agent Class Initialized
INFO - 2020-04-04 10:18:36 --> Model Class Initialized
INFO - 2020-04-04 10:18:36 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:36 --> Template Class Initialized
INFO - 2020-04-04 10:18:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:18:36 --> Email Class Initialized
INFO - 2020-04-04 10:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:18:36 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:18:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:18:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:18:36 --> Encryption Class Initialized
INFO - 2020-04-04 10:18:36 --> Controller Class Initialized
DEBUG - 2020-04-04 10:18:36 --> follow MX_Controller Initialized
INFO - 2020-04-04 10:18:36 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-04 10:18:36 --> Model Class Initialized
INFO - 2020-04-04 10:18:36 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-04 10:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:18:36 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:18:36 --> Final output sent to browser
DEBUG - 2020-04-04 10:18:36 --> Total execution time: 0.5830
INFO - 2020-04-04 10:18:38 --> Config Class Initialized
INFO - 2020-04-04 10:18:38 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:18:38 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:18:38 --> Utf8 Class Initialized
INFO - 2020-04-04 10:18:38 --> URI Class Initialized
INFO - 2020-04-04 10:18:38 --> Router Class Initialized
INFO - 2020-04-04 10:18:38 --> Output Class Initialized
INFO - 2020-04-04 10:18:38 --> Security Class Initialized
DEBUG - 2020-04-04 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:18:38 --> CSRF cookie sent
INFO - 2020-04-04 10:18:38 --> Input Class Initialized
INFO - 2020-04-04 10:18:38 --> Language Class Initialized
INFO - 2020-04-04 10:18:38 --> Language Class Initialized
INFO - 2020-04-04 10:18:38 --> Config Class Initialized
INFO - 2020-04-04 10:18:38 --> Loader Class Initialized
INFO - 2020-04-04 10:18:38 --> Helper loaded: url_helper
INFO - 2020-04-04 10:18:38 --> Helper loaded: file_helper
INFO - 2020-04-04 10:18:38 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:18:38 --> Helper loaded: common_helper
INFO - 2020-04-04 10:18:38 --> Helper loaded: language_helper
INFO - 2020-04-04 10:18:38 --> Helper loaded: email_helper
INFO - 2020-04-04 10:18:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:18:38 --> Database Driver Class Initialized
INFO - 2020-04-04 10:18:38 --> Parser Class Initialized
INFO - 2020-04-04 10:18:38 --> User Agent Class Initialized
INFO - 2020-04-04 10:18:38 --> Model Class Initialized
INFO - 2020-04-04 10:18:38 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:38 --> Template Class Initialized
INFO - 2020-04-04 10:18:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:18:38 --> Email Class Initialized
INFO - 2020-04-04 10:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:18:38 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:18:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:18:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:18:38 --> Encryption Class Initialized
INFO - 2020-04-04 10:18:38 --> Controller Class Initialized
DEBUG - 2020-04-04 10:18:38 --> follow MX_Controller Initialized
INFO - 2020-04-04 10:18:38 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-04 10:18:38 --> Model Class Initialized
INFO - 2020-04-04 10:18:38 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:18:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/setting.php
DEBUG - 2020-04-04 10:18:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/content.php
DEBUG - 2020-04-04 10:18:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-04 10:18:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:18:38 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:18:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:18:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:18:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:18:38 --> Final output sent to browser
DEBUG - 2020-04-04 10:18:39 --> Total execution time: 0.5819
INFO - 2020-04-04 10:18:41 --> Config Class Initialized
INFO - 2020-04-04 10:18:41 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:18:41 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:18:41 --> Utf8 Class Initialized
INFO - 2020-04-04 10:18:41 --> URI Class Initialized
INFO - 2020-04-04 10:18:41 --> Router Class Initialized
INFO - 2020-04-04 10:18:41 --> Output Class Initialized
INFO - 2020-04-04 10:18:41 --> Security Class Initialized
DEBUG - 2020-04-04 10:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:18:41 --> CSRF cookie sent
INFO - 2020-04-04 10:18:41 --> CSRF token verified
INFO - 2020-04-04 10:18:41 --> Input Class Initialized
INFO - 2020-04-04 10:18:41 --> Language Class Initialized
INFO - 2020-04-04 10:18:41 --> Language Class Initialized
INFO - 2020-04-04 10:18:41 --> Config Class Initialized
INFO - 2020-04-04 10:18:41 --> Loader Class Initialized
INFO - 2020-04-04 10:18:41 --> Helper loaded: url_helper
INFO - 2020-04-04 10:18:41 --> Helper loaded: file_helper
INFO - 2020-04-04 10:18:41 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:18:41 --> Helper loaded: common_helper
INFO - 2020-04-04 10:18:41 --> Helper loaded: language_helper
INFO - 2020-04-04 10:18:41 --> Helper loaded: email_helper
INFO - 2020-04-04 10:18:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:18:41 --> Database Driver Class Initialized
INFO - 2020-04-04 10:18:41 --> Parser Class Initialized
INFO - 2020-04-04 10:18:41 --> User Agent Class Initialized
INFO - 2020-04-04 10:18:41 --> Model Class Initialized
INFO - 2020-04-04 10:18:41 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:41 --> Template Class Initialized
INFO - 2020-04-04 10:18:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:18:41 --> Email Class Initialized
INFO - 2020-04-04 10:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:18:41 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:18:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:18:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:18:41 --> Encryption Class Initialized
INFO - 2020-04-04 10:18:41 --> Controller Class Initialized
DEBUG - 2020-04-04 10:18:41 --> follow MX_Controller Initialized
INFO - 2020-04-04 10:18:41 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-04 10:18:41 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/log.php
INFO - 2020-04-04 10:18:41 --> Final output sent to browser
DEBUG - 2020-04-04 10:18:41 --> Total execution time: 0.4531
INFO - 2020-04-04 10:18:51 --> Config Class Initialized
INFO - 2020-04-04 10:18:51 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:18:51 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:18:51 --> Utf8 Class Initialized
INFO - 2020-04-04 10:18:51 --> URI Class Initialized
INFO - 2020-04-04 10:18:51 --> Router Class Initialized
INFO - 2020-04-04 10:18:51 --> Output Class Initialized
INFO - 2020-04-04 10:18:51 --> Security Class Initialized
DEBUG - 2020-04-04 10:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:18:51 --> CSRF cookie sent
INFO - 2020-04-04 10:18:51 --> Input Class Initialized
INFO - 2020-04-04 10:18:51 --> Language Class Initialized
INFO - 2020-04-04 10:18:51 --> Language Class Initialized
INFO - 2020-04-04 10:18:51 --> Config Class Initialized
INFO - 2020-04-04 10:18:51 --> Loader Class Initialized
INFO - 2020-04-04 10:18:51 --> Helper loaded: url_helper
INFO - 2020-04-04 10:18:51 --> Helper loaded: file_helper
INFO - 2020-04-04 10:18:51 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:18:51 --> Helper loaded: common_helper
INFO - 2020-04-04 10:18:51 --> Helper loaded: language_helper
INFO - 2020-04-04 10:18:51 --> Helper loaded: email_helper
INFO - 2020-04-04 10:18:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:18:51 --> Database Driver Class Initialized
INFO - 2020-04-04 10:18:51 --> Parser Class Initialized
INFO - 2020-04-04 10:18:51 --> User Agent Class Initialized
DEBUG - 2020-04-04 10:18:51 --> Template Class Initialized
INFO - 2020-04-04 10:18:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:18:51 --> Email Class Initialized
INFO - 2020-04-04 10:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:18:51 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:18:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:18:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:18:51 --> Encryption Class Initialized
INFO - 2020-04-04 10:18:51 --> Controller Class Initialized
DEBUG - 2020-04-04 10:18:51 --> follow MX_Controller Initialized
INFO - 2020-04-04 10:18:51 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-04 10:18:51 --> Model Class Initialized
INFO - 2020-04-04 10:18:51 --> Model Class Initialized
INFO - 2020-04-04 10:18:51 --> Model Class Initialized
INFO - 2020-04-04 10:18:52 --> Final output sent to browser
DEBUG - 2020-04-04 10:18:52 --> Total execution time: 1.6212
ERROR - 2020-04-04 10:18:52 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-04-04 10:18:52 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-04-04 10:18:55 --> Config Class Initialized
INFO - 2020-04-04 10:18:55 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:18:55 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:18:55 --> Utf8 Class Initialized
INFO - 2020-04-04 10:18:55 --> URI Class Initialized
INFO - 2020-04-04 10:18:55 --> Router Class Initialized
INFO - 2020-04-04 10:18:55 --> Output Class Initialized
INFO - 2020-04-04 10:18:55 --> Security Class Initialized
DEBUG - 2020-04-04 10:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:18:55 --> CSRF cookie sent
INFO - 2020-04-04 10:18:55 --> CSRF token verified
INFO - 2020-04-04 10:18:56 --> Input Class Initialized
INFO - 2020-04-04 10:18:56 --> Language Class Initialized
INFO - 2020-04-04 10:18:56 --> Language Class Initialized
INFO - 2020-04-04 10:18:56 --> Config Class Initialized
INFO - 2020-04-04 10:18:56 --> Loader Class Initialized
INFO - 2020-04-04 10:18:56 --> Helper loaded: url_helper
INFO - 2020-04-04 10:18:56 --> Helper loaded: file_helper
INFO - 2020-04-04 10:18:56 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:18:56 --> Helper loaded: common_helper
INFO - 2020-04-04 10:18:56 --> Helper loaded: language_helper
INFO - 2020-04-04 10:18:56 --> Helper loaded: email_helper
INFO - 2020-04-04 10:18:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:18:56 --> Database Driver Class Initialized
INFO - 2020-04-04 10:18:56 --> Parser Class Initialized
INFO - 2020-04-04 10:18:56 --> User Agent Class Initialized
INFO - 2020-04-04 10:18:56 --> Model Class Initialized
INFO - 2020-04-04 10:18:56 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:56 --> Template Class Initialized
INFO - 2020-04-04 10:18:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:18:56 --> Email Class Initialized
INFO - 2020-04-04 10:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:18:56 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:18:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:18:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:18:56 --> Encryption Class Initialized
INFO - 2020-04-04 10:18:56 --> Controller Class Initialized
DEBUG - 2020-04-04 10:18:56 --> follow MX_Controller Initialized
INFO - 2020-04-04 10:18:56 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-04 10:18:56 --> Model Class Initialized
DEBUG - 2020-04-04 10:18:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/log.php
INFO - 2020-04-04 10:18:56 --> Final output sent to browser
DEBUG - 2020-04-04 10:18:56 --> Total execution time: 0.4067
INFO - 2020-04-04 10:22:43 --> Config Class Initialized
INFO - 2020-04-04 10:22:43 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:22:43 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:22:43 --> Utf8 Class Initialized
INFO - 2020-04-04 10:22:43 --> URI Class Initialized
INFO - 2020-04-04 10:22:43 --> Router Class Initialized
INFO - 2020-04-04 10:22:43 --> Output Class Initialized
INFO - 2020-04-04 10:22:43 --> Security Class Initialized
DEBUG - 2020-04-04 10:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:22:43 --> CSRF cookie sent
INFO - 2020-04-04 10:22:43 --> Input Class Initialized
INFO - 2020-04-04 10:22:43 --> Language Class Initialized
INFO - 2020-04-04 10:22:43 --> Language Class Initialized
INFO - 2020-04-04 10:22:43 --> Config Class Initialized
INFO - 2020-04-04 10:22:43 --> Loader Class Initialized
INFO - 2020-04-04 10:22:43 --> Helper loaded: url_helper
INFO - 2020-04-04 10:22:43 --> Helper loaded: file_helper
INFO - 2020-04-04 10:22:43 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:22:43 --> Helper loaded: common_helper
INFO - 2020-04-04 10:22:43 --> Helper loaded: language_helper
INFO - 2020-04-04 10:22:43 --> Helper loaded: email_helper
INFO - 2020-04-04 10:22:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:22:43 --> Database Driver Class Initialized
INFO - 2020-04-04 10:22:43 --> Parser Class Initialized
INFO - 2020-04-04 10:22:43 --> User Agent Class Initialized
INFO - 2020-04-04 10:22:43 --> Model Class Initialized
INFO - 2020-04-04 10:22:43 --> Model Class Initialized
DEBUG - 2020-04-04 10:22:43 --> Template Class Initialized
INFO - 2020-04-04 10:22:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:22:43 --> Email Class Initialized
INFO - 2020-04-04 10:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:22:43 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:22:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:22:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:22:43 --> Encryption Class Initialized
INFO - 2020-04-04 10:22:43 --> Controller Class Initialized
DEBUG - 2020-04-04 10:22:43 --> language MX_Controller Initialized
INFO - 2020-04-04 10:22:43 --> Config Class Initialized
INFO - 2020-04-04 10:22:43 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:22:43 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:22:43 --> Utf8 Class Initialized
INFO - 2020-04-04 10:22:43 --> URI Class Initialized
DEBUG - 2020-04-04 10:22:43 --> No URI present. Default controller set.
INFO - 2020-04-04 10:22:43 --> Router Class Initialized
INFO - 2020-04-04 10:22:43 --> Output Class Initialized
INFO - 2020-04-04 10:22:43 --> Security Class Initialized
DEBUG - 2020-04-04 10:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:22:43 --> CSRF cookie sent
INFO - 2020-04-04 10:22:43 --> Input Class Initialized
INFO - 2020-04-04 10:22:43 --> Language Class Initialized
INFO - 2020-04-04 10:22:44 --> Language Class Initialized
INFO - 2020-04-04 10:22:44 --> Config Class Initialized
INFO - 2020-04-04 10:22:44 --> Loader Class Initialized
INFO - 2020-04-04 10:22:44 --> Helper loaded: url_helper
INFO - 2020-04-04 10:22:44 --> Helper loaded: file_helper
INFO - 2020-04-04 10:22:44 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:22:44 --> Helper loaded: common_helper
INFO - 2020-04-04 10:22:44 --> Helper loaded: language_helper
INFO - 2020-04-04 10:22:44 --> Helper loaded: email_helper
INFO - 2020-04-04 10:22:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:22:44 --> Database Driver Class Initialized
INFO - 2020-04-04 10:22:44 --> Parser Class Initialized
INFO - 2020-04-04 10:22:44 --> User Agent Class Initialized
INFO - 2020-04-04 10:22:44 --> Model Class Initialized
INFO - 2020-04-04 10:22:44 --> Model Class Initialized
DEBUG - 2020-04-04 10:22:44 --> Template Class Initialized
INFO - 2020-04-04 10:22:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:22:44 --> Email Class Initialized
INFO - 2020-04-04 10:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:22:44 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:22:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:22:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:22:44 --> Encryption Class Initialized
INFO - 2020-04-04 10:22:44 --> Controller Class Initialized
DEBUG - 2020-04-04 10:22:44 --> home MX_Controller Initialized
INFO - 2020-04-04 10:22:44 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:22:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-04 10:22:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-04 10:22:44 --> Final output sent to browser
DEBUG - 2020-04-04 10:22:44 --> Total execution time: 0.4604
INFO - 2020-04-04 10:22:45 --> Config Class Initialized
INFO - 2020-04-04 10:22:45 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:22:45 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:22:45 --> Utf8 Class Initialized
INFO - 2020-04-04 10:22:45 --> URI Class Initialized
INFO - 2020-04-04 10:22:45 --> Router Class Initialized
INFO - 2020-04-04 10:22:45 --> Output Class Initialized
INFO - 2020-04-04 10:22:45 --> Security Class Initialized
DEBUG - 2020-04-04 10:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:22:46 --> CSRF cookie sent
INFO - 2020-04-04 10:22:46 --> Input Class Initialized
INFO - 2020-04-04 10:22:46 --> Language Class Initialized
INFO - 2020-04-04 10:22:46 --> Language Class Initialized
INFO - 2020-04-04 10:22:46 --> Config Class Initialized
INFO - 2020-04-04 10:22:46 --> Loader Class Initialized
INFO - 2020-04-04 10:22:46 --> Helper loaded: url_helper
INFO - 2020-04-04 10:22:46 --> Helper loaded: file_helper
INFO - 2020-04-04 10:22:46 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:22:46 --> Helper loaded: common_helper
INFO - 2020-04-04 10:22:46 --> Helper loaded: language_helper
INFO - 2020-04-04 10:22:46 --> Helper loaded: email_helper
INFO - 2020-04-04 10:22:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:22:46 --> Database Driver Class Initialized
INFO - 2020-04-04 10:22:46 --> Parser Class Initialized
INFO - 2020-04-04 10:22:46 --> User Agent Class Initialized
INFO - 2020-04-04 10:22:46 --> Model Class Initialized
INFO - 2020-04-04 10:22:46 --> Model Class Initialized
DEBUG - 2020-04-04 10:22:46 --> Template Class Initialized
INFO - 2020-04-04 10:22:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:22:46 --> Email Class Initialized
INFO - 2020-04-04 10:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:22:46 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:22:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:22:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:22:46 --> Encryption Class Initialized
INFO - 2020-04-04 10:22:46 --> Controller Class Initialized
DEBUG - 2020-04-04 10:22:46 --> auth MX_Controller Initialized
INFO - 2020-04-04 10:22:46 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-04 10:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-04 10:22:46 --> Final output sent to browser
DEBUG - 2020-04-04 10:22:46 --> Total execution time: 0.9916
INFO - 2020-04-04 10:22:49 --> Config Class Initialized
INFO - 2020-04-04 10:22:49 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:22:49 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:22:49 --> Utf8 Class Initialized
INFO - 2020-04-04 10:22:49 --> URI Class Initialized
INFO - 2020-04-04 10:22:49 --> Router Class Initialized
INFO - 2020-04-04 10:22:49 --> Output Class Initialized
INFO - 2020-04-04 10:22:49 --> Security Class Initialized
DEBUG - 2020-04-04 10:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:22:49 --> CSRF cookie sent
INFO - 2020-04-04 10:22:49 --> CSRF token verified
INFO - 2020-04-04 10:22:49 --> Input Class Initialized
INFO - 2020-04-04 10:22:49 --> Language Class Initialized
INFO - 2020-04-04 10:22:49 --> Language Class Initialized
INFO - 2020-04-04 10:22:49 --> Config Class Initialized
INFO - 2020-04-04 10:22:49 --> Loader Class Initialized
INFO - 2020-04-04 10:22:49 --> Helper loaded: url_helper
INFO - 2020-04-04 10:22:49 --> Helper loaded: file_helper
INFO - 2020-04-04 10:22:49 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:22:49 --> Helper loaded: common_helper
INFO - 2020-04-04 10:22:49 --> Helper loaded: language_helper
INFO - 2020-04-04 10:22:49 --> Helper loaded: email_helper
INFO - 2020-04-04 10:22:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:22:49 --> Database Driver Class Initialized
INFO - 2020-04-04 10:22:49 --> Parser Class Initialized
INFO - 2020-04-04 10:22:49 --> User Agent Class Initialized
INFO - 2020-04-04 10:22:49 --> Model Class Initialized
INFO - 2020-04-04 10:22:49 --> Model Class Initialized
DEBUG - 2020-04-04 10:22:49 --> Template Class Initialized
INFO - 2020-04-04 10:22:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:22:49 --> Email Class Initialized
INFO - 2020-04-04 10:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:22:49 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:22:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:22:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:22:49 --> Encryption Class Initialized
INFO - 2020-04-04 10:22:49 --> Controller Class Initialized
DEBUG - 2020-04-04 10:22:49 --> auth MX_Controller Initialized
INFO - 2020-04-04 10:22:51 --> Config Class Initialized
INFO - 2020-04-04 10:22:51 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:22:51 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:22:51 --> Utf8 Class Initialized
INFO - 2020-04-04 10:22:51 --> URI Class Initialized
INFO - 2020-04-04 10:22:51 --> Router Class Initialized
INFO - 2020-04-04 10:22:51 --> Output Class Initialized
INFO - 2020-04-04 10:22:51 --> Security Class Initialized
DEBUG - 2020-04-04 10:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:22:51 --> CSRF cookie sent
INFO - 2020-04-04 10:22:51 --> Input Class Initialized
INFO - 2020-04-04 10:22:51 --> Language Class Initialized
INFO - 2020-04-04 10:22:51 --> Language Class Initialized
INFO - 2020-04-04 10:22:51 --> Config Class Initialized
INFO - 2020-04-04 10:22:51 --> Loader Class Initialized
INFO - 2020-04-04 10:22:51 --> Helper loaded: url_helper
INFO - 2020-04-04 10:22:51 --> Helper loaded: file_helper
INFO - 2020-04-04 10:22:51 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:22:51 --> Helper loaded: common_helper
INFO - 2020-04-04 10:22:51 --> Helper loaded: language_helper
INFO - 2020-04-04 10:22:51 --> Helper loaded: email_helper
INFO - 2020-04-04 10:22:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:22:51 --> Database Driver Class Initialized
INFO - 2020-04-04 10:22:51 --> Parser Class Initialized
INFO - 2020-04-04 10:22:51 --> User Agent Class Initialized
INFO - 2020-04-04 10:22:51 --> Model Class Initialized
INFO - 2020-04-04 10:22:51 --> Model Class Initialized
DEBUG - 2020-04-04 10:22:51 --> Template Class Initialized
INFO - 2020-04-04 10:22:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:22:51 --> Email Class Initialized
INFO - 2020-04-04 10:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:22:51 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:22:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:22:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:22:51 --> Encryption Class Initialized
INFO - 2020-04-04 10:22:52 --> Controller Class Initialized
DEBUG - 2020-04-04 10:22:52 --> dashboard MX_Controller Initialized
INFO - 2020-04-04 10:22:52 --> Model Class Initialized
DEBUG - 2020-04-04 10:22:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-04 10:22:52 --> Model Class Initialized
INFO - 2020-04-04 10:22:52 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:22:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-04 10:22:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-04 10:22:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:22:52 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:22:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:22:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:22:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:22:52 --> Final output sent to browser
DEBUG - 2020-04-04 10:22:52 --> Total execution time: 0.7539
INFO - 2020-04-04 10:22:55 --> Config Class Initialized
INFO - 2020-04-04 10:22:55 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:22:55 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:22:55 --> Utf8 Class Initialized
INFO - 2020-04-04 10:22:55 --> URI Class Initialized
INFO - 2020-04-04 10:22:55 --> Router Class Initialized
INFO - 2020-04-04 10:22:55 --> Output Class Initialized
INFO - 2020-04-04 10:22:55 --> Security Class Initialized
DEBUG - 2020-04-04 10:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:22:55 --> CSRF cookie sent
INFO - 2020-04-04 10:22:55 --> Input Class Initialized
INFO - 2020-04-04 10:22:55 --> Language Class Initialized
INFO - 2020-04-04 10:22:55 --> Language Class Initialized
INFO - 2020-04-04 10:22:55 --> Config Class Initialized
INFO - 2020-04-04 10:22:55 --> Loader Class Initialized
INFO - 2020-04-04 10:22:55 --> Helper loaded: url_helper
INFO - 2020-04-04 10:22:55 --> Helper loaded: file_helper
INFO - 2020-04-04 10:22:55 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:22:55 --> Helper loaded: common_helper
INFO - 2020-04-04 10:22:55 --> Helper loaded: language_helper
INFO - 2020-04-04 10:22:55 --> Helper loaded: email_helper
INFO - 2020-04-04 10:22:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:22:55 --> Database Driver Class Initialized
INFO - 2020-04-04 10:22:56 --> Parser Class Initialized
INFO - 2020-04-04 10:22:56 --> User Agent Class Initialized
INFO - 2020-04-04 10:22:56 --> Model Class Initialized
INFO - 2020-04-04 10:22:56 --> Model Class Initialized
DEBUG - 2020-04-04 10:22:56 --> Template Class Initialized
INFO - 2020-04-04 10:22:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:22:56 --> Email Class Initialized
INFO - 2020-04-04 10:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:22:56 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:22:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:22:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:22:56 --> Encryption Class Initialized
INFO - 2020-04-04 10:22:56 --> Controller Class Initialized
DEBUG - 2020-04-04 10:22:56 --> auth MX_Controller Initialized
INFO - 2020-04-04 10:22:56 --> Model Class Initialized
INFO - 2020-04-04 10:22:56 --> Config Class Initialized
INFO - 2020-04-04 10:22:56 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:22:56 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:22:56 --> Utf8 Class Initialized
INFO - 2020-04-04 10:22:56 --> URI Class Initialized
DEBUG - 2020-04-04 10:22:56 --> No URI present. Default controller set.
INFO - 2020-04-04 10:22:56 --> Router Class Initialized
INFO - 2020-04-04 10:22:56 --> Output Class Initialized
INFO - 2020-04-04 10:22:56 --> Security Class Initialized
DEBUG - 2020-04-04 10:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:22:56 --> CSRF cookie sent
INFO - 2020-04-04 10:22:56 --> Input Class Initialized
INFO - 2020-04-04 10:22:56 --> Language Class Initialized
INFO - 2020-04-04 10:22:56 --> Language Class Initialized
INFO - 2020-04-04 10:22:56 --> Config Class Initialized
INFO - 2020-04-04 10:22:56 --> Loader Class Initialized
INFO - 2020-04-04 10:22:56 --> Helper loaded: url_helper
INFO - 2020-04-04 10:22:56 --> Helper loaded: file_helper
INFO - 2020-04-04 10:22:56 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:22:56 --> Helper loaded: common_helper
INFO - 2020-04-04 10:22:56 --> Helper loaded: language_helper
INFO - 2020-04-04 10:22:56 --> Helper loaded: email_helper
INFO - 2020-04-04 10:22:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:22:56 --> Database Driver Class Initialized
INFO - 2020-04-04 10:22:56 --> Parser Class Initialized
INFO - 2020-04-04 10:22:56 --> User Agent Class Initialized
INFO - 2020-04-04 10:22:56 --> Model Class Initialized
INFO - 2020-04-04 10:22:56 --> Model Class Initialized
DEBUG - 2020-04-04 10:22:56 --> Template Class Initialized
INFO - 2020-04-04 10:22:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:22:56 --> Email Class Initialized
INFO - 2020-04-04 10:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:22:56 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:22:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:22:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:22:56 --> Encryption Class Initialized
INFO - 2020-04-04 10:22:56 --> Controller Class Initialized
DEBUG - 2020-04-04 10:22:56 --> home MX_Controller Initialized
INFO - 2020-04-04 10:22:56 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-04 10:22:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-04 10:22:56 --> Final output sent to browser
DEBUG - 2020-04-04 10:22:56 --> Total execution time: 0.4538
INFO - 2020-04-04 10:22:58 --> Config Class Initialized
INFO - 2020-04-04 10:22:58 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:22:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:22:58 --> Utf8 Class Initialized
INFO - 2020-04-04 10:22:58 --> URI Class Initialized
INFO - 2020-04-04 10:22:58 --> Router Class Initialized
INFO - 2020-04-04 10:22:58 --> Output Class Initialized
INFO - 2020-04-04 10:22:58 --> Security Class Initialized
DEBUG - 2020-04-04 10:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:22:58 --> CSRF cookie sent
INFO - 2020-04-04 10:22:58 --> Input Class Initialized
INFO - 2020-04-04 10:22:58 --> Language Class Initialized
INFO - 2020-04-04 10:22:58 --> Language Class Initialized
INFO - 2020-04-04 10:22:58 --> Config Class Initialized
INFO - 2020-04-04 10:22:58 --> Loader Class Initialized
INFO - 2020-04-04 10:22:58 --> Helper loaded: url_helper
INFO - 2020-04-04 10:22:58 --> Helper loaded: file_helper
INFO - 2020-04-04 10:22:58 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:22:58 --> Helper loaded: common_helper
INFO - 2020-04-04 10:22:58 --> Helper loaded: language_helper
INFO - 2020-04-04 10:22:58 --> Helper loaded: email_helper
INFO - 2020-04-04 10:22:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:22:58 --> Database Driver Class Initialized
INFO - 2020-04-04 10:22:58 --> Parser Class Initialized
INFO - 2020-04-04 10:22:58 --> User Agent Class Initialized
INFO - 2020-04-04 10:22:58 --> Model Class Initialized
INFO - 2020-04-04 10:22:58 --> Model Class Initialized
DEBUG - 2020-04-04 10:22:58 --> Template Class Initialized
INFO - 2020-04-04 10:22:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:22:59 --> Email Class Initialized
INFO - 2020-04-04 10:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:22:59 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:22:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:22:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:22:59 --> Encryption Class Initialized
INFO - 2020-04-04 10:22:59 --> Controller Class Initialized
DEBUG - 2020-04-04 10:22:59 --> auth MX_Controller Initialized
INFO - 2020-04-04 10:22:59 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-04 10:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-04 10:22:59 --> Final output sent to browser
DEBUG - 2020-04-04 10:22:59 --> Total execution time: 0.8706
INFO - 2020-04-04 10:23:12 --> Config Class Initialized
INFO - 2020-04-04 10:23:12 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:23:12 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:23:12 --> Utf8 Class Initialized
INFO - 2020-04-04 10:23:12 --> URI Class Initialized
INFO - 2020-04-04 10:23:12 --> Router Class Initialized
INFO - 2020-04-04 10:23:12 --> Output Class Initialized
INFO - 2020-04-04 10:23:12 --> Security Class Initialized
DEBUG - 2020-04-04 10:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:23:12 --> CSRF cookie sent
INFO - 2020-04-04 10:23:12 --> CSRF token verified
INFO - 2020-04-04 10:23:12 --> Input Class Initialized
INFO - 2020-04-04 10:23:12 --> Language Class Initialized
INFO - 2020-04-04 10:23:12 --> Language Class Initialized
INFO - 2020-04-04 10:23:12 --> Config Class Initialized
INFO - 2020-04-04 10:23:12 --> Loader Class Initialized
INFO - 2020-04-04 10:23:12 --> Helper loaded: url_helper
INFO - 2020-04-04 10:23:12 --> Helper loaded: file_helper
INFO - 2020-04-04 10:23:12 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:23:12 --> Helper loaded: common_helper
INFO - 2020-04-04 10:23:12 --> Helper loaded: language_helper
INFO - 2020-04-04 10:23:12 --> Helper loaded: email_helper
INFO - 2020-04-04 10:23:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:23:12 --> Database Driver Class Initialized
INFO - 2020-04-04 10:23:12 --> Parser Class Initialized
INFO - 2020-04-04 10:23:12 --> User Agent Class Initialized
INFO - 2020-04-04 10:23:12 --> Model Class Initialized
INFO - 2020-04-04 10:23:12 --> Model Class Initialized
DEBUG - 2020-04-04 10:23:12 --> Template Class Initialized
INFO - 2020-04-04 10:23:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:23:12 --> Email Class Initialized
INFO - 2020-04-04 10:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:23:12 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:23:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:23:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:23:12 --> Encryption Class Initialized
INFO - 2020-04-04 10:23:12 --> Controller Class Initialized
DEBUG - 2020-04-04 10:23:12 --> auth MX_Controller Initialized
INFO - 2020-04-04 10:23:18 --> Config Class Initialized
INFO - 2020-04-04 10:23:18 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:23:18 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:23:18 --> Utf8 Class Initialized
INFO - 2020-04-04 10:23:18 --> URI Class Initialized
INFO - 2020-04-04 10:23:18 --> Router Class Initialized
INFO - 2020-04-04 10:23:18 --> Output Class Initialized
INFO - 2020-04-04 10:23:18 --> Security Class Initialized
DEBUG - 2020-04-04 10:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:23:18 --> CSRF cookie sent
INFO - 2020-04-04 10:23:18 --> CSRF token verified
INFO - 2020-04-04 10:23:18 --> Input Class Initialized
INFO - 2020-04-04 10:23:18 --> Language Class Initialized
INFO - 2020-04-04 10:23:18 --> Language Class Initialized
INFO - 2020-04-04 10:23:18 --> Config Class Initialized
INFO - 2020-04-04 10:23:18 --> Loader Class Initialized
INFO - 2020-04-04 10:23:18 --> Helper loaded: url_helper
INFO - 2020-04-04 10:23:18 --> Helper loaded: file_helper
INFO - 2020-04-04 10:23:18 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:23:18 --> Helper loaded: common_helper
INFO - 2020-04-04 10:23:18 --> Helper loaded: language_helper
INFO - 2020-04-04 10:23:18 --> Helper loaded: email_helper
INFO - 2020-04-04 10:23:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:23:19 --> Database Driver Class Initialized
INFO - 2020-04-04 10:23:19 --> Parser Class Initialized
INFO - 2020-04-04 10:23:19 --> User Agent Class Initialized
INFO - 2020-04-04 10:23:19 --> Model Class Initialized
INFO - 2020-04-04 10:23:19 --> Model Class Initialized
DEBUG - 2020-04-04 10:23:19 --> Template Class Initialized
INFO - 2020-04-04 10:23:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:23:19 --> Email Class Initialized
INFO - 2020-04-04 10:23:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:23:19 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:23:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:23:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:23:19 --> Encryption Class Initialized
INFO - 2020-04-04 10:23:19 --> Controller Class Initialized
DEBUG - 2020-04-04 10:23:19 --> auth MX_Controller Initialized
INFO - 2020-04-04 10:23:26 --> Config Class Initialized
INFO - 2020-04-04 10:23:26 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:23:26 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:23:26 --> Utf8 Class Initialized
INFO - 2020-04-04 10:23:26 --> URI Class Initialized
INFO - 2020-04-04 10:23:26 --> Router Class Initialized
INFO - 2020-04-04 10:23:26 --> Output Class Initialized
INFO - 2020-04-04 10:23:26 --> Security Class Initialized
DEBUG - 2020-04-04 10:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:23:26 --> CSRF cookie sent
INFO - 2020-04-04 10:23:26 --> CSRF token verified
INFO - 2020-04-04 10:23:26 --> Input Class Initialized
INFO - 2020-04-04 10:23:26 --> Language Class Initialized
INFO - 2020-04-04 10:23:26 --> Language Class Initialized
INFO - 2020-04-04 10:23:26 --> Config Class Initialized
INFO - 2020-04-04 10:23:26 --> Loader Class Initialized
INFO - 2020-04-04 10:23:26 --> Helper loaded: url_helper
INFO - 2020-04-04 10:23:26 --> Helper loaded: file_helper
INFO - 2020-04-04 10:23:26 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:23:26 --> Helper loaded: common_helper
INFO - 2020-04-04 10:23:26 --> Helper loaded: language_helper
INFO - 2020-04-04 10:23:26 --> Helper loaded: email_helper
INFO - 2020-04-04 10:23:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:23:26 --> Database Driver Class Initialized
INFO - 2020-04-04 10:23:26 --> Parser Class Initialized
INFO - 2020-04-04 10:23:26 --> User Agent Class Initialized
INFO - 2020-04-04 10:23:26 --> Model Class Initialized
INFO - 2020-04-04 10:23:26 --> Model Class Initialized
DEBUG - 2020-04-04 10:23:26 --> Template Class Initialized
INFO - 2020-04-04 10:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:23:26 --> Email Class Initialized
INFO - 2020-04-04 10:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:23:26 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:23:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:23:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:23:26 --> Encryption Class Initialized
INFO - 2020-04-04 10:23:26 --> Controller Class Initialized
DEBUG - 2020-04-04 10:23:26 --> auth MX_Controller Initialized
INFO - 2020-04-04 10:25:38 --> Config Class Initialized
INFO - 2020-04-04 10:25:38 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:25:38 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:25:38 --> Utf8 Class Initialized
INFO - 2020-04-04 10:25:38 --> URI Class Initialized
INFO - 2020-04-04 10:25:38 --> Router Class Initialized
INFO - 2020-04-04 10:25:38 --> Output Class Initialized
INFO - 2020-04-04 10:25:38 --> Security Class Initialized
DEBUG - 2020-04-04 10:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:25:38 --> CSRF cookie sent
INFO - 2020-04-04 10:25:38 --> Input Class Initialized
INFO - 2020-04-04 10:25:38 --> Language Class Initialized
INFO - 2020-04-04 10:25:38 --> Language Class Initialized
INFO - 2020-04-04 10:25:38 --> Config Class Initialized
INFO - 2020-04-04 10:25:38 --> Loader Class Initialized
INFO - 2020-04-04 10:25:38 --> Helper loaded: url_helper
INFO - 2020-04-04 10:25:38 --> Helper loaded: file_helper
INFO - 2020-04-04 10:25:38 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:25:38 --> Helper loaded: common_helper
INFO - 2020-04-04 10:25:38 --> Helper loaded: language_helper
INFO - 2020-04-04 10:25:38 --> Helper loaded: email_helper
INFO - 2020-04-04 10:25:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:25:38 --> Database Driver Class Initialized
INFO - 2020-04-04 10:25:38 --> Parser Class Initialized
INFO - 2020-04-04 10:25:38 --> User Agent Class Initialized
INFO - 2020-04-04 10:25:38 --> Model Class Initialized
INFO - 2020-04-04 10:25:38 --> Model Class Initialized
DEBUG - 2020-04-04 10:25:38 --> Template Class Initialized
INFO - 2020-04-04 10:25:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:25:38 --> Email Class Initialized
INFO - 2020-04-04 10:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:25:39 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:25:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:25:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:25:39 --> Encryption Class Initialized
INFO - 2020-04-04 10:25:39 --> Controller Class Initialized
DEBUG - 2020-04-04 10:25:39 --> follow MX_Controller Initialized
INFO - 2020-04-04 10:25:39 --> Model Class Initialized
DEBUG - 2020-04-04 10:25:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-04 10:25:39 --> Model Class Initialized
INFO - 2020-04-04 10:25:39 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:25:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/setting.php
DEBUG - 2020-04-04 10:25:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/content.php
DEBUG - 2020-04-04 10:25:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-04 10:25:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:25:39 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:25:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:25:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:25:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:25:39 --> Final output sent to browser
DEBUG - 2020-04-04 10:25:39 --> Total execution time: 0.6434
INFO - 2020-04-04 10:26:10 --> Config Class Initialized
INFO - 2020-04-04 10:26:10 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:26:10 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:26:10 --> Utf8 Class Initialized
INFO - 2020-04-04 10:26:10 --> URI Class Initialized
INFO - 2020-04-04 10:26:10 --> Router Class Initialized
INFO - 2020-04-04 10:26:10 --> Output Class Initialized
INFO - 2020-04-04 10:26:10 --> Security Class Initialized
DEBUG - 2020-04-04 10:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:26:10 --> CSRF cookie sent
INFO - 2020-04-04 10:26:10 --> Input Class Initialized
INFO - 2020-04-04 10:26:10 --> Language Class Initialized
INFO - 2020-04-04 10:26:11 --> Language Class Initialized
INFO - 2020-04-04 10:26:11 --> Config Class Initialized
INFO - 2020-04-04 10:26:11 --> Loader Class Initialized
INFO - 2020-04-04 10:26:11 --> Helper loaded: url_helper
INFO - 2020-04-04 10:26:11 --> Helper loaded: file_helper
INFO - 2020-04-04 10:26:11 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:26:11 --> Helper loaded: common_helper
INFO - 2020-04-04 10:26:11 --> Helper loaded: language_helper
INFO - 2020-04-04 10:26:11 --> Helper loaded: email_helper
INFO - 2020-04-04 10:26:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:26:11 --> Database Driver Class Initialized
INFO - 2020-04-04 10:26:11 --> Parser Class Initialized
INFO - 2020-04-04 10:26:11 --> User Agent Class Initialized
INFO - 2020-04-04 10:26:11 --> Model Class Initialized
INFO - 2020-04-04 10:26:11 --> Model Class Initialized
DEBUG - 2020-04-04 10:26:11 --> Template Class Initialized
INFO - 2020-04-04 10:26:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:26:11 --> Email Class Initialized
INFO - 2020-04-04 10:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:26:11 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:26:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:26:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:26:11 --> Encryption Class Initialized
INFO - 2020-04-04 10:26:11 --> Controller Class Initialized
DEBUG - 2020-04-04 10:26:11 --> like MX_Controller Initialized
INFO - 2020-04-04 10:26:11 --> Model Class Initialized
DEBUG - 2020-04-04 10:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/models/like_model.php
INFO - 2020-04-04 10:26:11 --> Model Class Initialized
INFO - 2020-04-04 10:26:11 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/index.php
DEBUG - 2020-04-04 10:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:26:11 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:26:11 --> Final output sent to browser
DEBUG - 2020-04-04 10:26:11 --> Total execution time: 0.6161
INFO - 2020-04-04 10:26:12 --> Config Class Initialized
INFO - 2020-04-04 10:26:12 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:26:12 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:26:12 --> Utf8 Class Initialized
INFO - 2020-04-04 10:26:12 --> URI Class Initialized
INFO - 2020-04-04 10:26:12 --> Router Class Initialized
INFO - 2020-04-04 10:26:12 --> Output Class Initialized
INFO - 2020-04-04 10:26:12 --> Security Class Initialized
DEBUG - 2020-04-04 10:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:26:12 --> CSRF cookie sent
INFO - 2020-04-04 10:26:12 --> Input Class Initialized
INFO - 2020-04-04 10:26:12 --> Language Class Initialized
INFO - 2020-04-04 10:26:12 --> Language Class Initialized
INFO - 2020-04-04 10:26:12 --> Config Class Initialized
INFO - 2020-04-04 10:26:12 --> Loader Class Initialized
INFO - 2020-04-04 10:26:12 --> Helper loaded: url_helper
INFO - 2020-04-04 10:26:12 --> Helper loaded: file_helper
INFO - 2020-04-04 10:26:12 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:26:12 --> Helper loaded: common_helper
INFO - 2020-04-04 10:26:12 --> Helper loaded: language_helper
INFO - 2020-04-04 10:26:12 --> Helper loaded: email_helper
INFO - 2020-04-04 10:26:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:26:12 --> Database Driver Class Initialized
INFO - 2020-04-04 10:26:12 --> Parser Class Initialized
INFO - 2020-04-04 10:26:12 --> User Agent Class Initialized
INFO - 2020-04-04 10:26:12 --> Model Class Initialized
INFO - 2020-04-04 10:26:12 --> Model Class Initialized
DEBUG - 2020-04-04 10:26:13 --> Template Class Initialized
INFO - 2020-04-04 10:26:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:26:13 --> Email Class Initialized
INFO - 2020-04-04 10:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:26:13 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:26:13 --> Encryption Class Initialized
INFO - 2020-04-04 10:26:13 --> Controller Class Initialized
DEBUG - 2020-04-04 10:26:13 --> like MX_Controller Initialized
INFO - 2020-04-04 10:26:13 --> Model Class Initialized
DEBUG - 2020-04-04 10:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/models/like_model.php
INFO - 2020-04-04 10:26:13 --> Model Class Initialized
INFO - 2020-04-04 10:26:13 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/setting.php
DEBUG - 2020-04-04 10:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/content.php
DEBUG - 2020-04-04 10:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/index.php
DEBUG - 2020-04-04 10:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:26:13 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:26:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:26:13 --> Final output sent to browser
DEBUG - 2020-04-04 10:26:13 --> Total execution time: 0.6058
INFO - 2020-04-04 10:31:40 --> Config Class Initialized
INFO - 2020-04-04 10:31:40 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:31:40 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:31:40 --> Utf8 Class Initialized
INFO - 2020-04-04 10:31:40 --> URI Class Initialized
INFO - 2020-04-04 10:31:40 --> Router Class Initialized
INFO - 2020-04-04 10:31:40 --> Output Class Initialized
INFO - 2020-04-04 10:31:40 --> Security Class Initialized
DEBUG - 2020-04-04 10:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:31:40 --> CSRF cookie sent
INFO - 2020-04-04 10:31:40 --> CSRF token verified
INFO - 2020-04-04 10:31:40 --> Input Class Initialized
INFO - 2020-04-04 10:31:40 --> Language Class Initialized
INFO - 2020-04-04 10:31:40 --> Language Class Initialized
INFO - 2020-04-04 10:31:40 --> Config Class Initialized
INFO - 2020-04-04 10:31:40 --> Loader Class Initialized
INFO - 2020-04-04 10:31:40 --> Helper loaded: url_helper
INFO - 2020-04-04 10:31:40 --> Helper loaded: file_helper
INFO - 2020-04-04 10:31:40 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:31:40 --> Helper loaded: common_helper
INFO - 2020-04-04 10:31:40 --> Helper loaded: language_helper
INFO - 2020-04-04 10:31:40 --> Helper loaded: email_helper
INFO - 2020-04-04 10:31:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:31:40 --> Database Driver Class Initialized
INFO - 2020-04-04 10:31:40 --> Parser Class Initialized
INFO - 2020-04-04 10:31:40 --> User Agent Class Initialized
INFO - 2020-04-04 10:31:40 --> Model Class Initialized
INFO - 2020-04-04 10:31:40 --> Model Class Initialized
DEBUG - 2020-04-04 10:31:40 --> Template Class Initialized
INFO - 2020-04-04 10:31:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:31:40 --> Email Class Initialized
INFO - 2020-04-04 10:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:31:40 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:31:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:31:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:31:41 --> Encryption Class Initialized
INFO - 2020-04-04 10:31:41 --> Controller Class Initialized
DEBUG - 2020-04-04 10:31:41 --> like MX_Controller Initialized
INFO - 2020-04-04 10:31:41 --> Model Class Initialized
DEBUG - 2020-04-04 10:31:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/models/like_model.php
INFO - 2020-04-04 10:31:41 --> Model Class Initialized
DEBUG - 2020-04-04 10:31:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/log.php
INFO - 2020-04-04 10:31:41 --> Final output sent to browser
DEBUG - 2020-04-04 10:31:41 --> Total execution time: 0.4967
INFO - 2020-04-04 10:31:44 --> Config Class Initialized
INFO - 2020-04-04 10:31:44 --> Config Class Initialized
INFO - 2020-04-04 10:31:44 --> Hooks Class Initialized
INFO - 2020-04-04 10:31:44 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:31:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 10:31:44 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:31:44 --> Utf8 Class Initialized
INFO - 2020-04-04 10:31:44 --> Utf8 Class Initialized
INFO - 2020-04-04 10:31:44 --> URI Class Initialized
INFO - 2020-04-04 10:31:44 --> URI Class Initialized
INFO - 2020-04-04 10:31:44 --> Router Class Initialized
INFO - 2020-04-04 10:31:44 --> Router Class Initialized
INFO - 2020-04-04 10:31:44 --> Output Class Initialized
INFO - 2020-04-04 10:31:44 --> Output Class Initialized
INFO - 2020-04-04 10:31:44 --> Security Class Initialized
INFO - 2020-04-04 10:31:44 --> Security Class Initialized
DEBUG - 2020-04-04 10:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 10:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:31:44 --> CSRF cookie sent
INFO - 2020-04-04 10:31:44 --> CSRF cookie sent
INFO - 2020-04-04 10:31:44 --> Input Class Initialized
INFO - 2020-04-04 10:31:44 --> Input Class Initialized
INFO - 2020-04-04 10:31:44 --> Language Class Initialized
INFO - 2020-04-04 10:31:44 --> Language Class Initialized
ERROR - 2020-04-04 10:31:44 --> 404 Page Not Found: /index
ERROR - 2020-04-04 10:31:44 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:36:03 --> Config Class Initialized
INFO - 2020-04-04 10:36:03 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:36:03 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:36:03 --> Utf8 Class Initialized
INFO - 2020-04-04 10:36:03 --> URI Class Initialized
INFO - 2020-04-04 10:36:03 --> Router Class Initialized
INFO - 2020-04-04 10:36:03 --> Output Class Initialized
INFO - 2020-04-04 10:36:03 --> Security Class Initialized
DEBUG - 2020-04-04 10:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:36:03 --> CSRF cookie sent
INFO - 2020-04-04 10:36:03 --> Input Class Initialized
INFO - 2020-04-04 10:36:03 --> Language Class Initialized
INFO - 2020-04-04 10:36:03 --> Language Class Initialized
INFO - 2020-04-04 10:36:03 --> Config Class Initialized
INFO - 2020-04-04 10:36:03 --> Loader Class Initialized
INFO - 2020-04-04 10:36:03 --> Helper loaded: url_helper
INFO - 2020-04-04 10:36:03 --> Helper loaded: file_helper
INFO - 2020-04-04 10:36:03 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:36:03 --> Helper loaded: common_helper
INFO - 2020-04-04 10:36:03 --> Helper loaded: language_helper
INFO - 2020-04-04 10:36:03 --> Helper loaded: email_helper
INFO - 2020-04-04 10:36:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:36:03 --> Database Driver Class Initialized
INFO - 2020-04-04 10:36:03 --> Parser Class Initialized
INFO - 2020-04-04 10:36:03 --> User Agent Class Initialized
INFO - 2020-04-04 10:36:03 --> Model Class Initialized
INFO - 2020-04-04 10:36:03 --> Model Class Initialized
DEBUG - 2020-04-04 10:36:03 --> Template Class Initialized
INFO - 2020-04-04 10:36:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:36:03 --> Email Class Initialized
INFO - 2020-04-04 10:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:36:03 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:36:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:36:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:36:03 --> Encryption Class Initialized
INFO - 2020-04-04 10:36:03 --> Controller Class Initialized
DEBUG - 2020-04-04 10:36:03 --> like MX_Controller Initialized
INFO - 2020-04-04 10:36:03 --> Model Class Initialized
DEBUG - 2020-04-04 10:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/models/like_model.php
INFO - 2020-04-04 10:36:03 --> Model Class Initialized
INFO - 2020-04-04 10:36:03 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/setting.php
DEBUG - 2020-04-04 10:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/content.php
DEBUG - 2020-04-04 10:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/index.php
DEBUG - 2020-04-04 10:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:36:03 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:36:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:36:03 --> Final output sent to browser
DEBUG - 2020-04-04 10:36:03 --> Total execution time: 0.6701
INFO - 2020-04-04 10:36:04 --> Config Class Initialized
INFO - 2020-04-04 10:36:04 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:36:04 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:36:04 --> Utf8 Class Initialized
INFO - 2020-04-04 10:36:04 --> URI Class Initialized
INFO - 2020-04-04 10:36:04 --> Router Class Initialized
INFO - 2020-04-04 10:36:04 --> Output Class Initialized
INFO - 2020-04-04 10:36:04 --> Security Class Initialized
DEBUG - 2020-04-04 10:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:36:04 --> CSRF cookie sent
INFO - 2020-04-04 10:36:04 --> Input Class Initialized
INFO - 2020-04-04 10:36:04 --> Config Class Initialized
INFO - 2020-04-04 10:36:04 --> Hooks Class Initialized
INFO - 2020-04-04 10:36:04 --> Language Class Initialized
ERROR - 2020-04-04 10:36:04 --> 404 Page Not Found: /index
DEBUG - 2020-04-04 10:36:04 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:36:04 --> Utf8 Class Initialized
INFO - 2020-04-04 10:36:04 --> URI Class Initialized
INFO - 2020-04-04 10:36:04 --> Router Class Initialized
INFO - 2020-04-04 10:36:04 --> Output Class Initialized
INFO - 2020-04-04 10:36:04 --> Security Class Initialized
DEBUG - 2020-04-04 10:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:36:04 --> CSRF cookie sent
INFO - 2020-04-04 10:36:04 --> Input Class Initialized
INFO - 2020-04-04 10:36:04 --> Language Class Initialized
ERROR - 2020-04-04 10:36:04 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:36:05 --> Config Class Initialized
INFO - 2020-04-04 10:36:05 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:36:05 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:36:05 --> Utf8 Class Initialized
INFO - 2020-04-04 10:36:05 --> URI Class Initialized
INFO - 2020-04-04 10:36:05 --> Router Class Initialized
INFO - 2020-04-04 10:36:05 --> Output Class Initialized
INFO - 2020-04-04 10:36:05 --> Security Class Initialized
DEBUG - 2020-04-04 10:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:36:05 --> CSRF cookie sent
INFO - 2020-04-04 10:36:05 --> CSRF token verified
INFO - 2020-04-04 10:36:05 --> Input Class Initialized
INFO - 2020-04-04 10:36:05 --> Language Class Initialized
INFO - 2020-04-04 10:36:05 --> Language Class Initialized
INFO - 2020-04-04 10:36:05 --> Config Class Initialized
INFO - 2020-04-04 10:36:05 --> Loader Class Initialized
INFO - 2020-04-04 10:36:05 --> Helper loaded: url_helper
INFO - 2020-04-04 10:36:05 --> Helper loaded: file_helper
INFO - 2020-04-04 10:36:05 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:36:05 --> Helper loaded: common_helper
INFO - 2020-04-04 10:36:05 --> Helper loaded: language_helper
INFO - 2020-04-04 10:36:06 --> Helper loaded: email_helper
INFO - 2020-04-04 10:36:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:36:06 --> Database Driver Class Initialized
INFO - 2020-04-04 10:36:06 --> Parser Class Initialized
INFO - 2020-04-04 10:36:06 --> User Agent Class Initialized
INFO - 2020-04-04 10:36:06 --> Model Class Initialized
INFO - 2020-04-04 10:36:06 --> Model Class Initialized
DEBUG - 2020-04-04 10:36:06 --> Template Class Initialized
INFO - 2020-04-04 10:36:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:36:06 --> Email Class Initialized
INFO - 2020-04-04 10:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:36:06 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:36:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:36:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:36:06 --> Encryption Class Initialized
INFO - 2020-04-04 10:36:06 --> Controller Class Initialized
DEBUG - 2020-04-04 10:36:06 --> like MX_Controller Initialized
INFO - 2020-04-04 10:36:06 --> Model Class Initialized
DEBUG - 2020-04-04 10:36:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/models/like_model.php
INFO - 2020-04-04 10:36:06 --> Model Class Initialized
DEBUG - 2020-04-04 10:36:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/log.php
INFO - 2020-04-04 10:36:06 --> Final output sent to browser
DEBUG - 2020-04-04 10:36:06 --> Total execution time: 0.5986
INFO - 2020-04-04 10:39:26 --> Config Class Initialized
INFO - 2020-04-04 10:39:26 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:39:26 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:39:26 --> Utf8 Class Initialized
INFO - 2020-04-04 10:39:26 --> URI Class Initialized
INFO - 2020-04-04 10:39:26 --> Router Class Initialized
INFO - 2020-04-04 10:39:26 --> Output Class Initialized
INFO - 2020-04-04 10:39:26 --> Security Class Initialized
DEBUG - 2020-04-04 10:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:39:26 --> CSRF cookie sent
INFO - 2020-04-04 10:39:26 --> Input Class Initialized
INFO - 2020-04-04 10:39:26 --> Language Class Initialized
INFO - 2020-04-04 10:39:26 --> Language Class Initialized
INFO - 2020-04-04 10:39:26 --> Config Class Initialized
INFO - 2020-04-04 10:39:26 --> Loader Class Initialized
INFO - 2020-04-04 10:39:26 --> Helper loaded: url_helper
INFO - 2020-04-04 10:39:26 --> Helper loaded: file_helper
INFO - 2020-04-04 10:39:26 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:39:26 --> Helper loaded: common_helper
INFO - 2020-04-04 10:39:26 --> Helper loaded: language_helper
INFO - 2020-04-04 10:39:26 --> Helper loaded: email_helper
INFO - 2020-04-04 10:39:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:39:27 --> Database Driver Class Initialized
INFO - 2020-04-04 10:39:27 --> Parser Class Initialized
INFO - 2020-04-04 10:39:27 --> User Agent Class Initialized
INFO - 2020-04-04 10:39:27 --> Model Class Initialized
INFO - 2020-04-04 10:39:27 --> Model Class Initialized
DEBUG - 2020-04-04 10:39:27 --> Template Class Initialized
INFO - 2020-04-04 10:39:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:39:27 --> Email Class Initialized
INFO - 2020-04-04 10:39:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:39:27 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:39:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:39:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:39:27 --> Encryption Class Initialized
INFO - 2020-04-04 10:39:27 --> Controller Class Initialized
DEBUG - 2020-04-04 10:39:27 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:39:27 --> Model Class Initialized
INFO - 2020-04-04 10:39:27 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:39:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:39:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:39:27 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:39:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:39:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:39:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:39:27 --> Final output sent to browser
DEBUG - 2020-04-04 10:39:27 --> Total execution time: 0.6156
INFO - 2020-04-04 10:39:27 --> Config Class Initialized
INFO - 2020-04-04 10:39:27 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:39:27 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:39:27 --> Utf8 Class Initialized
INFO - 2020-04-04 10:39:27 --> URI Class Initialized
INFO - 2020-04-04 10:39:27 --> Router Class Initialized
INFO - 2020-04-04 10:39:27 --> Output Class Initialized
INFO - 2020-04-04 10:39:27 --> Security Class Initialized
DEBUG - 2020-04-04 10:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:39:27 --> CSRF cookie sent
INFO - 2020-04-04 10:39:27 --> Input Class Initialized
INFO - 2020-04-04 10:39:27 --> Language Class Initialized
ERROR - 2020-04-04 10:39:27 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:39:27 --> Config Class Initialized
INFO - 2020-04-04 10:39:27 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:39:27 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:39:28 --> Utf8 Class Initialized
INFO - 2020-04-04 10:39:28 --> URI Class Initialized
INFO - 2020-04-04 10:39:28 --> Router Class Initialized
INFO - 2020-04-04 10:39:28 --> Output Class Initialized
INFO - 2020-04-04 10:39:28 --> Security Class Initialized
DEBUG - 2020-04-04 10:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:39:28 --> CSRF cookie sent
INFO - 2020-04-04 10:39:28 --> Input Class Initialized
INFO - 2020-04-04 10:39:28 --> Language Class Initialized
ERROR - 2020-04-04 10:39:28 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:39:34 --> Config Class Initialized
INFO - 2020-04-04 10:39:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:39:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:39:34 --> Utf8 Class Initialized
INFO - 2020-04-04 10:39:34 --> URI Class Initialized
INFO - 2020-04-04 10:39:34 --> Router Class Initialized
INFO - 2020-04-04 10:39:34 --> Output Class Initialized
INFO - 2020-04-04 10:39:34 --> Security Class Initialized
DEBUG - 2020-04-04 10:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:39:34 --> CSRF cookie sent
INFO - 2020-04-04 10:42:20 --> Config Class Initialized
INFO - 2020-04-04 10:42:20 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:42:20 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:42:20 --> Utf8 Class Initialized
INFO - 2020-04-04 10:42:20 --> URI Class Initialized
INFO - 2020-04-04 10:42:20 --> Router Class Initialized
INFO - 2020-04-04 10:42:20 --> Output Class Initialized
INFO - 2020-04-04 10:42:20 --> Security Class Initialized
DEBUG - 2020-04-04 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:42:20 --> CSRF cookie sent
INFO - 2020-04-04 10:42:20 --> Input Class Initialized
INFO - 2020-04-04 10:42:20 --> Language Class Initialized
INFO - 2020-04-04 10:42:20 --> Language Class Initialized
INFO - 2020-04-04 10:42:20 --> Config Class Initialized
INFO - 2020-04-04 10:42:20 --> Loader Class Initialized
INFO - 2020-04-04 10:42:20 --> Helper loaded: url_helper
INFO - 2020-04-04 10:42:20 --> Helper loaded: file_helper
INFO - 2020-04-04 10:42:20 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:42:20 --> Helper loaded: common_helper
INFO - 2020-04-04 10:42:20 --> Helper loaded: language_helper
INFO - 2020-04-04 10:42:20 --> Helper loaded: email_helper
INFO - 2020-04-04 10:42:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:42:21 --> Database Driver Class Initialized
INFO - 2020-04-04 10:42:21 --> Parser Class Initialized
INFO - 2020-04-04 10:42:21 --> User Agent Class Initialized
INFO - 2020-04-04 10:42:21 --> Model Class Initialized
INFO - 2020-04-04 10:42:21 --> Model Class Initialized
DEBUG - 2020-04-04 10:42:21 --> Template Class Initialized
INFO - 2020-04-04 10:42:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:42:21 --> Email Class Initialized
INFO - 2020-04-04 10:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:42:21 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:42:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:42:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:42:21 --> Encryption Class Initialized
INFO - 2020-04-04 10:42:21 --> Controller Class Initialized
DEBUG - 2020-04-04 10:42:21 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:42:21 --> Model Class Initialized
INFO - 2020-04-04 10:42:21 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:42:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:42:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:42:21 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:42:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:42:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:42:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:42:21 --> Final output sent to browser
DEBUG - 2020-04-04 10:42:21 --> Total execution time: 0.6820
INFO - 2020-04-04 10:42:21 --> Config Class Initialized
INFO - 2020-04-04 10:42:21 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:42:21 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:42:21 --> Utf8 Class Initialized
INFO - 2020-04-04 10:42:21 --> URI Class Initialized
INFO - 2020-04-04 10:42:21 --> Router Class Initialized
INFO - 2020-04-04 10:42:21 --> Output Class Initialized
INFO - 2020-04-04 10:42:21 --> Security Class Initialized
DEBUG - 2020-04-04 10:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:42:21 --> CSRF cookie sent
INFO - 2020-04-04 10:42:21 --> Input Class Initialized
INFO - 2020-04-04 10:42:21 --> Language Class Initialized
ERROR - 2020-04-04 10:42:21 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:42:21 --> Config Class Initialized
INFO - 2020-04-04 10:42:21 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:42:21 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:42:21 --> Utf8 Class Initialized
INFO - 2020-04-04 10:42:21 --> URI Class Initialized
INFO - 2020-04-04 10:42:22 --> Router Class Initialized
INFO - 2020-04-04 10:42:22 --> Output Class Initialized
INFO - 2020-04-04 10:42:22 --> Security Class Initialized
DEBUG - 2020-04-04 10:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:42:22 --> CSRF cookie sent
INFO - 2020-04-04 10:42:22 --> Input Class Initialized
INFO - 2020-04-04 10:42:22 --> Language Class Initialized
ERROR - 2020-04-04 10:42:22 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:42:24 --> Config Class Initialized
INFO - 2020-04-04 10:42:24 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:42:24 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:42:24 --> Utf8 Class Initialized
INFO - 2020-04-04 10:42:24 --> URI Class Initialized
INFO - 2020-04-04 10:42:24 --> Router Class Initialized
INFO - 2020-04-04 10:42:24 --> Output Class Initialized
INFO - 2020-04-04 10:42:24 --> Security Class Initialized
DEBUG - 2020-04-04 10:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:42:24 --> CSRF cookie sent
INFO - 2020-04-04 10:42:24 --> Input Class Initialized
INFO - 2020-04-04 10:42:24 --> Language Class Initialized
INFO - 2020-04-04 10:42:24 --> Language Class Initialized
INFO - 2020-04-04 10:42:24 --> Config Class Initialized
INFO - 2020-04-04 10:42:24 --> Loader Class Initialized
INFO - 2020-04-04 10:42:24 --> Helper loaded: url_helper
INFO - 2020-04-04 10:42:24 --> Helper loaded: file_helper
INFO - 2020-04-04 10:42:24 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:42:24 --> Helper loaded: common_helper
INFO - 2020-04-04 10:42:24 --> Helper loaded: language_helper
INFO - 2020-04-04 10:42:24 --> Helper loaded: email_helper
INFO - 2020-04-04 10:42:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:42:24 --> Database Driver Class Initialized
INFO - 2020-04-04 10:42:24 --> Parser Class Initialized
INFO - 2020-04-04 10:42:24 --> User Agent Class Initialized
INFO - 2020-04-04 10:42:24 --> Model Class Initialized
INFO - 2020-04-04 10:42:24 --> Model Class Initialized
DEBUG - 2020-04-04 10:42:24 --> Template Class Initialized
INFO - 2020-04-04 10:42:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:42:24 --> Email Class Initialized
INFO - 2020-04-04 10:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:42:24 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:42:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:42:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:42:24 --> Encryption Class Initialized
INFO - 2020-04-04 10:42:24 --> Controller Class Initialized
DEBUG - 2020-04-04 10:42:24 --> retweet MX_Controller Initialized
INFO - 2020-04-04 10:42:24 --> Model Class Initialized
DEBUG - 2020-04-04 10:42:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/retweet/models/retweet_model.php
INFO - 2020-04-04 10:42:24 --> Model Class Initialized
INFO - 2020-04-04 10:42:24 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:42:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/retweet/views/index.php
DEBUG - 2020-04-04 10:42:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:42:24 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:42:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:42:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:42:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:42:24 --> Final output sent to browser
DEBUG - 2020-04-04 10:42:25 --> Total execution time: 0.5770
INFO - 2020-04-04 10:42:28 --> Config Class Initialized
INFO - 2020-04-04 10:42:28 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:42:28 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:42:28 --> Utf8 Class Initialized
INFO - 2020-04-04 10:42:28 --> URI Class Initialized
INFO - 2020-04-04 10:42:28 --> Router Class Initialized
INFO - 2020-04-04 10:42:28 --> Output Class Initialized
INFO - 2020-04-04 10:42:28 --> Security Class Initialized
DEBUG - 2020-04-04 10:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:42:28 --> CSRF cookie sent
INFO - 2020-04-04 10:42:28 --> Input Class Initialized
INFO - 2020-04-04 10:42:28 --> Language Class Initialized
INFO - 2020-04-04 10:42:28 --> Language Class Initialized
INFO - 2020-04-04 10:42:28 --> Config Class Initialized
INFO - 2020-04-04 10:42:28 --> Loader Class Initialized
INFO - 2020-04-04 10:42:28 --> Helper loaded: url_helper
INFO - 2020-04-04 10:42:28 --> Helper loaded: file_helper
INFO - 2020-04-04 10:42:28 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:42:28 --> Helper loaded: common_helper
INFO - 2020-04-04 10:42:28 --> Helper loaded: language_helper
INFO - 2020-04-04 10:42:28 --> Helper loaded: email_helper
INFO - 2020-04-04 10:42:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:42:28 --> Database Driver Class Initialized
INFO - 2020-04-04 10:42:28 --> Parser Class Initialized
INFO - 2020-04-04 10:42:28 --> User Agent Class Initialized
INFO - 2020-04-04 10:42:28 --> Model Class Initialized
INFO - 2020-04-04 10:42:28 --> Model Class Initialized
DEBUG - 2020-04-04 10:42:28 --> Template Class Initialized
INFO - 2020-04-04 10:42:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:42:28 --> Email Class Initialized
INFO - 2020-04-04 10:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:42:28 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:42:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:42:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:42:28 --> Encryption Class Initialized
INFO - 2020-04-04 10:42:28 --> Controller Class Initialized
DEBUG - 2020-04-04 10:42:29 --> like MX_Controller Initialized
INFO - 2020-04-04 10:42:29 --> Model Class Initialized
DEBUG - 2020-04-04 10:42:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/models/like_model.php
INFO - 2020-04-04 10:42:29 --> Model Class Initialized
INFO - 2020-04-04 10:42:29 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:42:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/index.php
DEBUG - 2020-04-04 10:42:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:42:29 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:42:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:42:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:42:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:42:29 --> Final output sent to browser
DEBUG - 2020-04-04 10:42:29 --> Total execution time: 0.5704
INFO - 2020-04-04 10:44:24 --> Config Class Initialized
INFO - 2020-04-04 10:44:24 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:24 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:24 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:24 --> URI Class Initialized
INFO - 2020-04-04 10:44:25 --> Router Class Initialized
INFO - 2020-04-04 10:44:25 --> Output Class Initialized
INFO - 2020-04-04 10:44:25 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:25 --> CSRF cookie sent
INFO - 2020-04-04 10:44:25 --> Input Class Initialized
INFO - 2020-04-04 10:44:25 --> Language Class Initialized
INFO - 2020-04-04 10:44:25 --> Language Class Initialized
INFO - 2020-04-04 10:44:25 --> Config Class Initialized
INFO - 2020-04-04 10:44:25 --> Loader Class Initialized
INFO - 2020-04-04 10:44:25 --> Helper loaded: url_helper
INFO - 2020-04-04 10:44:25 --> Helper loaded: file_helper
INFO - 2020-04-04 10:44:25 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:44:25 --> Helper loaded: common_helper
INFO - 2020-04-04 10:44:25 --> Helper loaded: language_helper
INFO - 2020-04-04 10:44:25 --> Helper loaded: email_helper
INFO - 2020-04-04 10:44:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:44:25 --> Database Driver Class Initialized
INFO - 2020-04-04 10:44:25 --> Parser Class Initialized
INFO - 2020-04-04 10:44:25 --> User Agent Class Initialized
INFO - 2020-04-04 10:44:25 --> Model Class Initialized
INFO - 2020-04-04 10:44:25 --> Model Class Initialized
DEBUG - 2020-04-04 10:44:25 --> Template Class Initialized
INFO - 2020-04-04 10:44:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:44:25 --> Email Class Initialized
INFO - 2020-04-04 10:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:44:25 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:44:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:44:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:44:25 --> Encryption Class Initialized
INFO - 2020-04-04 10:44:25 --> Controller Class Initialized
DEBUG - 2020-04-04 10:44:25 --> like MX_Controller Initialized
INFO - 2020-04-04 10:44:25 --> Model Class Initialized
DEBUG - 2020-04-04 10:44:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/models/like_model.php
INFO - 2020-04-04 10:44:25 --> Model Class Initialized
INFO - 2020-04-04 10:44:25 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:44:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/index.php
DEBUG - 2020-04-04 10:44:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:44:25 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:44:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:44:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:44:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:44:25 --> Final output sent to browser
DEBUG - 2020-04-04 10:44:25 --> Total execution time: 0.6083
INFO - 2020-04-04 10:44:27 --> Config Class Initialized
INFO - 2020-04-04 10:44:27 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:27 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:27 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:27 --> URI Class Initialized
INFO - 2020-04-04 10:44:27 --> Router Class Initialized
INFO - 2020-04-04 10:44:27 --> Output Class Initialized
INFO - 2020-04-04 10:44:27 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:28 --> CSRF cookie sent
INFO - 2020-04-04 10:44:28 --> Input Class Initialized
INFO - 2020-04-04 10:44:28 --> Language Class Initialized
INFO - 2020-04-04 10:44:28 --> Language Class Initialized
INFO - 2020-04-04 10:44:28 --> Config Class Initialized
INFO - 2020-04-04 10:44:28 --> Loader Class Initialized
INFO - 2020-04-04 10:44:28 --> Helper loaded: url_helper
INFO - 2020-04-04 10:44:28 --> Helper loaded: file_helper
INFO - 2020-04-04 10:44:28 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:44:28 --> Helper loaded: common_helper
INFO - 2020-04-04 10:44:28 --> Helper loaded: language_helper
INFO - 2020-04-04 10:44:28 --> Helper loaded: email_helper
INFO - 2020-04-04 10:44:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:44:28 --> Database Driver Class Initialized
INFO - 2020-04-04 10:44:28 --> Parser Class Initialized
INFO - 2020-04-04 10:44:28 --> User Agent Class Initialized
INFO - 2020-04-04 10:44:28 --> Model Class Initialized
INFO - 2020-04-04 10:44:28 --> Model Class Initialized
DEBUG - 2020-04-04 10:44:28 --> Template Class Initialized
INFO - 2020-04-04 10:44:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:44:28 --> Email Class Initialized
INFO - 2020-04-04 10:44:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:44:28 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:44:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:44:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:44:28 --> Encryption Class Initialized
INFO - 2020-04-04 10:44:28 --> Controller Class Initialized
DEBUG - 2020-04-04 10:44:28 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:44:28 --> Model Class Initialized
INFO - 2020-04-04 10:44:28 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:44:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:44:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:44:28 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:44:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:44:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:44:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:44:28 --> Final output sent to browser
DEBUG - 2020-04-04 10:44:28 --> Total execution time: 0.5831
INFO - 2020-04-04 10:44:36 --> Config Class Initialized
INFO - 2020-04-04 10:44:36 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:36 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:36 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:36 --> URI Class Initialized
INFO - 2020-04-04 10:44:36 --> Router Class Initialized
INFO - 2020-04-04 10:44:36 --> Output Class Initialized
INFO - 2020-04-04 10:44:36 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:36 --> CSRF cookie sent
INFO - 2020-04-04 10:44:40 --> Config Class Initialized
INFO - 2020-04-04 10:44:40 --> Config Class Initialized
INFO - 2020-04-04 10:44:40 --> Hooks Class Initialized
INFO - 2020-04-04 10:44:40 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 10:44:40 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:40 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:40 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:40 --> URI Class Initialized
INFO - 2020-04-04 10:44:40 --> URI Class Initialized
INFO - 2020-04-04 10:44:40 --> Router Class Initialized
INFO - 2020-04-04 10:44:40 --> Router Class Initialized
INFO - 2020-04-04 10:44:40 --> Output Class Initialized
INFO - 2020-04-04 10:44:40 --> Output Class Initialized
INFO - 2020-04-04 10:44:40 --> Security Class Initialized
INFO - 2020-04-04 10:44:40 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 10:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:40 --> CSRF cookie sent
INFO - 2020-04-04 10:44:40 --> CSRF cookie sent
INFO - 2020-04-04 10:44:40 --> Input Class Initialized
INFO - 2020-04-04 10:44:40 --> Input Class Initialized
INFO - 2020-04-04 10:44:40 --> Language Class Initialized
INFO - 2020-04-04 10:44:40 --> Language Class Initialized
ERROR - 2020-04-04 10:44:40 --> 404 Page Not Found: /index
ERROR - 2020-04-04 10:44:40 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:44:42 --> Config Class Initialized
INFO - 2020-04-04 10:44:42 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:42 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:42 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:42 --> URI Class Initialized
INFO - 2020-04-04 10:44:42 --> Router Class Initialized
INFO - 2020-04-04 10:44:42 --> Output Class Initialized
INFO - 2020-04-04 10:44:42 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:42 --> CSRF cookie sent
INFO - 2020-04-04 10:44:42 --> Input Class Initialized
INFO - 2020-04-04 10:44:42 --> Language Class Initialized
INFO - 2020-04-04 10:44:42 --> Language Class Initialized
INFO - 2020-04-04 10:44:42 --> Config Class Initialized
INFO - 2020-04-04 10:44:42 --> Loader Class Initialized
INFO - 2020-04-04 10:44:42 --> Helper loaded: url_helper
INFO - 2020-04-04 10:44:42 --> Helper loaded: file_helper
INFO - 2020-04-04 10:44:42 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:44:42 --> Helper loaded: common_helper
INFO - 2020-04-04 10:44:42 --> Helper loaded: language_helper
INFO - 2020-04-04 10:44:42 --> Helper loaded: email_helper
INFO - 2020-04-04 10:44:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:44:42 --> Database Driver Class Initialized
INFO - 2020-04-04 10:44:42 --> Parser Class Initialized
INFO - 2020-04-04 10:44:42 --> User Agent Class Initialized
INFO - 2020-04-04 10:44:42 --> Model Class Initialized
INFO - 2020-04-04 10:44:42 --> Model Class Initialized
DEBUG - 2020-04-04 10:44:43 --> Template Class Initialized
INFO - 2020-04-04 10:44:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:44:43 --> Email Class Initialized
INFO - 2020-04-04 10:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:44:43 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:44:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:44:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:44:43 --> Encryption Class Initialized
INFO - 2020-04-04 10:44:43 --> Controller Class Initialized
DEBUG - 2020-04-04 10:44:43 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:44:43 --> Model Class Initialized
INFO - 2020-04-04 10:44:43 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:44:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:44:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:44:43 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:44:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:44:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:44:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:44:43 --> Final output sent to browser
DEBUG - 2020-04-04 10:44:43 --> Total execution time: 0.5760
INFO - 2020-04-04 10:44:43 --> Config Class Initialized
INFO - 2020-04-04 10:44:43 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:43 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:43 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:43 --> URI Class Initialized
INFO - 2020-04-04 10:44:43 --> Router Class Initialized
INFO - 2020-04-04 10:44:43 --> Output Class Initialized
INFO - 2020-04-04 10:44:43 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:43 --> CSRF cookie sent
INFO - 2020-04-04 10:44:43 --> Input Class Initialized
INFO - 2020-04-04 10:44:43 --> Config Class Initialized
INFO - 2020-04-04 10:44:43 --> Hooks Class Initialized
INFO - 2020-04-04 10:44:43 --> Language Class Initialized
ERROR - 2020-04-04 10:44:43 --> 404 Page Not Found: /index
DEBUG - 2020-04-04 10:44:43 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:43 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:43 --> URI Class Initialized
INFO - 2020-04-04 10:44:43 --> Router Class Initialized
INFO - 2020-04-04 10:44:43 --> Output Class Initialized
INFO - 2020-04-04 10:44:43 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:43 --> CSRF cookie sent
INFO - 2020-04-04 10:44:43 --> Input Class Initialized
INFO - 2020-04-04 10:44:43 --> Language Class Initialized
ERROR - 2020-04-04 10:44:44 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:44:49 --> Config Class Initialized
INFO - 2020-04-04 10:44:49 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:49 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:49 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:49 --> URI Class Initialized
INFO - 2020-04-04 10:44:49 --> Router Class Initialized
INFO - 2020-04-04 10:44:49 --> Output Class Initialized
INFO - 2020-04-04 10:44:49 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:49 --> CSRF cookie sent
INFO - 2020-04-04 10:44:49 --> Input Class Initialized
INFO - 2020-04-04 10:44:49 --> Language Class Initialized
INFO - 2020-04-04 10:44:49 --> Language Class Initialized
INFO - 2020-04-04 10:44:49 --> Config Class Initialized
INFO - 2020-04-04 10:44:49 --> Loader Class Initialized
INFO - 2020-04-04 10:44:49 --> Helper loaded: url_helper
INFO - 2020-04-04 10:44:49 --> Helper loaded: file_helper
INFO - 2020-04-04 10:44:49 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:44:49 --> Helper loaded: common_helper
INFO - 2020-04-04 10:44:49 --> Helper loaded: language_helper
INFO - 2020-04-04 10:44:49 --> Helper loaded: email_helper
INFO - 2020-04-04 10:44:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:44:49 --> Database Driver Class Initialized
INFO - 2020-04-04 10:44:49 --> Parser Class Initialized
INFO - 2020-04-04 10:44:49 --> User Agent Class Initialized
INFO - 2020-04-04 10:44:49 --> Model Class Initialized
INFO - 2020-04-04 10:44:49 --> Model Class Initialized
DEBUG - 2020-04-04 10:44:49 --> Template Class Initialized
INFO - 2020-04-04 10:44:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:44:49 --> Email Class Initialized
INFO - 2020-04-04 10:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:44:49 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:44:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:44:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:44:49 --> Encryption Class Initialized
INFO - 2020-04-04 10:44:49 --> Controller Class Initialized
DEBUG - 2020-04-04 10:44:49 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:44:49 --> Model Class Initialized
INFO - 2020-04-04 10:44:50 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:44:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:44:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:44:50 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:44:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:44:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:44:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:44:50 --> Final output sent to browser
DEBUG - 2020-04-04 10:44:50 --> Total execution time: 0.6680
INFO - 2020-04-04 10:44:50 --> Config Class Initialized
INFO - 2020-04-04 10:44:50 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:50 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:50 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:50 --> URI Class Initialized
INFO - 2020-04-04 10:44:50 --> Router Class Initialized
INFO - 2020-04-04 10:44:50 --> Output Class Initialized
INFO - 2020-04-04 10:44:50 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:50 --> CSRF cookie sent
INFO - 2020-04-04 10:44:50 --> Input Class Initialized
INFO - 2020-04-04 10:44:50 --> Language Class Initialized
ERROR - 2020-04-04 10:44:50 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:44:50 --> Config Class Initialized
INFO - 2020-04-04 10:44:50 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:50 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:50 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:50 --> URI Class Initialized
INFO - 2020-04-04 10:44:50 --> Router Class Initialized
INFO - 2020-04-04 10:44:50 --> Output Class Initialized
INFO - 2020-04-04 10:44:50 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:50 --> CSRF cookie sent
INFO - 2020-04-04 10:44:50 --> Input Class Initialized
INFO - 2020-04-04 10:44:50 --> Language Class Initialized
ERROR - 2020-04-04 10:44:50 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:44:56 --> Config Class Initialized
INFO - 2020-04-04 10:44:56 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:56 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:56 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:56 --> URI Class Initialized
INFO - 2020-04-04 10:44:56 --> Router Class Initialized
INFO - 2020-04-04 10:44:56 --> Output Class Initialized
INFO - 2020-04-04 10:44:56 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:56 --> CSRF cookie sent
INFO - 2020-04-04 10:44:56 --> CSRF token verified
INFO - 2020-04-04 10:44:56 --> Input Class Initialized
INFO - 2020-04-04 10:44:56 --> Language Class Initialized
INFO - 2020-04-04 10:44:56 --> Language Class Initialized
INFO - 2020-04-04 10:44:56 --> Config Class Initialized
INFO - 2020-04-04 10:44:56 --> Loader Class Initialized
INFO - 2020-04-04 10:44:56 --> Helper loaded: url_helper
INFO - 2020-04-04 10:44:56 --> Helper loaded: file_helper
INFO - 2020-04-04 10:44:56 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:44:56 --> Helper loaded: common_helper
INFO - 2020-04-04 10:44:56 --> Helper loaded: language_helper
INFO - 2020-04-04 10:44:56 --> Helper loaded: email_helper
INFO - 2020-04-04 10:44:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:44:56 --> Database Driver Class Initialized
INFO - 2020-04-04 10:44:56 --> Parser Class Initialized
INFO - 2020-04-04 10:44:56 --> User Agent Class Initialized
INFO - 2020-04-04 10:44:56 --> Model Class Initialized
INFO - 2020-04-04 10:44:56 --> Model Class Initialized
DEBUG - 2020-04-04 10:44:56 --> Template Class Initialized
INFO - 2020-04-04 10:44:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:44:56 --> Email Class Initialized
INFO - 2020-04-04 10:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:44:56 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:44:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:44:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:44:56 --> Encryption Class Initialized
INFO - 2020-04-04 10:44:56 --> Controller Class Initialized
DEBUG - 2020-04-04 10:44:56 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:44:56 --> Model Class Initialized
INFO - 2020-04-04 10:44:56 --> Upload Class Initialized
INFO - 2020-04-04 10:44:58 --> Config Class Initialized
INFO - 2020-04-04 10:44:58 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:58 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:58 --> URI Class Initialized
INFO - 2020-04-04 10:44:59 --> Router Class Initialized
INFO - 2020-04-04 10:44:59 --> Output Class Initialized
INFO - 2020-04-04 10:44:59 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:59 --> CSRF cookie sent
INFO - 2020-04-04 10:44:59 --> Input Class Initialized
INFO - 2020-04-04 10:44:59 --> Language Class Initialized
INFO - 2020-04-04 10:44:59 --> Language Class Initialized
INFO - 2020-04-04 10:44:59 --> Config Class Initialized
INFO - 2020-04-04 10:44:59 --> Loader Class Initialized
INFO - 2020-04-04 10:44:59 --> Helper loaded: url_helper
INFO - 2020-04-04 10:44:59 --> Helper loaded: file_helper
INFO - 2020-04-04 10:44:59 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:44:59 --> Helper loaded: common_helper
INFO - 2020-04-04 10:44:59 --> Helper loaded: language_helper
INFO - 2020-04-04 10:44:59 --> Helper loaded: email_helper
INFO - 2020-04-04 10:44:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:44:59 --> Database Driver Class Initialized
INFO - 2020-04-04 10:44:59 --> Parser Class Initialized
INFO - 2020-04-04 10:44:59 --> User Agent Class Initialized
INFO - 2020-04-04 10:44:59 --> Model Class Initialized
INFO - 2020-04-04 10:44:59 --> Model Class Initialized
DEBUG - 2020-04-04 10:44:59 --> Template Class Initialized
INFO - 2020-04-04 10:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:44:59 --> Email Class Initialized
INFO - 2020-04-04 10:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:44:59 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:44:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:44:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:44:59 --> Encryption Class Initialized
INFO - 2020-04-04 10:44:59 --> Controller Class Initialized
DEBUG - 2020-04-04 10:44:59 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:44:59 --> Model Class Initialized
INFO - 2020-04-04 10:44:59 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:44:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:44:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:44:59 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:44:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:44:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:44:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:44:59 --> Final output sent to browser
DEBUG - 2020-04-04 10:44:59 --> Total execution time: 0.6129
INFO - 2020-04-04 10:44:59 --> Config Class Initialized
INFO - 2020-04-04 10:44:59 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:44:59 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:44:59 --> Utf8 Class Initialized
INFO - 2020-04-04 10:44:59 --> URI Class Initialized
INFO - 2020-04-04 10:44:59 --> Router Class Initialized
INFO - 2020-04-04 10:44:59 --> Output Class Initialized
INFO - 2020-04-04 10:44:59 --> Security Class Initialized
DEBUG - 2020-04-04 10:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:44:59 --> CSRF cookie sent
INFO - 2020-04-04 10:44:59 --> Config Class Initialized
INFO - 2020-04-04 10:44:59 --> Hooks Class Initialized
INFO - 2020-04-04 10:44:59 --> Input Class Initialized
INFO - 2020-04-04 10:44:59 --> Language Class Initialized
DEBUG - 2020-04-04 10:44:59 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:00 --> Utf8 Class Initialized
ERROR - 2020-04-04 10:45:00 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:45:00 --> URI Class Initialized
INFO - 2020-04-04 10:45:00 --> Router Class Initialized
INFO - 2020-04-04 10:45:00 --> Output Class Initialized
INFO - 2020-04-04 10:45:00 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:00 --> CSRF cookie sent
INFO - 2020-04-04 10:45:00 --> Input Class Initialized
INFO - 2020-04-04 10:45:00 --> Language Class Initialized
ERROR - 2020-04-04 10:45:00 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:45:05 --> Config Class Initialized
INFO - 2020-04-04 10:45:05 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:45:05 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:05 --> Utf8 Class Initialized
INFO - 2020-04-04 10:45:05 --> URI Class Initialized
INFO - 2020-04-04 10:45:05 --> Router Class Initialized
INFO - 2020-04-04 10:45:05 --> Output Class Initialized
INFO - 2020-04-04 10:45:05 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:05 --> CSRF cookie sent
INFO - 2020-04-04 10:45:05 --> Input Class Initialized
INFO - 2020-04-04 10:45:05 --> Language Class Initialized
INFO - 2020-04-04 10:45:05 --> Language Class Initialized
INFO - 2020-04-04 10:45:05 --> Config Class Initialized
INFO - 2020-04-04 10:45:05 --> Loader Class Initialized
INFO - 2020-04-04 10:45:05 --> Helper loaded: url_helper
INFO - 2020-04-04 10:45:05 --> Helper loaded: file_helper
INFO - 2020-04-04 10:45:05 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:45:05 --> Helper loaded: common_helper
INFO - 2020-04-04 10:45:05 --> Helper loaded: language_helper
INFO - 2020-04-04 10:45:05 --> Helper loaded: email_helper
INFO - 2020-04-04 10:45:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:45:05 --> Database Driver Class Initialized
INFO - 2020-04-04 10:45:05 --> Parser Class Initialized
INFO - 2020-04-04 10:45:05 --> User Agent Class Initialized
INFO - 2020-04-04 10:45:05 --> Model Class Initialized
INFO - 2020-04-04 10:45:05 --> Model Class Initialized
DEBUG - 2020-04-04 10:45:05 --> Template Class Initialized
INFO - 2020-04-04 10:45:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:45:05 --> Email Class Initialized
INFO - 2020-04-04 10:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:45:05 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:45:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:45:05 --> Encryption Class Initialized
INFO - 2020-04-04 10:45:05 --> Controller Class Initialized
DEBUG - 2020-04-04 10:45:05 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:45:05 --> Model Class Initialized
INFO - 2020-04-04 10:45:05 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:45:05 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:45:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:45:05 --> Final output sent to browser
DEBUG - 2020-04-04 10:45:05 --> Total execution time: 0.7729
INFO - 2020-04-04 10:45:06 --> Config Class Initialized
INFO - 2020-04-04 10:45:06 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:45:06 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:06 --> Utf8 Class Initialized
INFO - 2020-04-04 10:45:06 --> URI Class Initialized
INFO - 2020-04-04 10:45:06 --> Router Class Initialized
INFO - 2020-04-04 10:45:06 --> Output Class Initialized
INFO - 2020-04-04 10:45:06 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:06 --> CSRF cookie sent
INFO - 2020-04-04 10:45:06 --> Config Class Initialized
INFO - 2020-04-04 10:45:06 --> Input Class Initialized
INFO - 2020-04-04 10:45:06 --> Hooks Class Initialized
INFO - 2020-04-04 10:45:06 --> Language Class Initialized
DEBUG - 2020-04-04 10:45:06 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:06 --> Utf8 Class Initialized
ERROR - 2020-04-04 10:45:06 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:45:06 --> URI Class Initialized
INFO - 2020-04-04 10:45:06 --> Router Class Initialized
INFO - 2020-04-04 10:45:06 --> Output Class Initialized
INFO - 2020-04-04 10:45:06 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:06 --> CSRF cookie sent
INFO - 2020-04-04 10:45:06 --> Input Class Initialized
INFO - 2020-04-04 10:45:06 --> Language Class Initialized
ERROR - 2020-04-04 10:45:06 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:45:14 --> Config Class Initialized
INFO - 2020-04-04 10:45:14 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:45:14 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:14 --> Utf8 Class Initialized
INFO - 2020-04-04 10:45:14 --> URI Class Initialized
INFO - 2020-04-04 10:45:14 --> Router Class Initialized
INFO - 2020-04-04 10:45:14 --> Output Class Initialized
INFO - 2020-04-04 10:45:14 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:14 --> CSRF cookie sent
INFO - 2020-04-04 10:45:14 --> CSRF token verified
INFO - 2020-04-04 10:45:14 --> Input Class Initialized
INFO - 2020-04-04 10:45:14 --> Language Class Initialized
INFO - 2020-04-04 10:45:14 --> Language Class Initialized
INFO - 2020-04-04 10:45:14 --> Config Class Initialized
INFO - 2020-04-04 10:45:14 --> Loader Class Initialized
INFO - 2020-04-04 10:45:14 --> Helper loaded: url_helper
INFO - 2020-04-04 10:45:14 --> Helper loaded: file_helper
INFO - 2020-04-04 10:45:14 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:45:14 --> Helper loaded: common_helper
INFO - 2020-04-04 10:45:14 --> Helper loaded: language_helper
INFO - 2020-04-04 10:45:14 --> Helper loaded: email_helper
INFO - 2020-04-04 10:45:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:45:14 --> Database Driver Class Initialized
INFO - 2020-04-04 10:45:14 --> Parser Class Initialized
INFO - 2020-04-04 10:45:14 --> User Agent Class Initialized
INFO - 2020-04-04 10:45:14 --> Model Class Initialized
INFO - 2020-04-04 10:45:14 --> Model Class Initialized
DEBUG - 2020-04-04 10:45:14 --> Template Class Initialized
INFO - 2020-04-04 10:45:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:45:14 --> Email Class Initialized
INFO - 2020-04-04 10:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:45:14 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:45:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:45:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:45:14 --> Encryption Class Initialized
INFO - 2020-04-04 10:45:14 --> Controller Class Initialized
DEBUG - 2020-04-04 10:45:14 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:45:15 --> Model Class Initialized
INFO - 2020-04-04 10:45:15 --> Upload Class Initialized
INFO - 2020-04-04 10:45:17 --> Config Class Initialized
INFO - 2020-04-04 10:45:17 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:45:17 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:17 --> Utf8 Class Initialized
INFO - 2020-04-04 10:45:17 --> URI Class Initialized
INFO - 2020-04-04 10:45:17 --> Router Class Initialized
INFO - 2020-04-04 10:45:17 --> Output Class Initialized
INFO - 2020-04-04 10:45:17 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:17 --> CSRF cookie sent
INFO - 2020-04-04 10:45:17 --> Input Class Initialized
INFO - 2020-04-04 10:45:17 --> Language Class Initialized
INFO - 2020-04-04 10:45:17 --> Language Class Initialized
INFO - 2020-04-04 10:45:17 --> Config Class Initialized
INFO - 2020-04-04 10:45:17 --> Loader Class Initialized
INFO - 2020-04-04 10:45:17 --> Helper loaded: url_helper
INFO - 2020-04-04 10:45:17 --> Helper loaded: file_helper
INFO - 2020-04-04 10:45:17 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:45:17 --> Helper loaded: common_helper
INFO - 2020-04-04 10:45:17 --> Helper loaded: language_helper
INFO - 2020-04-04 10:45:17 --> Helper loaded: email_helper
INFO - 2020-04-04 10:45:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:45:17 --> Database Driver Class Initialized
INFO - 2020-04-04 10:45:17 --> Parser Class Initialized
INFO - 2020-04-04 10:45:17 --> User Agent Class Initialized
INFO - 2020-04-04 10:45:17 --> Model Class Initialized
INFO - 2020-04-04 10:45:17 --> Model Class Initialized
DEBUG - 2020-04-04 10:45:17 --> Template Class Initialized
INFO - 2020-04-04 10:45:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:45:17 --> Email Class Initialized
INFO - 2020-04-04 10:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:45:17 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:45:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:45:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:45:17 --> Encryption Class Initialized
INFO - 2020-04-04 10:45:17 --> Controller Class Initialized
DEBUG - 2020-04-04 10:45:17 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:45:17 --> Model Class Initialized
INFO - 2020-04-04 10:45:17 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:45:17 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:45:17 --> Final output sent to browser
DEBUG - 2020-04-04 10:45:17 --> Total execution time: 0.5960
INFO - 2020-04-04 10:45:17 --> Config Class Initialized
INFO - 2020-04-04 10:45:17 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:45:17 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:17 --> Utf8 Class Initialized
INFO - 2020-04-04 10:45:17 --> URI Class Initialized
INFO - 2020-04-04 10:45:17 --> Router Class Initialized
INFO - 2020-04-04 10:45:17 --> Output Class Initialized
INFO - 2020-04-04 10:45:18 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:18 --> CSRF cookie sent
INFO - 2020-04-04 10:45:18 --> Config Class Initialized
INFO - 2020-04-04 10:45:18 --> Input Class Initialized
INFO - 2020-04-04 10:45:18 --> Hooks Class Initialized
INFO - 2020-04-04 10:45:18 --> Language Class Initialized
DEBUG - 2020-04-04 10:45:18 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:18 --> Utf8 Class Initialized
ERROR - 2020-04-04 10:45:18 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:45:18 --> URI Class Initialized
INFO - 2020-04-04 10:45:18 --> Router Class Initialized
INFO - 2020-04-04 10:45:18 --> Output Class Initialized
INFO - 2020-04-04 10:45:18 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:18 --> CSRF cookie sent
INFO - 2020-04-04 10:45:18 --> Input Class Initialized
INFO - 2020-04-04 10:45:18 --> Language Class Initialized
ERROR - 2020-04-04 10:45:18 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:45:34 --> Config Class Initialized
INFO - 2020-04-04 10:45:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:45:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:34 --> Utf8 Class Initialized
INFO - 2020-04-04 10:45:34 --> URI Class Initialized
INFO - 2020-04-04 10:45:34 --> Router Class Initialized
INFO - 2020-04-04 10:45:34 --> Output Class Initialized
INFO - 2020-04-04 10:45:34 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:34 --> CSRF cookie sent
INFO - 2020-04-04 10:45:34 --> CSRF token verified
INFO - 2020-04-04 10:45:34 --> Input Class Initialized
INFO - 2020-04-04 10:45:34 --> Language Class Initialized
INFO - 2020-04-04 10:45:34 --> Language Class Initialized
INFO - 2020-04-04 10:45:34 --> Config Class Initialized
INFO - 2020-04-04 10:45:34 --> Loader Class Initialized
INFO - 2020-04-04 10:45:34 --> Helper loaded: url_helper
INFO - 2020-04-04 10:45:34 --> Helper loaded: file_helper
INFO - 2020-04-04 10:45:34 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:45:34 --> Helper loaded: common_helper
INFO - 2020-04-04 10:45:34 --> Helper loaded: language_helper
INFO - 2020-04-04 10:45:34 --> Helper loaded: email_helper
INFO - 2020-04-04 10:45:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:45:34 --> Database Driver Class Initialized
INFO - 2020-04-04 10:45:34 --> Parser Class Initialized
INFO - 2020-04-04 10:45:34 --> User Agent Class Initialized
INFO - 2020-04-04 10:45:34 --> Model Class Initialized
INFO - 2020-04-04 10:45:34 --> Model Class Initialized
DEBUG - 2020-04-04 10:45:34 --> Template Class Initialized
INFO - 2020-04-04 10:45:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:45:34 --> Email Class Initialized
INFO - 2020-04-04 10:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:45:34 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:45:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:45:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:45:34 --> Encryption Class Initialized
INFO - 2020-04-04 10:45:34 --> Controller Class Initialized
DEBUG - 2020-04-04 10:45:34 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:45:34 --> Model Class Initialized
INFO - 2020-04-04 10:45:44 --> Config Class Initialized
INFO - 2020-04-04 10:45:44 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:45:44 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:44 --> Utf8 Class Initialized
INFO - 2020-04-04 10:45:44 --> URI Class Initialized
INFO - 2020-04-04 10:45:44 --> Router Class Initialized
INFO - 2020-04-04 10:45:44 --> Output Class Initialized
INFO - 2020-04-04 10:45:44 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:44 --> CSRF cookie sent
INFO - 2020-04-04 10:45:44 --> Input Class Initialized
INFO - 2020-04-04 10:45:44 --> Language Class Initialized
INFO - 2020-04-04 10:45:44 --> Language Class Initialized
INFO - 2020-04-04 10:45:44 --> Config Class Initialized
INFO - 2020-04-04 10:45:44 --> Loader Class Initialized
INFO - 2020-04-04 10:45:44 --> Helper loaded: url_helper
INFO - 2020-04-04 10:45:44 --> Helper loaded: file_helper
INFO - 2020-04-04 10:45:44 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:45:44 --> Helper loaded: common_helper
INFO - 2020-04-04 10:45:44 --> Helper loaded: language_helper
INFO - 2020-04-04 10:45:44 --> Helper loaded: email_helper
INFO - 2020-04-04 10:45:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:45:44 --> Database Driver Class Initialized
INFO - 2020-04-04 10:45:44 --> Parser Class Initialized
INFO - 2020-04-04 10:45:44 --> User Agent Class Initialized
INFO - 2020-04-04 10:45:44 --> Model Class Initialized
INFO - 2020-04-04 10:45:44 --> Model Class Initialized
DEBUG - 2020-04-04 10:45:44 --> Template Class Initialized
INFO - 2020-04-04 10:45:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:45:44 --> Email Class Initialized
INFO - 2020-04-04 10:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:45:44 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:45:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:45:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:45:44 --> Encryption Class Initialized
INFO - 2020-04-04 10:45:44 --> Controller Class Initialized
DEBUG - 2020-04-04 10:45:44 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:45:44 --> Model Class Initialized
INFO - 2020-04-04 10:45:44 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:45:44 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:45:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:45:44 --> Final output sent to browser
DEBUG - 2020-04-04 10:45:44 --> Total execution time: 0.7307
INFO - 2020-04-04 10:45:50 --> Config Class Initialized
INFO - 2020-04-04 10:45:50 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:45:50 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:45:50 --> Utf8 Class Initialized
INFO - 2020-04-04 10:45:51 --> URI Class Initialized
INFO - 2020-04-04 10:45:51 --> Router Class Initialized
INFO - 2020-04-04 10:45:51 --> Output Class Initialized
INFO - 2020-04-04 10:45:51 --> Security Class Initialized
DEBUG - 2020-04-04 10:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:45:51 --> CSRF cookie sent
INFO - 2020-04-04 10:45:51 --> CSRF token verified
INFO - 2020-04-04 10:45:51 --> Input Class Initialized
INFO - 2020-04-04 10:45:51 --> Language Class Initialized
INFO - 2020-04-04 10:45:51 --> Language Class Initialized
INFO - 2020-04-04 10:45:51 --> Config Class Initialized
INFO - 2020-04-04 10:45:51 --> Loader Class Initialized
INFO - 2020-04-04 10:45:51 --> Helper loaded: url_helper
INFO - 2020-04-04 10:45:51 --> Helper loaded: file_helper
INFO - 2020-04-04 10:45:51 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:45:51 --> Helper loaded: common_helper
INFO - 2020-04-04 10:45:51 --> Helper loaded: language_helper
INFO - 2020-04-04 10:45:51 --> Helper loaded: email_helper
INFO - 2020-04-04 10:45:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:45:51 --> Database Driver Class Initialized
INFO - 2020-04-04 10:45:51 --> Parser Class Initialized
INFO - 2020-04-04 10:45:51 --> User Agent Class Initialized
INFO - 2020-04-04 10:45:51 --> Model Class Initialized
INFO - 2020-04-04 10:45:51 --> Model Class Initialized
DEBUG - 2020-04-04 10:45:51 --> Template Class Initialized
INFO - 2020-04-04 10:45:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:45:51 --> Email Class Initialized
INFO - 2020-04-04 10:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:45:51 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:45:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:45:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:45:51 --> Encryption Class Initialized
INFO - 2020-04-04 10:45:51 --> Controller Class Initialized
DEBUG - 2020-04-04 10:45:51 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:45:51 --> Model Class Initialized
INFO - 2020-04-04 10:47:03 --> Config Class Initialized
INFO - 2020-04-04 10:47:03 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:47:03 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:47:03 --> Utf8 Class Initialized
INFO - 2020-04-04 10:47:03 --> URI Class Initialized
INFO - 2020-04-04 10:47:03 --> Router Class Initialized
INFO - 2020-04-04 10:47:03 --> Output Class Initialized
INFO - 2020-04-04 10:47:03 --> Security Class Initialized
DEBUG - 2020-04-04 10:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:47:03 --> CSRF cookie sent
INFO - 2020-04-04 10:47:03 --> Input Class Initialized
INFO - 2020-04-04 10:47:03 --> Language Class Initialized
INFO - 2020-04-04 10:47:03 --> Language Class Initialized
INFO - 2020-04-04 10:47:03 --> Config Class Initialized
INFO - 2020-04-04 10:47:04 --> Loader Class Initialized
INFO - 2020-04-04 10:47:04 --> Helper loaded: url_helper
INFO - 2020-04-04 10:47:04 --> Helper loaded: file_helper
INFO - 2020-04-04 10:47:04 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:47:04 --> Helper loaded: common_helper
INFO - 2020-04-04 10:47:04 --> Helper loaded: language_helper
INFO - 2020-04-04 10:47:04 --> Helper loaded: email_helper
INFO - 2020-04-04 10:47:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:47:04 --> Database Driver Class Initialized
INFO - 2020-04-04 10:47:04 --> Parser Class Initialized
INFO - 2020-04-04 10:47:04 --> User Agent Class Initialized
INFO - 2020-04-04 10:47:04 --> Model Class Initialized
INFO - 2020-04-04 10:47:04 --> Model Class Initialized
DEBUG - 2020-04-04 10:47:04 --> Template Class Initialized
INFO - 2020-04-04 10:47:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:47:04 --> Email Class Initialized
INFO - 2020-04-04 10:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:47:04 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:47:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:47:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:47:04 --> Encryption Class Initialized
INFO - 2020-04-04 10:47:04 --> Controller Class Initialized
DEBUG - 2020-04-04 10:47:04 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:47:04 --> Model Class Initialized
INFO - 2020-04-04 10:47:04 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:47:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:47:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:47:04 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:47:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:47:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:47:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:47:04 --> Final output sent to browser
DEBUG - 2020-04-04 10:47:04 --> Total execution time: 0.6839
INFO - 2020-04-04 10:47:34 --> Config Class Initialized
INFO - 2020-04-04 10:47:34 --> Config Class Initialized
INFO - 2020-04-04 10:47:34 --> Hooks Class Initialized
INFO - 2020-04-04 10:47:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:47:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 10:47:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:47:34 --> Utf8 Class Initialized
INFO - 2020-04-04 10:47:34 --> Utf8 Class Initialized
INFO - 2020-04-04 10:47:34 --> URI Class Initialized
INFO - 2020-04-04 10:47:34 --> URI Class Initialized
INFO - 2020-04-04 10:47:34 --> Router Class Initialized
INFO - 2020-04-04 10:47:34 --> Router Class Initialized
INFO - 2020-04-04 10:47:34 --> Output Class Initialized
INFO - 2020-04-04 10:47:34 --> Output Class Initialized
INFO - 2020-04-04 10:47:34 --> Security Class Initialized
INFO - 2020-04-04 10:47:34 --> Security Class Initialized
DEBUG - 2020-04-04 10:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 10:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:47:34 --> CSRF cookie sent
INFO - 2020-04-04 10:47:34 --> CSRF cookie sent
INFO - 2020-04-04 10:47:34 --> Input Class Initialized
INFO - 2020-04-04 10:47:34 --> Input Class Initialized
INFO - 2020-04-04 10:47:34 --> Language Class Initialized
INFO - 2020-04-04 10:47:34 --> Language Class Initialized
ERROR - 2020-04-04 10:47:34 --> 404 Page Not Found: /index
ERROR - 2020-04-04 10:47:34 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:47:44 --> Config Class Initialized
INFO - 2020-04-04 10:47:44 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:47:44 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:47:44 --> Utf8 Class Initialized
INFO - 2020-04-04 10:47:44 --> URI Class Initialized
INFO - 2020-04-04 10:47:44 --> Router Class Initialized
INFO - 2020-04-04 10:47:44 --> Output Class Initialized
INFO - 2020-04-04 10:47:44 --> Security Class Initialized
DEBUG - 2020-04-04 10:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:47:44 --> CSRF cookie sent
INFO - 2020-04-04 10:47:44 --> CSRF token verified
INFO - 2020-04-04 10:47:44 --> Input Class Initialized
INFO - 2020-04-04 10:47:44 --> Language Class Initialized
INFO - 2020-04-04 10:47:44 --> Language Class Initialized
INFO - 2020-04-04 10:47:44 --> Config Class Initialized
INFO - 2020-04-04 10:47:44 --> Loader Class Initialized
INFO - 2020-04-04 10:47:44 --> Helper loaded: url_helper
INFO - 2020-04-04 10:47:44 --> Helper loaded: file_helper
INFO - 2020-04-04 10:47:44 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:47:44 --> Helper loaded: common_helper
INFO - 2020-04-04 10:47:44 --> Helper loaded: language_helper
INFO - 2020-04-04 10:47:44 --> Helper loaded: email_helper
INFO - 2020-04-04 10:47:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:47:44 --> Database Driver Class Initialized
INFO - 2020-04-04 10:47:44 --> Parser Class Initialized
INFO - 2020-04-04 10:47:44 --> User Agent Class Initialized
INFO - 2020-04-04 10:47:44 --> Model Class Initialized
INFO - 2020-04-04 10:47:44 --> Model Class Initialized
DEBUG - 2020-04-04 10:47:44 --> Template Class Initialized
INFO - 2020-04-04 10:47:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:47:44 --> Email Class Initialized
INFO - 2020-04-04 10:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:47:44 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:47:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:47:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:47:44 --> Encryption Class Initialized
INFO - 2020-04-04 10:47:44 --> Controller Class Initialized
DEBUG - 2020-04-04 10:47:44 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:47:44 --> Model Class Initialized
INFO - 2020-04-04 10:47:44 --> Upload Class Initialized
INFO - 2020-04-04 10:47:46 --> Config Class Initialized
INFO - 2020-04-04 10:47:46 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:47:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:47:46 --> Utf8 Class Initialized
INFO - 2020-04-04 10:47:46 --> URI Class Initialized
INFO - 2020-04-04 10:47:46 --> Router Class Initialized
INFO - 2020-04-04 10:47:46 --> Output Class Initialized
INFO - 2020-04-04 10:47:46 --> Security Class Initialized
DEBUG - 2020-04-04 10:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:47:46 --> CSRF cookie sent
INFO - 2020-04-04 10:47:46 --> Input Class Initialized
INFO - 2020-04-04 10:47:46 --> Language Class Initialized
INFO - 2020-04-04 10:47:46 --> Language Class Initialized
INFO - 2020-04-04 10:47:46 --> Config Class Initialized
INFO - 2020-04-04 10:47:47 --> Loader Class Initialized
INFO - 2020-04-04 10:47:47 --> Helper loaded: url_helper
INFO - 2020-04-04 10:47:47 --> Helper loaded: file_helper
INFO - 2020-04-04 10:47:47 --> Helper loaded: cookie_helper
INFO - 2020-04-04 10:47:47 --> Helper loaded: common_helper
INFO - 2020-04-04 10:47:47 --> Helper loaded: language_helper
INFO - 2020-04-04 10:47:47 --> Helper loaded: email_helper
INFO - 2020-04-04 10:47:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 10:47:47 --> Database Driver Class Initialized
INFO - 2020-04-04 10:47:47 --> Parser Class Initialized
INFO - 2020-04-04 10:47:47 --> User Agent Class Initialized
INFO - 2020-04-04 10:47:47 --> Model Class Initialized
INFO - 2020-04-04 10:47:47 --> Model Class Initialized
DEBUG - 2020-04-04 10:47:47 --> Template Class Initialized
INFO - 2020-04-04 10:47:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 10:47:47 --> Email Class Initialized
INFO - 2020-04-04 10:47:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 10:47:47 --> Pagination Class Initialized
DEBUG - 2020-04-04 10:47:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 10:47:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 10:47:47 --> Encryption Class Initialized
INFO - 2020-04-04 10:47:47 --> Controller Class Initialized
DEBUG - 2020-04-04 10:47:47 --> gallery MX_Controller Initialized
INFO - 2020-04-04 10:47:47 --> Model Class Initialized
INFO - 2020-04-04 10:47:47 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 10:47:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 10:47:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 10:47:47 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 10:47:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 10:47:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 10:47:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 10:47:47 --> Final output sent to browser
DEBUG - 2020-04-04 10:47:47 --> Total execution time: 0.6720
INFO - 2020-04-04 10:47:47 --> Config Class Initialized
INFO - 2020-04-04 10:47:47 --> Hooks Class Initialized
DEBUG - 2020-04-04 10:47:47 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:47:47 --> Utf8 Class Initialized
INFO - 2020-04-04 10:47:47 --> URI Class Initialized
INFO - 2020-04-04 10:47:47 --> Router Class Initialized
INFO - 2020-04-04 10:47:47 --> Output Class Initialized
INFO - 2020-04-04 10:47:47 --> Config Class Initialized
INFO - 2020-04-04 10:47:47 --> Hooks Class Initialized
INFO - 2020-04-04 10:47:47 --> Security Class Initialized
DEBUG - 2020-04-04 10:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 10:47:47 --> UTF-8 Support Enabled
INFO - 2020-04-04 10:47:47 --> Utf8 Class Initialized
INFO - 2020-04-04 10:47:47 --> CSRF cookie sent
INFO - 2020-04-04 10:47:47 --> Input Class Initialized
INFO - 2020-04-04 10:47:47 --> URI Class Initialized
INFO - 2020-04-04 10:47:47 --> Language Class Initialized
INFO - 2020-04-04 10:47:47 --> Router Class Initialized
ERROR - 2020-04-04 10:47:47 --> 404 Page Not Found: /index
INFO - 2020-04-04 10:47:47 --> Output Class Initialized
INFO - 2020-04-04 10:47:48 --> Security Class Initialized
DEBUG - 2020-04-04 10:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 10:47:48 --> CSRF cookie sent
INFO - 2020-04-04 10:47:48 --> Input Class Initialized
INFO - 2020-04-04 10:47:48 --> Language Class Initialized
ERROR - 2020-04-04 10:47:48 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:02:54 --> Config Class Initialized
INFO - 2020-04-04 11:02:54 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:02:54 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:02:54 --> Utf8 Class Initialized
INFO - 2020-04-04 11:02:54 --> URI Class Initialized
INFO - 2020-04-04 11:02:54 --> Router Class Initialized
INFO - 2020-04-04 11:02:54 --> Output Class Initialized
INFO - 2020-04-04 11:02:54 --> Security Class Initialized
DEBUG - 2020-04-04 11:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:02:54 --> CSRF cookie sent
INFO - 2020-04-04 11:02:54 --> Input Class Initialized
INFO - 2020-04-04 11:02:54 --> Language Class Initialized
INFO - 2020-04-04 11:02:54 --> Language Class Initialized
INFO - 2020-04-04 11:02:54 --> Config Class Initialized
INFO - 2020-04-04 11:02:54 --> Loader Class Initialized
INFO - 2020-04-04 11:02:54 --> Helper loaded: url_helper
INFO - 2020-04-04 11:02:54 --> Helper loaded: file_helper
INFO - 2020-04-04 11:02:54 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:02:54 --> Helper loaded: common_helper
INFO - 2020-04-04 11:02:54 --> Helper loaded: language_helper
INFO - 2020-04-04 11:02:54 --> Helper loaded: email_helper
INFO - 2020-04-04 11:02:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:02:54 --> Database Driver Class Initialized
INFO - 2020-04-04 11:02:55 --> Parser Class Initialized
INFO - 2020-04-04 11:02:55 --> User Agent Class Initialized
INFO - 2020-04-04 11:02:55 --> Model Class Initialized
INFO - 2020-04-04 11:02:55 --> Model Class Initialized
DEBUG - 2020-04-04 11:02:55 --> Template Class Initialized
INFO - 2020-04-04 11:02:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:02:55 --> Email Class Initialized
INFO - 2020-04-04 11:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:02:55 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:02:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:02:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:02:55 --> Encryption Class Initialized
INFO - 2020-04-04 11:02:55 --> Controller Class Initialized
DEBUG - 2020-04-04 11:02:55 --> post MX_Controller Initialized
INFO - 2020-04-04 11:02:55 --> Model Class Initialized
ERROR - 2020-04-04 11:02:55 --> Could not find the language line ""
ERROR - 2020-04-04 11:02:55 --> Could not find the language line ""
ERROR - 2020-04-04 11:02:55 --> Could not find the language line ""
DEBUG - 2020-04-04 11:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:02:55 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:02:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:02:55 --> Final output sent to browser
DEBUG - 2020-04-04 11:02:55 --> Total execution time: 0.7043
INFO - 2020-04-04 11:02:55 --> Config Class Initialized
INFO - 2020-04-04 11:02:55 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:02:55 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:02:55 --> Utf8 Class Initialized
INFO - 2020-04-04 11:02:55 --> URI Class Initialized
INFO - 2020-04-04 11:02:55 --> Router Class Initialized
INFO - 2020-04-04 11:02:55 --> Output Class Initialized
INFO - 2020-04-04 11:02:55 --> Security Class Initialized
DEBUG - 2020-04-04 11:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:02:55 --> CSRF cookie sent
INFO - 2020-04-04 11:02:55 --> Input Class Initialized
INFO - 2020-04-04 11:02:55 --> Language Class Initialized
INFO - 2020-04-04 11:02:55 --> Config Class Initialized
INFO - 2020-04-04 11:02:55 --> Hooks Class Initialized
ERROR - 2020-04-04 11:02:55 --> 404 Page Not Found: /index
DEBUG - 2020-04-04 11:02:55 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:02:55 --> Utf8 Class Initialized
INFO - 2020-04-04 11:02:55 --> URI Class Initialized
INFO - 2020-04-04 11:02:55 --> Router Class Initialized
INFO - 2020-04-04 11:02:56 --> Output Class Initialized
INFO - 2020-04-04 11:02:56 --> Security Class Initialized
DEBUG - 2020-04-04 11:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:02:56 --> CSRF cookie sent
INFO - 2020-04-04 11:02:56 --> Input Class Initialized
INFO - 2020-04-04 11:02:56 --> Language Class Initialized
ERROR - 2020-04-04 11:02:56 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:03:19 --> Config Class Initialized
INFO - 2020-04-04 11:03:19 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:03:19 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:03:19 --> Utf8 Class Initialized
INFO - 2020-04-04 11:03:19 --> URI Class Initialized
INFO - 2020-04-04 11:03:19 --> Router Class Initialized
INFO - 2020-04-04 11:03:19 --> Output Class Initialized
INFO - 2020-04-04 11:03:19 --> Security Class Initialized
DEBUG - 2020-04-04 11:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:03:19 --> CSRF cookie sent
INFO - 2020-04-04 11:03:19 --> CSRF token verified
INFO - 2020-04-04 11:03:19 --> Input Class Initialized
INFO - 2020-04-04 11:03:19 --> Language Class Initialized
INFO - 2020-04-04 11:03:19 --> Language Class Initialized
INFO - 2020-04-04 11:03:20 --> Config Class Initialized
INFO - 2020-04-04 11:03:20 --> Loader Class Initialized
INFO - 2020-04-04 11:03:20 --> Helper loaded: url_helper
INFO - 2020-04-04 11:03:20 --> Helper loaded: file_helper
INFO - 2020-04-04 11:03:20 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:03:20 --> Helper loaded: common_helper
INFO - 2020-04-04 11:03:20 --> Helper loaded: language_helper
INFO - 2020-04-04 11:03:20 --> Helper loaded: email_helper
INFO - 2020-04-04 11:03:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:03:20 --> Database Driver Class Initialized
INFO - 2020-04-04 11:03:20 --> Parser Class Initialized
INFO - 2020-04-04 11:03:20 --> User Agent Class Initialized
INFO - 2020-04-04 11:03:20 --> Model Class Initialized
INFO - 2020-04-04 11:03:20 --> Model Class Initialized
DEBUG - 2020-04-04 11:03:20 --> Template Class Initialized
INFO - 2020-04-04 11:03:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:03:20 --> Email Class Initialized
INFO - 2020-04-04 11:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:03:20 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:03:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:03:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:03:20 --> Encryption Class Initialized
INFO - 2020-04-04 11:03:20 --> Controller Class Initialized
DEBUG - 2020-04-04 11:03:20 --> gallery MX_Controller Initialized
INFO - 2020-04-04 11:03:20 --> Model Class Initialized
INFO - 2020-04-04 11:03:20 --> Upload Class Initialized
INFO - 2020-04-04 11:04:51 --> Config Class Initialized
INFO - 2020-04-04 11:04:51 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:04:51 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:04:51 --> Utf8 Class Initialized
INFO - 2020-04-04 11:04:51 --> URI Class Initialized
INFO - 2020-04-04 11:04:51 --> Router Class Initialized
INFO - 2020-04-04 11:04:51 --> Output Class Initialized
INFO - 2020-04-04 11:04:51 --> Security Class Initialized
DEBUG - 2020-04-04 11:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:04:51 --> CSRF cookie sent
INFO - 2020-04-04 11:04:51 --> Input Class Initialized
INFO - 2020-04-04 11:04:51 --> Language Class Initialized
INFO - 2020-04-04 11:04:52 --> Language Class Initialized
INFO - 2020-04-04 11:04:52 --> Config Class Initialized
INFO - 2020-04-04 11:04:52 --> Loader Class Initialized
INFO - 2020-04-04 11:04:52 --> Helper loaded: url_helper
INFO - 2020-04-04 11:04:52 --> Helper loaded: file_helper
INFO - 2020-04-04 11:04:52 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:04:52 --> Helper loaded: common_helper
INFO - 2020-04-04 11:04:52 --> Helper loaded: language_helper
INFO - 2020-04-04 11:04:52 --> Helper loaded: email_helper
INFO - 2020-04-04 11:04:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:04:52 --> Database Driver Class Initialized
INFO - 2020-04-04 11:04:52 --> Parser Class Initialized
INFO - 2020-04-04 11:04:52 --> User Agent Class Initialized
INFO - 2020-04-04 11:04:52 --> Model Class Initialized
INFO - 2020-04-04 11:04:52 --> Model Class Initialized
DEBUG - 2020-04-04 11:04:52 --> Template Class Initialized
INFO - 2020-04-04 11:04:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:04:52 --> Email Class Initialized
INFO - 2020-04-04 11:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:04:52 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:04:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:04:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:04:52 --> Encryption Class Initialized
INFO - 2020-04-04 11:04:52 --> Controller Class Initialized
DEBUG - 2020-04-04 11:04:52 --> post MX_Controller Initialized
INFO - 2020-04-04 11:04:52 --> Model Class Initialized
ERROR - 2020-04-04 11:04:52 --> Could not find the language line ""
ERROR - 2020-04-04 11:04:52 --> Could not find the language line ""
ERROR - 2020-04-04 11:04:52 --> Could not find the language line ""
DEBUG - 2020-04-04 11:04:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:04:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:04:52 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:04:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:04:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:04:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:04:52 --> Final output sent to browser
DEBUG - 2020-04-04 11:04:52 --> Total execution time: 0.6960
INFO - 2020-04-04 11:05:04 --> Config Class Initialized
INFO - 2020-04-04 11:05:04 --> Config Class Initialized
INFO - 2020-04-04 11:05:04 --> Hooks Class Initialized
INFO - 2020-04-04 11:05:04 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:05:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:05:04 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:05:04 --> Utf8 Class Initialized
INFO - 2020-04-04 11:05:04 --> Utf8 Class Initialized
INFO - 2020-04-04 11:05:04 --> URI Class Initialized
INFO - 2020-04-04 11:05:04 --> URI Class Initialized
INFO - 2020-04-04 11:05:04 --> Router Class Initialized
INFO - 2020-04-04 11:05:04 --> Router Class Initialized
INFO - 2020-04-04 11:05:04 --> Output Class Initialized
INFO - 2020-04-04 11:05:04 --> Output Class Initialized
INFO - 2020-04-04 11:05:04 --> Security Class Initialized
INFO - 2020-04-04 11:05:04 --> Security Class Initialized
DEBUG - 2020-04-04 11:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:05:04 --> CSRF cookie sent
INFO - 2020-04-04 11:05:04 --> CSRF cookie sent
INFO - 2020-04-04 11:05:04 --> Input Class Initialized
INFO - 2020-04-04 11:05:04 --> Input Class Initialized
INFO - 2020-04-04 11:05:04 --> Language Class Initialized
INFO - 2020-04-04 11:05:04 --> Language Class Initialized
ERROR - 2020-04-04 11:05:04 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:05:04 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:05:12 --> Config Class Initialized
INFO - 2020-04-04 11:05:12 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:05:12 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:05:12 --> Utf8 Class Initialized
INFO - 2020-04-04 11:05:12 --> URI Class Initialized
INFO - 2020-04-04 11:05:12 --> Router Class Initialized
INFO - 2020-04-04 11:05:12 --> Output Class Initialized
INFO - 2020-04-04 11:05:12 --> Security Class Initialized
DEBUG - 2020-04-04 11:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:05:12 --> CSRF cookie sent
INFO - 2020-04-04 11:05:12 --> Input Class Initialized
INFO - 2020-04-04 11:05:12 --> Language Class Initialized
INFO - 2020-04-04 11:05:12 --> Language Class Initialized
INFO - 2020-04-04 11:05:12 --> Config Class Initialized
INFO - 2020-04-04 11:05:12 --> Loader Class Initialized
INFO - 2020-04-04 11:05:12 --> Helper loaded: url_helper
INFO - 2020-04-04 11:05:12 --> Helper loaded: file_helper
INFO - 2020-04-04 11:05:12 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:05:12 --> Helper loaded: common_helper
INFO - 2020-04-04 11:05:12 --> Helper loaded: language_helper
INFO - 2020-04-04 11:05:12 --> Helper loaded: email_helper
INFO - 2020-04-04 11:05:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:05:12 --> Database Driver Class Initialized
INFO - 2020-04-04 11:05:12 --> Parser Class Initialized
INFO - 2020-04-04 11:05:12 --> User Agent Class Initialized
INFO - 2020-04-04 11:05:12 --> Model Class Initialized
INFO - 2020-04-04 11:05:12 --> Model Class Initialized
DEBUG - 2020-04-04 11:05:12 --> Template Class Initialized
INFO - 2020-04-04 11:05:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:05:12 --> Email Class Initialized
INFO - 2020-04-04 11:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:05:12 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:05:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:05:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:05:13 --> Encryption Class Initialized
INFO - 2020-04-04 11:05:13 --> Controller Class Initialized
DEBUG - 2020-04-04 11:05:13 --> post MX_Controller Initialized
INFO - 2020-04-04 11:05:13 --> Model Class Initialized
ERROR - 2020-04-04 11:05:13 --> Could not find the language line ""
ERROR - 2020-04-04 11:05:13 --> Could not find the language line ""
ERROR - 2020-04-04 11:05:13 --> Could not find the language line ""
DEBUG - 2020-04-04 11:05:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:05:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:05:13 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:05:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:05:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:05:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:05:13 --> Final output sent to browser
DEBUG - 2020-04-04 11:05:13 --> Total execution time: 0.7087
INFO - 2020-04-04 11:09:40 --> Config Class Initialized
INFO - 2020-04-04 11:09:40 --> Config Class Initialized
INFO - 2020-04-04 11:09:40 --> Hooks Class Initialized
INFO - 2020-04-04 11:09:40 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:09:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:09:40 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:09:40 --> Utf8 Class Initialized
INFO - 2020-04-04 11:09:40 --> Utf8 Class Initialized
INFO - 2020-04-04 11:09:40 --> URI Class Initialized
INFO - 2020-04-04 11:09:40 --> URI Class Initialized
INFO - 2020-04-04 11:09:40 --> Router Class Initialized
INFO - 2020-04-04 11:09:40 --> Router Class Initialized
INFO - 2020-04-04 11:09:40 --> Output Class Initialized
INFO - 2020-04-04 11:09:40 --> Output Class Initialized
INFO - 2020-04-04 11:09:40 --> Security Class Initialized
INFO - 2020-04-04 11:09:40 --> Security Class Initialized
DEBUG - 2020-04-04 11:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:09:40 --> CSRF cookie sent
INFO - 2020-04-04 11:09:40 --> CSRF cookie sent
INFO - 2020-04-04 11:09:40 --> Input Class Initialized
INFO - 2020-04-04 11:09:40 --> Input Class Initialized
INFO - 2020-04-04 11:09:40 --> Language Class Initialized
INFO - 2020-04-04 11:09:40 --> Language Class Initialized
ERROR - 2020-04-04 11:09:40 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:09:40 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:09:48 --> Config Class Initialized
INFO - 2020-04-04 11:09:48 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:09:48 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:09:48 --> Utf8 Class Initialized
INFO - 2020-04-04 11:09:48 --> URI Class Initialized
INFO - 2020-04-04 11:09:48 --> Router Class Initialized
INFO - 2020-04-04 11:09:48 --> Output Class Initialized
INFO - 2020-04-04 11:09:48 --> Security Class Initialized
DEBUG - 2020-04-04 11:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:09:48 --> CSRF cookie sent
INFO - 2020-04-04 11:09:48 --> Input Class Initialized
INFO - 2020-04-04 11:09:48 --> Language Class Initialized
INFO - 2020-04-04 11:09:48 --> Language Class Initialized
INFO - 2020-04-04 11:09:48 --> Config Class Initialized
INFO - 2020-04-04 11:09:48 --> Loader Class Initialized
INFO - 2020-04-04 11:09:48 --> Helper loaded: url_helper
INFO - 2020-04-04 11:09:48 --> Helper loaded: file_helper
INFO - 2020-04-04 11:09:48 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:09:48 --> Helper loaded: common_helper
INFO - 2020-04-04 11:09:48 --> Helper loaded: language_helper
INFO - 2020-04-04 11:09:48 --> Helper loaded: email_helper
INFO - 2020-04-04 11:09:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:09:48 --> Database Driver Class Initialized
INFO - 2020-04-04 11:09:48 --> Parser Class Initialized
INFO - 2020-04-04 11:09:48 --> User Agent Class Initialized
INFO - 2020-04-04 11:09:48 --> Model Class Initialized
INFO - 2020-04-04 11:09:48 --> Model Class Initialized
DEBUG - 2020-04-04 11:09:48 --> Template Class Initialized
INFO - 2020-04-04 11:09:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:09:48 --> Email Class Initialized
INFO - 2020-04-04 11:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:09:48 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:09:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:09:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:09:48 --> Encryption Class Initialized
INFO - 2020-04-04 11:09:48 --> Controller Class Initialized
DEBUG - 2020-04-04 11:09:48 --> post MX_Controller Initialized
INFO - 2020-04-04 11:09:48 --> Model Class Initialized
ERROR - 2020-04-04 11:09:48 --> Could not find the language line ""
ERROR - 2020-04-04 11:09:48 --> Could not find the language line ""
ERROR - 2020-04-04 11:09:48 --> Could not find the language line ""
DEBUG - 2020-04-04 11:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:09:49 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:09:49 --> Final output sent to browser
DEBUG - 2020-04-04 11:09:49 --> Total execution time: 0.7329
INFO - 2020-04-04 11:09:49 --> Config Class Initialized
INFO - 2020-04-04 11:09:49 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:09:49 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:09:49 --> Utf8 Class Initialized
INFO - 2020-04-04 11:09:49 --> URI Class Initialized
INFO - 2020-04-04 11:09:49 --> Config Class Initialized
INFO - 2020-04-04 11:09:49 --> Router Class Initialized
INFO - 2020-04-04 11:09:49 --> Hooks Class Initialized
INFO - 2020-04-04 11:09:49 --> Output Class Initialized
INFO - 2020-04-04 11:09:49 --> Security Class Initialized
DEBUG - 2020-04-04 11:09:49 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:09:49 --> Utf8 Class Initialized
DEBUG - 2020-04-04 11:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:09:49 --> CSRF cookie sent
INFO - 2020-04-04 11:09:49 --> URI Class Initialized
INFO - 2020-04-04 11:09:49 --> Input Class Initialized
INFO - 2020-04-04 11:09:49 --> Router Class Initialized
INFO - 2020-04-04 11:09:49 --> Language Class Initialized
INFO - 2020-04-04 11:09:49 --> Output Class Initialized
ERROR - 2020-04-04 11:09:49 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:09:49 --> Security Class Initialized
DEBUG - 2020-04-04 11:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:09:49 --> CSRF cookie sent
INFO - 2020-04-04 11:09:49 --> Input Class Initialized
INFO - 2020-04-04 11:09:49 --> Language Class Initialized
ERROR - 2020-04-04 11:09:49 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:10:06 --> Config Class Initialized
INFO - 2020-04-04 11:10:06 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:10:06 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:10:06 --> Utf8 Class Initialized
INFO - 2020-04-04 11:10:06 --> URI Class Initialized
INFO - 2020-04-04 11:10:06 --> Router Class Initialized
INFO - 2020-04-04 11:10:06 --> Output Class Initialized
INFO - 2020-04-04 11:10:06 --> Security Class Initialized
DEBUG - 2020-04-04 11:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:10:06 --> CSRF cookie sent
INFO - 2020-04-04 11:10:06 --> Input Class Initialized
INFO - 2020-04-04 11:10:06 --> Language Class Initialized
INFO - 2020-04-04 11:10:06 --> Language Class Initialized
INFO - 2020-04-04 11:10:06 --> Config Class Initialized
INFO - 2020-04-04 11:10:06 --> Loader Class Initialized
INFO - 2020-04-04 11:10:06 --> Helper loaded: url_helper
INFO - 2020-04-04 11:10:06 --> Helper loaded: file_helper
INFO - 2020-04-04 11:10:06 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:10:06 --> Helper loaded: common_helper
INFO - 2020-04-04 11:10:06 --> Helper loaded: language_helper
INFO - 2020-04-04 11:10:06 --> Helper loaded: email_helper
INFO - 2020-04-04 11:10:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:10:07 --> Database Driver Class Initialized
INFO - 2020-04-04 11:10:07 --> Parser Class Initialized
INFO - 2020-04-04 11:10:07 --> User Agent Class Initialized
INFO - 2020-04-04 11:10:07 --> Model Class Initialized
INFO - 2020-04-04 11:10:07 --> Model Class Initialized
DEBUG - 2020-04-04 11:10:07 --> Template Class Initialized
INFO - 2020-04-04 11:10:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:10:07 --> Email Class Initialized
INFO - 2020-04-04 11:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:10:07 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:10:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:10:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:10:07 --> Encryption Class Initialized
INFO - 2020-04-04 11:10:07 --> Controller Class Initialized
DEBUG - 2020-04-04 11:10:07 --> post MX_Controller Initialized
INFO - 2020-04-04 11:10:07 --> Model Class Initialized
ERROR - 2020-04-04 11:10:07 --> Could not find the language line ""
ERROR - 2020-04-04 11:10:07 --> Could not find the language line ""
ERROR - 2020-04-04 11:10:07 --> Could not find the language line ""
DEBUG - 2020-04-04 11:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:10:07 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:10:07 --> Final output sent to browser
DEBUG - 2020-04-04 11:10:07 --> Total execution time: 0.6429
INFO - 2020-04-04 11:10:07 --> Config Class Initialized
INFO - 2020-04-04 11:10:07 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:10:07 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:10:07 --> Utf8 Class Initialized
INFO - 2020-04-04 11:10:07 --> URI Class Initialized
INFO - 2020-04-04 11:10:07 --> Router Class Initialized
INFO - 2020-04-04 11:10:07 --> Output Class Initialized
INFO - 2020-04-04 11:10:07 --> Security Class Initialized
DEBUG - 2020-04-04 11:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:10:07 --> CSRF cookie sent
INFO - 2020-04-04 11:10:07 --> Input Class Initialized
INFO - 2020-04-04 11:10:07 --> Language Class Initialized
ERROR - 2020-04-04 11:10:07 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:10:08 --> Config Class Initialized
INFO - 2020-04-04 11:10:08 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:10:08 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:10:08 --> Utf8 Class Initialized
INFO - 2020-04-04 11:10:08 --> URI Class Initialized
INFO - 2020-04-04 11:10:08 --> Router Class Initialized
INFO - 2020-04-04 11:10:08 --> Output Class Initialized
INFO - 2020-04-04 11:10:08 --> Security Class Initialized
DEBUG - 2020-04-04 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:10:08 --> CSRF cookie sent
INFO - 2020-04-04 11:10:08 --> Input Class Initialized
INFO - 2020-04-04 11:10:08 --> Language Class Initialized
ERROR - 2020-04-04 11:10:08 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:11:06 --> Config Class Initialized
INFO - 2020-04-04 11:11:06 --> Config Class Initialized
INFO - 2020-04-04 11:11:06 --> Hooks Class Initialized
INFO - 2020-04-04 11:11:06 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:11:06 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:11:06 --> Utf8 Class Initialized
INFO - 2020-04-04 11:11:06 --> Utf8 Class Initialized
INFO - 2020-04-04 11:11:06 --> URI Class Initialized
INFO - 2020-04-04 11:11:06 --> URI Class Initialized
INFO - 2020-04-04 11:11:06 --> Router Class Initialized
INFO - 2020-04-04 11:11:06 --> Router Class Initialized
INFO - 2020-04-04 11:11:06 --> Output Class Initialized
INFO - 2020-04-04 11:11:06 --> Output Class Initialized
INFO - 2020-04-04 11:11:06 --> Security Class Initialized
INFO - 2020-04-04 11:11:06 --> Security Class Initialized
DEBUG - 2020-04-04 11:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:11:06 --> CSRF cookie sent
INFO - 2020-04-04 11:11:06 --> CSRF cookie sent
INFO - 2020-04-04 11:11:06 --> Input Class Initialized
INFO - 2020-04-04 11:11:06 --> Input Class Initialized
INFO - 2020-04-04 11:11:06 --> Language Class Initialized
INFO - 2020-04-04 11:11:06 --> Language Class Initialized
ERROR - 2020-04-04 11:11:06 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:11:06 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:13:09 --> Config Class Initialized
INFO - 2020-04-04 11:13:09 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:13:09 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:13:09 --> Utf8 Class Initialized
INFO - 2020-04-04 11:13:09 --> URI Class Initialized
INFO - 2020-04-04 11:13:09 --> Router Class Initialized
INFO - 2020-04-04 11:13:09 --> Output Class Initialized
INFO - 2020-04-04 11:13:09 --> Security Class Initialized
DEBUG - 2020-04-04 11:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:13:09 --> CSRF cookie sent
INFO - 2020-04-04 11:13:09 --> Input Class Initialized
INFO - 2020-04-04 11:13:09 --> Language Class Initialized
INFO - 2020-04-04 11:13:09 --> Language Class Initialized
INFO - 2020-04-04 11:13:09 --> Config Class Initialized
INFO - 2020-04-04 11:13:09 --> Loader Class Initialized
INFO - 2020-04-04 11:13:09 --> Helper loaded: url_helper
INFO - 2020-04-04 11:13:09 --> Helper loaded: file_helper
INFO - 2020-04-04 11:13:09 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:13:09 --> Helper loaded: common_helper
INFO - 2020-04-04 11:13:09 --> Helper loaded: language_helper
INFO - 2020-04-04 11:13:09 --> Helper loaded: email_helper
INFO - 2020-04-04 11:13:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:13:09 --> Database Driver Class Initialized
INFO - 2020-04-04 11:13:09 --> Parser Class Initialized
INFO - 2020-04-04 11:13:09 --> User Agent Class Initialized
INFO - 2020-04-04 11:13:09 --> Model Class Initialized
INFO - 2020-04-04 11:13:09 --> Model Class Initialized
DEBUG - 2020-04-04 11:13:09 --> Template Class Initialized
INFO - 2020-04-04 11:13:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:13:09 --> Email Class Initialized
INFO - 2020-04-04 11:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:13:09 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:13:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:13:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:13:09 --> Encryption Class Initialized
INFO - 2020-04-04 11:13:09 --> Controller Class Initialized
DEBUG - 2020-04-04 11:13:09 --> post MX_Controller Initialized
INFO - 2020-04-04 11:13:09 --> Model Class Initialized
ERROR - 2020-04-04 11:13:09 --> Could not find the language line ""
ERROR - 2020-04-04 11:13:09 --> Could not find the language line ""
ERROR - 2020-04-04 11:13:09 --> Could not find the language line ""
DEBUG - 2020-04-04 11:13:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:13:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:13:09 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:13:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:13:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:13:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:13:09 --> Final output sent to browser
DEBUG - 2020-04-04 11:13:09 --> Total execution time: 0.7501
INFO - 2020-04-04 11:13:20 --> Config Class Initialized
INFO - 2020-04-04 11:13:20 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:13:20 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:13:20 --> Utf8 Class Initialized
INFO - 2020-04-04 11:13:20 --> URI Class Initialized
INFO - 2020-04-04 11:13:20 --> Router Class Initialized
INFO - 2020-04-04 11:13:20 --> Output Class Initialized
INFO - 2020-04-04 11:13:20 --> Security Class Initialized
DEBUG - 2020-04-04 11:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:13:20 --> CSRF cookie sent
INFO - 2020-04-04 11:13:20 --> Input Class Initialized
INFO - 2020-04-04 11:13:20 --> Language Class Initialized
INFO - 2020-04-04 11:13:20 --> Language Class Initialized
INFO - 2020-04-04 11:13:20 --> Config Class Initialized
INFO - 2020-04-04 11:13:20 --> Loader Class Initialized
INFO - 2020-04-04 11:13:20 --> Helper loaded: url_helper
INFO - 2020-04-04 11:13:20 --> Helper loaded: file_helper
INFO - 2020-04-04 11:13:20 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:13:20 --> Helper loaded: common_helper
INFO - 2020-04-04 11:13:20 --> Helper loaded: language_helper
INFO - 2020-04-04 11:13:20 --> Helper loaded: email_helper
INFO - 2020-04-04 11:13:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:13:21 --> Database Driver Class Initialized
INFO - 2020-04-04 11:13:21 --> Parser Class Initialized
INFO - 2020-04-04 11:13:21 --> User Agent Class Initialized
INFO - 2020-04-04 11:13:21 --> Model Class Initialized
INFO - 2020-04-04 11:13:21 --> Model Class Initialized
DEBUG - 2020-04-04 11:13:21 --> Template Class Initialized
INFO - 2020-04-04 11:13:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:13:21 --> Email Class Initialized
INFO - 2020-04-04 11:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:13:21 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:13:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:13:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:13:21 --> Encryption Class Initialized
INFO - 2020-04-04 11:13:21 --> Controller Class Initialized
DEBUG - 2020-04-04 11:13:21 --> gallery MX_Controller Initialized
INFO - 2020-04-04 11:13:21 --> Model Class Initialized
INFO - 2020-04-04 11:13:21 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 11:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-04 11:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:13:21 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:13:21 --> Final output sent to browser
DEBUG - 2020-04-04 11:13:21 --> Total execution time: 0.6989
INFO - 2020-04-04 11:16:56 --> Config Class Initialized
INFO - 2020-04-04 11:16:56 --> Config Class Initialized
INFO - 2020-04-04 11:16:56 --> Hooks Class Initialized
INFO - 2020-04-04 11:16:56 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:16:56 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:16:56 --> Utf8 Class Initialized
INFO - 2020-04-04 11:16:56 --> Utf8 Class Initialized
INFO - 2020-04-04 11:16:56 --> URI Class Initialized
INFO - 2020-04-04 11:16:56 --> URI Class Initialized
INFO - 2020-04-04 11:16:56 --> Router Class Initialized
INFO - 2020-04-04 11:16:56 --> Router Class Initialized
INFO - 2020-04-04 11:16:56 --> Output Class Initialized
INFO - 2020-04-04 11:16:56 --> Output Class Initialized
INFO - 2020-04-04 11:16:56 --> Security Class Initialized
INFO - 2020-04-04 11:16:56 --> Security Class Initialized
DEBUG - 2020-04-04 11:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:16:56 --> CSRF cookie sent
INFO - 2020-04-04 11:16:56 --> CSRF cookie sent
INFO - 2020-04-04 11:16:56 --> Input Class Initialized
INFO - 2020-04-04 11:16:56 --> Input Class Initialized
INFO - 2020-04-04 11:16:56 --> Language Class Initialized
INFO - 2020-04-04 11:16:56 --> Language Class Initialized
ERROR - 2020-04-04 11:16:56 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:16:56 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:17:12 --> Config Class Initialized
INFO - 2020-04-04 11:17:12 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:17:12 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:17:12 --> Utf8 Class Initialized
INFO - 2020-04-04 11:17:12 --> URI Class Initialized
INFO - 2020-04-04 11:17:12 --> Router Class Initialized
INFO - 2020-04-04 11:17:12 --> Output Class Initialized
INFO - 2020-04-04 11:17:12 --> Security Class Initialized
DEBUG - 2020-04-04 11:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:17:12 --> CSRF cookie sent
INFO - 2020-04-04 11:17:12 --> Input Class Initialized
INFO - 2020-04-04 11:17:12 --> Language Class Initialized
INFO - 2020-04-04 11:17:12 --> Language Class Initialized
INFO - 2020-04-04 11:17:12 --> Config Class Initialized
INFO - 2020-04-04 11:17:12 --> Loader Class Initialized
INFO - 2020-04-04 11:17:12 --> Helper loaded: url_helper
INFO - 2020-04-04 11:17:12 --> Helper loaded: file_helper
INFO - 2020-04-04 11:17:12 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:17:12 --> Helper loaded: common_helper
INFO - 2020-04-04 11:17:12 --> Helper loaded: language_helper
INFO - 2020-04-04 11:17:12 --> Helper loaded: email_helper
INFO - 2020-04-04 11:17:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:17:12 --> Database Driver Class Initialized
INFO - 2020-04-04 11:17:12 --> Parser Class Initialized
INFO - 2020-04-04 11:17:12 --> User Agent Class Initialized
INFO - 2020-04-04 11:17:12 --> Model Class Initialized
INFO - 2020-04-04 11:17:12 --> Model Class Initialized
DEBUG - 2020-04-04 11:17:12 --> Template Class Initialized
INFO - 2020-04-04 11:17:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:17:12 --> Email Class Initialized
INFO - 2020-04-04 11:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:17:13 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:17:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:17:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:17:13 --> Encryption Class Initialized
INFO - 2020-04-04 11:17:13 --> Controller Class Initialized
DEBUG - 2020-04-04 11:17:13 --> post MX_Controller Initialized
INFO - 2020-04-04 11:17:13 --> Model Class Initialized
ERROR - 2020-04-04 11:17:13 --> Could not find the language line ""
ERROR - 2020-04-04 11:17:13 --> Could not find the language line ""
ERROR - 2020-04-04 11:17:13 --> Could not find the language line ""
DEBUG - 2020-04-04 11:17:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:17:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:17:13 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:17:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:17:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:17:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:17:13 --> Final output sent to browser
DEBUG - 2020-04-04 11:17:13 --> Total execution time: 0.7765
INFO - 2020-04-04 11:18:07 --> Config Class Initialized
INFO - 2020-04-04 11:18:07 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:18:07 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:18:07 --> Utf8 Class Initialized
INFO - 2020-04-04 11:18:07 --> URI Class Initialized
INFO - 2020-04-04 11:18:07 --> Router Class Initialized
INFO - 2020-04-04 11:18:07 --> Output Class Initialized
INFO - 2020-04-04 11:18:07 --> Security Class Initialized
DEBUG - 2020-04-04 11:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:18:07 --> CSRF cookie sent
INFO - 2020-04-04 11:18:07 --> Input Class Initialized
INFO - 2020-04-04 11:18:07 --> Language Class Initialized
INFO - 2020-04-04 11:18:07 --> Language Class Initialized
INFO - 2020-04-04 11:18:07 --> Config Class Initialized
INFO - 2020-04-04 11:18:07 --> Loader Class Initialized
INFO - 2020-04-04 11:18:07 --> Helper loaded: url_helper
INFO - 2020-04-04 11:18:07 --> Helper loaded: file_helper
INFO - 2020-04-04 11:18:07 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:18:07 --> Helper loaded: common_helper
INFO - 2020-04-04 11:18:07 --> Helper loaded: language_helper
INFO - 2020-04-04 11:18:07 --> Helper loaded: email_helper
INFO - 2020-04-04 11:18:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:18:07 --> Database Driver Class Initialized
INFO - 2020-04-04 11:18:07 --> Parser Class Initialized
INFO - 2020-04-04 11:18:07 --> User Agent Class Initialized
INFO - 2020-04-04 11:18:07 --> Model Class Initialized
INFO - 2020-04-04 11:18:07 --> Model Class Initialized
DEBUG - 2020-04-04 11:18:07 --> Template Class Initialized
INFO - 2020-04-04 11:18:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:18:08 --> Email Class Initialized
INFO - 2020-04-04 11:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:18:08 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:18:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:18:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:18:08 --> Encryption Class Initialized
INFO - 2020-04-04 11:18:08 --> Controller Class Initialized
DEBUG - 2020-04-04 11:18:08 --> post MX_Controller Initialized
INFO - 2020-04-04 11:18:08 --> Model Class Initialized
INFO - 2020-04-04 11:19:04 --> Config Class Initialized
INFO - 2020-04-04 11:19:04 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:19:04 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:19:04 --> Utf8 Class Initialized
INFO - 2020-04-04 11:19:04 --> URI Class Initialized
INFO - 2020-04-04 11:19:04 --> Router Class Initialized
INFO - 2020-04-04 11:19:04 --> Output Class Initialized
INFO - 2020-04-04 11:19:04 --> Security Class Initialized
DEBUG - 2020-04-04 11:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:19:05 --> CSRF cookie sent
INFO - 2020-04-04 11:19:05 --> Input Class Initialized
INFO - 2020-04-04 11:19:05 --> Language Class Initialized
INFO - 2020-04-04 11:19:05 --> Language Class Initialized
INFO - 2020-04-04 11:19:05 --> Config Class Initialized
INFO - 2020-04-04 11:19:05 --> Loader Class Initialized
INFO - 2020-04-04 11:19:05 --> Helper loaded: url_helper
INFO - 2020-04-04 11:19:05 --> Helper loaded: file_helper
INFO - 2020-04-04 11:19:05 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:19:05 --> Helper loaded: common_helper
INFO - 2020-04-04 11:19:05 --> Helper loaded: language_helper
INFO - 2020-04-04 11:19:05 --> Helper loaded: email_helper
INFO - 2020-04-04 11:19:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:19:05 --> Database Driver Class Initialized
INFO - 2020-04-04 11:19:05 --> Parser Class Initialized
INFO - 2020-04-04 11:19:05 --> User Agent Class Initialized
INFO - 2020-04-04 11:19:05 --> Model Class Initialized
INFO - 2020-04-04 11:19:05 --> Model Class Initialized
DEBUG - 2020-04-04 11:19:05 --> Template Class Initialized
INFO - 2020-04-04 11:19:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:19:05 --> Email Class Initialized
INFO - 2020-04-04 11:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:19:05 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:19:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:19:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:19:05 --> Encryption Class Initialized
INFO - 2020-04-04 11:19:05 --> Controller Class Initialized
DEBUG - 2020-04-04 11:19:05 --> post MX_Controller Initialized
INFO - 2020-04-04 11:19:05 --> Model Class Initialized
ERROR - 2020-04-04 11:19:05 --> Could not find the language line ""
ERROR - 2020-04-04 11:19:05 --> Could not find the language line ""
ERROR - 2020-04-04 11:19:05 --> Could not find the language line ""
DEBUG - 2020-04-04 11:19:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:19:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:19:05 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:19:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:19:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:19:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:19:05 --> Final output sent to browser
DEBUG - 2020-04-04 11:19:05 --> Total execution time: 0.8285
INFO - 2020-04-04 11:19:53 --> Config Class Initialized
INFO - 2020-04-04 11:19:53 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:19:53 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:19:53 --> Utf8 Class Initialized
INFO - 2020-04-04 11:19:53 --> URI Class Initialized
INFO - 2020-04-04 11:19:53 --> Router Class Initialized
INFO - 2020-04-04 11:19:53 --> Output Class Initialized
INFO - 2020-04-04 11:19:53 --> Security Class Initialized
DEBUG - 2020-04-04 11:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:19:53 --> CSRF cookie sent
INFO - 2020-04-04 11:19:53 --> Input Class Initialized
INFO - 2020-04-04 11:19:53 --> Language Class Initialized
INFO - 2020-04-04 11:19:53 --> Language Class Initialized
INFO - 2020-04-04 11:19:53 --> Config Class Initialized
INFO - 2020-04-04 11:19:53 --> Loader Class Initialized
INFO - 2020-04-04 11:19:53 --> Helper loaded: url_helper
INFO - 2020-04-04 11:19:53 --> Helper loaded: file_helper
INFO - 2020-04-04 11:19:53 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:19:53 --> Helper loaded: common_helper
INFO - 2020-04-04 11:19:53 --> Helper loaded: language_helper
INFO - 2020-04-04 11:19:53 --> Helper loaded: email_helper
INFO - 2020-04-04 11:19:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:19:53 --> Database Driver Class Initialized
INFO - 2020-04-04 11:19:53 --> Parser Class Initialized
INFO - 2020-04-04 11:19:53 --> User Agent Class Initialized
INFO - 2020-04-04 11:19:53 --> Model Class Initialized
INFO - 2020-04-04 11:19:53 --> Model Class Initialized
DEBUG - 2020-04-04 11:19:53 --> Template Class Initialized
INFO - 2020-04-04 11:19:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:19:53 --> Email Class Initialized
INFO - 2020-04-04 11:19:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:19:53 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:19:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:19:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:19:53 --> Encryption Class Initialized
INFO - 2020-04-04 11:19:53 --> Controller Class Initialized
DEBUG - 2020-04-04 11:19:53 --> post MX_Controller Initialized
INFO - 2020-04-04 11:19:53 --> Model Class Initialized
ERROR - 2020-04-04 11:19:53 --> Could not find the language line ""
ERROR - 2020-04-04 11:19:53 --> Could not find the language line ""
ERROR - 2020-04-04 11:19:53 --> Could not find the language line ""
DEBUG - 2020-04-04 11:19:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:19:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:19:53 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:19:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:19:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:19:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:19:53 --> Final output sent to browser
DEBUG - 2020-04-04 11:19:53 --> Total execution time: 0.7575
INFO - 2020-04-04 11:20:09 --> Config Class Initialized
INFO - 2020-04-04 11:20:09 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:20:09 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:20:09 --> Utf8 Class Initialized
INFO - 2020-04-04 11:20:09 --> URI Class Initialized
INFO - 2020-04-04 11:20:09 --> Router Class Initialized
INFO - 2020-04-04 11:20:09 --> Output Class Initialized
INFO - 2020-04-04 11:20:09 --> Security Class Initialized
DEBUG - 2020-04-04 11:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:20:09 --> CSRF cookie sent
INFO - 2020-04-04 11:20:09 --> Input Class Initialized
INFO - 2020-04-04 11:20:09 --> Language Class Initialized
INFO - 2020-04-04 11:20:09 --> Language Class Initialized
INFO - 2020-04-04 11:20:09 --> Config Class Initialized
INFO - 2020-04-04 11:20:09 --> Loader Class Initialized
INFO - 2020-04-04 11:20:09 --> Helper loaded: url_helper
INFO - 2020-04-04 11:20:09 --> Helper loaded: file_helper
INFO - 2020-04-04 11:20:09 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:20:09 --> Helper loaded: common_helper
INFO - 2020-04-04 11:20:09 --> Helper loaded: language_helper
INFO - 2020-04-04 11:20:09 --> Helper loaded: email_helper
INFO - 2020-04-04 11:20:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:20:09 --> Database Driver Class Initialized
INFO - 2020-04-04 11:20:09 --> Parser Class Initialized
INFO - 2020-04-04 11:20:09 --> User Agent Class Initialized
INFO - 2020-04-04 11:20:09 --> Model Class Initialized
INFO - 2020-04-04 11:20:09 --> Model Class Initialized
DEBUG - 2020-04-04 11:20:10 --> Template Class Initialized
INFO - 2020-04-04 11:20:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:20:10 --> Email Class Initialized
INFO - 2020-04-04 11:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:20:10 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:20:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:20:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:20:10 --> Encryption Class Initialized
INFO - 2020-04-04 11:20:10 --> Controller Class Initialized
DEBUG - 2020-04-04 11:20:10 --> post MX_Controller Initialized
INFO - 2020-04-04 11:20:10 --> Model Class Initialized
ERROR - 2020-04-04 11:20:10 --> Could not find the language line ""
ERROR - 2020-04-04 11:20:10 --> Could not find the language line ""
ERROR - 2020-04-04 11:20:10 --> Could not find the language line ""
DEBUG - 2020-04-04 11:20:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:20:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:20:10 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:20:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:20:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:20:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:20:10 --> Final output sent to browser
DEBUG - 2020-04-04 11:20:10 --> Total execution time: 0.6836
INFO - 2020-04-04 11:21:27 --> Config Class Initialized
INFO - 2020-04-04 11:21:27 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:21:27 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:21:27 --> Utf8 Class Initialized
INFO - 2020-04-04 11:21:27 --> URI Class Initialized
INFO - 2020-04-04 11:21:27 --> Router Class Initialized
INFO - 2020-04-04 11:21:27 --> Output Class Initialized
INFO - 2020-04-04 11:21:27 --> Security Class Initialized
DEBUG - 2020-04-04 11:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:21:27 --> CSRF cookie sent
INFO - 2020-04-04 11:21:27 --> Input Class Initialized
INFO - 2020-04-04 11:21:28 --> Language Class Initialized
INFO - 2020-04-04 11:21:28 --> Language Class Initialized
INFO - 2020-04-04 11:21:28 --> Config Class Initialized
INFO - 2020-04-04 11:21:28 --> Loader Class Initialized
INFO - 2020-04-04 11:21:28 --> Helper loaded: url_helper
INFO - 2020-04-04 11:21:28 --> Helper loaded: file_helper
INFO - 2020-04-04 11:21:28 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:21:28 --> Helper loaded: common_helper
INFO - 2020-04-04 11:21:28 --> Helper loaded: language_helper
INFO - 2020-04-04 11:21:28 --> Helper loaded: email_helper
INFO - 2020-04-04 11:21:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:21:28 --> Database Driver Class Initialized
INFO - 2020-04-04 11:21:28 --> Parser Class Initialized
INFO - 2020-04-04 11:21:28 --> User Agent Class Initialized
INFO - 2020-04-04 11:21:28 --> Model Class Initialized
INFO - 2020-04-04 11:21:28 --> Model Class Initialized
DEBUG - 2020-04-04 11:21:28 --> Template Class Initialized
INFO - 2020-04-04 11:21:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:21:28 --> Email Class Initialized
INFO - 2020-04-04 11:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:21:28 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:21:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:21:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:21:28 --> Encryption Class Initialized
INFO - 2020-04-04 11:21:28 --> Controller Class Initialized
DEBUG - 2020-04-04 11:21:28 --> post MX_Controller Initialized
INFO - 2020-04-04 11:21:28 --> Model Class Initialized
ERROR - 2020-04-04 11:21:28 --> Could not find the language line ""
ERROR - 2020-04-04 11:21:28 --> Could not find the language line ""
ERROR - 2020-04-04 11:21:28 --> Could not find the language line ""
DEBUG - 2020-04-04 11:21:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:21:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:21:28 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:21:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:21:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:21:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:21:28 --> Final output sent to browser
DEBUG - 2020-04-04 11:21:28 --> Total execution time: 0.6614
INFO - 2020-04-04 11:21:40 --> Config Class Initialized
INFO - 2020-04-04 11:21:40 --> Config Class Initialized
INFO - 2020-04-04 11:21:40 --> Hooks Class Initialized
INFO - 2020-04-04 11:21:40 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:21:40 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:21:40 --> Utf8 Class Initialized
INFO - 2020-04-04 11:21:40 --> Utf8 Class Initialized
INFO - 2020-04-04 11:21:40 --> URI Class Initialized
INFO - 2020-04-04 11:21:40 --> URI Class Initialized
INFO - 2020-04-04 11:21:40 --> Router Class Initialized
INFO - 2020-04-04 11:21:40 --> Router Class Initialized
INFO - 2020-04-04 11:21:40 --> Output Class Initialized
INFO - 2020-04-04 11:21:40 --> Output Class Initialized
INFO - 2020-04-04 11:21:40 --> Security Class Initialized
INFO - 2020-04-04 11:21:40 --> Security Class Initialized
DEBUG - 2020-04-04 11:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:21:40 --> CSRF cookie sent
INFO - 2020-04-04 11:21:40 --> CSRF cookie sent
INFO - 2020-04-04 11:21:40 --> Input Class Initialized
INFO - 2020-04-04 11:21:40 --> Input Class Initialized
INFO - 2020-04-04 11:21:40 --> Language Class Initialized
INFO - 2020-04-04 11:21:40 --> Language Class Initialized
ERROR - 2020-04-04 11:21:40 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:21:40 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:23:20 --> Config Class Initialized
INFO - 2020-04-04 11:23:20 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:23:20 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:23:20 --> Utf8 Class Initialized
INFO - 2020-04-04 11:23:20 --> URI Class Initialized
INFO - 2020-04-04 11:23:20 --> Router Class Initialized
INFO - 2020-04-04 11:23:20 --> Output Class Initialized
INFO - 2020-04-04 11:23:20 --> Security Class Initialized
DEBUG - 2020-04-04 11:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:23:20 --> CSRF cookie sent
INFO - 2020-04-04 11:23:20 --> Input Class Initialized
INFO - 2020-04-04 11:23:20 --> Language Class Initialized
INFO - 2020-04-04 11:23:20 --> Language Class Initialized
INFO - 2020-04-04 11:23:20 --> Config Class Initialized
INFO - 2020-04-04 11:23:20 --> Loader Class Initialized
INFO - 2020-04-04 11:23:20 --> Helper loaded: url_helper
INFO - 2020-04-04 11:23:20 --> Helper loaded: file_helper
INFO - 2020-04-04 11:23:21 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:23:21 --> Helper loaded: common_helper
INFO - 2020-04-04 11:23:21 --> Helper loaded: language_helper
INFO - 2020-04-04 11:23:21 --> Helper loaded: email_helper
INFO - 2020-04-04 11:23:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:23:21 --> Database Driver Class Initialized
INFO - 2020-04-04 11:23:21 --> Parser Class Initialized
INFO - 2020-04-04 11:23:21 --> User Agent Class Initialized
INFO - 2020-04-04 11:23:21 --> Model Class Initialized
INFO - 2020-04-04 11:23:21 --> Model Class Initialized
DEBUG - 2020-04-04 11:23:21 --> Template Class Initialized
INFO - 2020-04-04 11:23:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:23:21 --> Email Class Initialized
INFO - 2020-04-04 11:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:23:21 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:23:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:23:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:23:21 --> Encryption Class Initialized
INFO - 2020-04-04 11:23:21 --> Controller Class Initialized
DEBUG - 2020-04-04 11:23:21 --> post MX_Controller Initialized
INFO - 2020-04-04 11:23:21 --> Model Class Initialized
ERROR - 2020-04-04 11:23:21 --> Could not find the language line ""
ERROR - 2020-04-04 11:23:21 --> Could not find the language line ""
ERROR - 2020-04-04 11:23:21 --> Could not find the language line ""
DEBUG - 2020-04-04 11:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:23:21 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:23:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:23:21 --> Final output sent to browser
DEBUG - 2020-04-04 11:23:21 --> Total execution time: 0.6886
INFO - 2020-04-04 11:23:21 --> Config Class Initialized
INFO - 2020-04-04 11:23:21 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:23:21 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:23:21 --> Utf8 Class Initialized
INFO - 2020-04-04 11:23:21 --> URI Class Initialized
INFO - 2020-04-04 11:23:21 --> Router Class Initialized
INFO - 2020-04-04 11:23:21 --> Output Class Initialized
INFO - 2020-04-04 11:23:21 --> Security Class Initialized
DEBUG - 2020-04-04 11:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:23:21 --> CSRF cookie sent
INFO - 2020-04-04 11:23:21 --> Input Class Initialized
INFO - 2020-04-04 11:23:21 --> Language Class Initialized
ERROR - 2020-04-04 11:23:22 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:23:22 --> Config Class Initialized
INFO - 2020-04-04 11:23:22 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:23:22 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:23:22 --> Utf8 Class Initialized
INFO - 2020-04-04 11:23:22 --> URI Class Initialized
INFO - 2020-04-04 11:23:22 --> Router Class Initialized
INFO - 2020-04-04 11:23:22 --> Output Class Initialized
INFO - 2020-04-04 11:23:22 --> Security Class Initialized
DEBUG - 2020-04-04 11:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:23:22 --> CSRF cookie sent
INFO - 2020-04-04 11:23:22 --> Input Class Initialized
INFO - 2020-04-04 11:23:22 --> Language Class Initialized
ERROR - 2020-04-04 11:23:22 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:23:41 --> Config Class Initialized
INFO - 2020-04-04 11:23:41 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:23:42 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:23:42 --> Utf8 Class Initialized
INFO - 2020-04-04 11:23:42 --> URI Class Initialized
INFO - 2020-04-04 11:23:42 --> Router Class Initialized
INFO - 2020-04-04 11:23:42 --> Output Class Initialized
INFO - 2020-04-04 11:23:42 --> Security Class Initialized
DEBUG - 2020-04-04 11:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:23:42 --> CSRF cookie sent
INFO - 2020-04-04 11:23:42 --> Input Class Initialized
INFO - 2020-04-04 11:23:42 --> Language Class Initialized
INFO - 2020-04-04 11:23:42 --> Language Class Initialized
INFO - 2020-04-04 11:23:42 --> Config Class Initialized
INFO - 2020-04-04 11:23:42 --> Loader Class Initialized
INFO - 2020-04-04 11:23:42 --> Helper loaded: url_helper
INFO - 2020-04-04 11:23:42 --> Helper loaded: file_helper
INFO - 2020-04-04 11:23:42 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:23:42 --> Helper loaded: common_helper
INFO - 2020-04-04 11:23:42 --> Helper loaded: language_helper
INFO - 2020-04-04 11:23:42 --> Helper loaded: email_helper
INFO - 2020-04-04 11:23:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:23:42 --> Database Driver Class Initialized
INFO - 2020-04-04 11:23:42 --> Parser Class Initialized
INFO - 2020-04-04 11:23:42 --> User Agent Class Initialized
INFO - 2020-04-04 11:23:42 --> Model Class Initialized
INFO - 2020-04-04 11:23:42 --> Model Class Initialized
DEBUG - 2020-04-04 11:23:42 --> Template Class Initialized
INFO - 2020-04-04 11:23:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:23:42 --> Email Class Initialized
INFO - 2020-04-04 11:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:23:42 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:23:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:23:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:23:42 --> Encryption Class Initialized
INFO - 2020-04-04 11:23:42 --> Controller Class Initialized
DEBUG - 2020-04-04 11:23:42 --> post MX_Controller Initialized
INFO - 2020-04-04 11:23:42 --> Model Class Initialized
ERROR - 2020-04-04 11:23:42 --> Could not find the language line ""
ERROR - 2020-04-04 11:23:42 --> Could not find the language line ""
ERROR - 2020-04-04 11:23:42 --> Could not find the language line ""
DEBUG - 2020-04-04 11:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:23:42 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:23:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:23:42 --> Final output sent to browser
DEBUG - 2020-04-04 11:23:42 --> Total execution time: 0.6707
INFO - 2020-04-04 11:23:53 --> Config Class Initialized
INFO - 2020-04-04 11:23:53 --> Config Class Initialized
INFO - 2020-04-04 11:23:53 --> Hooks Class Initialized
INFO - 2020-04-04 11:23:53 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:23:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:23:54 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:23:54 --> Utf8 Class Initialized
INFO - 2020-04-04 11:23:54 --> Utf8 Class Initialized
INFO - 2020-04-04 11:23:54 --> URI Class Initialized
INFO - 2020-04-04 11:23:54 --> URI Class Initialized
INFO - 2020-04-04 11:23:54 --> Router Class Initialized
INFO - 2020-04-04 11:23:54 --> Router Class Initialized
INFO - 2020-04-04 11:23:54 --> Output Class Initialized
INFO - 2020-04-04 11:23:54 --> Output Class Initialized
INFO - 2020-04-04 11:23:54 --> Security Class Initialized
INFO - 2020-04-04 11:23:54 --> Security Class Initialized
DEBUG - 2020-04-04 11:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:23:54 --> CSRF cookie sent
INFO - 2020-04-04 11:23:54 --> CSRF cookie sent
INFO - 2020-04-04 11:23:54 --> Input Class Initialized
INFO - 2020-04-04 11:23:54 --> Input Class Initialized
INFO - 2020-04-04 11:23:54 --> Language Class Initialized
INFO - 2020-04-04 11:23:54 --> Language Class Initialized
ERROR - 2020-04-04 11:23:54 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:23:54 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:24:25 --> Config Class Initialized
INFO - 2020-04-04 11:24:25 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:24:25 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:24:25 --> Utf8 Class Initialized
INFO - 2020-04-04 11:24:25 --> URI Class Initialized
INFO - 2020-04-04 11:24:25 --> Router Class Initialized
INFO - 2020-04-04 11:24:25 --> Output Class Initialized
INFO - 2020-04-04 11:24:25 --> Security Class Initialized
DEBUG - 2020-04-04 11:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:24:25 --> CSRF cookie sent
INFO - 2020-04-04 11:24:25 --> Input Class Initialized
INFO - 2020-04-04 11:24:25 --> Language Class Initialized
INFO - 2020-04-04 11:24:25 --> Language Class Initialized
INFO - 2020-04-04 11:24:25 --> Config Class Initialized
INFO - 2020-04-04 11:24:25 --> Loader Class Initialized
INFO - 2020-04-04 11:24:25 --> Helper loaded: url_helper
INFO - 2020-04-04 11:24:25 --> Helper loaded: file_helper
INFO - 2020-04-04 11:24:25 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:24:25 --> Helper loaded: common_helper
INFO - 2020-04-04 11:24:25 --> Helper loaded: language_helper
INFO - 2020-04-04 11:24:25 --> Helper loaded: email_helper
INFO - 2020-04-04 11:24:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:24:25 --> Database Driver Class Initialized
INFO - 2020-04-04 11:24:25 --> Parser Class Initialized
INFO - 2020-04-04 11:24:25 --> User Agent Class Initialized
INFO - 2020-04-04 11:24:25 --> Model Class Initialized
INFO - 2020-04-04 11:24:25 --> Model Class Initialized
DEBUG - 2020-04-04 11:24:25 --> Template Class Initialized
INFO - 2020-04-04 11:24:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:24:25 --> Email Class Initialized
INFO - 2020-04-04 11:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:24:25 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:24:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:24:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:24:25 --> Encryption Class Initialized
INFO - 2020-04-04 11:24:25 --> Controller Class Initialized
DEBUG - 2020-04-04 11:24:25 --> post MX_Controller Initialized
INFO - 2020-04-04 11:24:25 --> Model Class Initialized
ERROR - 2020-04-04 11:24:25 --> Could not find the language line ""
ERROR - 2020-04-04 11:24:25 --> Could not find the language line ""
ERROR - 2020-04-04 11:24:25 --> Could not find the language line ""
DEBUG - 2020-04-04 11:24:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:24:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:24:25 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:24:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:24:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:24:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:24:25 --> Final output sent to browser
DEBUG - 2020-04-04 11:24:25 --> Total execution time: 0.6998
INFO - 2020-04-04 11:24:26 --> Config Class Initialized
INFO - 2020-04-04 11:24:26 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:24:26 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:24:26 --> Utf8 Class Initialized
INFO - 2020-04-04 11:24:26 --> URI Class Initialized
INFO - 2020-04-04 11:24:26 --> Router Class Initialized
INFO - 2020-04-04 11:24:26 --> Output Class Initialized
INFO - 2020-04-04 11:24:26 --> Security Class Initialized
DEBUG - 2020-04-04 11:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:24:26 --> CSRF cookie sent
INFO - 2020-04-04 11:24:26 --> Input Class Initialized
INFO - 2020-04-04 11:24:26 --> Language Class Initialized
ERROR - 2020-04-04 11:24:26 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:24:26 --> Config Class Initialized
INFO - 2020-04-04 11:24:26 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:24:26 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:24:26 --> Utf8 Class Initialized
INFO - 2020-04-04 11:24:26 --> URI Class Initialized
INFO - 2020-04-04 11:24:26 --> Router Class Initialized
INFO - 2020-04-04 11:24:26 --> Output Class Initialized
INFO - 2020-04-04 11:24:26 --> Security Class Initialized
DEBUG - 2020-04-04 11:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:24:26 --> CSRF cookie sent
INFO - 2020-04-04 11:24:26 --> Input Class Initialized
INFO - 2020-04-04 11:24:26 --> Language Class Initialized
ERROR - 2020-04-04 11:24:26 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:25:14 --> Config Class Initialized
INFO - 2020-04-04 11:25:14 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:25:14 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:25:14 --> Utf8 Class Initialized
INFO - 2020-04-04 11:25:14 --> URI Class Initialized
INFO - 2020-04-04 11:25:14 --> Router Class Initialized
INFO - 2020-04-04 11:25:14 --> Output Class Initialized
INFO - 2020-04-04 11:25:14 --> Security Class Initialized
DEBUG - 2020-04-04 11:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:25:14 --> CSRF cookie sent
INFO - 2020-04-04 11:25:14 --> Input Class Initialized
INFO - 2020-04-04 11:25:14 --> Language Class Initialized
INFO - 2020-04-04 11:25:14 --> Language Class Initialized
INFO - 2020-04-04 11:25:14 --> Config Class Initialized
INFO - 2020-04-04 11:25:14 --> Loader Class Initialized
INFO - 2020-04-04 11:25:14 --> Helper loaded: url_helper
INFO - 2020-04-04 11:25:14 --> Helper loaded: file_helper
INFO - 2020-04-04 11:25:14 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:25:14 --> Helper loaded: common_helper
INFO - 2020-04-04 11:25:14 --> Helper loaded: language_helper
INFO - 2020-04-04 11:25:14 --> Helper loaded: email_helper
INFO - 2020-04-04 11:25:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:25:14 --> Database Driver Class Initialized
INFO - 2020-04-04 11:25:14 --> Parser Class Initialized
INFO - 2020-04-04 11:25:14 --> User Agent Class Initialized
INFO - 2020-04-04 11:25:14 --> Model Class Initialized
INFO - 2020-04-04 11:25:14 --> Model Class Initialized
DEBUG - 2020-04-04 11:25:14 --> Template Class Initialized
INFO - 2020-04-04 11:25:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:25:14 --> Email Class Initialized
INFO - 2020-04-04 11:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:25:14 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:25:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:25:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:25:14 --> Encryption Class Initialized
INFO - 2020-04-04 11:25:14 --> Controller Class Initialized
DEBUG - 2020-04-04 11:25:14 --> post MX_Controller Initialized
INFO - 2020-04-04 11:25:14 --> Model Class Initialized
ERROR - 2020-04-04 11:25:14 --> Could not find the language line ""
ERROR - 2020-04-04 11:25:14 --> Could not find the language line ""
ERROR - 2020-04-04 11:25:14 --> Could not find the language line ""
DEBUG - 2020-04-04 11:25:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:25:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:25:14 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:25:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:25:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:25:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:25:14 --> Final output sent to browser
DEBUG - 2020-04-04 11:25:14 --> Total execution time: 0.7190
INFO - 2020-04-04 11:25:44 --> Config Class Initialized
INFO - 2020-04-04 11:25:44 --> Config Class Initialized
INFO - 2020-04-04 11:25:45 --> Hooks Class Initialized
INFO - 2020-04-04 11:25:45 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:25:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:25:45 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:25:45 --> Utf8 Class Initialized
INFO - 2020-04-04 11:25:45 --> Utf8 Class Initialized
INFO - 2020-04-04 11:25:45 --> URI Class Initialized
INFO - 2020-04-04 11:25:45 --> URI Class Initialized
INFO - 2020-04-04 11:25:45 --> Router Class Initialized
INFO - 2020-04-04 11:25:45 --> Router Class Initialized
INFO - 2020-04-04 11:25:45 --> Output Class Initialized
INFO - 2020-04-04 11:25:45 --> Output Class Initialized
INFO - 2020-04-04 11:25:45 --> Security Class Initialized
INFO - 2020-04-04 11:25:45 --> Security Class Initialized
DEBUG - 2020-04-04 11:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:25:45 --> CSRF cookie sent
INFO - 2020-04-04 11:25:45 --> CSRF cookie sent
INFO - 2020-04-04 11:25:45 --> Input Class Initialized
INFO - 2020-04-04 11:25:45 --> Input Class Initialized
INFO - 2020-04-04 11:25:45 --> Language Class Initialized
INFO - 2020-04-04 11:25:45 --> Language Class Initialized
ERROR - 2020-04-04 11:25:45 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:25:45 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:26:07 --> Config Class Initialized
INFO - 2020-04-04 11:26:07 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:26:07 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:26:07 --> Utf8 Class Initialized
INFO - 2020-04-04 11:26:07 --> URI Class Initialized
INFO - 2020-04-04 11:26:07 --> Router Class Initialized
INFO - 2020-04-04 11:26:07 --> Output Class Initialized
INFO - 2020-04-04 11:26:07 --> Security Class Initialized
DEBUG - 2020-04-04 11:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:26:07 --> CSRF cookie sent
INFO - 2020-04-04 11:26:07 --> CSRF token verified
INFO - 2020-04-04 11:26:07 --> Input Class Initialized
INFO - 2020-04-04 11:26:07 --> Language Class Initialized
INFO - 2020-04-04 11:26:07 --> Language Class Initialized
INFO - 2020-04-04 11:26:07 --> Config Class Initialized
INFO - 2020-04-04 11:26:07 --> Loader Class Initialized
INFO - 2020-04-04 11:26:07 --> Helper loaded: url_helper
INFO - 2020-04-04 11:26:07 --> Helper loaded: file_helper
INFO - 2020-04-04 11:26:07 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:26:07 --> Helper loaded: common_helper
INFO - 2020-04-04 11:26:07 --> Helper loaded: language_helper
INFO - 2020-04-04 11:26:07 --> Helper loaded: email_helper
INFO - 2020-04-04 11:26:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:26:07 --> Database Driver Class Initialized
INFO - 2020-04-04 11:26:07 --> Parser Class Initialized
INFO - 2020-04-04 11:26:07 --> User Agent Class Initialized
INFO - 2020-04-04 11:26:07 --> Model Class Initialized
INFO - 2020-04-04 11:26:07 --> Model Class Initialized
DEBUG - 2020-04-04 11:26:07 --> Template Class Initialized
INFO - 2020-04-04 11:26:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:26:07 --> Email Class Initialized
INFO - 2020-04-04 11:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:26:07 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:26:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:26:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:26:07 --> Encryption Class Initialized
INFO - 2020-04-04 11:26:07 --> Controller Class Initialized
DEBUG - 2020-04-04 11:26:07 --> gallery MX_Controller Initialized
INFO - 2020-04-04 11:26:07 --> Model Class Initialized
INFO - 2020-04-04 11:26:07 --> Upload Class Initialized
INFO - 2020-04-04 11:26:16 --> Config Class Initialized
INFO - 2020-04-04 11:26:16 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:26:16 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:26:17 --> Utf8 Class Initialized
INFO - 2020-04-04 11:26:17 --> URI Class Initialized
INFO - 2020-04-04 11:26:17 --> Router Class Initialized
INFO - 2020-04-04 11:26:17 --> Output Class Initialized
INFO - 2020-04-04 11:26:17 --> Security Class Initialized
DEBUG - 2020-04-04 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:26:17 --> CSRF cookie sent
INFO - 2020-04-04 11:26:17 --> Input Class Initialized
INFO - 2020-04-04 11:26:17 --> Language Class Initialized
INFO - 2020-04-04 11:26:17 --> Language Class Initialized
INFO - 2020-04-04 11:26:17 --> Config Class Initialized
INFO - 2020-04-04 11:26:17 --> Loader Class Initialized
INFO - 2020-04-04 11:26:17 --> Helper loaded: url_helper
INFO - 2020-04-04 11:26:17 --> Helper loaded: file_helper
INFO - 2020-04-04 11:26:17 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:26:17 --> Helper loaded: common_helper
INFO - 2020-04-04 11:26:17 --> Helper loaded: language_helper
INFO - 2020-04-04 11:26:17 --> Helper loaded: email_helper
INFO - 2020-04-04 11:26:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:26:17 --> Database Driver Class Initialized
INFO - 2020-04-04 11:26:17 --> Parser Class Initialized
INFO - 2020-04-04 11:26:17 --> User Agent Class Initialized
INFO - 2020-04-04 11:26:17 --> Model Class Initialized
INFO - 2020-04-04 11:26:17 --> Model Class Initialized
DEBUG - 2020-04-04 11:26:17 --> Template Class Initialized
INFO - 2020-04-04 11:26:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:26:17 --> Email Class Initialized
INFO - 2020-04-04 11:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:26:17 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:26:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:26:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:26:17 --> Encryption Class Initialized
INFO - 2020-04-04 11:26:17 --> Controller Class Initialized
DEBUG - 2020-04-04 11:26:17 --> post MX_Controller Initialized
INFO - 2020-04-04 11:26:17 --> Model Class Initialized
ERROR - 2020-04-04 11:26:17 --> Could not find the language line ""
ERROR - 2020-04-04 11:26:17 --> Could not find the language line ""
ERROR - 2020-04-04 11:26:17 --> Could not find the language line ""
DEBUG - 2020-04-04 11:26:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:26:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:26:17 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:26:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:26:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:26:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:26:17 --> Final output sent to browser
DEBUG - 2020-04-04 11:26:17 --> Total execution time: 0.8032
INFO - 2020-04-04 11:26:18 --> Config Class Initialized
INFO - 2020-04-04 11:26:18 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:26:18 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:26:18 --> Utf8 Class Initialized
INFO - 2020-04-04 11:26:18 --> URI Class Initialized
INFO - 2020-04-04 11:26:18 --> Router Class Initialized
INFO - 2020-04-04 11:26:18 --> Config Class Initialized
INFO - 2020-04-04 11:26:18 --> Hooks Class Initialized
INFO - 2020-04-04 11:26:18 --> Output Class Initialized
INFO - 2020-04-04 11:26:18 --> Security Class Initialized
DEBUG - 2020-04-04 11:26:18 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:26:18 --> Utf8 Class Initialized
DEBUG - 2020-04-04 11:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:26:18 --> CSRF cookie sent
INFO - 2020-04-04 11:26:18 --> URI Class Initialized
INFO - 2020-04-04 11:26:18 --> Input Class Initialized
INFO - 2020-04-04 11:26:18 --> Router Class Initialized
INFO - 2020-04-04 11:26:18 --> Language Class Initialized
INFO - 2020-04-04 11:26:18 --> Output Class Initialized
ERROR - 2020-04-04 11:26:18 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:26:18 --> Security Class Initialized
DEBUG - 2020-04-04 11:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:26:18 --> CSRF cookie sent
INFO - 2020-04-04 11:26:18 --> Input Class Initialized
INFO - 2020-04-04 11:26:18 --> Language Class Initialized
ERROR - 2020-04-04 11:26:18 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:26:39 --> Config Class Initialized
INFO - 2020-04-04 11:26:39 --> Config Class Initialized
INFO - 2020-04-04 11:26:39 --> Hooks Class Initialized
INFO - 2020-04-04 11:26:39 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:26:39 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:26:39 --> Utf8 Class Initialized
INFO - 2020-04-04 11:26:39 --> Utf8 Class Initialized
INFO - 2020-04-04 11:26:39 --> URI Class Initialized
INFO - 2020-04-04 11:26:39 --> URI Class Initialized
INFO - 2020-04-04 11:26:39 --> Router Class Initialized
INFO - 2020-04-04 11:26:39 --> Router Class Initialized
INFO - 2020-04-04 11:26:39 --> Output Class Initialized
INFO - 2020-04-04 11:26:39 --> Output Class Initialized
INFO - 2020-04-04 11:26:39 --> Security Class Initialized
INFO - 2020-04-04 11:26:39 --> Security Class Initialized
DEBUG - 2020-04-04 11:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:26:39 --> CSRF cookie sent
INFO - 2020-04-04 11:26:39 --> CSRF cookie sent
INFO - 2020-04-04 11:26:39 --> Input Class Initialized
INFO - 2020-04-04 11:26:39 --> Input Class Initialized
INFO - 2020-04-04 11:26:39 --> Language Class Initialized
INFO - 2020-04-04 11:26:39 --> Language Class Initialized
ERROR - 2020-04-04 11:26:39 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:26:39 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:27:33 --> Config Class Initialized
INFO - 2020-04-04 11:27:33 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:27:33 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:27:33 --> Utf8 Class Initialized
INFO - 2020-04-04 11:27:33 --> URI Class Initialized
INFO - 2020-04-04 11:27:33 --> Router Class Initialized
INFO - 2020-04-04 11:27:33 --> Output Class Initialized
INFO - 2020-04-04 11:27:33 --> Security Class Initialized
DEBUG - 2020-04-04 11:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:27:33 --> CSRF cookie sent
INFO - 2020-04-04 11:27:33 --> Input Class Initialized
INFO - 2020-04-04 11:27:33 --> Language Class Initialized
INFO - 2020-04-04 11:27:33 --> Language Class Initialized
INFO - 2020-04-04 11:27:33 --> Config Class Initialized
INFO - 2020-04-04 11:27:33 --> Loader Class Initialized
INFO - 2020-04-04 11:27:33 --> Helper loaded: url_helper
INFO - 2020-04-04 11:27:33 --> Helper loaded: file_helper
INFO - 2020-04-04 11:27:33 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:27:33 --> Helper loaded: common_helper
INFO - 2020-04-04 11:27:33 --> Helper loaded: language_helper
INFO - 2020-04-04 11:27:33 --> Helper loaded: email_helper
INFO - 2020-04-04 11:27:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:27:33 --> Database Driver Class Initialized
INFO - 2020-04-04 11:27:33 --> Parser Class Initialized
INFO - 2020-04-04 11:27:33 --> User Agent Class Initialized
INFO - 2020-04-04 11:27:33 --> Model Class Initialized
INFO - 2020-04-04 11:27:33 --> Model Class Initialized
DEBUG - 2020-04-04 11:27:33 --> Template Class Initialized
INFO - 2020-04-04 11:27:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:27:33 --> Email Class Initialized
INFO - 2020-04-04 11:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:27:33 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:27:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:27:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:27:33 --> Encryption Class Initialized
INFO - 2020-04-04 11:27:33 --> Controller Class Initialized
DEBUG - 2020-04-04 11:27:33 --> post MX_Controller Initialized
INFO - 2020-04-04 11:27:33 --> Model Class Initialized
ERROR - 2020-04-04 11:27:33 --> Could not find the language line ""
ERROR - 2020-04-04 11:27:33 --> Could not find the language line ""
ERROR - 2020-04-04 11:27:33 --> Could not find the language line ""
DEBUG - 2020-04-04 11:27:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:27:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:27:34 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:27:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:27:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:27:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:27:34 --> Final output sent to browser
DEBUG - 2020-04-04 11:27:34 --> Total execution time: 0.6923
INFO - 2020-04-04 11:27:34 --> Config Class Initialized
INFO - 2020-04-04 11:27:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:27:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:27:34 --> Utf8 Class Initialized
INFO - 2020-04-04 11:27:34 --> URI Class Initialized
INFO - 2020-04-04 11:27:34 --> Router Class Initialized
INFO - 2020-04-04 11:27:34 --> Output Class Initialized
INFO - 2020-04-04 11:27:34 --> Security Class Initialized
DEBUG - 2020-04-04 11:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:27:34 --> CSRF cookie sent
INFO - 2020-04-04 11:27:34 --> Input Class Initialized
INFO - 2020-04-04 11:27:34 --> Language Class Initialized
ERROR - 2020-04-04 11:27:34 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:27:34 --> Config Class Initialized
INFO - 2020-04-04 11:27:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:27:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:27:34 --> Utf8 Class Initialized
INFO - 2020-04-04 11:27:34 --> URI Class Initialized
INFO - 2020-04-04 11:27:34 --> Router Class Initialized
INFO - 2020-04-04 11:27:34 --> Output Class Initialized
INFO - 2020-04-04 11:27:35 --> Security Class Initialized
DEBUG - 2020-04-04 11:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:27:35 --> CSRF cookie sent
INFO - 2020-04-04 11:27:35 --> Input Class Initialized
INFO - 2020-04-04 11:27:35 --> Language Class Initialized
ERROR - 2020-04-04 11:27:35 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:27:42 --> Config Class Initialized
INFO - 2020-04-04 11:27:42 --> Config Class Initialized
INFO - 2020-04-04 11:27:42 --> Hooks Class Initialized
INFO - 2020-04-04 11:27:42 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:27:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:27:42 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:27:42 --> Utf8 Class Initialized
INFO - 2020-04-04 11:27:42 --> Utf8 Class Initialized
INFO - 2020-04-04 11:27:42 --> URI Class Initialized
INFO - 2020-04-04 11:27:42 --> URI Class Initialized
INFO - 2020-04-04 11:27:42 --> Router Class Initialized
INFO - 2020-04-04 11:27:42 --> Router Class Initialized
INFO - 2020-04-04 11:27:42 --> Output Class Initialized
INFO - 2020-04-04 11:27:42 --> Output Class Initialized
INFO - 2020-04-04 11:27:42 --> Security Class Initialized
INFO - 2020-04-04 11:27:42 --> Security Class Initialized
DEBUG - 2020-04-04 11:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:27:42 --> CSRF cookie sent
INFO - 2020-04-04 11:27:42 --> CSRF cookie sent
INFO - 2020-04-04 11:27:42 --> Input Class Initialized
INFO - 2020-04-04 11:27:42 --> Input Class Initialized
INFO - 2020-04-04 11:27:42 --> Language Class Initialized
INFO - 2020-04-04 11:27:42 --> Language Class Initialized
ERROR - 2020-04-04 11:27:43 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:27:43 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:27:58 --> Config Class Initialized
INFO - 2020-04-04 11:27:58 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:27:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:27:58 --> Utf8 Class Initialized
INFO - 2020-04-04 11:27:58 --> URI Class Initialized
INFO - 2020-04-04 11:27:58 --> Router Class Initialized
INFO - 2020-04-04 11:27:58 --> Output Class Initialized
INFO - 2020-04-04 11:27:58 --> Security Class Initialized
DEBUG - 2020-04-04 11:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:27:58 --> CSRF cookie sent
INFO - 2020-04-04 11:27:58 --> Input Class Initialized
INFO - 2020-04-04 11:27:58 --> Language Class Initialized
INFO - 2020-04-04 11:27:58 --> Language Class Initialized
INFO - 2020-04-04 11:27:58 --> Config Class Initialized
INFO - 2020-04-04 11:27:58 --> Loader Class Initialized
INFO - 2020-04-04 11:27:58 --> Helper loaded: url_helper
INFO - 2020-04-04 11:27:58 --> Helper loaded: file_helper
INFO - 2020-04-04 11:27:58 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:27:58 --> Helper loaded: common_helper
INFO - 2020-04-04 11:27:58 --> Helper loaded: language_helper
INFO - 2020-04-04 11:27:58 --> Helper loaded: email_helper
INFO - 2020-04-04 11:27:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:27:58 --> Database Driver Class Initialized
INFO - 2020-04-04 11:27:58 --> Parser Class Initialized
INFO - 2020-04-04 11:27:58 --> User Agent Class Initialized
INFO - 2020-04-04 11:27:58 --> Model Class Initialized
INFO - 2020-04-04 11:27:58 --> Model Class Initialized
DEBUG - 2020-04-04 11:27:58 --> Template Class Initialized
INFO - 2020-04-04 11:27:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:27:58 --> Email Class Initialized
INFO - 2020-04-04 11:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:27:58 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:27:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:27:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:27:58 --> Encryption Class Initialized
INFO - 2020-04-04 11:27:58 --> Controller Class Initialized
DEBUG - 2020-04-04 11:27:58 --> post MX_Controller Initialized
INFO - 2020-04-04 11:27:58 --> Model Class Initialized
ERROR - 2020-04-04 11:27:58 --> Could not find the language line ""
ERROR - 2020-04-04 11:27:58 --> Could not find the language line ""
ERROR - 2020-04-04 11:27:58 --> Could not find the language line ""
DEBUG - 2020-04-04 11:27:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:27:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:27:58 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:27:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:27:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:27:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:27:58 --> Final output sent to browser
DEBUG - 2020-04-04 11:27:58 --> Total execution time: 0.7260
INFO - 2020-04-04 11:27:59 --> Config Class Initialized
INFO - 2020-04-04 11:27:59 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:27:59 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:27:59 --> Utf8 Class Initialized
INFO - 2020-04-04 11:27:59 --> URI Class Initialized
INFO - 2020-04-04 11:27:59 --> Router Class Initialized
INFO - 2020-04-04 11:27:59 --> Output Class Initialized
INFO - 2020-04-04 11:27:59 --> Security Class Initialized
DEBUG - 2020-04-04 11:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:27:59 --> CSRF cookie sent
INFO - 2020-04-04 11:27:59 --> Input Class Initialized
INFO - 2020-04-04 11:27:59 --> Language Class Initialized
ERROR - 2020-04-04 11:27:59 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:27:59 --> Config Class Initialized
INFO - 2020-04-04 11:27:59 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:27:59 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:27:59 --> Utf8 Class Initialized
INFO - 2020-04-04 11:27:59 --> URI Class Initialized
INFO - 2020-04-04 11:27:59 --> Router Class Initialized
INFO - 2020-04-04 11:27:59 --> Output Class Initialized
INFO - 2020-04-04 11:27:59 --> Security Class Initialized
DEBUG - 2020-04-04 11:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:27:59 --> CSRF cookie sent
INFO - 2020-04-04 11:27:59 --> Input Class Initialized
INFO - 2020-04-04 11:27:59 --> Language Class Initialized
ERROR - 2020-04-04 11:27:59 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:30:45 --> Config Class Initialized
INFO - 2020-04-04 11:30:45 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:30:45 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:30:45 --> Utf8 Class Initialized
INFO - 2020-04-04 11:30:45 --> URI Class Initialized
INFO - 2020-04-04 11:30:45 --> Router Class Initialized
INFO - 2020-04-04 11:30:45 --> Output Class Initialized
INFO - 2020-04-04 11:30:45 --> Security Class Initialized
DEBUG - 2020-04-04 11:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:30:45 --> CSRF cookie sent
INFO - 2020-04-04 11:30:45 --> Input Class Initialized
INFO - 2020-04-04 11:30:45 --> Language Class Initialized
INFO - 2020-04-04 11:30:45 --> Language Class Initialized
INFO - 2020-04-04 11:30:45 --> Config Class Initialized
INFO - 2020-04-04 11:30:45 --> Loader Class Initialized
INFO - 2020-04-04 11:30:45 --> Helper loaded: url_helper
INFO - 2020-04-04 11:30:45 --> Helper loaded: file_helper
INFO - 2020-04-04 11:30:45 --> Helper loaded: cookie_helper
INFO - 2020-04-04 11:30:45 --> Helper loaded: common_helper
INFO - 2020-04-04 11:30:45 --> Helper loaded: language_helper
INFO - 2020-04-04 11:30:45 --> Helper loaded: email_helper
INFO - 2020-04-04 11:30:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 11:30:45 --> Database Driver Class Initialized
INFO - 2020-04-04 11:30:45 --> Parser Class Initialized
INFO - 2020-04-04 11:30:45 --> User Agent Class Initialized
INFO - 2020-04-04 11:30:45 --> Model Class Initialized
INFO - 2020-04-04 11:30:45 --> Model Class Initialized
DEBUG - 2020-04-04 11:30:45 --> Template Class Initialized
INFO - 2020-04-04 11:30:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 11:30:45 --> Email Class Initialized
INFO - 2020-04-04 11:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 11:30:45 --> Pagination Class Initialized
DEBUG - 2020-04-04 11:30:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 11:30:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 11:30:45 --> Encryption Class Initialized
INFO - 2020-04-04 11:30:45 --> Controller Class Initialized
DEBUG - 2020-04-04 11:30:45 --> post MX_Controller Initialized
INFO - 2020-04-04 11:30:45 --> Model Class Initialized
ERROR - 2020-04-04 11:30:45 --> Could not find the language line ""
ERROR - 2020-04-04 11:30:45 --> Could not find the language line ""
ERROR - 2020-04-04 11:30:45 --> Could not find the language line ""
DEBUG - 2020-04-04 11:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 11:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 11:30:45 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 11:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 11:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 11:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 11:30:45 --> Final output sent to browser
DEBUG - 2020-04-04 11:30:45 --> Total execution time: 0.6823
INFO - 2020-04-04 11:30:46 --> Config Class Initialized
INFO - 2020-04-04 11:30:46 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:30:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:30:46 --> Utf8 Class Initialized
INFO - 2020-04-04 11:30:46 --> URI Class Initialized
INFO - 2020-04-04 11:30:46 --> Router Class Initialized
INFO - 2020-04-04 11:30:46 --> Output Class Initialized
INFO - 2020-04-04 11:30:46 --> Security Class Initialized
DEBUG - 2020-04-04 11:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:30:46 --> CSRF cookie sent
INFO - 2020-04-04 11:30:46 --> Input Class Initialized
INFO - 2020-04-04 11:30:46 --> Language Class Initialized
ERROR - 2020-04-04 11:30:46 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:30:46 --> Config Class Initialized
INFO - 2020-04-04 11:30:46 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:30:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:30:46 --> Utf8 Class Initialized
INFO - 2020-04-04 11:30:46 --> URI Class Initialized
INFO - 2020-04-04 11:30:46 --> Router Class Initialized
INFO - 2020-04-04 11:30:46 --> Output Class Initialized
INFO - 2020-04-04 11:30:46 --> Security Class Initialized
DEBUG - 2020-04-04 11:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:30:46 --> CSRF cookie sent
INFO - 2020-04-04 11:30:46 --> Input Class Initialized
INFO - 2020-04-04 11:30:46 --> Language Class Initialized
ERROR - 2020-04-04 11:30:46 --> 404 Page Not Found: /index
INFO - 2020-04-04 11:30:57 --> Config Class Initialized
INFO - 2020-04-04 11:30:57 --> Config Class Initialized
INFO - 2020-04-04 11:30:57 --> Hooks Class Initialized
INFO - 2020-04-04 11:30:57 --> Hooks Class Initialized
DEBUG - 2020-04-04 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 11:30:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 11:30:58 --> Utf8 Class Initialized
INFO - 2020-04-04 11:30:58 --> Utf8 Class Initialized
INFO - 2020-04-04 11:30:58 --> URI Class Initialized
INFO - 2020-04-04 11:30:58 --> URI Class Initialized
INFO - 2020-04-04 11:30:58 --> Router Class Initialized
INFO - 2020-04-04 11:30:58 --> Router Class Initialized
INFO - 2020-04-04 11:30:58 --> Output Class Initialized
INFO - 2020-04-04 11:30:58 --> Output Class Initialized
INFO - 2020-04-04 11:30:58 --> Security Class Initialized
INFO - 2020-04-04 11:30:58 --> Security Class Initialized
DEBUG - 2020-04-04 11:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 11:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 11:30:58 --> CSRF cookie sent
INFO - 2020-04-04 11:30:58 --> CSRF cookie sent
INFO - 2020-04-04 11:30:58 --> Input Class Initialized
INFO - 2020-04-04 11:30:58 --> Input Class Initialized
INFO - 2020-04-04 11:30:58 --> Language Class Initialized
INFO - 2020-04-04 11:30:58 --> Language Class Initialized
ERROR - 2020-04-04 11:30:58 --> 404 Page Not Found: /index
ERROR - 2020-04-04 11:30:58 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:39:08 --> Config Class Initialized
INFO - 2020-04-04 15:39:08 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:39:08 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:39:08 --> Utf8 Class Initialized
INFO - 2020-04-04 15:39:08 --> URI Class Initialized
DEBUG - 2020-04-04 15:39:09 --> No URI present. Default controller set.
INFO - 2020-04-04 15:39:09 --> Router Class Initialized
INFO - 2020-04-04 15:39:09 --> Output Class Initialized
INFO - 2020-04-04 15:39:09 --> Security Class Initialized
DEBUG - 2020-04-04 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:39:09 --> CSRF cookie sent
INFO - 2020-04-04 15:39:09 --> Input Class Initialized
INFO - 2020-04-04 15:39:09 --> Language Class Initialized
INFO - 2020-04-04 15:39:09 --> Language Class Initialized
INFO - 2020-04-04 15:39:09 --> Config Class Initialized
INFO - 2020-04-04 15:39:09 --> Loader Class Initialized
INFO - 2020-04-04 15:39:09 --> Helper loaded: url_helper
INFO - 2020-04-04 15:39:09 --> Helper loaded: file_helper
INFO - 2020-04-04 15:39:09 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:39:09 --> Helper loaded: common_helper
INFO - 2020-04-04 15:39:09 --> Helper loaded: language_helper
INFO - 2020-04-04 15:39:09 --> Helper loaded: email_helper
INFO - 2020-04-04 15:39:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:39:09 --> Database Driver Class Initialized
INFO - 2020-04-04 15:39:09 --> Parser Class Initialized
INFO - 2020-04-04 15:39:09 --> User Agent Class Initialized
INFO - 2020-04-04 15:39:09 --> Model Class Initialized
INFO - 2020-04-04 15:39:09 --> Model Class Initialized
DEBUG - 2020-04-04 15:39:09 --> Template Class Initialized
INFO - 2020-04-04 15:39:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:39:09 --> Email Class Initialized
INFO - 2020-04-04 15:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:39:09 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:39:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:39:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:39:10 --> Encryption Class Initialized
INFO - 2020-04-04 15:39:10 --> Controller Class Initialized
DEBUG - 2020-04-04 15:39:10 --> home MX_Controller Initialized
INFO - 2020-04-04 15:39:10 --> Model Class Initialized
INFO - 2020-04-04 15:39:10 --> Config Class Initialized
INFO - 2020-04-04 15:39:10 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:39:10 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:39:10 --> Utf8 Class Initialized
INFO - 2020-04-04 15:39:10 --> URI Class Initialized
INFO - 2020-04-04 15:39:10 --> Router Class Initialized
INFO - 2020-04-04 15:39:10 --> Output Class Initialized
INFO - 2020-04-04 15:39:10 --> Security Class Initialized
DEBUG - 2020-04-04 15:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:39:10 --> CSRF cookie sent
INFO - 2020-04-04 15:39:10 --> Input Class Initialized
INFO - 2020-04-04 15:39:10 --> Language Class Initialized
INFO - 2020-04-04 15:39:10 --> Language Class Initialized
INFO - 2020-04-04 15:39:10 --> Config Class Initialized
INFO - 2020-04-04 15:39:10 --> Loader Class Initialized
INFO - 2020-04-04 15:39:10 --> Helper loaded: url_helper
INFO - 2020-04-04 15:39:10 --> Helper loaded: file_helper
INFO - 2020-04-04 15:39:10 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:39:10 --> Helper loaded: common_helper
INFO - 2020-04-04 15:39:10 --> Helper loaded: language_helper
INFO - 2020-04-04 15:39:10 --> Helper loaded: email_helper
INFO - 2020-04-04 15:39:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:39:10 --> Database Driver Class Initialized
INFO - 2020-04-04 15:39:10 --> Parser Class Initialized
INFO - 2020-04-04 15:39:10 --> User Agent Class Initialized
INFO - 2020-04-04 15:39:10 --> Model Class Initialized
INFO - 2020-04-04 15:39:10 --> Model Class Initialized
DEBUG - 2020-04-04 15:39:10 --> Template Class Initialized
INFO - 2020-04-04 15:39:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:39:10 --> Email Class Initialized
INFO - 2020-04-04 15:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:39:10 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:39:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:39:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:39:10 --> Encryption Class Initialized
INFO - 2020-04-04 15:39:10 --> Controller Class Initialized
DEBUG - 2020-04-04 15:39:10 --> twitter MX_Controller Initialized
INFO - 2020-04-04 15:39:10 --> Model Class Initialized
DEBUG - 2020-04-04 15:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-04 15:39:10 --> Model Class Initialized
DEBUG - 2020-04-04 15:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-04 15:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:39:10 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:39:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:39:10 --> Final output sent to browser
DEBUG - 2020-04-04 15:39:11 --> Total execution time: 0.8274
INFO - 2020-04-04 15:39:16 --> Config Class Initialized
INFO - 2020-04-04 15:39:16 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:39:16 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:39:16 --> Utf8 Class Initialized
INFO - 2020-04-04 15:39:16 --> URI Class Initialized
INFO - 2020-04-04 15:39:16 --> Router Class Initialized
INFO - 2020-04-04 15:39:16 --> Output Class Initialized
INFO - 2020-04-04 15:39:16 --> Security Class Initialized
DEBUG - 2020-04-04 15:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:39:16 --> CSRF cookie sent
INFO - 2020-04-04 15:39:16 --> Input Class Initialized
INFO - 2020-04-04 15:39:16 --> Language Class Initialized
INFO - 2020-04-04 15:39:16 --> Language Class Initialized
INFO - 2020-04-04 15:39:16 --> Config Class Initialized
INFO - 2020-04-04 15:39:16 --> Loader Class Initialized
INFO - 2020-04-04 15:39:16 --> Helper loaded: url_helper
INFO - 2020-04-04 15:39:16 --> Helper loaded: file_helper
INFO - 2020-04-04 15:39:16 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:39:17 --> Helper loaded: common_helper
INFO - 2020-04-04 15:39:17 --> Helper loaded: language_helper
INFO - 2020-04-04 15:39:17 --> Helper loaded: email_helper
INFO - 2020-04-04 15:39:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:39:17 --> Database Driver Class Initialized
INFO - 2020-04-04 15:39:17 --> Parser Class Initialized
INFO - 2020-04-04 15:39:17 --> User Agent Class Initialized
INFO - 2020-04-04 15:39:17 --> Model Class Initialized
INFO - 2020-04-04 15:39:17 --> Model Class Initialized
DEBUG - 2020-04-04 15:39:17 --> Template Class Initialized
INFO - 2020-04-04 15:39:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:39:17 --> Email Class Initialized
INFO - 2020-04-04 15:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:39:17 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:39:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:39:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:39:17 --> Encryption Class Initialized
INFO - 2020-04-04 15:39:17 --> Controller Class Initialized
DEBUG - 2020-04-04 15:39:17 --> dashboard MX_Controller Initialized
INFO - 2020-04-04 15:39:17 --> Model Class Initialized
DEBUG - 2020-04-04 15:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-04 15:39:17 --> Model Class Initialized
INFO - 2020-04-04 15:39:17 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 15:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-04 15:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-04 15:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:39:17 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:39:17 --> Final output sent to browser
DEBUG - 2020-04-04 15:39:17 --> Total execution time: 0.8657
INFO - 2020-04-04 15:40:05 --> Config Class Initialized
INFO - 2020-04-04 15:40:05 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:40:05 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:40:05 --> Utf8 Class Initialized
INFO - 2020-04-04 15:40:05 --> URI Class Initialized
INFO - 2020-04-04 15:40:05 --> Router Class Initialized
INFO - 2020-04-04 15:40:05 --> Output Class Initialized
INFO - 2020-04-04 15:40:05 --> Security Class Initialized
DEBUG - 2020-04-04 15:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:40:05 --> CSRF cookie sent
INFO - 2020-04-04 15:40:05 --> Input Class Initialized
INFO - 2020-04-04 15:40:05 --> Language Class Initialized
INFO - 2020-04-04 15:40:05 --> Language Class Initialized
INFO - 2020-04-04 15:40:05 --> Config Class Initialized
INFO - 2020-04-04 15:40:05 --> Loader Class Initialized
INFO - 2020-04-04 15:40:05 --> Helper loaded: url_helper
INFO - 2020-04-04 15:40:05 --> Helper loaded: file_helper
INFO - 2020-04-04 15:40:05 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:40:05 --> Helper loaded: common_helper
INFO - 2020-04-04 15:40:05 --> Helper loaded: language_helper
INFO - 2020-04-04 15:40:06 --> Helper loaded: email_helper
INFO - 2020-04-04 15:40:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:40:06 --> Database Driver Class Initialized
INFO - 2020-04-04 15:40:06 --> Parser Class Initialized
INFO - 2020-04-04 15:40:06 --> User Agent Class Initialized
INFO - 2020-04-04 15:40:06 --> Model Class Initialized
INFO - 2020-04-04 15:40:06 --> Model Class Initialized
DEBUG - 2020-04-04 15:40:06 --> Template Class Initialized
INFO - 2020-04-04 15:40:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:40:06 --> Email Class Initialized
INFO - 2020-04-04 15:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:40:06 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:40:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:40:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:40:06 --> Encryption Class Initialized
INFO - 2020-04-04 15:40:06 --> Controller Class Initialized
DEBUG - 2020-04-04 15:40:06 --> post MX_Controller Initialized
INFO - 2020-04-04 15:40:06 --> Model Class Initialized
ERROR - 2020-04-04 15:40:06 --> Could not find the language line ""
ERROR - 2020-04-04 15:40:06 --> Could not find the language line ""
ERROR - 2020-04-04 15:40:06 --> Could not find the language line ""
DEBUG - 2020-04-04 15:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:40:06 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:40:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:40:06 --> Final output sent to browser
DEBUG - 2020-04-04 15:40:06 --> Total execution time: 0.7417
INFO - 2020-04-04 15:41:38 --> Config Class Initialized
INFO - 2020-04-04 15:41:39 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:41:39 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:41:39 --> Utf8 Class Initialized
INFO - 2020-04-04 15:41:39 --> URI Class Initialized
INFO - 2020-04-04 15:41:39 --> Router Class Initialized
INFO - 2020-04-04 15:41:39 --> Output Class Initialized
INFO - 2020-04-04 15:41:39 --> Security Class Initialized
DEBUG - 2020-04-04 15:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:41:39 --> CSRF cookie sent
INFO - 2020-04-04 15:41:39 --> Input Class Initialized
INFO - 2020-04-04 15:41:39 --> Language Class Initialized
INFO - 2020-04-04 15:41:39 --> Language Class Initialized
INFO - 2020-04-04 15:41:39 --> Config Class Initialized
INFO - 2020-04-04 15:41:39 --> Loader Class Initialized
INFO - 2020-04-04 15:41:39 --> Helper loaded: url_helper
INFO - 2020-04-04 15:41:39 --> Helper loaded: file_helper
INFO - 2020-04-04 15:41:39 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:41:39 --> Helper loaded: common_helper
INFO - 2020-04-04 15:41:39 --> Helper loaded: language_helper
INFO - 2020-04-04 15:41:39 --> Helper loaded: email_helper
INFO - 2020-04-04 15:41:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:41:39 --> Database Driver Class Initialized
INFO - 2020-04-04 15:41:39 --> Parser Class Initialized
INFO - 2020-04-04 15:41:39 --> User Agent Class Initialized
INFO - 2020-04-04 15:41:39 --> Model Class Initialized
INFO - 2020-04-04 15:41:39 --> Model Class Initialized
DEBUG - 2020-04-04 15:41:39 --> Template Class Initialized
INFO - 2020-04-04 15:41:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:41:39 --> Email Class Initialized
INFO - 2020-04-04 15:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:41:39 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:41:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:41:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:41:39 --> Encryption Class Initialized
INFO - 2020-04-04 15:41:39 --> Controller Class Initialized
DEBUG - 2020-04-04 15:41:39 --> post MX_Controller Initialized
INFO - 2020-04-04 15:41:39 --> Model Class Initialized
ERROR - 2020-04-04 15:41:39 --> Could not find the language line ""
ERROR - 2020-04-04 15:41:39 --> Could not find the language line ""
ERROR - 2020-04-04 15:41:39 --> Could not find the language line ""
DEBUG - 2020-04-04 15:41:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:41:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:41:39 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:41:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:41:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:41:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:41:39 --> Final output sent to browser
DEBUG - 2020-04-04 15:41:39 --> Total execution time: 0.7253
INFO - 2020-04-04 15:42:04 --> Config Class Initialized
INFO - 2020-04-04 15:42:04 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:42:04 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:42:04 --> Utf8 Class Initialized
INFO - 2020-04-04 15:42:04 --> URI Class Initialized
INFO - 2020-04-04 15:42:04 --> Router Class Initialized
INFO - 2020-04-04 15:42:04 --> Output Class Initialized
INFO - 2020-04-04 15:42:04 --> Security Class Initialized
DEBUG - 2020-04-04 15:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:42:04 --> CSRF cookie sent
INFO - 2020-04-04 15:42:04 --> Input Class Initialized
INFO - 2020-04-04 15:42:04 --> Language Class Initialized
INFO - 2020-04-04 15:42:04 --> Language Class Initialized
INFO - 2020-04-04 15:42:04 --> Config Class Initialized
INFO - 2020-04-04 15:42:04 --> Loader Class Initialized
INFO - 2020-04-04 15:42:05 --> Helper loaded: url_helper
INFO - 2020-04-04 15:42:05 --> Helper loaded: file_helper
INFO - 2020-04-04 15:42:05 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:42:05 --> Helper loaded: common_helper
INFO - 2020-04-04 15:42:05 --> Helper loaded: language_helper
INFO - 2020-04-04 15:42:05 --> Helper loaded: email_helper
INFO - 2020-04-04 15:42:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:42:05 --> Database Driver Class Initialized
INFO - 2020-04-04 15:42:05 --> Parser Class Initialized
INFO - 2020-04-04 15:42:05 --> User Agent Class Initialized
INFO - 2020-04-04 15:42:05 --> Model Class Initialized
INFO - 2020-04-04 15:42:05 --> Model Class Initialized
DEBUG - 2020-04-04 15:42:05 --> Template Class Initialized
INFO - 2020-04-04 15:42:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:42:05 --> Email Class Initialized
INFO - 2020-04-04 15:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:42:05 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:42:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:42:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:42:05 --> Encryption Class Initialized
INFO - 2020-04-04 15:42:05 --> Controller Class Initialized
DEBUG - 2020-04-04 15:42:05 --> post MX_Controller Initialized
INFO - 2020-04-04 15:42:05 --> Model Class Initialized
ERROR - 2020-04-04 15:42:05 --> Could not find the language line ""
ERROR - 2020-04-04 15:42:05 --> Could not find the language line ""
ERROR - 2020-04-04 15:42:05 --> Could not find the language line ""
DEBUG - 2020-04-04 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:42:05 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:42:05 --> Final output sent to browser
DEBUG - 2020-04-04 15:42:05 --> Total execution time: 0.7273
INFO - 2020-04-04 15:45:28 --> Config Class Initialized
INFO - 2020-04-04 15:45:28 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:45:28 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:45:28 --> Utf8 Class Initialized
INFO - 2020-04-04 15:45:28 --> URI Class Initialized
INFO - 2020-04-04 15:45:28 --> Router Class Initialized
INFO - 2020-04-04 15:45:28 --> Output Class Initialized
INFO - 2020-04-04 15:45:28 --> Security Class Initialized
DEBUG - 2020-04-04 15:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:45:29 --> CSRF cookie sent
INFO - 2020-04-04 15:45:29 --> Input Class Initialized
INFO - 2020-04-04 15:45:29 --> Language Class Initialized
INFO - 2020-04-04 15:45:29 --> Language Class Initialized
INFO - 2020-04-04 15:45:29 --> Config Class Initialized
INFO - 2020-04-04 15:45:29 --> Loader Class Initialized
INFO - 2020-04-04 15:45:29 --> Helper loaded: url_helper
INFO - 2020-04-04 15:45:29 --> Helper loaded: file_helper
INFO - 2020-04-04 15:45:29 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:45:29 --> Helper loaded: common_helper
INFO - 2020-04-04 15:45:29 --> Helper loaded: language_helper
INFO - 2020-04-04 15:45:29 --> Helper loaded: email_helper
INFO - 2020-04-04 15:45:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:45:29 --> Database Driver Class Initialized
INFO - 2020-04-04 15:45:29 --> Parser Class Initialized
INFO - 2020-04-04 15:45:29 --> User Agent Class Initialized
INFO - 2020-04-04 15:45:29 --> Model Class Initialized
INFO - 2020-04-04 15:45:29 --> Model Class Initialized
DEBUG - 2020-04-04 15:45:29 --> Template Class Initialized
INFO - 2020-04-04 15:45:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:45:29 --> Email Class Initialized
INFO - 2020-04-04 15:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:45:29 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:45:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:45:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:45:29 --> Encryption Class Initialized
INFO - 2020-04-04 15:45:29 --> Controller Class Initialized
DEBUG - 2020-04-04 15:45:29 --> post MX_Controller Initialized
INFO - 2020-04-04 15:45:29 --> Model Class Initialized
ERROR - 2020-04-04 15:45:29 --> Could not find the language line ""
ERROR - 2020-04-04 15:45:29 --> Could not find the language line ""
ERROR - 2020-04-04 15:45:29 --> Could not find the language line ""
DEBUG - 2020-04-04 15:45:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:45:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:45:29 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:45:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:45:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:45:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:45:29 --> Final output sent to browser
DEBUG - 2020-04-04 15:45:29 --> Total execution time: 0.7656
INFO - 2020-04-04 15:46:20 --> Config Class Initialized
INFO - 2020-04-04 15:46:20 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:46:20 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:46:20 --> Utf8 Class Initialized
INFO - 2020-04-04 15:46:20 --> URI Class Initialized
INFO - 2020-04-04 15:46:20 --> Router Class Initialized
INFO - 2020-04-04 15:46:20 --> Output Class Initialized
INFO - 2020-04-04 15:46:20 --> Security Class Initialized
DEBUG - 2020-04-04 15:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:46:20 --> CSRF cookie sent
INFO - 2020-04-04 15:46:20 --> Input Class Initialized
INFO - 2020-04-04 15:46:20 --> Language Class Initialized
INFO - 2020-04-04 15:46:20 --> Language Class Initialized
INFO - 2020-04-04 15:46:20 --> Config Class Initialized
INFO - 2020-04-04 15:46:20 --> Loader Class Initialized
INFO - 2020-04-04 15:46:20 --> Helper loaded: url_helper
INFO - 2020-04-04 15:46:20 --> Helper loaded: file_helper
INFO - 2020-04-04 15:46:20 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:46:20 --> Helper loaded: common_helper
INFO - 2020-04-04 15:46:20 --> Helper loaded: language_helper
INFO - 2020-04-04 15:46:20 --> Helper loaded: email_helper
INFO - 2020-04-04 15:46:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:46:20 --> Database Driver Class Initialized
INFO - 2020-04-04 15:46:20 --> Parser Class Initialized
INFO - 2020-04-04 15:46:20 --> User Agent Class Initialized
INFO - 2020-04-04 15:46:20 --> Model Class Initialized
INFO - 2020-04-04 15:46:20 --> Model Class Initialized
DEBUG - 2020-04-04 15:46:20 --> Template Class Initialized
INFO - 2020-04-04 15:46:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:46:20 --> Email Class Initialized
INFO - 2020-04-04 15:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:46:20 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:46:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:46:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:46:20 --> Encryption Class Initialized
INFO - 2020-04-04 15:46:21 --> Controller Class Initialized
DEBUG - 2020-04-04 15:46:21 --> post MX_Controller Initialized
INFO - 2020-04-04 15:46:21 --> Model Class Initialized
ERROR - 2020-04-04 15:46:21 --> Could not find the language line ""
ERROR - 2020-04-04 15:46:21 --> Could not find the language line ""
ERROR - 2020-04-04 15:46:21 --> Could not find the language line ""
DEBUG - 2020-04-04 15:46:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:46:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:46:21 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:46:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:46:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:46:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:46:21 --> Final output sent to browser
DEBUG - 2020-04-04 15:46:21 --> Total execution time: 0.7235
INFO - 2020-04-04 15:46:56 --> Config Class Initialized
INFO - 2020-04-04 15:46:56 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:46:56 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:46:56 --> Utf8 Class Initialized
INFO - 2020-04-04 15:46:56 --> URI Class Initialized
INFO - 2020-04-04 15:46:56 --> Router Class Initialized
INFO - 2020-04-04 15:46:56 --> Output Class Initialized
INFO - 2020-04-04 15:46:56 --> Security Class Initialized
DEBUG - 2020-04-04 15:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:46:56 --> CSRF cookie sent
INFO - 2020-04-04 15:46:56 --> Input Class Initialized
INFO - 2020-04-04 15:46:56 --> Language Class Initialized
INFO - 2020-04-04 15:46:56 --> Language Class Initialized
INFO - 2020-04-04 15:46:56 --> Config Class Initialized
INFO - 2020-04-04 15:46:56 --> Loader Class Initialized
INFO - 2020-04-04 15:46:56 --> Helper loaded: url_helper
INFO - 2020-04-04 15:46:56 --> Helper loaded: file_helper
INFO - 2020-04-04 15:46:57 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:46:57 --> Helper loaded: common_helper
INFO - 2020-04-04 15:46:57 --> Helper loaded: language_helper
INFO - 2020-04-04 15:46:57 --> Helper loaded: email_helper
INFO - 2020-04-04 15:46:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:46:57 --> Database Driver Class Initialized
INFO - 2020-04-04 15:46:57 --> Parser Class Initialized
INFO - 2020-04-04 15:46:57 --> User Agent Class Initialized
INFO - 2020-04-04 15:46:57 --> Model Class Initialized
INFO - 2020-04-04 15:46:57 --> Model Class Initialized
DEBUG - 2020-04-04 15:46:57 --> Template Class Initialized
INFO - 2020-04-04 15:46:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:46:57 --> Email Class Initialized
INFO - 2020-04-04 15:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:46:57 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:46:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:46:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:46:57 --> Encryption Class Initialized
INFO - 2020-04-04 15:46:57 --> Controller Class Initialized
DEBUG - 2020-04-04 15:46:57 --> post MX_Controller Initialized
INFO - 2020-04-04 15:46:57 --> Model Class Initialized
ERROR - 2020-04-04 15:46:57 --> Could not find the language line ""
ERROR - 2020-04-04 15:46:57 --> Could not find the language line ""
ERROR - 2020-04-04 15:46:57 --> Could not find the language line ""
DEBUG - 2020-04-04 15:46:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:46:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:46:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:46:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:46:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:46:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:46:57 --> Final output sent to browser
DEBUG - 2020-04-04 15:46:57 --> Total execution time: 0.7771
INFO - 2020-04-04 15:47:54 --> Config Class Initialized
INFO - 2020-04-04 15:47:54 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:47:54 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:47:54 --> Utf8 Class Initialized
INFO - 2020-04-04 15:47:54 --> URI Class Initialized
INFO - 2020-04-04 15:47:54 --> Router Class Initialized
INFO - 2020-04-04 15:47:54 --> Output Class Initialized
INFO - 2020-04-04 15:47:54 --> Security Class Initialized
DEBUG - 2020-04-04 15:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:47:54 --> CSRF cookie sent
INFO - 2020-04-04 15:47:54 --> Input Class Initialized
INFO - 2020-04-04 15:47:54 --> Language Class Initialized
INFO - 2020-04-04 15:47:54 --> Language Class Initialized
INFO - 2020-04-04 15:47:54 --> Config Class Initialized
INFO - 2020-04-04 15:47:54 --> Loader Class Initialized
INFO - 2020-04-04 15:47:54 --> Helper loaded: url_helper
INFO - 2020-04-04 15:47:54 --> Helper loaded: file_helper
INFO - 2020-04-04 15:47:54 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:47:54 --> Helper loaded: common_helper
INFO - 2020-04-04 15:47:54 --> Helper loaded: language_helper
INFO - 2020-04-04 15:47:54 --> Helper loaded: email_helper
INFO - 2020-04-04 15:47:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:47:54 --> Database Driver Class Initialized
INFO - 2020-04-04 15:47:54 --> Parser Class Initialized
INFO - 2020-04-04 15:47:54 --> User Agent Class Initialized
INFO - 2020-04-04 15:47:54 --> Model Class Initialized
INFO - 2020-04-04 15:47:54 --> Model Class Initialized
DEBUG - 2020-04-04 15:47:54 --> Template Class Initialized
INFO - 2020-04-04 15:47:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:47:54 --> Email Class Initialized
INFO - 2020-04-04 15:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:47:54 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:47:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:47:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:47:54 --> Encryption Class Initialized
INFO - 2020-04-04 15:47:54 --> Controller Class Initialized
DEBUG - 2020-04-04 15:47:54 --> post MX_Controller Initialized
INFO - 2020-04-04 15:47:54 --> Model Class Initialized
ERROR - 2020-04-04 15:47:55 --> Could not find the language line ""
ERROR - 2020-04-04 15:47:55 --> Could not find the language line ""
ERROR - 2020-04-04 15:47:55 --> Could not find the language line ""
DEBUG - 2020-04-04 15:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:47:55 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:47:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:47:55 --> Final output sent to browser
DEBUG - 2020-04-04 15:47:55 --> Total execution time: 0.7300
INFO - 2020-04-04 15:48:36 --> Config Class Initialized
INFO - 2020-04-04 15:48:36 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:48:36 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:48:36 --> Utf8 Class Initialized
INFO - 2020-04-04 15:48:36 --> URI Class Initialized
INFO - 2020-04-04 15:48:36 --> Router Class Initialized
INFO - 2020-04-04 15:48:36 --> Output Class Initialized
INFO - 2020-04-04 15:48:36 --> Security Class Initialized
DEBUG - 2020-04-04 15:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:48:36 --> CSRF cookie sent
INFO - 2020-04-04 15:48:36 --> Input Class Initialized
INFO - 2020-04-04 15:48:36 --> Language Class Initialized
INFO - 2020-04-04 15:48:36 --> Language Class Initialized
INFO - 2020-04-04 15:48:36 --> Config Class Initialized
INFO - 2020-04-04 15:48:36 --> Loader Class Initialized
INFO - 2020-04-04 15:48:36 --> Helper loaded: url_helper
INFO - 2020-04-04 15:48:36 --> Helper loaded: file_helper
INFO - 2020-04-04 15:48:36 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:48:36 --> Helper loaded: common_helper
INFO - 2020-04-04 15:48:36 --> Helper loaded: language_helper
INFO - 2020-04-04 15:48:36 --> Helper loaded: email_helper
INFO - 2020-04-04 15:48:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:48:36 --> Database Driver Class Initialized
INFO - 2020-04-04 15:48:36 --> Parser Class Initialized
INFO - 2020-04-04 15:48:36 --> User Agent Class Initialized
INFO - 2020-04-04 15:48:36 --> Model Class Initialized
INFO - 2020-04-04 15:48:36 --> Model Class Initialized
DEBUG - 2020-04-04 15:48:36 --> Template Class Initialized
INFO - 2020-04-04 15:48:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:48:36 --> Email Class Initialized
INFO - 2020-04-04 15:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:48:36 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:48:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:48:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:48:37 --> Encryption Class Initialized
INFO - 2020-04-04 15:48:37 --> Controller Class Initialized
DEBUG - 2020-04-04 15:48:37 --> post MX_Controller Initialized
INFO - 2020-04-04 15:48:37 --> Model Class Initialized
ERROR - 2020-04-04 15:48:37 --> Could not find the language line ""
ERROR - 2020-04-04 15:48:37 --> Could not find the language line ""
ERROR - 2020-04-04 15:48:37 --> Could not find the language line ""
DEBUG - 2020-04-04 15:48:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:48:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:48:37 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:48:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:48:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:48:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:48:37 --> Final output sent to browser
DEBUG - 2020-04-04 15:48:37 --> Total execution time: 0.7625
INFO - 2020-04-04 15:49:26 --> Config Class Initialized
INFO - 2020-04-04 15:49:26 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:49:26 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:49:26 --> Utf8 Class Initialized
INFO - 2020-04-04 15:49:26 --> URI Class Initialized
INFO - 2020-04-04 15:49:26 --> Router Class Initialized
INFO - 2020-04-04 15:49:26 --> Output Class Initialized
INFO - 2020-04-04 15:49:26 --> Security Class Initialized
DEBUG - 2020-04-04 15:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:49:26 --> CSRF cookie sent
INFO - 2020-04-04 15:49:26 --> Input Class Initialized
INFO - 2020-04-04 15:49:26 --> Language Class Initialized
INFO - 2020-04-04 15:49:26 --> Language Class Initialized
INFO - 2020-04-04 15:49:26 --> Config Class Initialized
INFO - 2020-04-04 15:49:26 --> Loader Class Initialized
INFO - 2020-04-04 15:49:26 --> Helper loaded: url_helper
INFO - 2020-04-04 15:49:26 --> Helper loaded: file_helper
INFO - 2020-04-04 15:49:26 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:49:26 --> Helper loaded: common_helper
INFO - 2020-04-04 15:49:26 --> Helper loaded: language_helper
INFO - 2020-04-04 15:49:26 --> Helper loaded: email_helper
INFO - 2020-04-04 15:49:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:49:26 --> Database Driver Class Initialized
INFO - 2020-04-04 15:49:26 --> Parser Class Initialized
INFO - 2020-04-04 15:49:26 --> User Agent Class Initialized
INFO - 2020-04-04 15:49:26 --> Model Class Initialized
INFO - 2020-04-04 15:49:26 --> Model Class Initialized
DEBUG - 2020-04-04 15:49:26 --> Template Class Initialized
INFO - 2020-04-04 15:49:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:49:26 --> Email Class Initialized
INFO - 2020-04-04 15:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:49:26 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:49:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:49:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:49:26 --> Encryption Class Initialized
INFO - 2020-04-04 15:49:26 --> Controller Class Initialized
DEBUG - 2020-04-04 15:49:26 --> post MX_Controller Initialized
INFO - 2020-04-04 15:49:26 --> Model Class Initialized
ERROR - 2020-04-04 15:49:26 --> Could not find the language line ""
ERROR - 2020-04-04 15:49:26 --> Could not find the language line ""
ERROR - 2020-04-04 15:49:26 --> Could not find the language line ""
DEBUG - 2020-04-04 15:49:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:49:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:49:26 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:49:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:49:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:49:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:49:27 --> Final output sent to browser
DEBUG - 2020-04-04 15:49:27 --> Total execution time: 0.7947
INFO - 2020-04-04 15:49:36 --> Config Class Initialized
INFO - 2020-04-04 15:49:36 --> Config Class Initialized
INFO - 2020-04-04 15:49:36 --> Hooks Class Initialized
INFO - 2020-04-04 15:49:36 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 15:49:36 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:49:36 --> Utf8 Class Initialized
INFO - 2020-04-04 15:49:36 --> Utf8 Class Initialized
INFO - 2020-04-04 15:49:36 --> URI Class Initialized
INFO - 2020-04-04 15:49:36 --> URI Class Initialized
INFO - 2020-04-04 15:49:36 --> Router Class Initialized
INFO - 2020-04-04 15:49:36 --> Router Class Initialized
INFO - 2020-04-04 15:49:36 --> Output Class Initialized
INFO - 2020-04-04 15:49:36 --> Output Class Initialized
INFO - 2020-04-04 15:49:36 --> Security Class Initialized
INFO - 2020-04-04 15:49:36 --> Security Class Initialized
DEBUG - 2020-04-04 15:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 15:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:49:36 --> CSRF cookie sent
INFO - 2020-04-04 15:49:36 --> CSRF cookie sent
INFO - 2020-04-04 15:49:36 --> Input Class Initialized
INFO - 2020-04-04 15:49:36 --> Input Class Initialized
INFO - 2020-04-04 15:49:36 --> Language Class Initialized
INFO - 2020-04-04 15:49:36 --> Language Class Initialized
ERROR - 2020-04-04 15:49:36 --> 404 Page Not Found: /index
ERROR - 2020-04-04 15:49:36 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:52:31 --> Config Class Initialized
INFO - 2020-04-04 15:52:31 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:52:31 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:52:31 --> Utf8 Class Initialized
INFO - 2020-04-04 15:52:31 --> URI Class Initialized
INFO - 2020-04-04 15:52:31 --> Router Class Initialized
INFO - 2020-04-04 15:52:31 --> Output Class Initialized
INFO - 2020-04-04 15:52:31 --> Security Class Initialized
DEBUG - 2020-04-04 15:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:52:31 --> CSRF cookie sent
INFO - 2020-04-04 15:52:31 --> Input Class Initialized
INFO - 2020-04-04 15:52:31 --> Language Class Initialized
INFO - 2020-04-04 15:52:31 --> Language Class Initialized
INFO - 2020-04-04 15:52:31 --> Config Class Initialized
INFO - 2020-04-04 15:52:31 --> Loader Class Initialized
INFO - 2020-04-04 15:52:31 --> Helper loaded: url_helper
INFO - 2020-04-04 15:52:31 --> Helper loaded: file_helper
INFO - 2020-04-04 15:52:31 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:52:31 --> Helper loaded: common_helper
INFO - 2020-04-04 15:52:31 --> Helper loaded: language_helper
INFO - 2020-04-04 15:52:31 --> Helper loaded: email_helper
INFO - 2020-04-04 15:52:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:52:31 --> Database Driver Class Initialized
INFO - 2020-04-04 15:52:31 --> Parser Class Initialized
INFO - 2020-04-04 15:52:31 --> User Agent Class Initialized
INFO - 2020-04-04 15:52:31 --> Model Class Initialized
INFO - 2020-04-04 15:52:31 --> Model Class Initialized
DEBUG - 2020-04-04 15:52:31 --> Template Class Initialized
INFO - 2020-04-04 15:52:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:52:31 --> Email Class Initialized
INFO - 2020-04-04 15:52:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:52:31 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:52:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:52:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:52:31 --> Encryption Class Initialized
INFO - 2020-04-04 15:52:31 --> Controller Class Initialized
DEBUG - 2020-04-04 15:52:31 --> post MX_Controller Initialized
INFO - 2020-04-04 15:52:31 --> Model Class Initialized
ERROR - 2020-04-04 15:52:31 --> Could not find the language line ""
ERROR - 2020-04-04 15:52:31 --> Could not find the language line ""
ERROR - 2020-04-04 15:52:31 --> Could not find the language line ""
DEBUG - 2020-04-04 15:52:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:52:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:52:31 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:52:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:52:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:52:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:52:32 --> Final output sent to browser
DEBUG - 2020-04-04 15:52:32 --> Total execution time: 0.9949
INFO - 2020-04-04 15:52:32 --> Config Class Initialized
INFO - 2020-04-04 15:52:32 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:52:32 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:52:32 --> Utf8 Class Initialized
INFO - 2020-04-04 15:52:32 --> URI Class Initialized
INFO - 2020-04-04 15:52:32 --> Router Class Initialized
INFO - 2020-04-04 15:52:32 --> Output Class Initialized
INFO - 2020-04-04 15:52:32 --> Security Class Initialized
DEBUG - 2020-04-04 15:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:52:32 --> Config Class Initialized
INFO - 2020-04-04 15:52:32 --> CSRF cookie sent
INFO - 2020-04-04 15:52:32 --> Hooks Class Initialized
INFO - 2020-04-04 15:52:32 --> Input Class Initialized
DEBUG - 2020-04-04 15:52:32 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:52:32 --> Utf8 Class Initialized
INFO - 2020-04-04 15:52:32 --> Language Class Initialized
INFO - 2020-04-04 15:52:32 --> URI Class Initialized
ERROR - 2020-04-04 15:52:32 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:52:32 --> Router Class Initialized
INFO - 2020-04-04 15:52:32 --> Output Class Initialized
INFO - 2020-04-04 15:52:32 --> Security Class Initialized
DEBUG - 2020-04-04 15:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:52:32 --> CSRF cookie sent
INFO - 2020-04-04 15:52:32 --> Input Class Initialized
INFO - 2020-04-04 15:52:32 --> Language Class Initialized
ERROR - 2020-04-04 15:52:32 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:54:36 --> Config Class Initialized
INFO - 2020-04-04 15:54:36 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:54:36 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:54:36 --> Utf8 Class Initialized
INFO - 2020-04-04 15:54:36 --> URI Class Initialized
INFO - 2020-04-04 15:54:36 --> Router Class Initialized
INFO - 2020-04-04 15:54:36 --> Output Class Initialized
INFO - 2020-04-04 15:54:36 --> Security Class Initialized
DEBUG - 2020-04-04 15:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:54:36 --> CSRF cookie sent
INFO - 2020-04-04 15:54:36 --> Input Class Initialized
INFO - 2020-04-04 15:54:36 --> Language Class Initialized
INFO - 2020-04-04 15:54:36 --> Language Class Initialized
INFO - 2020-04-04 15:54:36 --> Config Class Initialized
INFO - 2020-04-04 15:54:36 --> Loader Class Initialized
INFO - 2020-04-04 15:54:36 --> Helper loaded: url_helper
INFO - 2020-04-04 15:54:36 --> Helper loaded: file_helper
INFO - 2020-04-04 15:54:36 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:54:36 --> Helper loaded: common_helper
INFO - 2020-04-04 15:54:36 --> Helper loaded: language_helper
INFO - 2020-04-04 15:54:36 --> Helper loaded: email_helper
INFO - 2020-04-04 15:54:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:54:36 --> Database Driver Class Initialized
INFO - 2020-04-04 15:54:36 --> Parser Class Initialized
INFO - 2020-04-04 15:54:36 --> User Agent Class Initialized
INFO - 2020-04-04 15:54:36 --> Model Class Initialized
INFO - 2020-04-04 15:54:36 --> Model Class Initialized
DEBUG - 2020-04-04 15:54:36 --> Template Class Initialized
INFO - 2020-04-04 15:54:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:54:36 --> Email Class Initialized
INFO - 2020-04-04 15:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:54:36 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:54:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:54:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:54:36 --> Encryption Class Initialized
INFO - 2020-04-04 15:54:36 --> Controller Class Initialized
DEBUG - 2020-04-04 15:54:36 --> post MX_Controller Initialized
INFO - 2020-04-04 15:54:36 --> Model Class Initialized
ERROR - 2020-04-04 15:54:36 --> Could not find the language line ""
ERROR - 2020-04-04 15:54:36 --> Could not find the language line ""
ERROR - 2020-04-04 15:54:36 --> Could not find the language line ""
DEBUG - 2020-04-04 15:54:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:54:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:54:36 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:54:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:54:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:54:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:54:36 --> Final output sent to browser
DEBUG - 2020-04-04 15:54:36 --> Total execution time: 0.8153
INFO - 2020-04-04 15:54:57 --> Config Class Initialized
INFO - 2020-04-04 15:54:57 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:54:57 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:54:57 --> Utf8 Class Initialized
INFO - 2020-04-04 15:54:57 --> URI Class Initialized
INFO - 2020-04-04 15:54:57 --> Router Class Initialized
INFO - 2020-04-04 15:54:58 --> Output Class Initialized
INFO - 2020-04-04 15:54:58 --> Security Class Initialized
DEBUG - 2020-04-04 15:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:54:58 --> CSRF cookie sent
INFO - 2020-04-04 15:54:58 --> Input Class Initialized
INFO - 2020-04-04 15:54:58 --> Language Class Initialized
INFO - 2020-04-04 15:54:58 --> Language Class Initialized
INFO - 2020-04-04 15:54:58 --> Config Class Initialized
INFO - 2020-04-04 15:54:58 --> Loader Class Initialized
INFO - 2020-04-04 15:54:58 --> Helper loaded: url_helper
INFO - 2020-04-04 15:54:58 --> Helper loaded: file_helper
INFO - 2020-04-04 15:54:58 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:54:58 --> Helper loaded: common_helper
INFO - 2020-04-04 15:54:58 --> Helper loaded: language_helper
INFO - 2020-04-04 15:54:58 --> Helper loaded: email_helper
INFO - 2020-04-04 15:54:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:54:58 --> Database Driver Class Initialized
INFO - 2020-04-04 15:54:58 --> Parser Class Initialized
INFO - 2020-04-04 15:54:58 --> User Agent Class Initialized
INFO - 2020-04-04 15:54:58 --> Model Class Initialized
INFO - 2020-04-04 15:54:58 --> Model Class Initialized
DEBUG - 2020-04-04 15:54:58 --> Template Class Initialized
INFO - 2020-04-04 15:54:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:54:58 --> Email Class Initialized
INFO - 2020-04-04 15:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:54:58 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:54:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:54:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:54:58 --> Encryption Class Initialized
INFO - 2020-04-04 15:54:58 --> Controller Class Initialized
DEBUG - 2020-04-04 15:54:58 --> post MX_Controller Initialized
INFO - 2020-04-04 15:54:58 --> Model Class Initialized
ERROR - 2020-04-04 15:54:58 --> Could not find the language line ""
ERROR - 2020-04-04 15:54:58 --> Could not find the language line ""
ERROR - 2020-04-04 15:54:58 --> Could not find the language line ""
DEBUG - 2020-04-04 15:54:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:54:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:54:58 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:54:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:54:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:54:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:54:58 --> Final output sent to browser
DEBUG - 2020-04-04 15:54:58 --> Total execution time: 0.7448
INFO - 2020-04-04 15:55:30 --> Config Class Initialized
INFO - 2020-04-04 15:55:30 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:55:30 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:55:30 --> Utf8 Class Initialized
INFO - 2020-04-04 15:55:30 --> URI Class Initialized
INFO - 2020-04-04 15:55:30 --> Router Class Initialized
INFO - 2020-04-04 15:55:30 --> Output Class Initialized
INFO - 2020-04-04 15:55:30 --> Security Class Initialized
DEBUG - 2020-04-04 15:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:55:30 --> CSRF cookie sent
INFO - 2020-04-04 15:55:30 --> Input Class Initialized
INFO - 2020-04-04 15:55:30 --> Language Class Initialized
INFO - 2020-04-04 15:55:30 --> Language Class Initialized
INFO - 2020-04-04 15:55:30 --> Config Class Initialized
INFO - 2020-04-04 15:55:30 --> Loader Class Initialized
INFO - 2020-04-04 15:55:30 --> Helper loaded: url_helper
INFO - 2020-04-04 15:55:30 --> Helper loaded: file_helper
INFO - 2020-04-04 15:55:30 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:55:30 --> Helper loaded: common_helper
INFO - 2020-04-04 15:55:30 --> Helper loaded: language_helper
INFO - 2020-04-04 15:55:30 --> Helper loaded: email_helper
INFO - 2020-04-04 15:55:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:55:31 --> Database Driver Class Initialized
INFO - 2020-04-04 15:55:31 --> Parser Class Initialized
INFO - 2020-04-04 15:55:31 --> User Agent Class Initialized
INFO - 2020-04-04 15:55:31 --> Model Class Initialized
INFO - 2020-04-04 15:55:31 --> Model Class Initialized
DEBUG - 2020-04-04 15:55:31 --> Template Class Initialized
INFO - 2020-04-04 15:55:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:55:31 --> Email Class Initialized
INFO - 2020-04-04 15:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:55:31 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:55:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:55:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:55:31 --> Encryption Class Initialized
INFO - 2020-04-04 15:55:31 --> Controller Class Initialized
DEBUG - 2020-04-04 15:55:31 --> post MX_Controller Initialized
INFO - 2020-04-04 15:55:31 --> Model Class Initialized
ERROR - 2020-04-04 15:55:31 --> Could not find the language line ""
ERROR - 2020-04-04 15:55:31 --> Could not find the language line ""
ERROR - 2020-04-04 15:55:31 --> Could not find the language line ""
DEBUG - 2020-04-04 15:55:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:55:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:55:31 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:55:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:55:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:55:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:55:31 --> Final output sent to browser
DEBUG - 2020-04-04 15:55:31 --> Total execution time: 0.7441
INFO - 2020-04-04 15:56:05 --> Config Class Initialized
INFO - 2020-04-04 15:56:05 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:56:05 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:56:05 --> Utf8 Class Initialized
INFO - 2020-04-04 15:56:05 --> URI Class Initialized
INFO - 2020-04-04 15:56:05 --> Router Class Initialized
INFO - 2020-04-04 15:56:05 --> Output Class Initialized
INFO - 2020-04-04 15:56:05 --> Security Class Initialized
DEBUG - 2020-04-04 15:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:56:05 --> CSRF cookie sent
INFO - 2020-04-04 15:56:05 --> Input Class Initialized
INFO - 2020-04-04 15:56:05 --> Language Class Initialized
INFO - 2020-04-04 15:56:06 --> Language Class Initialized
INFO - 2020-04-04 15:56:06 --> Config Class Initialized
INFO - 2020-04-04 15:56:06 --> Loader Class Initialized
INFO - 2020-04-04 15:56:06 --> Helper loaded: url_helper
INFO - 2020-04-04 15:56:06 --> Helper loaded: file_helper
INFO - 2020-04-04 15:56:06 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:56:06 --> Helper loaded: common_helper
INFO - 2020-04-04 15:56:06 --> Helper loaded: language_helper
INFO - 2020-04-04 15:56:06 --> Helper loaded: email_helper
INFO - 2020-04-04 15:56:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:56:06 --> Database Driver Class Initialized
INFO - 2020-04-04 15:56:06 --> Parser Class Initialized
INFO - 2020-04-04 15:56:06 --> User Agent Class Initialized
INFO - 2020-04-04 15:56:06 --> Model Class Initialized
INFO - 2020-04-04 15:56:06 --> Model Class Initialized
DEBUG - 2020-04-04 15:56:06 --> Template Class Initialized
INFO - 2020-04-04 15:56:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:56:06 --> Email Class Initialized
INFO - 2020-04-04 15:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:56:06 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:56:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:56:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:56:06 --> Encryption Class Initialized
INFO - 2020-04-04 15:56:06 --> Controller Class Initialized
DEBUG - 2020-04-04 15:56:06 --> post MX_Controller Initialized
INFO - 2020-04-04 15:56:06 --> Model Class Initialized
ERROR - 2020-04-04 15:56:06 --> Could not find the language line ""
ERROR - 2020-04-04 15:56:06 --> Could not find the language line ""
ERROR - 2020-04-04 15:56:06 --> Could not find the language line ""
DEBUG - 2020-04-04 15:56:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:56:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:56:06 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:56:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:56:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:56:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:56:06 --> Final output sent to browser
DEBUG - 2020-04-04 15:56:06 --> Total execution time: 0.7608
INFO - 2020-04-04 15:56:34 --> Config Class Initialized
INFO - 2020-04-04 15:56:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:56:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:56:34 --> Utf8 Class Initialized
INFO - 2020-04-04 15:56:34 --> URI Class Initialized
INFO - 2020-04-04 15:56:34 --> Router Class Initialized
INFO - 2020-04-04 15:56:34 --> Output Class Initialized
INFO - 2020-04-04 15:56:34 --> Security Class Initialized
DEBUG - 2020-04-04 15:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:56:34 --> CSRF cookie sent
INFO - 2020-04-04 15:56:34 --> Input Class Initialized
INFO - 2020-04-04 15:56:34 --> Language Class Initialized
INFO - 2020-04-04 15:56:34 --> Language Class Initialized
INFO - 2020-04-04 15:56:34 --> Config Class Initialized
INFO - 2020-04-04 15:56:34 --> Loader Class Initialized
INFO - 2020-04-04 15:56:34 --> Helper loaded: url_helper
INFO - 2020-04-04 15:56:34 --> Helper loaded: file_helper
INFO - 2020-04-04 15:56:34 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:56:34 --> Helper loaded: common_helper
INFO - 2020-04-04 15:56:34 --> Helper loaded: language_helper
INFO - 2020-04-04 15:56:34 --> Helper loaded: email_helper
INFO - 2020-04-04 15:56:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:56:34 --> Database Driver Class Initialized
INFO - 2020-04-04 15:56:34 --> Parser Class Initialized
INFO - 2020-04-04 15:56:34 --> User Agent Class Initialized
INFO - 2020-04-04 15:56:34 --> Model Class Initialized
INFO - 2020-04-04 15:56:34 --> Model Class Initialized
DEBUG - 2020-04-04 15:56:34 --> Template Class Initialized
INFO - 2020-04-04 15:56:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:56:34 --> Email Class Initialized
INFO - 2020-04-04 15:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:56:34 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:56:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:56:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:56:34 --> Encryption Class Initialized
INFO - 2020-04-04 15:56:34 --> Controller Class Initialized
DEBUG - 2020-04-04 15:56:34 --> post MX_Controller Initialized
INFO - 2020-04-04 15:56:34 --> Model Class Initialized
ERROR - 2020-04-04 15:56:35 --> Could not find the language line ""
ERROR - 2020-04-04 15:56:35 --> Could not find the language line ""
ERROR - 2020-04-04 15:56:35 --> Could not find the language line ""
DEBUG - 2020-04-04 15:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:56:35 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:56:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:56:35 --> Final output sent to browser
DEBUG - 2020-04-04 15:56:35 --> Total execution time: 0.8024
INFO - 2020-04-04 15:56:39 --> Config Class Initialized
INFO - 2020-04-04 15:56:39 --> Config Class Initialized
INFO - 2020-04-04 15:56:39 --> Hooks Class Initialized
INFO - 2020-04-04 15:56:39 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:56:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 15:56:39 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:56:39 --> Utf8 Class Initialized
INFO - 2020-04-04 15:56:39 --> Utf8 Class Initialized
INFO - 2020-04-04 15:56:39 --> URI Class Initialized
INFO - 2020-04-04 15:56:39 --> URI Class Initialized
INFO - 2020-04-04 15:56:39 --> Router Class Initialized
INFO - 2020-04-04 15:56:39 --> Router Class Initialized
INFO - 2020-04-04 15:56:39 --> Output Class Initialized
INFO - 2020-04-04 15:56:39 --> Output Class Initialized
INFO - 2020-04-04 15:56:39 --> Security Class Initialized
INFO - 2020-04-04 15:56:39 --> Security Class Initialized
DEBUG - 2020-04-04 15:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 15:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:56:39 --> CSRF cookie sent
INFO - 2020-04-04 15:56:39 --> CSRF cookie sent
INFO - 2020-04-04 15:56:39 --> Input Class Initialized
INFO - 2020-04-04 15:56:39 --> Input Class Initialized
INFO - 2020-04-04 15:56:39 --> Language Class Initialized
INFO - 2020-04-04 15:56:39 --> Language Class Initialized
ERROR - 2020-04-04 15:56:39 --> 404 Page Not Found: /index
ERROR - 2020-04-04 15:56:39 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:58:34 --> Config Class Initialized
INFO - 2020-04-04 15:58:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:58:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:58:34 --> Utf8 Class Initialized
INFO - 2020-04-04 15:58:34 --> URI Class Initialized
INFO - 2020-04-04 15:58:34 --> Router Class Initialized
INFO - 2020-04-04 15:58:34 --> Output Class Initialized
INFO - 2020-04-04 15:58:34 --> Security Class Initialized
DEBUG - 2020-04-04 15:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:58:34 --> CSRF cookie sent
INFO - 2020-04-04 15:58:34 --> Input Class Initialized
INFO - 2020-04-04 15:58:34 --> Language Class Initialized
INFO - 2020-04-04 15:58:34 --> Language Class Initialized
INFO - 2020-04-04 15:58:34 --> Config Class Initialized
INFO - 2020-04-04 15:58:34 --> Loader Class Initialized
INFO - 2020-04-04 15:58:34 --> Helper loaded: url_helper
INFO - 2020-04-04 15:58:34 --> Helper loaded: file_helper
INFO - 2020-04-04 15:58:34 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:58:34 --> Helper loaded: common_helper
INFO - 2020-04-04 15:58:34 --> Helper loaded: language_helper
INFO - 2020-04-04 15:58:34 --> Helper loaded: email_helper
INFO - 2020-04-04 15:58:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:58:34 --> Database Driver Class Initialized
INFO - 2020-04-04 15:58:34 --> Parser Class Initialized
INFO - 2020-04-04 15:58:35 --> User Agent Class Initialized
INFO - 2020-04-04 15:58:35 --> Model Class Initialized
INFO - 2020-04-04 15:58:35 --> Model Class Initialized
DEBUG - 2020-04-04 15:58:35 --> Template Class Initialized
INFO - 2020-04-04 15:58:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:58:35 --> Email Class Initialized
INFO - 2020-04-04 15:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:58:35 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:58:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:58:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:58:35 --> Encryption Class Initialized
INFO - 2020-04-04 15:58:35 --> Controller Class Initialized
DEBUG - 2020-04-04 15:58:35 --> post MX_Controller Initialized
INFO - 2020-04-04 15:58:35 --> Model Class Initialized
ERROR - 2020-04-04 15:58:35 --> Could not find the language line ""
ERROR - 2020-04-04 15:58:35 --> Could not find the language line ""
ERROR - 2020-04-04 15:58:35 --> Could not find the language line ""
DEBUG - 2020-04-04 15:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:58:35 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:58:35 --> Final output sent to browser
DEBUG - 2020-04-04 15:58:35 --> Total execution time: 0.8136
INFO - 2020-04-04 15:58:35 --> Config Class Initialized
INFO - 2020-04-04 15:58:35 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:58:35 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:58:35 --> Utf8 Class Initialized
INFO - 2020-04-04 15:58:35 --> URI Class Initialized
INFO - 2020-04-04 15:58:35 --> Router Class Initialized
INFO - 2020-04-04 15:58:35 --> Output Class Initialized
INFO - 2020-04-04 15:58:35 --> Config Class Initialized
INFO - 2020-04-04 15:58:35 --> Hooks Class Initialized
INFO - 2020-04-04 15:58:35 --> Security Class Initialized
DEBUG - 2020-04-04 15:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 15:58:35 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:58:35 --> Utf8 Class Initialized
INFO - 2020-04-04 15:58:35 --> CSRF cookie sent
INFO - 2020-04-04 15:58:35 --> Input Class Initialized
INFO - 2020-04-04 15:58:35 --> URI Class Initialized
INFO - 2020-04-04 15:58:35 --> Language Class Initialized
INFO - 2020-04-04 15:58:35 --> Router Class Initialized
ERROR - 2020-04-04 15:58:35 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:58:35 --> Output Class Initialized
INFO - 2020-04-04 15:58:35 --> Security Class Initialized
DEBUG - 2020-04-04 15:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:58:35 --> CSRF cookie sent
INFO - 2020-04-04 15:58:35 --> Input Class Initialized
INFO - 2020-04-04 15:58:35 --> Language Class Initialized
ERROR - 2020-04-04 15:58:35 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:58:46 --> Config Class Initialized
INFO - 2020-04-04 15:58:46 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:58:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:58:46 --> Utf8 Class Initialized
INFO - 2020-04-04 15:58:46 --> URI Class Initialized
INFO - 2020-04-04 15:58:46 --> Router Class Initialized
INFO - 2020-04-04 15:58:46 --> Output Class Initialized
INFO - 2020-04-04 15:58:46 --> Security Class Initialized
DEBUG - 2020-04-04 15:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:58:46 --> CSRF cookie sent
INFO - 2020-04-04 15:58:46 --> Input Class Initialized
INFO - 2020-04-04 15:58:46 --> Language Class Initialized
INFO - 2020-04-04 15:58:46 --> Language Class Initialized
INFO - 2020-04-04 15:58:46 --> Config Class Initialized
INFO - 2020-04-04 15:58:46 --> Loader Class Initialized
INFO - 2020-04-04 15:58:46 --> Helper loaded: url_helper
INFO - 2020-04-04 15:58:47 --> Helper loaded: file_helper
INFO - 2020-04-04 15:58:47 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:58:47 --> Helper loaded: common_helper
INFO - 2020-04-04 15:58:47 --> Helper loaded: language_helper
INFO - 2020-04-04 15:58:47 --> Helper loaded: email_helper
INFO - 2020-04-04 15:58:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:58:47 --> Database Driver Class Initialized
INFO - 2020-04-04 15:58:47 --> Parser Class Initialized
INFO - 2020-04-04 15:58:47 --> User Agent Class Initialized
INFO - 2020-04-04 15:58:47 --> Model Class Initialized
INFO - 2020-04-04 15:58:47 --> Model Class Initialized
DEBUG - 2020-04-04 15:58:47 --> Template Class Initialized
INFO - 2020-04-04 15:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:58:47 --> Email Class Initialized
INFO - 2020-04-04 15:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:58:47 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:58:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:58:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:58:47 --> Encryption Class Initialized
INFO - 2020-04-04 15:58:47 --> Controller Class Initialized
DEBUG - 2020-04-04 15:58:47 --> post MX_Controller Initialized
INFO - 2020-04-04 15:58:47 --> Model Class Initialized
ERROR - 2020-04-04 15:58:47 --> Could not find the language line ""
ERROR - 2020-04-04 15:58:47 --> Could not find the language line ""
ERROR - 2020-04-04 15:58:47 --> Could not find the language line ""
DEBUG - 2020-04-04 15:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:58:47 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:58:47 --> Final output sent to browser
DEBUG - 2020-04-04 15:58:47 --> Total execution time: 0.8431
INFO - 2020-04-04 15:58:47 --> Config Class Initialized
INFO - 2020-04-04 15:58:47 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:58:47 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:58:47 --> Utf8 Class Initialized
INFO - 2020-04-04 15:58:47 --> URI Class Initialized
INFO - 2020-04-04 15:58:47 --> Router Class Initialized
INFO - 2020-04-04 15:58:47 --> Output Class Initialized
INFO - 2020-04-04 15:58:47 --> Security Class Initialized
DEBUG - 2020-04-04 15:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:58:48 --> CSRF cookie sent
INFO - 2020-04-04 15:58:48 --> Config Class Initialized
INFO - 2020-04-04 15:58:48 --> Hooks Class Initialized
INFO - 2020-04-04 15:58:48 --> Input Class Initialized
INFO - 2020-04-04 15:58:48 --> Language Class Initialized
DEBUG - 2020-04-04 15:58:48 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:58:48 --> Utf8 Class Initialized
ERROR - 2020-04-04 15:58:48 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:58:48 --> URI Class Initialized
INFO - 2020-04-04 15:58:48 --> Router Class Initialized
INFO - 2020-04-04 15:58:48 --> Output Class Initialized
INFO - 2020-04-04 15:58:48 --> Security Class Initialized
DEBUG - 2020-04-04 15:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:58:48 --> CSRF cookie sent
INFO - 2020-04-04 15:58:48 --> Input Class Initialized
INFO - 2020-04-04 15:58:48 --> Language Class Initialized
ERROR - 2020-04-04 15:58:48 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:58:58 --> Config Class Initialized
INFO - 2020-04-04 15:58:58 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:58:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:58:58 --> Utf8 Class Initialized
INFO - 2020-04-04 15:58:58 --> URI Class Initialized
INFO - 2020-04-04 15:58:58 --> Router Class Initialized
INFO - 2020-04-04 15:58:58 --> Output Class Initialized
INFO - 2020-04-04 15:58:58 --> Security Class Initialized
DEBUG - 2020-04-04 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:58:58 --> CSRF cookie sent
INFO - 2020-04-04 15:58:58 --> Input Class Initialized
INFO - 2020-04-04 15:58:58 --> Language Class Initialized
INFO - 2020-04-04 15:58:58 --> Language Class Initialized
INFO - 2020-04-04 15:58:58 --> Config Class Initialized
INFO - 2020-04-04 15:58:58 --> Loader Class Initialized
INFO - 2020-04-04 15:58:58 --> Helper loaded: url_helper
INFO - 2020-04-04 15:58:58 --> Helper loaded: file_helper
INFO - 2020-04-04 15:58:58 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:58:58 --> Helper loaded: common_helper
INFO - 2020-04-04 15:58:58 --> Helper loaded: language_helper
INFO - 2020-04-04 15:58:58 --> Helper loaded: email_helper
INFO - 2020-04-04 15:58:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:58:58 --> Database Driver Class Initialized
INFO - 2020-04-04 15:58:58 --> Parser Class Initialized
INFO - 2020-04-04 15:58:58 --> User Agent Class Initialized
INFO - 2020-04-04 15:58:58 --> Model Class Initialized
INFO - 2020-04-04 15:58:58 --> Model Class Initialized
DEBUG - 2020-04-04 15:58:58 --> Template Class Initialized
INFO - 2020-04-04 15:58:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:58:58 --> Email Class Initialized
INFO - 2020-04-04 15:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:58:58 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:58:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:58:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:58:59 --> Encryption Class Initialized
INFO - 2020-04-04 15:58:59 --> Controller Class Initialized
DEBUG - 2020-04-04 15:58:59 --> post MX_Controller Initialized
INFO - 2020-04-04 15:58:59 --> Model Class Initialized
ERROR - 2020-04-04 15:58:59 --> Could not find the language line ""
ERROR - 2020-04-04 15:58:59 --> Could not find the language line ""
ERROR - 2020-04-04 15:58:59 --> Could not find the language line ""
DEBUG - 2020-04-04 15:58:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:58:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:58:59 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:58:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:58:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:58:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:58:59 --> Final output sent to browser
DEBUG - 2020-04-04 15:58:59 --> Total execution time: 0.8052
INFO - 2020-04-04 15:58:59 --> Config Class Initialized
INFO - 2020-04-04 15:58:59 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:58:59 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:58:59 --> Utf8 Class Initialized
INFO - 2020-04-04 15:58:59 --> URI Class Initialized
INFO - 2020-04-04 15:58:59 --> Router Class Initialized
INFO - 2020-04-04 15:58:59 --> Output Class Initialized
INFO - 2020-04-04 15:58:59 --> Security Class Initialized
DEBUG - 2020-04-04 15:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:58:59 --> CSRF cookie sent
INFO - 2020-04-04 15:58:59 --> Input Class Initialized
INFO - 2020-04-04 15:58:59 --> Language Class Initialized
ERROR - 2020-04-04 15:58:59 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:58:59 --> Config Class Initialized
INFO - 2020-04-04 15:58:59 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:58:59 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:59:00 --> Utf8 Class Initialized
INFO - 2020-04-04 15:59:00 --> URI Class Initialized
INFO - 2020-04-04 15:59:00 --> Router Class Initialized
INFO - 2020-04-04 15:59:00 --> Output Class Initialized
INFO - 2020-04-04 15:59:00 --> Security Class Initialized
DEBUG - 2020-04-04 15:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:59:00 --> CSRF cookie sent
INFO - 2020-04-04 15:59:00 --> Input Class Initialized
INFO - 2020-04-04 15:59:00 --> Language Class Initialized
ERROR - 2020-04-04 15:59:00 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:59:47 --> Config Class Initialized
INFO - 2020-04-04 15:59:47 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:59:47 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:59:47 --> Utf8 Class Initialized
INFO - 2020-04-04 15:59:47 --> URI Class Initialized
INFO - 2020-04-04 15:59:47 --> Router Class Initialized
INFO - 2020-04-04 15:59:47 --> Output Class Initialized
INFO - 2020-04-04 15:59:47 --> Security Class Initialized
DEBUG - 2020-04-04 15:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:59:47 --> CSRF cookie sent
INFO - 2020-04-04 15:59:47 --> Input Class Initialized
INFO - 2020-04-04 15:59:47 --> Language Class Initialized
INFO - 2020-04-04 15:59:47 --> Language Class Initialized
INFO - 2020-04-04 15:59:47 --> Config Class Initialized
INFO - 2020-04-04 15:59:47 --> Loader Class Initialized
INFO - 2020-04-04 15:59:47 --> Helper loaded: url_helper
INFO - 2020-04-04 15:59:47 --> Helper loaded: file_helper
INFO - 2020-04-04 15:59:48 --> Helper loaded: cookie_helper
INFO - 2020-04-04 15:59:48 --> Helper loaded: common_helper
INFO - 2020-04-04 15:59:48 --> Helper loaded: language_helper
INFO - 2020-04-04 15:59:48 --> Helper loaded: email_helper
INFO - 2020-04-04 15:59:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 15:59:48 --> Database Driver Class Initialized
INFO - 2020-04-04 15:59:48 --> Parser Class Initialized
INFO - 2020-04-04 15:59:48 --> User Agent Class Initialized
INFO - 2020-04-04 15:59:48 --> Model Class Initialized
INFO - 2020-04-04 15:59:48 --> Model Class Initialized
DEBUG - 2020-04-04 15:59:48 --> Template Class Initialized
INFO - 2020-04-04 15:59:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 15:59:48 --> Email Class Initialized
INFO - 2020-04-04 15:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 15:59:48 --> Pagination Class Initialized
DEBUG - 2020-04-04 15:59:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 15:59:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 15:59:48 --> Encryption Class Initialized
INFO - 2020-04-04 15:59:48 --> Controller Class Initialized
DEBUG - 2020-04-04 15:59:48 --> post MX_Controller Initialized
INFO - 2020-04-04 15:59:48 --> Model Class Initialized
ERROR - 2020-04-04 15:59:48 --> Could not find the language line ""
ERROR - 2020-04-04 15:59:48 --> Could not find the language line ""
ERROR - 2020-04-04 15:59:48 --> Could not find the language line ""
DEBUG - 2020-04-04 15:59:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 15:59:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 15:59:48 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 15:59:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 15:59:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 15:59:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 15:59:48 --> Final output sent to browser
DEBUG - 2020-04-04 15:59:48 --> Total execution time: 0.8108
INFO - 2020-04-04 15:59:48 --> Config Class Initialized
INFO - 2020-04-04 15:59:48 --> Hooks Class Initialized
DEBUG - 2020-04-04 15:59:48 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:59:48 --> Utf8 Class Initialized
INFO - 2020-04-04 15:59:48 --> URI Class Initialized
INFO - 2020-04-04 15:59:48 --> Router Class Initialized
INFO - 2020-04-04 15:59:48 --> Output Class Initialized
INFO - 2020-04-04 15:59:48 --> Security Class Initialized
DEBUG - 2020-04-04 15:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:59:49 --> CSRF cookie sent
INFO - 2020-04-04 15:59:49 --> Config Class Initialized
INFO - 2020-04-04 15:59:49 --> Input Class Initialized
INFO - 2020-04-04 15:59:49 --> Hooks Class Initialized
INFO - 2020-04-04 15:59:49 --> Language Class Initialized
DEBUG - 2020-04-04 15:59:49 --> UTF-8 Support Enabled
INFO - 2020-04-04 15:59:49 --> Utf8 Class Initialized
ERROR - 2020-04-04 15:59:49 --> 404 Page Not Found: /index
INFO - 2020-04-04 15:59:49 --> URI Class Initialized
INFO - 2020-04-04 15:59:49 --> Router Class Initialized
INFO - 2020-04-04 15:59:49 --> Output Class Initialized
INFO - 2020-04-04 15:59:49 --> Security Class Initialized
DEBUG - 2020-04-04 15:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 15:59:49 --> CSRF cookie sent
INFO - 2020-04-04 15:59:49 --> Input Class Initialized
INFO - 2020-04-04 15:59:49 --> Language Class Initialized
ERROR - 2020-04-04 15:59:49 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:01:56 --> Config Class Initialized
INFO - 2020-04-04 16:01:56 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:01:56 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:01:56 --> Utf8 Class Initialized
INFO - 2020-04-04 16:01:56 --> URI Class Initialized
INFO - 2020-04-04 16:01:56 --> Router Class Initialized
INFO - 2020-04-04 16:01:56 --> Output Class Initialized
INFO - 2020-04-04 16:01:56 --> Security Class Initialized
DEBUG - 2020-04-04 16:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:01:56 --> CSRF cookie sent
INFO - 2020-04-04 16:01:56 --> Input Class Initialized
INFO - 2020-04-04 16:01:56 --> Language Class Initialized
INFO - 2020-04-04 16:01:56 --> Language Class Initialized
INFO - 2020-04-04 16:01:56 --> Config Class Initialized
INFO - 2020-04-04 16:01:57 --> Loader Class Initialized
INFO - 2020-04-04 16:01:57 --> Helper loaded: url_helper
INFO - 2020-04-04 16:01:57 --> Helper loaded: file_helper
INFO - 2020-04-04 16:01:57 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:01:57 --> Helper loaded: common_helper
INFO - 2020-04-04 16:01:57 --> Helper loaded: language_helper
INFO - 2020-04-04 16:01:57 --> Helper loaded: email_helper
INFO - 2020-04-04 16:01:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:01:57 --> Database Driver Class Initialized
INFO - 2020-04-04 16:01:57 --> Parser Class Initialized
INFO - 2020-04-04 16:01:57 --> User Agent Class Initialized
INFO - 2020-04-04 16:01:57 --> Model Class Initialized
INFO - 2020-04-04 16:01:57 --> Model Class Initialized
DEBUG - 2020-04-04 16:01:57 --> Template Class Initialized
INFO - 2020-04-04 16:01:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:01:57 --> Email Class Initialized
INFO - 2020-04-04 16:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:01:57 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:01:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:01:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:01:57 --> Encryption Class Initialized
INFO - 2020-04-04 16:01:57 --> Controller Class Initialized
DEBUG - 2020-04-04 16:01:57 --> post MX_Controller Initialized
INFO - 2020-04-04 16:01:57 --> Model Class Initialized
ERROR - 2020-04-04 16:01:57 --> Could not find the language line ""
ERROR - 2020-04-04 16:01:57 --> Could not find the language line ""
ERROR - 2020-04-04 16:01:57 --> Could not find the language line ""
DEBUG - 2020-04-04 16:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:01:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:01:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:01:57 --> Final output sent to browser
DEBUG - 2020-04-04 16:01:57 --> Total execution time: 0.7666
INFO - 2020-04-04 16:01:57 --> Config Class Initialized
INFO - 2020-04-04 16:01:57 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:01:57 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:01:57 --> Utf8 Class Initialized
INFO - 2020-04-04 16:01:57 --> URI Class Initialized
INFO - 2020-04-04 16:01:57 --> Router Class Initialized
INFO - 2020-04-04 16:01:57 --> Output Class Initialized
INFO - 2020-04-04 16:01:58 --> Security Class Initialized
DEBUG - 2020-04-04 16:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:01:58 --> CSRF cookie sent
INFO - 2020-04-04 16:01:58 --> Input Class Initialized
INFO - 2020-04-04 16:01:58 --> Language Class Initialized
ERROR - 2020-04-04 16:01:58 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:01:58 --> Config Class Initialized
INFO - 2020-04-04 16:01:58 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:01:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:01:58 --> Utf8 Class Initialized
INFO - 2020-04-04 16:01:58 --> URI Class Initialized
INFO - 2020-04-04 16:01:58 --> Router Class Initialized
INFO - 2020-04-04 16:01:58 --> Output Class Initialized
INFO - 2020-04-04 16:01:58 --> Security Class Initialized
DEBUG - 2020-04-04 16:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:01:58 --> CSRF cookie sent
INFO - 2020-04-04 16:01:58 --> Input Class Initialized
INFO - 2020-04-04 16:01:58 --> Language Class Initialized
ERROR - 2020-04-04 16:01:58 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:02:12 --> Config Class Initialized
INFO - 2020-04-04 16:02:12 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:02:12 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:02:12 --> Utf8 Class Initialized
INFO - 2020-04-04 16:02:12 --> URI Class Initialized
INFO - 2020-04-04 16:02:12 --> Router Class Initialized
INFO - 2020-04-04 16:02:12 --> Output Class Initialized
INFO - 2020-04-04 16:02:12 --> Security Class Initialized
DEBUG - 2020-04-04 16:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:02:12 --> CSRF cookie sent
INFO - 2020-04-04 16:02:12 --> Input Class Initialized
INFO - 2020-04-04 16:02:12 --> Language Class Initialized
INFO - 2020-04-04 16:02:12 --> Language Class Initialized
INFO - 2020-04-04 16:02:12 --> Config Class Initialized
INFO - 2020-04-04 16:02:12 --> Loader Class Initialized
INFO - 2020-04-04 16:02:12 --> Helper loaded: url_helper
INFO - 2020-04-04 16:02:12 --> Helper loaded: file_helper
INFO - 2020-04-04 16:02:12 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:02:12 --> Helper loaded: common_helper
INFO - 2020-04-04 16:02:12 --> Helper loaded: language_helper
INFO - 2020-04-04 16:02:12 --> Helper loaded: email_helper
INFO - 2020-04-04 16:02:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:02:12 --> Database Driver Class Initialized
INFO - 2020-04-04 16:02:12 --> Parser Class Initialized
INFO - 2020-04-04 16:02:12 --> User Agent Class Initialized
INFO - 2020-04-04 16:02:12 --> Model Class Initialized
INFO - 2020-04-04 16:02:12 --> Model Class Initialized
DEBUG - 2020-04-04 16:02:12 --> Template Class Initialized
INFO - 2020-04-04 16:02:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:02:12 --> Email Class Initialized
INFO - 2020-04-04 16:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:02:13 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:02:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:02:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:02:13 --> Encryption Class Initialized
INFO - 2020-04-04 16:02:13 --> Controller Class Initialized
DEBUG - 2020-04-04 16:02:13 --> post MX_Controller Initialized
INFO - 2020-04-04 16:02:13 --> Model Class Initialized
ERROR - 2020-04-04 16:02:13 --> Could not find the language line ""
ERROR - 2020-04-04 16:02:13 --> Could not find the language line ""
ERROR - 2020-04-04 16:02:13 --> Could not find the language line ""
DEBUG - 2020-04-04 16:02:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:02:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:02:13 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:02:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:02:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:02:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:02:13 --> Final output sent to browser
DEBUG - 2020-04-04 16:02:13 --> Total execution time: 0.7610
INFO - 2020-04-04 16:02:13 --> Config Class Initialized
INFO - 2020-04-04 16:02:13 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:02:13 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:02:13 --> Utf8 Class Initialized
INFO - 2020-04-04 16:02:13 --> URI Class Initialized
INFO - 2020-04-04 16:02:13 --> Router Class Initialized
INFO - 2020-04-04 16:02:13 --> Output Class Initialized
INFO - 2020-04-04 16:02:13 --> Security Class Initialized
DEBUG - 2020-04-04 16:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:02:13 --> CSRF cookie sent
INFO - 2020-04-04 16:02:13 --> Input Class Initialized
INFO - 2020-04-04 16:02:13 --> Language Class Initialized
ERROR - 2020-04-04 16:02:13 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:02:13 --> Config Class Initialized
INFO - 2020-04-04 16:02:13 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:02:14 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:02:14 --> Utf8 Class Initialized
INFO - 2020-04-04 16:02:14 --> URI Class Initialized
INFO - 2020-04-04 16:02:14 --> Router Class Initialized
INFO - 2020-04-04 16:02:14 --> Output Class Initialized
INFO - 2020-04-04 16:02:14 --> Security Class Initialized
DEBUG - 2020-04-04 16:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:02:14 --> CSRF cookie sent
INFO - 2020-04-04 16:02:14 --> Input Class Initialized
INFO - 2020-04-04 16:02:14 --> Language Class Initialized
ERROR - 2020-04-04 16:02:14 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:02:33 --> Config Class Initialized
INFO - 2020-04-04 16:02:33 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:02:33 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:02:33 --> Utf8 Class Initialized
INFO - 2020-04-04 16:02:33 --> URI Class Initialized
INFO - 2020-04-04 16:02:33 --> Router Class Initialized
INFO - 2020-04-04 16:02:33 --> Output Class Initialized
INFO - 2020-04-04 16:02:33 --> Security Class Initialized
DEBUG - 2020-04-04 16:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:02:33 --> CSRF cookie sent
INFO - 2020-04-04 16:02:33 --> Input Class Initialized
INFO - 2020-04-04 16:02:33 --> Language Class Initialized
INFO - 2020-04-04 16:02:33 --> Language Class Initialized
INFO - 2020-04-04 16:02:33 --> Config Class Initialized
INFO - 2020-04-04 16:02:33 --> Loader Class Initialized
INFO - 2020-04-04 16:02:33 --> Helper loaded: url_helper
INFO - 2020-04-04 16:02:33 --> Helper loaded: file_helper
INFO - 2020-04-04 16:02:33 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:02:33 --> Helper loaded: common_helper
INFO - 2020-04-04 16:02:33 --> Helper loaded: language_helper
INFO - 2020-04-04 16:02:33 --> Helper loaded: email_helper
INFO - 2020-04-04 16:02:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:02:33 --> Database Driver Class Initialized
INFO - 2020-04-04 16:02:33 --> Parser Class Initialized
INFO - 2020-04-04 16:02:33 --> User Agent Class Initialized
INFO - 2020-04-04 16:02:33 --> Model Class Initialized
INFO - 2020-04-04 16:02:33 --> Model Class Initialized
DEBUG - 2020-04-04 16:02:33 --> Template Class Initialized
INFO - 2020-04-04 16:02:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:02:33 --> Email Class Initialized
INFO - 2020-04-04 16:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:02:33 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:02:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:02:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:02:33 --> Encryption Class Initialized
INFO - 2020-04-04 16:02:33 --> Controller Class Initialized
DEBUG - 2020-04-04 16:02:33 --> post MX_Controller Initialized
INFO - 2020-04-04 16:02:33 --> Model Class Initialized
ERROR - 2020-04-04 16:02:33 --> Could not find the language line ""
ERROR - 2020-04-04 16:02:33 --> Could not find the language line ""
ERROR - 2020-04-04 16:02:33 --> Could not find the language line ""
DEBUG - 2020-04-04 16:02:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:02:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:02:33 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:02:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:02:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:02:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:02:33 --> Final output sent to browser
DEBUG - 2020-04-04 16:02:33 --> Total execution time: 0.7790
INFO - 2020-04-04 16:02:34 --> Config Class Initialized
INFO - 2020-04-04 16:02:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:02:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:02:34 --> Utf8 Class Initialized
INFO - 2020-04-04 16:02:34 --> URI Class Initialized
INFO - 2020-04-04 16:02:34 --> Router Class Initialized
INFO - 2020-04-04 16:02:34 --> Output Class Initialized
INFO - 2020-04-04 16:02:34 --> Security Class Initialized
DEBUG - 2020-04-04 16:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:02:34 --> CSRF cookie sent
INFO - 2020-04-04 16:02:34 --> Input Class Initialized
INFO - 2020-04-04 16:02:34 --> Language Class Initialized
ERROR - 2020-04-04 16:02:34 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:02:34 --> Config Class Initialized
INFO - 2020-04-04 16:02:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:02:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:02:34 --> Utf8 Class Initialized
INFO - 2020-04-04 16:02:34 --> URI Class Initialized
INFO - 2020-04-04 16:02:34 --> Router Class Initialized
INFO - 2020-04-04 16:02:34 --> Output Class Initialized
INFO - 2020-04-04 16:02:34 --> Security Class Initialized
DEBUG - 2020-04-04 16:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:02:34 --> CSRF cookie sent
INFO - 2020-04-04 16:02:34 --> Input Class Initialized
INFO - 2020-04-04 16:02:34 --> Language Class Initialized
ERROR - 2020-04-04 16:02:34 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:03:14 --> Config Class Initialized
INFO - 2020-04-04 16:03:14 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:03:14 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:03:14 --> Utf8 Class Initialized
INFO - 2020-04-04 16:03:14 --> URI Class Initialized
INFO - 2020-04-04 16:03:14 --> Router Class Initialized
INFO - 2020-04-04 16:03:14 --> Output Class Initialized
INFO - 2020-04-04 16:03:14 --> Security Class Initialized
DEBUG - 2020-04-04 16:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:03:14 --> CSRF cookie sent
INFO - 2020-04-04 16:03:14 --> Input Class Initialized
INFO - 2020-04-04 16:03:14 --> Language Class Initialized
INFO - 2020-04-04 16:03:14 --> Language Class Initialized
INFO - 2020-04-04 16:03:14 --> Config Class Initialized
INFO - 2020-04-04 16:03:14 --> Loader Class Initialized
INFO - 2020-04-04 16:03:14 --> Helper loaded: url_helper
INFO - 2020-04-04 16:03:14 --> Helper loaded: file_helper
INFO - 2020-04-04 16:03:14 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:03:14 --> Helper loaded: common_helper
INFO - 2020-04-04 16:03:14 --> Helper loaded: language_helper
INFO - 2020-04-04 16:03:14 --> Helper loaded: email_helper
INFO - 2020-04-04 16:03:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:03:14 --> Database Driver Class Initialized
INFO - 2020-04-04 16:03:14 --> Parser Class Initialized
INFO - 2020-04-04 16:03:14 --> User Agent Class Initialized
INFO - 2020-04-04 16:03:14 --> Model Class Initialized
INFO - 2020-04-04 16:03:14 --> Model Class Initialized
DEBUG - 2020-04-04 16:03:14 --> Template Class Initialized
INFO - 2020-04-04 16:03:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:03:14 --> Email Class Initialized
INFO - 2020-04-04 16:03:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:03:15 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:03:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:03:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:03:15 --> Encryption Class Initialized
INFO - 2020-04-04 16:03:15 --> Controller Class Initialized
DEBUG - 2020-04-04 16:03:15 --> post MX_Controller Initialized
INFO - 2020-04-04 16:03:15 --> Model Class Initialized
ERROR - 2020-04-04 16:03:15 --> Could not find the language line ""
ERROR - 2020-04-04 16:03:15 --> Could not find the language line ""
ERROR - 2020-04-04 16:03:15 --> Could not find the language line ""
DEBUG - 2020-04-04 16:03:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:03:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:03:15 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:03:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:03:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:03:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:03:15 --> Final output sent to browser
DEBUG - 2020-04-04 16:03:15 --> Total execution time: 0.8411
INFO - 2020-04-04 16:03:31 --> Config Class Initialized
INFO - 2020-04-04 16:03:31 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:03:31 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:03:31 --> Utf8 Class Initialized
INFO - 2020-04-04 16:03:31 --> URI Class Initialized
INFO - 2020-04-04 16:03:31 --> Router Class Initialized
INFO - 2020-04-04 16:03:31 --> Output Class Initialized
INFO - 2020-04-04 16:03:31 --> Security Class Initialized
DEBUG - 2020-04-04 16:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:03:31 --> CSRF cookie sent
INFO - 2020-04-04 16:03:31 --> Input Class Initialized
INFO - 2020-04-04 16:03:31 --> Language Class Initialized
INFO - 2020-04-04 16:03:31 --> Language Class Initialized
INFO - 2020-04-04 16:03:31 --> Config Class Initialized
INFO - 2020-04-04 16:03:32 --> Loader Class Initialized
INFO - 2020-04-04 16:03:32 --> Helper loaded: url_helper
INFO - 2020-04-04 16:03:32 --> Helper loaded: file_helper
INFO - 2020-04-04 16:03:32 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:03:32 --> Helper loaded: common_helper
INFO - 2020-04-04 16:03:32 --> Helper loaded: language_helper
INFO - 2020-04-04 16:03:32 --> Helper loaded: email_helper
INFO - 2020-04-04 16:03:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:03:32 --> Database Driver Class Initialized
INFO - 2020-04-04 16:03:32 --> Parser Class Initialized
INFO - 2020-04-04 16:03:32 --> User Agent Class Initialized
INFO - 2020-04-04 16:03:32 --> Model Class Initialized
INFO - 2020-04-04 16:03:32 --> Model Class Initialized
DEBUG - 2020-04-04 16:03:32 --> Template Class Initialized
INFO - 2020-04-04 16:03:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:03:32 --> Email Class Initialized
INFO - 2020-04-04 16:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:03:32 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:03:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:03:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:03:32 --> Encryption Class Initialized
INFO - 2020-04-04 16:03:32 --> Controller Class Initialized
DEBUG - 2020-04-04 16:03:32 --> post MX_Controller Initialized
INFO - 2020-04-04 16:03:32 --> Model Class Initialized
ERROR - 2020-04-04 16:03:32 --> Could not find the language line ""
ERROR - 2020-04-04 16:03:32 --> Could not find the language line ""
ERROR - 2020-04-04 16:03:32 --> Could not find the language line ""
DEBUG - 2020-04-04 16:03:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:03:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:03:32 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:03:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:03:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:03:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:03:32 --> Final output sent to browser
DEBUG - 2020-04-04 16:03:32 --> Total execution time: 0.8279
INFO - 2020-04-04 16:04:14 --> Config Class Initialized
INFO - 2020-04-04 16:04:14 --> Config Class Initialized
INFO - 2020-04-04 16:04:14 --> Hooks Class Initialized
INFO - 2020-04-04 16:04:14 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 16:04:14 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:04:14 --> Utf8 Class Initialized
INFO - 2020-04-04 16:04:14 --> Utf8 Class Initialized
INFO - 2020-04-04 16:04:14 --> URI Class Initialized
INFO - 2020-04-04 16:04:14 --> URI Class Initialized
INFO - 2020-04-04 16:04:14 --> Router Class Initialized
INFO - 2020-04-04 16:04:14 --> Router Class Initialized
INFO - 2020-04-04 16:04:15 --> Output Class Initialized
INFO - 2020-04-04 16:04:15 --> Output Class Initialized
INFO - 2020-04-04 16:04:15 --> Security Class Initialized
INFO - 2020-04-04 16:04:15 --> Security Class Initialized
DEBUG - 2020-04-04 16:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 16:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:04:15 --> CSRF cookie sent
INFO - 2020-04-04 16:04:15 --> CSRF cookie sent
INFO - 2020-04-04 16:04:15 --> Input Class Initialized
INFO - 2020-04-04 16:04:15 --> Input Class Initialized
INFO - 2020-04-04 16:04:15 --> Language Class Initialized
INFO - 2020-04-04 16:04:15 --> Language Class Initialized
ERROR - 2020-04-04 16:04:15 --> 404 Page Not Found: /index
ERROR - 2020-04-04 16:04:15 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:06:05 --> Config Class Initialized
INFO - 2020-04-04 16:06:05 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:06:05 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:06:05 --> Utf8 Class Initialized
INFO - 2020-04-04 16:06:05 --> URI Class Initialized
INFO - 2020-04-04 16:06:05 --> Router Class Initialized
INFO - 2020-04-04 16:06:05 --> Output Class Initialized
INFO - 2020-04-04 16:06:05 --> Security Class Initialized
DEBUG - 2020-04-04 16:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:06:05 --> CSRF cookie sent
INFO - 2020-04-04 16:06:05 --> Input Class Initialized
INFO - 2020-04-04 16:06:05 --> Language Class Initialized
INFO - 2020-04-04 16:06:05 --> Language Class Initialized
INFO - 2020-04-04 16:06:05 --> Config Class Initialized
INFO - 2020-04-04 16:06:05 --> Loader Class Initialized
INFO - 2020-04-04 16:06:05 --> Helper loaded: url_helper
INFO - 2020-04-04 16:06:05 --> Helper loaded: file_helper
INFO - 2020-04-04 16:06:05 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:06:05 --> Helper loaded: common_helper
INFO - 2020-04-04 16:06:05 --> Helper loaded: language_helper
INFO - 2020-04-04 16:06:05 --> Helper loaded: email_helper
INFO - 2020-04-04 16:06:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:06:06 --> Database Driver Class Initialized
INFO - 2020-04-04 16:06:06 --> Parser Class Initialized
INFO - 2020-04-04 16:06:06 --> User Agent Class Initialized
INFO - 2020-04-04 16:06:06 --> Model Class Initialized
INFO - 2020-04-04 16:06:06 --> Model Class Initialized
DEBUG - 2020-04-04 16:06:06 --> Template Class Initialized
INFO - 2020-04-04 16:06:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:06:06 --> Email Class Initialized
INFO - 2020-04-04 16:06:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:06:06 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:06:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:06:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:06:06 --> Encryption Class Initialized
INFO - 2020-04-04 16:06:06 --> Controller Class Initialized
DEBUG - 2020-04-04 16:06:06 --> post MX_Controller Initialized
INFO - 2020-04-04 16:06:06 --> Model Class Initialized
ERROR - 2020-04-04 16:06:06 --> Could not find the language line ""
ERROR - 2020-04-04 16:06:06 --> Could not find the language line ""
ERROR - 2020-04-04 16:06:06 --> Could not find the language line ""
DEBUG - 2020-04-04 16:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:06:06 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:06:06 --> Final output sent to browser
DEBUG - 2020-04-04 16:06:06 --> Total execution time: 0.8492
INFO - 2020-04-04 16:06:06 --> Config Class Initialized
INFO - 2020-04-04 16:06:06 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:06:06 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:06:06 --> Utf8 Class Initialized
INFO - 2020-04-04 16:06:06 --> URI Class Initialized
INFO - 2020-04-04 16:06:06 --> Router Class Initialized
INFO - 2020-04-04 16:06:06 --> Output Class Initialized
INFO - 2020-04-04 16:06:06 --> Security Class Initialized
DEBUG - 2020-04-04 16:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:06:06 --> CSRF cookie sent
INFO - 2020-04-04 16:06:07 --> Input Class Initialized
INFO - 2020-04-04 16:06:07 --> Language Class Initialized
ERROR - 2020-04-04 16:06:07 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:06:07 --> Config Class Initialized
INFO - 2020-04-04 16:06:07 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:06:07 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:06:07 --> Utf8 Class Initialized
INFO - 2020-04-04 16:06:07 --> URI Class Initialized
INFO - 2020-04-04 16:06:07 --> Router Class Initialized
INFO - 2020-04-04 16:06:07 --> Output Class Initialized
INFO - 2020-04-04 16:06:07 --> Security Class Initialized
DEBUG - 2020-04-04 16:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:06:07 --> CSRF cookie sent
INFO - 2020-04-04 16:06:07 --> Input Class Initialized
INFO - 2020-04-04 16:06:07 --> Language Class Initialized
ERROR - 2020-04-04 16:06:07 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:06:46 --> Config Class Initialized
INFO - 2020-04-04 16:06:46 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:06:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:06:46 --> Utf8 Class Initialized
INFO - 2020-04-04 16:06:46 --> URI Class Initialized
INFO - 2020-04-04 16:06:46 --> Router Class Initialized
INFO - 2020-04-04 16:06:46 --> Output Class Initialized
INFO - 2020-04-04 16:06:46 --> Security Class Initialized
DEBUG - 2020-04-04 16:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:06:46 --> CSRF cookie sent
INFO - 2020-04-04 16:06:46 --> Input Class Initialized
INFO - 2020-04-04 16:06:46 --> Language Class Initialized
INFO - 2020-04-04 16:06:46 --> Language Class Initialized
INFO - 2020-04-04 16:06:46 --> Config Class Initialized
INFO - 2020-04-04 16:06:46 --> Loader Class Initialized
INFO - 2020-04-04 16:06:46 --> Helper loaded: url_helper
INFO - 2020-04-04 16:06:46 --> Helper loaded: file_helper
INFO - 2020-04-04 16:06:46 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:06:46 --> Helper loaded: common_helper
INFO - 2020-04-04 16:06:46 --> Helper loaded: language_helper
INFO - 2020-04-04 16:06:46 --> Helper loaded: email_helper
INFO - 2020-04-04 16:06:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:06:46 --> Database Driver Class Initialized
INFO - 2020-04-04 16:06:46 --> Parser Class Initialized
INFO - 2020-04-04 16:06:46 --> User Agent Class Initialized
INFO - 2020-04-04 16:06:46 --> Model Class Initialized
INFO - 2020-04-04 16:06:46 --> Model Class Initialized
DEBUG - 2020-04-04 16:06:46 --> Template Class Initialized
INFO - 2020-04-04 16:06:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:06:46 --> Email Class Initialized
INFO - 2020-04-04 16:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:06:46 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:06:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:06:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:06:46 --> Encryption Class Initialized
INFO - 2020-04-04 16:06:46 --> Controller Class Initialized
DEBUG - 2020-04-04 16:06:46 --> post MX_Controller Initialized
INFO - 2020-04-04 16:06:46 --> Model Class Initialized
ERROR - 2020-04-04 16:06:46 --> Could not find the language line ""
ERROR - 2020-04-04 16:06:46 --> Could not find the language line ""
ERROR - 2020-04-04 16:06:46 --> Could not find the language line ""
DEBUG - 2020-04-04 16:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:06:46 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:06:46 --> Final output sent to browser
DEBUG - 2020-04-04 16:06:46 --> Total execution time: 0.7879
INFO - 2020-04-04 16:06:47 --> Config Class Initialized
INFO - 2020-04-04 16:06:47 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:06:47 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:06:47 --> Utf8 Class Initialized
INFO - 2020-04-04 16:06:47 --> URI Class Initialized
INFO - 2020-04-04 16:06:47 --> Router Class Initialized
INFO - 2020-04-04 16:06:47 --> Output Class Initialized
INFO - 2020-04-04 16:06:47 --> Security Class Initialized
DEBUG - 2020-04-04 16:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:06:47 --> CSRF cookie sent
INFO - 2020-04-04 16:06:47 --> Input Class Initialized
INFO - 2020-04-04 16:06:47 --> Language Class Initialized
ERROR - 2020-04-04 16:06:47 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:06:47 --> Config Class Initialized
INFO - 2020-04-04 16:06:47 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:06:47 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:06:47 --> Utf8 Class Initialized
INFO - 2020-04-04 16:06:47 --> URI Class Initialized
INFO - 2020-04-04 16:06:47 --> Router Class Initialized
INFO - 2020-04-04 16:06:47 --> Output Class Initialized
INFO - 2020-04-04 16:06:47 --> Security Class Initialized
DEBUG - 2020-04-04 16:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:06:47 --> CSRF cookie sent
INFO - 2020-04-04 16:06:47 --> Input Class Initialized
INFO - 2020-04-04 16:06:47 --> Language Class Initialized
ERROR - 2020-04-04 16:06:47 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:07:41 --> Config Class Initialized
INFO - 2020-04-04 16:07:41 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:07:41 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:07:41 --> Utf8 Class Initialized
INFO - 2020-04-04 16:07:41 --> URI Class Initialized
INFO - 2020-04-04 16:07:41 --> Router Class Initialized
INFO - 2020-04-04 16:07:41 --> Output Class Initialized
INFO - 2020-04-04 16:07:41 --> Security Class Initialized
DEBUG - 2020-04-04 16:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:07:41 --> CSRF cookie sent
INFO - 2020-04-04 16:07:41 --> Input Class Initialized
INFO - 2020-04-04 16:07:41 --> Language Class Initialized
INFO - 2020-04-04 16:07:41 --> Language Class Initialized
INFO - 2020-04-04 16:07:41 --> Config Class Initialized
INFO - 2020-04-04 16:07:41 --> Loader Class Initialized
INFO - 2020-04-04 16:07:41 --> Helper loaded: url_helper
INFO - 2020-04-04 16:07:41 --> Helper loaded: file_helper
INFO - 2020-04-04 16:07:41 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:07:41 --> Helper loaded: common_helper
INFO - 2020-04-04 16:07:41 --> Helper loaded: language_helper
INFO - 2020-04-04 16:07:41 --> Helper loaded: email_helper
INFO - 2020-04-04 16:07:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:07:41 --> Database Driver Class Initialized
INFO - 2020-04-04 16:07:41 --> Parser Class Initialized
INFO - 2020-04-04 16:07:41 --> User Agent Class Initialized
INFO - 2020-04-04 16:07:41 --> Model Class Initialized
INFO - 2020-04-04 16:07:41 --> Model Class Initialized
DEBUG - 2020-04-04 16:07:41 --> Template Class Initialized
INFO - 2020-04-04 16:07:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:07:41 --> Email Class Initialized
INFO - 2020-04-04 16:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:07:41 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:07:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:07:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:07:41 --> Encryption Class Initialized
INFO - 2020-04-04 16:07:41 --> Controller Class Initialized
DEBUG - 2020-04-04 16:07:41 --> post MX_Controller Initialized
INFO - 2020-04-04 16:07:41 --> Model Class Initialized
ERROR - 2020-04-04 16:07:41 --> Could not find the language line ""
ERROR - 2020-04-04 16:07:41 --> Could not find the language line ""
ERROR - 2020-04-04 16:07:41 --> Could not find the language line ""
DEBUG - 2020-04-04 16:07:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:07:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:07:41 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:07:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:07:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:07:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:07:41 --> Final output sent to browser
DEBUG - 2020-04-04 16:07:41 --> Total execution time: 0.9001
INFO - 2020-04-04 16:07:42 --> Config Class Initialized
INFO - 2020-04-04 16:07:42 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:07:42 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:07:42 --> Utf8 Class Initialized
INFO - 2020-04-04 16:07:42 --> URI Class Initialized
INFO - 2020-04-04 16:07:42 --> Router Class Initialized
INFO - 2020-04-04 16:07:42 --> Output Class Initialized
INFO - 2020-04-04 16:07:42 --> Security Class Initialized
DEBUG - 2020-04-04 16:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:07:42 --> CSRF cookie sent
INFO - 2020-04-04 16:07:42 --> Config Class Initialized
INFO - 2020-04-04 16:07:42 --> Hooks Class Initialized
INFO - 2020-04-04 16:07:42 --> Input Class Initialized
INFO - 2020-04-04 16:07:42 --> Language Class Initialized
DEBUG - 2020-04-04 16:07:42 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:07:42 --> Utf8 Class Initialized
ERROR - 2020-04-04 16:07:42 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:07:42 --> URI Class Initialized
INFO - 2020-04-04 16:07:42 --> Router Class Initialized
INFO - 2020-04-04 16:07:42 --> Output Class Initialized
INFO - 2020-04-04 16:07:42 --> Security Class Initialized
DEBUG - 2020-04-04 16:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:07:42 --> CSRF cookie sent
INFO - 2020-04-04 16:07:42 --> Input Class Initialized
INFO - 2020-04-04 16:07:42 --> Language Class Initialized
ERROR - 2020-04-04 16:07:42 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:08:11 --> Config Class Initialized
INFO - 2020-04-04 16:08:11 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:08:11 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:08:11 --> Utf8 Class Initialized
INFO - 2020-04-04 16:08:11 --> URI Class Initialized
INFO - 2020-04-04 16:08:11 --> Router Class Initialized
INFO - 2020-04-04 16:08:11 --> Output Class Initialized
INFO - 2020-04-04 16:08:11 --> Security Class Initialized
DEBUG - 2020-04-04 16:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:08:11 --> CSRF cookie sent
INFO - 2020-04-04 16:08:11 --> Input Class Initialized
INFO - 2020-04-04 16:08:11 --> Language Class Initialized
INFO - 2020-04-04 16:08:11 --> Language Class Initialized
INFO - 2020-04-04 16:08:11 --> Config Class Initialized
INFO - 2020-04-04 16:08:11 --> Loader Class Initialized
INFO - 2020-04-04 16:08:11 --> Helper loaded: url_helper
INFO - 2020-04-04 16:08:11 --> Helper loaded: file_helper
INFO - 2020-04-04 16:08:11 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:08:11 --> Helper loaded: common_helper
INFO - 2020-04-04 16:08:11 --> Helper loaded: language_helper
INFO - 2020-04-04 16:08:11 --> Helper loaded: email_helper
INFO - 2020-04-04 16:08:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:08:12 --> Database Driver Class Initialized
INFO - 2020-04-04 16:08:12 --> Parser Class Initialized
INFO - 2020-04-04 16:08:12 --> User Agent Class Initialized
INFO - 2020-04-04 16:08:12 --> Model Class Initialized
INFO - 2020-04-04 16:08:12 --> Model Class Initialized
DEBUG - 2020-04-04 16:08:12 --> Template Class Initialized
INFO - 2020-04-04 16:08:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:08:12 --> Email Class Initialized
INFO - 2020-04-04 16:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:08:12 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:08:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:08:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:08:12 --> Encryption Class Initialized
INFO - 2020-04-04 16:08:12 --> Controller Class Initialized
DEBUG - 2020-04-04 16:08:12 --> post MX_Controller Initialized
INFO - 2020-04-04 16:08:12 --> Model Class Initialized
ERROR - 2020-04-04 16:08:12 --> Could not find the language line ""
ERROR - 2020-04-04 16:08:12 --> Could not find the language line ""
ERROR - 2020-04-04 16:08:12 --> Could not find the language line ""
DEBUG - 2020-04-04 16:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:08:12 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:08:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:08:12 --> Final output sent to browser
DEBUG - 2020-04-04 16:08:12 --> Total execution time: 0.8008
INFO - 2020-04-04 16:09:34 --> Config Class Initialized
INFO - 2020-04-04 16:09:34 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:09:34 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:09:34 --> Utf8 Class Initialized
INFO - 2020-04-04 16:09:34 --> URI Class Initialized
INFO - 2020-04-04 16:09:34 --> Router Class Initialized
INFO - 2020-04-04 16:09:34 --> Output Class Initialized
INFO - 2020-04-04 16:09:34 --> Security Class Initialized
DEBUG - 2020-04-04 16:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:09:34 --> CSRF cookie sent
INFO - 2020-04-04 16:09:34 --> Input Class Initialized
INFO - 2020-04-04 16:09:34 --> Language Class Initialized
INFO - 2020-04-04 16:09:34 --> Language Class Initialized
INFO - 2020-04-04 16:09:34 --> Config Class Initialized
INFO - 2020-04-04 16:09:34 --> Loader Class Initialized
INFO - 2020-04-04 16:09:34 --> Helper loaded: url_helper
INFO - 2020-04-04 16:09:34 --> Helper loaded: file_helper
INFO - 2020-04-04 16:09:34 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:09:34 --> Helper loaded: common_helper
INFO - 2020-04-04 16:09:34 --> Helper loaded: language_helper
INFO - 2020-04-04 16:09:34 --> Helper loaded: email_helper
INFO - 2020-04-04 16:09:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:09:34 --> Database Driver Class Initialized
INFO - 2020-04-04 16:09:34 --> Parser Class Initialized
INFO - 2020-04-04 16:09:34 --> User Agent Class Initialized
INFO - 2020-04-04 16:09:34 --> Model Class Initialized
INFO - 2020-04-04 16:09:34 --> Model Class Initialized
DEBUG - 2020-04-04 16:09:34 --> Template Class Initialized
INFO - 2020-04-04 16:09:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:09:34 --> Email Class Initialized
INFO - 2020-04-04 16:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:09:34 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:09:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:09:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:09:34 --> Encryption Class Initialized
INFO - 2020-04-04 16:09:34 --> Controller Class Initialized
DEBUG - 2020-04-04 16:09:34 --> post MX_Controller Initialized
INFO - 2020-04-04 16:09:34 --> Model Class Initialized
ERROR - 2020-04-04 16:09:34 --> Could not find the language line ""
ERROR - 2020-04-04 16:09:35 --> Could not find the language line ""
ERROR - 2020-04-04 16:09:35 --> Could not find the language line ""
DEBUG - 2020-04-04 16:09:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:09:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:09:35 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:09:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:09:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:09:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:09:35 --> Final output sent to browser
DEBUG - 2020-04-04 16:09:35 --> Total execution time: 0.9092
INFO - 2020-04-04 16:09:48 --> Config Class Initialized
INFO - 2020-04-04 16:09:48 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:09:48 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:09:48 --> Utf8 Class Initialized
INFO - 2020-04-04 16:09:48 --> URI Class Initialized
INFO - 2020-04-04 16:09:48 --> Router Class Initialized
INFO - 2020-04-04 16:09:48 --> Output Class Initialized
INFO - 2020-04-04 16:09:48 --> Security Class Initialized
DEBUG - 2020-04-04 16:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:09:48 --> CSRF cookie sent
INFO - 2020-04-04 16:09:48 --> Input Class Initialized
INFO - 2020-04-04 16:09:48 --> Language Class Initialized
INFO - 2020-04-04 16:09:48 --> Language Class Initialized
INFO - 2020-04-04 16:09:48 --> Config Class Initialized
INFO - 2020-04-04 16:09:48 --> Loader Class Initialized
INFO - 2020-04-04 16:09:48 --> Helper loaded: url_helper
INFO - 2020-04-04 16:09:48 --> Helper loaded: file_helper
INFO - 2020-04-04 16:09:48 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:09:48 --> Helper loaded: common_helper
INFO - 2020-04-04 16:09:48 --> Helper loaded: language_helper
INFO - 2020-04-04 16:09:48 --> Helper loaded: email_helper
INFO - 2020-04-04 16:09:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:09:48 --> Database Driver Class Initialized
INFO - 2020-04-04 16:09:48 --> Parser Class Initialized
INFO - 2020-04-04 16:09:48 --> User Agent Class Initialized
INFO - 2020-04-04 16:09:48 --> Model Class Initialized
INFO - 2020-04-04 16:09:48 --> Model Class Initialized
DEBUG - 2020-04-04 16:09:48 --> Template Class Initialized
INFO - 2020-04-04 16:09:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:09:48 --> Email Class Initialized
INFO - 2020-04-04 16:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:09:48 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:09:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:09:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:09:48 --> Encryption Class Initialized
INFO - 2020-04-04 16:09:48 --> Controller Class Initialized
DEBUG - 2020-04-04 16:09:48 --> post MX_Controller Initialized
INFO - 2020-04-04 16:09:48 --> Model Class Initialized
ERROR - 2020-04-04 16:09:48 --> Could not find the language line ""
ERROR - 2020-04-04 16:09:48 --> Could not find the language line ""
ERROR - 2020-04-04 16:09:49 --> Could not find the language line ""
DEBUG - 2020-04-04 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:09:49 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:09:49 --> Final output sent to browser
DEBUG - 2020-04-04 16:09:49 --> Total execution time: 0.8483
INFO - 2020-04-04 16:10:39 --> Config Class Initialized
INFO - 2020-04-04 16:10:39 --> Config Class Initialized
INFO - 2020-04-04 16:10:39 --> Hooks Class Initialized
INFO - 2020-04-04 16:10:39 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:10:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 16:10:39 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:10:39 --> Utf8 Class Initialized
INFO - 2020-04-04 16:10:39 --> Utf8 Class Initialized
INFO - 2020-04-04 16:10:39 --> URI Class Initialized
INFO - 2020-04-04 16:10:39 --> URI Class Initialized
INFO - 2020-04-04 16:10:39 --> Router Class Initialized
INFO - 2020-04-04 16:10:39 --> Router Class Initialized
INFO - 2020-04-04 16:10:39 --> Output Class Initialized
INFO - 2020-04-04 16:10:39 --> Output Class Initialized
INFO - 2020-04-04 16:10:39 --> Security Class Initialized
INFO - 2020-04-04 16:10:39 --> Security Class Initialized
DEBUG - 2020-04-04 16:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 16:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:10:39 --> CSRF cookie sent
INFO - 2020-04-04 16:10:39 --> CSRF cookie sent
INFO - 2020-04-04 16:10:39 --> Input Class Initialized
INFO - 2020-04-04 16:10:39 --> Input Class Initialized
INFO - 2020-04-04 16:10:39 --> Language Class Initialized
INFO - 2020-04-04 16:10:39 --> Language Class Initialized
ERROR - 2020-04-04 16:10:39 --> 404 Page Not Found: /index
ERROR - 2020-04-04 16:10:39 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:11:17 --> Config Class Initialized
INFO - 2020-04-04 16:11:17 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:11:17 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:11:17 --> Utf8 Class Initialized
INFO - 2020-04-04 16:11:17 --> URI Class Initialized
INFO - 2020-04-04 16:11:17 --> Router Class Initialized
INFO - 2020-04-04 16:11:17 --> Output Class Initialized
INFO - 2020-04-04 16:11:17 --> Security Class Initialized
DEBUG - 2020-04-04 16:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:11:18 --> CSRF cookie sent
INFO - 2020-04-04 16:11:18 --> Input Class Initialized
INFO - 2020-04-04 16:11:18 --> Language Class Initialized
INFO - 2020-04-04 16:11:18 --> Language Class Initialized
INFO - 2020-04-04 16:11:18 --> Config Class Initialized
INFO - 2020-04-04 16:11:18 --> Loader Class Initialized
INFO - 2020-04-04 16:11:18 --> Helper loaded: url_helper
INFO - 2020-04-04 16:11:18 --> Helper loaded: file_helper
INFO - 2020-04-04 16:11:18 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:11:18 --> Helper loaded: common_helper
INFO - 2020-04-04 16:11:18 --> Helper loaded: language_helper
INFO - 2020-04-04 16:11:18 --> Helper loaded: email_helper
INFO - 2020-04-04 16:11:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:11:18 --> Database Driver Class Initialized
INFO - 2020-04-04 16:11:18 --> Parser Class Initialized
INFO - 2020-04-04 16:11:18 --> User Agent Class Initialized
INFO - 2020-04-04 16:11:18 --> Model Class Initialized
INFO - 2020-04-04 16:11:18 --> Model Class Initialized
DEBUG - 2020-04-04 16:11:18 --> Template Class Initialized
INFO - 2020-04-04 16:11:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:11:18 --> Email Class Initialized
INFO - 2020-04-04 16:11:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:11:18 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:11:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:11:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:11:18 --> Encryption Class Initialized
INFO - 2020-04-04 16:11:18 --> Controller Class Initialized
DEBUG - 2020-04-04 16:11:18 --> post MX_Controller Initialized
INFO - 2020-04-04 16:11:18 --> Model Class Initialized
ERROR - 2020-04-04 16:11:18 --> Could not find the language line ""
ERROR - 2020-04-04 16:11:18 --> Could not find the language line ""
ERROR - 2020-04-04 16:11:18 --> Could not find the language line ""
DEBUG - 2020-04-04 16:11:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:11:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:11:18 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:11:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:11:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:11:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:11:18 --> Final output sent to browser
DEBUG - 2020-04-04 16:11:18 --> Total execution time: 0.8633
INFO - 2020-04-04 16:11:19 --> Config Class Initialized
INFO - 2020-04-04 16:11:19 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:11:19 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:11:19 --> Utf8 Class Initialized
INFO - 2020-04-04 16:11:19 --> URI Class Initialized
INFO - 2020-04-04 16:11:19 --> Router Class Initialized
INFO - 2020-04-04 16:11:19 --> Output Class Initialized
INFO - 2020-04-04 16:11:19 --> Security Class Initialized
DEBUG - 2020-04-04 16:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:11:19 --> CSRF cookie sent
INFO - 2020-04-04 16:11:19 --> Input Class Initialized
INFO - 2020-04-04 16:11:19 --> Language Class Initialized
ERROR - 2020-04-04 16:11:19 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:11:19 --> Config Class Initialized
INFO - 2020-04-04 16:11:19 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:11:19 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:11:19 --> Utf8 Class Initialized
INFO - 2020-04-04 16:11:19 --> URI Class Initialized
INFO - 2020-04-04 16:11:19 --> Router Class Initialized
INFO - 2020-04-04 16:11:19 --> Output Class Initialized
INFO - 2020-04-04 16:11:19 --> Security Class Initialized
DEBUG - 2020-04-04 16:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:11:19 --> CSRF cookie sent
INFO - 2020-04-04 16:11:19 --> Input Class Initialized
INFO - 2020-04-04 16:11:19 --> Language Class Initialized
ERROR - 2020-04-04 16:11:19 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:11:46 --> Config Class Initialized
INFO - 2020-04-04 16:11:46 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:11:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:11:46 --> Utf8 Class Initialized
INFO - 2020-04-04 16:11:46 --> URI Class Initialized
INFO - 2020-04-04 16:11:46 --> Router Class Initialized
INFO - 2020-04-04 16:11:46 --> Output Class Initialized
INFO - 2020-04-04 16:11:46 --> Security Class Initialized
DEBUG - 2020-04-04 16:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:11:46 --> CSRF cookie sent
INFO - 2020-04-04 16:11:46 --> Input Class Initialized
INFO - 2020-04-04 16:11:46 --> Language Class Initialized
INFO - 2020-04-04 16:11:46 --> Language Class Initialized
INFO - 2020-04-04 16:11:46 --> Config Class Initialized
INFO - 2020-04-04 16:11:46 --> Loader Class Initialized
INFO - 2020-04-04 16:11:46 --> Helper loaded: url_helper
INFO - 2020-04-04 16:11:46 --> Helper loaded: file_helper
INFO - 2020-04-04 16:11:46 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:11:46 --> Helper loaded: common_helper
INFO - 2020-04-04 16:11:46 --> Helper loaded: language_helper
INFO - 2020-04-04 16:11:46 --> Helper loaded: email_helper
INFO - 2020-04-04 16:11:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:11:46 --> Database Driver Class Initialized
INFO - 2020-04-04 16:11:46 --> Parser Class Initialized
INFO - 2020-04-04 16:11:46 --> User Agent Class Initialized
INFO - 2020-04-04 16:11:46 --> Model Class Initialized
INFO - 2020-04-04 16:11:46 --> Model Class Initialized
DEBUG - 2020-04-04 16:11:46 --> Template Class Initialized
INFO - 2020-04-04 16:11:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:11:47 --> Email Class Initialized
INFO - 2020-04-04 16:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:11:47 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:11:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:11:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:11:47 --> Encryption Class Initialized
INFO - 2020-04-04 16:11:47 --> Controller Class Initialized
DEBUG - 2020-04-04 16:11:47 --> post MX_Controller Initialized
INFO - 2020-04-04 16:11:47 --> Model Class Initialized
ERROR - 2020-04-04 16:11:47 --> Could not find the language line ""
ERROR - 2020-04-04 16:11:47 --> Could not find the language line ""
ERROR - 2020-04-04 16:11:47 --> Could not find the language line ""
DEBUG - 2020-04-04 16:11:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:11:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:11:47 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:11:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:11:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:11:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:11:47 --> Final output sent to browser
DEBUG - 2020-04-04 16:11:47 --> Total execution time: 0.8343
INFO - 2020-04-04 16:11:47 --> Config Class Initialized
INFO - 2020-04-04 16:11:47 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:11:47 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:11:47 --> Utf8 Class Initialized
INFO - 2020-04-04 16:11:47 --> URI Class Initialized
INFO - 2020-04-04 16:11:47 --> Router Class Initialized
INFO - 2020-04-04 16:11:47 --> Output Class Initialized
INFO - 2020-04-04 16:11:47 --> Security Class Initialized
DEBUG - 2020-04-04 16:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:11:47 --> CSRF cookie sent
INFO - 2020-04-04 16:11:47 --> Input Class Initialized
INFO - 2020-04-04 16:11:47 --> Language Class Initialized
ERROR - 2020-04-04 16:11:47 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:11:48 --> Config Class Initialized
INFO - 2020-04-04 16:11:48 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:11:48 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:11:48 --> Utf8 Class Initialized
INFO - 2020-04-04 16:11:48 --> URI Class Initialized
INFO - 2020-04-04 16:11:48 --> Router Class Initialized
INFO - 2020-04-04 16:11:48 --> Output Class Initialized
INFO - 2020-04-04 16:11:48 --> Security Class Initialized
DEBUG - 2020-04-04 16:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:11:48 --> CSRF cookie sent
INFO - 2020-04-04 16:11:48 --> Input Class Initialized
INFO - 2020-04-04 16:11:48 --> Language Class Initialized
ERROR - 2020-04-04 16:11:48 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:11:57 --> Config Class Initialized
INFO - 2020-04-04 16:11:57 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:11:57 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:11:57 --> Utf8 Class Initialized
INFO - 2020-04-04 16:11:57 --> URI Class Initialized
INFO - 2020-04-04 16:11:57 --> Router Class Initialized
INFO - 2020-04-04 16:11:57 --> Output Class Initialized
INFO - 2020-04-04 16:11:57 --> Security Class Initialized
DEBUG - 2020-04-04 16:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:11:57 --> CSRF cookie sent
INFO - 2020-04-04 16:11:57 --> Input Class Initialized
INFO - 2020-04-04 16:11:57 --> Language Class Initialized
INFO - 2020-04-04 16:11:57 --> Language Class Initialized
INFO - 2020-04-04 16:11:57 --> Config Class Initialized
INFO - 2020-04-04 16:11:57 --> Loader Class Initialized
INFO - 2020-04-04 16:11:57 --> Helper loaded: url_helper
INFO - 2020-04-04 16:11:57 --> Helper loaded: file_helper
INFO - 2020-04-04 16:11:57 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:11:57 --> Helper loaded: common_helper
INFO - 2020-04-04 16:11:57 --> Helper loaded: language_helper
INFO - 2020-04-04 16:11:57 --> Helper loaded: email_helper
INFO - 2020-04-04 16:11:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:11:57 --> Database Driver Class Initialized
INFO - 2020-04-04 16:11:57 --> Parser Class Initialized
INFO - 2020-04-04 16:11:57 --> User Agent Class Initialized
INFO - 2020-04-04 16:11:57 --> Model Class Initialized
INFO - 2020-04-04 16:11:57 --> Model Class Initialized
DEBUG - 2020-04-04 16:11:57 --> Template Class Initialized
INFO - 2020-04-04 16:11:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:11:57 --> Email Class Initialized
INFO - 2020-04-04 16:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:11:57 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:11:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:11:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:11:57 --> Encryption Class Initialized
INFO - 2020-04-04 16:11:57 --> Controller Class Initialized
DEBUG - 2020-04-04 16:11:57 --> post MX_Controller Initialized
INFO - 2020-04-04 16:11:57 --> Model Class Initialized
ERROR - 2020-04-04 16:11:57 --> Could not find the language line ""
ERROR - 2020-04-04 16:11:57 --> Could not find the language line ""
ERROR - 2020-04-04 16:11:57 --> Could not find the language line ""
DEBUG - 2020-04-04 16:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:11:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:11:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:11:58 --> Final output sent to browser
DEBUG - 2020-04-04 16:11:58 --> Total execution time: 0.9149
INFO - 2020-04-04 16:12:12 --> Config Class Initialized
INFO - 2020-04-04 16:12:12 --> Config Class Initialized
INFO - 2020-04-04 16:12:12 --> Hooks Class Initialized
INFO - 2020-04-04 16:12:12 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:12:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 16:12:12 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:12:12 --> Utf8 Class Initialized
INFO - 2020-04-04 16:12:12 --> Utf8 Class Initialized
INFO - 2020-04-04 16:12:12 --> URI Class Initialized
INFO - 2020-04-04 16:12:12 --> URI Class Initialized
INFO - 2020-04-04 16:12:12 --> Router Class Initialized
INFO - 2020-04-04 16:12:12 --> Router Class Initialized
INFO - 2020-04-04 16:12:12 --> Output Class Initialized
INFO - 2020-04-04 16:12:12 --> Output Class Initialized
INFO - 2020-04-04 16:12:12 --> Security Class Initialized
INFO - 2020-04-04 16:12:12 --> Security Class Initialized
DEBUG - 2020-04-04 16:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 16:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:12:12 --> CSRF cookie sent
INFO - 2020-04-04 16:12:12 --> CSRF cookie sent
INFO - 2020-04-04 16:12:12 --> Input Class Initialized
INFO - 2020-04-04 16:12:12 --> Input Class Initialized
INFO - 2020-04-04 16:12:12 --> Language Class Initialized
INFO - 2020-04-04 16:12:12 --> Language Class Initialized
ERROR - 2020-04-04 16:12:12 --> 404 Page Not Found: /index
ERROR - 2020-04-04 16:12:12 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:12:30 --> Config Class Initialized
INFO - 2020-04-04 16:12:30 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:12:30 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:12:30 --> Utf8 Class Initialized
INFO - 2020-04-04 16:12:30 --> URI Class Initialized
INFO - 2020-04-04 16:12:30 --> Router Class Initialized
INFO - 2020-04-04 16:12:30 --> Output Class Initialized
INFO - 2020-04-04 16:12:30 --> Security Class Initialized
DEBUG - 2020-04-04 16:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:12:30 --> CSRF cookie sent
INFO - 2020-04-04 16:12:30 --> Input Class Initialized
INFO - 2020-04-04 16:12:30 --> Language Class Initialized
INFO - 2020-04-04 16:12:30 --> Language Class Initialized
INFO - 2020-04-04 16:12:30 --> Config Class Initialized
INFO - 2020-04-04 16:12:30 --> Loader Class Initialized
INFO - 2020-04-04 16:12:30 --> Helper loaded: url_helper
INFO - 2020-04-04 16:12:30 --> Helper loaded: file_helper
INFO - 2020-04-04 16:12:30 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:12:30 --> Helper loaded: common_helper
INFO - 2020-04-04 16:12:30 --> Helper loaded: language_helper
INFO - 2020-04-04 16:12:30 --> Helper loaded: email_helper
INFO - 2020-04-04 16:12:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:12:30 --> Database Driver Class Initialized
INFO - 2020-04-04 16:12:31 --> Parser Class Initialized
INFO - 2020-04-04 16:12:31 --> User Agent Class Initialized
INFO - 2020-04-04 16:12:31 --> Model Class Initialized
INFO - 2020-04-04 16:12:31 --> Model Class Initialized
DEBUG - 2020-04-04 16:12:31 --> Template Class Initialized
INFO - 2020-04-04 16:12:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:12:31 --> Email Class Initialized
INFO - 2020-04-04 16:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:12:31 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:12:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:12:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:12:31 --> Encryption Class Initialized
INFO - 2020-04-04 16:12:31 --> Controller Class Initialized
DEBUG - 2020-04-04 16:12:31 --> post MX_Controller Initialized
INFO - 2020-04-04 16:12:31 --> Model Class Initialized
ERROR - 2020-04-04 16:12:31 --> Could not find the language line ""
ERROR - 2020-04-04 16:12:31 --> Could not find the language line ""
ERROR - 2020-04-04 16:12:31 --> Could not find the language line ""
DEBUG - 2020-04-04 16:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:12:31 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:12:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:12:31 --> Final output sent to browser
DEBUG - 2020-04-04 16:12:31 --> Total execution time: 0.8423
INFO - 2020-04-04 16:12:31 --> Config Class Initialized
INFO - 2020-04-04 16:12:31 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:12:31 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:12:31 --> Utf8 Class Initialized
INFO - 2020-04-04 16:12:31 --> URI Class Initialized
INFO - 2020-04-04 16:12:31 --> Config Class Initialized
INFO - 2020-04-04 16:12:31 --> Hooks Class Initialized
INFO - 2020-04-04 16:12:31 --> Router Class Initialized
INFO - 2020-04-04 16:12:31 --> Output Class Initialized
DEBUG - 2020-04-04 16:12:31 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:12:31 --> Utf8 Class Initialized
INFO - 2020-04-04 16:12:31 --> Security Class Initialized
INFO - 2020-04-04 16:12:31 --> URI Class Initialized
DEBUG - 2020-04-04 16:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:12:31 --> CSRF cookie sent
INFO - 2020-04-04 16:12:31 --> Router Class Initialized
INFO - 2020-04-04 16:12:32 --> Input Class Initialized
INFO - 2020-04-04 16:12:32 --> Output Class Initialized
INFO - 2020-04-04 16:12:32 --> Language Class Initialized
INFO - 2020-04-04 16:12:32 --> Security Class Initialized
ERROR - 2020-04-04 16:12:32 --> 404 Page Not Found: /index
DEBUG - 2020-04-04 16:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:12:32 --> CSRF cookie sent
INFO - 2020-04-04 16:12:32 --> Input Class Initialized
INFO - 2020-04-04 16:12:32 --> Language Class Initialized
ERROR - 2020-04-04 16:12:32 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:13:24 --> Config Class Initialized
INFO - 2020-04-04 16:13:24 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:13:24 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:13:24 --> Utf8 Class Initialized
INFO - 2020-04-04 16:13:24 --> URI Class Initialized
INFO - 2020-04-04 16:13:24 --> Router Class Initialized
INFO - 2020-04-04 16:13:24 --> Output Class Initialized
INFO - 2020-04-04 16:13:24 --> Security Class Initialized
DEBUG - 2020-04-04 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:13:24 --> CSRF cookie sent
INFO - 2020-04-04 16:13:24 --> Input Class Initialized
INFO - 2020-04-04 16:13:24 --> Language Class Initialized
INFO - 2020-04-04 16:13:24 --> Language Class Initialized
INFO - 2020-04-04 16:13:24 --> Config Class Initialized
INFO - 2020-04-04 16:13:24 --> Loader Class Initialized
INFO - 2020-04-04 16:13:24 --> Helper loaded: url_helper
INFO - 2020-04-04 16:13:24 --> Helper loaded: file_helper
INFO - 2020-04-04 16:13:25 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:13:25 --> Helper loaded: common_helper
INFO - 2020-04-04 16:13:25 --> Helper loaded: language_helper
INFO - 2020-04-04 16:13:25 --> Helper loaded: email_helper
INFO - 2020-04-04 16:13:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:13:25 --> Database Driver Class Initialized
INFO - 2020-04-04 16:13:25 --> Parser Class Initialized
INFO - 2020-04-04 16:13:25 --> User Agent Class Initialized
INFO - 2020-04-04 16:13:25 --> Model Class Initialized
INFO - 2020-04-04 16:13:25 --> Model Class Initialized
DEBUG - 2020-04-04 16:13:25 --> Template Class Initialized
INFO - 2020-04-04 16:13:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:13:25 --> Email Class Initialized
INFO - 2020-04-04 16:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:13:25 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:13:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:13:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:13:25 --> Encryption Class Initialized
INFO - 2020-04-04 16:13:25 --> Controller Class Initialized
DEBUG - 2020-04-04 16:13:25 --> post MX_Controller Initialized
INFO - 2020-04-04 16:13:25 --> Model Class Initialized
ERROR - 2020-04-04 16:13:25 --> Could not find the language line ""
ERROR - 2020-04-04 16:13:25 --> Could not find the language line ""
ERROR - 2020-04-04 16:13:25 --> Could not find the language line ""
DEBUG - 2020-04-04 16:13:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:13:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:13:25 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:13:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:13:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:13:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:13:25 --> Final output sent to browser
DEBUG - 2020-04-04 16:13:25 --> Total execution time: 0.8091
INFO - 2020-04-04 16:13:25 --> Config Class Initialized
INFO - 2020-04-04 16:13:25 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:13:25 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:13:25 --> Utf8 Class Initialized
INFO - 2020-04-04 16:13:25 --> URI Class Initialized
INFO - 2020-04-04 16:13:25 --> Config Class Initialized
INFO - 2020-04-04 16:13:25 --> Hooks Class Initialized
INFO - 2020-04-04 16:13:25 --> Router Class Initialized
INFO - 2020-04-04 16:13:25 --> Output Class Initialized
DEBUG - 2020-04-04 16:13:25 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:13:25 --> Utf8 Class Initialized
INFO - 2020-04-04 16:13:25 --> Security Class Initialized
INFO - 2020-04-04 16:13:26 --> URI Class Initialized
DEBUG - 2020-04-04 16:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:13:26 --> CSRF cookie sent
INFO - 2020-04-04 16:13:26 --> Router Class Initialized
INFO - 2020-04-04 16:13:26 --> Input Class Initialized
INFO - 2020-04-04 16:13:26 --> Output Class Initialized
INFO - 2020-04-04 16:13:26 --> Language Class Initialized
INFO - 2020-04-04 16:13:26 --> Security Class Initialized
ERROR - 2020-04-04 16:13:26 --> 404 Page Not Found: /index
DEBUG - 2020-04-04 16:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:13:26 --> CSRF cookie sent
INFO - 2020-04-04 16:13:26 --> Input Class Initialized
INFO - 2020-04-04 16:13:26 --> Language Class Initialized
ERROR - 2020-04-04 16:13:26 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:14:43 --> Config Class Initialized
INFO - 2020-04-04 16:14:43 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:14:43 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:14:43 --> Utf8 Class Initialized
INFO - 2020-04-04 16:14:43 --> URI Class Initialized
INFO - 2020-04-04 16:14:43 --> Router Class Initialized
INFO - 2020-04-04 16:14:43 --> Output Class Initialized
INFO - 2020-04-04 16:14:43 --> Security Class Initialized
DEBUG - 2020-04-04 16:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:14:43 --> CSRF cookie sent
INFO - 2020-04-04 16:14:43 --> Input Class Initialized
INFO - 2020-04-04 16:14:43 --> Language Class Initialized
INFO - 2020-04-04 16:14:43 --> Language Class Initialized
INFO - 2020-04-04 16:14:43 --> Config Class Initialized
INFO - 2020-04-04 16:14:43 --> Loader Class Initialized
INFO - 2020-04-04 16:14:43 --> Helper loaded: url_helper
INFO - 2020-04-04 16:14:43 --> Helper loaded: file_helper
INFO - 2020-04-04 16:14:43 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:14:43 --> Helper loaded: common_helper
INFO - 2020-04-04 16:14:43 --> Helper loaded: language_helper
INFO - 2020-04-04 16:14:43 --> Helper loaded: email_helper
INFO - 2020-04-04 16:14:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:14:43 --> Database Driver Class Initialized
INFO - 2020-04-04 16:14:44 --> Parser Class Initialized
INFO - 2020-04-04 16:14:44 --> User Agent Class Initialized
INFO - 2020-04-04 16:14:44 --> Model Class Initialized
INFO - 2020-04-04 16:14:44 --> Model Class Initialized
DEBUG - 2020-04-04 16:14:44 --> Template Class Initialized
INFO - 2020-04-04 16:14:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:14:44 --> Email Class Initialized
INFO - 2020-04-04 16:14:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:14:44 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:14:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:14:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:14:44 --> Encryption Class Initialized
INFO - 2020-04-04 16:14:44 --> Controller Class Initialized
DEBUG - 2020-04-04 16:14:44 --> post MX_Controller Initialized
INFO - 2020-04-04 16:14:44 --> Model Class Initialized
ERROR - 2020-04-04 16:14:44 --> Could not find the language line ""
ERROR - 2020-04-04 16:14:44 --> Could not find the language line ""
ERROR - 2020-04-04 16:14:44 --> Could not find the language line ""
DEBUG - 2020-04-04 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:14:44 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:14:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:14:44 --> Final output sent to browser
DEBUG - 2020-04-04 16:14:44 --> Total execution time: 0.8849
INFO - 2020-04-04 16:14:44 --> Config Class Initialized
INFO - 2020-04-04 16:14:44 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:14:44 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:14:44 --> Utf8 Class Initialized
INFO - 2020-04-04 16:14:44 --> URI Class Initialized
INFO - 2020-04-04 16:14:44 --> Router Class Initialized
INFO - 2020-04-04 16:14:44 --> Output Class Initialized
INFO - 2020-04-04 16:14:44 --> Security Class Initialized
DEBUG - 2020-04-04 16:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:14:45 --> CSRF cookie sent
INFO - 2020-04-04 16:14:45 --> Input Class Initialized
INFO - 2020-04-04 16:14:45 --> Language Class Initialized
ERROR - 2020-04-04 16:14:45 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:14:45 --> Config Class Initialized
INFO - 2020-04-04 16:14:45 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:14:45 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:14:45 --> Utf8 Class Initialized
INFO - 2020-04-04 16:14:45 --> URI Class Initialized
INFO - 2020-04-04 16:14:45 --> Router Class Initialized
INFO - 2020-04-04 16:14:45 --> Output Class Initialized
INFO - 2020-04-04 16:14:45 --> Security Class Initialized
DEBUG - 2020-04-04 16:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:14:45 --> CSRF cookie sent
INFO - 2020-04-04 16:14:45 --> Input Class Initialized
INFO - 2020-04-04 16:14:45 --> Language Class Initialized
ERROR - 2020-04-04 16:14:45 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:16:05 --> Config Class Initialized
INFO - 2020-04-04 16:16:05 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:16:05 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:16:05 --> Utf8 Class Initialized
INFO - 2020-04-04 16:16:05 --> URI Class Initialized
INFO - 2020-04-04 16:16:05 --> Router Class Initialized
INFO - 2020-04-04 16:16:05 --> Output Class Initialized
INFO - 2020-04-04 16:16:05 --> Security Class Initialized
DEBUG - 2020-04-04 16:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:16:05 --> CSRF cookie sent
INFO - 2020-04-04 16:16:05 --> Input Class Initialized
INFO - 2020-04-04 16:16:05 --> Language Class Initialized
INFO - 2020-04-04 16:16:05 --> Language Class Initialized
INFO - 2020-04-04 16:16:05 --> Config Class Initialized
INFO - 2020-04-04 16:16:05 --> Loader Class Initialized
INFO - 2020-04-04 16:16:05 --> Helper loaded: url_helper
INFO - 2020-04-04 16:16:05 --> Helper loaded: file_helper
INFO - 2020-04-04 16:16:05 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:16:05 --> Helper loaded: common_helper
INFO - 2020-04-04 16:16:05 --> Helper loaded: language_helper
INFO - 2020-04-04 16:16:05 --> Helper loaded: email_helper
INFO - 2020-04-04 16:16:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:16:05 --> Database Driver Class Initialized
INFO - 2020-04-04 16:16:05 --> Parser Class Initialized
INFO - 2020-04-04 16:16:05 --> User Agent Class Initialized
INFO - 2020-04-04 16:16:05 --> Model Class Initialized
INFO - 2020-04-04 16:16:05 --> Model Class Initialized
DEBUG - 2020-04-04 16:16:05 --> Template Class Initialized
INFO - 2020-04-04 16:16:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:16:05 --> Email Class Initialized
INFO - 2020-04-04 16:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:16:05 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:16:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:16:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:16:05 --> Encryption Class Initialized
INFO - 2020-04-04 16:16:06 --> Controller Class Initialized
DEBUG - 2020-04-04 16:16:06 --> post MX_Controller Initialized
INFO - 2020-04-04 16:16:06 --> Model Class Initialized
ERROR - 2020-04-04 16:16:06 --> Could not find the language line ""
ERROR - 2020-04-04 16:16:06 --> Could not find the language line ""
ERROR - 2020-04-04 16:16:06 --> Could not find the language line ""
DEBUG - 2020-04-04 16:16:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:16:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:16:06 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:16:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:16:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:16:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:16:06 --> Final output sent to browser
DEBUG - 2020-04-04 16:16:06 --> Total execution time: 0.8338
INFO - 2020-04-04 16:16:06 --> Config Class Initialized
INFO - 2020-04-04 16:16:06 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:16:06 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:16:06 --> Utf8 Class Initialized
INFO - 2020-04-04 16:16:06 --> URI Class Initialized
INFO - 2020-04-04 16:16:06 --> Router Class Initialized
INFO - 2020-04-04 16:16:06 --> Output Class Initialized
INFO - 2020-04-04 16:16:06 --> Security Class Initialized
DEBUG - 2020-04-04 16:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:16:06 --> CSRF cookie sent
INFO - 2020-04-04 16:16:06 --> Input Class Initialized
INFO - 2020-04-04 16:16:06 --> Language Class Initialized
ERROR - 2020-04-04 16:16:06 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:16:06 --> Config Class Initialized
INFO - 2020-04-04 16:16:06 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:16:06 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:16:07 --> Utf8 Class Initialized
INFO - 2020-04-04 16:16:07 --> URI Class Initialized
INFO - 2020-04-04 16:16:07 --> Router Class Initialized
INFO - 2020-04-04 16:16:07 --> Output Class Initialized
INFO - 2020-04-04 16:16:07 --> Security Class Initialized
DEBUG - 2020-04-04 16:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:16:07 --> CSRF cookie sent
INFO - 2020-04-04 16:16:07 --> Input Class Initialized
INFO - 2020-04-04 16:16:07 --> Language Class Initialized
ERROR - 2020-04-04 16:16:07 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:17:19 --> Config Class Initialized
INFO - 2020-04-04 16:17:19 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:17:19 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:17:19 --> Utf8 Class Initialized
INFO - 2020-04-04 16:17:19 --> URI Class Initialized
INFO - 2020-04-04 16:17:20 --> Router Class Initialized
INFO - 2020-04-04 16:17:20 --> Output Class Initialized
INFO - 2020-04-04 16:17:20 --> Security Class Initialized
DEBUG - 2020-04-04 16:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:17:20 --> CSRF cookie sent
INFO - 2020-04-04 16:17:20 --> Input Class Initialized
INFO - 2020-04-04 16:17:20 --> Language Class Initialized
INFO - 2020-04-04 16:17:20 --> Language Class Initialized
INFO - 2020-04-04 16:17:20 --> Config Class Initialized
INFO - 2020-04-04 16:17:20 --> Loader Class Initialized
INFO - 2020-04-04 16:17:20 --> Helper loaded: url_helper
INFO - 2020-04-04 16:17:20 --> Helper loaded: file_helper
INFO - 2020-04-04 16:17:20 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:17:20 --> Helper loaded: common_helper
INFO - 2020-04-04 16:17:20 --> Helper loaded: language_helper
INFO - 2020-04-04 16:17:20 --> Helper loaded: email_helper
INFO - 2020-04-04 16:17:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:17:20 --> Database Driver Class Initialized
INFO - 2020-04-04 16:17:20 --> Parser Class Initialized
INFO - 2020-04-04 16:17:20 --> User Agent Class Initialized
INFO - 2020-04-04 16:17:20 --> Model Class Initialized
INFO - 2020-04-04 16:17:20 --> Model Class Initialized
DEBUG - 2020-04-04 16:17:20 --> Template Class Initialized
INFO - 2020-04-04 16:17:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:17:20 --> Email Class Initialized
INFO - 2020-04-04 16:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:17:20 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:17:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:17:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:17:20 --> Encryption Class Initialized
INFO - 2020-04-04 16:17:20 --> Controller Class Initialized
DEBUG - 2020-04-04 16:17:20 --> post MX_Controller Initialized
INFO - 2020-04-04 16:17:20 --> Model Class Initialized
ERROR - 2020-04-04 16:17:20 --> Could not find the language line ""
ERROR - 2020-04-04 16:17:20 --> Could not find the language line ""
ERROR - 2020-04-04 16:17:20 --> Could not find the language line ""
DEBUG - 2020-04-04 16:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:17:20 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:17:20 --> Final output sent to browser
DEBUG - 2020-04-04 16:17:20 --> Total execution time: 0.8355
INFO - 2020-04-04 16:17:21 --> Config Class Initialized
INFO - 2020-04-04 16:17:21 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:17:21 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:17:21 --> Utf8 Class Initialized
INFO - 2020-04-04 16:17:21 --> URI Class Initialized
INFO - 2020-04-04 16:17:21 --> Router Class Initialized
INFO - 2020-04-04 16:17:21 --> Output Class Initialized
INFO - 2020-04-04 16:17:21 --> Security Class Initialized
DEBUG - 2020-04-04 16:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:17:21 --> CSRF cookie sent
INFO - 2020-04-04 16:17:21 --> Input Class Initialized
INFO - 2020-04-04 16:17:21 --> Language Class Initialized
ERROR - 2020-04-04 16:17:21 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:17:21 --> Config Class Initialized
INFO - 2020-04-04 16:17:21 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:17:21 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:17:21 --> Utf8 Class Initialized
INFO - 2020-04-04 16:17:21 --> URI Class Initialized
INFO - 2020-04-04 16:17:21 --> Router Class Initialized
INFO - 2020-04-04 16:17:21 --> Output Class Initialized
INFO - 2020-04-04 16:17:21 --> Security Class Initialized
DEBUG - 2020-04-04 16:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:17:21 --> CSRF cookie sent
INFO - 2020-04-04 16:17:21 --> Input Class Initialized
INFO - 2020-04-04 16:17:21 --> Language Class Initialized
ERROR - 2020-04-04 16:17:21 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:17:50 --> Config Class Initialized
INFO - 2020-04-04 16:17:50 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:17:50 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:17:50 --> Utf8 Class Initialized
INFO - 2020-04-04 16:17:50 --> URI Class Initialized
INFO - 2020-04-04 16:17:50 --> Router Class Initialized
INFO - 2020-04-04 16:17:50 --> Output Class Initialized
INFO - 2020-04-04 16:17:50 --> Security Class Initialized
DEBUG - 2020-04-04 16:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:17:50 --> CSRF cookie sent
INFO - 2020-04-04 16:17:50 --> Input Class Initialized
INFO - 2020-04-04 16:17:50 --> Language Class Initialized
INFO - 2020-04-04 16:17:50 --> Language Class Initialized
INFO - 2020-04-04 16:17:50 --> Config Class Initialized
INFO - 2020-04-04 16:17:50 --> Loader Class Initialized
INFO - 2020-04-04 16:17:51 --> Helper loaded: url_helper
INFO - 2020-04-04 16:17:51 --> Helper loaded: file_helper
INFO - 2020-04-04 16:17:51 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:17:51 --> Helper loaded: common_helper
INFO - 2020-04-04 16:17:51 --> Helper loaded: language_helper
INFO - 2020-04-04 16:17:51 --> Helper loaded: email_helper
INFO - 2020-04-04 16:17:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:17:51 --> Database Driver Class Initialized
INFO - 2020-04-04 16:17:51 --> Parser Class Initialized
INFO - 2020-04-04 16:17:51 --> User Agent Class Initialized
INFO - 2020-04-04 16:17:51 --> Model Class Initialized
INFO - 2020-04-04 16:17:51 --> Model Class Initialized
DEBUG - 2020-04-04 16:17:51 --> Template Class Initialized
INFO - 2020-04-04 16:17:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:17:51 --> Email Class Initialized
INFO - 2020-04-04 16:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:17:51 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:17:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:17:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:17:51 --> Encryption Class Initialized
INFO - 2020-04-04 16:17:51 --> Controller Class Initialized
DEBUG - 2020-04-04 16:17:51 --> post MX_Controller Initialized
INFO - 2020-04-04 16:17:51 --> Model Class Initialized
ERROR - 2020-04-04 16:17:51 --> Could not find the language line ""
ERROR - 2020-04-04 16:17:51 --> Could not find the language line ""
ERROR - 2020-04-04 16:17:51 --> Could not find the language line ""
DEBUG - 2020-04-04 16:17:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:17:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:17:51 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:17:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:17:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:17:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:17:51 --> Final output sent to browser
DEBUG - 2020-04-04 16:17:51 --> Total execution time: 0.8508
INFO - 2020-04-04 16:17:51 --> Config Class Initialized
INFO - 2020-04-04 16:17:51 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:17:51 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:17:52 --> Utf8 Class Initialized
INFO - 2020-04-04 16:17:52 --> URI Class Initialized
INFO - 2020-04-04 16:17:52 --> Router Class Initialized
INFO - 2020-04-04 16:17:52 --> Output Class Initialized
INFO - 2020-04-04 16:17:52 --> Security Class Initialized
DEBUG - 2020-04-04 16:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:17:52 --> CSRF cookie sent
INFO - 2020-04-04 16:17:52 --> Input Class Initialized
INFO - 2020-04-04 16:17:52 --> Language Class Initialized
ERROR - 2020-04-04 16:17:52 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:17:52 --> Config Class Initialized
INFO - 2020-04-04 16:17:52 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:17:52 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:17:52 --> Utf8 Class Initialized
INFO - 2020-04-04 16:17:52 --> URI Class Initialized
INFO - 2020-04-04 16:17:52 --> Router Class Initialized
INFO - 2020-04-04 16:17:52 --> Output Class Initialized
INFO - 2020-04-04 16:17:52 --> Security Class Initialized
DEBUG - 2020-04-04 16:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:17:52 --> CSRF cookie sent
INFO - 2020-04-04 16:17:52 --> Input Class Initialized
INFO - 2020-04-04 16:17:52 --> Language Class Initialized
ERROR - 2020-04-04 16:17:52 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:17:58 --> Config Class Initialized
INFO - 2020-04-04 16:17:58 --> Config Class Initialized
INFO - 2020-04-04 16:17:58 --> Hooks Class Initialized
INFO - 2020-04-04 16:17:58 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:17:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 16:17:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:17:58 --> Utf8 Class Initialized
INFO - 2020-04-04 16:17:58 --> Utf8 Class Initialized
INFO - 2020-04-04 16:17:58 --> URI Class Initialized
INFO - 2020-04-04 16:17:58 --> URI Class Initialized
INFO - 2020-04-04 16:17:58 --> Router Class Initialized
INFO - 2020-04-04 16:17:58 --> Router Class Initialized
INFO - 2020-04-04 16:17:58 --> Output Class Initialized
INFO - 2020-04-04 16:17:58 --> Output Class Initialized
INFO - 2020-04-04 16:17:58 --> Security Class Initialized
INFO - 2020-04-04 16:17:58 --> Security Class Initialized
DEBUG - 2020-04-04 16:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 16:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:17:58 --> CSRF cookie sent
INFO - 2020-04-04 16:17:58 --> CSRF cookie sent
INFO - 2020-04-04 16:17:58 --> Input Class Initialized
INFO - 2020-04-04 16:17:58 --> Input Class Initialized
INFO - 2020-04-04 16:17:58 --> Language Class Initialized
INFO - 2020-04-04 16:17:58 --> Language Class Initialized
ERROR - 2020-04-04 16:17:58 --> 404 Page Not Found: /index
ERROR - 2020-04-04 16:17:58 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:19:44 --> Config Class Initialized
INFO - 2020-04-04 16:19:44 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:19:44 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:19:44 --> Utf8 Class Initialized
INFO - 2020-04-04 16:19:44 --> URI Class Initialized
INFO - 2020-04-04 16:19:44 --> Router Class Initialized
INFO - 2020-04-04 16:19:44 --> Output Class Initialized
INFO - 2020-04-04 16:19:44 --> Security Class Initialized
DEBUG - 2020-04-04 16:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:19:44 --> CSRF cookie sent
INFO - 2020-04-04 16:19:44 --> Input Class Initialized
INFO - 2020-04-04 16:19:44 --> Language Class Initialized
INFO - 2020-04-04 16:19:44 --> Language Class Initialized
INFO - 2020-04-04 16:19:44 --> Config Class Initialized
INFO - 2020-04-04 16:19:44 --> Loader Class Initialized
INFO - 2020-04-04 16:19:45 --> Helper loaded: url_helper
INFO - 2020-04-04 16:19:45 --> Helper loaded: file_helper
INFO - 2020-04-04 16:19:45 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:19:45 --> Helper loaded: common_helper
INFO - 2020-04-04 16:19:45 --> Helper loaded: language_helper
INFO - 2020-04-04 16:19:45 --> Helper loaded: email_helper
INFO - 2020-04-04 16:19:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:19:45 --> Database Driver Class Initialized
INFO - 2020-04-04 16:19:45 --> Parser Class Initialized
INFO - 2020-04-04 16:19:45 --> User Agent Class Initialized
INFO - 2020-04-04 16:19:45 --> Model Class Initialized
INFO - 2020-04-04 16:19:45 --> Model Class Initialized
DEBUG - 2020-04-04 16:19:45 --> Template Class Initialized
INFO - 2020-04-04 16:19:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:19:45 --> Email Class Initialized
INFO - 2020-04-04 16:19:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:19:45 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:19:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:19:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:19:45 --> Encryption Class Initialized
INFO - 2020-04-04 16:19:45 --> Controller Class Initialized
DEBUG - 2020-04-04 16:19:45 --> post MX_Controller Initialized
INFO - 2020-04-04 16:19:45 --> Model Class Initialized
ERROR - 2020-04-04 16:19:45 --> Could not find the language line ""
ERROR - 2020-04-04 16:19:45 --> Could not find the language line ""
ERROR - 2020-04-04 16:19:45 --> Could not find the language line ""
DEBUG - 2020-04-04 16:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:19:45 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:19:45 --> Final output sent to browser
DEBUG - 2020-04-04 16:19:45 --> Total execution time: 0.8524
INFO - 2020-04-04 16:19:45 --> Config Class Initialized
INFO - 2020-04-04 16:19:45 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:19:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:19:46 --> Utf8 Class Initialized
INFO - 2020-04-04 16:19:46 --> URI Class Initialized
INFO - 2020-04-04 16:19:46 --> Config Class Initialized
INFO - 2020-04-04 16:19:46 --> Hooks Class Initialized
INFO - 2020-04-04 16:19:46 --> Router Class Initialized
INFO - 2020-04-04 16:19:46 --> Output Class Initialized
DEBUG - 2020-04-04 16:19:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:19:46 --> Utf8 Class Initialized
INFO - 2020-04-04 16:19:46 --> Security Class Initialized
INFO - 2020-04-04 16:19:46 --> URI Class Initialized
DEBUG - 2020-04-04 16:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:19:46 --> CSRF cookie sent
INFO - 2020-04-04 16:19:46 --> Router Class Initialized
INFO - 2020-04-04 16:19:46 --> Input Class Initialized
INFO - 2020-04-04 16:19:46 --> Output Class Initialized
INFO - 2020-04-04 16:19:46 --> Language Class Initialized
INFO - 2020-04-04 16:19:46 --> Security Class Initialized
ERROR - 2020-04-04 16:19:46 --> 404 Page Not Found: /index
DEBUG - 2020-04-04 16:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:19:46 --> CSRF cookie sent
INFO - 2020-04-04 16:19:46 --> Input Class Initialized
INFO - 2020-04-04 16:19:46 --> Language Class Initialized
ERROR - 2020-04-04 16:19:46 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:19:55 --> Config Class Initialized
INFO - 2020-04-04 16:19:55 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:19:55 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:19:55 --> Utf8 Class Initialized
INFO - 2020-04-04 16:19:55 --> URI Class Initialized
INFO - 2020-04-04 16:19:55 --> Router Class Initialized
INFO - 2020-04-04 16:19:55 --> Output Class Initialized
INFO - 2020-04-04 16:19:55 --> Security Class Initialized
DEBUG - 2020-04-04 16:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:19:55 --> CSRF cookie sent
INFO - 2020-04-04 16:19:55 --> Input Class Initialized
INFO - 2020-04-04 16:19:55 --> Language Class Initialized
INFO - 2020-04-04 16:19:55 --> Language Class Initialized
INFO - 2020-04-04 16:19:55 --> Config Class Initialized
INFO - 2020-04-04 16:19:55 --> Loader Class Initialized
INFO - 2020-04-04 16:19:55 --> Helper loaded: url_helper
INFO - 2020-04-04 16:19:55 --> Helper loaded: file_helper
INFO - 2020-04-04 16:19:55 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:19:55 --> Helper loaded: common_helper
INFO - 2020-04-04 16:19:55 --> Helper loaded: language_helper
INFO - 2020-04-04 16:19:55 --> Helper loaded: email_helper
INFO - 2020-04-04 16:19:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:19:55 --> Database Driver Class Initialized
INFO - 2020-04-04 16:19:55 --> Parser Class Initialized
INFO - 2020-04-04 16:19:55 --> User Agent Class Initialized
INFO - 2020-04-04 16:19:55 --> Model Class Initialized
INFO - 2020-04-04 16:19:55 --> Model Class Initialized
DEBUG - 2020-04-04 16:19:55 --> Template Class Initialized
INFO - 2020-04-04 16:19:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:19:55 --> Email Class Initialized
INFO - 2020-04-04 16:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:19:55 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:19:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:19:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:19:56 --> Encryption Class Initialized
INFO - 2020-04-04 16:19:56 --> Controller Class Initialized
DEBUG - 2020-04-04 16:19:56 --> follow MX_Controller Initialized
INFO - 2020-04-04 16:19:56 --> Model Class Initialized
DEBUG - 2020-04-04 16:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-04 16:19:56 --> Model Class Initialized
INFO - 2020-04-04 16:19:56 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 16:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-04 16:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:19:56 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:19:56 --> Final output sent to browser
DEBUG - 2020-04-04 16:19:56 --> Total execution time: 0.9629
INFO - 2020-04-04 16:19:56 --> Config Class Initialized
INFO - 2020-04-04 16:19:56 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:19:56 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:19:56 --> Utf8 Class Initialized
INFO - 2020-04-04 16:19:56 --> URI Class Initialized
INFO - 2020-04-04 16:19:56 --> Router Class Initialized
INFO - 2020-04-04 16:19:56 --> Output Class Initialized
INFO - 2020-04-04 16:19:56 --> Security Class Initialized
DEBUG - 2020-04-04 16:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:19:56 --> CSRF cookie sent
INFO - 2020-04-04 16:19:56 --> Input Class Initialized
INFO - 2020-04-04 16:19:56 --> Language Class Initialized
ERROR - 2020-04-04 16:19:56 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:19:56 --> Config Class Initialized
INFO - 2020-04-04 16:19:56 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:19:57 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:19:57 --> Utf8 Class Initialized
INFO - 2020-04-04 16:19:57 --> URI Class Initialized
INFO - 2020-04-04 16:19:57 --> Router Class Initialized
INFO - 2020-04-04 16:19:57 --> Output Class Initialized
INFO - 2020-04-04 16:19:57 --> Security Class Initialized
DEBUG - 2020-04-04 16:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:19:57 --> CSRF cookie sent
INFO - 2020-04-04 16:19:57 --> Input Class Initialized
INFO - 2020-04-04 16:19:57 --> Language Class Initialized
ERROR - 2020-04-04 16:19:57 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:19:58 --> Config Class Initialized
INFO - 2020-04-04 16:19:58 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:19:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:19:58 --> Utf8 Class Initialized
INFO - 2020-04-04 16:19:58 --> URI Class Initialized
INFO - 2020-04-04 16:19:58 --> Router Class Initialized
INFO - 2020-04-04 16:19:58 --> Output Class Initialized
INFO - 2020-04-04 16:19:58 --> Security Class Initialized
DEBUG - 2020-04-04 16:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:19:58 --> CSRF cookie sent
INFO - 2020-04-04 16:19:58 --> Input Class Initialized
INFO - 2020-04-04 16:19:58 --> Language Class Initialized
INFO - 2020-04-04 16:19:58 --> Language Class Initialized
INFO - 2020-04-04 16:19:58 --> Config Class Initialized
INFO - 2020-04-04 16:19:58 --> Loader Class Initialized
INFO - 2020-04-04 16:19:58 --> Helper loaded: url_helper
INFO - 2020-04-04 16:19:58 --> Helper loaded: file_helper
INFO - 2020-04-04 16:19:58 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:19:59 --> Helper loaded: common_helper
INFO - 2020-04-04 16:19:59 --> Helper loaded: language_helper
INFO - 2020-04-04 16:19:59 --> Helper loaded: email_helper
INFO - 2020-04-04 16:19:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:19:59 --> Database Driver Class Initialized
INFO - 2020-04-04 16:19:59 --> Parser Class Initialized
INFO - 2020-04-04 16:19:59 --> User Agent Class Initialized
INFO - 2020-04-04 16:19:59 --> Model Class Initialized
INFO - 2020-04-04 16:19:59 --> Model Class Initialized
DEBUG - 2020-04-04 16:19:59 --> Template Class Initialized
INFO - 2020-04-04 16:19:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:19:59 --> Email Class Initialized
INFO - 2020-04-04 16:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:19:59 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:19:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:19:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:19:59 --> Encryption Class Initialized
INFO - 2020-04-04 16:19:59 --> Controller Class Initialized
DEBUG - 2020-04-04 16:19:59 --> follow MX_Controller Initialized
INFO - 2020-04-04 16:19:59 --> Model Class Initialized
DEBUG - 2020-04-04 16:19:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-04 16:19:59 --> Model Class Initialized
INFO - 2020-04-04 16:19:59 --> Helper loaded: inflector_helper
DEBUG - 2020-04-04 16:19:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/setting.php
DEBUG - 2020-04-04 16:19:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/content.php
DEBUG - 2020-04-04 16:19:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-04 16:19:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:19:59 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:19:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:19:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:19:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:19:59 --> Final output sent to browser
DEBUG - 2020-04-04 16:19:59 --> Total execution time: 1.0372
INFO - 2020-04-04 16:19:59 --> Config Class Initialized
INFO - 2020-04-04 16:19:59 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:19:59 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:19:59 --> Utf8 Class Initialized
INFO - 2020-04-04 16:19:59 --> URI Class Initialized
INFO - 2020-04-04 16:19:59 --> Router Class Initialized
INFO - 2020-04-04 16:20:00 --> Output Class Initialized
INFO - 2020-04-04 16:20:00 --> Config Class Initialized
INFO - 2020-04-04 16:20:00 --> Hooks Class Initialized
INFO - 2020-04-04 16:20:00 --> Security Class Initialized
DEBUG - 2020-04-04 16:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 16:20:00 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:20:00 --> Utf8 Class Initialized
INFO - 2020-04-04 16:20:00 --> CSRF cookie sent
INFO - 2020-04-04 16:20:00 --> Input Class Initialized
INFO - 2020-04-04 16:20:00 --> URI Class Initialized
INFO - 2020-04-04 16:20:00 --> Language Class Initialized
INFO - 2020-04-04 16:20:00 --> Router Class Initialized
ERROR - 2020-04-04 16:20:00 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:20:00 --> Output Class Initialized
INFO - 2020-04-04 16:20:00 --> Security Class Initialized
DEBUG - 2020-04-04 16:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:20:00 --> CSRF cookie sent
INFO - 2020-04-04 16:20:00 --> Input Class Initialized
INFO - 2020-04-04 16:20:00 --> Language Class Initialized
ERROR - 2020-04-04 16:20:00 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:20:10 --> Config Class Initialized
INFO - 2020-04-04 16:20:10 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:20:10 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:20:10 --> Utf8 Class Initialized
INFO - 2020-04-04 16:20:10 --> URI Class Initialized
INFO - 2020-04-04 16:20:10 --> Router Class Initialized
INFO - 2020-04-04 16:20:10 --> Output Class Initialized
INFO - 2020-04-04 16:20:10 --> Security Class Initialized
DEBUG - 2020-04-04 16:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:20:10 --> CSRF cookie sent
INFO - 2020-04-04 16:20:10 --> Input Class Initialized
INFO - 2020-04-04 16:20:10 --> Language Class Initialized
INFO - 2020-04-04 16:20:10 --> Language Class Initialized
INFO - 2020-04-04 16:20:10 --> Config Class Initialized
INFO - 2020-04-04 16:20:10 --> Loader Class Initialized
INFO - 2020-04-04 16:20:10 --> Helper loaded: url_helper
INFO - 2020-04-04 16:20:10 --> Helper loaded: file_helper
INFO - 2020-04-04 16:20:10 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:20:10 --> Helper loaded: common_helper
INFO - 2020-04-04 16:20:10 --> Helper loaded: language_helper
INFO - 2020-04-04 16:20:10 --> Helper loaded: email_helper
INFO - 2020-04-04 16:20:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:20:10 --> Database Driver Class Initialized
INFO - 2020-04-04 16:20:11 --> Parser Class Initialized
INFO - 2020-04-04 16:20:11 --> User Agent Class Initialized
INFO - 2020-04-04 16:20:11 --> Model Class Initialized
INFO - 2020-04-04 16:20:11 --> Model Class Initialized
DEBUG - 2020-04-04 16:20:11 --> Template Class Initialized
INFO - 2020-04-04 16:20:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:20:11 --> Email Class Initialized
INFO - 2020-04-04 16:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:20:11 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:20:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:20:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:20:11 --> Encryption Class Initialized
INFO - 2020-04-04 16:20:11 --> Controller Class Initialized
DEBUG - 2020-04-04 16:20:11 --> post MX_Controller Initialized
INFO - 2020-04-04 16:20:11 --> Model Class Initialized
ERROR - 2020-04-04 16:20:11 --> Could not find the language line ""
ERROR - 2020-04-04 16:20:11 --> Could not find the language line ""
ERROR - 2020-04-04 16:20:11 --> Could not find the language line ""
DEBUG - 2020-04-04 16:20:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:20:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:20:11 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:20:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:20:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:20:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:20:11 --> Final output sent to browser
DEBUG - 2020-04-04 16:20:11 --> Total execution time: 0.9606
INFO - 2020-04-04 16:20:11 --> Config Class Initialized
INFO - 2020-04-04 16:20:11 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:20:11 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:20:11 --> Utf8 Class Initialized
INFO - 2020-04-04 16:20:11 --> URI Class Initialized
INFO - 2020-04-04 16:20:11 --> Config Class Initialized
INFO - 2020-04-04 16:20:11 --> Hooks Class Initialized
INFO - 2020-04-04 16:20:11 --> Router Class Initialized
INFO - 2020-04-04 16:20:11 --> Output Class Initialized
DEBUG - 2020-04-04 16:20:11 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:20:11 --> Utf8 Class Initialized
INFO - 2020-04-04 16:20:11 --> Security Class Initialized
DEBUG - 2020-04-04 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:20:11 --> URI Class Initialized
INFO - 2020-04-04 16:20:11 --> CSRF cookie sent
INFO - 2020-04-04 16:20:11 --> Router Class Initialized
INFO - 2020-04-04 16:20:11 --> Input Class Initialized
INFO - 2020-04-04 16:20:11 --> Output Class Initialized
INFO - 2020-04-04 16:20:12 --> Language Class Initialized
INFO - 2020-04-04 16:20:12 --> Security Class Initialized
ERROR - 2020-04-04 16:20:12 --> 404 Page Not Found: /index
DEBUG - 2020-04-04 16:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:20:12 --> CSRF cookie sent
INFO - 2020-04-04 16:20:12 --> Input Class Initialized
INFO - 2020-04-04 16:20:12 --> Language Class Initialized
ERROR - 2020-04-04 16:20:12 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:22:16 --> Config Class Initialized
INFO - 2020-04-04 16:22:16 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:22:16 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:22:16 --> Utf8 Class Initialized
INFO - 2020-04-04 16:22:16 --> URI Class Initialized
INFO - 2020-04-04 16:22:16 --> Router Class Initialized
INFO - 2020-04-04 16:22:16 --> Output Class Initialized
INFO - 2020-04-04 16:22:16 --> Security Class Initialized
DEBUG - 2020-04-04 16:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:22:16 --> CSRF cookie sent
INFO - 2020-04-04 16:22:16 --> Input Class Initialized
INFO - 2020-04-04 16:22:16 --> Language Class Initialized
INFO - 2020-04-04 16:22:16 --> Language Class Initialized
INFO - 2020-04-04 16:22:16 --> Config Class Initialized
INFO - 2020-04-04 16:22:16 --> Loader Class Initialized
INFO - 2020-04-04 16:22:16 --> Helper loaded: url_helper
INFO - 2020-04-04 16:22:16 --> Helper loaded: file_helper
INFO - 2020-04-04 16:22:16 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:22:16 --> Helper loaded: common_helper
INFO - 2020-04-04 16:22:16 --> Helper loaded: language_helper
INFO - 2020-04-04 16:22:16 --> Helper loaded: email_helper
INFO - 2020-04-04 16:22:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:22:17 --> Database Driver Class Initialized
INFO - 2020-04-04 16:22:17 --> Parser Class Initialized
INFO - 2020-04-04 16:22:17 --> User Agent Class Initialized
INFO - 2020-04-04 16:22:17 --> Model Class Initialized
INFO - 2020-04-04 16:22:17 --> Model Class Initialized
DEBUG - 2020-04-04 16:22:17 --> Template Class Initialized
INFO - 2020-04-04 16:22:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:22:17 --> Email Class Initialized
INFO - 2020-04-04 16:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:22:17 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:22:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:22:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:22:17 --> Encryption Class Initialized
INFO - 2020-04-04 16:22:17 --> Controller Class Initialized
DEBUG - 2020-04-04 16:22:17 --> post MX_Controller Initialized
INFO - 2020-04-04 16:22:17 --> Model Class Initialized
ERROR - 2020-04-04 16:22:17 --> Could not find the language line ""
ERROR - 2020-04-04 16:22:17 --> Could not find the language line ""
ERROR - 2020-04-04 16:22:17 --> Could not find the language line ""
DEBUG - 2020-04-04 16:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:22:17 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:22:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:22:17 --> Final output sent to browser
DEBUG - 2020-04-04 16:22:17 --> Total execution time: 0.9022
INFO - 2020-04-04 16:22:17 --> Config Class Initialized
INFO - 2020-04-04 16:22:17 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:22:17 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:22:17 --> Utf8 Class Initialized
INFO - 2020-04-04 16:22:18 --> URI Class Initialized
INFO - 2020-04-04 16:22:18 --> Router Class Initialized
INFO - 2020-04-04 16:22:18 --> Output Class Initialized
INFO - 2020-04-04 16:22:18 --> Security Class Initialized
DEBUG - 2020-04-04 16:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:22:18 --> CSRF cookie sent
INFO - 2020-04-04 16:22:18 --> Input Class Initialized
INFO - 2020-04-04 16:22:18 --> Language Class Initialized
ERROR - 2020-04-04 16:22:18 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:22:18 --> Config Class Initialized
INFO - 2020-04-04 16:22:18 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:22:18 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:22:18 --> Utf8 Class Initialized
INFO - 2020-04-04 16:22:18 --> URI Class Initialized
INFO - 2020-04-04 16:22:18 --> Router Class Initialized
INFO - 2020-04-04 16:22:18 --> Output Class Initialized
INFO - 2020-04-04 16:22:18 --> Security Class Initialized
DEBUG - 2020-04-04 16:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:22:18 --> CSRF cookie sent
INFO - 2020-04-04 16:22:18 --> Input Class Initialized
INFO - 2020-04-04 16:22:18 --> Language Class Initialized
ERROR - 2020-04-04 16:22:18 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:22:36 --> Config Class Initialized
INFO - 2020-04-04 16:22:36 --> Config Class Initialized
INFO - 2020-04-04 16:22:36 --> Hooks Class Initialized
INFO - 2020-04-04 16:22:36 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 16:22:36 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:22:36 --> Utf8 Class Initialized
INFO - 2020-04-04 16:22:36 --> Utf8 Class Initialized
INFO - 2020-04-04 16:22:36 --> URI Class Initialized
INFO - 2020-04-04 16:22:36 --> URI Class Initialized
INFO - 2020-04-04 16:22:36 --> Router Class Initialized
INFO - 2020-04-04 16:22:36 --> Router Class Initialized
INFO - 2020-04-04 16:22:36 --> Output Class Initialized
INFO - 2020-04-04 16:22:36 --> Output Class Initialized
INFO - 2020-04-04 16:22:36 --> Security Class Initialized
INFO - 2020-04-04 16:22:36 --> Security Class Initialized
DEBUG - 2020-04-04 16:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 16:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:22:36 --> CSRF cookie sent
INFO - 2020-04-04 16:22:36 --> CSRF cookie sent
INFO - 2020-04-04 16:22:36 --> Input Class Initialized
INFO - 2020-04-04 16:22:36 --> Input Class Initialized
INFO - 2020-04-04 16:22:36 --> Language Class Initialized
INFO - 2020-04-04 16:22:36 --> Language Class Initialized
ERROR - 2020-04-04 16:22:36 --> 404 Page Not Found: /index
ERROR - 2020-04-04 16:22:36 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:22:58 --> Config Class Initialized
INFO - 2020-04-04 16:22:58 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:22:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:22:58 --> Utf8 Class Initialized
INFO - 2020-04-04 16:22:58 --> URI Class Initialized
INFO - 2020-04-04 16:22:58 --> Router Class Initialized
INFO - 2020-04-04 16:22:58 --> Output Class Initialized
INFO - 2020-04-04 16:22:58 --> Security Class Initialized
DEBUG - 2020-04-04 16:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:22:58 --> CSRF cookie sent
INFO - 2020-04-04 16:22:58 --> Input Class Initialized
INFO - 2020-04-04 16:22:58 --> Language Class Initialized
INFO - 2020-04-04 16:22:58 --> Language Class Initialized
INFO - 2020-04-04 16:22:58 --> Config Class Initialized
INFO - 2020-04-04 16:22:58 --> Loader Class Initialized
INFO - 2020-04-04 16:22:58 --> Helper loaded: url_helper
INFO - 2020-04-04 16:22:58 --> Helper loaded: file_helper
INFO - 2020-04-04 16:22:58 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:22:58 --> Helper loaded: common_helper
INFO - 2020-04-04 16:22:58 --> Helper loaded: language_helper
INFO - 2020-04-04 16:22:58 --> Helper loaded: email_helper
INFO - 2020-04-04 16:22:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:22:58 --> Database Driver Class Initialized
INFO - 2020-04-04 16:22:58 --> Parser Class Initialized
INFO - 2020-04-04 16:22:58 --> User Agent Class Initialized
INFO - 2020-04-04 16:22:58 --> Model Class Initialized
INFO - 2020-04-04 16:22:58 --> Model Class Initialized
DEBUG - 2020-04-04 16:22:58 --> Template Class Initialized
INFO - 2020-04-04 16:22:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:22:58 --> Email Class Initialized
INFO - 2020-04-04 16:22:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:22:58 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:22:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:22:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:22:58 --> Encryption Class Initialized
INFO - 2020-04-04 16:22:58 --> Controller Class Initialized
DEBUG - 2020-04-04 16:22:58 --> post MX_Controller Initialized
INFO - 2020-04-04 16:22:59 --> Model Class Initialized
ERROR - 2020-04-04 16:22:59 --> Could not find the language line ""
ERROR - 2020-04-04 16:22:59 --> Could not find the language line ""
ERROR - 2020-04-04 16:22:59 --> Could not find the language line ""
DEBUG - 2020-04-04 16:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:22:59 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:22:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:22:59 --> Final output sent to browser
DEBUG - 2020-04-04 16:22:59 --> Total execution time: 0.8759
INFO - 2020-04-04 16:22:59 --> Config Class Initialized
INFO - 2020-04-04 16:22:59 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:22:59 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:22:59 --> Utf8 Class Initialized
INFO - 2020-04-04 16:22:59 --> URI Class Initialized
INFO - 2020-04-04 16:22:59 --> Router Class Initialized
INFO - 2020-04-04 16:22:59 --> Output Class Initialized
INFO - 2020-04-04 16:22:59 --> Security Class Initialized
DEBUG - 2020-04-04 16:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:22:59 --> CSRF cookie sent
INFO - 2020-04-04 16:22:59 --> Input Class Initialized
INFO - 2020-04-04 16:22:59 --> Language Class Initialized
ERROR - 2020-04-04 16:22:59 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:22:59 --> Config Class Initialized
INFO - 2020-04-04 16:22:59 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:22:59 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:23:00 --> Utf8 Class Initialized
INFO - 2020-04-04 16:23:00 --> URI Class Initialized
INFO - 2020-04-04 16:23:00 --> Router Class Initialized
INFO - 2020-04-04 16:23:00 --> Output Class Initialized
INFO - 2020-04-04 16:23:00 --> Security Class Initialized
DEBUG - 2020-04-04 16:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:23:00 --> CSRF cookie sent
INFO - 2020-04-04 16:23:00 --> Input Class Initialized
INFO - 2020-04-04 16:23:00 --> Language Class Initialized
ERROR - 2020-04-04 16:23:00 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:25:22 --> Config Class Initialized
INFO - 2020-04-04 16:25:22 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:25:22 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:25:22 --> Utf8 Class Initialized
INFO - 2020-04-04 16:25:22 --> URI Class Initialized
INFO - 2020-04-04 16:25:22 --> Router Class Initialized
INFO - 2020-04-04 16:25:22 --> Output Class Initialized
INFO - 2020-04-04 16:25:22 --> Security Class Initialized
DEBUG - 2020-04-04 16:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:25:22 --> CSRF cookie sent
INFO - 2020-04-04 16:25:22 --> Input Class Initialized
INFO - 2020-04-04 16:25:22 --> Language Class Initialized
INFO - 2020-04-04 16:25:22 --> Language Class Initialized
INFO - 2020-04-04 16:25:22 --> Config Class Initialized
INFO - 2020-04-04 16:25:22 --> Loader Class Initialized
INFO - 2020-04-04 16:25:22 --> Helper loaded: url_helper
INFO - 2020-04-04 16:25:22 --> Helper loaded: file_helper
INFO - 2020-04-04 16:25:22 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:25:22 --> Helper loaded: common_helper
INFO - 2020-04-04 16:25:22 --> Helper loaded: language_helper
INFO - 2020-04-04 16:25:22 --> Helper loaded: email_helper
INFO - 2020-04-04 16:25:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:25:22 --> Database Driver Class Initialized
INFO - 2020-04-04 16:25:22 --> Parser Class Initialized
INFO - 2020-04-04 16:25:22 --> User Agent Class Initialized
INFO - 2020-04-04 16:25:22 --> Model Class Initialized
INFO - 2020-04-04 16:25:23 --> Model Class Initialized
DEBUG - 2020-04-04 16:25:23 --> Template Class Initialized
INFO - 2020-04-04 16:25:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:25:23 --> Email Class Initialized
INFO - 2020-04-04 16:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:25:23 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:25:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:25:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:25:23 --> Encryption Class Initialized
INFO - 2020-04-04 16:25:23 --> Controller Class Initialized
DEBUG - 2020-04-04 16:25:23 --> post MX_Controller Initialized
INFO - 2020-04-04 16:25:23 --> Model Class Initialized
ERROR - 2020-04-04 16:25:23 --> Could not find the language line ""
ERROR - 2020-04-04 16:25:23 --> Could not find the language line ""
ERROR - 2020-04-04 16:25:23 --> Could not find the language line ""
DEBUG - 2020-04-04 16:25:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:25:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:25:23 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:25:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:25:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:25:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:25:23 --> Final output sent to browser
DEBUG - 2020-04-04 16:25:23 --> Total execution time: 0.8843
INFO - 2020-04-04 16:25:23 --> Config Class Initialized
INFO - 2020-04-04 16:25:23 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:25:23 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:25:23 --> Utf8 Class Initialized
INFO - 2020-04-04 16:25:23 --> URI Class Initialized
INFO - 2020-04-04 16:25:23 --> Router Class Initialized
INFO - 2020-04-04 16:25:23 --> Output Class Initialized
INFO - 2020-04-04 16:25:23 --> Security Class Initialized
DEBUG - 2020-04-04 16:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:25:23 --> CSRF cookie sent
INFO - 2020-04-04 16:25:23 --> Input Class Initialized
INFO - 2020-04-04 16:25:23 --> Language Class Initialized
ERROR - 2020-04-04 16:25:24 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:25:24 --> Config Class Initialized
INFO - 2020-04-04 16:25:24 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:25:24 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:25:24 --> Utf8 Class Initialized
INFO - 2020-04-04 16:25:24 --> URI Class Initialized
INFO - 2020-04-04 16:25:24 --> Router Class Initialized
INFO - 2020-04-04 16:25:24 --> Output Class Initialized
INFO - 2020-04-04 16:25:24 --> Security Class Initialized
DEBUG - 2020-04-04 16:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:25:24 --> CSRF cookie sent
INFO - 2020-04-04 16:25:24 --> Input Class Initialized
INFO - 2020-04-04 16:25:24 --> Language Class Initialized
ERROR - 2020-04-04 16:25:24 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:26:09 --> Config Class Initialized
INFO - 2020-04-04 16:26:09 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:26:09 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:26:09 --> Utf8 Class Initialized
INFO - 2020-04-04 16:26:09 --> URI Class Initialized
INFO - 2020-04-04 16:26:09 --> Router Class Initialized
INFO - 2020-04-04 16:26:09 --> Output Class Initialized
INFO - 2020-04-04 16:26:09 --> Security Class Initialized
DEBUG - 2020-04-04 16:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:26:09 --> CSRF cookie sent
INFO - 2020-04-04 16:26:09 --> Input Class Initialized
INFO - 2020-04-04 16:26:09 --> Language Class Initialized
INFO - 2020-04-04 16:26:09 --> Language Class Initialized
INFO - 2020-04-04 16:26:09 --> Config Class Initialized
INFO - 2020-04-04 16:26:10 --> Loader Class Initialized
INFO - 2020-04-04 16:26:10 --> Helper loaded: url_helper
INFO - 2020-04-04 16:26:10 --> Helper loaded: file_helper
INFO - 2020-04-04 16:26:10 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:26:10 --> Helper loaded: common_helper
INFO - 2020-04-04 16:26:10 --> Helper loaded: language_helper
INFO - 2020-04-04 16:26:10 --> Helper loaded: email_helper
INFO - 2020-04-04 16:26:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:26:10 --> Database Driver Class Initialized
INFO - 2020-04-04 16:26:10 --> Parser Class Initialized
INFO - 2020-04-04 16:26:10 --> User Agent Class Initialized
INFO - 2020-04-04 16:26:10 --> Model Class Initialized
INFO - 2020-04-04 16:26:10 --> Model Class Initialized
DEBUG - 2020-04-04 16:26:10 --> Template Class Initialized
INFO - 2020-04-04 16:26:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:26:10 --> Email Class Initialized
INFO - 2020-04-04 16:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:26:10 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:26:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:26:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:26:10 --> Encryption Class Initialized
INFO - 2020-04-04 16:26:10 --> Controller Class Initialized
DEBUG - 2020-04-04 16:26:10 --> post MX_Controller Initialized
INFO - 2020-04-04 16:26:10 --> Model Class Initialized
ERROR - 2020-04-04 16:26:10 --> Could not find the language line ""
ERROR - 2020-04-04 16:26:10 --> Could not find the language line ""
ERROR - 2020-04-04 16:26:10 --> Could not find the language line ""
DEBUG - 2020-04-04 16:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:26:10 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:26:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:26:10 --> Final output sent to browser
DEBUG - 2020-04-04 16:26:10 --> Total execution time: 0.8565
INFO - 2020-04-04 16:26:10 --> Config Class Initialized
INFO - 2020-04-04 16:26:10 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:26:11 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:26:11 --> Utf8 Class Initialized
INFO - 2020-04-04 16:26:11 --> URI Class Initialized
INFO - 2020-04-04 16:26:11 --> Router Class Initialized
INFO - 2020-04-04 16:26:11 --> Output Class Initialized
INFO - 2020-04-04 16:26:11 --> Security Class Initialized
DEBUG - 2020-04-04 16:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:26:11 --> CSRF cookie sent
INFO - 2020-04-04 16:26:11 --> Input Class Initialized
INFO - 2020-04-04 16:26:11 --> Language Class Initialized
ERROR - 2020-04-04 16:26:11 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:26:11 --> Config Class Initialized
INFO - 2020-04-04 16:26:11 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:26:11 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:26:11 --> Utf8 Class Initialized
INFO - 2020-04-04 16:26:11 --> URI Class Initialized
INFO - 2020-04-04 16:26:11 --> Router Class Initialized
INFO - 2020-04-04 16:26:11 --> Output Class Initialized
INFO - 2020-04-04 16:26:11 --> Security Class Initialized
DEBUG - 2020-04-04 16:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:26:11 --> CSRF cookie sent
INFO - 2020-04-04 16:26:11 --> Input Class Initialized
INFO - 2020-04-04 16:26:11 --> Language Class Initialized
ERROR - 2020-04-04 16:26:11 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:26:36 --> Config Class Initialized
INFO - 2020-04-04 16:26:36 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:26:36 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:26:36 --> Utf8 Class Initialized
INFO - 2020-04-04 16:26:36 --> URI Class Initialized
INFO - 2020-04-04 16:26:36 --> Router Class Initialized
INFO - 2020-04-04 16:26:36 --> Output Class Initialized
INFO - 2020-04-04 16:26:36 --> Security Class Initialized
DEBUG - 2020-04-04 16:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:26:36 --> CSRF cookie sent
INFO - 2020-04-04 16:26:36 --> Input Class Initialized
INFO - 2020-04-04 16:26:36 --> Language Class Initialized
INFO - 2020-04-04 16:26:36 --> Language Class Initialized
INFO - 2020-04-04 16:26:36 --> Config Class Initialized
INFO - 2020-04-04 16:26:36 --> Loader Class Initialized
INFO - 2020-04-04 16:26:36 --> Helper loaded: url_helper
INFO - 2020-04-04 16:26:36 --> Helper loaded: file_helper
INFO - 2020-04-04 16:26:36 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:26:36 --> Helper loaded: common_helper
INFO - 2020-04-04 16:26:36 --> Helper loaded: language_helper
INFO - 2020-04-04 16:26:36 --> Helper loaded: email_helper
INFO - 2020-04-04 16:26:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:26:36 --> Database Driver Class Initialized
INFO - 2020-04-04 16:26:36 --> Parser Class Initialized
INFO - 2020-04-04 16:26:36 --> User Agent Class Initialized
INFO - 2020-04-04 16:26:36 --> Model Class Initialized
INFO - 2020-04-04 16:26:36 --> Model Class Initialized
DEBUG - 2020-04-04 16:26:36 --> Template Class Initialized
INFO - 2020-04-04 16:26:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:26:36 --> Email Class Initialized
INFO - 2020-04-04 16:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:26:36 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:26:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:26:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:26:36 --> Encryption Class Initialized
INFO - 2020-04-04 16:26:36 --> Controller Class Initialized
DEBUG - 2020-04-04 16:26:36 --> post MX_Controller Initialized
INFO - 2020-04-04 16:26:36 --> Model Class Initialized
ERROR - 2020-04-04 16:26:36 --> Could not find the language line ""
ERROR - 2020-04-04 16:26:36 --> Could not find the language line ""
ERROR - 2020-04-04 16:26:36 --> Could not find the language line ""
DEBUG - 2020-04-04 16:26:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:26:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:26:36 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:26:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:26:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:26:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:26:36 --> Final output sent to browser
DEBUG - 2020-04-04 16:26:36 --> Total execution time: 0.8839
INFO - 2020-04-04 16:26:37 --> Config Class Initialized
INFO - 2020-04-04 16:26:37 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:26:37 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:26:37 --> Utf8 Class Initialized
INFO - 2020-04-04 16:26:37 --> URI Class Initialized
INFO - 2020-04-04 16:26:37 --> Router Class Initialized
INFO - 2020-04-04 16:26:37 --> Output Class Initialized
INFO - 2020-04-04 16:26:37 --> Security Class Initialized
DEBUG - 2020-04-04 16:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:26:37 --> CSRF cookie sent
INFO - 2020-04-04 16:26:37 --> Input Class Initialized
INFO - 2020-04-04 16:26:37 --> Language Class Initialized
ERROR - 2020-04-04 16:26:37 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:26:37 --> Config Class Initialized
INFO - 2020-04-04 16:26:37 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:26:37 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:26:37 --> Utf8 Class Initialized
INFO - 2020-04-04 16:26:37 --> URI Class Initialized
INFO - 2020-04-04 16:26:37 --> Router Class Initialized
INFO - 2020-04-04 16:26:37 --> Output Class Initialized
INFO - 2020-04-04 16:26:37 --> Security Class Initialized
DEBUG - 2020-04-04 16:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:26:37 --> CSRF cookie sent
INFO - 2020-04-04 16:26:37 --> Input Class Initialized
INFO - 2020-04-04 16:26:37 --> Language Class Initialized
ERROR - 2020-04-04 16:26:37 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:30:19 --> Config Class Initialized
INFO - 2020-04-04 16:30:19 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:30:19 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:30:19 --> Utf8 Class Initialized
INFO - 2020-04-04 16:30:20 --> URI Class Initialized
INFO - 2020-04-04 16:30:20 --> Router Class Initialized
INFO - 2020-04-04 16:30:20 --> Output Class Initialized
INFO - 2020-04-04 16:30:20 --> Security Class Initialized
DEBUG - 2020-04-04 16:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:30:20 --> CSRF cookie sent
INFO - 2020-04-04 16:30:20 --> Input Class Initialized
INFO - 2020-04-04 16:30:20 --> Language Class Initialized
INFO - 2020-04-04 16:30:20 --> Language Class Initialized
INFO - 2020-04-04 16:30:20 --> Config Class Initialized
INFO - 2020-04-04 16:30:20 --> Loader Class Initialized
INFO - 2020-04-04 16:30:20 --> Helper loaded: url_helper
INFO - 2020-04-04 16:30:20 --> Helper loaded: file_helper
INFO - 2020-04-04 16:30:20 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:30:20 --> Helper loaded: common_helper
INFO - 2020-04-04 16:30:20 --> Helper loaded: language_helper
INFO - 2020-04-04 16:30:20 --> Helper loaded: email_helper
INFO - 2020-04-04 16:30:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:30:20 --> Database Driver Class Initialized
INFO - 2020-04-04 16:30:20 --> Parser Class Initialized
INFO - 2020-04-04 16:30:20 --> User Agent Class Initialized
INFO - 2020-04-04 16:30:20 --> Model Class Initialized
INFO - 2020-04-04 16:30:20 --> Model Class Initialized
DEBUG - 2020-04-04 16:30:20 --> Template Class Initialized
INFO - 2020-04-04 16:30:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:30:20 --> Email Class Initialized
INFO - 2020-04-04 16:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:30:20 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:30:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:30:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:30:20 --> Encryption Class Initialized
INFO - 2020-04-04 16:30:20 --> Controller Class Initialized
DEBUG - 2020-04-04 16:30:20 --> post MX_Controller Initialized
INFO - 2020-04-04 16:30:20 --> Model Class Initialized
ERROR - 2020-04-04 16:30:20 --> Could not find the language line ""
ERROR - 2020-04-04 16:30:20 --> Could not find the language line ""
ERROR - 2020-04-04 16:30:20 --> Could not find the language line ""
DEBUG - 2020-04-04 16:30:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:30:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:30:20 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:30:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:30:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:30:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:30:20 --> Final output sent to browser
DEBUG - 2020-04-04 16:30:20 --> Total execution time: 0.8710
INFO - 2020-04-04 16:30:21 --> Config Class Initialized
INFO - 2020-04-04 16:30:21 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:30:21 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:30:21 --> Utf8 Class Initialized
INFO - 2020-04-04 16:30:21 --> URI Class Initialized
INFO - 2020-04-04 16:30:21 --> Router Class Initialized
INFO - 2020-04-04 16:30:21 --> Output Class Initialized
INFO - 2020-04-04 16:30:21 --> Security Class Initialized
DEBUG - 2020-04-04 16:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:30:21 --> CSRF cookie sent
INFO - 2020-04-04 16:30:21 --> Input Class Initialized
INFO - 2020-04-04 16:30:21 --> Language Class Initialized
ERROR - 2020-04-04 16:30:21 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:30:21 --> Config Class Initialized
INFO - 2020-04-04 16:30:21 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:30:21 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:30:21 --> Utf8 Class Initialized
INFO - 2020-04-04 16:30:21 --> URI Class Initialized
INFO - 2020-04-04 16:30:21 --> Router Class Initialized
INFO - 2020-04-04 16:30:21 --> Output Class Initialized
INFO - 2020-04-04 16:30:21 --> Security Class Initialized
DEBUG - 2020-04-04 16:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:30:21 --> CSRF cookie sent
INFO - 2020-04-04 16:30:21 --> Input Class Initialized
INFO - 2020-04-04 16:30:21 --> Language Class Initialized
ERROR - 2020-04-04 16:30:21 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:30:44 --> Config Class Initialized
INFO - 2020-04-04 16:30:45 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:30:45 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:30:45 --> Utf8 Class Initialized
INFO - 2020-04-04 16:30:45 --> URI Class Initialized
INFO - 2020-04-04 16:30:45 --> Router Class Initialized
INFO - 2020-04-04 16:30:45 --> Output Class Initialized
INFO - 2020-04-04 16:30:45 --> Security Class Initialized
DEBUG - 2020-04-04 16:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:30:45 --> CSRF cookie sent
INFO - 2020-04-04 16:30:45 --> Input Class Initialized
INFO - 2020-04-04 16:30:45 --> Language Class Initialized
INFO - 2020-04-04 16:30:45 --> Language Class Initialized
INFO - 2020-04-04 16:30:45 --> Config Class Initialized
INFO - 2020-04-04 16:30:45 --> Loader Class Initialized
INFO - 2020-04-04 16:30:45 --> Helper loaded: url_helper
INFO - 2020-04-04 16:30:45 --> Helper loaded: file_helper
INFO - 2020-04-04 16:30:45 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:30:45 --> Helper loaded: common_helper
INFO - 2020-04-04 16:30:45 --> Helper loaded: language_helper
INFO - 2020-04-04 16:30:45 --> Helper loaded: email_helper
INFO - 2020-04-04 16:30:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:30:45 --> Database Driver Class Initialized
INFO - 2020-04-04 16:30:45 --> Parser Class Initialized
INFO - 2020-04-04 16:30:45 --> User Agent Class Initialized
INFO - 2020-04-04 16:30:45 --> Model Class Initialized
INFO - 2020-04-04 16:30:45 --> Model Class Initialized
DEBUG - 2020-04-04 16:30:45 --> Template Class Initialized
INFO - 2020-04-04 16:30:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:30:45 --> Email Class Initialized
INFO - 2020-04-04 16:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:30:45 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:30:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:30:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:30:45 --> Encryption Class Initialized
INFO - 2020-04-04 16:30:45 --> Controller Class Initialized
DEBUG - 2020-04-04 16:30:45 --> post MX_Controller Initialized
INFO - 2020-04-04 16:30:45 --> Model Class Initialized
ERROR - 2020-04-04 16:30:45 --> Could not find the language line ""
ERROR - 2020-04-04 16:30:45 --> Could not find the language line ""
ERROR - 2020-04-04 16:30:45 --> Could not find the language line ""
DEBUG - 2020-04-04 16:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:30:45 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:30:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:30:45 --> Final output sent to browser
DEBUG - 2020-04-04 16:30:45 --> Total execution time: 0.9393
INFO - 2020-04-04 16:30:50 --> Config Class Initialized
INFO - 2020-04-04 16:30:50 --> Config Class Initialized
INFO - 2020-04-04 16:30:50 --> Hooks Class Initialized
INFO - 2020-04-04 16:30:50 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:30:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 16:30:50 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:30:50 --> Utf8 Class Initialized
INFO - 2020-04-04 16:30:50 --> Utf8 Class Initialized
INFO - 2020-04-04 16:30:50 --> URI Class Initialized
INFO - 2020-04-04 16:30:50 --> URI Class Initialized
INFO - 2020-04-04 16:30:50 --> Router Class Initialized
INFO - 2020-04-04 16:30:50 --> Router Class Initialized
INFO - 2020-04-04 16:30:50 --> Output Class Initialized
INFO - 2020-04-04 16:30:50 --> Output Class Initialized
INFO - 2020-04-04 16:30:50 --> Security Class Initialized
INFO - 2020-04-04 16:30:50 --> Security Class Initialized
DEBUG - 2020-04-04 16:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 16:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:30:50 --> CSRF cookie sent
INFO - 2020-04-04 16:30:50 --> CSRF cookie sent
INFO - 2020-04-04 16:30:50 --> Input Class Initialized
INFO - 2020-04-04 16:30:50 --> Input Class Initialized
INFO - 2020-04-04 16:30:50 --> Language Class Initialized
INFO - 2020-04-04 16:30:50 --> Language Class Initialized
ERROR - 2020-04-04 16:30:50 --> 404 Page Not Found: /index
ERROR - 2020-04-04 16:30:50 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:31:50 --> Config Class Initialized
INFO - 2020-04-04 16:31:50 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:31:50 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:31:50 --> Utf8 Class Initialized
INFO - 2020-04-04 16:31:50 --> URI Class Initialized
INFO - 2020-04-04 16:31:50 --> Router Class Initialized
INFO - 2020-04-04 16:31:50 --> Output Class Initialized
INFO - 2020-04-04 16:31:50 --> Security Class Initialized
DEBUG - 2020-04-04 16:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:31:50 --> CSRF cookie sent
INFO - 2020-04-04 16:31:50 --> Input Class Initialized
INFO - 2020-04-04 16:31:50 --> Language Class Initialized
INFO - 2020-04-04 16:31:50 --> Language Class Initialized
INFO - 2020-04-04 16:31:50 --> Config Class Initialized
INFO - 2020-04-04 16:31:50 --> Loader Class Initialized
INFO - 2020-04-04 16:31:50 --> Helper loaded: url_helper
INFO - 2020-04-04 16:31:50 --> Helper loaded: file_helper
INFO - 2020-04-04 16:31:50 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:31:50 --> Helper loaded: common_helper
INFO - 2020-04-04 16:31:50 --> Helper loaded: language_helper
INFO - 2020-04-04 16:31:50 --> Helper loaded: email_helper
INFO - 2020-04-04 16:31:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:31:50 --> Database Driver Class Initialized
INFO - 2020-04-04 16:31:50 --> Parser Class Initialized
INFO - 2020-04-04 16:31:50 --> User Agent Class Initialized
INFO - 2020-04-04 16:31:50 --> Model Class Initialized
INFO - 2020-04-04 16:31:50 --> Model Class Initialized
DEBUG - 2020-04-04 16:31:50 --> Template Class Initialized
INFO - 2020-04-04 16:31:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:31:50 --> Email Class Initialized
INFO - 2020-04-04 16:31:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:31:50 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:31:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:31:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:31:50 --> Encryption Class Initialized
INFO - 2020-04-04 16:31:50 --> Controller Class Initialized
DEBUG - 2020-04-04 16:31:50 --> post MX_Controller Initialized
INFO - 2020-04-04 16:31:50 --> Model Class Initialized
ERROR - 2020-04-04 16:31:50 --> Could not find the language line ""
ERROR - 2020-04-04 16:31:50 --> Could not find the language line ""
ERROR - 2020-04-04 16:31:50 --> Could not find the language line ""
DEBUG - 2020-04-04 16:31:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:31:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:31:50 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:31:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:31:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:31:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:31:50 --> Final output sent to browser
DEBUG - 2020-04-04 16:31:50 --> Total execution time: 0.8746
INFO - 2020-04-04 16:31:51 --> Config Class Initialized
INFO - 2020-04-04 16:31:51 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:31:51 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:31:51 --> Utf8 Class Initialized
INFO - 2020-04-04 16:31:51 --> URI Class Initialized
INFO - 2020-04-04 16:31:51 --> Router Class Initialized
INFO - 2020-04-04 16:31:51 --> Output Class Initialized
INFO - 2020-04-04 16:31:51 --> Security Class Initialized
DEBUG - 2020-04-04 16:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:31:51 --> CSRF cookie sent
INFO - 2020-04-04 16:31:51 --> Input Class Initialized
INFO - 2020-04-04 16:31:51 --> Language Class Initialized
ERROR - 2020-04-04 16:31:51 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:31:51 --> Config Class Initialized
INFO - 2020-04-04 16:31:51 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:31:51 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:31:51 --> Utf8 Class Initialized
INFO - 2020-04-04 16:31:51 --> URI Class Initialized
INFO - 2020-04-04 16:31:51 --> Router Class Initialized
INFO - 2020-04-04 16:31:51 --> Output Class Initialized
INFO - 2020-04-04 16:31:51 --> Security Class Initialized
DEBUG - 2020-04-04 16:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:31:51 --> CSRF cookie sent
INFO - 2020-04-04 16:31:51 --> Input Class Initialized
INFO - 2020-04-04 16:31:51 --> Language Class Initialized
ERROR - 2020-04-04 16:31:51 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:32:25 --> Config Class Initialized
INFO - 2020-04-04 16:32:25 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:32:25 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:32:25 --> Utf8 Class Initialized
INFO - 2020-04-04 16:32:25 --> URI Class Initialized
INFO - 2020-04-04 16:32:25 --> Router Class Initialized
INFO - 2020-04-04 16:32:25 --> Output Class Initialized
INFO - 2020-04-04 16:32:25 --> Security Class Initialized
DEBUG - 2020-04-04 16:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:32:25 --> CSRF cookie sent
INFO - 2020-04-04 16:32:25 --> Input Class Initialized
INFO - 2020-04-04 16:32:25 --> Language Class Initialized
INFO - 2020-04-04 16:32:25 --> Language Class Initialized
INFO - 2020-04-04 16:32:25 --> Config Class Initialized
INFO - 2020-04-04 16:32:25 --> Loader Class Initialized
INFO - 2020-04-04 16:32:25 --> Helper loaded: url_helper
INFO - 2020-04-04 16:32:25 --> Helper loaded: file_helper
INFO - 2020-04-04 16:32:25 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:32:25 --> Helper loaded: common_helper
INFO - 2020-04-04 16:32:25 --> Helper loaded: language_helper
INFO - 2020-04-04 16:32:25 --> Helper loaded: email_helper
INFO - 2020-04-04 16:32:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:32:25 --> Database Driver Class Initialized
INFO - 2020-04-04 16:32:25 --> Parser Class Initialized
INFO - 2020-04-04 16:32:26 --> User Agent Class Initialized
INFO - 2020-04-04 16:32:26 --> Model Class Initialized
INFO - 2020-04-04 16:32:26 --> Model Class Initialized
DEBUG - 2020-04-04 16:32:26 --> Template Class Initialized
INFO - 2020-04-04 16:32:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:32:26 --> Email Class Initialized
INFO - 2020-04-04 16:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:32:26 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:32:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:32:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:32:26 --> Encryption Class Initialized
INFO - 2020-04-04 16:32:26 --> Controller Class Initialized
DEBUG - 2020-04-04 16:32:26 --> post MX_Controller Initialized
INFO - 2020-04-04 16:32:26 --> Model Class Initialized
ERROR - 2020-04-04 16:32:26 --> Could not find the language line ""
ERROR - 2020-04-04 16:32:26 --> Could not find the language line ""
ERROR - 2020-04-04 16:32:26 --> Could not find the language line ""
DEBUG - 2020-04-04 16:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:32:26 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:32:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:32:26 --> Final output sent to browser
DEBUG - 2020-04-04 16:32:26 --> Total execution time: 1.0208
INFO - 2020-04-04 16:32:26 --> Config Class Initialized
INFO - 2020-04-04 16:32:26 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:32:26 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:32:26 --> Utf8 Class Initialized
INFO - 2020-04-04 16:32:26 --> URI Class Initialized
INFO - 2020-04-04 16:32:27 --> Router Class Initialized
INFO - 2020-04-04 16:32:27 --> Output Class Initialized
INFO - 2020-04-04 16:32:27 --> Security Class Initialized
DEBUG - 2020-04-04 16:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:32:27 --> CSRF cookie sent
INFO - 2020-04-04 16:32:27 --> Input Class Initialized
INFO - 2020-04-04 16:32:27 --> Language Class Initialized
ERROR - 2020-04-04 16:32:27 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:32:27 --> Config Class Initialized
INFO - 2020-04-04 16:32:27 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:32:27 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:32:27 --> Utf8 Class Initialized
INFO - 2020-04-04 16:32:27 --> URI Class Initialized
INFO - 2020-04-04 16:32:27 --> Router Class Initialized
INFO - 2020-04-04 16:32:27 --> Output Class Initialized
INFO - 2020-04-04 16:32:27 --> Security Class Initialized
DEBUG - 2020-04-04 16:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:32:27 --> CSRF cookie sent
INFO - 2020-04-04 16:32:27 --> Input Class Initialized
INFO - 2020-04-04 16:32:27 --> Language Class Initialized
ERROR - 2020-04-04 16:32:27 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:33:51 --> Config Class Initialized
INFO - 2020-04-04 16:33:51 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:33:51 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:33:51 --> Utf8 Class Initialized
INFO - 2020-04-04 16:33:51 --> URI Class Initialized
INFO - 2020-04-04 16:33:51 --> Router Class Initialized
INFO - 2020-04-04 16:33:51 --> Output Class Initialized
INFO - 2020-04-04 16:33:52 --> Security Class Initialized
DEBUG - 2020-04-04 16:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:33:52 --> CSRF cookie sent
INFO - 2020-04-04 16:33:52 --> Input Class Initialized
INFO - 2020-04-04 16:33:52 --> Language Class Initialized
INFO - 2020-04-04 16:33:52 --> Language Class Initialized
INFO - 2020-04-04 16:33:52 --> Config Class Initialized
INFO - 2020-04-04 16:33:52 --> Loader Class Initialized
INFO - 2020-04-04 16:33:52 --> Helper loaded: url_helper
INFO - 2020-04-04 16:33:52 --> Helper loaded: file_helper
INFO - 2020-04-04 16:33:52 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:33:52 --> Helper loaded: common_helper
INFO - 2020-04-04 16:33:52 --> Helper loaded: language_helper
INFO - 2020-04-04 16:33:52 --> Helper loaded: email_helper
INFO - 2020-04-04 16:33:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:33:52 --> Database Driver Class Initialized
INFO - 2020-04-04 16:33:52 --> Parser Class Initialized
INFO - 2020-04-04 16:33:52 --> User Agent Class Initialized
INFO - 2020-04-04 16:33:52 --> Model Class Initialized
INFO - 2020-04-04 16:33:52 --> Model Class Initialized
DEBUG - 2020-04-04 16:33:52 --> Template Class Initialized
INFO - 2020-04-04 16:33:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:33:52 --> Email Class Initialized
INFO - 2020-04-04 16:33:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:33:52 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:33:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:33:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:33:52 --> Encryption Class Initialized
INFO - 2020-04-04 16:33:52 --> Controller Class Initialized
DEBUG - 2020-04-04 16:33:52 --> post MX_Controller Initialized
INFO - 2020-04-04 16:33:52 --> Model Class Initialized
ERROR - 2020-04-04 16:33:52 --> Could not find the language line ""
ERROR - 2020-04-04 16:33:52 --> Could not find the language line ""
ERROR - 2020-04-04 16:33:52 --> Could not find the language line ""
DEBUG - 2020-04-04 16:33:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:33:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:33:52 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:33:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:33:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:33:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:33:52 --> Final output sent to browser
DEBUG - 2020-04-04 16:33:52 --> Total execution time: 0.8732
INFO - 2020-04-04 16:33:53 --> Config Class Initialized
INFO - 2020-04-04 16:33:53 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:33:53 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:33:53 --> Utf8 Class Initialized
INFO - 2020-04-04 16:33:53 --> URI Class Initialized
INFO - 2020-04-04 16:33:53 --> Router Class Initialized
INFO - 2020-04-04 16:33:53 --> Output Class Initialized
INFO - 2020-04-04 16:33:53 --> Security Class Initialized
DEBUG - 2020-04-04 16:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:33:53 --> CSRF cookie sent
INFO - 2020-04-04 16:33:53 --> Input Class Initialized
INFO - 2020-04-04 16:33:53 --> Language Class Initialized
ERROR - 2020-04-04 16:33:53 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:33:53 --> Config Class Initialized
INFO - 2020-04-04 16:33:53 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:33:53 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:33:53 --> Utf8 Class Initialized
INFO - 2020-04-04 16:33:53 --> URI Class Initialized
INFO - 2020-04-04 16:33:53 --> Router Class Initialized
INFO - 2020-04-04 16:33:53 --> Output Class Initialized
INFO - 2020-04-04 16:33:53 --> Security Class Initialized
DEBUG - 2020-04-04 16:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:33:53 --> CSRF cookie sent
INFO - 2020-04-04 16:33:53 --> Input Class Initialized
INFO - 2020-04-04 16:33:53 --> Language Class Initialized
ERROR - 2020-04-04 16:33:53 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:34:08 --> Config Class Initialized
INFO - 2020-04-04 16:34:08 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:34:08 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:34:08 --> Utf8 Class Initialized
INFO - 2020-04-04 16:34:08 --> URI Class Initialized
INFO - 2020-04-04 16:34:08 --> Router Class Initialized
INFO - 2020-04-04 16:34:08 --> Output Class Initialized
INFO - 2020-04-04 16:34:08 --> Security Class Initialized
DEBUG - 2020-04-04 16:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:34:08 --> CSRF cookie sent
INFO - 2020-04-04 16:34:08 --> Input Class Initialized
INFO - 2020-04-04 16:34:08 --> Language Class Initialized
INFO - 2020-04-04 16:34:08 --> Language Class Initialized
INFO - 2020-04-04 16:34:08 --> Config Class Initialized
INFO - 2020-04-04 16:34:08 --> Loader Class Initialized
INFO - 2020-04-04 16:34:08 --> Helper loaded: url_helper
INFO - 2020-04-04 16:34:08 --> Helper loaded: file_helper
INFO - 2020-04-04 16:34:08 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:34:08 --> Helper loaded: common_helper
INFO - 2020-04-04 16:34:08 --> Helper loaded: language_helper
INFO - 2020-04-04 16:34:08 --> Helper loaded: email_helper
INFO - 2020-04-04 16:34:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:34:08 --> Database Driver Class Initialized
INFO - 2020-04-04 16:34:08 --> Parser Class Initialized
INFO - 2020-04-04 16:34:08 --> User Agent Class Initialized
INFO - 2020-04-04 16:34:08 --> Model Class Initialized
INFO - 2020-04-04 16:34:08 --> Model Class Initialized
DEBUG - 2020-04-04 16:34:08 --> Template Class Initialized
INFO - 2020-04-04 16:34:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:34:09 --> Email Class Initialized
INFO - 2020-04-04 16:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:34:09 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:34:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:34:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:34:09 --> Encryption Class Initialized
INFO - 2020-04-04 16:34:09 --> Controller Class Initialized
DEBUG - 2020-04-04 16:34:09 --> post MX_Controller Initialized
INFO - 2020-04-04 16:34:09 --> Model Class Initialized
ERROR - 2020-04-04 16:34:09 --> Could not find the language line ""
ERROR - 2020-04-04 16:34:09 --> Could not find the language line ""
ERROR - 2020-04-04 16:34:09 --> Could not find the language line ""
DEBUG - 2020-04-04 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:34:09 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:34:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:34:09 --> Final output sent to browser
DEBUG - 2020-04-04 16:34:09 --> Total execution time: 0.8781
INFO - 2020-04-04 16:34:09 --> Config Class Initialized
INFO - 2020-04-04 16:34:09 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:34:09 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:34:09 --> Utf8 Class Initialized
INFO - 2020-04-04 16:34:09 --> URI Class Initialized
INFO - 2020-04-04 16:34:09 --> Router Class Initialized
INFO - 2020-04-04 16:34:09 --> Output Class Initialized
INFO - 2020-04-04 16:34:09 --> Security Class Initialized
DEBUG - 2020-04-04 16:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:34:09 --> CSRF cookie sent
INFO - 2020-04-04 16:34:09 --> Input Class Initialized
INFO - 2020-04-04 16:34:09 --> Language Class Initialized
ERROR - 2020-04-04 16:34:09 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:34:10 --> Config Class Initialized
INFO - 2020-04-04 16:34:10 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:34:10 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:34:10 --> Utf8 Class Initialized
INFO - 2020-04-04 16:34:10 --> URI Class Initialized
INFO - 2020-04-04 16:34:10 --> Router Class Initialized
INFO - 2020-04-04 16:34:10 --> Output Class Initialized
INFO - 2020-04-04 16:34:10 --> Security Class Initialized
DEBUG - 2020-04-04 16:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:34:10 --> CSRF cookie sent
INFO - 2020-04-04 16:34:10 --> Input Class Initialized
INFO - 2020-04-04 16:34:10 --> Language Class Initialized
ERROR - 2020-04-04 16:34:10 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:35:21 --> Config Class Initialized
INFO - 2020-04-04 16:35:21 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:35:21 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:35:21 --> Utf8 Class Initialized
INFO - 2020-04-04 16:35:21 --> URI Class Initialized
INFO - 2020-04-04 16:35:21 --> Router Class Initialized
INFO - 2020-04-04 16:35:21 --> Output Class Initialized
INFO - 2020-04-04 16:35:21 --> Security Class Initialized
DEBUG - 2020-04-04 16:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:35:21 --> CSRF cookie sent
INFO - 2020-04-04 16:35:21 --> Input Class Initialized
INFO - 2020-04-04 16:35:21 --> Language Class Initialized
INFO - 2020-04-04 16:35:21 --> Language Class Initialized
INFO - 2020-04-04 16:35:21 --> Config Class Initialized
INFO - 2020-04-04 16:35:21 --> Loader Class Initialized
INFO - 2020-04-04 16:35:21 --> Helper loaded: url_helper
INFO - 2020-04-04 16:35:21 --> Helper loaded: file_helper
INFO - 2020-04-04 16:35:21 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:35:21 --> Helper loaded: common_helper
INFO - 2020-04-04 16:35:21 --> Helper loaded: language_helper
INFO - 2020-04-04 16:35:21 --> Helper loaded: email_helper
INFO - 2020-04-04 16:35:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:35:21 --> Database Driver Class Initialized
INFO - 2020-04-04 16:35:21 --> Parser Class Initialized
INFO - 2020-04-04 16:35:22 --> User Agent Class Initialized
INFO - 2020-04-04 16:35:22 --> Model Class Initialized
INFO - 2020-04-04 16:35:22 --> Model Class Initialized
DEBUG - 2020-04-04 16:35:22 --> Template Class Initialized
INFO - 2020-04-04 16:35:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:35:22 --> Email Class Initialized
INFO - 2020-04-04 16:35:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:35:22 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:35:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:35:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:35:22 --> Encryption Class Initialized
INFO - 2020-04-04 16:35:22 --> Controller Class Initialized
DEBUG - 2020-04-04 16:35:22 --> post MX_Controller Initialized
INFO - 2020-04-04 16:35:22 --> Model Class Initialized
ERROR - 2020-04-04 16:35:22 --> Could not find the language line ""
ERROR - 2020-04-04 16:35:22 --> Could not find the language line ""
ERROR - 2020-04-04 16:35:22 --> Could not find the language line ""
DEBUG - 2020-04-04 16:35:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:35:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:35:22 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:35:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:35:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:35:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:35:22 --> Final output sent to browser
DEBUG - 2020-04-04 16:35:22 --> Total execution time: 0.9276
INFO - 2020-04-04 16:35:22 --> Config Class Initialized
INFO - 2020-04-04 16:35:22 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:35:22 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:35:22 --> Utf8 Class Initialized
INFO - 2020-04-04 16:35:22 --> URI Class Initialized
INFO - 2020-04-04 16:35:22 --> Router Class Initialized
INFO - 2020-04-04 16:35:22 --> Output Class Initialized
INFO - 2020-04-04 16:35:22 --> Security Class Initialized
DEBUG - 2020-04-04 16:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:35:23 --> CSRF cookie sent
INFO - 2020-04-04 16:35:23 --> Input Class Initialized
INFO - 2020-04-04 16:35:23 --> Language Class Initialized
ERROR - 2020-04-04 16:35:23 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:35:23 --> Config Class Initialized
INFO - 2020-04-04 16:35:23 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:35:23 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:35:23 --> Utf8 Class Initialized
INFO - 2020-04-04 16:35:23 --> URI Class Initialized
INFO - 2020-04-04 16:35:23 --> Router Class Initialized
INFO - 2020-04-04 16:35:23 --> Output Class Initialized
INFO - 2020-04-04 16:35:23 --> Security Class Initialized
DEBUG - 2020-04-04 16:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:35:23 --> CSRF cookie sent
INFO - 2020-04-04 16:35:23 --> Input Class Initialized
INFO - 2020-04-04 16:35:23 --> Language Class Initialized
ERROR - 2020-04-04 16:35:23 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:35:46 --> Config Class Initialized
INFO - 2020-04-04 16:35:46 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:35:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:35:46 --> Utf8 Class Initialized
INFO - 2020-04-04 16:35:46 --> URI Class Initialized
INFO - 2020-04-04 16:35:46 --> Router Class Initialized
INFO - 2020-04-04 16:35:46 --> Output Class Initialized
INFO - 2020-04-04 16:35:46 --> Security Class Initialized
DEBUG - 2020-04-04 16:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:35:46 --> CSRF cookie sent
INFO - 2020-04-04 16:35:46 --> Input Class Initialized
INFO - 2020-04-04 16:35:46 --> Language Class Initialized
INFO - 2020-04-04 16:35:46 --> Language Class Initialized
INFO - 2020-04-04 16:35:46 --> Config Class Initialized
INFO - 2020-04-04 16:35:46 --> Loader Class Initialized
INFO - 2020-04-04 16:35:46 --> Helper loaded: url_helper
INFO - 2020-04-04 16:35:46 --> Helper loaded: file_helper
INFO - 2020-04-04 16:35:46 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:35:46 --> Helper loaded: common_helper
INFO - 2020-04-04 16:35:46 --> Helper loaded: language_helper
INFO - 2020-04-04 16:35:46 --> Helper loaded: email_helper
INFO - 2020-04-04 16:35:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:35:46 --> Database Driver Class Initialized
INFO - 2020-04-04 16:35:46 --> Parser Class Initialized
INFO - 2020-04-04 16:35:46 --> User Agent Class Initialized
INFO - 2020-04-04 16:35:46 --> Model Class Initialized
INFO - 2020-04-04 16:35:46 --> Model Class Initialized
DEBUG - 2020-04-04 16:35:46 --> Template Class Initialized
INFO - 2020-04-04 16:35:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:35:46 --> Email Class Initialized
INFO - 2020-04-04 16:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:35:46 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:35:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:35:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:35:46 --> Encryption Class Initialized
INFO - 2020-04-04 16:35:46 --> Controller Class Initialized
DEBUG - 2020-04-04 16:35:46 --> post MX_Controller Initialized
INFO - 2020-04-04 16:35:46 --> Model Class Initialized
ERROR - 2020-04-04 16:35:46 --> Could not find the language line ""
ERROR - 2020-04-04 16:35:46 --> Could not find the language line ""
ERROR - 2020-04-04 16:35:46 --> Could not find the language line ""
DEBUG - 2020-04-04 16:35:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:35:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:35:46 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:35:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:35:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:35:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:35:46 --> Final output sent to browser
DEBUG - 2020-04-04 16:35:46 --> Total execution time: 0.9042
INFO - 2020-04-04 16:35:47 --> Config Class Initialized
INFO - 2020-04-04 16:35:47 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:35:47 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:35:47 --> Utf8 Class Initialized
INFO - 2020-04-04 16:35:47 --> URI Class Initialized
INFO - 2020-04-04 16:35:47 --> Router Class Initialized
INFO - 2020-04-04 16:35:47 --> Output Class Initialized
INFO - 2020-04-04 16:35:47 --> Security Class Initialized
DEBUG - 2020-04-04 16:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:35:47 --> CSRF cookie sent
INFO - 2020-04-04 16:35:47 --> Input Class Initialized
INFO - 2020-04-04 16:35:47 --> Language Class Initialized
ERROR - 2020-04-04 16:35:47 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:35:47 --> Config Class Initialized
INFO - 2020-04-04 16:35:47 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:35:47 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:35:47 --> Utf8 Class Initialized
INFO - 2020-04-04 16:35:47 --> URI Class Initialized
INFO - 2020-04-04 16:35:47 --> Router Class Initialized
INFO - 2020-04-04 16:35:47 --> Output Class Initialized
INFO - 2020-04-04 16:35:47 --> Security Class Initialized
DEBUG - 2020-04-04 16:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:35:47 --> CSRF cookie sent
INFO - 2020-04-04 16:35:47 --> Input Class Initialized
INFO - 2020-04-04 16:35:47 --> Language Class Initialized
ERROR - 2020-04-04 16:35:47 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:37:44 --> Config Class Initialized
INFO - 2020-04-04 16:37:44 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:37:44 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:37:44 --> Utf8 Class Initialized
INFO - 2020-04-04 16:37:44 --> URI Class Initialized
INFO - 2020-04-04 16:37:44 --> Router Class Initialized
INFO - 2020-04-04 16:37:44 --> Output Class Initialized
INFO - 2020-04-04 16:37:44 --> Security Class Initialized
DEBUG - 2020-04-04 16:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:37:45 --> CSRF cookie sent
INFO - 2020-04-04 16:37:45 --> Input Class Initialized
INFO - 2020-04-04 16:37:45 --> Language Class Initialized
INFO - 2020-04-04 16:37:45 --> Language Class Initialized
INFO - 2020-04-04 16:37:45 --> Config Class Initialized
INFO - 2020-04-04 16:37:45 --> Loader Class Initialized
INFO - 2020-04-04 16:37:45 --> Helper loaded: url_helper
INFO - 2020-04-04 16:37:45 --> Helper loaded: file_helper
INFO - 2020-04-04 16:37:45 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:37:45 --> Helper loaded: common_helper
INFO - 2020-04-04 16:37:45 --> Helper loaded: language_helper
INFO - 2020-04-04 16:37:45 --> Helper loaded: email_helper
INFO - 2020-04-04 16:37:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:37:45 --> Database Driver Class Initialized
INFO - 2020-04-04 16:37:45 --> Parser Class Initialized
INFO - 2020-04-04 16:37:45 --> User Agent Class Initialized
INFO - 2020-04-04 16:37:45 --> Model Class Initialized
INFO - 2020-04-04 16:37:45 --> Model Class Initialized
DEBUG - 2020-04-04 16:37:45 --> Template Class Initialized
INFO - 2020-04-04 16:37:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:37:45 --> Email Class Initialized
INFO - 2020-04-04 16:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:37:45 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:37:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:37:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:37:45 --> Encryption Class Initialized
INFO - 2020-04-04 16:37:45 --> Controller Class Initialized
DEBUG - 2020-04-04 16:37:45 --> post MX_Controller Initialized
INFO - 2020-04-04 16:37:45 --> Model Class Initialized
ERROR - 2020-04-04 16:37:45 --> Could not find the language line ""
ERROR - 2020-04-04 16:37:45 --> Could not find the language line ""
ERROR - 2020-04-04 16:37:45 --> Could not find the language line ""
DEBUG - 2020-04-04 16:37:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:37:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:37:45 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:37:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:37:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:37:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:37:45 --> Final output sent to browser
DEBUG - 2020-04-04 16:37:45 --> Total execution time: 0.9596
INFO - 2020-04-04 16:37:46 --> Config Class Initialized
INFO - 2020-04-04 16:37:46 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:37:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:37:46 --> Utf8 Class Initialized
INFO - 2020-04-04 16:37:46 --> URI Class Initialized
INFO - 2020-04-04 16:37:46 --> Router Class Initialized
INFO - 2020-04-04 16:37:46 --> Output Class Initialized
INFO - 2020-04-04 16:37:46 --> Security Class Initialized
DEBUG - 2020-04-04 16:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:37:46 --> CSRF cookie sent
INFO - 2020-04-04 16:37:46 --> Input Class Initialized
INFO - 2020-04-04 16:37:46 --> Language Class Initialized
ERROR - 2020-04-04 16:37:46 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:37:46 --> Config Class Initialized
INFO - 2020-04-04 16:37:46 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:37:46 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:37:46 --> Utf8 Class Initialized
INFO - 2020-04-04 16:37:46 --> URI Class Initialized
INFO - 2020-04-04 16:37:46 --> Router Class Initialized
INFO - 2020-04-04 16:37:46 --> Output Class Initialized
INFO - 2020-04-04 16:37:46 --> Security Class Initialized
DEBUG - 2020-04-04 16:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:37:46 --> CSRF cookie sent
INFO - 2020-04-04 16:37:46 --> Input Class Initialized
INFO - 2020-04-04 16:37:46 --> Language Class Initialized
ERROR - 2020-04-04 16:37:46 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:38:41 --> Config Class Initialized
INFO - 2020-04-04 16:38:41 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:38:41 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:38:41 --> Utf8 Class Initialized
INFO - 2020-04-04 16:38:41 --> URI Class Initialized
INFO - 2020-04-04 16:38:41 --> Router Class Initialized
INFO - 2020-04-04 16:38:41 --> Output Class Initialized
INFO - 2020-04-04 16:38:41 --> Security Class Initialized
DEBUG - 2020-04-04 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:38:41 --> CSRF cookie sent
INFO - 2020-04-04 16:38:41 --> Input Class Initialized
INFO - 2020-04-04 16:38:41 --> Language Class Initialized
INFO - 2020-04-04 16:38:41 --> Language Class Initialized
INFO - 2020-04-04 16:38:41 --> Config Class Initialized
INFO - 2020-04-04 16:38:41 --> Loader Class Initialized
INFO - 2020-04-04 16:38:41 --> Helper loaded: url_helper
INFO - 2020-04-04 16:38:41 --> Helper loaded: file_helper
INFO - 2020-04-04 16:38:41 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:38:41 --> Helper loaded: common_helper
INFO - 2020-04-04 16:38:41 --> Helper loaded: language_helper
INFO - 2020-04-04 16:38:41 --> Helper loaded: email_helper
INFO - 2020-04-04 16:38:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:38:41 --> Database Driver Class Initialized
INFO - 2020-04-04 16:38:41 --> Parser Class Initialized
INFO - 2020-04-04 16:38:41 --> User Agent Class Initialized
INFO - 2020-04-04 16:38:41 --> Model Class Initialized
INFO - 2020-04-04 16:38:41 --> Model Class Initialized
DEBUG - 2020-04-04 16:38:41 --> Template Class Initialized
INFO - 2020-04-04 16:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:38:41 --> Email Class Initialized
INFO - 2020-04-04 16:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:38:41 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:38:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:38:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:38:41 --> Encryption Class Initialized
INFO - 2020-04-04 16:38:41 --> Controller Class Initialized
DEBUG - 2020-04-04 16:38:41 --> post MX_Controller Initialized
INFO - 2020-04-04 16:38:41 --> Model Class Initialized
ERROR - 2020-04-04 16:38:41 --> Could not find the language line ""
ERROR - 2020-04-04 16:38:42 --> Could not find the language line ""
ERROR - 2020-04-04 16:38:42 --> Could not find the language line ""
DEBUG - 2020-04-04 16:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:38:42 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:38:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:38:42 --> Final output sent to browser
DEBUG - 2020-04-04 16:38:42 --> Total execution time: 0.9455
INFO - 2020-04-04 16:38:42 --> Config Class Initialized
INFO - 2020-04-04 16:38:42 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:38:42 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:38:42 --> Utf8 Class Initialized
INFO - 2020-04-04 16:38:42 --> URI Class Initialized
INFO - 2020-04-04 16:38:42 --> Router Class Initialized
INFO - 2020-04-04 16:38:42 --> Output Class Initialized
INFO - 2020-04-04 16:38:42 --> Security Class Initialized
DEBUG - 2020-04-04 16:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:38:42 --> CSRF cookie sent
INFO - 2020-04-04 16:38:42 --> Input Class Initialized
INFO - 2020-04-04 16:38:42 --> Language Class Initialized
ERROR - 2020-04-04 16:38:42 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:38:42 --> Config Class Initialized
INFO - 2020-04-04 16:38:42 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:38:42 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:38:42 --> Utf8 Class Initialized
INFO - 2020-04-04 16:38:42 --> URI Class Initialized
INFO - 2020-04-04 16:38:43 --> Router Class Initialized
INFO - 2020-04-04 16:38:43 --> Output Class Initialized
INFO - 2020-04-04 16:38:43 --> Security Class Initialized
DEBUG - 2020-04-04 16:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:38:43 --> CSRF cookie sent
INFO - 2020-04-04 16:38:43 --> Input Class Initialized
INFO - 2020-04-04 16:38:43 --> Language Class Initialized
ERROR - 2020-04-04 16:38:43 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:40:11 --> Config Class Initialized
INFO - 2020-04-04 16:40:11 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:40:11 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:40:11 --> Utf8 Class Initialized
INFO - 2020-04-04 16:40:11 --> URI Class Initialized
INFO - 2020-04-04 16:40:11 --> Router Class Initialized
INFO - 2020-04-04 16:40:11 --> Output Class Initialized
INFO - 2020-04-04 16:40:11 --> Security Class Initialized
DEBUG - 2020-04-04 16:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:40:11 --> CSRF cookie sent
INFO - 2020-04-04 16:40:11 --> Input Class Initialized
INFO - 2020-04-04 16:40:11 --> Language Class Initialized
INFO - 2020-04-04 16:40:12 --> Language Class Initialized
INFO - 2020-04-04 16:40:12 --> Config Class Initialized
INFO - 2020-04-04 16:40:12 --> Loader Class Initialized
INFO - 2020-04-04 16:40:12 --> Helper loaded: url_helper
INFO - 2020-04-04 16:40:12 --> Helper loaded: file_helper
INFO - 2020-04-04 16:40:12 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:40:12 --> Helper loaded: common_helper
INFO - 2020-04-04 16:40:12 --> Helper loaded: language_helper
INFO - 2020-04-04 16:40:12 --> Helper loaded: email_helper
INFO - 2020-04-04 16:40:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:40:12 --> Database Driver Class Initialized
INFO - 2020-04-04 16:40:12 --> Parser Class Initialized
INFO - 2020-04-04 16:40:12 --> User Agent Class Initialized
INFO - 2020-04-04 16:40:12 --> Model Class Initialized
INFO - 2020-04-04 16:40:12 --> Model Class Initialized
DEBUG - 2020-04-04 16:40:12 --> Template Class Initialized
INFO - 2020-04-04 16:40:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:40:12 --> Email Class Initialized
INFO - 2020-04-04 16:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:40:12 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:40:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:40:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:40:12 --> Encryption Class Initialized
INFO - 2020-04-04 16:40:12 --> Controller Class Initialized
DEBUG - 2020-04-04 16:40:12 --> post MX_Controller Initialized
INFO - 2020-04-04 16:40:12 --> Model Class Initialized
ERROR - 2020-04-04 16:40:12 --> Could not find the language line ""
ERROR - 2020-04-04 16:40:12 --> Could not find the language line ""
ERROR - 2020-04-04 16:40:12 --> Could not find the language line ""
DEBUG - 2020-04-04 16:40:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:40:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:40:12 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:40:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:40:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:40:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:40:12 --> Final output sent to browser
DEBUG - 2020-04-04 16:40:12 --> Total execution time: 1.0454
INFO - 2020-04-04 16:40:13 --> Config Class Initialized
INFO - 2020-04-04 16:40:13 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:40:13 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:40:13 --> Utf8 Class Initialized
INFO - 2020-04-04 16:40:13 --> URI Class Initialized
INFO - 2020-04-04 16:40:13 --> Router Class Initialized
INFO - 2020-04-04 16:40:13 --> Output Class Initialized
INFO - 2020-04-04 16:40:13 --> Security Class Initialized
DEBUG - 2020-04-04 16:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:40:13 --> CSRF cookie sent
INFO - 2020-04-04 16:40:13 --> Input Class Initialized
INFO - 2020-04-04 16:40:13 --> Language Class Initialized
ERROR - 2020-04-04 16:40:13 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:40:13 --> Config Class Initialized
INFO - 2020-04-04 16:40:13 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:40:13 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:40:13 --> Utf8 Class Initialized
INFO - 2020-04-04 16:40:13 --> URI Class Initialized
INFO - 2020-04-04 16:40:13 --> Router Class Initialized
INFO - 2020-04-04 16:40:13 --> Output Class Initialized
INFO - 2020-04-04 16:40:13 --> Security Class Initialized
DEBUG - 2020-04-04 16:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:40:13 --> CSRF cookie sent
INFO - 2020-04-04 16:40:13 --> Input Class Initialized
INFO - 2020-04-04 16:40:13 --> Language Class Initialized
ERROR - 2020-04-04 16:40:13 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:40:29 --> Config Class Initialized
INFO - 2020-04-04 16:40:29 --> Config Class Initialized
INFO - 2020-04-04 16:40:29 --> Hooks Class Initialized
INFO - 2020-04-04 16:40:29 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:40:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-04 16:40:29 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:40:29 --> Utf8 Class Initialized
INFO - 2020-04-04 16:40:29 --> Utf8 Class Initialized
INFO - 2020-04-04 16:40:29 --> URI Class Initialized
INFO - 2020-04-04 16:40:29 --> URI Class Initialized
INFO - 2020-04-04 16:40:29 --> Router Class Initialized
INFO - 2020-04-04 16:40:29 --> Router Class Initialized
INFO - 2020-04-04 16:40:29 --> Output Class Initialized
INFO - 2020-04-04 16:40:29 --> Output Class Initialized
INFO - 2020-04-04 16:40:29 --> Security Class Initialized
INFO - 2020-04-04 16:40:29 --> Security Class Initialized
DEBUG - 2020-04-04 16:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-04 16:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:40:29 --> CSRF cookie sent
INFO - 2020-04-04 16:40:29 --> CSRF cookie sent
INFO - 2020-04-04 16:40:29 --> Input Class Initialized
INFO - 2020-04-04 16:40:29 --> Input Class Initialized
INFO - 2020-04-04 16:40:29 --> Language Class Initialized
INFO - 2020-04-04 16:40:29 --> Language Class Initialized
ERROR - 2020-04-04 16:40:29 --> 404 Page Not Found: /index
ERROR - 2020-04-04 16:40:29 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:41:26 --> Config Class Initialized
INFO - 2020-04-04 16:41:26 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:41:26 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:41:26 --> Utf8 Class Initialized
INFO - 2020-04-04 16:41:26 --> URI Class Initialized
INFO - 2020-04-04 16:41:26 --> Router Class Initialized
INFO - 2020-04-04 16:41:26 --> Output Class Initialized
INFO - 2020-04-04 16:41:26 --> Security Class Initialized
DEBUG - 2020-04-04 16:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:41:26 --> CSRF cookie sent
INFO - 2020-04-04 16:41:26 --> Input Class Initialized
INFO - 2020-04-04 16:41:26 --> Language Class Initialized
INFO - 2020-04-04 16:41:26 --> Language Class Initialized
INFO - 2020-04-04 16:41:26 --> Config Class Initialized
INFO - 2020-04-04 16:41:26 --> Loader Class Initialized
INFO - 2020-04-04 16:41:26 --> Helper loaded: url_helper
INFO - 2020-04-04 16:41:26 --> Helper loaded: file_helper
INFO - 2020-04-04 16:41:27 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:41:27 --> Helper loaded: common_helper
INFO - 2020-04-04 16:41:27 --> Helper loaded: language_helper
INFO - 2020-04-04 16:41:27 --> Helper loaded: email_helper
INFO - 2020-04-04 16:41:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:41:27 --> Database Driver Class Initialized
INFO - 2020-04-04 16:41:27 --> Parser Class Initialized
INFO - 2020-04-04 16:41:27 --> User Agent Class Initialized
INFO - 2020-04-04 16:41:27 --> Model Class Initialized
INFO - 2020-04-04 16:41:27 --> Model Class Initialized
DEBUG - 2020-04-04 16:41:27 --> Template Class Initialized
INFO - 2020-04-04 16:41:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:41:27 --> Email Class Initialized
INFO - 2020-04-04 16:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:41:27 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:41:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:41:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:41:27 --> Encryption Class Initialized
INFO - 2020-04-04 16:41:27 --> Controller Class Initialized
DEBUG - 2020-04-04 16:41:27 --> post MX_Controller Initialized
INFO - 2020-04-04 16:41:27 --> Model Class Initialized
ERROR - 2020-04-04 16:41:27 --> Could not find the language line ""
ERROR - 2020-04-04 16:41:27 --> Could not find the language line ""
ERROR - 2020-04-04 16:41:27 --> Could not find the language line ""
DEBUG - 2020-04-04 16:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:41:27 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:41:27 --> Final output sent to browser
DEBUG - 2020-04-04 16:41:27 --> Total execution time: 0.9358
INFO - 2020-04-04 16:41:27 --> Config Class Initialized
INFO - 2020-04-04 16:41:27 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:41:28 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:41:28 --> Utf8 Class Initialized
INFO - 2020-04-04 16:41:28 --> URI Class Initialized
INFO - 2020-04-04 16:41:28 --> Router Class Initialized
INFO - 2020-04-04 16:41:28 --> Output Class Initialized
INFO - 2020-04-04 16:41:28 --> Security Class Initialized
DEBUG - 2020-04-04 16:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:41:28 --> CSRF cookie sent
INFO - 2020-04-04 16:41:28 --> Input Class Initialized
INFO - 2020-04-04 16:41:28 --> Language Class Initialized
ERROR - 2020-04-04 16:41:28 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:41:28 --> Config Class Initialized
INFO - 2020-04-04 16:41:28 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:41:28 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:41:28 --> Utf8 Class Initialized
INFO - 2020-04-04 16:41:28 --> URI Class Initialized
INFO - 2020-04-04 16:41:28 --> Router Class Initialized
INFO - 2020-04-04 16:41:28 --> Output Class Initialized
INFO - 2020-04-04 16:41:28 --> Security Class Initialized
DEBUG - 2020-04-04 16:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:41:28 --> CSRF cookie sent
INFO - 2020-04-04 16:41:28 --> Input Class Initialized
INFO - 2020-04-04 16:41:28 --> Language Class Initialized
ERROR - 2020-04-04 16:41:28 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:42:39 --> Config Class Initialized
INFO - 2020-04-04 16:42:39 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:42:39 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:42:39 --> Utf8 Class Initialized
INFO - 2020-04-04 16:42:39 --> URI Class Initialized
INFO - 2020-04-04 16:42:39 --> Router Class Initialized
INFO - 2020-04-04 16:42:39 --> Output Class Initialized
INFO - 2020-04-04 16:42:39 --> Security Class Initialized
DEBUG - 2020-04-04 16:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:42:40 --> CSRF cookie sent
INFO - 2020-04-04 16:42:40 --> Input Class Initialized
INFO - 2020-04-04 16:42:40 --> Language Class Initialized
INFO - 2020-04-04 16:42:40 --> Language Class Initialized
INFO - 2020-04-04 16:42:40 --> Config Class Initialized
INFO - 2020-04-04 16:42:40 --> Loader Class Initialized
INFO - 2020-04-04 16:42:40 --> Helper loaded: url_helper
INFO - 2020-04-04 16:42:40 --> Helper loaded: file_helper
INFO - 2020-04-04 16:42:40 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:42:40 --> Helper loaded: common_helper
INFO - 2020-04-04 16:42:40 --> Helper loaded: language_helper
INFO - 2020-04-04 16:42:40 --> Helper loaded: email_helper
INFO - 2020-04-04 16:42:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:42:40 --> Database Driver Class Initialized
INFO - 2020-04-04 16:42:40 --> Parser Class Initialized
INFO - 2020-04-04 16:42:40 --> User Agent Class Initialized
INFO - 2020-04-04 16:42:40 --> Model Class Initialized
INFO - 2020-04-04 16:42:40 --> Model Class Initialized
DEBUG - 2020-04-04 16:42:40 --> Template Class Initialized
INFO - 2020-04-04 16:42:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:42:40 --> Email Class Initialized
INFO - 2020-04-04 16:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:42:40 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:42:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:42:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:42:40 --> Encryption Class Initialized
INFO - 2020-04-04 16:42:40 --> Controller Class Initialized
DEBUG - 2020-04-04 16:42:40 --> post MX_Controller Initialized
INFO - 2020-04-04 16:42:40 --> Model Class Initialized
ERROR - 2020-04-04 16:42:40 --> Could not find the language line ""
ERROR - 2020-04-04 16:42:40 --> Could not find the language line ""
ERROR - 2020-04-04 16:42:40 --> Could not find the language line ""
DEBUG - 2020-04-04 16:42:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:42:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:42:40 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:42:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:42:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:42:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:42:40 --> Final output sent to browser
DEBUG - 2020-04-04 16:42:40 --> Total execution time: 0.9648
INFO - 2020-04-04 16:42:41 --> Config Class Initialized
INFO - 2020-04-04 16:42:41 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:42:41 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:42:41 --> Utf8 Class Initialized
INFO - 2020-04-04 16:42:41 --> URI Class Initialized
INFO - 2020-04-04 16:42:41 --> Router Class Initialized
INFO - 2020-04-04 16:42:41 --> Output Class Initialized
INFO - 2020-04-04 16:42:41 --> Security Class Initialized
DEBUG - 2020-04-04 16:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:42:41 --> CSRF cookie sent
INFO - 2020-04-04 16:42:41 --> Input Class Initialized
INFO - 2020-04-04 16:42:41 --> Language Class Initialized
ERROR - 2020-04-04 16:42:41 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:42:41 --> Config Class Initialized
INFO - 2020-04-04 16:42:41 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:42:41 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:42:41 --> Utf8 Class Initialized
INFO - 2020-04-04 16:42:41 --> URI Class Initialized
INFO - 2020-04-04 16:42:41 --> Router Class Initialized
INFO - 2020-04-04 16:42:41 --> Output Class Initialized
INFO - 2020-04-04 16:42:41 --> Security Class Initialized
DEBUG - 2020-04-04 16:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:42:41 --> CSRF cookie sent
INFO - 2020-04-04 16:42:41 --> Input Class Initialized
INFO - 2020-04-04 16:42:41 --> Language Class Initialized
ERROR - 2020-04-04 16:42:41 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:43:43 --> Config Class Initialized
INFO - 2020-04-04 16:43:43 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:43:43 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:43:43 --> Utf8 Class Initialized
INFO - 2020-04-04 16:43:43 --> URI Class Initialized
INFO - 2020-04-04 16:43:43 --> Router Class Initialized
INFO - 2020-04-04 16:43:43 --> Output Class Initialized
INFO - 2020-04-04 16:43:43 --> Security Class Initialized
DEBUG - 2020-04-04 16:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:43:43 --> CSRF cookie sent
INFO - 2020-04-04 16:43:43 --> Input Class Initialized
INFO - 2020-04-04 16:43:43 --> Language Class Initialized
INFO - 2020-04-04 16:43:43 --> Language Class Initialized
INFO - 2020-04-04 16:43:43 --> Config Class Initialized
INFO - 2020-04-04 16:43:43 --> Loader Class Initialized
INFO - 2020-04-04 16:43:43 --> Helper loaded: url_helper
INFO - 2020-04-04 16:43:43 --> Helper loaded: file_helper
INFO - 2020-04-04 16:43:43 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:43:43 --> Helper loaded: common_helper
INFO - 2020-04-04 16:43:43 --> Helper loaded: language_helper
INFO - 2020-04-04 16:43:43 --> Helper loaded: email_helper
INFO - 2020-04-04 16:43:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:43:43 --> Database Driver Class Initialized
INFO - 2020-04-04 16:43:43 --> Parser Class Initialized
INFO - 2020-04-04 16:43:43 --> User Agent Class Initialized
INFO - 2020-04-04 16:43:43 --> Model Class Initialized
INFO - 2020-04-04 16:43:43 --> Model Class Initialized
DEBUG - 2020-04-04 16:43:43 --> Template Class Initialized
INFO - 2020-04-04 16:43:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:43:44 --> Email Class Initialized
INFO - 2020-04-04 16:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:43:44 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:43:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:43:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:43:44 --> Encryption Class Initialized
INFO - 2020-04-04 16:43:44 --> Controller Class Initialized
DEBUG - 2020-04-04 16:43:44 --> post MX_Controller Initialized
INFO - 2020-04-04 16:43:44 --> Model Class Initialized
ERROR - 2020-04-04 16:43:44 --> Could not find the language line ""
ERROR - 2020-04-04 16:43:44 --> Could not find the language line ""
ERROR - 2020-04-04 16:43:44 --> Could not find the language line ""
DEBUG - 2020-04-04 16:43:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:43:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:43:44 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:43:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:43:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:43:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:43:44 --> Final output sent to browser
DEBUG - 2020-04-04 16:43:44 --> Total execution time: 0.8922
INFO - 2020-04-04 16:43:44 --> Config Class Initialized
INFO - 2020-04-04 16:43:44 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:43:44 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:43:44 --> Utf8 Class Initialized
INFO - 2020-04-04 16:43:44 --> URI Class Initialized
INFO - 2020-04-04 16:43:44 --> Router Class Initialized
INFO - 2020-04-04 16:43:44 --> Output Class Initialized
INFO - 2020-04-04 16:43:44 --> Security Class Initialized
DEBUG - 2020-04-04 16:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:43:44 --> CSRF cookie sent
INFO - 2020-04-04 16:43:44 --> Input Class Initialized
INFO - 2020-04-04 16:43:44 --> Language Class Initialized
ERROR - 2020-04-04 16:43:45 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:43:45 --> Config Class Initialized
INFO - 2020-04-04 16:43:45 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:43:45 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:43:45 --> Utf8 Class Initialized
INFO - 2020-04-04 16:43:45 --> URI Class Initialized
INFO - 2020-04-04 16:43:45 --> Router Class Initialized
INFO - 2020-04-04 16:43:45 --> Output Class Initialized
INFO - 2020-04-04 16:43:45 --> Security Class Initialized
DEBUG - 2020-04-04 16:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:43:45 --> CSRF cookie sent
INFO - 2020-04-04 16:43:45 --> Input Class Initialized
INFO - 2020-04-04 16:43:45 --> Language Class Initialized
ERROR - 2020-04-04 16:43:45 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:45:24 --> Config Class Initialized
INFO - 2020-04-04 16:45:24 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:45:24 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:45:24 --> Utf8 Class Initialized
INFO - 2020-04-04 16:45:24 --> URI Class Initialized
INFO - 2020-04-04 16:45:24 --> Router Class Initialized
INFO - 2020-04-04 16:45:24 --> Output Class Initialized
INFO - 2020-04-04 16:45:24 --> Security Class Initialized
DEBUG - 2020-04-04 16:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:45:24 --> CSRF cookie sent
INFO - 2020-04-04 16:45:24 --> Input Class Initialized
INFO - 2020-04-04 16:45:24 --> Language Class Initialized
INFO - 2020-04-04 16:45:24 --> Language Class Initialized
INFO - 2020-04-04 16:45:24 --> Config Class Initialized
INFO - 2020-04-04 16:45:24 --> Loader Class Initialized
INFO - 2020-04-04 16:45:24 --> Helper loaded: url_helper
INFO - 2020-04-04 16:45:24 --> Helper loaded: file_helper
INFO - 2020-04-04 16:45:24 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:45:24 --> Helper loaded: common_helper
INFO - 2020-04-04 16:45:24 --> Helper loaded: language_helper
INFO - 2020-04-04 16:45:24 --> Helper loaded: email_helper
INFO - 2020-04-04 16:45:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:45:24 --> Database Driver Class Initialized
INFO - 2020-04-04 16:45:24 --> Parser Class Initialized
INFO - 2020-04-04 16:45:24 --> User Agent Class Initialized
INFO - 2020-04-04 16:45:24 --> Model Class Initialized
INFO - 2020-04-04 16:45:24 --> Model Class Initialized
DEBUG - 2020-04-04 16:45:24 --> Template Class Initialized
INFO - 2020-04-04 16:45:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:45:24 --> Email Class Initialized
INFO - 2020-04-04 16:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:45:24 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:45:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:45:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:45:24 --> Encryption Class Initialized
INFO - 2020-04-04 16:45:24 --> Controller Class Initialized
DEBUG - 2020-04-04 16:45:24 --> post MX_Controller Initialized
INFO - 2020-04-04 16:45:24 --> Model Class Initialized
ERROR - 2020-04-04 16:45:25 --> Could not find the language line ""
ERROR - 2020-04-04 16:45:25 --> Could not find the language line ""
ERROR - 2020-04-04 16:45:25 --> Could not find the language line ""
DEBUG - 2020-04-04 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:45:25 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:45:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:45:25 --> Final output sent to browser
DEBUG - 2020-04-04 16:45:25 --> Total execution time: 0.9325
INFO - 2020-04-04 16:45:25 --> Config Class Initialized
INFO - 2020-04-04 16:45:25 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:45:25 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:45:25 --> Utf8 Class Initialized
INFO - 2020-04-04 16:45:25 --> URI Class Initialized
INFO - 2020-04-04 16:45:25 --> Router Class Initialized
INFO - 2020-04-04 16:45:25 --> Output Class Initialized
INFO - 2020-04-04 16:45:25 --> Security Class Initialized
DEBUG - 2020-04-04 16:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:45:25 --> CSRF cookie sent
INFO - 2020-04-04 16:45:25 --> Input Class Initialized
INFO - 2020-04-04 16:45:25 --> Language Class Initialized
ERROR - 2020-04-04 16:45:25 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:45:25 --> Config Class Initialized
INFO - 2020-04-04 16:45:25 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:45:25 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:45:25 --> Utf8 Class Initialized
INFO - 2020-04-04 16:45:26 --> URI Class Initialized
INFO - 2020-04-04 16:45:26 --> Router Class Initialized
INFO - 2020-04-04 16:45:26 --> Output Class Initialized
INFO - 2020-04-04 16:45:26 --> Security Class Initialized
DEBUG - 2020-04-04 16:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:45:26 --> CSRF cookie sent
INFO - 2020-04-04 16:45:26 --> Input Class Initialized
INFO - 2020-04-04 16:45:26 --> Language Class Initialized
ERROR - 2020-04-04 16:45:26 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:45:58 --> Config Class Initialized
INFO - 2020-04-04 16:45:58 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:45:58 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:45:58 --> Utf8 Class Initialized
INFO - 2020-04-04 16:45:58 --> URI Class Initialized
INFO - 2020-04-04 16:45:58 --> Router Class Initialized
INFO - 2020-04-04 16:45:58 --> Output Class Initialized
INFO - 2020-04-04 16:45:58 --> Security Class Initialized
DEBUG - 2020-04-04 16:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:45:58 --> CSRF cookie sent
INFO - 2020-04-04 16:45:58 --> Input Class Initialized
INFO - 2020-04-04 16:45:58 --> Language Class Initialized
INFO - 2020-04-04 16:45:58 --> Language Class Initialized
INFO - 2020-04-04 16:45:58 --> Config Class Initialized
INFO - 2020-04-04 16:45:59 --> Loader Class Initialized
INFO - 2020-04-04 16:45:59 --> Helper loaded: url_helper
INFO - 2020-04-04 16:45:59 --> Helper loaded: file_helper
INFO - 2020-04-04 16:45:59 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:45:59 --> Helper loaded: common_helper
INFO - 2020-04-04 16:45:59 --> Helper loaded: language_helper
INFO - 2020-04-04 16:45:59 --> Helper loaded: email_helper
INFO - 2020-04-04 16:45:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:45:59 --> Database Driver Class Initialized
INFO - 2020-04-04 16:45:59 --> Parser Class Initialized
INFO - 2020-04-04 16:45:59 --> User Agent Class Initialized
INFO - 2020-04-04 16:45:59 --> Model Class Initialized
INFO - 2020-04-04 16:45:59 --> Model Class Initialized
DEBUG - 2020-04-04 16:45:59 --> Template Class Initialized
INFO - 2020-04-04 16:45:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:45:59 --> Email Class Initialized
INFO - 2020-04-04 16:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:45:59 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:45:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:45:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:45:59 --> Encryption Class Initialized
INFO - 2020-04-04 16:45:59 --> Controller Class Initialized
DEBUG - 2020-04-04 16:45:59 --> post MX_Controller Initialized
INFO - 2020-04-04 16:45:59 --> Model Class Initialized
ERROR - 2020-04-04 16:45:59 --> Could not find the language line ""
ERROR - 2020-04-04 16:45:59 --> Could not find the language line ""
ERROR - 2020-04-04 16:45:59 --> Could not find the language line ""
DEBUG - 2020-04-04 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:45:59 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:45:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:45:59 --> Final output sent to browser
DEBUG - 2020-04-04 16:45:59 --> Total execution time: 0.9050
INFO - 2020-04-04 16:45:59 --> Config Class Initialized
INFO - 2020-04-04 16:46:00 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:46:00 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:46:00 --> Utf8 Class Initialized
INFO - 2020-04-04 16:46:00 --> URI Class Initialized
INFO - 2020-04-04 16:46:00 --> Router Class Initialized
INFO - 2020-04-04 16:46:00 --> Output Class Initialized
INFO - 2020-04-04 16:46:00 --> Security Class Initialized
DEBUG - 2020-04-04 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:46:00 --> CSRF cookie sent
INFO - 2020-04-04 16:46:00 --> Input Class Initialized
INFO - 2020-04-04 16:46:00 --> Language Class Initialized
ERROR - 2020-04-04 16:46:00 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:46:00 --> Config Class Initialized
INFO - 2020-04-04 16:46:00 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:46:00 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:46:00 --> Utf8 Class Initialized
INFO - 2020-04-04 16:46:00 --> URI Class Initialized
INFO - 2020-04-04 16:46:00 --> Router Class Initialized
INFO - 2020-04-04 16:46:00 --> Output Class Initialized
INFO - 2020-04-04 16:46:00 --> Security Class Initialized
DEBUG - 2020-04-04 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:46:00 --> CSRF cookie sent
INFO - 2020-04-04 16:46:00 --> Input Class Initialized
INFO - 2020-04-04 16:46:00 --> Language Class Initialized
ERROR - 2020-04-04 16:46:00 --> 404 Page Not Found: /index
INFO - 2020-04-04 16:46:12 --> Config Class Initialized
INFO - 2020-04-04 16:46:12 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:46:12 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:46:12 --> Utf8 Class Initialized
INFO - 2020-04-04 16:46:12 --> URI Class Initialized
INFO - 2020-04-04 16:46:12 --> Router Class Initialized
INFO - 2020-04-04 16:46:12 --> Output Class Initialized
INFO - 2020-04-04 16:46:13 --> Security Class Initialized
DEBUG - 2020-04-04 16:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:46:13 --> CSRF cookie sent
INFO - 2020-04-04 16:46:13 --> Input Class Initialized
INFO - 2020-04-04 16:46:13 --> Language Class Initialized
INFO - 2020-04-04 16:46:13 --> Language Class Initialized
INFO - 2020-04-04 16:46:13 --> Config Class Initialized
INFO - 2020-04-04 16:46:13 --> Loader Class Initialized
INFO - 2020-04-04 16:46:13 --> Helper loaded: url_helper
INFO - 2020-04-04 16:46:13 --> Helper loaded: file_helper
INFO - 2020-04-04 16:46:13 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:46:13 --> Helper loaded: common_helper
INFO - 2020-04-04 16:46:13 --> Helper loaded: language_helper
INFO - 2020-04-04 16:46:13 --> Helper loaded: email_helper
INFO - 2020-04-04 16:46:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:46:13 --> Database Driver Class Initialized
INFO - 2020-04-04 16:46:13 --> Parser Class Initialized
INFO - 2020-04-04 16:46:13 --> User Agent Class Initialized
INFO - 2020-04-04 16:46:13 --> Model Class Initialized
INFO - 2020-04-04 16:46:13 --> Model Class Initialized
DEBUG - 2020-04-04 16:46:13 --> Template Class Initialized
INFO - 2020-04-04 16:46:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:46:13 --> Email Class Initialized
INFO - 2020-04-04 16:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:46:13 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:46:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:46:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:46:13 --> Encryption Class Initialized
INFO - 2020-04-04 16:46:13 --> Controller Class Initialized
DEBUG - 2020-04-04 16:46:13 --> post MX_Controller Initialized
INFO - 2020-04-04 16:46:13 --> Model Class Initialized
ERROR - 2020-04-04 16:46:13 --> Could not find the language line ""
ERROR - 2020-04-04 16:46:13 --> Could not find the language line ""
ERROR - 2020-04-04 16:46:13 --> Could not find the language line ""
DEBUG - 2020-04-04 16:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:46:13 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:46:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:46:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:46:14 --> Final output sent to browser
DEBUG - 2020-04-04 16:46:14 --> Total execution time: 1.2055
INFO - 2020-04-04 16:46:48 --> Config Class Initialized
INFO - 2020-04-04 16:46:48 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:46:48 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:46:48 --> Utf8 Class Initialized
INFO - 2020-04-04 16:46:48 --> URI Class Initialized
INFO - 2020-04-04 16:46:48 --> Router Class Initialized
INFO - 2020-04-04 16:46:48 --> Output Class Initialized
INFO - 2020-04-04 16:46:48 --> Security Class Initialized
DEBUG - 2020-04-04 16:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:46:48 --> CSRF cookie sent
INFO - 2020-04-04 16:46:48 --> Input Class Initialized
INFO - 2020-04-04 16:46:48 --> Language Class Initialized
INFO - 2020-04-04 16:46:48 --> Language Class Initialized
INFO - 2020-04-04 16:46:48 --> Config Class Initialized
INFO - 2020-04-04 16:46:48 --> Loader Class Initialized
INFO - 2020-04-04 16:46:48 --> Helper loaded: url_helper
INFO - 2020-04-04 16:46:48 --> Helper loaded: file_helper
INFO - 2020-04-04 16:46:48 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:46:48 --> Helper loaded: common_helper
INFO - 2020-04-04 16:46:49 --> Helper loaded: language_helper
INFO - 2020-04-04 16:46:49 --> Helper loaded: email_helper
INFO - 2020-04-04 16:46:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:46:49 --> Database Driver Class Initialized
INFO - 2020-04-04 16:46:49 --> Parser Class Initialized
INFO - 2020-04-04 16:46:49 --> User Agent Class Initialized
INFO - 2020-04-04 16:46:49 --> Model Class Initialized
INFO - 2020-04-04 16:46:49 --> Model Class Initialized
DEBUG - 2020-04-04 16:46:49 --> Template Class Initialized
INFO - 2020-04-04 16:46:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:46:49 --> Email Class Initialized
INFO - 2020-04-04 16:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:46:49 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:46:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:46:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:46:49 --> Encryption Class Initialized
INFO - 2020-04-04 16:46:49 --> Controller Class Initialized
DEBUG - 2020-04-04 16:46:49 --> post MX_Controller Initialized
INFO - 2020-04-04 16:46:49 --> Model Class Initialized
ERROR - 2020-04-04 16:46:49 --> Could not find the language line ""
ERROR - 2020-04-04 16:46:49 --> Could not find the language line ""
ERROR - 2020-04-04 16:46:49 --> Could not find the language line ""
DEBUG - 2020-04-04 16:46:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:46:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:46:49 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:46:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:46:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:46:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:46:49 --> Final output sent to browser
DEBUG - 2020-04-04 16:46:49 --> Total execution time: 0.8912
INFO - 2020-04-04 16:47:31 --> Config Class Initialized
INFO - 2020-04-04 16:47:31 --> Hooks Class Initialized
DEBUG - 2020-04-04 16:47:31 --> UTF-8 Support Enabled
INFO - 2020-04-04 16:47:31 --> Utf8 Class Initialized
INFO - 2020-04-04 16:47:31 --> URI Class Initialized
INFO - 2020-04-04 16:47:31 --> Router Class Initialized
INFO - 2020-04-04 16:47:31 --> Output Class Initialized
INFO - 2020-04-04 16:47:31 --> Security Class Initialized
DEBUG - 2020-04-04 16:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-04 16:47:31 --> CSRF cookie sent
INFO - 2020-04-04 16:47:31 --> Input Class Initialized
INFO - 2020-04-04 16:47:31 --> Language Class Initialized
INFO - 2020-04-04 16:47:31 --> Language Class Initialized
INFO - 2020-04-04 16:47:31 --> Config Class Initialized
INFO - 2020-04-04 16:47:31 --> Loader Class Initialized
INFO - 2020-04-04 16:47:31 --> Helper loaded: url_helper
INFO - 2020-04-04 16:47:31 --> Helper loaded: file_helper
INFO - 2020-04-04 16:47:31 --> Helper loaded: cookie_helper
INFO - 2020-04-04 16:47:31 --> Helper loaded: common_helper
INFO - 2020-04-04 16:47:31 --> Helper loaded: language_helper
INFO - 2020-04-04 16:47:31 --> Helper loaded: email_helper
INFO - 2020-04-04 16:47:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-04 16:47:31 --> Database Driver Class Initialized
INFO - 2020-04-04 16:47:31 --> Parser Class Initialized
INFO - 2020-04-04 16:47:31 --> User Agent Class Initialized
INFO - 2020-04-04 16:47:31 --> Model Class Initialized
INFO - 2020-04-04 16:47:31 --> Model Class Initialized
DEBUG - 2020-04-04 16:47:31 --> Template Class Initialized
INFO - 2020-04-04 16:47:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-04 16:47:32 --> Email Class Initialized
INFO - 2020-04-04 16:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-04 16:47:32 --> Pagination Class Initialized
DEBUG - 2020-04-04 16:47:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-04 16:47:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-04 16:47:32 --> Encryption Class Initialized
INFO - 2020-04-04 16:47:32 --> Controller Class Initialized
DEBUG - 2020-04-04 16:47:32 --> post MX_Controller Initialized
INFO - 2020-04-04 16:47:32 --> Model Class Initialized
ERROR - 2020-04-04 16:47:32 --> Could not find the language line ""
ERROR - 2020-04-04 16:47:32 --> Could not find the language line ""
ERROR - 2020-04-04 16:47:32 --> Could not find the language line ""
DEBUG - 2020-04-04 16:47:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-04 16:47:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-04 16:47:32 --> blocks MX_Controller Initialized
DEBUG - 2020-04-04 16:47:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-04 16:47:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-04 16:47:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-04 16:47:32 --> Final output sent to browser
DEBUG - 2020-04-04 16:47:32 --> Total execution time: 0.9277
