<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-21 03:13:55 --> Config Class Initialized
INFO - 2020-04-21 03:13:55 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:13:55 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:13:55 --> Utf8 Class Initialized
INFO - 2020-04-21 03:13:55 --> URI Class Initialized
DEBUG - 2020-04-21 03:13:55 --> No URI present. Default controller set.
INFO - 2020-04-21 03:13:55 --> Router Class Initialized
INFO - 2020-04-21 03:13:55 --> Output Class Initialized
INFO - 2020-04-21 03:13:55 --> Security Class Initialized
DEBUG - 2020-04-21 03:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:13:55 --> CSRF cookie sent
INFO - 2020-04-21 03:13:55 --> Input Class Initialized
INFO - 2020-04-21 03:13:55 --> Language Class Initialized
INFO - 2020-04-21 03:13:55 --> Language Class Initialized
INFO - 2020-04-21 03:13:55 --> Config Class Initialized
INFO - 2020-04-21 03:13:55 --> Loader Class Initialized
INFO - 2020-04-21 03:13:55 --> Helper loaded: url_helper
INFO - 2020-04-21 03:13:55 --> Helper loaded: file_helper
INFO - 2020-04-21 03:13:55 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:13:55 --> Helper loaded: common_helper
INFO - 2020-04-21 03:13:55 --> Helper loaded: language_helper
INFO - 2020-04-21 03:13:55 --> Helper loaded: email_helper
INFO - 2020-04-21 03:13:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:13:55 --> Database Driver Class Initialized
INFO - 2020-04-21 03:13:55 --> Parser Class Initialized
INFO - 2020-04-21 03:13:55 --> User Agent Class Initialized
INFO - 2020-04-21 03:13:55 --> Model Class Initialized
INFO - 2020-04-21 03:13:55 --> Model Class Initialized
DEBUG - 2020-04-21 03:13:56 --> Template Class Initialized
INFO - 2020-04-21 03:13:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:13:56 --> Email Class Initialized
INFO - 2020-04-21 03:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:13:56 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:13:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:13:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:13:56 --> Encryption Class Initialized
INFO - 2020-04-21 03:13:56 --> Controller Class Initialized
DEBUG - 2020-04-21 03:13:56 --> home MX_Controller Initialized
INFO - 2020-04-21 03:13:56 --> Model Class Initialized
INFO - 2020-04-21 03:13:56 --> Config Class Initialized
INFO - 2020-04-21 03:13:56 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:13:56 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:13:56 --> Utf8 Class Initialized
INFO - 2020-04-21 03:13:56 --> URI Class Initialized
INFO - 2020-04-21 03:13:56 --> Router Class Initialized
INFO - 2020-04-21 03:13:56 --> Output Class Initialized
INFO - 2020-04-21 03:13:56 --> Security Class Initialized
DEBUG - 2020-04-21 03:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:13:56 --> CSRF cookie sent
INFO - 2020-04-21 03:13:56 --> Input Class Initialized
INFO - 2020-04-21 03:13:56 --> Language Class Initialized
INFO - 2020-04-21 03:13:56 --> Language Class Initialized
INFO - 2020-04-21 03:13:56 --> Config Class Initialized
INFO - 2020-04-21 03:13:56 --> Loader Class Initialized
INFO - 2020-04-21 03:13:56 --> Helper loaded: url_helper
INFO - 2020-04-21 03:13:56 --> Helper loaded: file_helper
INFO - 2020-04-21 03:13:56 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:13:56 --> Helper loaded: common_helper
INFO - 2020-04-21 03:13:56 --> Helper loaded: language_helper
INFO - 2020-04-21 03:13:56 --> Helper loaded: email_helper
INFO - 2020-04-21 03:13:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:13:56 --> Database Driver Class Initialized
INFO - 2020-04-21 03:13:56 --> Parser Class Initialized
INFO - 2020-04-21 03:13:56 --> User Agent Class Initialized
INFO - 2020-04-21 03:13:56 --> Model Class Initialized
INFO - 2020-04-21 03:13:56 --> Model Class Initialized
DEBUG - 2020-04-21 03:13:56 --> Template Class Initialized
INFO - 2020-04-21 03:13:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:13:56 --> Email Class Initialized
INFO - 2020-04-21 03:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:13:56 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:13:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:13:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:13:56 --> Encryption Class Initialized
INFO - 2020-04-21 03:13:56 --> Controller Class Initialized
DEBUG - 2020-04-21 03:13:56 --> twitter MX_Controller Initialized
INFO - 2020-04-21 03:13:56 --> Model Class Initialized
DEBUG - 2020-04-21 03:13:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-21 03:13:56 --> Model Class Initialized
DEBUG - 2020-04-21 03:13:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/views/index.php
DEBUG - 2020-04-21 03:13:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:13:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:13:57 --> Final output sent to browser
DEBUG - 2020-04-21 03:13:57 --> Total execution time: 0.6709
INFO - 2020-04-21 03:14:02 --> Config Class Initialized
INFO - 2020-04-21 03:14:02 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:14:02 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:14:02 --> Utf8 Class Initialized
INFO - 2020-04-21 03:14:02 --> URI Class Initialized
INFO - 2020-04-21 03:14:02 --> Router Class Initialized
INFO - 2020-04-21 03:14:02 --> Output Class Initialized
INFO - 2020-04-21 03:14:02 --> Security Class Initialized
DEBUG - 2020-04-21 03:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:14:02 --> CSRF cookie sent
INFO - 2020-04-21 03:14:02 --> Input Class Initialized
INFO - 2020-04-21 03:14:02 --> Language Class Initialized
INFO - 2020-04-21 03:14:02 --> Language Class Initialized
INFO - 2020-04-21 03:14:02 --> Config Class Initialized
INFO - 2020-04-21 03:14:03 --> Loader Class Initialized
INFO - 2020-04-21 03:14:03 --> Helper loaded: url_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: file_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: common_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: language_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: email_helper
INFO - 2020-04-21 03:14:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:14:03 --> Database Driver Class Initialized
INFO - 2020-04-21 03:14:03 --> Parser Class Initialized
INFO - 2020-04-21 03:14:03 --> User Agent Class Initialized
INFO - 2020-04-21 03:14:03 --> Model Class Initialized
INFO - 2020-04-21 03:14:03 --> Model Class Initialized
DEBUG - 2020-04-21 03:14:03 --> Template Class Initialized
INFO - 2020-04-21 03:14:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:14:03 --> Email Class Initialized
INFO - 2020-04-21 03:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:14:03 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:14:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:14:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:14:03 --> Encryption Class Initialized
INFO - 2020-04-21 03:14:03 --> Controller Class Initialized
DEBUG - 2020-04-21 03:14:03 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:14:03 --> Model Class Initialized
INFO - 2020-04-21 03:14:03 --> Config Class Initialized
INFO - 2020-04-21 03:14:03 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:14:03 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:14:03 --> Utf8 Class Initialized
INFO - 2020-04-21 03:14:03 --> URI Class Initialized
INFO - 2020-04-21 03:14:03 --> Router Class Initialized
INFO - 2020-04-21 03:14:03 --> Output Class Initialized
INFO - 2020-04-21 03:14:03 --> Security Class Initialized
DEBUG - 2020-04-21 03:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:14:03 --> CSRF cookie sent
INFO - 2020-04-21 03:14:03 --> Input Class Initialized
INFO - 2020-04-21 03:14:03 --> Language Class Initialized
INFO - 2020-04-21 03:14:03 --> Language Class Initialized
INFO - 2020-04-21 03:14:03 --> Config Class Initialized
INFO - 2020-04-21 03:14:03 --> Loader Class Initialized
INFO - 2020-04-21 03:14:03 --> Helper loaded: url_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: file_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: common_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: language_helper
INFO - 2020-04-21 03:14:03 --> Helper loaded: email_helper
INFO - 2020-04-21 03:14:03 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:14:03 --> Database Driver Class Initialized
INFO - 2020-04-21 03:14:03 --> Parser Class Initialized
INFO - 2020-04-21 03:14:03 --> User Agent Class Initialized
INFO - 2020-04-21 03:14:03 --> Model Class Initialized
INFO - 2020-04-21 03:14:03 --> Model Class Initialized
DEBUG - 2020-04-21 03:14:03 --> Template Class Initialized
INFO - 2020-04-21 03:14:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:14:03 --> Email Class Initialized
INFO - 2020-04-21 03:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:14:03 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:14:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:14:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:14:03 --> Encryption Class Initialized
INFO - 2020-04-21 03:14:03 --> Controller Class Initialized
DEBUG - 2020-04-21 03:14:03 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:14:03 --> Model Class Initialized
INFO - 2020-04-21 03:14:03 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 03:14:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-21 03:14:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 03:14:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:14:03 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:14:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:14:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:14:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:14:03 --> Final output sent to browser
DEBUG - 2020-04-21 03:14:03 --> Total execution time: 0.6438
INFO - 2020-04-21 03:14:06 --> Config Class Initialized
INFO - 2020-04-21 03:14:06 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:14:06 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:14:06 --> Utf8 Class Initialized
INFO - 2020-04-21 03:14:06 --> URI Class Initialized
INFO - 2020-04-21 03:14:06 --> Router Class Initialized
INFO - 2020-04-21 03:14:06 --> Output Class Initialized
INFO - 2020-04-21 03:14:06 --> Security Class Initialized
DEBUG - 2020-04-21 03:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:14:06 --> CSRF cookie sent
INFO - 2020-04-21 03:14:06 --> Input Class Initialized
INFO - 2020-04-21 03:14:06 --> Language Class Initialized
INFO - 2020-04-21 03:14:06 --> Language Class Initialized
INFO - 2020-04-21 03:14:06 --> Config Class Initialized
INFO - 2020-04-21 03:14:06 --> Loader Class Initialized
INFO - 2020-04-21 03:14:06 --> Helper loaded: url_helper
INFO - 2020-04-21 03:14:06 --> Helper loaded: file_helper
INFO - 2020-04-21 03:14:06 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:14:06 --> Helper loaded: common_helper
INFO - 2020-04-21 03:14:06 --> Helper loaded: language_helper
INFO - 2020-04-21 03:14:06 --> Helper loaded: email_helper
INFO - 2020-04-21 03:14:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:14:06 --> Database Driver Class Initialized
INFO - 2020-04-21 03:14:06 --> Parser Class Initialized
INFO - 2020-04-21 03:14:06 --> User Agent Class Initialized
INFO - 2020-04-21 03:14:06 --> Model Class Initialized
INFO - 2020-04-21 03:14:06 --> Model Class Initialized
DEBUG - 2020-04-21 03:14:06 --> Template Class Initialized
INFO - 2020-04-21 03:14:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:14:06 --> Email Class Initialized
INFO - 2020-04-21 03:14:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:14:06 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:14:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:14:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:14:06 --> Encryption Class Initialized
INFO - 2020-04-21 03:14:06 --> Controller Class Initialized
DEBUG - 2020-04-21 03:14:06 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:14:06 --> Model Class Initialized
DEBUG - 2020-04-21 03:14:06 --> module MX_Controller Initialized
INFO - 2020-04-21 03:14:07 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 03:14:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 03:14:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 03:14:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:14:07 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:14:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:14:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:14:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:14:08 --> Final output sent to browser
DEBUG - 2020-04-21 03:14:08 --> Total execution time: 1.9359
INFO - 2020-04-21 03:39:08 --> Config Class Initialized
INFO - 2020-04-21 03:39:08 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:39:08 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:39:08 --> Utf8 Class Initialized
INFO - 2020-04-21 03:39:08 --> URI Class Initialized
INFO - 2020-04-21 03:39:08 --> Router Class Initialized
INFO - 2020-04-21 03:39:08 --> Output Class Initialized
INFO - 2020-04-21 03:39:08 --> Security Class Initialized
DEBUG - 2020-04-21 03:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:39:09 --> CSRF cookie sent
INFO - 2020-04-21 03:39:09 --> Input Class Initialized
INFO - 2020-04-21 03:39:09 --> Language Class Initialized
INFO - 2020-04-21 03:39:09 --> Language Class Initialized
INFO - 2020-04-21 03:39:09 --> Config Class Initialized
INFO - 2020-04-21 03:39:09 --> Loader Class Initialized
INFO - 2020-04-21 03:39:09 --> Helper loaded: url_helper
INFO - 2020-04-21 03:39:09 --> Helper loaded: file_helper
INFO - 2020-04-21 03:39:09 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:39:09 --> Helper loaded: common_helper
INFO - 2020-04-21 03:39:09 --> Helper loaded: language_helper
INFO - 2020-04-21 03:39:09 --> Helper loaded: email_helper
INFO - 2020-04-21 03:39:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:39:09 --> Database Driver Class Initialized
INFO - 2020-04-21 03:39:09 --> Parser Class Initialized
INFO - 2020-04-21 03:39:09 --> User Agent Class Initialized
INFO - 2020-04-21 03:39:09 --> Model Class Initialized
INFO - 2020-04-21 03:39:09 --> Model Class Initialized
DEBUG - 2020-04-21 03:39:09 --> Template Class Initialized
INFO - 2020-04-21 03:39:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:39:09 --> Email Class Initialized
INFO - 2020-04-21 03:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:39:09 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:39:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:39:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:39:09 --> Encryption Class Initialized
INFO - 2020-04-21 03:39:09 --> Controller Class Initialized
DEBUG - 2020-04-21 03:39:09 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:39:09 --> Model Class Initialized
ERROR - 2020-04-21 03:39:10 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ',' or ')' D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 32
INFO - 2020-04-21 03:39:26 --> Config Class Initialized
INFO - 2020-04-21 03:39:26 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:39:26 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:39:26 --> Utf8 Class Initialized
INFO - 2020-04-21 03:39:26 --> URI Class Initialized
INFO - 2020-04-21 03:39:26 --> Router Class Initialized
INFO - 2020-04-21 03:39:26 --> Output Class Initialized
INFO - 2020-04-21 03:39:26 --> Security Class Initialized
DEBUG - 2020-04-21 03:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:39:26 --> CSRF cookie sent
INFO - 2020-04-21 03:39:26 --> Input Class Initialized
INFO - 2020-04-21 03:39:26 --> Language Class Initialized
INFO - 2020-04-21 03:39:26 --> Language Class Initialized
INFO - 2020-04-21 03:39:26 --> Config Class Initialized
INFO - 2020-04-21 03:39:26 --> Loader Class Initialized
INFO - 2020-04-21 03:39:26 --> Helper loaded: url_helper
INFO - 2020-04-21 03:39:26 --> Helper loaded: file_helper
INFO - 2020-04-21 03:39:26 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:39:26 --> Helper loaded: common_helper
INFO - 2020-04-21 03:39:26 --> Helper loaded: language_helper
INFO - 2020-04-21 03:39:26 --> Helper loaded: email_helper
INFO - 2020-04-21 03:39:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:39:26 --> Database Driver Class Initialized
INFO - 2020-04-21 03:39:26 --> Parser Class Initialized
INFO - 2020-04-21 03:39:26 --> User Agent Class Initialized
INFO - 2020-04-21 03:39:26 --> Model Class Initialized
INFO - 2020-04-21 03:39:26 --> Model Class Initialized
DEBUG - 2020-04-21 03:39:26 --> Template Class Initialized
INFO - 2020-04-21 03:39:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:39:26 --> Email Class Initialized
INFO - 2020-04-21 03:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:39:26 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:39:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:39:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:39:26 --> Encryption Class Initialized
INFO - 2020-04-21 03:39:26 --> Controller Class Initialized
DEBUG - 2020-04-21 03:39:26 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:39:26 --> Model Class Initialized
ERROR - 2020-04-21 03:39:27 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ',' or ')' D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 32
INFO - 2020-04-21 03:39:51 --> Config Class Initialized
INFO - 2020-04-21 03:39:51 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:39:51 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:39:51 --> Utf8 Class Initialized
INFO - 2020-04-21 03:39:51 --> URI Class Initialized
INFO - 2020-04-21 03:39:51 --> Router Class Initialized
INFO - 2020-04-21 03:39:51 --> Output Class Initialized
INFO - 2020-04-21 03:39:51 --> Security Class Initialized
DEBUG - 2020-04-21 03:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:39:51 --> CSRF cookie sent
INFO - 2020-04-21 03:39:51 --> Input Class Initialized
INFO - 2020-04-21 03:39:51 --> Language Class Initialized
INFO - 2020-04-21 03:39:51 --> Language Class Initialized
INFO - 2020-04-21 03:39:51 --> Config Class Initialized
INFO - 2020-04-21 03:39:51 --> Loader Class Initialized
INFO - 2020-04-21 03:39:51 --> Helper loaded: url_helper
INFO - 2020-04-21 03:39:51 --> Helper loaded: file_helper
INFO - 2020-04-21 03:39:51 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:39:51 --> Helper loaded: common_helper
INFO - 2020-04-21 03:39:51 --> Helper loaded: language_helper
INFO - 2020-04-21 03:39:51 --> Helper loaded: email_helper
INFO - 2020-04-21 03:39:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:39:51 --> Database Driver Class Initialized
INFO - 2020-04-21 03:39:52 --> Parser Class Initialized
INFO - 2020-04-21 03:39:52 --> User Agent Class Initialized
INFO - 2020-04-21 03:39:52 --> Model Class Initialized
INFO - 2020-04-21 03:39:52 --> Model Class Initialized
DEBUG - 2020-04-21 03:39:52 --> Template Class Initialized
INFO - 2020-04-21 03:39:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:39:52 --> Email Class Initialized
INFO - 2020-04-21 03:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:39:52 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:39:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:39:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:39:52 --> Encryption Class Initialized
INFO - 2020-04-21 03:39:52 --> Controller Class Initialized
DEBUG - 2020-04-21 03:39:52 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:39:52 --> Model Class Initialized
ERROR - 2020-04-21 03:39:52 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ',' or ')' D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 32
INFO - 2020-04-21 03:40:06 --> Config Class Initialized
INFO - 2020-04-21 03:40:06 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:40:06 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:40:06 --> Utf8 Class Initialized
INFO - 2020-04-21 03:40:06 --> URI Class Initialized
INFO - 2020-04-21 03:40:06 --> Router Class Initialized
INFO - 2020-04-21 03:40:06 --> Output Class Initialized
INFO - 2020-04-21 03:40:06 --> Security Class Initialized
DEBUG - 2020-04-21 03:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:40:06 --> CSRF cookie sent
INFO - 2020-04-21 03:40:06 --> Input Class Initialized
INFO - 2020-04-21 03:40:06 --> Language Class Initialized
INFO - 2020-04-21 03:40:06 --> Language Class Initialized
INFO - 2020-04-21 03:40:06 --> Config Class Initialized
INFO - 2020-04-21 03:40:06 --> Loader Class Initialized
INFO - 2020-04-21 03:40:06 --> Helper loaded: url_helper
INFO - 2020-04-21 03:40:06 --> Helper loaded: file_helper
INFO - 2020-04-21 03:40:06 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:40:06 --> Helper loaded: common_helper
INFO - 2020-04-21 03:40:06 --> Helper loaded: language_helper
INFO - 2020-04-21 03:40:07 --> Helper loaded: email_helper
INFO - 2020-04-21 03:40:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:40:07 --> Database Driver Class Initialized
INFO - 2020-04-21 03:40:07 --> Parser Class Initialized
INFO - 2020-04-21 03:40:07 --> User Agent Class Initialized
INFO - 2020-04-21 03:40:07 --> Model Class Initialized
INFO - 2020-04-21 03:40:07 --> Model Class Initialized
DEBUG - 2020-04-21 03:40:07 --> Template Class Initialized
INFO - 2020-04-21 03:40:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:40:07 --> Email Class Initialized
INFO - 2020-04-21 03:40:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:40:07 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:40:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:40:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:40:07 --> Encryption Class Initialized
INFO - 2020-04-21 03:40:07 --> Controller Class Initialized
DEBUG - 2020-04-21 03:40:07 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:40:07 --> Model Class Initialized
DEBUG - 2020-04-21 03:40:07 --> module MX_Controller Initialized
ERROR - 2020-04-21 03:40:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 16
ERROR - 2020-04-21 03:40:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 17
ERROR - 2020-04-21 03:40:07 --> Severity: Warning --> file_get_contents(/script_list?purchase_code=44f14e73-a24f-489c-ac74-be4e70eaa127): failed to open stream: No error D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\helpers\common_helper.php 298
INFO - 2020-04-21 03:40:36 --> Config Class Initialized
INFO - 2020-04-21 03:40:36 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:40:36 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:40:36 --> Utf8 Class Initialized
INFO - 2020-04-21 03:40:36 --> URI Class Initialized
INFO - 2020-04-21 03:40:36 --> Router Class Initialized
INFO - 2020-04-21 03:40:36 --> Output Class Initialized
INFO - 2020-04-21 03:40:36 --> Security Class Initialized
DEBUG - 2020-04-21 03:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:40:36 --> CSRF cookie sent
INFO - 2020-04-21 03:40:36 --> Input Class Initialized
INFO - 2020-04-21 03:40:36 --> Language Class Initialized
INFO - 2020-04-21 03:40:36 --> Language Class Initialized
INFO - 2020-04-21 03:40:36 --> Config Class Initialized
INFO - 2020-04-21 03:40:36 --> Loader Class Initialized
INFO - 2020-04-21 03:40:36 --> Helper loaded: url_helper
INFO - 2020-04-21 03:40:36 --> Helper loaded: file_helper
INFO - 2020-04-21 03:40:36 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:40:36 --> Helper loaded: common_helper
INFO - 2020-04-21 03:40:36 --> Helper loaded: language_helper
INFO - 2020-04-21 03:40:36 --> Helper loaded: email_helper
INFO - 2020-04-21 03:40:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:40:36 --> Database Driver Class Initialized
INFO - 2020-04-21 03:40:36 --> Parser Class Initialized
INFO - 2020-04-21 03:40:36 --> User Agent Class Initialized
INFO - 2020-04-21 03:40:36 --> Model Class Initialized
INFO - 2020-04-21 03:40:36 --> Model Class Initialized
DEBUG - 2020-04-21 03:40:36 --> Template Class Initialized
INFO - 2020-04-21 03:40:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:40:36 --> Email Class Initialized
INFO - 2020-04-21 03:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:40:36 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:40:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:40:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:40:36 --> Encryption Class Initialized
INFO - 2020-04-21 03:40:36 --> Controller Class Initialized
DEBUG - 2020-04-21 03:40:36 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:40:36 --> Model Class Initialized
DEBUG - 2020-04-21 03:40:36 --> module MX_Controller Initialized
INFO - 2020-04-21 03:40:56 --> Config Class Initialized
INFO - 2020-04-21 03:40:56 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:40:56 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:40:56 --> Utf8 Class Initialized
INFO - 2020-04-21 03:40:56 --> URI Class Initialized
INFO - 2020-04-21 03:40:56 --> Router Class Initialized
INFO - 2020-04-21 03:40:56 --> Output Class Initialized
INFO - 2020-04-21 03:40:56 --> Security Class Initialized
DEBUG - 2020-04-21 03:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:40:56 --> CSRF cookie sent
INFO - 2020-04-21 03:40:56 --> Input Class Initialized
INFO - 2020-04-21 03:40:56 --> Language Class Initialized
INFO - 2020-04-21 03:40:56 --> Language Class Initialized
INFO - 2020-04-21 03:40:56 --> Config Class Initialized
INFO - 2020-04-21 03:40:56 --> Loader Class Initialized
INFO - 2020-04-21 03:40:56 --> Helper loaded: url_helper
INFO - 2020-04-21 03:40:56 --> Helper loaded: file_helper
INFO - 2020-04-21 03:40:56 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:40:56 --> Helper loaded: common_helper
INFO - 2020-04-21 03:40:56 --> Helper loaded: language_helper
INFO - 2020-04-21 03:40:56 --> Helper loaded: email_helper
INFO - 2020-04-21 03:40:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:40:56 --> Database Driver Class Initialized
INFO - 2020-04-21 03:40:56 --> Parser Class Initialized
INFO - 2020-04-21 03:40:56 --> User Agent Class Initialized
INFO - 2020-04-21 03:40:56 --> Model Class Initialized
INFO - 2020-04-21 03:40:56 --> Model Class Initialized
DEBUG - 2020-04-21 03:40:56 --> Template Class Initialized
INFO - 2020-04-21 03:40:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:40:56 --> Email Class Initialized
INFO - 2020-04-21 03:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:40:56 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:40:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:40:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:40:56 --> Encryption Class Initialized
INFO - 2020-04-21 03:40:56 --> Controller Class Initialized
DEBUG - 2020-04-21 03:40:56 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:40:56 --> Model Class Initialized
DEBUG - 2020-04-21 03:40:56 --> module MX_Controller Initialized
INFO - 2020-04-21 03:41:08 --> Config Class Initialized
INFO - 2020-04-21 03:41:08 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:41:08 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:41:08 --> Utf8 Class Initialized
INFO - 2020-04-21 03:41:08 --> URI Class Initialized
INFO - 2020-04-21 03:41:08 --> Router Class Initialized
INFO - 2020-04-21 03:41:08 --> Output Class Initialized
INFO - 2020-04-21 03:41:08 --> Security Class Initialized
DEBUG - 2020-04-21 03:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:41:08 --> CSRF cookie sent
INFO - 2020-04-21 03:41:08 --> Input Class Initialized
INFO - 2020-04-21 03:41:08 --> Language Class Initialized
INFO - 2020-04-21 03:41:08 --> Language Class Initialized
INFO - 2020-04-21 03:41:08 --> Config Class Initialized
INFO - 2020-04-21 03:41:08 --> Loader Class Initialized
INFO - 2020-04-21 03:41:08 --> Helper loaded: url_helper
INFO - 2020-04-21 03:41:08 --> Helper loaded: file_helper
INFO - 2020-04-21 03:41:08 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:41:08 --> Helper loaded: common_helper
INFO - 2020-04-21 03:41:08 --> Helper loaded: language_helper
INFO - 2020-04-21 03:41:08 --> Helper loaded: email_helper
INFO - 2020-04-21 03:41:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:41:08 --> Database Driver Class Initialized
INFO - 2020-04-21 03:41:08 --> Parser Class Initialized
INFO - 2020-04-21 03:41:08 --> User Agent Class Initialized
INFO - 2020-04-21 03:41:08 --> Model Class Initialized
INFO - 2020-04-21 03:41:08 --> Model Class Initialized
DEBUG - 2020-04-21 03:41:08 --> Template Class Initialized
INFO - 2020-04-21 03:41:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:41:08 --> Email Class Initialized
INFO - 2020-04-21 03:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:41:08 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:41:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:41:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:41:08 --> Encryption Class Initialized
INFO - 2020-04-21 03:41:08 --> Controller Class Initialized
DEBUG - 2020-04-21 03:41:08 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:41:08 --> Model Class Initialized
DEBUG - 2020-04-21 03:41:08 --> module MX_Controller Initialized
INFO - 2020-04-21 03:41:28 --> Config Class Initialized
INFO - 2020-04-21 03:41:29 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:41:29 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:41:29 --> Utf8 Class Initialized
INFO - 2020-04-21 03:41:29 --> URI Class Initialized
INFO - 2020-04-21 03:41:29 --> Router Class Initialized
INFO - 2020-04-21 03:41:29 --> Output Class Initialized
INFO - 2020-04-21 03:41:29 --> Security Class Initialized
DEBUG - 2020-04-21 03:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:41:29 --> CSRF cookie sent
INFO - 2020-04-21 03:41:29 --> Input Class Initialized
INFO - 2020-04-21 03:41:29 --> Language Class Initialized
INFO - 2020-04-21 03:41:29 --> Language Class Initialized
INFO - 2020-04-21 03:41:29 --> Config Class Initialized
INFO - 2020-04-21 03:41:29 --> Loader Class Initialized
INFO - 2020-04-21 03:41:29 --> Helper loaded: url_helper
INFO - 2020-04-21 03:41:29 --> Helper loaded: file_helper
INFO - 2020-04-21 03:41:29 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:41:29 --> Helper loaded: common_helper
INFO - 2020-04-21 03:41:29 --> Helper loaded: language_helper
INFO - 2020-04-21 03:41:29 --> Helper loaded: email_helper
INFO - 2020-04-21 03:41:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:41:29 --> Database Driver Class Initialized
INFO - 2020-04-21 03:41:29 --> Parser Class Initialized
INFO - 2020-04-21 03:41:29 --> User Agent Class Initialized
INFO - 2020-04-21 03:41:29 --> Model Class Initialized
INFO - 2020-04-21 03:41:29 --> Model Class Initialized
DEBUG - 2020-04-21 03:41:29 --> Template Class Initialized
INFO - 2020-04-21 03:41:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:41:29 --> Email Class Initialized
INFO - 2020-04-21 03:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:41:29 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:41:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:41:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:41:29 --> Encryption Class Initialized
INFO - 2020-04-21 03:41:29 --> Controller Class Initialized
DEBUG - 2020-04-21 03:41:29 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:41:29 --> Model Class Initialized
DEBUG - 2020-04-21 03:41:29 --> module MX_Controller Initialized
INFO - 2020-04-21 03:41:52 --> Config Class Initialized
INFO - 2020-04-21 03:41:52 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:41:52 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:41:52 --> Utf8 Class Initialized
INFO - 2020-04-21 03:41:52 --> URI Class Initialized
INFO - 2020-04-21 03:41:52 --> Router Class Initialized
INFO - 2020-04-21 03:41:52 --> Output Class Initialized
INFO - 2020-04-21 03:41:52 --> Security Class Initialized
DEBUG - 2020-04-21 03:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:41:52 --> CSRF cookie sent
INFO - 2020-04-21 03:41:52 --> Input Class Initialized
INFO - 2020-04-21 03:41:52 --> Language Class Initialized
INFO - 2020-04-21 03:41:52 --> Language Class Initialized
INFO - 2020-04-21 03:41:52 --> Config Class Initialized
INFO - 2020-04-21 03:41:52 --> Loader Class Initialized
INFO - 2020-04-21 03:41:52 --> Helper loaded: url_helper
INFO - 2020-04-21 03:41:52 --> Helper loaded: file_helper
INFO - 2020-04-21 03:41:52 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:41:52 --> Helper loaded: common_helper
INFO - 2020-04-21 03:41:53 --> Helper loaded: language_helper
INFO - 2020-04-21 03:41:53 --> Helper loaded: email_helper
INFO - 2020-04-21 03:41:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:41:53 --> Database Driver Class Initialized
INFO - 2020-04-21 03:41:53 --> Parser Class Initialized
INFO - 2020-04-21 03:41:53 --> User Agent Class Initialized
INFO - 2020-04-21 03:41:53 --> Model Class Initialized
INFO - 2020-04-21 03:41:53 --> Model Class Initialized
DEBUG - 2020-04-21 03:41:53 --> Template Class Initialized
INFO - 2020-04-21 03:41:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:41:53 --> Email Class Initialized
INFO - 2020-04-21 03:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:41:53 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:41:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:41:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:41:53 --> Encryption Class Initialized
INFO - 2020-04-21 03:41:53 --> Controller Class Initialized
DEBUG - 2020-04-21 03:41:53 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:41:53 --> Model Class Initialized
DEBUG - 2020-04-21 03:41:53 --> module MX_Controller Initialized
INFO - 2020-04-21 03:42:11 --> Config Class Initialized
INFO - 2020-04-21 03:42:11 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:12 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:12 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:12 --> URI Class Initialized
INFO - 2020-04-21 03:42:12 --> Router Class Initialized
INFO - 2020-04-21 03:42:12 --> Output Class Initialized
INFO - 2020-04-21 03:42:12 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:12 --> CSRF cookie sent
INFO - 2020-04-21 03:42:12 --> Input Class Initialized
INFO - 2020-04-21 03:42:12 --> Language Class Initialized
INFO - 2020-04-21 03:42:12 --> Language Class Initialized
INFO - 2020-04-21 03:42:12 --> Config Class Initialized
INFO - 2020-04-21 03:42:12 --> Loader Class Initialized
INFO - 2020-04-21 03:42:12 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:12 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:12 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:12 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:12 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:12 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:12 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:12 --> Parser Class Initialized
INFO - 2020-04-21 03:42:12 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:12 --> Model Class Initialized
INFO - 2020-04-21 03:42:12 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:12 --> Template Class Initialized
INFO - 2020-04-21 03:42:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:12 --> Email Class Initialized
INFO - 2020-04-21 03:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:12 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:12 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:12 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:12 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:42:12 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:12 --> module MX_Controller Initialized
INFO - 2020-04-21 03:42:25 --> Config Class Initialized
INFO - 2020-04-21 03:42:25 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:25 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:25 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:25 --> URI Class Initialized
INFO - 2020-04-21 03:42:25 --> Router Class Initialized
INFO - 2020-04-21 03:42:25 --> Output Class Initialized
INFO - 2020-04-21 03:42:25 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:25 --> CSRF cookie sent
INFO - 2020-04-21 03:42:25 --> Input Class Initialized
INFO - 2020-04-21 03:42:25 --> Language Class Initialized
INFO - 2020-04-21 03:42:25 --> Language Class Initialized
INFO - 2020-04-21 03:42:25 --> Config Class Initialized
INFO - 2020-04-21 03:42:25 --> Loader Class Initialized
INFO - 2020-04-21 03:42:25 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:25 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:25 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:25 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:25 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:25 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:25 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:25 --> Parser Class Initialized
INFO - 2020-04-21 03:42:25 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:25 --> Model Class Initialized
INFO - 2020-04-21 03:42:25 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:25 --> Template Class Initialized
INFO - 2020-04-21 03:42:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:25 --> Email Class Initialized
INFO - 2020-04-21 03:42:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:25 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:26 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:26 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:26 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:42:26 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:26 --> module MX_Controller Initialized
INFO - 2020-04-21 03:42:39 --> Config Class Initialized
INFO - 2020-04-21 03:42:39 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:39 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:39 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:39 --> URI Class Initialized
INFO - 2020-04-21 03:42:40 --> Router Class Initialized
INFO - 2020-04-21 03:42:40 --> Output Class Initialized
INFO - 2020-04-21 03:42:40 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:40 --> CSRF cookie sent
INFO - 2020-04-21 03:42:40 --> Input Class Initialized
INFO - 2020-04-21 03:42:40 --> Language Class Initialized
INFO - 2020-04-21 03:42:40 --> Language Class Initialized
INFO - 2020-04-21 03:42:40 --> Config Class Initialized
INFO - 2020-04-21 03:42:40 --> Loader Class Initialized
INFO - 2020-04-21 03:42:40 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:40 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:40 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:40 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:40 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:40 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:40 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:40 --> Parser Class Initialized
INFO - 2020-04-21 03:42:40 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:40 --> Model Class Initialized
INFO - 2020-04-21 03:42:40 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:40 --> Template Class Initialized
INFO - 2020-04-21 03:42:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:40 --> Email Class Initialized
INFO - 2020-04-21 03:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:40 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:40 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:40 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:40 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:42:40 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:40 --> module MX_Controller Initialized
ERROR - 2020-04-21 03:42:41 --> Severity: Warning --> json_decode() expects parameter 1 to be string, object given D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 32
INFO - 2020-04-21 03:42:41 --> Config Class Initialized
INFO - 2020-04-21 03:42:41 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:41 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:41 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:41 --> URI Class Initialized
DEBUG - 2020-04-21 03:42:41 --> No URI present. Default controller set.
INFO - 2020-04-21 03:42:41 --> Router Class Initialized
INFO - 2020-04-21 03:42:41 --> Output Class Initialized
INFO - 2020-04-21 03:42:41 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:41 --> CSRF cookie sent
INFO - 2020-04-21 03:42:41 --> Input Class Initialized
INFO - 2020-04-21 03:42:41 --> Language Class Initialized
INFO - 2020-04-21 03:42:41 --> Language Class Initialized
INFO - 2020-04-21 03:42:41 --> Config Class Initialized
INFO - 2020-04-21 03:42:41 --> Loader Class Initialized
INFO - 2020-04-21 03:42:41 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:41 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:41 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:41 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:41 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:41 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:41 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:41 --> Parser Class Initialized
INFO - 2020-04-21 03:42:41 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:41 --> Model Class Initialized
INFO - 2020-04-21 03:42:41 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:41 --> Template Class Initialized
INFO - 2020-04-21 03:42:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:41 --> Email Class Initialized
INFO - 2020-04-21 03:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:41 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:41 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:41 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:41 --> home MX_Controller Initialized
INFO - 2020-04-21 03:42:41 --> Model Class Initialized
INFO - 2020-04-21 03:42:41 --> Config Class Initialized
INFO - 2020-04-21 03:42:41 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:41 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:41 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:42 --> URI Class Initialized
INFO - 2020-04-21 03:42:42 --> Router Class Initialized
INFO - 2020-04-21 03:42:42 --> Output Class Initialized
INFO - 2020-04-21 03:42:42 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:42 --> CSRF cookie sent
INFO - 2020-04-21 03:42:42 --> Input Class Initialized
INFO - 2020-04-21 03:42:42 --> Language Class Initialized
INFO - 2020-04-21 03:42:42 --> Language Class Initialized
INFO - 2020-04-21 03:42:42 --> Config Class Initialized
INFO - 2020-04-21 03:42:42 --> Loader Class Initialized
INFO - 2020-04-21 03:42:42 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:42 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:42 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:42 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:42 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:42 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:42 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:42 --> Parser Class Initialized
INFO - 2020-04-21 03:42:42 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:42 --> Model Class Initialized
INFO - 2020-04-21 03:42:42 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:42 --> Template Class Initialized
INFO - 2020-04-21 03:42:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:42 --> Email Class Initialized
INFO - 2020-04-21 03:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:42 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:42 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:42 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:42 --> twitter MX_Controller Initialized
INFO - 2020-04-21 03:42:42 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-21 03:42:42 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/views/index.php
DEBUG - 2020-04-21 03:42:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:42:42 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:42:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:42:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:42:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:42:42 --> Final output sent to browser
DEBUG - 2020-04-21 03:42:42 --> Total execution time: 0.6268
INFO - 2020-04-21 03:42:45 --> Config Class Initialized
INFO - 2020-04-21 03:42:45 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:45 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:45 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:45 --> URI Class Initialized
INFO - 2020-04-21 03:42:45 --> Router Class Initialized
INFO - 2020-04-21 03:42:45 --> Output Class Initialized
INFO - 2020-04-21 03:42:45 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:45 --> CSRF cookie sent
INFO - 2020-04-21 03:42:45 --> Input Class Initialized
INFO - 2020-04-21 03:42:45 --> Language Class Initialized
INFO - 2020-04-21 03:42:45 --> Language Class Initialized
INFO - 2020-04-21 03:42:45 --> Config Class Initialized
INFO - 2020-04-21 03:42:45 --> Loader Class Initialized
INFO - 2020-04-21 03:42:45 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:45 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:45 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:45 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:45 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:45 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:45 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:45 --> Parser Class Initialized
INFO - 2020-04-21 03:42:45 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:45 --> Model Class Initialized
INFO - 2020-04-21 03:42:45 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:45 --> Template Class Initialized
INFO - 2020-04-21 03:42:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:45 --> Email Class Initialized
INFO - 2020-04-21 03:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:45 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:46 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:46 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:46 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:42:46 --> Model Class Initialized
INFO - 2020-04-21 03:42:46 --> Config Class Initialized
INFO - 2020-04-21 03:42:46 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:46 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:46 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:46 --> URI Class Initialized
INFO - 2020-04-21 03:42:46 --> Router Class Initialized
INFO - 2020-04-21 03:42:46 --> Output Class Initialized
INFO - 2020-04-21 03:42:46 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:46 --> CSRF cookie sent
INFO - 2020-04-21 03:42:46 --> Input Class Initialized
INFO - 2020-04-21 03:42:46 --> Language Class Initialized
INFO - 2020-04-21 03:42:46 --> Language Class Initialized
INFO - 2020-04-21 03:42:46 --> Config Class Initialized
INFO - 2020-04-21 03:42:46 --> Loader Class Initialized
INFO - 2020-04-21 03:42:46 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:46 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:46 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:46 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:46 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:46 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:46 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:46 --> Parser Class Initialized
INFO - 2020-04-21 03:42:46 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:46 --> Model Class Initialized
INFO - 2020-04-21 03:42:46 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:46 --> Template Class Initialized
INFO - 2020-04-21 03:42:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:46 --> Email Class Initialized
INFO - 2020-04-21 03:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:46 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:46 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:46 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:46 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:42:46 --> Model Class Initialized
INFO - 2020-04-21 03:42:46 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 03:42:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-21 03:42:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 03:42:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:42:46 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:42:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:42:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:42:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:42:46 --> Final output sent to browser
DEBUG - 2020-04-21 03:42:46 --> Total execution time: 0.6238
INFO - 2020-04-21 03:42:48 --> Config Class Initialized
INFO - 2020-04-21 03:42:48 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:48 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:48 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:48 --> URI Class Initialized
INFO - 2020-04-21 03:42:48 --> Router Class Initialized
INFO - 2020-04-21 03:42:48 --> Output Class Initialized
INFO - 2020-04-21 03:42:48 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:48 --> CSRF cookie sent
INFO - 2020-04-21 03:42:48 --> Input Class Initialized
INFO - 2020-04-21 03:42:48 --> Language Class Initialized
INFO - 2020-04-21 03:42:48 --> Language Class Initialized
INFO - 2020-04-21 03:42:48 --> Config Class Initialized
INFO - 2020-04-21 03:42:48 --> Loader Class Initialized
INFO - 2020-04-21 03:42:48 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:48 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:48 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:48 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:48 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:48 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:48 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:48 --> Parser Class Initialized
INFO - 2020-04-21 03:42:48 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:48 --> Model Class Initialized
INFO - 2020-04-21 03:42:48 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:48 --> Template Class Initialized
INFO - 2020-04-21 03:42:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:48 --> Email Class Initialized
INFO - 2020-04-21 03:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:49 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:49 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:49 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:49 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:42:49 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:49 --> module MX_Controller Initialized
ERROR - 2020-04-21 03:42:50 --> Severity: Warning --> json_decode() expects parameter 1 to be string, object given D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 32
INFO - 2020-04-21 03:42:50 --> Config Class Initialized
INFO - 2020-04-21 03:42:50 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:50 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:50 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:50 --> URI Class Initialized
DEBUG - 2020-04-21 03:42:50 --> No URI present. Default controller set.
INFO - 2020-04-21 03:42:50 --> Router Class Initialized
INFO - 2020-04-21 03:42:50 --> Output Class Initialized
INFO - 2020-04-21 03:42:50 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:50 --> CSRF cookie sent
INFO - 2020-04-21 03:42:50 --> Input Class Initialized
INFO - 2020-04-21 03:42:50 --> Language Class Initialized
INFO - 2020-04-21 03:42:50 --> Language Class Initialized
INFO - 2020-04-21 03:42:50 --> Config Class Initialized
INFO - 2020-04-21 03:42:50 --> Loader Class Initialized
INFO - 2020-04-21 03:42:50 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:50 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:50 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:50 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:50 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:50 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:50 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:50 --> Parser Class Initialized
INFO - 2020-04-21 03:42:50 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:50 --> Model Class Initialized
INFO - 2020-04-21 03:42:50 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:50 --> Template Class Initialized
INFO - 2020-04-21 03:42:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:50 --> Email Class Initialized
INFO - 2020-04-21 03:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:50 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:50 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:50 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:50 --> home MX_Controller Initialized
INFO - 2020-04-21 03:42:50 --> Model Class Initialized
INFO - 2020-04-21 03:42:50 --> Config Class Initialized
INFO - 2020-04-21 03:42:50 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:42:50 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:42:50 --> Utf8 Class Initialized
INFO - 2020-04-21 03:42:50 --> URI Class Initialized
INFO - 2020-04-21 03:42:50 --> Router Class Initialized
INFO - 2020-04-21 03:42:50 --> Output Class Initialized
INFO - 2020-04-21 03:42:50 --> Security Class Initialized
DEBUG - 2020-04-21 03:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:42:50 --> CSRF cookie sent
INFO - 2020-04-21 03:42:50 --> Input Class Initialized
INFO - 2020-04-21 03:42:50 --> Language Class Initialized
INFO - 2020-04-21 03:42:50 --> Language Class Initialized
INFO - 2020-04-21 03:42:50 --> Config Class Initialized
INFO - 2020-04-21 03:42:50 --> Loader Class Initialized
INFO - 2020-04-21 03:42:51 --> Helper loaded: url_helper
INFO - 2020-04-21 03:42:51 --> Helper loaded: file_helper
INFO - 2020-04-21 03:42:51 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:42:51 --> Helper loaded: common_helper
INFO - 2020-04-21 03:42:51 --> Helper loaded: language_helper
INFO - 2020-04-21 03:42:51 --> Helper loaded: email_helper
INFO - 2020-04-21 03:42:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:42:51 --> Database Driver Class Initialized
INFO - 2020-04-21 03:42:51 --> Parser Class Initialized
INFO - 2020-04-21 03:42:51 --> User Agent Class Initialized
INFO - 2020-04-21 03:42:51 --> Model Class Initialized
INFO - 2020-04-21 03:42:51 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:51 --> Template Class Initialized
INFO - 2020-04-21 03:42:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:42:51 --> Email Class Initialized
INFO - 2020-04-21 03:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:42:51 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:42:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:42:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:42:51 --> Encryption Class Initialized
INFO - 2020-04-21 03:42:51 --> Controller Class Initialized
DEBUG - 2020-04-21 03:42:51 --> twitter MX_Controller Initialized
INFO - 2020-04-21 03:42:51 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-21 03:42:51 --> Model Class Initialized
DEBUG - 2020-04-21 03:42:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/views/index.php
DEBUG - 2020-04-21 03:42:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:42:51 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:42:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:42:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:42:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:42:51 --> Final output sent to browser
DEBUG - 2020-04-21 03:42:51 --> Total execution time: 0.5409
INFO - 2020-04-21 03:44:29 --> Config Class Initialized
INFO - 2020-04-21 03:44:29 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:44:29 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:44:29 --> Utf8 Class Initialized
INFO - 2020-04-21 03:44:29 --> URI Class Initialized
INFO - 2020-04-21 03:44:29 --> Router Class Initialized
INFO - 2020-04-21 03:44:29 --> Output Class Initialized
INFO - 2020-04-21 03:44:29 --> Security Class Initialized
DEBUG - 2020-04-21 03:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:44:29 --> CSRF cookie sent
INFO - 2020-04-21 03:44:29 --> Input Class Initialized
INFO - 2020-04-21 03:44:29 --> Language Class Initialized
INFO - 2020-04-21 03:44:29 --> Language Class Initialized
INFO - 2020-04-21 03:44:29 --> Config Class Initialized
INFO - 2020-04-21 03:44:29 --> Loader Class Initialized
INFO - 2020-04-21 03:44:29 --> Helper loaded: url_helper
INFO - 2020-04-21 03:44:29 --> Helper loaded: file_helper
INFO - 2020-04-21 03:44:29 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:44:29 --> Helper loaded: common_helper
INFO - 2020-04-21 03:44:29 --> Helper loaded: language_helper
INFO - 2020-04-21 03:44:29 --> Helper loaded: email_helper
INFO - 2020-04-21 03:44:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:44:29 --> Database Driver Class Initialized
INFO - 2020-04-21 03:44:29 --> Parser Class Initialized
INFO - 2020-04-21 03:44:29 --> User Agent Class Initialized
INFO - 2020-04-21 03:44:29 --> Model Class Initialized
INFO - 2020-04-21 03:44:29 --> Model Class Initialized
DEBUG - 2020-04-21 03:44:29 --> Template Class Initialized
INFO - 2020-04-21 03:44:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:44:29 --> Email Class Initialized
INFO - 2020-04-21 03:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:44:29 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:44:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:44:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:44:29 --> Encryption Class Initialized
INFO - 2020-04-21 03:44:29 --> Controller Class Initialized
DEBUG - 2020-04-21 03:44:30 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:44:30 --> Model Class Initialized
INFO - 2020-04-21 03:44:30 --> Config Class Initialized
INFO - 2020-04-21 03:44:30 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:44:30 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:44:30 --> Utf8 Class Initialized
INFO - 2020-04-21 03:44:30 --> URI Class Initialized
INFO - 2020-04-21 03:44:30 --> Router Class Initialized
INFO - 2020-04-21 03:44:30 --> Output Class Initialized
INFO - 2020-04-21 03:44:30 --> Security Class Initialized
DEBUG - 2020-04-21 03:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:44:30 --> CSRF cookie sent
INFO - 2020-04-21 03:44:30 --> Input Class Initialized
INFO - 2020-04-21 03:44:30 --> Language Class Initialized
INFO - 2020-04-21 03:44:30 --> Language Class Initialized
INFO - 2020-04-21 03:44:30 --> Config Class Initialized
INFO - 2020-04-21 03:44:30 --> Loader Class Initialized
INFO - 2020-04-21 03:44:30 --> Helper loaded: url_helper
INFO - 2020-04-21 03:44:30 --> Helper loaded: file_helper
INFO - 2020-04-21 03:44:30 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:44:30 --> Helper loaded: common_helper
INFO - 2020-04-21 03:44:30 --> Helper loaded: language_helper
INFO - 2020-04-21 03:44:30 --> Helper loaded: email_helper
INFO - 2020-04-21 03:44:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:44:30 --> Database Driver Class Initialized
INFO - 2020-04-21 03:44:30 --> Parser Class Initialized
INFO - 2020-04-21 03:44:30 --> User Agent Class Initialized
INFO - 2020-04-21 03:44:30 --> Model Class Initialized
INFO - 2020-04-21 03:44:30 --> Model Class Initialized
DEBUG - 2020-04-21 03:44:30 --> Template Class Initialized
INFO - 2020-04-21 03:44:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:44:30 --> Email Class Initialized
INFO - 2020-04-21 03:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:44:30 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:44:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:44:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:44:30 --> Encryption Class Initialized
INFO - 2020-04-21 03:44:30 --> Controller Class Initialized
DEBUG - 2020-04-21 03:44:30 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:44:30 --> Model Class Initialized
INFO - 2020-04-21 03:44:30 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 03:44:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-21 03:44:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 03:44:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:44:30 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:44:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:44:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:44:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:44:30 --> Final output sent to browser
DEBUG - 2020-04-21 03:44:30 --> Total execution time: 0.5615
INFO - 2020-04-21 03:44:32 --> Config Class Initialized
INFO - 2020-04-21 03:44:32 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:44:32 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:44:32 --> Utf8 Class Initialized
INFO - 2020-04-21 03:44:32 --> URI Class Initialized
INFO - 2020-04-21 03:44:32 --> Router Class Initialized
INFO - 2020-04-21 03:44:32 --> Output Class Initialized
INFO - 2020-04-21 03:44:32 --> Security Class Initialized
DEBUG - 2020-04-21 03:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:44:32 --> CSRF cookie sent
INFO - 2020-04-21 03:44:32 --> Input Class Initialized
INFO - 2020-04-21 03:44:32 --> Language Class Initialized
INFO - 2020-04-21 03:44:32 --> Language Class Initialized
INFO - 2020-04-21 03:44:32 --> Config Class Initialized
INFO - 2020-04-21 03:44:32 --> Loader Class Initialized
INFO - 2020-04-21 03:44:32 --> Helper loaded: url_helper
INFO - 2020-04-21 03:44:32 --> Helper loaded: file_helper
INFO - 2020-04-21 03:44:32 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:44:32 --> Helper loaded: common_helper
INFO - 2020-04-21 03:44:32 --> Helper loaded: language_helper
INFO - 2020-04-21 03:44:32 --> Helper loaded: email_helper
INFO - 2020-04-21 03:44:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:44:33 --> Database Driver Class Initialized
INFO - 2020-04-21 03:44:33 --> Parser Class Initialized
INFO - 2020-04-21 03:44:33 --> User Agent Class Initialized
INFO - 2020-04-21 03:44:33 --> Model Class Initialized
INFO - 2020-04-21 03:44:33 --> Model Class Initialized
DEBUG - 2020-04-21 03:44:33 --> Template Class Initialized
INFO - 2020-04-21 03:44:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:44:33 --> Email Class Initialized
INFO - 2020-04-21 03:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:44:33 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:44:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:44:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:44:33 --> Encryption Class Initialized
INFO - 2020-04-21 03:44:33 --> Controller Class Initialized
DEBUG - 2020-04-21 03:44:33 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:44:33 --> Model Class Initialized
DEBUG - 2020-04-21 03:44:33 --> module MX_Controller Initialized
ERROR - 2020-04-21 03:44:34 --> Severity: Warning --> json_decode() expects parameter 1 to be string, object given D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 34
INFO - 2020-04-21 03:44:53 --> Config Class Initialized
INFO - 2020-04-21 03:44:53 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:44:53 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:44:53 --> Utf8 Class Initialized
INFO - 2020-04-21 03:44:53 --> URI Class Initialized
INFO - 2020-04-21 03:44:53 --> Router Class Initialized
INFO - 2020-04-21 03:44:53 --> Output Class Initialized
INFO - 2020-04-21 03:44:53 --> Security Class Initialized
DEBUG - 2020-04-21 03:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:44:53 --> CSRF cookie sent
INFO - 2020-04-21 03:44:53 --> Input Class Initialized
INFO - 2020-04-21 03:44:53 --> Language Class Initialized
INFO - 2020-04-21 03:44:53 --> Language Class Initialized
INFO - 2020-04-21 03:44:53 --> Config Class Initialized
INFO - 2020-04-21 03:44:53 --> Loader Class Initialized
INFO - 2020-04-21 03:44:53 --> Helper loaded: url_helper
INFO - 2020-04-21 03:44:53 --> Helper loaded: file_helper
INFO - 2020-04-21 03:44:53 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:44:53 --> Helper loaded: common_helper
INFO - 2020-04-21 03:44:53 --> Helper loaded: language_helper
INFO - 2020-04-21 03:44:53 --> Helper loaded: email_helper
INFO - 2020-04-21 03:44:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:44:54 --> Database Driver Class Initialized
INFO - 2020-04-21 03:44:54 --> Parser Class Initialized
INFO - 2020-04-21 03:44:54 --> User Agent Class Initialized
INFO - 2020-04-21 03:44:54 --> Model Class Initialized
INFO - 2020-04-21 03:44:54 --> Model Class Initialized
DEBUG - 2020-04-21 03:44:54 --> Template Class Initialized
INFO - 2020-04-21 03:44:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:44:54 --> Email Class Initialized
INFO - 2020-04-21 03:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:44:54 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:44:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:44:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:44:54 --> Encryption Class Initialized
INFO - 2020-04-21 03:44:54 --> Controller Class Initialized
DEBUG - 2020-04-21 03:44:54 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:44:54 --> Model Class Initialized
DEBUG - 2020-04-21 03:44:54 --> module MX_Controller Initialized
INFO - 2020-04-21 03:45:07 --> Config Class Initialized
INFO - 2020-04-21 03:45:08 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:45:08 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:45:08 --> Utf8 Class Initialized
INFO - 2020-04-21 03:45:08 --> URI Class Initialized
INFO - 2020-04-21 03:45:08 --> Router Class Initialized
INFO - 2020-04-21 03:45:08 --> Output Class Initialized
INFO - 2020-04-21 03:45:08 --> Security Class Initialized
DEBUG - 2020-04-21 03:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:45:08 --> CSRF cookie sent
INFO - 2020-04-21 03:45:08 --> Input Class Initialized
INFO - 2020-04-21 03:45:08 --> Language Class Initialized
INFO - 2020-04-21 03:45:08 --> Language Class Initialized
INFO - 2020-04-21 03:45:08 --> Config Class Initialized
INFO - 2020-04-21 03:45:08 --> Loader Class Initialized
INFO - 2020-04-21 03:45:08 --> Helper loaded: url_helper
INFO - 2020-04-21 03:45:08 --> Helper loaded: file_helper
INFO - 2020-04-21 03:45:08 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:45:08 --> Helper loaded: common_helper
INFO - 2020-04-21 03:45:08 --> Helper loaded: language_helper
INFO - 2020-04-21 03:45:08 --> Helper loaded: email_helper
INFO - 2020-04-21 03:45:08 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:45:08 --> Database Driver Class Initialized
INFO - 2020-04-21 03:45:08 --> Parser Class Initialized
INFO - 2020-04-21 03:45:08 --> User Agent Class Initialized
INFO - 2020-04-21 03:45:08 --> Model Class Initialized
INFO - 2020-04-21 03:45:08 --> Model Class Initialized
DEBUG - 2020-04-21 03:45:08 --> Template Class Initialized
INFO - 2020-04-21 03:45:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:45:08 --> Email Class Initialized
INFO - 2020-04-21 03:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:45:08 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:45:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:45:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:45:08 --> Encryption Class Initialized
INFO - 2020-04-21 03:45:08 --> Controller Class Initialized
DEBUG - 2020-04-21 03:45:08 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:45:08 --> Model Class Initialized
DEBUG - 2020-04-21 03:45:08 --> module MX_Controller Initialized
INFO - 2020-04-21 03:45:20 --> Config Class Initialized
INFO - 2020-04-21 03:45:20 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:45:20 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:45:20 --> Utf8 Class Initialized
INFO - 2020-04-21 03:45:20 --> URI Class Initialized
INFO - 2020-04-21 03:45:20 --> Router Class Initialized
INFO - 2020-04-21 03:45:20 --> Output Class Initialized
INFO - 2020-04-21 03:45:20 --> Security Class Initialized
DEBUG - 2020-04-21 03:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:45:20 --> CSRF cookie sent
INFO - 2020-04-21 03:45:20 --> Input Class Initialized
INFO - 2020-04-21 03:45:20 --> Language Class Initialized
INFO - 2020-04-21 03:45:20 --> Language Class Initialized
INFO - 2020-04-21 03:45:20 --> Config Class Initialized
INFO - 2020-04-21 03:45:20 --> Loader Class Initialized
INFO - 2020-04-21 03:45:20 --> Helper loaded: url_helper
INFO - 2020-04-21 03:45:20 --> Helper loaded: file_helper
INFO - 2020-04-21 03:45:20 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:45:20 --> Helper loaded: common_helper
INFO - 2020-04-21 03:45:20 --> Helper loaded: language_helper
INFO - 2020-04-21 03:45:20 --> Helper loaded: email_helper
INFO - 2020-04-21 03:45:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:45:20 --> Database Driver Class Initialized
INFO - 2020-04-21 03:45:20 --> Parser Class Initialized
INFO - 2020-04-21 03:45:20 --> User Agent Class Initialized
INFO - 2020-04-21 03:45:21 --> Model Class Initialized
INFO - 2020-04-21 03:45:21 --> Model Class Initialized
DEBUG - 2020-04-21 03:45:21 --> Template Class Initialized
INFO - 2020-04-21 03:45:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:45:21 --> Email Class Initialized
INFO - 2020-04-21 03:45:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:45:21 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:45:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:45:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:45:21 --> Encryption Class Initialized
INFO - 2020-04-21 03:45:21 --> Controller Class Initialized
DEBUG - 2020-04-21 03:45:21 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:45:21 --> Model Class Initialized
DEBUG - 2020-04-21 03:45:21 --> module MX_Controller Initialized
INFO - 2020-04-21 03:45:22 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 03:45:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 03:45:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 03:45:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:45:22 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:45:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:45:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:45:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:45:22 --> Final output sent to browser
DEBUG - 2020-04-21 03:45:22 --> Total execution time: 1.7253
INFO - 2020-04-21 03:45:53 --> Config Class Initialized
INFO - 2020-04-21 03:45:53 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:45:53 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:45:53 --> Utf8 Class Initialized
INFO - 2020-04-21 03:45:54 --> URI Class Initialized
INFO - 2020-04-21 03:45:54 --> Router Class Initialized
INFO - 2020-04-21 03:45:54 --> Output Class Initialized
INFO - 2020-04-21 03:45:54 --> Security Class Initialized
DEBUG - 2020-04-21 03:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:45:54 --> CSRF cookie sent
INFO - 2020-04-21 03:45:54 --> Input Class Initialized
INFO - 2020-04-21 03:45:54 --> Language Class Initialized
INFO - 2020-04-21 03:45:54 --> Language Class Initialized
INFO - 2020-04-21 03:45:54 --> Config Class Initialized
INFO - 2020-04-21 03:45:54 --> Loader Class Initialized
INFO - 2020-04-21 03:45:54 --> Helper loaded: url_helper
INFO - 2020-04-21 03:45:54 --> Helper loaded: file_helper
INFO - 2020-04-21 03:45:54 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:45:54 --> Helper loaded: common_helper
INFO - 2020-04-21 03:45:54 --> Helper loaded: language_helper
INFO - 2020-04-21 03:45:54 --> Helper loaded: email_helper
INFO - 2020-04-21 03:45:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:45:54 --> Database Driver Class Initialized
INFO - 2020-04-21 03:45:54 --> Parser Class Initialized
INFO - 2020-04-21 03:45:54 --> User Agent Class Initialized
INFO - 2020-04-21 03:45:54 --> Model Class Initialized
INFO - 2020-04-21 03:45:54 --> Model Class Initialized
DEBUG - 2020-04-21 03:45:54 --> Template Class Initialized
INFO - 2020-04-21 03:45:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:45:54 --> Email Class Initialized
INFO - 2020-04-21 03:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:45:54 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:45:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:45:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:45:54 --> Encryption Class Initialized
INFO - 2020-04-21 03:45:54 --> Controller Class Initialized
DEBUG - 2020-04-21 03:45:54 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:45:54 --> Model Class Initialized
DEBUG - 2020-04-21 03:45:54 --> module MX_Controller Initialized
INFO - 2020-04-21 03:45:55 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 03:45:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 03:45:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 03:45:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:45:55 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:45:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:45:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:45:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:45:55 --> Final output sent to browser
DEBUG - 2020-04-21 03:45:55 --> Total execution time: 1.7835
INFO - 2020-04-21 03:46:52 --> Config Class Initialized
INFO - 2020-04-21 03:46:52 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:46:52 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:46:52 --> Utf8 Class Initialized
INFO - 2020-04-21 03:46:52 --> URI Class Initialized
INFO - 2020-04-21 03:46:52 --> Router Class Initialized
INFO - 2020-04-21 03:46:52 --> Output Class Initialized
INFO - 2020-04-21 03:46:52 --> Security Class Initialized
DEBUG - 2020-04-21 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:46:52 --> CSRF cookie sent
INFO - 2020-04-21 03:46:52 --> Input Class Initialized
INFO - 2020-04-21 03:46:52 --> Language Class Initialized
INFO - 2020-04-21 03:46:52 --> Language Class Initialized
INFO - 2020-04-21 03:46:52 --> Config Class Initialized
INFO - 2020-04-21 03:46:52 --> Loader Class Initialized
INFO - 2020-04-21 03:46:52 --> Helper loaded: url_helper
INFO - 2020-04-21 03:46:52 --> Helper loaded: file_helper
INFO - 2020-04-21 03:46:52 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:46:52 --> Helper loaded: common_helper
INFO - 2020-04-21 03:46:52 --> Helper loaded: language_helper
INFO - 2020-04-21 03:46:52 --> Helper loaded: email_helper
INFO - 2020-04-21 03:46:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:46:52 --> Database Driver Class Initialized
INFO - 2020-04-21 03:46:52 --> Parser Class Initialized
INFO - 2020-04-21 03:46:52 --> User Agent Class Initialized
INFO - 2020-04-21 03:46:52 --> Model Class Initialized
INFO - 2020-04-21 03:46:52 --> Model Class Initialized
DEBUG - 2020-04-21 03:46:52 --> Template Class Initialized
INFO - 2020-04-21 03:46:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:46:52 --> Email Class Initialized
INFO - 2020-04-21 03:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:46:52 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:46:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:46:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:46:52 --> Encryption Class Initialized
INFO - 2020-04-21 03:46:52 --> Controller Class Initialized
DEBUG - 2020-04-21 03:46:52 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:46:52 --> Model Class Initialized
DEBUG - 2020-04-21 03:46:52 --> module MX_Controller Initialized
INFO - 2020-04-21 03:46:53 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 03:46:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 03:46:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 03:46:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:46:53 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:46:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:46:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:46:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:46:53 --> Final output sent to browser
DEBUG - 2020-04-21 03:46:53 --> Total execution time: 1.7230
INFO - 2020-04-21 03:48:16 --> Config Class Initialized
INFO - 2020-04-21 03:48:16 --> Hooks Class Initialized
DEBUG - 2020-04-21 03:48:16 --> UTF-8 Support Enabled
INFO - 2020-04-21 03:48:16 --> Utf8 Class Initialized
INFO - 2020-04-21 03:48:16 --> URI Class Initialized
INFO - 2020-04-21 03:48:16 --> Router Class Initialized
INFO - 2020-04-21 03:48:16 --> Output Class Initialized
INFO - 2020-04-21 03:48:16 --> Security Class Initialized
DEBUG - 2020-04-21 03:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 03:48:16 --> CSRF cookie sent
INFO - 2020-04-21 03:48:16 --> Input Class Initialized
INFO - 2020-04-21 03:48:16 --> Language Class Initialized
INFO - 2020-04-21 03:48:16 --> Language Class Initialized
INFO - 2020-04-21 03:48:16 --> Config Class Initialized
INFO - 2020-04-21 03:48:16 --> Loader Class Initialized
INFO - 2020-04-21 03:48:16 --> Helper loaded: url_helper
INFO - 2020-04-21 03:48:16 --> Helper loaded: file_helper
INFO - 2020-04-21 03:48:16 --> Helper loaded: cookie_helper
INFO - 2020-04-21 03:48:16 --> Helper loaded: common_helper
INFO - 2020-04-21 03:48:16 --> Helper loaded: language_helper
INFO - 2020-04-21 03:48:16 --> Helper loaded: email_helper
INFO - 2020-04-21 03:48:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 03:48:16 --> Database Driver Class Initialized
INFO - 2020-04-21 03:48:16 --> Parser Class Initialized
INFO - 2020-04-21 03:48:16 --> User Agent Class Initialized
INFO - 2020-04-21 03:48:16 --> Model Class Initialized
INFO - 2020-04-21 03:48:16 --> Model Class Initialized
DEBUG - 2020-04-21 03:48:16 --> Template Class Initialized
INFO - 2020-04-21 03:48:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 03:48:16 --> Email Class Initialized
INFO - 2020-04-21 03:48:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 03:48:16 --> Pagination Class Initialized
DEBUG - 2020-04-21 03:48:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 03:48:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 03:48:16 --> Encryption Class Initialized
INFO - 2020-04-21 03:48:16 --> Controller Class Initialized
DEBUG - 2020-04-21 03:48:16 --> settings MX_Controller Initialized
INFO - 2020-04-21 03:48:16 --> Model Class Initialized
DEBUG - 2020-04-21 03:48:16 --> module MX_Controller Initialized
INFO - 2020-04-21 03:48:18 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 03:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 03:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 03:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 03:48:18 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 03:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 03:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 03:48:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 03:48:18 --> Final output sent to browser
DEBUG - 2020-04-21 03:48:18 --> Total execution time: 1.8225
INFO - 2020-04-21 04:07:24 --> Config Class Initialized
INFO - 2020-04-21 04:07:24 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:07:24 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:07:24 --> Utf8 Class Initialized
INFO - 2020-04-21 04:07:24 --> URI Class Initialized
INFO - 2020-04-21 04:07:25 --> Router Class Initialized
INFO - 2020-04-21 04:07:25 --> Output Class Initialized
INFO - 2020-04-21 04:07:25 --> Security Class Initialized
DEBUG - 2020-04-21 04:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:07:25 --> CSRF cookie sent
INFO - 2020-04-21 04:07:25 --> Input Class Initialized
INFO - 2020-04-21 04:07:25 --> Language Class Initialized
INFO - 2020-04-21 04:07:25 --> Language Class Initialized
INFO - 2020-04-21 04:07:25 --> Config Class Initialized
INFO - 2020-04-21 04:07:25 --> Loader Class Initialized
INFO - 2020-04-21 04:07:25 --> Helper loaded: url_helper
INFO - 2020-04-21 04:07:25 --> Helper loaded: file_helper
INFO - 2020-04-21 04:07:25 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:07:25 --> Helper loaded: common_helper
INFO - 2020-04-21 04:07:25 --> Helper loaded: language_helper
INFO - 2020-04-21 04:07:25 --> Helper loaded: email_helper
INFO - 2020-04-21 04:07:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:07:25 --> Database Driver Class Initialized
INFO - 2020-04-21 04:07:25 --> Parser Class Initialized
INFO - 2020-04-21 04:07:25 --> User Agent Class Initialized
INFO - 2020-04-21 04:07:25 --> Model Class Initialized
INFO - 2020-04-21 04:07:25 --> Model Class Initialized
DEBUG - 2020-04-21 04:07:25 --> Template Class Initialized
INFO - 2020-04-21 04:07:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:07:25 --> Email Class Initialized
INFO - 2020-04-21 04:07:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:07:25 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:07:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:07:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:07:25 --> Encryption Class Initialized
INFO - 2020-04-21 04:07:25 --> Controller Class Initialized
DEBUG - 2020-04-21 04:07:25 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:07:25 --> Model Class Initialized
DEBUG - 2020-04-21 04:07:25 --> module MX_Controller Initialized
INFO - 2020-04-21 04:07:26 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 04:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 04:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 04:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:07:26 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:07:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:07:27 --> Final output sent to browser
DEBUG - 2020-04-21 04:07:27 --> Total execution time: 2.0655
INFO - 2020-04-21 04:07:29 --> Config Class Initialized
INFO - 2020-04-21 04:07:29 --> Config Class Initialized
INFO - 2020-04-21 04:07:29 --> Hooks Class Initialized
INFO - 2020-04-21 04:07:29 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 04:07:29 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:07:29 --> Utf8 Class Initialized
INFO - 2020-04-21 04:07:29 --> Utf8 Class Initialized
INFO - 2020-04-21 04:07:29 --> URI Class Initialized
INFO - 2020-04-21 04:07:29 --> URI Class Initialized
INFO - 2020-04-21 04:07:29 --> Router Class Initialized
INFO - 2020-04-21 04:07:29 --> Router Class Initialized
INFO - 2020-04-21 04:07:29 --> Output Class Initialized
INFO - 2020-04-21 04:07:29 --> Output Class Initialized
INFO - 2020-04-21 04:07:29 --> Security Class Initialized
INFO - 2020-04-21 04:07:29 --> Security Class Initialized
DEBUG - 2020-04-21 04:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-21 04:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:07:29 --> CSRF cookie sent
INFO - 2020-04-21 04:07:29 --> CSRF cookie sent
INFO - 2020-04-21 04:07:29 --> Input Class Initialized
INFO - 2020-04-21 04:07:29 --> Input Class Initialized
INFO - 2020-04-21 04:07:29 --> Language Class Initialized
INFO - 2020-04-21 04:07:29 --> Language Class Initialized
ERROR - 2020-04-21 04:07:29 --> 404 Page Not Found: /index
ERROR - 2020-04-21 04:07:29 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:07:31 --> Config Class Initialized
INFO - 2020-04-21 04:07:31 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:07:31 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:07:31 --> Utf8 Class Initialized
INFO - 2020-04-21 04:07:31 --> URI Class Initialized
INFO - 2020-04-21 04:07:31 --> Router Class Initialized
INFO - 2020-04-21 04:07:31 --> Output Class Initialized
INFO - 2020-04-21 04:07:31 --> Security Class Initialized
DEBUG - 2020-04-21 04:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:07:31 --> CSRF cookie sent
INFO - 2020-04-21 04:07:31 --> CSRF token verified
INFO - 2020-04-21 04:07:31 --> Input Class Initialized
INFO - 2020-04-21 04:07:31 --> Language Class Initialized
INFO - 2020-04-21 04:07:31 --> Language Class Initialized
INFO - 2020-04-21 04:07:31 --> Config Class Initialized
INFO - 2020-04-21 04:07:31 --> Loader Class Initialized
INFO - 2020-04-21 04:07:31 --> Helper loaded: url_helper
INFO - 2020-04-21 04:07:31 --> Helper loaded: file_helper
INFO - 2020-04-21 04:07:31 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:07:31 --> Helper loaded: common_helper
INFO - 2020-04-21 04:07:31 --> Helper loaded: language_helper
INFO - 2020-04-21 04:07:31 --> Helper loaded: email_helper
INFO - 2020-04-21 04:07:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:07:31 --> Database Driver Class Initialized
INFO - 2020-04-21 04:07:31 --> Parser Class Initialized
INFO - 2020-04-21 04:07:31 --> User Agent Class Initialized
INFO - 2020-04-21 04:07:31 --> Model Class Initialized
INFO - 2020-04-21 04:07:31 --> Model Class Initialized
DEBUG - 2020-04-21 04:07:31 --> Template Class Initialized
INFO - 2020-04-21 04:07:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:07:31 --> Email Class Initialized
INFO - 2020-04-21 04:07:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:07:31 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:07:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:07:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:07:31 --> Encryption Class Initialized
INFO - 2020-04-21 04:07:31 --> Controller Class Initialized
DEBUG - 2020-04-21 04:07:31 --> module MX_Controller Initialized
INFO - 2020-04-21 04:07:31 --> Model Class Initialized
INFO - 2020-04-21 04:31:18 --> Config Class Initialized
INFO - 2020-04-21 04:31:18 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:31:18 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:31:18 --> Utf8 Class Initialized
INFO - 2020-04-21 04:31:18 --> URI Class Initialized
INFO - 2020-04-21 04:31:18 --> Router Class Initialized
INFO - 2020-04-21 04:31:18 --> Output Class Initialized
INFO - 2020-04-21 04:31:18 --> Security Class Initialized
DEBUG - 2020-04-21 04:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:31:18 --> CSRF cookie sent
INFO - 2020-04-21 04:31:18 --> Input Class Initialized
INFO - 2020-04-21 04:31:18 --> Language Class Initialized
INFO - 2020-04-21 04:31:18 --> Language Class Initialized
INFO - 2020-04-21 04:31:18 --> Config Class Initialized
INFO - 2020-04-21 04:31:18 --> Loader Class Initialized
INFO - 2020-04-21 04:31:18 --> Helper loaded: url_helper
INFO - 2020-04-21 04:31:18 --> Helper loaded: file_helper
INFO - 2020-04-21 04:31:18 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:31:18 --> Helper loaded: common_helper
INFO - 2020-04-21 04:31:18 --> Helper loaded: language_helper
INFO - 2020-04-21 04:31:18 --> Helper loaded: email_helper
INFO - 2020-04-21 04:31:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:31:18 --> Database Driver Class Initialized
INFO - 2020-04-21 04:31:18 --> Parser Class Initialized
INFO - 2020-04-21 04:31:18 --> User Agent Class Initialized
INFO - 2020-04-21 04:31:18 --> Model Class Initialized
INFO - 2020-04-21 04:31:19 --> Model Class Initialized
DEBUG - 2020-04-21 04:31:19 --> Template Class Initialized
INFO - 2020-04-21 04:31:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:31:19 --> Email Class Initialized
INFO - 2020-04-21 04:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:31:19 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:31:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:31:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:31:19 --> Encryption Class Initialized
INFO - 2020-04-21 04:31:19 --> Controller Class Initialized
DEBUG - 2020-04-21 04:31:19 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:31:19 --> Model Class Initialized
DEBUG - 2020-04-21 04:31:19 --> module MX_Controller Initialized
INFO - 2020-04-21 04:31:20 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 04:31:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 04:31:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 04:31:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:31:20 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:31:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:31:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:31:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:31:20 --> Final output sent to browser
DEBUG - 2020-04-21 04:31:20 --> Total execution time: 1.7651
INFO - 2020-04-21 04:31:20 --> Config Class Initialized
INFO - 2020-04-21 04:31:20 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:31:20 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:31:20 --> Utf8 Class Initialized
INFO - 2020-04-21 04:31:20 --> URI Class Initialized
INFO - 2020-04-21 04:31:20 --> Router Class Initialized
INFO - 2020-04-21 04:31:20 --> Output Class Initialized
INFO - 2020-04-21 04:31:20 --> Security Class Initialized
DEBUG - 2020-04-21 04:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:31:20 --> CSRF cookie sent
INFO - 2020-04-21 04:31:20 --> Input Class Initialized
INFO - 2020-04-21 04:31:20 --> Config Class Initialized
INFO - 2020-04-21 04:31:20 --> Hooks Class Initialized
INFO - 2020-04-21 04:31:20 --> Language Class Initialized
ERROR - 2020-04-21 04:31:20 --> 404 Page Not Found: /index
DEBUG - 2020-04-21 04:31:20 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:31:20 --> Utf8 Class Initialized
INFO - 2020-04-21 04:31:20 --> URI Class Initialized
INFO - 2020-04-21 04:31:20 --> Router Class Initialized
INFO - 2020-04-21 04:31:20 --> Output Class Initialized
INFO - 2020-04-21 04:31:20 --> Security Class Initialized
DEBUG - 2020-04-21 04:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:31:21 --> CSRF cookie sent
INFO - 2020-04-21 04:31:21 --> Input Class Initialized
INFO - 2020-04-21 04:31:21 --> Language Class Initialized
ERROR - 2020-04-21 04:31:21 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:32:50 --> Config Class Initialized
INFO - 2020-04-21 04:32:50 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:32:50 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:32:50 --> Utf8 Class Initialized
INFO - 2020-04-21 04:32:50 --> URI Class Initialized
INFO - 2020-04-21 04:32:50 --> Router Class Initialized
INFO - 2020-04-21 04:32:50 --> Output Class Initialized
INFO - 2020-04-21 04:32:50 --> Security Class Initialized
DEBUG - 2020-04-21 04:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:32:50 --> CSRF cookie sent
INFO - 2020-04-21 04:32:50 --> CSRF token verified
INFO - 2020-04-21 04:32:50 --> Input Class Initialized
INFO - 2020-04-21 04:32:50 --> Language Class Initialized
INFO - 2020-04-21 04:32:50 --> Language Class Initialized
INFO - 2020-04-21 04:32:50 --> Config Class Initialized
INFO - 2020-04-21 04:32:50 --> Loader Class Initialized
INFO - 2020-04-21 04:32:50 --> Helper loaded: url_helper
INFO - 2020-04-21 04:32:50 --> Helper loaded: file_helper
INFO - 2020-04-21 04:32:50 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:32:50 --> Helper loaded: common_helper
INFO - 2020-04-21 04:32:50 --> Helper loaded: language_helper
INFO - 2020-04-21 04:32:50 --> Helper loaded: email_helper
INFO - 2020-04-21 04:32:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:32:50 --> Database Driver Class Initialized
INFO - 2020-04-21 04:32:50 --> Parser Class Initialized
INFO - 2020-04-21 04:32:50 --> User Agent Class Initialized
INFO - 2020-04-21 04:32:50 --> Model Class Initialized
INFO - 2020-04-21 04:32:50 --> Model Class Initialized
DEBUG - 2020-04-21 04:32:50 --> Template Class Initialized
INFO - 2020-04-21 04:32:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:32:50 --> Email Class Initialized
INFO - 2020-04-21 04:32:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:32:50 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:32:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:32:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:32:50 --> Encryption Class Initialized
INFO - 2020-04-21 04:32:50 --> Controller Class Initialized
DEBUG - 2020-04-21 04:32:50 --> module MX_Controller Initialized
INFO - 2020-04-21 04:32:50 --> Model Class Initialized
ERROR - 2020-04-21 04:32:56 --> Severity: Notice --> Undefined variable: purchase_code D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 107
INFO - 2020-04-21 04:33:36 --> Config Class Initialized
INFO - 2020-04-21 04:33:36 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:36 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:36 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:36 --> URI Class Initialized
INFO - 2020-04-21 04:33:36 --> Router Class Initialized
INFO - 2020-04-21 04:33:36 --> Output Class Initialized
INFO - 2020-04-21 04:33:36 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:36 --> CSRF cookie sent
INFO - 2020-04-21 04:33:36 --> Input Class Initialized
INFO - 2020-04-21 04:33:36 --> Language Class Initialized
INFO - 2020-04-21 04:33:36 --> Language Class Initialized
INFO - 2020-04-21 04:33:36 --> Config Class Initialized
INFO - 2020-04-21 04:33:36 --> Loader Class Initialized
INFO - 2020-04-21 04:33:36 --> Helper loaded: url_helper
INFO - 2020-04-21 04:33:36 --> Helper loaded: file_helper
INFO - 2020-04-21 04:33:36 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:33:36 --> Helper loaded: common_helper
INFO - 2020-04-21 04:33:37 --> Helper loaded: language_helper
INFO - 2020-04-21 04:33:37 --> Helper loaded: email_helper
INFO - 2020-04-21 04:33:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:33:37 --> Database Driver Class Initialized
INFO - 2020-04-21 04:33:37 --> Parser Class Initialized
INFO - 2020-04-21 04:33:37 --> User Agent Class Initialized
INFO - 2020-04-21 04:33:37 --> Model Class Initialized
INFO - 2020-04-21 04:33:37 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:37 --> Template Class Initialized
INFO - 2020-04-21 04:33:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:33:37 --> Email Class Initialized
INFO - 2020-04-21 04:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:33:37 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:33:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:33:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:33:37 --> Encryption Class Initialized
INFO - 2020-04-21 04:33:37 --> Controller Class Initialized
DEBUG - 2020-04-21 04:33:37 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:33:37 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:37 --> module MX_Controller Initialized
INFO - 2020-04-21 04:33:37 --> Config Class Initialized
INFO - 2020-04-21 04:33:37 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:37 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:37 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:37 --> URI Class Initialized
DEBUG - 2020-04-21 04:33:37 --> No URI present. Default controller set.
INFO - 2020-04-21 04:33:37 --> Router Class Initialized
INFO - 2020-04-21 04:33:37 --> Output Class Initialized
INFO - 2020-04-21 04:33:37 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:37 --> CSRF cookie sent
INFO - 2020-04-21 04:33:37 --> Input Class Initialized
INFO - 2020-04-21 04:33:37 --> Language Class Initialized
INFO - 2020-04-21 04:33:37 --> Language Class Initialized
INFO - 2020-04-21 04:33:37 --> Config Class Initialized
INFO - 2020-04-21 04:33:37 --> Loader Class Initialized
INFO - 2020-04-21 04:33:37 --> Helper loaded: url_helper
INFO - 2020-04-21 04:33:37 --> Helper loaded: file_helper
INFO - 2020-04-21 04:33:37 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:33:37 --> Helper loaded: common_helper
INFO - 2020-04-21 04:33:37 --> Helper loaded: language_helper
INFO - 2020-04-21 04:33:37 --> Helper loaded: email_helper
INFO - 2020-04-21 04:33:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:33:37 --> Database Driver Class Initialized
INFO - 2020-04-21 04:33:37 --> Parser Class Initialized
INFO - 2020-04-21 04:33:37 --> User Agent Class Initialized
INFO - 2020-04-21 04:33:37 --> Model Class Initialized
INFO - 2020-04-21 04:33:37 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:37 --> Template Class Initialized
INFO - 2020-04-21 04:33:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:33:37 --> Email Class Initialized
INFO - 2020-04-21 04:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:33:37 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:33:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:33:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:33:37 --> Encryption Class Initialized
INFO - 2020-04-21 04:33:37 --> Controller Class Initialized
DEBUG - 2020-04-21 04:33:37 --> home MX_Controller Initialized
INFO - 2020-04-21 04:33:37 --> Model Class Initialized
INFO - 2020-04-21 04:33:37 --> Config Class Initialized
INFO - 2020-04-21 04:33:37 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:37 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:37 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:37 --> URI Class Initialized
INFO - 2020-04-21 04:33:37 --> Router Class Initialized
INFO - 2020-04-21 04:33:38 --> Output Class Initialized
INFO - 2020-04-21 04:33:38 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:38 --> CSRF cookie sent
INFO - 2020-04-21 04:33:38 --> Input Class Initialized
INFO - 2020-04-21 04:33:38 --> Language Class Initialized
INFO - 2020-04-21 04:33:38 --> Language Class Initialized
INFO - 2020-04-21 04:33:38 --> Config Class Initialized
INFO - 2020-04-21 04:33:38 --> Loader Class Initialized
INFO - 2020-04-21 04:33:38 --> Helper loaded: url_helper
INFO - 2020-04-21 04:33:38 --> Helper loaded: file_helper
INFO - 2020-04-21 04:33:38 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:33:38 --> Helper loaded: common_helper
INFO - 2020-04-21 04:33:38 --> Helper loaded: language_helper
INFO - 2020-04-21 04:33:38 --> Helper loaded: email_helper
INFO - 2020-04-21 04:33:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:33:38 --> Database Driver Class Initialized
INFO - 2020-04-21 04:33:38 --> Parser Class Initialized
INFO - 2020-04-21 04:33:38 --> User Agent Class Initialized
INFO - 2020-04-21 04:33:38 --> Model Class Initialized
INFO - 2020-04-21 04:33:38 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:38 --> Template Class Initialized
INFO - 2020-04-21 04:33:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:33:38 --> Email Class Initialized
INFO - 2020-04-21 04:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:33:38 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:33:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:33:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:33:38 --> Encryption Class Initialized
INFO - 2020-04-21 04:33:38 --> Controller Class Initialized
DEBUG - 2020-04-21 04:33:38 --> twitter MX_Controller Initialized
INFO - 2020-04-21 04:33:38 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-21 04:33:38 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/views/index.php
DEBUG - 2020-04-21 04:33:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:33:38 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:33:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:33:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:33:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:33:38 --> Final output sent to browser
DEBUG - 2020-04-21 04:33:38 --> Total execution time: 0.6543
INFO - 2020-04-21 04:33:38 --> Config Class Initialized
INFO - 2020-04-21 04:33:38 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:38 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:38 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:38 --> URI Class Initialized
INFO - 2020-04-21 04:33:38 --> Router Class Initialized
INFO - 2020-04-21 04:33:39 --> Output Class Initialized
INFO - 2020-04-21 04:33:39 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:39 --> CSRF cookie sent
INFO - 2020-04-21 04:33:39 --> Input Class Initialized
INFO - 2020-04-21 04:33:39 --> Config Class Initialized
INFO - 2020-04-21 04:33:39 --> Hooks Class Initialized
INFO - 2020-04-21 04:33:39 --> Language Class Initialized
ERROR - 2020-04-21 04:33:39 --> 404 Page Not Found: /index
DEBUG - 2020-04-21 04:33:39 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:39 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:39 --> URI Class Initialized
INFO - 2020-04-21 04:33:39 --> Router Class Initialized
INFO - 2020-04-21 04:33:39 --> Output Class Initialized
INFO - 2020-04-21 04:33:39 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:39 --> CSRF cookie sent
INFO - 2020-04-21 04:33:39 --> Input Class Initialized
INFO - 2020-04-21 04:33:39 --> Language Class Initialized
ERROR - 2020-04-21 04:33:39 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:33:44 --> Config Class Initialized
INFO - 2020-04-21 04:33:44 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:44 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:44 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:44 --> URI Class Initialized
INFO - 2020-04-21 04:33:44 --> Router Class Initialized
INFO - 2020-04-21 04:33:44 --> Output Class Initialized
INFO - 2020-04-21 04:33:44 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:44 --> CSRF cookie sent
INFO - 2020-04-21 04:33:44 --> Input Class Initialized
INFO - 2020-04-21 04:33:44 --> Language Class Initialized
INFO - 2020-04-21 04:33:44 --> Language Class Initialized
INFO - 2020-04-21 04:33:44 --> Config Class Initialized
INFO - 2020-04-21 04:33:44 --> Loader Class Initialized
INFO - 2020-04-21 04:33:44 --> Helper loaded: url_helper
INFO - 2020-04-21 04:33:44 --> Helper loaded: file_helper
INFO - 2020-04-21 04:33:44 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:33:44 --> Helper loaded: common_helper
INFO - 2020-04-21 04:33:44 --> Helper loaded: language_helper
INFO - 2020-04-21 04:33:44 --> Helper loaded: email_helper
INFO - 2020-04-21 04:33:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:33:44 --> Database Driver Class Initialized
INFO - 2020-04-21 04:33:44 --> Parser Class Initialized
INFO - 2020-04-21 04:33:44 --> User Agent Class Initialized
INFO - 2020-04-21 04:33:44 --> Model Class Initialized
INFO - 2020-04-21 04:33:44 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:44 --> Template Class Initialized
INFO - 2020-04-21 04:33:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:33:44 --> Email Class Initialized
INFO - 2020-04-21 04:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:33:45 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:33:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:33:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:33:45 --> Encryption Class Initialized
INFO - 2020-04-21 04:33:45 --> Controller Class Initialized
DEBUG - 2020-04-21 04:33:45 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:33:45 --> Model Class Initialized
INFO - 2020-04-21 04:33:45 --> Config Class Initialized
INFO - 2020-04-21 04:33:45 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:45 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:45 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:45 --> URI Class Initialized
INFO - 2020-04-21 04:33:45 --> Router Class Initialized
INFO - 2020-04-21 04:33:45 --> Output Class Initialized
INFO - 2020-04-21 04:33:45 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:45 --> CSRF cookie sent
INFO - 2020-04-21 04:33:45 --> Input Class Initialized
INFO - 2020-04-21 04:33:45 --> Language Class Initialized
INFO - 2020-04-21 04:33:45 --> Language Class Initialized
INFO - 2020-04-21 04:33:45 --> Config Class Initialized
INFO - 2020-04-21 04:33:45 --> Loader Class Initialized
INFO - 2020-04-21 04:33:45 --> Helper loaded: url_helper
INFO - 2020-04-21 04:33:45 --> Helper loaded: file_helper
INFO - 2020-04-21 04:33:45 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:33:45 --> Helper loaded: common_helper
INFO - 2020-04-21 04:33:45 --> Helper loaded: language_helper
INFO - 2020-04-21 04:33:45 --> Helper loaded: email_helper
INFO - 2020-04-21 04:33:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:33:45 --> Database Driver Class Initialized
INFO - 2020-04-21 04:33:45 --> Parser Class Initialized
INFO - 2020-04-21 04:33:45 --> User Agent Class Initialized
INFO - 2020-04-21 04:33:45 --> Model Class Initialized
INFO - 2020-04-21 04:33:45 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:45 --> Template Class Initialized
INFO - 2020-04-21 04:33:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:33:45 --> Email Class Initialized
INFO - 2020-04-21 04:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:33:45 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:33:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:33:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:33:45 --> Encryption Class Initialized
INFO - 2020-04-21 04:33:45 --> Controller Class Initialized
DEBUG - 2020-04-21 04:33:45 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:33:45 --> Model Class Initialized
INFO - 2020-04-21 04:33:45 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 04:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-21 04:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 04:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:33:45 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:33:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:33:45 --> Final output sent to browser
DEBUG - 2020-04-21 04:33:45 --> Total execution time: 0.8003
INFO - 2020-04-21 04:33:46 --> Config Class Initialized
INFO - 2020-04-21 04:33:46 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:46 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:46 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:46 --> URI Class Initialized
INFO - 2020-04-21 04:33:46 --> Router Class Initialized
INFO - 2020-04-21 04:33:46 --> Output Class Initialized
INFO - 2020-04-21 04:33:46 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:46 --> CSRF cookie sent
INFO - 2020-04-21 04:33:46 --> Config Class Initialized
INFO - 2020-04-21 04:33:46 --> Hooks Class Initialized
INFO - 2020-04-21 04:33:46 --> Input Class Initialized
INFO - 2020-04-21 04:33:46 --> Language Class Initialized
DEBUG - 2020-04-21 04:33:46 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:46 --> Utf8 Class Initialized
ERROR - 2020-04-21 04:33:46 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:33:46 --> URI Class Initialized
INFO - 2020-04-21 04:33:46 --> Router Class Initialized
INFO - 2020-04-21 04:33:46 --> Output Class Initialized
INFO - 2020-04-21 04:33:46 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:46 --> CSRF cookie sent
INFO - 2020-04-21 04:33:46 --> Input Class Initialized
INFO - 2020-04-21 04:33:46 --> Language Class Initialized
ERROR - 2020-04-21 04:33:46 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:33:48 --> Config Class Initialized
INFO - 2020-04-21 04:33:48 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:48 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:48 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:48 --> URI Class Initialized
INFO - 2020-04-21 04:33:48 --> Router Class Initialized
INFO - 2020-04-21 04:33:48 --> Output Class Initialized
INFO - 2020-04-21 04:33:48 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:48 --> CSRF cookie sent
INFO - 2020-04-21 04:33:48 --> Input Class Initialized
INFO - 2020-04-21 04:33:48 --> Language Class Initialized
INFO - 2020-04-21 04:33:48 --> Language Class Initialized
INFO - 2020-04-21 04:33:48 --> Config Class Initialized
INFO - 2020-04-21 04:33:48 --> Loader Class Initialized
INFO - 2020-04-21 04:33:48 --> Helper loaded: url_helper
INFO - 2020-04-21 04:33:48 --> Helper loaded: file_helper
INFO - 2020-04-21 04:33:48 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:33:48 --> Helper loaded: common_helper
INFO - 2020-04-21 04:33:48 --> Helper loaded: language_helper
INFO - 2020-04-21 04:33:48 --> Helper loaded: email_helper
INFO - 2020-04-21 04:33:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:33:48 --> Database Driver Class Initialized
INFO - 2020-04-21 04:33:48 --> Parser Class Initialized
INFO - 2020-04-21 04:33:48 --> User Agent Class Initialized
INFO - 2020-04-21 04:33:48 --> Model Class Initialized
INFO - 2020-04-21 04:33:48 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:48 --> Template Class Initialized
INFO - 2020-04-21 04:33:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:33:48 --> Email Class Initialized
INFO - 2020-04-21 04:33:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:33:48 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:33:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:33:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:33:48 --> Encryption Class Initialized
INFO - 2020-04-21 04:33:49 --> Controller Class Initialized
DEBUG - 2020-04-21 04:33:49 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:33:49 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:49 --> module MX_Controller Initialized
INFO - 2020-04-21 04:33:49 --> Config Class Initialized
INFO - 2020-04-21 04:33:49 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:49 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:49 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:49 --> URI Class Initialized
DEBUG - 2020-04-21 04:33:49 --> No URI present. Default controller set.
INFO - 2020-04-21 04:33:49 --> Router Class Initialized
INFO - 2020-04-21 04:33:49 --> Output Class Initialized
INFO - 2020-04-21 04:33:49 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:49 --> CSRF cookie sent
INFO - 2020-04-21 04:33:49 --> Input Class Initialized
INFO - 2020-04-21 04:33:49 --> Language Class Initialized
INFO - 2020-04-21 04:33:49 --> Language Class Initialized
INFO - 2020-04-21 04:33:49 --> Config Class Initialized
INFO - 2020-04-21 04:33:49 --> Loader Class Initialized
INFO - 2020-04-21 04:33:49 --> Helper loaded: url_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: file_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: common_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: language_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: email_helper
INFO - 2020-04-21 04:33:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:33:49 --> Database Driver Class Initialized
INFO - 2020-04-21 04:33:49 --> Parser Class Initialized
INFO - 2020-04-21 04:33:49 --> User Agent Class Initialized
INFO - 2020-04-21 04:33:49 --> Model Class Initialized
INFO - 2020-04-21 04:33:49 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:49 --> Template Class Initialized
INFO - 2020-04-21 04:33:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:33:49 --> Email Class Initialized
INFO - 2020-04-21 04:33:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:33:49 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:33:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:33:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:33:49 --> Encryption Class Initialized
INFO - 2020-04-21 04:33:49 --> Controller Class Initialized
DEBUG - 2020-04-21 04:33:49 --> home MX_Controller Initialized
INFO - 2020-04-21 04:33:49 --> Model Class Initialized
INFO - 2020-04-21 04:33:49 --> Config Class Initialized
INFO - 2020-04-21 04:33:49 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:49 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:49 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:49 --> URI Class Initialized
INFO - 2020-04-21 04:33:49 --> Router Class Initialized
INFO - 2020-04-21 04:33:49 --> Output Class Initialized
INFO - 2020-04-21 04:33:49 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:49 --> CSRF cookie sent
INFO - 2020-04-21 04:33:49 --> Input Class Initialized
INFO - 2020-04-21 04:33:49 --> Language Class Initialized
INFO - 2020-04-21 04:33:49 --> Language Class Initialized
INFO - 2020-04-21 04:33:49 --> Config Class Initialized
INFO - 2020-04-21 04:33:49 --> Loader Class Initialized
INFO - 2020-04-21 04:33:49 --> Helper loaded: url_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: file_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: common_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: language_helper
INFO - 2020-04-21 04:33:49 --> Helper loaded: email_helper
INFO - 2020-04-21 04:33:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:33:50 --> Database Driver Class Initialized
INFO - 2020-04-21 04:33:50 --> Parser Class Initialized
INFO - 2020-04-21 04:33:50 --> User Agent Class Initialized
INFO - 2020-04-21 04:33:50 --> Model Class Initialized
INFO - 2020-04-21 04:33:50 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:50 --> Template Class Initialized
INFO - 2020-04-21 04:33:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:33:50 --> Email Class Initialized
INFO - 2020-04-21 04:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:33:50 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:33:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:33:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:33:50 --> Encryption Class Initialized
INFO - 2020-04-21 04:33:50 --> Controller Class Initialized
DEBUG - 2020-04-21 04:33:50 --> twitter MX_Controller Initialized
INFO - 2020-04-21 04:33:50 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-21 04:33:50 --> Model Class Initialized
DEBUG - 2020-04-21 04:33:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/twitter/views/index.php
DEBUG - 2020-04-21 04:33:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:33:50 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:33:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:33:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:33:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:33:50 --> Final output sent to browser
DEBUG - 2020-04-21 04:33:50 --> Total execution time: 0.6846
INFO - 2020-04-21 04:33:50 --> Config Class Initialized
INFO - 2020-04-21 04:33:50 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:50 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:50 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:50 --> URI Class Initialized
INFO - 2020-04-21 04:33:50 --> Router Class Initialized
INFO - 2020-04-21 04:33:50 --> Output Class Initialized
INFO - 2020-04-21 04:33:50 --> Security Class Initialized
INFO - 2020-04-21 04:33:50 --> Config Class Initialized
INFO - 2020-04-21 04:33:50 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:50 --> CSRF cookie sent
DEBUG - 2020-04-21 04:33:50 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:33:50 --> Input Class Initialized
INFO - 2020-04-21 04:33:50 --> Utf8 Class Initialized
INFO - 2020-04-21 04:33:50 --> Language Class Initialized
INFO - 2020-04-21 04:33:50 --> URI Class Initialized
ERROR - 2020-04-21 04:33:50 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:33:50 --> Router Class Initialized
INFO - 2020-04-21 04:33:50 --> Output Class Initialized
INFO - 2020-04-21 04:33:50 --> Security Class Initialized
DEBUG - 2020-04-21 04:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:33:50 --> CSRF cookie sent
INFO - 2020-04-21 04:33:50 --> Input Class Initialized
INFO - 2020-04-21 04:33:50 --> Language Class Initialized
ERROR - 2020-04-21 04:33:50 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:35:10 --> Config Class Initialized
INFO - 2020-04-21 04:35:10 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:35:10 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:35:10 --> Utf8 Class Initialized
INFO - 2020-04-21 04:35:10 --> URI Class Initialized
INFO - 2020-04-21 04:35:10 --> Router Class Initialized
INFO - 2020-04-21 04:35:10 --> Output Class Initialized
INFO - 2020-04-21 04:35:10 --> Security Class Initialized
DEBUG - 2020-04-21 04:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:35:10 --> Config Class Initialized
INFO - 2020-04-21 04:35:10 --> Hooks Class Initialized
INFO - 2020-04-21 04:35:10 --> CSRF cookie sent
INFO - 2020-04-21 04:35:10 --> Input Class Initialized
DEBUG - 2020-04-21 04:35:10 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:35:10 --> Utf8 Class Initialized
INFO - 2020-04-21 04:35:10 --> Language Class Initialized
INFO - 2020-04-21 04:35:10 --> URI Class Initialized
ERROR - 2020-04-21 04:35:10 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:35:10 --> Router Class Initialized
INFO - 2020-04-21 04:35:10 --> Output Class Initialized
INFO - 2020-04-21 04:35:10 --> Security Class Initialized
DEBUG - 2020-04-21 04:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:35:10 --> CSRF cookie sent
INFO - 2020-04-21 04:35:10 --> Input Class Initialized
INFO - 2020-04-21 04:35:10 --> Language Class Initialized
ERROR - 2020-04-21 04:35:10 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:35:11 --> Config Class Initialized
INFO - 2020-04-21 04:35:11 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:35:11 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:35:11 --> Utf8 Class Initialized
INFO - 2020-04-21 04:35:12 --> URI Class Initialized
INFO - 2020-04-21 04:35:12 --> Router Class Initialized
INFO - 2020-04-21 04:35:12 --> Output Class Initialized
INFO - 2020-04-21 04:35:12 --> Security Class Initialized
DEBUG - 2020-04-21 04:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:35:12 --> CSRF cookie sent
INFO - 2020-04-21 04:35:12 --> Input Class Initialized
INFO - 2020-04-21 04:35:12 --> Language Class Initialized
INFO - 2020-04-21 04:35:12 --> Language Class Initialized
INFO - 2020-04-21 04:35:12 --> Config Class Initialized
INFO - 2020-04-21 04:35:12 --> Loader Class Initialized
INFO - 2020-04-21 04:35:12 --> Helper loaded: url_helper
INFO - 2020-04-21 04:35:12 --> Helper loaded: file_helper
INFO - 2020-04-21 04:35:12 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:35:12 --> Helper loaded: common_helper
INFO - 2020-04-21 04:35:12 --> Helper loaded: language_helper
INFO - 2020-04-21 04:35:12 --> Helper loaded: email_helper
INFO - 2020-04-21 04:35:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:35:12 --> Database Driver Class Initialized
INFO - 2020-04-21 04:35:12 --> Parser Class Initialized
INFO - 2020-04-21 04:35:12 --> User Agent Class Initialized
INFO - 2020-04-21 04:35:12 --> Model Class Initialized
INFO - 2020-04-21 04:35:12 --> Model Class Initialized
DEBUG - 2020-04-21 04:35:12 --> Template Class Initialized
INFO - 2020-04-21 04:35:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:35:12 --> Email Class Initialized
INFO - 2020-04-21 04:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:35:12 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:35:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:35:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:35:12 --> Encryption Class Initialized
INFO - 2020-04-21 04:35:12 --> Controller Class Initialized
DEBUG - 2020-04-21 04:35:12 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:35:12 --> Model Class Initialized
DEBUG - 2020-04-21 04:35:12 --> module MX_Controller Initialized
INFO - 2020-04-21 04:35:13 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 04:35:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 04:35:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 04:35:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:35:13 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:35:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:35:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:35:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:35:13 --> Final output sent to browser
DEBUG - 2020-04-21 04:35:13 --> Total execution time: 1.7361
INFO - 2020-04-21 04:35:13 --> Config Class Initialized
INFO - 2020-04-21 04:35:13 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:35:13 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:35:13 --> Utf8 Class Initialized
INFO - 2020-04-21 04:35:13 --> URI Class Initialized
INFO - 2020-04-21 04:35:13 --> Router Class Initialized
INFO - 2020-04-21 04:35:14 --> Output Class Initialized
INFO - 2020-04-21 04:35:14 --> Security Class Initialized
INFO - 2020-04-21 04:35:14 --> Config Class Initialized
INFO - 2020-04-21 04:35:14 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:35:14 --> CSRF cookie sent
DEBUG - 2020-04-21 04:35:14 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:35:14 --> Utf8 Class Initialized
INFO - 2020-04-21 04:35:14 --> Input Class Initialized
INFO - 2020-04-21 04:35:14 --> Language Class Initialized
INFO - 2020-04-21 04:35:14 --> URI Class Initialized
ERROR - 2020-04-21 04:35:14 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:35:14 --> Router Class Initialized
INFO - 2020-04-21 04:35:14 --> Output Class Initialized
INFO - 2020-04-21 04:35:14 --> Security Class Initialized
DEBUG - 2020-04-21 04:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:35:14 --> CSRF cookie sent
INFO - 2020-04-21 04:35:14 --> Input Class Initialized
INFO - 2020-04-21 04:35:14 --> Language Class Initialized
ERROR - 2020-04-21 04:35:14 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:35:59 --> Config Class Initialized
INFO - 2020-04-21 04:35:59 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:35:59 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:35:59 --> Utf8 Class Initialized
INFO - 2020-04-21 04:36:00 --> URI Class Initialized
INFO - 2020-04-21 04:36:00 --> Router Class Initialized
INFO - 2020-04-21 04:36:00 --> Output Class Initialized
INFO - 2020-04-21 04:36:00 --> Security Class Initialized
DEBUG - 2020-04-21 04:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:36:00 --> CSRF cookie sent
INFO - 2020-04-21 04:36:00 --> Input Class Initialized
INFO - 2020-04-21 04:36:00 --> Language Class Initialized
INFO - 2020-04-21 04:36:00 --> Language Class Initialized
INFO - 2020-04-21 04:36:00 --> Config Class Initialized
INFO - 2020-04-21 04:36:00 --> Loader Class Initialized
INFO - 2020-04-21 04:36:00 --> Helper loaded: url_helper
INFO - 2020-04-21 04:36:00 --> Helper loaded: file_helper
INFO - 2020-04-21 04:36:00 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:36:00 --> Helper loaded: common_helper
INFO - 2020-04-21 04:36:00 --> Helper loaded: language_helper
INFO - 2020-04-21 04:36:00 --> Helper loaded: email_helper
INFO - 2020-04-21 04:36:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:36:00 --> Database Driver Class Initialized
INFO - 2020-04-21 04:36:00 --> Parser Class Initialized
INFO - 2020-04-21 04:36:00 --> User Agent Class Initialized
INFO - 2020-04-21 04:36:00 --> Model Class Initialized
INFO - 2020-04-21 04:36:00 --> Model Class Initialized
DEBUG - 2020-04-21 04:36:00 --> Template Class Initialized
INFO - 2020-04-21 04:36:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:36:00 --> Email Class Initialized
INFO - 2020-04-21 04:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:36:00 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:36:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:36:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:36:00 --> Encryption Class Initialized
INFO - 2020-04-21 04:36:00 --> Controller Class Initialized
DEBUG - 2020-04-21 04:36:00 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:36:00 --> Model Class Initialized
DEBUG - 2020-04-21 04:36:00 --> module MX_Controller Initialized
INFO - 2020-04-21 04:36:01 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 04:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 04:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 04:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:36:01 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:36:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:36:01 --> Final output sent to browser
DEBUG - 2020-04-21 04:36:01 --> Total execution time: 1.8237
INFO - 2020-04-21 04:36:01 --> Config Class Initialized
INFO - 2020-04-21 04:36:02 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:36:02 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:36:02 --> Utf8 Class Initialized
INFO - 2020-04-21 04:36:02 --> URI Class Initialized
INFO - 2020-04-21 04:36:02 --> Router Class Initialized
INFO - 2020-04-21 04:36:02 --> Output Class Initialized
INFO - 2020-04-21 04:36:02 --> Security Class Initialized
INFO - 2020-04-21 04:36:02 --> Config Class Initialized
INFO - 2020-04-21 04:36:02 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:36:02 --> CSRF cookie sent
DEBUG - 2020-04-21 04:36:02 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:36:02 --> Input Class Initialized
INFO - 2020-04-21 04:36:02 --> Utf8 Class Initialized
INFO - 2020-04-21 04:36:02 --> Language Class Initialized
INFO - 2020-04-21 04:36:02 --> URI Class Initialized
ERROR - 2020-04-21 04:36:02 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:36:02 --> Router Class Initialized
INFO - 2020-04-21 04:36:02 --> Output Class Initialized
INFO - 2020-04-21 04:36:02 --> Security Class Initialized
DEBUG - 2020-04-21 04:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:36:02 --> CSRF cookie sent
INFO - 2020-04-21 04:36:02 --> Input Class Initialized
INFO - 2020-04-21 04:36:02 --> Language Class Initialized
ERROR - 2020-04-21 04:36:02 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:36:05 --> Config Class Initialized
INFO - 2020-04-21 04:36:05 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:36:05 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:36:05 --> Utf8 Class Initialized
INFO - 2020-04-21 04:36:06 --> URI Class Initialized
INFO - 2020-04-21 04:36:06 --> Router Class Initialized
INFO - 2020-04-21 04:36:06 --> Output Class Initialized
INFO - 2020-04-21 04:36:06 --> Security Class Initialized
DEBUG - 2020-04-21 04:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:36:06 --> CSRF cookie sent
INFO - 2020-04-21 04:36:06 --> CSRF token verified
INFO - 2020-04-21 04:36:06 --> Input Class Initialized
INFO - 2020-04-21 04:36:06 --> Language Class Initialized
INFO - 2020-04-21 04:36:06 --> Language Class Initialized
INFO - 2020-04-21 04:36:06 --> Config Class Initialized
INFO - 2020-04-21 04:36:06 --> Loader Class Initialized
INFO - 2020-04-21 04:36:06 --> Helper loaded: url_helper
INFO - 2020-04-21 04:36:06 --> Helper loaded: file_helper
INFO - 2020-04-21 04:36:06 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:36:06 --> Helper loaded: common_helper
INFO - 2020-04-21 04:36:06 --> Helper loaded: language_helper
INFO - 2020-04-21 04:36:06 --> Helper loaded: email_helper
INFO - 2020-04-21 04:36:06 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:36:06 --> Database Driver Class Initialized
INFO - 2020-04-21 04:36:06 --> Parser Class Initialized
INFO - 2020-04-21 04:36:06 --> User Agent Class Initialized
INFO - 2020-04-21 04:36:06 --> Model Class Initialized
INFO - 2020-04-21 04:36:06 --> Model Class Initialized
DEBUG - 2020-04-21 04:36:06 --> Template Class Initialized
INFO - 2020-04-21 04:36:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:36:06 --> Email Class Initialized
INFO - 2020-04-21 04:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:36:06 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:36:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:36:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:36:06 --> Encryption Class Initialized
INFO - 2020-04-21 04:36:06 --> Controller Class Initialized
DEBUG - 2020-04-21 04:36:06 --> module MX_Controller Initialized
INFO - 2020-04-21 04:36:06 --> Model Class Initialized
INFO - 2020-04-21 04:36:18 --> Config Class Initialized
INFO - 2020-04-21 04:36:18 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:36:18 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:36:18 --> Utf8 Class Initialized
INFO - 2020-04-21 04:36:18 --> URI Class Initialized
INFO - 2020-04-21 04:36:18 --> Router Class Initialized
INFO - 2020-04-21 04:36:18 --> Output Class Initialized
INFO - 2020-04-21 04:36:18 --> Security Class Initialized
DEBUG - 2020-04-21 04:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:36:18 --> CSRF cookie sent
INFO - 2020-04-21 04:36:18 --> Input Class Initialized
INFO - 2020-04-21 04:36:18 --> Language Class Initialized
INFO - 2020-04-21 04:36:18 --> Language Class Initialized
INFO - 2020-04-21 04:36:18 --> Config Class Initialized
INFO - 2020-04-21 04:36:18 --> Loader Class Initialized
INFO - 2020-04-21 04:36:18 --> Helper loaded: url_helper
INFO - 2020-04-21 04:36:18 --> Helper loaded: file_helper
INFO - 2020-04-21 04:36:18 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:36:18 --> Helper loaded: common_helper
INFO - 2020-04-21 04:36:18 --> Helper loaded: language_helper
INFO - 2020-04-21 04:36:18 --> Helper loaded: email_helper
INFO - 2020-04-21 04:36:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:36:18 --> Database Driver Class Initialized
INFO - 2020-04-21 04:36:18 --> Parser Class Initialized
INFO - 2020-04-21 04:36:18 --> User Agent Class Initialized
INFO - 2020-04-21 04:36:18 --> Model Class Initialized
INFO - 2020-04-21 04:36:18 --> Model Class Initialized
DEBUG - 2020-04-21 04:36:18 --> Template Class Initialized
INFO - 2020-04-21 04:36:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:36:18 --> Email Class Initialized
INFO - 2020-04-21 04:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:36:19 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:36:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:36:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:36:19 --> Encryption Class Initialized
INFO - 2020-04-21 04:36:19 --> Controller Class Initialized
DEBUG - 2020-04-21 04:36:19 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:36:19 --> Model Class Initialized
DEBUG - 2020-04-21 04:36:19 --> module MX_Controller Initialized
INFO - 2020-04-21 04:36:20 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 04:36:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 04:36:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 04:36:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:36:20 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:36:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:36:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:36:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:36:20 --> Final output sent to browser
DEBUG - 2020-04-21 04:36:20 --> Total execution time: 1.8916
INFO - 2020-04-21 04:36:20 --> Config Class Initialized
INFO - 2020-04-21 04:36:20 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:36:20 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:36:20 --> Utf8 Class Initialized
INFO - 2020-04-21 04:36:20 --> URI Class Initialized
INFO - 2020-04-21 04:36:20 --> Router Class Initialized
INFO - 2020-04-21 04:36:20 --> Output Class Initialized
INFO - 2020-04-21 04:36:20 --> Security Class Initialized
DEBUG - 2020-04-21 04:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:36:20 --> Config Class Initialized
INFO - 2020-04-21 04:36:20 --> CSRF cookie sent
INFO - 2020-04-21 04:36:20 --> Input Class Initialized
INFO - 2020-04-21 04:36:20 --> Hooks Class Initialized
INFO - 2020-04-21 04:36:20 --> Language Class Initialized
DEBUG - 2020-04-21 04:36:20 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:36:20 --> Utf8 Class Initialized
ERROR - 2020-04-21 04:36:20 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:36:20 --> URI Class Initialized
INFO - 2020-04-21 04:36:20 --> Router Class Initialized
INFO - 2020-04-21 04:36:20 --> Output Class Initialized
INFO - 2020-04-21 04:36:20 --> Security Class Initialized
DEBUG - 2020-04-21 04:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:36:20 --> CSRF cookie sent
INFO - 2020-04-21 04:36:21 --> Input Class Initialized
INFO - 2020-04-21 04:36:21 --> Language Class Initialized
ERROR - 2020-04-21 04:36:21 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:41:22 --> Config Class Initialized
INFO - 2020-04-21 04:41:22 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:41:22 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:41:22 --> Utf8 Class Initialized
INFO - 2020-04-21 04:41:22 --> URI Class Initialized
INFO - 2020-04-21 04:41:22 --> Router Class Initialized
INFO - 2020-04-21 04:41:22 --> Output Class Initialized
INFO - 2020-04-21 04:41:22 --> Security Class Initialized
DEBUG - 2020-04-21 04:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:41:22 --> CSRF cookie sent
INFO - 2020-04-21 04:41:22 --> Input Class Initialized
INFO - 2020-04-21 04:41:22 --> Language Class Initialized
INFO - 2020-04-21 04:41:22 --> Language Class Initialized
INFO - 2020-04-21 04:41:22 --> Config Class Initialized
INFO - 2020-04-21 04:41:22 --> Loader Class Initialized
INFO - 2020-04-21 04:41:22 --> Helper loaded: url_helper
INFO - 2020-04-21 04:41:22 --> Helper loaded: file_helper
INFO - 2020-04-21 04:41:22 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:41:22 --> Helper loaded: common_helper
INFO - 2020-04-21 04:41:22 --> Helper loaded: language_helper
INFO - 2020-04-21 04:41:22 --> Helper loaded: email_helper
INFO - 2020-04-21 04:41:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:41:22 --> Database Driver Class Initialized
INFO - 2020-04-21 04:41:22 --> Parser Class Initialized
INFO - 2020-04-21 04:41:22 --> User Agent Class Initialized
INFO - 2020-04-21 04:41:22 --> Model Class Initialized
INFO - 2020-04-21 04:41:22 --> Model Class Initialized
DEBUG - 2020-04-21 04:41:22 --> Template Class Initialized
INFO - 2020-04-21 04:41:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:41:22 --> Email Class Initialized
INFO - 2020-04-21 04:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:41:22 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:41:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:41:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:41:22 --> Encryption Class Initialized
INFO - 2020-04-21 04:41:22 --> Controller Class Initialized
DEBUG - 2020-04-21 04:41:22 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:41:22 --> Model Class Initialized
DEBUG - 2020-04-21 04:41:23 --> module MX_Controller Initialized
INFO - 2020-04-21 04:41:24 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 04:41:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 04:41:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 04:41:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:41:24 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:41:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:41:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:41:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:41:24 --> Final output sent to browser
DEBUG - 2020-04-21 04:41:24 --> Total execution time: 1.9195
INFO - 2020-04-21 04:41:24 --> Config Class Initialized
INFO - 2020-04-21 04:41:24 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:41:24 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:41:24 --> Utf8 Class Initialized
INFO - 2020-04-21 04:41:24 --> URI Class Initialized
INFO - 2020-04-21 04:41:24 --> Router Class Initialized
INFO - 2020-04-21 04:41:24 --> Output Class Initialized
INFO - 2020-04-21 04:41:24 --> Security Class Initialized
INFO - 2020-04-21 04:41:24 --> Config Class Initialized
DEBUG - 2020-04-21 04:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:41:24 --> Hooks Class Initialized
INFO - 2020-04-21 04:41:24 --> CSRF cookie sent
INFO - 2020-04-21 04:41:24 --> Input Class Initialized
DEBUG - 2020-04-21 04:41:24 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:41:24 --> Utf8 Class Initialized
INFO - 2020-04-21 04:41:24 --> Language Class Initialized
ERROR - 2020-04-21 04:41:24 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:41:24 --> URI Class Initialized
INFO - 2020-04-21 04:41:24 --> Router Class Initialized
INFO - 2020-04-21 04:41:24 --> Output Class Initialized
INFO - 2020-04-21 04:41:24 --> Security Class Initialized
DEBUG - 2020-04-21 04:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:41:24 --> CSRF cookie sent
INFO - 2020-04-21 04:41:24 --> Input Class Initialized
INFO - 2020-04-21 04:41:24 --> Language Class Initialized
ERROR - 2020-04-21 04:41:24 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:41:27 --> Config Class Initialized
INFO - 2020-04-21 04:41:27 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:41:27 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:41:27 --> Utf8 Class Initialized
INFO - 2020-04-21 04:41:27 --> URI Class Initialized
INFO - 2020-04-21 04:41:27 --> Router Class Initialized
INFO - 2020-04-21 04:41:27 --> Output Class Initialized
INFO - 2020-04-21 04:41:27 --> Security Class Initialized
DEBUG - 2020-04-21 04:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:41:28 --> CSRF cookie sent
INFO - 2020-04-21 04:41:28 --> CSRF token verified
INFO - 2020-04-21 04:41:28 --> Input Class Initialized
INFO - 2020-04-21 04:41:28 --> Language Class Initialized
INFO - 2020-04-21 04:41:28 --> Language Class Initialized
INFO - 2020-04-21 04:41:28 --> Config Class Initialized
INFO - 2020-04-21 04:41:28 --> Loader Class Initialized
INFO - 2020-04-21 04:41:28 --> Helper loaded: url_helper
INFO - 2020-04-21 04:41:28 --> Helper loaded: file_helper
INFO - 2020-04-21 04:41:28 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:41:28 --> Helper loaded: common_helper
INFO - 2020-04-21 04:41:28 --> Helper loaded: language_helper
INFO - 2020-04-21 04:41:28 --> Helper loaded: email_helper
INFO - 2020-04-21 04:41:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:41:28 --> Database Driver Class Initialized
INFO - 2020-04-21 04:41:28 --> Parser Class Initialized
INFO - 2020-04-21 04:41:28 --> User Agent Class Initialized
INFO - 2020-04-21 04:41:28 --> Model Class Initialized
INFO - 2020-04-21 04:41:28 --> Model Class Initialized
DEBUG - 2020-04-21 04:41:28 --> Template Class Initialized
INFO - 2020-04-21 04:41:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:41:28 --> Email Class Initialized
INFO - 2020-04-21 04:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:41:28 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:41:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:41:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:41:28 --> Encryption Class Initialized
INFO - 2020-04-21 04:41:28 --> Controller Class Initialized
DEBUG - 2020-04-21 04:41:28 --> module MX_Controller Initialized
INFO - 2020-04-21 04:41:28 --> Model Class Initialized
INFO - 2020-04-21 04:41:40 --> Config Class Initialized
INFO - 2020-04-21 04:41:40 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:41:40 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:41:40 --> Utf8 Class Initialized
INFO - 2020-04-21 04:41:40 --> URI Class Initialized
INFO - 2020-04-21 04:41:40 --> Router Class Initialized
INFO - 2020-04-21 04:41:40 --> Output Class Initialized
INFO - 2020-04-21 04:41:40 --> Security Class Initialized
DEBUG - 2020-04-21 04:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:41:40 --> CSRF cookie sent
INFO - 2020-04-21 04:41:40 --> Input Class Initialized
INFO - 2020-04-21 04:41:40 --> Language Class Initialized
INFO - 2020-04-21 04:41:40 --> Language Class Initialized
INFO - 2020-04-21 04:41:40 --> Config Class Initialized
INFO - 2020-04-21 04:41:40 --> Loader Class Initialized
INFO - 2020-04-21 04:41:40 --> Helper loaded: url_helper
INFO - 2020-04-21 04:41:40 --> Helper loaded: file_helper
INFO - 2020-04-21 04:41:40 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:41:40 --> Helper loaded: common_helper
INFO - 2020-04-21 04:41:40 --> Helper loaded: language_helper
INFO - 2020-04-21 04:41:40 --> Helper loaded: email_helper
INFO - 2020-04-21 04:41:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:41:40 --> Database Driver Class Initialized
INFO - 2020-04-21 04:41:40 --> Parser Class Initialized
INFO - 2020-04-21 04:41:40 --> User Agent Class Initialized
INFO - 2020-04-21 04:41:40 --> Model Class Initialized
INFO - 2020-04-21 04:41:40 --> Model Class Initialized
DEBUG - 2020-04-21 04:41:40 --> Template Class Initialized
INFO - 2020-04-21 04:41:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:41:40 --> Email Class Initialized
INFO - 2020-04-21 04:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:41:40 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:41:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:41:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:41:40 --> Encryption Class Initialized
INFO - 2020-04-21 04:41:40 --> Controller Class Initialized
DEBUG - 2020-04-21 04:41:40 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:41:41 --> Model Class Initialized
DEBUG - 2020-04-21 04:41:41 --> module MX_Controller Initialized
ERROR - 2020-04-21 04:41:41 --> Severity: error --> Exception: Call to undefined function get_json_content() D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules\settings\controllers\module.php 17
INFO - 2020-04-21 04:44:35 --> Config Class Initialized
INFO - 2020-04-21 04:44:35 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:44:35 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:44:35 --> Utf8 Class Initialized
INFO - 2020-04-21 04:44:35 --> URI Class Initialized
INFO - 2020-04-21 04:44:35 --> Router Class Initialized
INFO - 2020-04-21 04:44:35 --> Output Class Initialized
INFO - 2020-04-21 04:44:35 --> Security Class Initialized
DEBUG - 2020-04-21 04:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:44:35 --> CSRF cookie sent
INFO - 2020-04-21 04:44:35 --> Input Class Initialized
INFO - 2020-04-21 04:44:35 --> Language Class Initialized
INFO - 2020-04-21 04:44:35 --> Language Class Initialized
INFO - 2020-04-21 04:44:35 --> Config Class Initialized
INFO - 2020-04-21 04:44:35 --> Loader Class Initialized
INFO - 2020-04-21 04:44:35 --> Helper loaded: url_helper
INFO - 2020-04-21 04:44:35 --> Helper loaded: file_helper
INFO - 2020-04-21 04:44:35 --> Helper loaded: cookie_helper
INFO - 2020-04-21 04:44:35 --> Helper loaded: common_helper
INFO - 2020-04-21 04:44:35 --> Helper loaded: language_helper
INFO - 2020-04-21 04:44:35 --> Helper loaded: email_helper
INFO - 2020-04-21 04:44:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-21 04:44:35 --> Database Driver Class Initialized
INFO - 2020-04-21 04:44:35 --> Parser Class Initialized
INFO - 2020-04-21 04:44:35 --> User Agent Class Initialized
INFO - 2020-04-21 04:44:35 --> Model Class Initialized
INFO - 2020-04-21 04:44:35 --> Model Class Initialized
DEBUG - 2020-04-21 04:44:35 --> Template Class Initialized
INFO - 2020-04-21 04:44:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-21 04:44:35 --> Email Class Initialized
INFO - 2020-04-21 04:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-21 04:44:35 --> Pagination Class Initialized
DEBUG - 2020-04-21 04:44:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-21 04:44:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-21 04:44:35 --> Encryption Class Initialized
INFO - 2020-04-21 04:44:35 --> Controller Class Initialized
DEBUG - 2020-04-21 04:44:35 --> settings MX_Controller Initialized
INFO - 2020-04-21 04:44:35 --> Model Class Initialized
DEBUG - 2020-04-21 04:44:35 --> module MX_Controller Initialized
INFO - 2020-04-21 04:44:36 --> Helper loaded: inflector_helper
DEBUG - 2020-04-21 04:44:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/module.php
DEBUG - 2020-04-21 04:44:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/settings/views/index.php
DEBUG - 2020-04-21 04:44:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-21 04:44:36 --> blocks MX_Controller Initialized
DEBUG - 2020-04-21 04:44:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-21 04:44:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-21 04:44:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-21 04:44:36 --> Final output sent to browser
DEBUG - 2020-04-21 04:44:36 --> Total execution time: 1.8538
INFO - 2020-04-21 04:44:37 --> Config Class Initialized
INFO - 2020-04-21 04:44:37 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:44:37 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:44:37 --> Utf8 Class Initialized
INFO - 2020-04-21 04:44:37 --> URI Class Initialized
INFO - 2020-04-21 04:44:37 --> Router Class Initialized
INFO - 2020-04-21 04:44:37 --> Output Class Initialized
INFO - 2020-04-21 04:44:37 --> Config Class Initialized
INFO - 2020-04-21 04:44:37 --> Hooks Class Initialized
INFO - 2020-04-21 04:44:37 --> Security Class Initialized
DEBUG - 2020-04-21 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-21 04:44:37 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:44:37 --> Utf8 Class Initialized
INFO - 2020-04-21 04:44:37 --> CSRF cookie sent
INFO - 2020-04-21 04:44:37 --> Input Class Initialized
INFO - 2020-04-21 04:44:37 --> URI Class Initialized
INFO - 2020-04-21 04:44:37 --> Language Class Initialized
INFO - 2020-04-21 04:44:37 --> Router Class Initialized
ERROR - 2020-04-21 04:44:37 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:44:37 --> Output Class Initialized
INFO - 2020-04-21 04:44:37 --> Security Class Initialized
DEBUG - 2020-04-21 04:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:44:37 --> CSRF cookie sent
INFO - 2020-04-21 04:44:37 --> Input Class Initialized
INFO - 2020-04-21 04:44:37 --> Language Class Initialized
ERROR - 2020-04-21 04:44:37 --> 404 Page Not Found: /index
INFO - 2020-04-21 04:44:42 --> Config Class Initialized
INFO - 2020-04-21 04:44:42 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:44:42 --> UTF-8 Support Enabled
INFO - 2020-04-21 04:44:42 --> Utf8 Class Initialized
INFO - 2020-04-21 04:44:42 --> URI Class Initialized
INFO - 2020-04-21 04:44:42 --> Router Class Initialized
INFO - 2020-04-21 04:44:42 --> Output Class Initialized
INFO - 2020-04-21 04:44:42 --> Security Class Initialized
DEBUG - 2020-04-21 04:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-21 04:44:42 --> CSRF cookie sent
INFO - 2020-04-21 04:44:42 --> Input Class Initialized
INFO - 2020-04-21 04:44:42 --> Language Class Initialized
ERROR - 2020-04-21 04:44:42 --> 404 Page Not Found: /index
