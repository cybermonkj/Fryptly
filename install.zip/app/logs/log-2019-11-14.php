<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-14 11:10:27 --> Config Class Initialized
INFO - 2019-11-14 11:10:27 --> Config Class Initialized
INFO - 2019-11-14 11:10:27 --> Hooks Class Initialized
INFO - 2019-11-14 11:10:27 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:10:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-14 11:10:28 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:10:28 --> Utf8 Class Initialized
INFO - 2019-11-14 11:10:28 --> Utf8 Class Initialized
INFO - 2019-11-14 11:10:28 --> URI Class Initialized
INFO - 2019-11-14 11:10:28 --> URI Class Initialized
DEBUG - 2019-11-14 11:10:28 --> No URI present. Default controller set.
DEBUG - 2019-11-14 11:10:28 --> No URI present. Default controller set.
INFO - 2019-11-14 11:10:28 --> Router Class Initialized
INFO - 2019-11-14 11:10:28 --> Router Class Initialized
INFO - 2019-11-14 11:10:28 --> Output Class Initialized
INFO - 2019-11-14 11:10:28 --> Output Class Initialized
INFO - 2019-11-14 11:10:28 --> Security Class Initialized
INFO - 2019-11-14 11:10:28 --> Security Class Initialized
DEBUG - 2019-11-14 11:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-14 11:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:10:28 --> CSRF cookie sent
INFO - 2019-11-14 11:10:28 --> CSRF cookie sent
INFO - 2019-11-14 11:10:28 --> Input Class Initialized
INFO - 2019-11-14 11:10:28 --> Input Class Initialized
INFO - 2019-11-14 11:10:28 --> Language Class Initialized
INFO - 2019-11-14 11:10:28 --> Language Class Initialized
INFO - 2019-11-14 11:10:28 --> Language Class Initialized
INFO - 2019-11-14 11:10:28 --> Language Class Initialized
INFO - 2019-11-14 11:10:28 --> Config Class Initialized
INFO - 2019-11-14 11:10:28 --> Config Class Initialized
INFO - 2019-11-14 11:10:28 --> Loader Class Initialized
INFO - 2019-11-14 11:10:28 --> Loader Class Initialized
INFO - 2019-11-14 11:10:28 --> Helper loaded: url_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: url_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: common_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: common_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: language_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: language_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: email_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: email_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:10:28 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:10:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:10:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:10:28 --> Parser Class Initialized
INFO - 2019-11-14 11:10:28 --> Parser Class Initialized
INFO - 2019-11-14 11:10:28 --> User Agent Class Initialized
INFO - 2019-11-14 11:10:28 --> User Agent Class Initialized
INFO - 2019-11-14 11:10:28 --> Model Class Initialized
INFO - 2019-11-14 11:10:28 --> Model Class Initialized
INFO - 2019-11-14 11:10:28 --> Database Driver Class Initialized
INFO - 2019-11-14 11:10:28 --> Database Driver Class Initialized
INFO - 2019-11-14 11:10:29 --> Model Class Initialized
INFO - 2019-11-14 11:10:29 --> Model Class Initialized
DEBUG - 2019-11-14 11:10:29 --> Template Class Initialized
DEBUG - 2019-11-14 11:10:29 --> Template Class Initialized
INFO - 2019-11-14 11:10:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:10:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:10:29 --> Pagination Class Initialized
INFO - 2019-11-14 11:10:29 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-14 11:10:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:10:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:10:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:10:29 --> Encryption Class Initialized
INFO - 2019-11-14 11:10:29 --> Encryption Class Initialized
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-14 11:10:30 --> Controller Class Initialized
INFO - 2019-11-14 11:10:30 --> Controller Class Initialized
DEBUG - 2019-11-14 11:10:30 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 11:10:30 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-14 11:10:30 --> Model Class Initialized
INFO - 2019-11-14 11:10:30 --> Model Class Initialized
INFO - 2019-11-14 11:10:30 --> Helper loaded: inflector_helper
INFO - 2019-11-14 11:10:30 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
DEBUG - 2019-11-14 11:10:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-14 11:10:30 --> Final output sent to browser
INFO - 2019-11-14 11:10:30 --> Final output sent to browser
DEBUG - 2019-11-14 11:10:30 --> Total execution time: 2.7854
DEBUG - 2019-11-14 11:10:30 --> Total execution time: 2.7182
INFO - 2019-11-14 11:10:51 --> Config Class Initialized
INFO - 2019-11-14 11:10:51 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:10:51 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:10:51 --> Utf8 Class Initialized
INFO - 2019-11-14 11:10:51 --> URI Class Initialized
INFO - 2019-11-14 11:10:51 --> Router Class Initialized
INFO - 2019-11-14 11:10:51 --> Output Class Initialized
INFO - 2019-11-14 11:10:51 --> Security Class Initialized
DEBUG - 2019-11-14 11:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:10:51 --> CSRF cookie sent
INFO - 2019-11-14 11:10:51 --> Input Class Initialized
INFO - 2019-11-14 11:10:51 --> Language Class Initialized
INFO - 2019-11-14 11:10:51 --> Language Class Initialized
INFO - 2019-11-14 11:10:51 --> Config Class Initialized
INFO - 2019-11-14 11:10:51 --> Loader Class Initialized
INFO - 2019-11-14 11:10:51 --> Helper loaded: url_helper
INFO - 2019-11-14 11:10:51 --> Helper loaded: common_helper
INFO - 2019-11-14 11:10:51 --> Helper loaded: language_helper
INFO - 2019-11-14 11:10:51 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:10:51 --> Helper loaded: email_helper
INFO - 2019-11-14 11:10:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:10:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:10:51 --> Parser Class Initialized
INFO - 2019-11-14 11:10:51 --> User Agent Class Initialized
INFO - 2019-11-14 11:10:51 --> Model Class Initialized
INFO - 2019-11-14 11:10:51 --> Database Driver Class Initialized
INFO - 2019-11-14 11:10:51 --> Model Class Initialized
DEBUG - 2019-11-14 11:10:51 --> Template Class Initialized
INFO - 2019-11-14 11:10:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:10:51 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:10:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:10:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:10:51 --> Encryption Class Initialized
INFO - 2019-11-14 11:10:51 --> Controller Class Initialized
DEBUG - 2019-11-14 11:10:51 --> package MX_Controller Initialized
DEBUG - 2019-11-14 11:10:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-14 11:10:51 --> Model Class Initialized
INFO - 2019-11-14 11:10:51 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:10:52 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:10:52 --> Model Class Initialized
DEBUG - 2019-11-14 11:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:10:52 --> Model Class Initialized
DEBUG - 2019-11-14 11:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-14 11:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-14 11:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:10:52 --> Final output sent to browser
DEBUG - 2019-11-14 11:10:52 --> Total execution time: 1.1973
ERROR - 2019-11-14 11:10:52 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-11-14 11:10:55 --> Config Class Initialized
INFO - 2019-11-14 11:10:55 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:10:55 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:10:55 --> Utf8 Class Initialized
INFO - 2019-11-14 11:10:55 --> URI Class Initialized
INFO - 2019-11-14 11:10:55 --> Router Class Initialized
INFO - 2019-11-14 11:10:55 --> Output Class Initialized
INFO - 2019-11-14 11:10:55 --> Security Class Initialized
DEBUG - 2019-11-14 11:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:10:55 --> CSRF cookie sent
INFO - 2019-11-14 11:10:55 --> CSRF token verified
INFO - 2019-11-14 11:10:56 --> Input Class Initialized
INFO - 2019-11-14 11:10:56 --> Language Class Initialized
INFO - 2019-11-14 11:10:56 --> Language Class Initialized
INFO - 2019-11-14 11:10:56 --> Config Class Initialized
INFO - 2019-11-14 11:10:56 --> Loader Class Initialized
INFO - 2019-11-14 11:10:56 --> Helper loaded: url_helper
INFO - 2019-11-14 11:10:56 --> Helper loaded: common_helper
INFO - 2019-11-14 11:10:56 --> Helper loaded: language_helper
INFO - 2019-11-14 11:10:56 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:10:56 --> Helper loaded: email_helper
INFO - 2019-11-14 11:10:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:10:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:10:56 --> Parser Class Initialized
INFO - 2019-11-14 11:10:56 --> User Agent Class Initialized
INFO - 2019-11-14 11:10:56 --> Model Class Initialized
INFO - 2019-11-14 11:10:56 --> Database Driver Class Initialized
INFO - 2019-11-14 11:10:56 --> Model Class Initialized
DEBUG - 2019-11-14 11:10:56 --> Template Class Initialized
ERROR - 2019-11-14 11:10:56 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::write) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\libraries\Session\drivers\Session_database_driver.php 49
INFO - 2019-11-14 11:11:08 --> Config Class Initialized
INFO - 2019-11-14 11:11:08 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:11:08 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:11:08 --> Utf8 Class Initialized
INFO - 2019-11-14 11:11:08 --> URI Class Initialized
INFO - 2019-11-14 11:11:08 --> Router Class Initialized
INFO - 2019-11-14 11:11:08 --> Output Class Initialized
INFO - 2019-11-14 11:11:08 --> Security Class Initialized
DEBUG - 2019-11-14 11:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:11:08 --> CSRF cookie sent
INFO - 2019-11-14 11:11:08 --> CSRF token verified
INFO - 2019-11-14 11:11:08 --> Input Class Initialized
INFO - 2019-11-14 11:11:08 --> Language Class Initialized
INFO - 2019-11-14 11:11:08 --> Language Class Initialized
INFO - 2019-11-14 11:11:08 --> Config Class Initialized
INFO - 2019-11-14 11:11:08 --> Loader Class Initialized
INFO - 2019-11-14 11:11:08 --> Helper loaded: url_helper
INFO - 2019-11-14 11:11:08 --> Helper loaded: common_helper
INFO - 2019-11-14 11:11:08 --> Helper loaded: language_helper
INFO - 2019-11-14 11:11:08 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:11:08 --> Helper loaded: email_helper
INFO - 2019-11-14 11:11:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:11:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:11:08 --> Parser Class Initialized
INFO - 2019-11-14 11:11:08 --> User Agent Class Initialized
INFO - 2019-11-14 11:11:08 --> Model Class Initialized
INFO - 2019-11-14 11:11:08 --> Database Driver Class Initialized
INFO - 2019-11-14 11:11:08 --> Model Class Initialized
DEBUG - 2019-11-14 11:11:08 --> Template Class Initialized
ERROR - 2019-11-14 11:11:08 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::write) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\libraries\Session\drivers\Session_database_driver.php 49
INFO - 2019-11-14 11:11:24 --> Config Class Initialized
INFO - 2019-11-14 11:11:24 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:11:24 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:11:24 --> Utf8 Class Initialized
INFO - 2019-11-14 11:11:24 --> URI Class Initialized
INFO - 2019-11-14 11:11:24 --> Router Class Initialized
INFO - 2019-11-14 11:11:24 --> Output Class Initialized
INFO - 2019-11-14 11:11:24 --> Security Class Initialized
DEBUG - 2019-11-14 11:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:11:24 --> CSRF cookie sent
INFO - 2019-11-14 11:11:24 --> Input Class Initialized
INFO - 2019-11-14 11:11:24 --> Language Class Initialized
INFO - 2019-11-14 11:11:24 --> Language Class Initialized
INFO - 2019-11-14 11:11:24 --> Config Class Initialized
INFO - 2019-11-14 11:11:24 --> Loader Class Initialized
INFO - 2019-11-14 11:11:24 --> Helper loaded: url_helper
INFO - 2019-11-14 11:11:24 --> Helper loaded: common_helper
INFO - 2019-11-14 11:11:24 --> Helper loaded: language_helper
INFO - 2019-11-14 11:11:24 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:11:24 --> Helper loaded: email_helper
INFO - 2019-11-14 11:11:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:11:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:11:24 --> Parser Class Initialized
INFO - 2019-11-14 11:11:24 --> User Agent Class Initialized
INFO - 2019-11-14 11:11:24 --> Model Class Initialized
INFO - 2019-11-14 11:11:24 --> Database Driver Class Initialized
INFO - 2019-11-14 11:11:24 --> Model Class Initialized
DEBUG - 2019-11-14 11:11:24 --> Template Class Initialized
ERROR - 2019-11-14 11:11:24 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::write) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\libraries\Session\drivers\Session_database_driver.php 49
INFO - 2019-11-14 11:12:28 --> Config Class Initialized
INFO - 2019-11-14 11:12:28 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:12:28 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:12:28 --> Utf8 Class Initialized
INFO - 2019-11-14 11:12:28 --> URI Class Initialized
INFO - 2019-11-14 11:12:28 --> Router Class Initialized
INFO - 2019-11-14 11:12:28 --> Output Class Initialized
INFO - 2019-11-14 11:12:28 --> Security Class Initialized
DEBUG - 2019-11-14 11:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:12:28 --> CSRF cookie sent
INFO - 2019-11-14 11:12:28 --> CSRF token verified
INFO - 2019-11-14 11:12:28 --> Input Class Initialized
INFO - 2019-11-14 11:12:28 --> Language Class Initialized
INFO - 2019-11-14 11:12:28 --> Language Class Initialized
INFO - 2019-11-14 11:12:28 --> Config Class Initialized
INFO - 2019-11-14 11:12:28 --> Loader Class Initialized
INFO - 2019-11-14 11:12:28 --> Helper loaded: url_helper
INFO - 2019-11-14 11:12:28 --> Helper loaded: common_helper
INFO - 2019-11-14 11:12:28 --> Helper loaded: language_helper
INFO - 2019-11-14 11:12:28 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:12:29 --> Helper loaded: email_helper
INFO - 2019-11-14 11:12:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:12:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:12:29 --> Parser Class Initialized
INFO - 2019-11-14 11:12:29 --> User Agent Class Initialized
INFO - 2019-11-14 11:12:29 --> Model Class Initialized
INFO - 2019-11-14 11:12:29 --> Database Driver Class Initialized
INFO - 2019-11-14 11:12:29 --> Model Class Initialized
DEBUG - 2019-11-14 11:12:29 --> Template Class Initialized
ERROR - 2019-11-14 11:12:29 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::write) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\libraries\Session\drivers\Session_database_driver.php 49
INFO - 2019-11-14 11:12:42 --> Config Class Initialized
INFO - 2019-11-14 11:12:42 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:12:42 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:12:42 --> Utf8 Class Initialized
INFO - 2019-11-14 11:12:42 --> URI Class Initialized
INFO - 2019-11-14 11:12:42 --> Router Class Initialized
INFO - 2019-11-14 11:12:42 --> Output Class Initialized
INFO - 2019-11-14 11:12:42 --> Security Class Initialized
DEBUG - 2019-11-14 11:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:12:42 --> CSRF cookie sent
INFO - 2019-11-14 11:12:42 --> CSRF token verified
INFO - 2019-11-14 11:12:42 --> Input Class Initialized
INFO - 2019-11-14 11:12:42 --> Language Class Initialized
INFO - 2019-11-14 11:12:42 --> Language Class Initialized
INFO - 2019-11-14 11:12:42 --> Config Class Initialized
INFO - 2019-11-14 11:12:43 --> Loader Class Initialized
INFO - 2019-11-14 11:12:43 --> Helper loaded: url_helper
INFO - 2019-11-14 11:12:43 --> Helper loaded: common_helper
INFO - 2019-11-14 11:12:43 --> Helper loaded: language_helper
INFO - 2019-11-14 11:12:43 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:12:43 --> Helper loaded: email_helper
INFO - 2019-11-14 11:12:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:12:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:12:43 --> Parser Class Initialized
INFO - 2019-11-14 11:12:43 --> User Agent Class Initialized
INFO - 2019-11-14 11:12:43 --> Model Class Initialized
INFO - 2019-11-14 11:12:43 --> Database Driver Class Initialized
INFO - 2019-11-14 11:12:43 --> Model Class Initialized
DEBUG - 2019-11-14 11:12:43 --> Template Class Initialized
ERROR - 2019-11-14 11:12:43 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::write) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\libraries\Session\drivers\Session_database_driver.php 49
INFO - 2019-11-14 11:13:09 --> Config Class Initialized
INFO - 2019-11-14 11:13:09 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:13:09 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:13:09 --> Utf8 Class Initialized
INFO - 2019-11-14 11:13:09 --> URI Class Initialized
INFO - 2019-11-14 11:13:09 --> Router Class Initialized
INFO - 2019-11-14 11:13:09 --> Output Class Initialized
INFO - 2019-11-14 11:13:09 --> Security Class Initialized
DEBUG - 2019-11-14 11:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:13:10 --> CSRF cookie sent
INFO - 2019-11-14 11:13:10 --> CSRF token verified
INFO - 2019-11-14 11:13:10 --> Input Class Initialized
INFO - 2019-11-14 11:13:10 --> Language Class Initialized
INFO - 2019-11-14 11:13:10 --> Language Class Initialized
INFO - 2019-11-14 11:13:10 --> Config Class Initialized
INFO - 2019-11-14 11:13:10 --> Loader Class Initialized
INFO - 2019-11-14 11:13:10 --> Helper loaded: url_helper
INFO - 2019-11-14 11:13:10 --> Helper loaded: common_helper
INFO - 2019-11-14 11:13:10 --> Helper loaded: language_helper
INFO - 2019-11-14 11:13:10 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:13:10 --> Helper loaded: email_helper
INFO - 2019-11-14 11:13:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:13:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:13:10 --> Parser Class Initialized
INFO - 2019-11-14 11:13:10 --> User Agent Class Initialized
INFO - 2019-11-14 11:13:10 --> Model Class Initialized
INFO - 2019-11-14 11:13:10 --> Database Driver Class Initialized
INFO - 2019-11-14 11:13:10 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:10 --> Template Class Initialized
INFO - 2019-11-14 11:13:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:13:10 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:13:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:13:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:13:10 --> Encryption Class Initialized
INFO - 2019-11-14 11:13:10 --> Controller Class Initialized
DEBUG - 2019-11-14 11:13:10 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:13:10 --> Model Class Initialized
INFO - 2019-11-14 11:13:10 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:13:10 --> Could not find the language line "dotpay"
ERROR - 2019-11-14 11:13:10 --> Could not find the language line "paystack"
ERROR - 2019-11-14 11:13:10 --> Could not find the language line "paytm"
DEBUG - 2019-11-14 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:13:10 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:13:10 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:13:10 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:13:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:13:10 --> Final output sent to browser
DEBUG - 2019-11-14 11:13:10 --> Total execution time: 0.7553
INFO - 2019-11-14 11:13:22 --> Config Class Initialized
INFO - 2019-11-14 11:13:22 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:13:22 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:13:22 --> Utf8 Class Initialized
INFO - 2019-11-14 11:13:22 --> URI Class Initialized
INFO - 2019-11-14 11:13:22 --> Router Class Initialized
INFO - 2019-11-14 11:13:22 --> Output Class Initialized
INFO - 2019-11-14 11:13:22 --> Security Class Initialized
DEBUG - 2019-11-14 11:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:13:22 --> CSRF cookie sent
INFO - 2019-11-14 11:13:22 --> CSRF token verified
INFO - 2019-11-14 11:13:22 --> Input Class Initialized
INFO - 2019-11-14 11:13:22 --> Language Class Initialized
INFO - 2019-11-14 11:13:22 --> Language Class Initialized
INFO - 2019-11-14 11:13:22 --> Config Class Initialized
INFO - 2019-11-14 11:13:22 --> Loader Class Initialized
INFO - 2019-11-14 11:13:22 --> Helper loaded: url_helper
INFO - 2019-11-14 11:13:22 --> Helper loaded: common_helper
INFO - 2019-11-14 11:13:22 --> Helper loaded: language_helper
INFO - 2019-11-14 11:13:22 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:13:22 --> Helper loaded: email_helper
INFO - 2019-11-14 11:13:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:13:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:13:22 --> Parser Class Initialized
INFO - 2019-11-14 11:13:22 --> User Agent Class Initialized
INFO - 2019-11-14 11:13:22 --> Model Class Initialized
INFO - 2019-11-14 11:13:22 --> Database Driver Class Initialized
INFO - 2019-11-14 11:13:22 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:22 --> Template Class Initialized
INFO - 2019-11-14 11:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:13:22 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:13:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:13:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:13:22 --> Encryption Class Initialized
INFO - 2019-11-14 11:13:22 --> Controller Class Initialized
DEBUG - 2019-11-14 11:13:22 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:13:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:13:22 --> Model Class Initialized
INFO - 2019-11-14 11:13:22 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:13:23 --> Could not find the language line "dotpay"
ERROR - 2019-11-14 11:13:23 --> Could not find the language line "paystack"
ERROR - 2019-11-14 11:13:23 --> Could not find the language line "paytm"
DEBUG - 2019-11-14 11:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:13:23 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:13:23 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:13:23 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:13:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:13:23 --> Final output sent to browser
DEBUG - 2019-11-14 11:13:23 --> Total execution time: 0.6951
INFO - 2019-11-14 11:13:37 --> Config Class Initialized
INFO - 2019-11-14 11:13:37 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:13:37 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:13:37 --> Utf8 Class Initialized
INFO - 2019-11-14 11:13:37 --> URI Class Initialized
INFO - 2019-11-14 11:13:37 --> Router Class Initialized
INFO - 2019-11-14 11:13:37 --> Output Class Initialized
INFO - 2019-11-14 11:13:37 --> Security Class Initialized
DEBUG - 2019-11-14 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:13:37 --> CSRF cookie sent
INFO - 2019-11-14 11:13:37 --> Input Class Initialized
INFO - 2019-11-14 11:13:37 --> Language Class Initialized
INFO - 2019-11-14 11:13:37 --> Language Class Initialized
INFO - 2019-11-14 11:13:37 --> Config Class Initialized
INFO - 2019-11-14 11:13:37 --> Loader Class Initialized
INFO - 2019-11-14 11:13:37 --> Helper loaded: url_helper
INFO - 2019-11-14 11:13:37 --> Helper loaded: common_helper
INFO - 2019-11-14 11:13:37 --> Helper loaded: language_helper
INFO - 2019-11-14 11:13:37 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:13:37 --> Helper loaded: email_helper
INFO - 2019-11-14 11:13:37 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:13:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:13:37 --> Parser Class Initialized
INFO - 2019-11-14 11:13:37 --> User Agent Class Initialized
INFO - 2019-11-14 11:13:37 --> Model Class Initialized
INFO - 2019-11-14 11:13:37 --> Database Driver Class Initialized
INFO - 2019-11-14 11:13:37 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:37 --> Template Class Initialized
INFO - 2019-11-14 11:13:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:13:37 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:13:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:13:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:13:37 --> Encryption Class Initialized
INFO - 2019-11-14 11:13:37 --> Controller Class Initialized
DEBUG - 2019-11-14 11:13:37 --> auth MX_Controller Initialized
DEBUG - 2019-11-14 11:13:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-14 11:13:37 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-14 11:13:37 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:13:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-14 11:13:37 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 11:13:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 11:13:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-14 11:13:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 11:13:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 11:13:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-14 11:13:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-14 11:13:37 --> Final output sent to browser
DEBUG - 2019-11-14 11:13:37 --> Total execution time: 0.6574
INFO - 2019-11-14 11:13:39 --> Config Class Initialized
INFO - 2019-11-14 11:13:39 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:13:39 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:13:39 --> Utf8 Class Initialized
INFO - 2019-11-14 11:13:39 --> URI Class Initialized
INFO - 2019-11-14 11:13:39 --> Router Class Initialized
INFO - 2019-11-14 11:13:39 --> Output Class Initialized
INFO - 2019-11-14 11:13:39 --> Security Class Initialized
DEBUG - 2019-11-14 11:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:13:39 --> CSRF cookie sent
INFO - 2019-11-14 11:13:39 --> CSRF token verified
INFO - 2019-11-14 11:13:39 --> Input Class Initialized
INFO - 2019-11-14 11:13:39 --> Language Class Initialized
INFO - 2019-11-14 11:13:39 --> Language Class Initialized
INFO - 2019-11-14 11:13:39 --> Config Class Initialized
INFO - 2019-11-14 11:13:39 --> Loader Class Initialized
INFO - 2019-11-14 11:13:39 --> Helper loaded: url_helper
INFO - 2019-11-14 11:13:39 --> Helper loaded: common_helper
INFO - 2019-11-14 11:13:39 --> Helper loaded: language_helper
INFO - 2019-11-14 11:13:39 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:13:39 --> Helper loaded: email_helper
INFO - 2019-11-14 11:13:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:13:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:13:39 --> Parser Class Initialized
INFO - 2019-11-14 11:13:39 --> User Agent Class Initialized
INFO - 2019-11-14 11:13:39 --> Model Class Initialized
INFO - 2019-11-14 11:13:39 --> Database Driver Class Initialized
INFO - 2019-11-14 11:13:39 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:39 --> Template Class Initialized
INFO - 2019-11-14 11:13:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:13:39 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:13:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:13:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:13:39 --> Encryption Class Initialized
INFO - 2019-11-14 11:13:39 --> Controller Class Initialized
DEBUG - 2019-11-14 11:13:39 --> auth MX_Controller Initialized
DEBUG - 2019-11-14 11:13:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-14 11:13:39 --> Model Class Initialized
INFO - 2019-11-14 11:13:44 --> Config Class Initialized
INFO - 2019-11-14 11:13:44 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:13:44 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:13:44 --> Utf8 Class Initialized
INFO - 2019-11-14 11:13:44 --> URI Class Initialized
INFO - 2019-11-14 11:13:45 --> Router Class Initialized
INFO - 2019-11-14 11:13:45 --> Output Class Initialized
INFO - 2019-11-14 11:13:45 --> Security Class Initialized
DEBUG - 2019-11-14 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:13:45 --> CSRF cookie sent
INFO - 2019-11-14 11:13:45 --> Input Class Initialized
INFO - 2019-11-14 11:13:45 --> Language Class Initialized
INFO - 2019-11-14 11:13:45 --> Language Class Initialized
INFO - 2019-11-14 11:13:45 --> Config Class Initialized
INFO - 2019-11-14 11:13:45 --> Loader Class Initialized
INFO - 2019-11-14 11:13:45 --> Helper loaded: url_helper
INFO - 2019-11-14 11:13:45 --> Helper loaded: common_helper
INFO - 2019-11-14 11:13:45 --> Helper loaded: language_helper
INFO - 2019-11-14 11:13:45 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:13:45 --> Helper loaded: email_helper
INFO - 2019-11-14 11:13:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:13:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:13:45 --> Parser Class Initialized
INFO - 2019-11-14 11:13:45 --> User Agent Class Initialized
INFO - 2019-11-14 11:13:45 --> Model Class Initialized
INFO - 2019-11-14 11:13:45 --> Database Driver Class Initialized
INFO - 2019-11-14 11:13:45 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:45 --> Template Class Initialized
INFO - 2019-11-14 11:13:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:13:45 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:13:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:13:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:13:45 --> Encryption Class Initialized
INFO - 2019-11-14 11:13:45 --> Controller Class Initialized
DEBUG - 2019-11-14 11:13:45 --> statistics MX_Controller Initialized
DEBUG - 2019-11-14 11:13:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-14 11:13:45 --> Model Class Initialized
ERROR - 2019-11-14 11:13:45 --> Could not find the language line "Pending"
ERROR - 2019-11-14 11:13:45 --> Could not find the language line "Pending"
INFO - 2019-11-14 11:13:45 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:13:45 --> Could not find the language line "total_orders"
ERROR - 2019-11-14 11:13:45 --> Could not find the language line "total_orders"
ERROR - 2019-11-14 11:13:45 --> Could not find the language line "Pending"
DEBUG - 2019-11-14 11:13:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-14 11:13:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:13:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:13:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:13:45 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:13:45 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 11:13:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 11:13:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 11:13:46 --> Final output sent to browser
DEBUG - 2019-11-14 11:13:46 --> Total execution time: 1.1559
INFO - 2019-11-14 11:13:53 --> Config Class Initialized
INFO - 2019-11-14 11:13:53 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:13:53 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:13:53 --> Utf8 Class Initialized
INFO - 2019-11-14 11:13:53 --> URI Class Initialized
INFO - 2019-11-14 11:13:53 --> Router Class Initialized
INFO - 2019-11-14 11:13:53 --> Output Class Initialized
INFO - 2019-11-14 11:13:53 --> Security Class Initialized
DEBUG - 2019-11-14 11:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:13:53 --> CSRF cookie sent
INFO - 2019-11-14 11:13:53 --> Input Class Initialized
INFO - 2019-11-14 11:13:53 --> Language Class Initialized
INFO - 2019-11-14 11:13:53 --> Language Class Initialized
INFO - 2019-11-14 11:13:53 --> Config Class Initialized
INFO - 2019-11-14 11:13:53 --> Loader Class Initialized
INFO - 2019-11-14 11:13:53 --> Helper loaded: url_helper
INFO - 2019-11-14 11:13:53 --> Helper loaded: common_helper
INFO - 2019-11-14 11:13:53 --> Helper loaded: language_helper
INFO - 2019-11-14 11:13:53 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:13:53 --> Helper loaded: email_helper
INFO - 2019-11-14 11:13:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:13:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:13:53 --> Parser Class Initialized
INFO - 2019-11-14 11:13:53 --> User Agent Class Initialized
INFO - 2019-11-14 11:13:53 --> Model Class Initialized
INFO - 2019-11-14 11:13:53 --> Database Driver Class Initialized
INFO - 2019-11-14 11:13:53 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:53 --> Template Class Initialized
INFO - 2019-11-14 11:13:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:13:53 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:13:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:13:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:13:53 --> Encryption Class Initialized
INFO - 2019-11-14 11:13:53 --> Controller Class Initialized
DEBUG - 2019-11-14 11:13:53 --> setting MX_Controller Initialized
DEBUG - 2019-11-14 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-14 11:13:53 --> Model Class Initialized
INFO - 2019-11-14 11:13:53 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-14 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-14 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-14 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:13:53 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:13:53 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:13:53 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 11:13:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 11:13:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 11:13:54 --> Final output sent to browser
DEBUG - 2019-11-14 11:13:54 --> Total execution time: 0.9336
INFO - 2019-11-14 11:13:57 --> Config Class Initialized
INFO - 2019-11-14 11:13:57 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:13:57 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:13:57 --> Utf8 Class Initialized
INFO - 2019-11-14 11:13:57 --> URI Class Initialized
INFO - 2019-11-14 11:13:57 --> Router Class Initialized
INFO - 2019-11-14 11:13:57 --> Output Class Initialized
INFO - 2019-11-14 11:13:57 --> Security Class Initialized
DEBUG - 2019-11-14 11:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:13:57 --> CSRF cookie sent
INFO - 2019-11-14 11:13:57 --> Input Class Initialized
INFO - 2019-11-14 11:13:57 --> Language Class Initialized
INFO - 2019-11-14 11:13:57 --> Language Class Initialized
INFO - 2019-11-14 11:13:57 --> Config Class Initialized
INFO - 2019-11-14 11:13:57 --> Loader Class Initialized
INFO - 2019-11-14 11:13:57 --> Helper loaded: url_helper
INFO - 2019-11-14 11:13:57 --> Helper loaded: common_helper
INFO - 2019-11-14 11:13:57 --> Helper loaded: language_helper
INFO - 2019-11-14 11:13:57 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:13:57 --> Helper loaded: email_helper
INFO - 2019-11-14 11:13:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:13:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:13:57 --> Parser Class Initialized
INFO - 2019-11-14 11:13:57 --> User Agent Class Initialized
INFO - 2019-11-14 11:13:57 --> Model Class Initialized
INFO - 2019-11-14 11:13:57 --> Database Driver Class Initialized
INFO - 2019-11-14 11:13:57 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:57 --> Template Class Initialized
INFO - 2019-11-14 11:13:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:13:57 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:13:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:13:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:13:57 --> Encryption Class Initialized
INFO - 2019-11-14 11:13:57 --> Controller Class Initialized
DEBUG - 2019-11-14 11:13:57 --> setting MX_Controller Initialized
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-14 11:13:57 --> Model Class Initialized
INFO - 2019-11-14 11:13:57 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-14 11:13:57 --> Could not find the language line "Shopier"
ERROR - 2019-11-14 11:13:57 --> Could not find the language line "shopier_api_key"
ERROR - 2019-11-14 11:13:57 --> Could not find the language line "shopier_api_secret"
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/shopier.php
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:13:57 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:13:57 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:13:57 --> Model Class Initialized
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 11:13:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 11:13:57 --> Final output sent to browser
DEBUG - 2019-11-14 11:13:57 --> Total execution time: 0.8292
INFO - 2019-11-14 11:14:16 --> Config Class Initialized
INFO - 2019-11-14 11:14:16 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:14:16 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:14:16 --> Utf8 Class Initialized
INFO - 2019-11-14 11:14:16 --> URI Class Initialized
INFO - 2019-11-14 11:14:16 --> Router Class Initialized
INFO - 2019-11-14 11:14:17 --> Output Class Initialized
INFO - 2019-11-14 11:14:17 --> Security Class Initialized
DEBUG - 2019-11-14 11:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:14:17 --> CSRF cookie sent
INFO - 2019-11-14 11:14:17 --> CSRF token verified
INFO - 2019-11-14 11:14:17 --> Input Class Initialized
INFO - 2019-11-14 11:14:17 --> Language Class Initialized
INFO - 2019-11-14 11:14:17 --> Language Class Initialized
INFO - 2019-11-14 11:14:17 --> Config Class Initialized
INFO - 2019-11-14 11:14:17 --> Loader Class Initialized
INFO - 2019-11-14 11:14:17 --> Helper loaded: url_helper
INFO - 2019-11-14 11:14:17 --> Helper loaded: common_helper
INFO - 2019-11-14 11:14:17 --> Helper loaded: language_helper
INFO - 2019-11-14 11:14:17 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:14:17 --> Helper loaded: email_helper
INFO - 2019-11-14 11:14:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:14:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:14:17 --> Parser Class Initialized
INFO - 2019-11-14 11:14:17 --> User Agent Class Initialized
INFO - 2019-11-14 11:14:17 --> Model Class Initialized
INFO - 2019-11-14 11:14:17 --> Database Driver Class Initialized
INFO - 2019-11-14 11:14:17 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:17 --> Template Class Initialized
INFO - 2019-11-14 11:14:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:14:17 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:14:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:14:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:14:17 --> Encryption Class Initialized
INFO - 2019-11-14 11:14:17 --> Controller Class Initialized
DEBUG - 2019-11-14 11:14:17 --> setting MX_Controller Initialized
DEBUG - 2019-11-14 11:14:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-14 11:14:17 --> Model Class Initialized
INFO - 2019-11-14 11:14:21 --> Config Class Initialized
INFO - 2019-11-14 11:14:21 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:14:21 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:14:21 --> Utf8 Class Initialized
INFO - 2019-11-14 11:14:21 --> URI Class Initialized
INFO - 2019-11-14 11:14:22 --> Router Class Initialized
INFO - 2019-11-14 11:14:22 --> Output Class Initialized
INFO - 2019-11-14 11:14:22 --> Security Class Initialized
DEBUG - 2019-11-14 11:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:14:22 --> CSRF cookie sent
INFO - 2019-11-14 11:14:22 --> Input Class Initialized
INFO - 2019-11-14 11:14:22 --> Language Class Initialized
INFO - 2019-11-14 11:14:22 --> Language Class Initialized
INFO - 2019-11-14 11:14:22 --> Config Class Initialized
INFO - 2019-11-14 11:14:22 --> Loader Class Initialized
INFO - 2019-11-14 11:14:22 --> Helper loaded: url_helper
INFO - 2019-11-14 11:14:22 --> Helper loaded: common_helper
INFO - 2019-11-14 11:14:22 --> Helper loaded: language_helper
INFO - 2019-11-14 11:14:22 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:14:22 --> Helper loaded: email_helper
INFO - 2019-11-14 11:14:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:14:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:14:22 --> Parser Class Initialized
INFO - 2019-11-14 11:14:22 --> User Agent Class Initialized
INFO - 2019-11-14 11:14:22 --> Model Class Initialized
INFO - 2019-11-14 11:14:22 --> Database Driver Class Initialized
INFO - 2019-11-14 11:14:22 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:22 --> Template Class Initialized
INFO - 2019-11-14 11:14:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:14:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:14:22 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:14:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:14:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:14:22 --> Encryption Class Initialized
INFO - 2019-11-14 11:14:22 --> Controller Class Initialized
DEBUG - 2019-11-14 11:14:22 --> setting MX_Controller Initialized
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-14 11:14:22 --> Model Class Initialized
INFO - 2019-11-14 11:14:22 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-14 11:14:22 --> Could not find the language line "Shopier"
ERROR - 2019-11-14 11:14:22 --> Could not find the language line "shopier_api_key"
ERROR - 2019-11-14 11:14:22 --> Could not find the language line "shopier_api_secret"
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/shopier.php
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:14:22 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:14:22 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:14:22 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 11:14:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 11:14:22 --> Final output sent to browser
DEBUG - 2019-11-14 11:14:22 --> Total execution time: 0.8565
INFO - 2019-11-14 11:14:38 --> Config Class Initialized
INFO - 2019-11-14 11:14:38 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:14:38 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:14:38 --> Utf8 Class Initialized
INFO - 2019-11-14 11:14:38 --> URI Class Initialized
INFO - 2019-11-14 11:14:38 --> Router Class Initialized
INFO - 2019-11-14 11:14:38 --> Output Class Initialized
INFO - 2019-11-14 11:14:38 --> Security Class Initialized
DEBUG - 2019-11-14 11:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:14:38 --> CSRF cookie sent
INFO - 2019-11-14 11:14:38 --> Input Class Initialized
INFO - 2019-11-14 11:14:38 --> Language Class Initialized
INFO - 2019-11-14 11:14:38 --> Language Class Initialized
INFO - 2019-11-14 11:14:38 --> Config Class Initialized
INFO - 2019-11-14 11:14:38 --> Loader Class Initialized
INFO - 2019-11-14 11:14:38 --> Helper loaded: url_helper
INFO - 2019-11-14 11:14:38 --> Helper loaded: common_helper
INFO - 2019-11-14 11:14:38 --> Helper loaded: language_helper
INFO - 2019-11-14 11:14:38 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:14:38 --> Helper loaded: email_helper
INFO - 2019-11-14 11:14:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:14:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:14:38 --> Parser Class Initialized
INFO - 2019-11-14 11:14:38 --> User Agent Class Initialized
INFO - 2019-11-14 11:14:38 --> Model Class Initialized
INFO - 2019-11-14 11:14:38 --> Database Driver Class Initialized
INFO - 2019-11-14 11:14:38 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:38 --> Template Class Initialized
INFO - 2019-11-14 11:14:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:14:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:14:38 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:14:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:14:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:14:38 --> Encryption Class Initialized
INFO - 2019-11-14 11:14:38 --> Controller Class Initialized
DEBUG - 2019-11-14 11:14:38 --> language MX_Controller Initialized
DEBUG - 2019-11-14 11:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-14 11:14:38 --> Model Class Initialized
INFO - 2019-11-14 11:14:38 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-11-14 11:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:14:38 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:14:38 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:14:38 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 11:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 11:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 11:14:38 --> Final output sent to browser
DEBUG - 2019-11-14 11:14:38 --> Total execution time: 0.8288
INFO - 2019-11-14 11:14:41 --> Config Class Initialized
INFO - 2019-11-14 11:14:41 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:14:41 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:14:41 --> Utf8 Class Initialized
INFO - 2019-11-14 11:14:41 --> URI Class Initialized
INFO - 2019-11-14 11:14:41 --> Router Class Initialized
INFO - 2019-11-14 11:14:41 --> Output Class Initialized
INFO - 2019-11-14 11:14:41 --> Security Class Initialized
DEBUG - 2019-11-14 11:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:14:41 --> CSRF cookie sent
INFO - 2019-11-14 11:14:41 --> Input Class Initialized
INFO - 2019-11-14 11:14:41 --> Language Class Initialized
INFO - 2019-11-14 11:14:41 --> Language Class Initialized
INFO - 2019-11-14 11:14:41 --> Config Class Initialized
INFO - 2019-11-14 11:14:41 --> Loader Class Initialized
INFO - 2019-11-14 11:14:41 --> Helper loaded: url_helper
INFO - 2019-11-14 11:14:41 --> Helper loaded: common_helper
INFO - 2019-11-14 11:14:41 --> Helper loaded: language_helper
INFO - 2019-11-14 11:14:41 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:14:41 --> Helper loaded: email_helper
INFO - 2019-11-14 11:14:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:14:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:14:41 --> Parser Class Initialized
INFO - 2019-11-14 11:14:41 --> User Agent Class Initialized
INFO - 2019-11-14 11:14:41 --> Model Class Initialized
INFO - 2019-11-14 11:14:41 --> Database Driver Class Initialized
INFO - 2019-11-14 11:14:41 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:41 --> Template Class Initialized
INFO - 2019-11-14 11:14:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:14:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:14:41 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:14:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:14:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:14:41 --> Encryption Class Initialized
INFO - 2019-11-14 11:14:41 --> Controller Class Initialized
DEBUG - 2019-11-14 11:14:41 --> language MX_Controller Initialized
DEBUG - 2019-11-14 11:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-14 11:14:41 --> Model Class Initialized
INFO - 2019-11-14 11:14:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:14:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2019-11-14 11:14:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:14:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:14:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:14:45 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:14:45 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 11:14:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 11:14:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 11:14:45 --> Final output sent to browser
DEBUG - 2019-11-14 11:14:45 --> Total execution time: 4.6464
INFO - 2019-11-14 11:14:51 --> Config Class Initialized
INFO - 2019-11-14 11:14:51 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:14:51 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:14:51 --> Utf8 Class Initialized
INFO - 2019-11-14 11:14:51 --> URI Class Initialized
INFO - 2019-11-14 11:14:51 --> Router Class Initialized
INFO - 2019-11-14 11:14:51 --> Output Class Initialized
INFO - 2019-11-14 11:14:51 --> Security Class Initialized
DEBUG - 2019-11-14 11:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:14:51 --> CSRF cookie sent
INFO - 2019-11-14 11:14:51 --> CSRF token verified
INFO - 2019-11-14 11:14:51 --> Input Class Initialized
INFO - 2019-11-14 11:14:51 --> Language Class Initialized
INFO - 2019-11-14 11:14:51 --> Language Class Initialized
INFO - 2019-11-14 11:14:51 --> Config Class Initialized
INFO - 2019-11-14 11:14:51 --> Loader Class Initialized
INFO - 2019-11-14 11:14:51 --> Helper loaded: url_helper
INFO - 2019-11-14 11:14:51 --> Helper loaded: common_helper
INFO - 2019-11-14 11:14:51 --> Helper loaded: language_helper
INFO - 2019-11-14 11:14:51 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:14:51 --> Helper loaded: email_helper
INFO - 2019-11-14 11:14:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:14:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:14:51 --> Parser Class Initialized
INFO - 2019-11-14 11:14:51 --> User Agent Class Initialized
INFO - 2019-11-14 11:14:51 --> Model Class Initialized
INFO - 2019-11-14 11:14:51 --> Database Driver Class Initialized
INFO - 2019-11-14 11:14:51 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:51 --> Template Class Initialized
INFO - 2019-11-14 11:14:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:14:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:14:51 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:14:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:14:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:14:51 --> Encryption Class Initialized
INFO - 2019-11-14 11:14:51 --> Controller Class Initialized
DEBUG - 2019-11-14 11:14:51 --> language MX_Controller Initialized
DEBUG - 2019-11-14 11:14:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-14 11:14:51 --> Model Class Initialized
INFO - 2019-11-14 11:14:58 --> Config Class Initialized
INFO - 2019-11-14 11:14:58 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:14:58 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:14:58 --> Utf8 Class Initialized
INFO - 2019-11-14 11:14:58 --> URI Class Initialized
INFO - 2019-11-14 11:14:58 --> Router Class Initialized
INFO - 2019-11-14 11:14:58 --> Output Class Initialized
INFO - 2019-11-14 11:14:58 --> Security Class Initialized
DEBUG - 2019-11-14 11:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:14:58 --> CSRF cookie sent
INFO - 2019-11-14 11:14:58 --> Input Class Initialized
INFO - 2019-11-14 11:14:58 --> Language Class Initialized
INFO - 2019-11-14 11:14:58 --> Language Class Initialized
INFO - 2019-11-14 11:14:58 --> Config Class Initialized
INFO - 2019-11-14 11:14:58 --> Loader Class Initialized
INFO - 2019-11-14 11:14:58 --> Helper loaded: url_helper
INFO - 2019-11-14 11:14:58 --> Helper loaded: common_helper
INFO - 2019-11-14 11:14:58 --> Helper loaded: language_helper
INFO - 2019-11-14 11:14:58 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:14:59 --> Helper loaded: email_helper
INFO - 2019-11-14 11:14:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:14:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:14:59 --> Parser Class Initialized
INFO - 2019-11-14 11:14:59 --> User Agent Class Initialized
INFO - 2019-11-14 11:14:59 --> Model Class Initialized
INFO - 2019-11-14 11:14:59 --> Database Driver Class Initialized
INFO - 2019-11-14 11:14:59 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:59 --> Template Class Initialized
INFO - 2019-11-14 11:14:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:14:59 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:14:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:14:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:14:59 --> Encryption Class Initialized
INFO - 2019-11-14 11:14:59 --> Controller Class Initialized
DEBUG - 2019-11-14 11:14:59 --> language MX_Controller Initialized
DEBUG - 2019-11-14 11:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-14 11:14:59 --> Model Class Initialized
INFO - 2019-11-14 11:14:59 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-11-14 11:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:14:59 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:14:59 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:14:59 --> Model Class Initialized
DEBUG - 2019-11-14 11:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 11:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 11:14:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 11:14:59 --> Final output sent to browser
DEBUG - 2019-11-14 11:14:59 --> Total execution time: 0.6305
INFO - 2019-11-14 11:15:03 --> Config Class Initialized
INFO - 2019-11-14 11:15:03 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:15:03 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:15:03 --> Utf8 Class Initialized
INFO - 2019-11-14 11:15:03 --> URI Class Initialized
INFO - 2019-11-14 11:15:03 --> Router Class Initialized
INFO - 2019-11-14 11:15:03 --> Output Class Initialized
INFO - 2019-11-14 11:15:03 --> Security Class Initialized
DEBUG - 2019-11-14 11:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:15:03 --> CSRF cookie sent
INFO - 2019-11-14 11:15:03 --> CSRF token verified
INFO - 2019-11-14 11:15:03 --> Input Class Initialized
INFO - 2019-11-14 11:15:03 --> Language Class Initialized
INFO - 2019-11-14 11:15:03 --> Language Class Initialized
INFO - 2019-11-14 11:15:03 --> Config Class Initialized
INFO - 2019-11-14 11:15:03 --> Loader Class Initialized
INFO - 2019-11-14 11:15:03 --> Helper loaded: url_helper
INFO - 2019-11-14 11:15:03 --> Helper loaded: common_helper
INFO - 2019-11-14 11:15:03 --> Helper loaded: language_helper
INFO - 2019-11-14 11:15:03 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:15:03 --> Helper loaded: email_helper
INFO - 2019-11-14 11:15:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:15:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:15:03 --> Parser Class Initialized
INFO - 2019-11-14 11:15:03 --> User Agent Class Initialized
INFO - 2019-11-14 11:15:03 --> Model Class Initialized
INFO - 2019-11-14 11:15:03 --> Database Driver Class Initialized
INFO - 2019-11-14 11:15:03 --> Model Class Initialized
DEBUG - 2019-11-14 11:15:03 --> Template Class Initialized
INFO - 2019-11-14 11:15:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:15:03 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:15:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:15:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:15:03 --> Encryption Class Initialized
INFO - 2019-11-14 11:15:03 --> Controller Class Initialized
DEBUG - 2019-11-14 11:15:03 --> language MX_Controller Initialized
DEBUG - 2019-11-14 11:15:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-14 11:15:03 --> Model Class Initialized
INFO - 2019-11-14 11:15:04 --> Config Class Initialized
INFO - 2019-11-14 11:15:04 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:15:04 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:15:05 --> Utf8 Class Initialized
INFO - 2019-11-14 11:15:05 --> URI Class Initialized
INFO - 2019-11-14 11:15:05 --> Router Class Initialized
INFO - 2019-11-14 11:15:05 --> Output Class Initialized
INFO - 2019-11-14 11:15:05 --> Security Class Initialized
DEBUG - 2019-11-14 11:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:15:05 --> CSRF cookie sent
INFO - 2019-11-14 11:15:05 --> Input Class Initialized
INFO - 2019-11-14 11:15:05 --> Language Class Initialized
INFO - 2019-11-14 11:15:05 --> Language Class Initialized
INFO - 2019-11-14 11:15:05 --> Config Class Initialized
INFO - 2019-11-14 11:15:05 --> Loader Class Initialized
INFO - 2019-11-14 11:15:05 --> Helper loaded: url_helper
INFO - 2019-11-14 11:15:05 --> Helper loaded: common_helper
INFO - 2019-11-14 11:15:05 --> Helper loaded: language_helper
INFO - 2019-11-14 11:15:05 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:15:05 --> Helper loaded: email_helper
INFO - 2019-11-14 11:15:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:15:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:15:05 --> Parser Class Initialized
INFO - 2019-11-14 11:15:05 --> User Agent Class Initialized
INFO - 2019-11-14 11:15:05 --> Model Class Initialized
INFO - 2019-11-14 11:15:05 --> Database Driver Class Initialized
INFO - 2019-11-14 11:15:05 --> Model Class Initialized
DEBUG - 2019-11-14 11:15:05 --> Template Class Initialized
INFO - 2019-11-14 11:15:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:15:05 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:15:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:15:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:15:05 --> Encryption Class Initialized
INFO - 2019-11-14 11:15:05 --> Controller Class Initialized
DEBUG - 2019-11-14 11:15:05 --> language MX_Controller Initialized
DEBUG - 2019-11-14 11:15:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-14 11:15:05 --> Model Class Initialized
INFO - 2019-11-14 11:15:05 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:15:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-11-14 11:15:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:15:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:15:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:15:05 --> Model Class Initialized
DEBUG - 2019-11-14 11:15:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:15:05 --> Model Class Initialized
DEBUG - 2019-11-14 11:15:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 11:15:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 11:15:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 11:15:05 --> Final output sent to browser
DEBUG - 2019-11-14 11:15:05 --> Total execution time: 0.6861
INFO - 2019-11-14 11:15:07 --> Config Class Initialized
INFO - 2019-11-14 11:15:07 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:15:07 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:15:07 --> Utf8 Class Initialized
INFO - 2019-11-14 11:15:07 --> URI Class Initialized
INFO - 2019-11-14 11:15:07 --> Router Class Initialized
INFO - 2019-11-14 11:15:07 --> Output Class Initialized
INFO - 2019-11-14 11:15:07 --> Security Class Initialized
DEBUG - 2019-11-14 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:15:07 --> CSRF cookie sent
INFO - 2019-11-14 11:15:07 --> CSRF token verified
INFO - 2019-11-14 11:15:07 --> Input Class Initialized
INFO - 2019-11-14 11:15:07 --> Language Class Initialized
INFO - 2019-11-14 11:15:07 --> Language Class Initialized
INFO - 2019-11-14 11:15:07 --> Config Class Initialized
INFO - 2019-11-14 11:15:07 --> Loader Class Initialized
INFO - 2019-11-14 11:15:07 --> Helper loaded: url_helper
INFO - 2019-11-14 11:15:07 --> Helper loaded: common_helper
INFO - 2019-11-14 11:15:07 --> Helper loaded: language_helper
INFO - 2019-11-14 11:15:07 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:15:07 --> Helper loaded: email_helper
INFO - 2019-11-14 11:15:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:15:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:15:07 --> Parser Class Initialized
INFO - 2019-11-14 11:15:07 --> User Agent Class Initialized
INFO - 2019-11-14 11:15:07 --> Model Class Initialized
INFO - 2019-11-14 11:15:07 --> Database Driver Class Initialized
INFO - 2019-11-14 11:15:07 --> Model Class Initialized
DEBUG - 2019-11-14 11:15:07 --> Template Class Initialized
INFO - 2019-11-14 11:15:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:15:07 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:15:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:15:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:15:07 --> Encryption Class Initialized
INFO - 2019-11-14 11:15:07 --> Controller Class Initialized
DEBUG - 2019-11-14 11:15:07 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:15:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:15:07 --> Model Class Initialized
INFO - 2019-11-14 11:15:07 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:15:07 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 11:15:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:15:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:15:07 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:15:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:15:07 --> Model Class Initialized
DEBUG - 2019-11-14 11:15:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:15:07 --> Model Class Initialized
DEBUG - 2019-11-14 11:15:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:15:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:15:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:15:07 --> Final output sent to browser
DEBUG - 2019-11-14 11:15:07 --> Total execution time: 0.6968
INFO - 2019-11-14 11:15:15 --> Config Class Initialized
INFO - 2019-11-14 11:15:15 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:15:15 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:15:15 --> Utf8 Class Initialized
INFO - 2019-11-14 11:15:15 --> URI Class Initialized
INFO - 2019-11-14 11:15:15 --> Router Class Initialized
INFO - 2019-11-14 11:15:15 --> Output Class Initialized
INFO - 2019-11-14 11:15:15 --> Security Class Initialized
DEBUG - 2019-11-14 11:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:15:15 --> CSRF cookie sent
INFO - 2019-11-14 11:15:15 --> CSRF token verified
INFO - 2019-11-14 11:15:15 --> Input Class Initialized
INFO - 2019-11-14 11:15:15 --> Language Class Initialized
INFO - 2019-11-14 11:15:15 --> Language Class Initialized
INFO - 2019-11-14 11:15:15 --> Config Class Initialized
INFO - 2019-11-14 11:15:15 --> Loader Class Initialized
INFO - 2019-11-14 11:15:15 --> Helper loaded: url_helper
INFO - 2019-11-14 11:15:15 --> Helper loaded: common_helper
INFO - 2019-11-14 11:15:15 --> Helper loaded: language_helper
INFO - 2019-11-14 11:15:15 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:15:15 --> Helper loaded: email_helper
INFO - 2019-11-14 11:15:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:15:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:15:15 --> Parser Class Initialized
INFO - 2019-11-14 11:15:15 --> User Agent Class Initialized
INFO - 2019-11-14 11:15:15 --> Model Class Initialized
INFO - 2019-11-14 11:15:15 --> Database Driver Class Initialized
INFO - 2019-11-14 11:15:15 --> Model Class Initialized
DEBUG - 2019-11-14 11:15:15 --> Template Class Initialized
INFO - 2019-11-14 11:15:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:15:15 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:15:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:15:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:15:15 --> Encryption Class Initialized
INFO - 2019-11-14 11:15:15 --> Controller Class Initialized
DEBUG - 2019-11-14 11:15:15 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:15:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:15:15 --> Model Class Initialized
DEBUG - 2019-11-14 11:15:15 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 11:15:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
ERROR - 2019-11-14 11:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 113
ERROR - 2019-11-14 11:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 114
ERROR - 2019-11-14 11:15:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 115
ERROR - 2019-11-14 11:15:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 117
ERROR - 2019-11-14 11:15:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 118
ERROR - 2019-11-14 11:15:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 119
ERROR - 2019-11-14 11:15:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 120
INFO - 2019-11-14 11:37:52 --> Config Class Initialized
INFO - 2019-11-14 11:37:52 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:37:52 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:37:52 --> Utf8 Class Initialized
INFO - 2019-11-14 11:37:52 --> URI Class Initialized
INFO - 2019-11-14 11:37:52 --> Router Class Initialized
INFO - 2019-11-14 11:37:52 --> Output Class Initialized
INFO - 2019-11-14 11:37:52 --> Security Class Initialized
DEBUG - 2019-11-14 11:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:37:52 --> CSRF cookie sent
INFO - 2019-11-14 11:37:52 --> CSRF token verified
INFO - 2019-11-14 11:37:52 --> Input Class Initialized
INFO - 2019-11-14 11:37:52 --> Language Class Initialized
INFO - 2019-11-14 11:37:52 --> Language Class Initialized
INFO - 2019-11-14 11:37:52 --> Config Class Initialized
INFO - 2019-11-14 11:37:52 --> Loader Class Initialized
INFO - 2019-11-14 11:37:52 --> Helper loaded: url_helper
INFO - 2019-11-14 11:37:52 --> Helper loaded: common_helper
INFO - 2019-11-14 11:37:52 --> Helper loaded: language_helper
INFO - 2019-11-14 11:37:52 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:37:52 --> Helper loaded: email_helper
INFO - 2019-11-14 11:37:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:37:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:37:52 --> Parser Class Initialized
INFO - 2019-11-14 11:37:52 --> User Agent Class Initialized
INFO - 2019-11-14 11:37:52 --> Model Class Initialized
INFO - 2019-11-14 11:37:52 --> Database Driver Class Initialized
INFO - 2019-11-14 11:37:52 --> Model Class Initialized
DEBUG - 2019-11-14 11:37:52 --> Template Class Initialized
INFO - 2019-11-14 11:37:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:37:52 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:37:52 --> Encryption Class Initialized
INFO - 2019-11-14 11:37:52 --> Controller Class Initialized
DEBUG - 2019-11-14 11:37:52 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:37:52 --> Model Class Initialized
INFO - 2019-11-14 11:37:52 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:37:52 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 11:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:37:52 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:37:52 --> Model Class Initialized
DEBUG - 2019-11-14 11:37:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:37:52 --> Model Class Initialized
DEBUG - 2019-11-14 11:37:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:37:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:37:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:37:53 --> Final output sent to browser
DEBUG - 2019-11-14 11:37:53 --> Total execution time: 0.6921
INFO - 2019-11-14 11:40:16 --> Config Class Initialized
INFO - 2019-11-14 11:40:16 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:40:16 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:40:16 --> Utf8 Class Initialized
INFO - 2019-11-14 11:40:16 --> URI Class Initialized
INFO - 2019-11-14 11:40:16 --> Router Class Initialized
INFO - 2019-11-14 11:40:16 --> Output Class Initialized
INFO - 2019-11-14 11:40:16 --> Security Class Initialized
DEBUG - 2019-11-14 11:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:40:16 --> CSRF cookie sent
INFO - 2019-11-14 11:40:16 --> CSRF token verified
INFO - 2019-11-14 11:40:16 --> Input Class Initialized
INFO - 2019-11-14 11:40:16 --> Language Class Initialized
INFO - 2019-11-14 11:40:16 --> Language Class Initialized
INFO - 2019-11-14 11:40:16 --> Config Class Initialized
INFO - 2019-11-14 11:40:16 --> Loader Class Initialized
INFO - 2019-11-14 11:40:16 --> Helper loaded: url_helper
INFO - 2019-11-14 11:40:16 --> Helper loaded: common_helper
INFO - 2019-11-14 11:40:16 --> Helper loaded: language_helper
INFO - 2019-11-14 11:40:16 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:40:16 --> Helper loaded: email_helper
INFO - 2019-11-14 11:40:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:40:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:40:16 --> Parser Class Initialized
INFO - 2019-11-14 11:40:16 --> User Agent Class Initialized
INFO - 2019-11-14 11:40:16 --> Model Class Initialized
INFO - 2019-11-14 11:40:16 --> Database Driver Class Initialized
INFO - 2019-11-14 11:40:16 --> Model Class Initialized
DEBUG - 2019-11-14 11:40:16 --> Template Class Initialized
INFO - 2019-11-14 11:40:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:40:16 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:40:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:40:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:40:16 --> Encryption Class Initialized
INFO - 2019-11-14 11:40:16 --> Controller Class Initialized
DEBUG - 2019-11-14 11:40:16 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:40:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:40:16 --> Model Class Initialized
ERROR - 2019-11-14 11:40:16 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 102
INFO - 2019-11-14 11:40:38 --> Config Class Initialized
INFO - 2019-11-14 11:40:38 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:40:38 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:40:38 --> Utf8 Class Initialized
INFO - 2019-11-14 11:40:38 --> URI Class Initialized
INFO - 2019-11-14 11:40:38 --> Router Class Initialized
INFO - 2019-11-14 11:40:38 --> Output Class Initialized
INFO - 2019-11-14 11:40:38 --> Security Class Initialized
DEBUG - 2019-11-14 11:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:40:38 --> CSRF cookie sent
INFO - 2019-11-14 11:40:38 --> CSRF token verified
INFO - 2019-11-14 11:40:38 --> Input Class Initialized
INFO - 2019-11-14 11:40:38 --> Language Class Initialized
INFO - 2019-11-14 11:40:38 --> Language Class Initialized
INFO - 2019-11-14 11:40:38 --> Config Class Initialized
INFO - 2019-11-14 11:40:38 --> Loader Class Initialized
INFO - 2019-11-14 11:40:38 --> Helper loaded: url_helper
INFO - 2019-11-14 11:40:38 --> Helper loaded: common_helper
INFO - 2019-11-14 11:40:38 --> Helper loaded: language_helper
INFO - 2019-11-14 11:40:38 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:40:38 --> Helper loaded: email_helper
INFO - 2019-11-14 11:40:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:40:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:40:38 --> Parser Class Initialized
INFO - 2019-11-14 11:40:38 --> User Agent Class Initialized
INFO - 2019-11-14 11:40:38 --> Model Class Initialized
INFO - 2019-11-14 11:40:38 --> Database Driver Class Initialized
INFO - 2019-11-14 11:40:38 --> Model Class Initialized
DEBUG - 2019-11-14 11:40:38 --> Template Class Initialized
INFO - 2019-11-14 11:40:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:40:38 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:40:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:40:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:40:38 --> Encryption Class Initialized
INFO - 2019-11-14 11:40:38 --> Controller Class Initialized
DEBUG - 2019-11-14 11:40:38 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:40:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:40:39 --> Model Class Initialized
INFO - 2019-11-14 11:40:39 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:40:39 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 11:40:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:40:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:40:39 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:40:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:40:39 --> Model Class Initialized
DEBUG - 2019-11-14 11:40:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:40:39 --> Model Class Initialized
DEBUG - 2019-11-14 11:40:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:40:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:40:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:40:39 --> Final output sent to browser
DEBUG - 2019-11-14 11:40:39 --> Total execution time: 0.7836
INFO - 2019-11-14 11:40:45 --> Config Class Initialized
INFO - 2019-11-14 11:40:45 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:40:45 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:40:45 --> Utf8 Class Initialized
INFO - 2019-11-14 11:40:45 --> URI Class Initialized
INFO - 2019-11-14 11:40:45 --> Router Class Initialized
INFO - 2019-11-14 11:40:45 --> Output Class Initialized
INFO - 2019-11-14 11:40:45 --> Security Class Initialized
DEBUG - 2019-11-14 11:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:40:45 --> CSRF cookie sent
INFO - 2019-11-14 11:40:45 --> CSRF token verified
INFO - 2019-11-14 11:40:45 --> Input Class Initialized
INFO - 2019-11-14 11:40:45 --> Language Class Initialized
INFO - 2019-11-14 11:40:45 --> Language Class Initialized
INFO - 2019-11-14 11:40:45 --> Config Class Initialized
INFO - 2019-11-14 11:40:45 --> Loader Class Initialized
INFO - 2019-11-14 11:40:45 --> Helper loaded: url_helper
INFO - 2019-11-14 11:40:45 --> Helper loaded: common_helper
INFO - 2019-11-14 11:40:45 --> Helper loaded: language_helper
INFO - 2019-11-14 11:40:45 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:40:45 --> Helper loaded: email_helper
INFO - 2019-11-14 11:40:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:40:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:40:45 --> Parser Class Initialized
INFO - 2019-11-14 11:40:45 --> User Agent Class Initialized
INFO - 2019-11-14 11:40:45 --> Model Class Initialized
INFO - 2019-11-14 11:40:45 --> Database Driver Class Initialized
INFO - 2019-11-14 11:40:45 --> Model Class Initialized
DEBUG - 2019-11-14 11:40:45 --> Template Class Initialized
INFO - 2019-11-14 11:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:40:45 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:40:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:40:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:40:45 --> Encryption Class Initialized
INFO - 2019-11-14 11:40:45 --> Controller Class Initialized
DEBUG - 2019-11-14 11:40:45 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:40:45 --> Model Class Initialized
DEBUG - 2019-11-14 11:40:45 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 11:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 11:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 11:40:45 --> Final output sent to browser
DEBUG - 2019-11-14 11:40:45 --> Total execution time: 0.5083
INFO - 2019-11-14 11:40:51 --> Config Class Initialized
INFO - 2019-11-14 11:40:51 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:40:51 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:40:51 --> Utf8 Class Initialized
INFO - 2019-11-14 11:40:51 --> URI Class Initialized
INFO - 2019-11-14 11:40:51 --> Router Class Initialized
INFO - 2019-11-14 11:40:51 --> Output Class Initialized
INFO - 2019-11-14 11:40:51 --> Security Class Initialized
DEBUG - 2019-11-14 11:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:40:51 --> CSRF cookie sent
INFO - 2019-11-14 11:40:51 --> CSRF token verified
INFO - 2019-11-14 11:40:51 --> Input Class Initialized
INFO - 2019-11-14 11:40:51 --> Language Class Initialized
INFO - 2019-11-14 11:40:51 --> Language Class Initialized
INFO - 2019-11-14 11:40:51 --> Config Class Initialized
INFO - 2019-11-14 11:40:51 --> Loader Class Initialized
INFO - 2019-11-14 11:40:51 --> Helper loaded: url_helper
INFO - 2019-11-14 11:40:51 --> Helper loaded: common_helper
INFO - 2019-11-14 11:40:51 --> Helper loaded: language_helper
INFO - 2019-11-14 11:40:51 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:40:51 --> Helper loaded: email_helper
INFO - 2019-11-14 11:40:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:40:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:40:51 --> Parser Class Initialized
INFO - 2019-11-14 11:40:51 --> User Agent Class Initialized
INFO - 2019-11-14 11:40:51 --> Model Class Initialized
INFO - 2019-11-14 11:40:51 --> Database Driver Class Initialized
INFO - 2019-11-14 11:40:51 --> Model Class Initialized
DEBUG - 2019-11-14 11:40:51 --> Template Class Initialized
INFO - 2019-11-14 11:40:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:40:51 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:40:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:40:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:40:51 --> Encryption Class Initialized
INFO - 2019-11-14 11:40:51 --> Controller Class Initialized
DEBUG - 2019-11-14 11:40:51 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:40:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:40:51 --> Model Class Initialized
INFO - 2019-11-14 11:41:44 --> Config Class Initialized
INFO - 2019-11-14 11:41:44 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:41:44 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:41:44 --> Utf8 Class Initialized
INFO - 2019-11-14 11:41:44 --> URI Class Initialized
INFO - 2019-11-14 11:41:44 --> Router Class Initialized
INFO - 2019-11-14 11:41:44 --> Output Class Initialized
INFO - 2019-11-14 11:41:44 --> Security Class Initialized
DEBUG - 2019-11-14 11:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:41:44 --> CSRF cookie sent
INFO - 2019-11-14 11:41:44 --> CSRF token verified
INFO - 2019-11-14 11:41:44 --> Input Class Initialized
INFO - 2019-11-14 11:41:44 --> Language Class Initialized
INFO - 2019-11-14 11:41:44 --> Language Class Initialized
INFO - 2019-11-14 11:41:44 --> Config Class Initialized
INFO - 2019-11-14 11:41:44 --> Loader Class Initialized
INFO - 2019-11-14 11:41:44 --> Helper loaded: url_helper
INFO - 2019-11-14 11:41:44 --> Helper loaded: common_helper
INFO - 2019-11-14 11:41:44 --> Helper loaded: language_helper
INFO - 2019-11-14 11:41:44 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:41:44 --> Helper loaded: email_helper
INFO - 2019-11-14 11:41:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:41:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:41:44 --> Parser Class Initialized
INFO - 2019-11-14 11:41:44 --> User Agent Class Initialized
INFO - 2019-11-14 11:41:44 --> Model Class Initialized
INFO - 2019-11-14 11:41:44 --> Database Driver Class Initialized
INFO - 2019-11-14 11:41:44 --> Model Class Initialized
DEBUG - 2019-11-14 11:41:44 --> Template Class Initialized
INFO - 2019-11-14 11:41:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:41:45 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:41:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:41:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:41:45 --> Encryption Class Initialized
INFO - 2019-11-14 11:41:45 --> Controller Class Initialized
DEBUG - 2019-11-14 11:41:45 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:41:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:41:45 --> Model Class Initialized
INFO - 2019-11-14 11:42:35 --> Config Class Initialized
INFO - 2019-11-14 11:42:35 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:42:35 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:42:35 --> Utf8 Class Initialized
INFO - 2019-11-14 11:42:35 --> URI Class Initialized
INFO - 2019-11-14 11:42:35 --> Router Class Initialized
INFO - 2019-11-14 11:42:35 --> Output Class Initialized
INFO - 2019-11-14 11:42:35 --> Security Class Initialized
DEBUG - 2019-11-14 11:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:42:36 --> CSRF cookie sent
INFO - 2019-11-14 11:42:36 --> CSRF token verified
INFO - 2019-11-14 11:42:36 --> Input Class Initialized
INFO - 2019-11-14 11:42:36 --> Language Class Initialized
INFO - 2019-11-14 11:42:36 --> Language Class Initialized
INFO - 2019-11-14 11:42:36 --> Config Class Initialized
INFO - 2019-11-14 11:42:36 --> Loader Class Initialized
INFO - 2019-11-14 11:42:36 --> Helper loaded: url_helper
INFO - 2019-11-14 11:42:36 --> Helper loaded: common_helper
INFO - 2019-11-14 11:42:36 --> Helper loaded: language_helper
INFO - 2019-11-14 11:42:36 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:42:36 --> Helper loaded: email_helper
INFO - 2019-11-14 11:42:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:42:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:42:36 --> Parser Class Initialized
INFO - 2019-11-14 11:42:36 --> User Agent Class Initialized
INFO - 2019-11-14 11:42:36 --> Model Class Initialized
INFO - 2019-11-14 11:42:36 --> Database Driver Class Initialized
INFO - 2019-11-14 11:42:36 --> Model Class Initialized
DEBUG - 2019-11-14 11:42:36 --> Template Class Initialized
INFO - 2019-11-14 11:42:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:42:36 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:42:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:42:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:42:36 --> Encryption Class Initialized
INFO - 2019-11-14 11:42:36 --> Controller Class Initialized
DEBUG - 2019-11-14 11:42:36 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:42:36 --> Model Class Initialized
INFO - 2019-11-14 11:42:36 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:42:36 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 11:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:42:36 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:42:36 --> Model Class Initialized
DEBUG - 2019-11-14 11:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:42:36 --> Model Class Initialized
DEBUG - 2019-11-14 11:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:42:36 --> Final output sent to browser
DEBUG - 2019-11-14 11:42:36 --> Total execution time: 0.6804
INFO - 2019-11-14 11:43:01 --> Config Class Initialized
INFO - 2019-11-14 11:43:01 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:43:01 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:43:01 --> Utf8 Class Initialized
INFO - 2019-11-14 11:43:01 --> URI Class Initialized
INFO - 2019-11-14 11:43:01 --> Router Class Initialized
INFO - 2019-11-14 11:43:01 --> Output Class Initialized
INFO - 2019-11-14 11:43:01 --> Security Class Initialized
DEBUG - 2019-11-14 11:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:43:01 --> CSRF cookie sent
INFO - 2019-11-14 11:43:01 --> CSRF token verified
INFO - 2019-11-14 11:43:01 --> Input Class Initialized
INFO - 2019-11-14 11:43:01 --> Language Class Initialized
INFO - 2019-11-14 11:43:01 --> Language Class Initialized
INFO - 2019-11-14 11:43:01 --> Config Class Initialized
INFO - 2019-11-14 11:43:01 --> Loader Class Initialized
INFO - 2019-11-14 11:43:01 --> Helper loaded: url_helper
INFO - 2019-11-14 11:43:01 --> Helper loaded: common_helper
INFO - 2019-11-14 11:43:01 --> Helper loaded: language_helper
INFO - 2019-11-14 11:43:01 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:43:01 --> Helper loaded: email_helper
INFO - 2019-11-14 11:43:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:43:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:43:01 --> Parser Class Initialized
INFO - 2019-11-14 11:43:01 --> User Agent Class Initialized
INFO - 2019-11-14 11:43:01 --> Model Class Initialized
INFO - 2019-11-14 11:43:01 --> Database Driver Class Initialized
INFO - 2019-11-14 11:43:02 --> Model Class Initialized
DEBUG - 2019-11-14 11:43:02 --> Template Class Initialized
INFO - 2019-11-14 11:43:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:43:02 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:43:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:43:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:43:02 --> Encryption Class Initialized
INFO - 2019-11-14 11:43:02 --> Controller Class Initialized
DEBUG - 2019-11-14 11:43:02 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:43:02 --> Model Class Initialized
INFO - 2019-11-14 11:43:02 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:43:02 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 11:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:43:02 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:43:02 --> Model Class Initialized
DEBUG - 2019-11-14 11:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:43:02 --> Model Class Initialized
DEBUG - 2019-11-14 11:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:43:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:43:02 --> Final output sent to browser
DEBUG - 2019-11-14 11:43:02 --> Total execution time: 0.7032
INFO - 2019-11-14 11:43:09 --> Config Class Initialized
INFO - 2019-11-14 11:43:09 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:43:09 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:43:09 --> Utf8 Class Initialized
INFO - 2019-11-14 11:43:09 --> URI Class Initialized
INFO - 2019-11-14 11:43:09 --> Router Class Initialized
INFO - 2019-11-14 11:43:09 --> Output Class Initialized
INFO - 2019-11-14 11:43:09 --> Security Class Initialized
DEBUG - 2019-11-14 11:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:43:09 --> CSRF cookie sent
INFO - 2019-11-14 11:43:09 --> CSRF token verified
INFO - 2019-11-14 11:43:09 --> Input Class Initialized
INFO - 2019-11-14 11:43:09 --> Language Class Initialized
INFO - 2019-11-14 11:43:09 --> Language Class Initialized
INFO - 2019-11-14 11:43:09 --> Config Class Initialized
INFO - 2019-11-14 11:43:09 --> Loader Class Initialized
INFO - 2019-11-14 11:43:09 --> Helper loaded: url_helper
INFO - 2019-11-14 11:43:09 --> Helper loaded: common_helper
INFO - 2019-11-14 11:43:09 --> Helper loaded: language_helper
INFO - 2019-11-14 11:43:09 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:43:09 --> Helper loaded: email_helper
INFO - 2019-11-14 11:43:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:43:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:43:09 --> Parser Class Initialized
INFO - 2019-11-14 11:43:09 --> User Agent Class Initialized
INFO - 2019-11-14 11:43:09 --> Model Class Initialized
INFO - 2019-11-14 11:43:09 --> Database Driver Class Initialized
INFO - 2019-11-14 11:43:09 --> Model Class Initialized
DEBUG - 2019-11-14 11:43:09 --> Template Class Initialized
INFO - 2019-11-14 11:43:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:43:09 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:43:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:43:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:43:09 --> Encryption Class Initialized
INFO - 2019-11-14 11:43:09 --> Controller Class Initialized
DEBUG - 2019-11-14 11:43:09 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:43:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:43:09 --> Model Class Initialized
DEBUG - 2019-11-14 11:43:09 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 11:43:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 11:43:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 11:43:09 --> Final output sent to browser
DEBUG - 2019-11-14 11:43:09 --> Total execution time: 0.5203
INFO - 2019-11-14 11:43:13 --> Config Class Initialized
INFO - 2019-11-14 11:43:13 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:43:13 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:43:13 --> Utf8 Class Initialized
INFO - 2019-11-14 11:43:13 --> URI Class Initialized
INFO - 2019-11-14 11:43:13 --> Router Class Initialized
INFO - 2019-11-14 11:43:13 --> Output Class Initialized
INFO - 2019-11-14 11:43:13 --> Security Class Initialized
DEBUG - 2019-11-14 11:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:43:13 --> CSRF cookie sent
INFO - 2019-11-14 11:43:13 --> CSRF token verified
INFO - 2019-11-14 11:43:13 --> Input Class Initialized
INFO - 2019-11-14 11:43:13 --> Language Class Initialized
INFO - 2019-11-14 11:43:13 --> Language Class Initialized
INFO - 2019-11-14 11:43:13 --> Config Class Initialized
INFO - 2019-11-14 11:43:13 --> Loader Class Initialized
INFO - 2019-11-14 11:43:13 --> Helper loaded: url_helper
INFO - 2019-11-14 11:43:13 --> Helper loaded: common_helper
INFO - 2019-11-14 11:43:13 --> Helper loaded: language_helper
INFO - 2019-11-14 11:43:13 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:43:13 --> Helper loaded: email_helper
INFO - 2019-11-14 11:43:13 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:43:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:43:13 --> Parser Class Initialized
INFO - 2019-11-14 11:43:13 --> User Agent Class Initialized
INFO - 2019-11-14 11:43:13 --> Model Class Initialized
INFO - 2019-11-14 11:43:13 --> Database Driver Class Initialized
INFO - 2019-11-14 11:43:13 --> Model Class Initialized
DEBUG - 2019-11-14 11:43:13 --> Template Class Initialized
INFO - 2019-11-14 11:43:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:43:13 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:43:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:43:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:43:13 --> Encryption Class Initialized
INFO - 2019-11-14 11:43:13 --> Controller Class Initialized
DEBUG - 2019-11-14 11:43:13 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:43:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:43:13 --> Model Class Initialized
INFO - 2019-11-14 11:47:29 --> Config Class Initialized
INFO - 2019-11-14 11:47:29 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:47:29 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:47:29 --> Utf8 Class Initialized
INFO - 2019-11-14 11:47:29 --> URI Class Initialized
INFO - 2019-11-14 11:47:29 --> Router Class Initialized
INFO - 2019-11-14 11:47:29 --> Output Class Initialized
INFO - 2019-11-14 11:47:29 --> Security Class Initialized
DEBUG - 2019-11-14 11:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:47:29 --> CSRF cookie sent
INFO - 2019-11-14 11:47:29 --> CSRF token verified
INFO - 2019-11-14 11:47:29 --> Input Class Initialized
INFO - 2019-11-14 11:47:29 --> Language Class Initialized
INFO - 2019-11-14 11:47:29 --> Language Class Initialized
INFO - 2019-11-14 11:47:29 --> Config Class Initialized
INFO - 2019-11-14 11:47:29 --> Loader Class Initialized
INFO - 2019-11-14 11:47:29 --> Helper loaded: url_helper
INFO - 2019-11-14 11:47:29 --> Helper loaded: common_helper
INFO - 2019-11-14 11:47:29 --> Helper loaded: language_helper
INFO - 2019-11-14 11:47:29 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:47:29 --> Helper loaded: email_helper
INFO - 2019-11-14 11:47:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:47:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:47:29 --> Parser Class Initialized
INFO - 2019-11-14 11:47:29 --> User Agent Class Initialized
INFO - 2019-11-14 11:47:29 --> Model Class Initialized
INFO - 2019-11-14 11:47:29 --> Database Driver Class Initialized
INFO - 2019-11-14 11:47:29 --> Model Class Initialized
DEBUG - 2019-11-14 11:47:29 --> Template Class Initialized
INFO - 2019-11-14 11:47:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:47:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:47:29 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:47:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:47:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:47:29 --> Encryption Class Initialized
INFO - 2019-11-14 11:47:29 --> Controller Class Initialized
DEBUG - 2019-11-14 11:47:29 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:47:29 --> Model Class Initialized
INFO - 2019-11-14 11:47:29 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:47:29 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 11:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:47:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:47:29 --> Model Class Initialized
DEBUG - 2019-11-14 11:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:47:29 --> Model Class Initialized
DEBUG - 2019-11-14 11:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:47:29 --> Final output sent to browser
DEBUG - 2019-11-14 11:47:29 --> Total execution time: 0.6703
INFO - 2019-11-14 11:47:39 --> Config Class Initialized
INFO - 2019-11-14 11:47:39 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:47:39 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:47:39 --> Utf8 Class Initialized
INFO - 2019-11-14 11:47:39 --> URI Class Initialized
INFO - 2019-11-14 11:47:39 --> Router Class Initialized
INFO - 2019-11-14 11:47:39 --> Output Class Initialized
INFO - 2019-11-14 11:47:39 --> Security Class Initialized
DEBUG - 2019-11-14 11:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:47:39 --> CSRF cookie sent
INFO - 2019-11-14 11:47:39 --> CSRF token verified
INFO - 2019-11-14 11:47:39 --> Input Class Initialized
INFO - 2019-11-14 11:47:39 --> Language Class Initialized
INFO - 2019-11-14 11:47:39 --> Language Class Initialized
INFO - 2019-11-14 11:47:39 --> Config Class Initialized
INFO - 2019-11-14 11:47:39 --> Loader Class Initialized
INFO - 2019-11-14 11:47:39 --> Helper loaded: url_helper
INFO - 2019-11-14 11:47:39 --> Helper loaded: common_helper
INFO - 2019-11-14 11:47:39 --> Helper loaded: language_helper
INFO - 2019-11-14 11:47:39 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:47:39 --> Helper loaded: email_helper
INFO - 2019-11-14 11:47:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:47:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:47:39 --> Parser Class Initialized
INFO - 2019-11-14 11:47:39 --> User Agent Class Initialized
INFO - 2019-11-14 11:47:39 --> Model Class Initialized
INFO - 2019-11-14 11:47:39 --> Database Driver Class Initialized
INFO - 2019-11-14 11:47:39 --> Model Class Initialized
DEBUG - 2019-11-14 11:47:39 --> Template Class Initialized
INFO - 2019-11-14 11:47:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:47:40 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:47:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:47:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:47:40 --> Encryption Class Initialized
INFO - 2019-11-14 11:47:40 --> Controller Class Initialized
DEBUG - 2019-11-14 11:47:40 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:47:40 --> Model Class Initialized
INFO - 2019-11-14 11:47:40 --> Config Class Initialized
INFO - 2019-11-14 11:47:40 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:47:40 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:47:40 --> Utf8 Class Initialized
INFO - 2019-11-14 11:47:40 --> URI Class Initialized
DEBUG - 2019-11-14 11:47:40 --> No URI present. Default controller set.
INFO - 2019-11-14 11:47:40 --> Router Class Initialized
INFO - 2019-11-14 11:47:40 --> Output Class Initialized
INFO - 2019-11-14 11:47:40 --> Security Class Initialized
DEBUG - 2019-11-14 11:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:47:40 --> CSRF cookie sent
INFO - 2019-11-14 11:47:40 --> Input Class Initialized
INFO - 2019-11-14 11:47:40 --> Language Class Initialized
INFO - 2019-11-14 11:47:40 --> Language Class Initialized
INFO - 2019-11-14 11:47:40 --> Config Class Initialized
INFO - 2019-11-14 11:47:40 --> Loader Class Initialized
INFO - 2019-11-14 11:47:40 --> Helper loaded: url_helper
INFO - 2019-11-14 11:47:40 --> Helper loaded: common_helper
INFO - 2019-11-14 11:47:40 --> Helper loaded: language_helper
INFO - 2019-11-14 11:47:40 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:47:40 --> Helper loaded: email_helper
INFO - 2019-11-14 11:47:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:47:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:47:40 --> Parser Class Initialized
INFO - 2019-11-14 11:47:40 --> User Agent Class Initialized
INFO - 2019-11-14 11:47:40 --> Model Class Initialized
INFO - 2019-11-14 11:47:40 --> Database Driver Class Initialized
INFO - 2019-11-14 11:47:40 --> Model Class Initialized
DEBUG - 2019-11-14 11:47:40 --> Template Class Initialized
INFO - 2019-11-14 11:47:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:47:40 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:47:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:47:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:47:40 --> Encryption Class Initialized
DEBUG - 2019-11-14 11:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 11:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-14 11:47:40 --> Controller Class Initialized
DEBUG - 2019-11-14 11:47:40 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 11:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 11:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-14 11:47:40 --> Model Class Initialized
INFO - 2019-11-14 11:47:40 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 11:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 11:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-14 11:47:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-14 11:47:40 --> Final output sent to browser
DEBUG - 2019-11-14 11:47:40 --> Total execution time: 0.6229
INFO - 2019-11-14 11:48:07 --> Config Class Initialized
INFO - 2019-11-14 11:48:07 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:48:07 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:48:07 --> Utf8 Class Initialized
INFO - 2019-11-14 11:48:07 --> URI Class Initialized
INFO - 2019-11-14 11:48:07 --> Router Class Initialized
INFO - 2019-11-14 11:48:07 --> Output Class Initialized
INFO - 2019-11-14 11:48:07 --> Security Class Initialized
DEBUG - 2019-11-14 11:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:48:07 --> CSRF cookie sent
INFO - 2019-11-14 11:48:07 --> CSRF token verified
INFO - 2019-11-14 11:48:07 --> Input Class Initialized
INFO - 2019-11-14 11:48:07 --> Language Class Initialized
INFO - 2019-11-14 11:48:07 --> Language Class Initialized
INFO - 2019-11-14 11:48:07 --> Config Class Initialized
INFO - 2019-11-14 11:48:07 --> Loader Class Initialized
INFO - 2019-11-14 11:48:07 --> Helper loaded: url_helper
INFO - 2019-11-14 11:48:07 --> Helper loaded: common_helper
INFO - 2019-11-14 11:48:07 --> Helper loaded: language_helper
INFO - 2019-11-14 11:48:07 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:48:07 --> Helper loaded: email_helper
INFO - 2019-11-14 11:48:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:48:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:48:07 --> Parser Class Initialized
INFO - 2019-11-14 11:48:07 --> User Agent Class Initialized
INFO - 2019-11-14 11:48:07 --> Model Class Initialized
INFO - 2019-11-14 11:48:07 --> Database Driver Class Initialized
INFO - 2019-11-14 11:48:07 --> Model Class Initialized
DEBUG - 2019-11-14 11:48:07 --> Template Class Initialized
INFO - 2019-11-14 11:48:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:48:07 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:48:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:48:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:48:07 --> Encryption Class Initialized
INFO - 2019-11-14 11:48:07 --> Controller Class Initialized
DEBUG - 2019-11-14 11:48:07 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:48:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:48:07 --> Model Class Initialized
INFO - 2019-11-14 11:48:07 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:48:07 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 11:48:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:48:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:48:08 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:48:08 --> Model Class Initialized
DEBUG - 2019-11-14 11:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:48:08 --> Model Class Initialized
DEBUG - 2019-11-14 11:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:48:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:48:08 --> Final output sent to browser
DEBUG - 2019-11-14 11:48:08 --> Total execution time: 0.8314
INFO - 2019-11-14 11:48:39 --> Config Class Initialized
INFO - 2019-11-14 11:48:39 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:48:39 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:48:39 --> Utf8 Class Initialized
INFO - 2019-11-14 11:48:39 --> URI Class Initialized
INFO - 2019-11-14 11:48:39 --> Router Class Initialized
INFO - 2019-11-14 11:48:39 --> Output Class Initialized
INFO - 2019-11-14 11:48:39 --> Security Class Initialized
DEBUG - 2019-11-14 11:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:48:39 --> CSRF cookie sent
INFO - 2019-11-14 11:48:39 --> CSRF token verified
INFO - 2019-11-14 11:48:39 --> Input Class Initialized
INFO - 2019-11-14 11:48:39 --> Language Class Initialized
INFO - 2019-11-14 11:48:39 --> Language Class Initialized
INFO - 2019-11-14 11:48:39 --> Config Class Initialized
INFO - 2019-11-14 11:48:39 --> Loader Class Initialized
INFO - 2019-11-14 11:48:39 --> Helper loaded: url_helper
INFO - 2019-11-14 11:48:39 --> Helper loaded: common_helper
INFO - 2019-11-14 11:48:39 --> Helper loaded: language_helper
INFO - 2019-11-14 11:48:39 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:48:39 --> Helper loaded: email_helper
INFO - 2019-11-14 11:48:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:48:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:48:39 --> Parser Class Initialized
INFO - 2019-11-14 11:48:39 --> User Agent Class Initialized
INFO - 2019-11-14 11:48:39 --> Model Class Initialized
INFO - 2019-11-14 11:48:39 --> Database Driver Class Initialized
INFO - 2019-11-14 11:48:39 --> Model Class Initialized
DEBUG - 2019-11-14 11:48:39 --> Template Class Initialized
INFO - 2019-11-14 11:48:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:48:39 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:48:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:48:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:48:39 --> Encryption Class Initialized
INFO - 2019-11-14 11:48:39 --> Controller Class Initialized
DEBUG - 2019-11-14 11:48:39 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:48:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:48:39 --> Model Class Initialized
INFO - 2019-11-14 11:48:39 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:48:39 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 11:48:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:48:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:48:39 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:48:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:48:39 --> Model Class Initialized
DEBUG - 2019-11-14 11:48:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:48:39 --> Model Class Initialized
DEBUG - 2019-11-14 11:48:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:48:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:48:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:48:39 --> Final output sent to browser
DEBUG - 2019-11-14 11:48:39 --> Total execution time: 0.6938
INFO - 2019-11-14 11:48:49 --> Config Class Initialized
INFO - 2019-11-14 11:48:49 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:48:49 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:48:49 --> Utf8 Class Initialized
INFO - 2019-11-14 11:48:49 --> URI Class Initialized
INFO - 2019-11-14 11:48:49 --> Router Class Initialized
INFO - 2019-11-14 11:48:49 --> Output Class Initialized
INFO - 2019-11-14 11:48:49 --> Security Class Initialized
DEBUG - 2019-11-14 11:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:48:49 --> CSRF cookie sent
INFO - 2019-11-14 11:48:49 --> CSRF token verified
INFO - 2019-11-14 11:48:49 --> Input Class Initialized
INFO - 2019-11-14 11:48:49 --> Language Class Initialized
INFO - 2019-11-14 11:48:49 --> Language Class Initialized
INFO - 2019-11-14 11:48:49 --> Config Class Initialized
INFO - 2019-11-14 11:48:49 --> Loader Class Initialized
INFO - 2019-11-14 11:48:49 --> Helper loaded: url_helper
INFO - 2019-11-14 11:48:49 --> Helper loaded: common_helper
INFO - 2019-11-14 11:48:49 --> Helper loaded: language_helper
INFO - 2019-11-14 11:48:49 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:48:49 --> Helper loaded: email_helper
INFO - 2019-11-14 11:48:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:48:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:48:49 --> Parser Class Initialized
INFO - 2019-11-14 11:48:49 --> User Agent Class Initialized
INFO - 2019-11-14 11:48:49 --> Model Class Initialized
INFO - 2019-11-14 11:48:49 --> Database Driver Class Initialized
INFO - 2019-11-14 11:48:49 --> Model Class Initialized
DEBUG - 2019-11-14 11:48:49 --> Template Class Initialized
INFO - 2019-11-14 11:48:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:48:50 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:48:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:48:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:48:50 --> Encryption Class Initialized
INFO - 2019-11-14 11:48:50 --> Controller Class Initialized
DEBUG - 2019-11-14 11:48:50 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:48:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:48:50 --> Model Class Initialized
DEBUG - 2019-11-14 11:48:50 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 11:48:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 11:48:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 11:48:50 --> Final output sent to browser
DEBUG - 2019-11-14 11:48:50 --> Total execution time: 0.5646
INFO - 2019-11-14 11:49:07 --> Config Class Initialized
INFO - 2019-11-14 11:49:07 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:49:07 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:49:07 --> Utf8 Class Initialized
INFO - 2019-11-14 11:49:07 --> URI Class Initialized
INFO - 2019-11-14 11:49:07 --> Router Class Initialized
INFO - 2019-11-14 11:49:07 --> Output Class Initialized
INFO - 2019-11-14 11:49:07 --> Security Class Initialized
DEBUG - 2019-11-14 11:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:49:07 --> CSRF cookie sent
INFO - 2019-11-14 11:49:07 --> CSRF token verified
INFO - 2019-11-14 11:49:07 --> Input Class Initialized
INFO - 2019-11-14 11:49:07 --> Language Class Initialized
INFO - 2019-11-14 11:49:07 --> Language Class Initialized
INFO - 2019-11-14 11:49:07 --> Config Class Initialized
INFO - 2019-11-14 11:49:08 --> Loader Class Initialized
INFO - 2019-11-14 11:49:08 --> Helper loaded: url_helper
INFO - 2019-11-14 11:49:08 --> Helper loaded: common_helper
INFO - 2019-11-14 11:49:08 --> Helper loaded: language_helper
INFO - 2019-11-14 11:49:08 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:49:08 --> Helper loaded: email_helper
INFO - 2019-11-14 11:49:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:49:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:49:08 --> Parser Class Initialized
INFO - 2019-11-14 11:49:08 --> User Agent Class Initialized
INFO - 2019-11-14 11:49:08 --> Model Class Initialized
INFO - 2019-11-14 11:49:08 --> Database Driver Class Initialized
INFO - 2019-11-14 11:49:08 --> Model Class Initialized
DEBUG - 2019-11-14 11:49:08 --> Template Class Initialized
INFO - 2019-11-14 11:49:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:49:08 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:49:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:49:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:49:08 --> Encryption Class Initialized
INFO - 2019-11-14 11:49:08 --> Controller Class Initialized
DEBUG - 2019-11-14 11:49:08 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:49:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:49:08 --> Model Class Initialized
INFO - 2019-11-14 11:49:08 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 11:49:08 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 11:49:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 11:49:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 11:49:08 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 11:49:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 11:49:08 --> Model Class Initialized
DEBUG - 2019-11-14 11:49:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 11:49:08 --> Model Class Initialized
DEBUG - 2019-11-14 11:49:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 11:49:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 11:49:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 11:49:08 --> Final output sent to browser
DEBUG - 2019-11-14 11:49:08 --> Total execution time: 0.7172
INFO - 2019-11-14 11:49:13 --> Config Class Initialized
INFO - 2019-11-14 11:49:13 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:49:13 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:49:13 --> Utf8 Class Initialized
INFO - 2019-11-14 11:49:13 --> URI Class Initialized
INFO - 2019-11-14 11:49:13 --> Router Class Initialized
INFO - 2019-11-14 11:49:13 --> Output Class Initialized
INFO - 2019-11-14 11:49:13 --> Security Class Initialized
DEBUG - 2019-11-14 11:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:49:13 --> CSRF cookie sent
INFO - 2019-11-14 11:49:13 --> CSRF token verified
INFO - 2019-11-14 11:49:13 --> Input Class Initialized
INFO - 2019-11-14 11:49:13 --> Language Class Initialized
INFO - 2019-11-14 11:49:13 --> Language Class Initialized
INFO - 2019-11-14 11:49:13 --> Config Class Initialized
INFO - 2019-11-14 11:49:13 --> Loader Class Initialized
INFO - 2019-11-14 11:49:13 --> Helper loaded: url_helper
INFO - 2019-11-14 11:49:13 --> Helper loaded: common_helper
INFO - 2019-11-14 11:49:13 --> Helper loaded: language_helper
INFO - 2019-11-14 11:49:13 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:49:13 --> Helper loaded: email_helper
INFO - 2019-11-14 11:49:13 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:49:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:49:13 --> Parser Class Initialized
INFO - 2019-11-14 11:49:13 --> User Agent Class Initialized
INFO - 2019-11-14 11:49:13 --> Model Class Initialized
INFO - 2019-11-14 11:49:13 --> Database Driver Class Initialized
INFO - 2019-11-14 11:49:14 --> Model Class Initialized
DEBUG - 2019-11-14 11:49:14 --> Template Class Initialized
INFO - 2019-11-14 11:49:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:49:14 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:49:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:49:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:49:14 --> Encryption Class Initialized
INFO - 2019-11-14 11:49:14 --> Controller Class Initialized
DEBUG - 2019-11-14 11:49:14 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 11:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 11:49:14 --> Model Class Initialized
INFO - 2019-11-14 11:49:14 --> Config Class Initialized
INFO - 2019-11-14 11:49:14 --> Hooks Class Initialized
DEBUG - 2019-11-14 11:49:14 --> UTF-8 Support Enabled
INFO - 2019-11-14 11:49:14 --> Utf8 Class Initialized
INFO - 2019-11-14 11:49:14 --> URI Class Initialized
DEBUG - 2019-11-14 11:49:14 --> No URI present. Default controller set.
INFO - 2019-11-14 11:49:14 --> Router Class Initialized
INFO - 2019-11-14 11:49:14 --> Output Class Initialized
INFO - 2019-11-14 11:49:14 --> Security Class Initialized
DEBUG - 2019-11-14 11:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 11:49:14 --> CSRF cookie sent
INFO - 2019-11-14 11:49:14 --> Input Class Initialized
INFO - 2019-11-14 11:49:14 --> Language Class Initialized
INFO - 2019-11-14 11:49:14 --> Language Class Initialized
INFO - 2019-11-14 11:49:14 --> Config Class Initialized
INFO - 2019-11-14 11:49:14 --> Loader Class Initialized
INFO - 2019-11-14 11:49:14 --> Helper loaded: url_helper
INFO - 2019-11-14 11:49:14 --> Helper loaded: common_helper
INFO - 2019-11-14 11:49:14 --> Helper loaded: language_helper
INFO - 2019-11-14 11:49:14 --> Helper loaded: cookie_helper
INFO - 2019-11-14 11:49:14 --> Helper loaded: email_helper
INFO - 2019-11-14 11:49:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 11:49:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 11:49:14 --> Parser Class Initialized
INFO - 2019-11-14 11:49:14 --> User Agent Class Initialized
INFO - 2019-11-14 11:49:14 --> Model Class Initialized
INFO - 2019-11-14 11:49:14 --> Database Driver Class Initialized
INFO - 2019-11-14 11:49:14 --> Model Class Initialized
DEBUG - 2019-11-14 11:49:14 --> Template Class Initialized
INFO - 2019-11-14 11:49:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 11:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 11:49:14 --> Pagination Class Initialized
DEBUG - 2019-11-14 11:49:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 11:49:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 11:49:14 --> Encryption Class Initialized
DEBUG - 2019-11-14 11:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 11:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-14 11:49:14 --> Controller Class Initialized
DEBUG - 2019-11-14 11:49:14 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 11:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 11:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-14 11:49:14 --> Model Class Initialized
INFO - 2019-11-14 11:49:14 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 11:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 11:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 11:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-14 11:49:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-14 11:49:14 --> Final output sent to browser
DEBUG - 2019-11-14 11:49:14 --> Total execution time: 0.6646
INFO - 2019-11-14 14:17:38 --> Config Class Initialized
INFO - 2019-11-14 14:17:38 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:17:38 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:17:38 --> Utf8 Class Initialized
INFO - 2019-11-14 14:17:38 --> URI Class Initialized
INFO - 2019-11-14 14:17:39 --> Router Class Initialized
INFO - 2019-11-14 14:17:39 --> Output Class Initialized
INFO - 2019-11-14 14:17:39 --> Security Class Initialized
DEBUG - 2019-11-14 14:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:17:39 --> CSRF cookie sent
INFO - 2019-11-14 14:19:39 --> Config Class Initialized
INFO - 2019-11-14 14:19:39 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:19:39 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:19:39 --> Utf8 Class Initialized
INFO - 2019-11-14 14:19:39 --> URI Class Initialized
INFO - 2019-11-14 14:19:39 --> Router Class Initialized
INFO - 2019-11-14 14:19:39 --> Output Class Initialized
INFO - 2019-11-14 14:19:39 --> Security Class Initialized
DEBUG - 2019-11-14 14:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:19:39 --> CSRF cookie sent
INFO - 2019-11-14 14:19:44 --> Config Class Initialized
INFO - 2019-11-14 14:19:44 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:19:44 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:19:44 --> Utf8 Class Initialized
INFO - 2019-11-14 14:19:44 --> URI Class Initialized
INFO - 2019-11-14 14:19:44 --> Router Class Initialized
INFO - 2019-11-14 14:19:44 --> Output Class Initialized
INFO - 2019-11-14 14:19:44 --> Security Class Initialized
DEBUG - 2019-11-14 14:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:19:44 --> CSRF cookie sent
INFO - 2019-11-14 14:19:44 --> Input Class Initialized
INFO - 2019-11-14 14:19:44 --> Language Class Initialized
INFO - 2019-11-14 14:19:44 --> Language Class Initialized
INFO - 2019-11-14 14:19:44 --> Config Class Initialized
INFO - 2019-11-14 14:19:44 --> Loader Class Initialized
INFO - 2019-11-14 14:19:44 --> Helper loaded: url_helper
INFO - 2019-11-14 14:19:44 --> Helper loaded: common_helper
INFO - 2019-11-14 14:19:44 --> Helper loaded: language_helper
INFO - 2019-11-14 14:19:44 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:19:44 --> Helper loaded: email_helper
INFO - 2019-11-14 14:19:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:19:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:19:45 --> Parser Class Initialized
INFO - 2019-11-14 14:19:45 --> User Agent Class Initialized
INFO - 2019-11-14 14:19:45 --> Model Class Initialized
INFO - 2019-11-14 14:19:45 --> Database Driver Class Initialized
INFO - 2019-11-14 14:19:45 --> Model Class Initialized
DEBUG - 2019-11-14 14:19:45 --> Template Class Initialized
INFO - 2019-11-14 14:19:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:19:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:19:45 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:19:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:19:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:19:45 --> Encryption Class Initialized
INFO - 2019-11-14 14:19:45 --> Controller Class Initialized
DEBUG - 2019-11-14 14:19:45 --> package MX_Controller Initialized
DEBUG - 2019-11-14 14:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-14 14:19:45 --> Model Class Initialized
INFO - 2019-11-14 14:19:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 14:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:19:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:19:45 --> Model Class Initialized
DEBUG - 2019-11-14 14:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:19:45 --> Model Class Initialized
DEBUG - 2019-11-14 14:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-14 14:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-14 14:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:19:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:19:45 --> Final output sent to browser
DEBUG - 2019-11-14 14:19:45 --> Total execution time: 1.2536
INFO - 2019-11-14 14:19:48 --> Config Class Initialized
INFO - 2019-11-14 14:19:48 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:19:48 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:19:48 --> Utf8 Class Initialized
INFO - 2019-11-14 14:19:48 --> URI Class Initialized
INFO - 2019-11-14 14:19:48 --> Router Class Initialized
INFO - 2019-11-14 14:19:48 --> Output Class Initialized
INFO - 2019-11-14 14:19:49 --> Security Class Initialized
DEBUG - 2019-11-14 14:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:19:49 --> CSRF cookie sent
INFO - 2019-11-14 14:19:49 --> CSRF token verified
INFO - 2019-11-14 14:19:49 --> Input Class Initialized
INFO - 2019-11-14 14:19:49 --> Language Class Initialized
INFO - 2019-11-14 14:19:49 --> Language Class Initialized
INFO - 2019-11-14 14:19:49 --> Config Class Initialized
INFO - 2019-11-14 14:19:49 --> Loader Class Initialized
INFO - 2019-11-14 14:19:49 --> Helper loaded: url_helper
INFO - 2019-11-14 14:19:49 --> Helper loaded: common_helper
INFO - 2019-11-14 14:19:49 --> Helper loaded: language_helper
INFO - 2019-11-14 14:19:49 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:19:49 --> Helper loaded: email_helper
INFO - 2019-11-14 14:19:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:19:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:19:49 --> Parser Class Initialized
INFO - 2019-11-14 14:19:49 --> User Agent Class Initialized
INFO - 2019-11-14 14:19:49 --> Model Class Initialized
INFO - 2019-11-14 14:19:49 --> Database Driver Class Initialized
INFO - 2019-11-14 14:19:49 --> Model Class Initialized
DEBUG - 2019-11-14 14:19:49 --> Template Class Initialized
INFO - 2019-11-14 14:19:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:19:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:19:49 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:19:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:19:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:19:49 --> Encryption Class Initialized
INFO - 2019-11-14 14:19:49 --> Controller Class Initialized
DEBUG - 2019-11-14 14:19:49 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:19:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:19:49 --> Model Class Initialized
INFO - 2019-11-14 14:19:49 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:19:49 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:19:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:19:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:19:49 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:19:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:19:49 --> Model Class Initialized
DEBUG - 2019-11-14 14:19:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:19:49 --> Model Class Initialized
DEBUG - 2019-11-14 14:19:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:19:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:19:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:19:49 --> Final output sent to browser
DEBUG - 2019-11-14 14:19:49 --> Total execution time: 0.8311
INFO - 2019-11-14 14:19:57 --> Config Class Initialized
INFO - 2019-11-14 14:19:57 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:19:57 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:19:57 --> Utf8 Class Initialized
INFO - 2019-11-14 14:19:57 --> URI Class Initialized
INFO - 2019-11-14 14:19:57 --> Router Class Initialized
INFO - 2019-11-14 14:19:57 --> Output Class Initialized
INFO - 2019-11-14 14:19:57 --> Security Class Initialized
DEBUG - 2019-11-14 14:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:19:57 --> CSRF cookie sent
INFO - 2019-11-14 14:19:57 --> CSRF token verified
INFO - 2019-11-14 14:19:57 --> Input Class Initialized
INFO - 2019-11-14 14:19:57 --> Language Class Initialized
INFO - 2019-11-14 14:19:57 --> Language Class Initialized
INFO - 2019-11-14 14:19:57 --> Config Class Initialized
INFO - 2019-11-14 14:19:57 --> Loader Class Initialized
INFO - 2019-11-14 14:19:57 --> Helper loaded: url_helper
INFO - 2019-11-14 14:19:57 --> Helper loaded: common_helper
INFO - 2019-11-14 14:19:57 --> Helper loaded: language_helper
INFO - 2019-11-14 14:19:57 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:19:57 --> Helper loaded: email_helper
INFO - 2019-11-14 14:19:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:19:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:19:57 --> Parser Class Initialized
INFO - 2019-11-14 14:19:57 --> User Agent Class Initialized
INFO - 2019-11-14 14:19:57 --> Model Class Initialized
INFO - 2019-11-14 14:19:57 --> Database Driver Class Initialized
INFO - 2019-11-14 14:19:57 --> Model Class Initialized
DEBUG - 2019-11-14 14:19:57 --> Template Class Initialized
INFO - 2019-11-14 14:19:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:19:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:19:58 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:19:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:19:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:19:58 --> Encryption Class Initialized
INFO - 2019-11-14 14:19:58 --> Controller Class Initialized
DEBUG - 2019-11-14 14:19:58 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:19:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:19:58 --> Model Class Initialized
DEBUG - 2019-11-14 14:19:58 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:19:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 14:19:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 14:19:58 --> Final output sent to browser
DEBUG - 2019-11-14 14:19:58 --> Total execution time: 0.5479
INFO - 2019-11-14 14:20:04 --> Config Class Initialized
INFO - 2019-11-14 14:20:04 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:20:04 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:20:04 --> Utf8 Class Initialized
INFO - 2019-11-14 14:20:04 --> URI Class Initialized
INFO - 2019-11-14 14:20:04 --> Router Class Initialized
INFO - 2019-11-14 14:20:04 --> Output Class Initialized
INFO - 2019-11-14 14:20:04 --> Security Class Initialized
DEBUG - 2019-11-14 14:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:20:04 --> Input Class Initialized
INFO - 2019-11-14 14:20:04 --> Language Class Initialized
INFO - 2019-11-14 14:20:04 --> Language Class Initialized
INFO - 2019-11-14 14:20:04 --> Config Class Initialized
INFO - 2019-11-14 14:20:04 --> Loader Class Initialized
INFO - 2019-11-14 14:20:04 --> Helper loaded: url_helper
INFO - 2019-11-14 14:20:04 --> Helper loaded: common_helper
INFO - 2019-11-14 14:20:04 --> Helper loaded: language_helper
INFO - 2019-11-14 14:20:04 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:20:04 --> Helper loaded: email_helper
INFO - 2019-11-14 14:20:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:20:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:20:04 --> Parser Class Initialized
INFO - 2019-11-14 14:20:04 --> User Agent Class Initialized
INFO - 2019-11-14 14:20:04 --> Model Class Initialized
INFO - 2019-11-14 14:20:04 --> Database Driver Class Initialized
INFO - 2019-11-14 14:20:04 --> Model Class Initialized
DEBUG - 2019-11-14 14:20:04 --> Template Class Initialized
INFO - 2019-11-14 14:20:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:20:04 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:20:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:20:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:20:04 --> Encryption Class Initialized
INFO - 2019-11-14 14:20:04 --> Controller Class Initialized
DEBUG - 2019-11-14 14:20:04 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:20:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
INFO - 2019-11-14 14:20:04 --> Model Class Initialized
INFO - 2019-11-14 14:20:33 --> Config Class Initialized
INFO - 2019-11-14 14:20:33 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:20:33 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:20:33 --> Utf8 Class Initialized
INFO - 2019-11-14 14:20:33 --> URI Class Initialized
INFO - 2019-11-14 14:20:33 --> Router Class Initialized
INFO - 2019-11-14 14:20:33 --> Output Class Initialized
INFO - 2019-11-14 14:20:33 --> Security Class Initialized
DEBUG - 2019-11-14 14:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:20:33 --> CSRF cookie sent
INFO - 2019-11-14 14:20:33 --> Input Class Initialized
INFO - 2019-11-14 14:20:33 --> Language Class Initialized
INFO - 2019-11-14 14:20:33 --> Language Class Initialized
INFO - 2019-11-14 14:20:33 --> Config Class Initialized
INFO - 2019-11-14 14:20:33 --> Loader Class Initialized
INFO - 2019-11-14 14:20:33 --> Helper loaded: url_helper
INFO - 2019-11-14 14:20:33 --> Helper loaded: common_helper
INFO - 2019-11-14 14:20:33 --> Helper loaded: language_helper
INFO - 2019-11-14 14:20:33 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:20:33 --> Helper loaded: email_helper
INFO - 2019-11-14 14:20:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:20:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:20:33 --> Parser Class Initialized
INFO - 2019-11-14 14:20:33 --> User Agent Class Initialized
INFO - 2019-11-14 14:20:33 --> Model Class Initialized
INFO - 2019-11-14 14:20:33 --> Database Driver Class Initialized
INFO - 2019-11-14 14:20:33 --> Model Class Initialized
DEBUG - 2019-11-14 14:20:33 --> Template Class Initialized
INFO - 2019-11-14 14:20:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:20:33 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:20:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:20:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:20:33 --> Encryption Class Initialized
INFO - 2019-11-14 14:20:33 --> Controller Class Initialized
DEBUG - 2019-11-14 14:20:33 --> order MX_Controller Initialized
DEBUG - 2019-11-14 14:20:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 14:20:33 --> Model Class Initialized
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "order_id"
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "order_id"
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 14:20:33 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "Pending"
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "Pending"
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "Pending"
ERROR - 2019-11-14 14:20:33 --> Could not find the language line "Pending"
DEBUG - 2019-11-14 14:20:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 14:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:20:34 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:20:34 --> Model Class Initialized
DEBUG - 2019-11-14 14:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:20:34 --> Model Class Initialized
DEBUG - 2019-11-14 14:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 14:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 14:20:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 14:20:34 --> Final output sent to browser
DEBUG - 2019-11-14 14:20:34 --> Total execution time: 1.1019
INFO - 2019-11-14 14:24:48 --> Config Class Initialized
INFO - 2019-11-14 14:24:48 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:24:48 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:24:48 --> Utf8 Class Initialized
INFO - 2019-11-14 14:24:48 --> URI Class Initialized
INFO - 2019-11-14 14:24:48 --> Router Class Initialized
INFO - 2019-11-14 14:24:48 --> Output Class Initialized
INFO - 2019-11-14 14:24:48 --> Security Class Initialized
DEBUG - 2019-11-14 14:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:24:48 --> CSRF cookie sent
INFO - 2019-11-14 14:24:48 --> Input Class Initialized
INFO - 2019-11-14 14:24:48 --> Language Class Initialized
INFO - 2019-11-14 14:24:48 --> Language Class Initialized
INFO - 2019-11-14 14:24:48 --> Config Class Initialized
INFO - 2019-11-14 14:24:48 --> Loader Class Initialized
INFO - 2019-11-14 14:24:48 --> Helper loaded: url_helper
INFO - 2019-11-14 14:24:48 --> Helper loaded: common_helper
INFO - 2019-11-14 14:24:48 --> Helper loaded: language_helper
INFO - 2019-11-14 14:24:48 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:24:48 --> Helper loaded: email_helper
INFO - 2019-11-14 14:24:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:24:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:24:48 --> Parser Class Initialized
INFO - 2019-11-14 14:24:48 --> User Agent Class Initialized
INFO - 2019-11-14 14:24:48 --> Model Class Initialized
INFO - 2019-11-14 14:24:48 --> Database Driver Class Initialized
INFO - 2019-11-14 14:24:48 --> Model Class Initialized
DEBUG - 2019-11-14 14:24:48 --> Template Class Initialized
INFO - 2019-11-14 14:24:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:24:48 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:24:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:24:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:24:48 --> Encryption Class Initialized
INFO - 2019-11-14 14:24:48 --> Controller Class Initialized
DEBUG - 2019-11-14 14:24:48 --> transactions MX_Controller Initialized
DEBUG - 2019-11-14 14:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-14 14:24:48 --> Model Class Initialized
ERROR - 2019-11-14 14:24:48 --> Could not find the language line "order_id"
INFO - 2019-11-14 14:24:48 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 14:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-14 14:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:24:48 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:24:48 --> Model Class Initialized
DEBUG - 2019-11-14 14:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:24:48 --> Model Class Initialized
DEBUG - 2019-11-14 14:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 14:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 14:24:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 14:24:48 --> Final output sent to browser
DEBUG - 2019-11-14 14:24:48 --> Total execution time: 0.6836
INFO - 2019-11-14 14:27:30 --> Config Class Initialized
INFO - 2019-11-14 14:27:30 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:27:30 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:27:30 --> Utf8 Class Initialized
INFO - 2019-11-14 14:27:30 --> URI Class Initialized
INFO - 2019-11-14 14:27:30 --> Router Class Initialized
INFO - 2019-11-14 14:27:30 --> Output Class Initialized
INFO - 2019-11-14 14:27:30 --> Security Class Initialized
DEBUG - 2019-11-14 14:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:27:30 --> CSRF cookie sent
INFO - 2019-11-14 14:27:30 --> CSRF token verified
INFO - 2019-11-14 14:27:30 --> Input Class Initialized
INFO - 2019-11-14 14:27:30 --> Language Class Initialized
INFO - 2019-11-14 14:27:30 --> Language Class Initialized
INFO - 2019-11-14 14:27:30 --> Config Class Initialized
INFO - 2019-11-14 14:27:30 --> Loader Class Initialized
INFO - 2019-11-14 14:27:30 --> Helper loaded: url_helper
INFO - 2019-11-14 14:27:30 --> Helper loaded: common_helper
INFO - 2019-11-14 14:27:30 --> Helper loaded: language_helper
INFO - 2019-11-14 14:27:30 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:27:30 --> Helper loaded: email_helper
INFO - 2019-11-14 14:27:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:27:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:27:31 --> Parser Class Initialized
INFO - 2019-11-14 14:27:31 --> User Agent Class Initialized
INFO - 2019-11-14 14:27:31 --> Model Class Initialized
INFO - 2019-11-14 14:27:31 --> Database Driver Class Initialized
INFO - 2019-11-14 14:27:31 --> Model Class Initialized
DEBUG - 2019-11-14 14:27:31 --> Template Class Initialized
INFO - 2019-11-14 14:27:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:27:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:27:31 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:27:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:27:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:27:31 --> Encryption Class Initialized
INFO - 2019-11-14 14:27:31 --> Controller Class Initialized
DEBUG - 2019-11-14 14:27:31 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:27:31 --> Model Class Initialized
INFO - 2019-11-14 14:27:31 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:27:31 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:27:31 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:27:31 --> Model Class Initialized
DEBUG - 2019-11-14 14:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:27:31 --> Model Class Initialized
DEBUG - 2019-11-14 14:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:27:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:27:31 --> Final output sent to browser
DEBUG - 2019-11-14 14:27:31 --> Total execution time: 0.8029
INFO - 2019-11-14 14:27:39 --> Config Class Initialized
INFO - 2019-11-14 14:27:39 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:27:39 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:27:39 --> Utf8 Class Initialized
INFO - 2019-11-14 14:27:39 --> URI Class Initialized
INFO - 2019-11-14 14:27:39 --> Router Class Initialized
INFO - 2019-11-14 14:27:39 --> Output Class Initialized
INFO - 2019-11-14 14:27:39 --> Security Class Initialized
DEBUG - 2019-11-14 14:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:27:39 --> CSRF cookie sent
INFO - 2019-11-14 14:27:39 --> CSRF token verified
INFO - 2019-11-14 14:27:39 --> Input Class Initialized
INFO - 2019-11-14 14:27:39 --> Language Class Initialized
INFO - 2019-11-14 14:27:39 --> Language Class Initialized
INFO - 2019-11-14 14:27:39 --> Config Class Initialized
INFO - 2019-11-14 14:27:39 --> Loader Class Initialized
INFO - 2019-11-14 14:27:39 --> Helper loaded: url_helper
INFO - 2019-11-14 14:27:39 --> Helper loaded: common_helper
INFO - 2019-11-14 14:27:39 --> Helper loaded: language_helper
INFO - 2019-11-14 14:27:39 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:27:39 --> Helper loaded: email_helper
INFO - 2019-11-14 14:27:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:27:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:27:39 --> Parser Class Initialized
INFO - 2019-11-14 14:27:39 --> User Agent Class Initialized
INFO - 2019-11-14 14:27:39 --> Model Class Initialized
INFO - 2019-11-14 14:27:39 --> Database Driver Class Initialized
INFO - 2019-11-14 14:27:39 --> Model Class Initialized
DEBUG - 2019-11-14 14:27:39 --> Template Class Initialized
INFO - 2019-11-14 14:27:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:27:39 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:27:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:27:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:27:39 --> Encryption Class Initialized
INFO - 2019-11-14 14:27:39 --> Controller Class Initialized
DEBUG - 2019-11-14 14:27:39 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:27:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:27:39 --> Model Class Initialized
ERROR - 2019-11-14 14:27:39 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 185
INFO - 2019-11-14 14:27:49 --> Config Class Initialized
INFO - 2019-11-14 14:27:49 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:27:49 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:27:49 --> Utf8 Class Initialized
INFO - 2019-11-14 14:27:49 --> URI Class Initialized
INFO - 2019-11-14 14:27:49 --> Router Class Initialized
INFO - 2019-11-14 14:27:49 --> Output Class Initialized
INFO - 2019-11-14 14:27:49 --> Security Class Initialized
DEBUG - 2019-11-14 14:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:27:49 --> CSRF cookie sent
INFO - 2019-11-14 14:27:49 --> CSRF token verified
INFO - 2019-11-14 14:27:49 --> Input Class Initialized
INFO - 2019-11-14 14:27:49 --> Language Class Initialized
INFO - 2019-11-14 14:27:49 --> Language Class Initialized
INFO - 2019-11-14 14:27:49 --> Config Class Initialized
INFO - 2019-11-14 14:27:49 --> Loader Class Initialized
INFO - 2019-11-14 14:27:49 --> Helper loaded: url_helper
INFO - 2019-11-14 14:27:49 --> Helper loaded: common_helper
INFO - 2019-11-14 14:27:49 --> Helper loaded: language_helper
INFO - 2019-11-14 14:27:49 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:27:49 --> Helper loaded: email_helper
INFO - 2019-11-14 14:27:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:27:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:27:49 --> Parser Class Initialized
INFO - 2019-11-14 14:27:49 --> User Agent Class Initialized
INFO - 2019-11-14 14:27:49 --> Model Class Initialized
INFO - 2019-11-14 14:27:49 --> Database Driver Class Initialized
INFO - 2019-11-14 14:27:49 --> Model Class Initialized
DEBUG - 2019-11-14 14:27:49 --> Template Class Initialized
INFO - 2019-11-14 14:27:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:27:49 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:27:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:27:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:27:49 --> Encryption Class Initialized
INFO - 2019-11-14 14:27:49 --> Controller Class Initialized
DEBUG - 2019-11-14 14:27:49 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:27:50 --> Model Class Initialized
INFO - 2019-11-14 14:27:50 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:27:50 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:27:50 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:27:50 --> Model Class Initialized
DEBUG - 2019-11-14 14:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:27:50 --> Model Class Initialized
DEBUG - 2019-11-14 14:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:27:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:27:50 --> Final output sent to browser
DEBUG - 2019-11-14 14:27:50 --> Total execution time: 0.8466
INFO - 2019-11-14 14:27:56 --> Config Class Initialized
INFO - 2019-11-14 14:27:56 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:27:57 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:27:57 --> Utf8 Class Initialized
INFO - 2019-11-14 14:27:57 --> URI Class Initialized
INFO - 2019-11-14 14:27:57 --> Router Class Initialized
INFO - 2019-11-14 14:27:57 --> Output Class Initialized
INFO - 2019-11-14 14:27:57 --> Security Class Initialized
DEBUG - 2019-11-14 14:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:27:57 --> CSRF cookie sent
INFO - 2019-11-14 14:27:57 --> CSRF token verified
INFO - 2019-11-14 14:27:57 --> Input Class Initialized
INFO - 2019-11-14 14:27:57 --> Language Class Initialized
INFO - 2019-11-14 14:27:57 --> Language Class Initialized
INFO - 2019-11-14 14:27:57 --> Config Class Initialized
INFO - 2019-11-14 14:27:57 --> Loader Class Initialized
INFO - 2019-11-14 14:27:57 --> Helper loaded: url_helper
INFO - 2019-11-14 14:27:57 --> Helper loaded: common_helper
INFO - 2019-11-14 14:27:57 --> Helper loaded: language_helper
INFO - 2019-11-14 14:27:57 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:27:57 --> Helper loaded: email_helper
INFO - 2019-11-14 14:27:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:27:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:27:57 --> Parser Class Initialized
INFO - 2019-11-14 14:27:57 --> User Agent Class Initialized
INFO - 2019-11-14 14:27:57 --> Model Class Initialized
INFO - 2019-11-14 14:27:57 --> Database Driver Class Initialized
INFO - 2019-11-14 14:27:57 --> Model Class Initialized
DEBUG - 2019-11-14 14:27:57 --> Template Class Initialized
INFO - 2019-11-14 14:27:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:27:57 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:27:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:27:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:27:57 --> Encryption Class Initialized
INFO - 2019-11-14 14:27:57 --> Controller Class Initialized
DEBUG - 2019-11-14 14:27:57 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:27:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:27:57 --> Model Class Initialized
ERROR - 2019-11-14 14:27:57 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 185
INFO - 2019-11-14 14:28:36 --> Config Class Initialized
INFO - 2019-11-14 14:28:36 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:28:37 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:28:37 --> Utf8 Class Initialized
INFO - 2019-11-14 14:28:37 --> URI Class Initialized
INFO - 2019-11-14 14:28:37 --> Router Class Initialized
INFO - 2019-11-14 14:28:37 --> Output Class Initialized
INFO - 2019-11-14 14:28:37 --> Security Class Initialized
DEBUG - 2019-11-14 14:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:28:37 --> CSRF cookie sent
INFO - 2019-11-14 14:28:37 --> CSRF token verified
INFO - 2019-11-14 14:28:37 --> Input Class Initialized
INFO - 2019-11-14 14:28:37 --> Language Class Initialized
INFO - 2019-11-14 14:28:37 --> Language Class Initialized
INFO - 2019-11-14 14:28:37 --> Config Class Initialized
INFO - 2019-11-14 14:28:37 --> Loader Class Initialized
INFO - 2019-11-14 14:28:37 --> Helper loaded: url_helper
INFO - 2019-11-14 14:28:37 --> Helper loaded: common_helper
INFO - 2019-11-14 14:28:37 --> Helper loaded: language_helper
INFO - 2019-11-14 14:28:37 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:28:37 --> Helper loaded: email_helper
INFO - 2019-11-14 14:28:37 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:28:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:28:37 --> Parser Class Initialized
INFO - 2019-11-14 14:28:37 --> User Agent Class Initialized
INFO - 2019-11-14 14:28:37 --> Model Class Initialized
INFO - 2019-11-14 14:28:37 --> Database Driver Class Initialized
INFO - 2019-11-14 14:28:37 --> Model Class Initialized
DEBUG - 2019-11-14 14:28:37 --> Template Class Initialized
INFO - 2019-11-14 14:28:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:28:37 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:28:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:28:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:28:37 --> Encryption Class Initialized
INFO - 2019-11-14 14:28:37 --> Controller Class Initialized
DEBUG - 2019-11-14 14:28:37 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:28:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:28:37 --> Model Class Initialized
INFO - 2019-11-14 14:28:37 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:28:37 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:28:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:28:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:28:37 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:28:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:28:37 --> Model Class Initialized
DEBUG - 2019-11-14 14:28:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:28:37 --> Model Class Initialized
DEBUG - 2019-11-14 14:28:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:28:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:28:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:28:37 --> Final output sent to browser
DEBUG - 2019-11-14 14:28:37 --> Total execution time: 0.7370
INFO - 2019-11-14 14:28:46 --> Config Class Initialized
INFO - 2019-11-14 14:28:46 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:28:46 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:28:46 --> Utf8 Class Initialized
INFO - 2019-11-14 14:28:46 --> URI Class Initialized
INFO - 2019-11-14 14:28:46 --> Router Class Initialized
INFO - 2019-11-14 14:28:46 --> Output Class Initialized
INFO - 2019-11-14 14:28:46 --> Security Class Initialized
DEBUG - 2019-11-14 14:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:28:46 --> CSRF cookie sent
INFO - 2019-11-14 14:28:46 --> CSRF token verified
INFO - 2019-11-14 14:28:46 --> Input Class Initialized
INFO - 2019-11-14 14:28:46 --> Language Class Initialized
INFO - 2019-11-14 14:28:46 --> Language Class Initialized
INFO - 2019-11-14 14:28:46 --> Config Class Initialized
INFO - 2019-11-14 14:28:46 --> Loader Class Initialized
INFO - 2019-11-14 14:28:46 --> Helper loaded: url_helper
INFO - 2019-11-14 14:28:46 --> Helper loaded: common_helper
INFO - 2019-11-14 14:28:46 --> Helper loaded: language_helper
INFO - 2019-11-14 14:28:46 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:28:46 --> Helper loaded: email_helper
INFO - 2019-11-14 14:28:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:28:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:28:46 --> Parser Class Initialized
INFO - 2019-11-14 14:28:46 --> User Agent Class Initialized
INFO - 2019-11-14 14:28:46 --> Model Class Initialized
INFO - 2019-11-14 14:28:46 --> Database Driver Class Initialized
INFO - 2019-11-14 14:28:46 --> Model Class Initialized
DEBUG - 2019-11-14 14:28:46 --> Template Class Initialized
INFO - 2019-11-14 14:28:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:28:46 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:28:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:28:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:28:46 --> Encryption Class Initialized
INFO - 2019-11-14 14:28:46 --> Controller Class Initialized
DEBUG - 2019-11-14 14:28:46 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:28:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:28:46 --> Model Class Initialized
ERROR - 2019-11-14 14:28:46 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\shopier.php 185
INFO - 2019-11-14 14:29:10 --> Config Class Initialized
INFO - 2019-11-14 14:29:10 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:29:10 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:29:10 --> Utf8 Class Initialized
INFO - 2019-11-14 14:29:10 --> URI Class Initialized
INFO - 2019-11-14 14:29:10 --> Router Class Initialized
INFO - 2019-11-14 14:29:10 --> Output Class Initialized
INFO - 2019-11-14 14:29:10 --> Security Class Initialized
DEBUG - 2019-11-14 14:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:29:10 --> CSRF cookie sent
INFO - 2019-11-14 14:29:10 --> CSRF token verified
INFO - 2019-11-14 14:29:10 --> Input Class Initialized
INFO - 2019-11-14 14:29:10 --> Language Class Initialized
INFO - 2019-11-14 14:29:10 --> Language Class Initialized
INFO - 2019-11-14 14:29:10 --> Config Class Initialized
INFO - 2019-11-14 14:29:10 --> Loader Class Initialized
INFO - 2019-11-14 14:29:10 --> Helper loaded: url_helper
INFO - 2019-11-14 14:29:10 --> Helper loaded: common_helper
INFO - 2019-11-14 14:29:10 --> Helper loaded: language_helper
INFO - 2019-11-14 14:29:10 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:29:10 --> Helper loaded: email_helper
INFO - 2019-11-14 14:29:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:29:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:29:10 --> Parser Class Initialized
INFO - 2019-11-14 14:29:10 --> User Agent Class Initialized
INFO - 2019-11-14 14:29:10 --> Model Class Initialized
INFO - 2019-11-14 14:29:10 --> Database Driver Class Initialized
INFO - 2019-11-14 14:29:10 --> Model Class Initialized
DEBUG - 2019-11-14 14:29:11 --> Template Class Initialized
INFO - 2019-11-14 14:29:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:29:11 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:29:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:29:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:29:11 --> Encryption Class Initialized
INFO - 2019-11-14 14:29:11 --> Controller Class Initialized
DEBUG - 2019-11-14 14:29:11 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:29:11 --> Model Class Initialized
INFO - 2019-11-14 14:29:11 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:29:11 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:29:11 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:29:11 --> Model Class Initialized
DEBUG - 2019-11-14 14:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:29:11 --> Model Class Initialized
DEBUG - 2019-11-14 14:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:29:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:29:11 --> Final output sent to browser
DEBUG - 2019-11-14 14:29:11 --> Total execution time: 0.7659
INFO - 2019-11-14 14:29:19 --> Config Class Initialized
INFO - 2019-11-14 14:29:19 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:29:19 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:29:19 --> Utf8 Class Initialized
INFO - 2019-11-14 14:29:19 --> URI Class Initialized
INFO - 2019-11-14 14:29:19 --> Router Class Initialized
INFO - 2019-11-14 14:29:19 --> Output Class Initialized
INFO - 2019-11-14 14:29:19 --> Security Class Initialized
DEBUG - 2019-11-14 14:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:29:19 --> CSRF cookie sent
INFO - 2019-11-14 14:29:19 --> CSRF token verified
INFO - 2019-11-14 14:29:19 --> Input Class Initialized
INFO - 2019-11-14 14:29:19 --> Language Class Initialized
INFO - 2019-11-14 14:29:19 --> Language Class Initialized
INFO - 2019-11-14 14:29:19 --> Config Class Initialized
INFO - 2019-11-14 14:29:19 --> Loader Class Initialized
INFO - 2019-11-14 14:29:19 --> Helper loaded: url_helper
INFO - 2019-11-14 14:29:19 --> Helper loaded: common_helper
INFO - 2019-11-14 14:29:19 --> Helper loaded: language_helper
INFO - 2019-11-14 14:29:19 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:29:19 --> Helper loaded: email_helper
INFO - 2019-11-14 14:29:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:29:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:29:19 --> Parser Class Initialized
INFO - 2019-11-14 14:29:19 --> User Agent Class Initialized
INFO - 2019-11-14 14:29:19 --> Model Class Initialized
INFO - 2019-11-14 14:29:19 --> Database Driver Class Initialized
INFO - 2019-11-14 14:29:19 --> Model Class Initialized
DEBUG - 2019-11-14 14:29:19 --> Template Class Initialized
INFO - 2019-11-14 14:29:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:29:19 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:29:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:29:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:29:20 --> Encryption Class Initialized
INFO - 2019-11-14 14:29:20 --> Controller Class Initialized
DEBUG - 2019-11-14 14:29:20 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:29:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:29:20 --> Model Class Initialized
DEBUG - 2019-11-14 14:29:20 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:29:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 14:29:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 14:29:20 --> Final output sent to browser
DEBUG - 2019-11-14 14:29:20 --> Total execution time: 0.5521
INFO - 2019-11-14 14:29:42 --> Config Class Initialized
INFO - 2019-11-14 14:29:42 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:29:42 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:29:42 --> Utf8 Class Initialized
INFO - 2019-11-14 14:29:42 --> URI Class Initialized
INFO - 2019-11-14 14:29:42 --> Router Class Initialized
INFO - 2019-11-14 14:29:42 --> Output Class Initialized
INFO - 2019-11-14 14:29:42 --> Security Class Initialized
DEBUG - 2019-11-14 14:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:29:42 --> Input Class Initialized
INFO - 2019-11-14 14:29:42 --> Language Class Initialized
INFO - 2019-11-14 14:29:42 --> Language Class Initialized
INFO - 2019-11-14 14:29:42 --> Config Class Initialized
INFO - 2019-11-14 14:29:42 --> Loader Class Initialized
INFO - 2019-11-14 14:29:42 --> Helper loaded: url_helper
INFO - 2019-11-14 14:29:42 --> Helper loaded: common_helper
INFO - 2019-11-14 14:29:42 --> Helper loaded: language_helper
INFO - 2019-11-14 14:29:42 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:29:42 --> Helper loaded: email_helper
INFO - 2019-11-14 14:29:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:29:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:29:42 --> Parser Class Initialized
INFO - 2019-11-14 14:29:42 --> User Agent Class Initialized
INFO - 2019-11-14 14:29:42 --> Model Class Initialized
INFO - 2019-11-14 14:29:42 --> Database Driver Class Initialized
INFO - 2019-11-14 14:29:42 --> Model Class Initialized
DEBUG - 2019-11-14 14:29:42 --> Template Class Initialized
INFO - 2019-11-14 14:29:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:29:42 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:29:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:29:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:29:42 --> Encryption Class Initialized
INFO - 2019-11-14 14:29:42 --> Controller Class Initialized
DEBUG - 2019-11-14 14:29:42 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:29:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
INFO - 2019-11-14 14:29:42 --> Model Class Initialized
INFO - 2019-11-14 14:29:49 --> Config Class Initialized
INFO - 2019-11-14 14:29:49 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:29:49 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:29:49 --> Utf8 Class Initialized
INFO - 2019-11-14 14:29:49 --> URI Class Initialized
INFO - 2019-11-14 14:29:49 --> Router Class Initialized
INFO - 2019-11-14 14:29:49 --> Output Class Initialized
INFO - 2019-11-14 14:29:49 --> Security Class Initialized
DEBUG - 2019-11-14 14:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:29:50 --> Input Class Initialized
INFO - 2019-11-14 14:29:50 --> Language Class Initialized
INFO - 2019-11-14 14:29:50 --> Language Class Initialized
INFO - 2019-11-14 14:29:50 --> Config Class Initialized
INFO - 2019-11-14 14:29:50 --> Loader Class Initialized
INFO - 2019-11-14 14:29:50 --> Helper loaded: url_helper
INFO - 2019-11-14 14:29:50 --> Helper loaded: common_helper
INFO - 2019-11-14 14:29:50 --> Helper loaded: language_helper
INFO - 2019-11-14 14:29:50 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:29:50 --> Helper loaded: email_helper
INFO - 2019-11-14 14:29:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:29:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:29:50 --> Parser Class Initialized
INFO - 2019-11-14 14:29:50 --> User Agent Class Initialized
INFO - 2019-11-14 14:29:50 --> Model Class Initialized
INFO - 2019-11-14 14:29:50 --> Database Driver Class Initialized
INFO - 2019-11-14 14:29:50 --> Model Class Initialized
DEBUG - 2019-11-14 14:29:50 --> Template Class Initialized
INFO - 2019-11-14 14:29:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:29:50 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:29:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:29:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:29:50 --> Encryption Class Initialized
INFO - 2019-11-14 14:29:50 --> Controller Class Initialized
DEBUG - 2019-11-14 14:29:50 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:29:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
INFO - 2019-11-14 14:29:50 --> Model Class Initialized
INFO - 2019-11-14 14:29:53 --> Config Class Initialized
INFO - 2019-11-14 14:29:53 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:29:53 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:29:53 --> Utf8 Class Initialized
INFO - 2019-11-14 14:29:53 --> URI Class Initialized
INFO - 2019-11-14 14:29:53 --> Router Class Initialized
INFO - 2019-11-14 14:29:53 --> Output Class Initialized
INFO - 2019-11-14 14:29:53 --> Security Class Initialized
DEBUG - 2019-11-14 14:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:29:53 --> Input Class Initialized
INFO - 2019-11-14 14:29:53 --> Language Class Initialized
INFO - 2019-11-14 14:29:53 --> Language Class Initialized
INFO - 2019-11-14 14:29:53 --> Config Class Initialized
INFO - 2019-11-14 14:29:53 --> Loader Class Initialized
INFO - 2019-11-14 14:29:53 --> Helper loaded: url_helper
INFO - 2019-11-14 14:29:53 --> Helper loaded: common_helper
INFO - 2019-11-14 14:29:53 --> Helper loaded: language_helper
INFO - 2019-11-14 14:29:53 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:29:53 --> Helper loaded: email_helper
INFO - 2019-11-14 14:29:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:29:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:29:53 --> Parser Class Initialized
INFO - 2019-11-14 14:29:53 --> User Agent Class Initialized
INFO - 2019-11-14 14:29:53 --> Model Class Initialized
INFO - 2019-11-14 14:29:53 --> Database Driver Class Initialized
INFO - 2019-11-14 14:29:53 --> Model Class Initialized
DEBUG - 2019-11-14 14:29:53 --> Template Class Initialized
INFO - 2019-11-14 14:29:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:29:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:29:53 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:29:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:29:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:29:53 --> Encryption Class Initialized
INFO - 2019-11-14 14:29:53 --> Controller Class Initialized
DEBUG - 2019-11-14 14:29:53 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:29:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
INFO - 2019-11-14 14:29:53 --> Model Class Initialized
INFO - 2019-11-14 14:30:54 --> Config Class Initialized
INFO - 2019-11-14 14:30:54 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:30:54 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:30:54 --> Utf8 Class Initialized
INFO - 2019-11-14 14:30:54 --> URI Class Initialized
INFO - 2019-11-14 14:30:54 --> Router Class Initialized
INFO - 2019-11-14 14:30:55 --> Output Class Initialized
INFO - 2019-11-14 14:30:55 --> Security Class Initialized
DEBUG - 2019-11-14 14:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:30:55 --> CSRF cookie sent
INFO - 2019-11-14 14:30:55 --> CSRF token verified
INFO - 2019-11-14 14:30:55 --> Input Class Initialized
INFO - 2019-11-14 14:30:55 --> Language Class Initialized
INFO - 2019-11-14 14:30:55 --> Language Class Initialized
INFO - 2019-11-14 14:30:55 --> Config Class Initialized
INFO - 2019-11-14 14:30:55 --> Loader Class Initialized
INFO - 2019-11-14 14:30:55 --> Helper loaded: url_helper
INFO - 2019-11-14 14:30:55 --> Helper loaded: common_helper
INFO - 2019-11-14 14:30:55 --> Helper loaded: language_helper
INFO - 2019-11-14 14:30:55 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:30:55 --> Helper loaded: email_helper
INFO - 2019-11-14 14:30:55 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:30:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:30:55 --> Parser Class Initialized
INFO - 2019-11-14 14:30:55 --> User Agent Class Initialized
INFO - 2019-11-14 14:30:55 --> Model Class Initialized
INFO - 2019-11-14 14:30:55 --> Database Driver Class Initialized
INFO - 2019-11-14 14:30:55 --> Model Class Initialized
DEBUG - 2019-11-14 14:30:55 --> Template Class Initialized
INFO - 2019-11-14 14:30:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:30:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:30:55 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:30:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:30:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:30:55 --> Encryption Class Initialized
INFO - 2019-11-14 14:30:55 --> Controller Class Initialized
DEBUG - 2019-11-14 14:30:55 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:30:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:30:55 --> Model Class Initialized
INFO - 2019-11-14 14:30:55 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:30:55 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:30:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:30:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:30:55 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:30:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:30:55 --> Model Class Initialized
DEBUG - 2019-11-14 14:30:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:30:55 --> Model Class Initialized
DEBUG - 2019-11-14 14:30:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:30:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:30:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:30:55 --> Final output sent to browser
DEBUG - 2019-11-14 14:30:55 --> Total execution time: 0.7765
INFO - 2019-11-14 14:31:04 --> Config Class Initialized
INFO - 2019-11-14 14:31:04 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:31:04 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:31:04 --> Utf8 Class Initialized
INFO - 2019-11-14 14:31:04 --> URI Class Initialized
INFO - 2019-11-14 14:31:04 --> Router Class Initialized
INFO - 2019-11-14 14:31:04 --> Output Class Initialized
INFO - 2019-11-14 14:31:04 --> Security Class Initialized
DEBUG - 2019-11-14 14:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:31:04 --> CSRF cookie sent
INFO - 2019-11-14 14:31:04 --> CSRF token verified
INFO - 2019-11-14 14:31:04 --> Input Class Initialized
INFO - 2019-11-14 14:31:04 --> Language Class Initialized
INFO - 2019-11-14 14:31:04 --> Language Class Initialized
INFO - 2019-11-14 14:31:04 --> Config Class Initialized
INFO - 2019-11-14 14:31:04 --> Loader Class Initialized
INFO - 2019-11-14 14:31:04 --> Helper loaded: url_helper
INFO - 2019-11-14 14:31:04 --> Helper loaded: common_helper
INFO - 2019-11-14 14:31:04 --> Helper loaded: language_helper
INFO - 2019-11-14 14:31:04 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:31:04 --> Helper loaded: email_helper
INFO - 2019-11-14 14:31:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:31:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:31:04 --> Parser Class Initialized
INFO - 2019-11-14 14:31:04 --> User Agent Class Initialized
INFO - 2019-11-14 14:31:04 --> Model Class Initialized
INFO - 2019-11-14 14:31:04 --> Database Driver Class Initialized
INFO - 2019-11-14 14:31:04 --> Model Class Initialized
DEBUG - 2019-11-14 14:31:04 --> Template Class Initialized
INFO - 2019-11-14 14:31:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:31:04 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:31:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:31:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:31:04 --> Encryption Class Initialized
INFO - 2019-11-14 14:31:04 --> Controller Class Initialized
DEBUG - 2019-11-14 14:31:04 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:31:04 --> Model Class Initialized
DEBUG - 2019-11-14 14:31:04 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 14:31:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 14:31:04 --> Final output sent to browser
DEBUG - 2019-11-14 14:31:04 --> Total execution time: 0.6298
INFO - 2019-11-14 14:31:19 --> Config Class Initialized
INFO - 2019-11-14 14:31:19 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:31:19 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:31:19 --> Utf8 Class Initialized
INFO - 2019-11-14 14:31:19 --> URI Class Initialized
INFO - 2019-11-14 14:31:19 --> Router Class Initialized
INFO - 2019-11-14 14:31:19 --> Output Class Initialized
INFO - 2019-11-14 14:31:19 --> Security Class Initialized
DEBUG - 2019-11-14 14:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:31:19 --> Input Class Initialized
INFO - 2019-11-14 14:31:19 --> Language Class Initialized
INFO - 2019-11-14 14:31:19 --> Language Class Initialized
INFO - 2019-11-14 14:31:19 --> Config Class Initialized
INFO - 2019-11-14 14:31:19 --> Loader Class Initialized
INFO - 2019-11-14 14:31:19 --> Helper loaded: url_helper
INFO - 2019-11-14 14:31:19 --> Helper loaded: common_helper
INFO - 2019-11-14 14:31:19 --> Helper loaded: language_helper
INFO - 2019-11-14 14:31:19 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:31:19 --> Helper loaded: email_helper
INFO - 2019-11-14 14:31:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:31:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:31:19 --> Parser Class Initialized
INFO - 2019-11-14 14:31:19 --> User Agent Class Initialized
INFO - 2019-11-14 14:31:19 --> Model Class Initialized
INFO - 2019-11-14 14:31:19 --> Database Driver Class Initialized
INFO - 2019-11-14 14:31:19 --> Model Class Initialized
DEBUG - 2019-11-14 14:31:19 --> Template Class Initialized
INFO - 2019-11-14 14:31:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:31:19 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:31:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:31:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:31:19 --> Encryption Class Initialized
INFO - 2019-11-14 14:31:19 --> Controller Class Initialized
DEBUG - 2019-11-14 14:31:19 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:31:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
INFO - 2019-11-14 14:31:19 --> Model Class Initialized
INFO - 2019-11-14 14:37:31 --> Config Class Initialized
INFO - 2019-11-14 14:37:31 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:37:31 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:37:31 --> Utf8 Class Initialized
INFO - 2019-11-14 14:37:31 --> URI Class Initialized
INFO - 2019-11-14 14:37:31 --> Router Class Initialized
INFO - 2019-11-14 14:37:31 --> Output Class Initialized
INFO - 2019-11-14 14:37:31 --> Security Class Initialized
DEBUG - 2019-11-14 14:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:37:31 --> CSRF cookie sent
INFO - 2019-11-14 14:37:31 --> CSRF token verified
INFO - 2019-11-14 14:37:32 --> Input Class Initialized
INFO - 2019-11-14 14:37:32 --> Language Class Initialized
INFO - 2019-11-14 14:37:32 --> Language Class Initialized
INFO - 2019-11-14 14:37:32 --> Config Class Initialized
INFO - 2019-11-14 14:37:32 --> Loader Class Initialized
INFO - 2019-11-14 14:37:32 --> Helper loaded: url_helper
INFO - 2019-11-14 14:37:32 --> Helper loaded: common_helper
INFO - 2019-11-14 14:37:32 --> Helper loaded: language_helper
INFO - 2019-11-14 14:37:32 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:37:32 --> Helper loaded: email_helper
INFO - 2019-11-14 14:37:32 --> Helper loaded: file_manager_helper
ERROR - 2019-11-14 14:37:32 --> Severity: error --> Exception: syntax error, unexpected '"', expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\language\english\common_lang.php 496
INFO - 2019-11-14 14:37:49 --> Config Class Initialized
INFO - 2019-11-14 14:37:49 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:37:49 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:37:49 --> Utf8 Class Initialized
INFO - 2019-11-14 14:37:49 --> URI Class Initialized
INFO - 2019-11-14 14:37:49 --> Router Class Initialized
INFO - 2019-11-14 14:37:49 --> Output Class Initialized
INFO - 2019-11-14 14:37:49 --> Security Class Initialized
DEBUG - 2019-11-14 14:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:37:49 --> CSRF cookie sent
INFO - 2019-11-14 14:37:49 --> CSRF token verified
INFO - 2019-11-14 14:37:49 --> Input Class Initialized
INFO - 2019-11-14 14:37:49 --> Language Class Initialized
INFO - 2019-11-14 14:37:49 --> Language Class Initialized
INFO - 2019-11-14 14:37:49 --> Config Class Initialized
INFO - 2019-11-14 14:37:49 --> Loader Class Initialized
INFO - 2019-11-14 14:37:49 --> Helper loaded: url_helper
INFO - 2019-11-14 14:37:49 --> Helper loaded: common_helper
INFO - 2019-11-14 14:37:49 --> Helper loaded: language_helper
INFO - 2019-11-14 14:37:49 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:37:49 --> Helper loaded: email_helper
INFO - 2019-11-14 14:37:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:37:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:37:49 --> Parser Class Initialized
INFO - 2019-11-14 14:37:49 --> User Agent Class Initialized
INFO - 2019-11-14 14:37:49 --> Model Class Initialized
INFO - 2019-11-14 14:37:49 --> Database Driver Class Initialized
INFO - 2019-11-14 14:37:49 --> Model Class Initialized
DEBUG - 2019-11-14 14:37:49 --> Template Class Initialized
INFO - 2019-11-14 14:37:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:37:49 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:37:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:37:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:37:49 --> Encryption Class Initialized
INFO - 2019-11-14 14:37:49 --> Controller Class Initialized
DEBUG - 2019-11-14 14:37:49 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:37:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:37:49 --> Model Class Initialized
INFO - 2019-11-14 14:37:49 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:37:49 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:37:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:37:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:37:49 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:37:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:37:49 --> Model Class Initialized
DEBUG - 2019-11-14 14:37:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:37:49 --> Model Class Initialized
DEBUG - 2019-11-14 14:37:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:37:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:37:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:37:50 --> Final output sent to browser
DEBUG - 2019-11-14 14:37:50 --> Total execution time: 0.7865
INFO - 2019-11-14 14:37:57 --> Config Class Initialized
INFO - 2019-11-14 14:37:57 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:37:57 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:37:57 --> Utf8 Class Initialized
INFO - 2019-11-14 14:37:57 --> URI Class Initialized
INFO - 2019-11-14 14:37:57 --> Router Class Initialized
INFO - 2019-11-14 14:37:57 --> Output Class Initialized
INFO - 2019-11-14 14:37:57 --> Security Class Initialized
DEBUG - 2019-11-14 14:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:37:57 --> CSRF cookie sent
INFO - 2019-11-14 14:37:57 --> CSRF token verified
INFO - 2019-11-14 14:37:57 --> Input Class Initialized
INFO - 2019-11-14 14:37:57 --> Language Class Initialized
INFO - 2019-11-14 14:37:57 --> Language Class Initialized
INFO - 2019-11-14 14:37:57 --> Config Class Initialized
INFO - 2019-11-14 14:37:57 --> Loader Class Initialized
INFO - 2019-11-14 14:37:57 --> Helper loaded: url_helper
INFO - 2019-11-14 14:37:57 --> Helper loaded: common_helper
INFO - 2019-11-14 14:37:57 --> Helper loaded: language_helper
INFO - 2019-11-14 14:37:57 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:37:57 --> Helper loaded: email_helper
INFO - 2019-11-14 14:37:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:37:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:37:57 --> Parser Class Initialized
INFO - 2019-11-14 14:37:57 --> User Agent Class Initialized
INFO - 2019-11-14 14:37:57 --> Model Class Initialized
INFO - 2019-11-14 14:37:57 --> Database Driver Class Initialized
INFO - 2019-11-14 14:37:57 --> Model Class Initialized
DEBUG - 2019-11-14 14:37:57 --> Template Class Initialized
INFO - 2019-11-14 14:37:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:37:57 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:37:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:37:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:37:57 --> Encryption Class Initialized
INFO - 2019-11-14 14:37:57 --> Controller Class Initialized
DEBUG - 2019-11-14 14:37:57 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:37:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:37:57 --> Model Class Initialized
DEBUG - 2019-11-14 14:37:57 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:37:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 14:37:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 14:37:57 --> Final output sent to browser
DEBUG - 2019-11-14 14:37:57 --> Total execution time: 0.5948
INFO - 2019-11-14 14:37:57 --> Config Class Initialized
INFO - 2019-11-14 14:37:57 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:37:57 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:37:57 --> Utf8 Class Initialized
INFO - 2019-11-14 14:37:58 --> URI Class Initialized
INFO - 2019-11-14 14:37:58 --> Router Class Initialized
INFO - 2019-11-14 14:37:58 --> Output Class Initialized
INFO - 2019-11-14 14:37:58 --> Security Class Initialized
DEBUG - 2019-11-14 14:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:37:58 --> CSRF cookie sent
INFO - 2019-11-14 14:37:58 --> Input Class Initialized
INFO - 2019-11-14 14:37:58 --> Language Class Initialized
INFO - 2019-11-14 14:37:58 --> Language Class Initialized
INFO - 2019-11-14 14:37:58 --> Config Class Initialized
INFO - 2019-11-14 14:37:58 --> Loader Class Initialized
INFO - 2019-11-14 14:37:58 --> Helper loaded: url_helper
INFO - 2019-11-14 14:37:58 --> Helper loaded: common_helper
INFO - 2019-11-14 14:37:58 --> Helper loaded: language_helper
INFO - 2019-11-14 14:37:58 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:37:58 --> Helper loaded: email_helper
INFO - 2019-11-14 14:37:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:37:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:37:58 --> Parser Class Initialized
INFO - 2019-11-14 14:37:58 --> User Agent Class Initialized
INFO - 2019-11-14 14:37:58 --> Model Class Initialized
INFO - 2019-11-14 14:37:58 --> Database Driver Class Initialized
INFO - 2019-11-14 14:37:58 --> Model Class Initialized
DEBUG - 2019-11-14 14:37:58 --> Template Class Initialized
INFO - 2019-11-14 14:37:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:37:58 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:37:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:37:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:37:58 --> Encryption Class Initialized
INFO - 2019-11-14 14:37:58 --> Controller Class Initialized
DEBUG - 2019-11-14 14:37:58 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-14 14:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-14 14:37:58 --> Model Class Initialized
INFO - 2019-11-14 14:37:58 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 14:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-14 14:37:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-14 14:37:58 --> Final output sent to browser
DEBUG - 2019-11-14 14:37:58 --> Total execution time: 0.5251
INFO - 2019-11-14 14:38:26 --> Config Class Initialized
INFO - 2019-11-14 14:38:26 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:38:26 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:38:26 --> Utf8 Class Initialized
INFO - 2019-11-14 14:38:26 --> URI Class Initialized
INFO - 2019-11-14 14:38:26 --> Router Class Initialized
INFO - 2019-11-14 14:38:26 --> Output Class Initialized
INFO - 2019-11-14 14:38:26 --> Security Class Initialized
DEBUG - 2019-11-14 14:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:38:26 --> CSRF cookie sent
INFO - 2019-11-14 14:38:26 --> CSRF token verified
INFO - 2019-11-14 14:38:26 --> Input Class Initialized
INFO - 2019-11-14 14:38:26 --> Language Class Initialized
INFO - 2019-11-14 14:38:26 --> Language Class Initialized
INFO - 2019-11-14 14:38:26 --> Config Class Initialized
INFO - 2019-11-14 14:38:26 --> Loader Class Initialized
INFO - 2019-11-14 14:38:26 --> Helper loaded: url_helper
INFO - 2019-11-14 14:38:26 --> Helper loaded: common_helper
INFO - 2019-11-14 14:38:26 --> Helper loaded: language_helper
INFO - 2019-11-14 14:38:26 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:38:26 --> Helper loaded: email_helper
INFO - 2019-11-14 14:38:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:38:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:38:26 --> Parser Class Initialized
INFO - 2019-11-14 14:38:26 --> User Agent Class Initialized
INFO - 2019-11-14 14:38:26 --> Model Class Initialized
INFO - 2019-11-14 14:38:26 --> Database Driver Class Initialized
INFO - 2019-11-14 14:38:26 --> Model Class Initialized
DEBUG - 2019-11-14 14:38:26 --> Template Class Initialized
INFO - 2019-11-14 14:38:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:38:26 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:38:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:38:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:38:26 --> Encryption Class Initialized
INFO - 2019-11-14 14:38:26 --> Controller Class Initialized
DEBUG - 2019-11-14 14:38:26 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:38:26 --> Model Class Initialized
INFO - 2019-11-14 14:38:26 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:38:26 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:38:26 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:38:26 --> Model Class Initialized
DEBUG - 2019-11-14 14:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:38:26 --> Model Class Initialized
DEBUG - 2019-11-14 14:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:38:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:38:26 --> Final output sent to browser
DEBUG - 2019-11-14 14:38:26 --> Total execution time: 0.7111
INFO - 2019-11-14 14:38:33 --> Config Class Initialized
INFO - 2019-11-14 14:38:33 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:38:34 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:38:34 --> Utf8 Class Initialized
INFO - 2019-11-14 14:38:34 --> URI Class Initialized
INFO - 2019-11-14 14:38:34 --> Router Class Initialized
INFO - 2019-11-14 14:38:34 --> Output Class Initialized
INFO - 2019-11-14 14:38:34 --> Security Class Initialized
DEBUG - 2019-11-14 14:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:38:34 --> CSRF cookie sent
INFO - 2019-11-14 14:38:34 --> CSRF token verified
INFO - 2019-11-14 14:38:34 --> Input Class Initialized
INFO - 2019-11-14 14:38:34 --> Language Class Initialized
INFO - 2019-11-14 14:38:34 --> Language Class Initialized
INFO - 2019-11-14 14:38:34 --> Config Class Initialized
INFO - 2019-11-14 14:38:34 --> Loader Class Initialized
INFO - 2019-11-14 14:38:34 --> Helper loaded: url_helper
INFO - 2019-11-14 14:38:34 --> Helper loaded: common_helper
INFO - 2019-11-14 14:38:34 --> Helper loaded: language_helper
INFO - 2019-11-14 14:38:34 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:38:34 --> Helper loaded: email_helper
INFO - 2019-11-14 14:38:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:38:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:38:34 --> Parser Class Initialized
INFO - 2019-11-14 14:38:34 --> User Agent Class Initialized
INFO - 2019-11-14 14:38:34 --> Model Class Initialized
INFO - 2019-11-14 14:38:34 --> Database Driver Class Initialized
INFO - 2019-11-14 14:38:34 --> Model Class Initialized
DEBUG - 2019-11-14 14:38:34 --> Template Class Initialized
INFO - 2019-11-14 14:38:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:38:34 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:38:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:38:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:38:34 --> Encryption Class Initialized
INFO - 2019-11-14 14:38:34 --> Controller Class Initialized
DEBUG - 2019-11-14 14:38:34 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:38:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:38:34 --> Model Class Initialized
DEBUG - 2019-11-14 14:38:34 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:38:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 14:38:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 14:38:34 --> Final output sent to browser
DEBUG - 2019-11-14 14:38:34 --> Total execution time: 0.5870
INFO - 2019-11-14 14:40:53 --> Config Class Initialized
INFO - 2019-11-14 14:40:53 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:40:53 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:40:53 --> Utf8 Class Initialized
INFO - 2019-11-14 14:40:53 --> URI Class Initialized
INFO - 2019-11-14 14:40:53 --> Router Class Initialized
INFO - 2019-11-14 14:40:53 --> Output Class Initialized
INFO - 2019-11-14 14:40:53 --> Security Class Initialized
DEBUG - 2019-11-14 14:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:40:53 --> Input Class Initialized
INFO - 2019-11-14 14:40:53 --> Language Class Initialized
INFO - 2019-11-14 14:40:53 --> Language Class Initialized
INFO - 2019-11-14 14:40:53 --> Config Class Initialized
INFO - 2019-11-14 14:40:53 --> Loader Class Initialized
INFO - 2019-11-14 14:40:53 --> Helper loaded: url_helper
INFO - 2019-11-14 14:40:53 --> Helper loaded: common_helper
INFO - 2019-11-14 14:40:53 --> Helper loaded: language_helper
INFO - 2019-11-14 14:40:53 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:40:53 --> Helper loaded: email_helper
INFO - 2019-11-14 14:40:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:40:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:40:53 --> Parser Class Initialized
INFO - 2019-11-14 14:40:53 --> User Agent Class Initialized
INFO - 2019-11-14 14:40:53 --> Model Class Initialized
INFO - 2019-11-14 14:40:53 --> Database Driver Class Initialized
INFO - 2019-11-14 14:40:53 --> Model Class Initialized
DEBUG - 2019-11-14 14:40:53 --> Template Class Initialized
INFO - 2019-11-14 14:40:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:40:53 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:40:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:40:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:40:53 --> Encryption Class Initialized
INFO - 2019-11-14 14:40:53 --> Controller Class Initialized
DEBUG - 2019-11-14 14:40:53 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:40:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
INFO - 2019-11-14 14:40:53 --> Model Class Initialized
INFO - 2019-11-14 14:43:17 --> Config Class Initialized
INFO - 2019-11-14 14:43:17 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:43:17 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:43:17 --> Utf8 Class Initialized
INFO - 2019-11-14 14:43:17 --> URI Class Initialized
INFO - 2019-11-14 14:43:17 --> Router Class Initialized
INFO - 2019-11-14 14:43:17 --> Output Class Initialized
INFO - 2019-11-14 14:43:17 --> Security Class Initialized
DEBUG - 2019-11-14 14:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:43:17 --> CSRF cookie sent
INFO - 2019-11-14 14:43:17 --> CSRF token verified
INFO - 2019-11-14 14:43:17 --> Input Class Initialized
INFO - 2019-11-14 14:43:17 --> Language Class Initialized
INFO - 2019-11-14 14:43:17 --> Language Class Initialized
INFO - 2019-11-14 14:43:17 --> Config Class Initialized
INFO - 2019-11-14 14:43:17 --> Loader Class Initialized
INFO - 2019-11-14 14:43:17 --> Helper loaded: url_helper
INFO - 2019-11-14 14:43:17 --> Helper loaded: common_helper
INFO - 2019-11-14 14:43:17 --> Helper loaded: language_helper
INFO - 2019-11-14 14:43:17 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:43:17 --> Helper loaded: email_helper
INFO - 2019-11-14 14:43:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:43:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:43:18 --> Parser Class Initialized
INFO - 2019-11-14 14:43:18 --> User Agent Class Initialized
INFO - 2019-11-14 14:43:18 --> Model Class Initialized
INFO - 2019-11-14 14:43:18 --> Database Driver Class Initialized
INFO - 2019-11-14 14:43:18 --> Model Class Initialized
DEBUG - 2019-11-14 14:43:18 --> Template Class Initialized
INFO - 2019-11-14 14:43:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:43:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:43:18 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:43:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:43:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:43:18 --> Encryption Class Initialized
INFO - 2019-11-14 14:43:18 --> Controller Class Initialized
DEBUG - 2019-11-14 14:43:18 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:43:18 --> Model Class Initialized
INFO - 2019-11-14 14:43:18 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:43:18 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:43:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:43:18 --> Model Class Initialized
DEBUG - 2019-11-14 14:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:43:18 --> Model Class Initialized
DEBUG - 2019-11-14 14:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:43:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:43:18 --> Final output sent to browser
DEBUG - 2019-11-14 14:43:18 --> Total execution time: 0.8383
INFO - 2019-11-14 14:43:26 --> Config Class Initialized
INFO - 2019-11-14 14:43:26 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:43:26 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:43:26 --> Utf8 Class Initialized
INFO - 2019-11-14 14:43:26 --> URI Class Initialized
INFO - 2019-11-14 14:43:26 --> Router Class Initialized
INFO - 2019-11-14 14:43:26 --> Output Class Initialized
INFO - 2019-11-14 14:43:26 --> Security Class Initialized
DEBUG - 2019-11-14 14:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:43:26 --> CSRF cookie sent
INFO - 2019-11-14 14:43:26 --> CSRF token verified
INFO - 2019-11-14 14:43:26 --> Input Class Initialized
INFO - 2019-11-14 14:43:26 --> Language Class Initialized
INFO - 2019-11-14 14:43:26 --> Language Class Initialized
INFO - 2019-11-14 14:43:26 --> Config Class Initialized
INFO - 2019-11-14 14:43:26 --> Loader Class Initialized
INFO - 2019-11-14 14:43:26 --> Helper loaded: url_helper
INFO - 2019-11-14 14:43:26 --> Helper loaded: common_helper
INFO - 2019-11-14 14:43:26 --> Helper loaded: language_helper
INFO - 2019-11-14 14:43:26 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:43:26 --> Helper loaded: email_helper
INFO - 2019-11-14 14:43:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:43:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:43:26 --> Parser Class Initialized
INFO - 2019-11-14 14:43:26 --> User Agent Class Initialized
INFO - 2019-11-14 14:43:26 --> Model Class Initialized
INFO - 2019-11-14 14:43:26 --> Database Driver Class Initialized
INFO - 2019-11-14 14:43:26 --> Model Class Initialized
DEBUG - 2019-11-14 14:43:26 --> Template Class Initialized
INFO - 2019-11-14 14:43:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:43:26 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:43:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:43:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:43:26 --> Encryption Class Initialized
INFO - 2019-11-14 14:43:26 --> Controller Class Initialized
DEBUG - 2019-11-14 14:43:26 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:43:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:43:26 --> Model Class Initialized
DEBUG - 2019-11-14 14:43:26 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:43:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 14:43:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 14:43:26 --> Final output sent to browser
DEBUG - 2019-11-14 14:43:26 --> Total execution time: 0.5707
INFO - 2019-11-14 14:45:08 --> Config Class Initialized
INFO - 2019-11-14 14:45:08 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:45:08 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:45:08 --> Utf8 Class Initialized
INFO - 2019-11-14 14:45:08 --> URI Class Initialized
INFO - 2019-11-14 14:45:08 --> Router Class Initialized
INFO - 2019-11-14 14:45:08 --> Output Class Initialized
INFO - 2019-11-14 14:45:08 --> Security Class Initialized
DEBUG - 2019-11-14 14:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:45:08 --> CSRF cookie sent
INFO - 2019-11-14 14:45:08 --> CSRF token verified
INFO - 2019-11-14 14:45:08 --> Input Class Initialized
INFO - 2019-11-14 14:45:08 --> Language Class Initialized
INFO - 2019-11-14 14:45:08 --> Language Class Initialized
INFO - 2019-11-14 14:45:08 --> Config Class Initialized
INFO - 2019-11-14 14:45:08 --> Loader Class Initialized
INFO - 2019-11-14 14:45:08 --> Helper loaded: url_helper
INFO - 2019-11-14 14:45:08 --> Helper loaded: common_helper
INFO - 2019-11-14 14:45:08 --> Helper loaded: language_helper
INFO - 2019-11-14 14:45:08 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:45:08 --> Helper loaded: email_helper
INFO - 2019-11-14 14:45:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:45:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:45:08 --> Parser Class Initialized
INFO - 2019-11-14 14:45:08 --> User Agent Class Initialized
INFO - 2019-11-14 14:45:08 --> Model Class Initialized
INFO - 2019-11-14 14:45:08 --> Database Driver Class Initialized
INFO - 2019-11-14 14:45:08 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:08 --> Template Class Initialized
INFO - 2019-11-14 14:45:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:45:08 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:45:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:45:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:45:08 --> Encryption Class Initialized
INFO - 2019-11-14 14:45:08 --> Controller Class Initialized
DEBUG - 2019-11-14 14:45:08 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:45:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:45:08 --> Model Class Initialized
INFO - 2019-11-14 14:45:08 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:45:09 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:45:09 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:45:09 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:45:09 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:45:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:45:09 --> Final output sent to browser
DEBUG - 2019-11-14 14:45:09 --> Total execution time: 0.9075
INFO - 2019-11-14 14:45:16 --> Config Class Initialized
INFO - 2019-11-14 14:45:16 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:45:16 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:45:16 --> Utf8 Class Initialized
INFO - 2019-11-14 14:45:16 --> URI Class Initialized
INFO - 2019-11-14 14:45:16 --> Router Class Initialized
INFO - 2019-11-14 14:45:16 --> Output Class Initialized
INFO - 2019-11-14 14:45:16 --> Security Class Initialized
DEBUG - 2019-11-14 14:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:45:16 --> CSRF cookie sent
INFO - 2019-11-14 14:45:16 --> CSRF token verified
INFO - 2019-11-14 14:45:16 --> Input Class Initialized
INFO - 2019-11-14 14:45:16 --> Language Class Initialized
INFO - 2019-11-14 14:45:16 --> Language Class Initialized
INFO - 2019-11-14 14:45:16 --> Config Class Initialized
INFO - 2019-11-14 14:45:16 --> Loader Class Initialized
INFO - 2019-11-14 14:45:16 --> Helper loaded: url_helper
INFO - 2019-11-14 14:45:16 --> Helper loaded: common_helper
INFO - 2019-11-14 14:45:16 --> Helper loaded: language_helper
INFO - 2019-11-14 14:45:16 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:45:16 --> Helper loaded: email_helper
INFO - 2019-11-14 14:45:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:45:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:45:16 --> Parser Class Initialized
INFO - 2019-11-14 14:45:16 --> User Agent Class Initialized
INFO - 2019-11-14 14:45:16 --> Model Class Initialized
INFO - 2019-11-14 14:45:16 --> Database Driver Class Initialized
INFO - 2019-11-14 14:45:16 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:16 --> Template Class Initialized
INFO - 2019-11-14 14:45:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:45:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:45:16 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:45:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:45:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:45:16 --> Encryption Class Initialized
INFO - 2019-11-14 14:45:16 --> Controller Class Initialized
DEBUG - 2019-11-14 14:45:16 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:45:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:45:16 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:16 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:45:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 14:45:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 14:45:16 --> Final output sent to browser
DEBUG - 2019-11-14 14:45:16 --> Total execution time: 0.5786
INFO - 2019-11-14 14:45:16 --> Config Class Initialized
INFO - 2019-11-14 14:45:17 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:45:17 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:45:17 --> Utf8 Class Initialized
INFO - 2019-11-14 14:45:17 --> URI Class Initialized
INFO - 2019-11-14 14:45:17 --> Router Class Initialized
INFO - 2019-11-14 14:45:17 --> Output Class Initialized
INFO - 2019-11-14 14:45:17 --> Security Class Initialized
DEBUG - 2019-11-14 14:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:45:17 --> CSRF cookie sent
INFO - 2019-11-14 14:45:17 --> Input Class Initialized
INFO - 2019-11-14 14:45:17 --> Language Class Initialized
INFO - 2019-11-14 14:45:17 --> Language Class Initialized
INFO - 2019-11-14 14:45:17 --> Config Class Initialized
INFO - 2019-11-14 14:45:17 --> Loader Class Initialized
INFO - 2019-11-14 14:45:17 --> Helper loaded: url_helper
INFO - 2019-11-14 14:45:17 --> Helper loaded: common_helper
INFO - 2019-11-14 14:45:17 --> Helper loaded: language_helper
INFO - 2019-11-14 14:45:17 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:45:17 --> Helper loaded: email_helper
INFO - 2019-11-14 14:45:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:45:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:45:17 --> Parser Class Initialized
INFO - 2019-11-14 14:45:17 --> User Agent Class Initialized
INFO - 2019-11-14 14:45:17 --> Model Class Initialized
INFO - 2019-11-14 14:45:17 --> Database Driver Class Initialized
INFO - 2019-11-14 14:45:17 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:17 --> Template Class Initialized
INFO - 2019-11-14 14:45:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:45:17 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:45:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:45:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:45:17 --> Encryption Class Initialized
INFO - 2019-11-14 14:45:17 --> Controller Class Initialized
DEBUG - 2019-11-14 14:45:17 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-14 14:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-14 14:45:17 --> Model Class Initialized
INFO - 2019-11-14 14:45:17 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 14:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-14 14:45:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-14 14:45:17 --> Final output sent to browser
DEBUG - 2019-11-14 14:45:17 --> Total execution time: 0.5782
INFO - 2019-11-14 14:45:38 --> Config Class Initialized
INFO - 2019-11-14 14:45:38 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:45:39 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:45:39 --> Utf8 Class Initialized
INFO - 2019-11-14 14:45:39 --> URI Class Initialized
INFO - 2019-11-14 14:45:39 --> Router Class Initialized
INFO - 2019-11-14 14:45:39 --> Output Class Initialized
INFO - 2019-11-14 14:45:39 --> Security Class Initialized
DEBUG - 2019-11-14 14:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:45:39 --> CSRF cookie sent
INFO - 2019-11-14 14:45:39 --> CSRF token verified
INFO - 2019-11-14 14:45:39 --> Input Class Initialized
INFO - 2019-11-14 14:45:39 --> Language Class Initialized
INFO - 2019-11-14 14:45:39 --> Language Class Initialized
INFO - 2019-11-14 14:45:39 --> Config Class Initialized
INFO - 2019-11-14 14:45:39 --> Loader Class Initialized
INFO - 2019-11-14 14:45:39 --> Helper loaded: url_helper
INFO - 2019-11-14 14:45:39 --> Helper loaded: common_helper
INFO - 2019-11-14 14:45:39 --> Helper loaded: language_helper
INFO - 2019-11-14 14:45:39 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:45:39 --> Helper loaded: email_helper
INFO - 2019-11-14 14:45:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:45:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:45:39 --> Parser Class Initialized
INFO - 2019-11-14 14:45:39 --> User Agent Class Initialized
INFO - 2019-11-14 14:45:39 --> Model Class Initialized
INFO - 2019-11-14 14:45:39 --> Database Driver Class Initialized
INFO - 2019-11-14 14:45:39 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:39 --> Template Class Initialized
INFO - 2019-11-14 14:45:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:45:39 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:45:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:45:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:45:39 --> Encryption Class Initialized
INFO - 2019-11-14 14:45:39 --> Controller Class Initialized
DEBUG - 2019-11-14 14:45:39 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:45:39 --> Model Class Initialized
INFO - 2019-11-14 14:45:39 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:45:39 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:45:39 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:45:39 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:45:39 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:45:39 --> Final output sent to browser
DEBUG - 2019-11-14 14:45:40 --> Total execution time: 1.0232
INFO - 2019-11-14 14:45:50 --> Config Class Initialized
INFO - 2019-11-14 14:45:50 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:45:50 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:45:50 --> Utf8 Class Initialized
INFO - 2019-11-14 14:45:50 --> URI Class Initialized
INFO - 2019-11-14 14:45:50 --> Router Class Initialized
INFO - 2019-11-14 14:45:50 --> Output Class Initialized
INFO - 2019-11-14 14:45:50 --> Security Class Initialized
DEBUG - 2019-11-14 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:45:50 --> CSRF cookie sent
INFO - 2019-11-14 14:45:50 --> CSRF token verified
INFO - 2019-11-14 14:45:50 --> Input Class Initialized
INFO - 2019-11-14 14:45:50 --> Language Class Initialized
INFO - 2019-11-14 14:45:50 --> Language Class Initialized
INFO - 2019-11-14 14:45:50 --> Config Class Initialized
INFO - 2019-11-14 14:45:50 --> Loader Class Initialized
INFO - 2019-11-14 14:45:50 --> Helper loaded: url_helper
INFO - 2019-11-14 14:45:51 --> Helper loaded: common_helper
INFO - 2019-11-14 14:45:51 --> Helper loaded: language_helper
INFO - 2019-11-14 14:45:51 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:45:51 --> Helper loaded: email_helper
INFO - 2019-11-14 14:45:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:45:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:45:51 --> Parser Class Initialized
INFO - 2019-11-14 14:45:51 --> User Agent Class Initialized
INFO - 2019-11-14 14:45:51 --> Model Class Initialized
INFO - 2019-11-14 14:45:51 --> Database Driver Class Initialized
INFO - 2019-11-14 14:45:51 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:51 --> Template Class Initialized
INFO - 2019-11-14 14:45:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:45:51 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:45:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:45:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:45:51 --> Encryption Class Initialized
INFO - 2019-11-14 14:45:51 --> Controller Class Initialized
DEBUG - 2019-11-14 14:45:51 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:45:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:45:51 --> Model Class Initialized
DEBUG - 2019-11-14 14:45:51 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:45:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 14:45:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 14:45:51 --> Final output sent to browser
DEBUG - 2019-11-14 14:45:51 --> Total execution time: 0.6247
INFO - 2019-11-14 14:46:23 --> Config Class Initialized
INFO - 2019-11-14 14:46:23 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:46:23 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:46:23 --> Utf8 Class Initialized
INFO - 2019-11-14 14:46:24 --> URI Class Initialized
INFO - 2019-11-14 14:46:24 --> Router Class Initialized
INFO - 2019-11-14 14:46:24 --> Output Class Initialized
INFO - 2019-11-14 14:46:24 --> Security Class Initialized
DEBUG - 2019-11-14 14:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:46:24 --> CSRF cookie sent
INFO - 2019-11-14 14:46:24 --> Input Class Initialized
INFO - 2019-11-14 14:46:24 --> Language Class Initialized
INFO - 2019-11-14 14:46:24 --> Language Class Initialized
INFO - 2019-11-14 14:46:24 --> Config Class Initialized
INFO - 2019-11-14 14:46:24 --> Loader Class Initialized
INFO - 2019-11-14 14:46:24 --> Helper loaded: url_helper
INFO - 2019-11-14 14:46:24 --> Helper loaded: common_helper
INFO - 2019-11-14 14:46:24 --> Helper loaded: language_helper
INFO - 2019-11-14 14:46:24 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:46:24 --> Helper loaded: email_helper
INFO - 2019-11-14 14:46:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:46:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:46:24 --> Parser Class Initialized
INFO - 2019-11-14 14:46:24 --> User Agent Class Initialized
INFO - 2019-11-14 14:46:24 --> Model Class Initialized
INFO - 2019-11-14 14:46:24 --> Database Driver Class Initialized
INFO - 2019-11-14 14:46:24 --> Model Class Initialized
DEBUG - 2019-11-14 14:46:24 --> Template Class Initialized
INFO - 2019-11-14 14:46:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:46:24 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:46:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:46:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:46:24 --> Encryption Class Initialized
INFO - 2019-11-14 14:46:24 --> Controller Class Initialized
DEBUG - 2019-11-14 14:46:24 --> custom_page MX_Controller Initialized
DEBUG - 2019-11-14 14:46:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-11-14 14:46:24 --> Model Class Initialized
INFO - 2019-11-14 14:46:24 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 14:46:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-11-14 14:46:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-11-14 14:46:24 --> Final output sent to browser
DEBUG - 2019-11-14 14:46:24 --> Total execution time: 0.5548
INFO - 2019-11-14 14:46:42 --> Config Class Initialized
INFO - 2019-11-14 14:46:42 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:46:42 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:46:42 --> Utf8 Class Initialized
INFO - 2019-11-14 14:46:42 --> URI Class Initialized
INFO - 2019-11-14 14:46:42 --> Router Class Initialized
INFO - 2019-11-14 14:46:42 --> Output Class Initialized
INFO - 2019-11-14 14:46:42 --> Security Class Initialized
DEBUG - 2019-11-14 14:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:46:42 --> CSRF cookie sent
INFO - 2019-11-14 14:46:42 --> CSRF token verified
INFO - 2019-11-14 14:46:42 --> Input Class Initialized
INFO - 2019-11-14 14:46:42 --> Language Class Initialized
INFO - 2019-11-14 14:46:42 --> Language Class Initialized
INFO - 2019-11-14 14:46:42 --> Config Class Initialized
INFO - 2019-11-14 14:46:42 --> Loader Class Initialized
INFO - 2019-11-14 14:46:42 --> Helper loaded: url_helper
INFO - 2019-11-14 14:46:42 --> Helper loaded: common_helper
INFO - 2019-11-14 14:46:42 --> Helper loaded: language_helper
INFO - 2019-11-14 14:46:42 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:46:42 --> Helper loaded: email_helper
INFO - 2019-11-14 14:46:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:46:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:46:42 --> Parser Class Initialized
INFO - 2019-11-14 14:46:42 --> User Agent Class Initialized
INFO - 2019-11-14 14:46:42 --> Model Class Initialized
INFO - 2019-11-14 14:46:42 --> Database Driver Class Initialized
INFO - 2019-11-14 14:46:42 --> Model Class Initialized
DEBUG - 2019-11-14 14:46:42 --> Template Class Initialized
INFO - 2019-11-14 14:46:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:46:42 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:46:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:46:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:46:42 --> Encryption Class Initialized
INFO - 2019-11-14 14:46:42 --> Controller Class Initialized
DEBUG - 2019-11-14 14:46:42 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:46:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:46:42 --> Model Class Initialized
INFO - 2019-11-14 14:46:42 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 14:46:42 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 14:46:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 14:46:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 14:46:43 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 14:46:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 14:46:43 --> Model Class Initialized
DEBUG - 2019-11-14 14:46:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 14:46:43 --> Model Class Initialized
DEBUG - 2019-11-14 14:46:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 14:46:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 14:46:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 14:46:43 --> Final output sent to browser
DEBUG - 2019-11-14 14:46:43 --> Total execution time: 0.8226
INFO - 2019-11-14 14:46:49 --> Config Class Initialized
INFO - 2019-11-14 14:46:49 --> Hooks Class Initialized
DEBUG - 2019-11-14 14:46:49 --> UTF-8 Support Enabled
INFO - 2019-11-14 14:46:49 --> Utf8 Class Initialized
INFO - 2019-11-14 14:46:49 --> URI Class Initialized
INFO - 2019-11-14 14:46:49 --> Router Class Initialized
INFO - 2019-11-14 14:46:49 --> Output Class Initialized
INFO - 2019-11-14 14:46:49 --> Security Class Initialized
DEBUG - 2019-11-14 14:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 14:46:49 --> CSRF cookie sent
INFO - 2019-11-14 14:46:49 --> CSRF token verified
INFO - 2019-11-14 14:46:49 --> Input Class Initialized
INFO - 2019-11-14 14:46:50 --> Language Class Initialized
INFO - 2019-11-14 14:46:50 --> Language Class Initialized
INFO - 2019-11-14 14:46:50 --> Config Class Initialized
INFO - 2019-11-14 14:46:50 --> Loader Class Initialized
INFO - 2019-11-14 14:46:50 --> Helper loaded: url_helper
INFO - 2019-11-14 14:46:50 --> Helper loaded: common_helper
INFO - 2019-11-14 14:46:50 --> Helper loaded: language_helper
INFO - 2019-11-14 14:46:50 --> Helper loaded: cookie_helper
INFO - 2019-11-14 14:46:50 --> Helper loaded: email_helper
INFO - 2019-11-14 14:46:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 14:46:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 14:46:50 --> Parser Class Initialized
INFO - 2019-11-14 14:46:50 --> User Agent Class Initialized
INFO - 2019-11-14 14:46:50 --> Model Class Initialized
INFO - 2019-11-14 14:46:50 --> Database Driver Class Initialized
INFO - 2019-11-14 14:46:50 --> Model Class Initialized
DEBUG - 2019-11-14 14:46:50 --> Template Class Initialized
INFO - 2019-11-14 14:46:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 14:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 14:46:50 --> Pagination Class Initialized
DEBUG - 2019-11-14 14:46:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 14:46:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 14:46:50 --> Encryption Class Initialized
INFO - 2019-11-14 14:46:50 --> Controller Class Initialized
DEBUG - 2019-11-14 14:46:50 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 14:46:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 14:46:50 --> Model Class Initialized
DEBUG - 2019-11-14 14:46:50 --> shopier MX_Controller Initialized
DEBUG - 2019-11-14 14:46:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/shopierapi.php
DEBUG - 2019-11-14 14:46:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/shopier/index.php
INFO - 2019-11-14 14:46:50 --> Final output sent to browser
DEBUG - 2019-11-14 14:46:50 --> Total execution time: 0.6834
INFO - 2019-11-14 15:14:41 --> Config Class Initialized
INFO - 2019-11-14 15:14:41 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:14:41 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:14:41 --> Utf8 Class Initialized
INFO - 2019-11-14 15:14:41 --> URI Class Initialized
INFO - 2019-11-14 15:14:41 --> Router Class Initialized
INFO - 2019-11-14 15:14:41 --> Output Class Initialized
INFO - 2019-11-14 15:14:41 --> Security Class Initialized
DEBUG - 2019-11-14 15:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:14:41 --> CSRF cookie sent
INFO - 2019-11-14 15:14:41 --> CSRF token verified
INFO - 2019-11-14 15:14:41 --> Input Class Initialized
INFO - 2019-11-14 15:14:41 --> Language Class Initialized
INFO - 2019-11-14 15:14:41 --> Language Class Initialized
INFO - 2019-11-14 15:14:41 --> Config Class Initialized
INFO - 2019-11-14 15:14:41 --> Loader Class Initialized
INFO - 2019-11-14 15:14:41 --> Helper loaded: url_helper
INFO - 2019-11-14 15:14:41 --> Helper loaded: common_helper
INFO - 2019-11-14 15:14:41 --> Helper loaded: language_helper
INFO - 2019-11-14 15:14:41 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:14:41 --> Helper loaded: email_helper
INFO - 2019-11-14 15:14:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:14:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:14:41 --> Parser Class Initialized
INFO - 2019-11-14 15:14:41 --> User Agent Class Initialized
INFO - 2019-11-14 15:14:41 --> Model Class Initialized
INFO - 2019-11-14 15:14:41 --> Database Driver Class Initialized
INFO - 2019-11-14 15:14:41 --> Model Class Initialized
DEBUG - 2019-11-14 15:14:41 --> Template Class Initialized
INFO - 2019-11-14 15:14:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:14:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:14:41 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:14:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:14:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:14:41 --> Encryption Class Initialized
INFO - 2019-11-14 15:14:41 --> Controller Class Initialized
DEBUG - 2019-11-14 15:14:41 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:14:41 --> Model Class Initialized
INFO - 2019-11-14 15:14:41 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:14:41 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 15:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 15:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:14:41 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:14:41 --> Model Class Initialized
DEBUG - 2019-11-14 15:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:14:41 --> Model Class Initialized
DEBUG - 2019-11-14 15:14:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:14:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:14:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:14:42 --> Final output sent to browser
DEBUG - 2019-11-14 15:14:42 --> Total execution time: 0.8862
INFO - 2019-11-14 15:14:56 --> Config Class Initialized
INFO - 2019-11-14 15:14:56 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:14:56 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:14:56 --> Utf8 Class Initialized
INFO - 2019-11-14 15:14:56 --> URI Class Initialized
INFO - 2019-11-14 15:14:56 --> Router Class Initialized
INFO - 2019-11-14 15:14:56 --> Output Class Initialized
INFO - 2019-11-14 15:14:56 --> Security Class Initialized
DEBUG - 2019-11-14 15:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:14:56 --> CSRF cookie sent
INFO - 2019-11-14 15:14:56 --> CSRF token verified
INFO - 2019-11-14 15:14:56 --> Input Class Initialized
INFO - 2019-11-14 15:14:56 --> Language Class Initialized
INFO - 2019-11-14 15:14:56 --> Language Class Initialized
INFO - 2019-11-14 15:14:56 --> Config Class Initialized
INFO - 2019-11-14 15:14:56 --> Loader Class Initialized
INFO - 2019-11-14 15:14:56 --> Helper loaded: url_helper
INFO - 2019-11-14 15:14:56 --> Helper loaded: common_helper
INFO - 2019-11-14 15:14:56 --> Helper loaded: language_helper
INFO - 2019-11-14 15:14:56 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:14:57 --> Helper loaded: email_helper
INFO - 2019-11-14 15:14:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:14:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:14:57 --> Parser Class Initialized
INFO - 2019-11-14 15:14:57 --> User Agent Class Initialized
INFO - 2019-11-14 15:14:57 --> Model Class Initialized
INFO - 2019-11-14 15:14:57 --> Database Driver Class Initialized
INFO - 2019-11-14 15:14:57 --> Model Class Initialized
DEBUG - 2019-11-14 15:14:57 --> Template Class Initialized
INFO - 2019-11-14 15:14:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:14:57 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:14:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:14:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:14:57 --> Encryption Class Initialized
INFO - 2019-11-14 15:14:57 --> Controller Class Initialized
DEBUG - 2019-11-14 15:14:57 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:14:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:14:57 --> Model Class Initialized
DEBUG - 2019-11-14 15:14:57 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:14:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:14:59 --> orders MX_Controller Initialized
INFO - 2019-11-14 15:14:59 --> Config Class Initialized
INFO - 2019-11-14 15:14:59 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:14:59 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:14:59 --> Utf8 Class Initialized
INFO - 2019-11-14 15:14:59 --> URI Class Initialized
INFO - 2019-11-14 15:14:59 --> Router Class Initialized
INFO - 2019-11-14 15:14:59 --> Output Class Initialized
INFO - 2019-11-14 15:14:59 --> Security Class Initialized
DEBUG - 2019-11-14 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:14:59 --> CSRF cookie sent
INFO - 2019-11-14 15:14:59 --> Input Class Initialized
INFO - 2019-11-14 15:14:59 --> Language Class Initialized
INFO - 2019-11-14 15:14:59 --> Language Class Initialized
INFO - 2019-11-14 15:14:59 --> Config Class Initialized
INFO - 2019-11-14 15:14:59 --> Loader Class Initialized
INFO - 2019-11-14 15:14:59 --> Helper loaded: url_helper
INFO - 2019-11-14 15:14:59 --> Helper loaded: common_helper
INFO - 2019-11-14 15:14:59 --> Helper loaded: language_helper
INFO - 2019-11-14 15:14:59 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:14:59 --> Helper loaded: email_helper
INFO - 2019-11-14 15:14:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:14:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:14:59 --> Parser Class Initialized
INFO - 2019-11-14 15:14:59 --> User Agent Class Initialized
INFO - 2019-11-14 15:14:59 --> Model Class Initialized
INFO - 2019-11-14 15:15:00 --> Database Driver Class Initialized
INFO - 2019-11-14 15:15:00 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:00 --> Template Class Initialized
INFO - 2019-11-14 15:15:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:15:00 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:15:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:15:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:15:00 --> Encryption Class Initialized
INFO - 2019-11-14 15:15:00 --> Controller Class Initialized
DEBUG - 2019-11-14 15:15:00 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:15:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:15:00 --> Model Class Initialized
INFO - 2019-11-14 15:15:00 --> Config Class Initialized
INFO - 2019-11-14 15:15:00 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:15:00 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:15:00 --> Utf8 Class Initialized
INFO - 2019-11-14 15:15:00 --> URI Class Initialized
DEBUG - 2019-11-14 15:15:00 --> No URI present. Default controller set.
INFO - 2019-11-14 15:15:00 --> Router Class Initialized
INFO - 2019-11-14 15:15:00 --> Output Class Initialized
INFO - 2019-11-14 15:15:00 --> Security Class Initialized
DEBUG - 2019-11-14 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:15:00 --> CSRF cookie sent
INFO - 2019-11-14 15:15:00 --> Input Class Initialized
INFO - 2019-11-14 15:15:00 --> Language Class Initialized
INFO - 2019-11-14 15:15:00 --> Language Class Initialized
INFO - 2019-11-14 15:15:00 --> Config Class Initialized
INFO - 2019-11-14 15:15:00 --> Loader Class Initialized
INFO - 2019-11-14 15:15:00 --> Helper loaded: url_helper
INFO - 2019-11-14 15:15:00 --> Helper loaded: common_helper
INFO - 2019-11-14 15:15:00 --> Helper loaded: language_helper
INFO - 2019-11-14 15:15:00 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:15:00 --> Helper loaded: email_helper
INFO - 2019-11-14 15:15:00 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:15:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:15:00 --> Parser Class Initialized
INFO - 2019-11-14 15:15:00 --> User Agent Class Initialized
INFO - 2019-11-14 15:15:00 --> Model Class Initialized
INFO - 2019-11-14 15:15:00 --> Database Driver Class Initialized
INFO - 2019-11-14 15:15:00 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:00 --> Template Class Initialized
INFO - 2019-11-14 15:15:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:15:00 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:15:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:15:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:15:00 --> Encryption Class Initialized
DEBUG - 2019-11-14 15:15:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 15:15:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-14 15:15:00 --> Controller Class Initialized
DEBUG - 2019-11-14 15:15:00 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 15:15:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 15:15:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-14 15:15:00 --> Model Class Initialized
INFO - 2019-11-14 15:15:00 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:15:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 15:15:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 15:15:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-14 15:15:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-14 15:15:01 --> Final output sent to browser
DEBUG - 2019-11-14 15:15:01 --> Total execution time: 0.8459
INFO - 2019-11-14 15:15:17 --> Config Class Initialized
INFO - 2019-11-14 15:15:17 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:15:17 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:15:17 --> Utf8 Class Initialized
INFO - 2019-11-14 15:15:17 --> URI Class Initialized
INFO - 2019-11-14 15:15:17 --> Router Class Initialized
INFO - 2019-11-14 15:15:17 --> Output Class Initialized
INFO - 2019-11-14 15:15:17 --> Security Class Initialized
DEBUG - 2019-11-14 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:15:17 --> CSRF cookie sent
INFO - 2019-11-14 15:15:17 --> Input Class Initialized
INFO - 2019-11-14 15:15:17 --> Language Class Initialized
INFO - 2019-11-14 15:15:17 --> Language Class Initialized
INFO - 2019-11-14 15:15:17 --> Config Class Initialized
INFO - 2019-11-14 15:15:17 --> Loader Class Initialized
INFO - 2019-11-14 15:15:17 --> Helper loaded: url_helper
INFO - 2019-11-14 15:15:17 --> Helper loaded: common_helper
INFO - 2019-11-14 15:15:17 --> Helper loaded: language_helper
INFO - 2019-11-14 15:15:17 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:15:17 --> Helper loaded: email_helper
INFO - 2019-11-14 15:15:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:15:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:15:17 --> Parser Class Initialized
INFO - 2019-11-14 15:15:17 --> User Agent Class Initialized
INFO - 2019-11-14 15:15:17 --> Model Class Initialized
INFO - 2019-11-14 15:15:17 --> Database Driver Class Initialized
INFO - 2019-11-14 15:15:17 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:17 --> Template Class Initialized
INFO - 2019-11-14 15:15:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:15:17 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:15:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:15:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:15:17 --> Encryption Class Initialized
INFO - 2019-11-14 15:15:17 --> Controller Class Initialized
DEBUG - 2019-11-14 15:15:17 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:15:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:15:17 --> Model Class Initialized
ERROR - 2019-11-14 15:15:17 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:15:17 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:15:17 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:15:17 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:15:17 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:15:17 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:17 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:15:18 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:18 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:18 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:18 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:18 --> Could not find the language line "Pending"
DEBUG - 2019-11-14 15:15:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:15:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:15:18 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:15:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:15:18 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:15:18 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:15:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:15:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:15:18 --> Final output sent to browser
DEBUG - 2019-11-14 15:15:18 --> Total execution time: 1.0565
INFO - 2019-11-14 15:15:20 --> Config Class Initialized
INFO - 2019-11-14 15:15:20 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:15:20 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:15:21 --> Utf8 Class Initialized
INFO - 2019-11-14 15:15:21 --> URI Class Initialized
INFO - 2019-11-14 15:15:21 --> Router Class Initialized
INFO - 2019-11-14 15:15:21 --> Output Class Initialized
INFO - 2019-11-14 15:15:21 --> Security Class Initialized
DEBUG - 2019-11-14 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:15:21 --> CSRF cookie sent
INFO - 2019-11-14 15:15:21 --> Input Class Initialized
INFO - 2019-11-14 15:15:21 --> Language Class Initialized
INFO - 2019-11-14 15:15:21 --> Language Class Initialized
INFO - 2019-11-14 15:15:21 --> Config Class Initialized
INFO - 2019-11-14 15:15:21 --> Loader Class Initialized
INFO - 2019-11-14 15:15:21 --> Helper loaded: url_helper
INFO - 2019-11-14 15:15:21 --> Helper loaded: common_helper
INFO - 2019-11-14 15:15:21 --> Helper loaded: language_helper
INFO - 2019-11-14 15:15:21 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:15:21 --> Helper loaded: email_helper
INFO - 2019-11-14 15:15:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:15:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:15:21 --> Parser Class Initialized
INFO - 2019-11-14 15:15:21 --> User Agent Class Initialized
INFO - 2019-11-14 15:15:21 --> Model Class Initialized
INFO - 2019-11-14 15:15:21 --> Database Driver Class Initialized
INFO - 2019-11-14 15:15:21 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:21 --> Template Class Initialized
INFO - 2019-11-14 15:15:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:15:21 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:15:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:15:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:15:21 --> Encryption Class Initialized
INFO - 2019-11-14 15:15:21 --> Controller Class Initialized
DEBUG - 2019-11-14 15:15:21 --> transactions MX_Controller Initialized
DEBUG - 2019-11-14 15:15:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-14 15:15:21 --> Model Class Initialized
ERROR - 2019-11-14 15:15:21 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:15:21 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:15:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-14 15:15:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:15:21 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:15:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:15:21 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:15:21 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:15:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:15:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:15:21 --> Final output sent to browser
DEBUG - 2019-11-14 15:15:21 --> Total execution time: 0.8035
INFO - 2019-11-14 15:15:30 --> Config Class Initialized
INFO - 2019-11-14 15:15:30 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:15:30 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:15:30 --> Utf8 Class Initialized
INFO - 2019-11-14 15:15:30 --> URI Class Initialized
INFO - 2019-11-14 15:15:30 --> Router Class Initialized
INFO - 2019-11-14 15:15:30 --> Output Class Initialized
INFO - 2019-11-14 15:15:30 --> Security Class Initialized
DEBUG - 2019-11-14 15:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:15:30 --> CSRF cookie sent
INFO - 2019-11-14 15:15:30 --> Input Class Initialized
INFO - 2019-11-14 15:15:30 --> Language Class Initialized
INFO - 2019-11-14 15:15:30 --> Language Class Initialized
INFO - 2019-11-14 15:15:30 --> Config Class Initialized
INFO - 2019-11-14 15:15:30 --> Loader Class Initialized
INFO - 2019-11-14 15:15:30 --> Helper loaded: url_helper
INFO - 2019-11-14 15:15:30 --> Helper loaded: common_helper
INFO - 2019-11-14 15:15:30 --> Helper loaded: language_helper
INFO - 2019-11-14 15:15:30 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:15:30 --> Helper loaded: email_helper
INFO - 2019-11-14 15:15:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:15:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:15:30 --> Parser Class Initialized
INFO - 2019-11-14 15:15:30 --> User Agent Class Initialized
INFO - 2019-11-14 15:15:30 --> Model Class Initialized
INFO - 2019-11-14 15:15:30 --> Database Driver Class Initialized
INFO - 2019-11-14 15:15:30 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:30 --> Template Class Initialized
INFO - 2019-11-14 15:15:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:15:30 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:15:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:15:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:15:30 --> Encryption Class Initialized
INFO - 2019-11-14 15:15:30 --> Controller Class Initialized
DEBUG - 2019-11-14 15:15:30 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:15:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:15:30 --> Model Class Initialized
ERROR - 2019-11-14 15:15:30 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:15:30 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:15:31 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:15:31 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:15:31 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:15:31 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:31 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:15:31 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:31 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:31 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:31 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:15:31 --> Could not find the language line "Pending"
DEBUG - 2019-11-14 15:15:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:15:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:15:31 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:15:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:15:31 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:15:31 --> Model Class Initialized
DEBUG - 2019-11-14 15:15:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:15:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:15:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:15:31 --> Final output sent to browser
DEBUG - 2019-11-14 15:15:31 --> Total execution time: 1.0027
INFO - 2019-11-14 15:16:12 --> Config Class Initialized
INFO - 2019-11-14 15:16:12 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:16:12 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:16:12 --> Utf8 Class Initialized
INFO - 2019-11-14 15:16:12 --> URI Class Initialized
INFO - 2019-11-14 15:16:12 --> Router Class Initialized
INFO - 2019-11-14 15:16:12 --> Output Class Initialized
INFO - 2019-11-14 15:16:12 --> Security Class Initialized
DEBUG - 2019-11-14 15:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:16:12 --> CSRF cookie sent
INFO - 2019-11-14 15:16:12 --> CSRF token verified
INFO - 2019-11-14 15:16:12 --> Input Class Initialized
INFO - 2019-11-14 15:16:12 --> Language Class Initialized
INFO - 2019-11-14 15:16:12 --> Language Class Initialized
INFO - 2019-11-14 15:16:12 --> Config Class Initialized
INFO - 2019-11-14 15:16:12 --> Loader Class Initialized
INFO - 2019-11-14 15:16:12 --> Helper loaded: url_helper
INFO - 2019-11-14 15:16:12 --> Helper loaded: common_helper
INFO - 2019-11-14 15:16:12 --> Helper loaded: language_helper
INFO - 2019-11-14 15:16:12 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:16:12 --> Helper loaded: email_helper
INFO - 2019-11-14 15:16:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:16:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:16:12 --> Parser Class Initialized
INFO - 2019-11-14 15:16:12 --> User Agent Class Initialized
INFO - 2019-11-14 15:16:12 --> Model Class Initialized
INFO - 2019-11-14 15:16:13 --> Database Driver Class Initialized
INFO - 2019-11-14 15:16:13 --> Model Class Initialized
DEBUG - 2019-11-14 15:16:13 --> Template Class Initialized
INFO - 2019-11-14 15:16:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:16:13 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:16:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:16:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:16:13 --> Encryption Class Initialized
INFO - 2019-11-14 15:16:13 --> Controller Class Initialized
DEBUG - 2019-11-14 15:16:13 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:16:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:16:13 --> Model Class Initialized
INFO - 2019-11-14 15:16:13 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:16:13 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 15:16:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 15:16:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:16:13 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:16:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:16:13 --> Model Class Initialized
DEBUG - 2019-11-14 15:16:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:16:13 --> Model Class Initialized
DEBUG - 2019-11-14 15:16:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:16:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:16:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:16:13 --> Final output sent to browser
DEBUG - 2019-11-14 15:16:13 --> Total execution time: 1.0665
INFO - 2019-11-14 15:16:21 --> Config Class Initialized
INFO - 2019-11-14 15:16:21 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:16:21 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:16:21 --> Utf8 Class Initialized
INFO - 2019-11-14 15:16:21 --> URI Class Initialized
INFO - 2019-11-14 15:16:21 --> Router Class Initialized
INFO - 2019-11-14 15:16:21 --> Output Class Initialized
INFO - 2019-11-14 15:16:21 --> Security Class Initialized
DEBUG - 2019-11-14 15:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:16:21 --> CSRF cookie sent
INFO - 2019-11-14 15:16:21 --> CSRF token verified
INFO - 2019-11-14 15:16:21 --> Input Class Initialized
INFO - 2019-11-14 15:16:21 --> Language Class Initialized
INFO - 2019-11-14 15:16:21 --> Language Class Initialized
INFO - 2019-11-14 15:16:21 --> Config Class Initialized
INFO - 2019-11-14 15:16:21 --> Loader Class Initialized
INFO - 2019-11-14 15:16:21 --> Helper loaded: url_helper
INFO - 2019-11-14 15:16:21 --> Helper loaded: common_helper
INFO - 2019-11-14 15:16:21 --> Helper loaded: language_helper
INFO - 2019-11-14 15:16:21 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:16:21 --> Helper loaded: email_helper
INFO - 2019-11-14 15:16:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:16:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:16:21 --> Parser Class Initialized
INFO - 2019-11-14 15:16:21 --> User Agent Class Initialized
INFO - 2019-11-14 15:16:21 --> Model Class Initialized
INFO - 2019-11-14 15:16:21 --> Database Driver Class Initialized
INFO - 2019-11-14 15:16:21 --> Model Class Initialized
DEBUG - 2019-11-14 15:16:21 --> Template Class Initialized
INFO - 2019-11-14 15:16:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:16:21 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:16:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:16:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:16:21 --> Encryption Class Initialized
INFO - 2019-11-14 15:16:21 --> Controller Class Initialized
DEBUG - 2019-11-14 15:16:21 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:16:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:16:21 --> Model Class Initialized
DEBUG - 2019-11-14 15:16:21 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:16:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:16:22 --> orders MX_Controller Initialized
DEBUG - 2019-11-14 15:16:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-14 15:16:23 --> Final output sent to browser
DEBUG - 2019-11-14 15:16:23 --> Total execution time: 1.9226
INFO - 2019-11-14 15:16:36 --> Config Class Initialized
INFO - 2019-11-14 15:16:37 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:16:37 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:16:37 --> Utf8 Class Initialized
INFO - 2019-11-14 15:16:37 --> URI Class Initialized
INFO - 2019-11-14 15:16:37 --> Router Class Initialized
INFO - 2019-11-14 15:16:37 --> Output Class Initialized
INFO - 2019-11-14 15:16:37 --> Security Class Initialized
DEBUG - 2019-11-14 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:16:37 --> Input Class Initialized
INFO - 2019-11-14 15:16:37 --> Language Class Initialized
INFO - 2019-11-14 15:16:37 --> Language Class Initialized
INFO - 2019-11-14 15:16:37 --> Config Class Initialized
INFO - 2019-11-14 15:16:37 --> Loader Class Initialized
INFO - 2019-11-14 15:16:37 --> Helper loaded: url_helper
INFO - 2019-11-14 15:16:37 --> Helper loaded: common_helper
INFO - 2019-11-14 15:16:37 --> Helper loaded: language_helper
INFO - 2019-11-14 15:16:37 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:16:37 --> Helper loaded: email_helper
INFO - 2019-11-14 15:16:37 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:16:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:16:37 --> Parser Class Initialized
INFO - 2019-11-14 15:16:37 --> User Agent Class Initialized
INFO - 2019-11-14 15:16:37 --> Model Class Initialized
INFO - 2019-11-14 15:16:37 --> Database Driver Class Initialized
INFO - 2019-11-14 15:16:37 --> Model Class Initialized
DEBUG - 2019-11-14 15:16:37 --> Template Class Initialized
INFO - 2019-11-14 15:16:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:16:37 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:16:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:16:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:16:37 --> Encryption Class Initialized
INFO - 2019-11-14 15:16:37 --> Controller Class Initialized
DEBUG - 2019-11-14 15:16:37 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:16:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:16:37 --> Model Class Initialized
INFO - 2019-11-14 15:16:38 --> Config Class Initialized
INFO - 2019-11-14 15:16:38 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:16:38 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:16:38 --> Utf8 Class Initialized
INFO - 2019-11-14 15:16:38 --> URI Class Initialized
INFO - 2019-11-14 15:16:38 --> Router Class Initialized
INFO - 2019-11-14 15:16:38 --> Output Class Initialized
INFO - 2019-11-14 15:16:38 --> Security Class Initialized
DEBUG - 2019-11-14 15:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:16:38 --> CSRF cookie sent
INFO - 2019-11-14 15:16:38 --> Input Class Initialized
INFO - 2019-11-14 15:16:38 --> Language Class Initialized
INFO - 2019-11-14 15:16:38 --> Language Class Initialized
INFO - 2019-11-14 15:16:38 --> Config Class Initialized
INFO - 2019-11-14 15:16:38 --> Loader Class Initialized
INFO - 2019-11-14 15:16:38 --> Helper loaded: url_helper
INFO - 2019-11-14 15:16:38 --> Helper loaded: common_helper
INFO - 2019-11-14 15:16:38 --> Helper loaded: language_helper
INFO - 2019-11-14 15:16:38 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:16:39 --> Helper loaded: email_helper
INFO - 2019-11-14 15:16:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:16:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:16:39 --> Parser Class Initialized
INFO - 2019-11-14 15:16:39 --> User Agent Class Initialized
INFO - 2019-11-14 15:16:39 --> Model Class Initialized
INFO - 2019-11-14 15:16:39 --> Database Driver Class Initialized
INFO - 2019-11-14 15:16:39 --> Model Class Initialized
DEBUG - 2019-11-14 15:16:39 --> Template Class Initialized
INFO - 2019-11-14 15:16:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:16:39 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:16:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:16:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:16:39 --> Encryption Class Initialized
INFO - 2019-11-14 15:16:39 --> Controller Class Initialized
DEBUG - 2019-11-14 15:16:39 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:16:39 --> Model Class Initialized
INFO - 2019-11-14 15:16:39 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-11-14 15:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:16:39 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:16:39 --> Model Class Initialized
DEBUG - 2019-11-14 15:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:16:39 --> Model Class Initialized
DEBUG - 2019-11-14 15:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:16:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:16:39 --> Final output sent to browser
DEBUG - 2019-11-14 15:16:39 --> Total execution time: 0.8913
INFO - 2019-11-14 15:18:35 --> Config Class Initialized
INFO - 2019-11-14 15:18:35 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:18:35 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:18:35 --> Utf8 Class Initialized
INFO - 2019-11-14 15:18:35 --> URI Class Initialized
INFO - 2019-11-14 15:18:35 --> Router Class Initialized
INFO - 2019-11-14 15:18:35 --> Output Class Initialized
INFO - 2019-11-14 15:18:35 --> Security Class Initialized
DEBUG - 2019-11-14 15:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:18:35 --> CSRF cookie sent
INFO - 2019-11-14 15:18:35 --> Input Class Initialized
INFO - 2019-11-14 15:18:35 --> Language Class Initialized
INFO - 2019-11-14 15:18:35 --> Language Class Initialized
INFO - 2019-11-14 15:18:35 --> Config Class Initialized
INFO - 2019-11-14 15:18:35 --> Loader Class Initialized
INFO - 2019-11-14 15:18:35 --> Helper loaded: url_helper
INFO - 2019-11-14 15:18:35 --> Helper loaded: common_helper
INFO - 2019-11-14 15:18:35 --> Helper loaded: language_helper
INFO - 2019-11-14 15:18:35 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:18:35 --> Helper loaded: email_helper
INFO - 2019-11-14 15:18:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:18:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:18:35 --> Parser Class Initialized
INFO - 2019-11-14 15:18:35 --> User Agent Class Initialized
INFO - 2019-11-14 15:18:35 --> Model Class Initialized
INFO - 2019-11-14 15:18:35 --> Database Driver Class Initialized
INFO - 2019-11-14 15:18:35 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:35 --> Template Class Initialized
INFO - 2019-11-14 15:18:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:18:35 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:18:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:18:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:18:35 --> Encryption Class Initialized
INFO - 2019-11-14 15:18:35 --> Controller Class Initialized
DEBUG - 2019-11-14 15:18:35 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:18:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:18:35 --> Model Class Initialized
INFO - 2019-11-14 15:18:35 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:18:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-11-14 15:18:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:18:35 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:18:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:18:36 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:18:36 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:18:36 --> Final output sent to browser
DEBUG - 2019-11-14 15:18:36 --> Total execution time: 0.9031
INFO - 2019-11-14 15:18:39 --> Config Class Initialized
INFO - 2019-11-14 15:18:39 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:18:39 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:18:39 --> Utf8 Class Initialized
INFO - 2019-11-14 15:18:39 --> URI Class Initialized
INFO - 2019-11-14 15:18:39 --> Router Class Initialized
INFO - 2019-11-14 15:18:39 --> Output Class Initialized
INFO - 2019-11-14 15:18:39 --> Security Class Initialized
DEBUG - 2019-11-14 15:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:18:39 --> CSRF cookie sent
INFO - 2019-11-14 15:18:39 --> Input Class Initialized
INFO - 2019-11-14 15:18:39 --> Language Class Initialized
INFO - 2019-11-14 15:18:39 --> Language Class Initialized
INFO - 2019-11-14 15:18:39 --> Config Class Initialized
INFO - 2019-11-14 15:18:39 --> Loader Class Initialized
INFO - 2019-11-14 15:18:39 --> Helper loaded: url_helper
INFO - 2019-11-14 15:18:39 --> Helper loaded: common_helper
INFO - 2019-11-14 15:18:39 --> Helper loaded: language_helper
INFO - 2019-11-14 15:18:39 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:18:39 --> Helper loaded: email_helper
INFO - 2019-11-14 15:18:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:18:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:18:39 --> Parser Class Initialized
INFO - 2019-11-14 15:18:39 --> User Agent Class Initialized
INFO - 2019-11-14 15:18:39 --> Model Class Initialized
INFO - 2019-11-14 15:18:39 --> Database Driver Class Initialized
INFO - 2019-11-14 15:18:39 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:39 --> Template Class Initialized
INFO - 2019-11-14 15:18:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:18:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:18:39 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:18:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:18:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:18:39 --> Encryption Class Initialized
INFO - 2019-11-14 15:18:39 --> Controller Class Initialized
DEBUG - 2019-11-14 15:18:39 --> package MX_Controller Initialized
DEBUG - 2019-11-14 15:18:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-14 15:18:39 --> Model Class Initialized
INFO - 2019-11-14 15:18:39 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:18:40 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:18:40 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:18:40 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-14 15:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-14 15:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:18:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:18:40 --> Final output sent to browser
DEBUG - 2019-11-14 15:18:40 --> Total execution time: 0.9516
INFO - 2019-11-14 15:18:43 --> Config Class Initialized
INFO - 2019-11-14 15:18:43 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:18:43 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:18:43 --> Utf8 Class Initialized
INFO - 2019-11-14 15:18:43 --> URI Class Initialized
INFO - 2019-11-14 15:18:43 --> Router Class Initialized
INFO - 2019-11-14 15:18:43 --> Output Class Initialized
INFO - 2019-11-14 15:18:43 --> Security Class Initialized
DEBUG - 2019-11-14 15:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:18:43 --> CSRF cookie sent
INFO - 2019-11-14 15:18:43 --> CSRF token verified
INFO - 2019-11-14 15:18:43 --> Input Class Initialized
INFO - 2019-11-14 15:18:43 --> Language Class Initialized
INFO - 2019-11-14 15:18:43 --> Language Class Initialized
INFO - 2019-11-14 15:18:43 --> Config Class Initialized
INFO - 2019-11-14 15:18:43 --> Loader Class Initialized
INFO - 2019-11-14 15:18:43 --> Helper loaded: url_helper
INFO - 2019-11-14 15:18:43 --> Helper loaded: common_helper
INFO - 2019-11-14 15:18:43 --> Helper loaded: language_helper
INFO - 2019-11-14 15:18:43 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:18:43 --> Helper loaded: email_helper
INFO - 2019-11-14 15:18:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:18:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:18:43 --> Parser Class Initialized
INFO - 2019-11-14 15:18:43 --> User Agent Class Initialized
INFO - 2019-11-14 15:18:43 --> Model Class Initialized
INFO - 2019-11-14 15:18:43 --> Database Driver Class Initialized
INFO - 2019-11-14 15:18:43 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:43 --> Template Class Initialized
INFO - 2019-11-14 15:18:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:18:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:18:43 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:18:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:18:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:18:43 --> Encryption Class Initialized
INFO - 2019-11-14 15:18:43 --> Controller Class Initialized
DEBUG - 2019-11-14 15:18:43 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:18:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:18:43 --> Model Class Initialized
INFO - 2019-11-14 15:18:43 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:18:43 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 15:18:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 15:18:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:18:43 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:18:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:18:43 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:18:44 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:18:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:18:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:18:44 --> Final output sent to browser
DEBUG - 2019-11-14 15:18:44 --> Total execution time: 1.0531
INFO - 2019-11-14 15:18:52 --> Config Class Initialized
INFO - 2019-11-14 15:18:52 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:18:52 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:18:52 --> Utf8 Class Initialized
INFO - 2019-11-14 15:18:52 --> URI Class Initialized
INFO - 2019-11-14 15:18:52 --> Router Class Initialized
INFO - 2019-11-14 15:18:52 --> Output Class Initialized
INFO - 2019-11-14 15:18:53 --> Security Class Initialized
DEBUG - 2019-11-14 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:18:53 --> CSRF cookie sent
INFO - 2019-11-14 15:18:53 --> CSRF token verified
INFO - 2019-11-14 15:18:53 --> Input Class Initialized
INFO - 2019-11-14 15:18:53 --> Language Class Initialized
INFO - 2019-11-14 15:18:53 --> Language Class Initialized
INFO - 2019-11-14 15:18:53 --> Config Class Initialized
INFO - 2019-11-14 15:18:53 --> Loader Class Initialized
INFO - 2019-11-14 15:18:53 --> Helper loaded: url_helper
INFO - 2019-11-14 15:18:53 --> Helper loaded: common_helper
INFO - 2019-11-14 15:18:53 --> Helper loaded: language_helper
INFO - 2019-11-14 15:18:53 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:18:53 --> Helper loaded: email_helper
INFO - 2019-11-14 15:18:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:18:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:18:53 --> Parser Class Initialized
INFO - 2019-11-14 15:18:53 --> User Agent Class Initialized
INFO - 2019-11-14 15:18:53 --> Model Class Initialized
INFO - 2019-11-14 15:18:53 --> Database Driver Class Initialized
INFO - 2019-11-14 15:18:53 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:53 --> Template Class Initialized
INFO - 2019-11-14 15:18:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:18:53 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:18:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:18:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:18:53 --> Encryption Class Initialized
INFO - 2019-11-14 15:18:53 --> Controller Class Initialized
DEBUG - 2019-11-14 15:18:53 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:18:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:18:53 --> Model Class Initialized
DEBUG - 2019-11-14 15:18:53 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:18:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:18:54 --> orders MX_Controller Initialized
DEBUG - 2019-11-14 15:18:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-14 15:18:54 --> Final output sent to browser
DEBUG - 2019-11-14 15:18:54 --> Total execution time: 1.7667
INFO - 2019-11-14 15:19:02 --> Config Class Initialized
INFO - 2019-11-14 15:19:02 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:19:02 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:19:02 --> Utf8 Class Initialized
INFO - 2019-11-14 15:19:02 --> URI Class Initialized
INFO - 2019-11-14 15:19:02 --> Router Class Initialized
INFO - 2019-11-14 15:19:02 --> Output Class Initialized
INFO - 2019-11-14 15:19:02 --> Security Class Initialized
DEBUG - 2019-11-14 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:19:02 --> Input Class Initialized
INFO - 2019-11-14 15:19:02 --> Language Class Initialized
INFO - 2019-11-14 15:19:02 --> Language Class Initialized
INFO - 2019-11-14 15:19:02 --> Config Class Initialized
INFO - 2019-11-14 15:19:02 --> Loader Class Initialized
INFO - 2019-11-14 15:19:02 --> Helper loaded: url_helper
INFO - 2019-11-14 15:19:02 --> Helper loaded: common_helper
INFO - 2019-11-14 15:19:02 --> Helper loaded: language_helper
INFO - 2019-11-14 15:19:02 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:19:02 --> Helper loaded: email_helper
INFO - 2019-11-14 15:19:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:19:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:19:02 --> Parser Class Initialized
INFO - 2019-11-14 15:19:02 --> User Agent Class Initialized
INFO - 2019-11-14 15:19:02 --> Model Class Initialized
INFO - 2019-11-14 15:19:02 --> Database Driver Class Initialized
INFO - 2019-11-14 15:19:02 --> Model Class Initialized
DEBUG - 2019-11-14 15:19:02 --> Template Class Initialized
INFO - 2019-11-14 15:19:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:19:02 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:19:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:19:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:19:02 --> Encryption Class Initialized
INFO - 2019-11-14 15:19:03 --> Controller Class Initialized
DEBUG - 2019-11-14 15:19:03 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:19:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:19:03 --> Model Class Initialized
INFO - 2019-11-14 15:19:04 --> Config Class Initialized
INFO - 2019-11-14 15:19:04 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:19:04 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:19:04 --> Utf8 Class Initialized
INFO - 2019-11-14 15:19:04 --> URI Class Initialized
INFO - 2019-11-14 15:19:04 --> Router Class Initialized
INFO - 2019-11-14 15:19:04 --> Output Class Initialized
INFO - 2019-11-14 15:19:04 --> Security Class Initialized
DEBUG - 2019-11-14 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:19:04 --> CSRF cookie sent
INFO - 2019-11-14 15:19:04 --> Input Class Initialized
INFO - 2019-11-14 15:19:04 --> Language Class Initialized
INFO - 2019-11-14 15:19:04 --> Language Class Initialized
INFO - 2019-11-14 15:19:04 --> Config Class Initialized
INFO - 2019-11-14 15:19:04 --> Loader Class Initialized
INFO - 2019-11-14 15:19:04 --> Helper loaded: url_helper
INFO - 2019-11-14 15:19:04 --> Helper loaded: common_helper
INFO - 2019-11-14 15:19:04 --> Helper loaded: language_helper
INFO - 2019-11-14 15:19:04 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:19:04 --> Helper loaded: email_helper
INFO - 2019-11-14 15:19:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:19:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:19:04 --> Parser Class Initialized
INFO - 2019-11-14 15:19:04 --> User Agent Class Initialized
INFO - 2019-11-14 15:19:04 --> Model Class Initialized
INFO - 2019-11-14 15:19:04 --> Database Driver Class Initialized
INFO - 2019-11-14 15:19:04 --> Model Class Initialized
DEBUG - 2019-11-14 15:19:04 --> Template Class Initialized
INFO - 2019-11-14 15:19:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:19:04 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:19:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:19:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:19:04 --> Encryption Class Initialized
INFO - 2019-11-14 15:19:04 --> Controller Class Initialized
DEBUG - 2019-11-14 15:19:04 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:19:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:19:04 --> Model Class Initialized
INFO - 2019-11-14 15:19:04 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:19:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-11-14 15:19:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:19:04 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:19:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:19:04 --> Model Class Initialized
DEBUG - 2019-11-14 15:19:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:19:04 --> Model Class Initialized
DEBUG - 2019-11-14 15:19:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:19:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:19:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:19:04 --> Final output sent to browser
DEBUG - 2019-11-14 15:19:05 --> Total execution time: 0.8584
INFO - 2019-11-14 15:20:04 --> Config Class Initialized
INFO - 2019-11-14 15:20:04 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:20:04 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:20:04 --> Utf8 Class Initialized
INFO - 2019-11-14 15:20:04 --> URI Class Initialized
INFO - 2019-11-14 15:20:04 --> Router Class Initialized
INFO - 2019-11-14 15:20:04 --> Output Class Initialized
INFO - 2019-11-14 15:20:04 --> Security Class Initialized
DEBUG - 2019-11-14 15:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:20:04 --> CSRF cookie sent
INFO - 2019-11-14 15:20:04 --> Input Class Initialized
INFO - 2019-11-14 15:20:04 --> Language Class Initialized
INFO - 2019-11-14 15:20:04 --> Language Class Initialized
INFO - 2019-11-14 15:20:04 --> Config Class Initialized
INFO - 2019-11-14 15:20:04 --> Loader Class Initialized
INFO - 2019-11-14 15:20:04 --> Helper loaded: url_helper
INFO - 2019-11-14 15:20:04 --> Helper loaded: common_helper
INFO - 2019-11-14 15:20:04 --> Helper loaded: language_helper
INFO - 2019-11-14 15:20:04 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:20:04 --> Helper loaded: email_helper
INFO - 2019-11-14 15:20:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:20:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:20:04 --> Parser Class Initialized
INFO - 2019-11-14 15:20:04 --> User Agent Class Initialized
INFO - 2019-11-14 15:20:04 --> Model Class Initialized
INFO - 2019-11-14 15:20:04 --> Database Driver Class Initialized
INFO - 2019-11-14 15:20:04 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:04 --> Template Class Initialized
INFO - 2019-11-14 15:20:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:20:04 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:20:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:20:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:20:04 --> Encryption Class Initialized
INFO - 2019-11-14 15:20:04 --> Controller Class Initialized
DEBUG - 2019-11-14 15:20:04 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:20:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:20:04 --> Model Class Initialized
ERROR - 2019-11-14 15:20:04 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:20:04 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:20:04 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:20:04 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:20:04 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:20:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:20:05 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:20:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:20:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:20:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:20:05 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:20:05 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-14 15:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:20:05 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:20:05 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:20:05 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:20:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:20:05 --> Final output sent to browser
DEBUG - 2019-11-14 15:20:05 --> Total execution time: 1.2027
INFO - 2019-11-14 15:20:11 --> Config Class Initialized
INFO - 2019-11-14 15:20:11 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:20:11 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:20:11 --> Utf8 Class Initialized
INFO - 2019-11-14 15:20:11 --> URI Class Initialized
INFO - 2019-11-14 15:20:11 --> Router Class Initialized
INFO - 2019-11-14 15:20:11 --> Output Class Initialized
INFO - 2019-11-14 15:20:11 --> Security Class Initialized
DEBUG - 2019-11-14 15:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:20:11 --> CSRF cookie sent
INFO - 2019-11-14 15:20:11 --> CSRF token verified
INFO - 2019-11-14 15:20:11 --> Input Class Initialized
INFO - 2019-11-14 15:20:11 --> Language Class Initialized
INFO - 2019-11-14 15:20:11 --> Language Class Initialized
INFO - 2019-11-14 15:20:11 --> Config Class Initialized
INFO - 2019-11-14 15:20:11 --> Loader Class Initialized
INFO - 2019-11-14 15:20:11 --> Helper loaded: url_helper
INFO - 2019-11-14 15:20:11 --> Helper loaded: common_helper
INFO - 2019-11-14 15:20:11 --> Helper loaded: language_helper
INFO - 2019-11-14 15:20:11 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:20:11 --> Helper loaded: email_helper
INFO - 2019-11-14 15:20:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:20:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:20:11 --> Parser Class Initialized
INFO - 2019-11-14 15:20:11 --> User Agent Class Initialized
INFO - 2019-11-14 15:20:11 --> Model Class Initialized
INFO - 2019-11-14 15:20:11 --> Database Driver Class Initialized
INFO - 2019-11-14 15:20:11 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:11 --> Template Class Initialized
INFO - 2019-11-14 15:20:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:20:11 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:20:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:20:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:20:11 --> Encryption Class Initialized
INFO - 2019-11-14 15:20:11 --> Controller Class Initialized
DEBUG - 2019-11-14 15:20:11 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:20:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:20:11 --> Model Class Initialized
ERROR - 2019-11-14 15:20:11 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:20:11 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:20:11 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:20:11 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:20:16 --> Config Class Initialized
INFO - 2019-11-14 15:20:16 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:20:16 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:20:16 --> Utf8 Class Initialized
INFO - 2019-11-14 15:20:16 --> URI Class Initialized
INFO - 2019-11-14 15:20:16 --> Router Class Initialized
INFO - 2019-11-14 15:20:16 --> Output Class Initialized
INFO - 2019-11-14 15:20:16 --> Security Class Initialized
DEBUG - 2019-11-14 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:20:16 --> CSRF cookie sent
INFO - 2019-11-14 15:20:16 --> CSRF token verified
INFO - 2019-11-14 15:20:16 --> Input Class Initialized
INFO - 2019-11-14 15:20:16 --> Language Class Initialized
INFO - 2019-11-14 15:20:16 --> Language Class Initialized
INFO - 2019-11-14 15:20:16 --> Config Class Initialized
INFO - 2019-11-14 15:20:16 --> Loader Class Initialized
INFO - 2019-11-14 15:20:16 --> Helper loaded: url_helper
INFO - 2019-11-14 15:20:16 --> Helper loaded: common_helper
INFO - 2019-11-14 15:20:16 --> Helper loaded: language_helper
INFO - 2019-11-14 15:20:16 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:20:16 --> Helper loaded: email_helper
INFO - 2019-11-14 15:20:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:20:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:20:16 --> Parser Class Initialized
INFO - 2019-11-14 15:20:16 --> User Agent Class Initialized
INFO - 2019-11-14 15:20:16 --> Model Class Initialized
INFO - 2019-11-14 15:20:16 --> Database Driver Class Initialized
INFO - 2019-11-14 15:20:16 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:16 --> Template Class Initialized
INFO - 2019-11-14 15:20:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:20:17 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:20:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:20:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:20:17 --> Encryption Class Initialized
INFO - 2019-11-14 15:20:17 --> Controller Class Initialized
DEBUG - 2019-11-14 15:20:17 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:20:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:20:17 --> Model Class Initialized
ERROR - 2019-11-14 15:20:17 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:20:17 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:20:17 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:20:17 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:20:21 --> Config Class Initialized
INFO - 2019-11-14 15:20:21 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:20:21 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:20:21 --> Utf8 Class Initialized
INFO - 2019-11-14 15:20:21 --> URI Class Initialized
INFO - 2019-11-14 15:20:21 --> Router Class Initialized
INFO - 2019-11-14 15:20:21 --> Output Class Initialized
INFO - 2019-11-14 15:20:21 --> Security Class Initialized
DEBUG - 2019-11-14 15:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:20:21 --> CSRF cookie sent
INFO - 2019-11-14 15:20:21 --> CSRF token verified
INFO - 2019-11-14 15:20:21 --> Input Class Initialized
INFO - 2019-11-14 15:20:21 --> Language Class Initialized
INFO - 2019-11-14 15:20:21 --> Language Class Initialized
INFO - 2019-11-14 15:20:21 --> Config Class Initialized
INFO - 2019-11-14 15:20:21 --> Loader Class Initialized
INFO - 2019-11-14 15:20:22 --> Helper loaded: url_helper
INFO - 2019-11-14 15:20:22 --> Helper loaded: common_helper
INFO - 2019-11-14 15:20:22 --> Helper loaded: language_helper
INFO - 2019-11-14 15:20:22 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:20:22 --> Helper loaded: email_helper
INFO - 2019-11-14 15:20:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:20:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:20:22 --> Parser Class Initialized
INFO - 2019-11-14 15:20:22 --> User Agent Class Initialized
INFO - 2019-11-14 15:20:22 --> Model Class Initialized
INFO - 2019-11-14 15:20:22 --> Database Driver Class Initialized
INFO - 2019-11-14 15:20:22 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:22 --> Template Class Initialized
INFO - 2019-11-14 15:20:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:20:22 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:20:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:20:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:20:22 --> Encryption Class Initialized
INFO - 2019-11-14 15:20:22 --> Controller Class Initialized
DEBUG - 2019-11-14 15:20:22 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:20:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:20:22 --> Model Class Initialized
ERROR - 2019-11-14 15:20:22 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:20:22 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:20:22 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:20:22 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:20:25 --> Config Class Initialized
INFO - 2019-11-14 15:20:25 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:20:25 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:20:25 --> Utf8 Class Initialized
INFO - 2019-11-14 15:20:25 --> URI Class Initialized
INFO - 2019-11-14 15:20:25 --> Router Class Initialized
INFO - 2019-11-14 15:20:25 --> Output Class Initialized
INFO - 2019-11-14 15:20:25 --> Security Class Initialized
DEBUG - 2019-11-14 15:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:20:25 --> CSRF cookie sent
INFO - 2019-11-14 15:20:25 --> Input Class Initialized
INFO - 2019-11-14 15:20:25 --> Language Class Initialized
INFO - 2019-11-14 15:20:25 --> Language Class Initialized
INFO - 2019-11-14 15:20:25 --> Config Class Initialized
INFO - 2019-11-14 15:20:25 --> Loader Class Initialized
INFO - 2019-11-14 15:20:25 --> Helper loaded: url_helper
INFO - 2019-11-14 15:20:25 --> Helper loaded: common_helper
INFO - 2019-11-14 15:20:25 --> Helper loaded: language_helper
INFO - 2019-11-14 15:20:26 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:20:26 --> Helper loaded: email_helper
INFO - 2019-11-14 15:20:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:20:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:20:26 --> Parser Class Initialized
INFO - 2019-11-14 15:20:26 --> User Agent Class Initialized
INFO - 2019-11-14 15:20:26 --> Model Class Initialized
INFO - 2019-11-14 15:20:26 --> Database Driver Class Initialized
INFO - 2019-11-14 15:20:26 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:26 --> Template Class Initialized
INFO - 2019-11-14 15:20:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:20:26 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:20:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:20:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:20:26 --> Encryption Class Initialized
INFO - 2019-11-14 15:20:26 --> Controller Class Initialized
DEBUG - 2019-11-14 15:20:26 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:20:26 --> Model Class Initialized
INFO - 2019-11-14 15:20:26 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-11-14 15:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:20:26 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:20:26 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:20:26 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:20:26 --> Final output sent to browser
DEBUG - 2019-11-14 15:20:26 --> Total execution time: 0.9188
INFO - 2019-11-14 15:20:30 --> Config Class Initialized
INFO - 2019-11-14 15:20:30 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:20:30 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:20:30 --> Utf8 Class Initialized
INFO - 2019-11-14 15:20:30 --> URI Class Initialized
INFO - 2019-11-14 15:20:30 --> Router Class Initialized
INFO - 2019-11-14 15:20:30 --> Output Class Initialized
INFO - 2019-11-14 15:20:30 --> Security Class Initialized
DEBUG - 2019-11-14 15:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:20:30 --> CSRF cookie sent
INFO - 2019-11-14 15:20:30 --> Input Class Initialized
INFO - 2019-11-14 15:20:30 --> Language Class Initialized
INFO - 2019-11-14 15:20:30 --> Language Class Initialized
INFO - 2019-11-14 15:20:30 --> Config Class Initialized
INFO - 2019-11-14 15:20:31 --> Loader Class Initialized
INFO - 2019-11-14 15:20:31 --> Helper loaded: url_helper
INFO - 2019-11-14 15:20:31 --> Helper loaded: common_helper
INFO - 2019-11-14 15:20:31 --> Helper loaded: language_helper
INFO - 2019-11-14 15:20:31 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:20:31 --> Helper loaded: email_helper
INFO - 2019-11-14 15:20:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:20:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:20:31 --> Parser Class Initialized
INFO - 2019-11-14 15:20:31 --> User Agent Class Initialized
INFO - 2019-11-14 15:20:31 --> Model Class Initialized
INFO - 2019-11-14 15:20:31 --> Database Driver Class Initialized
INFO - 2019-11-14 15:20:31 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:31 --> Template Class Initialized
INFO - 2019-11-14 15:20:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:20:31 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:20:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:20:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:20:31 --> Encryption Class Initialized
INFO - 2019-11-14 15:20:31 --> Controller Class Initialized
DEBUG - 2019-11-14 15:20:31 --> package MX_Controller Initialized
DEBUG - 2019-11-14 15:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-14 15:20:31 --> Model Class Initialized
INFO - 2019-11-14 15:20:31 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:20:31 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:20:31 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:20:31 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-14 15:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-14 15:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:20:31 --> Final output sent to browser
DEBUG - 2019-11-14 15:20:31 --> Total execution time: 0.9402
INFO - 2019-11-14 15:20:36 --> Config Class Initialized
INFO - 2019-11-14 15:20:36 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:20:36 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:20:36 --> Utf8 Class Initialized
INFO - 2019-11-14 15:20:36 --> URI Class Initialized
INFO - 2019-11-14 15:20:36 --> Router Class Initialized
INFO - 2019-11-14 15:20:36 --> Output Class Initialized
INFO - 2019-11-14 15:20:36 --> Security Class Initialized
DEBUG - 2019-11-14 15:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:20:36 --> CSRF cookie sent
INFO - 2019-11-14 15:20:36 --> Input Class Initialized
INFO - 2019-11-14 15:20:36 --> Language Class Initialized
INFO - 2019-11-14 15:20:36 --> Language Class Initialized
INFO - 2019-11-14 15:20:36 --> Config Class Initialized
INFO - 2019-11-14 15:20:36 --> Loader Class Initialized
INFO - 2019-11-14 15:20:36 --> Helper loaded: url_helper
INFO - 2019-11-14 15:20:36 --> Helper loaded: common_helper
INFO - 2019-11-14 15:20:36 --> Helper loaded: language_helper
INFO - 2019-11-14 15:20:36 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:20:36 --> Helper loaded: email_helper
INFO - 2019-11-14 15:20:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:20:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:20:36 --> Parser Class Initialized
INFO - 2019-11-14 15:20:36 --> User Agent Class Initialized
INFO - 2019-11-14 15:20:36 --> Model Class Initialized
INFO - 2019-11-14 15:20:36 --> Database Driver Class Initialized
INFO - 2019-11-14 15:20:36 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:36 --> Template Class Initialized
INFO - 2019-11-14 15:20:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:20:36 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:20:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:20:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:20:36 --> Encryption Class Initialized
INFO - 2019-11-14 15:20:36 --> Controller Class Initialized
DEBUG - 2019-11-14 15:20:36 --> package MX_Controller Initialized
DEBUG - 2019-11-14 15:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-14 15:20:36 --> Model Class Initialized
INFO - 2019-11-14 15:20:36 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:20:36 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:20:36 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:20:36 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-14 15:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-14 15:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:20:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:20:36 --> Final output sent to browser
DEBUG - 2019-11-14 15:20:36 --> Total execution time: 0.9190
INFO - 2019-11-14 15:20:40 --> Config Class Initialized
INFO - 2019-11-14 15:20:40 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:20:40 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:20:40 --> Utf8 Class Initialized
INFO - 2019-11-14 15:20:40 --> URI Class Initialized
INFO - 2019-11-14 15:20:40 --> Router Class Initialized
INFO - 2019-11-14 15:20:40 --> Output Class Initialized
INFO - 2019-11-14 15:20:40 --> Security Class Initialized
DEBUG - 2019-11-14 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:20:40 --> CSRF cookie sent
INFO - 2019-11-14 15:20:40 --> CSRF token verified
INFO - 2019-11-14 15:20:40 --> Input Class Initialized
INFO - 2019-11-14 15:20:40 --> Language Class Initialized
INFO - 2019-11-14 15:20:40 --> Language Class Initialized
INFO - 2019-11-14 15:20:40 --> Config Class Initialized
INFO - 2019-11-14 15:20:40 --> Loader Class Initialized
INFO - 2019-11-14 15:20:40 --> Helper loaded: url_helper
INFO - 2019-11-14 15:20:40 --> Helper loaded: common_helper
INFO - 2019-11-14 15:20:40 --> Helper loaded: language_helper
INFO - 2019-11-14 15:20:40 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:20:40 --> Helper loaded: email_helper
INFO - 2019-11-14 15:20:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:20:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:20:40 --> Parser Class Initialized
INFO - 2019-11-14 15:20:40 --> User Agent Class Initialized
INFO - 2019-11-14 15:20:40 --> Model Class Initialized
INFO - 2019-11-14 15:20:40 --> Database Driver Class Initialized
INFO - 2019-11-14 15:20:40 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:40 --> Template Class Initialized
INFO - 2019-11-14 15:20:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:20:40 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:20:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:20:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:20:40 --> Encryption Class Initialized
INFO - 2019-11-14 15:20:40 --> Controller Class Initialized
DEBUG - 2019-11-14 15:20:40 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:20:40 --> Model Class Initialized
INFO - 2019-11-14 15:20:40 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:20:41 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 15:20:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 15:20:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:20:41 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:20:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:20:41 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:20:41 --> Model Class Initialized
DEBUG - 2019-11-14 15:20:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:20:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:20:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:20:41 --> Final output sent to browser
DEBUG - 2019-11-14 15:20:41 --> Total execution time: 1.0776
INFO - 2019-11-14 15:21:01 --> Config Class Initialized
INFO - 2019-11-14 15:21:01 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:21:01 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:21:01 --> Utf8 Class Initialized
INFO - 2019-11-14 15:21:01 --> URI Class Initialized
INFO - 2019-11-14 15:21:01 --> Router Class Initialized
INFO - 2019-11-14 15:21:01 --> Output Class Initialized
INFO - 2019-11-14 15:21:01 --> Security Class Initialized
DEBUG - 2019-11-14 15:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:21:01 --> CSRF cookie sent
INFO - 2019-11-14 15:21:01 --> CSRF token verified
INFO - 2019-11-14 15:21:01 --> Input Class Initialized
INFO - 2019-11-14 15:21:01 --> Language Class Initialized
INFO - 2019-11-14 15:21:01 --> Language Class Initialized
INFO - 2019-11-14 15:21:01 --> Config Class Initialized
INFO - 2019-11-14 15:21:01 --> Loader Class Initialized
INFO - 2019-11-14 15:21:01 --> Helper loaded: url_helper
INFO - 2019-11-14 15:21:01 --> Helper loaded: common_helper
INFO - 2019-11-14 15:21:01 --> Helper loaded: language_helper
INFO - 2019-11-14 15:21:01 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:21:01 --> Helper loaded: email_helper
INFO - 2019-11-14 15:21:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:21:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:21:01 --> Parser Class Initialized
INFO - 2019-11-14 15:21:01 --> User Agent Class Initialized
INFO - 2019-11-14 15:21:01 --> Model Class Initialized
INFO - 2019-11-14 15:21:01 --> Database Driver Class Initialized
INFO - 2019-11-14 15:21:01 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:01 --> Template Class Initialized
INFO - 2019-11-14 15:21:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:21:01 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:21:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:21:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:21:01 --> Encryption Class Initialized
INFO - 2019-11-14 15:21:01 --> Controller Class Initialized
DEBUG - 2019-11-14 15:21:01 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:21:01 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:01 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:21:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:21:02 --> orders MX_Controller Initialized
DEBUG - 2019-11-14 15:21:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-14 15:21:02 --> Final output sent to browser
DEBUG - 2019-11-14 15:21:02 --> Total execution time: 1.8178
INFO - 2019-11-14 15:21:08 --> Config Class Initialized
INFO - 2019-11-14 15:21:08 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:21:08 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:21:08 --> Utf8 Class Initialized
INFO - 2019-11-14 15:21:08 --> URI Class Initialized
INFO - 2019-11-14 15:21:08 --> Router Class Initialized
INFO - 2019-11-14 15:21:08 --> Output Class Initialized
INFO - 2019-11-14 15:21:08 --> Security Class Initialized
DEBUG - 2019-11-14 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:21:08 --> Input Class Initialized
INFO - 2019-11-14 15:21:08 --> Language Class Initialized
INFO - 2019-11-14 15:21:08 --> Language Class Initialized
INFO - 2019-11-14 15:21:08 --> Config Class Initialized
INFO - 2019-11-14 15:21:08 --> Loader Class Initialized
INFO - 2019-11-14 15:21:08 --> Helper loaded: url_helper
INFO - 2019-11-14 15:21:08 --> Helper loaded: common_helper
INFO - 2019-11-14 15:21:08 --> Helper loaded: language_helper
INFO - 2019-11-14 15:21:08 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:21:08 --> Helper loaded: email_helper
INFO - 2019-11-14 15:21:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:21:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:21:09 --> Parser Class Initialized
INFO - 2019-11-14 15:21:09 --> User Agent Class Initialized
INFO - 2019-11-14 15:21:09 --> Model Class Initialized
INFO - 2019-11-14 15:21:09 --> Database Driver Class Initialized
INFO - 2019-11-14 15:21:09 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:09 --> Template Class Initialized
INFO - 2019-11-14 15:21:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:21:09 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:21:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:21:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:21:09 --> Encryption Class Initialized
INFO - 2019-11-14 15:21:09 --> Controller Class Initialized
DEBUG - 2019-11-14 15:21:09 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:21:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:21:09 --> Model Class Initialized
INFO - 2019-11-14 15:21:19 --> Config Class Initialized
INFO - 2019-11-14 15:21:19 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:21:19 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:21:19 --> Utf8 Class Initialized
INFO - 2019-11-14 15:21:19 --> URI Class Initialized
INFO - 2019-11-14 15:21:19 --> Router Class Initialized
INFO - 2019-11-14 15:21:19 --> Output Class Initialized
INFO - 2019-11-14 15:21:19 --> Security Class Initialized
DEBUG - 2019-11-14 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:21:19 --> CSRF cookie sent
INFO - 2019-11-14 15:21:19 --> Input Class Initialized
INFO - 2019-11-14 15:21:19 --> Language Class Initialized
INFO - 2019-11-14 15:21:19 --> Language Class Initialized
INFO - 2019-11-14 15:21:19 --> Config Class Initialized
INFO - 2019-11-14 15:21:19 --> Loader Class Initialized
INFO - 2019-11-14 15:21:19 --> Helper loaded: url_helper
INFO - 2019-11-14 15:21:19 --> Helper loaded: common_helper
INFO - 2019-11-14 15:21:19 --> Helper loaded: language_helper
INFO - 2019-11-14 15:21:19 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:21:19 --> Helper loaded: email_helper
INFO - 2019-11-14 15:21:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:21:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:21:19 --> Parser Class Initialized
INFO - 2019-11-14 15:21:19 --> User Agent Class Initialized
INFO - 2019-11-14 15:21:19 --> Model Class Initialized
INFO - 2019-11-14 15:21:19 --> Database Driver Class Initialized
INFO - 2019-11-14 15:21:19 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:19 --> Template Class Initialized
INFO - 2019-11-14 15:21:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:21:19 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:21:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:21:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:21:19 --> Encryption Class Initialized
INFO - 2019-11-14 15:21:19 --> Controller Class Initialized
DEBUG - 2019-11-14 15:21:19 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:21:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:21:19 --> Model Class Initialized
ERROR - 2019-11-14 15:21:19 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:21:19 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:21:19 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:21:19 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:21:19 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:21:19 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:21:19 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:21:19 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:21:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:21:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:21:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:21:20 --> Could not find the language line "Pending"
DEBUG - 2019-11-14 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:21:20 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:21:20 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:21:20 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:21:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:21:20 --> Final output sent to browser
DEBUG - 2019-11-14 15:21:20 --> Total execution time: 1.1910
INFO - 2019-11-14 15:21:21 --> Config Class Initialized
INFO - 2019-11-14 15:21:21 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:21:21 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:21:21 --> Utf8 Class Initialized
INFO - 2019-11-14 15:21:21 --> URI Class Initialized
INFO - 2019-11-14 15:21:21 --> Router Class Initialized
INFO - 2019-11-14 15:21:21 --> Output Class Initialized
INFO - 2019-11-14 15:21:21 --> Security Class Initialized
DEBUG - 2019-11-14 15:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:21:21 --> CSRF cookie sent
INFO - 2019-11-14 15:21:21 --> Input Class Initialized
INFO - 2019-11-14 15:21:21 --> Language Class Initialized
INFO - 2019-11-14 15:21:21 --> Language Class Initialized
INFO - 2019-11-14 15:21:21 --> Config Class Initialized
INFO - 2019-11-14 15:21:21 --> Loader Class Initialized
INFO - 2019-11-14 15:21:21 --> Helper loaded: url_helper
INFO - 2019-11-14 15:21:21 --> Helper loaded: common_helper
INFO - 2019-11-14 15:21:21 --> Helper loaded: language_helper
INFO - 2019-11-14 15:21:21 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:21:22 --> Helper loaded: email_helper
INFO - 2019-11-14 15:21:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:21:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:21:22 --> Parser Class Initialized
INFO - 2019-11-14 15:21:22 --> User Agent Class Initialized
INFO - 2019-11-14 15:21:22 --> Model Class Initialized
INFO - 2019-11-14 15:21:22 --> Database Driver Class Initialized
INFO - 2019-11-14 15:21:22 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:22 --> Template Class Initialized
INFO - 2019-11-14 15:21:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:21:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:21:22 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:21:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:21:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:21:22 --> Encryption Class Initialized
INFO - 2019-11-14 15:21:22 --> Controller Class Initialized
DEBUG - 2019-11-14 15:21:22 --> transactions MX_Controller Initialized
DEBUG - 2019-11-14 15:21:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-14 15:21:22 --> Model Class Initialized
ERROR - 2019-11-14 15:21:22 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:21:22 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:21:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-14 15:21:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:21:22 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:21:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:21:22 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:21:22 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:21:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:21:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:21:22 --> Final output sent to browser
DEBUG - 2019-11-14 15:21:22 --> Total execution time: 0.8907
INFO - 2019-11-14 15:21:46 --> Config Class Initialized
INFO - 2019-11-14 15:21:46 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:21:46 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:21:46 --> Utf8 Class Initialized
INFO - 2019-11-14 15:21:46 --> URI Class Initialized
INFO - 2019-11-14 15:21:46 --> Router Class Initialized
INFO - 2019-11-14 15:21:46 --> Output Class Initialized
INFO - 2019-11-14 15:21:46 --> Security Class Initialized
DEBUG - 2019-11-14 15:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:21:46 --> Input Class Initialized
INFO - 2019-11-14 15:21:46 --> Language Class Initialized
INFO - 2019-11-14 15:21:46 --> Language Class Initialized
INFO - 2019-11-14 15:21:46 --> Config Class Initialized
INFO - 2019-11-14 15:21:46 --> Loader Class Initialized
INFO - 2019-11-14 15:21:46 --> Helper loaded: url_helper
INFO - 2019-11-14 15:21:46 --> Helper loaded: common_helper
INFO - 2019-11-14 15:21:46 --> Helper loaded: language_helper
INFO - 2019-11-14 15:21:46 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:21:46 --> Helper loaded: email_helper
INFO - 2019-11-14 15:21:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:21:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:21:46 --> Parser Class Initialized
INFO - 2019-11-14 15:21:46 --> User Agent Class Initialized
INFO - 2019-11-14 15:21:46 --> Model Class Initialized
INFO - 2019-11-14 15:21:47 --> Database Driver Class Initialized
INFO - 2019-11-14 15:21:47 --> Model Class Initialized
DEBUG - 2019-11-14 15:21:47 --> Template Class Initialized
INFO - 2019-11-14 15:21:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:21:47 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:21:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:21:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:21:47 --> Encryption Class Initialized
INFO - 2019-11-14 15:21:47 --> Controller Class Initialized
DEBUG - 2019-11-14 15:21:47 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:21:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:21:47 --> Model Class Initialized
INFO - 2019-11-14 15:22:43 --> Config Class Initialized
INFO - 2019-11-14 15:22:43 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:22:43 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:22:43 --> Utf8 Class Initialized
INFO - 2019-11-14 15:22:43 --> URI Class Initialized
INFO - 2019-11-14 15:22:43 --> Router Class Initialized
INFO - 2019-11-14 15:22:43 --> Output Class Initialized
INFO - 2019-11-14 15:22:43 --> Security Class Initialized
DEBUG - 2019-11-14 15:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:22:43 --> Input Class Initialized
INFO - 2019-11-14 15:22:43 --> Language Class Initialized
INFO - 2019-11-14 15:22:43 --> Language Class Initialized
INFO - 2019-11-14 15:22:43 --> Config Class Initialized
INFO - 2019-11-14 15:22:43 --> Loader Class Initialized
INFO - 2019-11-14 15:22:43 --> Helper loaded: url_helper
INFO - 2019-11-14 15:22:43 --> Helper loaded: common_helper
INFO - 2019-11-14 15:22:43 --> Helper loaded: language_helper
INFO - 2019-11-14 15:22:43 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:22:43 --> Helper loaded: email_helper
INFO - 2019-11-14 15:22:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:22:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:22:43 --> Parser Class Initialized
INFO - 2019-11-14 15:22:43 --> User Agent Class Initialized
INFO - 2019-11-14 15:22:43 --> Model Class Initialized
INFO - 2019-11-14 15:22:43 --> Database Driver Class Initialized
INFO - 2019-11-14 15:22:43 --> Model Class Initialized
DEBUG - 2019-11-14 15:22:43 --> Template Class Initialized
INFO - 2019-11-14 15:22:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:22:43 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:22:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:22:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:22:43 --> Encryption Class Initialized
INFO - 2019-11-14 15:22:43 --> Controller Class Initialized
DEBUG - 2019-11-14 15:22:43 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:22:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:22:43 --> Model Class Initialized
INFO - 2019-11-14 15:24:01 --> Config Class Initialized
INFO - 2019-11-14 15:24:01 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:24:01 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:24:01 --> Utf8 Class Initialized
INFO - 2019-11-14 15:24:01 --> URI Class Initialized
INFO - 2019-11-14 15:24:01 --> Router Class Initialized
INFO - 2019-11-14 15:24:01 --> Output Class Initialized
INFO - 2019-11-14 15:24:01 --> Security Class Initialized
DEBUG - 2019-11-14 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:24:01 --> Input Class Initialized
INFO - 2019-11-14 15:24:01 --> Language Class Initialized
INFO - 2019-11-14 15:24:01 --> Language Class Initialized
INFO - 2019-11-14 15:24:01 --> Config Class Initialized
INFO - 2019-11-14 15:24:01 --> Loader Class Initialized
INFO - 2019-11-14 15:24:01 --> Helper loaded: url_helper
INFO - 2019-11-14 15:24:01 --> Helper loaded: common_helper
INFO - 2019-11-14 15:24:01 --> Helper loaded: language_helper
INFO - 2019-11-14 15:24:01 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:24:01 --> Helper loaded: email_helper
INFO - 2019-11-14 15:24:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:24:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:24:01 --> Parser Class Initialized
INFO - 2019-11-14 15:24:01 --> User Agent Class Initialized
INFO - 2019-11-14 15:24:01 --> Model Class Initialized
INFO - 2019-11-14 15:24:01 --> Database Driver Class Initialized
INFO - 2019-11-14 15:24:01 --> Model Class Initialized
DEBUG - 2019-11-14 15:24:01 --> Template Class Initialized
INFO - 2019-11-14 15:24:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:24:01 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:24:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:24:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:24:01 --> Encryption Class Initialized
INFO - 2019-11-14 15:24:01 --> Controller Class Initialized
DEBUG - 2019-11-14 15:24:01 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:24:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:24:01 --> Model Class Initialized
INFO - 2019-11-14 15:24:12 --> Config Class Initialized
INFO - 2019-11-14 15:24:12 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:24:12 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:24:12 --> Utf8 Class Initialized
INFO - 2019-11-14 15:24:12 --> URI Class Initialized
INFO - 2019-11-14 15:24:12 --> Router Class Initialized
INFO - 2019-11-14 15:24:12 --> Output Class Initialized
INFO - 2019-11-14 15:24:12 --> Security Class Initialized
DEBUG - 2019-11-14 15:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:24:12 --> CSRF cookie sent
INFO - 2019-11-14 15:24:12 --> CSRF token verified
INFO - 2019-11-14 15:24:12 --> Input Class Initialized
INFO - 2019-11-14 15:24:12 --> Language Class Initialized
INFO - 2019-11-14 15:24:12 --> Language Class Initialized
INFO - 2019-11-14 15:24:12 --> Config Class Initialized
INFO - 2019-11-14 15:24:12 --> Loader Class Initialized
INFO - 2019-11-14 15:24:12 --> Helper loaded: url_helper
INFO - 2019-11-14 15:24:12 --> Helper loaded: common_helper
INFO - 2019-11-14 15:24:13 --> Helper loaded: language_helper
INFO - 2019-11-14 15:24:13 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:24:13 --> Helper loaded: email_helper
INFO - 2019-11-14 15:24:13 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:24:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:24:13 --> Parser Class Initialized
INFO - 2019-11-14 15:24:13 --> User Agent Class Initialized
INFO - 2019-11-14 15:24:13 --> Model Class Initialized
INFO - 2019-11-14 15:24:13 --> Database Driver Class Initialized
INFO - 2019-11-14 15:24:13 --> Model Class Initialized
DEBUG - 2019-11-14 15:24:13 --> Template Class Initialized
INFO - 2019-11-14 15:24:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:24:13 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:24:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:24:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:24:13 --> Encryption Class Initialized
INFO - 2019-11-14 15:24:13 --> Controller Class Initialized
DEBUG - 2019-11-14 15:24:13 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:24:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:24:13 --> Model Class Initialized
DEBUG - 2019-11-14 15:24:13 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:24:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:24:14 --> orders MX_Controller Initialized
DEBUG - 2019-11-14 15:24:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-14 15:24:14 --> Final output sent to browser
DEBUG - 2019-11-14 15:24:14 --> Total execution time: 1.7998
INFO - 2019-11-14 15:24:21 --> Config Class Initialized
INFO - 2019-11-14 15:24:21 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:24:21 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:24:21 --> Utf8 Class Initialized
INFO - 2019-11-14 15:24:21 --> URI Class Initialized
INFO - 2019-11-14 15:24:21 --> Router Class Initialized
INFO - 2019-11-14 15:24:21 --> Output Class Initialized
INFO - 2019-11-14 15:24:21 --> Security Class Initialized
DEBUG - 2019-11-14 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:24:21 --> Input Class Initialized
INFO - 2019-11-14 15:24:21 --> Language Class Initialized
INFO - 2019-11-14 15:24:21 --> Language Class Initialized
INFO - 2019-11-14 15:24:22 --> Config Class Initialized
INFO - 2019-11-14 15:24:22 --> Loader Class Initialized
INFO - 2019-11-14 15:24:22 --> Helper loaded: url_helper
INFO - 2019-11-14 15:24:22 --> Helper loaded: common_helper
INFO - 2019-11-14 15:24:22 --> Helper loaded: language_helper
INFO - 2019-11-14 15:24:22 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:24:22 --> Helper loaded: email_helper
INFO - 2019-11-14 15:24:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:24:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:24:22 --> Parser Class Initialized
INFO - 2019-11-14 15:24:22 --> User Agent Class Initialized
INFO - 2019-11-14 15:24:22 --> Model Class Initialized
INFO - 2019-11-14 15:24:22 --> Database Driver Class Initialized
INFO - 2019-11-14 15:24:22 --> Model Class Initialized
DEBUG - 2019-11-14 15:24:22 --> Template Class Initialized
INFO - 2019-11-14 15:24:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:24:22 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:24:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:24:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:24:22 --> Encryption Class Initialized
INFO - 2019-11-14 15:24:22 --> Controller Class Initialized
DEBUG - 2019-11-14 15:24:22 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:24:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:24:22 --> Model Class Initialized
INFO - 2019-11-14 15:24:49 --> Config Class Initialized
INFO - 2019-11-14 15:24:49 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:24:49 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:24:49 --> Utf8 Class Initialized
INFO - 2019-11-14 15:24:49 --> URI Class Initialized
INFO - 2019-11-14 15:24:49 --> Router Class Initialized
INFO - 2019-11-14 15:24:49 --> Output Class Initialized
INFO - 2019-11-14 15:24:49 --> Security Class Initialized
DEBUG - 2019-11-14 15:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:24:49 --> Input Class Initialized
INFO - 2019-11-14 15:24:49 --> Language Class Initialized
INFO - 2019-11-14 15:24:49 --> Language Class Initialized
INFO - 2019-11-14 15:24:49 --> Config Class Initialized
INFO - 2019-11-14 15:24:49 --> Loader Class Initialized
INFO - 2019-11-14 15:24:49 --> Helper loaded: url_helper
INFO - 2019-11-14 15:24:49 --> Helper loaded: common_helper
INFO - 2019-11-14 15:24:49 --> Helper loaded: language_helper
INFO - 2019-11-14 15:24:50 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:24:50 --> Helper loaded: email_helper
INFO - 2019-11-14 15:24:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:24:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:24:50 --> Parser Class Initialized
INFO - 2019-11-14 15:24:50 --> User Agent Class Initialized
INFO - 2019-11-14 15:24:50 --> Model Class Initialized
INFO - 2019-11-14 15:24:50 --> Database Driver Class Initialized
INFO - 2019-11-14 15:24:50 --> Model Class Initialized
DEBUG - 2019-11-14 15:24:50 --> Template Class Initialized
INFO - 2019-11-14 15:24:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:24:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:24:50 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:24:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:24:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:24:50 --> Encryption Class Initialized
INFO - 2019-11-14 15:24:50 --> Controller Class Initialized
DEBUG - 2019-11-14 15:24:50 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:24:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:24:50 --> Model Class Initialized
INFO - 2019-11-14 15:27:01 --> Config Class Initialized
INFO - 2019-11-14 15:27:01 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:27:01 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:27:01 --> Utf8 Class Initialized
INFO - 2019-11-14 15:27:01 --> URI Class Initialized
INFO - 2019-11-14 15:27:01 --> Router Class Initialized
INFO - 2019-11-14 15:27:01 --> Output Class Initialized
INFO - 2019-11-14 15:27:01 --> Security Class Initialized
DEBUG - 2019-11-14 15:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:27:01 --> Input Class Initialized
INFO - 2019-11-14 15:27:01 --> Language Class Initialized
INFO - 2019-11-14 15:27:01 --> Language Class Initialized
INFO - 2019-11-14 15:27:01 --> Config Class Initialized
INFO - 2019-11-14 15:27:01 --> Loader Class Initialized
INFO - 2019-11-14 15:27:01 --> Helper loaded: url_helper
INFO - 2019-11-14 15:27:01 --> Helper loaded: common_helper
INFO - 2019-11-14 15:27:01 --> Helper loaded: language_helper
INFO - 2019-11-14 15:27:01 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:27:01 --> Helper loaded: email_helper
INFO - 2019-11-14 15:27:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:27:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:27:01 --> Parser Class Initialized
INFO - 2019-11-14 15:27:01 --> User Agent Class Initialized
INFO - 2019-11-14 15:27:01 --> Model Class Initialized
INFO - 2019-11-14 15:27:01 --> Database Driver Class Initialized
INFO - 2019-11-14 15:27:01 --> Model Class Initialized
DEBUG - 2019-11-14 15:27:01 --> Template Class Initialized
INFO - 2019-11-14 15:27:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:27:02 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:27:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:27:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:27:02 --> Encryption Class Initialized
INFO - 2019-11-14 15:27:02 --> Controller Class Initialized
DEBUG - 2019-11-14 15:27:02 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:27:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:27:02 --> Model Class Initialized
INFO - 2019-11-14 15:27:52 --> Config Class Initialized
INFO - 2019-11-14 15:27:52 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:27:52 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:27:52 --> Utf8 Class Initialized
INFO - 2019-11-14 15:27:52 --> URI Class Initialized
INFO - 2019-11-14 15:27:52 --> Router Class Initialized
INFO - 2019-11-14 15:27:52 --> Output Class Initialized
INFO - 2019-11-14 15:27:52 --> Security Class Initialized
DEBUG - 2019-11-14 15:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:27:52 --> Input Class Initialized
INFO - 2019-11-14 15:27:52 --> Language Class Initialized
INFO - 2019-11-14 15:27:52 --> Language Class Initialized
INFO - 2019-11-14 15:27:52 --> Config Class Initialized
INFO - 2019-11-14 15:27:52 --> Loader Class Initialized
INFO - 2019-11-14 15:27:52 --> Helper loaded: url_helper
INFO - 2019-11-14 15:27:52 --> Helper loaded: common_helper
INFO - 2019-11-14 15:27:52 --> Helper loaded: language_helper
INFO - 2019-11-14 15:27:52 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:27:52 --> Helper loaded: email_helper
INFO - 2019-11-14 15:27:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:27:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:27:53 --> Parser Class Initialized
INFO - 2019-11-14 15:27:53 --> User Agent Class Initialized
INFO - 2019-11-14 15:27:53 --> Model Class Initialized
INFO - 2019-11-14 15:27:53 --> Database Driver Class Initialized
INFO - 2019-11-14 15:27:53 --> Model Class Initialized
DEBUG - 2019-11-14 15:27:53 --> Template Class Initialized
INFO - 2019-11-14 15:27:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:27:53 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:27:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:27:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:27:53 --> Encryption Class Initialized
INFO - 2019-11-14 15:27:53 --> Controller Class Initialized
DEBUG - 2019-11-14 15:27:53 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:27:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:27:53 --> Model Class Initialized
INFO - 2019-11-14 15:28:26 --> Config Class Initialized
INFO - 2019-11-14 15:28:26 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:28:26 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:28:26 --> Utf8 Class Initialized
INFO - 2019-11-14 15:28:26 --> URI Class Initialized
INFO - 2019-11-14 15:28:26 --> Router Class Initialized
INFO - 2019-11-14 15:28:26 --> Output Class Initialized
INFO - 2019-11-14 15:28:26 --> Security Class Initialized
DEBUG - 2019-11-14 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:28:26 --> Input Class Initialized
INFO - 2019-11-14 15:28:26 --> Language Class Initialized
INFO - 2019-11-14 15:28:26 --> Language Class Initialized
INFO - 2019-11-14 15:28:26 --> Config Class Initialized
INFO - 2019-11-14 15:28:26 --> Loader Class Initialized
INFO - 2019-11-14 15:28:26 --> Helper loaded: url_helper
INFO - 2019-11-14 15:28:26 --> Helper loaded: common_helper
INFO - 2019-11-14 15:28:26 --> Helper loaded: language_helper
INFO - 2019-11-14 15:28:26 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:28:26 --> Helper loaded: email_helper
INFO - 2019-11-14 15:28:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:28:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:28:26 --> Parser Class Initialized
INFO - 2019-11-14 15:28:26 --> User Agent Class Initialized
INFO - 2019-11-14 15:28:27 --> Model Class Initialized
INFO - 2019-11-14 15:28:27 --> Database Driver Class Initialized
INFO - 2019-11-14 15:28:27 --> Model Class Initialized
DEBUG - 2019-11-14 15:28:27 --> Template Class Initialized
INFO - 2019-11-14 15:28:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:28:27 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:28:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:28:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:28:27 --> Encryption Class Initialized
INFO - 2019-11-14 15:28:27 --> Controller Class Initialized
DEBUG - 2019-11-14 15:28:27 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:28:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:28:27 --> Model Class Initialized
INFO - 2019-11-14 15:36:16 --> Config Class Initialized
INFO - 2019-11-14 15:36:16 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:36:16 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:36:16 --> Utf8 Class Initialized
INFO - 2019-11-14 15:36:16 --> URI Class Initialized
INFO - 2019-11-14 15:36:16 --> Router Class Initialized
INFO - 2019-11-14 15:36:16 --> Output Class Initialized
INFO - 2019-11-14 15:36:16 --> Security Class Initialized
DEBUG - 2019-11-14 15:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:36:16 --> Input Class Initialized
INFO - 2019-11-14 15:36:16 --> Language Class Initialized
INFO - 2019-11-14 15:36:16 --> Language Class Initialized
INFO - 2019-11-14 15:36:16 --> Config Class Initialized
INFO - 2019-11-14 15:36:16 --> Loader Class Initialized
INFO - 2019-11-14 15:36:16 --> Helper loaded: url_helper
INFO - 2019-11-14 15:36:16 --> Helper loaded: common_helper
INFO - 2019-11-14 15:36:16 --> Helper loaded: language_helper
INFO - 2019-11-14 15:36:16 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:36:16 --> Helper loaded: email_helper
INFO - 2019-11-14 15:36:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:36:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:36:17 --> Parser Class Initialized
INFO - 2019-11-14 15:36:17 --> User Agent Class Initialized
INFO - 2019-11-14 15:36:17 --> Model Class Initialized
INFO - 2019-11-14 15:36:17 --> Database Driver Class Initialized
INFO - 2019-11-14 15:36:17 --> Model Class Initialized
DEBUG - 2019-11-14 15:36:17 --> Template Class Initialized
INFO - 2019-11-14 15:36:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:36:17 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:36:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:36:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:36:17 --> Encryption Class Initialized
INFO - 2019-11-14 15:36:17 --> Controller Class Initialized
DEBUG - 2019-11-14 15:36:17 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:36:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:36:17 --> Model Class Initialized
INFO - 2019-11-14 15:39:46 --> Config Class Initialized
INFO - 2019-11-14 15:39:46 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:39:46 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:39:46 --> Utf8 Class Initialized
INFO - 2019-11-14 15:39:46 --> URI Class Initialized
INFO - 2019-11-14 15:39:46 --> Router Class Initialized
INFO - 2019-11-14 15:39:46 --> Output Class Initialized
INFO - 2019-11-14 15:39:46 --> Security Class Initialized
DEBUG - 2019-11-14 15:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:39:46 --> Input Class Initialized
INFO - 2019-11-14 15:39:46 --> Language Class Initialized
INFO - 2019-11-14 15:39:46 --> Language Class Initialized
INFO - 2019-11-14 15:39:46 --> Config Class Initialized
INFO - 2019-11-14 15:39:46 --> Loader Class Initialized
INFO - 2019-11-14 15:39:46 --> Helper loaded: url_helper
INFO - 2019-11-14 15:39:46 --> Helper loaded: common_helper
INFO - 2019-11-14 15:39:46 --> Helper loaded: language_helper
INFO - 2019-11-14 15:39:46 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:39:46 --> Helper loaded: email_helper
INFO - 2019-11-14 15:39:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:39:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:39:46 --> Parser Class Initialized
INFO - 2019-11-14 15:39:46 --> User Agent Class Initialized
INFO - 2019-11-14 15:39:46 --> Model Class Initialized
INFO - 2019-11-14 15:39:46 --> Database Driver Class Initialized
INFO - 2019-11-14 15:39:46 --> Model Class Initialized
DEBUG - 2019-11-14 15:39:46 --> Template Class Initialized
INFO - 2019-11-14 15:39:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:39:46 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:39:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:39:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:39:46 --> Encryption Class Initialized
INFO - 2019-11-14 15:39:46 --> Controller Class Initialized
DEBUG - 2019-11-14 15:39:46 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:39:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:39:47 --> Model Class Initialized
INFO - 2019-11-14 15:41:01 --> Config Class Initialized
INFO - 2019-11-14 15:41:01 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:41:01 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:41:01 --> Utf8 Class Initialized
INFO - 2019-11-14 15:41:01 --> URI Class Initialized
INFO - 2019-11-14 15:41:01 --> Router Class Initialized
INFO - 2019-11-14 15:41:01 --> Output Class Initialized
INFO - 2019-11-14 15:41:01 --> Security Class Initialized
DEBUG - 2019-11-14 15:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:41:01 --> Input Class Initialized
INFO - 2019-11-14 15:41:01 --> Language Class Initialized
INFO - 2019-11-14 15:41:01 --> Language Class Initialized
INFO - 2019-11-14 15:41:01 --> Config Class Initialized
INFO - 2019-11-14 15:41:01 --> Loader Class Initialized
INFO - 2019-11-14 15:41:01 --> Helper loaded: url_helper
INFO - 2019-11-14 15:41:01 --> Helper loaded: common_helper
INFO - 2019-11-14 15:41:01 --> Helper loaded: language_helper
INFO - 2019-11-14 15:41:01 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:41:01 --> Helper loaded: email_helper
INFO - 2019-11-14 15:41:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:41:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:41:01 --> Parser Class Initialized
INFO - 2019-11-14 15:41:01 --> User Agent Class Initialized
INFO - 2019-11-14 15:41:01 --> Model Class Initialized
INFO - 2019-11-14 15:41:01 --> Database Driver Class Initialized
INFO - 2019-11-14 15:41:01 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:01 --> Template Class Initialized
INFO - 2019-11-14 15:41:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:41:01 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:41:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:41:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:41:01 --> Encryption Class Initialized
INFO - 2019-11-14 15:41:01 --> Controller Class Initialized
DEBUG - 2019-11-14 15:41:01 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:41:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:41:01 --> Model Class Initialized
ERROR - 2019-11-14 15:41:02 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 117
ERROR - 2019-11-14 15:41:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 117
ERROR - 2019-11-14 15:41:02 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 130
ERROR - 2019-11-14 15:41:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 130
INFO - 2019-11-14 15:41:03 --> Config Class Initialized
INFO - 2019-11-14 15:41:03 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:41:03 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:41:03 --> Utf8 Class Initialized
INFO - 2019-11-14 15:41:03 --> URI Class Initialized
INFO - 2019-11-14 15:41:03 --> Router Class Initialized
INFO - 2019-11-14 15:41:03 --> Output Class Initialized
INFO - 2019-11-14 15:41:03 --> Security Class Initialized
DEBUG - 2019-11-14 15:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:41:03 --> CSRF cookie sent
INFO - 2019-11-14 15:41:03 --> Input Class Initialized
INFO - 2019-11-14 15:41:03 --> Language Class Initialized
INFO - 2019-11-14 15:41:03 --> Language Class Initialized
INFO - 2019-11-14 15:41:03 --> Config Class Initialized
INFO - 2019-11-14 15:41:03 --> Loader Class Initialized
INFO - 2019-11-14 15:41:03 --> Helper loaded: url_helper
INFO - 2019-11-14 15:41:03 --> Helper loaded: common_helper
INFO - 2019-11-14 15:41:03 --> Helper loaded: language_helper
INFO - 2019-11-14 15:41:03 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:41:03 --> Helper loaded: email_helper
INFO - 2019-11-14 15:41:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:41:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:41:03 --> Parser Class Initialized
INFO - 2019-11-14 15:41:03 --> User Agent Class Initialized
INFO - 2019-11-14 15:41:03 --> Model Class Initialized
INFO - 2019-11-14 15:41:03 --> Database Driver Class Initialized
INFO - 2019-11-14 15:41:03 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:03 --> Template Class Initialized
INFO - 2019-11-14 15:41:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:41:03 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:41:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:41:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:41:03 --> Encryption Class Initialized
INFO - 2019-11-14 15:41:03 --> Controller Class Initialized
DEBUG - 2019-11-14 15:41:03 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:41:03 --> Model Class Initialized
INFO - 2019-11-14 15:41:03 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-14 15:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:41:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:41:03 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:41:03 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:41:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:41:04 --> Final output sent to browser
DEBUG - 2019-11-14 15:41:04 --> Total execution time: 0.9925
INFO - 2019-11-14 15:41:10 --> Config Class Initialized
INFO - 2019-11-14 15:41:10 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:41:10 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:41:10 --> Utf8 Class Initialized
INFO - 2019-11-14 15:41:10 --> URI Class Initialized
INFO - 2019-11-14 15:41:10 --> Router Class Initialized
INFO - 2019-11-14 15:41:10 --> Output Class Initialized
INFO - 2019-11-14 15:41:10 --> Security Class Initialized
DEBUG - 2019-11-14 15:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:41:10 --> CSRF cookie sent
INFO - 2019-11-14 15:41:10 --> Input Class Initialized
INFO - 2019-11-14 15:41:10 --> Language Class Initialized
INFO - 2019-11-14 15:41:10 --> Language Class Initialized
INFO - 2019-11-14 15:41:10 --> Config Class Initialized
INFO - 2019-11-14 15:41:10 --> Loader Class Initialized
INFO - 2019-11-14 15:41:10 --> Helper loaded: url_helper
INFO - 2019-11-14 15:41:10 --> Helper loaded: common_helper
INFO - 2019-11-14 15:41:10 --> Helper loaded: language_helper
INFO - 2019-11-14 15:41:10 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:41:10 --> Helper loaded: email_helper
INFO - 2019-11-14 15:41:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:41:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:41:10 --> Parser Class Initialized
INFO - 2019-11-14 15:41:10 --> User Agent Class Initialized
INFO - 2019-11-14 15:41:10 --> Model Class Initialized
INFO - 2019-11-14 15:41:10 --> Database Driver Class Initialized
INFO - 2019-11-14 15:41:10 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:10 --> Template Class Initialized
INFO - 2019-11-14 15:41:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:41:10 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:41:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:41:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:41:11 --> Encryption Class Initialized
INFO - 2019-11-14 15:41:11 --> Controller Class Initialized
DEBUG - 2019-11-14 15:41:11 --> transactions MX_Controller Initialized
DEBUG - 2019-11-14 15:41:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-14 15:41:11 --> Model Class Initialized
ERROR - 2019-11-14 15:41:11 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:41:11 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:41:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-14 15:41:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:41:11 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:41:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:41:11 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:41:11 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:41:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:41:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:41:11 --> Final output sent to browser
DEBUG - 2019-11-14 15:41:11 --> Total execution time: 0.9797
INFO - 2019-11-14 15:41:14 --> Config Class Initialized
INFO - 2019-11-14 15:41:14 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:41:14 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:41:14 --> Utf8 Class Initialized
INFO - 2019-11-14 15:41:14 --> URI Class Initialized
INFO - 2019-11-14 15:41:14 --> Router Class Initialized
INFO - 2019-11-14 15:41:14 --> Output Class Initialized
INFO - 2019-11-14 15:41:14 --> Security Class Initialized
DEBUG - 2019-11-14 15:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:41:15 --> CSRF cookie sent
INFO - 2019-11-14 15:41:15 --> Input Class Initialized
INFO - 2019-11-14 15:41:15 --> Language Class Initialized
INFO - 2019-11-14 15:41:15 --> Language Class Initialized
INFO - 2019-11-14 15:41:15 --> Config Class Initialized
INFO - 2019-11-14 15:41:15 --> Loader Class Initialized
INFO - 2019-11-14 15:41:15 --> Helper loaded: url_helper
INFO - 2019-11-14 15:41:15 --> Helper loaded: common_helper
INFO - 2019-11-14 15:41:15 --> Helper loaded: language_helper
INFO - 2019-11-14 15:41:15 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:41:15 --> Helper loaded: email_helper
INFO - 2019-11-14 15:41:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:41:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:41:15 --> Parser Class Initialized
INFO - 2019-11-14 15:41:15 --> User Agent Class Initialized
INFO - 2019-11-14 15:41:15 --> Model Class Initialized
INFO - 2019-11-14 15:41:15 --> Database Driver Class Initialized
INFO - 2019-11-14 15:41:15 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:15 --> Template Class Initialized
INFO - 2019-11-14 15:41:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:41:15 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:41:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:41:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:41:15 --> Encryption Class Initialized
INFO - 2019-11-14 15:41:15 --> Controller Class Initialized
DEBUG - 2019-11-14 15:41:15 --> transactions MX_Controller Initialized
DEBUG - 2019-11-14 15:41:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-14 15:41:15 --> Model Class Initialized
ERROR - 2019-11-14 15:41:15 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:41:15 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:41:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-14 15:41:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:41:15 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:41:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:41:15 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:41:15 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:41:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:41:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:41:15 --> Final output sent to browser
DEBUG - 2019-11-14 15:41:15 --> Total execution time: 0.9600
INFO - 2019-11-14 15:41:18 --> Config Class Initialized
INFO - 2019-11-14 15:41:18 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:41:18 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:41:18 --> Utf8 Class Initialized
INFO - 2019-11-14 15:41:18 --> URI Class Initialized
INFO - 2019-11-14 15:41:18 --> Router Class Initialized
INFO - 2019-11-14 15:41:18 --> Output Class Initialized
INFO - 2019-11-14 15:41:18 --> Security Class Initialized
DEBUG - 2019-11-14 15:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:41:18 --> CSRF cookie sent
INFO - 2019-11-14 15:41:18 --> Input Class Initialized
INFO - 2019-11-14 15:41:18 --> Language Class Initialized
INFO - 2019-11-14 15:41:18 --> Language Class Initialized
INFO - 2019-11-14 15:41:18 --> Config Class Initialized
INFO - 2019-11-14 15:41:18 --> Loader Class Initialized
INFO - 2019-11-14 15:41:18 --> Helper loaded: url_helper
INFO - 2019-11-14 15:41:18 --> Helper loaded: common_helper
INFO - 2019-11-14 15:41:18 --> Helper loaded: language_helper
INFO - 2019-11-14 15:41:18 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:41:18 --> Helper loaded: email_helper
INFO - 2019-11-14 15:41:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:41:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:41:18 --> Parser Class Initialized
INFO - 2019-11-14 15:41:18 --> User Agent Class Initialized
INFO - 2019-11-14 15:41:18 --> Model Class Initialized
INFO - 2019-11-14 15:41:18 --> Database Driver Class Initialized
INFO - 2019-11-14 15:41:18 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:18 --> Template Class Initialized
INFO - 2019-11-14 15:41:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:41:18 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:41:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:41:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:41:18 --> Encryption Class Initialized
INFO - 2019-11-14 15:41:18 --> Controller Class Initialized
DEBUG - 2019-11-14 15:41:18 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:41:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:41:18 --> Model Class Initialized
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:41:18 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:41:18 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:41:19 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-14 15:41:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:41:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:41:19 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:41:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:41:19 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:41:19 --> Model Class Initialized
DEBUG - 2019-11-14 15:41:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:41:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:41:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:41:19 --> Final output sent to browser
DEBUG - 2019-11-14 15:41:19 --> Total execution time: 1.0976
INFO - 2019-11-14 15:42:03 --> Config Class Initialized
INFO - 2019-11-14 15:42:03 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:42:03 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:42:04 --> Utf8 Class Initialized
INFO - 2019-11-14 15:42:04 --> URI Class Initialized
INFO - 2019-11-14 15:42:04 --> Router Class Initialized
INFO - 2019-11-14 15:42:04 --> Output Class Initialized
INFO - 2019-11-14 15:42:04 --> Security Class Initialized
DEBUG - 2019-11-14 15:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:42:04 --> CSRF cookie sent
INFO - 2019-11-14 15:42:04 --> Input Class Initialized
INFO - 2019-11-14 15:42:04 --> Language Class Initialized
INFO - 2019-11-14 15:42:04 --> Language Class Initialized
INFO - 2019-11-14 15:42:04 --> Config Class Initialized
INFO - 2019-11-14 15:42:04 --> Loader Class Initialized
INFO - 2019-11-14 15:42:04 --> Helper loaded: url_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: common_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: language_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: email_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:42:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:42:04 --> Parser Class Initialized
INFO - 2019-11-14 15:42:04 --> User Agent Class Initialized
INFO - 2019-11-14 15:42:04 --> Model Class Initialized
INFO - 2019-11-14 15:42:04 --> Database Driver Class Initialized
INFO - 2019-11-14 15:42:04 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:04 --> Template Class Initialized
INFO - 2019-11-14 15:42:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:42:04 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:42:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:42:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:42:04 --> Encryption Class Initialized
INFO - 2019-11-14 15:42:04 --> Controller Class Initialized
DEBUG - 2019-11-14 15:42:04 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:42:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:42:04 --> Model Class Initialized
INFO - 2019-11-14 15:42:04 --> Config Class Initialized
INFO - 2019-11-14 15:42:04 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:42:04 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:42:04 --> Utf8 Class Initialized
INFO - 2019-11-14 15:42:04 --> URI Class Initialized
DEBUG - 2019-11-14 15:42:04 --> No URI present. Default controller set.
INFO - 2019-11-14 15:42:04 --> Router Class Initialized
INFO - 2019-11-14 15:42:04 --> Output Class Initialized
INFO - 2019-11-14 15:42:04 --> Security Class Initialized
DEBUG - 2019-11-14 15:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:42:04 --> CSRF cookie sent
INFO - 2019-11-14 15:42:04 --> Input Class Initialized
INFO - 2019-11-14 15:42:04 --> Language Class Initialized
INFO - 2019-11-14 15:42:04 --> Language Class Initialized
INFO - 2019-11-14 15:42:04 --> Config Class Initialized
INFO - 2019-11-14 15:42:04 --> Loader Class Initialized
INFO - 2019-11-14 15:42:04 --> Helper loaded: url_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: common_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: language_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: email_helper
INFO - 2019-11-14 15:42:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:42:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:42:04 --> Parser Class Initialized
INFO - 2019-11-14 15:42:04 --> User Agent Class Initialized
INFO - 2019-11-14 15:42:05 --> Model Class Initialized
INFO - 2019-11-14 15:42:05 --> Database Driver Class Initialized
INFO - 2019-11-14 15:42:05 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:05 --> Template Class Initialized
INFO - 2019-11-14 15:42:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:42:05 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:42:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:42:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:42:05 --> Encryption Class Initialized
DEBUG - 2019-11-14 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-14 15:42:05 --> Controller Class Initialized
DEBUG - 2019-11-14 15:42:05 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-14 15:42:05 --> Model Class Initialized
INFO - 2019-11-14 15:42:05 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-14 15:42:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-14 15:42:05 --> Final output sent to browser
DEBUG - 2019-11-14 15:42:05 --> Total execution time: 0.8871
INFO - 2019-11-14 15:42:07 --> Config Class Initialized
INFO - 2019-11-14 15:42:07 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:42:07 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:42:07 --> Utf8 Class Initialized
INFO - 2019-11-14 15:42:07 --> URI Class Initialized
INFO - 2019-11-14 15:42:07 --> Router Class Initialized
INFO - 2019-11-14 15:42:07 --> Output Class Initialized
INFO - 2019-11-14 15:42:07 --> Security Class Initialized
DEBUG - 2019-11-14 15:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:42:07 --> CSRF cookie sent
INFO - 2019-11-14 15:42:07 --> Input Class Initialized
INFO - 2019-11-14 15:42:07 --> Language Class Initialized
INFO - 2019-11-14 15:42:07 --> Language Class Initialized
INFO - 2019-11-14 15:42:07 --> Config Class Initialized
INFO - 2019-11-14 15:42:07 --> Loader Class Initialized
INFO - 2019-11-14 15:42:07 --> Helper loaded: url_helper
INFO - 2019-11-14 15:42:07 --> Helper loaded: common_helper
INFO - 2019-11-14 15:42:07 --> Helper loaded: language_helper
INFO - 2019-11-14 15:42:07 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:42:07 --> Helper loaded: email_helper
INFO - 2019-11-14 15:42:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:42:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:42:07 --> Parser Class Initialized
INFO - 2019-11-14 15:42:07 --> User Agent Class Initialized
INFO - 2019-11-14 15:42:07 --> Model Class Initialized
INFO - 2019-11-14 15:42:07 --> Database Driver Class Initialized
INFO - 2019-11-14 15:42:07 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:07 --> Template Class Initialized
INFO - 2019-11-14 15:42:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:42:08 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:42:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:42:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:42:08 --> Encryption Class Initialized
INFO - 2019-11-14 15:42:08 --> Controller Class Initialized
DEBUG - 2019-11-14 15:42:08 --> package MX_Controller Initialized
DEBUG - 2019-11-14 15:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-14 15:42:08 --> Model Class Initialized
INFO - 2019-11-14 15:42:08 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:42:08 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:42:08 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:42:08 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-14 15:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-14 15:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:42:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:42:08 --> Final output sent to browser
DEBUG - 2019-11-14 15:42:08 --> Total execution time: 1.1925
INFO - 2019-11-14 15:42:11 --> Config Class Initialized
INFO - 2019-11-14 15:42:11 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:42:11 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:42:11 --> Utf8 Class Initialized
INFO - 2019-11-14 15:42:11 --> URI Class Initialized
INFO - 2019-11-14 15:42:11 --> Router Class Initialized
INFO - 2019-11-14 15:42:11 --> Output Class Initialized
INFO - 2019-11-14 15:42:11 --> Security Class Initialized
DEBUG - 2019-11-14 15:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:42:11 --> CSRF cookie sent
INFO - 2019-11-14 15:42:11 --> CSRF token verified
INFO - 2019-11-14 15:42:11 --> Input Class Initialized
INFO - 2019-11-14 15:42:11 --> Language Class Initialized
INFO - 2019-11-14 15:42:11 --> Language Class Initialized
INFO - 2019-11-14 15:42:11 --> Config Class Initialized
INFO - 2019-11-14 15:42:11 --> Loader Class Initialized
INFO - 2019-11-14 15:42:11 --> Helper loaded: url_helper
INFO - 2019-11-14 15:42:11 --> Helper loaded: common_helper
INFO - 2019-11-14 15:42:11 --> Helper loaded: language_helper
INFO - 2019-11-14 15:42:11 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:42:11 --> Helper loaded: email_helper
INFO - 2019-11-14 15:42:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:42:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:42:11 --> Parser Class Initialized
INFO - 2019-11-14 15:42:11 --> User Agent Class Initialized
INFO - 2019-11-14 15:42:11 --> Model Class Initialized
INFO - 2019-11-14 15:42:12 --> Database Driver Class Initialized
INFO - 2019-11-14 15:42:12 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:12 --> Template Class Initialized
INFO - 2019-11-14 15:42:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:42:12 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:42:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:42:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:42:12 --> Encryption Class Initialized
INFO - 2019-11-14 15:42:12 --> Controller Class Initialized
DEBUG - 2019-11-14 15:42:12 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:42:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:42:12 --> Model Class Initialized
INFO - 2019-11-14 15:42:12 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:42:12 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 15:42:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 15:42:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:42:12 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:42:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:42:12 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:42:12 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:42:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:42:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:42:12 --> Final output sent to browser
DEBUG - 2019-11-14 15:42:12 --> Total execution time: 1.0698
INFO - 2019-11-14 15:42:27 --> Config Class Initialized
INFO - 2019-11-14 15:42:27 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:42:27 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:42:27 --> Utf8 Class Initialized
INFO - 2019-11-14 15:42:27 --> URI Class Initialized
INFO - 2019-11-14 15:42:27 --> Router Class Initialized
INFO - 2019-11-14 15:42:27 --> Output Class Initialized
INFO - 2019-11-14 15:42:27 --> Security Class Initialized
DEBUG - 2019-11-14 15:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:42:27 --> CSRF cookie sent
INFO - 2019-11-14 15:42:27 --> CSRF token verified
INFO - 2019-11-14 15:42:27 --> Input Class Initialized
INFO - 2019-11-14 15:42:27 --> Language Class Initialized
INFO - 2019-11-14 15:42:27 --> Language Class Initialized
INFO - 2019-11-14 15:42:27 --> Config Class Initialized
INFO - 2019-11-14 15:42:27 --> Loader Class Initialized
INFO - 2019-11-14 15:42:27 --> Helper loaded: url_helper
INFO - 2019-11-14 15:42:27 --> Helper loaded: common_helper
INFO - 2019-11-14 15:42:27 --> Helper loaded: language_helper
INFO - 2019-11-14 15:42:27 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:42:27 --> Helper loaded: email_helper
INFO - 2019-11-14 15:42:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:42:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:42:27 --> Parser Class Initialized
INFO - 2019-11-14 15:42:27 --> User Agent Class Initialized
INFO - 2019-11-14 15:42:27 --> Model Class Initialized
INFO - 2019-11-14 15:42:27 --> Database Driver Class Initialized
INFO - 2019-11-14 15:42:27 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:27 --> Template Class Initialized
INFO - 2019-11-14 15:42:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:42:27 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:42:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:42:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:42:27 --> Encryption Class Initialized
INFO - 2019-11-14 15:42:27 --> Controller Class Initialized
DEBUG - 2019-11-14 15:42:27 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:42:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:42:27 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:27 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:42:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:42:28 --> orders MX_Controller Initialized
DEBUG - 2019-11-14 15:42:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-14 15:42:28 --> Final output sent to browser
DEBUG - 2019-11-14 15:42:28 --> Total execution time: 1.7472
INFO - 2019-11-14 15:42:34 --> Config Class Initialized
INFO - 2019-11-14 15:42:34 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:42:34 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:42:34 --> Utf8 Class Initialized
INFO - 2019-11-14 15:42:34 --> URI Class Initialized
INFO - 2019-11-14 15:42:34 --> Router Class Initialized
INFO - 2019-11-14 15:42:34 --> Output Class Initialized
INFO - 2019-11-14 15:42:34 --> Security Class Initialized
DEBUG - 2019-11-14 15:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:42:34 --> Input Class Initialized
INFO - 2019-11-14 15:42:35 --> Language Class Initialized
INFO - 2019-11-14 15:42:35 --> Language Class Initialized
INFO - 2019-11-14 15:42:35 --> Config Class Initialized
INFO - 2019-11-14 15:42:35 --> Loader Class Initialized
INFO - 2019-11-14 15:42:35 --> Helper loaded: url_helper
INFO - 2019-11-14 15:42:35 --> Helper loaded: common_helper
INFO - 2019-11-14 15:42:35 --> Helper loaded: language_helper
INFO - 2019-11-14 15:42:35 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:42:35 --> Helper loaded: email_helper
INFO - 2019-11-14 15:42:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:42:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:42:35 --> Parser Class Initialized
INFO - 2019-11-14 15:42:35 --> User Agent Class Initialized
INFO - 2019-11-14 15:42:35 --> Model Class Initialized
INFO - 2019-11-14 15:42:35 --> Database Driver Class Initialized
INFO - 2019-11-14 15:42:35 --> Model Class Initialized
DEBUG - 2019-11-14 15:42:35 --> Template Class Initialized
INFO - 2019-11-14 15:42:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:42:35 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:42:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:42:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:42:35 --> Encryption Class Initialized
INFO - 2019-11-14 15:42:35 --> Controller Class Initialized
DEBUG - 2019-11-14 15:42:35 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:42:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:42:35 --> Model Class Initialized
ERROR - 2019-11-14 15:42:36 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 123
ERROR - 2019-11-14 15:42:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 123
INFO - 2019-11-14 15:43:32 --> Config Class Initialized
INFO - 2019-11-14 15:43:32 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:43:32 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:43:32 --> Utf8 Class Initialized
INFO - 2019-11-14 15:43:32 --> URI Class Initialized
INFO - 2019-11-14 15:43:32 --> Router Class Initialized
INFO - 2019-11-14 15:43:32 --> Output Class Initialized
INFO - 2019-11-14 15:43:32 --> Security Class Initialized
DEBUG - 2019-11-14 15:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:43:32 --> Input Class Initialized
INFO - 2019-11-14 15:43:32 --> Language Class Initialized
INFO - 2019-11-14 15:43:32 --> Language Class Initialized
INFO - 2019-11-14 15:43:32 --> Config Class Initialized
INFO - 2019-11-14 15:43:32 --> Loader Class Initialized
INFO - 2019-11-14 15:43:32 --> Helper loaded: url_helper
INFO - 2019-11-14 15:43:32 --> Helper loaded: common_helper
INFO - 2019-11-14 15:43:32 --> Helper loaded: language_helper
INFO - 2019-11-14 15:43:32 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:43:32 --> Helper loaded: email_helper
INFO - 2019-11-14 15:43:32 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:43:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:43:32 --> Parser Class Initialized
INFO - 2019-11-14 15:43:32 --> User Agent Class Initialized
INFO - 2019-11-14 15:43:32 --> Model Class Initialized
INFO - 2019-11-14 15:43:32 --> Database Driver Class Initialized
INFO - 2019-11-14 15:43:32 --> Model Class Initialized
DEBUG - 2019-11-14 15:43:32 --> Template Class Initialized
INFO - 2019-11-14 15:43:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:43:32 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:43:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:43:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:43:32 --> Encryption Class Initialized
INFO - 2019-11-14 15:43:32 --> Controller Class Initialized
DEBUG - 2019-11-14 15:43:32 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:43:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:43:32 --> Model Class Initialized
ERROR - 2019-11-14 15:43:34 --> Severity: Notice --> Undefined property: stdClass::$order_id D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 122
INFO - 2019-11-14 15:43:54 --> Config Class Initialized
INFO - 2019-11-14 15:43:54 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:43:54 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:43:54 --> Utf8 Class Initialized
INFO - 2019-11-14 15:43:54 --> URI Class Initialized
INFO - 2019-11-14 15:43:54 --> Router Class Initialized
INFO - 2019-11-14 15:43:54 --> Output Class Initialized
INFO - 2019-11-14 15:43:54 --> Security Class Initialized
DEBUG - 2019-11-14 15:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:43:54 --> Input Class Initialized
INFO - 2019-11-14 15:43:54 --> Language Class Initialized
INFO - 2019-11-14 15:43:55 --> Language Class Initialized
INFO - 2019-11-14 15:43:55 --> Config Class Initialized
INFO - 2019-11-14 15:43:55 --> Loader Class Initialized
INFO - 2019-11-14 15:43:55 --> Helper loaded: url_helper
INFO - 2019-11-14 15:43:55 --> Helper loaded: common_helper
INFO - 2019-11-14 15:43:55 --> Helper loaded: language_helper
INFO - 2019-11-14 15:43:55 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:43:55 --> Helper loaded: email_helper
INFO - 2019-11-14 15:43:55 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:43:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:43:55 --> Parser Class Initialized
INFO - 2019-11-14 15:43:55 --> User Agent Class Initialized
INFO - 2019-11-14 15:43:55 --> Model Class Initialized
INFO - 2019-11-14 15:43:55 --> Database Driver Class Initialized
INFO - 2019-11-14 15:43:55 --> Model Class Initialized
DEBUG - 2019-11-14 15:43:55 --> Template Class Initialized
INFO - 2019-11-14 15:43:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:43:55 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:43:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:43:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:43:55 --> Encryption Class Initialized
INFO - 2019-11-14 15:43:55 --> Controller Class Initialized
DEBUG - 2019-11-14 15:43:55 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:43:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:43:55 --> Model Class Initialized
INFO - 2019-11-14 15:44:11 --> Config Class Initialized
INFO - 2019-11-14 15:44:11 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:44:11 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:44:11 --> Utf8 Class Initialized
INFO - 2019-11-14 15:44:11 --> URI Class Initialized
INFO - 2019-11-14 15:44:12 --> Router Class Initialized
INFO - 2019-11-14 15:44:12 --> Output Class Initialized
INFO - 2019-11-14 15:44:12 --> Security Class Initialized
DEBUG - 2019-11-14 15:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:44:12 --> Input Class Initialized
INFO - 2019-11-14 15:44:12 --> Language Class Initialized
INFO - 2019-11-14 15:44:12 --> Language Class Initialized
INFO - 2019-11-14 15:44:12 --> Config Class Initialized
INFO - 2019-11-14 15:44:12 --> Loader Class Initialized
INFO - 2019-11-14 15:44:12 --> Helper loaded: url_helper
INFO - 2019-11-14 15:44:12 --> Helper loaded: common_helper
INFO - 2019-11-14 15:44:12 --> Helper loaded: language_helper
INFO - 2019-11-14 15:44:12 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:44:12 --> Helper loaded: email_helper
INFO - 2019-11-14 15:44:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:44:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:44:12 --> Parser Class Initialized
INFO - 2019-11-14 15:44:12 --> User Agent Class Initialized
INFO - 2019-11-14 15:44:12 --> Model Class Initialized
INFO - 2019-11-14 15:44:12 --> Database Driver Class Initialized
INFO - 2019-11-14 15:44:12 --> Model Class Initialized
DEBUG - 2019-11-14 15:44:12 --> Template Class Initialized
INFO - 2019-11-14 15:44:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:44:12 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:44:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:44:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:44:12 --> Encryption Class Initialized
INFO - 2019-11-14 15:44:12 --> Controller Class Initialized
DEBUG - 2019-11-14 15:44:12 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:44:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:44:12 --> Model Class Initialized
INFO - 2019-11-14 15:46:24 --> Config Class Initialized
INFO - 2019-11-14 15:46:24 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:46:24 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:46:24 --> Utf8 Class Initialized
INFO - 2019-11-14 15:46:24 --> URI Class Initialized
INFO - 2019-11-14 15:46:24 --> Router Class Initialized
INFO - 2019-11-14 15:46:25 --> Output Class Initialized
INFO - 2019-11-14 15:46:25 --> Security Class Initialized
DEBUG - 2019-11-14 15:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:46:25 --> Input Class Initialized
INFO - 2019-11-14 15:46:25 --> Language Class Initialized
INFO - 2019-11-14 15:46:25 --> Language Class Initialized
INFO - 2019-11-14 15:46:25 --> Config Class Initialized
INFO - 2019-11-14 15:46:25 --> Loader Class Initialized
INFO - 2019-11-14 15:46:25 --> Helper loaded: url_helper
INFO - 2019-11-14 15:46:25 --> Helper loaded: common_helper
INFO - 2019-11-14 15:46:25 --> Helper loaded: language_helper
INFO - 2019-11-14 15:46:25 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:46:25 --> Helper loaded: email_helper
INFO - 2019-11-14 15:46:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:46:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:46:25 --> Parser Class Initialized
INFO - 2019-11-14 15:46:25 --> User Agent Class Initialized
INFO - 2019-11-14 15:46:25 --> Model Class Initialized
INFO - 2019-11-14 15:46:25 --> Database Driver Class Initialized
INFO - 2019-11-14 15:46:25 --> Model Class Initialized
DEBUG - 2019-11-14 15:46:25 --> Template Class Initialized
INFO - 2019-11-14 15:46:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:46:25 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:46:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:46:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:46:25 --> Encryption Class Initialized
INFO - 2019-11-14 15:46:25 --> Controller Class Initialized
DEBUG - 2019-11-14 15:46:25 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:46:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:46:25 --> Model Class Initialized
ERROR - 2019-11-14 15:46:26 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 129
ERROR - 2019-11-14 15:46:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 129
INFO - 2019-11-14 15:46:26 --> Config Class Initialized
INFO - 2019-11-14 15:46:26 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:46:26 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:46:26 --> Utf8 Class Initialized
INFO - 2019-11-14 15:46:26 --> URI Class Initialized
INFO - 2019-11-14 15:46:26 --> Router Class Initialized
INFO - 2019-11-14 15:46:26 --> Output Class Initialized
INFO - 2019-11-14 15:46:26 --> Security Class Initialized
DEBUG - 2019-11-14 15:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:46:26 --> CSRF cookie sent
INFO - 2019-11-14 15:46:26 --> Input Class Initialized
INFO - 2019-11-14 15:46:26 --> Language Class Initialized
INFO - 2019-11-14 15:46:26 --> Language Class Initialized
INFO - 2019-11-14 15:46:26 --> Config Class Initialized
INFO - 2019-11-14 15:46:26 --> Loader Class Initialized
INFO - 2019-11-14 15:46:26 --> Helper loaded: url_helper
INFO - 2019-11-14 15:46:26 --> Helper loaded: common_helper
INFO - 2019-11-14 15:46:26 --> Helper loaded: language_helper
INFO - 2019-11-14 15:46:26 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:46:26 --> Helper loaded: email_helper
INFO - 2019-11-14 15:46:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:46:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:46:27 --> Parser Class Initialized
INFO - 2019-11-14 15:46:27 --> User Agent Class Initialized
INFO - 2019-11-14 15:46:27 --> Model Class Initialized
INFO - 2019-11-14 15:46:27 --> Database Driver Class Initialized
INFO - 2019-11-14 15:46:27 --> Model Class Initialized
DEBUG - 2019-11-14 15:46:27 --> Template Class Initialized
INFO - 2019-11-14 15:46:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:46:27 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:46:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:46:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:46:27 --> Encryption Class Initialized
INFO - 2019-11-14 15:46:27 --> Controller Class Initialized
DEBUG - 2019-11-14 15:46:27 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:46:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:46:27 --> Model Class Initialized
INFO - 2019-11-14 15:46:27 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:46:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-14 15:46:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:46:27 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:46:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:46:27 --> Model Class Initialized
DEBUG - 2019-11-14 15:46:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:46:27 --> Model Class Initialized
DEBUG - 2019-11-14 15:46:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:46:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:46:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:46:27 --> Final output sent to browser
DEBUG - 2019-11-14 15:46:27 --> Total execution time: 1.0013
INFO - 2019-11-14 15:46:28 --> Config Class Initialized
INFO - 2019-11-14 15:46:28 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:46:28 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:46:28 --> Utf8 Class Initialized
INFO - 2019-11-14 15:46:28 --> URI Class Initialized
INFO - 2019-11-14 15:46:28 --> Router Class Initialized
INFO - 2019-11-14 15:46:28 --> Output Class Initialized
INFO - 2019-11-14 15:46:28 --> Security Class Initialized
DEBUG - 2019-11-14 15:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:46:28 --> CSRF cookie sent
INFO - 2019-11-14 15:46:28 --> Input Class Initialized
INFO - 2019-11-14 15:46:28 --> Language Class Initialized
INFO - 2019-11-14 15:46:28 --> Language Class Initialized
INFO - 2019-11-14 15:46:28 --> Config Class Initialized
INFO - 2019-11-14 15:46:28 --> Loader Class Initialized
INFO - 2019-11-14 15:46:28 --> Helper loaded: url_helper
INFO - 2019-11-14 15:46:28 --> Helper loaded: common_helper
INFO - 2019-11-14 15:46:28 --> Helper loaded: language_helper
INFO - 2019-11-14 15:46:28 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:46:28 --> Helper loaded: email_helper
INFO - 2019-11-14 15:46:28 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:46:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:46:28 --> Parser Class Initialized
INFO - 2019-11-14 15:46:28 --> User Agent Class Initialized
INFO - 2019-11-14 15:46:28 --> Model Class Initialized
INFO - 2019-11-14 15:46:28 --> Database Driver Class Initialized
INFO - 2019-11-14 15:46:28 --> Model Class Initialized
DEBUG - 2019-11-14 15:46:28 --> Template Class Initialized
INFO - 2019-11-14 15:46:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:46:28 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:46:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:46:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:46:28 --> Encryption Class Initialized
INFO - 2019-11-14 15:46:28 --> Controller Class Initialized
DEBUG - 2019-11-14 15:46:29 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:46:29 --> Model Class Initialized
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:46:29 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:46:29 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-14 15:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:46:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:46:29 --> Model Class Initialized
DEBUG - 2019-11-14 15:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:46:29 --> Model Class Initialized
DEBUG - 2019-11-14 15:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:46:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:46:29 --> Final output sent to browser
DEBUG - 2019-11-14 15:46:29 --> Total execution time: 1.3076
INFO - 2019-11-14 15:47:41 --> Config Class Initialized
INFO - 2019-11-14 15:47:41 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:47:41 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:47:41 --> Utf8 Class Initialized
INFO - 2019-11-14 15:47:41 --> URI Class Initialized
INFO - 2019-11-14 15:47:41 --> Router Class Initialized
INFO - 2019-11-14 15:47:41 --> Output Class Initialized
INFO - 2019-11-14 15:47:41 --> Security Class Initialized
DEBUG - 2019-11-14 15:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:47:41 --> CSRF cookie sent
INFO - 2019-11-14 15:47:41 --> Input Class Initialized
INFO - 2019-11-14 15:47:41 --> Language Class Initialized
INFO - 2019-11-14 15:47:41 --> Language Class Initialized
INFO - 2019-11-14 15:47:41 --> Config Class Initialized
INFO - 2019-11-14 15:47:41 --> Loader Class Initialized
INFO - 2019-11-14 15:47:41 --> Helper loaded: url_helper
INFO - 2019-11-14 15:47:41 --> Helper loaded: common_helper
INFO - 2019-11-14 15:47:41 --> Helper loaded: language_helper
INFO - 2019-11-14 15:47:41 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:47:41 --> Helper loaded: email_helper
INFO - 2019-11-14 15:47:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:47:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:47:42 --> Parser Class Initialized
INFO - 2019-11-14 15:47:42 --> User Agent Class Initialized
INFO - 2019-11-14 15:47:42 --> Model Class Initialized
INFO - 2019-11-14 15:47:42 --> Database Driver Class Initialized
INFO - 2019-11-14 15:47:42 --> Model Class Initialized
DEBUG - 2019-11-14 15:47:42 --> Template Class Initialized
INFO - 2019-11-14 15:47:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:47:42 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:47:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:47:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:47:42 --> Encryption Class Initialized
INFO - 2019-11-14 15:47:42 --> Controller Class Initialized
DEBUG - 2019-11-14 15:47:42 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:47:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:47:42 --> Model Class Initialized
INFO - 2019-11-14 15:47:42 --> Config Class Initialized
INFO - 2019-11-14 15:47:42 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:47:42 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:47:42 --> Utf8 Class Initialized
INFO - 2019-11-14 15:47:42 --> URI Class Initialized
DEBUG - 2019-11-14 15:47:42 --> No URI present. Default controller set.
INFO - 2019-11-14 15:47:42 --> Router Class Initialized
INFO - 2019-11-14 15:47:42 --> Output Class Initialized
INFO - 2019-11-14 15:47:42 --> Security Class Initialized
DEBUG - 2019-11-14 15:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:47:42 --> CSRF cookie sent
INFO - 2019-11-14 15:47:42 --> Input Class Initialized
INFO - 2019-11-14 15:47:42 --> Language Class Initialized
INFO - 2019-11-14 15:47:42 --> Language Class Initialized
INFO - 2019-11-14 15:47:42 --> Config Class Initialized
INFO - 2019-11-14 15:47:42 --> Loader Class Initialized
INFO - 2019-11-14 15:47:42 --> Helper loaded: url_helper
INFO - 2019-11-14 15:47:42 --> Helper loaded: common_helper
INFO - 2019-11-14 15:47:42 --> Helper loaded: language_helper
INFO - 2019-11-14 15:47:42 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:47:42 --> Helper loaded: email_helper
INFO - 2019-11-14 15:47:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:47:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:47:42 --> Parser Class Initialized
INFO - 2019-11-14 15:47:42 --> User Agent Class Initialized
INFO - 2019-11-14 15:47:42 --> Model Class Initialized
INFO - 2019-11-14 15:47:42 --> Database Driver Class Initialized
INFO - 2019-11-14 15:47:42 --> Model Class Initialized
DEBUG - 2019-11-14 15:47:42 --> Template Class Initialized
INFO - 2019-11-14 15:47:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:47:42 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:47:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:47:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:47:43 --> Encryption Class Initialized
DEBUG - 2019-11-14 15:47:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 15:47:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-14 15:47:43 --> Controller Class Initialized
DEBUG - 2019-11-14 15:47:43 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 15:47:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 15:47:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-14 15:47:43 --> Model Class Initialized
INFO - 2019-11-14 15:47:43 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:47:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 15:47:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 15:47:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-14 15:47:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-14 15:47:43 --> Final output sent to browser
DEBUG - 2019-11-14 15:47:43 --> Total execution time: 0.9057
INFO - 2019-11-14 15:47:47 --> Config Class Initialized
INFO - 2019-11-14 15:47:47 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:47:47 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:47:48 --> Utf8 Class Initialized
INFO - 2019-11-14 15:47:48 --> URI Class Initialized
INFO - 2019-11-14 15:47:48 --> Router Class Initialized
INFO - 2019-11-14 15:47:48 --> Output Class Initialized
INFO - 2019-11-14 15:47:48 --> Security Class Initialized
DEBUG - 2019-11-14 15:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:47:48 --> CSRF cookie sent
INFO - 2019-11-14 15:47:48 --> Input Class Initialized
INFO - 2019-11-14 15:47:48 --> Language Class Initialized
INFO - 2019-11-14 15:47:48 --> Language Class Initialized
INFO - 2019-11-14 15:47:48 --> Config Class Initialized
INFO - 2019-11-14 15:47:48 --> Loader Class Initialized
INFO - 2019-11-14 15:47:48 --> Helper loaded: url_helper
INFO - 2019-11-14 15:47:48 --> Helper loaded: common_helper
INFO - 2019-11-14 15:47:48 --> Helper loaded: language_helper
INFO - 2019-11-14 15:47:48 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:47:48 --> Helper loaded: email_helper
INFO - 2019-11-14 15:47:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:47:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:47:48 --> Parser Class Initialized
INFO - 2019-11-14 15:47:48 --> User Agent Class Initialized
INFO - 2019-11-14 15:47:48 --> Model Class Initialized
INFO - 2019-11-14 15:47:48 --> Database Driver Class Initialized
INFO - 2019-11-14 15:47:48 --> Model Class Initialized
DEBUG - 2019-11-14 15:47:48 --> Template Class Initialized
INFO - 2019-11-14 15:47:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:47:48 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:47:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:47:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:47:48 --> Encryption Class Initialized
INFO - 2019-11-14 15:47:48 --> Controller Class Initialized
DEBUG - 2019-11-14 15:47:48 --> package MX_Controller Initialized
DEBUG - 2019-11-14 15:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-14 15:47:48 --> Model Class Initialized
INFO - 2019-11-14 15:47:48 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:47:48 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:47:48 --> Model Class Initialized
DEBUG - 2019-11-14 15:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:47:48 --> Model Class Initialized
DEBUG - 2019-11-14 15:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-14 15:47:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-14 15:47:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:47:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:47:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:47:49 --> Final output sent to browser
DEBUG - 2019-11-14 15:47:49 --> Total execution time: 1.1717
INFO - 2019-11-14 15:47:51 --> Config Class Initialized
INFO - 2019-11-14 15:47:52 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:47:52 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:47:52 --> Utf8 Class Initialized
INFO - 2019-11-14 15:47:52 --> URI Class Initialized
INFO - 2019-11-14 15:47:52 --> Router Class Initialized
INFO - 2019-11-14 15:47:52 --> Output Class Initialized
INFO - 2019-11-14 15:47:52 --> Security Class Initialized
DEBUG - 2019-11-14 15:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:47:52 --> CSRF cookie sent
INFO - 2019-11-14 15:47:52 --> CSRF token verified
INFO - 2019-11-14 15:47:52 --> Input Class Initialized
INFO - 2019-11-14 15:47:52 --> Language Class Initialized
INFO - 2019-11-14 15:47:52 --> Language Class Initialized
INFO - 2019-11-14 15:47:52 --> Config Class Initialized
INFO - 2019-11-14 15:47:52 --> Loader Class Initialized
INFO - 2019-11-14 15:47:52 --> Helper loaded: url_helper
INFO - 2019-11-14 15:47:52 --> Helper loaded: common_helper
INFO - 2019-11-14 15:47:52 --> Helper loaded: language_helper
INFO - 2019-11-14 15:47:52 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:47:52 --> Helper loaded: email_helper
INFO - 2019-11-14 15:47:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:47:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:47:52 --> Parser Class Initialized
INFO - 2019-11-14 15:47:52 --> User Agent Class Initialized
INFO - 2019-11-14 15:47:52 --> Model Class Initialized
INFO - 2019-11-14 15:47:52 --> Database Driver Class Initialized
INFO - 2019-11-14 15:47:52 --> Model Class Initialized
DEBUG - 2019-11-14 15:47:52 --> Template Class Initialized
INFO - 2019-11-14 15:47:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:47:52 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:47:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:47:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:47:52 --> Encryption Class Initialized
INFO - 2019-11-14 15:47:52 --> Controller Class Initialized
DEBUG - 2019-11-14 15:47:52 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:47:52 --> Model Class Initialized
INFO - 2019-11-14 15:47:52 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:47:52 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 15:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 15:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:47:52 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:47:52 --> Model Class Initialized
DEBUG - 2019-11-14 15:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:47:52 --> Model Class Initialized
DEBUG - 2019-11-14 15:47:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:47:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:47:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:47:53 --> Final output sent to browser
DEBUG - 2019-11-14 15:47:53 --> Total execution time: 1.0722
INFO - 2019-11-14 15:48:00 --> Config Class Initialized
INFO - 2019-11-14 15:48:00 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:48:00 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:48:00 --> Utf8 Class Initialized
INFO - 2019-11-14 15:48:00 --> URI Class Initialized
INFO - 2019-11-14 15:48:00 --> Router Class Initialized
INFO - 2019-11-14 15:48:00 --> Output Class Initialized
INFO - 2019-11-14 15:48:00 --> Security Class Initialized
DEBUG - 2019-11-14 15:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:48:00 --> CSRF cookie sent
INFO - 2019-11-14 15:48:00 --> CSRF token verified
INFO - 2019-11-14 15:48:00 --> Input Class Initialized
INFO - 2019-11-14 15:48:00 --> Language Class Initialized
INFO - 2019-11-14 15:48:00 --> Language Class Initialized
INFO - 2019-11-14 15:48:00 --> Config Class Initialized
INFO - 2019-11-14 15:48:00 --> Loader Class Initialized
INFO - 2019-11-14 15:48:00 --> Helper loaded: url_helper
INFO - 2019-11-14 15:48:00 --> Helper loaded: common_helper
INFO - 2019-11-14 15:48:00 --> Helper loaded: language_helper
INFO - 2019-11-14 15:48:00 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:48:00 --> Helper loaded: email_helper
INFO - 2019-11-14 15:48:00 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:48:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:48:01 --> Parser Class Initialized
INFO - 2019-11-14 15:48:01 --> User Agent Class Initialized
INFO - 2019-11-14 15:48:01 --> Model Class Initialized
INFO - 2019-11-14 15:48:01 --> Database Driver Class Initialized
INFO - 2019-11-14 15:48:01 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:01 --> Template Class Initialized
INFO - 2019-11-14 15:48:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:48:01 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:48:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:48:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:48:01 --> Encryption Class Initialized
INFO - 2019-11-14 15:48:01 --> Controller Class Initialized
DEBUG - 2019-11-14 15:48:01 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:48:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:48:01 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:01 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:48:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:48:02 --> orders MX_Controller Initialized
DEBUG - 2019-11-14 15:48:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-14 15:48:02 --> Final output sent to browser
DEBUG - 2019-11-14 15:48:02 --> Total execution time: 1.8216
INFO - 2019-11-14 15:48:11 --> Config Class Initialized
INFO - 2019-11-14 15:48:11 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:48:11 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:48:11 --> Utf8 Class Initialized
INFO - 2019-11-14 15:48:11 --> URI Class Initialized
INFO - 2019-11-14 15:48:11 --> Router Class Initialized
INFO - 2019-11-14 15:48:11 --> Output Class Initialized
INFO - 2019-11-14 15:48:11 --> Security Class Initialized
DEBUG - 2019-11-14 15:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:48:11 --> CSRF cookie sent
INFO - 2019-11-14 15:48:11 --> Input Class Initialized
INFO - 2019-11-14 15:48:11 --> Language Class Initialized
INFO - 2019-11-14 15:48:11 --> Language Class Initialized
INFO - 2019-11-14 15:48:11 --> Config Class Initialized
INFO - 2019-11-14 15:48:11 --> Loader Class Initialized
INFO - 2019-11-14 15:48:11 --> Config Class Initialized
INFO - 2019-11-14 15:48:11 --> Hooks Class Initialized
INFO - 2019-11-14 15:48:11 --> Helper loaded: url_helper
DEBUG - 2019-11-14 15:48:11 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:48:11 --> Helper loaded: common_helper
INFO - 2019-11-14 15:48:11 --> Utf8 Class Initialized
INFO - 2019-11-14 15:48:11 --> Helper loaded: language_helper
INFO - 2019-11-14 15:48:11 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:48:11 --> URI Class Initialized
INFO - 2019-11-14 15:48:11 --> Helper loaded: email_helper
INFO - 2019-11-14 15:48:11 --> Router Class Initialized
INFO - 2019-11-14 15:48:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:48:11 --> Output Class Initialized
INFO - 2019-11-14 15:48:11 --> Security Class Initialized
INFO - 2019-11-14 15:48:11 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-14 15:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:48:11 --> Parser Class Initialized
INFO - 2019-11-14 15:48:11 --> Input Class Initialized
INFO - 2019-11-14 15:48:11 --> User Agent Class Initialized
INFO - 2019-11-14 15:48:11 --> Language Class Initialized
INFO - 2019-11-14 15:48:11 --> Model Class Initialized
INFO - 2019-11-14 15:48:11 --> Language Class Initialized
INFO - 2019-11-14 15:48:11 --> Database Driver Class Initialized
INFO - 2019-11-14 15:48:11 --> Config Class Initialized
INFO - 2019-11-14 15:48:11 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:11 --> Template Class Initialized
INFO - 2019-11-14 15:48:11 --> Loader Class Initialized
INFO - 2019-11-14 15:48:11 --> Helper loaded: url_helper
INFO - 2019-11-14 15:48:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:48:11 --> Helper loaded: common_helper
INFO - 2019-11-14 15:48:11 --> Pagination Class Initialized
INFO - 2019-11-14 15:48:11 --> Helper loaded: language_helper
INFO - 2019-11-14 15:48:11 --> Helper loaded: cookie_helper
DEBUG - 2019-11-14 15:48:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:48:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:48:12 --> Helper loaded: email_helper
INFO - 2019-11-14 15:48:12 --> Encryption Class Initialized
INFO - 2019-11-14 15:48:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:48:12 --> Controller Class Initialized
INFO - 2019-11-14 15:48:12 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-14 15:48:12 --> order MX_Controller Initialized
INFO - 2019-11-14 15:48:12 --> Parser Class Initialized
DEBUG - 2019-11-14 15:48:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:48:12 --> User Agent Class Initialized
INFO - 2019-11-14 15:48:12 --> Model Class Initialized
INFO - 2019-11-14 15:48:12 --> Model Class Initialized
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:48:12 --> Database Driver Class Initialized
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:48:12 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:12 --> Template Class Initialized
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:48:12 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:48:12 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-14 15:48:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:48:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:48:12 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:48:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:48:12 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:48:12 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:48:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:48:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:48:12 --> Final output sent to browser
DEBUG - 2019-11-14 15:48:12 --> Total execution time: 1.2185
INFO - 2019-11-14 15:48:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:48:12 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:48:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:48:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:48:12 --> Encryption Class Initialized
INFO - 2019-11-14 15:48:12 --> Controller Class Initialized
DEBUG - 2019-11-14 15:48:12 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:48:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:48:12 --> Model Class Initialized
ERROR - 2019-11-14 15:48:13 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 129
ERROR - 2019-11-14 15:48:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\mollie.php 129
INFO - 2019-11-14 15:48:13 --> Config Class Initialized
INFO - 2019-11-14 15:48:13 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:48:13 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:48:13 --> Utf8 Class Initialized
INFO - 2019-11-14 15:48:13 --> URI Class Initialized
INFO - 2019-11-14 15:48:13 --> Router Class Initialized
INFO - 2019-11-14 15:48:14 --> Output Class Initialized
INFO - 2019-11-14 15:48:14 --> Security Class Initialized
DEBUG - 2019-11-14 15:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:48:14 --> CSRF cookie sent
INFO - 2019-11-14 15:48:14 --> Input Class Initialized
INFO - 2019-11-14 15:48:14 --> Language Class Initialized
INFO - 2019-11-14 15:48:14 --> Language Class Initialized
INFO - 2019-11-14 15:48:14 --> Config Class Initialized
INFO - 2019-11-14 15:48:14 --> Loader Class Initialized
INFO - 2019-11-14 15:48:14 --> Helper loaded: url_helper
INFO - 2019-11-14 15:48:14 --> Helper loaded: common_helper
INFO - 2019-11-14 15:48:14 --> Helper loaded: language_helper
INFO - 2019-11-14 15:48:14 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:48:14 --> Helper loaded: email_helper
INFO - 2019-11-14 15:48:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:48:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:48:14 --> Parser Class Initialized
INFO - 2019-11-14 15:48:14 --> User Agent Class Initialized
INFO - 2019-11-14 15:48:14 --> Model Class Initialized
INFO - 2019-11-14 15:48:14 --> Database Driver Class Initialized
INFO - 2019-11-14 15:48:14 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:14 --> Template Class Initialized
INFO - 2019-11-14 15:48:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:48:14 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:48:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:48:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:48:14 --> Encryption Class Initialized
INFO - 2019-11-14 15:48:14 --> Controller Class Initialized
DEBUG - 2019-11-14 15:48:14 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:48:14 --> Model Class Initialized
INFO - 2019-11-14 15:48:14 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-14 15:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:48:14 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:48:14 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:48:14 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:48:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:48:14 --> Final output sent to browser
DEBUG - 2019-11-14 15:48:14 --> Total execution time: 1.0511
INFO - 2019-11-14 15:48:19 --> Config Class Initialized
INFO - 2019-11-14 15:48:19 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:48:19 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:48:19 --> Utf8 Class Initialized
INFO - 2019-11-14 15:48:19 --> URI Class Initialized
INFO - 2019-11-14 15:48:19 --> Router Class Initialized
INFO - 2019-11-14 15:48:19 --> Output Class Initialized
INFO - 2019-11-14 15:48:19 --> Security Class Initialized
DEBUG - 2019-11-14 15:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:48:19 --> CSRF cookie sent
INFO - 2019-11-14 15:48:19 --> Input Class Initialized
INFO - 2019-11-14 15:48:19 --> Language Class Initialized
INFO - 2019-11-14 15:48:19 --> Language Class Initialized
INFO - 2019-11-14 15:48:19 --> Config Class Initialized
INFO - 2019-11-14 15:48:19 --> Loader Class Initialized
INFO - 2019-11-14 15:48:19 --> Helper loaded: url_helper
INFO - 2019-11-14 15:48:19 --> Helper loaded: common_helper
INFO - 2019-11-14 15:48:19 --> Helper loaded: language_helper
INFO - 2019-11-14 15:48:19 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:48:19 --> Helper loaded: email_helper
INFO - 2019-11-14 15:48:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:48:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:48:19 --> Parser Class Initialized
INFO - 2019-11-14 15:48:19 --> User Agent Class Initialized
INFO - 2019-11-14 15:48:19 --> Model Class Initialized
INFO - 2019-11-14 15:48:19 --> Database Driver Class Initialized
INFO - 2019-11-14 15:48:20 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:20 --> Template Class Initialized
INFO - 2019-11-14 15:48:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:48:20 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:48:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:48:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:48:20 --> Encryption Class Initialized
INFO - 2019-11-14 15:48:20 --> Controller Class Initialized
DEBUG - 2019-11-14 15:48:20 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:48:20 --> Model Class Initialized
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:48:20 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:48:20 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-14 15:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:48:20 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:48:20 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:48:20 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:48:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:48:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:48:21 --> Final output sent to browser
DEBUG - 2019-11-14 15:48:21 --> Total execution time: 1.8052
INFO - 2019-11-14 15:48:23 --> Config Class Initialized
INFO - 2019-11-14 15:48:23 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:48:23 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:48:23 --> Utf8 Class Initialized
INFO - 2019-11-14 15:48:23 --> URI Class Initialized
INFO - 2019-11-14 15:48:23 --> Router Class Initialized
INFO - 2019-11-14 15:48:23 --> Output Class Initialized
INFO - 2019-11-14 15:48:23 --> Security Class Initialized
DEBUG - 2019-11-14 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:48:23 --> CSRF cookie sent
INFO - 2019-11-14 15:48:23 --> Input Class Initialized
INFO - 2019-11-14 15:48:23 --> Language Class Initialized
INFO - 2019-11-14 15:48:23 --> Language Class Initialized
INFO - 2019-11-14 15:48:23 --> Config Class Initialized
INFO - 2019-11-14 15:48:23 --> Loader Class Initialized
INFO - 2019-11-14 15:48:23 --> Helper loaded: url_helper
INFO - 2019-11-14 15:48:23 --> Helper loaded: common_helper
INFO - 2019-11-14 15:48:23 --> Helper loaded: language_helper
INFO - 2019-11-14 15:48:23 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:48:23 --> Helper loaded: email_helper
INFO - 2019-11-14 15:48:23 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:48:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:48:23 --> Parser Class Initialized
INFO - 2019-11-14 15:48:23 --> User Agent Class Initialized
INFO - 2019-11-14 15:48:23 --> Model Class Initialized
INFO - 2019-11-14 15:48:23 --> Database Driver Class Initialized
INFO - 2019-11-14 15:48:23 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:23 --> Template Class Initialized
INFO - 2019-11-14 15:48:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:48:23 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:48:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:48:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:48:23 --> Encryption Class Initialized
INFO - 2019-11-14 15:48:24 --> Controller Class Initialized
DEBUG - 2019-11-14 15:48:24 --> transactions MX_Controller Initialized
DEBUG - 2019-11-14 15:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-14 15:48:24 --> Model Class Initialized
ERROR - 2019-11-14 15:48:24 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:48:24 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-14 15:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:48:24 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:48:24 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:48:24 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:48:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:48:24 --> Final output sent to browser
DEBUG - 2019-11-14 15:48:24 --> Total execution time: 1.2752
INFO - 2019-11-14 15:48:27 --> Config Class Initialized
INFO - 2019-11-14 15:48:27 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:48:27 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:48:27 --> Utf8 Class Initialized
INFO - 2019-11-14 15:48:27 --> URI Class Initialized
INFO - 2019-11-14 15:48:27 --> Router Class Initialized
INFO - 2019-11-14 15:48:27 --> Output Class Initialized
INFO - 2019-11-14 15:48:27 --> Security Class Initialized
DEBUG - 2019-11-14 15:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:48:27 --> CSRF cookie sent
INFO - 2019-11-14 15:48:27 --> Input Class Initialized
INFO - 2019-11-14 15:48:27 --> Language Class Initialized
INFO - 2019-11-14 15:48:27 --> Language Class Initialized
INFO - 2019-11-14 15:48:27 --> Config Class Initialized
INFO - 2019-11-14 15:48:27 --> Loader Class Initialized
INFO - 2019-11-14 15:48:27 --> Helper loaded: url_helper
INFO - 2019-11-14 15:48:27 --> Helper loaded: common_helper
INFO - 2019-11-14 15:48:27 --> Helper loaded: language_helper
INFO - 2019-11-14 15:48:27 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:48:27 --> Helper loaded: email_helper
INFO - 2019-11-14 15:48:27 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:48:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:48:27 --> Parser Class Initialized
INFO - 2019-11-14 15:48:27 --> User Agent Class Initialized
INFO - 2019-11-14 15:48:27 --> Model Class Initialized
INFO - 2019-11-14 15:48:27 --> Database Driver Class Initialized
INFO - 2019-11-14 15:48:27 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:28 --> Template Class Initialized
INFO - 2019-11-14 15:48:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:48:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:48:28 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:48:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:48:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:48:28 --> Encryption Class Initialized
INFO - 2019-11-14 15:48:28 --> Controller Class Initialized
DEBUG - 2019-11-14 15:48:28 --> transactions MX_Controller Initialized
DEBUG - 2019-11-14 15:48:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-14 15:48:28 --> Model Class Initialized
ERROR - 2019-11-14 15:48:28 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:48:28 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:48:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-14 15:48:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:48:28 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:48:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:48:28 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:48:28 --> Model Class Initialized
DEBUG - 2019-11-14 15:48:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:48:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:48:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:48:28 --> Final output sent to browser
DEBUG - 2019-11-14 15:48:28 --> Total execution time: 1.1468
INFO - 2019-11-14 15:49:16 --> Config Class Initialized
INFO - 2019-11-14 15:49:16 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:49:16 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:16 --> Utf8 Class Initialized
INFO - 2019-11-14 15:49:16 --> URI Class Initialized
INFO - 2019-11-14 15:49:16 --> Router Class Initialized
INFO - 2019-11-14 15:49:16 --> Output Class Initialized
INFO - 2019-11-14 15:49:16 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:16 --> CSRF cookie sent
INFO - 2019-11-14 15:49:16 --> Input Class Initialized
INFO - 2019-11-14 15:49:16 --> Language Class Initialized
INFO - 2019-11-14 15:49:16 --> Language Class Initialized
INFO - 2019-11-14 15:49:16 --> Config Class Initialized
INFO - 2019-11-14 15:49:16 --> Loader Class Initialized
INFO - 2019-11-14 15:49:16 --> Helper loaded: url_helper
INFO - 2019-11-14 15:49:16 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:16 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:17 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:49:17 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:49:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:17 --> Parser Class Initialized
INFO - 2019-11-14 15:49:17 --> User Agent Class Initialized
INFO - 2019-11-14 15:49:17 --> Model Class Initialized
INFO - 2019-11-14 15:49:17 --> Database Driver Class Initialized
INFO - 2019-11-14 15:49:17 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:17 --> Template Class Initialized
INFO - 2019-11-14 15:49:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:17 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:49:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:17 --> Encryption Class Initialized
INFO - 2019-11-14 15:49:17 --> Controller Class Initialized
DEBUG - 2019-11-14 15:49:17 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:49:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:49:17 --> Model Class Initialized
INFO - 2019-11-14 15:49:17 --> Config Class Initialized
INFO - 2019-11-14 15:49:17 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:49:17 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:17 --> Utf8 Class Initialized
INFO - 2019-11-14 15:49:17 --> URI Class Initialized
DEBUG - 2019-11-14 15:49:17 --> No URI present. Default controller set.
INFO - 2019-11-14 15:49:17 --> Router Class Initialized
INFO - 2019-11-14 15:49:17 --> Output Class Initialized
INFO - 2019-11-14 15:49:17 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:17 --> CSRF cookie sent
INFO - 2019-11-14 15:49:17 --> Input Class Initialized
INFO - 2019-11-14 15:49:17 --> Language Class Initialized
INFO - 2019-11-14 15:49:17 --> Language Class Initialized
INFO - 2019-11-14 15:49:17 --> Config Class Initialized
INFO - 2019-11-14 15:49:17 --> Loader Class Initialized
INFO - 2019-11-14 15:49:17 --> Helper loaded: url_helper
INFO - 2019-11-14 15:49:17 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:17 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:17 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:49:17 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:49:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:17 --> Parser Class Initialized
INFO - 2019-11-14 15:49:17 --> User Agent Class Initialized
INFO - 2019-11-14 15:49:17 --> Model Class Initialized
INFO - 2019-11-14 15:49:17 --> Database Driver Class Initialized
INFO - 2019-11-14 15:49:17 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:17 --> Template Class Initialized
INFO - 2019-11-14 15:49:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:17 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:49:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:18 --> Encryption Class Initialized
DEBUG - 2019-11-14 15:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 15:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-14 15:49:18 --> Controller Class Initialized
DEBUG - 2019-11-14 15:49:18 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 15:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 15:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-14 15:49:18 --> Model Class Initialized
INFO - 2019-11-14 15:49:18 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 15:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 15:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-14 15:49:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-14 15:49:18 --> Final output sent to browser
DEBUG - 2019-11-14 15:49:18 --> Total execution time: 0.9111
INFO - 2019-11-14 15:49:20 --> Config Class Initialized
INFO - 2019-11-14 15:49:20 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:49:20 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:20 --> Utf8 Class Initialized
INFO - 2019-11-14 15:49:20 --> URI Class Initialized
INFO - 2019-11-14 15:49:21 --> Router Class Initialized
INFO - 2019-11-14 15:49:21 --> Output Class Initialized
INFO - 2019-11-14 15:49:21 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:21 --> CSRF cookie sent
INFO - 2019-11-14 15:49:21 --> Input Class Initialized
INFO - 2019-11-14 15:49:21 --> Language Class Initialized
INFO - 2019-11-14 15:49:21 --> Language Class Initialized
INFO - 2019-11-14 15:49:21 --> Config Class Initialized
INFO - 2019-11-14 15:49:21 --> Loader Class Initialized
INFO - 2019-11-14 15:49:21 --> Helper loaded: url_helper
INFO - 2019-11-14 15:49:21 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:21 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:21 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:49:21 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:49:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:21 --> Parser Class Initialized
INFO - 2019-11-14 15:49:21 --> User Agent Class Initialized
INFO - 2019-11-14 15:49:21 --> Model Class Initialized
INFO - 2019-11-14 15:49:21 --> Database Driver Class Initialized
INFO - 2019-11-14 15:49:21 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:21 --> Template Class Initialized
INFO - 2019-11-14 15:49:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:21 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:49:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:21 --> Encryption Class Initialized
INFO - 2019-11-14 15:49:21 --> Controller Class Initialized
DEBUG - 2019-11-14 15:49:21 --> package MX_Controller Initialized
DEBUG - 2019-11-14 15:49:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-14 15:49:21 --> Model Class Initialized
INFO - 2019-11-14 15:49:21 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:49:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:49:21 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:49:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:49:21 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:49:21 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-14 15:49:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-14 15:49:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:49:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:49:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:49:22 --> Final output sent to browser
DEBUG - 2019-11-14 15:49:22 --> Total execution time: 1.1983
INFO - 2019-11-14 15:49:24 --> Config Class Initialized
INFO - 2019-11-14 15:49:24 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:49:24 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:24 --> Utf8 Class Initialized
INFO - 2019-11-14 15:49:24 --> URI Class Initialized
INFO - 2019-11-14 15:49:24 --> Router Class Initialized
INFO - 2019-11-14 15:49:24 --> Output Class Initialized
INFO - 2019-11-14 15:49:24 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:25 --> CSRF cookie sent
INFO - 2019-11-14 15:49:25 --> CSRF token verified
INFO - 2019-11-14 15:49:25 --> Input Class Initialized
INFO - 2019-11-14 15:49:25 --> Language Class Initialized
INFO - 2019-11-14 15:49:25 --> Language Class Initialized
INFO - 2019-11-14 15:49:25 --> Config Class Initialized
INFO - 2019-11-14 15:49:25 --> Loader Class Initialized
INFO - 2019-11-14 15:49:25 --> Helper loaded: url_helper
INFO - 2019-11-14 15:49:25 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:25 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:25 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:49:25 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:49:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:25 --> Parser Class Initialized
INFO - 2019-11-14 15:49:25 --> User Agent Class Initialized
INFO - 2019-11-14 15:49:25 --> Model Class Initialized
INFO - 2019-11-14 15:49:25 --> Database Driver Class Initialized
INFO - 2019-11-14 15:49:25 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:25 --> Template Class Initialized
INFO - 2019-11-14 15:49:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:25 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:49:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:25 --> Encryption Class Initialized
INFO - 2019-11-14 15:49:25 --> Controller Class Initialized
DEBUG - 2019-11-14 15:49:25 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:49:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:49:25 --> Model Class Initialized
INFO - 2019-11-14 15:49:25 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:49:25 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 15:49:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 15:49:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:49:25 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:49:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:49:25 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:49:25 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:49:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:49:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:49:25 --> Final output sent to browser
DEBUG - 2019-11-14 15:49:26 --> Total execution time: 1.1669
INFO - 2019-11-14 15:49:33 --> Config Class Initialized
INFO - 2019-11-14 15:49:33 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:49:33 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:33 --> Utf8 Class Initialized
INFO - 2019-11-14 15:49:33 --> URI Class Initialized
INFO - 2019-11-14 15:49:33 --> Router Class Initialized
INFO - 2019-11-14 15:49:33 --> Output Class Initialized
INFO - 2019-11-14 15:49:33 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:33 --> CSRF cookie sent
INFO - 2019-11-14 15:49:33 --> CSRF token verified
INFO - 2019-11-14 15:49:33 --> Input Class Initialized
INFO - 2019-11-14 15:49:33 --> Language Class Initialized
INFO - 2019-11-14 15:49:34 --> Language Class Initialized
INFO - 2019-11-14 15:49:34 --> Config Class Initialized
INFO - 2019-11-14 15:49:34 --> Loader Class Initialized
INFO - 2019-11-14 15:49:34 --> Helper loaded: url_helper
INFO - 2019-11-14 15:49:34 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:34 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:34 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:49:34 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:49:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:34 --> Parser Class Initialized
INFO - 2019-11-14 15:49:34 --> User Agent Class Initialized
INFO - 2019-11-14 15:49:34 --> Model Class Initialized
INFO - 2019-11-14 15:49:34 --> Database Driver Class Initialized
INFO - 2019-11-14 15:49:34 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:34 --> Template Class Initialized
INFO - 2019-11-14 15:49:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:34 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:49:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:34 --> Encryption Class Initialized
INFO - 2019-11-14 15:49:34 --> Controller Class Initialized
DEBUG - 2019-11-14 15:49:34 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:49:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:49:34 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:34 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:49:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:49:35 --> orders MX_Controller Initialized
DEBUG - 2019-11-14 15:49:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-14 15:49:35 --> Final output sent to browser
DEBUG - 2019-11-14 15:49:35 --> Total execution time: 2.1634
INFO - 2019-11-14 15:49:43 --> Config Class Initialized
INFO - 2019-11-14 15:49:43 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:49:43 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:43 --> Utf8 Class Initialized
INFO - 2019-11-14 15:49:43 --> URI Class Initialized
INFO - 2019-11-14 15:49:43 --> Router Class Initialized
INFO - 2019-11-14 15:49:43 --> Output Class Initialized
INFO - 2019-11-14 15:49:43 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:43 --> Input Class Initialized
INFO - 2019-11-14 15:49:43 --> Language Class Initialized
INFO - 2019-11-14 15:49:43 --> Language Class Initialized
INFO - 2019-11-14 15:49:43 --> Config Class Initialized
INFO - 2019-11-14 15:49:43 --> Loader Class Initialized
INFO - 2019-11-14 15:49:43 --> Helper loaded: url_helper
INFO - 2019-11-14 15:49:43 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:43 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:43 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:49:43 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:49:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:43 --> Parser Class Initialized
INFO - 2019-11-14 15:49:43 --> User Agent Class Initialized
INFO - 2019-11-14 15:49:43 --> Model Class Initialized
INFO - 2019-11-14 15:49:43 --> Database Driver Class Initialized
INFO - 2019-11-14 15:49:43 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:43 --> Template Class Initialized
INFO - 2019-11-14 15:49:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:43 --> Config Class Initialized
INFO - 2019-11-14 15:49:43 --> Hooks Class Initialized
INFO - 2019-11-14 15:49:43 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-14 15:49:43 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:43 --> Utf8 Class Initialized
INFO - 2019-11-14 15:49:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:43 --> Encryption Class Initialized
INFO - 2019-11-14 15:49:43 --> URI Class Initialized
INFO - 2019-11-14 15:49:43 --> Controller Class Initialized
INFO - 2019-11-14 15:49:43 --> Router Class Initialized
DEBUG - 2019-11-14 15:49:43 --> mollie MX_Controller Initialized
INFO - 2019-11-14 15:49:43 --> Output Class Initialized
INFO - 2019-11-14 15:49:43 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:43 --> Model Class Initialized
INFO - 2019-11-14 15:49:43 --> CSRF cookie sent
INFO - 2019-11-14 15:49:43 --> Input Class Initialized
INFO - 2019-11-14 15:49:43 --> Language Class Initialized
INFO - 2019-11-14 15:49:43 --> Language Class Initialized
INFO - 2019-11-14 15:49:43 --> Config Class Initialized
INFO - 2019-11-14 15:49:44 --> Loader Class Initialized
INFO - 2019-11-14 15:49:44 --> Helper loaded: url_helper
INFO - 2019-11-14 15:49:44 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:44 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:44 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:49:44 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:49:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:44 --> Parser Class Initialized
INFO - 2019-11-14 15:49:44 --> User Agent Class Initialized
INFO - 2019-11-14 15:49:44 --> Model Class Initialized
INFO - 2019-11-14 15:49:44 --> Database Driver Class Initialized
INFO - 2019-11-14 15:49:44 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:44 --> Template Class Initialized
INFO - 2019-11-14 15:49:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:44 --> Config Class Initialized
INFO - 2019-11-14 15:49:44 --> Hooks Class Initialized
INFO - 2019-11-14 15:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:44 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:44 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:44 --> Utf8 Class Initialized
DEBUG - 2019-11-14 15:49:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:49:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:44 --> URI Class Initialized
INFO - 2019-11-14 15:49:44 --> Encryption Class Initialized
INFO - 2019-11-14 15:49:44 --> Router Class Initialized
INFO - 2019-11-14 15:49:45 --> Controller Class Initialized
INFO - 2019-11-14 15:49:45 --> Output Class Initialized
DEBUG - 2019-11-14 15:49:45 --> transactions MX_Controller Initialized
INFO - 2019-11-14 15:49:45 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
DEBUG - 2019-11-14 15:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:45 --> Model Class Initialized
INFO - 2019-11-14 15:49:45 --> CSRF cookie sent
INFO - 2019-11-14 15:49:45 --> Input Class Initialized
ERROR - 2019-11-14 15:49:45 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:49:45 --> Language Class Initialized
INFO - 2019-11-14 15:49:45 --> Helper loaded: inflector_helper
INFO - 2019-11-14 15:49:45 --> Language Class Initialized
INFO - 2019-11-14 15:49:45 --> Config Class Initialized
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
INFO - 2019-11-14 15:49:45 --> Loader Class Initialized
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:49:45 --> blocks MX_Controller Initialized
INFO - 2019-11-14 15:49:45 --> Helper loaded: url_helper
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:49:45 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:45 --> Model Class Initialized
INFO - 2019-11-14 15:49:45 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:45 --> Helper loaded: cookie_helper
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:49:45 --> Model Class Initialized
INFO - 2019-11-14 15:49:45 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:45 --> Helper loaded: file_manager_helper
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
INFO - 2019-11-14 15:49:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:45 --> Parser Class Initialized
INFO - 2019-11-14 15:49:45 --> User Agent Class Initialized
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:49:45 --> Model Class Initialized
INFO - 2019-11-14 15:49:45 --> Final output sent to browser
INFO - 2019-11-14 15:49:45 --> Database Driver Class Initialized
DEBUG - 2019-11-14 15:49:45 --> Total execution time: 1.6666
INFO - 2019-11-14 15:49:45 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:45 --> Template Class Initialized
INFO - 2019-11-14 15:49:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:45 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:49:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:45 --> Encryption Class Initialized
INFO - 2019-11-14 15:49:45 --> Controller Class Initialized
DEBUG - 2019-11-14 15:49:45 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:49:45 --> Model Class Initialized
INFO - 2019-11-14 15:49:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:49:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:49:45 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:49:45 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:49:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:49:46 --> Final output sent to browser
DEBUG - 2019-11-14 15:49:46 --> Total execution time: 1.1159
INFO - 2019-11-14 15:49:50 --> Config Class Initialized
INFO - 2019-11-14 15:49:50 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:49:50 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:50 --> Utf8 Class Initialized
INFO - 2019-11-14 15:49:50 --> URI Class Initialized
INFO - 2019-11-14 15:49:50 --> Router Class Initialized
INFO - 2019-11-14 15:49:50 --> Output Class Initialized
INFO - 2019-11-14 15:49:50 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:50 --> CSRF cookie sent
INFO - 2019-11-14 15:49:50 --> Input Class Initialized
INFO - 2019-11-14 15:49:50 --> Language Class Initialized
INFO - 2019-11-14 15:49:50 --> Language Class Initialized
INFO - 2019-11-14 15:49:50 --> Config Class Initialized
INFO - 2019-11-14 15:49:50 --> Loader Class Initialized
INFO - 2019-11-14 15:49:50 --> Helper loaded: url_helper
INFO - 2019-11-14 15:49:50 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:50 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:50 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:49:50 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:49:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:50 --> Parser Class Initialized
INFO - 2019-11-14 15:49:50 --> User Agent Class Initialized
INFO - 2019-11-14 15:49:50 --> Model Class Initialized
INFO - 2019-11-14 15:49:50 --> Database Driver Class Initialized
INFO - 2019-11-14 15:49:50 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:50 --> Template Class Initialized
INFO - 2019-11-14 15:49:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:50 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:49:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:50 --> Encryption Class Initialized
INFO - 2019-11-14 15:49:50 --> Controller Class Initialized
DEBUG - 2019-11-14 15:49:50 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:49:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:49:50 --> Model Class Initialized
ERROR - 2019-11-14 15:49:50 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:49:50 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:49:50 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:49:50 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:49:51 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:49:51 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:49:51 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:49:51 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:49:51 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:49:51 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-14 15:49:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:49:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:49:51 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:49:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:49:51 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:49:51 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:49:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:49:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:49:51 --> Final output sent to browser
DEBUG - 2019-11-14 15:49:51 --> Total execution time: 1.2734
INFO - 2019-11-14 15:49:59 --> Config Class Initialized
INFO - 2019-11-14 15:49:59 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:49:59 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:49:59 --> Utf8 Class Initialized
INFO - 2019-11-14 15:49:59 --> URI Class Initialized
INFO - 2019-11-14 15:49:59 --> Router Class Initialized
INFO - 2019-11-14 15:49:59 --> Output Class Initialized
INFO - 2019-11-14 15:49:59 --> Security Class Initialized
DEBUG - 2019-11-14 15:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:49:59 --> CSRF cookie sent
INFO - 2019-11-14 15:49:59 --> Input Class Initialized
INFO - 2019-11-14 15:49:59 --> Language Class Initialized
INFO - 2019-11-14 15:49:59 --> Language Class Initialized
INFO - 2019-11-14 15:49:59 --> Config Class Initialized
INFO - 2019-11-14 15:49:59 --> Loader Class Initialized
INFO - 2019-11-14 15:49:59 --> Helper loaded: url_helper
INFO - 2019-11-14 15:49:59 --> Helper loaded: common_helper
INFO - 2019-11-14 15:49:59 --> Helper loaded: language_helper
INFO - 2019-11-14 15:49:59 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:49:59 --> Helper loaded: email_helper
INFO - 2019-11-14 15:49:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:49:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:49:59 --> Parser Class Initialized
INFO - 2019-11-14 15:49:59 --> User Agent Class Initialized
INFO - 2019-11-14 15:49:59 --> Model Class Initialized
INFO - 2019-11-14 15:49:59 --> Database Driver Class Initialized
INFO - 2019-11-14 15:49:59 --> Model Class Initialized
DEBUG - 2019-11-14 15:49:59 --> Template Class Initialized
INFO - 2019-11-14 15:49:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:49:59 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:49:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:49:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:49:59 --> Encryption Class Initialized
INFO - 2019-11-14 15:49:59 --> Controller Class Initialized
DEBUG - 2019-11-14 15:49:59 --> transactions MX_Controller Initialized
DEBUG - 2019-11-14 15:50:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-14 15:50:00 --> Model Class Initialized
ERROR - 2019-11-14 15:50:00 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:50:00 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:50:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-14 15:50:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:50:00 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:50:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:50:00 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:50:00 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:50:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:50:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:50:00 --> Final output sent to browser
DEBUG - 2019-11-14 15:50:00 --> Total execution time: 1.0475
INFO - 2019-11-14 15:50:08 --> Config Class Initialized
INFO - 2019-11-14 15:50:08 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:50:08 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:50:08 --> Utf8 Class Initialized
INFO - 2019-11-14 15:50:08 --> URI Class Initialized
INFO - 2019-11-14 15:50:08 --> Router Class Initialized
INFO - 2019-11-14 15:50:08 --> Output Class Initialized
INFO - 2019-11-14 15:50:08 --> Security Class Initialized
DEBUG - 2019-11-14 15:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:50:08 --> CSRF cookie sent
INFO - 2019-11-14 15:50:08 --> Input Class Initialized
INFO - 2019-11-14 15:50:08 --> Language Class Initialized
INFO - 2019-11-14 15:50:08 --> Language Class Initialized
INFO - 2019-11-14 15:50:08 --> Config Class Initialized
INFO - 2019-11-14 15:50:08 --> Loader Class Initialized
INFO - 2019-11-14 15:50:08 --> Helper loaded: url_helper
INFO - 2019-11-14 15:50:08 --> Helper loaded: common_helper
INFO - 2019-11-14 15:50:08 --> Helper loaded: language_helper
INFO - 2019-11-14 15:50:08 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:50:08 --> Helper loaded: email_helper
INFO - 2019-11-14 15:50:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:50:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:50:08 --> Parser Class Initialized
INFO - 2019-11-14 15:50:08 --> User Agent Class Initialized
INFO - 2019-11-14 15:50:08 --> Model Class Initialized
INFO - 2019-11-14 15:50:08 --> Database Driver Class Initialized
INFO - 2019-11-14 15:50:08 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:08 --> Template Class Initialized
INFO - 2019-11-14 15:50:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:50:08 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:50:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:50:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:50:08 --> Encryption Class Initialized
INFO - 2019-11-14 15:50:08 --> Controller Class Initialized
DEBUG - 2019-11-14 15:50:08 --> package MX_Controller Initialized
DEBUG - 2019-11-14 15:50:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-14 15:50:08 --> Model Class Initialized
INFO - 2019-11-14 15:50:08 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:50:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:50:08 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:50:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:50:08 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:50:09 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-14 15:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-14 15:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:50:09 --> Final output sent to browser
DEBUG - 2019-11-14 15:50:09 --> Total execution time: 1.0965
INFO - 2019-11-14 15:50:12 --> Config Class Initialized
INFO - 2019-11-14 15:50:12 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:50:12 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:50:12 --> Utf8 Class Initialized
INFO - 2019-11-14 15:50:12 --> URI Class Initialized
INFO - 2019-11-14 15:50:12 --> Router Class Initialized
INFO - 2019-11-14 15:50:12 --> Output Class Initialized
INFO - 2019-11-14 15:50:12 --> Security Class Initialized
DEBUG - 2019-11-14 15:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:50:12 --> CSRF cookie sent
INFO - 2019-11-14 15:50:12 --> CSRF token verified
INFO - 2019-11-14 15:50:12 --> Input Class Initialized
INFO - 2019-11-14 15:50:12 --> Language Class Initialized
INFO - 2019-11-14 15:50:12 --> Language Class Initialized
INFO - 2019-11-14 15:50:12 --> Config Class Initialized
INFO - 2019-11-14 15:50:12 --> Loader Class Initialized
INFO - 2019-11-14 15:50:12 --> Helper loaded: url_helper
INFO - 2019-11-14 15:50:12 --> Helper loaded: common_helper
INFO - 2019-11-14 15:50:12 --> Helper loaded: language_helper
INFO - 2019-11-14 15:50:12 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:50:12 --> Helper loaded: email_helper
INFO - 2019-11-14 15:50:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:50:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:50:12 --> Parser Class Initialized
INFO - 2019-11-14 15:50:12 --> User Agent Class Initialized
INFO - 2019-11-14 15:50:12 --> Model Class Initialized
INFO - 2019-11-14 15:50:12 --> Database Driver Class Initialized
INFO - 2019-11-14 15:50:12 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:12 --> Template Class Initialized
INFO - 2019-11-14 15:50:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:50:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:50:13 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:50:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:50:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:50:13 --> Encryption Class Initialized
INFO - 2019-11-14 15:50:13 --> Controller Class Initialized
DEBUG - 2019-11-14 15:50:13 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:50:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:50:13 --> Model Class Initialized
INFO - 2019-11-14 15:50:13 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:50:13 --> Could not find the language line "shopier"
DEBUG - 2019-11-14 15:50:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-14 15:50:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:50:13 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:50:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:50:13 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:50:13 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:50:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:50:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:50:13 --> Final output sent to browser
DEBUG - 2019-11-14 15:50:13 --> Total execution time: 1.1518
INFO - 2019-11-14 15:50:20 --> Config Class Initialized
INFO - 2019-11-14 15:50:20 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:50:20 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:50:20 --> Utf8 Class Initialized
INFO - 2019-11-14 15:50:20 --> URI Class Initialized
INFO - 2019-11-14 15:50:20 --> Router Class Initialized
INFO - 2019-11-14 15:50:20 --> Output Class Initialized
INFO - 2019-11-14 15:50:20 --> Security Class Initialized
DEBUG - 2019-11-14 15:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:50:20 --> CSRF cookie sent
INFO - 2019-11-14 15:50:20 --> CSRF token verified
INFO - 2019-11-14 15:50:20 --> Input Class Initialized
INFO - 2019-11-14 15:50:20 --> Language Class Initialized
INFO - 2019-11-14 15:50:20 --> Language Class Initialized
INFO - 2019-11-14 15:50:20 --> Config Class Initialized
INFO - 2019-11-14 15:50:20 --> Loader Class Initialized
INFO - 2019-11-14 15:50:20 --> Helper loaded: url_helper
INFO - 2019-11-14 15:50:20 --> Helper loaded: common_helper
INFO - 2019-11-14 15:50:20 --> Helper loaded: language_helper
INFO - 2019-11-14 15:50:20 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:50:20 --> Helper loaded: email_helper
INFO - 2019-11-14 15:50:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:50:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:50:20 --> Parser Class Initialized
INFO - 2019-11-14 15:50:20 --> User Agent Class Initialized
INFO - 2019-11-14 15:50:20 --> Model Class Initialized
INFO - 2019-11-14 15:50:20 --> Database Driver Class Initialized
INFO - 2019-11-14 15:50:20 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:20 --> Template Class Initialized
INFO - 2019-11-14 15:50:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:50:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:50:20 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:50:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:50:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:50:20 --> Encryption Class Initialized
INFO - 2019-11-14 15:50:20 --> Controller Class Initialized
DEBUG - 2019-11-14 15:50:20 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:50:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:50:20 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:20 --> cardinity MX_Controller Initialized
DEBUG - 2019-11-14 15:50:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/index.php
INFO - 2019-11-14 15:50:20 --> Final output sent to browser
DEBUG - 2019-11-14 15:50:20 --> Total execution time: 0.7670
INFO - 2019-11-14 15:50:36 --> Config Class Initialized
INFO - 2019-11-14 15:50:36 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:50:36 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:50:36 --> Utf8 Class Initialized
INFO - 2019-11-14 15:50:36 --> URI Class Initialized
INFO - 2019-11-14 15:50:36 --> Router Class Initialized
INFO - 2019-11-14 15:50:36 --> Output Class Initialized
INFO - 2019-11-14 15:50:36 --> Security Class Initialized
DEBUG - 2019-11-14 15:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:50:36 --> CSRF cookie sent
INFO - 2019-11-14 15:50:36 --> CSRF token verified
INFO - 2019-11-14 15:50:36 --> Input Class Initialized
INFO - 2019-11-14 15:50:36 --> Language Class Initialized
INFO - 2019-11-14 15:50:36 --> Language Class Initialized
INFO - 2019-11-14 15:50:36 --> Config Class Initialized
INFO - 2019-11-14 15:50:36 --> Loader Class Initialized
INFO - 2019-11-14 15:50:36 --> Helper loaded: url_helper
INFO - 2019-11-14 15:50:36 --> Helper loaded: common_helper
INFO - 2019-11-14 15:50:36 --> Helper loaded: language_helper
INFO - 2019-11-14 15:50:36 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:50:36 --> Helper loaded: email_helper
INFO - 2019-11-14 15:50:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:50:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:50:36 --> Parser Class Initialized
INFO - 2019-11-14 15:50:36 --> User Agent Class Initialized
INFO - 2019-11-14 15:50:36 --> Model Class Initialized
INFO - 2019-11-14 15:50:36 --> Database Driver Class Initialized
INFO - 2019-11-14 15:50:36 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:36 --> Template Class Initialized
INFO - 2019-11-14 15:50:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:50:37 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:50:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:50:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:50:37 --> Encryption Class Initialized
INFO - 2019-11-14 15:50:37 --> Controller Class Initialized
DEBUG - 2019-11-14 15:50:37 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:50:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:50:37 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:37 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:50:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
DEBUG - 2019-11-14 15:50:38 --> orders MX_Controller Initialized
DEBUG - 2019-11-14 15:50:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/mollie/index.php
INFO - 2019-11-14 15:50:38 --> Final output sent to browser
DEBUG - 2019-11-14 15:50:38 --> Total execution time: 1.8643
INFO - 2019-11-14 15:50:45 --> Config Class Initialized
INFO - 2019-11-14 15:50:45 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:50:45 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:50:45 --> Utf8 Class Initialized
INFO - 2019-11-14 15:50:45 --> URI Class Initialized
INFO - 2019-11-14 15:50:45 --> Router Class Initialized
INFO - 2019-11-14 15:50:45 --> Output Class Initialized
INFO - 2019-11-14 15:50:45 --> Security Class Initialized
DEBUG - 2019-11-14 15:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:50:45 --> Input Class Initialized
INFO - 2019-11-14 15:50:45 --> Language Class Initialized
INFO - 2019-11-14 15:50:45 --> Language Class Initialized
INFO - 2019-11-14 15:50:45 --> Config Class Initialized
INFO - 2019-11-14 15:50:45 --> Loader Class Initialized
INFO - 2019-11-14 15:50:45 --> Helper loaded: url_helper
INFO - 2019-11-14 15:50:45 --> Helper loaded: common_helper
INFO - 2019-11-14 15:50:45 --> Helper loaded: language_helper
INFO - 2019-11-14 15:50:45 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:50:45 --> Helper loaded: email_helper
INFO - 2019-11-14 15:50:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:50:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:50:45 --> Parser Class Initialized
INFO - 2019-11-14 15:50:45 --> User Agent Class Initialized
INFO - 2019-11-14 15:50:45 --> Model Class Initialized
INFO - 2019-11-14 15:50:46 --> Database Driver Class Initialized
INFO - 2019-11-14 15:50:46 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:46 --> Template Class Initialized
INFO - 2019-11-14 15:50:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:50:46 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:50:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:50:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:50:46 --> Encryption Class Initialized
INFO - 2019-11-14 15:50:46 --> Controller Class Initialized
DEBUG - 2019-11-14 15:50:46 --> mollie MX_Controller Initialized
DEBUG - 2019-11-14 15:50:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/mollieapi.php
INFO - 2019-11-14 15:50:46 --> Model Class Initialized
INFO - 2019-11-14 15:50:47 --> Config Class Initialized
INFO - 2019-11-14 15:50:47 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:50:47 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:50:47 --> Utf8 Class Initialized
INFO - 2019-11-14 15:50:47 --> URI Class Initialized
INFO - 2019-11-14 15:50:47 --> Router Class Initialized
INFO - 2019-11-14 15:50:47 --> Output Class Initialized
INFO - 2019-11-14 15:50:47 --> Security Class Initialized
DEBUG - 2019-11-14 15:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:50:47 --> CSRF cookie sent
INFO - 2019-11-14 15:50:47 --> Input Class Initialized
INFO - 2019-11-14 15:50:47 --> Language Class Initialized
INFO - 2019-11-14 15:50:47 --> Language Class Initialized
INFO - 2019-11-14 15:50:47 --> Config Class Initialized
INFO - 2019-11-14 15:50:47 --> Loader Class Initialized
INFO - 2019-11-14 15:50:47 --> Helper loaded: url_helper
INFO - 2019-11-14 15:50:47 --> Helper loaded: common_helper
INFO - 2019-11-14 15:50:47 --> Helper loaded: language_helper
INFO - 2019-11-14 15:50:47 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:50:47 --> Helper loaded: email_helper
INFO - 2019-11-14 15:50:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:50:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:50:47 --> Parser Class Initialized
INFO - 2019-11-14 15:50:47 --> User Agent Class Initialized
INFO - 2019-11-14 15:50:47 --> Model Class Initialized
INFO - 2019-11-14 15:50:47 --> Database Driver Class Initialized
INFO - 2019-11-14 15:50:47 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:47 --> Template Class Initialized
INFO - 2019-11-14 15:50:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:50:47 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:50:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:50:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:50:47 --> Encryption Class Initialized
INFO - 2019-11-14 15:50:48 --> Controller Class Initialized
DEBUG - 2019-11-14 15:50:48 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 15:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 15:50:48 --> Model Class Initialized
INFO - 2019-11-14 15:50:48 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-14 15:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:50:48 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:50:48 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:50:48 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-14 15:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-14 15:50:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-14 15:50:48 --> Final output sent to browser
DEBUG - 2019-11-14 15:50:48 --> Total execution time: 0.9883
INFO - 2019-11-14 15:50:53 --> Config Class Initialized
INFO - 2019-11-14 15:50:53 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:50:53 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:50:53 --> Utf8 Class Initialized
INFO - 2019-11-14 15:50:53 --> URI Class Initialized
INFO - 2019-11-14 15:50:53 --> Router Class Initialized
INFO - 2019-11-14 15:50:53 --> Output Class Initialized
INFO - 2019-11-14 15:50:53 --> Security Class Initialized
DEBUG - 2019-11-14 15:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:50:53 --> CSRF cookie sent
INFO - 2019-11-14 15:50:53 --> Input Class Initialized
INFO - 2019-11-14 15:50:53 --> Language Class Initialized
INFO - 2019-11-14 15:50:53 --> Language Class Initialized
INFO - 2019-11-14 15:50:53 --> Config Class Initialized
INFO - 2019-11-14 15:50:53 --> Loader Class Initialized
INFO - 2019-11-14 15:50:53 --> Helper loaded: url_helper
INFO - 2019-11-14 15:50:53 --> Helper loaded: common_helper
INFO - 2019-11-14 15:50:53 --> Helper loaded: language_helper
INFO - 2019-11-14 15:50:53 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:50:54 --> Helper loaded: email_helper
INFO - 2019-11-14 15:50:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:50:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:50:54 --> Parser Class Initialized
INFO - 2019-11-14 15:50:54 --> User Agent Class Initialized
INFO - 2019-11-14 15:50:54 --> Model Class Initialized
INFO - 2019-11-14 15:50:54 --> Database Driver Class Initialized
INFO - 2019-11-14 15:50:54 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:54 --> Template Class Initialized
INFO - 2019-11-14 15:50:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:50:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:50:54 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:50:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:50:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:50:54 --> Encryption Class Initialized
INFO - 2019-11-14 15:50:54 --> Controller Class Initialized
DEBUG - 2019-11-14 15:50:54 --> transactions MX_Controller Initialized
DEBUG - 2019-11-14 15:50:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-14 15:50:54 --> Model Class Initialized
ERROR - 2019-11-14 15:50:54 --> Could not find the language line "order_id"
INFO - 2019-11-14 15:50:54 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 15:50:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-14 15:50:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:50:54 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:50:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:50:54 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:50:54 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:50:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:50:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:50:54 --> Final output sent to browser
DEBUG - 2019-11-14 15:50:54 --> Total execution time: 1.1559
INFO - 2019-11-14 15:50:56 --> Config Class Initialized
INFO - 2019-11-14 15:50:56 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:50:56 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:50:56 --> Utf8 Class Initialized
INFO - 2019-11-14 15:50:56 --> URI Class Initialized
INFO - 2019-11-14 15:50:56 --> Router Class Initialized
INFO - 2019-11-14 15:50:56 --> Output Class Initialized
INFO - 2019-11-14 15:50:56 --> Security Class Initialized
DEBUG - 2019-11-14 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:50:56 --> CSRF cookie sent
INFO - 2019-11-14 15:50:56 --> Input Class Initialized
INFO - 2019-11-14 15:50:56 --> Language Class Initialized
INFO - 2019-11-14 15:50:56 --> Language Class Initialized
INFO - 2019-11-14 15:50:56 --> Config Class Initialized
INFO - 2019-11-14 15:50:56 --> Loader Class Initialized
INFO - 2019-11-14 15:50:56 --> Helper loaded: url_helper
INFO - 2019-11-14 15:50:56 --> Helper loaded: common_helper
INFO - 2019-11-14 15:50:56 --> Helper loaded: language_helper
INFO - 2019-11-14 15:50:56 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:50:56 --> Helper loaded: email_helper
INFO - 2019-11-14 15:50:56 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:50:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:50:56 --> Parser Class Initialized
INFO - 2019-11-14 15:50:56 --> User Agent Class Initialized
INFO - 2019-11-14 15:50:56 --> Model Class Initialized
INFO - 2019-11-14 15:50:56 --> Database Driver Class Initialized
INFO - 2019-11-14 15:50:56 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:56 --> Template Class Initialized
INFO - 2019-11-14 15:50:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:50:56 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:50:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:50:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:50:57 --> Encryption Class Initialized
INFO - 2019-11-14 15:50:57 --> Controller Class Initialized
DEBUG - 2019-11-14 15:50:57 --> order MX_Controller Initialized
DEBUG - 2019-11-14 15:50:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-14 15:50:57 --> Model Class Initialized
ERROR - 2019-11-14 15:50:57 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:50:57 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-14 15:50:57 --> Could not find the language line "order_id"
ERROR - 2019-11-14 15:50:57 --> Could not find the language line "order_basic_details"
INFO - 2019-11-14 15:50:57 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:50:57 --> Could not find the language line "Awaiting"
ERROR - 2019-11-14 15:50:57 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:50:57 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:50:57 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:50:57 --> Could not find the language line "Awaiting"
DEBUG - 2019-11-14 15:50:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-14 15:50:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:50:57 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:50:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:50:57 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:50:57 --> Model Class Initialized
DEBUG - 2019-11-14 15:50:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:50:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:50:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:50:57 --> Final output sent to browser
DEBUG - 2019-11-14 15:50:57 --> Total execution time: 1.2254
INFO - 2019-11-14 15:51:01 --> Config Class Initialized
INFO - 2019-11-14 15:51:01 --> Hooks Class Initialized
DEBUG - 2019-11-14 15:51:01 --> UTF-8 Support Enabled
INFO - 2019-11-14 15:51:01 --> Utf8 Class Initialized
INFO - 2019-11-14 15:51:01 --> URI Class Initialized
INFO - 2019-11-14 15:51:01 --> Router Class Initialized
INFO - 2019-11-14 15:51:01 --> Output Class Initialized
INFO - 2019-11-14 15:51:01 --> Security Class Initialized
DEBUG - 2019-11-14 15:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 15:51:01 --> CSRF cookie sent
INFO - 2019-11-14 15:51:01 --> Input Class Initialized
INFO - 2019-11-14 15:51:01 --> Language Class Initialized
INFO - 2019-11-14 15:51:01 --> Language Class Initialized
INFO - 2019-11-14 15:51:01 --> Config Class Initialized
INFO - 2019-11-14 15:51:01 --> Loader Class Initialized
INFO - 2019-11-14 15:51:01 --> Helper loaded: url_helper
INFO - 2019-11-14 15:51:02 --> Helper loaded: common_helper
INFO - 2019-11-14 15:51:02 --> Helper loaded: language_helper
INFO - 2019-11-14 15:51:02 --> Helper loaded: cookie_helper
INFO - 2019-11-14 15:51:02 --> Helper loaded: email_helper
INFO - 2019-11-14 15:51:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 15:51:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 15:51:02 --> Parser Class Initialized
INFO - 2019-11-14 15:51:02 --> User Agent Class Initialized
INFO - 2019-11-14 15:51:02 --> Model Class Initialized
INFO - 2019-11-14 15:51:02 --> Database Driver Class Initialized
INFO - 2019-11-14 15:51:02 --> Model Class Initialized
DEBUG - 2019-11-14 15:51:02 --> Template Class Initialized
INFO - 2019-11-14 15:51:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 15:51:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 15:51:02 --> Pagination Class Initialized
DEBUG - 2019-11-14 15:51:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 15:51:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 15:51:02 --> Encryption Class Initialized
INFO - 2019-11-14 15:51:02 --> Controller Class Initialized
DEBUG - 2019-11-14 15:51:02 --> statistics MX_Controller Initialized
DEBUG - 2019-11-14 15:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-14 15:51:02 --> Model Class Initialized
ERROR - 2019-11-14 15:51:02 --> Could not find the language line "Pending"
ERROR - 2019-11-14 15:51:02 --> Could not find the language line "Pending"
INFO - 2019-11-14 15:51:02 --> Helper loaded: inflector_helper
ERROR - 2019-11-14 15:51:02 --> Could not find the language line "total_orders"
ERROR - 2019-11-14 15:51:02 --> Could not find the language line "total_orders"
ERROR - 2019-11-14 15:51:02 --> Could not find the language line "Pending"
DEBUG - 2019-11-14 15:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-14 15:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-14 15:51:02 --> blocks MX_Controller Initialized
DEBUG - 2019-11-14 15:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-14 15:51:02 --> Model Class Initialized
DEBUG - 2019-11-14 15:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-14 15:51:02 --> Model Class Initialized
DEBUG - 2019-11-14 15:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-14 15:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-14 15:51:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-14 15:51:02 --> Final output sent to browser
DEBUG - 2019-11-14 15:51:02 --> Total execution time: 1.1716
INFO - 2019-11-14 23:16:39 --> Config Class Initialized
INFO - 2019-11-14 23:16:39 --> Hooks Class Initialized
DEBUG - 2019-11-14 23:16:39 --> UTF-8 Support Enabled
INFO - 2019-11-14 23:16:39 --> Utf8 Class Initialized
INFO - 2019-11-14 23:16:39 --> URI Class Initialized
INFO - 2019-11-14 23:16:39 --> Router Class Initialized
INFO - 2019-11-14 23:16:39 --> Output Class Initialized
INFO - 2019-11-14 23:16:39 --> Security Class Initialized
DEBUG - 2019-11-14 23:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 23:16:39 --> CSRF cookie sent
INFO - 2019-11-14 23:16:39 --> Input Class Initialized
INFO - 2019-11-14 23:16:39 --> Language Class Initialized
INFO - 2019-11-14 23:16:39 --> Language Class Initialized
INFO - 2019-11-14 23:16:39 --> Config Class Initialized
INFO - 2019-11-14 23:16:39 --> Loader Class Initialized
INFO - 2019-11-14 23:16:39 --> Helper loaded: url_helper
INFO - 2019-11-14 23:16:39 --> Helper loaded: common_helper
INFO - 2019-11-14 23:16:39 --> Helper loaded: language_helper
INFO - 2019-11-14 23:16:39 --> Helper loaded: cookie_helper
INFO - 2019-11-14 23:16:39 --> Helper loaded: email_helper
INFO - 2019-11-14 23:16:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 23:16:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 23:16:40 --> Parser Class Initialized
INFO - 2019-11-14 23:16:40 --> User Agent Class Initialized
INFO - 2019-11-14 23:16:40 --> Model Class Initialized
INFO - 2019-11-14 23:16:40 --> Database Driver Class Initialized
INFO - 2019-11-14 23:16:40 --> Model Class Initialized
DEBUG - 2019-11-14 23:16:40 --> Template Class Initialized
INFO - 2019-11-14 23:16:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 23:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 23:16:40 --> Pagination Class Initialized
DEBUG - 2019-11-14 23:16:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 23:16:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 23:16:40 --> Encryption Class Initialized
INFO - 2019-11-14 23:16:40 --> Controller Class Initialized
DEBUG - 2019-11-14 23:16:40 --> checkout MX_Controller Initialized
DEBUG - 2019-11-14 23:16:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-14 23:16:40 --> Model Class Initialized
INFO - 2019-11-14 23:16:40 --> Config Class Initialized
INFO - 2019-11-14 23:16:40 --> Hooks Class Initialized
DEBUG - 2019-11-14 23:16:40 --> UTF-8 Support Enabled
INFO - 2019-11-14 23:16:40 --> Utf8 Class Initialized
INFO - 2019-11-14 23:16:40 --> URI Class Initialized
DEBUG - 2019-11-14 23:16:40 --> No URI present. Default controller set.
INFO - 2019-11-14 23:16:40 --> Router Class Initialized
INFO - 2019-11-14 23:16:40 --> Output Class Initialized
INFO - 2019-11-14 23:16:40 --> Security Class Initialized
DEBUG - 2019-11-14 23:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-14 23:16:40 --> CSRF cookie sent
INFO - 2019-11-14 23:16:40 --> Input Class Initialized
INFO - 2019-11-14 23:16:40 --> Language Class Initialized
INFO - 2019-11-14 23:16:40 --> Language Class Initialized
INFO - 2019-11-14 23:16:41 --> Config Class Initialized
INFO - 2019-11-14 23:16:41 --> Loader Class Initialized
INFO - 2019-11-14 23:16:41 --> Helper loaded: url_helper
INFO - 2019-11-14 23:16:41 --> Helper loaded: common_helper
INFO - 2019-11-14 23:16:41 --> Helper loaded: language_helper
INFO - 2019-11-14 23:16:41 --> Helper loaded: cookie_helper
INFO - 2019-11-14 23:16:41 --> Helper loaded: email_helper
INFO - 2019-11-14 23:16:41 --> Helper loaded: file_manager_helper
INFO - 2019-11-14 23:16:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-14 23:16:41 --> Parser Class Initialized
INFO - 2019-11-14 23:16:41 --> User Agent Class Initialized
INFO - 2019-11-14 23:16:41 --> Model Class Initialized
INFO - 2019-11-14 23:16:41 --> Database Driver Class Initialized
INFO - 2019-11-14 23:16:41 --> Model Class Initialized
DEBUG - 2019-11-14 23:16:41 --> Template Class Initialized
INFO - 2019-11-14 23:16:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-14 23:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-14 23:16:41 --> Pagination Class Initialized
DEBUG - 2019-11-14 23:16:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-14 23:16:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-14 23:16:41 --> Encryption Class Initialized
DEBUG - 2019-11-14 23:16:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 23:16:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-14 23:16:41 --> Controller Class Initialized
DEBUG - 2019-11-14 23:16:41 --> pergo MX_Controller Initialized
DEBUG - 2019-11-14 23:16:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-14 23:16:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-14 23:16:41 --> Model Class Initialized
INFO - 2019-11-14 23:16:41 --> Helper loaded: inflector_helper
DEBUG - 2019-11-14 23:16:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-14 23:16:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-14 23:16:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-14 23:16:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-14 23:16:42 --> Final output sent to browser
DEBUG - 2019-11-14 23:16:42 --> Total execution time: 1.3824
