<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-28 22:01:41 --> Config Class Initialized
INFO - 2019-11-28 22:01:41 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:01:41 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:01:41 --> Utf8 Class Initialized
INFO - 2019-11-28 22:01:41 --> URI Class Initialized
DEBUG - 2019-11-28 22:01:41 --> No URI present. Default controller set.
INFO - 2019-11-28 22:01:41 --> Router Class Initialized
INFO - 2019-11-28 22:01:41 --> Output Class Initialized
INFO - 2019-11-28 22:01:41 --> Security Class Initialized
DEBUG - 2019-11-28 22:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:01:41 --> CSRF cookie sent
INFO - 2019-11-28 22:01:41 --> Input Class Initialized
INFO - 2019-11-28 22:01:41 --> Language Class Initialized
INFO - 2019-11-28 22:01:41 --> Language Class Initialized
INFO - 2019-11-28 22:01:41 --> Config Class Initialized
INFO - 2019-11-28 22:01:41 --> Loader Class Initialized
INFO - 2019-11-28 22:01:41 --> Helper loaded: url_helper
INFO - 2019-11-28 22:01:42 --> Helper loaded: common_helper
INFO - 2019-11-28 22:01:42 --> Helper loaded: language_helper
INFO - 2019-11-28 22:01:42 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:01:42 --> Helper loaded: email_helper
INFO - 2019-11-28 22:01:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:01:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:01:42 --> Parser Class Initialized
INFO - 2019-11-28 22:01:42 --> User Agent Class Initialized
INFO - 2019-11-28 22:01:42 --> Model Class Initialized
INFO - 2019-11-28 22:01:42 --> Database Driver Class Initialized
INFO - 2019-11-28 22:01:42 --> Model Class Initialized
DEBUG - 2019-11-28 22:01:42 --> Template Class Initialized
INFO - 2019-11-28 22:01:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:01:42 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:01:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:01:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:01:42 --> Encryption Class Initialized
DEBUG - 2019-11-28 22:01:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-28 22:01:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-28 22:01:42 --> Controller Class Initialized
DEBUG - 2019-11-28 22:01:42 --> pergo MX_Controller Initialized
DEBUG - 2019-11-28 22:01:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-28 22:01:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-28 22:01:42 --> Model Class Initialized
INFO - 2019-11-28 22:01:42 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-28 22:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-28 22:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-28 22:01:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-28 22:01:43 --> Final output sent to browser
DEBUG - 2019-11-28 22:01:43 --> Total execution time: 2.0926
INFO - 2019-11-28 22:01:50 --> Config Class Initialized
INFO - 2019-11-28 22:01:50 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:01:50 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:01:50 --> Utf8 Class Initialized
INFO - 2019-11-28 22:01:50 --> URI Class Initialized
INFO - 2019-11-28 22:01:50 --> Router Class Initialized
INFO - 2019-11-28 22:01:50 --> Output Class Initialized
INFO - 2019-11-28 22:01:50 --> Security Class Initialized
DEBUG - 2019-11-28 22:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:01:50 --> CSRF cookie sent
INFO - 2019-11-28 22:01:50 --> Input Class Initialized
INFO - 2019-11-28 22:01:50 --> Language Class Initialized
INFO - 2019-11-28 22:01:50 --> Language Class Initialized
INFO - 2019-11-28 22:01:50 --> Config Class Initialized
INFO - 2019-11-28 22:01:51 --> Loader Class Initialized
INFO - 2019-11-28 22:01:51 --> Helper loaded: url_helper
INFO - 2019-11-28 22:01:51 --> Helper loaded: common_helper
INFO - 2019-11-28 22:01:51 --> Helper loaded: language_helper
INFO - 2019-11-28 22:01:51 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:01:51 --> Helper loaded: email_helper
INFO - 2019-11-28 22:01:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:01:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:01:51 --> Parser Class Initialized
INFO - 2019-11-28 22:01:51 --> User Agent Class Initialized
INFO - 2019-11-28 22:01:51 --> Model Class Initialized
INFO - 2019-11-28 22:01:51 --> Database Driver Class Initialized
INFO - 2019-11-28 22:01:51 --> Model Class Initialized
DEBUG - 2019-11-28 22:01:51 --> Template Class Initialized
INFO - 2019-11-28 22:01:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:01:51 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:01:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:01:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:01:51 --> Encryption Class Initialized
INFO - 2019-11-28 22:01:51 --> Controller Class Initialized
DEBUG - 2019-11-28 22:01:51 --> auth MX_Controller Initialized
DEBUG - 2019-11-28 22:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-28 22:01:51 --> Model Class Initialized
DEBUG - 2019-11-28 22:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-28 22:01:51 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-28 22:01:51 --> pergo MX_Controller Initialized
DEBUG - 2019-11-28 22:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-28 22:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-28 22:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-28 22:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-28 22:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-28 22:01:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-28 22:01:51 --> Final output sent to browser
DEBUG - 2019-11-28 22:01:51 --> Total execution time: 0.8551
INFO - 2019-11-28 22:01:53 --> Config Class Initialized
INFO - 2019-11-28 22:01:53 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:01:53 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:01:53 --> Utf8 Class Initialized
INFO - 2019-11-28 22:01:53 --> URI Class Initialized
INFO - 2019-11-28 22:01:53 --> Router Class Initialized
INFO - 2019-11-28 22:01:53 --> Output Class Initialized
INFO - 2019-11-28 22:01:53 --> Security Class Initialized
DEBUG - 2019-11-28 22:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:01:53 --> CSRF cookie sent
INFO - 2019-11-28 22:01:53 --> CSRF token verified
INFO - 2019-11-28 22:01:53 --> Input Class Initialized
INFO - 2019-11-28 22:01:53 --> Language Class Initialized
INFO - 2019-11-28 22:01:53 --> Language Class Initialized
INFO - 2019-11-28 22:01:53 --> Config Class Initialized
INFO - 2019-11-28 22:01:54 --> Loader Class Initialized
INFO - 2019-11-28 22:01:54 --> Helper loaded: url_helper
INFO - 2019-11-28 22:01:54 --> Helper loaded: common_helper
INFO - 2019-11-28 22:01:54 --> Helper loaded: language_helper
INFO - 2019-11-28 22:01:54 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:01:54 --> Helper loaded: email_helper
INFO - 2019-11-28 22:01:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:01:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:01:54 --> Parser Class Initialized
INFO - 2019-11-28 22:01:54 --> User Agent Class Initialized
INFO - 2019-11-28 22:01:54 --> Model Class Initialized
INFO - 2019-11-28 22:01:54 --> Database Driver Class Initialized
INFO - 2019-11-28 22:01:54 --> Model Class Initialized
DEBUG - 2019-11-28 22:01:54 --> Template Class Initialized
INFO - 2019-11-28 22:01:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:01:54 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:01:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:01:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:01:54 --> Encryption Class Initialized
INFO - 2019-11-28 22:01:54 --> Controller Class Initialized
DEBUG - 2019-11-28 22:01:54 --> auth MX_Controller Initialized
DEBUG - 2019-11-28 22:01:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-28 22:01:54 --> Model Class Initialized
INFO - 2019-11-28 22:01:58 --> Config Class Initialized
INFO - 2019-11-28 22:01:58 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:01:58 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:01:58 --> Utf8 Class Initialized
INFO - 2019-11-28 22:01:58 --> URI Class Initialized
INFO - 2019-11-28 22:01:58 --> Router Class Initialized
INFO - 2019-11-28 22:01:58 --> Output Class Initialized
INFO - 2019-11-28 22:01:58 --> Security Class Initialized
DEBUG - 2019-11-28 22:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:01:58 --> CSRF cookie sent
INFO - 2019-11-28 22:01:59 --> Input Class Initialized
INFO - 2019-11-28 22:01:59 --> Language Class Initialized
INFO - 2019-11-28 22:01:59 --> Language Class Initialized
INFO - 2019-11-28 22:01:59 --> Config Class Initialized
INFO - 2019-11-28 22:01:59 --> Loader Class Initialized
INFO - 2019-11-28 22:01:59 --> Helper loaded: url_helper
INFO - 2019-11-28 22:01:59 --> Helper loaded: common_helper
INFO - 2019-11-28 22:01:59 --> Helper loaded: language_helper
INFO - 2019-11-28 22:01:59 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:01:59 --> Helper loaded: email_helper
INFO - 2019-11-28 22:01:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:01:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:01:59 --> Parser Class Initialized
INFO - 2019-11-28 22:01:59 --> User Agent Class Initialized
INFO - 2019-11-28 22:01:59 --> Model Class Initialized
INFO - 2019-11-28 22:01:59 --> Database Driver Class Initialized
INFO - 2019-11-28 22:01:59 --> Model Class Initialized
DEBUG - 2019-11-28 22:01:59 --> Template Class Initialized
INFO - 2019-11-28 22:01:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:01:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:01:59 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:01:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:01:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:01:59 --> Encryption Class Initialized
INFO - 2019-11-28 22:01:59 --> Controller Class Initialized
DEBUG - 2019-11-28 22:01:59 --> statistics MX_Controller Initialized
DEBUG - 2019-11-28 22:01:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-28 22:01:59 --> Model Class Initialized
ERROR - 2019-11-28 22:01:59 --> Could not find the language line "Pending"
ERROR - 2019-11-28 22:01:59 --> Could not find the language line "Pending"
INFO - 2019-11-28 22:01:59 --> Helper loaded: inflector_helper
ERROR - 2019-11-28 22:01:59 --> Could not find the language line "total_orders"
ERROR - 2019-11-28 22:01:59 --> Could not find the language line "total_orders"
ERROR - 2019-11-28 22:01:59 --> Could not find the language line "Pending"
DEBUG - 2019-11-28 22:01:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-28 22:01:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:01:59 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:01:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:01:59 --> Model Class Initialized
DEBUG - 2019-11-28 22:01:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:01:59 --> Model Class Initialized
DEBUG - 2019-11-28 22:01:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:02:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:02:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:02:00 --> Final output sent to browser
DEBUG - 2019-11-28 22:02:00 --> Total execution time: 1.2027
INFO - 2019-11-28 22:02:04 --> Config Class Initialized
INFO - 2019-11-28 22:02:04 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:02:04 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:02:04 --> Utf8 Class Initialized
INFO - 2019-11-28 22:02:04 --> URI Class Initialized
INFO - 2019-11-28 22:02:04 --> Router Class Initialized
INFO - 2019-11-28 22:02:04 --> Output Class Initialized
INFO - 2019-11-28 22:02:04 --> Security Class Initialized
DEBUG - 2019-11-28 22:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:02:04 --> CSRF cookie sent
INFO - 2019-11-28 22:02:04 --> Input Class Initialized
INFO - 2019-11-28 22:02:04 --> Language Class Initialized
INFO - 2019-11-28 22:02:04 --> Language Class Initialized
INFO - 2019-11-28 22:02:04 --> Config Class Initialized
INFO - 2019-11-28 22:02:04 --> Loader Class Initialized
INFO - 2019-11-28 22:02:04 --> Helper loaded: url_helper
INFO - 2019-11-28 22:02:04 --> Helper loaded: common_helper
INFO - 2019-11-28 22:02:04 --> Helper loaded: language_helper
INFO - 2019-11-28 22:02:04 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:02:04 --> Helper loaded: email_helper
INFO - 2019-11-28 22:02:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:02:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:02:04 --> Parser Class Initialized
INFO - 2019-11-28 22:02:04 --> User Agent Class Initialized
INFO - 2019-11-28 22:02:04 --> Model Class Initialized
INFO - 2019-11-28 22:02:04 --> Database Driver Class Initialized
INFO - 2019-11-28 22:02:04 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:04 --> Template Class Initialized
INFO - 2019-11-28 22:02:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:02:04 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:02:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:02:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:02:04 --> Encryption Class Initialized
INFO - 2019-11-28 22:02:04 --> Controller Class Initialized
DEBUG - 2019-11-28 22:02:04 --> setting MX_Controller Initialized
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-28 22:02:04 --> Model Class Initialized
INFO - 2019-11-28 22:02:04 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:02:04 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:02:04 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:02:04 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:02:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:02:04 --> Final output sent to browser
DEBUG - 2019-11-28 22:02:05 --> Total execution time: 0.9968
INFO - 2019-11-28 22:02:10 --> Config Class Initialized
INFO - 2019-11-28 22:02:10 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:02:10 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:02:10 --> Utf8 Class Initialized
INFO - 2019-11-28 22:02:10 --> URI Class Initialized
INFO - 2019-11-28 22:02:10 --> Router Class Initialized
INFO - 2019-11-28 22:02:10 --> Output Class Initialized
INFO - 2019-11-28 22:02:10 --> Security Class Initialized
DEBUG - 2019-11-28 22:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:02:10 --> CSRF cookie sent
INFO - 2019-11-28 22:02:10 --> Input Class Initialized
INFO - 2019-11-28 22:02:10 --> Language Class Initialized
INFO - 2019-11-28 22:02:10 --> Language Class Initialized
INFO - 2019-11-28 22:02:10 --> Config Class Initialized
INFO - 2019-11-28 22:02:10 --> Loader Class Initialized
INFO - 2019-11-28 22:02:10 --> Helper loaded: url_helper
INFO - 2019-11-28 22:02:10 --> Helper loaded: common_helper
INFO - 2019-11-28 22:02:10 --> Helper loaded: language_helper
INFO - 2019-11-28 22:02:10 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:02:10 --> Helper loaded: email_helper
INFO - 2019-11-28 22:02:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:02:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:02:10 --> Parser Class Initialized
INFO - 2019-11-28 22:02:10 --> User Agent Class Initialized
INFO - 2019-11-28 22:02:10 --> Model Class Initialized
INFO - 2019-11-28 22:02:10 --> Database Driver Class Initialized
INFO - 2019-11-28 22:02:10 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:10 --> Template Class Initialized
INFO - 2019-11-28 22:02:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:02:10 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:02:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:02:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:02:10 --> Encryption Class Initialized
INFO - 2019-11-28 22:02:10 --> Controller Class Initialized
DEBUG - 2019-11-28 22:02:10 --> setting MX_Controller Initialized
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-28 22:02:10 --> Model Class Initialized
INFO - 2019-11-28 22:02:10 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/mollie.php
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:02:10 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:02:10 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:02:10 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:02:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:02:10 --> Final output sent to browser
DEBUG - 2019-11-28 22:02:10 --> Total execution time: 0.8304
INFO - 2019-11-28 22:02:26 --> Config Class Initialized
INFO - 2019-11-28 22:02:26 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:02:26 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:02:26 --> Utf8 Class Initialized
INFO - 2019-11-28 22:02:26 --> URI Class Initialized
INFO - 2019-11-28 22:02:26 --> Router Class Initialized
INFO - 2019-11-28 22:02:26 --> Output Class Initialized
INFO - 2019-11-28 22:02:26 --> Security Class Initialized
DEBUG - 2019-11-28 22:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:02:26 --> CSRF cookie sent
INFO - 2019-11-28 22:02:26 --> Input Class Initialized
INFO - 2019-11-28 22:02:26 --> Language Class Initialized
INFO - 2019-11-28 22:02:26 --> Language Class Initialized
INFO - 2019-11-28 22:02:26 --> Config Class Initialized
INFO - 2019-11-28 22:02:26 --> Loader Class Initialized
INFO - 2019-11-28 22:02:26 --> Helper loaded: url_helper
INFO - 2019-11-28 22:02:26 --> Helper loaded: common_helper
INFO - 2019-11-28 22:02:26 --> Helper loaded: language_helper
INFO - 2019-11-28 22:02:26 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:02:26 --> Helper loaded: email_helper
INFO - 2019-11-28 22:02:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:02:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:02:26 --> Parser Class Initialized
INFO - 2019-11-28 22:02:26 --> User Agent Class Initialized
INFO - 2019-11-28 22:02:26 --> Model Class Initialized
INFO - 2019-11-28 22:02:26 --> Database Driver Class Initialized
INFO - 2019-11-28 22:02:26 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:26 --> Template Class Initialized
INFO - 2019-11-28 22:02:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:02:26 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:02:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:02:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:02:26 --> Encryption Class Initialized
INFO - 2019-11-28 22:02:26 --> Controller Class Initialized
DEBUG - 2019-11-28 22:02:27 --> setting MX_Controller Initialized
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-28 22:02:27 --> Model Class Initialized
INFO - 2019-11-28 22:02:27 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/payment.php
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:02:27 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:02:27 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:02:27 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:02:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:02:27 --> Final output sent to browser
DEBUG - 2019-11-28 22:02:27 --> Total execution time: 0.8810
INFO - 2019-11-28 22:02:28 --> Config Class Initialized
INFO - 2019-11-28 22:02:28 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:02:28 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:02:29 --> Utf8 Class Initialized
INFO - 2019-11-28 22:02:29 --> URI Class Initialized
INFO - 2019-11-28 22:02:29 --> Router Class Initialized
INFO - 2019-11-28 22:02:29 --> Output Class Initialized
INFO - 2019-11-28 22:02:29 --> Security Class Initialized
DEBUG - 2019-11-28 22:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:02:29 --> CSRF cookie sent
INFO - 2019-11-28 22:02:29 --> Input Class Initialized
INFO - 2019-11-28 22:02:29 --> Language Class Initialized
INFO - 2019-11-28 22:02:29 --> Language Class Initialized
INFO - 2019-11-28 22:02:29 --> Config Class Initialized
INFO - 2019-11-28 22:02:29 --> Loader Class Initialized
INFO - 2019-11-28 22:02:29 --> Helper loaded: url_helper
INFO - 2019-11-28 22:02:29 --> Helper loaded: common_helper
INFO - 2019-11-28 22:02:29 --> Helper loaded: language_helper
INFO - 2019-11-28 22:02:29 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:02:29 --> Helper loaded: email_helper
INFO - 2019-11-28 22:02:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:02:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:02:29 --> Parser Class Initialized
INFO - 2019-11-28 22:02:29 --> User Agent Class Initialized
INFO - 2019-11-28 22:02:29 --> Model Class Initialized
INFO - 2019-11-28 22:02:29 --> Database Driver Class Initialized
INFO - 2019-11-28 22:02:29 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:29 --> Template Class Initialized
INFO - 2019-11-28 22:02:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:02:29 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:02:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:02:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:02:29 --> Encryption Class Initialized
INFO - 2019-11-28 22:02:29 --> Controller Class Initialized
DEBUG - 2019-11-28 22:02:29 --> setting MX_Controller Initialized
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-28 22:02:29 --> Model Class Initialized
INFO - 2019-11-28 22:02:29 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/cardinity.php
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:02:29 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:02:29 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:02:29 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:02:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:02:29 --> Final output sent to browser
DEBUG - 2019-11-28 22:02:29 --> Total execution time: 0.8236
INFO - 2019-11-28 22:02:31 --> Config Class Initialized
INFO - 2019-11-28 22:02:31 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:02:31 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:02:31 --> Utf8 Class Initialized
INFO - 2019-11-28 22:02:31 --> URI Class Initialized
INFO - 2019-11-28 22:02:31 --> Router Class Initialized
INFO - 2019-11-28 22:02:31 --> Output Class Initialized
INFO - 2019-11-28 22:02:31 --> Security Class Initialized
DEBUG - 2019-11-28 22:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:02:31 --> CSRF cookie sent
INFO - 2019-11-28 22:02:31 --> Input Class Initialized
INFO - 2019-11-28 22:02:31 --> Language Class Initialized
INFO - 2019-11-28 22:02:31 --> Language Class Initialized
INFO - 2019-11-28 22:02:31 --> Config Class Initialized
INFO - 2019-11-28 22:02:31 --> Loader Class Initialized
INFO - 2019-11-28 22:02:31 --> Helper loaded: url_helper
INFO - 2019-11-28 22:02:31 --> Helper loaded: common_helper
INFO - 2019-11-28 22:02:31 --> Helper loaded: language_helper
INFO - 2019-11-28 22:02:31 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:02:31 --> Helper loaded: email_helper
INFO - 2019-11-28 22:02:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:02:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:02:31 --> Parser Class Initialized
INFO - 2019-11-28 22:02:31 --> User Agent Class Initialized
INFO - 2019-11-28 22:02:31 --> Model Class Initialized
INFO - 2019-11-28 22:02:31 --> Database Driver Class Initialized
INFO - 2019-11-28 22:02:31 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:31 --> Template Class Initialized
INFO - 2019-11-28 22:02:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:02:31 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:02:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:02:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:02:31 --> Encryption Class Initialized
INFO - 2019-11-28 22:02:31 --> Controller Class Initialized
DEBUG - 2019-11-28 22:02:31 --> setting MX_Controller Initialized
DEBUG - 2019-11-28 22:02:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-28 22:02:31 --> Model Class Initialized
INFO - 2019-11-28 22:02:31 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:02:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-28 22:02:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinbase.php
DEBUG - 2019-11-28 22:02:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-28 22:02:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:02:32 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:02:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:02:32 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:02:32 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:02:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:02:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:02:32 --> Final output sent to browser
DEBUG - 2019-11-28 22:02:32 --> Total execution time: 0.8602
INFO - 2019-11-28 22:02:33 --> Config Class Initialized
INFO - 2019-11-28 22:02:33 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:02:33 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:02:33 --> Utf8 Class Initialized
INFO - 2019-11-28 22:02:33 --> URI Class Initialized
INFO - 2019-11-28 22:02:33 --> Router Class Initialized
INFO - 2019-11-28 22:02:34 --> Output Class Initialized
INFO - 2019-11-28 22:02:34 --> Security Class Initialized
DEBUG - 2019-11-28 22:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:02:34 --> CSRF cookie sent
INFO - 2019-11-28 22:02:34 --> Input Class Initialized
INFO - 2019-11-28 22:02:34 --> Language Class Initialized
INFO - 2019-11-28 22:02:34 --> Language Class Initialized
INFO - 2019-11-28 22:02:34 --> Config Class Initialized
INFO - 2019-11-28 22:02:34 --> Loader Class Initialized
INFO - 2019-11-28 22:02:34 --> Helper loaded: url_helper
INFO - 2019-11-28 22:02:34 --> Helper loaded: common_helper
INFO - 2019-11-28 22:02:34 --> Helper loaded: language_helper
INFO - 2019-11-28 22:02:34 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:02:34 --> Helper loaded: email_helper
INFO - 2019-11-28 22:02:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:02:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:02:34 --> Parser Class Initialized
INFO - 2019-11-28 22:02:34 --> User Agent Class Initialized
INFO - 2019-11-28 22:02:34 --> Model Class Initialized
INFO - 2019-11-28 22:02:34 --> Database Driver Class Initialized
INFO - 2019-11-28 22:02:34 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:34 --> Template Class Initialized
INFO - 2019-11-28 22:02:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:02:34 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:02:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:02:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:02:34 --> Encryption Class Initialized
INFO - 2019-11-28 22:02:34 --> Controller Class Initialized
DEBUG - 2019-11-28 22:02:34 --> setting MX_Controller Initialized
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-28 22:02:34 --> Model Class Initialized
INFO - 2019-11-28 22:02:34 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-28 22:02:34 --> Could not find the language line "coinpayments_integration"
ERROR - 2019-11-28 22:02:34 --> Could not find the language line "coin_acceptance_settings"
ERROR - 2019-11-28 22:02:34 --> Could not find the language line "make_sure_the_list_of_coins_have_the_enabled_status_in"
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinpayments.php
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:02:34 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:02:34 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:02:34 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:02:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:02:34 --> Final output sent to browser
DEBUG - 2019-11-28 22:02:34 --> Total execution time: 0.9075
INFO - 2019-11-28 22:02:38 --> Config Class Initialized
INFO - 2019-11-28 22:02:38 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:02:38 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:02:38 --> Utf8 Class Initialized
INFO - 2019-11-28 22:02:38 --> URI Class Initialized
INFO - 2019-11-28 22:02:38 --> Router Class Initialized
INFO - 2019-11-28 22:02:38 --> Output Class Initialized
INFO - 2019-11-28 22:02:38 --> Security Class Initialized
DEBUG - 2019-11-28 22:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:02:38 --> CSRF cookie sent
INFO - 2019-11-28 22:02:38 --> Input Class Initialized
INFO - 2019-11-28 22:02:38 --> Language Class Initialized
INFO - 2019-11-28 22:02:38 --> Language Class Initialized
INFO - 2019-11-28 22:02:38 --> Config Class Initialized
INFO - 2019-11-28 22:02:38 --> Loader Class Initialized
INFO - 2019-11-28 22:02:38 --> Helper loaded: url_helper
INFO - 2019-11-28 22:02:38 --> Helper loaded: common_helper
INFO - 2019-11-28 22:02:38 --> Helper loaded: language_helper
INFO - 2019-11-28 22:02:38 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:02:38 --> Helper loaded: email_helper
INFO - 2019-11-28 22:02:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:02:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:02:38 --> Parser Class Initialized
INFO - 2019-11-28 22:02:38 --> User Agent Class Initialized
INFO - 2019-11-28 22:02:38 --> Model Class Initialized
INFO - 2019-11-28 22:02:38 --> Database Driver Class Initialized
INFO - 2019-11-28 22:02:38 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:38 --> Template Class Initialized
INFO - 2019-11-28 22:02:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:02:38 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:02:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:02:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:02:38 --> Encryption Class Initialized
INFO - 2019-11-28 22:02:38 --> Controller Class Initialized
DEBUG - 2019-11-28 22:02:38 --> setting MX_Controller Initialized
DEBUG - 2019-11-28 22:02:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-28 22:02:38 --> Model Class Initialized
INFO - 2019-11-28 22:02:38 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:02:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-28 22:02:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-28 22:02:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-28 22:02:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:02:38 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:02:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:02:38 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:02:38 --> Model Class Initialized
DEBUG - 2019-11-28 22:02:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:02:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:02:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:02:39 --> Final output sent to browser
DEBUG - 2019-11-28 22:02:39 --> Total execution time: 0.8669
INFO - 2019-11-28 22:15:19 --> Config Class Initialized
INFO - 2019-11-28 22:15:19 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:15:19 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:15:19 --> Utf8 Class Initialized
INFO - 2019-11-28 22:15:19 --> URI Class Initialized
INFO - 2019-11-28 22:15:19 --> Router Class Initialized
INFO - 2019-11-28 22:15:19 --> Output Class Initialized
INFO - 2019-11-28 22:15:19 --> Security Class Initialized
DEBUG - 2019-11-28 22:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:15:19 --> CSRF cookie sent
INFO - 2019-11-28 22:15:19 --> Input Class Initialized
INFO - 2019-11-28 22:15:19 --> Language Class Initialized
INFO - 2019-11-28 22:15:19 --> Language Class Initialized
INFO - 2019-11-28 22:15:19 --> Config Class Initialized
INFO - 2019-11-28 22:15:19 --> Loader Class Initialized
INFO - 2019-11-28 22:15:19 --> Helper loaded: url_helper
INFO - 2019-11-28 22:15:19 --> Helper loaded: common_helper
INFO - 2019-11-28 22:15:19 --> Helper loaded: language_helper
INFO - 2019-11-28 22:15:19 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:15:19 --> Helper loaded: email_helper
INFO - 2019-11-28 22:15:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:15:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:15:19 --> Parser Class Initialized
INFO - 2019-11-28 22:15:19 --> User Agent Class Initialized
INFO - 2019-11-28 22:15:19 --> Model Class Initialized
INFO - 2019-11-28 22:15:19 --> Database Driver Class Initialized
INFO - 2019-11-28 22:15:19 --> Model Class Initialized
DEBUG - 2019-11-28 22:15:19 --> Template Class Initialized
INFO - 2019-11-28 22:15:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:15:19 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:15:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:15:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:15:20 --> Encryption Class Initialized
INFO - 2019-11-28 22:15:20 --> Controller Class Initialized
DEBUG - 2019-11-28 22:15:20 --> setting MX_Controller Initialized
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-28 22:15:20 --> Model Class Initialized
INFO - 2019-11-28 22:15:20 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:15:20 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:15:20 --> Model Class Initialized
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:15:20 --> Model Class Initialized
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:15:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:15:20 --> Final output sent to browser
DEBUG - 2019-11-28 22:15:20 --> Total execution time: 0.8814
INFO - 2019-11-28 22:15:23 --> Config Class Initialized
INFO - 2019-11-28 22:15:23 --> Hooks Class Initialized
DEBUG - 2019-11-28 22:15:23 --> UTF-8 Support Enabled
INFO - 2019-11-28 22:15:23 --> Utf8 Class Initialized
INFO - 2019-11-28 22:15:23 --> URI Class Initialized
INFO - 2019-11-28 22:15:23 --> Router Class Initialized
INFO - 2019-11-28 22:15:23 --> Output Class Initialized
INFO - 2019-11-28 22:15:23 --> Security Class Initialized
DEBUG - 2019-11-28 22:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-28 22:15:23 --> CSRF cookie sent
INFO - 2019-11-28 22:15:23 --> Input Class Initialized
INFO - 2019-11-28 22:15:23 --> Language Class Initialized
INFO - 2019-11-28 22:15:23 --> Language Class Initialized
INFO - 2019-11-28 22:15:23 --> Config Class Initialized
INFO - 2019-11-28 22:15:23 --> Loader Class Initialized
INFO - 2019-11-28 22:15:23 --> Helper loaded: url_helper
INFO - 2019-11-28 22:15:23 --> Helper loaded: common_helper
INFO - 2019-11-28 22:15:23 --> Helper loaded: language_helper
INFO - 2019-11-28 22:15:23 --> Helper loaded: cookie_helper
INFO - 2019-11-28 22:15:23 --> Helper loaded: email_helper
INFO - 2019-11-28 22:15:23 --> Helper loaded: file_manager_helper
INFO - 2019-11-28 22:15:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-28 22:15:23 --> Parser Class Initialized
INFO - 2019-11-28 22:15:23 --> User Agent Class Initialized
INFO - 2019-11-28 22:15:23 --> Model Class Initialized
INFO - 2019-11-28 22:15:23 --> Database Driver Class Initialized
INFO - 2019-11-28 22:15:23 --> Model Class Initialized
DEBUG - 2019-11-28 22:15:23 --> Template Class Initialized
INFO - 2019-11-28 22:15:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-28 22:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-28 22:15:23 --> Pagination Class Initialized
DEBUG - 2019-11-28 22:15:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-28 22:15:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-28 22:15:23 --> Encryption Class Initialized
INFO - 2019-11-28 22:15:23 --> Controller Class Initialized
DEBUG - 2019-11-28 22:15:23 --> setting MX_Controller Initialized
DEBUG - 2019-11-28 22:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-28 22:15:23 --> Model Class Initialized
INFO - 2019-11-28 22:15:23 --> Helper loaded: inflector_helper
DEBUG - 2019-11-28 22:15:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-28 22:15:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2019-11-28 22:15:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-28 22:15:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-28 22:15:24 --> blocks MX_Controller Initialized
DEBUG - 2019-11-28 22:15:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-28 22:15:24 --> Model Class Initialized
DEBUG - 2019-11-28 22:15:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-28 22:15:24 --> Model Class Initialized
DEBUG - 2019-11-28 22:15:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-28 22:15:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-28 22:15:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-28 22:15:24 --> Final output sent to browser
DEBUG - 2019-11-28 22:15:24 --> Total execution time: 0.8557
