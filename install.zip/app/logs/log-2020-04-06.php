<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-06 15:45:19 --> Config Class Initialized
INFO - 2020-04-06 15:45:19 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:19 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:19 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:19 --> URI Class Initialized
DEBUG - 2020-04-06 15:45:19 --> No URI present. Default controller set.
INFO - 2020-04-06 15:45:19 --> Router Class Initialized
INFO - 2020-04-06 15:45:19 --> Output Class Initialized
INFO - 2020-04-06 15:45:19 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:19 --> CSRF cookie sent
INFO - 2020-04-06 15:45:19 --> Input Class Initialized
INFO - 2020-04-06 15:45:19 --> Language Class Initialized
INFO - 2020-04-06 15:45:19 --> Language Class Initialized
INFO - 2020-04-06 15:45:19 --> Config Class Initialized
INFO - 2020-04-06 15:45:19 --> Loader Class Initialized
INFO - 2020-04-06 15:45:19 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:19 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:19 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:19 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:19 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:19 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:19 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:19 --> Parser Class Initialized
INFO - 2020-04-06 15:45:19 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:20 --> Model Class Initialized
INFO - 2020-04-06 15:45:20 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:20 --> Template Class Initialized
INFO - 2020-04-06 15:45:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:20 --> Email Class Initialized
INFO - 2020-04-06 15:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:20 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:20 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:20 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:20 --> home MX_Controller Initialized
INFO - 2020-04-06 15:45:20 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 15:45:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-06 15:45:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-06 15:45:20 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:20 --> Total execution time: 1.5896
INFO - 2020-04-06 15:45:22 --> Config Class Initialized
INFO - 2020-04-06 15:45:22 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:22 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:22 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:22 --> URI Class Initialized
INFO - 2020-04-06 15:45:22 --> Router Class Initialized
INFO - 2020-04-06 15:45:22 --> Output Class Initialized
INFO - 2020-04-06 15:45:22 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:22 --> CSRF cookie sent
INFO - 2020-04-06 15:45:22 --> Input Class Initialized
INFO - 2020-04-06 15:45:22 --> Language Class Initialized
INFO - 2020-04-06 15:45:23 --> Language Class Initialized
INFO - 2020-04-06 15:45:23 --> Config Class Initialized
INFO - 2020-04-06 15:45:23 --> Loader Class Initialized
INFO - 2020-04-06 15:45:23 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:23 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:23 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:23 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:23 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:23 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:23 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:23 --> Parser Class Initialized
INFO - 2020-04-06 15:45:23 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:23 --> Model Class Initialized
INFO - 2020-04-06 15:45:23 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:23 --> Template Class Initialized
INFO - 2020-04-06 15:45:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:23 --> Email Class Initialized
INFO - 2020-04-06 15:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:23 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:23 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:23 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:23 --> auth MX_Controller Initialized
INFO - 2020-04-06 15:45:23 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 15:45:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-06 15:45:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-06 15:45:23 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:23 --> Total execution time: 1.1398
INFO - 2020-04-06 15:45:28 --> Config Class Initialized
INFO - 2020-04-06 15:45:28 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:28 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:28 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:28 --> URI Class Initialized
INFO - 2020-04-06 15:45:28 --> Router Class Initialized
INFO - 2020-04-06 15:45:28 --> Output Class Initialized
INFO - 2020-04-06 15:45:28 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:28 --> CSRF cookie sent
INFO - 2020-04-06 15:45:28 --> CSRF token verified
INFO - 2020-04-06 15:45:28 --> Input Class Initialized
INFO - 2020-04-06 15:45:28 --> Language Class Initialized
INFO - 2020-04-06 15:45:28 --> Language Class Initialized
INFO - 2020-04-06 15:45:28 --> Config Class Initialized
INFO - 2020-04-06 15:45:28 --> Loader Class Initialized
INFO - 2020-04-06 15:45:28 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:28 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:28 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:28 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:28 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:28 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:28 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:28 --> Parser Class Initialized
INFO - 2020-04-06 15:45:28 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:28 --> Model Class Initialized
INFO - 2020-04-06 15:45:28 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:28 --> Template Class Initialized
INFO - 2020-04-06 15:45:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:28 --> Email Class Initialized
INFO - 2020-04-06 15:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:28 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:28 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:28 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:28 --> auth MX_Controller Initialized
INFO - 2020-04-06 15:45:30 --> Config Class Initialized
INFO - 2020-04-06 15:45:30 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:30 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:30 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:30 --> URI Class Initialized
INFO - 2020-04-06 15:45:30 --> Router Class Initialized
INFO - 2020-04-06 15:45:30 --> Output Class Initialized
INFO - 2020-04-06 15:45:30 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:30 --> CSRF cookie sent
INFO - 2020-04-06 15:45:30 --> Input Class Initialized
INFO - 2020-04-06 15:45:30 --> Language Class Initialized
INFO - 2020-04-06 15:45:30 --> Language Class Initialized
INFO - 2020-04-06 15:45:30 --> Config Class Initialized
INFO - 2020-04-06 15:45:30 --> Loader Class Initialized
INFO - 2020-04-06 15:45:30 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:30 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:30 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:30 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:30 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:30 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:30 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:30 --> Parser Class Initialized
INFO - 2020-04-06 15:45:30 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:30 --> Model Class Initialized
INFO - 2020-04-06 15:45:30 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:30 --> Template Class Initialized
INFO - 2020-04-06 15:45:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:30 --> Email Class Initialized
INFO - 2020-04-06 15:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:30 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:30 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:30 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:30 --> dashboard MX_Controller Initialized
INFO - 2020-04-06 15:45:30 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-06 15:45:31 --> Model Class Initialized
INFO - 2020-04-06 15:45:31 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 15:45:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-06 15:45:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-06 15:45:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:45:31 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:45:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:45:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:45:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:45:31 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:31 --> Total execution time: 0.7951
INFO - 2020-04-06 15:45:34 --> Config Class Initialized
INFO - 2020-04-06 15:45:34 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:34 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:34 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:34 --> URI Class Initialized
INFO - 2020-04-06 15:45:34 --> Router Class Initialized
INFO - 2020-04-06 15:45:34 --> Output Class Initialized
INFO - 2020-04-06 15:45:34 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:35 --> CSRF cookie sent
INFO - 2020-04-06 15:45:35 --> Input Class Initialized
INFO - 2020-04-06 15:45:35 --> Language Class Initialized
INFO - 2020-04-06 15:45:35 --> Language Class Initialized
INFO - 2020-04-06 15:45:35 --> Config Class Initialized
INFO - 2020-04-06 15:45:35 --> Loader Class Initialized
INFO - 2020-04-06 15:45:35 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:35 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:35 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:35 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:35 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:35 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:35 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:35 --> Parser Class Initialized
INFO - 2020-04-06 15:45:35 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:35 --> Model Class Initialized
INFO - 2020-04-06 15:45:35 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:35 --> Template Class Initialized
INFO - 2020-04-06 15:45:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:35 --> Email Class Initialized
INFO - 2020-04-06 15:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:35 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:35 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:35 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:35 --> post MX_Controller Initialized
INFO - 2020-04-06 15:45:35 --> Model Class Initialized
ERROR - 2020-04-06 15:45:35 --> Could not find the language line ""
ERROR - 2020-04-06 15:45:35 --> Could not find the language line ""
ERROR - 2020-04-06 15:45:35 --> Could not find the language line ""
DEBUG - 2020-04-06 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:45:35 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:45:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:45:35 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:35 --> Total execution time: 0.5252
INFO - 2020-04-06 15:45:37 --> Config Class Initialized
INFO - 2020-04-06 15:45:37 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:37 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:37 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:37 --> URI Class Initialized
INFO - 2020-04-06 15:45:37 --> Router Class Initialized
INFO - 2020-04-06 15:45:37 --> Output Class Initialized
INFO - 2020-04-06 15:45:37 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:37 --> CSRF cookie sent
INFO - 2020-04-06 15:45:37 --> Input Class Initialized
INFO - 2020-04-06 15:45:37 --> Language Class Initialized
INFO - 2020-04-06 15:45:37 --> Language Class Initialized
INFO - 2020-04-06 15:45:37 --> Config Class Initialized
INFO - 2020-04-06 15:45:37 --> Loader Class Initialized
INFO - 2020-04-06 15:45:37 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:37 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:37 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:37 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:37 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:37 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:37 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:37 --> Parser Class Initialized
INFO - 2020-04-06 15:45:37 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:37 --> Model Class Initialized
INFO - 2020-04-06 15:45:37 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:37 --> Template Class Initialized
INFO - 2020-04-06 15:45:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:37 --> Email Class Initialized
INFO - 2020-04-06 15:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:37 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:37 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:37 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:37 --> schedule MX_Controller Initialized
INFO - 2020-04-06 15:45:37 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/models/schedule_model.php
INFO - 2020-04-06 15:45:37 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/views/index.php
DEBUG - 2020-04-06 15:45:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:45:37 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:45:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:45:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:45:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:45:37 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:37 --> Total execution time: 0.5326
INFO - 2020-04-06 15:45:39 --> Config Class Initialized
INFO - 2020-04-06 15:45:39 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:39 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:39 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:39 --> URI Class Initialized
INFO - 2020-04-06 15:45:39 --> Router Class Initialized
INFO - 2020-04-06 15:45:39 --> Output Class Initialized
INFO - 2020-04-06 15:45:39 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:39 --> CSRF cookie sent
INFO - 2020-04-06 15:45:39 --> Input Class Initialized
INFO - 2020-04-06 15:45:39 --> Language Class Initialized
INFO - 2020-04-06 15:45:39 --> Language Class Initialized
INFO - 2020-04-06 15:45:39 --> Config Class Initialized
INFO - 2020-04-06 15:45:39 --> Loader Class Initialized
INFO - 2020-04-06 15:45:39 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:39 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:39 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:39 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:39 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:39 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:39 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:39 --> Parser Class Initialized
INFO - 2020-04-06 15:45:39 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:39 --> Model Class Initialized
INFO - 2020-04-06 15:45:39 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:39 --> Template Class Initialized
INFO - 2020-04-06 15:45:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:39 --> Email Class Initialized
INFO - 2020-04-06 15:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:39 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:39 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:39 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:39 --> follow MX_Controller Initialized
INFO - 2020-04-06 15:45:39 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 15:45:39 --> Model Class Initialized
INFO - 2020-04-06 15:45:39 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 15:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 15:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:45:39 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:45:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:45:39 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:39 --> Total execution time: 0.5153
INFO - 2020-04-06 15:45:41 --> Config Class Initialized
INFO - 2020-04-06 15:45:41 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:41 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:41 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:41 --> URI Class Initialized
INFO - 2020-04-06 15:45:41 --> Router Class Initialized
INFO - 2020-04-06 15:45:41 --> Output Class Initialized
INFO - 2020-04-06 15:45:41 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:41 --> CSRF cookie sent
INFO - 2020-04-06 15:45:41 --> Input Class Initialized
INFO - 2020-04-06 15:45:41 --> Language Class Initialized
INFO - 2020-04-06 15:45:41 --> Language Class Initialized
INFO - 2020-04-06 15:45:41 --> Config Class Initialized
INFO - 2020-04-06 15:45:41 --> Loader Class Initialized
INFO - 2020-04-06 15:45:41 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:41 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:41 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:41 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:41 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:41 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:41 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:41 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:41 --> Parser Class Initialized
INFO - 2020-04-06 15:45:41 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:41 --> Model Class Initialized
INFO - 2020-04-06 15:45:41 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:41 --> Template Class Initialized
INFO - 2020-04-06 15:45:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:41 --> Email Class Initialized
INFO - 2020-04-06 15:45:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:41 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:41 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:41 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:41 --> post MX_Controller Initialized
INFO - 2020-04-06 15:45:41 --> Model Class Initialized
ERROR - 2020-04-06 15:45:41 --> Could not find the language line ""
ERROR - 2020-04-06 15:45:41 --> Could not find the language line ""
ERROR - 2020-04-06 15:45:41 --> Could not find the language line ""
DEBUG - 2020-04-06 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:45:41 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:45:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:45:41 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:41 --> Total execution time: 0.5026
INFO - 2020-04-06 15:45:45 --> Config Class Initialized
INFO - 2020-04-06 15:45:45 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:45 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:45 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:45 --> URI Class Initialized
INFO - 2020-04-06 15:45:45 --> Router Class Initialized
INFO - 2020-04-06 15:45:45 --> Output Class Initialized
INFO - 2020-04-06 15:45:45 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:45 --> CSRF cookie sent
INFO - 2020-04-06 15:45:45 --> Input Class Initialized
INFO - 2020-04-06 15:45:45 --> Language Class Initialized
INFO - 2020-04-06 15:45:45 --> Language Class Initialized
INFO - 2020-04-06 15:45:45 --> Config Class Initialized
INFO - 2020-04-06 15:45:45 --> Loader Class Initialized
INFO - 2020-04-06 15:45:45 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:45 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:45 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:45 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:45 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:45 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:45 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:45 --> Parser Class Initialized
INFO - 2020-04-06 15:45:45 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:45 --> Model Class Initialized
INFO - 2020-04-06 15:45:45 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:45 --> Template Class Initialized
INFO - 2020-04-06 15:45:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:45 --> Email Class Initialized
INFO - 2020-04-06 15:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:45 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:45 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:45 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:45 --> follow MX_Controller Initialized
INFO - 2020-04-06 15:45:45 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 15:45:45 --> Model Class Initialized
INFO - 2020-04-06 15:45:45 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 15:45:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 15:45:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:45:45 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:45:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:45:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:45:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:45:45 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:45 --> Total execution time: 0.5218
INFO - 2020-04-06 15:45:47 --> Config Class Initialized
INFO - 2020-04-06 15:45:47 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:47 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:47 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:47 --> URI Class Initialized
INFO - 2020-04-06 15:45:47 --> Router Class Initialized
INFO - 2020-04-06 15:45:47 --> Output Class Initialized
INFO - 2020-04-06 15:45:47 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:47 --> CSRF cookie sent
INFO - 2020-04-06 15:45:47 --> Input Class Initialized
INFO - 2020-04-06 15:45:47 --> Language Class Initialized
INFO - 2020-04-06 15:45:47 --> Language Class Initialized
INFO - 2020-04-06 15:45:47 --> Config Class Initialized
INFO - 2020-04-06 15:45:47 --> Loader Class Initialized
INFO - 2020-04-06 15:45:47 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:47 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:47 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:47 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:47 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:47 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:47 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:47 --> Parser Class Initialized
INFO - 2020-04-06 15:45:47 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:47 --> Model Class Initialized
INFO - 2020-04-06 15:45:47 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:47 --> Template Class Initialized
INFO - 2020-04-06 15:45:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:47 --> Email Class Initialized
INFO - 2020-04-06 15:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:47 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:47 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:47 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:47 --> unfollow MX_Controller Initialized
INFO - 2020-04-06 15:45:47 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/unfollow/models/unfollow_model.php
INFO - 2020-04-06 15:45:47 --> Model Class Initialized
INFO - 2020-04-06 15:45:47 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 15:45:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/unfollow/views/index.php
DEBUG - 2020-04-06 15:45:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:45:47 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:45:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:45:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:45:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:45:47 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:47 --> Total execution time: 0.5220
INFO - 2020-04-06 15:45:48 --> Config Class Initialized
INFO - 2020-04-06 15:45:48 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:48 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:48 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:48 --> URI Class Initialized
INFO - 2020-04-06 15:45:48 --> Router Class Initialized
INFO - 2020-04-06 15:45:48 --> Output Class Initialized
INFO - 2020-04-06 15:45:48 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:48 --> CSRF cookie sent
INFO - 2020-04-06 15:45:48 --> Input Class Initialized
INFO - 2020-04-06 15:45:48 --> Language Class Initialized
INFO - 2020-04-06 15:45:48 --> Language Class Initialized
INFO - 2020-04-06 15:45:48 --> Config Class Initialized
INFO - 2020-04-06 15:45:48 --> Loader Class Initialized
INFO - 2020-04-06 15:45:48 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:48 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:48 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:48 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:48 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:48 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:48 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:48 --> Parser Class Initialized
INFO - 2020-04-06 15:45:48 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:48 --> Model Class Initialized
INFO - 2020-04-06 15:45:48 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:48 --> Template Class Initialized
INFO - 2020-04-06 15:45:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:48 --> Email Class Initialized
INFO - 2020-04-06 15:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:48 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:48 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:48 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:48 --> schedule MX_Controller Initialized
INFO - 2020-04-06 15:45:48 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/models/schedule_model.php
INFO - 2020-04-06 15:45:48 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/views/index.php
DEBUG - 2020-04-06 15:45:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:45:49 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:45:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:45:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:45:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:45:49 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:49 --> Total execution time: 0.4838
INFO - 2020-04-06 15:45:51 --> Config Class Initialized
INFO - 2020-04-06 15:45:51 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:45:51 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:45:51 --> Utf8 Class Initialized
INFO - 2020-04-06 15:45:51 --> URI Class Initialized
INFO - 2020-04-06 15:45:51 --> Router Class Initialized
INFO - 2020-04-06 15:45:51 --> Output Class Initialized
INFO - 2020-04-06 15:45:51 --> Security Class Initialized
DEBUG - 2020-04-06 15:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:45:51 --> CSRF cookie sent
INFO - 2020-04-06 15:45:51 --> Input Class Initialized
INFO - 2020-04-06 15:45:51 --> Language Class Initialized
INFO - 2020-04-06 15:45:51 --> Language Class Initialized
INFO - 2020-04-06 15:45:51 --> Config Class Initialized
INFO - 2020-04-06 15:45:51 --> Loader Class Initialized
INFO - 2020-04-06 15:45:51 --> Helper loaded: url_helper
INFO - 2020-04-06 15:45:51 --> Helper loaded: file_helper
INFO - 2020-04-06 15:45:51 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:45:51 --> Helper loaded: common_helper
INFO - 2020-04-06 15:45:51 --> Helper loaded: language_helper
INFO - 2020-04-06 15:45:51 --> Helper loaded: email_helper
INFO - 2020-04-06 15:45:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:45:51 --> Database Driver Class Initialized
INFO - 2020-04-06 15:45:51 --> Parser Class Initialized
INFO - 2020-04-06 15:45:51 --> User Agent Class Initialized
INFO - 2020-04-06 15:45:51 --> Model Class Initialized
INFO - 2020-04-06 15:45:51 --> Model Class Initialized
DEBUG - 2020-04-06 15:45:51 --> Template Class Initialized
INFO - 2020-04-06 15:45:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:45:52 --> Email Class Initialized
INFO - 2020-04-06 15:45:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:45:52 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:45:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:45:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:45:52 --> Encryption Class Initialized
INFO - 2020-04-06 15:45:52 --> Controller Class Initialized
DEBUG - 2020-04-06 15:45:52 --> post MX_Controller Initialized
INFO - 2020-04-06 15:45:52 --> Model Class Initialized
ERROR - 2020-04-06 15:45:52 --> Could not find the language line ""
ERROR - 2020-04-06 15:45:52 --> Could not find the language line ""
ERROR - 2020-04-06 15:45:52 --> Could not find the language line ""
DEBUG - 2020-04-06 15:45:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 15:45:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:45:52 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:45:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:45:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:45:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:45:52 --> Final output sent to browser
DEBUG - 2020-04-06 15:45:52 --> Total execution time: 0.5035
INFO - 2020-04-06 15:55:19 --> Config Class Initialized
INFO - 2020-04-06 15:55:19 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:55:19 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:55:19 --> Utf8 Class Initialized
INFO - 2020-04-06 15:55:19 --> URI Class Initialized
INFO - 2020-04-06 15:55:19 --> Router Class Initialized
INFO - 2020-04-06 15:55:19 --> Output Class Initialized
INFO - 2020-04-06 15:55:19 --> Security Class Initialized
DEBUG - 2020-04-06 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:55:19 --> CSRF cookie sent
INFO - 2020-04-06 15:55:19 --> CSRF token verified
INFO - 2020-04-06 15:55:19 --> Input Class Initialized
INFO - 2020-04-06 15:55:19 --> Language Class Initialized
INFO - 2020-04-06 15:55:19 --> Language Class Initialized
INFO - 2020-04-06 15:55:19 --> Config Class Initialized
INFO - 2020-04-06 15:55:19 --> Loader Class Initialized
INFO - 2020-04-06 15:55:19 --> Helper loaded: url_helper
INFO - 2020-04-06 15:55:19 --> Helper loaded: file_helper
INFO - 2020-04-06 15:55:19 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:55:19 --> Helper loaded: common_helper
INFO - 2020-04-06 15:55:19 --> Helper loaded: language_helper
INFO - 2020-04-06 15:55:19 --> Helper loaded: email_helper
INFO - 2020-04-06 15:55:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:55:19 --> Database Driver Class Initialized
INFO - 2020-04-06 15:55:19 --> Parser Class Initialized
INFO - 2020-04-06 15:55:19 --> User Agent Class Initialized
INFO - 2020-04-06 15:55:19 --> Model Class Initialized
INFO - 2020-04-06 15:55:19 --> Model Class Initialized
DEBUG - 2020-04-06 15:55:19 --> Template Class Initialized
INFO - 2020-04-06 15:55:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:55:19 --> Email Class Initialized
INFO - 2020-04-06 15:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:55:19 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:55:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:55:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:55:19 --> Encryption Class Initialized
INFO - 2020-04-06 15:55:19 --> Controller Class Initialized
DEBUG - 2020-04-06 15:55:19 --> post MX_Controller Initialized
INFO - 2020-04-06 15:55:19 --> Model Class Initialized
INFO - 2020-04-06 15:55:26 --> Config Class Initialized
INFO - 2020-04-06 15:55:26 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:55:26 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:55:26 --> Utf8 Class Initialized
INFO - 2020-04-06 15:55:26 --> URI Class Initialized
INFO - 2020-04-06 15:55:26 --> Router Class Initialized
INFO - 2020-04-06 15:55:26 --> Output Class Initialized
INFO - 2020-04-06 15:55:26 --> Security Class Initialized
DEBUG - 2020-04-06 15:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:55:26 --> CSRF cookie sent
INFO - 2020-04-06 15:55:26 --> CSRF token verified
INFO - 2020-04-06 15:55:26 --> Input Class Initialized
INFO - 2020-04-06 15:55:26 --> Language Class Initialized
INFO - 2020-04-06 15:55:26 --> Language Class Initialized
INFO - 2020-04-06 15:55:26 --> Config Class Initialized
INFO - 2020-04-06 15:55:26 --> Loader Class Initialized
INFO - 2020-04-06 15:55:26 --> Helper loaded: url_helper
INFO - 2020-04-06 15:55:26 --> Helper loaded: file_helper
INFO - 2020-04-06 15:55:26 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:55:26 --> Helper loaded: common_helper
INFO - 2020-04-06 15:55:26 --> Helper loaded: language_helper
INFO - 2020-04-06 15:55:26 --> Helper loaded: email_helper
INFO - 2020-04-06 15:55:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:55:26 --> Database Driver Class Initialized
INFO - 2020-04-06 15:55:26 --> Parser Class Initialized
INFO - 2020-04-06 15:55:26 --> User Agent Class Initialized
INFO - 2020-04-06 15:55:26 --> Model Class Initialized
INFO - 2020-04-06 15:55:26 --> Model Class Initialized
DEBUG - 2020-04-06 15:55:26 --> Template Class Initialized
INFO - 2020-04-06 15:55:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:55:26 --> Email Class Initialized
INFO - 2020-04-06 15:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:55:26 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:55:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:55:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:55:26 --> Encryption Class Initialized
INFO - 2020-04-06 15:55:26 --> Controller Class Initialized
DEBUG - 2020-04-06 15:55:26 --> post MX_Controller Initialized
INFO - 2020-04-06 15:55:26 --> Model Class Initialized
INFO - 2020-04-06 15:56:19 --> Config Class Initialized
INFO - 2020-04-06 15:56:19 --> Hooks Class Initialized
INFO - 2020-04-06 15:56:19 --> Config Class Initialized
INFO - 2020-04-06 15:56:19 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:56:19 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:56:19 --> Utf8 Class Initialized
DEBUG - 2020-04-06 15:56:19 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:56:19 --> Utf8 Class Initialized
INFO - 2020-04-06 15:56:19 --> URI Class Initialized
INFO - 2020-04-06 15:56:19 --> URI Class Initialized
INFO - 2020-04-06 15:56:19 --> Router Class Initialized
INFO - 2020-04-06 15:56:19 --> Output Class Initialized
INFO - 2020-04-06 15:56:19 --> Router Class Initialized
INFO - 2020-04-06 15:56:19 --> Security Class Initialized
INFO - 2020-04-06 15:56:19 --> Output Class Initialized
INFO - 2020-04-06 15:56:19 --> Security Class Initialized
DEBUG - 2020-04-06 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:56:19 --> CSRF cookie sent
DEBUG - 2020-04-06 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:56:19 --> Input Class Initialized
INFO - 2020-04-06 15:56:19 --> CSRF cookie sent
INFO - 2020-04-06 15:56:19 --> Input Class Initialized
INFO - 2020-04-06 15:56:19 --> Language Class Initialized
INFO - 2020-04-06 15:56:19 --> Language Class Initialized
ERROR - 2020-04-06 15:56:19 --> 404 Page Not Found: /index
ERROR - 2020-04-06 15:56:19 --> 404 Page Not Found: /index
INFO - 2020-04-06 15:56:20 --> Config Class Initialized
INFO - 2020-04-06 15:56:20 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:56:20 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:56:20 --> Utf8 Class Initialized
INFO - 2020-04-06 15:56:20 --> URI Class Initialized
INFO - 2020-04-06 15:56:20 --> Router Class Initialized
INFO - 2020-04-06 15:56:20 --> Output Class Initialized
INFO - 2020-04-06 15:56:20 --> Security Class Initialized
DEBUG - 2020-04-06 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:56:20 --> CSRF cookie sent
INFO - 2020-04-06 15:56:20 --> CSRF token verified
INFO - 2020-04-06 15:56:20 --> Input Class Initialized
INFO - 2020-04-06 15:56:20 --> Language Class Initialized
INFO - 2020-04-06 15:56:20 --> Language Class Initialized
INFO - 2020-04-06 15:56:20 --> Config Class Initialized
INFO - 2020-04-06 15:56:20 --> Loader Class Initialized
INFO - 2020-04-06 15:56:20 --> Helper loaded: url_helper
INFO - 2020-04-06 15:56:20 --> Helper loaded: file_helper
INFO - 2020-04-06 15:56:20 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:56:20 --> Helper loaded: common_helper
INFO - 2020-04-06 15:56:20 --> Helper loaded: language_helper
INFO - 2020-04-06 15:56:20 --> Helper loaded: email_helper
INFO - 2020-04-06 15:56:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:56:20 --> Database Driver Class Initialized
INFO - 2020-04-06 15:56:20 --> Parser Class Initialized
INFO - 2020-04-06 15:56:20 --> User Agent Class Initialized
INFO - 2020-04-06 15:56:20 --> Model Class Initialized
INFO - 2020-04-06 15:56:20 --> Model Class Initialized
DEBUG - 2020-04-06 15:56:20 --> Template Class Initialized
INFO - 2020-04-06 15:56:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:56:20 --> Email Class Initialized
INFO - 2020-04-06 15:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:56:20 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:56:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:56:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:56:20 --> Encryption Class Initialized
INFO - 2020-04-06 15:56:20 --> Controller Class Initialized
DEBUG - 2020-04-06 15:56:20 --> post MX_Controller Initialized
INFO - 2020-04-06 15:56:20 --> Model Class Initialized
INFO - 2020-04-06 15:56:56 --> Config Class Initialized
INFO - 2020-04-06 15:56:56 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:56:56 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:56:56 --> Utf8 Class Initialized
INFO - 2020-04-06 15:56:56 --> URI Class Initialized
INFO - 2020-04-06 15:56:56 --> Router Class Initialized
INFO - 2020-04-06 15:56:56 --> Output Class Initialized
INFO - 2020-04-06 15:56:56 --> Security Class Initialized
DEBUG - 2020-04-06 15:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:56:56 --> CSRF cookie sent
INFO - 2020-04-06 15:56:56 --> CSRF token verified
INFO - 2020-04-06 15:56:56 --> Input Class Initialized
INFO - 2020-04-06 15:56:56 --> Language Class Initialized
INFO - 2020-04-06 15:56:56 --> Language Class Initialized
INFO - 2020-04-06 15:56:56 --> Config Class Initialized
INFO - 2020-04-06 15:56:56 --> Loader Class Initialized
INFO - 2020-04-06 15:56:56 --> Helper loaded: url_helper
INFO - 2020-04-06 15:56:56 --> Helper loaded: file_helper
INFO - 2020-04-06 15:56:56 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:56:56 --> Helper loaded: common_helper
INFO - 2020-04-06 15:56:56 --> Helper loaded: language_helper
INFO - 2020-04-06 15:56:56 --> Helper loaded: email_helper
INFO - 2020-04-06 15:56:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:56:56 --> Database Driver Class Initialized
INFO - 2020-04-06 15:56:56 --> Parser Class Initialized
INFO - 2020-04-06 15:56:56 --> User Agent Class Initialized
INFO - 2020-04-06 15:56:56 --> Model Class Initialized
INFO - 2020-04-06 15:56:56 --> Model Class Initialized
DEBUG - 2020-04-06 15:56:56 --> Template Class Initialized
INFO - 2020-04-06 15:56:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:56:56 --> Email Class Initialized
INFO - 2020-04-06 15:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:56:56 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:56:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:56:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:56:57 --> Encryption Class Initialized
INFO - 2020-04-06 15:56:57 --> Controller Class Initialized
DEBUG - 2020-04-06 15:56:57 --> post MX_Controller Initialized
INFO - 2020-04-06 15:56:57 --> Model Class Initialized
INFO - 2020-04-06 15:57:03 --> Config Class Initialized
INFO - 2020-04-06 15:57:03 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:57:03 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:57:03 --> Utf8 Class Initialized
INFO - 2020-04-06 15:57:03 --> URI Class Initialized
INFO - 2020-04-06 15:57:03 --> Router Class Initialized
INFO - 2020-04-06 15:57:03 --> Output Class Initialized
INFO - 2020-04-06 15:57:03 --> Security Class Initialized
DEBUG - 2020-04-06 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:57:03 --> CSRF cookie sent
INFO - 2020-04-06 15:57:03 --> CSRF token verified
INFO - 2020-04-06 15:57:04 --> Input Class Initialized
INFO - 2020-04-06 15:57:04 --> Language Class Initialized
INFO - 2020-04-06 15:57:04 --> Language Class Initialized
INFO - 2020-04-06 15:57:04 --> Config Class Initialized
INFO - 2020-04-06 15:57:04 --> Loader Class Initialized
INFO - 2020-04-06 15:57:04 --> Helper loaded: url_helper
INFO - 2020-04-06 15:57:04 --> Helper loaded: file_helper
INFO - 2020-04-06 15:57:04 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:57:04 --> Helper loaded: common_helper
INFO - 2020-04-06 15:57:04 --> Helper loaded: language_helper
INFO - 2020-04-06 15:57:04 --> Helper loaded: email_helper
INFO - 2020-04-06 15:57:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:57:04 --> Database Driver Class Initialized
INFO - 2020-04-06 15:57:04 --> Parser Class Initialized
INFO - 2020-04-06 15:57:04 --> User Agent Class Initialized
INFO - 2020-04-06 15:57:04 --> Model Class Initialized
INFO - 2020-04-06 15:57:04 --> Model Class Initialized
DEBUG - 2020-04-06 15:57:04 --> Template Class Initialized
INFO - 2020-04-06 15:57:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:57:04 --> Email Class Initialized
INFO - 2020-04-06 15:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:57:04 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:57:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:57:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:57:04 --> Encryption Class Initialized
INFO - 2020-04-06 15:57:04 --> Controller Class Initialized
DEBUG - 2020-04-06 15:57:04 --> post MX_Controller Initialized
INFO - 2020-04-06 15:57:04 --> Model Class Initialized
INFO - 2020-04-06 15:57:17 --> Config Class Initialized
INFO - 2020-04-06 15:57:17 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:57:17 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:57:17 --> Utf8 Class Initialized
INFO - 2020-04-06 15:57:17 --> URI Class Initialized
INFO - 2020-04-06 15:57:17 --> Router Class Initialized
INFO - 2020-04-06 15:57:17 --> Output Class Initialized
INFO - 2020-04-06 15:57:17 --> Security Class Initialized
DEBUG - 2020-04-06 15:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:57:17 --> CSRF cookie sent
INFO - 2020-04-06 15:57:17 --> CSRF token verified
INFO - 2020-04-06 15:57:17 --> Input Class Initialized
INFO - 2020-04-06 15:57:17 --> Language Class Initialized
INFO - 2020-04-06 15:57:17 --> Language Class Initialized
INFO - 2020-04-06 15:57:17 --> Config Class Initialized
INFO - 2020-04-06 15:57:17 --> Loader Class Initialized
INFO - 2020-04-06 15:57:17 --> Helper loaded: url_helper
INFO - 2020-04-06 15:57:17 --> Helper loaded: file_helper
INFO - 2020-04-06 15:57:17 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:57:17 --> Helper loaded: common_helper
INFO - 2020-04-06 15:57:17 --> Helper loaded: language_helper
INFO - 2020-04-06 15:57:17 --> Helper loaded: email_helper
INFO - 2020-04-06 15:57:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:57:17 --> Database Driver Class Initialized
INFO - 2020-04-06 15:57:17 --> Parser Class Initialized
INFO - 2020-04-06 15:57:17 --> User Agent Class Initialized
INFO - 2020-04-06 15:57:17 --> Model Class Initialized
INFO - 2020-04-06 15:57:17 --> Model Class Initialized
DEBUG - 2020-04-06 15:57:17 --> Template Class Initialized
INFO - 2020-04-06 15:57:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:57:17 --> Email Class Initialized
INFO - 2020-04-06 15:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:57:17 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:57:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:57:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:57:17 --> Encryption Class Initialized
INFO - 2020-04-06 15:57:17 --> Controller Class Initialized
DEBUG - 2020-04-06 15:57:17 --> post MX_Controller Initialized
INFO - 2020-04-06 15:57:18 --> Model Class Initialized
INFO - 2020-04-06 15:58:25 --> Config Class Initialized
INFO - 2020-04-06 15:58:25 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:58:25 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:58:25 --> Utf8 Class Initialized
INFO - 2020-04-06 15:58:25 --> URI Class Initialized
INFO - 2020-04-06 15:58:25 --> Router Class Initialized
INFO - 2020-04-06 15:58:25 --> Output Class Initialized
INFO - 2020-04-06 15:58:25 --> Security Class Initialized
DEBUG - 2020-04-06 15:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:58:25 --> CSRF cookie sent
INFO - 2020-04-06 15:58:25 --> CSRF token verified
INFO - 2020-04-06 15:58:25 --> Input Class Initialized
INFO - 2020-04-06 15:58:25 --> Language Class Initialized
INFO - 2020-04-06 15:58:25 --> Language Class Initialized
INFO - 2020-04-06 15:58:25 --> Config Class Initialized
INFO - 2020-04-06 15:58:25 --> Loader Class Initialized
INFO - 2020-04-06 15:58:25 --> Helper loaded: url_helper
INFO - 2020-04-06 15:58:25 --> Helper loaded: file_helper
INFO - 2020-04-06 15:58:25 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:58:25 --> Helper loaded: common_helper
INFO - 2020-04-06 15:58:25 --> Helper loaded: language_helper
INFO - 2020-04-06 15:58:25 --> Helper loaded: email_helper
INFO - 2020-04-06 15:58:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:58:25 --> Database Driver Class Initialized
INFO - 2020-04-06 15:58:25 --> Parser Class Initialized
INFO - 2020-04-06 15:58:25 --> User Agent Class Initialized
INFO - 2020-04-06 15:58:25 --> Model Class Initialized
INFO - 2020-04-06 15:58:25 --> Model Class Initialized
DEBUG - 2020-04-06 15:58:25 --> Template Class Initialized
INFO - 2020-04-06 15:58:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:58:25 --> Email Class Initialized
INFO - 2020-04-06 15:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:58:25 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:58:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:58:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:58:25 --> Encryption Class Initialized
INFO - 2020-04-06 15:58:25 --> Controller Class Initialized
DEBUG - 2020-04-06 15:58:25 --> post MX_Controller Initialized
INFO - 2020-04-06 15:58:25 --> Model Class Initialized
INFO - 2020-04-06 15:58:55 --> Config Class Initialized
INFO - 2020-04-06 15:58:55 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:58:55 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:58:55 --> Utf8 Class Initialized
INFO - 2020-04-06 15:58:55 --> URI Class Initialized
INFO - 2020-04-06 15:58:55 --> Router Class Initialized
INFO - 2020-04-06 15:58:55 --> Output Class Initialized
INFO - 2020-04-06 15:58:55 --> Security Class Initialized
DEBUG - 2020-04-06 15:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:58:55 --> CSRF cookie sent
INFO - 2020-04-06 15:58:55 --> Input Class Initialized
INFO - 2020-04-06 15:58:55 --> Language Class Initialized
INFO - 2020-04-06 15:58:55 --> Language Class Initialized
INFO - 2020-04-06 15:58:55 --> Config Class Initialized
INFO - 2020-04-06 15:58:55 --> Loader Class Initialized
INFO - 2020-04-06 15:58:55 --> Helper loaded: url_helper
INFO - 2020-04-06 15:58:55 --> Helper loaded: file_helper
INFO - 2020-04-06 15:58:55 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:58:55 --> Helper loaded: common_helper
INFO - 2020-04-06 15:58:55 --> Helper loaded: language_helper
INFO - 2020-04-06 15:58:55 --> Helper loaded: email_helper
INFO - 2020-04-06 15:58:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:58:55 --> Database Driver Class Initialized
INFO - 2020-04-06 15:58:55 --> Parser Class Initialized
INFO - 2020-04-06 15:58:55 --> User Agent Class Initialized
INFO - 2020-04-06 15:58:55 --> Model Class Initialized
INFO - 2020-04-06 15:58:55 --> Model Class Initialized
DEBUG - 2020-04-06 15:58:55 --> Template Class Initialized
INFO - 2020-04-06 15:58:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:58:55 --> Email Class Initialized
INFO - 2020-04-06 15:58:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:58:55 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:58:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:58:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:58:55 --> Encryption Class Initialized
INFO - 2020-04-06 15:58:55 --> Controller Class Initialized
DEBUG - 2020-04-06 15:58:55 --> twitter MX_Controller Initialized
INFO - 2020-04-06 15:58:55 --> Model Class Initialized
DEBUG - 2020-04-06 15:58:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-06 15:58:55 --> Model Class Initialized
DEBUG - 2020-04-06 15:58:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-06 15:58:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:58:55 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:58:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:58:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:58:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:58:55 --> Final output sent to browser
DEBUG - 2020-04-06 15:58:55 --> Total execution time: 0.6715
INFO - 2020-04-06 15:58:56 --> Config Class Initialized
INFO - 2020-04-06 15:58:56 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:58:56 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:58:56 --> Utf8 Class Initialized
INFO - 2020-04-06 15:58:56 --> URI Class Initialized
INFO - 2020-04-06 15:58:56 --> Router Class Initialized
INFO - 2020-04-06 15:58:56 --> Output Class Initialized
INFO - 2020-04-06 15:58:56 --> Security Class Initialized
DEBUG - 2020-04-06 15:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:58:56 --> CSRF cookie sent
INFO - 2020-04-06 15:58:56 --> Input Class Initialized
INFO - 2020-04-06 15:58:56 --> Config Class Initialized
INFO - 2020-04-06 15:58:56 --> Hooks Class Initialized
INFO - 2020-04-06 15:58:56 --> Language Class Initialized
ERROR - 2020-04-06 15:58:56 --> 404 Page Not Found: /index
DEBUG - 2020-04-06 15:58:56 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:58:56 --> Utf8 Class Initialized
INFO - 2020-04-06 15:58:56 --> URI Class Initialized
INFO - 2020-04-06 15:58:56 --> Router Class Initialized
INFO - 2020-04-06 15:58:56 --> Output Class Initialized
INFO - 2020-04-06 15:58:56 --> Security Class Initialized
DEBUG - 2020-04-06 15:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:58:56 --> CSRF cookie sent
INFO - 2020-04-06 15:58:56 --> Input Class Initialized
INFO - 2020-04-06 15:58:56 --> Language Class Initialized
ERROR - 2020-04-06 15:58:56 --> 404 Page Not Found: /index
INFO - 2020-04-06 15:58:58 --> Config Class Initialized
INFO - 2020-04-06 15:58:58 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:58:58 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:58:58 --> Utf8 Class Initialized
INFO - 2020-04-06 15:58:58 --> URI Class Initialized
INFO - 2020-04-06 15:58:58 --> Router Class Initialized
INFO - 2020-04-06 15:58:58 --> Output Class Initialized
INFO - 2020-04-06 15:58:58 --> Security Class Initialized
DEBUG - 2020-04-06 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:58:58 --> CSRF cookie sent
INFO - 2020-04-06 15:58:58 --> CSRF token verified
INFO - 2020-04-06 15:58:58 --> Input Class Initialized
INFO - 2020-04-06 15:58:58 --> Language Class Initialized
INFO - 2020-04-06 15:58:58 --> Language Class Initialized
INFO - 2020-04-06 15:58:58 --> Config Class Initialized
INFO - 2020-04-06 15:58:58 --> Loader Class Initialized
INFO - 2020-04-06 15:58:58 --> Helper loaded: url_helper
INFO - 2020-04-06 15:58:58 --> Helper loaded: file_helper
INFO - 2020-04-06 15:58:58 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:58:58 --> Helper loaded: common_helper
INFO - 2020-04-06 15:58:58 --> Helper loaded: language_helper
INFO - 2020-04-06 15:58:58 --> Helper loaded: email_helper
INFO - 2020-04-06 15:58:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:58:58 --> Database Driver Class Initialized
INFO - 2020-04-06 15:58:58 --> Parser Class Initialized
INFO - 2020-04-06 15:58:58 --> User Agent Class Initialized
INFO - 2020-04-06 15:58:58 --> Model Class Initialized
INFO - 2020-04-06 15:58:58 --> Model Class Initialized
DEBUG - 2020-04-06 15:58:58 --> Template Class Initialized
INFO - 2020-04-06 15:58:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:58:58 --> Email Class Initialized
INFO - 2020-04-06 15:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:58:58 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:58:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:58:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:58:58 --> Encryption Class Initialized
INFO - 2020-04-06 15:58:58 --> Controller Class Initialized
DEBUG - 2020-04-06 15:58:58 --> twitter MX_Controller Initialized
INFO - 2020-04-06 15:58:58 --> Model Class Initialized
DEBUG - 2020-04-06 15:58:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-06 15:58:58 --> Model Class Initialized
INFO - 2020-04-06 15:59:01 --> Config Class Initialized
INFO - 2020-04-06 15:59:01 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:01 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:01 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:01 --> URI Class Initialized
INFO - 2020-04-06 15:59:01 --> Router Class Initialized
INFO - 2020-04-06 15:59:01 --> Output Class Initialized
INFO - 2020-04-06 15:59:01 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:01 --> CSRF cookie sent
INFO - 2020-04-06 15:59:01 --> Input Class Initialized
INFO - 2020-04-06 15:59:01 --> Language Class Initialized
INFO - 2020-04-06 15:59:01 --> Language Class Initialized
INFO - 2020-04-06 15:59:01 --> Config Class Initialized
INFO - 2020-04-06 15:59:01 --> Loader Class Initialized
INFO - 2020-04-06 15:59:01 --> Helper loaded: url_helper
INFO - 2020-04-06 15:59:01 --> Helper loaded: file_helper
INFO - 2020-04-06 15:59:01 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:59:01 --> Helper loaded: common_helper
INFO - 2020-04-06 15:59:01 --> Helper loaded: language_helper
INFO - 2020-04-06 15:59:02 --> Helper loaded: email_helper
INFO - 2020-04-06 15:59:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:59:02 --> Database Driver Class Initialized
INFO - 2020-04-06 15:59:02 --> Parser Class Initialized
INFO - 2020-04-06 15:59:02 --> User Agent Class Initialized
INFO - 2020-04-06 15:59:02 --> Model Class Initialized
INFO - 2020-04-06 15:59:02 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:02 --> Template Class Initialized
INFO - 2020-04-06 15:59:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:59:02 --> Email Class Initialized
INFO - 2020-04-06 15:59:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:59:02 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:59:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:59:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:59:02 --> Encryption Class Initialized
INFO - 2020-04-06 15:59:02 --> Controller Class Initialized
DEBUG - 2020-04-06 15:59:02 --> twitter MX_Controller Initialized
INFO - 2020-04-06 15:59:02 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-06 15:59:02 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-06 15:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:59:02 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:59:02 --> Final output sent to browser
DEBUG - 2020-04-06 15:59:02 --> Total execution time: 0.6101
INFO - 2020-04-06 15:59:02 --> Config Class Initialized
INFO - 2020-04-06 15:59:02 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:02 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:02 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:02 --> URI Class Initialized
INFO - 2020-04-06 15:59:02 --> Router Class Initialized
INFO - 2020-04-06 15:59:02 --> Output Class Initialized
INFO - 2020-04-06 15:59:02 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:02 --> CSRF cookie sent
INFO - 2020-04-06 15:59:02 --> Input Class Initialized
INFO - 2020-04-06 15:59:02 --> Language Class Initialized
ERROR - 2020-04-06 15:59:02 --> 404 Page Not Found: /index
INFO - 2020-04-06 15:59:02 --> Config Class Initialized
INFO - 2020-04-06 15:59:02 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:02 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:02 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:02 --> URI Class Initialized
INFO - 2020-04-06 15:59:02 --> Router Class Initialized
INFO - 2020-04-06 15:59:02 --> Output Class Initialized
INFO - 2020-04-06 15:59:02 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:03 --> CSRF cookie sent
INFO - 2020-04-06 15:59:03 --> Input Class Initialized
INFO - 2020-04-06 15:59:03 --> Language Class Initialized
ERROR - 2020-04-06 15:59:03 --> 404 Page Not Found: /index
INFO - 2020-04-06 15:59:04 --> Config Class Initialized
INFO - 2020-04-06 15:59:04 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:04 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:04 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:04 --> URI Class Initialized
INFO - 2020-04-06 15:59:05 --> Router Class Initialized
INFO - 2020-04-06 15:59:05 --> Output Class Initialized
INFO - 2020-04-06 15:59:05 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:05 --> CSRF cookie sent
INFO - 2020-04-06 15:59:05 --> Input Class Initialized
INFO - 2020-04-06 15:59:05 --> Language Class Initialized
INFO - 2020-04-06 15:59:05 --> Language Class Initialized
INFO - 2020-04-06 15:59:05 --> Config Class Initialized
INFO - 2020-04-06 15:59:05 --> Loader Class Initialized
INFO - 2020-04-06 15:59:05 --> Helper loaded: url_helper
INFO - 2020-04-06 15:59:05 --> Helper loaded: file_helper
INFO - 2020-04-06 15:59:05 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:59:05 --> Helper loaded: common_helper
INFO - 2020-04-06 15:59:05 --> Helper loaded: language_helper
INFO - 2020-04-06 15:59:05 --> Helper loaded: email_helper
INFO - 2020-04-06 15:59:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:59:05 --> Database Driver Class Initialized
INFO - 2020-04-06 15:59:05 --> Parser Class Initialized
INFO - 2020-04-06 15:59:05 --> User Agent Class Initialized
INFO - 2020-04-06 15:59:05 --> Model Class Initialized
INFO - 2020-04-06 15:59:05 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:05 --> Template Class Initialized
INFO - 2020-04-06 15:59:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:59:05 --> Email Class Initialized
INFO - 2020-04-06 15:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:59:05 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:59:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:59:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:59:05 --> Encryption Class Initialized
INFO - 2020-04-06 15:59:05 --> Controller Class Initialized
DEBUG - 2020-04-06 15:59:05 --> twitter MX_Controller Initialized
INFO - 2020-04-06 15:59:05 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-06 15:59:05 --> Model Class Initialized
INFO - 2020-04-06 15:59:09 --> Config Class Initialized
INFO - 2020-04-06 15:59:09 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:09 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:09 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:09 --> URI Class Initialized
INFO - 2020-04-06 15:59:09 --> Router Class Initialized
INFO - 2020-04-06 15:59:09 --> Output Class Initialized
INFO - 2020-04-06 15:59:09 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:09 --> CSRF cookie sent
INFO - 2020-04-06 15:59:09 --> Input Class Initialized
INFO - 2020-04-06 15:59:09 --> Language Class Initialized
INFO - 2020-04-06 15:59:09 --> Language Class Initialized
INFO - 2020-04-06 15:59:09 --> Config Class Initialized
INFO - 2020-04-06 15:59:09 --> Loader Class Initialized
INFO - 2020-04-06 15:59:09 --> Helper loaded: url_helper
INFO - 2020-04-06 15:59:09 --> Helper loaded: file_helper
INFO - 2020-04-06 15:59:09 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:59:09 --> Helper loaded: common_helper
INFO - 2020-04-06 15:59:09 --> Helper loaded: language_helper
INFO - 2020-04-06 15:59:09 --> Helper loaded: email_helper
INFO - 2020-04-06 15:59:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:59:09 --> Database Driver Class Initialized
INFO - 2020-04-06 15:59:09 --> Parser Class Initialized
INFO - 2020-04-06 15:59:09 --> User Agent Class Initialized
INFO - 2020-04-06 15:59:09 --> Model Class Initialized
INFO - 2020-04-06 15:59:09 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:09 --> Template Class Initialized
INFO - 2020-04-06 15:59:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:59:09 --> Email Class Initialized
INFO - 2020-04-06 15:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:59:09 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:59:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:59:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:59:09 --> Encryption Class Initialized
INFO - 2020-04-06 15:59:09 --> Controller Class Initialized
DEBUG - 2020-04-06 15:59:09 --> twitter MX_Controller Initialized
INFO - 2020-04-06 15:59:09 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-06 15:59:09 --> Model Class Initialized
INFO - 2020-04-06 15:59:11 --> Config Class Initialized
INFO - 2020-04-06 15:59:11 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:11 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:11 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:11 --> URI Class Initialized
INFO - 2020-04-06 15:59:11 --> Router Class Initialized
INFO - 2020-04-06 15:59:11 --> Output Class Initialized
INFO - 2020-04-06 15:59:11 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:11 --> CSRF cookie sent
INFO - 2020-04-06 15:59:11 --> Input Class Initialized
INFO - 2020-04-06 15:59:11 --> Language Class Initialized
INFO - 2020-04-06 15:59:11 --> Language Class Initialized
INFO - 2020-04-06 15:59:11 --> Config Class Initialized
INFO - 2020-04-06 15:59:11 --> Loader Class Initialized
INFO - 2020-04-06 15:59:11 --> Helper loaded: url_helper
INFO - 2020-04-06 15:59:11 --> Helper loaded: file_helper
INFO - 2020-04-06 15:59:11 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:59:11 --> Helper loaded: common_helper
INFO - 2020-04-06 15:59:11 --> Helper loaded: language_helper
INFO - 2020-04-06 15:59:11 --> Helper loaded: email_helper
INFO - 2020-04-06 15:59:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:59:11 --> Database Driver Class Initialized
INFO - 2020-04-06 15:59:11 --> Parser Class Initialized
INFO - 2020-04-06 15:59:11 --> User Agent Class Initialized
INFO - 2020-04-06 15:59:11 --> Model Class Initialized
INFO - 2020-04-06 15:59:11 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:11 --> Template Class Initialized
INFO - 2020-04-06 15:59:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:59:11 --> Email Class Initialized
INFO - 2020-04-06 15:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:59:11 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:59:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:59:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:59:11 --> Encryption Class Initialized
INFO - 2020-04-06 15:59:11 --> Controller Class Initialized
DEBUG - 2020-04-06 15:59:11 --> twitter MX_Controller Initialized
INFO - 2020-04-06 15:59:11 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-06 15:59:11 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-06 15:59:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:59:11 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:59:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:59:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:59:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:59:11 --> Final output sent to browser
DEBUG - 2020-04-06 15:59:11 --> Total execution time: 0.5773
INFO - 2020-04-06 15:59:12 --> Config Class Initialized
INFO - 2020-04-06 15:59:12 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:12 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:12 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:12 --> URI Class Initialized
INFO - 2020-04-06 15:59:12 --> Router Class Initialized
INFO - 2020-04-06 15:59:12 --> Output Class Initialized
INFO - 2020-04-06 15:59:12 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:12 --> CSRF cookie sent
INFO - 2020-04-06 15:59:12 --> Input Class Initialized
INFO - 2020-04-06 15:59:12 --> Language Class Initialized
ERROR - 2020-04-06 15:59:12 --> 404 Page Not Found: /index
INFO - 2020-04-06 15:59:12 --> Config Class Initialized
INFO - 2020-04-06 15:59:12 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:12 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:12 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:12 --> URI Class Initialized
INFO - 2020-04-06 15:59:12 --> Router Class Initialized
INFO - 2020-04-06 15:59:12 --> Output Class Initialized
INFO - 2020-04-06 15:59:12 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:12 --> CSRF cookie sent
INFO - 2020-04-06 15:59:12 --> Input Class Initialized
INFO - 2020-04-06 15:59:12 --> Language Class Initialized
ERROR - 2020-04-06 15:59:12 --> 404 Page Not Found: /index
INFO - 2020-04-06 15:59:36 --> Config Class Initialized
INFO - 2020-04-06 15:59:36 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:36 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:36 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:36 --> URI Class Initialized
INFO - 2020-04-06 15:59:36 --> Router Class Initialized
INFO - 2020-04-06 15:59:36 --> Output Class Initialized
INFO - 2020-04-06 15:59:36 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:36 --> CSRF cookie sent
INFO - 2020-04-06 15:59:36 --> Input Class Initialized
INFO - 2020-04-06 15:59:36 --> Language Class Initialized
INFO - 2020-04-06 15:59:36 --> Language Class Initialized
INFO - 2020-04-06 15:59:36 --> Config Class Initialized
INFO - 2020-04-06 15:59:36 --> Loader Class Initialized
INFO - 2020-04-06 15:59:36 --> Helper loaded: url_helper
INFO - 2020-04-06 15:59:36 --> Helper loaded: file_helper
INFO - 2020-04-06 15:59:36 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:59:36 --> Helper loaded: common_helper
INFO - 2020-04-06 15:59:36 --> Helper loaded: language_helper
INFO - 2020-04-06 15:59:36 --> Helper loaded: email_helper
INFO - 2020-04-06 15:59:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:59:36 --> Database Driver Class Initialized
INFO - 2020-04-06 15:59:36 --> Parser Class Initialized
INFO - 2020-04-06 15:59:36 --> User Agent Class Initialized
INFO - 2020-04-06 15:59:36 --> Model Class Initialized
INFO - 2020-04-06 15:59:36 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:36 --> Template Class Initialized
INFO - 2020-04-06 15:59:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:59:36 --> Email Class Initialized
INFO - 2020-04-06 15:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:59:36 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:59:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:59:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:59:36 --> Encryption Class Initialized
INFO - 2020-04-06 15:59:36 --> Controller Class Initialized
DEBUG - 2020-04-06 15:59:36 --> post MX_Controller Initialized
INFO - 2020-04-06 15:59:36 --> Model Class Initialized
ERROR - 2020-04-06 15:59:36 --> Could not find the language line ""
ERROR - 2020-04-06 15:59:36 --> Could not find the language line ""
ERROR - 2020-04-06 15:59:36 --> Could not find the language line ""
DEBUG - 2020-04-06 15:59:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 15:59:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 15:59:36 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 15:59:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 15:59:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 15:59:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 15:59:36 --> Final output sent to browser
DEBUG - 2020-04-06 15:59:36 --> Total execution time: 0.6562
INFO - 2020-04-06 15:59:37 --> Config Class Initialized
INFO - 2020-04-06 15:59:37 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:37 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:37 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:37 --> URI Class Initialized
INFO - 2020-04-06 15:59:37 --> Router Class Initialized
INFO - 2020-04-06 15:59:37 --> Output Class Initialized
INFO - 2020-04-06 15:59:37 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:37 --> CSRF cookie sent
INFO - 2020-04-06 15:59:37 --> Input Class Initialized
INFO - 2020-04-06 15:59:37 --> Language Class Initialized
INFO - 2020-04-06 15:59:37 --> Config Class Initialized
INFO - 2020-04-06 15:59:37 --> Hooks Class Initialized
ERROR - 2020-04-06 15:59:37 --> 404 Page Not Found: /index
DEBUG - 2020-04-06 15:59:37 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:37 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:37 --> URI Class Initialized
INFO - 2020-04-06 15:59:37 --> Router Class Initialized
INFO - 2020-04-06 15:59:37 --> Output Class Initialized
INFO - 2020-04-06 15:59:37 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:37 --> CSRF cookie sent
INFO - 2020-04-06 15:59:37 --> Input Class Initialized
INFO - 2020-04-06 15:59:37 --> Language Class Initialized
ERROR - 2020-04-06 15:59:37 --> 404 Page Not Found: /index
INFO - 2020-04-06 15:59:55 --> Config Class Initialized
INFO - 2020-04-06 15:59:55 --> Hooks Class Initialized
DEBUG - 2020-04-06 15:59:55 --> UTF-8 Support Enabled
INFO - 2020-04-06 15:59:55 --> Utf8 Class Initialized
INFO - 2020-04-06 15:59:55 --> URI Class Initialized
INFO - 2020-04-06 15:59:55 --> Router Class Initialized
INFO - 2020-04-06 15:59:55 --> Output Class Initialized
INFO - 2020-04-06 15:59:55 --> Security Class Initialized
DEBUG - 2020-04-06 15:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 15:59:55 --> CSRF cookie sent
INFO - 2020-04-06 15:59:55 --> CSRF token verified
INFO - 2020-04-06 15:59:55 --> Input Class Initialized
INFO - 2020-04-06 15:59:55 --> Language Class Initialized
INFO - 2020-04-06 15:59:55 --> Language Class Initialized
INFO - 2020-04-06 15:59:55 --> Config Class Initialized
INFO - 2020-04-06 15:59:55 --> Loader Class Initialized
INFO - 2020-04-06 15:59:55 --> Helper loaded: url_helper
INFO - 2020-04-06 15:59:55 --> Helper loaded: file_helper
INFO - 2020-04-06 15:59:55 --> Helper loaded: cookie_helper
INFO - 2020-04-06 15:59:55 --> Helper loaded: common_helper
INFO - 2020-04-06 15:59:55 --> Helper loaded: language_helper
INFO - 2020-04-06 15:59:55 --> Helper loaded: email_helper
INFO - 2020-04-06 15:59:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 15:59:55 --> Database Driver Class Initialized
INFO - 2020-04-06 15:59:55 --> Parser Class Initialized
INFO - 2020-04-06 15:59:55 --> User Agent Class Initialized
INFO - 2020-04-06 15:59:55 --> Model Class Initialized
INFO - 2020-04-06 15:59:55 --> Model Class Initialized
DEBUG - 2020-04-06 15:59:55 --> Template Class Initialized
INFO - 2020-04-06 15:59:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 15:59:55 --> Email Class Initialized
INFO - 2020-04-06 15:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 15:59:55 --> Pagination Class Initialized
DEBUG - 2020-04-06 15:59:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 15:59:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 15:59:55 --> Encryption Class Initialized
INFO - 2020-04-06 15:59:55 --> Controller Class Initialized
DEBUG - 2020-04-06 15:59:55 --> post MX_Controller Initialized
INFO - 2020-04-06 15:59:55 --> Model Class Initialized
INFO - 2020-04-06 16:00:07 --> Config Class Initialized
INFO - 2020-04-06 16:00:07 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:00:07 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:07 --> Utf8 Class Initialized
INFO - 2020-04-06 16:00:07 --> URI Class Initialized
INFO - 2020-04-06 16:00:07 --> Router Class Initialized
INFO - 2020-04-06 16:00:07 --> Output Class Initialized
INFO - 2020-04-06 16:00:07 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:07 --> CSRF cookie sent
INFO - 2020-04-06 16:00:07 --> CSRF token verified
INFO - 2020-04-06 16:00:07 --> Input Class Initialized
INFO - 2020-04-06 16:00:07 --> Language Class Initialized
INFO - 2020-04-06 16:00:07 --> Language Class Initialized
INFO - 2020-04-06 16:00:07 --> Config Class Initialized
INFO - 2020-04-06 16:00:07 --> Loader Class Initialized
INFO - 2020-04-06 16:00:07 --> Helper loaded: url_helper
INFO - 2020-04-06 16:00:07 --> Helper loaded: file_helper
INFO - 2020-04-06 16:00:07 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:00:07 --> Helper loaded: common_helper
INFO - 2020-04-06 16:00:07 --> Helper loaded: language_helper
INFO - 2020-04-06 16:00:07 --> Helper loaded: email_helper
INFO - 2020-04-06 16:00:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:00:07 --> Database Driver Class Initialized
INFO - 2020-04-06 16:00:07 --> Parser Class Initialized
INFO - 2020-04-06 16:00:07 --> User Agent Class Initialized
INFO - 2020-04-06 16:00:07 --> Model Class Initialized
INFO - 2020-04-06 16:00:07 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:07 --> Template Class Initialized
INFO - 2020-04-06 16:00:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:00:07 --> Email Class Initialized
INFO - 2020-04-06 16:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:00:07 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:00:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:00:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:00:07 --> Encryption Class Initialized
INFO - 2020-04-06 16:00:07 --> Controller Class Initialized
DEBUG - 2020-04-06 16:00:07 --> post MX_Controller Initialized
INFO - 2020-04-06 16:00:07 --> Model Class Initialized
INFO - 2020-04-06 16:00:18 --> Config Class Initialized
INFO - 2020-04-06 16:00:18 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:00:18 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:18 --> Utf8 Class Initialized
INFO - 2020-04-06 16:00:18 --> URI Class Initialized
INFO - 2020-04-06 16:00:18 --> Router Class Initialized
INFO - 2020-04-06 16:00:18 --> Output Class Initialized
INFO - 2020-04-06 16:00:18 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:18 --> CSRF cookie sent
INFO - 2020-04-06 16:00:18 --> Input Class Initialized
INFO - 2020-04-06 16:00:18 --> Language Class Initialized
INFO - 2020-04-06 16:00:18 --> Language Class Initialized
INFO - 2020-04-06 16:00:18 --> Config Class Initialized
INFO - 2020-04-06 16:00:18 --> Loader Class Initialized
INFO - 2020-04-06 16:00:18 --> Helper loaded: url_helper
INFO - 2020-04-06 16:00:18 --> Helper loaded: file_helper
INFO - 2020-04-06 16:00:18 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:00:18 --> Helper loaded: common_helper
INFO - 2020-04-06 16:00:18 --> Helper loaded: language_helper
INFO - 2020-04-06 16:00:18 --> Helper loaded: email_helper
INFO - 2020-04-06 16:00:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:00:19 --> Database Driver Class Initialized
INFO - 2020-04-06 16:00:19 --> Parser Class Initialized
INFO - 2020-04-06 16:00:19 --> User Agent Class Initialized
INFO - 2020-04-06 16:00:19 --> Model Class Initialized
INFO - 2020-04-06 16:00:19 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:19 --> Template Class Initialized
INFO - 2020-04-06 16:00:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:00:19 --> Email Class Initialized
INFO - 2020-04-06 16:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:00:19 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:00:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:00:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:00:19 --> Encryption Class Initialized
INFO - 2020-04-06 16:00:19 --> Controller Class Initialized
DEBUG - 2020-04-06 16:00:19 --> post MX_Controller Initialized
INFO - 2020-04-06 16:00:19 --> Model Class Initialized
ERROR - 2020-04-06 16:00:19 --> Could not find the language line ""
ERROR - 2020-04-06 16:00:19 --> Could not find the language line ""
ERROR - 2020-04-06 16:00:19 --> Could not find the language line ""
DEBUG - 2020-04-06 16:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 16:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:00:19 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:00:19 --> Final output sent to browser
DEBUG - 2020-04-06 16:00:19 --> Total execution time: 0.6452
INFO - 2020-04-06 16:00:19 --> Config Class Initialized
INFO - 2020-04-06 16:00:19 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:00:19 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:19 --> Utf8 Class Initialized
INFO - 2020-04-06 16:00:19 --> URI Class Initialized
INFO - 2020-04-06 16:00:19 --> Router Class Initialized
INFO - 2020-04-06 16:00:19 --> Output Class Initialized
INFO - 2020-04-06 16:00:19 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:19 --> CSRF cookie sent
INFO - 2020-04-06 16:00:19 --> Config Class Initialized
INFO - 2020-04-06 16:00:19 --> Hooks Class Initialized
INFO - 2020-04-06 16:00:19 --> Input Class Initialized
INFO - 2020-04-06 16:00:19 --> Language Class Initialized
DEBUG - 2020-04-06 16:00:19 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:19 --> Utf8 Class Initialized
ERROR - 2020-04-06 16:00:19 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:00:19 --> URI Class Initialized
INFO - 2020-04-06 16:00:19 --> Router Class Initialized
INFO - 2020-04-06 16:00:19 --> Output Class Initialized
INFO - 2020-04-06 16:00:19 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:19 --> CSRF cookie sent
INFO - 2020-04-06 16:00:19 --> Input Class Initialized
INFO - 2020-04-06 16:00:19 --> Language Class Initialized
ERROR - 2020-04-06 16:00:19 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:00:39 --> Config Class Initialized
INFO - 2020-04-06 16:00:40 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:00:40 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:40 --> Utf8 Class Initialized
INFO - 2020-04-06 16:00:40 --> URI Class Initialized
INFO - 2020-04-06 16:00:40 --> Router Class Initialized
INFO - 2020-04-06 16:00:40 --> Output Class Initialized
INFO - 2020-04-06 16:00:40 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:40 --> CSRF cookie sent
INFO - 2020-04-06 16:00:40 --> Input Class Initialized
INFO - 2020-04-06 16:00:40 --> Language Class Initialized
INFO - 2020-04-06 16:00:40 --> Language Class Initialized
INFO - 2020-04-06 16:00:40 --> Config Class Initialized
INFO - 2020-04-06 16:00:40 --> Loader Class Initialized
INFO - 2020-04-06 16:00:40 --> Helper loaded: url_helper
INFO - 2020-04-06 16:00:40 --> Helper loaded: file_helper
INFO - 2020-04-06 16:00:40 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:00:40 --> Helper loaded: common_helper
INFO - 2020-04-06 16:00:40 --> Helper loaded: language_helper
INFO - 2020-04-06 16:00:40 --> Helper loaded: email_helper
INFO - 2020-04-06 16:00:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:00:40 --> Database Driver Class Initialized
INFO - 2020-04-06 16:00:40 --> Parser Class Initialized
INFO - 2020-04-06 16:00:40 --> User Agent Class Initialized
INFO - 2020-04-06 16:00:40 --> Model Class Initialized
INFO - 2020-04-06 16:00:40 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:40 --> Template Class Initialized
INFO - 2020-04-06 16:00:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:00:40 --> Email Class Initialized
INFO - 2020-04-06 16:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:00:40 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:00:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:00:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:00:40 --> Encryption Class Initialized
INFO - 2020-04-06 16:00:40 --> Controller Class Initialized
DEBUG - 2020-04-06 16:00:40 --> schedule MX_Controller Initialized
INFO - 2020-04-06 16:00:40 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/models/schedule_model.php
INFO - 2020-04-06 16:00:40 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/views/index.php
DEBUG - 2020-04-06 16:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:00:40 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:00:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:00:40 --> Final output sent to browser
DEBUG - 2020-04-06 16:00:40 --> Total execution time: 0.5814
INFO - 2020-04-06 16:00:42 --> Config Class Initialized
INFO - 2020-04-06 16:00:42 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:00:42 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:42 --> Utf8 Class Initialized
INFO - 2020-04-06 16:00:42 --> URI Class Initialized
INFO - 2020-04-06 16:00:42 --> Router Class Initialized
INFO - 2020-04-06 16:00:42 --> Output Class Initialized
INFO - 2020-04-06 16:00:42 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:42 --> CSRF cookie sent
INFO - 2020-04-06 16:00:43 --> Input Class Initialized
INFO - 2020-04-06 16:00:43 --> Language Class Initialized
INFO - 2020-04-06 16:00:43 --> Language Class Initialized
INFO - 2020-04-06 16:00:43 --> Config Class Initialized
INFO - 2020-04-06 16:00:43 --> Loader Class Initialized
INFO - 2020-04-06 16:00:43 --> Helper loaded: url_helper
INFO - 2020-04-06 16:00:43 --> Helper loaded: file_helper
INFO - 2020-04-06 16:00:43 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:00:43 --> Helper loaded: common_helper
INFO - 2020-04-06 16:00:43 --> Helper loaded: language_helper
INFO - 2020-04-06 16:00:43 --> Helper loaded: email_helper
INFO - 2020-04-06 16:00:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:00:43 --> Database Driver Class Initialized
INFO - 2020-04-06 16:00:43 --> Parser Class Initialized
INFO - 2020-04-06 16:00:43 --> User Agent Class Initialized
INFO - 2020-04-06 16:00:43 --> Model Class Initialized
INFO - 2020-04-06 16:00:43 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:43 --> Template Class Initialized
INFO - 2020-04-06 16:00:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:00:43 --> Email Class Initialized
INFO - 2020-04-06 16:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:00:43 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:00:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:00:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:00:43 --> Encryption Class Initialized
INFO - 2020-04-06 16:00:43 --> Controller Class Initialized
DEBUG - 2020-04-06 16:00:43 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:00:43 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:00:43 --> Model Class Initialized
INFO - 2020-04-06 16:00:43 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 16:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:00:43 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:00:43 --> Final output sent to browser
DEBUG - 2020-04-06 16:00:43 --> Total execution time: 0.5831
INFO - 2020-04-06 16:00:44 --> Config Class Initialized
INFO - 2020-04-06 16:00:44 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:00:44 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:44 --> Utf8 Class Initialized
INFO - 2020-04-06 16:00:44 --> URI Class Initialized
INFO - 2020-04-06 16:00:44 --> Router Class Initialized
INFO - 2020-04-06 16:00:44 --> Output Class Initialized
INFO - 2020-04-06 16:00:44 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:44 --> CSRF cookie sent
INFO - 2020-04-06 16:00:44 --> Input Class Initialized
INFO - 2020-04-06 16:00:44 --> Language Class Initialized
INFO - 2020-04-06 16:00:44 --> Language Class Initialized
INFO - 2020-04-06 16:00:44 --> Config Class Initialized
INFO - 2020-04-06 16:00:44 --> Loader Class Initialized
INFO - 2020-04-06 16:00:44 --> Helper loaded: url_helper
INFO - 2020-04-06 16:00:44 --> Helper loaded: file_helper
INFO - 2020-04-06 16:00:44 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:00:44 --> Helper loaded: common_helper
INFO - 2020-04-06 16:00:44 --> Helper loaded: language_helper
INFO - 2020-04-06 16:00:44 --> Helper loaded: email_helper
INFO - 2020-04-06 16:00:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:00:44 --> Database Driver Class Initialized
INFO - 2020-04-06 16:00:44 --> Parser Class Initialized
INFO - 2020-04-06 16:00:44 --> User Agent Class Initialized
INFO - 2020-04-06 16:00:44 --> Model Class Initialized
INFO - 2020-04-06 16:00:44 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:44 --> Template Class Initialized
INFO - 2020-04-06 16:00:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:00:45 --> Email Class Initialized
INFO - 2020-04-06 16:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:00:45 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:00:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:00:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:00:45 --> Encryption Class Initialized
INFO - 2020-04-06 16:00:45 --> Controller Class Initialized
DEBUG - 2020-04-06 16:00:45 --> unfollow MX_Controller Initialized
INFO - 2020-04-06 16:00:45 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/unfollow/models/unfollow_model.php
INFO - 2020-04-06 16:00:45 --> Model Class Initialized
INFO - 2020-04-06 16:00:45 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/unfollow/views/index.php
DEBUG - 2020-04-06 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:00:45 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:00:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:00:45 --> Final output sent to browser
DEBUG - 2020-04-06 16:00:45 --> Total execution time: 0.5878
INFO - 2020-04-06 16:00:46 --> Config Class Initialized
INFO - 2020-04-06 16:00:46 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:00:46 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:46 --> Utf8 Class Initialized
INFO - 2020-04-06 16:00:46 --> URI Class Initialized
INFO - 2020-04-06 16:00:46 --> Router Class Initialized
INFO - 2020-04-06 16:00:46 --> Output Class Initialized
INFO - 2020-04-06 16:00:46 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:46 --> CSRF cookie sent
INFO - 2020-04-06 16:00:46 --> Input Class Initialized
INFO - 2020-04-06 16:00:46 --> Language Class Initialized
INFO - 2020-04-06 16:00:46 --> Language Class Initialized
INFO - 2020-04-06 16:00:46 --> Config Class Initialized
INFO - 2020-04-06 16:00:46 --> Loader Class Initialized
INFO - 2020-04-06 16:00:46 --> Helper loaded: url_helper
INFO - 2020-04-06 16:00:46 --> Helper loaded: file_helper
INFO - 2020-04-06 16:00:46 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:00:46 --> Helper loaded: common_helper
INFO - 2020-04-06 16:00:46 --> Helper loaded: language_helper
INFO - 2020-04-06 16:00:46 --> Helper loaded: email_helper
INFO - 2020-04-06 16:00:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:00:46 --> Database Driver Class Initialized
INFO - 2020-04-06 16:00:46 --> Parser Class Initialized
INFO - 2020-04-06 16:00:46 --> User Agent Class Initialized
INFO - 2020-04-06 16:00:46 --> Model Class Initialized
INFO - 2020-04-06 16:00:46 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:46 --> Template Class Initialized
INFO - 2020-04-06 16:00:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:00:47 --> Email Class Initialized
INFO - 2020-04-06 16:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:00:47 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:00:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:00:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:00:47 --> Encryption Class Initialized
INFO - 2020-04-06 16:00:47 --> Controller Class Initialized
DEBUG - 2020-04-06 16:00:47 --> post MX_Controller Initialized
INFO - 2020-04-06 16:00:47 --> Model Class Initialized
ERROR - 2020-04-06 16:00:47 --> Could not find the language line ""
ERROR - 2020-04-06 16:00:47 --> Could not find the language line ""
ERROR - 2020-04-06 16:00:47 --> Could not find the language line ""
DEBUG - 2020-04-06 16:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 16:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:00:47 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:00:47 --> Final output sent to browser
DEBUG - 2020-04-06 16:00:47 --> Total execution time: 0.5737
INFO - 2020-04-06 16:00:48 --> Config Class Initialized
INFO - 2020-04-06 16:00:48 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:00:48 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:48 --> Utf8 Class Initialized
INFO - 2020-04-06 16:00:48 --> URI Class Initialized
INFO - 2020-04-06 16:00:48 --> Router Class Initialized
INFO - 2020-04-06 16:00:48 --> Output Class Initialized
INFO - 2020-04-06 16:00:48 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:48 --> CSRF cookie sent
INFO - 2020-04-06 16:00:48 --> Input Class Initialized
INFO - 2020-04-06 16:00:49 --> Language Class Initialized
INFO - 2020-04-06 16:00:49 --> Language Class Initialized
INFO - 2020-04-06 16:00:49 --> Config Class Initialized
INFO - 2020-04-06 16:00:49 --> Loader Class Initialized
INFO - 2020-04-06 16:00:49 --> Helper loaded: url_helper
INFO - 2020-04-06 16:00:49 --> Helper loaded: file_helper
INFO - 2020-04-06 16:00:49 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:00:49 --> Helper loaded: common_helper
INFO - 2020-04-06 16:00:49 --> Helper loaded: language_helper
INFO - 2020-04-06 16:00:49 --> Helper loaded: email_helper
INFO - 2020-04-06 16:00:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:00:49 --> Database Driver Class Initialized
INFO - 2020-04-06 16:00:49 --> Parser Class Initialized
INFO - 2020-04-06 16:00:49 --> User Agent Class Initialized
INFO - 2020-04-06 16:00:49 --> Model Class Initialized
INFO - 2020-04-06 16:00:49 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:49 --> Template Class Initialized
INFO - 2020-04-06 16:00:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:00:49 --> Email Class Initialized
INFO - 2020-04-06 16:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:00:49 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:00:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:00:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:00:49 --> Encryption Class Initialized
INFO - 2020-04-06 16:00:49 --> Controller Class Initialized
DEBUG - 2020-04-06 16:00:49 --> schedule MX_Controller Initialized
INFO - 2020-04-06 16:00:49 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/models/schedule_model.php
INFO - 2020-04-06 16:00:49 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/views/index.php
DEBUG - 2020-04-06 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:00:49 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:00:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:00:49 --> Final output sent to browser
DEBUG - 2020-04-06 16:00:49 --> Total execution time: 0.5752
INFO - 2020-04-06 16:00:58 --> Config Class Initialized
INFO - 2020-04-06 16:00:58 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:00:58 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:00:58 --> Utf8 Class Initialized
INFO - 2020-04-06 16:00:58 --> URI Class Initialized
INFO - 2020-04-06 16:00:58 --> Router Class Initialized
INFO - 2020-04-06 16:00:58 --> Output Class Initialized
INFO - 2020-04-06 16:00:58 --> Security Class Initialized
DEBUG - 2020-04-06 16:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:00:58 --> CSRF cookie sent
INFO - 2020-04-06 16:00:58 --> Input Class Initialized
INFO - 2020-04-06 16:00:58 --> Language Class Initialized
INFO - 2020-04-06 16:00:58 --> Language Class Initialized
INFO - 2020-04-06 16:00:58 --> Config Class Initialized
INFO - 2020-04-06 16:00:58 --> Loader Class Initialized
INFO - 2020-04-06 16:00:58 --> Helper loaded: url_helper
INFO - 2020-04-06 16:00:58 --> Helper loaded: file_helper
INFO - 2020-04-06 16:00:58 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:00:58 --> Helper loaded: common_helper
INFO - 2020-04-06 16:00:58 --> Helper loaded: language_helper
INFO - 2020-04-06 16:00:58 --> Helper loaded: email_helper
INFO - 2020-04-06 16:00:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:00:58 --> Database Driver Class Initialized
INFO - 2020-04-06 16:00:58 --> Parser Class Initialized
INFO - 2020-04-06 16:00:58 --> User Agent Class Initialized
INFO - 2020-04-06 16:00:58 --> Model Class Initialized
INFO - 2020-04-06 16:00:58 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:58 --> Template Class Initialized
INFO - 2020-04-06 16:00:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:00:58 --> Email Class Initialized
INFO - 2020-04-06 16:00:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:00:58 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:00:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:00:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:00:58 --> Encryption Class Initialized
INFO - 2020-04-06 16:00:58 --> Controller Class Initialized
DEBUG - 2020-04-06 16:00:58 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:00:58 --> Model Class Initialized
DEBUG - 2020-04-06 16:00:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:00:58 --> Model Class Initialized
INFO - 2020-04-06 16:00:58 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:00:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 16:00:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:00:58 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:00:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:00:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:00:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:00:59 --> Final output sent to browser
DEBUG - 2020-04-06 16:00:59 --> Total execution time: 0.5821
INFO - 2020-04-06 16:01:00 --> Config Class Initialized
INFO - 2020-04-06 16:01:00 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:01:00 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:01:00 --> Utf8 Class Initialized
INFO - 2020-04-06 16:01:00 --> URI Class Initialized
INFO - 2020-04-06 16:01:00 --> Router Class Initialized
INFO - 2020-04-06 16:01:00 --> Output Class Initialized
INFO - 2020-04-06 16:01:00 --> Security Class Initialized
DEBUG - 2020-04-06 16:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:01:00 --> CSRF cookie sent
INFO - 2020-04-06 16:01:00 --> Input Class Initialized
INFO - 2020-04-06 16:01:00 --> Language Class Initialized
INFO - 2020-04-06 16:01:00 --> Language Class Initialized
INFO - 2020-04-06 16:01:00 --> Config Class Initialized
INFO - 2020-04-06 16:01:01 --> Loader Class Initialized
INFO - 2020-04-06 16:01:01 --> Helper loaded: url_helper
INFO - 2020-04-06 16:01:01 --> Helper loaded: file_helper
INFO - 2020-04-06 16:01:01 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:01:01 --> Helper loaded: common_helper
INFO - 2020-04-06 16:01:01 --> Helper loaded: language_helper
INFO - 2020-04-06 16:01:01 --> Helper loaded: email_helper
INFO - 2020-04-06 16:01:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:01:01 --> Database Driver Class Initialized
INFO - 2020-04-06 16:01:01 --> Parser Class Initialized
INFO - 2020-04-06 16:01:01 --> User Agent Class Initialized
INFO - 2020-04-06 16:01:01 --> Model Class Initialized
INFO - 2020-04-06 16:01:01 --> Model Class Initialized
DEBUG - 2020-04-06 16:01:01 --> Template Class Initialized
INFO - 2020-04-06 16:01:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:01:01 --> Email Class Initialized
INFO - 2020-04-06 16:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:01:01 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:01:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:01:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:01:01 --> Encryption Class Initialized
INFO - 2020-04-06 16:01:01 --> Controller Class Initialized
DEBUG - 2020-04-06 16:01:01 --> gallery MX_Controller Initialized
INFO - 2020-04-06 16:01:01 --> Model Class Initialized
INFO - 2020-04-06 16:01:01 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-06 16:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:01:01 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:01:01 --> Final output sent to browser
DEBUG - 2020-04-06 16:01:01 --> Total execution time: 0.6341
INFO - 2020-04-06 16:01:15 --> Config Class Initialized
INFO - 2020-04-06 16:01:15 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:01:15 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:01:15 --> Utf8 Class Initialized
INFO - 2020-04-06 16:01:15 --> URI Class Initialized
INFO - 2020-04-06 16:01:15 --> Router Class Initialized
INFO - 2020-04-06 16:01:15 --> Output Class Initialized
INFO - 2020-04-06 16:01:15 --> Security Class Initialized
DEBUG - 2020-04-06 16:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:01:15 --> CSRF cookie sent
INFO - 2020-04-06 16:01:15 --> Input Class Initialized
INFO - 2020-04-06 16:01:15 --> Language Class Initialized
INFO - 2020-04-06 16:01:15 --> Language Class Initialized
INFO - 2020-04-06 16:01:15 --> Config Class Initialized
INFO - 2020-04-06 16:01:15 --> Loader Class Initialized
INFO - 2020-04-06 16:01:15 --> Helper loaded: url_helper
INFO - 2020-04-06 16:01:15 --> Helper loaded: file_helper
INFO - 2020-04-06 16:01:15 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:01:15 --> Helper loaded: common_helper
INFO - 2020-04-06 16:01:15 --> Helper loaded: language_helper
INFO - 2020-04-06 16:01:15 --> Helper loaded: email_helper
INFO - 2020-04-06 16:01:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:01:15 --> Database Driver Class Initialized
INFO - 2020-04-06 16:01:15 --> Parser Class Initialized
INFO - 2020-04-06 16:01:15 --> User Agent Class Initialized
INFO - 2020-04-06 16:01:15 --> Model Class Initialized
INFO - 2020-04-06 16:01:15 --> Model Class Initialized
DEBUG - 2020-04-06 16:01:15 --> Template Class Initialized
INFO - 2020-04-06 16:01:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:01:15 --> Email Class Initialized
INFO - 2020-04-06 16:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:01:15 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:01:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:01:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:01:16 --> Encryption Class Initialized
INFO - 2020-04-06 16:01:16 --> Controller Class Initialized
DEBUG - 2020-04-06 16:01:16 --> twitter MX_Controller Initialized
INFO - 2020-04-06 16:01:16 --> Model Class Initialized
DEBUG - 2020-04-06 16:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-06 16:01:16 --> Model Class Initialized
DEBUG - 2020-04-06 16:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-06 16:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:01:16 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:01:16 --> Final output sent to browser
DEBUG - 2020-04-06 16:01:16 --> Total execution time: 0.6032
INFO - 2020-04-06 16:01:18 --> Config Class Initialized
INFO - 2020-04-06 16:01:18 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:01:18 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:01:18 --> Utf8 Class Initialized
INFO - 2020-04-06 16:01:18 --> URI Class Initialized
INFO - 2020-04-06 16:01:18 --> Router Class Initialized
INFO - 2020-04-06 16:01:18 --> Output Class Initialized
INFO - 2020-04-06 16:01:18 --> Security Class Initialized
DEBUG - 2020-04-06 16:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:01:18 --> CSRF cookie sent
INFO - 2020-04-06 16:01:18 --> Input Class Initialized
INFO - 2020-04-06 16:01:18 --> Language Class Initialized
INFO - 2020-04-06 16:01:18 --> Language Class Initialized
INFO - 2020-04-06 16:01:18 --> Config Class Initialized
INFO - 2020-04-06 16:01:18 --> Loader Class Initialized
INFO - 2020-04-06 16:01:18 --> Helper loaded: url_helper
INFO - 2020-04-06 16:01:18 --> Helper loaded: file_helper
INFO - 2020-04-06 16:01:18 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:01:18 --> Helper loaded: common_helper
INFO - 2020-04-06 16:01:18 --> Helper loaded: language_helper
INFO - 2020-04-06 16:01:18 --> Helper loaded: email_helper
INFO - 2020-04-06 16:01:18 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:01:18 --> Database Driver Class Initialized
INFO - 2020-04-06 16:01:18 --> Parser Class Initialized
INFO - 2020-04-06 16:01:18 --> User Agent Class Initialized
INFO - 2020-04-06 16:01:18 --> Model Class Initialized
INFO - 2020-04-06 16:01:18 --> Model Class Initialized
DEBUG - 2020-04-06 16:01:18 --> Template Class Initialized
INFO - 2020-04-06 16:01:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:01:18 --> Email Class Initialized
INFO - 2020-04-06 16:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:01:19 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:01:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:01:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:01:19 --> Encryption Class Initialized
INFO - 2020-04-06 16:01:19 --> Controller Class Initialized
DEBUG - 2020-04-06 16:01:19 --> package MX_Controller Initialized
INFO - 2020-04-06 16:01:19 --> Model Class Initialized
DEBUG - 2020-04-06 16:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/package/models/package_model.php
INFO - 2020-04-06 16:01:19 --> Model Class Initialized
DEBUG - 2020-04-06 16:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/package/views/index.php
DEBUG - 2020-04-06 16:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:01:19 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:01:19 --> Final output sent to browser
DEBUG - 2020-04-06 16:01:19 --> Total execution time: 0.5933
INFO - 2020-04-06 16:02:48 --> Config Class Initialized
INFO - 2020-04-06 16:02:48 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:02:48 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:02:48 --> Utf8 Class Initialized
INFO - 2020-04-06 16:02:48 --> URI Class Initialized
INFO - 2020-04-06 16:02:48 --> Router Class Initialized
INFO - 2020-04-06 16:02:48 --> Output Class Initialized
INFO - 2020-04-06 16:02:48 --> Security Class Initialized
DEBUG - 2020-04-06 16:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:02:48 --> CSRF cookie sent
INFO - 2020-04-06 16:02:48 --> Input Class Initialized
INFO - 2020-04-06 16:02:48 --> Language Class Initialized
INFO - 2020-04-06 16:02:48 --> Language Class Initialized
INFO - 2020-04-06 16:02:48 --> Config Class Initialized
INFO - 2020-04-06 16:02:48 --> Loader Class Initialized
INFO - 2020-04-06 16:02:48 --> Helper loaded: url_helper
INFO - 2020-04-06 16:02:48 --> Helper loaded: file_helper
INFO - 2020-04-06 16:02:48 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:02:48 --> Helper loaded: common_helper
INFO - 2020-04-06 16:02:48 --> Helper loaded: language_helper
INFO - 2020-04-06 16:02:48 --> Helper loaded: email_helper
INFO - 2020-04-06 16:02:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:02:48 --> Database Driver Class Initialized
INFO - 2020-04-06 16:02:48 --> Parser Class Initialized
INFO - 2020-04-06 16:02:48 --> User Agent Class Initialized
INFO - 2020-04-06 16:02:48 --> Model Class Initialized
INFO - 2020-04-06 16:02:48 --> Model Class Initialized
DEBUG - 2020-04-06 16:02:48 --> Template Class Initialized
INFO - 2020-04-06 16:02:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:02:48 --> Email Class Initialized
INFO - 2020-04-06 16:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:02:48 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:02:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:02:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:02:48 --> Encryption Class Initialized
INFO - 2020-04-06 16:02:48 --> Controller Class Initialized
DEBUG - 2020-04-06 16:02:48 --> package MX_Controller Initialized
INFO - 2020-04-06 16:02:48 --> Model Class Initialized
DEBUG - 2020-04-06 16:02:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/package/models/package_model.php
INFO - 2020-04-06 16:02:49 --> Model Class Initialized
DEBUG - 2020-04-06 16:02:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/package/views/index.php
DEBUG - 2020-04-06 16:02:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:02:49 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:02:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:02:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:02:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:02:49 --> Final output sent to browser
DEBUG - 2020-04-06 16:02:49 --> Total execution time: 0.6540
INFO - 2020-04-06 16:02:57 --> Config Class Initialized
INFO - 2020-04-06 16:02:57 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:02:57 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:02:57 --> Utf8 Class Initialized
INFO - 2020-04-06 16:02:57 --> URI Class Initialized
INFO - 2020-04-06 16:02:57 --> Router Class Initialized
INFO - 2020-04-06 16:02:57 --> Output Class Initialized
INFO - 2020-04-06 16:02:57 --> Security Class Initialized
DEBUG - 2020-04-06 16:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:02:57 --> CSRF cookie sent
INFO - 2020-04-06 16:02:57 --> Input Class Initialized
INFO - 2020-04-06 16:02:57 --> Language Class Initialized
INFO - 2020-04-06 16:02:57 --> Language Class Initialized
INFO - 2020-04-06 16:02:57 --> Config Class Initialized
INFO - 2020-04-06 16:02:57 --> Loader Class Initialized
INFO - 2020-04-06 16:02:57 --> Helper loaded: url_helper
INFO - 2020-04-06 16:02:57 --> Helper loaded: file_helper
INFO - 2020-04-06 16:02:57 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:02:57 --> Helper loaded: common_helper
INFO - 2020-04-06 16:02:57 --> Helper loaded: language_helper
INFO - 2020-04-06 16:02:57 --> Helper loaded: email_helper
INFO - 2020-04-06 16:02:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:02:57 --> Database Driver Class Initialized
INFO - 2020-04-06 16:02:57 --> Parser Class Initialized
INFO - 2020-04-06 16:02:57 --> User Agent Class Initialized
INFO - 2020-04-06 16:02:57 --> Model Class Initialized
INFO - 2020-04-06 16:02:57 --> Model Class Initialized
DEBUG - 2020-04-06 16:02:57 --> Template Class Initialized
INFO - 2020-04-06 16:02:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:02:57 --> Email Class Initialized
INFO - 2020-04-06 16:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:02:57 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:02:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:02:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:02:57 --> Encryption Class Initialized
INFO - 2020-04-06 16:02:58 --> Controller Class Initialized
DEBUG - 2020-04-06 16:02:58 --> transaction MX_Controller Initialized
INFO - 2020-04-06 16:02:58 --> Model Class Initialized
DEBUG - 2020-04-06 16:02:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/transaction/models/transaction_model.php
INFO - 2020-04-06 16:02:58 --> Model Class Initialized
INFO - 2020-04-06 16:02:58 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:02:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/transaction/views/index.php
DEBUG - 2020-04-06 16:02:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:02:58 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:02:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:02:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:02:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:02:58 --> Final output sent to browser
DEBUG - 2020-04-06 16:02:58 --> Total execution time: 0.7669
INFO - 2020-04-06 16:03:09 --> Config Class Initialized
INFO - 2020-04-06 16:03:09 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:03:09 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:03:09 --> Utf8 Class Initialized
INFO - 2020-04-06 16:03:09 --> URI Class Initialized
INFO - 2020-04-06 16:03:09 --> Router Class Initialized
INFO - 2020-04-06 16:03:09 --> Output Class Initialized
INFO - 2020-04-06 16:03:09 --> Security Class Initialized
DEBUG - 2020-04-06 16:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:03:09 --> CSRF cookie sent
INFO - 2020-04-06 16:03:09 --> Input Class Initialized
INFO - 2020-04-06 16:03:09 --> Language Class Initialized
INFO - 2020-04-06 16:03:09 --> Language Class Initialized
INFO - 2020-04-06 16:03:09 --> Config Class Initialized
INFO - 2020-04-06 16:03:09 --> Loader Class Initialized
INFO - 2020-04-06 16:03:09 --> Helper loaded: url_helper
INFO - 2020-04-06 16:03:09 --> Helper loaded: file_helper
INFO - 2020-04-06 16:03:09 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:03:09 --> Helper loaded: common_helper
INFO - 2020-04-06 16:03:09 --> Helper loaded: language_helper
INFO - 2020-04-06 16:03:09 --> Helper loaded: email_helper
INFO - 2020-04-06 16:03:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:03:09 --> Database Driver Class Initialized
INFO - 2020-04-06 16:03:09 --> Parser Class Initialized
INFO - 2020-04-06 16:03:10 --> User Agent Class Initialized
INFO - 2020-04-06 16:03:10 --> Model Class Initialized
INFO - 2020-04-06 16:03:10 --> Model Class Initialized
DEBUG - 2020-04-06 16:03:10 --> Template Class Initialized
INFO - 2020-04-06 16:03:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:03:10 --> Email Class Initialized
INFO - 2020-04-06 16:03:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:03:10 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:03:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:03:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:03:10 --> Encryption Class Initialized
INFO - 2020-04-06 16:03:10 --> Controller Class Initialized
DEBUG - 2020-04-06 16:03:10 --> transaction MX_Controller Initialized
INFO - 2020-04-06 16:03:10 --> Model Class Initialized
DEBUG - 2020-04-06 16:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/transaction/models/transaction_model.php
INFO - 2020-04-06 16:03:10 --> Model Class Initialized
INFO - 2020-04-06 16:03:10 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/transaction/views/index.php
DEBUG - 2020-04-06 16:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:03:10 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:03:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:03:10 --> Final output sent to browser
DEBUG - 2020-04-06 16:03:10 --> Total execution time: 0.7588
INFO - 2020-04-06 16:05:28 --> Config Class Initialized
INFO - 2020-04-06 16:05:28 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:05:28 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:05:28 --> Utf8 Class Initialized
INFO - 2020-04-06 16:05:28 --> URI Class Initialized
INFO - 2020-04-06 16:05:28 --> Router Class Initialized
INFO - 2020-04-06 16:05:28 --> Output Class Initialized
INFO - 2020-04-06 16:05:28 --> Security Class Initialized
DEBUG - 2020-04-06 16:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:05:28 --> CSRF cookie sent
INFO - 2020-04-06 16:05:28 --> Input Class Initialized
INFO - 2020-04-06 16:05:28 --> Language Class Initialized
INFO - 2020-04-06 16:05:28 --> Language Class Initialized
INFO - 2020-04-06 16:05:28 --> Config Class Initialized
INFO - 2020-04-06 16:05:28 --> Loader Class Initialized
INFO - 2020-04-06 16:05:28 --> Helper loaded: url_helper
INFO - 2020-04-06 16:05:28 --> Helper loaded: file_helper
INFO - 2020-04-06 16:05:28 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:05:28 --> Helper loaded: common_helper
INFO - 2020-04-06 16:05:28 --> Helper loaded: language_helper
INFO - 2020-04-06 16:05:28 --> Helper loaded: email_helper
INFO - 2020-04-06 16:05:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:05:28 --> Database Driver Class Initialized
INFO - 2020-04-06 16:05:28 --> Parser Class Initialized
INFO - 2020-04-06 16:05:28 --> User Agent Class Initialized
INFO - 2020-04-06 16:05:28 --> Model Class Initialized
INFO - 2020-04-06 16:05:28 --> Model Class Initialized
DEBUG - 2020-04-06 16:05:28 --> Template Class Initialized
INFO - 2020-04-06 16:05:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:05:28 --> Email Class Initialized
INFO - 2020-04-06 16:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:05:28 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:05:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:05:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:05:28 --> Encryption Class Initialized
INFO - 2020-04-06 16:05:28 --> Controller Class Initialized
DEBUG - 2020-04-06 16:05:28 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:05:28 --> Model Class Initialized
INFO - 2020-04-06 16:05:28 --> Config Class Initialized
INFO - 2020-04-06 16:05:28 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:05:28 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:05:28 --> Utf8 Class Initialized
INFO - 2020-04-06 16:05:28 --> URI Class Initialized
INFO - 2020-04-06 16:05:28 --> Router Class Initialized
INFO - 2020-04-06 16:05:28 --> Output Class Initialized
INFO - 2020-04-06 16:05:28 --> Security Class Initialized
DEBUG - 2020-04-06 16:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:05:29 --> CSRF cookie sent
INFO - 2020-04-06 16:05:29 --> Input Class Initialized
INFO - 2020-04-06 16:05:29 --> Language Class Initialized
INFO - 2020-04-06 16:05:29 --> Language Class Initialized
INFO - 2020-04-06 16:05:29 --> Config Class Initialized
INFO - 2020-04-06 16:05:29 --> Loader Class Initialized
INFO - 2020-04-06 16:05:29 --> Helper loaded: url_helper
INFO - 2020-04-06 16:05:29 --> Helper loaded: file_helper
INFO - 2020-04-06 16:05:29 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:05:29 --> Helper loaded: common_helper
INFO - 2020-04-06 16:05:29 --> Helper loaded: language_helper
INFO - 2020-04-06 16:05:29 --> Helper loaded: email_helper
INFO - 2020-04-06 16:05:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:05:29 --> Database Driver Class Initialized
INFO - 2020-04-06 16:05:29 --> Parser Class Initialized
INFO - 2020-04-06 16:05:29 --> User Agent Class Initialized
INFO - 2020-04-06 16:05:29 --> Model Class Initialized
INFO - 2020-04-06 16:05:29 --> Model Class Initialized
DEBUG - 2020-04-06 16:05:29 --> Template Class Initialized
INFO - 2020-04-06 16:05:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:05:29 --> Email Class Initialized
INFO - 2020-04-06 16:05:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:05:29 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:05:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:05:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:05:29 --> Encryption Class Initialized
INFO - 2020-04-06 16:05:29 --> Controller Class Initialized
DEBUG - 2020-04-06 16:05:29 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:05:29 --> Model Class Initialized
INFO - 2020-04-06 16:05:29 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:05:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:05:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:05:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:05:29 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:05:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:05:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:05:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:05:29 --> Final output sent to browser
DEBUG - 2020-04-06 16:05:29 --> Total execution time: 0.6609
INFO - 2020-04-06 16:05:36 --> Config Class Initialized
INFO - 2020-04-06 16:05:36 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:05:36 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:05:36 --> Utf8 Class Initialized
INFO - 2020-04-06 16:05:36 --> URI Class Initialized
INFO - 2020-04-06 16:05:36 --> Router Class Initialized
INFO - 2020-04-06 16:05:36 --> Output Class Initialized
INFO - 2020-04-06 16:05:36 --> Security Class Initialized
DEBUG - 2020-04-06 16:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:05:36 --> CSRF cookie sent
INFO - 2020-04-06 16:05:36 --> Input Class Initialized
INFO - 2020-04-06 16:05:36 --> Language Class Initialized
INFO - 2020-04-06 16:05:36 --> Language Class Initialized
INFO - 2020-04-06 16:05:36 --> Config Class Initialized
INFO - 2020-04-06 16:05:36 --> Loader Class Initialized
INFO - 2020-04-06 16:05:36 --> Helper loaded: url_helper
INFO - 2020-04-06 16:05:36 --> Helper loaded: file_helper
INFO - 2020-04-06 16:05:36 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:05:36 --> Helper loaded: common_helper
INFO - 2020-04-06 16:05:36 --> Helper loaded: language_helper
INFO - 2020-04-06 16:05:36 --> Helper loaded: email_helper
INFO - 2020-04-06 16:05:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:05:36 --> Database Driver Class Initialized
INFO - 2020-04-06 16:05:36 --> Parser Class Initialized
INFO - 2020-04-06 16:05:36 --> User Agent Class Initialized
INFO - 2020-04-06 16:05:36 --> Model Class Initialized
INFO - 2020-04-06 16:05:36 --> Model Class Initialized
DEBUG - 2020-04-06 16:05:36 --> Template Class Initialized
INFO - 2020-04-06 16:05:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:05:36 --> Email Class Initialized
INFO - 2020-04-06 16:05:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:05:36 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:05:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:05:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:05:37 --> Encryption Class Initialized
INFO - 2020-04-06 16:05:37 --> Controller Class Initialized
DEBUG - 2020-04-06 16:05:37 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:05:37 --> Model Class Initialized
INFO - 2020-04-06 16:05:37 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/default_settings.php
DEBUG - 2020-04-06 16:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:05:37 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:05:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:05:37 --> Final output sent to browser
DEBUG - 2020-04-06 16:05:37 --> Total execution time: 0.6987
INFO - 2020-04-06 16:05:51 --> Config Class Initialized
INFO - 2020-04-06 16:05:51 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:05:51 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:05:51 --> Utf8 Class Initialized
INFO - 2020-04-06 16:05:51 --> URI Class Initialized
INFO - 2020-04-06 16:05:51 --> Router Class Initialized
INFO - 2020-04-06 16:05:51 --> Output Class Initialized
INFO - 2020-04-06 16:05:51 --> Security Class Initialized
DEBUG - 2020-04-06 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:05:51 --> CSRF cookie sent
INFO - 2020-04-06 16:05:51 --> Input Class Initialized
INFO - 2020-04-06 16:05:51 --> Language Class Initialized
INFO - 2020-04-06 16:05:51 --> Language Class Initialized
INFO - 2020-04-06 16:05:51 --> Config Class Initialized
INFO - 2020-04-06 16:05:51 --> Loader Class Initialized
INFO - 2020-04-06 16:05:51 --> Helper loaded: url_helper
INFO - 2020-04-06 16:05:51 --> Helper loaded: file_helper
INFO - 2020-04-06 16:05:51 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:05:51 --> Helper loaded: common_helper
INFO - 2020-04-06 16:05:51 --> Helper loaded: language_helper
INFO - 2020-04-06 16:05:51 --> Helper loaded: email_helper
INFO - 2020-04-06 16:05:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:05:51 --> Database Driver Class Initialized
INFO - 2020-04-06 16:05:51 --> Parser Class Initialized
INFO - 2020-04-06 16:05:51 --> User Agent Class Initialized
INFO - 2020-04-06 16:05:51 --> Model Class Initialized
INFO - 2020-04-06 16:05:51 --> Model Class Initialized
DEBUG - 2020-04-06 16:05:52 --> Template Class Initialized
INFO - 2020-04-06 16:05:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:05:52 --> Email Class Initialized
INFO - 2020-04-06 16:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:05:52 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:05:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:05:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:05:52 --> Encryption Class Initialized
INFO - 2020-04-06 16:05:52 --> Controller Class Initialized
DEBUG - 2020-04-06 16:05:52 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:05:52 --> Model Class Initialized
INFO - 2020-04-06 16:05:52 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/email_template.php
DEBUG - 2020-04-06 16:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:05:52 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:05:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:05:52 --> Final output sent to browser
DEBUG - 2020-04-06 16:05:52 --> Total execution time: 0.6545
INFO - 2020-04-06 16:08:54 --> Config Class Initialized
INFO - 2020-04-06 16:08:54 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:08:54 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:08:54 --> Utf8 Class Initialized
INFO - 2020-04-06 16:08:54 --> URI Class Initialized
INFO - 2020-04-06 16:08:54 --> Router Class Initialized
INFO - 2020-04-06 16:08:54 --> Output Class Initialized
INFO - 2020-04-06 16:08:54 --> Security Class Initialized
DEBUG - 2020-04-06 16:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:08:54 --> CSRF cookie sent
INFO - 2020-04-06 16:08:54 --> Input Class Initialized
INFO - 2020-04-06 16:08:54 --> Language Class Initialized
INFO - 2020-04-06 16:08:54 --> Language Class Initialized
INFO - 2020-04-06 16:08:54 --> Config Class Initialized
INFO - 2020-04-06 16:08:54 --> Loader Class Initialized
INFO - 2020-04-06 16:08:54 --> Helper loaded: url_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: file_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: common_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: language_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: email_helper
INFO - 2020-04-06 16:08:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:08:54 --> Database Driver Class Initialized
INFO - 2020-04-06 16:08:54 --> Parser Class Initialized
INFO - 2020-04-06 16:08:54 --> User Agent Class Initialized
INFO - 2020-04-06 16:08:54 --> Model Class Initialized
INFO - 2020-04-06 16:08:54 --> Model Class Initialized
DEBUG - 2020-04-06 16:08:54 --> Template Class Initialized
INFO - 2020-04-06 16:08:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:08:54 --> Email Class Initialized
INFO - 2020-04-06 16:08:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:08:54 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:08:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:08:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:08:54 --> Encryption Class Initialized
INFO - 2020-04-06 16:08:54 --> Controller Class Initialized
DEBUG - 2020-04-06 16:08:54 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:08:54 --> Model Class Initialized
INFO - 2020-04-06 16:08:54 --> Config Class Initialized
INFO - 2020-04-06 16:08:54 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:08:54 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:08:54 --> Utf8 Class Initialized
INFO - 2020-04-06 16:08:54 --> URI Class Initialized
INFO - 2020-04-06 16:08:54 --> Router Class Initialized
INFO - 2020-04-06 16:08:54 --> Output Class Initialized
INFO - 2020-04-06 16:08:54 --> Security Class Initialized
DEBUG - 2020-04-06 16:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:08:54 --> CSRF cookie sent
INFO - 2020-04-06 16:08:54 --> Input Class Initialized
INFO - 2020-04-06 16:08:54 --> Language Class Initialized
INFO - 2020-04-06 16:08:54 --> Language Class Initialized
INFO - 2020-04-06 16:08:54 --> Config Class Initialized
INFO - 2020-04-06 16:08:54 --> Loader Class Initialized
INFO - 2020-04-06 16:08:54 --> Helper loaded: url_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: file_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: common_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: language_helper
INFO - 2020-04-06 16:08:54 --> Helper loaded: email_helper
INFO - 2020-04-06 16:08:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:08:54 --> Database Driver Class Initialized
INFO - 2020-04-06 16:08:54 --> Parser Class Initialized
INFO - 2020-04-06 16:08:54 --> User Agent Class Initialized
INFO - 2020-04-06 16:08:54 --> Model Class Initialized
INFO - 2020-04-06 16:08:54 --> Model Class Initialized
DEBUG - 2020-04-06 16:08:54 --> Template Class Initialized
INFO - 2020-04-06 16:08:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:08:54 --> Email Class Initialized
INFO - 2020-04-06 16:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:08:55 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:08:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:08:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:08:55 --> Encryption Class Initialized
INFO - 2020-04-06 16:08:55 --> Controller Class Initialized
DEBUG - 2020-04-06 16:08:55 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:08:55 --> Model Class Initialized
INFO - 2020-04-06 16:08:55 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:08:55 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:08:55 --> Final output sent to browser
DEBUG - 2020-04-06 16:08:55 --> Total execution time: 0.5844
INFO - 2020-04-06 16:09:21 --> Config Class Initialized
INFO - 2020-04-06 16:09:21 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:09:22 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:09:22 --> Utf8 Class Initialized
INFO - 2020-04-06 16:09:22 --> URI Class Initialized
INFO - 2020-04-06 16:09:22 --> Router Class Initialized
INFO - 2020-04-06 16:09:22 --> Output Class Initialized
INFO - 2020-04-06 16:09:22 --> Security Class Initialized
DEBUG - 2020-04-06 16:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:09:22 --> CSRF cookie sent
INFO - 2020-04-06 16:09:22 --> Input Class Initialized
INFO - 2020-04-06 16:09:22 --> Language Class Initialized
INFO - 2020-04-06 16:09:22 --> Language Class Initialized
INFO - 2020-04-06 16:09:22 --> Config Class Initialized
INFO - 2020-04-06 16:09:22 --> Loader Class Initialized
INFO - 2020-04-06 16:09:22 --> Helper loaded: url_helper
INFO - 2020-04-06 16:09:22 --> Helper loaded: file_helper
INFO - 2020-04-06 16:09:22 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:09:22 --> Helper loaded: common_helper
INFO - 2020-04-06 16:09:22 --> Helper loaded: language_helper
INFO - 2020-04-06 16:09:22 --> Helper loaded: email_helper
INFO - 2020-04-06 16:09:22 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:09:22 --> Database Driver Class Initialized
INFO - 2020-04-06 16:09:22 --> Parser Class Initialized
INFO - 2020-04-06 16:09:22 --> User Agent Class Initialized
INFO - 2020-04-06 16:09:22 --> Model Class Initialized
INFO - 2020-04-06 16:09:22 --> Model Class Initialized
DEBUG - 2020-04-06 16:09:22 --> Template Class Initialized
INFO - 2020-04-06 16:09:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:09:22 --> Email Class Initialized
INFO - 2020-04-06 16:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:09:22 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:09:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:09:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:09:22 --> Encryption Class Initialized
INFO - 2020-04-06 16:09:22 --> Controller Class Initialized
DEBUG - 2020-04-06 16:09:22 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:09:22 --> Model Class Initialized
INFO - 2020-04-06 16:09:22 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:09:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/default_settings.php
DEBUG - 2020-04-06 16:09:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:09:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:09:22 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:09:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:09:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:09:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:09:22 --> Final output sent to browser
DEBUG - 2020-04-06 16:09:22 --> Total execution time: 0.7528
INFO - 2020-04-06 16:09:23 --> Config Class Initialized
INFO - 2020-04-06 16:09:23 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:09:23 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:09:23 --> Utf8 Class Initialized
INFO - 2020-04-06 16:09:23 --> URI Class Initialized
INFO - 2020-04-06 16:09:23 --> Router Class Initialized
INFO - 2020-04-06 16:09:23 --> Output Class Initialized
INFO - 2020-04-06 16:09:23 --> Security Class Initialized
DEBUG - 2020-04-06 16:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:09:23 --> CSRF cookie sent
INFO - 2020-04-06 16:09:23 --> Input Class Initialized
INFO - 2020-04-06 16:09:23 --> Language Class Initialized
INFO - 2020-04-06 16:09:23 --> Language Class Initialized
INFO - 2020-04-06 16:09:23 --> Config Class Initialized
INFO - 2020-04-06 16:09:23 --> Loader Class Initialized
INFO - 2020-04-06 16:09:24 --> Helper loaded: url_helper
INFO - 2020-04-06 16:09:24 --> Helper loaded: file_helper
INFO - 2020-04-06 16:09:24 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:09:24 --> Helper loaded: common_helper
INFO - 2020-04-06 16:09:24 --> Helper loaded: language_helper
INFO - 2020-04-06 16:09:24 --> Helper loaded: email_helper
INFO - 2020-04-06 16:09:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:09:24 --> Database Driver Class Initialized
INFO - 2020-04-06 16:09:24 --> Parser Class Initialized
INFO - 2020-04-06 16:09:24 --> User Agent Class Initialized
INFO - 2020-04-06 16:09:24 --> Model Class Initialized
INFO - 2020-04-06 16:09:24 --> Model Class Initialized
DEBUG - 2020-04-06 16:09:24 --> Template Class Initialized
INFO - 2020-04-06 16:09:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:09:24 --> Email Class Initialized
INFO - 2020-04-06 16:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:09:24 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:09:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:09:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:09:24 --> Encryption Class Initialized
INFO - 2020-04-06 16:09:24 --> Controller Class Initialized
DEBUG - 2020-04-06 16:09:24 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:09:24 --> Model Class Initialized
INFO - 2020-04-06 16:09:24 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:09:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/other.php
DEBUG - 2020-04-06 16:09:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:09:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:09:24 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:09:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:09:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:09:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:09:24 --> Final output sent to browser
DEBUG - 2020-04-06 16:09:24 --> Total execution time: 0.6096
INFO - 2020-04-06 16:09:25 --> Config Class Initialized
INFO - 2020-04-06 16:09:25 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:09:25 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:09:25 --> Utf8 Class Initialized
INFO - 2020-04-06 16:09:25 --> URI Class Initialized
INFO - 2020-04-06 16:09:25 --> Router Class Initialized
INFO - 2020-04-06 16:09:25 --> Output Class Initialized
INFO - 2020-04-06 16:09:25 --> Security Class Initialized
DEBUG - 2020-04-06 16:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:09:25 --> CSRF cookie sent
INFO - 2020-04-06 16:09:25 --> Input Class Initialized
INFO - 2020-04-06 16:09:25 --> Language Class Initialized
INFO - 2020-04-06 16:09:26 --> Language Class Initialized
INFO - 2020-04-06 16:09:26 --> Config Class Initialized
INFO - 2020-04-06 16:09:26 --> Loader Class Initialized
INFO - 2020-04-06 16:09:26 --> Helper loaded: url_helper
INFO - 2020-04-06 16:09:26 --> Helper loaded: file_helper
INFO - 2020-04-06 16:09:26 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:09:26 --> Helper loaded: common_helper
INFO - 2020-04-06 16:09:26 --> Helper loaded: language_helper
INFO - 2020-04-06 16:09:26 --> Helper loaded: email_helper
INFO - 2020-04-06 16:09:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:09:26 --> Database Driver Class Initialized
INFO - 2020-04-06 16:09:26 --> Parser Class Initialized
INFO - 2020-04-06 16:09:26 --> User Agent Class Initialized
INFO - 2020-04-06 16:09:26 --> Model Class Initialized
INFO - 2020-04-06 16:09:26 --> Model Class Initialized
DEBUG - 2020-04-06 16:09:26 --> Template Class Initialized
INFO - 2020-04-06 16:09:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:09:26 --> Email Class Initialized
INFO - 2020-04-06 16:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:09:26 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:09:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:09:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:09:26 --> Encryption Class Initialized
INFO - 2020-04-06 16:09:26 --> Controller Class Initialized
DEBUG - 2020-04-06 16:09:26 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:09:26 --> Model Class Initialized
INFO - 2020-04-06 16:09:26 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:09:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/email_smtp.php
DEBUG - 2020-04-06 16:09:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:09:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:09:26 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:09:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:09:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:09:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:09:26 --> Final output sent to browser
DEBUG - 2020-04-06 16:09:26 --> Total execution time: 0.6476
INFO - 2020-04-06 16:09:27 --> Config Class Initialized
INFO - 2020-04-06 16:09:27 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:09:27 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:09:27 --> Utf8 Class Initialized
INFO - 2020-04-06 16:09:27 --> URI Class Initialized
INFO - 2020-04-06 16:09:27 --> Router Class Initialized
INFO - 2020-04-06 16:09:27 --> Output Class Initialized
INFO - 2020-04-06 16:09:27 --> Security Class Initialized
DEBUG - 2020-04-06 16:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:09:27 --> CSRF cookie sent
INFO - 2020-04-06 16:09:27 --> Input Class Initialized
INFO - 2020-04-06 16:09:27 --> Language Class Initialized
INFO - 2020-04-06 16:09:27 --> Language Class Initialized
INFO - 2020-04-06 16:09:27 --> Config Class Initialized
INFO - 2020-04-06 16:09:27 --> Loader Class Initialized
INFO - 2020-04-06 16:09:27 --> Helper loaded: url_helper
INFO - 2020-04-06 16:09:27 --> Helper loaded: file_helper
INFO - 2020-04-06 16:09:27 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:09:27 --> Helper loaded: common_helper
INFO - 2020-04-06 16:09:27 --> Helper loaded: language_helper
INFO - 2020-04-06 16:09:27 --> Helper loaded: email_helper
INFO - 2020-04-06 16:09:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:09:27 --> Database Driver Class Initialized
INFO - 2020-04-06 16:09:27 --> Parser Class Initialized
INFO - 2020-04-06 16:09:27 --> User Agent Class Initialized
INFO - 2020-04-06 16:09:27 --> Model Class Initialized
INFO - 2020-04-06 16:09:27 --> Model Class Initialized
DEBUG - 2020-04-06 16:09:27 --> Template Class Initialized
INFO - 2020-04-06 16:09:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:09:27 --> Email Class Initialized
INFO - 2020-04-06 16:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:09:27 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:09:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:09:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:09:27 --> Encryption Class Initialized
INFO - 2020-04-06 16:09:27 --> Controller Class Initialized
DEBUG - 2020-04-06 16:09:27 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:09:27 --> Model Class Initialized
INFO - 2020-04-06 16:09:27 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/email_template.php
DEBUG - 2020-04-06 16:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:09:27 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:09:28 --> Final output sent to browser
DEBUG - 2020-04-06 16:09:28 --> Total execution time: 0.6177
INFO - 2020-04-06 16:09:31 --> Config Class Initialized
INFO - 2020-04-06 16:09:31 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:09:31 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:09:31 --> Utf8 Class Initialized
INFO - 2020-04-06 16:09:31 --> URI Class Initialized
INFO - 2020-04-06 16:09:31 --> Router Class Initialized
INFO - 2020-04-06 16:09:31 --> Output Class Initialized
INFO - 2020-04-06 16:09:31 --> Security Class Initialized
DEBUG - 2020-04-06 16:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:09:31 --> CSRF cookie sent
INFO - 2020-04-06 16:09:31 --> Input Class Initialized
INFO - 2020-04-06 16:09:31 --> Language Class Initialized
INFO - 2020-04-06 16:09:31 --> Language Class Initialized
INFO - 2020-04-06 16:09:31 --> Config Class Initialized
INFO - 2020-04-06 16:09:31 --> Loader Class Initialized
INFO - 2020-04-06 16:09:31 --> Helper loaded: url_helper
INFO - 2020-04-06 16:09:31 --> Helper loaded: file_helper
INFO - 2020-04-06 16:09:31 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:09:31 --> Helper loaded: common_helper
INFO - 2020-04-06 16:09:31 --> Helper loaded: language_helper
INFO - 2020-04-06 16:09:31 --> Helper loaded: email_helper
INFO - 2020-04-06 16:09:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:09:31 --> Database Driver Class Initialized
INFO - 2020-04-06 16:09:31 --> Parser Class Initialized
INFO - 2020-04-06 16:09:31 --> User Agent Class Initialized
INFO - 2020-04-06 16:09:31 --> Model Class Initialized
INFO - 2020-04-06 16:09:31 --> Model Class Initialized
DEBUG - 2020-04-06 16:09:31 --> Template Class Initialized
INFO - 2020-04-06 16:09:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:09:31 --> Email Class Initialized
INFO - 2020-04-06 16:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:09:31 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:09:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:09:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:09:31 --> Encryption Class Initialized
INFO - 2020-04-06 16:09:31 --> Controller Class Initialized
DEBUG - 2020-04-06 16:09:31 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:09:31 --> Model Class Initialized
INFO - 2020-04-06 16:09:31 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:09:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:09:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:09:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:09:31 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:09:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:09:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:09:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:09:32 --> Final output sent to browser
DEBUG - 2020-04-06 16:09:32 --> Total execution time: 0.6162
INFO - 2020-04-06 16:09:37 --> Config Class Initialized
INFO - 2020-04-06 16:09:37 --> Config Class Initialized
INFO - 2020-04-06 16:09:37 --> Hooks Class Initialized
INFO - 2020-04-06 16:09:37 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:09:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-06 16:09:37 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:09:37 --> Utf8 Class Initialized
INFO - 2020-04-06 16:09:37 --> Utf8 Class Initialized
INFO - 2020-04-06 16:09:37 --> URI Class Initialized
INFO - 2020-04-06 16:09:37 --> URI Class Initialized
INFO - 2020-04-06 16:09:37 --> Router Class Initialized
INFO - 2020-04-06 16:09:37 --> Router Class Initialized
INFO - 2020-04-06 16:09:37 --> Output Class Initialized
INFO - 2020-04-06 16:09:37 --> Output Class Initialized
INFO - 2020-04-06 16:09:37 --> Security Class Initialized
INFO - 2020-04-06 16:09:37 --> Security Class Initialized
DEBUG - 2020-04-06 16:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-06 16:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:09:37 --> CSRF cookie sent
INFO - 2020-04-06 16:09:37 --> CSRF cookie sent
INFO - 2020-04-06 16:09:37 --> Input Class Initialized
INFO - 2020-04-06 16:09:37 --> Input Class Initialized
INFO - 2020-04-06 16:09:37 --> Language Class Initialized
INFO - 2020-04-06 16:09:37 --> Language Class Initialized
ERROR - 2020-04-06 16:09:37 --> 404 Page Not Found: /index
ERROR - 2020-04-06 16:09:37 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:10:40 --> Config Class Initialized
INFO - 2020-04-06 16:10:40 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:10:40 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:10:40 --> Utf8 Class Initialized
INFO - 2020-04-06 16:10:40 --> URI Class Initialized
INFO - 2020-04-06 16:10:40 --> Router Class Initialized
INFO - 2020-04-06 16:10:40 --> Output Class Initialized
INFO - 2020-04-06 16:10:40 --> Security Class Initialized
DEBUG - 2020-04-06 16:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:10:40 --> CSRF cookie sent
INFO - 2020-04-06 16:10:40 --> Input Class Initialized
INFO - 2020-04-06 16:10:40 --> Language Class Initialized
INFO - 2020-04-06 16:10:40 --> Language Class Initialized
INFO - 2020-04-06 16:10:40 --> Config Class Initialized
INFO - 2020-04-06 16:10:40 --> Loader Class Initialized
INFO - 2020-04-06 16:10:40 --> Helper loaded: url_helper
INFO - 2020-04-06 16:10:40 --> Helper loaded: file_helper
INFO - 2020-04-06 16:10:40 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:10:40 --> Helper loaded: common_helper
INFO - 2020-04-06 16:10:40 --> Helper loaded: language_helper
INFO - 2020-04-06 16:10:40 --> Helper loaded: email_helper
INFO - 2020-04-06 16:10:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:10:40 --> Database Driver Class Initialized
INFO - 2020-04-06 16:10:40 --> Parser Class Initialized
INFO - 2020-04-06 16:10:40 --> User Agent Class Initialized
INFO - 2020-04-06 16:10:40 --> Model Class Initialized
INFO - 2020-04-06 16:10:40 --> Model Class Initialized
DEBUG - 2020-04-06 16:10:40 --> Template Class Initialized
INFO - 2020-04-06 16:10:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:10:40 --> Email Class Initialized
INFO - 2020-04-06 16:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:10:40 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:10:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:10:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:10:41 --> Encryption Class Initialized
INFO - 2020-04-06 16:10:41 --> Controller Class Initialized
DEBUG - 2020-04-06 16:10:41 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:10:41 --> Model Class Initialized
INFO - 2020-04-06 16:10:41 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:10:41 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:10:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:10:41 --> Final output sent to browser
DEBUG - 2020-04-06 16:10:41 --> Total execution time: 0.6176
INFO - 2020-04-06 16:10:41 --> Config Class Initialized
INFO - 2020-04-06 16:10:41 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:10:41 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:10:41 --> Utf8 Class Initialized
INFO - 2020-04-06 16:10:41 --> URI Class Initialized
INFO - 2020-04-06 16:10:41 --> Router Class Initialized
INFO - 2020-04-06 16:10:41 --> Output Class Initialized
INFO - 2020-04-06 16:10:41 --> Security Class Initialized
DEBUG - 2020-04-06 16:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:10:41 --> CSRF cookie sent
INFO - 2020-04-06 16:10:41 --> Input Class Initialized
INFO - 2020-04-06 16:10:41 --> Language Class Initialized
ERROR - 2020-04-06 16:10:41 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:10:41 --> Config Class Initialized
INFO - 2020-04-06 16:10:41 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:10:41 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:10:41 --> Utf8 Class Initialized
INFO - 2020-04-06 16:10:41 --> URI Class Initialized
INFO - 2020-04-06 16:10:41 --> Router Class Initialized
INFO - 2020-04-06 16:10:42 --> Output Class Initialized
INFO - 2020-04-06 16:10:42 --> Security Class Initialized
DEBUG - 2020-04-06 16:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:10:42 --> CSRF cookie sent
INFO - 2020-04-06 16:10:42 --> Input Class Initialized
INFO - 2020-04-06 16:10:42 --> Language Class Initialized
ERROR - 2020-04-06 16:10:42 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:10:46 --> Config Class Initialized
INFO - 2020-04-06 16:10:46 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:10:46 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:10:46 --> Utf8 Class Initialized
INFO - 2020-04-06 16:10:46 --> URI Class Initialized
INFO - 2020-04-06 16:10:46 --> Router Class Initialized
INFO - 2020-04-06 16:10:46 --> Output Class Initialized
INFO - 2020-04-06 16:10:46 --> Security Class Initialized
DEBUG - 2020-04-06 16:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:10:46 --> CSRF cookie sent
INFO - 2020-04-06 16:10:46 --> CSRF token verified
INFO - 2020-04-06 16:10:46 --> Input Class Initialized
INFO - 2020-04-06 16:10:46 --> Language Class Initialized
INFO - 2020-04-06 16:10:46 --> Language Class Initialized
INFO - 2020-04-06 16:10:46 --> Config Class Initialized
INFO - 2020-04-06 16:10:46 --> Loader Class Initialized
INFO - 2020-04-06 16:10:46 --> Helper loaded: url_helper
INFO - 2020-04-06 16:10:46 --> Helper loaded: file_helper
INFO - 2020-04-06 16:10:47 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:10:47 --> Helper loaded: common_helper
INFO - 2020-04-06 16:10:47 --> Helper loaded: language_helper
INFO - 2020-04-06 16:10:47 --> Helper loaded: email_helper
INFO - 2020-04-06 16:10:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:10:47 --> Database Driver Class Initialized
INFO - 2020-04-06 16:10:47 --> Parser Class Initialized
INFO - 2020-04-06 16:10:47 --> User Agent Class Initialized
INFO - 2020-04-06 16:10:47 --> Model Class Initialized
INFO - 2020-04-06 16:10:47 --> Model Class Initialized
DEBUG - 2020-04-06 16:10:47 --> Template Class Initialized
INFO - 2020-04-06 16:10:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:10:47 --> Email Class Initialized
INFO - 2020-04-06 16:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:10:47 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:10:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:10:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:10:47 --> Encryption Class Initialized
INFO - 2020-04-06 16:10:47 --> Controller Class Initialized
DEBUG - 2020-04-06 16:10:47 --> gallery MX_Controller Initialized
INFO - 2020-04-06 16:10:47 --> Model Class Initialized
INFO - 2020-04-06 16:10:47 --> Upload Class Initialized
INFO - 2020-04-06 16:10:51 --> Config Class Initialized
INFO - 2020-04-06 16:10:51 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:10:51 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:10:51 --> Utf8 Class Initialized
INFO - 2020-04-06 16:10:51 --> URI Class Initialized
INFO - 2020-04-06 16:10:51 --> Router Class Initialized
INFO - 2020-04-06 16:10:51 --> Output Class Initialized
INFO - 2020-04-06 16:10:51 --> Security Class Initialized
DEBUG - 2020-04-06 16:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:10:51 --> CSRF cookie sent
INFO - 2020-04-06 16:10:51 --> Input Class Initialized
INFO - 2020-04-06 16:10:51 --> Language Class Initialized
INFO - 2020-04-06 16:10:51 --> Language Class Initialized
INFO - 2020-04-06 16:10:52 --> Config Class Initialized
INFO - 2020-04-06 16:10:52 --> Loader Class Initialized
INFO - 2020-04-06 16:10:52 --> Helper loaded: url_helper
INFO - 2020-04-06 16:10:52 --> Helper loaded: file_helper
INFO - 2020-04-06 16:10:52 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:10:52 --> Helper loaded: common_helper
INFO - 2020-04-06 16:10:52 --> Helper loaded: language_helper
INFO - 2020-04-06 16:10:52 --> Helper loaded: email_helper
INFO - 2020-04-06 16:10:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:10:52 --> Database Driver Class Initialized
INFO - 2020-04-06 16:10:52 --> Parser Class Initialized
INFO - 2020-04-06 16:10:52 --> User Agent Class Initialized
INFO - 2020-04-06 16:10:52 --> Model Class Initialized
INFO - 2020-04-06 16:10:52 --> Model Class Initialized
DEBUG - 2020-04-06 16:10:52 --> Template Class Initialized
INFO - 2020-04-06 16:10:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:10:52 --> Email Class Initialized
INFO - 2020-04-06 16:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:10:52 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:10:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:10:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:10:52 --> Encryption Class Initialized
INFO - 2020-04-06 16:10:52 --> Controller Class Initialized
DEBUG - 2020-04-06 16:10:52 --> gallery MX_Controller Initialized
INFO - 2020-04-06 16:10:52 --> Model Class Initialized
INFO - 2020-04-06 16:10:52 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-06 16:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:10:52 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:10:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:10:52 --> Final output sent to browser
DEBUG - 2020-04-06 16:10:52 --> Total execution time: 0.6696
INFO - 2020-04-06 16:10:52 --> Config Class Initialized
INFO - 2020-04-06 16:10:52 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:10:52 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:10:52 --> Utf8 Class Initialized
INFO - 2020-04-06 16:10:52 --> URI Class Initialized
INFO - 2020-04-06 16:10:52 --> Router Class Initialized
INFO - 2020-04-06 16:10:52 --> Output Class Initialized
INFO - 2020-04-06 16:10:52 --> Security Class Initialized
DEBUG - 2020-04-06 16:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:10:52 --> CSRF cookie sent
INFO - 2020-04-06 16:10:52 --> Input Class Initialized
INFO - 2020-04-06 16:10:52 --> Language Class Initialized
ERROR - 2020-04-06 16:10:52 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:10:53 --> Config Class Initialized
INFO - 2020-04-06 16:10:53 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:10:53 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:10:53 --> Utf8 Class Initialized
INFO - 2020-04-06 16:10:53 --> URI Class Initialized
INFO - 2020-04-06 16:10:53 --> Router Class Initialized
INFO - 2020-04-06 16:10:53 --> Output Class Initialized
INFO - 2020-04-06 16:10:53 --> Security Class Initialized
DEBUG - 2020-04-06 16:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:10:53 --> CSRF cookie sent
INFO - 2020-04-06 16:10:53 --> Input Class Initialized
INFO - 2020-04-06 16:10:53 --> Language Class Initialized
ERROR - 2020-04-06 16:10:53 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:10:56 --> Config Class Initialized
INFO - 2020-04-06 16:10:56 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:10:56 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:10:56 --> Utf8 Class Initialized
INFO - 2020-04-06 16:10:56 --> URI Class Initialized
INFO - 2020-04-06 16:10:56 --> Router Class Initialized
INFO - 2020-04-06 16:10:56 --> Output Class Initialized
INFO - 2020-04-06 16:10:56 --> Security Class Initialized
DEBUG - 2020-04-06 16:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:10:56 --> CSRF cookie sent
INFO - 2020-04-06 16:10:56 --> CSRF token verified
INFO - 2020-04-06 16:10:56 --> Input Class Initialized
INFO - 2020-04-06 16:10:56 --> Language Class Initialized
INFO - 2020-04-06 16:10:56 --> Language Class Initialized
INFO - 2020-04-06 16:10:56 --> Config Class Initialized
INFO - 2020-04-06 16:10:56 --> Loader Class Initialized
INFO - 2020-04-06 16:10:56 --> Helper loaded: url_helper
INFO - 2020-04-06 16:10:56 --> Helper loaded: file_helper
INFO - 2020-04-06 16:10:56 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:10:56 --> Helper loaded: common_helper
INFO - 2020-04-06 16:10:56 --> Helper loaded: language_helper
INFO - 2020-04-06 16:10:56 --> Helper loaded: email_helper
INFO - 2020-04-06 16:10:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:10:56 --> Database Driver Class Initialized
INFO - 2020-04-06 16:10:56 --> Parser Class Initialized
INFO - 2020-04-06 16:10:56 --> User Agent Class Initialized
INFO - 2020-04-06 16:10:56 --> Model Class Initialized
INFO - 2020-04-06 16:10:56 --> Model Class Initialized
DEBUG - 2020-04-06 16:10:56 --> Template Class Initialized
INFO - 2020-04-06 16:10:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:10:56 --> Email Class Initialized
INFO - 2020-04-06 16:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:10:56 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:10:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:10:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:10:56 --> Encryption Class Initialized
INFO - 2020-04-06 16:10:56 --> Controller Class Initialized
DEBUG - 2020-04-06 16:10:56 --> gallery MX_Controller Initialized
INFO - 2020-04-06 16:10:56 --> Model Class Initialized
INFO - 2020-04-06 16:11:26 --> Config Class Initialized
INFO - 2020-04-06 16:11:26 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:11:26 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:11:26 --> Utf8 Class Initialized
INFO - 2020-04-06 16:11:26 --> URI Class Initialized
INFO - 2020-04-06 16:11:26 --> Router Class Initialized
INFO - 2020-04-06 16:11:27 --> Output Class Initialized
INFO - 2020-04-06 16:11:27 --> Security Class Initialized
DEBUG - 2020-04-06 16:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:11:27 --> CSRF cookie sent
INFO - 2020-04-06 16:11:27 --> Input Class Initialized
INFO - 2020-04-06 16:11:27 --> Language Class Initialized
INFO - 2020-04-06 16:11:27 --> Language Class Initialized
INFO - 2020-04-06 16:11:27 --> Config Class Initialized
INFO - 2020-04-06 16:11:27 --> Loader Class Initialized
INFO - 2020-04-06 16:11:27 --> Helper loaded: url_helper
INFO - 2020-04-06 16:11:27 --> Helper loaded: file_helper
INFO - 2020-04-06 16:11:27 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:11:27 --> Helper loaded: common_helper
INFO - 2020-04-06 16:11:27 --> Helper loaded: language_helper
INFO - 2020-04-06 16:11:27 --> Helper loaded: email_helper
INFO - 2020-04-06 16:11:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:11:27 --> Database Driver Class Initialized
INFO - 2020-04-06 16:11:27 --> Parser Class Initialized
INFO - 2020-04-06 16:11:27 --> User Agent Class Initialized
INFO - 2020-04-06 16:11:27 --> Model Class Initialized
INFO - 2020-04-06 16:11:27 --> Model Class Initialized
DEBUG - 2020-04-06 16:11:27 --> Template Class Initialized
INFO - 2020-04-06 16:11:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:11:27 --> Email Class Initialized
INFO - 2020-04-06 16:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:11:27 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:11:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:11:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:11:27 --> Encryption Class Initialized
INFO - 2020-04-06 16:11:27 --> Controller Class Initialized
DEBUG - 2020-04-06 16:11:27 --> schedule MX_Controller Initialized
INFO - 2020-04-06 16:11:27 --> Model Class Initialized
DEBUG - 2020-04-06 16:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/models/schedule_model.php
INFO - 2020-04-06 16:11:27 --> Model Class Initialized
DEBUG - 2020-04-06 16:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/views/index.php
DEBUG - 2020-04-06 16:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:11:27 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:11:27 --> Final output sent to browser
DEBUG - 2020-04-06 16:11:27 --> Total execution time: 0.6146
INFO - 2020-04-06 16:11:29 --> Config Class Initialized
INFO - 2020-04-06 16:11:29 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:11:29 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:11:29 --> Utf8 Class Initialized
INFO - 2020-04-06 16:11:29 --> URI Class Initialized
INFO - 2020-04-06 16:11:29 --> Router Class Initialized
INFO - 2020-04-06 16:11:29 --> Output Class Initialized
INFO - 2020-04-06 16:11:29 --> Security Class Initialized
DEBUG - 2020-04-06 16:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:11:29 --> CSRF cookie sent
INFO - 2020-04-06 16:11:29 --> Input Class Initialized
INFO - 2020-04-06 16:11:29 --> Language Class Initialized
INFO - 2020-04-06 16:11:29 --> Language Class Initialized
INFO - 2020-04-06 16:11:29 --> Config Class Initialized
INFO - 2020-04-06 16:11:29 --> Loader Class Initialized
INFO - 2020-04-06 16:11:29 --> Helper loaded: url_helper
INFO - 2020-04-06 16:11:29 --> Helper loaded: file_helper
INFO - 2020-04-06 16:11:29 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:11:29 --> Helper loaded: common_helper
INFO - 2020-04-06 16:11:29 --> Helper loaded: language_helper
INFO - 2020-04-06 16:11:29 --> Helper loaded: email_helper
INFO - 2020-04-06 16:11:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:11:29 --> Database Driver Class Initialized
INFO - 2020-04-06 16:11:29 --> Parser Class Initialized
INFO - 2020-04-06 16:11:29 --> User Agent Class Initialized
INFO - 2020-04-06 16:11:29 --> Model Class Initialized
INFO - 2020-04-06 16:11:29 --> Model Class Initialized
DEBUG - 2020-04-06 16:11:29 --> Template Class Initialized
INFO - 2020-04-06 16:11:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:11:29 --> Email Class Initialized
INFO - 2020-04-06 16:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:11:29 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:11:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:11:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:11:30 --> Encryption Class Initialized
INFO - 2020-04-06 16:11:30 --> Controller Class Initialized
DEBUG - 2020-04-06 16:11:30 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:11:30 --> Model Class Initialized
DEBUG - 2020-04-06 16:11:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:11:30 --> Model Class Initialized
INFO - 2020-04-06 16:11:30 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:11:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 16:11:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:11:30 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:11:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:11:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:11:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:11:30 --> Final output sent to browser
DEBUG - 2020-04-06 16:11:30 --> Total execution time: 0.6150
INFO - 2020-04-06 16:13:11 --> Config Class Initialized
INFO - 2020-04-06 16:13:11 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:13:11 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:13:11 --> Utf8 Class Initialized
INFO - 2020-04-06 16:13:11 --> URI Class Initialized
INFO - 2020-04-06 16:13:11 --> Router Class Initialized
INFO - 2020-04-06 16:13:11 --> Output Class Initialized
INFO - 2020-04-06 16:13:12 --> Security Class Initialized
DEBUG - 2020-04-06 16:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:13:12 --> CSRF cookie sent
INFO - 2020-04-06 16:13:12 --> Input Class Initialized
INFO - 2020-04-06 16:13:12 --> Language Class Initialized
INFO - 2020-04-06 16:13:12 --> Language Class Initialized
INFO - 2020-04-06 16:13:12 --> Config Class Initialized
INFO - 2020-04-06 16:13:12 --> Loader Class Initialized
INFO - 2020-04-06 16:13:12 --> Helper loaded: url_helper
INFO - 2020-04-06 16:13:12 --> Helper loaded: file_helper
INFO - 2020-04-06 16:13:12 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:13:12 --> Helper loaded: common_helper
INFO - 2020-04-06 16:13:12 --> Helper loaded: language_helper
INFO - 2020-04-06 16:13:12 --> Helper loaded: email_helper
INFO - 2020-04-06 16:13:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:13:12 --> Database Driver Class Initialized
INFO - 2020-04-06 16:13:12 --> Parser Class Initialized
INFO - 2020-04-06 16:13:12 --> User Agent Class Initialized
INFO - 2020-04-06 16:13:12 --> Model Class Initialized
INFO - 2020-04-06 16:13:12 --> Model Class Initialized
DEBUG - 2020-04-06 16:13:12 --> Template Class Initialized
INFO - 2020-04-06 16:13:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:13:12 --> Email Class Initialized
INFO - 2020-04-06 16:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:13:12 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:13:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:13:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:13:12 --> Encryption Class Initialized
INFO - 2020-04-06 16:13:12 --> Controller Class Initialized
DEBUG - 2020-04-06 16:13:12 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:13:12 --> Model Class Initialized
DEBUG - 2020-04-06 16:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:13:12 --> Model Class Initialized
INFO - 2020-04-06 16:13:12 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 16:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:13:12 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:13:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:13:12 --> Final output sent to browser
DEBUG - 2020-04-06 16:13:12 --> Total execution time: 0.6961
INFO - 2020-04-06 16:14:22 --> Config Class Initialized
INFO - 2020-04-06 16:14:22 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:14:22 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:14:22 --> Utf8 Class Initialized
INFO - 2020-04-06 16:14:22 --> URI Class Initialized
INFO - 2020-04-06 16:14:23 --> Router Class Initialized
INFO - 2020-04-06 16:14:23 --> Output Class Initialized
INFO - 2020-04-06 16:14:23 --> Security Class Initialized
DEBUG - 2020-04-06 16:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:14:23 --> CSRF cookie sent
INFO - 2020-04-06 16:14:23 --> Input Class Initialized
INFO - 2020-04-06 16:14:23 --> Language Class Initialized
INFO - 2020-04-06 16:14:23 --> Language Class Initialized
INFO - 2020-04-06 16:14:23 --> Config Class Initialized
INFO - 2020-04-06 16:14:23 --> Loader Class Initialized
INFO - 2020-04-06 16:14:23 --> Helper loaded: url_helper
INFO - 2020-04-06 16:14:23 --> Helper loaded: file_helper
INFO - 2020-04-06 16:14:23 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:14:23 --> Helper loaded: common_helper
INFO - 2020-04-06 16:14:23 --> Helper loaded: language_helper
INFO - 2020-04-06 16:14:23 --> Helper loaded: email_helper
INFO - 2020-04-06 16:14:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:14:23 --> Database Driver Class Initialized
INFO - 2020-04-06 16:14:23 --> Parser Class Initialized
INFO - 2020-04-06 16:14:23 --> User Agent Class Initialized
INFO - 2020-04-06 16:14:23 --> Model Class Initialized
INFO - 2020-04-06 16:14:23 --> Model Class Initialized
DEBUG - 2020-04-06 16:14:23 --> Template Class Initialized
INFO - 2020-04-06 16:14:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:14:23 --> Email Class Initialized
INFO - 2020-04-06 16:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:14:23 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:14:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:14:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:14:23 --> Encryption Class Initialized
INFO - 2020-04-06 16:14:23 --> Controller Class Initialized
DEBUG - 2020-04-06 16:14:23 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:14:23 --> Model Class Initialized
DEBUG - 2020-04-06 16:14:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:14:23 --> Model Class Initialized
INFO - 2020-04-06 16:14:23 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:14:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 16:14:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:14:23 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:14:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:14:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:14:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:14:23 --> Final output sent to browser
DEBUG - 2020-04-06 16:14:23 --> Total execution time: 0.6790
INFO - 2020-04-06 16:14:32 --> Config Class Initialized
INFO - 2020-04-06 16:14:32 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:14:32 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:14:32 --> Utf8 Class Initialized
INFO - 2020-04-06 16:14:32 --> URI Class Initialized
INFO - 2020-04-06 16:14:32 --> Router Class Initialized
INFO - 2020-04-06 16:14:32 --> Output Class Initialized
INFO - 2020-04-06 16:14:32 --> Security Class Initialized
DEBUG - 2020-04-06 16:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:14:32 --> CSRF cookie sent
INFO - 2020-04-06 16:14:32 --> Input Class Initialized
INFO - 2020-04-06 16:14:32 --> Language Class Initialized
INFO - 2020-04-06 16:14:32 --> Language Class Initialized
INFO - 2020-04-06 16:14:32 --> Config Class Initialized
INFO - 2020-04-06 16:14:32 --> Loader Class Initialized
INFO - 2020-04-06 16:14:32 --> Helper loaded: url_helper
INFO - 2020-04-06 16:14:32 --> Helper loaded: file_helper
INFO - 2020-04-06 16:14:32 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:14:32 --> Helper loaded: common_helper
INFO - 2020-04-06 16:14:32 --> Helper loaded: language_helper
INFO - 2020-04-06 16:14:32 --> Helper loaded: email_helper
INFO - 2020-04-06 16:14:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:14:32 --> Database Driver Class Initialized
INFO - 2020-04-06 16:14:32 --> Parser Class Initialized
INFO - 2020-04-06 16:14:32 --> User Agent Class Initialized
INFO - 2020-04-06 16:14:32 --> Model Class Initialized
INFO - 2020-04-06 16:14:32 --> Model Class Initialized
DEBUG - 2020-04-06 16:14:32 --> Template Class Initialized
INFO - 2020-04-06 16:14:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:14:32 --> Email Class Initialized
INFO - 2020-04-06 16:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:14:32 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:14:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:14:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:14:32 --> Encryption Class Initialized
INFO - 2020-04-06 16:14:32 --> Controller Class Initialized
DEBUG - 2020-04-06 16:14:32 --> package MX_Controller Initialized
INFO - 2020-04-06 16:14:32 --> Model Class Initialized
DEBUG - 2020-04-06 16:14:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/package/models/package_model.php
INFO - 2020-04-06 16:14:32 --> Model Class Initialized
DEBUG - 2020-04-06 16:14:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/package/views/index.php
DEBUG - 2020-04-06 16:14:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:14:32 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:14:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:14:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:14:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:14:32 --> Final output sent to browser
DEBUG - 2020-04-06 16:14:32 --> Total execution time: 0.6736
INFO - 2020-04-06 16:14:37 --> Config Class Initialized
INFO - 2020-04-06 16:14:37 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:14:37 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:14:37 --> Utf8 Class Initialized
INFO - 2020-04-06 16:14:37 --> URI Class Initialized
INFO - 2020-04-06 16:14:37 --> Router Class Initialized
INFO - 2020-04-06 16:14:37 --> Output Class Initialized
INFO - 2020-04-06 16:14:37 --> Security Class Initialized
DEBUG - 2020-04-06 16:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:14:37 --> CSRF cookie sent
INFO - 2020-04-06 16:14:37 --> Input Class Initialized
INFO - 2020-04-06 16:14:37 --> Language Class Initialized
INFO - 2020-04-06 16:14:37 --> Language Class Initialized
INFO - 2020-04-06 16:14:37 --> Config Class Initialized
INFO - 2020-04-06 16:14:37 --> Loader Class Initialized
INFO - 2020-04-06 16:14:37 --> Helper loaded: url_helper
INFO - 2020-04-06 16:14:37 --> Helper loaded: file_helper
INFO - 2020-04-06 16:14:37 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:14:37 --> Helper loaded: common_helper
INFO - 2020-04-06 16:14:37 --> Helper loaded: language_helper
INFO - 2020-04-06 16:14:37 --> Helper loaded: email_helper
INFO - 2020-04-06 16:14:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:14:37 --> Database Driver Class Initialized
INFO - 2020-04-06 16:14:37 --> Parser Class Initialized
INFO - 2020-04-06 16:14:37 --> User Agent Class Initialized
INFO - 2020-04-06 16:14:37 --> Model Class Initialized
INFO - 2020-04-06 16:14:37 --> Model Class Initialized
DEBUG - 2020-04-06 16:14:37 --> Template Class Initialized
INFO - 2020-04-06 16:14:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:14:37 --> Email Class Initialized
INFO - 2020-04-06 16:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:14:37 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:14:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:14:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:14:37 --> Encryption Class Initialized
INFO - 2020-04-06 16:14:37 --> Controller Class Initialized
DEBUG - 2020-04-06 16:14:37 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:14:37 --> Model Class Initialized
INFO - 2020-04-06 16:14:37 --> Config Class Initialized
INFO - 2020-04-06 16:14:37 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:14:37 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:14:38 --> Utf8 Class Initialized
INFO - 2020-04-06 16:14:38 --> URI Class Initialized
INFO - 2020-04-06 16:14:38 --> Router Class Initialized
INFO - 2020-04-06 16:14:38 --> Output Class Initialized
INFO - 2020-04-06 16:14:38 --> Security Class Initialized
DEBUG - 2020-04-06 16:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:14:38 --> CSRF cookie sent
INFO - 2020-04-06 16:14:38 --> Input Class Initialized
INFO - 2020-04-06 16:14:38 --> Language Class Initialized
INFO - 2020-04-06 16:14:38 --> Language Class Initialized
INFO - 2020-04-06 16:14:38 --> Config Class Initialized
INFO - 2020-04-06 16:14:38 --> Loader Class Initialized
INFO - 2020-04-06 16:14:38 --> Helper loaded: url_helper
INFO - 2020-04-06 16:14:38 --> Helper loaded: file_helper
INFO - 2020-04-06 16:14:38 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:14:38 --> Helper loaded: common_helper
INFO - 2020-04-06 16:14:38 --> Helper loaded: language_helper
INFO - 2020-04-06 16:14:38 --> Helper loaded: email_helper
INFO - 2020-04-06 16:14:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:14:38 --> Database Driver Class Initialized
INFO - 2020-04-06 16:14:38 --> Parser Class Initialized
INFO - 2020-04-06 16:14:38 --> User Agent Class Initialized
INFO - 2020-04-06 16:14:38 --> Model Class Initialized
INFO - 2020-04-06 16:14:38 --> Model Class Initialized
DEBUG - 2020-04-06 16:14:38 --> Template Class Initialized
INFO - 2020-04-06 16:14:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:14:38 --> Email Class Initialized
INFO - 2020-04-06 16:14:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:14:38 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:14:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:14:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:14:38 --> Encryption Class Initialized
INFO - 2020-04-06 16:14:38 --> Controller Class Initialized
DEBUG - 2020-04-06 16:14:38 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:14:38 --> Model Class Initialized
INFO - 2020-04-06 16:14:38 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:14:38 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:14:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:14:38 --> Final output sent to browser
DEBUG - 2020-04-06 16:14:38 --> Total execution time: 0.7275
INFO - 2020-04-06 16:15:27 --> Config Class Initialized
INFO - 2020-04-06 16:15:27 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:15:27 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:15:27 --> Utf8 Class Initialized
INFO - 2020-04-06 16:15:27 --> URI Class Initialized
INFO - 2020-04-06 16:15:27 --> Router Class Initialized
INFO - 2020-04-06 16:15:27 --> Output Class Initialized
INFO - 2020-04-06 16:15:27 --> Security Class Initialized
DEBUG - 2020-04-06 16:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:15:27 --> CSRF cookie sent
INFO - 2020-04-06 16:15:27 --> Input Class Initialized
INFO - 2020-04-06 16:15:27 --> Language Class Initialized
INFO - 2020-04-06 16:15:27 --> Language Class Initialized
INFO - 2020-04-06 16:15:27 --> Config Class Initialized
INFO - 2020-04-06 16:15:27 --> Loader Class Initialized
INFO - 2020-04-06 16:15:27 --> Helper loaded: url_helper
INFO - 2020-04-06 16:15:27 --> Helper loaded: file_helper
INFO - 2020-04-06 16:15:27 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:15:27 --> Helper loaded: common_helper
INFO - 2020-04-06 16:15:27 --> Helper loaded: language_helper
INFO - 2020-04-06 16:15:27 --> Helper loaded: email_helper
INFO - 2020-04-06 16:15:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:15:27 --> Database Driver Class Initialized
INFO - 2020-04-06 16:15:27 --> Parser Class Initialized
INFO - 2020-04-06 16:15:27 --> User Agent Class Initialized
INFO - 2020-04-06 16:15:27 --> Model Class Initialized
INFO - 2020-04-06 16:15:27 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:27 --> Template Class Initialized
INFO - 2020-04-06 16:15:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:15:27 --> Email Class Initialized
INFO - 2020-04-06 16:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:15:27 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:15:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:15:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:15:27 --> Encryption Class Initialized
INFO - 2020-04-06 16:15:27 --> Controller Class Initialized
DEBUG - 2020-04-06 16:15:27 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:15:27 --> Model Class Initialized
INFO - 2020-04-06 16:15:27 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:15:27 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:15:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:15:27 --> Final output sent to browser
DEBUG - 2020-04-06 16:15:27 --> Total execution time: 0.6631
INFO - 2020-04-06 16:15:37 --> Config Class Initialized
INFO - 2020-04-06 16:15:37 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:15:37 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:15:37 --> Utf8 Class Initialized
INFO - 2020-04-06 16:15:37 --> URI Class Initialized
INFO - 2020-04-06 16:15:37 --> Router Class Initialized
INFO - 2020-04-06 16:15:37 --> Output Class Initialized
INFO - 2020-04-06 16:15:37 --> Security Class Initialized
DEBUG - 2020-04-06 16:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:15:37 --> CSRF cookie sent
INFO - 2020-04-06 16:15:37 --> Input Class Initialized
INFO - 2020-04-06 16:15:37 --> Language Class Initialized
INFO - 2020-04-06 16:15:37 --> Language Class Initialized
INFO - 2020-04-06 16:15:37 --> Config Class Initialized
INFO - 2020-04-06 16:15:37 --> Loader Class Initialized
INFO - 2020-04-06 16:15:37 --> Helper loaded: url_helper
INFO - 2020-04-06 16:15:37 --> Helper loaded: file_helper
INFO - 2020-04-06 16:15:37 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:15:37 --> Helper loaded: common_helper
INFO - 2020-04-06 16:15:37 --> Helper loaded: language_helper
INFO - 2020-04-06 16:15:37 --> Helper loaded: email_helper
INFO - 2020-04-06 16:15:37 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:15:37 --> Database Driver Class Initialized
INFO - 2020-04-06 16:15:37 --> Parser Class Initialized
INFO - 2020-04-06 16:15:37 --> User Agent Class Initialized
INFO - 2020-04-06 16:15:37 --> Model Class Initialized
INFO - 2020-04-06 16:15:37 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:37 --> Template Class Initialized
INFO - 2020-04-06 16:15:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:15:37 --> Email Class Initialized
INFO - 2020-04-06 16:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:15:38 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:15:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:15:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:15:38 --> Encryption Class Initialized
INFO - 2020-04-06 16:15:38 --> Controller Class Initialized
DEBUG - 2020-04-06 16:15:38 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:15:38 --> Model Class Initialized
INFO - 2020-04-06 16:15:38 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:15:38 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:15:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:15:38 --> Final output sent to browser
DEBUG - 2020-04-06 16:15:38 --> Total execution time: 0.6593
INFO - 2020-04-06 16:15:49 --> Config Class Initialized
INFO - 2020-04-06 16:15:49 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:15:49 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:15:49 --> Utf8 Class Initialized
INFO - 2020-04-06 16:15:49 --> URI Class Initialized
INFO - 2020-04-06 16:15:49 --> Router Class Initialized
INFO - 2020-04-06 16:15:49 --> Output Class Initialized
INFO - 2020-04-06 16:15:49 --> Security Class Initialized
DEBUG - 2020-04-06 16:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:15:49 --> CSRF cookie sent
INFO - 2020-04-06 16:15:49 --> Input Class Initialized
INFO - 2020-04-06 16:15:49 --> Language Class Initialized
INFO - 2020-04-06 16:15:49 --> Language Class Initialized
INFO - 2020-04-06 16:15:49 --> Config Class Initialized
INFO - 2020-04-06 16:15:49 --> Loader Class Initialized
INFO - 2020-04-06 16:15:49 --> Helper loaded: url_helper
INFO - 2020-04-06 16:15:49 --> Helper loaded: file_helper
INFO - 2020-04-06 16:15:49 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:15:49 --> Helper loaded: common_helper
INFO - 2020-04-06 16:15:49 --> Helper loaded: language_helper
INFO - 2020-04-06 16:15:49 --> Helper loaded: email_helper
INFO - 2020-04-06 16:15:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:15:49 --> Database Driver Class Initialized
INFO - 2020-04-06 16:15:49 --> Parser Class Initialized
INFO - 2020-04-06 16:15:49 --> User Agent Class Initialized
INFO - 2020-04-06 16:15:49 --> Model Class Initialized
INFO - 2020-04-06 16:15:49 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:49 --> Template Class Initialized
INFO - 2020-04-06 16:15:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:15:49 --> Email Class Initialized
INFO - 2020-04-06 16:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:15:49 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:15:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:15:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:15:49 --> Encryption Class Initialized
INFO - 2020-04-06 16:15:49 --> Controller Class Initialized
DEBUG - 2020-04-06 16:15:49 --> users MX_Controller Initialized
INFO - 2020-04-06 16:15:49 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/users/models/users_model.php
INFO - 2020-04-06 16:15:49 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/users/views/index.php
DEBUG - 2020-04-06 16:15:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:15:49 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:15:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:15:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:15:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:15:49 --> Final output sent to browser
DEBUG - 2020-04-06 16:15:49 --> Total execution time: 0.7286
INFO - 2020-04-06 16:15:52 --> Config Class Initialized
INFO - 2020-04-06 16:15:52 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:15:52 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:15:52 --> Utf8 Class Initialized
INFO - 2020-04-06 16:15:52 --> URI Class Initialized
INFO - 2020-04-06 16:15:52 --> Router Class Initialized
INFO - 2020-04-06 16:15:52 --> Output Class Initialized
INFO - 2020-04-06 16:15:52 --> Security Class Initialized
DEBUG - 2020-04-06 16:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:15:52 --> CSRF cookie sent
INFO - 2020-04-06 16:15:52 --> Input Class Initialized
INFO - 2020-04-06 16:15:52 --> Language Class Initialized
INFO - 2020-04-06 16:15:52 --> Language Class Initialized
INFO - 2020-04-06 16:15:52 --> Config Class Initialized
INFO - 2020-04-06 16:15:53 --> Loader Class Initialized
INFO - 2020-04-06 16:15:53 --> Helper loaded: url_helper
INFO - 2020-04-06 16:15:53 --> Helper loaded: file_helper
INFO - 2020-04-06 16:15:53 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:15:53 --> Helper loaded: common_helper
INFO - 2020-04-06 16:15:53 --> Helper loaded: language_helper
INFO - 2020-04-06 16:15:53 --> Helper loaded: email_helper
INFO - 2020-04-06 16:15:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:15:53 --> Database Driver Class Initialized
INFO - 2020-04-06 16:15:53 --> Parser Class Initialized
INFO - 2020-04-06 16:15:53 --> User Agent Class Initialized
INFO - 2020-04-06 16:15:53 --> Model Class Initialized
INFO - 2020-04-06 16:15:53 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:53 --> Template Class Initialized
INFO - 2020-04-06 16:15:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:15:53 --> Email Class Initialized
INFO - 2020-04-06 16:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:15:53 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:15:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:15:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:15:53 --> Encryption Class Initialized
INFO - 2020-04-06 16:15:53 --> Controller Class Initialized
DEBUG - 2020-04-06 16:15:53 --> package MX_Controller Initialized
INFO - 2020-04-06 16:15:53 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/package/models/package_model.php
INFO - 2020-04-06 16:15:53 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/package/views/index.php
DEBUG - 2020-04-06 16:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:15:53 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:15:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:15:53 --> Final output sent to browser
DEBUG - 2020-04-06 16:15:53 --> Total execution time: 0.6645
INFO - 2020-04-06 16:15:55 --> Config Class Initialized
INFO - 2020-04-06 16:15:55 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:15:55 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:15:55 --> Utf8 Class Initialized
INFO - 2020-04-06 16:15:55 --> URI Class Initialized
INFO - 2020-04-06 16:15:55 --> Router Class Initialized
INFO - 2020-04-06 16:15:56 --> Output Class Initialized
INFO - 2020-04-06 16:15:56 --> Security Class Initialized
DEBUG - 2020-04-06 16:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:15:56 --> CSRF cookie sent
INFO - 2020-04-06 16:15:56 --> Input Class Initialized
INFO - 2020-04-06 16:15:56 --> Language Class Initialized
INFO - 2020-04-06 16:15:56 --> Language Class Initialized
INFO - 2020-04-06 16:15:56 --> Config Class Initialized
INFO - 2020-04-06 16:15:56 --> Loader Class Initialized
INFO - 2020-04-06 16:15:56 --> Helper loaded: url_helper
INFO - 2020-04-06 16:15:56 --> Helper loaded: file_helper
INFO - 2020-04-06 16:15:56 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:15:56 --> Helper loaded: common_helper
INFO - 2020-04-06 16:15:56 --> Helper loaded: language_helper
INFO - 2020-04-06 16:15:56 --> Helper loaded: email_helper
INFO - 2020-04-06 16:15:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:15:56 --> Database Driver Class Initialized
INFO - 2020-04-06 16:15:56 --> Parser Class Initialized
INFO - 2020-04-06 16:15:56 --> User Agent Class Initialized
INFO - 2020-04-06 16:15:56 --> Model Class Initialized
INFO - 2020-04-06 16:15:56 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:56 --> Template Class Initialized
INFO - 2020-04-06 16:15:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:15:56 --> Email Class Initialized
INFO - 2020-04-06 16:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:15:56 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:15:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:15:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:15:56 --> Encryption Class Initialized
INFO - 2020-04-06 16:15:56 --> Controller Class Initialized
DEBUG - 2020-04-06 16:15:56 --> transaction MX_Controller Initialized
INFO - 2020-04-06 16:15:56 --> Model Class Initialized
DEBUG - 2020-04-06 16:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/transaction/models/transaction_model.php
INFO - 2020-04-06 16:15:56 --> Model Class Initialized
INFO - 2020-04-06 16:15:56 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/transaction/views/index.php
DEBUG - 2020-04-06 16:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:15:56 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:15:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:15:56 --> Final output sent to browser
DEBUG - 2020-04-06 16:15:56 --> Total execution time: 0.7292
INFO - 2020-04-06 16:16:02 --> Config Class Initialized
INFO - 2020-04-06 16:16:02 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:16:02 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:16:02 --> Utf8 Class Initialized
INFO - 2020-04-06 16:16:02 --> URI Class Initialized
INFO - 2020-04-06 16:16:02 --> Router Class Initialized
INFO - 2020-04-06 16:16:02 --> Output Class Initialized
INFO - 2020-04-06 16:16:02 --> Security Class Initialized
DEBUG - 2020-04-06 16:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:16:02 --> CSRF cookie sent
INFO - 2020-04-06 16:16:02 --> Input Class Initialized
INFO - 2020-04-06 16:16:02 --> Language Class Initialized
INFO - 2020-04-06 16:16:02 --> Language Class Initialized
INFO - 2020-04-06 16:16:02 --> Config Class Initialized
INFO - 2020-04-06 16:16:02 --> Loader Class Initialized
INFO - 2020-04-06 16:16:02 --> Helper loaded: url_helper
INFO - 2020-04-06 16:16:02 --> Helper loaded: file_helper
INFO - 2020-04-06 16:16:02 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:16:02 --> Helper loaded: common_helper
INFO - 2020-04-06 16:16:02 --> Helper loaded: language_helper
INFO - 2020-04-06 16:16:02 --> Helper loaded: email_helper
INFO - 2020-04-06 16:16:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:16:02 --> Database Driver Class Initialized
INFO - 2020-04-06 16:16:02 --> Parser Class Initialized
INFO - 2020-04-06 16:16:02 --> User Agent Class Initialized
INFO - 2020-04-06 16:16:02 --> Model Class Initialized
INFO - 2020-04-06 16:16:02 --> Model Class Initialized
DEBUG - 2020-04-06 16:16:02 --> Template Class Initialized
INFO - 2020-04-06 16:16:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:16:02 --> Email Class Initialized
INFO - 2020-04-06 16:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:16:02 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:16:02 --> Encryption Class Initialized
INFO - 2020-04-06 16:16:02 --> Controller Class Initialized
DEBUG - 2020-04-06 16:16:02 --> language MX_Controller Initialized
INFO - 2020-04-06 16:16:02 --> Model Class Initialized
DEBUG - 2020-04-06 16:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-06 16:16:02 --> Model Class Initialized
ERROR - 2020-04-06 16:16:02 --> Could not find the language line ""
DEBUG - 2020-04-06 16:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/views/index.php
DEBUG - 2020-04-06 16:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:16:02 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:16:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:16:02 --> Final output sent to browser
DEBUG - 2020-04-06 16:16:02 --> Total execution time: 0.6819
INFO - 2020-04-06 16:16:46 --> Config Class Initialized
INFO - 2020-04-06 16:16:46 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:16:46 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:16:46 --> Utf8 Class Initialized
INFO - 2020-04-06 16:16:46 --> URI Class Initialized
INFO - 2020-04-06 16:16:46 --> Router Class Initialized
INFO - 2020-04-06 16:16:46 --> Output Class Initialized
INFO - 2020-04-06 16:16:46 --> Security Class Initialized
DEBUG - 2020-04-06 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:16:46 --> CSRF cookie sent
INFO - 2020-04-06 16:16:46 --> Input Class Initialized
INFO - 2020-04-06 16:16:46 --> Language Class Initialized
INFO - 2020-04-06 16:16:46 --> Language Class Initialized
INFO - 2020-04-06 16:16:46 --> Config Class Initialized
INFO - 2020-04-06 16:16:46 --> Loader Class Initialized
INFO - 2020-04-06 16:16:46 --> Helper loaded: url_helper
INFO - 2020-04-06 16:16:46 --> Helper loaded: file_helper
INFO - 2020-04-06 16:16:46 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:16:46 --> Helper loaded: common_helper
INFO - 2020-04-06 16:16:46 --> Helper loaded: language_helper
INFO - 2020-04-06 16:16:46 --> Helper loaded: email_helper
INFO - 2020-04-06 16:16:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:16:46 --> Database Driver Class Initialized
INFO - 2020-04-06 16:16:46 --> Parser Class Initialized
INFO - 2020-04-06 16:16:46 --> User Agent Class Initialized
INFO - 2020-04-06 16:16:46 --> Model Class Initialized
INFO - 2020-04-06 16:16:46 --> Model Class Initialized
DEBUG - 2020-04-06 16:16:46 --> Template Class Initialized
INFO - 2020-04-06 16:16:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:16:46 --> Email Class Initialized
INFO - 2020-04-06 16:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:16:46 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:16:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:16:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:16:46 --> Encryption Class Initialized
INFO - 2020-04-06 16:16:46 --> Controller Class Initialized
DEBUG - 2020-04-06 16:16:46 --> language MX_Controller Initialized
INFO - 2020-04-06 16:16:46 --> Model Class Initialized
DEBUG - 2020-04-06 16:16:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-06 16:16:46 --> Model Class Initialized
ERROR - 2020-04-06 16:16:46 --> Could not find the language line ""
DEBUG - 2020-04-06 16:16:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/views/index.php
DEBUG - 2020-04-06 16:16:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:16:46 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:16:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:16:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:16:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:16:46 --> Final output sent to browser
DEBUG - 2020-04-06 16:16:46 --> Total execution time: 0.6788
INFO - 2020-04-06 16:17:03 --> Config Class Initialized
INFO - 2020-04-06 16:17:03 --> Config Class Initialized
INFO - 2020-04-06 16:17:03 --> Config Class Initialized
INFO - 2020-04-06 16:17:03 --> Hooks Class Initialized
INFO - 2020-04-06 16:17:03 --> Hooks Class Initialized
INFO - 2020-04-06 16:17:03 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:17:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-06 16:17:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-06 16:17:03 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:17:03 --> Utf8 Class Initialized
INFO - 2020-04-06 16:17:03 --> Utf8 Class Initialized
INFO - 2020-04-06 16:17:03 --> Utf8 Class Initialized
INFO - 2020-04-06 16:17:03 --> URI Class Initialized
INFO - 2020-04-06 16:17:03 --> URI Class Initialized
INFO - 2020-04-06 16:17:03 --> URI Class Initialized
INFO - 2020-04-06 16:17:03 --> Router Class Initialized
INFO - 2020-04-06 16:17:03 --> Router Class Initialized
INFO - 2020-04-06 16:17:03 --> Router Class Initialized
INFO - 2020-04-06 16:17:03 --> Output Class Initialized
INFO - 2020-04-06 16:17:03 --> Output Class Initialized
INFO - 2020-04-06 16:17:03 --> Output Class Initialized
INFO - 2020-04-06 16:17:03 --> Security Class Initialized
INFO - 2020-04-06 16:17:03 --> Security Class Initialized
INFO - 2020-04-06 16:17:03 --> Security Class Initialized
DEBUG - 2020-04-06 16:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-06 16:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-06 16:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:17:03 --> CSRF cookie sent
INFO - 2020-04-06 16:17:03 --> CSRF cookie sent
INFO - 2020-04-06 16:17:03 --> CSRF cookie sent
INFO - 2020-04-06 16:17:03 --> Input Class Initialized
INFO - 2020-04-06 16:17:03 --> Input Class Initialized
INFO - 2020-04-06 16:17:03 --> Input Class Initialized
INFO - 2020-04-06 16:17:03 --> Language Class Initialized
INFO - 2020-04-06 16:17:03 --> Language Class Initialized
INFO - 2020-04-06 16:17:03 --> Language Class Initialized
ERROR - 2020-04-06 16:17:03 --> 404 Page Not Found: /index
ERROR - 2020-04-06 16:17:03 --> 404 Page Not Found: /index
ERROR - 2020-04-06 16:17:03 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:18:19 --> Config Class Initialized
INFO - 2020-04-06 16:18:19 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:18:19 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:18:19 --> Utf8 Class Initialized
INFO - 2020-04-06 16:18:19 --> URI Class Initialized
INFO - 2020-04-06 16:18:19 --> Router Class Initialized
INFO - 2020-04-06 16:18:19 --> Output Class Initialized
INFO - 2020-04-06 16:18:19 --> Security Class Initialized
DEBUG - 2020-04-06 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:18:19 --> CSRF cookie sent
INFO - 2020-04-06 16:18:19 --> Input Class Initialized
INFO - 2020-04-06 16:18:19 --> Language Class Initialized
INFO - 2020-04-06 16:18:19 --> Language Class Initialized
INFO - 2020-04-06 16:18:19 --> Config Class Initialized
INFO - 2020-04-06 16:18:19 --> Loader Class Initialized
INFO - 2020-04-06 16:18:19 --> Helper loaded: url_helper
INFO - 2020-04-06 16:18:19 --> Helper loaded: file_helper
INFO - 2020-04-06 16:18:19 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:18:19 --> Helper loaded: common_helper
INFO - 2020-04-06 16:18:19 --> Helper loaded: language_helper
INFO - 2020-04-06 16:18:19 --> Helper loaded: email_helper
INFO - 2020-04-06 16:18:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:18:19 --> Database Driver Class Initialized
INFO - 2020-04-06 16:18:19 --> Parser Class Initialized
INFO - 2020-04-06 16:18:19 --> User Agent Class Initialized
INFO - 2020-04-06 16:18:19 --> Model Class Initialized
INFO - 2020-04-06 16:18:19 --> Model Class Initialized
DEBUG - 2020-04-06 16:18:19 --> Template Class Initialized
INFO - 2020-04-06 16:18:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:18:19 --> Email Class Initialized
INFO - 2020-04-06 16:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:18:19 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:18:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:18:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:18:19 --> Encryption Class Initialized
INFO - 2020-04-06 16:18:19 --> Controller Class Initialized
DEBUG - 2020-04-06 16:18:19 --> language MX_Controller Initialized
INFO - 2020-04-06 16:18:19 --> Model Class Initialized
DEBUG - 2020-04-06 16:18:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-06 16:18:19 --> Model Class Initialized
ERROR - 2020-04-06 16:18:19 --> Could not find the language line ""
DEBUG - 2020-04-06 16:18:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/views/index.php
DEBUG - 2020-04-06 16:18:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:18:19 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:18:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:18:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:18:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:18:19 --> Final output sent to browser
DEBUG - 2020-04-06 16:18:19 --> Total execution time: 0.7358
INFO - 2020-04-06 16:18:20 --> Config Class Initialized
INFO - 2020-04-06 16:18:20 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:18:20 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:18:20 --> Utf8 Class Initialized
INFO - 2020-04-06 16:18:20 --> URI Class Initialized
INFO - 2020-04-06 16:18:20 --> Router Class Initialized
INFO - 2020-04-06 16:18:20 --> Output Class Initialized
INFO - 2020-04-06 16:18:20 --> Security Class Initialized
DEBUG - 2020-04-06 16:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:18:20 --> CSRF cookie sent
INFO - 2020-04-06 16:18:20 --> Input Class Initialized
INFO - 2020-04-06 16:18:20 --> Language Class Initialized
ERROR - 2020-04-06 16:18:20 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:18:20 --> Config Class Initialized
INFO - 2020-04-06 16:18:20 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:18:20 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:18:20 --> Utf8 Class Initialized
INFO - 2020-04-06 16:18:20 --> URI Class Initialized
INFO - 2020-04-06 16:18:20 --> Router Class Initialized
INFO - 2020-04-06 16:18:20 --> Output Class Initialized
INFO - 2020-04-06 16:18:20 --> Security Class Initialized
DEBUG - 2020-04-06 16:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:18:20 --> CSRF cookie sent
INFO - 2020-04-06 16:18:20 --> Input Class Initialized
INFO - 2020-04-06 16:18:20 --> Language Class Initialized
ERROR - 2020-04-06 16:18:20 --> 404 Page Not Found: /index
INFO - 2020-04-06 16:18:35 --> Config Class Initialized
INFO - 2020-04-06 16:18:35 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:18:35 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:18:35 --> Utf8 Class Initialized
INFO - 2020-04-06 16:18:35 --> URI Class Initialized
INFO - 2020-04-06 16:18:35 --> Router Class Initialized
INFO - 2020-04-06 16:18:35 --> Output Class Initialized
INFO - 2020-04-06 16:18:35 --> Security Class Initialized
DEBUG - 2020-04-06 16:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:18:35 --> CSRF cookie sent
INFO - 2020-04-06 16:18:35 --> Input Class Initialized
INFO - 2020-04-06 16:18:35 --> Language Class Initialized
INFO - 2020-04-06 16:18:35 --> Language Class Initialized
INFO - 2020-04-06 16:18:35 --> Config Class Initialized
INFO - 2020-04-06 16:18:35 --> Loader Class Initialized
INFO - 2020-04-06 16:18:35 --> Helper loaded: url_helper
INFO - 2020-04-06 16:18:35 --> Helper loaded: file_helper
INFO - 2020-04-06 16:18:35 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:18:35 --> Helper loaded: common_helper
INFO - 2020-04-06 16:18:35 --> Helper loaded: language_helper
INFO - 2020-04-06 16:18:35 --> Helper loaded: email_helper
INFO - 2020-04-06 16:18:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:18:35 --> Database Driver Class Initialized
INFO - 2020-04-06 16:18:35 --> Parser Class Initialized
INFO - 2020-04-06 16:18:35 --> User Agent Class Initialized
INFO - 2020-04-06 16:18:35 --> Model Class Initialized
INFO - 2020-04-06 16:18:35 --> Model Class Initialized
DEBUG - 2020-04-06 16:18:36 --> Template Class Initialized
INFO - 2020-04-06 16:18:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:18:36 --> Email Class Initialized
INFO - 2020-04-06 16:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:18:36 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:18:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:18:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:18:36 --> Encryption Class Initialized
INFO - 2020-04-06 16:18:36 --> Controller Class Initialized
DEBUG - 2020-04-06 16:18:36 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:18:36 --> Model Class Initialized
DEBUG - 2020-04-06 16:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:18:36 --> Model Class Initialized
INFO - 2020-04-06 16:18:36 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 16:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:18:36 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:18:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:18:36 --> Final output sent to browser
DEBUG - 2020-04-06 16:18:36 --> Total execution time: 0.6916
INFO - 2020-04-06 16:18:38 --> Config Class Initialized
INFO - 2020-04-06 16:18:38 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:18:38 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:18:38 --> Utf8 Class Initialized
INFO - 2020-04-06 16:18:38 --> URI Class Initialized
INFO - 2020-04-06 16:18:38 --> Router Class Initialized
INFO - 2020-04-06 16:18:38 --> Output Class Initialized
INFO - 2020-04-06 16:18:38 --> Security Class Initialized
DEBUG - 2020-04-06 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:18:38 --> CSRF cookie sent
INFO - 2020-04-06 16:18:38 --> Input Class Initialized
INFO - 2020-04-06 16:18:38 --> Language Class Initialized
INFO - 2020-04-06 16:18:38 --> Language Class Initialized
INFO - 2020-04-06 16:18:38 --> Config Class Initialized
INFO - 2020-04-06 16:18:38 --> Loader Class Initialized
INFO - 2020-04-06 16:18:38 --> Helper loaded: url_helper
INFO - 2020-04-06 16:18:38 --> Helper loaded: file_helper
INFO - 2020-04-06 16:18:38 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:18:38 --> Helper loaded: common_helper
INFO - 2020-04-06 16:18:38 --> Helper loaded: language_helper
INFO - 2020-04-06 16:18:38 --> Helper loaded: email_helper
INFO - 2020-04-06 16:18:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:18:38 --> Database Driver Class Initialized
INFO - 2020-04-06 16:18:38 --> Parser Class Initialized
INFO - 2020-04-06 16:18:38 --> User Agent Class Initialized
INFO - 2020-04-06 16:18:38 --> Model Class Initialized
INFO - 2020-04-06 16:18:38 --> Model Class Initialized
DEBUG - 2020-04-06 16:18:38 --> Template Class Initialized
INFO - 2020-04-06 16:18:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:18:38 --> Email Class Initialized
INFO - 2020-04-06 16:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:18:38 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:18:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:18:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:18:38 --> Encryption Class Initialized
INFO - 2020-04-06 16:18:38 --> Controller Class Initialized
DEBUG - 2020-04-06 16:18:38 --> schedule MX_Controller Initialized
INFO - 2020-04-06 16:18:38 --> Model Class Initialized
DEBUG - 2020-04-06 16:18:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/models/schedule_model.php
INFO - 2020-04-06 16:18:38 --> Model Class Initialized
DEBUG - 2020-04-06 16:18:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/views/index.php
DEBUG - 2020-04-06 16:18:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:18:39 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:18:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:18:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:18:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:18:39 --> Final output sent to browser
DEBUG - 2020-04-06 16:18:39 --> Total execution time: 0.6711
INFO - 2020-04-06 16:18:40 --> Config Class Initialized
INFO - 2020-04-06 16:18:40 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:18:40 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:18:40 --> Utf8 Class Initialized
INFO - 2020-04-06 16:18:40 --> URI Class Initialized
INFO - 2020-04-06 16:18:40 --> Router Class Initialized
INFO - 2020-04-06 16:18:40 --> Output Class Initialized
INFO - 2020-04-06 16:18:40 --> Security Class Initialized
DEBUG - 2020-04-06 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:18:40 --> CSRF cookie sent
INFO - 2020-04-06 16:18:40 --> Input Class Initialized
INFO - 2020-04-06 16:18:40 --> Language Class Initialized
INFO - 2020-04-06 16:18:40 --> Language Class Initialized
INFO - 2020-04-06 16:18:40 --> Config Class Initialized
INFO - 2020-04-06 16:18:40 --> Loader Class Initialized
INFO - 2020-04-06 16:18:40 --> Helper loaded: url_helper
INFO - 2020-04-06 16:18:40 --> Helper loaded: file_helper
INFO - 2020-04-06 16:18:40 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:18:40 --> Helper loaded: common_helper
INFO - 2020-04-06 16:18:40 --> Helper loaded: language_helper
INFO - 2020-04-06 16:18:40 --> Helper loaded: email_helper
INFO - 2020-04-06 16:18:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:18:40 --> Database Driver Class Initialized
INFO - 2020-04-06 16:18:40 --> Parser Class Initialized
INFO - 2020-04-06 16:18:40 --> User Agent Class Initialized
INFO - 2020-04-06 16:18:40 --> Model Class Initialized
INFO - 2020-04-06 16:18:40 --> Model Class Initialized
DEBUG - 2020-04-06 16:18:40 --> Template Class Initialized
INFO - 2020-04-06 16:18:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:18:40 --> Email Class Initialized
INFO - 2020-04-06 16:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:18:40 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:18:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:18:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:18:40 --> Encryption Class Initialized
INFO - 2020-04-06 16:18:40 --> Controller Class Initialized
DEBUG - 2020-04-06 16:18:40 --> post MX_Controller Initialized
INFO - 2020-04-06 16:18:40 --> Model Class Initialized
ERROR - 2020-04-06 16:18:41 --> Could not find the language line ""
ERROR - 2020-04-06 16:18:41 --> Could not find the language line ""
ERROR - 2020-04-06 16:18:41 --> Could not find the language line ""
DEBUG - 2020-04-06 16:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 16:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:18:41 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:18:41 --> Final output sent to browser
DEBUG - 2020-04-06 16:18:41 --> Total execution time: 0.7206
INFO - 2020-04-06 16:19:49 --> Config Class Initialized
INFO - 2020-04-06 16:19:49 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:19:49 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:19:49 --> Utf8 Class Initialized
INFO - 2020-04-06 16:19:49 --> URI Class Initialized
INFO - 2020-04-06 16:19:49 --> Router Class Initialized
INFO - 2020-04-06 16:19:49 --> Output Class Initialized
INFO - 2020-04-06 16:19:49 --> Security Class Initialized
DEBUG - 2020-04-06 16:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:19:49 --> CSRF cookie sent
INFO - 2020-04-06 16:19:49 --> Input Class Initialized
INFO - 2020-04-06 16:19:49 --> Language Class Initialized
INFO - 2020-04-06 16:19:49 --> Language Class Initialized
INFO - 2020-04-06 16:19:49 --> Config Class Initialized
INFO - 2020-04-06 16:19:49 --> Loader Class Initialized
INFO - 2020-04-06 16:19:49 --> Helper loaded: url_helper
INFO - 2020-04-06 16:19:49 --> Helper loaded: file_helper
INFO - 2020-04-06 16:19:49 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:19:49 --> Helper loaded: common_helper
INFO - 2020-04-06 16:19:49 --> Helper loaded: language_helper
INFO - 2020-04-06 16:19:49 --> Helper loaded: email_helper
INFO - 2020-04-06 16:19:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:19:49 --> Database Driver Class Initialized
INFO - 2020-04-06 16:19:50 --> Parser Class Initialized
INFO - 2020-04-06 16:19:50 --> User Agent Class Initialized
INFO - 2020-04-06 16:19:50 --> Model Class Initialized
INFO - 2020-04-06 16:19:50 --> Model Class Initialized
DEBUG - 2020-04-06 16:19:50 --> Template Class Initialized
INFO - 2020-04-06 16:19:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:19:50 --> Email Class Initialized
INFO - 2020-04-06 16:19:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:19:50 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:19:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:19:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:19:50 --> Encryption Class Initialized
INFO - 2020-04-06 16:19:50 --> Controller Class Initialized
DEBUG - 2020-04-06 16:19:50 --> post MX_Controller Initialized
INFO - 2020-04-06 16:19:50 --> Model Class Initialized
ERROR - 2020-04-06 16:19:50 --> Could not find the language line ""
ERROR - 2020-04-06 16:19:50 --> Could not find the language line ""
ERROR - 2020-04-06 16:19:50 --> Could not find the language line ""
DEBUG - 2020-04-06 16:19:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 16:19:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:19:50 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:19:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:19:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:19:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:19:50 --> Final output sent to browser
DEBUG - 2020-04-06 16:19:50 --> Total execution time: 0.7027
INFO - 2020-04-06 16:19:56 --> Config Class Initialized
INFO - 2020-04-06 16:19:56 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:19:56 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:19:56 --> Utf8 Class Initialized
INFO - 2020-04-06 16:19:56 --> URI Class Initialized
INFO - 2020-04-06 16:19:56 --> Router Class Initialized
INFO - 2020-04-06 16:19:56 --> Output Class Initialized
INFO - 2020-04-06 16:19:56 --> Security Class Initialized
DEBUG - 2020-04-06 16:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:19:57 --> CSRF cookie sent
INFO - 2020-04-06 16:19:57 --> Input Class Initialized
INFO - 2020-04-06 16:19:57 --> Language Class Initialized
INFO - 2020-04-06 16:19:57 --> Language Class Initialized
INFO - 2020-04-06 16:19:57 --> Config Class Initialized
INFO - 2020-04-06 16:19:57 --> Loader Class Initialized
INFO - 2020-04-06 16:19:57 --> Helper loaded: url_helper
INFO - 2020-04-06 16:19:57 --> Helper loaded: file_helper
INFO - 2020-04-06 16:19:57 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:19:57 --> Helper loaded: common_helper
INFO - 2020-04-06 16:19:57 --> Helper loaded: language_helper
INFO - 2020-04-06 16:19:57 --> Helper loaded: email_helper
INFO - 2020-04-06 16:19:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:19:57 --> Database Driver Class Initialized
INFO - 2020-04-06 16:19:57 --> Parser Class Initialized
INFO - 2020-04-06 16:19:57 --> User Agent Class Initialized
INFO - 2020-04-06 16:19:57 --> Model Class Initialized
INFO - 2020-04-06 16:19:57 --> Model Class Initialized
DEBUG - 2020-04-06 16:19:57 --> Template Class Initialized
INFO - 2020-04-06 16:19:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:19:57 --> Email Class Initialized
INFO - 2020-04-06 16:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:19:57 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:19:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:19:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:19:57 --> Encryption Class Initialized
INFO - 2020-04-06 16:19:57 --> Controller Class Initialized
DEBUG - 2020-04-06 16:19:57 --> language MX_Controller Initialized
INFO - 2020-04-06 16:19:57 --> Model Class Initialized
DEBUG - 2020-04-06 16:19:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-06 16:19:57 --> Model Class Initialized
ERROR - 2020-04-06 16:19:57 --> Could not find the language line ""
DEBUG - 2020-04-06 16:19:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/views/index.php
DEBUG - 2020-04-06 16:19:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:19:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:19:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:19:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:19:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:19:57 --> Final output sent to browser
DEBUG - 2020-04-06 16:19:57 --> Total execution time: 0.7221
INFO - 2020-04-06 16:20:14 --> Config Class Initialized
INFO - 2020-04-06 16:20:14 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:20:14 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:20:14 --> Utf8 Class Initialized
INFO - 2020-04-06 16:20:14 --> URI Class Initialized
INFO - 2020-04-06 16:20:14 --> Router Class Initialized
INFO - 2020-04-06 16:20:14 --> Output Class Initialized
INFO - 2020-04-06 16:20:14 --> Security Class Initialized
DEBUG - 2020-04-06 16:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:20:14 --> CSRF cookie sent
INFO - 2020-04-06 16:20:14 --> Input Class Initialized
INFO - 2020-04-06 16:20:14 --> Language Class Initialized
INFO - 2020-04-06 16:20:14 --> Language Class Initialized
INFO - 2020-04-06 16:20:14 --> Config Class Initialized
INFO - 2020-04-06 16:20:14 --> Loader Class Initialized
INFO - 2020-04-06 16:20:14 --> Helper loaded: url_helper
INFO - 2020-04-06 16:20:14 --> Helper loaded: file_helper
INFO - 2020-04-06 16:20:14 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:20:14 --> Helper loaded: common_helper
INFO - 2020-04-06 16:20:14 --> Helper loaded: language_helper
INFO - 2020-04-06 16:20:14 --> Helper loaded: email_helper
INFO - 2020-04-06 16:20:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:20:14 --> Database Driver Class Initialized
INFO - 2020-04-06 16:20:14 --> Parser Class Initialized
INFO - 2020-04-06 16:20:14 --> User Agent Class Initialized
INFO - 2020-04-06 16:20:14 --> Model Class Initialized
INFO - 2020-04-06 16:20:14 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:14 --> Template Class Initialized
INFO - 2020-04-06 16:20:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:20:14 --> Email Class Initialized
INFO - 2020-04-06 16:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:20:14 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:20:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:20:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:20:14 --> Encryption Class Initialized
INFO - 2020-04-06 16:20:14 --> Controller Class Initialized
DEBUG - 2020-04-06 16:20:14 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:20:15 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:20:15 --> Model Class Initialized
INFO - 2020-04-06 16:20:15 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:20:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 16:20:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:20:15 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:20:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:20:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:20:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:20:15 --> Final output sent to browser
DEBUG - 2020-04-06 16:20:15 --> Total execution time: 0.7243
INFO - 2020-04-06 16:20:16 --> Config Class Initialized
INFO - 2020-04-06 16:20:16 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:20:16 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:20:16 --> Utf8 Class Initialized
INFO - 2020-04-06 16:20:16 --> URI Class Initialized
INFO - 2020-04-06 16:20:16 --> Router Class Initialized
INFO - 2020-04-06 16:20:16 --> Output Class Initialized
INFO - 2020-04-06 16:20:16 --> Security Class Initialized
DEBUG - 2020-04-06 16:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:20:16 --> CSRF cookie sent
INFO - 2020-04-06 16:20:16 --> Input Class Initialized
INFO - 2020-04-06 16:20:16 --> Language Class Initialized
INFO - 2020-04-06 16:20:17 --> Language Class Initialized
INFO - 2020-04-06 16:20:17 --> Config Class Initialized
INFO - 2020-04-06 16:20:17 --> Loader Class Initialized
INFO - 2020-04-06 16:20:17 --> Helper loaded: url_helper
INFO - 2020-04-06 16:20:17 --> Helper loaded: file_helper
INFO - 2020-04-06 16:20:17 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:20:17 --> Helper loaded: common_helper
INFO - 2020-04-06 16:20:17 --> Helper loaded: language_helper
INFO - 2020-04-06 16:20:17 --> Helper loaded: email_helper
INFO - 2020-04-06 16:20:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:20:17 --> Database Driver Class Initialized
INFO - 2020-04-06 16:20:17 --> Parser Class Initialized
INFO - 2020-04-06 16:20:17 --> User Agent Class Initialized
INFO - 2020-04-06 16:20:17 --> Model Class Initialized
INFO - 2020-04-06 16:20:17 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:17 --> Template Class Initialized
INFO - 2020-04-06 16:20:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:20:17 --> Email Class Initialized
INFO - 2020-04-06 16:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:20:17 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:20:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:20:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:20:17 --> Encryption Class Initialized
INFO - 2020-04-06 16:20:17 --> Controller Class Initialized
DEBUG - 2020-04-06 16:20:17 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:20:17 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:20:17 --> Model Class Initialized
INFO - 2020-04-06 16:20:17 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:20:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/setting.php
DEBUG - 2020-04-06 16:20:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/content.php
DEBUG - 2020-04-06 16:20:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 16:20:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:20:17 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:20:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:20:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:20:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:20:17 --> Final output sent to browser
DEBUG - 2020-04-06 16:20:17 --> Total execution time: 0.8047
INFO - 2020-04-06 16:20:18 --> Config Class Initialized
INFO - 2020-04-06 16:20:19 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:20:19 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:20:19 --> Utf8 Class Initialized
INFO - 2020-04-06 16:20:19 --> URI Class Initialized
INFO - 2020-04-06 16:20:19 --> Router Class Initialized
INFO - 2020-04-06 16:20:19 --> Output Class Initialized
INFO - 2020-04-06 16:20:19 --> Security Class Initialized
DEBUG - 2020-04-06 16:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:20:19 --> CSRF cookie sent
INFO - 2020-04-06 16:20:19 --> CSRF token verified
INFO - 2020-04-06 16:20:19 --> Input Class Initialized
INFO - 2020-04-06 16:20:19 --> Language Class Initialized
INFO - 2020-04-06 16:20:19 --> Language Class Initialized
INFO - 2020-04-06 16:20:19 --> Config Class Initialized
INFO - 2020-04-06 16:20:19 --> Loader Class Initialized
INFO - 2020-04-06 16:20:19 --> Helper loaded: url_helper
INFO - 2020-04-06 16:20:19 --> Helper loaded: file_helper
INFO - 2020-04-06 16:20:19 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:20:19 --> Helper loaded: common_helper
INFO - 2020-04-06 16:20:19 --> Helper loaded: language_helper
INFO - 2020-04-06 16:20:19 --> Helper loaded: email_helper
INFO - 2020-04-06 16:20:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:20:19 --> Database Driver Class Initialized
INFO - 2020-04-06 16:20:19 --> Parser Class Initialized
INFO - 2020-04-06 16:20:19 --> User Agent Class Initialized
INFO - 2020-04-06 16:20:19 --> Model Class Initialized
INFO - 2020-04-06 16:20:19 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:19 --> Template Class Initialized
INFO - 2020-04-06 16:20:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:20:19 --> Email Class Initialized
INFO - 2020-04-06 16:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:20:19 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:20:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:20:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:20:19 --> Encryption Class Initialized
INFO - 2020-04-06 16:20:19 --> Controller Class Initialized
DEBUG - 2020-04-06 16:20:19 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:20:19 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:20:19 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/log.php
INFO - 2020-04-06 16:20:19 --> Final output sent to browser
DEBUG - 2020-04-06 16:20:19 --> Total execution time: 0.6431
INFO - 2020-04-06 16:20:25 --> Config Class Initialized
INFO - 2020-04-06 16:20:25 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:20:25 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:20:25 --> Utf8 Class Initialized
INFO - 2020-04-06 16:20:25 --> URI Class Initialized
INFO - 2020-04-06 16:20:25 --> Router Class Initialized
INFO - 2020-04-06 16:20:25 --> Output Class Initialized
INFO - 2020-04-06 16:20:25 --> Security Class Initialized
DEBUG - 2020-04-06 16:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:20:25 --> CSRF cookie sent
INFO - 2020-04-06 16:20:25 --> CSRF token verified
INFO - 2020-04-06 16:20:25 --> Input Class Initialized
INFO - 2020-04-06 16:20:25 --> Language Class Initialized
INFO - 2020-04-06 16:20:26 --> Language Class Initialized
INFO - 2020-04-06 16:20:26 --> Config Class Initialized
INFO - 2020-04-06 16:20:26 --> Loader Class Initialized
INFO - 2020-04-06 16:20:26 --> Helper loaded: url_helper
INFO - 2020-04-06 16:20:26 --> Helper loaded: file_helper
INFO - 2020-04-06 16:20:26 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:20:26 --> Helper loaded: common_helper
INFO - 2020-04-06 16:20:26 --> Helper loaded: language_helper
INFO - 2020-04-06 16:20:26 --> Helper loaded: email_helper
INFO - 2020-04-06 16:20:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:20:26 --> Database Driver Class Initialized
INFO - 2020-04-06 16:20:26 --> Parser Class Initialized
INFO - 2020-04-06 16:20:26 --> User Agent Class Initialized
INFO - 2020-04-06 16:20:26 --> Model Class Initialized
INFO - 2020-04-06 16:20:26 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:26 --> Template Class Initialized
INFO - 2020-04-06 16:20:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:20:26 --> Email Class Initialized
INFO - 2020-04-06 16:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:20:26 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:20:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:20:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:20:26 --> Encryption Class Initialized
INFO - 2020-04-06 16:20:26 --> Controller Class Initialized
DEBUG - 2020-04-06 16:20:26 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:20:26 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:20:26 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/log.php
INFO - 2020-04-06 16:20:26 --> Final output sent to browser
DEBUG - 2020-04-06 16:20:26 --> Total execution time: 0.6367
INFO - 2020-04-06 16:20:28 --> Config Class Initialized
INFO - 2020-04-06 16:20:28 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:20:28 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:20:28 --> Utf8 Class Initialized
INFO - 2020-04-06 16:20:28 --> URI Class Initialized
INFO - 2020-04-06 16:20:28 --> Router Class Initialized
INFO - 2020-04-06 16:20:28 --> Output Class Initialized
INFO - 2020-04-06 16:20:28 --> Security Class Initialized
DEBUG - 2020-04-06 16:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:20:28 --> CSRF cookie sent
INFO - 2020-04-06 16:20:28 --> Input Class Initialized
INFO - 2020-04-06 16:20:28 --> Language Class Initialized
INFO - 2020-04-06 16:20:28 --> Language Class Initialized
INFO - 2020-04-06 16:20:28 --> Config Class Initialized
INFO - 2020-04-06 16:20:28 --> Loader Class Initialized
INFO - 2020-04-06 16:20:28 --> Helper loaded: url_helper
INFO - 2020-04-06 16:20:28 --> Helper loaded: file_helper
INFO - 2020-04-06 16:20:28 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:20:28 --> Helper loaded: common_helper
INFO - 2020-04-06 16:20:28 --> Helper loaded: language_helper
INFO - 2020-04-06 16:20:28 --> Helper loaded: email_helper
INFO - 2020-04-06 16:20:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:20:28 --> Database Driver Class Initialized
INFO - 2020-04-06 16:20:28 --> Parser Class Initialized
INFO - 2020-04-06 16:20:28 --> User Agent Class Initialized
INFO - 2020-04-06 16:20:28 --> Model Class Initialized
INFO - 2020-04-06 16:20:28 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:28 --> Template Class Initialized
INFO - 2020-04-06 16:20:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:20:28 --> Email Class Initialized
INFO - 2020-04-06 16:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:20:28 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:20:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:20:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:20:28 --> Encryption Class Initialized
INFO - 2020-04-06 16:20:28 --> Controller Class Initialized
DEBUG - 2020-04-06 16:20:29 --> post MX_Controller Initialized
INFO - 2020-04-06 16:20:29 --> Model Class Initialized
ERROR - 2020-04-06 16:20:29 --> Could not find the language line ""
ERROR - 2020-04-06 16:20:29 --> Could not find the language line ""
ERROR - 2020-04-06 16:20:29 --> Could not find the language line ""
DEBUG - 2020-04-06 16:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 16:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:20:29 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:20:29 --> Final output sent to browser
DEBUG - 2020-04-06 16:20:29 --> Total execution time: 0.6928
INFO - 2020-04-06 16:20:30 --> Config Class Initialized
INFO - 2020-04-06 16:20:30 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:20:30 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:20:30 --> Utf8 Class Initialized
INFO - 2020-04-06 16:20:30 --> URI Class Initialized
INFO - 2020-04-06 16:20:30 --> Router Class Initialized
INFO - 2020-04-06 16:20:30 --> Output Class Initialized
INFO - 2020-04-06 16:20:30 --> Security Class Initialized
DEBUG - 2020-04-06 16:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:20:30 --> CSRF cookie sent
INFO - 2020-04-06 16:20:30 --> Input Class Initialized
INFO - 2020-04-06 16:20:30 --> Language Class Initialized
INFO - 2020-04-06 16:20:30 --> Language Class Initialized
INFO - 2020-04-06 16:20:30 --> Config Class Initialized
INFO - 2020-04-06 16:20:30 --> Loader Class Initialized
INFO - 2020-04-06 16:20:30 --> Helper loaded: url_helper
INFO - 2020-04-06 16:20:30 --> Helper loaded: file_helper
INFO - 2020-04-06 16:20:30 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:20:30 --> Helper loaded: common_helper
INFO - 2020-04-06 16:20:30 --> Helper loaded: language_helper
INFO - 2020-04-06 16:20:30 --> Helper loaded: email_helper
INFO - 2020-04-06 16:20:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:20:30 --> Database Driver Class Initialized
INFO - 2020-04-06 16:20:30 --> Parser Class Initialized
INFO - 2020-04-06 16:20:30 --> User Agent Class Initialized
INFO - 2020-04-06 16:20:31 --> Model Class Initialized
INFO - 2020-04-06 16:20:31 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:31 --> Template Class Initialized
INFO - 2020-04-06 16:20:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:20:31 --> Email Class Initialized
INFO - 2020-04-06 16:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:20:31 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:20:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:20:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:20:31 --> Encryption Class Initialized
INFO - 2020-04-06 16:20:31 --> Controller Class Initialized
DEBUG - 2020-04-06 16:20:31 --> dashboard MX_Controller Initialized
INFO - 2020-04-06 16:20:31 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-06 16:20:31 --> Model Class Initialized
INFO - 2020-04-06 16:20:31 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-06 16:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-06 16:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:20:31 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:20:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:20:31 --> Final output sent to browser
DEBUG - 2020-04-06 16:20:31 --> Total execution time: 0.7532
INFO - 2020-04-06 16:20:39 --> Config Class Initialized
INFO - 2020-04-06 16:20:39 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:20:39 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:20:39 --> Utf8 Class Initialized
INFO - 2020-04-06 16:20:39 --> URI Class Initialized
INFO - 2020-04-06 16:20:39 --> Router Class Initialized
INFO - 2020-04-06 16:20:39 --> Output Class Initialized
INFO - 2020-04-06 16:20:39 --> Security Class Initialized
DEBUG - 2020-04-06 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:20:39 --> CSRF cookie sent
INFO - 2020-04-06 16:20:39 --> CSRF token verified
INFO - 2020-04-06 16:20:39 --> Input Class Initialized
INFO - 2020-04-06 16:20:39 --> Language Class Initialized
INFO - 2020-04-06 16:20:39 --> Language Class Initialized
INFO - 2020-04-06 16:20:39 --> Config Class Initialized
INFO - 2020-04-06 16:20:39 --> Loader Class Initialized
INFO - 2020-04-06 16:20:39 --> Helper loaded: url_helper
INFO - 2020-04-06 16:20:39 --> Helper loaded: file_helper
INFO - 2020-04-06 16:20:39 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:20:39 --> Helper loaded: common_helper
INFO - 2020-04-06 16:20:39 --> Helper loaded: language_helper
INFO - 2020-04-06 16:20:39 --> Helper loaded: email_helper
INFO - 2020-04-06 16:20:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:20:39 --> Database Driver Class Initialized
INFO - 2020-04-06 16:20:39 --> Parser Class Initialized
INFO - 2020-04-06 16:20:39 --> User Agent Class Initialized
INFO - 2020-04-06 16:20:39 --> Model Class Initialized
INFO - 2020-04-06 16:20:39 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:39 --> Template Class Initialized
INFO - 2020-04-06 16:20:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:20:39 --> Email Class Initialized
INFO - 2020-04-06 16:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:20:39 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:20:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:20:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:20:39 --> Encryption Class Initialized
INFO - 2020-04-06 16:20:39 --> Controller Class Initialized
DEBUG - 2020-04-06 16:20:39 --> dashboard MX_Controller Initialized
INFO - 2020-04-06 16:20:39 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-06 16:20:39 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
INFO - 2020-04-06 16:20:39 --> Final output sent to browser
DEBUG - 2020-04-06 16:20:39 --> Total execution time: 0.6512
INFO - 2020-04-06 16:20:42 --> Config Class Initialized
INFO - 2020-04-06 16:20:42 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:20:42 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:20:42 --> Utf8 Class Initialized
INFO - 2020-04-06 16:20:42 --> URI Class Initialized
INFO - 2020-04-06 16:20:42 --> Router Class Initialized
INFO - 2020-04-06 16:20:42 --> Output Class Initialized
INFO - 2020-04-06 16:20:42 --> Security Class Initialized
DEBUG - 2020-04-06 16:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:20:42 --> CSRF cookie sent
INFO - 2020-04-06 16:20:42 --> Input Class Initialized
INFO - 2020-04-06 16:20:42 --> Language Class Initialized
INFO - 2020-04-06 16:20:42 --> Language Class Initialized
INFO - 2020-04-06 16:20:42 --> Config Class Initialized
INFO - 2020-04-06 16:20:42 --> Loader Class Initialized
INFO - 2020-04-06 16:20:42 --> Helper loaded: url_helper
INFO - 2020-04-06 16:20:42 --> Helper loaded: file_helper
INFO - 2020-04-06 16:20:42 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:20:42 --> Helper loaded: common_helper
INFO - 2020-04-06 16:20:42 --> Helper loaded: language_helper
INFO - 2020-04-06 16:20:42 --> Helper loaded: email_helper
INFO - 2020-04-06 16:20:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:20:42 --> Database Driver Class Initialized
INFO - 2020-04-06 16:20:42 --> Parser Class Initialized
INFO - 2020-04-06 16:20:42 --> User Agent Class Initialized
INFO - 2020-04-06 16:20:42 --> Model Class Initialized
INFO - 2020-04-06 16:20:42 --> Model Class Initialized
DEBUG - 2020-04-06 16:20:42 --> Template Class Initialized
INFO - 2020-04-06 16:20:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:20:42 --> Email Class Initialized
INFO - 2020-04-06 16:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:20:42 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:20:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:20:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:20:42 --> Encryption Class Initialized
INFO - 2020-04-06 16:20:42 --> Controller Class Initialized
DEBUG - 2020-04-06 16:20:42 --> post MX_Controller Initialized
INFO - 2020-04-06 16:20:42 --> Model Class Initialized
ERROR - 2020-04-06 16:20:42 --> Could not find the language line ""
ERROR - 2020-04-06 16:20:42 --> Could not find the language line ""
ERROR - 2020-04-06 16:20:42 --> Could not find the language line ""
DEBUG - 2020-04-06 16:20:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 16:20:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:20:42 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:20:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:20:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:20:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:20:42 --> Final output sent to browser
DEBUG - 2020-04-06 16:20:42 --> Total execution time: 0.7469
INFO - 2020-04-06 16:21:57 --> Config Class Initialized
INFO - 2020-04-06 16:21:57 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:21:57 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:21:57 --> Utf8 Class Initialized
INFO - 2020-04-06 16:21:57 --> URI Class Initialized
INFO - 2020-04-06 16:21:58 --> Router Class Initialized
INFO - 2020-04-06 16:21:58 --> Output Class Initialized
INFO - 2020-04-06 16:21:58 --> Security Class Initialized
DEBUG - 2020-04-06 16:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:21:58 --> CSRF cookie sent
INFO - 2020-04-06 16:21:58 --> Input Class Initialized
INFO - 2020-04-06 16:21:58 --> Language Class Initialized
INFO - 2020-04-06 16:21:58 --> Language Class Initialized
INFO - 2020-04-06 16:21:58 --> Config Class Initialized
INFO - 2020-04-06 16:21:58 --> Loader Class Initialized
INFO - 2020-04-06 16:21:58 --> Helper loaded: url_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: file_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: common_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: language_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: email_helper
INFO - 2020-04-06 16:21:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:21:58 --> Database Driver Class Initialized
INFO - 2020-04-06 16:21:58 --> Parser Class Initialized
INFO - 2020-04-06 16:21:58 --> User Agent Class Initialized
INFO - 2020-04-06 16:21:58 --> Model Class Initialized
INFO - 2020-04-06 16:21:58 --> Model Class Initialized
DEBUG - 2020-04-06 16:21:58 --> Template Class Initialized
INFO - 2020-04-06 16:21:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:21:58 --> Email Class Initialized
INFO - 2020-04-06 16:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:21:58 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:21:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:21:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:21:58 --> Encryption Class Initialized
INFO - 2020-04-06 16:21:58 --> Controller Class Initialized
DEBUG - 2020-04-06 16:21:58 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:21:58 --> Model Class Initialized
INFO - 2020-04-06 16:21:58 --> Config Class Initialized
INFO - 2020-04-06 16:21:58 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:21:58 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:21:58 --> Utf8 Class Initialized
INFO - 2020-04-06 16:21:58 --> URI Class Initialized
INFO - 2020-04-06 16:21:58 --> Router Class Initialized
INFO - 2020-04-06 16:21:58 --> Output Class Initialized
INFO - 2020-04-06 16:21:58 --> Security Class Initialized
DEBUG - 2020-04-06 16:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:21:58 --> CSRF cookie sent
INFO - 2020-04-06 16:21:58 --> Input Class Initialized
INFO - 2020-04-06 16:21:58 --> Language Class Initialized
INFO - 2020-04-06 16:21:58 --> Language Class Initialized
INFO - 2020-04-06 16:21:58 --> Config Class Initialized
INFO - 2020-04-06 16:21:58 --> Loader Class Initialized
INFO - 2020-04-06 16:21:58 --> Helper loaded: url_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: file_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: common_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: language_helper
INFO - 2020-04-06 16:21:58 --> Helper loaded: email_helper
INFO - 2020-04-06 16:21:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:21:58 --> Database Driver Class Initialized
INFO - 2020-04-06 16:21:58 --> Parser Class Initialized
INFO - 2020-04-06 16:21:58 --> User Agent Class Initialized
INFO - 2020-04-06 16:21:58 --> Model Class Initialized
INFO - 2020-04-06 16:21:58 --> Model Class Initialized
DEBUG - 2020-04-06 16:21:58 --> Template Class Initialized
INFO - 2020-04-06 16:21:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:21:58 --> Email Class Initialized
INFO - 2020-04-06 16:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:21:58 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:21:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:21:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:21:59 --> Encryption Class Initialized
INFO - 2020-04-06 16:21:59 --> Controller Class Initialized
DEBUG - 2020-04-06 16:21:59 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:21:59 --> Model Class Initialized
INFO - 2020-04-06 16:21:59 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:21:59 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:21:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:21:59 --> Final output sent to browser
DEBUG - 2020-04-06 16:21:59 --> Total execution time: 0.7142
INFO - 2020-04-06 16:22:02 --> Config Class Initialized
INFO - 2020-04-06 16:22:02 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:22:02 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:22:02 --> Utf8 Class Initialized
INFO - 2020-04-06 16:22:02 --> URI Class Initialized
INFO - 2020-04-06 16:22:02 --> Router Class Initialized
INFO - 2020-04-06 16:22:02 --> Output Class Initialized
INFO - 2020-04-06 16:22:02 --> Security Class Initialized
DEBUG - 2020-04-06 16:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:22:02 --> CSRF cookie sent
INFO - 2020-04-06 16:22:02 --> Input Class Initialized
INFO - 2020-04-06 16:22:02 --> Language Class Initialized
INFO - 2020-04-06 16:22:02 --> Language Class Initialized
INFO - 2020-04-06 16:22:02 --> Config Class Initialized
INFO - 2020-04-06 16:22:02 --> Loader Class Initialized
INFO - 2020-04-06 16:22:02 --> Helper loaded: url_helper
INFO - 2020-04-06 16:22:02 --> Helper loaded: file_helper
INFO - 2020-04-06 16:22:02 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:22:02 --> Helper loaded: common_helper
INFO - 2020-04-06 16:22:02 --> Helper loaded: language_helper
INFO - 2020-04-06 16:22:02 --> Helper loaded: email_helper
INFO - 2020-04-06 16:22:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:22:02 --> Database Driver Class Initialized
INFO - 2020-04-06 16:22:02 --> Parser Class Initialized
INFO - 2020-04-06 16:22:02 --> User Agent Class Initialized
INFO - 2020-04-06 16:22:02 --> Model Class Initialized
INFO - 2020-04-06 16:22:02 --> Model Class Initialized
DEBUG - 2020-04-06 16:22:02 --> Template Class Initialized
INFO - 2020-04-06 16:22:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:22:02 --> Email Class Initialized
INFO - 2020-04-06 16:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:22:02 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:22:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:22:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:22:02 --> Encryption Class Initialized
INFO - 2020-04-06 16:22:02 --> Controller Class Initialized
DEBUG - 2020-04-06 16:22:02 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:22:02 --> Model Class Initialized
DEBUG - 2020-04-06 16:22:02 --> module MX_Controller Initialized
INFO - 2020-04-06 16:22:04 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 16:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:22:04 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:22:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:22:04 --> Final output sent to browser
DEBUG - 2020-04-06 16:22:04 --> Total execution time: 2.0738
INFO - 2020-04-06 16:22:35 --> Config Class Initialized
INFO - 2020-04-06 16:22:35 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:22:35 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:22:35 --> Utf8 Class Initialized
INFO - 2020-04-06 16:22:35 --> URI Class Initialized
INFO - 2020-04-06 16:22:35 --> Router Class Initialized
INFO - 2020-04-06 16:22:35 --> Output Class Initialized
INFO - 2020-04-06 16:22:35 --> Security Class Initialized
DEBUG - 2020-04-06 16:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:22:35 --> CSRF cookie sent
INFO - 2020-04-06 16:22:35 --> Input Class Initialized
INFO - 2020-04-06 16:22:35 --> Language Class Initialized
INFO - 2020-04-06 16:22:35 --> Language Class Initialized
INFO - 2020-04-06 16:22:35 --> Config Class Initialized
INFO - 2020-04-06 16:22:35 --> Loader Class Initialized
INFO - 2020-04-06 16:22:35 --> Helper loaded: url_helper
INFO - 2020-04-06 16:22:35 --> Helper loaded: file_helper
INFO - 2020-04-06 16:22:35 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:22:35 --> Helper loaded: common_helper
INFO - 2020-04-06 16:22:35 --> Helper loaded: language_helper
INFO - 2020-04-06 16:22:35 --> Helper loaded: email_helper
INFO - 2020-04-06 16:22:36 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:22:36 --> Database Driver Class Initialized
INFO - 2020-04-06 16:22:36 --> Parser Class Initialized
INFO - 2020-04-06 16:22:36 --> User Agent Class Initialized
INFO - 2020-04-06 16:22:36 --> Model Class Initialized
INFO - 2020-04-06 16:22:36 --> Model Class Initialized
DEBUG - 2020-04-06 16:22:36 --> Template Class Initialized
INFO - 2020-04-06 16:22:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:22:36 --> Email Class Initialized
INFO - 2020-04-06 16:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:22:36 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:22:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:22:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:22:36 --> Encryption Class Initialized
INFO - 2020-04-06 16:22:36 --> Controller Class Initialized
DEBUG - 2020-04-06 16:22:36 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:22:36 --> Model Class Initialized
INFO - 2020-04-06 16:22:36 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:22:36 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:22:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:22:36 --> Final output sent to browser
DEBUG - 2020-04-06 16:22:36 --> Total execution time: 0.6921
INFO - 2020-04-06 16:22:37 --> Config Class Initialized
INFO - 2020-04-06 16:22:37 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:22:37 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:22:37 --> Utf8 Class Initialized
INFO - 2020-04-06 16:22:37 --> URI Class Initialized
INFO - 2020-04-06 16:22:37 --> Router Class Initialized
INFO - 2020-04-06 16:22:37 --> Output Class Initialized
INFO - 2020-04-06 16:22:37 --> Security Class Initialized
DEBUG - 2020-04-06 16:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:22:37 --> CSRF cookie sent
INFO - 2020-04-06 16:22:37 --> Input Class Initialized
INFO - 2020-04-06 16:22:37 --> Language Class Initialized
INFO - 2020-04-06 16:22:37 --> Language Class Initialized
INFO - 2020-04-06 16:22:38 --> Config Class Initialized
INFO - 2020-04-06 16:22:38 --> Loader Class Initialized
INFO - 2020-04-06 16:22:38 --> Helper loaded: url_helper
INFO - 2020-04-06 16:22:38 --> Helper loaded: file_helper
INFO - 2020-04-06 16:22:38 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:22:38 --> Helper loaded: common_helper
INFO - 2020-04-06 16:22:38 --> Helper loaded: language_helper
INFO - 2020-04-06 16:22:38 --> Helper loaded: email_helper
INFO - 2020-04-06 16:22:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:22:38 --> Database Driver Class Initialized
INFO - 2020-04-06 16:22:38 --> Parser Class Initialized
INFO - 2020-04-06 16:22:38 --> User Agent Class Initialized
INFO - 2020-04-06 16:22:38 --> Model Class Initialized
INFO - 2020-04-06 16:22:38 --> Model Class Initialized
DEBUG - 2020-04-06 16:22:38 --> Template Class Initialized
INFO - 2020-04-06 16:22:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:22:38 --> Email Class Initialized
INFO - 2020-04-06 16:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:22:38 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:22:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:22:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:22:38 --> Encryption Class Initialized
INFO - 2020-04-06 16:22:38 --> Controller Class Initialized
DEBUG - 2020-04-06 16:22:38 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:22:38 --> Model Class Initialized
INFO - 2020-04-06 16:22:38 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/default_settings.php
DEBUG - 2020-04-06 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:22:38 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:22:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:22:38 --> Final output sent to browser
DEBUG - 2020-04-06 16:22:38 --> Total execution time: 0.8810
INFO - 2020-04-06 16:22:40 --> Config Class Initialized
INFO - 2020-04-06 16:22:40 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:22:40 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:22:40 --> Utf8 Class Initialized
INFO - 2020-04-06 16:22:40 --> URI Class Initialized
INFO - 2020-04-06 16:22:40 --> Router Class Initialized
INFO - 2020-04-06 16:22:40 --> Output Class Initialized
INFO - 2020-04-06 16:22:40 --> Security Class Initialized
DEBUG - 2020-04-06 16:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:22:40 --> CSRF cookie sent
INFO - 2020-04-06 16:22:40 --> Input Class Initialized
INFO - 2020-04-06 16:22:40 --> Language Class Initialized
INFO - 2020-04-06 16:22:40 --> Language Class Initialized
INFO - 2020-04-06 16:22:40 --> Config Class Initialized
INFO - 2020-04-06 16:22:40 --> Loader Class Initialized
INFO - 2020-04-06 16:22:40 --> Helper loaded: url_helper
INFO - 2020-04-06 16:22:40 --> Helper loaded: file_helper
INFO - 2020-04-06 16:22:40 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:22:40 --> Helper loaded: common_helper
INFO - 2020-04-06 16:22:40 --> Helper loaded: language_helper
INFO - 2020-04-06 16:22:40 --> Helper loaded: email_helper
INFO - 2020-04-06 16:22:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:22:40 --> Database Driver Class Initialized
INFO - 2020-04-06 16:22:40 --> Parser Class Initialized
INFO - 2020-04-06 16:22:40 --> User Agent Class Initialized
INFO - 2020-04-06 16:22:40 --> Model Class Initialized
INFO - 2020-04-06 16:22:40 --> Model Class Initialized
DEBUG - 2020-04-06 16:22:40 --> Template Class Initialized
INFO - 2020-04-06 16:22:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:22:40 --> Email Class Initialized
INFO - 2020-04-06 16:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:22:40 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:22:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:22:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:22:40 --> Encryption Class Initialized
INFO - 2020-04-06 16:22:40 --> Controller Class Initialized
DEBUG - 2020-04-06 16:22:40 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:22:40 --> Model Class Initialized
INFO - 2020-04-06 16:22:40 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:22:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/other.php
DEBUG - 2020-04-06 16:22:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:22:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:22:40 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:22:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:22:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:22:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:22:40 --> Final output sent to browser
DEBUG - 2020-04-06 16:22:40 --> Total execution time: 0.7092
INFO - 2020-04-06 16:22:43 --> Config Class Initialized
INFO - 2020-04-06 16:22:43 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:22:43 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:22:43 --> Utf8 Class Initialized
INFO - 2020-04-06 16:22:43 --> URI Class Initialized
INFO - 2020-04-06 16:22:43 --> Router Class Initialized
INFO - 2020-04-06 16:22:43 --> Output Class Initialized
INFO - 2020-04-06 16:22:43 --> Security Class Initialized
DEBUG - 2020-04-06 16:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:22:43 --> CSRF cookie sent
INFO - 2020-04-06 16:22:43 --> Input Class Initialized
INFO - 2020-04-06 16:22:43 --> Language Class Initialized
INFO - 2020-04-06 16:22:43 --> Language Class Initialized
INFO - 2020-04-06 16:22:43 --> Config Class Initialized
INFO - 2020-04-06 16:22:44 --> Loader Class Initialized
INFO - 2020-04-06 16:22:44 --> Helper loaded: url_helper
INFO - 2020-04-06 16:22:44 --> Helper loaded: file_helper
INFO - 2020-04-06 16:22:44 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:22:44 --> Helper loaded: common_helper
INFO - 2020-04-06 16:22:44 --> Helper loaded: language_helper
INFO - 2020-04-06 16:22:44 --> Helper loaded: email_helper
INFO - 2020-04-06 16:22:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:22:44 --> Database Driver Class Initialized
INFO - 2020-04-06 16:22:44 --> Parser Class Initialized
INFO - 2020-04-06 16:22:44 --> User Agent Class Initialized
INFO - 2020-04-06 16:22:44 --> Model Class Initialized
INFO - 2020-04-06 16:22:44 --> Model Class Initialized
DEBUG - 2020-04-06 16:22:44 --> Template Class Initialized
INFO - 2020-04-06 16:22:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:22:44 --> Email Class Initialized
INFO - 2020-04-06 16:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:22:44 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:22:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:22:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:22:44 --> Encryption Class Initialized
INFO - 2020-04-06 16:22:44 --> Controller Class Initialized
DEBUG - 2020-04-06 16:22:44 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:22:44 --> Model Class Initialized
INFO - 2020-04-06 16:22:44 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:22:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/email_smtp.php
DEBUG - 2020-04-06 16:22:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:22:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:22:44 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:22:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:22:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:22:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:22:44 --> Final output sent to browser
DEBUG - 2020-04-06 16:22:44 --> Total execution time: 0.7417
INFO - 2020-04-06 16:22:46 --> Config Class Initialized
INFO - 2020-04-06 16:22:46 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:22:46 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:22:46 --> Utf8 Class Initialized
INFO - 2020-04-06 16:22:46 --> URI Class Initialized
INFO - 2020-04-06 16:22:46 --> Router Class Initialized
INFO - 2020-04-06 16:22:46 --> Output Class Initialized
INFO - 2020-04-06 16:22:46 --> Security Class Initialized
DEBUG - 2020-04-06 16:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:22:46 --> CSRF cookie sent
INFO - 2020-04-06 16:22:46 --> Input Class Initialized
INFO - 2020-04-06 16:22:46 --> Language Class Initialized
INFO - 2020-04-06 16:22:46 --> Language Class Initialized
INFO - 2020-04-06 16:22:46 --> Config Class Initialized
INFO - 2020-04-06 16:22:46 --> Loader Class Initialized
INFO - 2020-04-06 16:22:46 --> Helper loaded: url_helper
INFO - 2020-04-06 16:22:46 --> Helper loaded: file_helper
INFO - 2020-04-06 16:22:46 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:22:46 --> Helper loaded: common_helper
INFO - 2020-04-06 16:22:46 --> Helper loaded: language_helper
INFO - 2020-04-06 16:22:46 --> Helper loaded: email_helper
INFO - 2020-04-06 16:22:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:22:46 --> Database Driver Class Initialized
INFO - 2020-04-06 16:22:46 --> Parser Class Initialized
INFO - 2020-04-06 16:22:46 --> User Agent Class Initialized
INFO - 2020-04-06 16:22:46 --> Model Class Initialized
INFO - 2020-04-06 16:22:46 --> Model Class Initialized
DEBUG - 2020-04-06 16:22:46 --> Template Class Initialized
INFO - 2020-04-06 16:22:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:22:46 --> Email Class Initialized
INFO - 2020-04-06 16:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:22:46 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:22:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:22:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:22:46 --> Encryption Class Initialized
INFO - 2020-04-06 16:22:46 --> Controller Class Initialized
DEBUG - 2020-04-06 16:22:46 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:22:46 --> Model Class Initialized
INFO - 2020-04-06 16:22:46 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/email_template.php
DEBUG - 2020-04-06 16:22:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:22:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:22:47 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:22:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:22:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:22:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:22:47 --> Final output sent to browser
DEBUG - 2020-04-06 16:22:47 --> Total execution time: 0.7187
INFO - 2020-04-06 16:22:48 --> Config Class Initialized
INFO - 2020-04-06 16:22:48 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:22:48 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:22:48 --> Utf8 Class Initialized
INFO - 2020-04-06 16:22:48 --> URI Class Initialized
INFO - 2020-04-06 16:22:48 --> Router Class Initialized
INFO - 2020-04-06 16:22:48 --> Output Class Initialized
INFO - 2020-04-06 16:22:48 --> Security Class Initialized
DEBUG - 2020-04-06 16:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:22:48 --> CSRF cookie sent
INFO - 2020-04-06 16:22:48 --> Input Class Initialized
INFO - 2020-04-06 16:22:48 --> Language Class Initialized
INFO - 2020-04-06 16:22:48 --> Language Class Initialized
INFO - 2020-04-06 16:22:49 --> Config Class Initialized
INFO - 2020-04-06 16:22:49 --> Loader Class Initialized
INFO - 2020-04-06 16:22:49 --> Helper loaded: url_helper
INFO - 2020-04-06 16:22:49 --> Helper loaded: file_helper
INFO - 2020-04-06 16:22:49 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:22:49 --> Helper loaded: common_helper
INFO - 2020-04-06 16:22:49 --> Helper loaded: language_helper
INFO - 2020-04-06 16:22:49 --> Helper loaded: email_helper
INFO - 2020-04-06 16:22:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:22:49 --> Database Driver Class Initialized
INFO - 2020-04-06 16:22:49 --> Parser Class Initialized
INFO - 2020-04-06 16:22:49 --> User Agent Class Initialized
INFO - 2020-04-06 16:22:49 --> Model Class Initialized
INFO - 2020-04-06 16:22:49 --> Model Class Initialized
DEBUG - 2020-04-06 16:22:49 --> Template Class Initialized
INFO - 2020-04-06 16:22:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:22:49 --> Email Class Initialized
INFO - 2020-04-06 16:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:22:49 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:22:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:22:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:22:49 --> Encryption Class Initialized
INFO - 2020-04-06 16:22:49 --> Controller Class Initialized
DEBUG - 2020-04-06 16:22:49 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:22:49 --> Model Class Initialized
INFO - 2020-04-06 16:22:49 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:22:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/email_smtp.php
DEBUG - 2020-04-06 16:22:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:22:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:22:49 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:22:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:22:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:22:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:22:49 --> Final output sent to browser
DEBUG - 2020-04-06 16:22:49 --> Total execution time: 0.7450
INFO - 2020-04-06 16:22:56 --> Config Class Initialized
INFO - 2020-04-06 16:22:56 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:22:56 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:22:56 --> Utf8 Class Initialized
INFO - 2020-04-06 16:22:56 --> URI Class Initialized
INFO - 2020-04-06 16:22:56 --> Router Class Initialized
INFO - 2020-04-06 16:22:56 --> Output Class Initialized
INFO - 2020-04-06 16:22:57 --> Security Class Initialized
DEBUG - 2020-04-06 16:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:22:57 --> CSRF cookie sent
INFO - 2020-04-06 16:22:57 --> Input Class Initialized
INFO - 2020-04-06 16:22:57 --> Language Class Initialized
INFO - 2020-04-06 16:22:57 --> Language Class Initialized
INFO - 2020-04-06 16:22:57 --> Config Class Initialized
INFO - 2020-04-06 16:22:57 --> Loader Class Initialized
INFO - 2020-04-06 16:22:57 --> Helper loaded: url_helper
INFO - 2020-04-06 16:22:57 --> Helper loaded: file_helper
INFO - 2020-04-06 16:22:57 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:22:57 --> Helper loaded: common_helper
INFO - 2020-04-06 16:22:57 --> Helper loaded: language_helper
INFO - 2020-04-06 16:22:57 --> Helper loaded: email_helper
INFO - 2020-04-06 16:22:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:22:57 --> Database Driver Class Initialized
INFO - 2020-04-06 16:22:57 --> Parser Class Initialized
INFO - 2020-04-06 16:22:57 --> User Agent Class Initialized
INFO - 2020-04-06 16:22:57 --> Model Class Initialized
INFO - 2020-04-06 16:22:57 --> Model Class Initialized
DEBUG - 2020-04-06 16:22:57 --> Template Class Initialized
INFO - 2020-04-06 16:22:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:22:57 --> Email Class Initialized
INFO - 2020-04-06 16:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:22:57 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:22:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:22:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:22:57 --> Encryption Class Initialized
INFO - 2020-04-06 16:22:57 --> Controller Class Initialized
DEBUG - 2020-04-06 16:22:57 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:22:57 --> Model Class Initialized
INFO - 2020-04-06 16:22:57 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/email_template.php
DEBUG - 2020-04-06 16:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:22:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:22:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:22:57 --> Final output sent to browser
DEBUG - 2020-04-06 16:22:57 --> Total execution time: 0.7428
INFO - 2020-04-06 16:30:46 --> Config Class Initialized
INFO - 2020-04-06 16:30:46 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:30:46 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:30:46 --> Utf8 Class Initialized
INFO - 2020-04-06 16:30:46 --> URI Class Initialized
INFO - 2020-04-06 16:30:46 --> Router Class Initialized
INFO - 2020-04-06 16:30:46 --> Output Class Initialized
INFO - 2020-04-06 16:30:46 --> Security Class Initialized
DEBUG - 2020-04-06 16:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:30:46 --> CSRF cookie sent
INFO - 2020-04-06 16:30:46 --> Input Class Initialized
INFO - 2020-04-06 16:30:46 --> Language Class Initialized
INFO - 2020-04-06 16:30:46 --> Language Class Initialized
INFO - 2020-04-06 16:30:46 --> Config Class Initialized
INFO - 2020-04-06 16:30:46 --> Loader Class Initialized
INFO - 2020-04-06 16:30:46 --> Helper loaded: url_helper
INFO - 2020-04-06 16:30:46 --> Helper loaded: file_helper
INFO - 2020-04-06 16:30:46 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:30:46 --> Helper loaded: common_helper
INFO - 2020-04-06 16:30:46 --> Helper loaded: language_helper
INFO - 2020-04-06 16:30:46 --> Helper loaded: email_helper
INFO - 2020-04-06 16:30:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:30:46 --> Database Driver Class Initialized
INFO - 2020-04-06 16:30:46 --> Parser Class Initialized
INFO - 2020-04-06 16:30:46 --> User Agent Class Initialized
INFO - 2020-04-06 16:30:46 --> Model Class Initialized
INFO - 2020-04-06 16:30:46 --> Model Class Initialized
DEBUG - 2020-04-06 16:30:46 --> Template Class Initialized
INFO - 2020-04-06 16:30:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:30:46 --> Email Class Initialized
INFO - 2020-04-06 16:30:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:30:46 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:30:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:30:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:30:46 --> Encryption Class Initialized
INFO - 2020-04-06 16:30:46 --> Controller Class Initialized
DEBUG - 2020-04-06 16:30:46 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:30:46 --> Model Class Initialized
INFO - 2020-04-06 16:30:46 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:30:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/email_template.php
DEBUG - 2020-04-06 16:30:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:30:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:30:46 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:30:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:30:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:30:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:30:46 --> Final output sent to browser
DEBUG - 2020-04-06 16:30:46 --> Total execution time: 0.8328
INFO - 2020-04-06 16:54:23 --> Config Class Initialized
INFO - 2020-04-06 16:54:23 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:54:23 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:54:23 --> Utf8 Class Initialized
INFO - 2020-04-06 16:54:23 --> URI Class Initialized
INFO - 2020-04-06 16:54:23 --> Router Class Initialized
INFO - 2020-04-06 16:54:23 --> Output Class Initialized
INFO - 2020-04-06 16:54:23 --> Security Class Initialized
DEBUG - 2020-04-06 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:54:23 --> CSRF cookie sent
INFO - 2020-04-06 16:54:23 --> Input Class Initialized
INFO - 2020-04-06 16:54:23 --> Language Class Initialized
INFO - 2020-04-06 16:54:23 --> Language Class Initialized
INFO - 2020-04-06 16:54:23 --> Config Class Initialized
INFO - 2020-04-06 16:54:23 --> Loader Class Initialized
INFO - 2020-04-06 16:54:23 --> Helper loaded: url_helper
INFO - 2020-04-06 16:54:23 --> Helper loaded: file_helper
INFO - 2020-04-06 16:54:23 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:54:23 --> Helper loaded: common_helper
INFO - 2020-04-06 16:54:23 --> Helper loaded: language_helper
INFO - 2020-04-06 16:54:23 --> Helper loaded: email_helper
INFO - 2020-04-06 16:54:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:54:23 --> Database Driver Class Initialized
INFO - 2020-04-06 16:54:23 --> Parser Class Initialized
INFO - 2020-04-06 16:54:23 --> User Agent Class Initialized
INFO - 2020-04-06 16:54:23 --> Model Class Initialized
INFO - 2020-04-06 16:54:23 --> Model Class Initialized
DEBUG - 2020-04-06 16:54:23 --> Template Class Initialized
INFO - 2020-04-06 16:54:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:54:23 --> Email Class Initialized
INFO - 2020-04-06 16:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:54:23 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:54:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:54:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:54:23 --> Encryption Class Initialized
INFO - 2020-04-06 16:54:23 --> Controller Class Initialized
DEBUG - 2020-04-06 16:54:23 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:54:23 --> Model Class Initialized
INFO - 2020-04-06 16:54:23 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:54:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:54:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:54:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:54:24 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:54:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:54:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:54:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:54:24 --> Final output sent to browser
DEBUG - 2020-04-06 16:54:24 --> Total execution time: 0.8246
INFO - 2020-04-06 16:54:26 --> Config Class Initialized
INFO - 2020-04-06 16:54:26 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:54:26 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:54:26 --> Utf8 Class Initialized
INFO - 2020-04-06 16:54:26 --> URI Class Initialized
INFO - 2020-04-06 16:54:26 --> Router Class Initialized
INFO - 2020-04-06 16:54:26 --> Output Class Initialized
INFO - 2020-04-06 16:54:26 --> Security Class Initialized
DEBUG - 2020-04-06 16:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:54:26 --> CSRF cookie sent
INFO - 2020-04-06 16:54:26 --> Input Class Initialized
INFO - 2020-04-06 16:54:26 --> Language Class Initialized
INFO - 2020-04-06 16:54:26 --> Language Class Initialized
INFO - 2020-04-06 16:54:26 --> Config Class Initialized
INFO - 2020-04-06 16:54:26 --> Loader Class Initialized
INFO - 2020-04-06 16:54:26 --> Helper loaded: url_helper
INFO - 2020-04-06 16:54:26 --> Helper loaded: file_helper
INFO - 2020-04-06 16:54:26 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:54:26 --> Helper loaded: common_helper
INFO - 2020-04-06 16:54:26 --> Helper loaded: language_helper
INFO - 2020-04-06 16:54:26 --> Helper loaded: email_helper
INFO - 2020-04-06 16:54:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:54:26 --> Database Driver Class Initialized
INFO - 2020-04-06 16:54:26 --> Parser Class Initialized
INFO - 2020-04-06 16:54:26 --> User Agent Class Initialized
INFO - 2020-04-06 16:54:26 --> Model Class Initialized
INFO - 2020-04-06 16:54:26 --> Model Class Initialized
DEBUG - 2020-04-06 16:54:26 --> Template Class Initialized
INFO - 2020-04-06 16:54:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:54:26 --> Email Class Initialized
INFO - 2020-04-06 16:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:54:26 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:54:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:54:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:54:26 --> Encryption Class Initialized
INFO - 2020-04-06 16:54:26 --> Controller Class Initialized
DEBUG - 2020-04-06 16:54:26 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:54:26 --> Model Class Initialized
INFO - 2020-04-06 16:54:26 --> Helper loaded: inflector_helper
ERROR - 2020-04-06 16:54:26 --> Could not find the language line "Other"
DEBUG - 2020-04-06 16:54:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/other.php
DEBUG - 2020-04-06 16:54:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:54:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:54:26 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:54:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:54:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:54:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:54:26 --> Final output sent to browser
DEBUG - 2020-04-06 16:54:26 --> Total execution time: 0.8551
INFO - 2020-04-06 16:54:28 --> Config Class Initialized
INFO - 2020-04-06 16:54:28 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:54:28 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:54:28 --> Utf8 Class Initialized
INFO - 2020-04-06 16:54:28 --> URI Class Initialized
INFO - 2020-04-06 16:54:28 --> Router Class Initialized
INFO - 2020-04-06 16:54:28 --> Output Class Initialized
INFO - 2020-04-06 16:54:28 --> Security Class Initialized
DEBUG - 2020-04-06 16:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:54:28 --> CSRF cookie sent
INFO - 2020-04-06 16:54:28 --> Input Class Initialized
INFO - 2020-04-06 16:54:28 --> Language Class Initialized
INFO - 2020-04-06 16:54:28 --> Language Class Initialized
INFO - 2020-04-06 16:54:28 --> Config Class Initialized
INFO - 2020-04-06 16:54:28 --> Loader Class Initialized
INFO - 2020-04-06 16:54:28 --> Helper loaded: url_helper
INFO - 2020-04-06 16:54:28 --> Helper loaded: file_helper
INFO - 2020-04-06 16:54:28 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:54:28 --> Helper loaded: common_helper
INFO - 2020-04-06 16:54:28 --> Helper loaded: language_helper
INFO - 2020-04-06 16:54:28 --> Helper loaded: email_helper
INFO - 2020-04-06 16:54:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:54:28 --> Database Driver Class Initialized
INFO - 2020-04-06 16:54:28 --> Parser Class Initialized
INFO - 2020-04-06 16:54:28 --> User Agent Class Initialized
INFO - 2020-04-06 16:54:28 --> Model Class Initialized
INFO - 2020-04-06 16:54:29 --> Model Class Initialized
DEBUG - 2020-04-06 16:54:29 --> Template Class Initialized
INFO - 2020-04-06 16:54:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:54:29 --> Email Class Initialized
INFO - 2020-04-06 16:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:54:29 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:54:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:54:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:54:29 --> Encryption Class Initialized
INFO - 2020-04-06 16:54:29 --> Controller Class Initialized
DEBUG - 2020-04-06 16:54:29 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:54:29 --> Model Class Initialized
INFO - 2020-04-06 16:54:29 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:54:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/default_settings.php
DEBUG - 2020-04-06 16:54:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:54:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:54:29 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:54:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:54:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:54:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:54:29 --> Final output sent to browser
DEBUG - 2020-04-06 16:54:29 --> Total execution time: 1.0001
INFO - 2020-04-06 16:54:30 --> Config Class Initialized
INFO - 2020-04-06 16:54:30 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:54:30 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:54:30 --> Utf8 Class Initialized
INFO - 2020-04-06 16:54:30 --> URI Class Initialized
INFO - 2020-04-06 16:54:30 --> Router Class Initialized
INFO - 2020-04-06 16:54:30 --> Output Class Initialized
INFO - 2020-04-06 16:54:30 --> Security Class Initialized
DEBUG - 2020-04-06 16:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:54:30 --> CSRF cookie sent
INFO - 2020-04-06 16:54:30 --> Input Class Initialized
INFO - 2020-04-06 16:54:30 --> Language Class Initialized
INFO - 2020-04-06 16:54:30 --> Language Class Initialized
INFO - 2020-04-06 16:54:30 --> Config Class Initialized
INFO - 2020-04-06 16:54:30 --> Loader Class Initialized
INFO - 2020-04-06 16:54:30 --> Helper loaded: url_helper
INFO - 2020-04-06 16:54:30 --> Helper loaded: file_helper
INFO - 2020-04-06 16:54:30 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:54:30 --> Helper loaded: common_helper
INFO - 2020-04-06 16:54:30 --> Helper loaded: language_helper
INFO - 2020-04-06 16:54:30 --> Helper loaded: email_helper
INFO - 2020-04-06 16:54:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:54:30 --> Database Driver Class Initialized
INFO - 2020-04-06 16:54:30 --> Parser Class Initialized
INFO - 2020-04-06 16:54:30 --> User Agent Class Initialized
INFO - 2020-04-06 16:54:30 --> Model Class Initialized
INFO - 2020-04-06 16:54:30 --> Model Class Initialized
DEBUG - 2020-04-06 16:54:30 --> Template Class Initialized
INFO - 2020-04-06 16:54:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:54:31 --> Email Class Initialized
INFO - 2020-04-06 16:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:54:31 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:54:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:54:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:54:31 --> Encryption Class Initialized
INFO - 2020-04-06 16:54:31 --> Controller Class Initialized
DEBUG - 2020-04-06 16:54:31 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:54:31 --> Model Class Initialized
INFO - 2020-04-06 16:54:31 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:54:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:54:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:54:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:54:31 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:54:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:54:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:54:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:54:31 --> Final output sent to browser
DEBUG - 2020-04-06 16:54:31 --> Total execution time: 0.8264
INFO - 2020-04-06 16:57:51 --> Config Class Initialized
INFO - 2020-04-06 16:57:51 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:57:51 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:57:51 --> Utf8 Class Initialized
INFO - 2020-04-06 16:57:51 --> URI Class Initialized
INFO - 2020-04-06 16:57:52 --> Router Class Initialized
INFO - 2020-04-06 16:57:52 --> Output Class Initialized
INFO - 2020-04-06 16:57:52 --> Security Class Initialized
DEBUG - 2020-04-06 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:57:52 --> CSRF cookie sent
INFO - 2020-04-06 16:57:52 --> Input Class Initialized
INFO - 2020-04-06 16:57:52 --> Language Class Initialized
INFO - 2020-04-06 16:57:52 --> Language Class Initialized
INFO - 2020-04-06 16:57:52 --> Config Class Initialized
INFO - 2020-04-06 16:57:52 --> Loader Class Initialized
INFO - 2020-04-06 16:57:52 --> Helper loaded: url_helper
INFO - 2020-04-06 16:57:52 --> Helper loaded: file_helper
INFO - 2020-04-06 16:57:52 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:57:52 --> Helper loaded: common_helper
INFO - 2020-04-06 16:57:52 --> Helper loaded: language_helper
INFO - 2020-04-06 16:57:52 --> Helper loaded: email_helper
INFO - 2020-04-06 16:57:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:57:52 --> Database Driver Class Initialized
INFO - 2020-04-06 16:57:52 --> Parser Class Initialized
INFO - 2020-04-06 16:57:52 --> User Agent Class Initialized
INFO - 2020-04-06 16:57:52 --> Model Class Initialized
INFO - 2020-04-06 16:57:52 --> Model Class Initialized
DEBUG - 2020-04-06 16:57:52 --> Template Class Initialized
INFO - 2020-04-06 16:57:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:57:52 --> Email Class Initialized
INFO - 2020-04-06 16:57:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:57:52 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:57:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:57:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:57:52 --> Encryption Class Initialized
INFO - 2020-04-06 16:57:52 --> Controller Class Initialized
DEBUG - 2020-04-06 16:57:52 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:57:52 --> Model Class Initialized
INFO - 2020-04-06 16:57:52 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:57:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:57:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:57:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:57:52 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:57:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:57:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:57:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:57:52 --> Final output sent to browser
DEBUG - 2020-04-06 16:57:52 --> Total execution time: 0.8542
INFO - 2020-04-06 16:57:54 --> Config Class Initialized
INFO - 2020-04-06 16:57:54 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:57:54 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:57:54 --> Utf8 Class Initialized
INFO - 2020-04-06 16:57:54 --> URI Class Initialized
INFO - 2020-04-06 16:57:54 --> Router Class Initialized
INFO - 2020-04-06 16:57:54 --> Output Class Initialized
INFO - 2020-04-06 16:57:54 --> Security Class Initialized
DEBUG - 2020-04-06 16:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:57:54 --> CSRF cookie sent
INFO - 2020-04-06 16:57:54 --> Input Class Initialized
INFO - 2020-04-06 16:57:54 --> Language Class Initialized
INFO - 2020-04-06 16:57:54 --> Language Class Initialized
INFO - 2020-04-06 16:57:54 --> Config Class Initialized
INFO - 2020-04-06 16:57:54 --> Loader Class Initialized
INFO - 2020-04-06 16:57:54 --> Helper loaded: url_helper
INFO - 2020-04-06 16:57:54 --> Helper loaded: file_helper
INFO - 2020-04-06 16:57:54 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:57:54 --> Helper loaded: common_helper
INFO - 2020-04-06 16:57:54 --> Helper loaded: language_helper
INFO - 2020-04-06 16:57:54 --> Helper loaded: email_helper
INFO - 2020-04-06 16:57:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:57:55 --> Database Driver Class Initialized
INFO - 2020-04-06 16:57:55 --> Parser Class Initialized
INFO - 2020-04-06 16:57:55 --> User Agent Class Initialized
INFO - 2020-04-06 16:57:55 --> Model Class Initialized
INFO - 2020-04-06 16:57:55 --> Model Class Initialized
DEBUG - 2020-04-06 16:57:55 --> Template Class Initialized
INFO - 2020-04-06 16:57:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:57:55 --> Email Class Initialized
INFO - 2020-04-06 16:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:57:55 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:57:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:57:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:57:55 --> Encryption Class Initialized
INFO - 2020-04-06 16:57:55 --> Controller Class Initialized
DEBUG - 2020-04-06 16:57:55 --> dashboard MX_Controller Initialized
INFO - 2020-04-06 16:57:55 --> Model Class Initialized
DEBUG - 2020-04-06 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-06 16:57:55 --> Model Class Initialized
INFO - 2020-04-06 16:57:55 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-06 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-06 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:57:55 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:57:55 --> Final output sent to browser
DEBUG - 2020-04-06 16:57:55 --> Total execution time: 0.9058
INFO - 2020-04-06 16:57:57 --> Config Class Initialized
INFO - 2020-04-06 16:57:57 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:57:57 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:57:57 --> Utf8 Class Initialized
INFO - 2020-04-06 16:57:57 --> URI Class Initialized
INFO - 2020-04-06 16:57:57 --> Router Class Initialized
INFO - 2020-04-06 16:57:57 --> Output Class Initialized
INFO - 2020-04-06 16:57:57 --> Security Class Initialized
DEBUG - 2020-04-06 16:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:57:57 --> CSRF cookie sent
INFO - 2020-04-06 16:57:57 --> Input Class Initialized
INFO - 2020-04-06 16:57:57 --> Language Class Initialized
INFO - 2020-04-06 16:57:57 --> Language Class Initialized
INFO - 2020-04-06 16:57:57 --> Config Class Initialized
INFO - 2020-04-06 16:57:57 --> Loader Class Initialized
INFO - 2020-04-06 16:57:57 --> Helper loaded: url_helper
INFO - 2020-04-06 16:57:57 --> Helper loaded: file_helper
INFO - 2020-04-06 16:57:57 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:57:57 --> Helper loaded: common_helper
INFO - 2020-04-06 16:57:57 --> Helper loaded: language_helper
INFO - 2020-04-06 16:57:57 --> Helper loaded: email_helper
INFO - 2020-04-06 16:57:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:57:57 --> Database Driver Class Initialized
INFO - 2020-04-06 16:57:57 --> Parser Class Initialized
INFO - 2020-04-06 16:57:57 --> User Agent Class Initialized
INFO - 2020-04-06 16:57:57 --> Model Class Initialized
INFO - 2020-04-06 16:57:57 --> Model Class Initialized
DEBUG - 2020-04-06 16:57:57 --> Template Class Initialized
INFO - 2020-04-06 16:57:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:57:57 --> Email Class Initialized
INFO - 2020-04-06 16:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:57:57 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:57:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:57:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:57:57 --> Encryption Class Initialized
INFO - 2020-04-06 16:57:57 --> Controller Class Initialized
DEBUG - 2020-04-06 16:57:57 --> post MX_Controller Initialized
INFO - 2020-04-06 16:57:57 --> Model Class Initialized
ERROR - 2020-04-06 16:57:57 --> Could not find the language line ""
ERROR - 2020-04-06 16:57:57 --> Could not find the language line ""
ERROR - 2020-04-06 16:57:57 --> Could not find the language line ""
DEBUG - 2020-04-06 16:57:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-06 16:57:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:57:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:57:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:57:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:57:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:57:57 --> Final output sent to browser
DEBUG - 2020-04-06 16:57:57 --> Total execution time: 0.8428
INFO - 2020-04-06 16:57:59 --> Config Class Initialized
INFO - 2020-04-06 16:57:59 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:57:59 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:57:59 --> Utf8 Class Initialized
INFO - 2020-04-06 16:57:59 --> URI Class Initialized
INFO - 2020-04-06 16:57:59 --> Router Class Initialized
INFO - 2020-04-06 16:57:59 --> Output Class Initialized
INFO - 2020-04-06 16:57:59 --> Security Class Initialized
DEBUG - 2020-04-06 16:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:57:59 --> CSRF cookie sent
INFO - 2020-04-06 16:57:59 --> Input Class Initialized
INFO - 2020-04-06 16:57:59 --> Language Class Initialized
INFO - 2020-04-06 16:57:59 --> Language Class Initialized
INFO - 2020-04-06 16:57:59 --> Config Class Initialized
INFO - 2020-04-06 16:57:59 --> Loader Class Initialized
INFO - 2020-04-06 16:57:59 --> Helper loaded: url_helper
INFO - 2020-04-06 16:57:59 --> Helper loaded: file_helper
INFO - 2020-04-06 16:57:59 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:57:59 --> Helper loaded: common_helper
INFO - 2020-04-06 16:57:59 --> Helper loaded: language_helper
INFO - 2020-04-06 16:57:59 --> Helper loaded: email_helper
INFO - 2020-04-06 16:57:59 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:57:59 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:00 --> Parser Class Initialized
INFO - 2020-04-06 16:58:00 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:00 --> Model Class Initialized
INFO - 2020-04-06 16:58:00 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:00 --> Template Class Initialized
INFO - 2020-04-06 16:58:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:00 --> Email Class Initialized
INFO - 2020-04-06 16:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:00 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:00 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:00 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:00 --> schedule MX_Controller Initialized
INFO - 2020-04-06 16:58:00 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/models/schedule_model.php
INFO - 2020-04-06 16:58:00 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/views/index.php
DEBUG - 2020-04-06 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:00 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:00 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:00 --> Total execution time: 0.8303
INFO - 2020-04-06 16:58:01 --> Config Class Initialized
INFO - 2020-04-06 16:58:01 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:01 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:02 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:02 --> URI Class Initialized
INFO - 2020-04-06 16:58:02 --> Router Class Initialized
INFO - 2020-04-06 16:58:02 --> Output Class Initialized
INFO - 2020-04-06 16:58:02 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:02 --> CSRF cookie sent
INFO - 2020-04-06 16:58:02 --> Input Class Initialized
INFO - 2020-04-06 16:58:02 --> Language Class Initialized
INFO - 2020-04-06 16:58:02 --> Language Class Initialized
INFO - 2020-04-06 16:58:02 --> Config Class Initialized
INFO - 2020-04-06 16:58:02 --> Loader Class Initialized
INFO - 2020-04-06 16:58:02 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:02 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:02 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:02 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:02 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:02 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:02 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:02 --> Parser Class Initialized
INFO - 2020-04-06 16:58:02 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:02 --> Model Class Initialized
INFO - 2020-04-06 16:58:02 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:02 --> Template Class Initialized
INFO - 2020-04-06 16:58:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:02 --> Email Class Initialized
INFO - 2020-04-06 16:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:02 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:02 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:02 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:02 --> follow MX_Controller Initialized
INFO - 2020-04-06 16:58:02 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-06 16:58:02 --> Model Class Initialized
INFO - 2020-04-06 16:58:02 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-06 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:02 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:02 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:02 --> Total execution time: 0.8459
INFO - 2020-04-06 16:58:04 --> Config Class Initialized
INFO - 2020-04-06 16:58:04 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:04 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:04 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:04 --> URI Class Initialized
INFO - 2020-04-06 16:58:04 --> Router Class Initialized
INFO - 2020-04-06 16:58:04 --> Output Class Initialized
INFO - 2020-04-06 16:58:04 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:04 --> CSRF cookie sent
INFO - 2020-04-06 16:58:04 --> Input Class Initialized
INFO - 2020-04-06 16:58:04 --> Language Class Initialized
INFO - 2020-04-06 16:58:04 --> Language Class Initialized
INFO - 2020-04-06 16:58:04 --> Config Class Initialized
INFO - 2020-04-06 16:58:04 --> Loader Class Initialized
INFO - 2020-04-06 16:58:04 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:04 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:04 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:04 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:04 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:04 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:04 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:04 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:04 --> Parser Class Initialized
INFO - 2020-04-06 16:58:04 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:04 --> Model Class Initialized
INFO - 2020-04-06 16:58:04 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:04 --> Template Class Initialized
INFO - 2020-04-06 16:58:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:04 --> Email Class Initialized
INFO - 2020-04-06 16:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:04 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:04 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:05 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:05 --> unfollow MX_Controller Initialized
INFO - 2020-04-06 16:58:05 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/unfollow/models/unfollow_model.php
INFO - 2020-04-06 16:58:05 --> Model Class Initialized
INFO - 2020-04-06 16:58:05 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/unfollow/views/index.php
DEBUG - 2020-04-06 16:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:05 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:05 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:05 --> Total execution time: 0.8348
INFO - 2020-04-06 16:58:06 --> Config Class Initialized
INFO - 2020-04-06 16:58:06 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:06 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:06 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:06 --> URI Class Initialized
INFO - 2020-04-06 16:58:06 --> Router Class Initialized
INFO - 2020-04-06 16:58:06 --> Output Class Initialized
INFO - 2020-04-06 16:58:06 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:06 --> CSRF cookie sent
INFO - 2020-04-06 16:58:06 --> Input Class Initialized
INFO - 2020-04-06 16:58:06 --> Language Class Initialized
INFO - 2020-04-06 16:58:06 --> Language Class Initialized
INFO - 2020-04-06 16:58:06 --> Config Class Initialized
INFO - 2020-04-06 16:58:06 --> Loader Class Initialized
INFO - 2020-04-06 16:58:06 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:06 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:06 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:06 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:07 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:07 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:07 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:07 --> Parser Class Initialized
INFO - 2020-04-06 16:58:07 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:07 --> Model Class Initialized
INFO - 2020-04-06 16:58:07 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:07 --> Template Class Initialized
INFO - 2020-04-06 16:58:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:07 --> Email Class Initialized
INFO - 2020-04-06 16:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:07 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:07 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:07 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:07 --> retweet MX_Controller Initialized
INFO - 2020-04-06 16:58:07 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/retweet/models/retweet_model.php
INFO - 2020-04-06 16:58:07 --> Model Class Initialized
INFO - 2020-04-06 16:58:07 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/retweet/views/index.php
DEBUG - 2020-04-06 16:58:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:07 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:07 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:07 --> Total execution time: 0.8631
INFO - 2020-04-06 16:58:08 --> Config Class Initialized
INFO - 2020-04-06 16:58:08 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:08 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:08 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:08 --> URI Class Initialized
INFO - 2020-04-06 16:58:08 --> Router Class Initialized
INFO - 2020-04-06 16:58:08 --> Output Class Initialized
INFO - 2020-04-06 16:58:08 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:08 --> CSRF cookie sent
INFO - 2020-04-06 16:58:08 --> Input Class Initialized
INFO - 2020-04-06 16:58:08 --> Language Class Initialized
INFO - 2020-04-06 16:58:09 --> Language Class Initialized
INFO - 2020-04-06 16:58:09 --> Config Class Initialized
INFO - 2020-04-06 16:58:09 --> Loader Class Initialized
INFO - 2020-04-06 16:58:09 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:09 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:09 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:09 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:09 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:09 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:09 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:09 --> Parser Class Initialized
INFO - 2020-04-06 16:58:09 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:09 --> Model Class Initialized
INFO - 2020-04-06 16:58:09 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:09 --> Template Class Initialized
INFO - 2020-04-06 16:58:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:09 --> Email Class Initialized
INFO - 2020-04-06 16:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:09 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:09 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:09 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:09 --> like MX_Controller Initialized
INFO - 2020-04-06 16:58:09 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/models/like_model.php
INFO - 2020-04-06 16:58:09 --> Model Class Initialized
INFO - 2020-04-06 16:58:09 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/like/views/index.php
DEBUG - 2020-04-06 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:09 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:09 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:09 --> Total execution time: 0.8702
INFO - 2020-04-06 16:58:10 --> Config Class Initialized
INFO - 2020-04-06 16:58:11 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:11 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:11 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:11 --> URI Class Initialized
INFO - 2020-04-06 16:58:11 --> Router Class Initialized
INFO - 2020-04-06 16:58:11 --> Output Class Initialized
INFO - 2020-04-06 16:58:11 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:11 --> CSRF cookie sent
INFO - 2020-04-06 16:58:11 --> Input Class Initialized
INFO - 2020-04-06 16:58:11 --> Language Class Initialized
INFO - 2020-04-06 16:58:11 --> Language Class Initialized
INFO - 2020-04-06 16:58:11 --> Config Class Initialized
INFO - 2020-04-06 16:58:11 --> Loader Class Initialized
INFO - 2020-04-06 16:58:11 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:11 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:11 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:11 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:11 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:11 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:11 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:11 --> Parser Class Initialized
INFO - 2020-04-06 16:58:11 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:11 --> Model Class Initialized
INFO - 2020-04-06 16:58:11 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:11 --> Template Class Initialized
INFO - 2020-04-06 16:58:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:11 --> Email Class Initialized
INFO - 2020-04-06 16:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:11 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:11 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:11 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:11 --> direct_messages MX_Controller Initialized
INFO - 2020-04-06 16:58:11 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/direct_messages/models/direct_messages_model.php
INFO - 2020-04-06 16:58:11 --> Model Class Initialized
INFO - 2020-04-06 16:58:11 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/direct_messages/views/index.php
DEBUG - 2020-04-06 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:11 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:11 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:11 --> Total execution time: 0.8642
INFO - 2020-04-06 16:58:13 --> Config Class Initialized
INFO - 2020-04-06 16:58:13 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:13 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:13 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:13 --> URI Class Initialized
INFO - 2020-04-06 16:58:13 --> Router Class Initialized
INFO - 2020-04-06 16:58:13 --> Output Class Initialized
INFO - 2020-04-06 16:58:13 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:13 --> CSRF cookie sent
INFO - 2020-04-06 16:58:13 --> Input Class Initialized
INFO - 2020-04-06 16:58:13 --> Language Class Initialized
INFO - 2020-04-06 16:58:13 --> Language Class Initialized
INFO - 2020-04-06 16:58:13 --> Config Class Initialized
INFO - 2020-04-06 16:58:13 --> Loader Class Initialized
INFO - 2020-04-06 16:58:13 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:13 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:13 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:13 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:13 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:13 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:13 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:13 --> Parser Class Initialized
INFO - 2020-04-06 16:58:13 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:13 --> Model Class Initialized
INFO - 2020-04-06 16:58:13 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:13 --> Template Class Initialized
INFO - 2020-04-06 16:58:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:13 --> Email Class Initialized
INFO - 2020-04-06 16:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:13 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:13 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:13 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:13 --> search MX_Controller Initialized
INFO - 2020-04-06 16:58:13 --> Model Class Initialized
INFO - 2020-04-06 16:58:13 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/search/views/index.php
DEBUG - 2020-04-06 16:58:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:13 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:13 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:13 --> Total execution time: 0.8196
INFO - 2020-04-06 16:58:15 --> Config Class Initialized
INFO - 2020-04-06 16:58:15 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:15 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:15 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:15 --> URI Class Initialized
INFO - 2020-04-06 16:58:15 --> Router Class Initialized
INFO - 2020-04-06 16:58:15 --> Output Class Initialized
INFO - 2020-04-06 16:58:15 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:15 --> CSRF cookie sent
INFO - 2020-04-06 16:58:15 --> Input Class Initialized
INFO - 2020-04-06 16:58:15 --> Language Class Initialized
INFO - 2020-04-06 16:58:15 --> Language Class Initialized
INFO - 2020-04-06 16:58:15 --> Config Class Initialized
INFO - 2020-04-06 16:58:15 --> Loader Class Initialized
INFO - 2020-04-06 16:58:15 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:15 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:15 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:15 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:16 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:16 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:16 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:16 --> Parser Class Initialized
INFO - 2020-04-06 16:58:16 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:16 --> Model Class Initialized
INFO - 2020-04-06 16:58:16 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:16 --> Template Class Initialized
INFO - 2020-04-06 16:58:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:16 --> Email Class Initialized
INFO - 2020-04-06 16:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:16 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:16 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:16 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:16 --> gallery MX_Controller Initialized
INFO - 2020-04-06 16:58:16 --> Model Class Initialized
INFO - 2020-04-06 16:58:16 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-06 16:58:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:16 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:16 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:16 --> Total execution time: 0.8131
INFO - 2020-04-06 16:58:34 --> Config Class Initialized
INFO - 2020-04-06 16:58:34 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:34 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:34 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:34 --> URI Class Initialized
INFO - 2020-04-06 16:58:34 --> Router Class Initialized
INFO - 2020-04-06 16:58:34 --> Output Class Initialized
INFO - 2020-04-06 16:58:34 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:34 --> CSRF cookie sent
INFO - 2020-04-06 16:58:34 --> Input Class Initialized
INFO - 2020-04-06 16:58:35 --> Language Class Initialized
INFO - 2020-04-06 16:58:35 --> Language Class Initialized
INFO - 2020-04-06 16:58:35 --> Config Class Initialized
INFO - 2020-04-06 16:58:35 --> Loader Class Initialized
INFO - 2020-04-06 16:58:35 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:35 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:35 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:35 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:35 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:35 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:35 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:35 --> Parser Class Initialized
INFO - 2020-04-06 16:58:35 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:35 --> Model Class Initialized
INFO - 2020-04-06 16:58:35 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:35 --> Template Class Initialized
INFO - 2020-04-06 16:58:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:35 --> Email Class Initialized
INFO - 2020-04-06 16:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:35 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:35 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:35 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:35 --> gallery MX_Controller Initialized
INFO - 2020-04-06 16:58:35 --> Model Class Initialized
INFO - 2020-04-06 16:58:35 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/gallery/views/index.php
DEBUG - 2020-04-06 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:35 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:35 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:35 --> Total execution time: 0.9326
INFO - 2020-04-06 16:58:37 --> Config Class Initialized
INFO - 2020-04-06 16:58:37 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:37 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:37 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:37 --> URI Class Initialized
INFO - 2020-04-06 16:58:37 --> Router Class Initialized
INFO - 2020-04-06 16:58:37 --> Output Class Initialized
INFO - 2020-04-06 16:58:37 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:37 --> CSRF cookie sent
INFO - 2020-04-06 16:58:37 --> Input Class Initialized
INFO - 2020-04-06 16:58:37 --> Language Class Initialized
INFO - 2020-04-06 16:58:37 --> Language Class Initialized
INFO - 2020-04-06 16:58:37 --> Config Class Initialized
INFO - 2020-04-06 16:58:37 --> Loader Class Initialized
INFO - 2020-04-06 16:58:37 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:37 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:37 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:37 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:37 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:37 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:38 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:38 --> Parser Class Initialized
INFO - 2020-04-06 16:58:38 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:38 --> Model Class Initialized
INFO - 2020-04-06 16:58:38 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:38 --> Template Class Initialized
INFO - 2020-04-06 16:58:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:38 --> Email Class Initialized
INFO - 2020-04-06 16:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:38 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:38 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:38 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:38 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:58:38 --> Model Class Initialized
INFO - 2020-04-06 16:58:38 --> Config Class Initialized
INFO - 2020-04-06 16:58:38 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:38 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:38 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:38 --> URI Class Initialized
INFO - 2020-04-06 16:58:38 --> Router Class Initialized
INFO - 2020-04-06 16:58:38 --> Output Class Initialized
INFO - 2020-04-06 16:58:38 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:38 --> CSRF cookie sent
INFO - 2020-04-06 16:58:38 --> Input Class Initialized
INFO - 2020-04-06 16:58:38 --> Language Class Initialized
INFO - 2020-04-06 16:58:38 --> Language Class Initialized
INFO - 2020-04-06 16:58:38 --> Config Class Initialized
INFO - 2020-04-06 16:58:38 --> Loader Class Initialized
INFO - 2020-04-06 16:58:38 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:38 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:38 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:38 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:38 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:38 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:38 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:38 --> Parser Class Initialized
INFO - 2020-04-06 16:58:38 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:38 --> Model Class Initialized
INFO - 2020-04-06 16:58:38 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:38 --> Template Class Initialized
INFO - 2020-04-06 16:58:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:38 --> Email Class Initialized
INFO - 2020-04-06 16:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:38 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:38 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:38 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:39 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:58:39 --> Model Class Initialized
INFO - 2020-04-06 16:58:39 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-06 16:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:39 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:39 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:39 --> Total execution time: 0.8844
INFO - 2020-04-06 16:58:41 --> Config Class Initialized
INFO - 2020-04-06 16:58:41 --> Hooks Class Initialized
DEBUG - 2020-04-06 16:58:41 --> UTF-8 Support Enabled
INFO - 2020-04-06 16:58:41 --> Utf8 Class Initialized
INFO - 2020-04-06 16:58:41 --> URI Class Initialized
INFO - 2020-04-06 16:58:41 --> Router Class Initialized
INFO - 2020-04-06 16:58:41 --> Output Class Initialized
INFO - 2020-04-06 16:58:41 --> Security Class Initialized
DEBUG - 2020-04-06 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 16:58:42 --> CSRF cookie sent
INFO - 2020-04-06 16:58:42 --> Input Class Initialized
INFO - 2020-04-06 16:58:42 --> Language Class Initialized
INFO - 2020-04-06 16:58:42 --> Language Class Initialized
INFO - 2020-04-06 16:58:42 --> Config Class Initialized
INFO - 2020-04-06 16:58:42 --> Loader Class Initialized
INFO - 2020-04-06 16:58:42 --> Helper loaded: url_helper
INFO - 2020-04-06 16:58:42 --> Helper loaded: file_helper
INFO - 2020-04-06 16:58:42 --> Helper loaded: cookie_helper
INFO - 2020-04-06 16:58:42 --> Helper loaded: common_helper
INFO - 2020-04-06 16:58:42 --> Helper loaded: language_helper
INFO - 2020-04-06 16:58:42 --> Helper loaded: email_helper
INFO - 2020-04-06 16:58:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 16:58:42 --> Database Driver Class Initialized
INFO - 2020-04-06 16:58:42 --> Parser Class Initialized
INFO - 2020-04-06 16:58:42 --> User Agent Class Initialized
INFO - 2020-04-06 16:58:42 --> Model Class Initialized
INFO - 2020-04-06 16:58:42 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:42 --> Template Class Initialized
INFO - 2020-04-06 16:58:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 16:58:42 --> Email Class Initialized
INFO - 2020-04-06 16:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 16:58:42 --> Pagination Class Initialized
DEBUG - 2020-04-06 16:58:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 16:58:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 16:58:42 --> Encryption Class Initialized
INFO - 2020-04-06 16:58:42 --> Controller Class Initialized
DEBUG - 2020-04-06 16:58:42 --> settings MX_Controller Initialized
INFO - 2020-04-06 16:58:42 --> Model Class Initialized
DEBUG - 2020-04-06 16:58:42 --> module MX_Controller Initialized
INFO - 2020-04-06 16:58:43 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 16:58:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 16:58:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 16:58:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 16:58:43 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 16:58:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 16:58:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 16:58:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 16:58:43 --> Final output sent to browser
DEBUG - 2020-04-06 16:58:43 --> Total execution time: 1.9901
INFO - 2020-04-06 17:01:31 --> Config Class Initialized
INFO - 2020-04-06 17:01:31 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:01:31 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:01:31 --> Utf8 Class Initialized
INFO - 2020-04-06 17:01:31 --> URI Class Initialized
INFO - 2020-04-06 17:01:31 --> Router Class Initialized
INFO - 2020-04-06 17:01:31 --> Output Class Initialized
INFO - 2020-04-06 17:01:31 --> Security Class Initialized
DEBUG - 2020-04-06 17:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:01:31 --> CSRF cookie sent
INFO - 2020-04-06 17:01:31 --> Input Class Initialized
INFO - 2020-04-06 17:01:31 --> Language Class Initialized
INFO - 2020-04-06 17:01:31 --> Language Class Initialized
INFO - 2020-04-06 17:01:31 --> Config Class Initialized
INFO - 2020-04-06 17:01:31 --> Loader Class Initialized
INFO - 2020-04-06 17:01:31 --> Helper loaded: url_helper
INFO - 2020-04-06 17:01:31 --> Helper loaded: file_helper
INFO - 2020-04-06 17:01:31 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:01:31 --> Helper loaded: common_helper
INFO - 2020-04-06 17:01:31 --> Helper loaded: language_helper
INFO - 2020-04-06 17:01:31 --> Helper loaded: email_helper
INFO - 2020-04-06 17:01:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:01:31 --> Database Driver Class Initialized
INFO - 2020-04-06 17:01:31 --> Parser Class Initialized
INFO - 2020-04-06 17:01:31 --> User Agent Class Initialized
INFO - 2020-04-06 17:01:31 --> Model Class Initialized
INFO - 2020-04-06 17:01:31 --> Model Class Initialized
DEBUG - 2020-04-06 17:01:31 --> Template Class Initialized
INFO - 2020-04-06 17:01:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:01:31 --> Email Class Initialized
INFO - 2020-04-06 17:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:01:31 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:01:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:01:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:01:32 --> Encryption Class Initialized
INFO - 2020-04-06 17:01:32 --> Controller Class Initialized
DEBUG - 2020-04-06 17:01:32 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:01:32 --> Model Class Initialized
DEBUG - 2020-04-06 17:01:32 --> module MX_Controller Initialized
INFO - 2020-04-06 17:01:33 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:01:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:01:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:01:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:01:33 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:01:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:01:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:01:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:01:33 --> Final output sent to browser
DEBUG - 2020-04-06 17:01:33 --> Total execution time: 2.3806
INFO - 2020-04-06 17:01:44 --> Config Class Initialized
INFO - 2020-04-06 17:01:44 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:01:44 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:01:44 --> Utf8 Class Initialized
INFO - 2020-04-06 17:01:44 --> URI Class Initialized
INFO - 2020-04-06 17:01:44 --> Router Class Initialized
INFO - 2020-04-06 17:01:44 --> Output Class Initialized
INFO - 2020-04-06 17:01:44 --> Security Class Initialized
DEBUG - 2020-04-06 17:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:01:44 --> CSRF cookie sent
INFO - 2020-04-06 17:01:44 --> Input Class Initialized
INFO - 2020-04-06 17:01:44 --> Language Class Initialized
INFO - 2020-04-06 17:01:44 --> Language Class Initialized
INFO - 2020-04-06 17:01:44 --> Config Class Initialized
INFO - 2020-04-06 17:01:44 --> Loader Class Initialized
INFO - 2020-04-06 17:01:44 --> Helper loaded: url_helper
INFO - 2020-04-06 17:01:44 --> Helper loaded: file_helper
INFO - 2020-04-06 17:01:44 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:01:44 --> Helper loaded: common_helper
INFO - 2020-04-06 17:01:44 --> Helper loaded: language_helper
INFO - 2020-04-06 17:01:44 --> Helper loaded: email_helper
INFO - 2020-04-06 17:01:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:01:44 --> Database Driver Class Initialized
INFO - 2020-04-06 17:01:44 --> Parser Class Initialized
INFO - 2020-04-06 17:01:44 --> User Agent Class Initialized
INFO - 2020-04-06 17:01:44 --> Model Class Initialized
INFO - 2020-04-06 17:01:44 --> Model Class Initialized
DEBUG - 2020-04-06 17:01:44 --> Template Class Initialized
INFO - 2020-04-06 17:01:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:01:44 --> Email Class Initialized
INFO - 2020-04-06 17:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:01:44 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:01:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:01:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:01:44 --> Encryption Class Initialized
INFO - 2020-04-06 17:01:45 --> Controller Class Initialized
DEBUG - 2020-04-06 17:01:45 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:01:45 --> Model Class Initialized
DEBUG - 2020-04-06 17:01:45 --> module MX_Controller Initialized
INFO - 2020-04-06 17:01:46 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:01:46 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:01:46 --> Final output sent to browser
DEBUG - 2020-04-06 17:01:46 --> Total execution time: 1.9438
INFO - 2020-04-06 17:08:13 --> Config Class Initialized
INFO - 2020-04-06 17:08:13 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:08:14 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:08:14 --> Utf8 Class Initialized
INFO - 2020-04-06 17:08:14 --> URI Class Initialized
INFO - 2020-04-06 17:08:14 --> Router Class Initialized
INFO - 2020-04-06 17:08:14 --> Output Class Initialized
INFO - 2020-04-06 17:08:14 --> Security Class Initialized
DEBUG - 2020-04-06 17:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:08:14 --> CSRF cookie sent
INFO - 2020-04-06 17:08:14 --> Input Class Initialized
INFO - 2020-04-06 17:08:14 --> Language Class Initialized
INFO - 2020-04-06 17:08:14 --> Language Class Initialized
INFO - 2020-04-06 17:08:14 --> Config Class Initialized
INFO - 2020-04-06 17:08:14 --> Loader Class Initialized
INFO - 2020-04-06 17:08:14 --> Helper loaded: url_helper
INFO - 2020-04-06 17:08:14 --> Helper loaded: file_helper
INFO - 2020-04-06 17:08:14 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:08:14 --> Helper loaded: common_helper
INFO - 2020-04-06 17:08:14 --> Helper loaded: language_helper
INFO - 2020-04-06 17:08:14 --> Helper loaded: email_helper
INFO - 2020-04-06 17:08:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:08:14 --> Database Driver Class Initialized
INFO - 2020-04-06 17:08:14 --> Parser Class Initialized
INFO - 2020-04-06 17:08:14 --> User Agent Class Initialized
INFO - 2020-04-06 17:08:14 --> Model Class Initialized
INFO - 2020-04-06 17:08:14 --> Model Class Initialized
DEBUG - 2020-04-06 17:08:14 --> Template Class Initialized
INFO - 2020-04-06 17:08:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:08:14 --> Email Class Initialized
INFO - 2020-04-06 17:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:08:14 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:08:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:08:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:08:14 --> Encryption Class Initialized
INFO - 2020-04-06 17:08:14 --> Controller Class Initialized
DEBUG - 2020-04-06 17:08:14 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:08:14 --> Model Class Initialized
DEBUG - 2020-04-06 17:08:14 --> module MX_Controller Initialized
INFO - 2020-04-06 17:08:15 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:08:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:08:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:08:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:08:15 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:08:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:08:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:08:16 --> Final output sent to browser
DEBUG - 2020-04-06 17:08:16 --> Total execution time: 2.0609
INFO - 2020-04-06 17:08:19 --> Config Class Initialized
INFO - 2020-04-06 17:08:19 --> Config Class Initialized
INFO - 2020-04-06 17:08:19 --> Hooks Class Initialized
INFO - 2020-04-06 17:08:19 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:08:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-06 17:08:19 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:08:19 --> Utf8 Class Initialized
INFO - 2020-04-06 17:08:19 --> Utf8 Class Initialized
INFO - 2020-04-06 17:08:19 --> URI Class Initialized
INFO - 2020-04-06 17:08:19 --> URI Class Initialized
INFO - 2020-04-06 17:08:19 --> Router Class Initialized
INFO - 2020-04-06 17:08:19 --> Router Class Initialized
INFO - 2020-04-06 17:08:19 --> Output Class Initialized
INFO - 2020-04-06 17:08:19 --> Output Class Initialized
INFO - 2020-04-06 17:08:19 --> Security Class Initialized
INFO - 2020-04-06 17:08:19 --> Security Class Initialized
DEBUG - 2020-04-06 17:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-06 17:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:08:20 --> CSRF cookie sent
INFO - 2020-04-06 17:08:20 --> CSRF cookie sent
INFO - 2020-04-06 17:08:20 --> Input Class Initialized
INFO - 2020-04-06 17:08:20 --> Input Class Initialized
INFO - 2020-04-06 17:08:20 --> Language Class Initialized
INFO - 2020-04-06 17:08:20 --> Language Class Initialized
ERROR - 2020-04-06 17:08:20 --> 404 Page Not Found: /index
ERROR - 2020-04-06 17:08:20 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:08:21 --> Config Class Initialized
INFO - 2020-04-06 17:08:21 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:08:21 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:08:21 --> Utf8 Class Initialized
INFO - 2020-04-06 17:08:21 --> URI Class Initialized
INFO - 2020-04-06 17:08:21 --> Router Class Initialized
INFO - 2020-04-06 17:08:21 --> Output Class Initialized
INFO - 2020-04-06 17:08:21 --> Security Class Initialized
DEBUG - 2020-04-06 17:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:08:21 --> CSRF cookie sent
INFO - 2020-04-06 17:08:21 --> CSRF token verified
INFO - 2020-04-06 17:08:21 --> Input Class Initialized
INFO - 2020-04-06 17:08:21 --> Language Class Initialized
INFO - 2020-04-06 17:08:21 --> Language Class Initialized
INFO - 2020-04-06 17:08:21 --> Config Class Initialized
INFO - 2020-04-06 17:08:21 --> Loader Class Initialized
INFO - 2020-04-06 17:08:21 --> Helper loaded: url_helper
INFO - 2020-04-06 17:08:21 --> Helper loaded: file_helper
INFO - 2020-04-06 17:08:21 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:08:21 --> Helper loaded: common_helper
INFO - 2020-04-06 17:08:21 --> Helper loaded: language_helper
INFO - 2020-04-06 17:08:21 --> Helper loaded: email_helper
INFO - 2020-04-06 17:08:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:08:21 --> Database Driver Class Initialized
INFO - 2020-04-06 17:08:21 --> Parser Class Initialized
INFO - 2020-04-06 17:08:21 --> User Agent Class Initialized
INFO - 2020-04-06 17:08:21 --> Model Class Initialized
INFO - 2020-04-06 17:08:21 --> Model Class Initialized
DEBUG - 2020-04-06 17:08:21 --> Template Class Initialized
INFO - 2020-04-06 17:08:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:08:21 --> Email Class Initialized
INFO - 2020-04-06 17:08:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:08:21 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:08:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:08:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:08:21 --> Encryption Class Initialized
INFO - 2020-04-06 17:08:21 --> Controller Class Initialized
DEBUG - 2020-04-06 17:08:21 --> module MX_Controller Initialized
INFO - 2020-04-06 17:08:21 --> Model Class Initialized
INFO - 2020-04-06 17:09:25 --> Config Class Initialized
INFO - 2020-04-06 17:09:25 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:09:25 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:09:25 --> Utf8 Class Initialized
INFO - 2020-04-06 17:09:25 --> URI Class Initialized
INFO - 2020-04-06 17:09:25 --> Router Class Initialized
INFO - 2020-04-06 17:09:25 --> Output Class Initialized
INFO - 2020-04-06 17:09:25 --> Security Class Initialized
DEBUG - 2020-04-06 17:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:09:25 --> CSRF cookie sent
INFO - 2020-04-06 17:09:25 --> Input Class Initialized
INFO - 2020-04-06 17:09:25 --> Language Class Initialized
INFO - 2020-04-06 17:09:25 --> Language Class Initialized
INFO - 2020-04-06 17:09:25 --> Config Class Initialized
INFO - 2020-04-06 17:09:25 --> Loader Class Initialized
INFO - 2020-04-06 17:09:25 --> Helper loaded: url_helper
INFO - 2020-04-06 17:09:25 --> Helper loaded: file_helper
INFO - 2020-04-06 17:09:25 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:09:25 --> Helper loaded: common_helper
INFO - 2020-04-06 17:09:25 --> Helper loaded: language_helper
INFO - 2020-04-06 17:09:25 --> Helper loaded: email_helper
INFO - 2020-04-06 17:09:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:09:25 --> Database Driver Class Initialized
INFO - 2020-04-06 17:09:25 --> Parser Class Initialized
INFO - 2020-04-06 17:09:25 --> User Agent Class Initialized
INFO - 2020-04-06 17:09:25 --> Model Class Initialized
INFO - 2020-04-06 17:09:25 --> Model Class Initialized
DEBUG - 2020-04-06 17:09:25 --> Template Class Initialized
INFO - 2020-04-06 17:09:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:09:25 --> Email Class Initialized
INFO - 2020-04-06 17:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:09:25 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:09:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:09:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:09:26 --> Encryption Class Initialized
INFO - 2020-04-06 17:09:26 --> Controller Class Initialized
DEBUG - 2020-04-06 17:09:26 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:09:26 --> Model Class Initialized
DEBUG - 2020-04-06 17:09:26 --> module MX_Controller Initialized
INFO - 2020-04-06 17:09:27 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:09:27 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:09:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:09:27 --> Final output sent to browser
DEBUG - 2020-04-06 17:09:27 --> Total execution time: 1.9440
INFO - 2020-04-06 17:09:27 --> Config Class Initialized
INFO - 2020-04-06 17:09:27 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:09:27 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:09:27 --> Utf8 Class Initialized
INFO - 2020-04-06 17:09:27 --> URI Class Initialized
INFO - 2020-04-06 17:09:27 --> Router Class Initialized
INFO - 2020-04-06 17:09:27 --> Config Class Initialized
INFO - 2020-04-06 17:09:27 --> Hooks Class Initialized
INFO - 2020-04-06 17:09:27 --> Output Class Initialized
INFO - 2020-04-06 17:09:27 --> Security Class Initialized
DEBUG - 2020-04-06 17:09:27 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:09:27 --> Utf8 Class Initialized
DEBUG - 2020-04-06 17:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:09:27 --> CSRF cookie sent
INFO - 2020-04-06 17:09:27 --> URI Class Initialized
INFO - 2020-04-06 17:09:28 --> Input Class Initialized
INFO - 2020-04-06 17:09:28 --> Router Class Initialized
INFO - 2020-04-06 17:09:28 --> Language Class Initialized
INFO - 2020-04-06 17:09:28 --> Output Class Initialized
ERROR - 2020-04-06 17:09:28 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:09:28 --> Security Class Initialized
DEBUG - 2020-04-06 17:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:09:28 --> CSRF cookie sent
INFO - 2020-04-06 17:09:28 --> Input Class Initialized
INFO - 2020-04-06 17:09:28 --> Language Class Initialized
ERROR - 2020-04-06 17:09:28 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:10:25 --> Config Class Initialized
INFO - 2020-04-06 17:10:25 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:10:25 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:10:25 --> Utf8 Class Initialized
INFO - 2020-04-06 17:10:25 --> URI Class Initialized
INFO - 2020-04-06 17:10:25 --> Router Class Initialized
INFO - 2020-04-06 17:10:25 --> Output Class Initialized
INFO - 2020-04-06 17:10:25 --> Security Class Initialized
DEBUG - 2020-04-06 17:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:10:25 --> CSRF cookie sent
INFO - 2020-04-06 17:10:25 --> Input Class Initialized
INFO - 2020-04-06 17:10:25 --> Language Class Initialized
INFO - 2020-04-06 17:10:25 --> Language Class Initialized
INFO - 2020-04-06 17:10:25 --> Config Class Initialized
INFO - 2020-04-06 17:10:25 --> Loader Class Initialized
INFO - 2020-04-06 17:10:25 --> Helper loaded: url_helper
INFO - 2020-04-06 17:10:25 --> Helper loaded: file_helper
INFO - 2020-04-06 17:10:25 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:10:25 --> Helper loaded: common_helper
INFO - 2020-04-06 17:10:25 --> Helper loaded: language_helper
INFO - 2020-04-06 17:10:25 --> Helper loaded: email_helper
INFO - 2020-04-06 17:10:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:10:25 --> Database Driver Class Initialized
INFO - 2020-04-06 17:10:25 --> Parser Class Initialized
INFO - 2020-04-06 17:10:25 --> User Agent Class Initialized
INFO - 2020-04-06 17:10:25 --> Model Class Initialized
INFO - 2020-04-06 17:10:25 --> Model Class Initialized
DEBUG - 2020-04-06 17:10:25 --> Template Class Initialized
INFO - 2020-04-06 17:10:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:10:25 --> Email Class Initialized
INFO - 2020-04-06 17:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:10:25 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:10:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:10:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:10:25 --> Encryption Class Initialized
INFO - 2020-04-06 17:10:25 --> Controller Class Initialized
DEBUG - 2020-04-06 17:10:25 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:10:26 --> Model Class Initialized
DEBUG - 2020-04-06 17:10:26 --> module MX_Controller Initialized
INFO - 2020-04-06 17:10:27 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:10:27 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:10:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:10:27 --> Final output sent to browser
DEBUG - 2020-04-06 17:10:27 --> Total execution time: 2.1976
INFO - 2020-04-06 17:10:27 --> Config Class Initialized
INFO - 2020-04-06 17:10:27 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:10:27 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:10:27 --> Utf8 Class Initialized
INFO - 2020-04-06 17:10:27 --> Config Class Initialized
INFO - 2020-04-06 17:10:28 --> Hooks Class Initialized
INFO - 2020-04-06 17:10:28 --> URI Class Initialized
DEBUG - 2020-04-06 17:10:28 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:10:28 --> Router Class Initialized
INFO - 2020-04-06 17:10:28 --> Utf8 Class Initialized
INFO - 2020-04-06 17:10:28 --> Output Class Initialized
INFO - 2020-04-06 17:10:28 --> URI Class Initialized
INFO - 2020-04-06 17:10:28 --> Security Class Initialized
DEBUG - 2020-04-06 17:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:10:28 --> Router Class Initialized
INFO - 2020-04-06 17:10:28 --> CSRF cookie sent
INFO - 2020-04-06 17:10:28 --> Output Class Initialized
INFO - 2020-04-06 17:10:28 --> Input Class Initialized
INFO - 2020-04-06 17:10:28 --> Security Class Initialized
INFO - 2020-04-06 17:10:28 --> Language Class Initialized
DEBUG - 2020-04-06 17:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:10:28 --> CSRF cookie sent
ERROR - 2020-04-06 17:10:28 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:10:28 --> Input Class Initialized
INFO - 2020-04-06 17:10:28 --> Language Class Initialized
ERROR - 2020-04-06 17:10:28 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:10:42 --> Config Class Initialized
INFO - 2020-04-06 17:10:42 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:10:42 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:10:42 --> Utf8 Class Initialized
INFO - 2020-04-06 17:10:42 --> URI Class Initialized
INFO - 2020-04-06 17:10:42 --> Router Class Initialized
INFO - 2020-04-06 17:10:42 --> Output Class Initialized
INFO - 2020-04-06 17:10:42 --> Security Class Initialized
DEBUG - 2020-04-06 17:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:10:42 --> CSRF cookie sent
INFO - 2020-04-06 17:10:42 --> Input Class Initialized
INFO - 2020-04-06 17:10:42 --> Language Class Initialized
INFO - 2020-04-06 17:10:42 --> Language Class Initialized
INFO - 2020-04-06 17:10:42 --> Config Class Initialized
INFO - 2020-04-06 17:10:42 --> Loader Class Initialized
INFO - 2020-04-06 17:10:42 --> Helper loaded: url_helper
INFO - 2020-04-06 17:10:42 --> Helper loaded: file_helper
INFO - 2020-04-06 17:10:42 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:10:42 --> Helper loaded: common_helper
INFO - 2020-04-06 17:10:42 --> Helper loaded: language_helper
INFO - 2020-04-06 17:10:42 --> Helper loaded: email_helper
INFO - 2020-04-06 17:10:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:10:42 --> Database Driver Class Initialized
INFO - 2020-04-06 17:10:42 --> Parser Class Initialized
INFO - 2020-04-06 17:10:42 --> User Agent Class Initialized
INFO - 2020-04-06 17:10:42 --> Model Class Initialized
INFO - 2020-04-06 17:10:42 --> Model Class Initialized
DEBUG - 2020-04-06 17:10:42 --> Template Class Initialized
INFO - 2020-04-06 17:10:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:10:42 --> Email Class Initialized
INFO - 2020-04-06 17:10:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:10:42 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:10:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:10:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:10:42 --> Encryption Class Initialized
INFO - 2020-04-06 17:10:42 --> Controller Class Initialized
DEBUG - 2020-04-06 17:10:42 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:10:43 --> Model Class Initialized
DEBUG - 2020-04-06 17:10:43 --> module MX_Controller Initialized
INFO - 2020-04-06 17:10:44 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:10:44 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:10:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:10:44 --> Final output sent to browser
DEBUG - 2020-04-06 17:10:44 --> Total execution time: 2.0777
INFO - 2020-04-06 17:10:44 --> Config Class Initialized
INFO - 2020-04-06 17:10:44 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:10:44 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:10:44 --> Utf8 Class Initialized
INFO - 2020-04-06 17:10:44 --> URI Class Initialized
INFO - 2020-04-06 17:10:44 --> Router Class Initialized
INFO - 2020-04-06 17:10:44 --> Output Class Initialized
INFO - 2020-04-06 17:10:44 --> Config Class Initialized
INFO - 2020-04-06 17:10:44 --> Hooks Class Initialized
INFO - 2020-04-06 17:10:44 --> Security Class Initialized
DEBUG - 2020-04-06 17:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-06 17:10:44 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:10:44 --> CSRF cookie sent
INFO - 2020-04-06 17:10:44 --> Utf8 Class Initialized
INFO - 2020-04-06 17:10:44 --> Input Class Initialized
INFO - 2020-04-06 17:10:44 --> URI Class Initialized
INFO - 2020-04-06 17:10:44 --> Language Class Initialized
INFO - 2020-04-06 17:10:44 --> Router Class Initialized
ERROR - 2020-04-06 17:10:44 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:10:44 --> Output Class Initialized
INFO - 2020-04-06 17:10:44 --> Security Class Initialized
DEBUG - 2020-04-06 17:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:10:44 --> CSRF cookie sent
INFO - 2020-04-06 17:10:44 --> Input Class Initialized
INFO - 2020-04-06 17:10:44 --> Language Class Initialized
ERROR - 2020-04-06 17:10:44 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:10:46 --> Config Class Initialized
INFO - 2020-04-06 17:10:46 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:10:46 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:10:46 --> Utf8 Class Initialized
INFO - 2020-04-06 17:10:46 --> URI Class Initialized
INFO - 2020-04-06 17:10:46 --> Router Class Initialized
INFO - 2020-04-06 17:10:46 --> Output Class Initialized
INFO - 2020-04-06 17:10:46 --> Security Class Initialized
DEBUG - 2020-04-06 17:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:10:46 --> CSRF cookie sent
INFO - 2020-04-06 17:10:46 --> CSRF token verified
INFO - 2020-04-06 17:10:46 --> Input Class Initialized
INFO - 2020-04-06 17:10:46 --> Language Class Initialized
INFO - 2020-04-06 17:10:46 --> Language Class Initialized
INFO - 2020-04-06 17:10:46 --> Config Class Initialized
INFO - 2020-04-06 17:10:46 --> Loader Class Initialized
INFO - 2020-04-06 17:10:46 --> Helper loaded: url_helper
INFO - 2020-04-06 17:10:46 --> Helper loaded: file_helper
INFO - 2020-04-06 17:10:46 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:10:46 --> Helper loaded: common_helper
INFO - 2020-04-06 17:10:46 --> Helper loaded: language_helper
INFO - 2020-04-06 17:10:46 --> Helper loaded: email_helper
INFO - 2020-04-06 17:10:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:10:46 --> Database Driver Class Initialized
INFO - 2020-04-06 17:10:46 --> Parser Class Initialized
INFO - 2020-04-06 17:10:46 --> User Agent Class Initialized
INFO - 2020-04-06 17:10:46 --> Model Class Initialized
INFO - 2020-04-06 17:10:46 --> Model Class Initialized
DEBUG - 2020-04-06 17:10:46 --> Template Class Initialized
INFO - 2020-04-06 17:10:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:10:46 --> Email Class Initialized
INFO - 2020-04-06 17:10:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:10:46 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:10:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:10:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:10:46 --> Encryption Class Initialized
INFO - 2020-04-06 17:10:46 --> Controller Class Initialized
DEBUG - 2020-04-06 17:10:46 --> module MX_Controller Initialized
INFO - 2020-04-06 17:10:46 --> Model Class Initialized
INFO - 2020-04-06 17:10:58 --> Config Class Initialized
INFO - 2020-04-06 17:10:58 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:10:58 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:10:58 --> Utf8 Class Initialized
INFO - 2020-04-06 17:10:58 --> URI Class Initialized
INFO - 2020-04-06 17:10:58 --> Router Class Initialized
INFO - 2020-04-06 17:10:58 --> Output Class Initialized
INFO - 2020-04-06 17:10:58 --> Security Class Initialized
DEBUG - 2020-04-06 17:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:10:58 --> CSRF cookie sent
INFO - 2020-04-06 17:10:58 --> Input Class Initialized
INFO - 2020-04-06 17:10:58 --> Language Class Initialized
INFO - 2020-04-06 17:10:58 --> Language Class Initialized
INFO - 2020-04-06 17:10:58 --> Config Class Initialized
INFO - 2020-04-06 17:10:58 --> Loader Class Initialized
INFO - 2020-04-06 17:10:58 --> Helper loaded: url_helper
INFO - 2020-04-06 17:10:58 --> Helper loaded: file_helper
INFO - 2020-04-06 17:10:58 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:10:58 --> Helper loaded: common_helper
INFO - 2020-04-06 17:10:58 --> Helper loaded: language_helper
INFO - 2020-04-06 17:10:58 --> Helper loaded: email_helper
INFO - 2020-04-06 17:10:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:10:58 --> Database Driver Class Initialized
INFO - 2020-04-06 17:10:58 --> Parser Class Initialized
INFO - 2020-04-06 17:10:58 --> User Agent Class Initialized
INFO - 2020-04-06 17:10:58 --> Model Class Initialized
INFO - 2020-04-06 17:10:58 --> Model Class Initialized
DEBUG - 2020-04-06 17:10:58 --> Template Class Initialized
INFO - 2020-04-06 17:10:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:10:58 --> Email Class Initialized
INFO - 2020-04-06 17:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:10:58 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:10:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:10:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:10:58 --> Encryption Class Initialized
INFO - 2020-04-06 17:10:58 --> Controller Class Initialized
DEBUG - 2020-04-06 17:10:58 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:10:58 --> Model Class Initialized
DEBUG - 2020-04-06 17:10:58 --> module MX_Controller Initialized
INFO - 2020-04-06 17:11:00 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:11:00 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:11:00 --> Final output sent to browser
DEBUG - 2020-04-06 17:11:00 --> Total execution time: 1.9920
INFO - 2020-04-06 17:11:00 --> Config Class Initialized
INFO - 2020-04-06 17:11:00 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:11:00 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:00 --> Utf8 Class Initialized
INFO - 2020-04-06 17:11:00 --> URI Class Initialized
INFO - 2020-04-06 17:11:00 --> Router Class Initialized
INFO - 2020-04-06 17:11:00 --> Config Class Initialized
INFO - 2020-04-06 17:11:00 --> Hooks Class Initialized
INFO - 2020-04-06 17:11:00 --> Output Class Initialized
DEBUG - 2020-04-06 17:11:00 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:00 --> Utf8 Class Initialized
INFO - 2020-04-06 17:11:00 --> Security Class Initialized
INFO - 2020-04-06 17:11:00 --> URI Class Initialized
DEBUG - 2020-04-06 17:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:00 --> CSRF cookie sent
INFO - 2020-04-06 17:11:00 --> Router Class Initialized
INFO - 2020-04-06 17:11:00 --> Input Class Initialized
INFO - 2020-04-06 17:11:00 --> Output Class Initialized
INFO - 2020-04-06 17:11:00 --> Language Class Initialized
INFO - 2020-04-06 17:11:00 --> Security Class Initialized
ERROR - 2020-04-06 17:11:00 --> 404 Page Not Found: /index
DEBUG - 2020-04-06 17:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:00 --> CSRF cookie sent
INFO - 2020-04-06 17:11:01 --> Input Class Initialized
INFO - 2020-04-06 17:11:01 --> Language Class Initialized
ERROR - 2020-04-06 17:11:01 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:11:25 --> Config Class Initialized
INFO - 2020-04-06 17:11:25 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:11:25 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:25 --> Utf8 Class Initialized
INFO - 2020-04-06 17:11:25 --> URI Class Initialized
INFO - 2020-04-06 17:11:25 --> Router Class Initialized
INFO - 2020-04-06 17:11:25 --> Output Class Initialized
INFO - 2020-04-06 17:11:25 --> Security Class Initialized
DEBUG - 2020-04-06 17:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:25 --> CSRF cookie sent
INFO - 2020-04-06 17:11:25 --> Input Class Initialized
INFO - 2020-04-06 17:11:25 --> Language Class Initialized
INFO - 2020-04-06 17:11:25 --> Language Class Initialized
INFO - 2020-04-06 17:11:25 --> Config Class Initialized
INFO - 2020-04-06 17:11:25 --> Loader Class Initialized
INFO - 2020-04-06 17:11:25 --> Helper loaded: url_helper
INFO - 2020-04-06 17:11:25 --> Helper loaded: file_helper
INFO - 2020-04-06 17:11:25 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:11:25 --> Helper loaded: common_helper
INFO - 2020-04-06 17:11:25 --> Helper loaded: language_helper
INFO - 2020-04-06 17:11:25 --> Helper loaded: email_helper
INFO - 2020-04-06 17:11:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:11:25 --> Database Driver Class Initialized
INFO - 2020-04-06 17:11:25 --> Parser Class Initialized
INFO - 2020-04-06 17:11:25 --> User Agent Class Initialized
INFO - 2020-04-06 17:11:25 --> Model Class Initialized
INFO - 2020-04-06 17:11:25 --> Model Class Initialized
DEBUG - 2020-04-06 17:11:25 --> Template Class Initialized
INFO - 2020-04-06 17:11:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:11:25 --> Email Class Initialized
INFO - 2020-04-06 17:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:11:25 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:11:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:11:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:11:25 --> Encryption Class Initialized
INFO - 2020-04-06 17:11:25 --> Controller Class Initialized
DEBUG - 2020-04-06 17:11:25 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:11:25 --> Model Class Initialized
DEBUG - 2020-04-06 17:11:25 --> module MX_Controller Initialized
INFO - 2020-04-06 17:11:27 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:11:27 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:11:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:11:27 --> Final output sent to browser
DEBUG - 2020-04-06 17:11:27 --> Total execution time: 2.0683
INFO - 2020-04-06 17:11:27 --> Config Class Initialized
INFO - 2020-04-06 17:11:27 --> Config Class Initialized
INFO - 2020-04-06 17:11:27 --> Hooks Class Initialized
INFO - 2020-04-06 17:11:27 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:11:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-06 17:11:27 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:27 --> Utf8 Class Initialized
INFO - 2020-04-06 17:11:27 --> Utf8 Class Initialized
INFO - 2020-04-06 17:11:27 --> URI Class Initialized
INFO - 2020-04-06 17:11:27 --> URI Class Initialized
INFO - 2020-04-06 17:11:27 --> Router Class Initialized
INFO - 2020-04-06 17:11:27 --> Router Class Initialized
INFO - 2020-04-06 17:11:27 --> Output Class Initialized
INFO - 2020-04-06 17:11:27 --> Output Class Initialized
INFO - 2020-04-06 17:11:27 --> Security Class Initialized
INFO - 2020-04-06 17:11:27 --> Security Class Initialized
DEBUG - 2020-04-06 17:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-06 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:27 --> CSRF cookie sent
INFO - 2020-04-06 17:11:27 --> CSRF cookie sent
INFO - 2020-04-06 17:11:27 --> Input Class Initialized
INFO - 2020-04-06 17:11:27 --> Input Class Initialized
INFO - 2020-04-06 17:11:27 --> Language Class Initialized
INFO - 2020-04-06 17:11:27 --> Language Class Initialized
ERROR - 2020-04-06 17:11:27 --> 404 Page Not Found: /index
ERROR - 2020-04-06 17:11:27 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:11:48 --> Config Class Initialized
INFO - 2020-04-06 17:11:48 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:11:48 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:48 --> Utf8 Class Initialized
INFO - 2020-04-06 17:11:48 --> URI Class Initialized
INFO - 2020-04-06 17:11:48 --> Router Class Initialized
INFO - 2020-04-06 17:11:48 --> Output Class Initialized
INFO - 2020-04-06 17:11:48 --> Security Class Initialized
DEBUG - 2020-04-06 17:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:48 --> CSRF cookie sent
INFO - 2020-04-06 17:11:48 --> Input Class Initialized
INFO - 2020-04-06 17:11:48 --> Language Class Initialized
INFO - 2020-04-06 17:11:48 --> Language Class Initialized
INFO - 2020-04-06 17:11:48 --> Config Class Initialized
INFO - 2020-04-06 17:11:48 --> Loader Class Initialized
INFO - 2020-04-06 17:11:48 --> Helper loaded: url_helper
INFO - 2020-04-06 17:11:48 --> Helper loaded: file_helper
INFO - 2020-04-06 17:11:48 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:11:48 --> Helper loaded: common_helper
INFO - 2020-04-06 17:11:48 --> Helper loaded: language_helper
INFO - 2020-04-06 17:11:48 --> Helper loaded: email_helper
INFO - 2020-04-06 17:11:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:11:48 --> Database Driver Class Initialized
INFO - 2020-04-06 17:11:48 --> Parser Class Initialized
INFO - 2020-04-06 17:11:48 --> User Agent Class Initialized
INFO - 2020-04-06 17:11:48 --> Model Class Initialized
INFO - 2020-04-06 17:11:48 --> Model Class Initialized
DEBUG - 2020-04-06 17:11:48 --> Template Class Initialized
INFO - 2020-04-06 17:11:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:11:48 --> Email Class Initialized
INFO - 2020-04-06 17:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:11:48 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:11:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:11:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:11:48 --> Encryption Class Initialized
INFO - 2020-04-06 17:11:48 --> Controller Class Initialized
DEBUG - 2020-04-06 17:11:48 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:11:48 --> Model Class Initialized
DEBUG - 2020-04-06 17:11:48 --> module MX_Controller Initialized
INFO - 2020-04-06 17:11:50 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:11:50 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:11:50 --> Final output sent to browser
DEBUG - 2020-04-06 17:11:50 --> Total execution time: 2.0463
INFO - 2020-04-06 17:11:50 --> Config Class Initialized
INFO - 2020-04-06 17:11:50 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:11:50 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:50 --> Utf8 Class Initialized
INFO - 2020-04-06 17:11:50 --> URI Class Initialized
INFO - 2020-04-06 17:11:50 --> Router Class Initialized
INFO - 2020-04-06 17:11:50 --> Config Class Initialized
INFO - 2020-04-06 17:11:50 --> Hooks Class Initialized
INFO - 2020-04-06 17:11:50 --> Output Class Initialized
INFO - 2020-04-06 17:11:50 --> Security Class Initialized
DEBUG - 2020-04-06 17:11:50 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:50 --> Utf8 Class Initialized
DEBUG - 2020-04-06 17:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:50 --> CSRF cookie sent
INFO - 2020-04-06 17:11:50 --> URI Class Initialized
INFO - 2020-04-06 17:11:50 --> Input Class Initialized
INFO - 2020-04-06 17:11:50 --> Router Class Initialized
INFO - 2020-04-06 17:11:50 --> Language Class Initialized
INFO - 2020-04-06 17:11:50 --> Output Class Initialized
ERROR - 2020-04-06 17:11:50 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:11:50 --> Security Class Initialized
DEBUG - 2020-04-06 17:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:51 --> CSRF cookie sent
INFO - 2020-04-06 17:11:51 --> Input Class Initialized
INFO - 2020-04-06 17:11:51 --> Language Class Initialized
ERROR - 2020-04-06 17:11:51 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:11:52 --> Config Class Initialized
INFO - 2020-04-06 17:11:52 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:11:52 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:52 --> Utf8 Class Initialized
INFO - 2020-04-06 17:11:52 --> URI Class Initialized
INFO - 2020-04-06 17:11:52 --> Router Class Initialized
INFO - 2020-04-06 17:11:52 --> Output Class Initialized
INFO - 2020-04-06 17:11:52 --> Security Class Initialized
DEBUG - 2020-04-06 17:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:52 --> CSRF cookie sent
INFO - 2020-04-06 17:11:52 --> Input Class Initialized
INFO - 2020-04-06 17:11:52 --> Language Class Initialized
INFO - 2020-04-06 17:11:52 --> Language Class Initialized
INFO - 2020-04-06 17:11:52 --> Config Class Initialized
INFO - 2020-04-06 17:11:52 --> Loader Class Initialized
INFO - 2020-04-06 17:11:52 --> Helper loaded: url_helper
INFO - 2020-04-06 17:11:52 --> Helper loaded: file_helper
INFO - 2020-04-06 17:11:52 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:11:52 --> Helper loaded: common_helper
INFO - 2020-04-06 17:11:52 --> Helper loaded: language_helper
INFO - 2020-04-06 17:11:52 --> Helper loaded: email_helper
INFO - 2020-04-06 17:11:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:11:52 --> Database Driver Class Initialized
INFO - 2020-04-06 17:11:52 --> Parser Class Initialized
INFO - 2020-04-06 17:11:52 --> User Agent Class Initialized
INFO - 2020-04-06 17:11:52 --> Model Class Initialized
INFO - 2020-04-06 17:11:52 --> Model Class Initialized
DEBUG - 2020-04-06 17:11:53 --> Template Class Initialized
INFO - 2020-04-06 17:11:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:11:53 --> Email Class Initialized
INFO - 2020-04-06 17:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:11:53 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:11:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:11:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:11:53 --> Encryption Class Initialized
INFO - 2020-04-06 17:11:53 --> Controller Class Initialized
DEBUG - 2020-04-06 17:11:53 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:11:53 --> Model Class Initialized
DEBUG - 2020-04-06 17:11:53 --> module MX_Controller Initialized
INFO - 2020-04-06 17:11:54 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:11:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:11:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:11:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:11:54 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:11:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:11:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:11:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:11:54 --> Final output sent to browser
DEBUG - 2020-04-06 17:11:54 --> Total execution time: 2.0451
INFO - 2020-04-06 17:11:54 --> Config Class Initialized
INFO - 2020-04-06 17:11:54 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:11:54 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:54 --> Utf8 Class Initialized
INFO - 2020-04-06 17:11:55 --> URI Class Initialized
INFO - 2020-04-06 17:11:55 --> Config Class Initialized
INFO - 2020-04-06 17:11:55 --> Router Class Initialized
INFO - 2020-04-06 17:11:55 --> Hooks Class Initialized
INFO - 2020-04-06 17:11:55 --> Output Class Initialized
INFO - 2020-04-06 17:11:55 --> Security Class Initialized
DEBUG - 2020-04-06 17:11:55 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:11:55 --> Utf8 Class Initialized
DEBUG - 2020-04-06 17:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:55 --> CSRF cookie sent
INFO - 2020-04-06 17:11:55 --> URI Class Initialized
INFO - 2020-04-06 17:11:55 --> Input Class Initialized
INFO - 2020-04-06 17:11:55 --> Router Class Initialized
INFO - 2020-04-06 17:11:55 --> Language Class Initialized
INFO - 2020-04-06 17:11:55 --> Output Class Initialized
ERROR - 2020-04-06 17:11:55 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:11:55 --> Security Class Initialized
DEBUG - 2020-04-06 17:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:11:55 --> CSRF cookie sent
INFO - 2020-04-06 17:11:55 --> Input Class Initialized
INFO - 2020-04-06 17:11:55 --> Language Class Initialized
ERROR - 2020-04-06 17:11:55 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:12:01 --> Config Class Initialized
INFO - 2020-04-06 17:12:01 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:12:01 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:12:01 --> Utf8 Class Initialized
INFO - 2020-04-06 17:12:01 --> URI Class Initialized
INFO - 2020-04-06 17:12:01 --> Router Class Initialized
INFO - 2020-04-06 17:12:01 --> Output Class Initialized
INFO - 2020-04-06 17:12:01 --> Security Class Initialized
DEBUG - 2020-04-06 17:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:12:01 --> CSRF cookie sent
INFO - 2020-04-06 17:12:01 --> CSRF token verified
INFO - 2020-04-06 17:12:01 --> Input Class Initialized
INFO - 2020-04-06 17:12:01 --> Language Class Initialized
INFO - 2020-04-06 17:12:01 --> Language Class Initialized
INFO - 2020-04-06 17:12:01 --> Config Class Initialized
INFO - 2020-04-06 17:12:01 --> Loader Class Initialized
INFO - 2020-04-06 17:12:01 --> Helper loaded: url_helper
INFO - 2020-04-06 17:12:01 --> Helper loaded: file_helper
INFO - 2020-04-06 17:12:01 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:12:01 --> Helper loaded: common_helper
INFO - 2020-04-06 17:12:01 --> Helper loaded: language_helper
INFO - 2020-04-06 17:12:01 --> Helper loaded: email_helper
INFO - 2020-04-06 17:12:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:12:01 --> Database Driver Class Initialized
INFO - 2020-04-06 17:12:01 --> Parser Class Initialized
INFO - 2020-04-06 17:12:01 --> User Agent Class Initialized
INFO - 2020-04-06 17:12:01 --> Model Class Initialized
INFO - 2020-04-06 17:12:01 --> Model Class Initialized
DEBUG - 2020-04-06 17:12:01 --> Template Class Initialized
INFO - 2020-04-06 17:12:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:12:01 --> Email Class Initialized
INFO - 2020-04-06 17:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:12:01 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:12:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:12:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:12:01 --> Encryption Class Initialized
INFO - 2020-04-06 17:12:01 --> Controller Class Initialized
DEBUG - 2020-04-06 17:12:01 --> module MX_Controller Initialized
INFO - 2020-04-06 17:12:01 --> Model Class Initialized
INFO - 2020-04-06 17:12:10 --> Config Class Initialized
INFO - 2020-04-06 17:12:10 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:12:10 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:12:10 --> Utf8 Class Initialized
INFO - 2020-04-06 17:12:10 --> URI Class Initialized
INFO - 2020-04-06 17:12:10 --> Router Class Initialized
INFO - 2020-04-06 17:12:10 --> Output Class Initialized
INFO - 2020-04-06 17:12:10 --> Security Class Initialized
DEBUG - 2020-04-06 17:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:12:10 --> CSRF cookie sent
INFO - 2020-04-06 17:12:10 --> Input Class Initialized
INFO - 2020-04-06 17:12:10 --> Language Class Initialized
INFO - 2020-04-06 17:12:10 --> Language Class Initialized
INFO - 2020-04-06 17:12:10 --> Config Class Initialized
INFO - 2020-04-06 17:12:10 --> Loader Class Initialized
INFO - 2020-04-06 17:12:10 --> Helper loaded: url_helper
INFO - 2020-04-06 17:12:10 --> Helper loaded: file_helper
INFO - 2020-04-06 17:12:10 --> Helper loaded: cookie_helper
INFO - 2020-04-06 17:12:10 --> Helper loaded: common_helper
INFO - 2020-04-06 17:12:10 --> Helper loaded: language_helper
INFO - 2020-04-06 17:12:10 --> Helper loaded: email_helper
INFO - 2020-04-06 17:12:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-06 17:12:10 --> Database Driver Class Initialized
INFO - 2020-04-06 17:12:10 --> Parser Class Initialized
INFO - 2020-04-06 17:12:10 --> User Agent Class Initialized
INFO - 2020-04-06 17:12:11 --> Model Class Initialized
INFO - 2020-04-06 17:12:11 --> Model Class Initialized
DEBUG - 2020-04-06 17:12:11 --> Template Class Initialized
INFO - 2020-04-06 17:12:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-06 17:12:11 --> Email Class Initialized
INFO - 2020-04-06 17:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-06 17:12:11 --> Pagination Class Initialized
DEBUG - 2020-04-06 17:12:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-06 17:12:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-06 17:12:11 --> Encryption Class Initialized
INFO - 2020-04-06 17:12:11 --> Controller Class Initialized
DEBUG - 2020-04-06 17:12:11 --> settings MX_Controller Initialized
INFO - 2020-04-06 17:12:11 --> Model Class Initialized
DEBUG - 2020-04-06 17:12:11 --> module MX_Controller Initialized
INFO - 2020-04-06 17:12:12 --> Helper loaded: inflector_helper
DEBUG - 2020-04-06 17:12:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/module.php
DEBUG - 2020-04-06 17:12:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-06 17:12:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-06 17:12:12 --> blocks MX_Controller Initialized
DEBUG - 2020-04-06 17:12:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-06 17:12:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-06 17:12:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-06 17:12:12 --> Final output sent to browser
DEBUG - 2020-04-06 17:12:12 --> Total execution time: 2.0776
INFO - 2020-04-06 17:12:12 --> Config Class Initialized
INFO - 2020-04-06 17:12:12 --> Hooks Class Initialized
DEBUG - 2020-04-06 17:12:12 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:12:12 --> Utf8 Class Initialized
INFO - 2020-04-06 17:12:12 --> URI Class Initialized
INFO - 2020-04-06 17:12:13 --> Router Class Initialized
INFO - 2020-04-06 17:12:13 --> Output Class Initialized
INFO - 2020-04-06 17:12:13 --> Security Class Initialized
DEBUG - 2020-04-06 17:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:12:13 --> CSRF cookie sent
INFO - 2020-04-06 17:12:13 --> Config Class Initialized
INFO - 2020-04-06 17:12:13 --> Hooks Class Initialized
INFO - 2020-04-06 17:12:13 --> Input Class Initialized
INFO - 2020-04-06 17:12:13 --> Language Class Initialized
DEBUG - 2020-04-06 17:12:13 --> UTF-8 Support Enabled
INFO - 2020-04-06 17:12:13 --> Utf8 Class Initialized
ERROR - 2020-04-06 17:12:13 --> 404 Page Not Found: /index
INFO - 2020-04-06 17:12:13 --> URI Class Initialized
INFO - 2020-04-06 17:12:13 --> Router Class Initialized
INFO - 2020-04-06 17:12:13 --> Output Class Initialized
INFO - 2020-04-06 17:12:13 --> Security Class Initialized
DEBUG - 2020-04-06 17:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-06 17:12:13 --> CSRF cookie sent
INFO - 2020-04-06 17:12:13 --> Input Class Initialized
INFO - 2020-04-06 17:12:13 --> Language Class Initialized
ERROR - 2020-04-06 17:12:13 --> 404 Page Not Found: /index
