<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-14 21:38:36 --> Config Class Initialized
INFO - 2019-12-14 21:38:36 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:38:36 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:38:36 --> Utf8 Class Initialized
INFO - 2019-12-14 21:38:36 --> URI Class Initialized
DEBUG - 2019-12-14 21:38:36 --> No URI present. Default controller set.
INFO - 2019-12-14 21:38:36 --> Router Class Initialized
INFO - 2019-12-14 21:38:36 --> Output Class Initialized
INFO - 2019-12-14 21:38:36 --> Security Class Initialized
DEBUG - 2019-12-14 21:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:38:36 --> CSRF cookie sent
INFO - 2019-12-14 21:38:36 --> Input Class Initialized
INFO - 2019-12-14 21:38:36 --> Language Class Initialized
INFO - 2019-12-14 21:38:36 --> Language Class Initialized
INFO - 2019-12-14 21:38:36 --> Config Class Initialized
INFO - 2019-12-14 21:38:36 --> Loader Class Initialized
INFO - 2019-12-14 21:38:36 --> Helper loaded: url_helper
INFO - 2019-12-14 21:38:36 --> Helper loaded: common_helper
INFO - 2019-12-14 21:38:36 --> Helper loaded: language_helper
INFO - 2019-12-14 21:38:36 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:38:36 --> Helper loaded: email_helper
INFO - 2019-12-14 21:38:36 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:38:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:38:36 --> Parser Class Initialized
INFO - 2019-12-14 21:38:36 --> User Agent Class Initialized
INFO - 2019-12-14 21:38:36 --> Model Class Initialized
INFO - 2019-12-14 21:38:36 --> Database Driver Class Initialized
INFO - 2019-12-14 21:38:36 --> Model Class Initialized
DEBUG - 2019-12-14 21:38:36 --> Template Class Initialized
INFO - 2019-12-14 21:38:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:38:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:38:36 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:38:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:38:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:38:36 --> Encryption Class Initialized
DEBUG - 2019-12-14 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-14 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-14 21:38:36 --> Controller Class Initialized
DEBUG - 2019-12-14 21:38:36 --> pergo MX_Controller Initialized
DEBUG - 2019-12-14 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-14 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-14 21:38:37 --> Model Class Initialized
INFO - 2019-12-14 21:38:37 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-14 21:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-14 21:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-14 21:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-14 21:38:37 --> Final output sent to browser
DEBUG - 2019-12-14 21:38:37 --> Total execution time: 1.4940
INFO - 2019-12-14 21:38:40 --> Config Class Initialized
INFO - 2019-12-14 21:38:40 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:38:40 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:38:40 --> Utf8 Class Initialized
INFO - 2019-12-14 21:38:40 --> URI Class Initialized
INFO - 2019-12-14 21:38:40 --> Router Class Initialized
INFO - 2019-12-14 21:38:40 --> Output Class Initialized
INFO - 2019-12-14 21:38:40 --> Security Class Initialized
DEBUG - 2019-12-14 21:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:38:40 --> CSRF cookie sent
INFO - 2019-12-14 21:38:40 --> Input Class Initialized
INFO - 2019-12-14 21:38:40 --> Language Class Initialized
INFO - 2019-12-14 21:38:40 --> Language Class Initialized
INFO - 2019-12-14 21:38:40 --> Config Class Initialized
INFO - 2019-12-14 21:38:40 --> Loader Class Initialized
INFO - 2019-12-14 21:38:40 --> Helper loaded: url_helper
INFO - 2019-12-14 21:38:40 --> Helper loaded: common_helper
INFO - 2019-12-14 21:38:40 --> Helper loaded: language_helper
INFO - 2019-12-14 21:38:40 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:38:40 --> Helper loaded: email_helper
INFO - 2019-12-14 21:38:40 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:38:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:38:40 --> Parser Class Initialized
INFO - 2019-12-14 21:38:40 --> User Agent Class Initialized
INFO - 2019-12-14 21:38:40 --> Model Class Initialized
INFO - 2019-12-14 21:38:40 --> Database Driver Class Initialized
INFO - 2019-12-14 21:38:40 --> Model Class Initialized
DEBUG - 2019-12-14 21:38:40 --> Template Class Initialized
INFO - 2019-12-14 21:38:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:38:40 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:38:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:38:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:38:40 --> Encryption Class Initialized
INFO - 2019-12-14 21:38:40 --> Controller Class Initialized
DEBUG - 2019-12-14 21:38:40 --> package MX_Controller Initialized
DEBUG - 2019-12-14 21:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-14 21:38:41 --> Model Class Initialized
INFO - 2019-12-14 21:38:41 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:38:41 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:38:41 --> Model Class Initialized
DEBUG - 2019-12-14 21:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:38:41 --> Model Class Initialized
DEBUG - 2019-12-14 21:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-14 21:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-14 21:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 21:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 21:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 21:38:41 --> Final output sent to browser
DEBUG - 2019-12-14 21:38:41 --> Total execution time: 1.3941
INFO - 2019-12-14 21:38:49 --> Config Class Initialized
INFO - 2019-12-14 21:38:49 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:38:49 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:38:49 --> Utf8 Class Initialized
INFO - 2019-12-14 21:38:49 --> URI Class Initialized
INFO - 2019-12-14 21:38:49 --> Router Class Initialized
INFO - 2019-12-14 21:38:49 --> Output Class Initialized
INFO - 2019-12-14 21:38:49 --> Security Class Initialized
DEBUG - 2019-12-14 21:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:38:49 --> CSRF cookie sent
INFO - 2019-12-14 21:38:49 --> Input Class Initialized
INFO - 2019-12-14 21:38:49 --> Language Class Initialized
INFO - 2019-12-14 21:38:49 --> Language Class Initialized
INFO - 2019-12-14 21:38:49 --> Config Class Initialized
INFO - 2019-12-14 21:38:49 --> Loader Class Initialized
INFO - 2019-12-14 21:38:49 --> Helper loaded: url_helper
INFO - 2019-12-14 21:38:49 --> Helper loaded: common_helper
INFO - 2019-12-14 21:38:49 --> Helper loaded: language_helper
INFO - 2019-12-14 21:38:49 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:38:49 --> Helper loaded: email_helper
INFO - 2019-12-14 21:38:49 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:38:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:38:49 --> Parser Class Initialized
INFO - 2019-12-14 21:38:49 --> User Agent Class Initialized
INFO - 2019-12-14 21:38:49 --> Model Class Initialized
INFO - 2019-12-14 21:38:49 --> Database Driver Class Initialized
INFO - 2019-12-14 21:38:49 --> Model Class Initialized
DEBUG - 2019-12-14 21:38:49 --> Template Class Initialized
INFO - 2019-12-14 21:38:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:38:49 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:38:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:38:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:38:49 --> Encryption Class Initialized
INFO - 2019-12-14 21:38:49 --> Controller Class Initialized
DEBUG - 2019-12-14 21:38:49 --> auth MX_Controller Initialized
DEBUG - 2019-12-14 21:38:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-14 21:38:49 --> Model Class Initialized
DEBUG - 2019-12-14 21:38:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-14 21:38:49 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:38:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-12-14 21:38:49 --> pergo MX_Controller Initialized
DEBUG - 2019-12-14 21:38:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-14 21:38:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-12-14 21:38:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-14 21:38:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-14 21:38:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-12-14 21:38:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-14 21:38:49 --> Final output sent to browser
DEBUG - 2019-12-14 21:38:49 --> Total execution time: 0.5599
INFO - 2019-12-14 21:38:51 --> Config Class Initialized
INFO - 2019-12-14 21:38:51 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:38:51 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:38:51 --> Utf8 Class Initialized
INFO - 2019-12-14 21:38:52 --> URI Class Initialized
INFO - 2019-12-14 21:38:52 --> Router Class Initialized
INFO - 2019-12-14 21:38:52 --> Output Class Initialized
INFO - 2019-12-14 21:38:52 --> Security Class Initialized
DEBUG - 2019-12-14 21:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:38:52 --> CSRF cookie sent
INFO - 2019-12-14 21:38:56 --> Config Class Initialized
INFO - 2019-12-14 21:38:56 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:38:56 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:38:56 --> Utf8 Class Initialized
INFO - 2019-12-14 21:38:56 --> URI Class Initialized
INFO - 2019-12-14 21:38:56 --> Router Class Initialized
INFO - 2019-12-14 21:38:56 --> Output Class Initialized
INFO - 2019-12-14 21:38:56 --> Security Class Initialized
DEBUG - 2019-12-14 21:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:38:56 --> CSRF cookie sent
INFO - 2019-12-14 21:38:56 --> CSRF token verified
INFO - 2019-12-14 21:38:56 --> Input Class Initialized
INFO - 2019-12-14 21:38:56 --> Language Class Initialized
INFO - 2019-12-14 21:38:56 --> Language Class Initialized
INFO - 2019-12-14 21:38:56 --> Config Class Initialized
INFO - 2019-12-14 21:38:56 --> Loader Class Initialized
INFO - 2019-12-14 21:38:56 --> Helper loaded: url_helper
INFO - 2019-12-14 21:38:56 --> Helper loaded: common_helper
INFO - 2019-12-14 21:38:56 --> Helper loaded: language_helper
INFO - 2019-12-14 21:38:56 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:38:56 --> Helper loaded: email_helper
INFO - 2019-12-14 21:38:56 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:38:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:38:56 --> Parser Class Initialized
INFO - 2019-12-14 21:38:56 --> User Agent Class Initialized
INFO - 2019-12-14 21:38:56 --> Model Class Initialized
INFO - 2019-12-14 21:38:56 --> Database Driver Class Initialized
INFO - 2019-12-14 21:38:56 --> Model Class Initialized
DEBUG - 2019-12-14 21:38:56 --> Template Class Initialized
INFO - 2019-12-14 21:38:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:38:56 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:38:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:38:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:38:56 --> Encryption Class Initialized
INFO - 2019-12-14 21:38:56 --> Controller Class Initialized
DEBUG - 2019-12-14 21:38:56 --> auth MX_Controller Initialized
DEBUG - 2019-12-14 21:38:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-14 21:38:56 --> Model Class Initialized
INFO - 2019-12-14 21:39:00 --> Config Class Initialized
INFO - 2019-12-14 21:39:00 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:39:00 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:39:00 --> Utf8 Class Initialized
INFO - 2019-12-14 21:39:00 --> URI Class Initialized
INFO - 2019-12-14 21:39:00 --> Router Class Initialized
INFO - 2019-12-14 21:39:00 --> Output Class Initialized
INFO - 2019-12-14 21:39:00 --> Security Class Initialized
DEBUG - 2019-12-14 21:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:39:00 --> CSRF cookie sent
INFO - 2019-12-14 21:39:00 --> Input Class Initialized
INFO - 2019-12-14 21:39:00 --> Language Class Initialized
INFO - 2019-12-14 21:39:00 --> Language Class Initialized
INFO - 2019-12-14 21:39:00 --> Config Class Initialized
INFO - 2019-12-14 21:39:00 --> Loader Class Initialized
INFO - 2019-12-14 21:39:00 --> Helper loaded: url_helper
INFO - 2019-12-14 21:39:00 --> Helper loaded: common_helper
INFO - 2019-12-14 21:39:00 --> Helper loaded: language_helper
INFO - 2019-12-14 21:39:00 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:39:00 --> Helper loaded: email_helper
INFO - 2019-12-14 21:39:00 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:39:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:39:00 --> Parser Class Initialized
INFO - 2019-12-14 21:39:00 --> User Agent Class Initialized
INFO - 2019-12-14 21:39:00 --> Model Class Initialized
INFO - 2019-12-14 21:39:00 --> Database Driver Class Initialized
INFO - 2019-12-14 21:39:00 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:00 --> Template Class Initialized
INFO - 2019-12-14 21:39:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:39:00 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:39:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:39:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:39:01 --> Encryption Class Initialized
INFO - 2019-12-14 21:39:01 --> Controller Class Initialized
DEBUG - 2019-12-14 21:39:01 --> package MX_Controller Initialized
DEBUG - 2019-12-14 21:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-14 21:39:01 --> Model Class Initialized
INFO - 2019-12-14 21:39:01 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:39:01 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:39:01 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:39:01 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-14 21:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-14 21:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 21:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 21:39:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 21:39:01 --> Final output sent to browser
DEBUG - 2019-12-14 21:39:01 --> Total execution time: 0.6507
INFO - 2019-12-14 21:39:02 --> Config Class Initialized
INFO - 2019-12-14 21:39:02 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:39:02 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:39:02 --> Utf8 Class Initialized
INFO - 2019-12-14 21:39:02 --> URI Class Initialized
INFO - 2019-12-14 21:39:02 --> Router Class Initialized
INFO - 2019-12-14 21:39:02 --> Output Class Initialized
INFO - 2019-12-14 21:39:02 --> Security Class Initialized
DEBUG - 2019-12-14 21:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:39:02 --> CSRF cookie sent
INFO - 2019-12-14 21:39:02 --> Input Class Initialized
INFO - 2019-12-14 21:39:02 --> Language Class Initialized
INFO - 2019-12-14 21:39:02 --> Language Class Initialized
INFO - 2019-12-14 21:39:02 --> Config Class Initialized
INFO - 2019-12-14 21:39:02 --> Loader Class Initialized
INFO - 2019-12-14 21:39:02 --> Helper loaded: url_helper
INFO - 2019-12-14 21:39:02 --> Helper loaded: common_helper
INFO - 2019-12-14 21:39:02 --> Helper loaded: language_helper
INFO - 2019-12-14 21:39:02 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:39:02 --> Helper loaded: email_helper
INFO - 2019-12-14 21:39:02 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:39:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:39:02 --> Parser Class Initialized
INFO - 2019-12-14 21:39:02 --> User Agent Class Initialized
INFO - 2019-12-14 21:39:02 --> Model Class Initialized
INFO - 2019-12-14 21:39:02 --> Database Driver Class Initialized
INFO - 2019-12-14 21:39:02 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:02 --> Template Class Initialized
INFO - 2019-12-14 21:39:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:39:02 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:39:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:39:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:39:02 --> Encryption Class Initialized
INFO - 2019-12-14 21:39:02 --> Controller Class Initialized
DEBUG - 2019-12-14 21:39:02 --> statistics MX_Controller Initialized
DEBUG - 2019-12-14 21:39:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-14 21:39:02 --> Model Class Initialized
ERROR - 2019-12-14 21:39:02 --> Could not find the language line "Pending"
ERROR - 2019-12-14 21:39:02 --> Could not find the language line "Pending"
INFO - 2019-12-14 21:39:02 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 21:39:02 --> Could not find the language line "total_orders"
ERROR - 2019-12-14 21:39:02 --> Could not find the language line "total_orders"
ERROR - 2019-12-14 21:39:03 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 21:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-12-14 21:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:39:03 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:39:03 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:39:03 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 21:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 21:39:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 21:39:03 --> Final output sent to browser
DEBUG - 2019-12-14 21:39:03 --> Total execution time: 1.0516
INFO - 2019-12-14 21:39:04 --> Config Class Initialized
INFO - 2019-12-14 21:39:04 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:39:04 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:39:04 --> Utf8 Class Initialized
INFO - 2019-12-14 21:39:04 --> URI Class Initialized
INFO - 2019-12-14 21:39:04 --> Router Class Initialized
INFO - 2019-12-14 21:39:04 --> Output Class Initialized
INFO - 2019-12-14 21:39:04 --> Security Class Initialized
DEBUG - 2019-12-14 21:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:39:04 --> CSRF cookie sent
INFO - 2019-12-14 21:39:04 --> CSRF token verified
INFO - 2019-12-14 21:39:04 --> Input Class Initialized
INFO - 2019-12-14 21:39:04 --> Language Class Initialized
INFO - 2019-12-14 21:39:04 --> Language Class Initialized
INFO - 2019-12-14 21:39:04 --> Config Class Initialized
INFO - 2019-12-14 21:39:04 --> Loader Class Initialized
INFO - 2019-12-14 21:39:04 --> Helper loaded: url_helper
INFO - 2019-12-14 21:39:04 --> Helper loaded: common_helper
INFO - 2019-12-14 21:39:04 --> Helper loaded: language_helper
INFO - 2019-12-14 21:39:04 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:39:04 --> Helper loaded: email_helper
INFO - 2019-12-14 21:39:04 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:39:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:39:04 --> Parser Class Initialized
INFO - 2019-12-14 21:39:04 --> User Agent Class Initialized
INFO - 2019-12-14 21:39:04 --> Model Class Initialized
INFO - 2019-12-14 21:39:04 --> Database Driver Class Initialized
INFO - 2019-12-14 21:39:04 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:04 --> Template Class Initialized
INFO - 2019-12-14 21:39:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:39:04 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:39:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:39:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:39:04 --> Encryption Class Initialized
INFO - 2019-12-14 21:39:04 --> Controller Class Initialized
DEBUG - 2019-12-14 21:39:04 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 21:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 21:39:05 --> Model Class Initialized
INFO - 2019-12-14 21:39:05 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 21:39:05 --> Could not find the language line "hesabe"
ERROR - 2019-12-14 21:39:05 --> Could not find the language line "payop"
ERROR - 2019-12-14 21:39:05 --> Could not find the language line "shopier"
DEBUG - 2019-12-14 21:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-14 21:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:39:05 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:39:05 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:39:05 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 21:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 21:39:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 21:39:05 --> Final output sent to browser
DEBUG - 2019-12-14 21:39:05 --> Total execution time: 0.8189
INFO - 2019-12-14 21:39:16 --> Config Class Initialized
INFO - 2019-12-14 21:39:16 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:39:16 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:39:16 --> Utf8 Class Initialized
INFO - 2019-12-14 21:39:16 --> URI Class Initialized
INFO - 2019-12-14 21:39:16 --> Router Class Initialized
INFO - 2019-12-14 21:39:16 --> Output Class Initialized
INFO - 2019-12-14 21:39:17 --> Security Class Initialized
DEBUG - 2019-12-14 21:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:39:17 --> CSRF cookie sent
INFO - 2019-12-14 21:39:17 --> CSRF token verified
INFO - 2019-12-14 21:39:17 --> Input Class Initialized
INFO - 2019-12-14 21:39:17 --> Language Class Initialized
INFO - 2019-12-14 21:39:17 --> Language Class Initialized
INFO - 2019-12-14 21:39:17 --> Config Class Initialized
INFO - 2019-12-14 21:39:17 --> Loader Class Initialized
INFO - 2019-12-14 21:39:17 --> Helper loaded: url_helper
INFO - 2019-12-14 21:39:17 --> Helper loaded: common_helper
INFO - 2019-12-14 21:39:17 --> Helper loaded: language_helper
INFO - 2019-12-14 21:39:17 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:39:17 --> Helper loaded: email_helper
INFO - 2019-12-14 21:39:17 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:39:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:39:17 --> Parser Class Initialized
INFO - 2019-12-14 21:39:17 --> User Agent Class Initialized
INFO - 2019-12-14 21:39:17 --> Model Class Initialized
INFO - 2019-12-14 21:39:17 --> Database Driver Class Initialized
INFO - 2019-12-14 21:39:17 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:17 --> Template Class Initialized
INFO - 2019-12-14 21:39:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:39:17 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:39:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:39:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:39:17 --> Encryption Class Initialized
INFO - 2019-12-14 21:39:17 --> Controller Class Initialized
DEBUG - 2019-12-14 21:39:17 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 21:39:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 21:39:17 --> Model Class Initialized
DEBUG - 2019-12-14 21:39:17 --> dotpay MX_Controller Initialized
INFO - 2019-12-14 21:52:37 --> Config Class Initialized
INFO - 2019-12-14 21:52:37 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:52:37 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:52:37 --> Utf8 Class Initialized
INFO - 2019-12-14 21:52:37 --> URI Class Initialized
INFO - 2019-12-14 21:52:37 --> Router Class Initialized
INFO - 2019-12-14 21:52:37 --> Output Class Initialized
INFO - 2019-12-14 21:52:37 --> Security Class Initialized
DEBUG - 2019-12-14 21:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:52:37 --> CSRF cookie sent
INFO - 2019-12-14 21:52:37 --> Input Class Initialized
INFO - 2019-12-14 21:52:37 --> Language Class Initialized
INFO - 2019-12-14 21:52:37 --> Language Class Initialized
INFO - 2019-12-14 21:52:37 --> Config Class Initialized
INFO - 2019-12-14 21:52:37 --> Loader Class Initialized
INFO - 2019-12-14 21:52:37 --> Helper loaded: url_helper
INFO - 2019-12-14 21:52:37 --> Helper loaded: common_helper
INFO - 2019-12-14 21:52:37 --> Helper loaded: language_helper
INFO - 2019-12-14 21:52:37 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:52:37 --> Helper loaded: email_helper
INFO - 2019-12-14 21:52:37 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:52:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:52:37 --> Parser Class Initialized
INFO - 2019-12-14 21:52:37 --> User Agent Class Initialized
INFO - 2019-12-14 21:52:37 --> Model Class Initialized
INFO - 2019-12-14 21:52:37 --> Database Driver Class Initialized
INFO - 2019-12-14 21:52:37 --> Model Class Initialized
DEBUG - 2019-12-14 21:52:37 --> Template Class Initialized
INFO - 2019-12-14 21:52:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:52:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:52:37 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:52:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:52:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:52:37 --> Encryption Class Initialized
INFO - 2019-12-14 21:52:37 --> Controller Class Initialized
DEBUG - 2019-12-14 21:52:37 --> setting MX_Controller Initialized
DEBUG - 2019-12-14 21:52:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-14 21:52:37 --> Model Class Initialized
INFO - 2019-12-14 21:52:37 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:52:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-14 21:52:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-12-14 21:52:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-14 21:52:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:52:38 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:52:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:52:38 --> Model Class Initialized
DEBUG - 2019-12-14 21:52:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:52:38 --> Model Class Initialized
DEBUG - 2019-12-14 21:52:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 21:52:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 21:52:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 21:52:38 --> Final output sent to browser
DEBUG - 2019-12-14 21:52:38 --> Total execution time: 0.7809
INFO - 2019-12-14 21:52:40 --> Config Class Initialized
INFO - 2019-12-14 21:52:40 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:52:40 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:52:40 --> Utf8 Class Initialized
INFO - 2019-12-14 21:52:40 --> URI Class Initialized
INFO - 2019-12-14 21:52:40 --> Router Class Initialized
INFO - 2019-12-14 21:52:40 --> Output Class Initialized
INFO - 2019-12-14 21:52:40 --> Security Class Initialized
DEBUG - 2019-12-14 21:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:52:40 --> CSRF cookie sent
INFO - 2019-12-14 21:52:40 --> Input Class Initialized
INFO - 2019-12-14 21:52:40 --> Language Class Initialized
INFO - 2019-12-14 21:52:40 --> Language Class Initialized
INFO - 2019-12-14 21:52:40 --> Config Class Initialized
INFO - 2019-12-14 21:52:40 --> Loader Class Initialized
INFO - 2019-12-14 21:52:40 --> Helper loaded: url_helper
INFO - 2019-12-14 21:52:40 --> Helper loaded: common_helper
INFO - 2019-12-14 21:52:40 --> Helper loaded: language_helper
INFO - 2019-12-14 21:52:40 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:52:40 --> Helper loaded: email_helper
INFO - 2019-12-14 21:52:40 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:52:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:52:40 --> Parser Class Initialized
INFO - 2019-12-14 21:52:40 --> User Agent Class Initialized
INFO - 2019-12-14 21:52:40 --> Model Class Initialized
INFO - 2019-12-14 21:52:41 --> Database Driver Class Initialized
INFO - 2019-12-14 21:52:41 --> Model Class Initialized
DEBUG - 2019-12-14 21:52:41 --> Template Class Initialized
INFO - 2019-12-14 21:52:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:52:41 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:52:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:52:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:52:41 --> Encryption Class Initialized
INFO - 2019-12-14 21:52:41 --> Controller Class Initialized
DEBUG - 2019-12-14 21:52:41 --> setting MX_Controller Initialized
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-14 21:52:41 --> Model Class Initialized
INFO - 2019-12-14 21:52:41 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:52:41 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:52:41 --> Model Class Initialized
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:52:41 --> Model Class Initialized
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 21:52:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 21:52:41 --> Final output sent to browser
DEBUG - 2019-12-14 21:52:41 --> Total execution time: 0.6330
INFO - 2019-12-14 21:56:10 --> Config Class Initialized
INFO - 2019-12-14 21:56:10 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:56:10 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:56:10 --> Utf8 Class Initialized
INFO - 2019-12-14 21:56:10 --> URI Class Initialized
INFO - 2019-12-14 21:56:10 --> Router Class Initialized
INFO - 2019-12-14 21:56:10 --> Output Class Initialized
INFO - 2019-12-14 21:56:10 --> Security Class Initialized
DEBUG - 2019-12-14 21:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:56:10 --> CSRF cookie sent
INFO - 2019-12-14 21:56:10 --> CSRF token verified
INFO - 2019-12-14 21:56:10 --> Input Class Initialized
INFO - 2019-12-14 21:56:10 --> Language Class Initialized
INFO - 2019-12-14 21:56:11 --> Language Class Initialized
INFO - 2019-12-14 21:56:11 --> Config Class Initialized
INFO - 2019-12-14 21:56:11 --> Loader Class Initialized
INFO - 2019-12-14 21:56:11 --> Helper loaded: url_helper
INFO - 2019-12-14 21:56:11 --> Helper loaded: common_helper
INFO - 2019-12-14 21:56:11 --> Helper loaded: language_helper
INFO - 2019-12-14 21:56:11 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:56:11 --> Helper loaded: email_helper
INFO - 2019-12-14 21:56:11 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:56:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:56:11 --> Parser Class Initialized
INFO - 2019-12-14 21:56:11 --> User Agent Class Initialized
INFO - 2019-12-14 21:56:11 --> Model Class Initialized
INFO - 2019-12-14 21:56:11 --> Database Driver Class Initialized
INFO - 2019-12-14 21:56:11 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:11 --> Template Class Initialized
INFO - 2019-12-14 21:56:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:56:11 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:56:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:56:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:56:11 --> Encryption Class Initialized
INFO - 2019-12-14 21:56:11 --> Controller Class Initialized
DEBUG - 2019-12-14 21:56:11 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 21:56:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 21:56:11 --> Model Class Initialized
INFO - 2019-12-14 21:56:11 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 21:56:11 --> Could not find the language line "hesabe"
ERROR - 2019-12-14 21:56:11 --> Could not find the language line "payop"
ERROR - 2019-12-14 21:56:11 --> Could not find the language line "shopier"
DEBUG - 2019-12-14 21:56:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-14 21:56:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:56:11 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:56:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:56:11 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:56:11 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 21:56:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 21:56:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 21:56:11 --> Final output sent to browser
DEBUG - 2019-12-14 21:56:11 --> Total execution time: 0.7964
INFO - 2019-12-14 21:56:23 --> Config Class Initialized
INFO - 2019-12-14 21:56:23 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:56:23 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:56:23 --> Utf8 Class Initialized
INFO - 2019-12-14 21:56:23 --> URI Class Initialized
INFO - 2019-12-14 21:56:23 --> Router Class Initialized
INFO - 2019-12-14 21:56:23 --> Output Class Initialized
INFO - 2019-12-14 21:56:23 --> Security Class Initialized
DEBUG - 2019-12-14 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:56:23 --> CSRF cookie sent
INFO - 2019-12-14 21:56:23 --> CSRF token verified
INFO - 2019-12-14 21:56:23 --> Input Class Initialized
INFO - 2019-12-14 21:56:23 --> Language Class Initialized
INFO - 2019-12-14 21:56:23 --> Language Class Initialized
INFO - 2019-12-14 21:56:23 --> Config Class Initialized
INFO - 2019-12-14 21:56:23 --> Loader Class Initialized
INFO - 2019-12-14 21:56:23 --> Helper loaded: url_helper
INFO - 2019-12-14 21:56:23 --> Helper loaded: common_helper
INFO - 2019-12-14 21:56:23 --> Helper loaded: language_helper
INFO - 2019-12-14 21:56:23 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:56:23 --> Helper loaded: email_helper
INFO - 2019-12-14 21:56:23 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:56:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:56:23 --> Parser Class Initialized
INFO - 2019-12-14 21:56:23 --> User Agent Class Initialized
INFO - 2019-12-14 21:56:23 --> Model Class Initialized
INFO - 2019-12-14 21:56:23 --> Database Driver Class Initialized
INFO - 2019-12-14 21:56:23 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:23 --> Template Class Initialized
INFO - 2019-12-14 21:56:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:56:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:56:23 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:56:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:56:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:56:23 --> Encryption Class Initialized
INFO - 2019-12-14 21:56:23 --> Controller Class Initialized
DEBUG - 2019-12-14 21:56:23 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 21:56:23 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:23 --> dotpay MX_Controller Initialized
DEBUG - 2019-12-14 21:56:23 --> orders MX_Controller Initialized
DEBUG - 2019-12-14 21:56:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-12-14 21:56:23 --> Final output sent to browser
DEBUG - 2019-12-14 21:56:23 --> Total execution time: 0.5945
INFO - 2019-12-14 21:56:33 --> Config Class Initialized
INFO - 2019-12-14 21:56:33 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:56:33 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:56:33 --> Utf8 Class Initialized
INFO - 2019-12-14 21:56:33 --> URI Class Initialized
INFO - 2019-12-14 21:56:33 --> Router Class Initialized
INFO - 2019-12-14 21:56:33 --> Output Class Initialized
INFO - 2019-12-14 21:56:33 --> Security Class Initialized
DEBUG - 2019-12-14 21:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:56:33 --> CSRF cookie sent
INFO - 2019-12-14 21:56:33 --> Input Class Initialized
INFO - 2019-12-14 21:56:33 --> Language Class Initialized
INFO - 2019-12-14 21:56:33 --> Language Class Initialized
INFO - 2019-12-14 21:56:33 --> Config Class Initialized
INFO - 2019-12-14 21:56:33 --> Loader Class Initialized
INFO - 2019-12-14 21:56:33 --> Helper loaded: url_helper
INFO - 2019-12-14 21:56:33 --> Helper loaded: common_helper
INFO - 2019-12-14 21:56:33 --> Helper loaded: language_helper
INFO - 2019-12-14 21:56:33 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:56:33 --> Helper loaded: email_helper
INFO - 2019-12-14 21:56:33 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:56:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:56:33 --> Parser Class Initialized
INFO - 2019-12-14 21:56:33 --> User Agent Class Initialized
INFO - 2019-12-14 21:56:33 --> Model Class Initialized
INFO - 2019-12-14 21:56:33 --> Database Driver Class Initialized
INFO - 2019-12-14 21:56:33 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:33 --> Template Class Initialized
INFO - 2019-12-14 21:56:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:56:33 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:56:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:56:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:56:33 --> Encryption Class Initialized
INFO - 2019-12-14 21:56:33 --> Controller Class Initialized
DEBUG - 2019-12-14 21:56:33 --> transactions MX_Controller Initialized
DEBUG - 2019-12-14 21:56:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-14 21:56:33 --> Model Class Initialized
ERROR - 2019-12-14 21:56:33 --> Could not find the language line "order_id"
INFO - 2019-12-14 21:56:33 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:56:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-14 21:56:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:56:33 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:56:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:56:33 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:56:33 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 21:56:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 21:56:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 21:56:34 --> Final output sent to browser
DEBUG - 2019-12-14 21:56:34 --> Total execution time: 0.7662
INFO - 2019-12-14 21:56:41 --> Config Class Initialized
INFO - 2019-12-14 21:56:41 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:56:41 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:56:41 --> Utf8 Class Initialized
INFO - 2019-12-14 21:56:41 --> URI Class Initialized
INFO - 2019-12-14 21:56:41 --> Router Class Initialized
INFO - 2019-12-14 21:56:41 --> Output Class Initialized
INFO - 2019-12-14 21:56:41 --> Security Class Initialized
DEBUG - 2019-12-14 21:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:56:41 --> CSRF cookie sent
INFO - 2019-12-14 21:56:41 --> Input Class Initialized
INFO - 2019-12-14 21:56:41 --> Language Class Initialized
INFO - 2019-12-14 21:56:41 --> Language Class Initialized
INFO - 2019-12-14 21:56:41 --> Config Class Initialized
INFO - 2019-12-14 21:56:41 --> Loader Class Initialized
INFO - 2019-12-14 21:56:41 --> Helper loaded: url_helper
INFO - 2019-12-14 21:56:41 --> Helper loaded: common_helper
INFO - 2019-12-14 21:56:41 --> Helper loaded: language_helper
INFO - 2019-12-14 21:56:41 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:56:41 --> Helper loaded: email_helper
INFO - 2019-12-14 21:56:41 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:56:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:56:41 --> Parser Class Initialized
INFO - 2019-12-14 21:56:41 --> User Agent Class Initialized
INFO - 2019-12-14 21:56:41 --> Model Class Initialized
INFO - 2019-12-14 21:56:41 --> Database Driver Class Initialized
INFO - 2019-12-14 21:56:41 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:41 --> Template Class Initialized
INFO - 2019-12-14 21:56:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:56:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:56:41 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:56:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:56:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:56:41 --> Encryption Class Initialized
INFO - 2019-12-14 21:56:41 --> Controller Class Initialized
DEBUG - 2019-12-14 21:56:41 --> order MX_Controller Initialized
DEBUG - 2019-12-14 21:56:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 21:56:41 --> Model Class Initialized
ERROR - 2019-12-14 21:56:41 --> Could not find the language line "order_id"
ERROR - 2019-12-14 21:56:41 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 21:56:41 --> Could not find the language line "order_id"
ERROR - 2019-12-14 21:56:41 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 21:56:41 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 21:56:42 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 21:56:42 --> Could not find the language line "Pending"
ERROR - 2019-12-14 21:56:42 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 21:56:42 --> Could not find the language line "Pending"
ERROR - 2019-12-14 21:56:42 --> Could not find the language line "Pending"
ERROR - 2019-12-14 21:56:42 --> Could not find the language line "Awaiting"
DEBUG - 2019-12-14 21:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 21:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:56:42 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:56:42 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:56:42 --> Model Class Initialized
DEBUG - 2019-12-14 21:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 21:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 21:56:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 21:56:42 --> Final output sent to browser
DEBUG - 2019-12-14 21:56:42 --> Total execution time: 0.8738
INFO - 2019-12-14 21:57:03 --> Config Class Initialized
INFO - 2019-12-14 21:57:03 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:57:03 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:57:03 --> Utf8 Class Initialized
INFO - 2019-12-14 21:57:03 --> URI Class Initialized
INFO - 2019-12-14 21:57:03 --> Router Class Initialized
INFO - 2019-12-14 21:57:03 --> Output Class Initialized
INFO - 2019-12-14 21:57:03 --> Security Class Initialized
DEBUG - 2019-12-14 21:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:57:03 --> Input Class Initialized
INFO - 2019-12-14 21:57:03 --> Language Class Initialized
INFO - 2019-12-14 21:57:03 --> Language Class Initialized
INFO - 2019-12-14 21:57:03 --> Config Class Initialized
INFO - 2019-12-14 21:57:03 --> Loader Class Initialized
INFO - 2019-12-14 21:57:03 --> Helper loaded: url_helper
INFO - 2019-12-14 21:57:03 --> Helper loaded: common_helper
INFO - 2019-12-14 21:57:03 --> Helper loaded: language_helper
INFO - 2019-12-14 21:57:03 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:57:03 --> Helper loaded: email_helper
INFO - 2019-12-14 21:57:03 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:57:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:57:04 --> Parser Class Initialized
INFO - 2019-12-14 21:57:04 --> User Agent Class Initialized
INFO - 2019-12-14 21:57:04 --> Model Class Initialized
INFO - 2019-12-14 21:57:04 --> Database Driver Class Initialized
INFO - 2019-12-14 21:57:04 --> Model Class Initialized
DEBUG - 2019-12-14 21:57:04 --> Template Class Initialized
INFO - 2019-12-14 21:57:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:57:04 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:57:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:57:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:57:04 --> Encryption Class Initialized
INFO - 2019-12-14 21:57:04 --> Controller Class Initialized
DEBUG - 2019-12-14 21:57:04 --> dotpay MX_Controller Initialized
INFO - 2019-12-14 21:57:04 --> Model Class Initialized
INFO - 2019-12-14 21:57:04 --> Config Class Initialized
INFO - 2019-12-14 21:57:04 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:57:04 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:57:04 --> Utf8 Class Initialized
INFO - 2019-12-14 21:57:04 --> URI Class Initialized
INFO - 2019-12-14 21:57:04 --> Router Class Initialized
INFO - 2019-12-14 21:57:04 --> Output Class Initialized
INFO - 2019-12-14 21:57:04 --> Security Class Initialized
DEBUG - 2019-12-14 21:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:57:04 --> CSRF cookie sent
INFO - 2019-12-14 21:57:04 --> Input Class Initialized
INFO - 2019-12-14 21:57:04 --> Language Class Initialized
INFO - 2019-12-14 21:57:04 --> Language Class Initialized
INFO - 2019-12-14 21:57:04 --> Config Class Initialized
INFO - 2019-12-14 21:57:04 --> Loader Class Initialized
INFO - 2019-12-14 21:57:04 --> Helper loaded: url_helper
INFO - 2019-12-14 21:57:04 --> Helper loaded: common_helper
INFO - 2019-12-14 21:57:04 --> Helper loaded: language_helper
INFO - 2019-12-14 21:57:04 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:57:04 --> Helper loaded: email_helper
INFO - 2019-12-14 21:57:04 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:57:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:57:04 --> Parser Class Initialized
INFO - 2019-12-14 21:57:04 --> User Agent Class Initialized
INFO - 2019-12-14 21:57:04 --> Model Class Initialized
INFO - 2019-12-14 21:57:04 --> Database Driver Class Initialized
INFO - 2019-12-14 21:57:04 --> Model Class Initialized
DEBUG - 2019-12-14 21:57:04 --> Template Class Initialized
INFO - 2019-12-14 21:57:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:57:04 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:57:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:57:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:57:04 --> Encryption Class Initialized
INFO - 2019-12-14 21:57:04 --> Controller Class Initialized
DEBUG - 2019-12-14 21:57:04 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 21:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 21:57:04 --> Model Class Initialized
INFO - 2019-12-14 21:57:04 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-12-14 21:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:57:04 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:57:04 --> Model Class Initialized
DEBUG - 2019-12-14 21:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:57:04 --> Model Class Initialized
DEBUG - 2019-12-14 21:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 21:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 21:57:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 21:57:04 --> Final output sent to browser
DEBUG - 2019-12-14 21:57:04 --> Total execution time: 0.5830
INFO - 2019-12-14 21:58:17 --> Config Class Initialized
INFO - 2019-12-14 21:58:17 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:58:17 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:58:17 --> Utf8 Class Initialized
INFO - 2019-12-14 21:58:17 --> URI Class Initialized
INFO - 2019-12-14 21:58:17 --> Router Class Initialized
INFO - 2019-12-14 21:58:17 --> Output Class Initialized
INFO - 2019-12-14 21:58:17 --> Security Class Initialized
DEBUG - 2019-12-14 21:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:58:17 --> CSRF cookie sent
INFO - 2019-12-14 21:58:17 --> Input Class Initialized
INFO - 2019-12-14 21:58:17 --> Language Class Initialized
INFO - 2019-12-14 21:58:17 --> Language Class Initialized
INFO - 2019-12-14 21:58:17 --> Config Class Initialized
INFO - 2019-12-14 21:58:17 --> Loader Class Initialized
INFO - 2019-12-14 21:58:17 --> Helper loaded: url_helper
INFO - 2019-12-14 21:58:17 --> Helper loaded: common_helper
INFO - 2019-12-14 21:58:17 --> Helper loaded: language_helper
INFO - 2019-12-14 21:58:17 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:58:17 --> Helper loaded: email_helper
INFO - 2019-12-14 21:58:17 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:58:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:58:17 --> Parser Class Initialized
INFO - 2019-12-14 21:58:17 --> User Agent Class Initialized
INFO - 2019-12-14 21:58:17 --> Model Class Initialized
INFO - 2019-12-14 21:58:17 --> Database Driver Class Initialized
INFO - 2019-12-14 21:58:17 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:17 --> Template Class Initialized
INFO - 2019-12-14 21:58:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:58:17 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:58:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:58:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:58:17 --> Encryption Class Initialized
INFO - 2019-12-14 21:58:17 --> Controller Class Initialized
DEBUG - 2019-12-14 21:58:17 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 21:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 21:58:17 --> Model Class Initialized
INFO - 2019-12-14 21:58:17 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_unsuccessfully.php
DEBUG - 2019-12-14 21:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:58:17 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:58:17 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:58:17 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 21:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 21:58:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 21:58:17 --> Final output sent to browser
DEBUG - 2019-12-14 21:58:17 --> Total execution time: 0.7262
INFO - 2019-12-14 21:58:39 --> Config Class Initialized
INFO - 2019-12-14 21:58:39 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:58:39 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:58:39 --> Utf8 Class Initialized
INFO - 2019-12-14 21:58:39 --> URI Class Initialized
INFO - 2019-12-14 21:58:39 --> Router Class Initialized
INFO - 2019-12-14 21:58:39 --> Output Class Initialized
INFO - 2019-12-14 21:58:39 --> Security Class Initialized
DEBUG - 2019-12-14 21:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:58:39 --> CSRF cookie sent
INFO - 2019-12-14 21:58:39 --> Input Class Initialized
INFO - 2019-12-14 21:58:39 --> Language Class Initialized
INFO - 2019-12-14 21:58:39 --> Language Class Initialized
INFO - 2019-12-14 21:58:39 --> Config Class Initialized
INFO - 2019-12-14 21:58:39 --> Loader Class Initialized
INFO - 2019-12-14 21:58:39 --> Helper loaded: url_helper
INFO - 2019-12-14 21:58:39 --> Helper loaded: common_helper
INFO - 2019-12-14 21:58:39 --> Helper loaded: language_helper
INFO - 2019-12-14 21:58:39 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:58:39 --> Helper loaded: email_helper
INFO - 2019-12-14 21:58:39 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:58:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:58:39 --> Parser Class Initialized
INFO - 2019-12-14 21:58:40 --> User Agent Class Initialized
INFO - 2019-12-14 21:58:40 --> Model Class Initialized
INFO - 2019-12-14 21:58:40 --> Database Driver Class Initialized
INFO - 2019-12-14 21:58:40 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:40 --> Template Class Initialized
INFO - 2019-12-14 21:58:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:58:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:58:40 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:58:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:58:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:58:40 --> Encryption Class Initialized
INFO - 2019-12-14 21:58:40 --> Controller Class Initialized
DEBUG - 2019-12-14 21:58:40 --> package MX_Controller Initialized
DEBUG - 2019-12-14 21:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-14 21:58:40 --> Model Class Initialized
INFO - 2019-12-14 21:58:40 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:58:40 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:58:40 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:58:40 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-14 21:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-14 21:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 21:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 21:58:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 21:58:40 --> Final output sent to browser
DEBUG - 2019-12-14 21:58:40 --> Total execution time: 0.7691
INFO - 2019-12-14 21:58:43 --> Config Class Initialized
INFO - 2019-12-14 21:58:43 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:58:43 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:58:43 --> Utf8 Class Initialized
INFO - 2019-12-14 21:58:43 --> URI Class Initialized
INFO - 2019-12-14 21:58:43 --> Router Class Initialized
INFO - 2019-12-14 21:58:43 --> Output Class Initialized
INFO - 2019-12-14 21:58:43 --> Security Class Initialized
DEBUG - 2019-12-14 21:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:58:43 --> CSRF cookie sent
INFO - 2019-12-14 21:58:43 --> CSRF token verified
INFO - 2019-12-14 21:58:43 --> Input Class Initialized
INFO - 2019-12-14 21:58:43 --> Language Class Initialized
INFO - 2019-12-14 21:58:43 --> Language Class Initialized
INFO - 2019-12-14 21:58:44 --> Config Class Initialized
INFO - 2019-12-14 21:58:44 --> Loader Class Initialized
INFO - 2019-12-14 21:58:44 --> Helper loaded: url_helper
INFO - 2019-12-14 21:58:44 --> Helper loaded: common_helper
INFO - 2019-12-14 21:58:44 --> Helper loaded: language_helper
INFO - 2019-12-14 21:58:44 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:58:44 --> Helper loaded: email_helper
INFO - 2019-12-14 21:58:44 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:58:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:58:44 --> Parser Class Initialized
INFO - 2019-12-14 21:58:44 --> User Agent Class Initialized
INFO - 2019-12-14 21:58:44 --> Model Class Initialized
INFO - 2019-12-14 21:58:44 --> Database Driver Class Initialized
INFO - 2019-12-14 21:58:44 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:44 --> Template Class Initialized
INFO - 2019-12-14 21:58:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:58:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:58:44 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:58:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:58:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:58:44 --> Encryption Class Initialized
INFO - 2019-12-14 21:58:44 --> Controller Class Initialized
DEBUG - 2019-12-14 21:58:44 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 21:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 21:58:44 --> Model Class Initialized
INFO - 2019-12-14 21:58:44 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 21:58:44 --> Could not find the language line "hesabe"
ERROR - 2019-12-14 21:58:44 --> Could not find the language line "payop"
ERROR - 2019-12-14 21:58:44 --> Could not find the language line "shopier"
DEBUG - 2019-12-14 21:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-14 21:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:58:44 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:58:44 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:58:44 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 21:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 21:58:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 21:58:44 --> Final output sent to browser
DEBUG - 2019-12-14 21:58:44 --> Total execution time: 0.7044
INFO - 2019-12-14 21:58:51 --> Config Class Initialized
INFO - 2019-12-14 21:58:51 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:58:51 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:58:51 --> Utf8 Class Initialized
INFO - 2019-12-14 21:58:51 --> URI Class Initialized
INFO - 2019-12-14 21:58:51 --> Router Class Initialized
INFO - 2019-12-14 21:58:51 --> Output Class Initialized
INFO - 2019-12-14 21:58:51 --> Security Class Initialized
DEBUG - 2019-12-14 21:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:58:51 --> CSRF cookie sent
INFO - 2019-12-14 21:58:51 --> CSRF token verified
INFO - 2019-12-14 21:58:51 --> Input Class Initialized
INFO - 2019-12-14 21:58:51 --> Language Class Initialized
INFO - 2019-12-14 21:58:51 --> Language Class Initialized
INFO - 2019-12-14 21:58:51 --> Config Class Initialized
INFO - 2019-12-14 21:58:51 --> Loader Class Initialized
INFO - 2019-12-14 21:58:51 --> Helper loaded: url_helper
INFO - 2019-12-14 21:58:51 --> Helper loaded: common_helper
INFO - 2019-12-14 21:58:51 --> Helper loaded: language_helper
INFO - 2019-12-14 21:58:51 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:58:51 --> Helper loaded: email_helper
INFO - 2019-12-14 21:58:51 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:58:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:58:51 --> Parser Class Initialized
INFO - 2019-12-14 21:58:51 --> User Agent Class Initialized
INFO - 2019-12-14 21:58:51 --> Model Class Initialized
INFO - 2019-12-14 21:58:51 --> Database Driver Class Initialized
INFO - 2019-12-14 21:58:51 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:51 --> Template Class Initialized
INFO - 2019-12-14 21:58:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:58:51 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:58:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:58:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:58:52 --> Encryption Class Initialized
INFO - 2019-12-14 21:58:52 --> Controller Class Initialized
DEBUG - 2019-12-14 21:58:52 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 21:58:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 21:58:52 --> Model Class Initialized
INFO - 2019-12-14 21:58:56 --> Config Class Initialized
INFO - 2019-12-14 21:58:56 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:58:56 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:58:56 --> Utf8 Class Initialized
INFO - 2019-12-14 21:58:56 --> URI Class Initialized
INFO - 2019-12-14 21:58:56 --> Router Class Initialized
INFO - 2019-12-14 21:58:56 --> Output Class Initialized
INFO - 2019-12-14 21:58:56 --> Security Class Initialized
DEBUG - 2019-12-14 21:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:58:56 --> CSRF cookie sent
INFO - 2019-12-14 21:58:56 --> CSRF token verified
INFO - 2019-12-14 21:58:56 --> Input Class Initialized
INFO - 2019-12-14 21:58:56 --> Language Class Initialized
INFO - 2019-12-14 21:58:56 --> Language Class Initialized
INFO - 2019-12-14 21:58:56 --> Config Class Initialized
INFO - 2019-12-14 21:58:56 --> Loader Class Initialized
INFO - 2019-12-14 21:58:56 --> Helper loaded: url_helper
INFO - 2019-12-14 21:58:56 --> Helper loaded: common_helper
INFO - 2019-12-14 21:58:56 --> Helper loaded: language_helper
INFO - 2019-12-14 21:58:56 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:58:56 --> Helper loaded: email_helper
INFO - 2019-12-14 21:58:56 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:58:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:58:56 --> Parser Class Initialized
INFO - 2019-12-14 21:58:56 --> User Agent Class Initialized
INFO - 2019-12-14 21:58:56 --> Model Class Initialized
INFO - 2019-12-14 21:58:56 --> Database Driver Class Initialized
INFO - 2019-12-14 21:58:56 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:56 --> Template Class Initialized
INFO - 2019-12-14 21:58:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:58:56 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:58:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:58:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:58:56 --> Encryption Class Initialized
INFO - 2019-12-14 21:58:56 --> Controller Class Initialized
DEBUG - 2019-12-14 21:58:56 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 21:58:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 21:58:56 --> Model Class Initialized
DEBUG - 2019-12-14 21:58:56 --> dotpay MX_Controller Initialized
DEBUG - 2019-12-14 21:58:56 --> orders MX_Controller Initialized
DEBUG - 2019-12-14 21:58:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-12-14 21:58:56 --> Final output sent to browser
DEBUG - 2019-12-14 21:58:56 --> Total execution time: 0.5485
INFO - 2019-12-14 21:59:01 --> Config Class Initialized
INFO - 2019-12-14 21:59:01 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:59:01 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:59:01 --> Utf8 Class Initialized
INFO - 2019-12-14 21:59:01 --> URI Class Initialized
INFO - 2019-12-14 21:59:01 --> Router Class Initialized
INFO - 2019-12-14 21:59:01 --> Output Class Initialized
INFO - 2019-12-14 21:59:01 --> Security Class Initialized
DEBUG - 2019-12-14 21:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:59:01 --> CSRF cookie sent
INFO - 2019-12-14 21:59:01 --> Input Class Initialized
INFO - 2019-12-14 21:59:01 --> Language Class Initialized
INFO - 2019-12-14 21:59:01 --> Language Class Initialized
INFO - 2019-12-14 21:59:01 --> Config Class Initialized
INFO - 2019-12-14 21:59:01 --> Loader Class Initialized
INFO - 2019-12-14 21:59:01 --> Helper loaded: url_helper
INFO - 2019-12-14 21:59:01 --> Helper loaded: common_helper
INFO - 2019-12-14 21:59:01 --> Helper loaded: language_helper
INFO - 2019-12-14 21:59:01 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:59:01 --> Helper loaded: email_helper
INFO - 2019-12-14 21:59:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:59:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:59:01 --> Parser Class Initialized
INFO - 2019-12-14 21:59:01 --> User Agent Class Initialized
INFO - 2019-12-14 21:59:01 --> Model Class Initialized
INFO - 2019-12-14 21:59:01 --> Database Driver Class Initialized
INFO - 2019-12-14 21:59:01 --> Model Class Initialized
DEBUG - 2019-12-14 21:59:01 --> Template Class Initialized
INFO - 2019-12-14 21:59:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:59:01 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:59:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:59:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:59:01 --> Encryption Class Initialized
INFO - 2019-12-14 21:59:01 --> Controller Class Initialized
DEBUG - 2019-12-14 21:59:01 --> order MX_Controller Initialized
DEBUG - 2019-12-14 21:59:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 21:59:01 --> Model Class Initialized
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "order_id"
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "order_id"
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 21:59:01 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "Pending"
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "Pending"
ERROR - 2019-12-14 21:59:01 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 21:59:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 21:59:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:59:01 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:59:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:59:02 --> Model Class Initialized
DEBUG - 2019-12-14 21:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:59:02 --> Model Class Initialized
DEBUG - 2019-12-14 21:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 21:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 21:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 21:59:02 --> Final output sent to browser
DEBUG - 2019-12-14 21:59:02 --> Total execution time: 0.8708
INFO - 2019-12-14 21:59:05 --> Config Class Initialized
INFO - 2019-12-14 21:59:05 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:59:05 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:59:05 --> Utf8 Class Initialized
INFO - 2019-12-14 21:59:05 --> URI Class Initialized
INFO - 2019-12-14 21:59:05 --> Router Class Initialized
INFO - 2019-12-14 21:59:05 --> Output Class Initialized
INFO - 2019-12-14 21:59:05 --> Security Class Initialized
DEBUG - 2019-12-14 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:59:05 --> CSRF cookie sent
INFO - 2019-12-14 21:59:05 --> Input Class Initialized
INFO - 2019-12-14 21:59:05 --> Language Class Initialized
INFO - 2019-12-14 21:59:05 --> Language Class Initialized
INFO - 2019-12-14 21:59:05 --> Config Class Initialized
INFO - 2019-12-14 21:59:05 --> Loader Class Initialized
INFO - 2019-12-14 21:59:05 --> Helper loaded: url_helper
INFO - 2019-12-14 21:59:05 --> Helper loaded: common_helper
INFO - 2019-12-14 21:59:05 --> Helper loaded: language_helper
INFO - 2019-12-14 21:59:05 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:59:05 --> Helper loaded: email_helper
INFO - 2019-12-14 21:59:05 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:59:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:59:05 --> Parser Class Initialized
INFO - 2019-12-14 21:59:05 --> User Agent Class Initialized
INFO - 2019-12-14 21:59:05 --> Model Class Initialized
INFO - 2019-12-14 21:59:05 --> Database Driver Class Initialized
INFO - 2019-12-14 21:59:05 --> Model Class Initialized
DEBUG - 2019-12-14 21:59:05 --> Template Class Initialized
INFO - 2019-12-14 21:59:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:59:05 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:59:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:59:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:59:05 --> Encryption Class Initialized
INFO - 2019-12-14 21:59:05 --> Controller Class Initialized
DEBUG - 2019-12-14 21:59:05 --> transactions MX_Controller Initialized
DEBUG - 2019-12-14 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-14 21:59:05 --> Model Class Initialized
ERROR - 2019-12-14 21:59:05 --> Could not find the language line "order_id"
INFO - 2019-12-14 21:59:05 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-14 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 21:59:05 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 21:59:05 --> Model Class Initialized
DEBUG - 2019-12-14 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 21:59:05 --> Model Class Initialized
DEBUG - 2019-12-14 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 21:59:05 --> Final output sent to browser
DEBUG - 2019-12-14 21:59:06 --> Total execution time: 0.7814
INFO - 2019-12-14 21:59:25 --> Config Class Initialized
INFO - 2019-12-14 21:59:25 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:59:25 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:59:25 --> Utf8 Class Initialized
INFO - 2019-12-14 21:59:25 --> URI Class Initialized
INFO - 2019-12-14 21:59:25 --> Router Class Initialized
INFO - 2019-12-14 21:59:25 --> Output Class Initialized
INFO - 2019-12-14 21:59:25 --> Security Class Initialized
DEBUG - 2019-12-14 21:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:59:25 --> Input Class Initialized
INFO - 2019-12-14 21:59:25 --> Language Class Initialized
INFO - 2019-12-14 21:59:25 --> Language Class Initialized
INFO - 2019-12-14 21:59:25 --> Config Class Initialized
INFO - 2019-12-14 21:59:25 --> Loader Class Initialized
INFO - 2019-12-14 21:59:25 --> Helper loaded: url_helper
INFO - 2019-12-14 21:59:25 --> Helper loaded: common_helper
INFO - 2019-12-14 21:59:25 --> Helper loaded: language_helper
INFO - 2019-12-14 21:59:25 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:59:25 --> Helper loaded: email_helper
INFO - 2019-12-14 21:59:25 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:59:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:59:25 --> Parser Class Initialized
INFO - 2019-12-14 21:59:25 --> User Agent Class Initialized
INFO - 2019-12-14 21:59:25 --> Model Class Initialized
INFO - 2019-12-14 21:59:25 --> Database Driver Class Initialized
INFO - 2019-12-14 21:59:25 --> Model Class Initialized
DEBUG - 2019-12-14 21:59:25 --> Template Class Initialized
INFO - 2019-12-14 21:59:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:59:25 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:59:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:59:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:59:25 --> Encryption Class Initialized
INFO - 2019-12-14 21:59:25 --> Controller Class Initialized
DEBUG - 2019-12-14 21:59:25 --> dotpay MX_Controller Initialized
INFO - 2019-12-14 21:59:25 --> Model Class Initialized
INFO - 2019-12-14 21:59:53 --> Config Class Initialized
INFO - 2019-12-14 21:59:53 --> Hooks Class Initialized
DEBUG - 2019-12-14 21:59:53 --> UTF-8 Support Enabled
INFO - 2019-12-14 21:59:53 --> Utf8 Class Initialized
INFO - 2019-12-14 21:59:53 --> URI Class Initialized
INFO - 2019-12-14 21:59:53 --> Router Class Initialized
INFO - 2019-12-14 21:59:53 --> Output Class Initialized
INFO - 2019-12-14 21:59:53 --> Security Class Initialized
DEBUG - 2019-12-14 21:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 21:59:53 --> Input Class Initialized
INFO - 2019-12-14 21:59:53 --> Language Class Initialized
INFO - 2019-12-14 21:59:53 --> Language Class Initialized
INFO - 2019-12-14 21:59:53 --> Config Class Initialized
INFO - 2019-12-14 21:59:53 --> Loader Class Initialized
INFO - 2019-12-14 21:59:53 --> Helper loaded: url_helper
INFO - 2019-12-14 21:59:53 --> Helper loaded: common_helper
INFO - 2019-12-14 21:59:53 --> Helper loaded: language_helper
INFO - 2019-12-14 21:59:53 --> Helper loaded: cookie_helper
INFO - 2019-12-14 21:59:53 --> Helper loaded: email_helper
INFO - 2019-12-14 21:59:53 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 21:59:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 21:59:53 --> Parser Class Initialized
INFO - 2019-12-14 21:59:53 --> User Agent Class Initialized
INFO - 2019-12-14 21:59:53 --> Model Class Initialized
INFO - 2019-12-14 21:59:53 --> Database Driver Class Initialized
INFO - 2019-12-14 21:59:53 --> Model Class Initialized
DEBUG - 2019-12-14 21:59:53 --> Template Class Initialized
INFO - 2019-12-14 21:59:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 21:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 21:59:53 --> Pagination Class Initialized
DEBUG - 2019-12-14 21:59:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 21:59:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 21:59:53 --> Encryption Class Initialized
INFO - 2019-12-14 21:59:53 --> Controller Class Initialized
DEBUG - 2019-12-14 21:59:53 --> dotpay MX_Controller Initialized
INFO - 2019-12-14 21:59:53 --> Model Class Initialized
INFO - 2019-12-14 22:00:18 --> Config Class Initialized
INFO - 2019-12-14 22:00:18 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:00:18 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:00:18 --> Utf8 Class Initialized
INFO - 2019-12-14 22:00:18 --> URI Class Initialized
INFO - 2019-12-14 22:00:18 --> Router Class Initialized
INFO - 2019-12-14 22:00:18 --> Output Class Initialized
INFO - 2019-12-14 22:00:18 --> Security Class Initialized
DEBUG - 2019-12-14 22:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:00:18 --> Input Class Initialized
INFO - 2019-12-14 22:00:18 --> Language Class Initialized
INFO - 2019-12-14 22:00:18 --> Language Class Initialized
INFO - 2019-12-14 22:00:18 --> Config Class Initialized
INFO - 2019-12-14 22:00:18 --> Loader Class Initialized
INFO - 2019-12-14 22:00:18 --> Helper loaded: url_helper
INFO - 2019-12-14 22:00:18 --> Helper loaded: common_helper
INFO - 2019-12-14 22:00:18 --> Helper loaded: language_helper
INFO - 2019-12-14 22:00:18 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:00:18 --> Helper loaded: email_helper
INFO - 2019-12-14 22:00:18 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:00:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:00:18 --> Parser Class Initialized
INFO - 2019-12-14 22:00:18 --> User Agent Class Initialized
INFO - 2019-12-14 22:00:18 --> Model Class Initialized
INFO - 2019-12-14 22:00:18 --> Database Driver Class Initialized
INFO - 2019-12-14 22:00:18 --> Model Class Initialized
DEBUG - 2019-12-14 22:00:18 --> Template Class Initialized
INFO - 2019-12-14 22:00:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:00:18 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:00:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:00:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:00:18 --> Encryption Class Initialized
INFO - 2019-12-14 22:00:18 --> Controller Class Initialized
DEBUG - 2019-12-14 22:00:18 --> dotpay MX_Controller Initialized
INFO - 2019-12-14 22:00:18 --> Model Class Initialized
INFO - 2019-12-14 22:01:36 --> Config Class Initialized
INFO - 2019-12-14 22:01:36 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:01:36 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:01:36 --> Utf8 Class Initialized
INFO - 2019-12-14 22:01:36 --> URI Class Initialized
INFO - 2019-12-14 22:01:36 --> Router Class Initialized
INFO - 2019-12-14 22:01:36 --> Output Class Initialized
INFO - 2019-12-14 22:01:36 --> Security Class Initialized
DEBUG - 2019-12-14 22:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:01:36 --> Input Class Initialized
INFO - 2019-12-14 22:01:36 --> Language Class Initialized
INFO - 2019-12-14 22:01:36 --> Language Class Initialized
INFO - 2019-12-14 22:01:36 --> Config Class Initialized
INFO - 2019-12-14 22:01:36 --> Loader Class Initialized
INFO - 2019-12-14 22:01:36 --> Helper loaded: url_helper
INFO - 2019-12-14 22:01:36 --> Helper loaded: common_helper
INFO - 2019-12-14 22:01:36 --> Helper loaded: language_helper
INFO - 2019-12-14 22:01:36 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:01:36 --> Helper loaded: email_helper
INFO - 2019-12-14 22:01:36 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:01:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:01:36 --> Parser Class Initialized
INFO - 2019-12-14 22:01:36 --> User Agent Class Initialized
INFO - 2019-12-14 22:01:36 --> Model Class Initialized
INFO - 2019-12-14 22:01:36 --> Database Driver Class Initialized
INFO - 2019-12-14 22:01:36 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:36 --> Template Class Initialized
INFO - 2019-12-14 22:01:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:01:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:01:36 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:01:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:01:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:01:36 --> Encryption Class Initialized
INFO - 2019-12-14 22:01:36 --> Controller Class Initialized
DEBUG - 2019-12-14 22:01:36 --> dotpay MX_Controller Initialized
INFO - 2019-12-14 22:01:36 --> Model Class Initialized
INFO - 2019-12-14 22:01:36 --> Config Class Initialized
INFO - 2019-12-14 22:01:36 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:01:36 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:01:37 --> Utf8 Class Initialized
INFO - 2019-12-14 22:01:37 --> URI Class Initialized
INFO - 2019-12-14 22:01:37 --> Router Class Initialized
INFO - 2019-12-14 22:01:37 --> Output Class Initialized
INFO - 2019-12-14 22:01:37 --> Security Class Initialized
DEBUG - 2019-12-14 22:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:01:37 --> CSRF cookie sent
INFO - 2019-12-14 22:01:37 --> Input Class Initialized
INFO - 2019-12-14 22:01:37 --> Language Class Initialized
INFO - 2019-12-14 22:01:37 --> Language Class Initialized
INFO - 2019-12-14 22:01:37 --> Config Class Initialized
INFO - 2019-12-14 22:01:37 --> Loader Class Initialized
INFO - 2019-12-14 22:01:37 --> Helper loaded: url_helper
INFO - 2019-12-14 22:01:37 --> Helper loaded: common_helper
INFO - 2019-12-14 22:01:37 --> Helper loaded: language_helper
INFO - 2019-12-14 22:01:37 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:01:37 --> Helper loaded: email_helper
INFO - 2019-12-14 22:01:37 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:01:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:01:37 --> Parser Class Initialized
INFO - 2019-12-14 22:01:37 --> User Agent Class Initialized
INFO - 2019-12-14 22:01:37 --> Model Class Initialized
INFO - 2019-12-14 22:01:37 --> Database Driver Class Initialized
INFO - 2019-12-14 22:01:37 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:37 --> Template Class Initialized
INFO - 2019-12-14 22:01:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:01:37 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:01:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:01:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:01:37 --> Encryption Class Initialized
INFO - 2019-12-14 22:01:37 --> Controller Class Initialized
DEBUG - 2019-12-14 22:01:37 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 22:01:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 22:01:37 --> Model Class Initialized
INFO - 2019-12-14 22:01:37 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:01:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-12-14 22:01:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:01:37 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:01:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:01:37 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:01:37 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 22:01:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 22:01:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 22:01:37 --> Final output sent to browser
DEBUG - 2019-12-14 22:01:37 --> Total execution time: 0.6491
INFO - 2019-12-14 22:01:41 --> Config Class Initialized
INFO - 2019-12-14 22:01:41 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:01:41 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:01:41 --> Utf8 Class Initialized
INFO - 2019-12-14 22:01:41 --> URI Class Initialized
INFO - 2019-12-14 22:01:41 --> Router Class Initialized
INFO - 2019-12-14 22:01:41 --> Output Class Initialized
INFO - 2019-12-14 22:01:41 --> Security Class Initialized
DEBUG - 2019-12-14 22:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:01:41 --> CSRF cookie sent
INFO - 2019-12-14 22:01:41 --> Input Class Initialized
INFO - 2019-12-14 22:01:41 --> Language Class Initialized
INFO - 2019-12-14 22:01:41 --> Language Class Initialized
INFO - 2019-12-14 22:01:41 --> Config Class Initialized
INFO - 2019-12-14 22:01:41 --> Loader Class Initialized
INFO - 2019-12-14 22:01:41 --> Helper loaded: url_helper
INFO - 2019-12-14 22:01:41 --> Helper loaded: common_helper
INFO - 2019-12-14 22:01:41 --> Helper loaded: language_helper
INFO - 2019-12-14 22:01:41 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:01:41 --> Helper loaded: email_helper
INFO - 2019-12-14 22:01:41 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:01:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:01:41 --> Parser Class Initialized
INFO - 2019-12-14 22:01:41 --> User Agent Class Initialized
INFO - 2019-12-14 22:01:41 --> Model Class Initialized
INFO - 2019-12-14 22:01:41 --> Database Driver Class Initialized
INFO - 2019-12-14 22:01:41 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:41 --> Template Class Initialized
INFO - 2019-12-14 22:01:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:01:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:01:41 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:01:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:01:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:01:41 --> Encryption Class Initialized
INFO - 2019-12-14 22:01:41 --> Controller Class Initialized
DEBUG - 2019-12-14 22:01:41 --> transactions MX_Controller Initialized
DEBUG - 2019-12-14 22:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-14 22:01:41 --> Model Class Initialized
ERROR - 2019-12-14 22:01:41 --> Could not find the language line "order_id"
INFO - 2019-12-14 22:01:41 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-14 22:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:01:41 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:01:41 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:01:41 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:01:41 --> Final output sent to browser
DEBUG - 2019-12-14 22:01:41 --> Total execution time: 0.7562
INFO - 2019-12-14 22:01:49 --> Config Class Initialized
INFO - 2019-12-14 22:01:49 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:01:49 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:01:49 --> Utf8 Class Initialized
INFO - 2019-12-14 22:01:49 --> URI Class Initialized
INFO - 2019-12-14 22:01:49 --> Router Class Initialized
INFO - 2019-12-14 22:01:49 --> Output Class Initialized
INFO - 2019-12-14 22:01:49 --> Security Class Initialized
DEBUG - 2019-12-14 22:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:01:49 --> CSRF cookie sent
INFO - 2019-12-14 22:01:49 --> Input Class Initialized
INFO - 2019-12-14 22:01:50 --> Language Class Initialized
INFO - 2019-12-14 22:01:50 --> Language Class Initialized
INFO - 2019-12-14 22:01:50 --> Config Class Initialized
INFO - 2019-12-14 22:01:50 --> Loader Class Initialized
INFO - 2019-12-14 22:01:50 --> Helper loaded: url_helper
INFO - 2019-12-14 22:01:50 --> Helper loaded: common_helper
INFO - 2019-12-14 22:01:50 --> Helper loaded: language_helper
INFO - 2019-12-14 22:01:50 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:01:50 --> Helper loaded: email_helper
INFO - 2019-12-14 22:01:50 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:01:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:01:50 --> Parser Class Initialized
INFO - 2019-12-14 22:01:50 --> User Agent Class Initialized
INFO - 2019-12-14 22:01:50 --> Model Class Initialized
INFO - 2019-12-14 22:01:50 --> Database Driver Class Initialized
INFO - 2019-12-14 22:01:50 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:50 --> Template Class Initialized
INFO - 2019-12-14 22:01:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:01:50 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:01:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:01:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:01:50 --> Encryption Class Initialized
INFO - 2019-12-14 22:01:50 --> Controller Class Initialized
DEBUG - 2019-12-14 22:01:50 --> order MX_Controller Initialized
DEBUG - 2019-12-14 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 22:01:50 --> Model Class Initialized
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 22:01:50 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:01:50 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:01:50 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:01:50 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:01:50 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:01:50 --> Final output sent to browser
DEBUG - 2019-12-14 22:01:50 --> Total execution time: 0.8774
INFO - 2019-12-14 22:01:53 --> Config Class Initialized
INFO - 2019-12-14 22:01:53 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:01:53 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:01:53 --> Utf8 Class Initialized
INFO - 2019-12-14 22:01:53 --> URI Class Initialized
INFO - 2019-12-14 22:01:53 --> Router Class Initialized
INFO - 2019-12-14 22:01:53 --> Output Class Initialized
INFO - 2019-12-14 22:01:53 --> Security Class Initialized
DEBUG - 2019-12-14 22:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:01:53 --> CSRF cookie sent
INFO - 2019-12-14 22:01:53 --> Input Class Initialized
INFO - 2019-12-14 22:01:53 --> Language Class Initialized
INFO - 2019-12-14 22:01:53 --> Language Class Initialized
INFO - 2019-12-14 22:01:53 --> Config Class Initialized
INFO - 2019-12-14 22:01:53 --> Loader Class Initialized
INFO - 2019-12-14 22:01:53 --> Helper loaded: url_helper
INFO - 2019-12-14 22:01:53 --> Helper loaded: common_helper
INFO - 2019-12-14 22:01:53 --> Helper loaded: language_helper
INFO - 2019-12-14 22:01:53 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:01:53 --> Helper loaded: email_helper
INFO - 2019-12-14 22:01:53 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:01:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:01:53 --> Parser Class Initialized
INFO - 2019-12-14 22:01:53 --> User Agent Class Initialized
INFO - 2019-12-14 22:01:53 --> Model Class Initialized
INFO - 2019-12-14 22:01:53 --> Database Driver Class Initialized
INFO - 2019-12-14 22:01:53 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:53 --> Template Class Initialized
INFO - 2019-12-14 22:01:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:01:53 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:01:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:01:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:01:53 --> Encryption Class Initialized
INFO - 2019-12-14 22:01:54 --> Controller Class Initialized
DEBUG - 2019-12-14 22:01:54 --> order MX_Controller Initialized
DEBUG - 2019-12-14 22:01:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 22:01:54 --> Model Class Initialized
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 22:01:54 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:01:54 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 22:01:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 22:01:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:01:54 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:01:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:01:54 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:01:54 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:01:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:01:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:01:54 --> Final output sent to browser
DEBUG - 2019-12-14 22:01:54 --> Total execution time: 0.9878
INFO - 2019-12-14 22:01:56 --> Config Class Initialized
INFO - 2019-12-14 22:01:56 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:01:56 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:01:56 --> Utf8 Class Initialized
INFO - 2019-12-14 22:01:56 --> URI Class Initialized
INFO - 2019-12-14 22:01:56 --> Router Class Initialized
INFO - 2019-12-14 22:01:56 --> Output Class Initialized
INFO - 2019-12-14 22:01:56 --> Security Class Initialized
DEBUG - 2019-12-14 22:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:01:56 --> CSRF cookie sent
INFO - 2019-12-14 22:01:56 --> Input Class Initialized
INFO - 2019-12-14 22:01:56 --> Language Class Initialized
INFO - 2019-12-14 22:01:56 --> Language Class Initialized
INFO - 2019-12-14 22:01:56 --> Config Class Initialized
INFO - 2019-12-14 22:01:56 --> Loader Class Initialized
INFO - 2019-12-14 22:01:56 --> Helper loaded: url_helper
INFO - 2019-12-14 22:01:56 --> Helper loaded: common_helper
INFO - 2019-12-14 22:01:56 --> Helper loaded: language_helper
INFO - 2019-12-14 22:01:56 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:01:56 --> Helper loaded: email_helper
INFO - 2019-12-14 22:01:56 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:01:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:01:56 --> Parser Class Initialized
INFO - 2019-12-14 22:01:56 --> User Agent Class Initialized
INFO - 2019-12-14 22:01:56 --> Model Class Initialized
INFO - 2019-12-14 22:01:56 --> Database Driver Class Initialized
INFO - 2019-12-14 22:01:56 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:56 --> Template Class Initialized
INFO - 2019-12-14 22:01:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:01:56 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:01:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:01:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:01:56 --> Encryption Class Initialized
INFO - 2019-12-14 22:01:56 --> Controller Class Initialized
DEBUG - 2019-12-14 22:01:56 --> transactions MX_Controller Initialized
DEBUG - 2019-12-14 22:01:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-14 22:01:56 --> Model Class Initialized
ERROR - 2019-12-14 22:01:56 --> Could not find the language line "order_id"
INFO - 2019-12-14 22:01:56 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:01:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-14 22:01:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:01:56 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:01:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:01:56 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:01:56 --> Model Class Initialized
DEBUG - 2019-12-14 22:01:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:01:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:01:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:01:56 --> Final output sent to browser
DEBUG - 2019-12-14 22:01:56 --> Total execution time: 0.6662
INFO - 2019-12-14 22:03:23 --> Config Class Initialized
INFO - 2019-12-14 22:03:23 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:03:23 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:03:23 --> Utf8 Class Initialized
INFO - 2019-12-14 22:03:23 --> URI Class Initialized
INFO - 2019-12-14 22:03:23 --> Router Class Initialized
INFO - 2019-12-14 22:03:23 --> Output Class Initialized
INFO - 2019-12-14 22:03:23 --> Security Class Initialized
DEBUG - 2019-12-14 22:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:03:23 --> CSRF cookie sent
INFO - 2019-12-14 22:03:23 --> Input Class Initialized
INFO - 2019-12-14 22:03:23 --> Language Class Initialized
INFO - 2019-12-14 22:03:23 --> Language Class Initialized
INFO - 2019-12-14 22:03:23 --> Config Class Initialized
INFO - 2019-12-14 22:03:23 --> Loader Class Initialized
INFO - 2019-12-14 22:03:23 --> Helper loaded: url_helper
INFO - 2019-12-14 22:03:23 --> Helper loaded: common_helper
INFO - 2019-12-14 22:03:23 --> Helper loaded: language_helper
INFO - 2019-12-14 22:03:23 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:03:23 --> Helper loaded: email_helper
INFO - 2019-12-14 22:03:23 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:03:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:03:23 --> Parser Class Initialized
INFO - 2019-12-14 22:03:23 --> User Agent Class Initialized
INFO - 2019-12-14 22:03:23 --> Model Class Initialized
INFO - 2019-12-14 22:03:23 --> Database Driver Class Initialized
INFO - 2019-12-14 22:03:23 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:23 --> Template Class Initialized
INFO - 2019-12-14 22:03:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:03:23 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:03:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:03:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:03:23 --> Encryption Class Initialized
INFO - 2019-12-14 22:03:23 --> Controller Class Initialized
DEBUG - 2019-12-14 22:03:23 --> order MX_Controller Initialized
DEBUG - 2019-12-14 22:03:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 22:03:23 --> Model Class Initialized
ERROR - 2019-12-14 22:03:23 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:03:23 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 22:03:23 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:03:24 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 22:03:24 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:03:24 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:03:24 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:03:24 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:03:24 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:03:24 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:03:24 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 22:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 22:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:03:24 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:03:24 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:03:24 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:03:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:03:24 --> Final output sent to browser
DEBUG - 2019-12-14 22:03:24 --> Total execution time: 0.9289
INFO - 2019-12-14 22:03:28 --> Config Class Initialized
INFO - 2019-12-14 22:03:28 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:03:28 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:03:28 --> Utf8 Class Initialized
INFO - 2019-12-14 22:03:28 --> URI Class Initialized
INFO - 2019-12-14 22:03:28 --> Router Class Initialized
INFO - 2019-12-14 22:03:28 --> Output Class Initialized
INFO - 2019-12-14 22:03:28 --> Security Class Initialized
DEBUG - 2019-12-14 22:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:03:28 --> CSRF cookie sent
INFO - 2019-12-14 22:03:28 --> Input Class Initialized
INFO - 2019-12-14 22:03:28 --> Language Class Initialized
INFO - 2019-12-14 22:03:28 --> Language Class Initialized
INFO - 2019-12-14 22:03:28 --> Config Class Initialized
INFO - 2019-12-14 22:03:28 --> Loader Class Initialized
INFO - 2019-12-14 22:03:28 --> Helper loaded: url_helper
INFO - 2019-12-14 22:03:28 --> Helper loaded: common_helper
INFO - 2019-12-14 22:03:28 --> Helper loaded: language_helper
INFO - 2019-12-14 22:03:28 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:03:28 --> Helper loaded: email_helper
INFO - 2019-12-14 22:03:28 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:03:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:03:28 --> Parser Class Initialized
INFO - 2019-12-14 22:03:28 --> User Agent Class Initialized
INFO - 2019-12-14 22:03:28 --> Model Class Initialized
INFO - 2019-12-14 22:03:28 --> Database Driver Class Initialized
INFO - 2019-12-14 22:03:28 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:28 --> Template Class Initialized
INFO - 2019-12-14 22:03:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:03:28 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:03:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:03:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:03:28 --> Encryption Class Initialized
INFO - 2019-12-14 22:03:28 --> Controller Class Initialized
DEBUG - 2019-12-14 22:03:28 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 22:03:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 22:03:28 --> Model Class Initialized
INFO - 2019-12-14 22:03:28 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:03:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-12-14 22:03:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:03:28 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:03:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:03:28 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:03:28 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 22:03:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 22:03:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 22:03:28 --> Final output sent to browser
DEBUG - 2019-12-14 22:03:28 --> Total execution time: 0.7479
INFO - 2019-12-14 22:03:30 --> Config Class Initialized
INFO - 2019-12-14 22:03:30 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:03:30 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:03:30 --> Utf8 Class Initialized
INFO - 2019-12-14 22:03:30 --> URI Class Initialized
INFO - 2019-12-14 22:03:30 --> Router Class Initialized
INFO - 2019-12-14 22:03:30 --> Output Class Initialized
INFO - 2019-12-14 22:03:30 --> Security Class Initialized
DEBUG - 2019-12-14 22:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:03:31 --> CSRF cookie sent
INFO - 2019-12-14 22:03:31 --> Input Class Initialized
INFO - 2019-12-14 22:03:31 --> Language Class Initialized
INFO - 2019-12-14 22:03:31 --> Language Class Initialized
INFO - 2019-12-14 22:03:31 --> Config Class Initialized
INFO - 2019-12-14 22:03:31 --> Loader Class Initialized
INFO - 2019-12-14 22:03:31 --> Helper loaded: url_helper
INFO - 2019-12-14 22:03:31 --> Helper loaded: common_helper
INFO - 2019-12-14 22:03:31 --> Helper loaded: language_helper
INFO - 2019-12-14 22:03:31 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:03:31 --> Helper loaded: email_helper
INFO - 2019-12-14 22:03:31 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:03:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:03:31 --> Parser Class Initialized
INFO - 2019-12-14 22:03:31 --> User Agent Class Initialized
INFO - 2019-12-14 22:03:31 --> Model Class Initialized
INFO - 2019-12-14 22:03:31 --> Database Driver Class Initialized
INFO - 2019-12-14 22:03:31 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:31 --> Template Class Initialized
INFO - 2019-12-14 22:03:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:03:31 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:03:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:03:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:03:31 --> Encryption Class Initialized
INFO - 2019-12-14 22:03:31 --> Controller Class Initialized
DEBUG - 2019-12-14 22:03:31 --> package MX_Controller Initialized
DEBUG - 2019-12-14 22:03:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-14 22:03:31 --> Model Class Initialized
INFO - 2019-12-14 22:03:31 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:03:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:03:31 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:03:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:03:31 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:03:31 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-14 22:03:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-14 22:03:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 22:03:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 22:03:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 22:03:31 --> Final output sent to browser
DEBUG - 2019-12-14 22:03:31 --> Total execution time: 0.8018
INFO - 2019-12-14 22:03:35 --> Config Class Initialized
INFO - 2019-12-14 22:03:36 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:03:36 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:03:36 --> Utf8 Class Initialized
INFO - 2019-12-14 22:03:36 --> URI Class Initialized
INFO - 2019-12-14 22:03:36 --> Router Class Initialized
INFO - 2019-12-14 22:03:36 --> Output Class Initialized
INFO - 2019-12-14 22:03:36 --> Security Class Initialized
DEBUG - 2019-12-14 22:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:03:36 --> CSRF cookie sent
INFO - 2019-12-14 22:03:36 --> CSRF token verified
INFO - 2019-12-14 22:03:36 --> Input Class Initialized
INFO - 2019-12-14 22:03:36 --> Language Class Initialized
INFO - 2019-12-14 22:03:36 --> Language Class Initialized
INFO - 2019-12-14 22:03:36 --> Config Class Initialized
INFO - 2019-12-14 22:03:36 --> Loader Class Initialized
INFO - 2019-12-14 22:03:36 --> Helper loaded: url_helper
INFO - 2019-12-14 22:03:36 --> Helper loaded: common_helper
INFO - 2019-12-14 22:03:36 --> Helper loaded: language_helper
INFO - 2019-12-14 22:03:36 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:03:36 --> Helper loaded: email_helper
INFO - 2019-12-14 22:03:36 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:03:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:03:36 --> Parser Class Initialized
INFO - 2019-12-14 22:03:36 --> User Agent Class Initialized
INFO - 2019-12-14 22:03:36 --> Model Class Initialized
INFO - 2019-12-14 22:03:36 --> Database Driver Class Initialized
INFO - 2019-12-14 22:03:36 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:36 --> Template Class Initialized
INFO - 2019-12-14 22:03:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:03:36 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:03:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:03:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:03:36 --> Encryption Class Initialized
INFO - 2019-12-14 22:03:36 --> Controller Class Initialized
DEBUG - 2019-12-14 22:03:36 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 22:03:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 22:03:36 --> Model Class Initialized
INFO - 2019-12-14 22:03:36 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:03:36 --> Could not find the language line "hesabe"
ERROR - 2019-12-14 22:03:36 --> Could not find the language line "payop"
ERROR - 2019-12-14 22:03:36 --> Could not find the language line "shopier"
DEBUG - 2019-12-14 22:03:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-14 22:03:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:03:36 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:03:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:03:36 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:03:36 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 22:03:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 22:03:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 22:03:36 --> Final output sent to browser
DEBUG - 2019-12-14 22:03:36 --> Total execution time: 0.7591
INFO - 2019-12-14 22:03:46 --> Config Class Initialized
INFO - 2019-12-14 22:03:46 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:03:46 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:03:46 --> Utf8 Class Initialized
INFO - 2019-12-14 22:03:46 --> URI Class Initialized
INFO - 2019-12-14 22:03:46 --> Router Class Initialized
INFO - 2019-12-14 22:03:46 --> Output Class Initialized
INFO - 2019-12-14 22:03:46 --> Security Class Initialized
DEBUG - 2019-12-14 22:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:03:46 --> CSRF cookie sent
INFO - 2019-12-14 22:03:46 --> CSRF token verified
INFO - 2019-12-14 22:03:46 --> Input Class Initialized
INFO - 2019-12-14 22:03:46 --> Language Class Initialized
INFO - 2019-12-14 22:03:46 --> Language Class Initialized
INFO - 2019-12-14 22:03:46 --> Config Class Initialized
INFO - 2019-12-14 22:03:46 --> Loader Class Initialized
INFO - 2019-12-14 22:03:46 --> Helper loaded: url_helper
INFO - 2019-12-14 22:03:47 --> Helper loaded: common_helper
INFO - 2019-12-14 22:03:47 --> Helper loaded: language_helper
INFO - 2019-12-14 22:03:47 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:03:47 --> Helper loaded: email_helper
INFO - 2019-12-14 22:03:47 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:03:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:03:47 --> Parser Class Initialized
INFO - 2019-12-14 22:03:47 --> User Agent Class Initialized
INFO - 2019-12-14 22:03:47 --> Model Class Initialized
INFO - 2019-12-14 22:03:47 --> Database Driver Class Initialized
INFO - 2019-12-14 22:03:47 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:47 --> Template Class Initialized
INFO - 2019-12-14 22:03:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:03:47 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:03:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:03:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:03:47 --> Encryption Class Initialized
INFO - 2019-12-14 22:03:47 --> Controller Class Initialized
DEBUG - 2019-12-14 22:03:47 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 22:03:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 22:03:47 --> Model Class Initialized
DEBUG - 2019-12-14 22:03:47 --> dotpay MX_Controller Initialized
DEBUG - 2019-12-14 22:03:47 --> orders MX_Controller Initialized
DEBUG - 2019-12-14 22:03:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-12-14 22:03:47 --> Final output sent to browser
DEBUG - 2019-12-14 22:03:47 --> Total execution time: 0.6627
INFO - 2019-12-14 22:04:04 --> Config Class Initialized
INFO - 2019-12-14 22:04:04 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:04:04 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:04:04 --> Utf8 Class Initialized
INFO - 2019-12-14 22:04:04 --> URI Class Initialized
INFO - 2019-12-14 22:04:04 --> Router Class Initialized
INFO - 2019-12-14 22:04:04 --> Output Class Initialized
INFO - 2019-12-14 22:04:04 --> Security Class Initialized
DEBUG - 2019-12-14 22:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:04:04 --> Input Class Initialized
INFO - 2019-12-14 22:04:04 --> Language Class Initialized
INFO - 2019-12-14 22:04:04 --> Language Class Initialized
INFO - 2019-12-14 22:04:04 --> Config Class Initialized
INFO - 2019-12-14 22:04:04 --> Loader Class Initialized
INFO - 2019-12-14 22:04:04 --> Helper loaded: url_helper
INFO - 2019-12-14 22:04:04 --> Helper loaded: common_helper
INFO - 2019-12-14 22:04:04 --> Helper loaded: language_helper
INFO - 2019-12-14 22:04:04 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:04:04 --> Helper loaded: email_helper
INFO - 2019-12-14 22:04:05 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:04:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:04:05 --> Parser Class Initialized
INFO - 2019-12-14 22:04:05 --> User Agent Class Initialized
INFO - 2019-12-14 22:04:05 --> Model Class Initialized
INFO - 2019-12-14 22:04:05 --> Database Driver Class Initialized
INFO - 2019-12-14 22:04:05 --> Model Class Initialized
DEBUG - 2019-12-14 22:04:05 --> Template Class Initialized
INFO - 2019-12-14 22:04:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:04:05 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:04:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:04:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:04:05 --> Encryption Class Initialized
INFO - 2019-12-14 22:04:05 --> Controller Class Initialized
DEBUG - 2019-12-14 22:04:05 --> dotpay MX_Controller Initialized
INFO - 2019-12-14 22:04:05 --> Model Class Initialized
INFO - 2019-12-14 22:04:20 --> Config Class Initialized
INFO - 2019-12-14 22:04:20 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:04:20 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:04:20 --> Utf8 Class Initialized
INFO - 2019-12-14 22:04:20 --> URI Class Initialized
INFO - 2019-12-14 22:04:20 --> Router Class Initialized
INFO - 2019-12-14 22:04:20 --> Output Class Initialized
INFO - 2019-12-14 22:04:20 --> Security Class Initialized
DEBUG - 2019-12-14 22:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:04:20 --> CSRF cookie sent
INFO - 2019-12-14 22:04:20 --> Input Class Initialized
INFO - 2019-12-14 22:04:20 --> Language Class Initialized
INFO - 2019-12-14 22:04:20 --> Language Class Initialized
INFO - 2019-12-14 22:04:20 --> Config Class Initialized
INFO - 2019-12-14 22:04:20 --> Loader Class Initialized
INFO - 2019-12-14 22:04:20 --> Helper loaded: url_helper
INFO - 2019-12-14 22:04:20 --> Helper loaded: common_helper
INFO - 2019-12-14 22:04:20 --> Helper loaded: language_helper
INFO - 2019-12-14 22:04:20 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:04:20 --> Helper loaded: email_helper
INFO - 2019-12-14 22:04:20 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:04:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:04:20 --> Parser Class Initialized
INFO - 2019-12-14 22:04:20 --> User Agent Class Initialized
INFO - 2019-12-14 22:04:20 --> Model Class Initialized
INFO - 2019-12-14 22:04:20 --> Database Driver Class Initialized
INFO - 2019-12-14 22:04:20 --> Model Class Initialized
DEBUG - 2019-12-14 22:04:20 --> Template Class Initialized
INFO - 2019-12-14 22:04:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:04:20 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:04:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:04:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:04:20 --> Encryption Class Initialized
INFO - 2019-12-14 22:04:20 --> Controller Class Initialized
DEBUG - 2019-12-14 22:04:20 --> order MX_Controller Initialized
DEBUG - 2019-12-14 22:04:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 22:04:20 --> Model Class Initialized
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 22:04:20 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:04:20 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 22:04:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 22:04:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:04:20 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:04:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:04:20 --> Model Class Initialized
DEBUG - 2019-12-14 22:04:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:04:20 --> Model Class Initialized
DEBUG - 2019-12-14 22:04:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:04:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:04:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:04:21 --> Final output sent to browser
DEBUG - 2019-12-14 22:04:21 --> Total execution time: 0.9085
INFO - 2019-12-14 22:04:35 --> Config Class Initialized
INFO - 2019-12-14 22:04:35 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:04:35 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:04:35 --> Utf8 Class Initialized
INFO - 2019-12-14 22:04:35 --> URI Class Initialized
DEBUG - 2019-12-14 22:04:35 --> No URI present. Default controller set.
INFO - 2019-12-14 22:04:35 --> Router Class Initialized
INFO - 2019-12-14 22:04:35 --> Output Class Initialized
INFO - 2019-12-14 22:04:35 --> Security Class Initialized
DEBUG - 2019-12-14 22:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:04:35 --> CSRF cookie sent
INFO - 2019-12-14 22:04:35 --> Input Class Initialized
INFO - 2019-12-14 22:04:35 --> Language Class Initialized
INFO - 2019-12-14 22:04:35 --> Language Class Initialized
INFO - 2019-12-14 22:04:35 --> Config Class Initialized
INFO - 2019-12-14 22:04:35 --> Loader Class Initialized
INFO - 2019-12-14 22:04:35 --> Helper loaded: url_helper
INFO - 2019-12-14 22:04:35 --> Helper loaded: common_helper
INFO - 2019-12-14 22:04:35 --> Helper loaded: language_helper
INFO - 2019-12-14 22:04:35 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:04:36 --> Helper loaded: email_helper
INFO - 2019-12-14 22:04:36 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:04:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:04:36 --> Parser Class Initialized
INFO - 2019-12-14 22:04:36 --> User Agent Class Initialized
INFO - 2019-12-14 22:04:36 --> Model Class Initialized
INFO - 2019-12-14 22:04:36 --> Database Driver Class Initialized
INFO - 2019-12-14 22:04:36 --> Model Class Initialized
DEBUG - 2019-12-14 22:04:36 --> Template Class Initialized
INFO - 2019-12-14 22:04:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:04:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:04:36 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:04:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:04:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:04:36 --> Encryption Class Initialized
DEBUG - 2019-12-14 22:04:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-14 22:04:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-14 22:04:36 --> Controller Class Initialized
DEBUG - 2019-12-14 22:04:36 --> pergo MX_Controller Initialized
DEBUG - 2019-12-14 22:04:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-14 22:04:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-14 22:04:36 --> Model Class Initialized
INFO - 2019-12-14 22:04:36 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:04:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-14 22:04:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-14 22:04:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-14 22:04:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-14 22:04:37 --> Final output sent to browser
DEBUG - 2019-12-14 22:04:37 --> Total execution time: 1.6606
INFO - 2019-12-14 22:04:40 --> Config Class Initialized
INFO - 2019-12-14 22:04:40 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:04:40 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:04:40 --> Utf8 Class Initialized
INFO - 2019-12-14 22:04:40 --> URI Class Initialized
INFO - 2019-12-14 22:04:40 --> Router Class Initialized
INFO - 2019-12-14 22:04:40 --> Output Class Initialized
INFO - 2019-12-14 22:04:40 --> Security Class Initialized
DEBUG - 2019-12-14 22:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:04:40 --> CSRF cookie sent
INFO - 2019-12-14 22:04:40 --> Input Class Initialized
INFO - 2019-12-14 22:04:40 --> Language Class Initialized
INFO - 2019-12-14 22:04:40 --> Language Class Initialized
INFO - 2019-12-14 22:04:40 --> Config Class Initialized
INFO - 2019-12-14 22:04:40 --> Loader Class Initialized
INFO - 2019-12-14 22:04:40 --> Helper loaded: url_helper
INFO - 2019-12-14 22:04:40 --> Helper loaded: common_helper
INFO - 2019-12-14 22:04:40 --> Helper loaded: language_helper
INFO - 2019-12-14 22:04:40 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:04:40 --> Helper loaded: email_helper
INFO - 2019-12-14 22:04:40 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:04:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:04:40 --> Parser Class Initialized
INFO - 2019-12-14 22:04:40 --> User Agent Class Initialized
INFO - 2019-12-14 22:04:40 --> Model Class Initialized
INFO - 2019-12-14 22:04:40 --> Database Driver Class Initialized
INFO - 2019-12-14 22:04:40 --> Model Class Initialized
DEBUG - 2019-12-14 22:04:40 --> Template Class Initialized
INFO - 2019-12-14 22:04:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:04:40 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:04:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:04:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:04:40 --> Encryption Class Initialized
INFO - 2019-12-14 22:04:40 --> Controller Class Initialized
DEBUG - 2019-12-14 22:04:40 --> package MX_Controller Initialized
DEBUG - 2019-12-14 22:04:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-14 22:04:40 --> Model Class Initialized
INFO - 2019-12-14 22:04:40 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:04:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:04:40 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:04:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:04:40 --> Model Class Initialized
DEBUG - 2019-12-14 22:04:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:04:40 --> Model Class Initialized
DEBUG - 2019-12-14 22:04:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-14 22:04:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-14 22:04:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 22:04:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 22:04:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 22:04:41 --> Final output sent to browser
DEBUG - 2019-12-14 22:04:41 --> Total execution time: 1.0032
INFO - 2019-12-14 22:06:08 --> Config Class Initialized
INFO - 2019-12-14 22:06:08 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:06:08 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:06:08 --> Utf8 Class Initialized
INFO - 2019-12-14 22:06:08 --> URI Class Initialized
INFO - 2019-12-14 22:06:08 --> Router Class Initialized
INFO - 2019-12-14 22:06:08 --> Output Class Initialized
INFO - 2019-12-14 22:06:08 --> Security Class Initialized
DEBUG - 2019-12-14 22:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:06:08 --> CSRF cookie sent
INFO - 2019-12-14 22:06:08 --> Input Class Initialized
INFO - 2019-12-14 22:06:08 --> Language Class Initialized
INFO - 2019-12-14 22:06:08 --> Language Class Initialized
INFO - 2019-12-14 22:06:08 --> Config Class Initialized
INFO - 2019-12-14 22:06:08 --> Loader Class Initialized
INFO - 2019-12-14 22:06:08 --> Helper loaded: url_helper
INFO - 2019-12-14 22:06:08 --> Helper loaded: common_helper
INFO - 2019-12-14 22:06:08 --> Helper loaded: language_helper
INFO - 2019-12-14 22:06:08 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:06:08 --> Helper loaded: email_helper
INFO - 2019-12-14 22:06:08 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:06:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:06:09 --> Parser Class Initialized
INFO - 2019-12-14 22:06:09 --> User Agent Class Initialized
INFO - 2019-12-14 22:06:09 --> Model Class Initialized
INFO - 2019-12-14 22:06:09 --> Database Driver Class Initialized
INFO - 2019-12-14 22:06:09 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:09 --> Template Class Initialized
INFO - 2019-12-14 22:06:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:06:09 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:06:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:06:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:06:09 --> Encryption Class Initialized
INFO - 2019-12-14 22:06:09 --> Controller Class Initialized
DEBUG - 2019-12-14 22:06:09 --> order MX_Controller Initialized
DEBUG - 2019-12-14 22:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 22:06:09 --> Model Class Initialized
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 22:06:09 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:06:09 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 22:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 22:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:06:09 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:06:09 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:06:09 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:06:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:06:09 --> Final output sent to browser
DEBUG - 2019-12-14 22:06:09 --> Total execution time: 0.9618
INFO - 2019-12-14 22:06:46 --> Config Class Initialized
INFO - 2019-12-14 22:06:46 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:06:46 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:06:46 --> Utf8 Class Initialized
INFO - 2019-12-14 22:06:46 --> URI Class Initialized
INFO - 2019-12-14 22:06:46 --> Router Class Initialized
INFO - 2019-12-14 22:06:46 --> Output Class Initialized
INFO - 2019-12-14 22:06:46 --> Security Class Initialized
DEBUG - 2019-12-14 22:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:06:47 --> CSRF cookie sent
INFO - 2019-12-14 22:06:47 --> Input Class Initialized
INFO - 2019-12-14 22:06:47 --> Language Class Initialized
INFO - 2019-12-14 22:06:47 --> Language Class Initialized
INFO - 2019-12-14 22:06:47 --> Config Class Initialized
INFO - 2019-12-14 22:06:47 --> Loader Class Initialized
INFO - 2019-12-14 22:06:47 --> Helper loaded: url_helper
INFO - 2019-12-14 22:06:47 --> Helper loaded: common_helper
INFO - 2019-12-14 22:06:47 --> Helper loaded: language_helper
INFO - 2019-12-14 22:06:47 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:06:47 --> Helper loaded: email_helper
INFO - 2019-12-14 22:06:47 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:06:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:06:47 --> Parser Class Initialized
INFO - 2019-12-14 22:06:47 --> User Agent Class Initialized
INFO - 2019-12-14 22:06:47 --> Model Class Initialized
INFO - 2019-12-14 22:06:47 --> Database Driver Class Initialized
INFO - 2019-12-14 22:06:47 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:47 --> Template Class Initialized
INFO - 2019-12-14 22:06:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:06:47 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:06:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:06:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:06:47 --> Encryption Class Initialized
INFO - 2019-12-14 22:06:47 --> Controller Class Initialized
DEBUG - 2019-12-14 22:06:47 --> order MX_Controller Initialized
DEBUG - 2019-12-14 22:06:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 22:06:47 --> Model Class Initialized
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 22:06:47 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:06:47 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 22:06:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 22:06:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:06:47 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:06:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:06:47 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:06:47 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:06:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:06:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:06:47 --> Final output sent to browser
DEBUG - 2019-12-14 22:06:47 --> Total execution time: 1.0155
INFO - 2019-12-14 22:06:54 --> Config Class Initialized
INFO - 2019-12-14 22:06:54 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:06:54 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:06:54 --> Utf8 Class Initialized
INFO - 2019-12-14 22:06:54 --> URI Class Initialized
INFO - 2019-12-14 22:06:54 --> Router Class Initialized
INFO - 2019-12-14 22:06:54 --> Output Class Initialized
INFO - 2019-12-14 22:06:54 --> Security Class Initialized
DEBUG - 2019-12-14 22:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:06:54 --> Input Class Initialized
INFO - 2019-12-14 22:06:54 --> Language Class Initialized
INFO - 2019-12-14 22:06:54 --> Language Class Initialized
INFO - 2019-12-14 22:06:54 --> Config Class Initialized
INFO - 2019-12-14 22:06:54 --> Loader Class Initialized
INFO - 2019-12-14 22:06:54 --> Helper loaded: url_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: common_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: language_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: email_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:06:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:06:55 --> Parser Class Initialized
INFO - 2019-12-14 22:06:55 --> User Agent Class Initialized
INFO - 2019-12-14 22:06:55 --> Model Class Initialized
INFO - 2019-12-14 22:06:55 --> Database Driver Class Initialized
INFO - 2019-12-14 22:06:55 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:55 --> Template Class Initialized
INFO - 2019-12-14 22:06:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:06:55 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:06:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:06:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:06:55 --> Encryption Class Initialized
INFO - 2019-12-14 22:06:55 --> Controller Class Initialized
DEBUG - 2019-12-14 22:06:55 --> dotpay MX_Controller Initialized
INFO - 2019-12-14 22:06:55 --> Model Class Initialized
INFO - 2019-12-14 22:06:55 --> Config Class Initialized
INFO - 2019-12-14 22:06:55 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:06:55 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:06:55 --> Utf8 Class Initialized
INFO - 2019-12-14 22:06:55 --> URI Class Initialized
INFO - 2019-12-14 22:06:55 --> Router Class Initialized
INFO - 2019-12-14 22:06:55 --> Output Class Initialized
INFO - 2019-12-14 22:06:55 --> Security Class Initialized
DEBUG - 2019-12-14 22:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:06:55 --> CSRF cookie sent
INFO - 2019-12-14 22:06:55 --> Input Class Initialized
INFO - 2019-12-14 22:06:55 --> Language Class Initialized
INFO - 2019-12-14 22:06:55 --> Language Class Initialized
INFO - 2019-12-14 22:06:55 --> Config Class Initialized
INFO - 2019-12-14 22:06:55 --> Loader Class Initialized
INFO - 2019-12-14 22:06:55 --> Helper loaded: url_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: common_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: language_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: email_helper
INFO - 2019-12-14 22:06:55 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:06:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:06:55 --> Parser Class Initialized
INFO - 2019-12-14 22:06:55 --> User Agent Class Initialized
INFO - 2019-12-14 22:06:55 --> Model Class Initialized
INFO - 2019-12-14 22:06:55 --> Database Driver Class Initialized
INFO - 2019-12-14 22:06:55 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:55 --> Template Class Initialized
INFO - 2019-12-14 22:06:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:06:55 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:06:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:06:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:06:55 --> Encryption Class Initialized
INFO - 2019-12-14 22:06:55 --> Controller Class Initialized
DEBUG - 2019-12-14 22:06:55 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 22:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 22:06:55 --> Model Class Initialized
INFO - 2019-12-14 22:06:55 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-12-14 22:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:06:55 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:06:55 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:06:55 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 22:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 22:06:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 22:06:56 --> Final output sent to browser
DEBUG - 2019-12-14 22:06:56 --> Total execution time: 0.7029
INFO - 2019-12-14 22:06:59 --> Config Class Initialized
INFO - 2019-12-14 22:06:59 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:06:59 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:06:59 --> Utf8 Class Initialized
INFO - 2019-12-14 22:06:59 --> URI Class Initialized
INFO - 2019-12-14 22:06:59 --> Router Class Initialized
INFO - 2019-12-14 22:06:59 --> Output Class Initialized
INFO - 2019-12-14 22:06:59 --> Security Class Initialized
DEBUG - 2019-12-14 22:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:06:59 --> CSRF cookie sent
INFO - 2019-12-14 22:06:59 --> Input Class Initialized
INFO - 2019-12-14 22:06:59 --> Language Class Initialized
INFO - 2019-12-14 22:06:59 --> Language Class Initialized
INFO - 2019-12-14 22:06:59 --> Config Class Initialized
INFO - 2019-12-14 22:06:59 --> Loader Class Initialized
INFO - 2019-12-14 22:06:59 --> Helper loaded: url_helper
INFO - 2019-12-14 22:06:59 --> Helper loaded: common_helper
INFO - 2019-12-14 22:06:59 --> Helper loaded: language_helper
INFO - 2019-12-14 22:06:59 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:06:59 --> Helper loaded: email_helper
INFO - 2019-12-14 22:06:59 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:06:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:06:59 --> Parser Class Initialized
INFO - 2019-12-14 22:06:59 --> User Agent Class Initialized
INFO - 2019-12-14 22:06:59 --> Model Class Initialized
INFO - 2019-12-14 22:06:59 --> Database Driver Class Initialized
INFO - 2019-12-14 22:06:59 --> Model Class Initialized
DEBUG - 2019-12-14 22:06:59 --> Template Class Initialized
INFO - 2019-12-14 22:06:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:06:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:06:59 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:06:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:06:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:06:59 --> Encryption Class Initialized
INFO - 2019-12-14 22:06:59 --> Controller Class Initialized
DEBUG - 2019-12-14 22:06:59 --> package MX_Controller Initialized
DEBUG - 2019-12-14 22:06:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-14 22:06:59 --> Model Class Initialized
INFO - 2019-12-14 22:06:59 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:06:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:07:00 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:07:00 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:07:00 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-14 22:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-14 22:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 22:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 22:07:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 22:07:00 --> Final output sent to browser
DEBUG - 2019-12-14 22:07:00 --> Total execution time: 0.8647
INFO - 2019-12-14 22:07:03 --> Config Class Initialized
INFO - 2019-12-14 22:07:03 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:07:03 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:07:03 --> Utf8 Class Initialized
INFO - 2019-12-14 22:07:03 --> URI Class Initialized
INFO - 2019-12-14 22:07:03 --> Router Class Initialized
INFO - 2019-12-14 22:07:03 --> Output Class Initialized
INFO - 2019-12-14 22:07:03 --> Security Class Initialized
DEBUG - 2019-12-14 22:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:07:03 --> CSRF cookie sent
INFO - 2019-12-14 22:07:03 --> CSRF token verified
INFO - 2019-12-14 22:07:03 --> Input Class Initialized
INFO - 2019-12-14 22:07:03 --> Language Class Initialized
INFO - 2019-12-14 22:07:03 --> Language Class Initialized
INFO - 2019-12-14 22:07:03 --> Config Class Initialized
INFO - 2019-12-14 22:07:03 --> Loader Class Initialized
INFO - 2019-12-14 22:07:03 --> Helper loaded: url_helper
INFO - 2019-12-14 22:07:03 --> Helper loaded: common_helper
INFO - 2019-12-14 22:07:03 --> Helper loaded: language_helper
INFO - 2019-12-14 22:07:03 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:07:03 --> Helper loaded: email_helper
INFO - 2019-12-14 22:07:03 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:07:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:07:03 --> Parser Class Initialized
INFO - 2019-12-14 22:07:03 --> User Agent Class Initialized
INFO - 2019-12-14 22:07:03 --> Model Class Initialized
INFO - 2019-12-14 22:07:03 --> Database Driver Class Initialized
INFO - 2019-12-14 22:07:03 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:03 --> Template Class Initialized
INFO - 2019-12-14 22:07:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:07:03 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:07:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:07:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:07:03 --> Encryption Class Initialized
INFO - 2019-12-14 22:07:03 --> Controller Class Initialized
DEBUG - 2019-12-14 22:07:03 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 22:07:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 22:07:03 --> Model Class Initialized
INFO - 2019-12-14 22:07:03 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:07:03 --> Could not find the language line "hesabe"
ERROR - 2019-12-14 22:07:03 --> Could not find the language line "payop"
ERROR - 2019-12-14 22:07:03 --> Could not find the language line "shopier"
DEBUG - 2019-12-14 22:07:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-14 22:07:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:07:04 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:07:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:07:04 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:07:04 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 22:07:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 22:07:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 22:07:04 --> Final output sent to browser
DEBUG - 2019-12-14 22:07:04 --> Total execution time: 0.8116
INFO - 2019-12-14 22:07:12 --> Config Class Initialized
INFO - 2019-12-14 22:07:12 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:07:12 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:07:12 --> Utf8 Class Initialized
INFO - 2019-12-14 22:07:12 --> URI Class Initialized
INFO - 2019-12-14 22:07:12 --> Router Class Initialized
INFO - 2019-12-14 22:07:12 --> Output Class Initialized
INFO - 2019-12-14 22:07:12 --> Security Class Initialized
DEBUG - 2019-12-14 22:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:07:12 --> CSRF cookie sent
INFO - 2019-12-14 22:07:12 --> CSRF token verified
INFO - 2019-12-14 22:07:12 --> Input Class Initialized
INFO - 2019-12-14 22:07:12 --> Language Class Initialized
INFO - 2019-12-14 22:07:12 --> Language Class Initialized
INFO - 2019-12-14 22:07:12 --> Config Class Initialized
INFO - 2019-12-14 22:07:12 --> Loader Class Initialized
INFO - 2019-12-14 22:07:12 --> Helper loaded: url_helper
INFO - 2019-12-14 22:07:12 --> Helper loaded: common_helper
INFO - 2019-12-14 22:07:12 --> Helper loaded: language_helper
INFO - 2019-12-14 22:07:12 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:07:12 --> Helper loaded: email_helper
INFO - 2019-12-14 22:07:12 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:07:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:07:12 --> Parser Class Initialized
INFO - 2019-12-14 22:07:12 --> User Agent Class Initialized
INFO - 2019-12-14 22:07:12 --> Model Class Initialized
INFO - 2019-12-14 22:07:12 --> Database Driver Class Initialized
INFO - 2019-12-14 22:07:12 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:13 --> Template Class Initialized
INFO - 2019-12-14 22:07:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:07:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:07:13 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:07:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:07:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:07:13 --> Encryption Class Initialized
INFO - 2019-12-14 22:07:13 --> Controller Class Initialized
DEBUG - 2019-12-14 22:07:13 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 22:07:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 22:07:13 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:13 --> dotpay MX_Controller Initialized
DEBUG - 2019-12-14 22:07:13 --> orders MX_Controller Initialized
DEBUG - 2019-12-14 22:07:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-12-14 22:07:13 --> Final output sent to browser
DEBUG - 2019-12-14 22:07:13 --> Total execution time: 0.6262
INFO - 2019-12-14 22:07:56 --> Config Class Initialized
INFO - 2019-12-14 22:07:56 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:07:56 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:07:56 --> Utf8 Class Initialized
INFO - 2019-12-14 22:07:56 --> URI Class Initialized
INFO - 2019-12-14 22:07:56 --> Router Class Initialized
INFO - 2019-12-14 22:07:56 --> Output Class Initialized
INFO - 2019-12-14 22:07:56 --> Security Class Initialized
DEBUG - 2019-12-14 22:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:07:56 --> CSRF cookie sent
INFO - 2019-12-14 22:07:56 --> Input Class Initialized
INFO - 2019-12-14 22:07:56 --> Language Class Initialized
INFO - 2019-12-14 22:07:56 --> Language Class Initialized
INFO - 2019-12-14 22:07:56 --> Config Class Initialized
INFO - 2019-12-14 22:07:56 --> Loader Class Initialized
INFO - 2019-12-14 22:07:56 --> Helper loaded: url_helper
INFO - 2019-12-14 22:07:56 --> Helper loaded: common_helper
INFO - 2019-12-14 22:07:56 --> Helper loaded: language_helper
INFO - 2019-12-14 22:07:56 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:07:56 --> Helper loaded: email_helper
INFO - 2019-12-14 22:07:56 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:07:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:07:56 --> Parser Class Initialized
INFO - 2019-12-14 22:07:56 --> User Agent Class Initialized
INFO - 2019-12-14 22:07:56 --> Model Class Initialized
INFO - 2019-12-14 22:07:56 --> Database Driver Class Initialized
INFO - 2019-12-14 22:07:56 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:56 --> Template Class Initialized
INFO - 2019-12-14 22:07:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:07:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:07:56 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:07:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:07:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:07:56 --> Encryption Class Initialized
INFO - 2019-12-14 22:07:56 --> Controller Class Initialized
DEBUG - 2019-12-14 22:07:56 --> order MX_Controller Initialized
DEBUG - 2019-12-14 22:07:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 22:07:56 --> Model Class Initialized
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 22:07:56 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:07:56 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 22:07:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 22:07:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:07:56 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:07:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:07:56 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:07:56 --> Model Class Initialized
DEBUG - 2019-12-14 22:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:07:57 --> Final output sent to browser
DEBUG - 2019-12-14 22:07:57 --> Total execution time: 1.0834
INFO - 2019-12-14 22:08:15 --> Config Class Initialized
INFO - 2019-12-14 22:08:15 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:08:15 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:08:15 --> Utf8 Class Initialized
INFO - 2019-12-14 22:08:15 --> URI Class Initialized
INFO - 2019-12-14 22:08:15 --> Router Class Initialized
INFO - 2019-12-14 22:08:15 --> Output Class Initialized
INFO - 2019-12-14 22:08:15 --> Security Class Initialized
DEBUG - 2019-12-14 22:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:08:15 --> Input Class Initialized
INFO - 2019-12-14 22:08:15 --> Language Class Initialized
INFO - 2019-12-14 22:08:15 --> Language Class Initialized
INFO - 2019-12-14 22:08:15 --> Config Class Initialized
INFO - 2019-12-14 22:08:15 --> Loader Class Initialized
INFO - 2019-12-14 22:08:15 --> Helper loaded: url_helper
INFO - 2019-12-14 22:08:15 --> Helper loaded: common_helper
INFO - 2019-12-14 22:08:15 --> Helper loaded: language_helper
INFO - 2019-12-14 22:08:15 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:08:15 --> Helper loaded: email_helper
INFO - 2019-12-14 22:08:15 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:08:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:08:15 --> Parser Class Initialized
INFO - 2019-12-14 22:08:15 --> User Agent Class Initialized
INFO - 2019-12-14 22:08:15 --> Model Class Initialized
INFO - 2019-12-14 22:08:15 --> Database Driver Class Initialized
INFO - 2019-12-14 22:08:15 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:15 --> Template Class Initialized
INFO - 2019-12-14 22:08:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:08:15 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:08:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:08:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:08:16 --> Encryption Class Initialized
INFO - 2019-12-14 22:08:16 --> Controller Class Initialized
DEBUG - 2019-12-14 22:08:16 --> dotpay MX_Controller Initialized
INFO - 2019-12-14 22:08:16 --> Model Class Initialized
INFO - 2019-12-14 22:08:16 --> Config Class Initialized
INFO - 2019-12-14 22:08:16 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:08:16 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:08:16 --> Utf8 Class Initialized
INFO - 2019-12-14 22:08:16 --> URI Class Initialized
INFO - 2019-12-14 22:08:16 --> Router Class Initialized
INFO - 2019-12-14 22:08:16 --> Output Class Initialized
INFO - 2019-12-14 22:08:16 --> Security Class Initialized
DEBUG - 2019-12-14 22:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:08:16 --> CSRF cookie sent
INFO - 2019-12-14 22:08:16 --> Input Class Initialized
INFO - 2019-12-14 22:08:16 --> Language Class Initialized
INFO - 2019-12-14 22:08:16 --> Language Class Initialized
INFO - 2019-12-14 22:08:16 --> Config Class Initialized
INFO - 2019-12-14 22:08:16 --> Loader Class Initialized
INFO - 2019-12-14 22:08:16 --> Helper loaded: url_helper
INFO - 2019-12-14 22:08:16 --> Helper loaded: common_helper
INFO - 2019-12-14 22:08:16 --> Helper loaded: language_helper
INFO - 2019-12-14 22:08:16 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:08:16 --> Helper loaded: email_helper
INFO - 2019-12-14 22:08:16 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:08:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:08:16 --> Parser Class Initialized
INFO - 2019-12-14 22:08:16 --> User Agent Class Initialized
INFO - 2019-12-14 22:08:16 --> Model Class Initialized
INFO - 2019-12-14 22:08:16 --> Database Driver Class Initialized
INFO - 2019-12-14 22:08:16 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:16 --> Template Class Initialized
INFO - 2019-12-14 22:08:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:08:16 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:08:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:08:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:08:16 --> Encryption Class Initialized
INFO - 2019-12-14 22:08:16 --> Controller Class Initialized
DEBUG - 2019-12-14 22:08:16 --> checkout MX_Controller Initialized
DEBUG - 2019-12-14 22:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-14 22:08:16 --> Model Class Initialized
INFO - 2019-12-14 22:08:16 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-12-14 22:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:08:16 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:08:16 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:08:16 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-14 22:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-14 22:08:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-14 22:08:16 --> Final output sent to browser
DEBUG - 2019-12-14 22:08:16 --> Total execution time: 0.7145
INFO - 2019-12-14 22:08:22 --> Config Class Initialized
INFO - 2019-12-14 22:08:22 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:08:22 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:08:22 --> Utf8 Class Initialized
INFO - 2019-12-14 22:08:22 --> URI Class Initialized
INFO - 2019-12-14 22:08:22 --> Router Class Initialized
INFO - 2019-12-14 22:08:22 --> Output Class Initialized
INFO - 2019-12-14 22:08:22 --> Security Class Initialized
DEBUG - 2019-12-14 22:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:08:22 --> CSRF cookie sent
INFO - 2019-12-14 22:08:22 --> Input Class Initialized
INFO - 2019-12-14 22:08:22 --> Language Class Initialized
INFO - 2019-12-14 22:08:22 --> Language Class Initialized
INFO - 2019-12-14 22:08:22 --> Config Class Initialized
INFO - 2019-12-14 22:08:22 --> Loader Class Initialized
INFO - 2019-12-14 22:08:22 --> Helper loaded: url_helper
INFO - 2019-12-14 22:08:22 --> Helper loaded: common_helper
INFO - 2019-12-14 22:08:22 --> Helper loaded: language_helper
INFO - 2019-12-14 22:08:22 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:08:22 --> Helper loaded: email_helper
INFO - 2019-12-14 22:08:22 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:08:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:08:22 --> Parser Class Initialized
INFO - 2019-12-14 22:08:22 --> User Agent Class Initialized
INFO - 2019-12-14 22:08:22 --> Model Class Initialized
INFO - 2019-12-14 22:08:22 --> Database Driver Class Initialized
INFO - 2019-12-14 22:08:22 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:22 --> Template Class Initialized
INFO - 2019-12-14 22:08:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:08:22 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:08:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:08:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:08:22 --> Encryption Class Initialized
INFO - 2019-12-14 22:08:22 --> Controller Class Initialized
DEBUG - 2019-12-14 22:08:22 --> order MX_Controller Initialized
DEBUG - 2019-12-14 22:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-12-14 22:08:23 --> Model Class Initialized
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "order_basic_details"
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "order_id"
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "order_basic_details"
INFO - 2019-12-14 22:08:23 --> Helper loaded: inflector_helper
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "Pending"
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "Awaiting"
ERROR - 2019-12-14 22:08:23 --> Could not find the language line "Pending"
DEBUG - 2019-12-14 22:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-12-14 22:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:08:23 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:08:23 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:08:23 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:08:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:08:23 --> Final output sent to browser
DEBUG - 2019-12-14 22:08:23 --> Total execution time: 1.1294
INFO - 2019-12-14 22:08:29 --> Config Class Initialized
INFO - 2019-12-14 22:08:29 --> Hooks Class Initialized
DEBUG - 2019-12-14 22:08:29 --> UTF-8 Support Enabled
INFO - 2019-12-14 22:08:29 --> Utf8 Class Initialized
INFO - 2019-12-14 22:08:29 --> URI Class Initialized
INFO - 2019-12-14 22:08:29 --> Router Class Initialized
INFO - 2019-12-14 22:08:29 --> Output Class Initialized
INFO - 2019-12-14 22:08:29 --> Security Class Initialized
DEBUG - 2019-12-14 22:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-14 22:08:29 --> CSRF cookie sent
INFO - 2019-12-14 22:08:29 --> Input Class Initialized
INFO - 2019-12-14 22:08:29 --> Language Class Initialized
INFO - 2019-12-14 22:08:29 --> Language Class Initialized
INFO - 2019-12-14 22:08:29 --> Config Class Initialized
INFO - 2019-12-14 22:08:29 --> Loader Class Initialized
INFO - 2019-12-14 22:08:29 --> Helper loaded: url_helper
INFO - 2019-12-14 22:08:29 --> Helper loaded: common_helper
INFO - 2019-12-14 22:08:29 --> Helper loaded: language_helper
INFO - 2019-12-14 22:08:29 --> Helper loaded: cookie_helper
INFO - 2019-12-14 22:08:29 --> Helper loaded: email_helper
INFO - 2019-12-14 22:08:29 --> Helper loaded: file_manager_helper
INFO - 2019-12-14 22:08:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-14 22:08:29 --> Parser Class Initialized
INFO - 2019-12-14 22:08:29 --> User Agent Class Initialized
INFO - 2019-12-14 22:08:29 --> Model Class Initialized
INFO - 2019-12-14 22:08:29 --> Database Driver Class Initialized
INFO - 2019-12-14 22:08:29 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:29 --> Template Class Initialized
INFO - 2019-12-14 22:08:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-14 22:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-14 22:08:30 --> Pagination Class Initialized
DEBUG - 2019-12-14 22:08:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-14 22:08:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-14 22:08:30 --> Encryption Class Initialized
INFO - 2019-12-14 22:08:30 --> Controller Class Initialized
DEBUG - 2019-12-14 22:08:30 --> transactions MX_Controller Initialized
DEBUG - 2019-12-14 22:08:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-14 22:08:30 --> Model Class Initialized
ERROR - 2019-12-14 22:08:30 --> Could not find the language line "order_id"
INFO - 2019-12-14 22:08:30 --> Helper loaded: inflector_helper
DEBUG - 2019-12-14 22:08:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-14 22:08:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-14 22:08:30 --> blocks MX_Controller Initialized
DEBUG - 2019-12-14 22:08:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-14 22:08:30 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-14 22:08:30 --> Model Class Initialized
DEBUG - 2019-12-14 22:08:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-14 22:08:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-14 22:08:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-14 22:08:30 --> Final output sent to browser
DEBUG - 2019-12-14 22:08:30 --> Total execution time: 0.7700
