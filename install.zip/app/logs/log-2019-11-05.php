<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-05 14:33:28 --> Config Class Initialized
INFO - 2019-11-05 14:33:28 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:33:28 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:33:28 --> Utf8 Class Initialized
INFO - 2019-11-05 14:33:28 --> URI Class Initialized
DEBUG - 2019-11-05 14:33:28 --> No URI present. Default controller set.
INFO - 2019-11-05 14:33:28 --> Router Class Initialized
INFO - 2019-11-05 14:33:28 --> Output Class Initialized
INFO - 2019-11-05 14:33:28 --> Security Class Initialized
DEBUG - 2019-11-05 14:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:33:28 --> CSRF cookie sent
INFO - 2019-11-05 14:33:28 --> Input Class Initialized
INFO - 2019-11-05 14:33:28 --> Language Class Initialized
INFO - 2019-11-05 14:33:29 --> Language Class Initialized
INFO - 2019-11-05 14:33:29 --> Config Class Initialized
INFO - 2019-11-05 14:33:29 --> Loader Class Initialized
INFO - 2019-11-05 14:33:29 --> Helper loaded: url_helper
INFO - 2019-11-05 14:33:29 --> Helper loaded: common_helper
INFO - 2019-11-05 14:33:29 --> Helper loaded: language_helper
INFO - 2019-11-05 14:33:29 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:33:29 --> Helper loaded: email_helper
INFO - 2019-11-05 14:33:29 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:33:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:33:29 --> Parser Class Initialized
INFO - 2019-11-05 14:33:29 --> User Agent Class Initialized
INFO - 2019-11-05 14:33:29 --> Model Class Initialized
INFO - 2019-11-05 14:33:29 --> Database Driver Class Initialized
INFO - 2019-11-05 14:33:29 --> Model Class Initialized
DEBUG - 2019-11-05 14:33:29 --> Template Class Initialized
INFO - 2019-11-05 14:33:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:33:30 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:33:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:33:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:33:30 --> Encryption Class Initialized
DEBUG - 2019-11-05 14:33:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 14:33:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 14:33:30 --> Controller Class Initialized
DEBUG - 2019-11-05 14:33:30 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 14:33:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 14:33:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 14:33:30 --> Model Class Initialized
INFO - 2019-11-05 14:33:30 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 14:33:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 14:33:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 14:33:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 14:33:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 14:33:30 --> Final output sent to browser
DEBUG - 2019-11-05 14:33:30 --> Total execution time: 2.2607
INFO - 2019-11-05 14:34:57 --> Config Class Initialized
INFO - 2019-11-05 14:34:57 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:34:57 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:34:57 --> Utf8 Class Initialized
INFO - 2019-11-05 14:34:57 --> URI Class Initialized
DEBUG - 2019-11-05 14:34:57 --> No URI present. Default controller set.
INFO - 2019-11-05 14:34:57 --> Router Class Initialized
INFO - 2019-11-05 14:34:57 --> Output Class Initialized
INFO - 2019-11-05 14:34:57 --> Security Class Initialized
DEBUG - 2019-11-05 14:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:34:57 --> CSRF cookie sent
INFO - 2019-11-05 14:34:57 --> Input Class Initialized
INFO - 2019-11-05 14:34:57 --> Language Class Initialized
INFO - 2019-11-05 14:34:57 --> Language Class Initialized
INFO - 2019-11-05 14:34:57 --> Config Class Initialized
INFO - 2019-11-05 14:34:57 --> Loader Class Initialized
INFO - 2019-11-05 14:34:57 --> Helper loaded: url_helper
INFO - 2019-11-05 14:34:57 --> Helper loaded: common_helper
INFO - 2019-11-05 14:34:57 --> Helper loaded: language_helper
INFO - 2019-11-05 14:34:57 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:34:57 --> Helper loaded: email_helper
INFO - 2019-11-05 14:34:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:34:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:34:58 --> Parser Class Initialized
INFO - 2019-11-05 14:34:58 --> User Agent Class Initialized
INFO - 2019-11-05 14:34:58 --> Model Class Initialized
INFO - 2019-11-05 14:34:58 --> Database Driver Class Initialized
INFO - 2019-11-05 14:34:58 --> Model Class Initialized
DEBUG - 2019-11-05 14:34:58 --> Template Class Initialized
INFO - 2019-11-05 14:34:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:34:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:34:58 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:34:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:34:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:34:58 --> Encryption Class Initialized
DEBUG - 2019-11-05 14:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 14:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 14:34:58 --> Controller Class Initialized
DEBUG - 2019-11-05 14:34:58 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 14:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 14:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 14:34:58 --> Model Class Initialized
INFO - 2019-11-05 14:34:58 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 14:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 14:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 14:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 14:34:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 14:34:58 --> Final output sent to browser
DEBUG - 2019-11-05 14:34:58 --> Total execution time: 1.3293
INFO - 2019-11-05 14:35:05 --> Config Class Initialized
INFO - 2019-11-05 14:35:05 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:35:05 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:35:05 --> Utf8 Class Initialized
INFO - 2019-11-05 14:35:05 --> URI Class Initialized
INFO - 2019-11-05 14:35:05 --> Router Class Initialized
INFO - 2019-11-05 14:35:05 --> Output Class Initialized
INFO - 2019-11-05 14:35:05 --> Security Class Initialized
DEBUG - 2019-11-05 14:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:35:05 --> CSRF cookie sent
INFO - 2019-11-05 14:35:05 --> Input Class Initialized
INFO - 2019-11-05 14:35:05 --> Language Class Initialized
INFO - 2019-11-05 14:35:05 --> Language Class Initialized
INFO - 2019-11-05 14:35:05 --> Config Class Initialized
INFO - 2019-11-05 14:35:05 --> Loader Class Initialized
INFO - 2019-11-05 14:35:05 --> Helper loaded: url_helper
INFO - 2019-11-05 14:35:05 --> Helper loaded: common_helper
INFO - 2019-11-05 14:35:05 --> Helper loaded: language_helper
INFO - 2019-11-05 14:35:05 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:35:05 --> Helper loaded: email_helper
INFO - 2019-11-05 14:35:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:35:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:35:05 --> Parser Class Initialized
INFO - 2019-11-05 14:35:05 --> User Agent Class Initialized
INFO - 2019-11-05 14:35:05 --> Model Class Initialized
INFO - 2019-11-05 14:35:05 --> Database Driver Class Initialized
INFO - 2019-11-05 14:35:05 --> Model Class Initialized
DEBUG - 2019-11-05 14:35:05 --> Template Class Initialized
INFO - 2019-11-05 14:35:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:35:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:35:05 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:35:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:35:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:35:05 --> Encryption Class Initialized
INFO - 2019-11-05 14:35:05 --> Controller Class Initialized
DEBUG - 2019-11-05 14:35:05 --> package MX_Controller Initialized
DEBUG - 2019-11-05 14:35:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-05 14:35:05 --> Model Class Initialized
INFO - 2019-11-05 14:35:06 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 14:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 14:35:06 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 14:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 14:35:06 --> Model Class Initialized
DEBUG - 2019-11-05 14:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 14:35:06 --> Model Class Initialized
DEBUG - 2019-11-05 14:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-05 14:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-05 14:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 14:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 14:35:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 14:35:06 --> Final output sent to browser
DEBUG - 2019-11-05 14:35:06 --> Total execution time: 1.1566
INFO - 2019-11-05 14:35:11 --> Config Class Initialized
INFO - 2019-11-05 14:35:11 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:35:11 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:35:11 --> Utf8 Class Initialized
INFO - 2019-11-05 14:35:11 --> URI Class Initialized
INFO - 2019-11-05 14:35:11 --> Router Class Initialized
INFO - 2019-11-05 14:35:11 --> Output Class Initialized
INFO - 2019-11-05 14:35:11 --> Security Class Initialized
DEBUG - 2019-11-05 14:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:35:11 --> CSRF cookie sent
INFO - 2019-11-05 14:35:11 --> CSRF token verified
INFO - 2019-11-05 14:35:11 --> Input Class Initialized
INFO - 2019-11-05 14:35:11 --> Language Class Initialized
INFO - 2019-11-05 14:35:11 --> Language Class Initialized
INFO - 2019-11-05 14:35:11 --> Config Class Initialized
INFO - 2019-11-05 14:35:11 --> Loader Class Initialized
INFO - 2019-11-05 14:35:11 --> Helper loaded: url_helper
INFO - 2019-11-05 14:35:11 --> Helper loaded: common_helper
INFO - 2019-11-05 14:35:11 --> Helper loaded: language_helper
INFO - 2019-11-05 14:35:11 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:35:11 --> Helper loaded: email_helper
INFO - 2019-11-05 14:35:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:35:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:35:11 --> Parser Class Initialized
INFO - 2019-11-05 14:35:11 --> User Agent Class Initialized
INFO - 2019-11-05 14:35:11 --> Model Class Initialized
INFO - 2019-11-05 14:35:11 --> Database Driver Class Initialized
INFO - 2019-11-05 14:35:11 --> Model Class Initialized
DEBUG - 2019-11-05 14:35:11 --> Template Class Initialized
INFO - 2019-11-05 14:35:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:35:11 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:35:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:35:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:35:11 --> Encryption Class Initialized
INFO - 2019-11-05 14:35:11 --> Controller Class Initialized
DEBUG - 2019-11-05 14:35:11 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 14:35:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 14:35:11 --> Model Class Initialized
INFO - 2019-11-05 14:35:11 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 14:35:11 --> Could not find the language line "dotpay"
DEBUG - 2019-11-05 14:35:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-05 14:35:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 14:35:11 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 14:35:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 14:35:11 --> Model Class Initialized
DEBUG - 2019-11-05 14:35:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 14:35:11 --> Model Class Initialized
DEBUG - 2019-11-05 14:35:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 14:35:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 14:35:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 14:35:11 --> Final output sent to browser
DEBUG - 2019-11-05 14:35:12 --> Total execution time: 0.7483
INFO - 2019-11-05 14:38:00 --> Config Class Initialized
INFO - 2019-11-05 14:38:00 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:38:00 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:38:00 --> Utf8 Class Initialized
INFO - 2019-11-05 14:38:00 --> URI Class Initialized
INFO - 2019-11-05 14:38:00 --> Router Class Initialized
INFO - 2019-11-05 14:38:00 --> Output Class Initialized
INFO - 2019-11-05 14:38:00 --> Security Class Initialized
DEBUG - 2019-11-05 14:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:38:00 --> CSRF cookie sent
INFO - 2019-11-05 14:38:00 --> CSRF token verified
INFO - 2019-11-05 14:38:00 --> Input Class Initialized
INFO - 2019-11-05 14:38:00 --> Language Class Initialized
INFO - 2019-11-05 14:38:00 --> Language Class Initialized
INFO - 2019-11-05 14:38:00 --> Config Class Initialized
INFO - 2019-11-05 14:38:00 --> Loader Class Initialized
INFO - 2019-11-05 14:38:00 --> Helper loaded: url_helper
INFO - 2019-11-05 14:38:00 --> Helper loaded: common_helper
INFO - 2019-11-05 14:38:00 --> Helper loaded: language_helper
INFO - 2019-11-05 14:38:00 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:38:00 --> Helper loaded: email_helper
INFO - 2019-11-05 14:38:00 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:38:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:38:00 --> Parser Class Initialized
INFO - 2019-11-05 14:38:00 --> User Agent Class Initialized
INFO - 2019-11-05 14:38:00 --> Model Class Initialized
INFO - 2019-11-05 14:38:00 --> Database Driver Class Initialized
INFO - 2019-11-05 14:38:00 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:00 --> Template Class Initialized
INFO - 2019-11-05 14:38:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:38:00 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:38:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:38:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:38:00 --> Encryption Class Initialized
INFO - 2019-11-05 14:38:00 --> Controller Class Initialized
DEBUG - 2019-11-05 14:38:00 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 14:38:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 14:38:01 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/index.php
INFO - 2019-11-05 14:38:01 --> Final output sent to browser
DEBUG - 2019-11-05 14:38:01 --> Total execution time: 0.4568
INFO - 2019-11-05 14:38:01 --> Config Class Initialized
INFO - 2019-11-05 14:38:01 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:38:01 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:38:01 --> Utf8 Class Initialized
INFO - 2019-11-05 14:38:01 --> URI Class Initialized
INFO - 2019-11-05 14:38:01 --> Router Class Initialized
INFO - 2019-11-05 14:38:01 --> Output Class Initialized
INFO - 2019-11-05 14:38:01 --> Security Class Initialized
DEBUG - 2019-11-05 14:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:38:01 --> Input Class Initialized
INFO - 2019-11-05 14:38:01 --> Language Class Initialized
INFO - 2019-11-05 14:38:01 --> Language Class Initialized
INFO - 2019-11-05 14:38:01 --> Config Class Initialized
INFO - 2019-11-05 14:38:01 --> Loader Class Initialized
INFO - 2019-11-05 14:38:01 --> Helper loaded: url_helper
INFO - 2019-11-05 14:38:01 --> Helper loaded: common_helper
INFO - 2019-11-05 14:38:01 --> Helper loaded: language_helper
INFO - 2019-11-05 14:38:01 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:38:01 --> Helper loaded: email_helper
INFO - 2019-11-05 14:38:01 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:38:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:38:01 --> Parser Class Initialized
INFO - 2019-11-05 14:38:01 --> User Agent Class Initialized
INFO - 2019-11-05 14:38:01 --> Model Class Initialized
INFO - 2019-11-05 14:38:01 --> Database Driver Class Initialized
INFO - 2019-11-05 14:38:01 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:01 --> Template Class Initialized
INFO - 2019-11-05 14:38:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:38:01 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:38:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:38:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:38:01 --> Encryption Class Initialized
INFO - 2019-11-05 14:38:01 --> Controller Class Initialized
DEBUG - 2019-11-05 14:38:01 --> dotpay MX_Controller Initialized
INFO - 2019-11-05 14:38:01 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/dotpay/dotpay_form.php
INFO - 2019-11-05 14:38:01 --> Final output sent to browser
DEBUG - 2019-11-05 14:38:01 --> Total execution time: 0.4202
INFO - 2019-11-05 14:38:36 --> Config Class Initialized
INFO - 2019-11-05 14:38:36 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:38:36 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:38:36 --> Utf8 Class Initialized
INFO - 2019-11-05 14:38:36 --> URI Class Initialized
INFO - 2019-11-05 14:38:36 --> Router Class Initialized
INFO - 2019-11-05 14:38:36 --> Output Class Initialized
INFO - 2019-11-05 14:38:36 --> Security Class Initialized
DEBUG - 2019-11-05 14:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:38:36 --> CSRF cookie sent
INFO - 2019-11-05 14:38:36 --> Input Class Initialized
INFO - 2019-11-05 14:38:36 --> Language Class Initialized
INFO - 2019-11-05 14:38:36 --> Language Class Initialized
INFO - 2019-11-05 14:38:36 --> Config Class Initialized
INFO - 2019-11-05 14:38:36 --> Loader Class Initialized
INFO - 2019-11-05 14:38:36 --> Helper loaded: url_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: common_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: language_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: email_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:38:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:38:36 --> Parser Class Initialized
INFO - 2019-11-05 14:38:36 --> User Agent Class Initialized
INFO - 2019-11-05 14:38:36 --> Model Class Initialized
INFO - 2019-11-05 14:38:36 --> Database Driver Class Initialized
INFO - 2019-11-05 14:38:36 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:36 --> Template Class Initialized
INFO - 2019-11-05 14:38:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:38:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:38:36 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:38:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:38:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:38:36 --> Encryption Class Initialized
INFO - 2019-11-05 14:38:36 --> Controller Class Initialized
DEBUG - 2019-11-05 14:38:36 --> auth MX_Controller Initialized
DEBUG - 2019-11-05 14:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-05 14:38:36 --> Model Class Initialized
INFO - 2019-11-05 14:38:36 --> Config Class Initialized
INFO - 2019-11-05 14:38:36 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:38:36 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:38:36 --> Utf8 Class Initialized
INFO - 2019-11-05 14:38:36 --> URI Class Initialized
INFO - 2019-11-05 14:38:36 --> Router Class Initialized
INFO - 2019-11-05 14:38:36 --> Output Class Initialized
INFO - 2019-11-05 14:38:36 --> Security Class Initialized
DEBUG - 2019-11-05 14:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:38:36 --> CSRF cookie sent
INFO - 2019-11-05 14:38:36 --> Input Class Initialized
INFO - 2019-11-05 14:38:36 --> Language Class Initialized
INFO - 2019-11-05 14:38:36 --> Language Class Initialized
INFO - 2019-11-05 14:38:36 --> Config Class Initialized
INFO - 2019-11-05 14:38:36 --> Loader Class Initialized
INFO - 2019-11-05 14:38:36 --> Helper loaded: url_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: common_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: language_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: email_helper
INFO - 2019-11-05 14:38:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:38:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:38:36 --> Parser Class Initialized
INFO - 2019-11-05 14:38:36 --> User Agent Class Initialized
INFO - 2019-11-05 14:38:36 --> Model Class Initialized
INFO - 2019-11-05 14:38:36 --> Database Driver Class Initialized
INFO - 2019-11-05 14:38:36 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:36 --> Template Class Initialized
INFO - 2019-11-05 14:38:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:38:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:38:36 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:38:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:38:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:38:36 --> Encryption Class Initialized
INFO - 2019-11-05 14:38:36 --> Controller Class Initialized
DEBUG - 2019-11-05 14:38:36 --> statistics MX_Controller Initialized
DEBUG - 2019-11-05 14:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-05 14:38:36 --> Model Class Initialized
ERROR - 2019-11-05 14:38:37 --> Could not find the language line "Pending"
ERROR - 2019-11-05 14:38:37 --> Could not find the language line "Pending"
INFO - 2019-11-05 14:38:37 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 14:38:37 --> Could not find the language line "total_orders"
ERROR - 2019-11-05 14:38:37 --> Could not find the language line "total_orders"
ERROR - 2019-11-05 14:38:37 --> Could not find the language line "Pending"
DEBUG - 2019-11-05 14:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-05 14:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 14:38:37 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 14:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 14:38:37 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 14:38:37 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 14:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 14:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 14:38:37 --> Final output sent to browser
DEBUG - 2019-11-05 14:38:37 --> Total execution time: 0.9877
INFO - 2019-11-05 14:38:40 --> Config Class Initialized
INFO - 2019-11-05 14:38:40 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:38:40 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:38:40 --> Utf8 Class Initialized
INFO - 2019-11-05 14:38:40 --> URI Class Initialized
INFO - 2019-11-05 14:38:40 --> Router Class Initialized
INFO - 2019-11-05 14:38:40 --> Output Class Initialized
INFO - 2019-11-05 14:38:40 --> Security Class Initialized
DEBUG - 2019-11-05 14:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:38:40 --> CSRF cookie sent
INFO - 2019-11-05 14:38:40 --> Input Class Initialized
INFO - 2019-11-05 14:38:40 --> Language Class Initialized
INFO - 2019-11-05 14:38:40 --> Language Class Initialized
INFO - 2019-11-05 14:38:40 --> Config Class Initialized
INFO - 2019-11-05 14:38:40 --> Loader Class Initialized
INFO - 2019-11-05 14:38:40 --> Helper loaded: url_helper
INFO - 2019-11-05 14:38:40 --> Helper loaded: common_helper
INFO - 2019-11-05 14:38:40 --> Helper loaded: language_helper
INFO - 2019-11-05 14:38:40 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:38:40 --> Helper loaded: email_helper
INFO - 2019-11-05 14:38:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:38:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:38:40 --> Parser Class Initialized
INFO - 2019-11-05 14:38:40 --> User Agent Class Initialized
INFO - 2019-11-05 14:38:40 --> Model Class Initialized
INFO - 2019-11-05 14:38:40 --> Database Driver Class Initialized
INFO - 2019-11-05 14:38:40 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:40 --> Template Class Initialized
INFO - 2019-11-05 14:38:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:38:40 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:38:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:38:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:38:40 --> Encryption Class Initialized
INFO - 2019-11-05 14:38:40 --> Controller Class Initialized
DEBUG - 2019-11-05 14:38:40 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 14:38:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 14:38:40 --> Model Class Initialized
INFO - 2019-11-05 14:38:40 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 14:38:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 14:38:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-05 14:38:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 14:38:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 14:38:40 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 14:38:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 14:38:40 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 14:38:40 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 14:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 14:38:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 14:38:41 --> Final output sent to browser
DEBUG - 2019-11-05 14:38:41 --> Total execution time: 0.9163
INFO - 2019-11-05 14:38:44 --> Config Class Initialized
INFO - 2019-11-05 14:38:44 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:38:44 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:38:44 --> Utf8 Class Initialized
INFO - 2019-11-05 14:38:44 --> URI Class Initialized
INFO - 2019-11-05 14:38:44 --> Router Class Initialized
INFO - 2019-11-05 14:38:44 --> Output Class Initialized
INFO - 2019-11-05 14:38:44 --> Security Class Initialized
DEBUG - 2019-11-05 14:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:38:44 --> CSRF cookie sent
INFO - 2019-11-05 14:38:44 --> Input Class Initialized
INFO - 2019-11-05 14:38:44 --> Language Class Initialized
INFO - 2019-11-05 14:38:44 --> Language Class Initialized
INFO - 2019-11-05 14:38:44 --> Config Class Initialized
INFO - 2019-11-05 14:38:44 --> Loader Class Initialized
INFO - 2019-11-05 14:38:44 --> Helper loaded: url_helper
INFO - 2019-11-05 14:38:44 --> Helper loaded: common_helper
INFO - 2019-11-05 14:38:44 --> Helper loaded: language_helper
INFO - 2019-11-05 14:38:44 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:38:45 --> Helper loaded: email_helper
INFO - 2019-11-05 14:38:45 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:38:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:38:45 --> Parser Class Initialized
INFO - 2019-11-05 14:38:45 --> User Agent Class Initialized
INFO - 2019-11-05 14:38:45 --> Model Class Initialized
INFO - 2019-11-05 14:38:45 --> Database Driver Class Initialized
INFO - 2019-11-05 14:38:45 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:45 --> Template Class Initialized
INFO - 2019-11-05 14:38:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:38:45 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:38:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:38:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:38:45 --> Encryption Class Initialized
INFO - 2019-11-05 14:38:45 --> Controller Class Initialized
DEBUG - 2019-11-05 14:38:45 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 14:38:45 --> Model Class Initialized
INFO - 2019-11-05 14:38:45 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 14:38:45 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 14:38:45 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 14:38:45 --> Model Class Initialized
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 14:38:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 14:38:45 --> Final output sent to browser
DEBUG - 2019-11-05 14:38:45 --> Total execution time: 0.8128
INFO - 2019-11-05 14:47:35 --> Config Class Initialized
INFO - 2019-11-05 14:47:35 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:47:35 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:47:35 --> Utf8 Class Initialized
INFO - 2019-11-05 14:47:35 --> URI Class Initialized
INFO - 2019-11-05 14:47:35 --> Router Class Initialized
INFO - 2019-11-05 14:47:35 --> Output Class Initialized
INFO - 2019-11-05 14:47:35 --> Security Class Initialized
DEBUG - 2019-11-05 14:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:47:35 --> CSRF cookie sent
INFO - 2019-11-05 14:47:35 --> Input Class Initialized
INFO - 2019-11-05 14:47:35 --> Language Class Initialized
INFO - 2019-11-05 14:47:35 --> Language Class Initialized
INFO - 2019-11-05 14:47:35 --> Config Class Initialized
INFO - 2019-11-05 14:47:35 --> Loader Class Initialized
INFO - 2019-11-05 14:47:35 --> Helper loaded: url_helper
INFO - 2019-11-05 14:47:35 --> Helper loaded: common_helper
INFO - 2019-11-05 14:47:35 --> Helper loaded: language_helper
INFO - 2019-11-05 14:47:35 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:47:35 --> Helper loaded: email_helper
INFO - 2019-11-05 14:47:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:47:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:47:35 --> Parser Class Initialized
INFO - 2019-11-05 14:47:35 --> User Agent Class Initialized
INFO - 2019-11-05 14:47:35 --> Model Class Initialized
INFO - 2019-11-05 14:47:35 --> Database Driver Class Initialized
INFO - 2019-11-05 14:47:35 --> Model Class Initialized
DEBUG - 2019-11-05 14:47:35 --> Template Class Initialized
INFO - 2019-11-05 14:47:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:47:35 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:47:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:47:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:47:35 --> Encryption Class Initialized
INFO - 2019-11-05 14:47:35 --> Controller Class Initialized
DEBUG - 2019-11-05 14:47:35 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 14:47:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 14:47:35 --> Model Class Initialized
INFO - 2019-11-05 14:47:35 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 14:47:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 14:47:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-05 14:47:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 14:47:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 14:47:36 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 14:47:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 14:47:36 --> Model Class Initialized
DEBUG - 2019-11-05 14:47:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 14:47:36 --> Model Class Initialized
DEBUG - 2019-11-05 14:47:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 14:47:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 14:47:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 14:47:36 --> Final output sent to browser
DEBUG - 2019-11-05 14:47:36 --> Total execution time: 0.8971
INFO - 2019-11-05 14:48:16 --> Config Class Initialized
INFO - 2019-11-05 14:48:16 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:48:16 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:48:16 --> Utf8 Class Initialized
INFO - 2019-11-05 14:48:16 --> URI Class Initialized
INFO - 2019-11-05 14:48:16 --> Router Class Initialized
INFO - 2019-11-05 14:48:16 --> Output Class Initialized
INFO - 2019-11-05 14:48:16 --> Security Class Initialized
DEBUG - 2019-11-05 14:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:48:16 --> CSRF cookie sent
INFO - 2019-11-05 14:48:16 --> Input Class Initialized
INFO - 2019-11-05 14:48:16 --> Language Class Initialized
INFO - 2019-11-05 14:48:16 --> Language Class Initialized
INFO - 2019-11-05 14:48:16 --> Config Class Initialized
INFO - 2019-11-05 14:48:16 --> Loader Class Initialized
INFO - 2019-11-05 14:48:16 --> Helper loaded: url_helper
INFO - 2019-11-05 14:48:16 --> Helper loaded: common_helper
INFO - 2019-11-05 14:48:16 --> Helper loaded: language_helper
INFO - 2019-11-05 14:48:16 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:48:16 --> Helper loaded: email_helper
INFO - 2019-11-05 14:48:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:48:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:48:16 --> Parser Class Initialized
INFO - 2019-11-05 14:48:17 --> User Agent Class Initialized
INFO - 2019-11-05 14:48:17 --> Model Class Initialized
INFO - 2019-11-05 14:48:17 --> Database Driver Class Initialized
INFO - 2019-11-05 14:48:17 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:17 --> Template Class Initialized
INFO - 2019-11-05 14:48:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:48:17 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:48:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:48:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:48:17 --> Encryption Class Initialized
INFO - 2019-11-05 14:48:17 --> Controller Class Initialized
DEBUG - 2019-11-05 14:48:17 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 14:48:17 --> Model Class Initialized
INFO - 2019-11-05 14:48:17 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 14:48:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 14:48:17 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 14:48:17 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 14:48:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 14:48:17 --> Final output sent to browser
DEBUG - 2019-11-05 14:48:17 --> Total execution time: 0.6149
INFO - 2019-11-05 14:48:34 --> Config Class Initialized
INFO - 2019-11-05 14:48:34 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:48:34 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:48:34 --> Utf8 Class Initialized
INFO - 2019-11-05 14:48:34 --> URI Class Initialized
INFO - 2019-11-05 14:48:34 --> Router Class Initialized
INFO - 2019-11-05 14:48:34 --> Output Class Initialized
INFO - 2019-11-05 14:48:34 --> Security Class Initialized
DEBUG - 2019-11-05 14:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:48:34 --> CSRF cookie sent
INFO - 2019-11-05 14:48:34 --> Input Class Initialized
INFO - 2019-11-05 14:48:34 --> Language Class Initialized
INFO - 2019-11-05 14:48:34 --> Language Class Initialized
INFO - 2019-11-05 14:48:34 --> Config Class Initialized
INFO - 2019-11-05 14:48:34 --> Loader Class Initialized
INFO - 2019-11-05 14:48:34 --> Helper loaded: url_helper
INFO - 2019-11-05 14:48:34 --> Helper loaded: common_helper
INFO - 2019-11-05 14:48:34 --> Helper loaded: language_helper
INFO - 2019-11-05 14:48:34 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:48:34 --> Helper loaded: email_helper
INFO - 2019-11-05 14:48:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:48:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:48:34 --> Parser Class Initialized
INFO - 2019-11-05 14:48:34 --> User Agent Class Initialized
INFO - 2019-11-05 14:48:34 --> Model Class Initialized
INFO - 2019-11-05 14:48:34 --> Database Driver Class Initialized
INFO - 2019-11-05 14:48:34 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:35 --> Template Class Initialized
INFO - 2019-11-05 14:48:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:48:35 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:48:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:48:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:48:35 --> Encryption Class Initialized
INFO - 2019-11-05 14:48:35 --> Controller Class Initialized
DEBUG - 2019-11-05 14:48:35 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 14:48:35 --> Model Class Initialized
INFO - 2019-11-05 14:48:35 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 14:48:35 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 14:48:35 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 14:48:35 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 14:48:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 14:48:35 --> Final output sent to browser
DEBUG - 2019-11-05 14:48:35 --> Total execution time: 0.7345
INFO - 2019-11-05 14:48:47 --> Config Class Initialized
INFO - 2019-11-05 14:48:47 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:48:47 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:48:47 --> Utf8 Class Initialized
INFO - 2019-11-05 14:48:47 --> URI Class Initialized
INFO - 2019-11-05 14:48:47 --> Router Class Initialized
INFO - 2019-11-05 14:48:47 --> Output Class Initialized
INFO - 2019-11-05 14:48:47 --> Security Class Initialized
DEBUG - 2019-11-05 14:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:48:47 --> CSRF cookie sent
INFO - 2019-11-05 14:48:47 --> CSRF token verified
INFO - 2019-11-05 14:48:47 --> Input Class Initialized
INFO - 2019-11-05 14:48:47 --> Language Class Initialized
INFO - 2019-11-05 14:48:47 --> Language Class Initialized
INFO - 2019-11-05 14:48:47 --> Config Class Initialized
INFO - 2019-11-05 14:48:47 --> Loader Class Initialized
INFO - 2019-11-05 14:48:47 --> Helper loaded: url_helper
INFO - 2019-11-05 14:48:47 --> Helper loaded: common_helper
INFO - 2019-11-05 14:48:47 --> Helper loaded: language_helper
INFO - 2019-11-05 14:48:47 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:48:47 --> Helper loaded: email_helper
INFO - 2019-11-05 14:48:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:48:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:48:48 --> Parser Class Initialized
INFO - 2019-11-05 14:48:48 --> User Agent Class Initialized
INFO - 2019-11-05 14:48:48 --> Model Class Initialized
INFO - 2019-11-05 14:48:48 --> Database Driver Class Initialized
INFO - 2019-11-05 14:48:48 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:48 --> Template Class Initialized
INFO - 2019-11-05 14:48:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:48:48 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:48:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:48:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:48:48 --> Encryption Class Initialized
INFO - 2019-11-05 14:48:48 --> Controller Class Initialized
DEBUG - 2019-11-05 14:48:48 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 14:48:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 14:48:48 --> Model Class Initialized
INFO - 2019-11-05 14:48:52 --> Config Class Initialized
INFO - 2019-11-05 14:48:52 --> Hooks Class Initialized
DEBUG - 2019-11-05 14:48:52 --> UTF-8 Support Enabled
INFO - 2019-11-05 14:48:52 --> Utf8 Class Initialized
INFO - 2019-11-05 14:48:52 --> URI Class Initialized
INFO - 2019-11-05 14:48:52 --> Router Class Initialized
INFO - 2019-11-05 14:48:52 --> Output Class Initialized
INFO - 2019-11-05 14:48:52 --> Security Class Initialized
DEBUG - 2019-11-05 14:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 14:48:52 --> CSRF cookie sent
INFO - 2019-11-05 14:48:52 --> Input Class Initialized
INFO - 2019-11-05 14:48:52 --> Language Class Initialized
INFO - 2019-11-05 14:48:52 --> Language Class Initialized
INFO - 2019-11-05 14:48:52 --> Config Class Initialized
INFO - 2019-11-05 14:48:52 --> Loader Class Initialized
INFO - 2019-11-05 14:48:52 --> Helper loaded: url_helper
INFO - 2019-11-05 14:48:52 --> Helper loaded: common_helper
INFO - 2019-11-05 14:48:52 --> Helper loaded: language_helper
INFO - 2019-11-05 14:48:52 --> Helper loaded: cookie_helper
INFO - 2019-11-05 14:48:53 --> Helper loaded: email_helper
INFO - 2019-11-05 14:48:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 14:48:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 14:48:53 --> Parser Class Initialized
INFO - 2019-11-05 14:48:53 --> User Agent Class Initialized
INFO - 2019-11-05 14:48:53 --> Model Class Initialized
INFO - 2019-11-05 14:48:53 --> Database Driver Class Initialized
INFO - 2019-11-05 14:48:53 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:53 --> Template Class Initialized
INFO - 2019-11-05 14:48:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 14:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 14:48:53 --> Pagination Class Initialized
DEBUG - 2019-11-05 14:48:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 14:48:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 14:48:53 --> Encryption Class Initialized
INFO - 2019-11-05 14:48:53 --> Controller Class Initialized
DEBUG - 2019-11-05 14:48:53 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 14:48:53 --> Model Class Initialized
INFO - 2019-11-05 14:48:53 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 14:48:53 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 14:48:53 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 14:48:53 --> Model Class Initialized
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 14:48:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 14:48:53 --> Final output sent to browser
DEBUG - 2019-11-05 14:48:53 --> Total execution time: 0.7117
INFO - 2019-11-05 15:42:15 --> Config Class Initialized
INFO - 2019-11-05 15:42:15 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:42:15 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:42:15 --> Utf8 Class Initialized
INFO - 2019-11-05 15:42:15 --> URI Class Initialized
INFO - 2019-11-05 15:42:15 --> Router Class Initialized
INFO - 2019-11-05 15:42:15 --> Output Class Initialized
INFO - 2019-11-05 15:42:15 --> Security Class Initialized
DEBUG - 2019-11-05 15:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:42:15 --> CSRF cookie sent
INFO - 2019-11-05 15:42:15 --> Input Class Initialized
INFO - 2019-11-05 15:42:15 --> Language Class Initialized
INFO - 2019-11-05 15:42:16 --> Language Class Initialized
INFO - 2019-11-05 15:42:16 --> Config Class Initialized
INFO - 2019-11-05 15:42:16 --> Loader Class Initialized
INFO - 2019-11-05 15:42:16 --> Helper loaded: url_helper
INFO - 2019-11-05 15:42:16 --> Helper loaded: common_helper
INFO - 2019-11-05 15:42:16 --> Helper loaded: language_helper
INFO - 2019-11-05 15:42:16 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:42:16 --> Helper loaded: email_helper
INFO - 2019-11-05 15:42:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:42:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:42:16 --> Parser Class Initialized
INFO - 2019-11-05 15:42:16 --> User Agent Class Initialized
INFO - 2019-11-05 15:42:16 --> Model Class Initialized
INFO - 2019-11-05 15:42:16 --> Database Driver Class Initialized
INFO - 2019-11-05 15:42:16 --> Model Class Initialized
DEBUG - 2019-11-05 15:42:16 --> Template Class Initialized
INFO - 2019-11-05 15:42:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:42:16 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:42:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:42:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:42:16 --> Encryption Class Initialized
INFO - 2019-11-05 15:42:16 --> Controller Class Initialized
DEBUG - 2019-11-05 15:42:16 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 15:42:16 --> Model Class Initialized
INFO - 2019-11-05 15:42:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 15:42:16 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 15:42:16 --> Model Class Initialized
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 15:42:16 --> Model Class Initialized
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 15:42:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 15:42:16 --> Final output sent to browser
DEBUG - 2019-11-05 15:42:16 --> Total execution time: 0.6080
INFO - 2019-11-05 15:57:51 --> Config Class Initialized
INFO - 2019-11-05 15:57:51 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:57:51 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:57:51 --> Utf8 Class Initialized
INFO - 2019-11-05 15:57:51 --> URI Class Initialized
INFO - 2019-11-05 15:57:51 --> Router Class Initialized
INFO - 2019-11-05 15:57:51 --> Output Class Initialized
INFO - 2019-11-05 15:57:51 --> Security Class Initialized
DEBUG - 2019-11-05 15:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:57:51 --> CSRF cookie sent
INFO - 2019-11-05 15:57:51 --> Input Class Initialized
INFO - 2019-11-05 15:57:51 --> Language Class Initialized
INFO - 2019-11-05 15:57:51 --> Language Class Initialized
INFO - 2019-11-05 15:57:51 --> Config Class Initialized
INFO - 2019-11-05 15:57:51 --> Loader Class Initialized
INFO - 2019-11-05 15:57:51 --> Helper loaded: url_helper
INFO - 2019-11-05 15:57:51 --> Helper loaded: common_helper
INFO - 2019-11-05 15:57:51 --> Helper loaded: language_helper
INFO - 2019-11-05 15:57:51 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:57:51 --> Helper loaded: email_helper
INFO - 2019-11-05 15:57:51 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:57:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:57:51 --> Parser Class Initialized
INFO - 2019-11-05 15:57:51 --> User Agent Class Initialized
INFO - 2019-11-05 15:57:51 --> Model Class Initialized
INFO - 2019-11-05 15:57:51 --> Database Driver Class Initialized
INFO - 2019-11-05 15:57:51 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:51 --> Template Class Initialized
INFO - 2019-11-05 15:57:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:57:51 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:57:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:57:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:57:51 --> Encryption Class Initialized
INFO - 2019-11-05 15:57:51 --> Controller Class Initialized
DEBUG - 2019-11-05 15:57:51 --> blogs MX_Controller Initialized
DEBUG - 2019-11-05 15:57:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/models/blogs_model.php
INFO - 2019-11-05 15:57:51 --> Model Class Initialized
INFO - 2019-11-05 15:57:51 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 15:57:51 --> Could not find the language line "Blogs"
ERROR - 2019-11-05 15:57:51 --> Could not find the language line "View"
ERROR - 2019-11-05 15:57:51 --> Could not find the language line "View"
ERROR - 2019-11-05 15:57:51 --> Could not find the language line "View"
DEBUG - 2019-11-05 15:57:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blogs/views/index.php
DEBUG - 2019-11-05 15:57:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 15:57:51 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 15:57:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 15:57:51 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 15:57:51 --> Model Class Initialized
ERROR - 2019-11-05 15:57:51 --> Could not find the language line "Blogs"
ERROR - 2019-11-05 15:57:51 --> Could not find the language line "Blogs"
DEBUG - 2019-11-05 15:57:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 15:57:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 15:57:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 15:57:51 --> Final output sent to browser
DEBUG - 2019-11-05 15:57:51 --> Total execution time: 0.7496
INFO - 2019-11-05 15:57:53 --> Config Class Initialized
INFO - 2019-11-05 15:57:53 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:57:53 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:57:53 --> Utf8 Class Initialized
INFO - 2019-11-05 15:57:53 --> URI Class Initialized
INFO - 2019-11-05 15:57:53 --> Router Class Initialized
INFO - 2019-11-05 15:57:53 --> Output Class Initialized
INFO - 2019-11-05 15:57:53 --> Security Class Initialized
DEBUG - 2019-11-05 15:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:57:53 --> CSRF cookie sent
INFO - 2019-11-05 15:57:53 --> Input Class Initialized
INFO - 2019-11-05 15:57:53 --> Language Class Initialized
INFO - 2019-11-05 15:57:53 --> Language Class Initialized
INFO - 2019-11-05 15:57:53 --> Config Class Initialized
INFO - 2019-11-05 15:57:53 --> Loader Class Initialized
INFO - 2019-11-05 15:57:53 --> Helper loaded: url_helper
INFO - 2019-11-05 15:57:53 --> Helper loaded: common_helper
INFO - 2019-11-05 15:57:53 --> Helper loaded: language_helper
INFO - 2019-11-05 15:57:53 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:57:53 --> Helper loaded: email_helper
INFO - 2019-11-05 15:57:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:57:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:57:53 --> Parser Class Initialized
INFO - 2019-11-05 15:57:53 --> User Agent Class Initialized
INFO - 2019-11-05 15:57:53 --> Model Class Initialized
INFO - 2019-11-05 15:57:53 --> Database Driver Class Initialized
INFO - 2019-11-05 15:57:53 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:53 --> Template Class Initialized
INFO - 2019-11-05 15:57:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:57:54 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:57:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:57:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:57:54 --> Encryption Class Initialized
INFO - 2019-11-05 15:57:54 --> Controller Class Initialized
DEBUG - 2019-11-05 15:57:54 --> faqs MX_Controller Initialized
DEBUG - 2019-11-05 15:57:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/models/faqs_model.php
INFO - 2019-11-05 15:57:54 --> Model Class Initialized
INFO - 2019-11-05 15:57:54 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 15:57:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/faqs/views/index.php
DEBUG - 2019-11-05 15:57:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 15:57:54 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 15:57:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 15:57:54 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 15:57:54 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 15:57:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 15:57:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 15:57:54 --> Final output sent to browser
DEBUG - 2019-11-05 15:57:54 --> Total execution time: 0.6234
INFO - 2019-11-05 15:57:55 --> Config Class Initialized
INFO - 2019-11-05 15:57:55 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:57:55 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:57:55 --> Utf8 Class Initialized
INFO - 2019-11-05 15:57:55 --> URI Class Initialized
INFO - 2019-11-05 15:57:55 --> Router Class Initialized
INFO - 2019-11-05 15:57:55 --> Output Class Initialized
INFO - 2019-11-05 15:57:55 --> Security Class Initialized
DEBUG - 2019-11-05 15:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:57:55 --> CSRF cookie sent
INFO - 2019-11-05 15:57:55 --> Input Class Initialized
INFO - 2019-11-05 15:57:55 --> Language Class Initialized
INFO - 2019-11-05 15:57:55 --> Language Class Initialized
INFO - 2019-11-05 15:57:55 --> Config Class Initialized
INFO - 2019-11-05 15:57:55 --> Loader Class Initialized
INFO - 2019-11-05 15:57:55 --> Helper loaded: url_helper
INFO - 2019-11-05 15:57:55 --> Helper loaded: common_helper
INFO - 2019-11-05 15:57:55 --> Helper loaded: language_helper
INFO - 2019-11-05 15:57:55 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:57:55 --> Helper loaded: email_helper
INFO - 2019-11-05 15:57:55 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:57:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:57:55 --> Parser Class Initialized
INFO - 2019-11-05 15:57:55 --> User Agent Class Initialized
INFO - 2019-11-05 15:57:55 --> Model Class Initialized
INFO - 2019-11-05 15:57:55 --> Database Driver Class Initialized
INFO - 2019-11-05 15:57:55 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:55 --> Template Class Initialized
INFO - 2019-11-05 15:57:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:57:55 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:57:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:57:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:57:55 --> Encryption Class Initialized
INFO - 2019-11-05 15:57:55 --> Controller Class Initialized
DEBUG - 2019-11-05 15:57:55 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 15:57:55 --> Model Class Initialized
INFO - 2019-11-05 15:57:55 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 15:57:55 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 15:57:55 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 15:57:55 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 15:57:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 15:57:55 --> Final output sent to browser
DEBUG - 2019-11-05 15:57:55 --> Total execution time: 0.5968
INFO - 2019-11-05 15:57:59 --> Config Class Initialized
INFO - 2019-11-05 15:57:59 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:57:59 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:57:59 --> Utf8 Class Initialized
INFO - 2019-11-05 15:57:59 --> URI Class Initialized
INFO - 2019-11-05 15:57:59 --> Router Class Initialized
INFO - 2019-11-05 15:57:59 --> Output Class Initialized
INFO - 2019-11-05 15:57:59 --> Security Class Initialized
DEBUG - 2019-11-05 15:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:57:59 --> CSRF cookie sent
INFO - 2019-11-05 15:57:59 --> Input Class Initialized
INFO - 2019-11-05 15:57:59 --> Language Class Initialized
INFO - 2019-11-05 15:57:59 --> Language Class Initialized
INFO - 2019-11-05 15:57:59 --> Config Class Initialized
INFO - 2019-11-05 15:57:59 --> Loader Class Initialized
INFO - 2019-11-05 15:57:59 --> Helper loaded: url_helper
INFO - 2019-11-05 15:57:59 --> Helper loaded: common_helper
INFO - 2019-11-05 15:57:59 --> Helper loaded: language_helper
INFO - 2019-11-05 15:57:59 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:57:59 --> Helper loaded: email_helper
INFO - 2019-11-05 15:57:59 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:57:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:57:59 --> Parser Class Initialized
INFO - 2019-11-05 15:57:59 --> User Agent Class Initialized
INFO - 2019-11-05 15:57:59 --> Model Class Initialized
INFO - 2019-11-05 15:57:59 --> Database Driver Class Initialized
INFO - 2019-11-05 15:57:59 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:59 --> Template Class Initialized
INFO - 2019-11-05 15:57:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:57:59 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:57:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:57:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:57:59 --> Encryption Class Initialized
INFO - 2019-11-05 15:57:59 --> Controller Class Initialized
DEBUG - 2019-11-05 15:57:59 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 15:57:59 --> Model Class Initialized
INFO - 2019-11-05 15:57:59 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-05 15:57:59 --> Could not find the language line "Paytm_Integration"
ERROR - 2019-11-05 15:57:59 --> Could not find the language line "currency_rate"
ERROR - 2019-11-05 15:57:59 --> Could not find the language line "Paytm_mid_merchant_id"
ERROR - 2019-11-05 15:57:59 --> Could not find the language line "paytm_merchant_key"
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paytm.php
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 15:57:59 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 15:57:59 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 15:57:59 --> Model Class Initialized
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 15:57:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 15:57:59 --> Final output sent to browser
DEBUG - 2019-11-05 15:57:59 --> Total execution time: 0.6843
INFO - 2019-11-05 15:58:09 --> Config Class Initialized
INFO - 2019-11-05 15:58:09 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:58:09 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:58:09 --> Utf8 Class Initialized
INFO - 2019-11-05 15:58:09 --> URI Class Initialized
INFO - 2019-11-05 15:58:09 --> Router Class Initialized
INFO - 2019-11-05 15:58:09 --> Output Class Initialized
INFO - 2019-11-05 15:58:09 --> Security Class Initialized
DEBUG - 2019-11-05 15:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:58:09 --> CSRF cookie sent
INFO - 2019-11-05 15:58:09 --> Input Class Initialized
INFO - 2019-11-05 15:58:09 --> Language Class Initialized
INFO - 2019-11-05 15:58:09 --> Language Class Initialized
INFO - 2019-11-05 15:58:09 --> Config Class Initialized
INFO - 2019-11-05 15:58:09 --> Loader Class Initialized
INFO - 2019-11-05 15:58:09 --> Helper loaded: url_helper
INFO - 2019-11-05 15:58:09 --> Helper loaded: common_helper
INFO - 2019-11-05 15:58:09 --> Helper loaded: language_helper
INFO - 2019-11-05 15:58:09 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:58:09 --> Helper loaded: email_helper
INFO - 2019-11-05 15:58:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:58:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:58:09 --> Parser Class Initialized
INFO - 2019-11-05 15:58:09 --> User Agent Class Initialized
INFO - 2019-11-05 15:58:09 --> Model Class Initialized
INFO - 2019-11-05 15:58:09 --> Database Driver Class Initialized
INFO - 2019-11-05 15:58:09 --> Model Class Initialized
DEBUG - 2019-11-05 15:58:09 --> Template Class Initialized
INFO - 2019-11-05 15:58:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:58:09 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:58:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:58:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:58:09 --> Encryption Class Initialized
INFO - 2019-11-05 15:58:09 --> Controller Class Initialized
DEBUG - 2019-11-05 15:58:09 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 15:58:09 --> Model Class Initialized
INFO - 2019-11-05 15:58:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/dotpay.php
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 15:58:09 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 15:58:09 --> Model Class Initialized
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 15:58:09 --> Model Class Initialized
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 15:58:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 15:58:09 --> Final output sent to browser
DEBUG - 2019-11-05 15:58:09 --> Total execution time: 0.6154
INFO - 2019-11-05 15:58:14 --> Config Class Initialized
INFO - 2019-11-05 15:58:14 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:58:14 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:58:14 --> Utf8 Class Initialized
INFO - 2019-11-05 15:58:14 --> URI Class Initialized
INFO - 2019-11-05 15:58:14 --> Router Class Initialized
INFO - 2019-11-05 15:58:14 --> Output Class Initialized
INFO - 2019-11-05 15:58:14 --> Security Class Initialized
DEBUG - 2019-11-05 15:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:58:14 --> CSRF cookie sent
INFO - 2019-11-05 15:58:14 --> Input Class Initialized
INFO - 2019-11-05 15:58:14 --> Language Class Initialized
INFO - 2019-11-05 15:58:14 --> Language Class Initialized
INFO - 2019-11-05 15:58:14 --> Config Class Initialized
INFO - 2019-11-05 15:58:15 --> Loader Class Initialized
INFO - 2019-11-05 15:58:15 --> Helper loaded: url_helper
INFO - 2019-11-05 15:58:15 --> Helper loaded: common_helper
INFO - 2019-11-05 15:58:15 --> Helper loaded: language_helper
INFO - 2019-11-05 15:58:15 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:58:15 --> Helper loaded: email_helper
INFO - 2019-11-05 15:58:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:58:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:58:15 --> Parser Class Initialized
INFO - 2019-11-05 15:58:15 --> User Agent Class Initialized
INFO - 2019-11-05 15:58:15 --> Model Class Initialized
INFO - 2019-11-05 15:58:15 --> Database Driver Class Initialized
INFO - 2019-11-05 15:58:15 --> Model Class Initialized
DEBUG - 2019-11-05 15:58:15 --> Template Class Initialized
INFO - 2019-11-05 15:58:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:58:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:58:15 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:58:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:58:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:58:15 --> Encryption Class Initialized
INFO - 2019-11-05 15:58:15 --> Controller Class Initialized
DEBUG - 2019-11-05 15:58:15 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 15:58:15 --> Model Class Initialized
INFO - 2019-11-05 15:58:15 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-05 15:58:15 --> Could not find the language line "Paytm_Integration"
ERROR - 2019-11-05 15:58:15 --> Could not find the language line "currency_rate"
ERROR - 2019-11-05 15:58:15 --> Could not find the language line "Paytm_mid_merchant_id"
ERROR - 2019-11-05 15:58:15 --> Could not find the language line "paytm_merchant_key"
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paytm.php
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 15:58:15 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 15:58:15 --> Model Class Initialized
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 15:58:15 --> Model Class Initialized
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 15:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 15:58:15 --> Final output sent to browser
DEBUG - 2019-11-05 15:58:15 --> Total execution time: 0.6613
INFO - 2019-11-05 15:59:25 --> Config Class Initialized
INFO - 2019-11-05 15:59:25 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:59:25 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:59:25 --> Utf8 Class Initialized
INFO - 2019-11-05 15:59:25 --> URI Class Initialized
INFO - 2019-11-05 15:59:26 --> Router Class Initialized
INFO - 2019-11-05 15:59:26 --> Output Class Initialized
INFO - 2019-11-05 15:59:26 --> Security Class Initialized
DEBUG - 2019-11-05 15:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:59:26 --> CSRF cookie sent
INFO - 2019-11-05 15:59:26 --> Input Class Initialized
INFO - 2019-11-05 15:59:26 --> Language Class Initialized
INFO - 2019-11-05 15:59:26 --> Language Class Initialized
INFO - 2019-11-05 15:59:26 --> Config Class Initialized
INFO - 2019-11-05 15:59:26 --> Loader Class Initialized
INFO - 2019-11-05 15:59:26 --> Helper loaded: url_helper
INFO - 2019-11-05 15:59:26 --> Helper loaded: common_helper
INFO - 2019-11-05 15:59:26 --> Helper loaded: language_helper
INFO - 2019-11-05 15:59:26 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:59:26 --> Helper loaded: email_helper
INFO - 2019-11-05 15:59:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:59:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:59:26 --> Parser Class Initialized
INFO - 2019-11-05 15:59:26 --> User Agent Class Initialized
INFO - 2019-11-05 15:59:26 --> Model Class Initialized
INFO - 2019-11-05 15:59:26 --> Database Driver Class Initialized
INFO - 2019-11-05 15:59:26 --> Model Class Initialized
DEBUG - 2019-11-05 15:59:26 --> Template Class Initialized
INFO - 2019-11-05 15:59:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:59:26 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:59:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:59:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:59:26 --> Encryption Class Initialized
INFO - 2019-11-05 15:59:26 --> Controller Class Initialized
DEBUG - 2019-11-05 15:59:26 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 15:59:26 --> Model Class Initialized
INFO - 2019-11-05 15:59:26 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-05 15:59:26 --> Could not find the language line "Paytm_Integration"
ERROR - 2019-11-05 15:59:26 --> Could not find the language line "Paytm_mid_merchant_id"
ERROR - 2019-11-05 15:59:26 --> Could not find the language line "paytm_merchant_key"
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paytm.php
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 15:59:26 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 15:59:26 --> Model Class Initialized
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 15:59:26 --> Model Class Initialized
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 15:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 15:59:26 --> Final output sent to browser
DEBUG - 2019-11-05 15:59:26 --> Total execution time: 0.7140
INFO - 2019-11-05 15:59:38 --> Config Class Initialized
INFO - 2019-11-05 15:59:38 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:59:38 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:59:38 --> Utf8 Class Initialized
INFO - 2019-11-05 15:59:38 --> URI Class Initialized
INFO - 2019-11-05 15:59:38 --> Router Class Initialized
INFO - 2019-11-05 15:59:38 --> Output Class Initialized
INFO - 2019-11-05 15:59:38 --> Security Class Initialized
DEBUG - 2019-11-05 15:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:59:38 --> CSRF cookie sent
INFO - 2019-11-05 15:59:38 --> CSRF token verified
INFO - 2019-11-05 15:59:38 --> Input Class Initialized
INFO - 2019-11-05 15:59:38 --> Language Class Initialized
INFO - 2019-11-05 15:59:38 --> Language Class Initialized
INFO - 2019-11-05 15:59:38 --> Config Class Initialized
INFO - 2019-11-05 15:59:38 --> Loader Class Initialized
INFO - 2019-11-05 15:59:38 --> Helper loaded: url_helper
INFO - 2019-11-05 15:59:38 --> Helper loaded: common_helper
INFO - 2019-11-05 15:59:38 --> Helper loaded: language_helper
INFO - 2019-11-05 15:59:38 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:59:38 --> Helper loaded: email_helper
INFO - 2019-11-05 15:59:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:59:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:59:38 --> Parser Class Initialized
INFO - 2019-11-05 15:59:38 --> User Agent Class Initialized
INFO - 2019-11-05 15:59:38 --> Model Class Initialized
INFO - 2019-11-05 15:59:39 --> Database Driver Class Initialized
INFO - 2019-11-05 15:59:39 --> Model Class Initialized
DEBUG - 2019-11-05 15:59:39 --> Template Class Initialized
INFO - 2019-11-05 15:59:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:59:39 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:59:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:59:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:59:39 --> Encryption Class Initialized
INFO - 2019-11-05 15:59:39 --> Controller Class Initialized
DEBUG - 2019-11-05 15:59:39 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 15:59:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 15:59:39 --> Model Class Initialized
INFO - 2019-11-05 15:59:43 --> Config Class Initialized
INFO - 2019-11-05 15:59:43 --> Hooks Class Initialized
DEBUG - 2019-11-05 15:59:43 --> UTF-8 Support Enabled
INFO - 2019-11-05 15:59:43 --> Utf8 Class Initialized
INFO - 2019-11-05 15:59:43 --> URI Class Initialized
INFO - 2019-11-05 15:59:43 --> Router Class Initialized
INFO - 2019-11-05 15:59:43 --> Output Class Initialized
INFO - 2019-11-05 15:59:43 --> Security Class Initialized
DEBUG - 2019-11-05 15:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 15:59:43 --> CSRF cookie sent
INFO - 2019-11-05 15:59:43 --> Input Class Initialized
INFO - 2019-11-05 15:59:43 --> Language Class Initialized
INFO - 2019-11-05 15:59:43 --> Language Class Initialized
INFO - 2019-11-05 15:59:43 --> Config Class Initialized
INFO - 2019-11-05 15:59:43 --> Loader Class Initialized
INFO - 2019-11-05 15:59:43 --> Helper loaded: url_helper
INFO - 2019-11-05 15:59:43 --> Helper loaded: common_helper
INFO - 2019-11-05 15:59:43 --> Helper loaded: language_helper
INFO - 2019-11-05 15:59:43 --> Helper loaded: cookie_helper
INFO - 2019-11-05 15:59:43 --> Helper loaded: email_helper
INFO - 2019-11-05 15:59:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 15:59:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 15:59:43 --> Parser Class Initialized
INFO - 2019-11-05 15:59:43 --> User Agent Class Initialized
INFO - 2019-11-05 15:59:43 --> Model Class Initialized
INFO - 2019-11-05 15:59:44 --> Database Driver Class Initialized
INFO - 2019-11-05 15:59:44 --> Model Class Initialized
DEBUG - 2019-11-05 15:59:44 --> Template Class Initialized
INFO - 2019-11-05 15:59:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 15:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 15:59:44 --> Pagination Class Initialized
DEBUG - 2019-11-05 15:59:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 15:59:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 15:59:44 --> Encryption Class Initialized
INFO - 2019-11-05 15:59:44 --> Controller Class Initialized
DEBUG - 2019-11-05 15:59:44 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 15:59:44 --> Model Class Initialized
INFO - 2019-11-05 15:59:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 15:59:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 15:59:44 --> Model Class Initialized
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 15:59:44 --> Model Class Initialized
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 15:59:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 15:59:44 --> Final output sent to browser
DEBUG - 2019-11-05 15:59:44 --> Total execution time: 0.6919
INFO - 2019-11-05 16:40:46 --> Config Class Initialized
INFO - 2019-11-05 16:40:46 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:40:46 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:40:46 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:46 --> URI Class Initialized
INFO - 2019-11-05 16:40:46 --> Router Class Initialized
INFO - 2019-11-05 16:40:46 --> Output Class Initialized
INFO - 2019-11-05 16:40:46 --> Security Class Initialized
DEBUG - 2019-11-05 16:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:40:46 --> CSRF cookie sent
INFO - 2019-11-05 16:40:46 --> Input Class Initialized
INFO - 2019-11-05 16:40:46 --> Language Class Initialized
INFO - 2019-11-05 16:40:47 --> Language Class Initialized
INFO - 2019-11-05 16:40:47 --> Config Class Initialized
INFO - 2019-11-05 16:40:47 --> Loader Class Initialized
INFO - 2019-11-05 16:40:47 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:47 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:47 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:47 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:40:47 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:47 --> Parser Class Initialized
INFO - 2019-11-05 16:40:47 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:47 --> Model Class Initialized
INFO - 2019-11-05 16:40:47 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:47 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:47 --> Template Class Initialized
INFO - 2019-11-05 16:40:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:47 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:40:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:47 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:47 --> Controller Class Initialized
DEBUG - 2019-11-05 16:40:47 --> users MX_Controller Initialized
DEBUG - 2019-11-05 16:40:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/users/models/users_model.php
INFO - 2019-11-05 16:40:47 --> Model Class Initialized
ERROR - 2019-11-05 16:40:47 --> Could not find the language line "Last_Order"
INFO - 2019-11-05 16:40:47 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:40:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/users/views/index.php
DEBUG - 2019-11-05 16:40:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:40:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:40:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:47 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:40:47 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 16:40:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 16:40:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 16:40:47 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:47 --> Total execution time: 0.5922
INFO - 2019-11-05 16:40:48 --> Config Class Initialized
INFO - 2019-11-05 16:40:48 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:40:48 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:40:48 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:48 --> URI Class Initialized
INFO - 2019-11-05 16:40:48 --> Router Class Initialized
INFO - 2019-11-05 16:40:48 --> Output Class Initialized
INFO - 2019-11-05 16:40:48 --> Security Class Initialized
DEBUG - 2019-11-05 16:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:40:48 --> CSRF cookie sent
INFO - 2019-11-05 16:40:48 --> Input Class Initialized
INFO - 2019-11-05 16:40:48 --> Language Class Initialized
INFO - 2019-11-05 16:40:48 --> Language Class Initialized
INFO - 2019-11-05 16:40:48 --> Config Class Initialized
INFO - 2019-11-05 16:40:48 --> Loader Class Initialized
INFO - 2019-11-05 16:40:48 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:48 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:48 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:48 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:40:48 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:48 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:49 --> Parser Class Initialized
INFO - 2019-11-05 16:40:49 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:49 --> Template Class Initialized
INFO - 2019-11-05 16:40:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:49 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:40:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:49 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:49 --> Controller Class Initialized
DEBUG - 2019-11-05 16:40:49 --> services MX_Controller Initialized
DEBUG - 2019-11-05 16:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 16:40:49 --> Could not find the language line "Delele"
DEBUG - 2019-11-05 16:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/index.php
DEBUG - 2019-11-05 16:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:40:49 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:40:49 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 16:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 16:40:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 16:40:49 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:49 --> Total execution time: 0.5983
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Hooks Class Initialized
INFO - 2019-11-05 16:40:49 --> Hooks Class Initialized
INFO - 2019-11-05 16:40:49 --> Hooks Class Initialized
INFO - 2019-11-05 16:40:49 --> Hooks Class Initialized
INFO - 2019-11-05 16:40:49 --> Hooks Class Initialized
INFO - 2019-11-05 16:40:49 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:40:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 16:40:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 16:40:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 16:40:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 16:40:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 16:40:49 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:40:49 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:49 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:49 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:49 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:49 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:49 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:49 --> URI Class Initialized
INFO - 2019-11-05 16:40:49 --> URI Class Initialized
INFO - 2019-11-05 16:40:49 --> URI Class Initialized
INFO - 2019-11-05 16:40:49 --> URI Class Initialized
INFO - 2019-11-05 16:40:49 --> URI Class Initialized
INFO - 2019-11-05 16:40:49 --> URI Class Initialized
INFO - 2019-11-05 16:40:49 --> Router Class Initialized
INFO - 2019-11-05 16:40:49 --> Router Class Initialized
INFO - 2019-11-05 16:40:49 --> Router Class Initialized
INFO - 2019-11-05 16:40:49 --> Router Class Initialized
INFO - 2019-11-05 16:40:49 --> Router Class Initialized
INFO - 2019-11-05 16:40:49 --> Router Class Initialized
INFO - 2019-11-05 16:40:49 --> Output Class Initialized
INFO - 2019-11-05 16:40:49 --> Output Class Initialized
INFO - 2019-11-05 16:40:49 --> Output Class Initialized
INFO - 2019-11-05 16:40:49 --> Output Class Initialized
INFO - 2019-11-05 16:40:49 --> Output Class Initialized
INFO - 2019-11-05 16:40:49 --> Output Class Initialized
INFO - 2019-11-05 16:40:49 --> Security Class Initialized
INFO - 2019-11-05 16:40:49 --> Security Class Initialized
INFO - 2019-11-05 16:40:49 --> Security Class Initialized
INFO - 2019-11-05 16:40:49 --> Security Class Initialized
INFO - 2019-11-05 16:40:49 --> Security Class Initialized
INFO - 2019-11-05 16:40:49 --> Security Class Initialized
DEBUG - 2019-11-05 16:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 16:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 16:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 16:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 16:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 16:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:40:49 --> CSRF cookie sent
INFO - 2019-11-05 16:40:49 --> CSRF cookie sent
INFO - 2019-11-05 16:40:49 --> CSRF cookie sent
INFO - 2019-11-05 16:40:49 --> CSRF cookie sent
INFO - 2019-11-05 16:40:49 --> CSRF cookie sent
INFO - 2019-11-05 16:40:49 --> CSRF cookie sent
INFO - 2019-11-05 16:40:49 --> CSRF token verified
INFO - 2019-11-05 16:40:49 --> CSRF token verified
INFO - 2019-11-05 16:40:49 --> CSRF token verified
INFO - 2019-11-05 16:40:49 --> CSRF token verified
INFO - 2019-11-05 16:40:49 --> CSRF token verified
INFO - 2019-11-05 16:40:49 --> CSRF token verified
INFO - 2019-11-05 16:40:49 --> Input Class Initialized
INFO - 2019-11-05 16:40:49 --> Input Class Initialized
INFO - 2019-11-05 16:40:49 --> Input Class Initialized
INFO - 2019-11-05 16:40:49 --> Input Class Initialized
INFO - 2019-11-05 16:40:49 --> Input Class Initialized
INFO - 2019-11-05 16:40:49 --> Input Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Language Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Config Class Initialized
INFO - 2019-11-05 16:40:49 --> Loader Class Initialized
INFO - 2019-11-05 16:40:49 --> Loader Class Initialized
INFO - 2019-11-05 16:40:49 --> Loader Class Initialized
INFO - 2019-11-05 16:40:49 --> Loader Class Initialized
INFO - 2019-11-05 16:40:49 --> Loader Class Initialized
INFO - 2019-11-05 16:40:49 --> Loader Class Initialized
INFO - 2019-11-05 16:40:49 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:49 --> Parser Class Initialized
INFO - 2019-11-05 16:40:49 --> Parser Class Initialized
INFO - 2019-11-05 16:40:49 --> Parser Class Initialized
INFO - 2019-11-05 16:40:49 --> Parser Class Initialized
INFO - 2019-11-05 16:40:49 --> Parser Class Initialized
INFO - 2019-11-05 16:40:49 --> Parser Class Initialized
INFO - 2019-11-05 16:40:49 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:49 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:49 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:49 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:49 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:49 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:49 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:49 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:49 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:49 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:49 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
INFO - 2019-11-05 16:40:49 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:49 --> Template Class Initialized
DEBUG - 2019-11-05 16:40:49 --> Template Class Initialized
DEBUG - 2019-11-05 16:40:49 --> Template Class Initialized
DEBUG - 2019-11-05 16:40:49 --> Template Class Initialized
DEBUG - 2019-11-05 16:40:49 --> Template Class Initialized
DEBUG - 2019-11-05 16:40:49 --> Template Class Initialized
INFO - 2019-11-05 16:40:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:50 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:40:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:50 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:50 --> Controller Class Initialized
DEBUG - 2019-11-05 16:40:50 --> services MX_Controller Initialized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-05 16:40:50 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:50 --> Total execution time: 0.5569
INFO - 2019-11-05 16:40:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:50 --> Config Class Initialized
INFO - 2019-11-05 16:40:50 --> Hooks Class Initialized
INFO - 2019-11-05 16:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:50 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:40:50 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:40:50 --> Utf8 Class Initialized
DEBUG - 2019-11-05 16:40:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:50 --> URI Class Initialized
INFO - 2019-11-05 16:40:50 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:50 --> Router Class Initialized
INFO - 2019-11-05 16:40:50 --> Controller Class Initialized
INFO - 2019-11-05 16:40:50 --> Output Class Initialized
DEBUG - 2019-11-05 16:40:50 --> services MX_Controller Initialized
INFO - 2019-11-05 16:40:50 --> Security Class Initialized
DEBUG - 2019-11-05 16:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
INFO - 2019-11-05 16:40:50 --> CSRF cookie sent
INFO - 2019-11-05 16:40:50 --> CSRF token verified
INFO - 2019-11-05 16:40:50 --> Input Class Initialized
INFO - 2019-11-05 16:40:50 --> Language Class Initialized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-05 16:40:50 --> Language Class Initialized
INFO - 2019-11-05 16:40:50 --> Config Class Initialized
INFO - 2019-11-05 16:40:50 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:50 --> Total execution time: 0.7400
INFO - 2019-11-05 16:40:50 --> Loader Class Initialized
INFO - 2019-11-05 16:40:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:50 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:50 --> Config Class Initialized
INFO - 2019-11-05 16:40:50 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:50 --> Hooks Class Initialized
INFO - 2019-11-05 16:40:50 --> Pagination Class Initialized
INFO - 2019-11-05 16:40:50 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:50 --> Helper loaded: cookie_helper
DEBUG - 2019-11-05 16:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2019-11-05 16:40:50 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:40:50 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:50 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:50 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:50 --> URI Class Initialized
INFO - 2019-11-05 16:40:50 --> Controller Class Initialized
INFO - 2019-11-05 16:40:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:50 --> Router Class Initialized
DEBUG - 2019-11-05 16:40:50 --> services MX_Controller Initialized
INFO - 2019-11-05 16:40:50 --> Output Class Initialized
INFO - 2019-11-05 16:40:50 --> Parser Class Initialized
INFO - 2019-11-05 16:40:50 --> Security Class Initialized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:50 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
INFO - 2019-11-05 16:40:50 --> CSRF cookie sent
INFO - 2019-11-05 16:40:50 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:50 --> CSRF token verified
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
INFO - 2019-11-05 16:40:50 --> Input Class Initialized
DEBUG - 2019-11-05 16:40:50 --> Template Class Initialized
INFO - 2019-11-05 16:40:50 --> Language Class Initialized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-05 16:40:50 --> Final output sent to browser
INFO - 2019-11-05 16:40:50 --> Language Class Initialized
DEBUG - 2019-11-05 16:40:50 --> Total execution time: 0.9658
INFO - 2019-11-05 16:40:50 --> Config Class Initialized
INFO - 2019-11-05 16:40:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:50 --> Loader Class Initialized
INFO - 2019-11-05 16:40:50 --> Config Class Initialized
INFO - 2019-11-05 16:40:50 --> Hooks Class Initialized
INFO - 2019-11-05 16:40:50 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:50 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:40:50 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:40:50 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:50 --> Utf8 Class Initialized
INFO - 2019-11-05 16:40:50 --> Helper loaded: language_helper
DEBUG - 2019-11-05 16:40:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:50 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:40:50 --> URI Class Initialized
INFO - 2019-11-05 16:40:50 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:50 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:50 --> Router Class Initialized
INFO - 2019-11-05 16:40:50 --> Controller Class Initialized
INFO - 2019-11-05 16:40:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:50 --> Output Class Initialized
DEBUG - 2019-11-05 16:40:50 --> services MX_Controller Initialized
INFO - 2019-11-05 16:40:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:40:50 --> Security Class Initialized
DEBUG - 2019-11-05 16:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:50 --> Parser Class Initialized
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
INFO - 2019-11-05 16:40:50 --> CSRF cookie sent
INFO - 2019-11-05 16:40:50 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:50 --> CSRF token verified
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
INFO - 2019-11-05 16:40:50 --> Input Class Initialized
INFO - 2019-11-05 16:40:50 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:50 --> Language Class Initialized
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
DEBUG - 2019-11-05 16:40:50 --> Template Class Initialized
INFO - 2019-11-05 16:40:50 --> Language Class Initialized
INFO - 2019-11-05 16:40:50 --> Config Class Initialized
INFO - 2019-11-05 16:40:50 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:50 --> Total execution time: 1.1662
INFO - 2019-11-05 16:40:50 --> Loader Class Initialized
INFO - 2019-11-05 16:40:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:50 --> Helper loaded: url_helper
INFO - 2019-11-05 16:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:50 --> Helper loaded: common_helper
INFO - 2019-11-05 16:40:50 --> Pagination Class Initialized
INFO - 2019-11-05 16:40:50 --> Helper loaded: language_helper
INFO - 2019-11-05 16:40:50 --> Helper loaded: cookie_helper
DEBUG - 2019-11-05 16:40:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:50 --> Helper loaded: email_helper
INFO - 2019-11-05 16:40:50 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:40:50 --> Controller Class Initialized
INFO - 2019-11-05 16:40:50 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-11-05 16:40:50 --> services MX_Controller Initialized
INFO - 2019-11-05 16:40:50 --> Parser Class Initialized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:50 --> User Agent Class Initialized
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
INFO - 2019-11-05 16:40:50 --> Database Driver Class Initialized
INFO - 2019-11-05 16:40:50 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:50 --> Template Class Initialized
DEBUG - 2019-11-05 16:40:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-05 16:40:50 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:50 --> Total execution time: 1.3429
INFO - 2019-11-05 16:40:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:51 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:40:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:51 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:51 --> Controller Class Initialized
DEBUG - 2019-11-05 16:40:51 --> services MX_Controller Initialized
DEBUG - 2019-11-05 16:40:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:51 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-05 16:40:51 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:51 --> Total execution time: 1.4970
INFO - 2019-11-05 16:40:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:51 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:40:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:51 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:51 --> Controller Class Initialized
DEBUG - 2019-11-05 16:40:51 --> services MX_Controller Initialized
DEBUG - 2019-11-05 16:40:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:51 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-05 16:40:51 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:51 --> Total execution time: 1.0772
INFO - 2019-11-05 16:40:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:51 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:40:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:51 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:51 --> Controller Class Initialized
DEBUG - 2019-11-05 16:40:51 --> services MX_Controller Initialized
DEBUG - 2019-11-05 16:40:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:51 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-05 16:40:51 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:51 --> Total execution time: 1.0441
INFO - 2019-11-05 16:40:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:40:51 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:40:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:40:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:40:51 --> Encryption Class Initialized
INFO - 2019-11-05 16:40:51 --> Controller Class Initialized
DEBUG - 2019-11-05 16:40:51 --> services MX_Controller Initialized
DEBUG - 2019-11-05 16:40:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:40:51 --> Model Class Initialized
DEBUG - 2019-11-05 16:40:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/views/ajax/load_services_by_cate.php
INFO - 2019-11-05 16:40:51 --> Final output sent to browser
DEBUG - 2019-11-05 16:40:51 --> Total execution time: 0.9777
INFO - 2019-11-05 16:41:09 --> Config Class Initialized
INFO - 2019-11-05 16:41:09 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:41:09 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:41:09 --> Utf8 Class Initialized
INFO - 2019-11-05 16:41:09 --> URI Class Initialized
INFO - 2019-11-05 16:41:09 --> Router Class Initialized
INFO - 2019-11-05 16:41:09 --> Output Class Initialized
INFO - 2019-11-05 16:41:09 --> Security Class Initialized
DEBUG - 2019-11-05 16:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:41:09 --> CSRF cookie sent
INFO - 2019-11-05 16:41:09 --> Input Class Initialized
INFO - 2019-11-05 16:41:09 --> Language Class Initialized
INFO - 2019-11-05 16:41:09 --> Language Class Initialized
INFO - 2019-11-05 16:41:09 --> Config Class Initialized
INFO - 2019-11-05 16:41:09 --> Loader Class Initialized
INFO - 2019-11-05 16:41:09 --> Helper loaded: url_helper
INFO - 2019-11-05 16:41:09 --> Helper loaded: common_helper
INFO - 2019-11-05 16:41:09 --> Helper loaded: language_helper
INFO - 2019-11-05 16:41:09 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:41:09 --> Helper loaded: email_helper
INFO - 2019-11-05 16:41:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:41:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:41:09 --> Parser Class Initialized
INFO - 2019-11-05 16:41:09 --> User Agent Class Initialized
INFO - 2019-11-05 16:41:09 --> Model Class Initialized
INFO - 2019-11-05 16:41:09 --> Database Driver Class Initialized
INFO - 2019-11-05 16:41:09 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:09 --> Template Class Initialized
INFO - 2019-11-05 16:41:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:41:09 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:41:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:41:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:41:09 --> Encryption Class Initialized
INFO - 2019-11-05 16:41:09 --> Controller Class Initialized
DEBUG - 2019-11-05 16:41:09 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 16:41:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 16:41:09 --> Model Class Initialized
INFO - 2019-11-05 16:41:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:41:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 16:41:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-05 16:41:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 16:41:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:41:10 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:41:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:41:10 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:41:10 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 16:41:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 16:41:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 16:41:10 --> Final output sent to browser
DEBUG - 2019-11-05 16:41:10 --> Total execution time: 0.7790
INFO - 2019-11-05 16:41:20 --> Config Class Initialized
INFO - 2019-11-05 16:41:20 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:41:20 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:41:20 --> Utf8 Class Initialized
INFO - 2019-11-05 16:41:20 --> URI Class Initialized
DEBUG - 2019-11-05 16:41:20 --> No URI present. Default controller set.
INFO - 2019-11-05 16:41:20 --> Router Class Initialized
INFO - 2019-11-05 16:41:20 --> Output Class Initialized
INFO - 2019-11-05 16:41:20 --> Security Class Initialized
DEBUG - 2019-11-05 16:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:41:20 --> CSRF cookie sent
INFO - 2019-11-05 16:41:20 --> Input Class Initialized
INFO - 2019-11-05 16:41:20 --> Language Class Initialized
INFO - 2019-11-05 16:41:20 --> Language Class Initialized
INFO - 2019-11-05 16:41:20 --> Config Class Initialized
INFO - 2019-11-05 16:41:20 --> Loader Class Initialized
INFO - 2019-11-05 16:41:20 --> Helper loaded: url_helper
INFO - 2019-11-05 16:41:20 --> Helper loaded: common_helper
INFO - 2019-11-05 16:41:20 --> Helper loaded: language_helper
INFO - 2019-11-05 16:41:21 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:41:21 --> Helper loaded: email_helper
INFO - 2019-11-05 16:41:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:41:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:41:21 --> Parser Class Initialized
INFO - 2019-11-05 16:41:21 --> User Agent Class Initialized
INFO - 2019-11-05 16:41:21 --> Model Class Initialized
INFO - 2019-11-05 16:41:21 --> Database Driver Class Initialized
INFO - 2019-11-05 16:41:21 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:21 --> Template Class Initialized
INFO - 2019-11-05 16:41:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:41:21 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:41:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:41:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:41:21 --> Encryption Class Initialized
DEBUG - 2019-11-05 16:41:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:41:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 16:41:21 --> Controller Class Initialized
DEBUG - 2019-11-05 16:41:21 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 16:41:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:41:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 16:41:21 --> Model Class Initialized
INFO - 2019-11-05 16:41:21 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:41:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 16:41:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 16:41:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 16:41:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 16:41:21 --> Final output sent to browser
DEBUG - 2019-11-05 16:41:21 --> Total execution time: 0.6674
INFO - 2019-11-05 16:41:26 --> Config Class Initialized
INFO - 2019-11-05 16:41:26 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:41:26 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:41:26 --> Utf8 Class Initialized
INFO - 2019-11-05 16:41:26 --> URI Class Initialized
INFO - 2019-11-05 16:41:26 --> Router Class Initialized
INFO - 2019-11-05 16:41:26 --> Output Class Initialized
INFO - 2019-11-05 16:41:26 --> Security Class Initialized
DEBUG - 2019-11-05 16:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:41:26 --> CSRF cookie sent
INFO - 2019-11-05 16:41:26 --> Input Class Initialized
INFO - 2019-11-05 16:41:26 --> Language Class Initialized
INFO - 2019-11-05 16:41:26 --> Language Class Initialized
INFO - 2019-11-05 16:41:26 --> Config Class Initialized
INFO - 2019-11-05 16:41:26 --> Loader Class Initialized
INFO - 2019-11-05 16:41:26 --> Helper loaded: url_helper
INFO - 2019-11-05 16:41:26 --> Helper loaded: common_helper
INFO - 2019-11-05 16:41:26 --> Helper loaded: language_helper
INFO - 2019-11-05 16:41:26 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:41:26 --> Helper loaded: email_helper
INFO - 2019-11-05 16:41:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:41:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:41:26 --> Parser Class Initialized
INFO - 2019-11-05 16:41:26 --> User Agent Class Initialized
INFO - 2019-11-05 16:41:26 --> Model Class Initialized
INFO - 2019-11-05 16:41:26 --> Database Driver Class Initialized
INFO - 2019-11-05 16:41:26 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:26 --> Template Class Initialized
INFO - 2019-11-05 16:41:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:41:26 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:41:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:41:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:41:26 --> Encryption Class Initialized
INFO - 2019-11-05 16:41:26 --> Controller Class Initialized
DEBUG - 2019-11-05 16:41:26 --> package MX_Controller Initialized
DEBUG - 2019-11-05 16:41:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-05 16:41:26 --> Model Class Initialized
INFO - 2019-11-05 16:41:26 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:41:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:41:26 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:41:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:41:26 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:41:26 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-05 16:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-05 16:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 16:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 16:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 16:41:27 --> Final output sent to browser
DEBUG - 2019-11-05 16:41:27 --> Total execution time: 0.9181
INFO - 2019-11-05 16:41:32 --> Config Class Initialized
INFO - 2019-11-05 16:41:32 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:41:32 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:41:32 --> Utf8 Class Initialized
INFO - 2019-11-05 16:41:32 --> URI Class Initialized
INFO - 2019-11-05 16:41:32 --> Router Class Initialized
INFO - 2019-11-05 16:41:32 --> Output Class Initialized
INFO - 2019-11-05 16:41:32 --> Security Class Initialized
DEBUG - 2019-11-05 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:41:32 --> CSRF cookie sent
INFO - 2019-11-05 16:41:32 --> CSRF token verified
INFO - 2019-11-05 16:41:32 --> Input Class Initialized
INFO - 2019-11-05 16:41:32 --> Language Class Initialized
INFO - 2019-11-05 16:41:32 --> Language Class Initialized
INFO - 2019-11-05 16:41:33 --> Config Class Initialized
INFO - 2019-11-05 16:41:33 --> Loader Class Initialized
INFO - 2019-11-05 16:41:33 --> Helper loaded: url_helper
INFO - 2019-11-05 16:41:33 --> Helper loaded: common_helper
INFO - 2019-11-05 16:41:33 --> Helper loaded: language_helper
INFO - 2019-11-05 16:41:33 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:41:33 --> Helper loaded: email_helper
INFO - 2019-11-05 16:41:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:41:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:41:33 --> Parser Class Initialized
INFO - 2019-11-05 16:41:33 --> User Agent Class Initialized
INFO - 2019-11-05 16:41:33 --> Model Class Initialized
INFO - 2019-11-05 16:41:33 --> Database Driver Class Initialized
INFO - 2019-11-05 16:41:33 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:33 --> Template Class Initialized
INFO - 2019-11-05 16:41:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:41:33 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:41:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:41:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:41:33 --> Encryption Class Initialized
INFO - 2019-11-05 16:41:33 --> Controller Class Initialized
DEBUG - 2019-11-05 16:41:33 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:41:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:41:33 --> Model Class Initialized
INFO - 2019-11-05 16:41:33 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 16:41:33 --> Could not find the language line "dotpay"
ERROR - 2019-11-05 16:41:33 --> Could not find the language line "paytm"
DEBUG - 2019-11-05 16:41:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-05 16:41:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:41:33 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:41:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:41:33 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:41:33 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 16:41:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 16:41:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 16:41:33 --> Final output sent to browser
DEBUG - 2019-11-05 16:41:33 --> Total execution time: 0.7216
INFO - 2019-11-05 16:41:52 --> Config Class Initialized
INFO - 2019-11-05 16:41:52 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:41:52 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:41:52 --> Utf8 Class Initialized
INFO - 2019-11-05 16:41:53 --> URI Class Initialized
INFO - 2019-11-05 16:41:53 --> Router Class Initialized
INFO - 2019-11-05 16:41:53 --> Output Class Initialized
INFO - 2019-11-05 16:41:53 --> Security Class Initialized
DEBUG - 2019-11-05 16:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:41:53 --> CSRF cookie sent
INFO - 2019-11-05 16:41:53 --> CSRF token verified
INFO - 2019-11-05 16:41:53 --> Input Class Initialized
INFO - 2019-11-05 16:41:53 --> Language Class Initialized
INFO - 2019-11-05 16:41:53 --> Language Class Initialized
INFO - 2019-11-05 16:41:53 --> Config Class Initialized
INFO - 2019-11-05 16:41:53 --> Loader Class Initialized
INFO - 2019-11-05 16:41:53 --> Helper loaded: url_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: common_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: language_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: email_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:41:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:41:53 --> Parser Class Initialized
INFO - 2019-11-05 16:41:53 --> User Agent Class Initialized
INFO - 2019-11-05 16:41:53 --> Model Class Initialized
INFO - 2019-11-05 16:41:53 --> Database Driver Class Initialized
INFO - 2019-11-05 16:41:53 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:53 --> Template Class Initialized
INFO - 2019-11-05 16:41:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:41:53 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:41:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:41:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:41:53 --> Encryption Class Initialized
INFO - 2019-11-05 16:41:53 --> Controller Class Initialized
DEBUG - 2019-11-05 16:41:53 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:41:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:41:53 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-05 16:41:53 --> Final output sent to browser
DEBUG - 2019-11-05 16:41:53 --> Total execution time: 0.5293
INFO - 2019-11-05 16:41:53 --> Config Class Initialized
INFO - 2019-11-05 16:41:53 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:41:53 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:41:53 --> Utf8 Class Initialized
INFO - 2019-11-05 16:41:53 --> URI Class Initialized
INFO - 2019-11-05 16:41:53 --> Router Class Initialized
INFO - 2019-11-05 16:41:53 --> Output Class Initialized
INFO - 2019-11-05 16:41:53 --> Security Class Initialized
DEBUG - 2019-11-05 16:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:41:53 --> Input Class Initialized
INFO - 2019-11-05 16:41:53 --> Language Class Initialized
INFO - 2019-11-05 16:41:53 --> Language Class Initialized
INFO - 2019-11-05 16:41:53 --> Config Class Initialized
INFO - 2019-11-05 16:41:53 --> Loader Class Initialized
INFO - 2019-11-05 16:41:53 --> Helper loaded: url_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: common_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: language_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: email_helper
INFO - 2019-11-05 16:41:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:41:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:41:53 --> Parser Class Initialized
INFO - 2019-11-05 16:41:53 --> User Agent Class Initialized
INFO - 2019-11-05 16:41:53 --> Model Class Initialized
INFO - 2019-11-05 16:41:53 --> Database Driver Class Initialized
INFO - 2019-11-05 16:41:53 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:53 --> Template Class Initialized
INFO - 2019-11-05 16:41:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:41:53 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:41:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:41:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:41:53 --> Encryption Class Initialized
INFO - 2019-11-05 16:41:53 --> Controller Class Initialized
DEBUG - 2019-11-05 16:41:53 --> paytm MX_Controller Initialized
INFO - 2019-11-05 16:41:53 --> Model Class Initialized
DEBUG - 2019-11-05 16:41:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 16:41:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
ERROR - 2019-11-05 16:41:54 --> Could not find the language line "paytm_confirmation"
ERROR - 2019-11-05 16:41:54 --> Severity: Notice --> Undefined variable: module D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 11
ERROR - 2019-11-05 16:41:54 --> Could not find the language line "total_amount_XX_includes_fee"
ERROR - 2019-11-05 16:41:54 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 15
ERROR - 2019-11-05 16:41:54 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 16
ERROR - 2019-11-05 16:41:54 --> Could not find the language line "the_system_will_convert_automatically_from_INR_to_USD_and_add_funds_to_your_blance_when_payment_is_made"
DEBUG - 2019-11-05 16:41:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-05 16:41:54 --> Final output sent to browser
DEBUG - 2019-11-05 16:41:54 --> Total execution time: 0.5860
INFO - 2019-11-05 16:42:13 --> Config Class Initialized
INFO - 2019-11-05 16:42:13 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:42:13 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:42:13 --> Utf8 Class Initialized
INFO - 2019-11-05 16:42:13 --> URI Class Initialized
INFO - 2019-11-05 16:42:13 --> Router Class Initialized
INFO - 2019-11-05 16:42:13 --> Output Class Initialized
INFO - 2019-11-05 16:42:13 --> Security Class Initialized
DEBUG - 2019-11-05 16:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:42:13 --> CSRF cookie sent
INFO - 2019-11-05 16:42:13 --> CSRF token verified
INFO - 2019-11-05 16:42:13 --> Input Class Initialized
INFO - 2019-11-05 16:42:13 --> Language Class Initialized
INFO - 2019-11-05 16:42:13 --> Language Class Initialized
INFO - 2019-11-05 16:42:13 --> Config Class Initialized
INFO - 2019-11-05 16:42:13 --> Loader Class Initialized
INFO - 2019-11-05 16:42:13 --> Helper loaded: url_helper
INFO - 2019-11-05 16:42:13 --> Helper loaded: common_helper
INFO - 2019-11-05 16:42:13 --> Helper loaded: language_helper
INFO - 2019-11-05 16:42:13 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:42:13 --> Helper loaded: email_helper
INFO - 2019-11-05 16:42:13 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:42:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:42:13 --> Parser Class Initialized
INFO - 2019-11-05 16:42:13 --> User Agent Class Initialized
INFO - 2019-11-05 16:42:13 --> Model Class Initialized
INFO - 2019-11-05 16:42:13 --> Database Driver Class Initialized
INFO - 2019-11-05 16:42:13 --> Model Class Initialized
DEBUG - 2019-11-05 16:42:13 --> Template Class Initialized
INFO - 2019-11-05 16:42:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:42:13 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:42:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:42:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:42:13 --> Encryption Class Initialized
INFO - 2019-11-05 16:42:13 --> Controller Class Initialized
DEBUG - 2019-11-05 16:42:13 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:42:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:42:13 --> Model Class Initialized
INFO - 2019-11-05 16:42:13 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 16:42:13 --> Could not find the language line "dotpay"
ERROR - 2019-11-05 16:42:13 --> Could not find the language line "paytm"
DEBUG - 2019-11-05 16:42:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-05 16:42:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:42:13 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:42:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:42:13 --> Model Class Initialized
DEBUG - 2019-11-05 16:42:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:42:13 --> Model Class Initialized
DEBUG - 2019-11-05 16:42:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 16:42:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 16:42:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 16:42:13 --> Final output sent to browser
DEBUG - 2019-11-05 16:42:14 --> Total execution time: 0.7579
INFO - 2019-11-05 16:42:35 --> Config Class Initialized
INFO - 2019-11-05 16:42:35 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:42:35 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:42:35 --> Utf8 Class Initialized
INFO - 2019-11-05 16:42:35 --> URI Class Initialized
INFO - 2019-11-05 16:42:35 --> Router Class Initialized
INFO - 2019-11-05 16:42:35 --> Output Class Initialized
INFO - 2019-11-05 16:42:35 --> Security Class Initialized
DEBUG - 2019-11-05 16:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:42:35 --> CSRF cookie sent
INFO - 2019-11-05 16:42:35 --> CSRF token verified
INFO - 2019-11-05 16:42:35 --> Input Class Initialized
INFO - 2019-11-05 16:42:35 --> Language Class Initialized
INFO - 2019-11-05 16:42:35 --> Language Class Initialized
INFO - 2019-11-05 16:42:35 --> Config Class Initialized
INFO - 2019-11-05 16:42:35 --> Loader Class Initialized
INFO - 2019-11-05 16:42:35 --> Helper loaded: url_helper
INFO - 2019-11-05 16:42:35 --> Helper loaded: common_helper
INFO - 2019-11-05 16:42:35 --> Helper loaded: language_helper
INFO - 2019-11-05 16:42:35 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:42:35 --> Helper loaded: email_helper
INFO - 2019-11-05 16:42:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:42:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:42:35 --> Parser Class Initialized
INFO - 2019-11-05 16:42:35 --> User Agent Class Initialized
INFO - 2019-11-05 16:42:35 --> Model Class Initialized
INFO - 2019-11-05 16:42:35 --> Database Driver Class Initialized
INFO - 2019-11-05 16:42:35 --> Model Class Initialized
DEBUG - 2019-11-05 16:42:35 --> Template Class Initialized
INFO - 2019-11-05 16:42:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:42:35 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:42:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:42:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:42:36 --> Encryption Class Initialized
INFO - 2019-11-05 16:42:36 --> Controller Class Initialized
DEBUG - 2019-11-05 16:42:36 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:42:36 --> Model Class Initialized
DEBUG - 2019-11-05 16:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-05 16:42:36 --> Final output sent to browser
DEBUG - 2019-11-05 16:42:36 --> Total execution time: 0.5229
INFO - 2019-11-05 16:42:36 --> Config Class Initialized
INFO - 2019-11-05 16:42:36 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:42:36 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:42:36 --> Utf8 Class Initialized
INFO - 2019-11-05 16:42:36 --> URI Class Initialized
INFO - 2019-11-05 16:42:36 --> Router Class Initialized
INFO - 2019-11-05 16:42:36 --> Output Class Initialized
INFO - 2019-11-05 16:42:36 --> Security Class Initialized
DEBUG - 2019-11-05 16:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:42:36 --> Input Class Initialized
INFO - 2019-11-05 16:42:36 --> Language Class Initialized
INFO - 2019-11-05 16:42:36 --> Language Class Initialized
INFO - 2019-11-05 16:42:36 --> Config Class Initialized
INFO - 2019-11-05 16:42:36 --> Loader Class Initialized
INFO - 2019-11-05 16:42:36 --> Helper loaded: url_helper
INFO - 2019-11-05 16:42:36 --> Helper loaded: common_helper
INFO - 2019-11-05 16:42:36 --> Helper loaded: language_helper
INFO - 2019-11-05 16:42:36 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:42:36 --> Helper loaded: email_helper
INFO - 2019-11-05 16:42:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:42:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:42:36 --> Parser Class Initialized
INFO - 2019-11-05 16:42:36 --> User Agent Class Initialized
INFO - 2019-11-05 16:42:36 --> Model Class Initialized
INFO - 2019-11-05 16:42:36 --> Database Driver Class Initialized
INFO - 2019-11-05 16:42:36 --> Model Class Initialized
DEBUG - 2019-11-05 16:42:36 --> Template Class Initialized
INFO - 2019-11-05 16:42:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:42:36 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:42:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:42:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:42:36 --> Encryption Class Initialized
INFO - 2019-11-05 16:42:36 --> Controller Class Initialized
DEBUG - 2019-11-05 16:42:36 --> paytm MX_Controller Initialized
INFO - 2019-11-05 16:42:36 --> Model Class Initialized
DEBUG - 2019-11-05 16:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 16:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
ERROR - 2019-11-05 16:42:36 --> Could not find the language line "paytm_confirmation"
ERROR - 2019-11-05 16:42:36 --> Severity: Notice --> Undefined variable: module D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 11
ERROR - 2019-11-05 16:42:36 --> Could not find the language line "total_amount_XX_includes_fee"
ERROR - 2019-11-05 16:42:36 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 15
ERROR - 2019-11-05 16:42:36 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 16
ERROR - 2019-11-05 16:42:36 --> Could not find the language line "the_system_will_convert_automatically_from_INR_to_USD_and_add_funds_to_your_blance_when_payment_is_made"
DEBUG - 2019-11-05 16:42:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-05 16:42:36 --> Final output sent to browser
DEBUG - 2019-11-05 16:42:36 --> Total execution time: 0.5994
INFO - 2019-11-05 16:42:57 --> Config Class Initialized
INFO - 2019-11-05 16:42:57 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:42:57 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:42:57 --> Utf8 Class Initialized
INFO - 2019-11-05 16:42:57 --> URI Class Initialized
DEBUG - 2019-11-05 16:42:57 --> No URI present. Default controller set.
INFO - 2019-11-05 16:42:57 --> Router Class Initialized
INFO - 2019-11-05 16:42:57 --> Output Class Initialized
INFO - 2019-11-05 16:42:57 --> Security Class Initialized
DEBUG - 2019-11-05 16:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:42:57 --> CSRF cookie sent
INFO - 2019-11-05 16:42:57 --> Input Class Initialized
INFO - 2019-11-05 16:42:57 --> Language Class Initialized
INFO - 2019-11-05 16:42:57 --> Language Class Initialized
INFO - 2019-11-05 16:42:57 --> Config Class Initialized
INFO - 2019-11-05 16:42:57 --> Loader Class Initialized
INFO - 2019-11-05 16:42:57 --> Helper loaded: url_helper
INFO - 2019-11-05 16:42:57 --> Helper loaded: common_helper
INFO - 2019-11-05 16:42:57 --> Helper loaded: language_helper
INFO - 2019-11-05 16:42:57 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:42:57 --> Helper loaded: email_helper
INFO - 2019-11-05 16:42:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:42:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:42:57 --> Parser Class Initialized
INFO - 2019-11-05 16:42:57 --> User Agent Class Initialized
INFO - 2019-11-05 16:42:57 --> Model Class Initialized
INFO - 2019-11-05 16:42:57 --> Database Driver Class Initialized
INFO - 2019-11-05 16:42:57 --> Model Class Initialized
DEBUG - 2019-11-05 16:42:57 --> Template Class Initialized
INFO - 2019-11-05 16:42:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:42:57 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:42:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:42:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:42:57 --> Encryption Class Initialized
DEBUG - 2019-11-05 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 16:42:57 --> Controller Class Initialized
DEBUG - 2019-11-05 16:42:57 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 16:42:57 --> Model Class Initialized
INFO - 2019-11-05 16:42:57 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 16:42:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 16:42:57 --> Final output sent to browser
DEBUG - 2019-11-05 16:42:57 --> Total execution time: 0.6714
INFO - 2019-11-05 16:43:02 --> Config Class Initialized
INFO - 2019-11-05 16:43:02 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:43:02 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:43:02 --> Utf8 Class Initialized
INFO - 2019-11-05 16:43:02 --> URI Class Initialized
INFO - 2019-11-05 16:43:02 --> Router Class Initialized
INFO - 2019-11-05 16:43:02 --> Output Class Initialized
INFO - 2019-11-05 16:43:02 --> Security Class Initialized
DEBUG - 2019-11-05 16:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:43:02 --> CSRF cookie sent
INFO - 2019-11-05 16:43:02 --> Input Class Initialized
INFO - 2019-11-05 16:43:03 --> Language Class Initialized
INFO - 2019-11-05 16:43:03 --> Language Class Initialized
INFO - 2019-11-05 16:43:03 --> Config Class Initialized
INFO - 2019-11-05 16:43:03 --> Loader Class Initialized
INFO - 2019-11-05 16:43:03 --> Helper loaded: url_helper
INFO - 2019-11-05 16:43:03 --> Helper loaded: common_helper
INFO - 2019-11-05 16:43:03 --> Helper loaded: language_helper
INFO - 2019-11-05 16:43:03 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:43:03 --> Helper loaded: email_helper
INFO - 2019-11-05 16:43:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:43:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:43:03 --> Parser Class Initialized
INFO - 2019-11-05 16:43:03 --> User Agent Class Initialized
INFO - 2019-11-05 16:43:03 --> Model Class Initialized
INFO - 2019-11-05 16:43:03 --> Database Driver Class Initialized
INFO - 2019-11-05 16:43:03 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:03 --> Template Class Initialized
INFO - 2019-11-05 16:43:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:43:03 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:43:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:43:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:43:03 --> Encryption Class Initialized
INFO - 2019-11-05 16:43:03 --> Controller Class Initialized
DEBUG - 2019-11-05 16:43:03 --> package MX_Controller Initialized
DEBUG - 2019-11-05 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-05 16:43:03 --> Model Class Initialized
INFO - 2019-11-05 16:43:03 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:43:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:43:03 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:43:03 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-05 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-05 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 16:43:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 16:43:03 --> Final output sent to browser
DEBUG - 2019-11-05 16:43:03 --> Total execution time: 0.8687
INFO - 2019-11-05 16:43:05 --> Config Class Initialized
INFO - 2019-11-05 16:43:05 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:43:05 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:43:05 --> Utf8 Class Initialized
INFO - 2019-11-05 16:43:05 --> URI Class Initialized
INFO - 2019-11-05 16:43:05 --> Router Class Initialized
INFO - 2019-11-05 16:43:05 --> Output Class Initialized
INFO - 2019-11-05 16:43:05 --> Security Class Initialized
DEBUG - 2019-11-05 16:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:43:05 --> CSRF cookie sent
INFO - 2019-11-05 16:43:05 --> CSRF token verified
INFO - 2019-11-05 16:43:05 --> Input Class Initialized
INFO - 2019-11-05 16:43:05 --> Language Class Initialized
INFO - 2019-11-05 16:43:05 --> Language Class Initialized
INFO - 2019-11-05 16:43:05 --> Config Class Initialized
INFO - 2019-11-05 16:43:05 --> Loader Class Initialized
INFO - 2019-11-05 16:43:05 --> Helper loaded: url_helper
INFO - 2019-11-05 16:43:05 --> Helper loaded: common_helper
INFO - 2019-11-05 16:43:05 --> Helper loaded: language_helper
INFO - 2019-11-05 16:43:05 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:43:05 --> Helper loaded: email_helper
INFO - 2019-11-05 16:43:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:43:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:43:05 --> Parser Class Initialized
INFO - 2019-11-05 16:43:05 --> User Agent Class Initialized
INFO - 2019-11-05 16:43:05 --> Model Class Initialized
INFO - 2019-11-05 16:43:05 --> Database Driver Class Initialized
INFO - 2019-11-05 16:43:05 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:05 --> Template Class Initialized
INFO - 2019-11-05 16:43:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:43:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:43:05 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:43:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:43:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:43:05 --> Encryption Class Initialized
INFO - 2019-11-05 16:43:05 --> Controller Class Initialized
DEBUG - 2019-11-05 16:43:05 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:43:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:43:05 --> Model Class Initialized
INFO - 2019-11-05 16:43:05 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 16:43:05 --> Could not find the language line "dotpay"
ERROR - 2019-11-05 16:43:05 --> Could not find the language line "paytm"
DEBUG - 2019-11-05 16:43:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-05 16:43:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:43:06 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:43:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:43:06 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:43:06 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 16:43:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 16:43:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 16:43:06 --> Final output sent to browser
DEBUG - 2019-11-05 16:43:06 --> Total execution time: 0.7049
INFO - 2019-11-05 16:43:16 --> Config Class Initialized
INFO - 2019-11-05 16:43:16 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:43:16 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:43:16 --> Utf8 Class Initialized
INFO - 2019-11-05 16:43:16 --> URI Class Initialized
INFO - 2019-11-05 16:43:16 --> Router Class Initialized
INFO - 2019-11-05 16:43:16 --> Output Class Initialized
INFO - 2019-11-05 16:43:16 --> Security Class Initialized
DEBUG - 2019-11-05 16:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:43:16 --> CSRF cookie sent
INFO - 2019-11-05 16:43:16 --> CSRF token verified
INFO - 2019-11-05 16:43:16 --> Input Class Initialized
INFO - 2019-11-05 16:43:16 --> Language Class Initialized
INFO - 2019-11-05 16:43:16 --> Language Class Initialized
INFO - 2019-11-05 16:43:16 --> Config Class Initialized
INFO - 2019-11-05 16:43:16 --> Loader Class Initialized
INFO - 2019-11-05 16:43:16 --> Helper loaded: url_helper
INFO - 2019-11-05 16:43:16 --> Helper loaded: common_helper
INFO - 2019-11-05 16:43:16 --> Helper loaded: language_helper
INFO - 2019-11-05 16:43:16 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:43:16 --> Helper loaded: email_helper
INFO - 2019-11-05 16:43:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:43:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:43:16 --> Parser Class Initialized
INFO - 2019-11-05 16:43:16 --> User Agent Class Initialized
INFO - 2019-11-05 16:43:16 --> Model Class Initialized
INFO - 2019-11-05 16:43:16 --> Database Driver Class Initialized
INFO - 2019-11-05 16:43:16 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:16 --> Template Class Initialized
INFO - 2019-11-05 16:43:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:43:16 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:43:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:43:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:43:16 --> Encryption Class Initialized
INFO - 2019-11-05 16:43:16 --> Controller Class Initialized
DEBUG - 2019-11-05 16:43:16 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:43:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:43:16 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-05 16:43:17 --> Final output sent to browser
DEBUG - 2019-11-05 16:43:17 --> Total execution time: 0.5130
INFO - 2019-11-05 16:43:17 --> Config Class Initialized
INFO - 2019-11-05 16:43:17 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:43:17 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:43:17 --> Utf8 Class Initialized
INFO - 2019-11-05 16:43:17 --> URI Class Initialized
INFO - 2019-11-05 16:43:17 --> Router Class Initialized
INFO - 2019-11-05 16:43:17 --> Output Class Initialized
INFO - 2019-11-05 16:43:17 --> Security Class Initialized
DEBUG - 2019-11-05 16:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:43:17 --> Input Class Initialized
INFO - 2019-11-05 16:43:17 --> Language Class Initialized
INFO - 2019-11-05 16:43:17 --> Language Class Initialized
INFO - 2019-11-05 16:43:17 --> Config Class Initialized
INFO - 2019-11-05 16:43:17 --> Loader Class Initialized
INFO - 2019-11-05 16:43:17 --> Helper loaded: url_helper
INFO - 2019-11-05 16:43:17 --> Helper loaded: common_helper
INFO - 2019-11-05 16:43:17 --> Helper loaded: language_helper
INFO - 2019-11-05 16:43:17 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:43:17 --> Helper loaded: email_helper
INFO - 2019-11-05 16:43:17 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:43:17 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:43:17 --> Parser Class Initialized
INFO - 2019-11-05 16:43:17 --> User Agent Class Initialized
INFO - 2019-11-05 16:43:17 --> Model Class Initialized
INFO - 2019-11-05 16:43:17 --> Database Driver Class Initialized
INFO - 2019-11-05 16:43:17 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:17 --> Template Class Initialized
INFO - 2019-11-05 16:43:17 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:43:17 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:43:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:43:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:43:17 --> Encryption Class Initialized
INFO - 2019-11-05 16:43:17 --> Controller Class Initialized
DEBUG - 2019-11-05 16:43:17 --> paytm MX_Controller Initialized
INFO - 2019-11-05 16:43:17 --> Model Class Initialized
DEBUG - 2019-11-05 16:43:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 16:43:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
ERROR - 2019-11-05 16:43:17 --> Could not find the language line "paytm_confirmation"
ERROR - 2019-11-05 16:43:17 --> Severity: Notice --> Undefined variable: module D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 11
ERROR - 2019-11-05 16:43:17 --> Could not find the language line "total_amount_XX_includes_fee"
ERROR - 2019-11-05 16:43:17 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 15
ERROR - 2019-11-05 16:43:17 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 16
ERROR - 2019-11-05 16:43:17 --> Could not find the language line "the_system_will_convert_automatically_from_INR_to_USD_and_add_funds_to_your_blance_when_payment_is_made"
DEBUG - 2019-11-05 16:43:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-05 16:43:17 --> Final output sent to browser
DEBUG - 2019-11-05 16:43:17 --> Total execution time: 0.5811
INFO - 2019-11-05 16:53:35 --> Config Class Initialized
INFO - 2019-11-05 16:53:35 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:53:35 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:53:35 --> Utf8 Class Initialized
INFO - 2019-11-05 16:53:35 --> URI Class Initialized
DEBUG - 2019-11-05 16:53:35 --> No URI present. Default controller set.
INFO - 2019-11-05 16:53:36 --> Router Class Initialized
INFO - 2019-11-05 16:53:36 --> Output Class Initialized
INFO - 2019-11-05 16:53:36 --> Security Class Initialized
DEBUG - 2019-11-05 16:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:53:36 --> CSRF cookie sent
INFO - 2019-11-05 16:53:36 --> Input Class Initialized
INFO - 2019-11-05 16:53:36 --> Language Class Initialized
INFO - 2019-11-05 16:53:36 --> Language Class Initialized
INFO - 2019-11-05 16:53:36 --> Config Class Initialized
INFO - 2019-11-05 16:53:36 --> Loader Class Initialized
INFO - 2019-11-05 16:53:36 --> Helper loaded: url_helper
INFO - 2019-11-05 16:53:36 --> Helper loaded: common_helper
INFO - 2019-11-05 16:53:36 --> Helper loaded: language_helper
INFO - 2019-11-05 16:53:36 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:53:36 --> Helper loaded: email_helper
INFO - 2019-11-05 16:53:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:53:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:53:36 --> Parser Class Initialized
INFO - 2019-11-05 16:53:36 --> User Agent Class Initialized
INFO - 2019-11-05 16:53:36 --> Model Class Initialized
INFO - 2019-11-05 16:53:36 --> Database Driver Class Initialized
INFO - 2019-11-05 16:53:36 --> Model Class Initialized
DEBUG - 2019-11-05 16:53:36 --> Template Class Initialized
INFO - 2019-11-05 16:53:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:53:36 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:53:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:53:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:53:36 --> Encryption Class Initialized
DEBUG - 2019-11-05 16:53:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:53:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 16:53:36 --> Controller Class Initialized
DEBUG - 2019-11-05 16:53:36 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 16:53:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:53:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 16:53:36 --> Model Class Initialized
INFO - 2019-11-05 16:53:36 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:53:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 16:53:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 16:53:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 16:53:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 16:53:36 --> Final output sent to browser
DEBUG - 2019-11-05 16:53:36 --> Total execution time: 0.5947
INFO - 2019-11-05 16:53:46 --> Config Class Initialized
INFO - 2019-11-05 16:53:46 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:53:46 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:53:46 --> Utf8 Class Initialized
INFO - 2019-11-05 16:53:46 --> URI Class Initialized
INFO - 2019-11-05 16:53:46 --> Router Class Initialized
INFO - 2019-11-05 16:53:46 --> Output Class Initialized
INFO - 2019-11-05 16:53:46 --> Security Class Initialized
DEBUG - 2019-11-05 16:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:53:47 --> CSRF cookie sent
INFO - 2019-11-05 16:53:47 --> Input Class Initialized
INFO - 2019-11-05 16:53:47 --> Language Class Initialized
INFO - 2019-11-05 16:53:47 --> Language Class Initialized
INFO - 2019-11-05 16:53:47 --> Config Class Initialized
INFO - 2019-11-05 16:53:47 --> Loader Class Initialized
INFO - 2019-11-05 16:53:47 --> Helper loaded: url_helper
INFO - 2019-11-05 16:53:47 --> Helper loaded: common_helper
INFO - 2019-11-05 16:53:47 --> Helper loaded: language_helper
INFO - 2019-11-05 16:53:47 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:53:47 --> Helper loaded: email_helper
INFO - 2019-11-05 16:53:47 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:53:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:53:47 --> Parser Class Initialized
INFO - 2019-11-05 16:53:47 --> User Agent Class Initialized
INFO - 2019-11-05 16:53:47 --> Model Class Initialized
INFO - 2019-11-05 16:53:47 --> Database Driver Class Initialized
INFO - 2019-11-05 16:53:47 --> Model Class Initialized
DEBUG - 2019-11-05 16:53:47 --> Template Class Initialized
INFO - 2019-11-05 16:53:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:53:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:53:47 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:53:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:53:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:53:47 --> Encryption Class Initialized
INFO - 2019-11-05 16:53:47 --> Controller Class Initialized
DEBUG - 2019-11-05 16:53:47 --> package MX_Controller Initialized
DEBUG - 2019-11-05 16:53:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-05 16:53:47 --> Model Class Initialized
INFO - 2019-11-05 16:53:47 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:53:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:53:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:53:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:53:47 --> Model Class Initialized
DEBUG - 2019-11-05 16:53:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:53:47 --> Model Class Initialized
DEBUG - 2019-11-05 16:53:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-05 16:53:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-05 16:53:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 16:53:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 16:53:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 16:53:47 --> Final output sent to browser
DEBUG - 2019-11-05 16:53:47 --> Total execution time: 0.6683
INFO - 2019-11-05 16:53:51 --> Config Class Initialized
INFO - 2019-11-05 16:53:51 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:53:51 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:53:51 --> Utf8 Class Initialized
INFO - 2019-11-05 16:53:51 --> URI Class Initialized
INFO - 2019-11-05 16:53:51 --> Router Class Initialized
INFO - 2019-11-05 16:53:51 --> Output Class Initialized
INFO - 2019-11-05 16:53:51 --> Security Class Initialized
DEBUG - 2019-11-05 16:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:53:52 --> CSRF cookie sent
INFO - 2019-11-05 16:53:52 --> CSRF token verified
INFO - 2019-11-05 16:53:52 --> Input Class Initialized
INFO - 2019-11-05 16:53:52 --> Language Class Initialized
INFO - 2019-11-05 16:53:52 --> Language Class Initialized
INFO - 2019-11-05 16:53:52 --> Config Class Initialized
INFO - 2019-11-05 16:53:52 --> Loader Class Initialized
INFO - 2019-11-05 16:53:52 --> Helper loaded: url_helper
INFO - 2019-11-05 16:53:52 --> Helper loaded: common_helper
INFO - 2019-11-05 16:53:52 --> Helper loaded: language_helper
INFO - 2019-11-05 16:53:52 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:53:52 --> Helper loaded: email_helper
INFO - 2019-11-05 16:53:52 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:53:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:53:52 --> Parser Class Initialized
INFO - 2019-11-05 16:53:52 --> User Agent Class Initialized
INFO - 2019-11-05 16:53:52 --> Model Class Initialized
INFO - 2019-11-05 16:53:52 --> Database Driver Class Initialized
INFO - 2019-11-05 16:53:52 --> Model Class Initialized
DEBUG - 2019-11-05 16:53:52 --> Template Class Initialized
INFO - 2019-11-05 16:53:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:53:52 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:53:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:53:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:53:52 --> Encryption Class Initialized
INFO - 2019-11-05 16:53:52 --> Controller Class Initialized
DEBUG - 2019-11-05 16:53:52 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:53:52 --> Model Class Initialized
INFO - 2019-11-05 16:53:52 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 16:53:52 --> Could not find the language line "dotpay"
ERROR - 2019-11-05 16:53:52 --> Could not find the language line "paytm"
DEBUG - 2019-11-05 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-05 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:53:52 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:53:52 --> Model Class Initialized
DEBUG - 2019-11-05 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:53:52 --> Model Class Initialized
DEBUG - 2019-11-05 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 16:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 16:53:52 --> Final output sent to browser
DEBUG - 2019-11-05 16:53:52 --> Total execution time: 0.6764
INFO - 2019-11-05 16:54:07 --> Config Class Initialized
INFO - 2019-11-05 16:54:07 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:54:07 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:54:07 --> Utf8 Class Initialized
INFO - 2019-11-05 16:54:07 --> URI Class Initialized
INFO - 2019-11-05 16:54:07 --> Router Class Initialized
INFO - 2019-11-05 16:54:07 --> Output Class Initialized
INFO - 2019-11-05 16:54:07 --> Security Class Initialized
DEBUG - 2019-11-05 16:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:54:07 --> CSRF cookie sent
INFO - 2019-11-05 16:54:07 --> CSRF token verified
INFO - 2019-11-05 16:54:07 --> Input Class Initialized
INFO - 2019-11-05 16:54:07 --> Language Class Initialized
INFO - 2019-11-05 16:54:07 --> Language Class Initialized
INFO - 2019-11-05 16:54:07 --> Config Class Initialized
INFO - 2019-11-05 16:54:07 --> Loader Class Initialized
INFO - 2019-11-05 16:54:07 --> Helper loaded: url_helper
INFO - 2019-11-05 16:54:07 --> Helper loaded: common_helper
INFO - 2019-11-05 16:54:07 --> Helper loaded: language_helper
INFO - 2019-11-05 16:54:07 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:54:07 --> Helper loaded: email_helper
INFO - 2019-11-05 16:54:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:54:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:54:07 --> Parser Class Initialized
INFO - 2019-11-05 16:54:07 --> User Agent Class Initialized
INFO - 2019-11-05 16:54:07 --> Model Class Initialized
INFO - 2019-11-05 16:54:08 --> Database Driver Class Initialized
INFO - 2019-11-05 16:54:08 --> Model Class Initialized
DEBUG - 2019-11-05 16:54:08 --> Template Class Initialized
INFO - 2019-11-05 16:54:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:54:08 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:54:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:54:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:54:08 --> Encryption Class Initialized
INFO - 2019-11-05 16:54:08 --> Controller Class Initialized
DEBUG - 2019-11-05 16:54:08 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:54:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:54:08 --> Model Class Initialized
DEBUG - 2019-11-05 16:54:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-05 16:54:08 --> Final output sent to browser
DEBUG - 2019-11-05 16:54:08 --> Total execution time: 0.4608
INFO - 2019-11-05 16:54:08 --> Config Class Initialized
INFO - 2019-11-05 16:54:08 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:54:08 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:54:08 --> Utf8 Class Initialized
INFO - 2019-11-05 16:54:08 --> URI Class Initialized
INFO - 2019-11-05 16:54:08 --> Router Class Initialized
INFO - 2019-11-05 16:54:08 --> Output Class Initialized
INFO - 2019-11-05 16:54:08 --> Security Class Initialized
DEBUG - 2019-11-05 16:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:54:08 --> Input Class Initialized
INFO - 2019-11-05 16:54:08 --> Language Class Initialized
INFO - 2019-11-05 16:54:08 --> Language Class Initialized
INFO - 2019-11-05 16:54:08 --> Config Class Initialized
INFO - 2019-11-05 16:54:08 --> Loader Class Initialized
INFO - 2019-11-05 16:54:08 --> Helper loaded: url_helper
INFO - 2019-11-05 16:54:08 --> Helper loaded: common_helper
INFO - 2019-11-05 16:54:08 --> Helper loaded: language_helper
INFO - 2019-11-05 16:54:08 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:54:08 --> Helper loaded: email_helper
INFO - 2019-11-05 16:54:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:54:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:54:08 --> Parser Class Initialized
INFO - 2019-11-05 16:54:08 --> User Agent Class Initialized
INFO - 2019-11-05 16:54:08 --> Model Class Initialized
INFO - 2019-11-05 16:54:08 --> Database Driver Class Initialized
INFO - 2019-11-05 16:54:08 --> Model Class Initialized
DEBUG - 2019-11-05 16:54:08 --> Template Class Initialized
INFO - 2019-11-05 16:54:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:54:08 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:54:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:54:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:54:08 --> Encryption Class Initialized
INFO - 2019-11-05 16:54:08 --> Controller Class Initialized
DEBUG - 2019-11-05 16:54:08 --> paytm MX_Controller Initialized
INFO - 2019-11-05 16:54:08 --> Config Class Initialized
INFO - 2019-11-05 16:54:08 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:54:08 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:54:08 --> Utf8 Class Initialized
INFO - 2019-11-05 16:54:08 --> URI Class Initialized
DEBUG - 2019-11-05 16:54:08 --> No URI present. Default controller set.
INFO - 2019-11-05 16:54:09 --> Router Class Initialized
INFO - 2019-11-05 16:54:09 --> Output Class Initialized
INFO - 2019-11-05 16:54:09 --> Security Class Initialized
DEBUG - 2019-11-05 16:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:54:09 --> CSRF cookie sent
INFO - 2019-11-05 16:54:09 --> Input Class Initialized
INFO - 2019-11-05 16:54:09 --> Language Class Initialized
INFO - 2019-11-05 16:54:09 --> Language Class Initialized
INFO - 2019-11-05 16:54:09 --> Config Class Initialized
INFO - 2019-11-05 16:54:09 --> Loader Class Initialized
INFO - 2019-11-05 16:54:09 --> Helper loaded: url_helper
INFO - 2019-11-05 16:54:09 --> Helper loaded: common_helper
INFO - 2019-11-05 16:54:09 --> Helper loaded: language_helper
INFO - 2019-11-05 16:54:09 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:54:09 --> Helper loaded: email_helper
INFO - 2019-11-05 16:54:09 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:54:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:54:09 --> Parser Class Initialized
INFO - 2019-11-05 16:54:09 --> User Agent Class Initialized
INFO - 2019-11-05 16:54:09 --> Model Class Initialized
INFO - 2019-11-05 16:54:09 --> Database Driver Class Initialized
INFO - 2019-11-05 16:54:09 --> Model Class Initialized
DEBUG - 2019-11-05 16:54:09 --> Template Class Initialized
INFO - 2019-11-05 16:54:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:54:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:54:09 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:54:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:54:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:54:09 --> Encryption Class Initialized
DEBUG - 2019-11-05 16:54:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:54:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 16:54:09 --> Controller Class Initialized
DEBUG - 2019-11-05 16:54:09 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 16:54:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:54:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 16:54:09 --> Model Class Initialized
INFO - 2019-11-05 16:54:09 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:54:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 16:54:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 16:54:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 16:54:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 16:54:09 --> Final output sent to browser
DEBUG - 2019-11-05 16:54:09 --> Total execution time: 0.6062
INFO - 2019-11-05 16:55:07 --> Config Class Initialized
INFO - 2019-11-05 16:55:07 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:55:07 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:55:07 --> Utf8 Class Initialized
INFO - 2019-11-05 16:55:07 --> URI Class Initialized
INFO - 2019-11-05 16:55:07 --> Router Class Initialized
INFO - 2019-11-05 16:55:07 --> Output Class Initialized
INFO - 2019-11-05 16:55:07 --> Security Class Initialized
DEBUG - 2019-11-05 16:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:55:07 --> CSRF cookie sent
INFO - 2019-11-05 16:55:07 --> Input Class Initialized
INFO - 2019-11-05 16:55:07 --> Language Class Initialized
INFO - 2019-11-05 16:55:07 --> Language Class Initialized
INFO - 2019-11-05 16:55:07 --> Config Class Initialized
INFO - 2019-11-05 16:55:07 --> Loader Class Initialized
INFO - 2019-11-05 16:55:07 --> Helper loaded: url_helper
INFO - 2019-11-05 16:55:07 --> Helper loaded: common_helper
INFO - 2019-11-05 16:55:07 --> Helper loaded: language_helper
INFO - 2019-11-05 16:55:07 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:55:07 --> Helper loaded: email_helper
INFO - 2019-11-05 16:55:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:55:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:55:07 --> Parser Class Initialized
INFO - 2019-11-05 16:55:07 --> User Agent Class Initialized
INFO - 2019-11-05 16:55:07 --> Model Class Initialized
INFO - 2019-11-05 16:55:07 --> Database Driver Class Initialized
INFO - 2019-11-05 16:55:07 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:07 --> Template Class Initialized
INFO - 2019-11-05 16:55:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:55:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:55:08 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:55:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:55:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:55:08 --> Encryption Class Initialized
INFO - 2019-11-05 16:55:08 --> Controller Class Initialized
DEBUG - 2019-11-05 16:55:08 --> package MX_Controller Initialized
DEBUG - 2019-11-05 16:55:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-05 16:55:08 --> Model Class Initialized
INFO - 2019-11-05 16:55:08 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:55:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:55:08 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:55:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:55:08 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:55:08 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-05 16:55:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-05 16:55:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 16:55:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 16:55:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 16:55:08 --> Final output sent to browser
DEBUG - 2019-11-05 16:55:08 --> Total execution time: 0.6668
INFO - 2019-11-05 16:55:14 --> Config Class Initialized
INFO - 2019-11-05 16:55:14 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:55:14 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:55:14 --> Utf8 Class Initialized
INFO - 2019-11-05 16:55:14 --> URI Class Initialized
INFO - 2019-11-05 16:55:14 --> Router Class Initialized
INFO - 2019-11-05 16:55:14 --> Output Class Initialized
INFO - 2019-11-05 16:55:14 --> Security Class Initialized
DEBUG - 2019-11-05 16:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:55:14 --> CSRF cookie sent
INFO - 2019-11-05 16:55:14 --> CSRF token verified
INFO - 2019-11-05 16:55:14 --> Input Class Initialized
INFO - 2019-11-05 16:55:14 --> Language Class Initialized
INFO - 2019-11-05 16:55:14 --> Language Class Initialized
INFO - 2019-11-05 16:55:14 --> Config Class Initialized
INFO - 2019-11-05 16:55:14 --> Loader Class Initialized
INFO - 2019-11-05 16:55:14 --> Helper loaded: url_helper
INFO - 2019-11-05 16:55:14 --> Helper loaded: common_helper
INFO - 2019-11-05 16:55:14 --> Helper loaded: language_helper
INFO - 2019-11-05 16:55:14 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:55:14 --> Helper loaded: email_helper
INFO - 2019-11-05 16:55:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:55:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:55:14 --> Parser Class Initialized
INFO - 2019-11-05 16:55:14 --> User Agent Class Initialized
INFO - 2019-11-05 16:55:14 --> Model Class Initialized
INFO - 2019-11-05 16:55:14 --> Database Driver Class Initialized
INFO - 2019-11-05 16:55:14 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:14 --> Template Class Initialized
INFO - 2019-11-05 16:55:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:55:15 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:55:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:55:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:55:15 --> Encryption Class Initialized
INFO - 2019-11-05 16:55:15 --> Controller Class Initialized
DEBUG - 2019-11-05 16:55:15 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:55:15 --> Model Class Initialized
INFO - 2019-11-05 16:55:15 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 16:55:15 --> Could not find the language line "dotpay"
ERROR - 2019-11-05 16:55:15 --> Could not find the language line "paytm"
DEBUG - 2019-11-05 16:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-05 16:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 16:55:15 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 16:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 16:55:15 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 16:55:15 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 16:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 16:55:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 16:55:15 --> Final output sent to browser
DEBUG - 2019-11-05 16:55:15 --> Total execution time: 0.6714
INFO - 2019-11-05 16:55:31 --> Config Class Initialized
INFO - 2019-11-05 16:55:31 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:55:31 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:55:31 --> Utf8 Class Initialized
INFO - 2019-11-05 16:55:31 --> URI Class Initialized
INFO - 2019-11-05 16:55:31 --> Router Class Initialized
INFO - 2019-11-05 16:55:31 --> Output Class Initialized
INFO - 2019-11-05 16:55:31 --> Security Class Initialized
DEBUG - 2019-11-05 16:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:55:31 --> CSRF cookie sent
INFO - 2019-11-05 16:55:31 --> CSRF token verified
INFO - 2019-11-05 16:55:31 --> Input Class Initialized
INFO - 2019-11-05 16:55:31 --> Language Class Initialized
INFO - 2019-11-05 16:55:31 --> Language Class Initialized
INFO - 2019-11-05 16:55:31 --> Config Class Initialized
INFO - 2019-11-05 16:55:31 --> Loader Class Initialized
INFO - 2019-11-05 16:55:31 --> Helper loaded: url_helper
INFO - 2019-11-05 16:55:31 --> Helper loaded: common_helper
INFO - 2019-11-05 16:55:31 --> Helper loaded: language_helper
INFO - 2019-11-05 16:55:31 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:55:31 --> Helper loaded: email_helper
INFO - 2019-11-05 16:55:31 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:55:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:55:31 --> Parser Class Initialized
INFO - 2019-11-05 16:55:31 --> User Agent Class Initialized
INFO - 2019-11-05 16:55:31 --> Model Class Initialized
INFO - 2019-11-05 16:55:31 --> Database Driver Class Initialized
INFO - 2019-11-05 16:55:31 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:31 --> Template Class Initialized
INFO - 2019-11-05 16:55:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:55:31 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:55:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:55:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:55:31 --> Encryption Class Initialized
INFO - 2019-11-05 16:55:31 --> Controller Class Initialized
DEBUG - 2019-11-05 16:55:31 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:55:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:55:31 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-05 16:55:32 --> Final output sent to browser
DEBUG - 2019-11-05 16:55:32 --> Total execution time: 0.5340
INFO - 2019-11-05 16:55:32 --> Config Class Initialized
INFO - 2019-11-05 16:55:32 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:55:32 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:55:32 --> Utf8 Class Initialized
INFO - 2019-11-05 16:55:32 --> URI Class Initialized
INFO - 2019-11-05 16:55:32 --> Router Class Initialized
INFO - 2019-11-05 16:55:32 --> Output Class Initialized
INFO - 2019-11-05 16:55:32 --> Security Class Initialized
DEBUG - 2019-11-05 16:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:55:32 --> Input Class Initialized
INFO - 2019-11-05 16:55:32 --> Language Class Initialized
INFO - 2019-11-05 16:55:32 --> Language Class Initialized
INFO - 2019-11-05 16:55:32 --> Config Class Initialized
INFO - 2019-11-05 16:55:32 --> Loader Class Initialized
INFO - 2019-11-05 16:55:32 --> Helper loaded: url_helper
INFO - 2019-11-05 16:55:32 --> Helper loaded: common_helper
INFO - 2019-11-05 16:55:32 --> Helper loaded: language_helper
INFO - 2019-11-05 16:55:32 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:55:32 --> Helper loaded: email_helper
INFO - 2019-11-05 16:55:32 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:55:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:55:32 --> Parser Class Initialized
INFO - 2019-11-05 16:55:32 --> User Agent Class Initialized
INFO - 2019-11-05 16:55:32 --> Model Class Initialized
INFO - 2019-11-05 16:55:32 --> Database Driver Class Initialized
INFO - 2019-11-05 16:55:32 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:32 --> Template Class Initialized
INFO - 2019-11-05 16:55:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:55:32 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:55:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:55:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:55:32 --> Encryption Class Initialized
INFO - 2019-11-05 16:55:32 --> Controller Class Initialized
DEBUG - 2019-11-05 16:55:32 --> paytm MX_Controller Initialized
INFO - 2019-11-05 16:55:32 --> Config Class Initialized
INFO - 2019-11-05 16:55:32 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:55:32 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:55:32 --> Utf8 Class Initialized
INFO - 2019-11-05 16:55:32 --> URI Class Initialized
DEBUG - 2019-11-05 16:55:32 --> No URI present. Default controller set.
INFO - 2019-11-05 16:55:32 --> Router Class Initialized
INFO - 2019-11-05 16:55:32 --> Output Class Initialized
INFO - 2019-11-05 16:55:32 --> Security Class Initialized
DEBUG - 2019-11-05 16:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:55:32 --> CSRF cookie sent
INFO - 2019-11-05 16:55:32 --> Input Class Initialized
INFO - 2019-11-05 16:55:32 --> Language Class Initialized
INFO - 2019-11-05 16:55:33 --> Language Class Initialized
INFO - 2019-11-05 16:55:33 --> Config Class Initialized
INFO - 2019-11-05 16:55:33 --> Loader Class Initialized
INFO - 2019-11-05 16:55:33 --> Helper loaded: url_helper
INFO - 2019-11-05 16:55:33 --> Helper loaded: common_helper
INFO - 2019-11-05 16:55:33 --> Helper loaded: language_helper
INFO - 2019-11-05 16:55:33 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:55:33 --> Helper loaded: email_helper
INFO - 2019-11-05 16:55:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:55:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:55:33 --> Parser Class Initialized
INFO - 2019-11-05 16:55:33 --> User Agent Class Initialized
INFO - 2019-11-05 16:55:33 --> Model Class Initialized
INFO - 2019-11-05 16:55:33 --> Database Driver Class Initialized
INFO - 2019-11-05 16:55:33 --> Model Class Initialized
DEBUG - 2019-11-05 16:55:33 --> Template Class Initialized
INFO - 2019-11-05 16:55:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:55:33 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:55:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:55:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:55:33 --> Encryption Class Initialized
DEBUG - 2019-11-05 16:55:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:55:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 16:55:33 --> Controller Class Initialized
DEBUG - 2019-11-05 16:55:33 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 16:55:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 16:55:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 16:55:33 --> Model Class Initialized
INFO - 2019-11-05 16:55:33 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 16:55:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 16:55:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 16:55:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 16:55:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 16:55:33 --> Final output sent to browser
DEBUG - 2019-11-05 16:55:33 --> Total execution time: 0.8100
INFO - 2019-11-05 16:58:14 --> Config Class Initialized
INFO - 2019-11-05 16:58:14 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:58:14 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:58:14 --> Utf8 Class Initialized
INFO - 2019-11-05 16:58:14 --> URI Class Initialized
INFO - 2019-11-05 16:58:14 --> Router Class Initialized
INFO - 2019-11-05 16:58:14 --> Output Class Initialized
INFO - 2019-11-05 16:58:14 --> Security Class Initialized
DEBUG - 2019-11-05 16:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:58:14 --> CSRF cookie sent
INFO - 2019-11-05 16:58:14 --> CSRF token verified
INFO - 2019-11-05 16:58:14 --> Input Class Initialized
INFO - 2019-11-05 16:58:14 --> Language Class Initialized
INFO - 2019-11-05 16:58:14 --> Language Class Initialized
INFO - 2019-11-05 16:58:14 --> Config Class Initialized
INFO - 2019-11-05 16:58:14 --> Loader Class Initialized
INFO - 2019-11-05 16:58:14 --> Helper loaded: url_helper
INFO - 2019-11-05 16:58:14 --> Helper loaded: common_helper
INFO - 2019-11-05 16:58:14 --> Helper loaded: language_helper
INFO - 2019-11-05 16:58:14 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:58:14 --> Helper loaded: email_helper
INFO - 2019-11-05 16:58:14 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:58:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:58:14 --> Parser Class Initialized
INFO - 2019-11-05 16:58:14 --> User Agent Class Initialized
INFO - 2019-11-05 16:58:14 --> Model Class Initialized
INFO - 2019-11-05 16:58:14 --> Database Driver Class Initialized
INFO - 2019-11-05 16:58:14 --> Model Class Initialized
DEBUG - 2019-11-05 16:58:14 --> Template Class Initialized
INFO - 2019-11-05 16:58:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:58:15 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:58:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:58:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:58:15 --> Encryption Class Initialized
INFO - 2019-11-05 16:58:15 --> Controller Class Initialized
DEBUG - 2019-11-05 16:58:15 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 16:58:15 --> Model Class Initialized
DEBUG - 2019-11-05 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-05 16:58:15 --> Final output sent to browser
DEBUG - 2019-11-05 16:58:15 --> Total execution time: 0.5538
INFO - 2019-11-05 16:58:15 --> Config Class Initialized
INFO - 2019-11-05 16:58:15 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:58:15 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:58:15 --> Utf8 Class Initialized
INFO - 2019-11-05 16:58:15 --> URI Class Initialized
INFO - 2019-11-05 16:58:15 --> Router Class Initialized
INFO - 2019-11-05 16:58:15 --> Output Class Initialized
INFO - 2019-11-05 16:58:15 --> Security Class Initialized
DEBUG - 2019-11-05 16:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:58:15 --> Input Class Initialized
INFO - 2019-11-05 16:58:15 --> Language Class Initialized
INFO - 2019-11-05 16:58:15 --> Language Class Initialized
INFO - 2019-11-05 16:58:15 --> Config Class Initialized
INFO - 2019-11-05 16:58:15 --> Loader Class Initialized
INFO - 2019-11-05 16:58:15 --> Helper loaded: url_helper
INFO - 2019-11-05 16:58:15 --> Helper loaded: common_helper
INFO - 2019-11-05 16:58:15 --> Helper loaded: language_helper
INFO - 2019-11-05 16:58:15 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:58:15 --> Helper loaded: email_helper
INFO - 2019-11-05 16:58:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:58:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:58:15 --> Parser Class Initialized
INFO - 2019-11-05 16:58:15 --> User Agent Class Initialized
INFO - 2019-11-05 16:58:15 --> Model Class Initialized
INFO - 2019-11-05 16:58:15 --> Database Driver Class Initialized
INFO - 2019-11-05 16:58:15 --> Model Class Initialized
DEBUG - 2019-11-05 16:58:15 --> Template Class Initialized
INFO - 2019-11-05 16:58:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:58:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:58:15 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:58:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:58:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:58:15 --> Encryption Class Initialized
INFO - 2019-11-05 16:58:15 --> Controller Class Initialized
DEBUG - 2019-11-05 16:58:15 --> paytm MX_Controller Initialized
INFO - 2019-11-05 16:58:15 --> Model Class Initialized
DEBUG - 2019-11-05 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 16:58:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-05 16:58:25 --> Config Class Initialized
INFO - 2019-11-05 16:58:25 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:58:25 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:58:25 --> Utf8 Class Initialized
INFO - 2019-11-05 16:58:25 --> URI Class Initialized
INFO - 2019-11-05 16:58:25 --> Router Class Initialized
INFO - 2019-11-05 16:58:25 --> Output Class Initialized
INFO - 2019-11-05 16:58:25 --> Security Class Initialized
DEBUG - 2019-11-05 16:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:58:25 --> Input Class Initialized
INFO - 2019-11-05 16:58:26 --> Language Class Initialized
INFO - 2019-11-05 16:58:26 --> Language Class Initialized
INFO - 2019-11-05 16:58:26 --> Config Class Initialized
INFO - 2019-11-05 16:58:26 --> Loader Class Initialized
INFO - 2019-11-05 16:58:26 --> Helper loaded: url_helper
INFO - 2019-11-05 16:58:26 --> Helper loaded: common_helper
INFO - 2019-11-05 16:58:26 --> Helper loaded: language_helper
INFO - 2019-11-05 16:58:26 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:58:26 --> Helper loaded: email_helper
INFO - 2019-11-05 16:58:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:58:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:58:26 --> Parser Class Initialized
INFO - 2019-11-05 16:58:26 --> User Agent Class Initialized
INFO - 2019-11-05 16:58:26 --> Model Class Initialized
INFO - 2019-11-05 16:58:26 --> Database Driver Class Initialized
INFO - 2019-11-05 16:58:26 --> Model Class Initialized
DEBUG - 2019-11-05 16:58:26 --> Template Class Initialized
INFO - 2019-11-05 16:58:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:58:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:58:26 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:58:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:58:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:58:26 --> Encryption Class Initialized
INFO - 2019-11-05 16:58:26 --> Controller Class Initialized
DEBUG - 2019-11-05 16:58:26 --> paytm MX_Controller Initialized
INFO - 2019-11-05 16:58:26 --> Model Class Initialized
DEBUG - 2019-11-05 16:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 16:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
ERROR - 2019-11-05 16:58:26 --> Could not find the language line "paytm_confirmation"
ERROR - 2019-11-05 16:58:26 --> Severity: Notice --> Undefined variable: module D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 11
ERROR - 2019-11-05 16:58:26 --> Could not find the language line "total_amount_XX_includes_fee"
ERROR - 2019-11-05 16:58:26 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 15
ERROR - 2019-11-05 16:58:26 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 16
ERROR - 2019-11-05 16:58:26 --> Could not find the language line "the_system_will_convert_automatically_from_INR_to_USD_and_add_funds_to_your_blance_when_payment_is_made"
DEBUG - 2019-11-05 16:58:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-05 16:58:26 --> Final output sent to browser
DEBUG - 2019-11-05 16:58:26 --> Total execution time: 0.6434
INFO - 2019-11-05 16:59:01 --> Config Class Initialized
INFO - 2019-11-05 16:59:01 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:59:01 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:59:01 --> Utf8 Class Initialized
INFO - 2019-11-05 16:59:01 --> URI Class Initialized
INFO - 2019-11-05 16:59:01 --> Router Class Initialized
INFO - 2019-11-05 16:59:01 --> Output Class Initialized
INFO - 2019-11-05 16:59:01 --> Security Class Initialized
DEBUG - 2019-11-05 16:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:59:01 --> Input Class Initialized
INFO - 2019-11-05 16:59:01 --> Language Class Initialized
INFO - 2019-11-05 16:59:01 --> Language Class Initialized
INFO - 2019-11-05 16:59:01 --> Config Class Initialized
INFO - 2019-11-05 16:59:01 --> Loader Class Initialized
INFO - 2019-11-05 16:59:01 --> Helper loaded: url_helper
INFO - 2019-11-05 16:59:01 --> Helper loaded: common_helper
INFO - 2019-11-05 16:59:01 --> Helper loaded: language_helper
INFO - 2019-11-05 16:59:02 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:59:02 --> Helper loaded: email_helper
INFO - 2019-11-05 16:59:02 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:59:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:59:02 --> Parser Class Initialized
INFO - 2019-11-05 16:59:02 --> User Agent Class Initialized
INFO - 2019-11-05 16:59:02 --> Model Class Initialized
INFO - 2019-11-05 16:59:02 --> Database Driver Class Initialized
INFO - 2019-11-05 16:59:02 --> Model Class Initialized
DEBUG - 2019-11-05 16:59:02 --> Template Class Initialized
INFO - 2019-11-05 16:59:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:59:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:59:02 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:59:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:59:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:59:02 --> Encryption Class Initialized
INFO - 2019-11-05 16:59:02 --> Controller Class Initialized
DEBUG - 2019-11-05 16:59:02 --> paytm MX_Controller Initialized
INFO - 2019-11-05 16:59:02 --> Model Class Initialized
DEBUG - 2019-11-05 16:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 16:59:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-05 16:59:53 --> Config Class Initialized
INFO - 2019-11-05 16:59:53 --> Hooks Class Initialized
DEBUG - 2019-11-05 16:59:53 --> UTF-8 Support Enabled
INFO - 2019-11-05 16:59:53 --> Utf8 Class Initialized
INFO - 2019-11-05 16:59:53 --> URI Class Initialized
INFO - 2019-11-05 16:59:53 --> Router Class Initialized
INFO - 2019-11-05 16:59:53 --> Output Class Initialized
INFO - 2019-11-05 16:59:53 --> Security Class Initialized
DEBUG - 2019-11-05 16:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 16:59:53 --> Input Class Initialized
INFO - 2019-11-05 16:59:53 --> Language Class Initialized
INFO - 2019-11-05 16:59:53 --> Language Class Initialized
INFO - 2019-11-05 16:59:53 --> Config Class Initialized
INFO - 2019-11-05 16:59:53 --> Loader Class Initialized
INFO - 2019-11-05 16:59:53 --> Helper loaded: url_helper
INFO - 2019-11-05 16:59:53 --> Helper loaded: common_helper
INFO - 2019-11-05 16:59:53 --> Helper loaded: language_helper
INFO - 2019-11-05 16:59:53 --> Helper loaded: cookie_helper
INFO - 2019-11-05 16:59:53 --> Helper loaded: email_helper
INFO - 2019-11-05 16:59:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 16:59:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 16:59:53 --> Parser Class Initialized
INFO - 2019-11-05 16:59:53 --> User Agent Class Initialized
INFO - 2019-11-05 16:59:53 --> Model Class Initialized
INFO - 2019-11-05 16:59:53 --> Database Driver Class Initialized
INFO - 2019-11-05 16:59:53 --> Model Class Initialized
DEBUG - 2019-11-05 16:59:53 --> Template Class Initialized
INFO - 2019-11-05 16:59:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 16:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 16:59:53 --> Pagination Class Initialized
DEBUG - 2019-11-05 16:59:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 16:59:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 16:59:53 --> Encryption Class Initialized
INFO - 2019-11-05 16:59:53 --> Controller Class Initialized
DEBUG - 2019-11-05 16:59:53 --> paytm MX_Controller Initialized
INFO - 2019-11-05 16:59:53 --> Model Class Initialized
DEBUG - 2019-11-05 16:59:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 16:59:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-05 16:59:54 --> orders MX_Controller Initialized
ERROR - 2019-11-05 16:59:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 69
ERROR - 2019-11-05 16:59:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 70
ERROR - 2019-11-05 16:59:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 71
ERROR - 2019-11-05 16:59:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 73
ERROR - 2019-11-05 16:59:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 74
ERROR - 2019-11-05 16:59:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 75
ERROR - 2019-11-05 16:59:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 76
ERROR - 2019-11-05 16:59:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\core\Exceptions.php:271) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\helpers\url_helper.php 564
INFO - 2019-11-05 17:00:19 --> Config Class Initialized
INFO - 2019-11-05 17:00:19 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:00:19 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:00:19 --> Utf8 Class Initialized
INFO - 2019-11-05 17:00:19 --> URI Class Initialized
INFO - 2019-11-05 17:00:19 --> Router Class Initialized
INFO - 2019-11-05 17:00:19 --> Output Class Initialized
INFO - 2019-11-05 17:00:19 --> Security Class Initialized
DEBUG - 2019-11-05 17:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:00:19 --> Input Class Initialized
INFO - 2019-11-05 17:00:19 --> Language Class Initialized
INFO - 2019-11-05 17:00:19 --> Language Class Initialized
INFO - 2019-11-05 17:00:19 --> Config Class Initialized
INFO - 2019-11-05 17:00:19 --> Loader Class Initialized
INFO - 2019-11-05 17:00:19 --> Helper loaded: url_helper
INFO - 2019-11-05 17:00:19 --> Helper loaded: common_helper
INFO - 2019-11-05 17:00:19 --> Helper loaded: language_helper
INFO - 2019-11-05 17:00:19 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:00:19 --> Helper loaded: email_helper
INFO - 2019-11-05 17:00:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:00:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:00:19 --> Parser Class Initialized
INFO - 2019-11-05 17:00:19 --> User Agent Class Initialized
INFO - 2019-11-05 17:00:19 --> Model Class Initialized
INFO - 2019-11-05 17:00:19 --> Database Driver Class Initialized
INFO - 2019-11-05 17:00:19 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:19 --> Template Class Initialized
INFO - 2019-11-05 17:00:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:00:19 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:00:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:00:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:00:19 --> Encryption Class Initialized
INFO - 2019-11-05 17:00:19 --> Controller Class Initialized
DEBUG - 2019-11-05 17:00:19 --> paytm MX_Controller Initialized
INFO - 2019-11-05 17:00:19 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 17:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-05 17:00:19 --> orders MX_Controller Initialized
ERROR - 2019-11-05 17:00:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 69
ERROR - 2019-11-05 17:00:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 70
ERROR - 2019-11-05 17:00:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 71
ERROR - 2019-11-05 17:00:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 73
ERROR - 2019-11-05 17:00:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 74
ERROR - 2019-11-05 17:00:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 75
ERROR - 2019-11-05 17:00:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 76
ERROR - 2019-11-05 17:00:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\core\Exceptions.php:271) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\helpers\url_helper.php 564
INFO - 2019-11-05 17:00:24 --> Config Class Initialized
INFO - 2019-11-05 17:00:24 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:00:24 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:00:24 --> Utf8 Class Initialized
INFO - 2019-11-05 17:00:24 --> URI Class Initialized
INFO - 2019-11-05 17:00:24 --> Router Class Initialized
INFO - 2019-11-05 17:00:24 --> Output Class Initialized
INFO - 2019-11-05 17:00:24 --> Security Class Initialized
DEBUG - 2019-11-05 17:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:00:24 --> CSRF cookie sent
INFO - 2019-11-05 17:00:24 --> Input Class Initialized
INFO - 2019-11-05 17:00:24 --> Language Class Initialized
INFO - 2019-11-05 17:00:24 --> Language Class Initialized
INFO - 2019-11-05 17:00:24 --> Config Class Initialized
INFO - 2019-11-05 17:00:24 --> Loader Class Initialized
INFO - 2019-11-05 17:00:24 --> Helper loaded: url_helper
INFO - 2019-11-05 17:00:24 --> Helper loaded: common_helper
INFO - 2019-11-05 17:00:24 --> Helper loaded: language_helper
INFO - 2019-11-05 17:00:24 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:00:24 --> Helper loaded: email_helper
INFO - 2019-11-05 17:00:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:00:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:00:24 --> Parser Class Initialized
INFO - 2019-11-05 17:00:24 --> User Agent Class Initialized
INFO - 2019-11-05 17:00:24 --> Model Class Initialized
INFO - 2019-11-05 17:00:24 --> Database Driver Class Initialized
INFO - 2019-11-05 17:00:24 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:24 --> Template Class Initialized
INFO - 2019-11-05 17:00:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:00:24 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:00:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:00:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:00:24 --> Encryption Class Initialized
INFO - 2019-11-05 17:00:24 --> Controller Class Initialized
DEBUG - 2019-11-05 17:00:24 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 17:00:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 17:00:24 --> Model Class Initialized
INFO - 2019-11-05 17:00:24 --> Config Class Initialized
INFO - 2019-11-05 17:00:24 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:00:24 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:00:24 --> Utf8 Class Initialized
INFO - 2019-11-05 17:00:24 --> URI Class Initialized
DEBUG - 2019-11-05 17:00:24 --> No URI present. Default controller set.
INFO - 2019-11-05 17:00:25 --> Router Class Initialized
INFO - 2019-11-05 17:00:25 --> Output Class Initialized
INFO - 2019-11-05 17:00:25 --> Security Class Initialized
DEBUG - 2019-11-05 17:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:00:25 --> CSRF cookie sent
INFO - 2019-11-05 17:00:25 --> Input Class Initialized
INFO - 2019-11-05 17:00:25 --> Language Class Initialized
INFO - 2019-11-05 17:00:25 --> Language Class Initialized
INFO - 2019-11-05 17:00:25 --> Config Class Initialized
INFO - 2019-11-05 17:00:25 --> Loader Class Initialized
INFO - 2019-11-05 17:00:25 --> Helper loaded: url_helper
INFO - 2019-11-05 17:00:25 --> Helper loaded: common_helper
INFO - 2019-11-05 17:00:25 --> Helper loaded: language_helper
INFO - 2019-11-05 17:00:25 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:00:25 --> Helper loaded: email_helper
INFO - 2019-11-05 17:00:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:00:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:00:25 --> Parser Class Initialized
INFO - 2019-11-05 17:00:25 --> User Agent Class Initialized
INFO - 2019-11-05 17:00:25 --> Model Class Initialized
INFO - 2019-11-05 17:00:25 --> Database Driver Class Initialized
INFO - 2019-11-05 17:00:25 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:25 --> Template Class Initialized
INFO - 2019-11-05 17:00:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:00:25 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:00:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:00:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:00:25 --> Encryption Class Initialized
DEBUG - 2019-11-05 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 17:00:25 --> Controller Class Initialized
DEBUG - 2019-11-05 17:00:25 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 17:00:25 --> Model Class Initialized
INFO - 2019-11-05 17:00:25 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 17:00:25 --> Final output sent to browser
DEBUG - 2019-11-05 17:00:25 --> Total execution time: 0.7481
INFO - 2019-11-05 17:00:32 --> Config Class Initialized
INFO - 2019-11-05 17:00:32 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:00:32 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:00:32 --> Utf8 Class Initialized
INFO - 2019-11-05 17:00:32 --> URI Class Initialized
INFO - 2019-11-05 17:00:32 --> Router Class Initialized
INFO - 2019-11-05 17:00:32 --> Output Class Initialized
INFO - 2019-11-05 17:00:32 --> Security Class Initialized
DEBUG - 2019-11-05 17:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:00:32 --> CSRF cookie sent
INFO - 2019-11-05 17:00:32 --> Input Class Initialized
INFO - 2019-11-05 17:00:32 --> Language Class Initialized
INFO - 2019-11-05 17:00:32 --> Language Class Initialized
INFO - 2019-11-05 17:00:32 --> Config Class Initialized
INFO - 2019-11-05 17:00:32 --> Loader Class Initialized
INFO - 2019-11-05 17:00:32 --> Helper loaded: url_helper
INFO - 2019-11-05 17:00:32 --> Helper loaded: common_helper
INFO - 2019-11-05 17:00:32 --> Helper loaded: language_helper
INFO - 2019-11-05 17:00:32 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:00:32 --> Helper loaded: email_helper
INFO - 2019-11-05 17:00:32 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:00:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:00:32 --> Parser Class Initialized
INFO - 2019-11-05 17:00:32 --> User Agent Class Initialized
INFO - 2019-11-05 17:00:32 --> Model Class Initialized
INFO - 2019-11-05 17:00:32 --> Database Driver Class Initialized
INFO - 2019-11-05 17:00:32 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:32 --> Template Class Initialized
INFO - 2019-11-05 17:00:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:00:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:00:32 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:00:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:00:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:00:32 --> Encryption Class Initialized
INFO - 2019-11-05 17:00:32 --> Controller Class Initialized
DEBUG - 2019-11-05 17:00:32 --> package MX_Controller Initialized
DEBUG - 2019-11-05 17:00:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-05 17:00:32 --> Model Class Initialized
INFO - 2019-11-05 17:00:32 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:00:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:00:32 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:00:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:00:33 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:00:33 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-05 17:00:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-05 17:00:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 17:00:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 17:00:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 17:00:33 --> Final output sent to browser
DEBUG - 2019-11-05 17:00:33 --> Total execution time: 0.9380
INFO - 2019-11-05 17:00:36 --> Config Class Initialized
INFO - 2019-11-05 17:00:36 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:00:36 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:00:36 --> Utf8 Class Initialized
INFO - 2019-11-05 17:00:36 --> URI Class Initialized
INFO - 2019-11-05 17:00:36 --> Router Class Initialized
INFO - 2019-11-05 17:00:36 --> Output Class Initialized
INFO - 2019-11-05 17:00:36 --> Security Class Initialized
DEBUG - 2019-11-05 17:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:00:36 --> CSRF cookie sent
INFO - 2019-11-05 17:00:36 --> CSRF token verified
INFO - 2019-11-05 17:00:36 --> Input Class Initialized
INFO - 2019-11-05 17:00:36 --> Language Class Initialized
INFO - 2019-11-05 17:00:36 --> Language Class Initialized
INFO - 2019-11-05 17:00:36 --> Config Class Initialized
INFO - 2019-11-05 17:00:36 --> Loader Class Initialized
INFO - 2019-11-05 17:00:36 --> Helper loaded: url_helper
INFO - 2019-11-05 17:00:36 --> Helper loaded: common_helper
INFO - 2019-11-05 17:00:36 --> Helper loaded: language_helper
INFO - 2019-11-05 17:00:36 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:00:36 --> Helper loaded: email_helper
INFO - 2019-11-05 17:00:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:00:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:00:36 --> Parser Class Initialized
INFO - 2019-11-05 17:00:36 --> User Agent Class Initialized
INFO - 2019-11-05 17:00:36 --> Model Class Initialized
INFO - 2019-11-05 17:00:36 --> Database Driver Class Initialized
INFO - 2019-11-05 17:00:36 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:36 --> Template Class Initialized
INFO - 2019-11-05 17:00:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:00:36 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:00:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:00:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:00:36 --> Encryption Class Initialized
INFO - 2019-11-05 17:00:36 --> Controller Class Initialized
DEBUG - 2019-11-05 17:00:36 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 17:00:36 --> Model Class Initialized
INFO - 2019-11-05 17:00:36 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 17:00:36 --> Could not find the language line "dotpay"
ERROR - 2019-11-05 17:00:36 --> Could not find the language line "paytm"
DEBUG - 2019-11-05 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-05 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:00:36 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:00:36 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:00:36 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 17:00:36 --> Final output sent to browser
DEBUG - 2019-11-05 17:00:36 --> Total execution time: 0.8223
INFO - 2019-11-05 17:00:45 --> Config Class Initialized
INFO - 2019-11-05 17:00:45 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:00:45 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:00:45 --> Utf8 Class Initialized
INFO - 2019-11-05 17:00:45 --> URI Class Initialized
INFO - 2019-11-05 17:00:45 --> Router Class Initialized
INFO - 2019-11-05 17:00:45 --> Output Class Initialized
INFO - 2019-11-05 17:00:45 --> Security Class Initialized
DEBUG - 2019-11-05 17:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:00:45 --> CSRF cookie sent
INFO - 2019-11-05 17:00:46 --> CSRF token verified
INFO - 2019-11-05 17:00:46 --> Input Class Initialized
INFO - 2019-11-05 17:00:46 --> Language Class Initialized
INFO - 2019-11-05 17:00:46 --> Language Class Initialized
INFO - 2019-11-05 17:00:46 --> Config Class Initialized
INFO - 2019-11-05 17:00:46 --> Loader Class Initialized
INFO - 2019-11-05 17:00:46 --> Helper loaded: url_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: common_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: language_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: email_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:00:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:00:46 --> Parser Class Initialized
INFO - 2019-11-05 17:00:46 --> User Agent Class Initialized
INFO - 2019-11-05 17:00:46 --> Model Class Initialized
INFO - 2019-11-05 17:00:46 --> Database Driver Class Initialized
INFO - 2019-11-05 17:00:46 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:46 --> Template Class Initialized
INFO - 2019-11-05 17:00:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:00:46 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:00:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:00:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:00:46 --> Encryption Class Initialized
INFO - 2019-11-05 17:00:46 --> Controller Class Initialized
DEBUG - 2019-11-05 17:00:46 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 17:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 17:00:46 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-05 17:00:46 --> Final output sent to browser
DEBUG - 2019-11-05 17:00:46 --> Total execution time: 0.5758
INFO - 2019-11-05 17:00:46 --> Config Class Initialized
INFO - 2019-11-05 17:00:46 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:00:46 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:00:46 --> Utf8 Class Initialized
INFO - 2019-11-05 17:00:46 --> URI Class Initialized
INFO - 2019-11-05 17:00:46 --> Router Class Initialized
INFO - 2019-11-05 17:00:46 --> Output Class Initialized
INFO - 2019-11-05 17:00:46 --> Security Class Initialized
DEBUG - 2019-11-05 17:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:00:46 --> Input Class Initialized
INFO - 2019-11-05 17:00:46 --> Language Class Initialized
INFO - 2019-11-05 17:00:46 --> Language Class Initialized
INFO - 2019-11-05 17:00:46 --> Config Class Initialized
INFO - 2019-11-05 17:00:46 --> Loader Class Initialized
INFO - 2019-11-05 17:00:46 --> Helper loaded: url_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: common_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: language_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: email_helper
INFO - 2019-11-05 17:00:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:00:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:00:46 --> Parser Class Initialized
INFO - 2019-11-05 17:00:46 --> User Agent Class Initialized
INFO - 2019-11-05 17:00:46 --> Model Class Initialized
INFO - 2019-11-05 17:00:46 --> Database Driver Class Initialized
INFO - 2019-11-05 17:00:46 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:46 --> Template Class Initialized
INFO - 2019-11-05 17:00:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:00:46 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:00:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:00:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:00:46 --> Encryption Class Initialized
INFO - 2019-11-05 17:00:46 --> Controller Class Initialized
DEBUG - 2019-11-05 17:00:46 --> paytm MX_Controller Initialized
INFO - 2019-11-05 17:00:46 --> Model Class Initialized
DEBUG - 2019-11-05 17:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 17:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
ERROR - 2019-11-05 17:00:47 --> Could not find the language line "paytm_confirmation"
ERROR - 2019-11-05 17:00:47 --> Severity: Notice --> Undefined variable: module D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 11
ERROR - 2019-11-05 17:00:47 --> Could not find the language line "total_amount_XX_includes_fee"
ERROR - 2019-11-05 17:00:47 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 15
ERROR - 2019-11-05 17:00:47 --> Severity: Notice --> Undefined variable: amount D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\views\paytm\paytm_form.php 16
ERROR - 2019-11-05 17:00:47 --> Could not find the language line "the_system_will_convert_automatically_from_INR_to_USD_and_add_funds_to_your_blance_when_payment_is_made"
DEBUG - 2019-11-05 17:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-05 17:00:47 --> Final output sent to browser
DEBUG - 2019-11-05 17:00:47 --> Total execution time: 0.6507
INFO - 2019-11-05 17:01:07 --> Config Class Initialized
INFO - 2019-11-05 17:01:07 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:01:07 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:01:07 --> Utf8 Class Initialized
INFO - 2019-11-05 17:01:07 --> URI Class Initialized
INFO - 2019-11-05 17:01:07 --> Router Class Initialized
INFO - 2019-11-05 17:01:07 --> Output Class Initialized
INFO - 2019-11-05 17:01:07 --> Security Class Initialized
DEBUG - 2019-11-05 17:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:01:07 --> Input Class Initialized
INFO - 2019-11-05 17:01:07 --> Language Class Initialized
INFO - 2019-11-05 17:01:07 --> Language Class Initialized
INFO - 2019-11-05 17:01:07 --> Config Class Initialized
INFO - 2019-11-05 17:01:07 --> Loader Class Initialized
INFO - 2019-11-05 17:01:07 --> Helper loaded: url_helper
INFO - 2019-11-05 17:01:07 --> Helper loaded: common_helper
INFO - 2019-11-05 17:01:07 --> Helper loaded: language_helper
INFO - 2019-11-05 17:01:07 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:01:07 --> Helper loaded: email_helper
INFO - 2019-11-05 17:01:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:01:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:01:07 --> Parser Class Initialized
INFO - 2019-11-05 17:01:07 --> User Agent Class Initialized
INFO - 2019-11-05 17:01:07 --> Model Class Initialized
INFO - 2019-11-05 17:01:07 --> Database Driver Class Initialized
INFO - 2019-11-05 17:01:07 --> Model Class Initialized
DEBUG - 2019-11-05 17:01:07 --> Template Class Initialized
INFO - 2019-11-05 17:01:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:01:07 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:01:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:01:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:01:07 --> Encryption Class Initialized
INFO - 2019-11-05 17:01:07 --> Controller Class Initialized
DEBUG - 2019-11-05 17:01:07 --> paytm MX_Controller Initialized
INFO - 2019-11-05 17:01:07 --> Model Class Initialized
DEBUG - 2019-11-05 17:01:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 17:01:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-05 17:01:07 --> orders MX_Controller Initialized
ERROR - 2019-11-05 17:01:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 69
ERROR - 2019-11-05 17:01:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 70
ERROR - 2019-11-05 17:01:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 71
ERROR - 2019-11-05 17:01:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 73
ERROR - 2019-11-05 17:01:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 74
ERROR - 2019-11-05 17:01:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 75
ERROR - 2019-11-05 17:01:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\orders.php 76
ERROR - 2019-11-05 17:01:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\core\Exceptions.php:271) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\core\system\helpers\url_helper.php 564
INFO - 2019-11-05 17:01:40 --> Config Class Initialized
INFO - 2019-11-05 17:01:40 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:01:40 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:01:40 --> Utf8 Class Initialized
INFO - 2019-11-05 17:01:40 --> URI Class Initialized
INFO - 2019-11-05 17:01:40 --> Router Class Initialized
INFO - 2019-11-05 17:01:40 --> Output Class Initialized
INFO - 2019-11-05 17:01:40 --> Security Class Initialized
DEBUG - 2019-11-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:01:40 --> Input Class Initialized
INFO - 2019-11-05 17:01:40 --> Language Class Initialized
INFO - 2019-11-05 17:01:40 --> Language Class Initialized
INFO - 2019-11-05 17:01:40 --> Config Class Initialized
INFO - 2019-11-05 17:01:40 --> Loader Class Initialized
INFO - 2019-11-05 17:01:40 --> Helper loaded: url_helper
INFO - 2019-11-05 17:01:40 --> Helper loaded: common_helper
INFO - 2019-11-05 17:01:40 --> Helper loaded: language_helper
INFO - 2019-11-05 17:01:40 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:01:40 --> Helper loaded: email_helper
INFO - 2019-11-05 17:01:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:01:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:01:40 --> Parser Class Initialized
INFO - 2019-11-05 17:01:40 --> User Agent Class Initialized
INFO - 2019-11-05 17:01:40 --> Model Class Initialized
INFO - 2019-11-05 17:01:40 --> Database Driver Class Initialized
INFO - 2019-11-05 17:01:41 --> Model Class Initialized
DEBUG - 2019-11-05 17:01:41 --> Template Class Initialized
INFO - 2019-11-05 17:01:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:01:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:01:41 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:01:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:01:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:01:41 --> Encryption Class Initialized
INFO - 2019-11-05 17:01:41 --> Controller Class Initialized
DEBUG - 2019-11-05 17:01:41 --> paytm MX_Controller Initialized
INFO - 2019-11-05 17:01:41 --> Model Class Initialized
DEBUG - 2019-11-05 17:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 17:01:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
INFO - 2019-11-05 17:03:18 --> Config Class Initialized
INFO - 2019-11-05 17:03:18 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:03:18 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:03:18 --> Utf8 Class Initialized
INFO - 2019-11-05 17:03:18 --> URI Class Initialized
INFO - 2019-11-05 17:03:18 --> Router Class Initialized
INFO - 2019-11-05 17:03:18 --> Output Class Initialized
INFO - 2019-11-05 17:03:18 --> Security Class Initialized
DEBUG - 2019-11-05 17:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:03:18 --> CSRF cookie sent
INFO - 2019-11-05 17:03:18 --> Input Class Initialized
INFO - 2019-11-05 17:03:19 --> Language Class Initialized
INFO - 2019-11-05 17:03:19 --> Language Class Initialized
INFO - 2019-11-05 17:03:19 --> Config Class Initialized
INFO - 2019-11-05 17:03:19 --> Loader Class Initialized
INFO - 2019-11-05 17:03:19 --> Helper loaded: url_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: common_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: language_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: email_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:03:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:03:19 --> Parser Class Initialized
INFO - 2019-11-05 17:03:19 --> User Agent Class Initialized
INFO - 2019-11-05 17:03:19 --> Model Class Initialized
INFO - 2019-11-05 17:03:19 --> Database Driver Class Initialized
INFO - 2019-11-05 17:03:19 --> Model Class Initialized
DEBUG - 2019-11-05 17:03:19 --> Template Class Initialized
INFO - 2019-11-05 17:03:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:03:19 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:03:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:03:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:03:19 --> Encryption Class Initialized
INFO - 2019-11-05 17:03:19 --> Controller Class Initialized
DEBUG - 2019-11-05 17:03:19 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 17:03:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 17:03:19 --> Model Class Initialized
INFO - 2019-11-05 17:03:19 --> Config Class Initialized
INFO - 2019-11-05 17:03:19 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:03:19 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:03:19 --> Utf8 Class Initialized
INFO - 2019-11-05 17:03:19 --> URI Class Initialized
DEBUG - 2019-11-05 17:03:19 --> No URI present. Default controller set.
INFO - 2019-11-05 17:03:19 --> Router Class Initialized
INFO - 2019-11-05 17:03:19 --> Output Class Initialized
INFO - 2019-11-05 17:03:19 --> Security Class Initialized
DEBUG - 2019-11-05 17:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:03:19 --> CSRF cookie sent
INFO - 2019-11-05 17:03:19 --> Input Class Initialized
INFO - 2019-11-05 17:03:19 --> Language Class Initialized
INFO - 2019-11-05 17:03:19 --> Language Class Initialized
INFO - 2019-11-05 17:03:19 --> Config Class Initialized
INFO - 2019-11-05 17:03:19 --> Loader Class Initialized
INFO - 2019-11-05 17:03:19 --> Helper loaded: url_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: common_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: language_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: email_helper
INFO - 2019-11-05 17:03:19 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:03:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:03:19 --> Parser Class Initialized
INFO - 2019-11-05 17:03:19 --> User Agent Class Initialized
INFO - 2019-11-05 17:03:19 --> Model Class Initialized
INFO - 2019-11-05 17:03:19 --> Database Driver Class Initialized
INFO - 2019-11-05 17:03:19 --> Model Class Initialized
DEBUG - 2019-11-05 17:03:19 --> Template Class Initialized
INFO - 2019-11-05 17:03:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:03:19 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:03:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:03:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:03:19 --> Encryption Class Initialized
DEBUG - 2019-11-05 17:03:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:03:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 17:03:19 --> Controller Class Initialized
DEBUG - 2019-11-05 17:03:19 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 17:03:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:03:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 17:03:19 --> Model Class Initialized
INFO - 2019-11-05 17:03:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:03:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 17:03:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 17:03:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 17:03:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 17:03:20 --> Final output sent to browser
DEBUG - 2019-11-05 17:03:20 --> Total execution time: 0.7466
INFO - 2019-11-05 17:03:50 --> Config Class Initialized
INFO - 2019-11-05 17:03:50 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:03:50 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:03:50 --> Utf8 Class Initialized
INFO - 2019-11-05 17:03:50 --> URI Class Initialized
DEBUG - 2019-11-05 17:03:50 --> No URI present. Default controller set.
INFO - 2019-11-05 17:03:50 --> Router Class Initialized
INFO - 2019-11-05 17:03:50 --> Output Class Initialized
INFO - 2019-11-05 17:03:50 --> Security Class Initialized
DEBUG - 2019-11-05 17:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:03:50 --> CSRF cookie sent
INFO - 2019-11-05 17:03:50 --> Input Class Initialized
INFO - 2019-11-05 17:03:50 --> Language Class Initialized
INFO - 2019-11-05 17:03:50 --> Language Class Initialized
INFO - 2019-11-05 17:03:50 --> Config Class Initialized
INFO - 2019-11-05 17:03:50 --> Loader Class Initialized
INFO - 2019-11-05 17:03:50 --> Helper loaded: url_helper
INFO - 2019-11-05 17:03:50 --> Helper loaded: common_helper
INFO - 2019-11-05 17:03:50 --> Helper loaded: language_helper
INFO - 2019-11-05 17:03:50 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:03:50 --> Helper loaded: email_helper
INFO - 2019-11-05 17:03:50 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:03:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:03:50 --> Parser Class Initialized
INFO - 2019-11-05 17:03:50 --> User Agent Class Initialized
INFO - 2019-11-05 17:03:50 --> Model Class Initialized
INFO - 2019-11-05 17:03:50 --> Database Driver Class Initialized
INFO - 2019-11-05 17:03:51 --> Model Class Initialized
DEBUG - 2019-11-05 17:03:51 --> Template Class Initialized
INFO - 2019-11-05 17:03:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:03:51 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:03:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:03:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:03:51 --> Encryption Class Initialized
DEBUG - 2019-11-05 17:03:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:03:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 17:03:51 --> Controller Class Initialized
DEBUG - 2019-11-05 17:03:51 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 17:03:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:03:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 17:03:51 --> Model Class Initialized
INFO - 2019-11-05 17:03:51 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:03:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 17:03:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 17:03:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 17:03:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 17:03:51 --> Final output sent to browser
DEBUG - 2019-11-05 17:03:51 --> Total execution time: 0.9213
INFO - 2019-11-05 17:04:03 --> Config Class Initialized
INFO - 2019-11-05 17:04:03 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:04:03 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:04:03 --> Utf8 Class Initialized
INFO - 2019-11-05 17:04:03 --> URI Class Initialized
INFO - 2019-11-05 17:04:03 --> Router Class Initialized
INFO - 2019-11-05 17:04:03 --> Output Class Initialized
INFO - 2019-11-05 17:04:03 --> Security Class Initialized
DEBUG - 2019-11-05 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:04:03 --> CSRF cookie sent
INFO - 2019-11-05 17:04:03 --> CSRF token verified
INFO - 2019-11-05 17:04:03 --> Input Class Initialized
INFO - 2019-11-05 17:04:03 --> Language Class Initialized
INFO - 2019-11-05 17:04:03 --> Language Class Initialized
INFO - 2019-11-05 17:04:03 --> Config Class Initialized
INFO - 2019-11-05 17:04:03 --> Loader Class Initialized
INFO - 2019-11-05 17:04:03 --> Helper loaded: url_helper
INFO - 2019-11-05 17:04:03 --> Helper loaded: common_helper
INFO - 2019-11-05 17:04:03 --> Helper loaded: language_helper
INFO - 2019-11-05 17:04:03 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:04:03 --> Helper loaded: email_helper
INFO - 2019-11-05 17:04:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:04:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:04:03 --> Parser Class Initialized
INFO - 2019-11-05 17:04:03 --> User Agent Class Initialized
INFO - 2019-11-05 17:04:03 --> Model Class Initialized
INFO - 2019-11-05 17:04:03 --> Database Driver Class Initialized
INFO - 2019-11-05 17:04:03 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:03 --> Template Class Initialized
INFO - 2019-11-05 17:04:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:04:03 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:04:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:04:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:04:03 --> Encryption Class Initialized
INFO - 2019-11-05 17:04:03 --> Controller Class Initialized
DEBUG - 2019-11-05 17:04:03 --> language MX_Controller Initialized
DEBUG - 2019-11-05 17:04:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-11-05 17:04:03 --> Model Class Initialized
INFO - 2019-11-05 17:04:05 --> Config Class Initialized
INFO - 2019-11-05 17:04:05 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:04:05 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:04:05 --> Utf8 Class Initialized
INFO - 2019-11-05 17:04:05 --> URI Class Initialized
DEBUG - 2019-11-05 17:04:05 --> No URI present. Default controller set.
INFO - 2019-11-05 17:04:05 --> Router Class Initialized
INFO - 2019-11-05 17:04:05 --> Output Class Initialized
INFO - 2019-11-05 17:04:05 --> Security Class Initialized
DEBUG - 2019-11-05 17:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:04:05 --> CSRF cookie sent
INFO - 2019-11-05 17:04:05 --> Input Class Initialized
INFO - 2019-11-05 17:04:05 --> Language Class Initialized
INFO - 2019-11-05 17:04:05 --> Language Class Initialized
INFO - 2019-11-05 17:04:05 --> Config Class Initialized
INFO - 2019-11-05 17:04:05 --> Loader Class Initialized
INFO - 2019-11-05 17:04:05 --> Helper loaded: url_helper
INFO - 2019-11-05 17:04:05 --> Helper loaded: common_helper
INFO - 2019-11-05 17:04:05 --> Helper loaded: language_helper
INFO - 2019-11-05 17:04:05 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:04:05 --> Helper loaded: email_helper
INFO - 2019-11-05 17:04:05 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:04:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:04:05 --> Parser Class Initialized
INFO - 2019-11-05 17:04:05 --> User Agent Class Initialized
INFO - 2019-11-05 17:04:05 --> Model Class Initialized
INFO - 2019-11-05 17:04:05 --> Database Driver Class Initialized
INFO - 2019-11-05 17:04:05 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:05 --> Template Class Initialized
INFO - 2019-11-05 17:04:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:04:05 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:04:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:04:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:04:05 --> Encryption Class Initialized
DEBUG - 2019-11-05 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 17:04:05 --> Controller Class Initialized
DEBUG - 2019-11-05 17:04:05 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 17:04:05 --> Model Class Initialized
INFO - 2019-11-05 17:04:05 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 17:04:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 17:04:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 17:04:06 --> Final output sent to browser
DEBUG - 2019-11-05 17:04:06 --> Total execution time: 0.9950
INFO - 2019-11-05 17:04:11 --> Config Class Initialized
INFO - 2019-11-05 17:04:11 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:04:11 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:04:11 --> Utf8 Class Initialized
INFO - 2019-11-05 17:04:11 --> URI Class Initialized
INFO - 2019-11-05 17:04:11 --> Router Class Initialized
INFO - 2019-11-05 17:04:11 --> Output Class Initialized
INFO - 2019-11-05 17:04:11 --> Security Class Initialized
DEBUG - 2019-11-05 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:04:11 --> CSRF cookie sent
INFO - 2019-11-05 17:04:11 --> Input Class Initialized
INFO - 2019-11-05 17:04:11 --> Language Class Initialized
INFO - 2019-11-05 17:04:11 --> Language Class Initialized
INFO - 2019-11-05 17:04:11 --> Config Class Initialized
INFO - 2019-11-05 17:04:11 --> Loader Class Initialized
INFO - 2019-11-05 17:04:12 --> Helper loaded: url_helper
INFO - 2019-11-05 17:04:12 --> Helper loaded: common_helper
INFO - 2019-11-05 17:04:12 --> Helper loaded: language_helper
INFO - 2019-11-05 17:04:12 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:04:12 --> Helper loaded: email_helper
INFO - 2019-11-05 17:04:12 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:04:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:04:12 --> Parser Class Initialized
INFO - 2019-11-05 17:04:12 --> User Agent Class Initialized
INFO - 2019-11-05 17:04:12 --> Model Class Initialized
INFO - 2019-11-05 17:04:12 --> Database Driver Class Initialized
INFO - 2019-11-05 17:04:12 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:12 --> Template Class Initialized
INFO - 2019-11-05 17:04:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:04:12 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:04:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:04:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:04:12 --> Encryption Class Initialized
INFO - 2019-11-05 17:04:12 --> Controller Class Initialized
DEBUG - 2019-11-05 17:04:12 --> package MX_Controller Initialized
DEBUG - 2019-11-05 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-05 17:04:12 --> Model Class Initialized
INFO - 2019-11-05 17:04:12 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:04:12 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:04:12 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:04:12 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-05 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-05 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 17:04:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 17:04:12 --> Final output sent to browser
DEBUG - 2019-11-05 17:04:12 --> Total execution time: 1.0237
INFO - 2019-11-05 17:04:15 --> Config Class Initialized
INFO - 2019-11-05 17:04:15 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:04:15 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:04:15 --> Utf8 Class Initialized
INFO - 2019-11-05 17:04:15 --> URI Class Initialized
INFO - 2019-11-05 17:04:15 --> Router Class Initialized
INFO - 2019-11-05 17:04:15 --> Output Class Initialized
INFO - 2019-11-05 17:04:15 --> Security Class Initialized
DEBUG - 2019-11-05 17:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:04:15 --> CSRF cookie sent
INFO - 2019-11-05 17:04:15 --> CSRF token verified
INFO - 2019-11-05 17:04:15 --> Input Class Initialized
INFO - 2019-11-05 17:04:15 --> Language Class Initialized
INFO - 2019-11-05 17:04:15 --> Language Class Initialized
INFO - 2019-11-05 17:04:15 --> Config Class Initialized
INFO - 2019-11-05 17:04:15 --> Loader Class Initialized
INFO - 2019-11-05 17:04:15 --> Helper loaded: url_helper
INFO - 2019-11-05 17:04:15 --> Helper loaded: common_helper
INFO - 2019-11-05 17:04:15 --> Helper loaded: language_helper
INFO - 2019-11-05 17:04:15 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:04:15 --> Helper loaded: email_helper
INFO - 2019-11-05 17:04:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:04:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:04:15 --> Parser Class Initialized
INFO - 2019-11-05 17:04:15 --> User Agent Class Initialized
INFO - 2019-11-05 17:04:15 --> Model Class Initialized
INFO - 2019-11-05 17:04:15 --> Database Driver Class Initialized
INFO - 2019-11-05 17:04:15 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:15 --> Template Class Initialized
INFO - 2019-11-05 17:04:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:04:16 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:04:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:04:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:04:16 --> Encryption Class Initialized
INFO - 2019-11-05 17:04:16 --> Controller Class Initialized
DEBUG - 2019-11-05 17:04:16 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 17:04:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 17:04:16 --> Model Class Initialized
INFO - 2019-11-05 17:04:16 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 17:04:16 --> Could not find the language line "dotpay"
ERROR - 2019-11-05 17:04:16 --> Could not find the language line "paytm"
DEBUG - 2019-11-05 17:04:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-05 17:04:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:04:16 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:04:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:04:16 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:04:16 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 17:04:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 17:04:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 17:04:16 --> Final output sent to browser
DEBUG - 2019-11-05 17:04:16 --> Total execution time: 0.8781
INFO - 2019-11-05 17:04:24 --> Config Class Initialized
INFO - 2019-11-05 17:04:24 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:04:24 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:04:24 --> Utf8 Class Initialized
INFO - 2019-11-05 17:04:24 --> URI Class Initialized
INFO - 2019-11-05 17:04:24 --> Router Class Initialized
INFO - 2019-11-05 17:04:24 --> Output Class Initialized
INFO - 2019-11-05 17:04:24 --> Security Class Initialized
DEBUG - 2019-11-05 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:04:24 --> CSRF cookie sent
INFO - 2019-11-05 17:04:24 --> CSRF token verified
INFO - 2019-11-05 17:04:24 --> Input Class Initialized
INFO - 2019-11-05 17:04:24 --> Language Class Initialized
INFO - 2019-11-05 17:04:24 --> Language Class Initialized
INFO - 2019-11-05 17:04:24 --> Config Class Initialized
INFO - 2019-11-05 17:04:24 --> Loader Class Initialized
INFO - 2019-11-05 17:04:24 --> Helper loaded: url_helper
INFO - 2019-11-05 17:04:24 --> Helper loaded: common_helper
INFO - 2019-11-05 17:04:24 --> Helper loaded: language_helper
INFO - 2019-11-05 17:04:24 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:04:24 --> Helper loaded: email_helper
INFO - 2019-11-05 17:04:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:04:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:04:24 --> Parser Class Initialized
INFO - 2019-11-05 17:04:24 --> User Agent Class Initialized
INFO - 2019-11-05 17:04:24 --> Model Class Initialized
INFO - 2019-11-05 17:04:24 --> Database Driver Class Initialized
INFO - 2019-11-05 17:04:24 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:24 --> Template Class Initialized
INFO - 2019-11-05 17:04:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:04:24 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:04:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:04:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:04:24 --> Encryption Class Initialized
INFO - 2019-11-05 17:04:24 --> Controller Class Initialized
DEBUG - 2019-11-05 17:04:24 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 17:04:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 17:04:24 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/index.php
INFO - 2019-11-05 17:04:24 --> Final output sent to browser
DEBUG - 2019-11-05 17:04:24 --> Total execution time: 0.5805
INFO - 2019-11-05 17:04:24 --> Config Class Initialized
INFO - 2019-11-05 17:04:24 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:04:24 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:04:24 --> Utf8 Class Initialized
INFO - 2019-11-05 17:04:24 --> URI Class Initialized
INFO - 2019-11-05 17:04:24 --> Router Class Initialized
INFO - 2019-11-05 17:04:24 --> Output Class Initialized
INFO - 2019-11-05 17:04:25 --> Security Class Initialized
DEBUG - 2019-11-05 17:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:04:25 --> Input Class Initialized
INFO - 2019-11-05 17:04:25 --> Language Class Initialized
INFO - 2019-11-05 17:04:25 --> Language Class Initialized
INFO - 2019-11-05 17:04:25 --> Config Class Initialized
INFO - 2019-11-05 17:04:25 --> Loader Class Initialized
INFO - 2019-11-05 17:04:25 --> Helper loaded: url_helper
INFO - 2019-11-05 17:04:25 --> Helper loaded: common_helper
INFO - 2019-11-05 17:04:25 --> Helper loaded: language_helper
INFO - 2019-11-05 17:04:25 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:04:25 --> Helper loaded: email_helper
INFO - 2019-11-05 17:04:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:04:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:04:25 --> Parser Class Initialized
INFO - 2019-11-05 17:04:25 --> User Agent Class Initialized
INFO - 2019-11-05 17:04:25 --> Model Class Initialized
INFO - 2019-11-05 17:04:25 --> Database Driver Class Initialized
INFO - 2019-11-05 17:04:25 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:25 --> Template Class Initialized
INFO - 2019-11-05 17:04:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:04:25 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:04:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:04:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:04:25 --> Encryption Class Initialized
INFO - 2019-11-05 17:04:25 --> Controller Class Initialized
DEBUG - 2019-11-05 17:04:25 --> paytm MX_Controller Initialized
INFO - 2019-11-05 17:04:25 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 17:04:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-05 17:04:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-05 17:04:25 --> Final output sent to browser
DEBUG - 2019-11-05 17:04:25 --> Total execution time: 0.5860
INFO - 2019-11-05 17:04:55 --> Config Class Initialized
INFO - 2019-11-05 17:04:55 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:04:55 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:04:55 --> Utf8 Class Initialized
INFO - 2019-11-05 17:04:55 --> URI Class Initialized
INFO - 2019-11-05 17:04:55 --> Router Class Initialized
INFO - 2019-11-05 17:04:55 --> Output Class Initialized
INFO - 2019-11-05 17:04:55 --> Security Class Initialized
DEBUG - 2019-11-05 17:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:04:55 --> Input Class Initialized
INFO - 2019-11-05 17:04:55 --> Language Class Initialized
INFO - 2019-11-05 17:04:55 --> Language Class Initialized
INFO - 2019-11-05 17:04:55 --> Config Class Initialized
INFO - 2019-11-05 17:04:55 --> Loader Class Initialized
INFO - 2019-11-05 17:04:55 --> Helper loaded: url_helper
INFO - 2019-11-05 17:04:55 --> Helper loaded: common_helper
INFO - 2019-11-05 17:04:55 --> Helper loaded: language_helper
INFO - 2019-11-05 17:04:55 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:04:55 --> Helper loaded: email_helper
INFO - 2019-11-05 17:04:55 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:04:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:04:55 --> Parser Class Initialized
INFO - 2019-11-05 17:04:55 --> User Agent Class Initialized
INFO - 2019-11-05 17:04:55 --> Model Class Initialized
INFO - 2019-11-05 17:04:55 --> Database Driver Class Initialized
INFO - 2019-11-05 17:04:55 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:55 --> Template Class Initialized
INFO - 2019-11-05 17:04:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:04:55 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:04:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:04:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:04:55 --> Encryption Class Initialized
INFO - 2019-11-05 17:04:55 --> Controller Class Initialized
DEBUG - 2019-11-05 17:04:55 --> paytm MX_Controller Initialized
INFO - 2019-11-05 17:04:56 --> Model Class Initialized
DEBUG - 2019-11-05 17:04:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 17:04:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-05 17:04:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-05 17:04:56 --> Final output sent to browser
DEBUG - 2019-11-05 17:04:56 --> Total execution time: 0.6045
INFO - 2019-11-05 17:05:02 --> Config Class Initialized
INFO - 2019-11-05 17:05:02 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:05:02 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:05:02 --> Utf8 Class Initialized
INFO - 2019-11-05 17:05:02 --> URI Class Initialized
INFO - 2019-11-05 17:05:02 --> Router Class Initialized
INFO - 2019-11-05 17:05:02 --> Output Class Initialized
INFO - 2019-11-05 17:05:02 --> Security Class Initialized
DEBUG - 2019-11-05 17:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:05:02 --> Input Class Initialized
INFO - 2019-11-05 17:05:02 --> Language Class Initialized
INFO - 2019-11-05 17:05:02 --> Language Class Initialized
INFO - 2019-11-05 17:05:02 --> Config Class Initialized
INFO - 2019-11-05 17:05:02 --> Loader Class Initialized
INFO - 2019-11-05 17:05:02 --> Helper loaded: url_helper
INFO - 2019-11-05 17:05:02 --> Helper loaded: common_helper
INFO - 2019-11-05 17:05:03 --> Helper loaded: language_helper
INFO - 2019-11-05 17:05:03 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:05:03 --> Helper loaded: email_helper
INFO - 2019-11-05 17:05:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:05:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:05:03 --> Parser Class Initialized
INFO - 2019-11-05 17:05:03 --> User Agent Class Initialized
INFO - 2019-11-05 17:05:03 --> Model Class Initialized
INFO - 2019-11-05 17:05:03 --> Database Driver Class Initialized
INFO - 2019-11-05 17:05:03 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:03 --> Template Class Initialized
INFO - 2019-11-05 17:05:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:05:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:05:03 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:05:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:05:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:05:03 --> Encryption Class Initialized
INFO - 2019-11-05 17:05:03 --> Controller Class Initialized
DEBUG - 2019-11-05 17:05:03 --> paytm MX_Controller Initialized
INFO - 2019-11-05 17:05:03 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 17:05:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-05 17:05:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/paytm/paytm_form.php
INFO - 2019-11-05 17:05:03 --> Final output sent to browser
DEBUG - 2019-11-05 17:05:03 --> Total execution time: 0.5821
INFO - 2019-11-05 17:05:25 --> Config Class Initialized
INFO - 2019-11-05 17:05:25 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:05:25 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:05:25 --> Utf8 Class Initialized
INFO - 2019-11-05 17:05:25 --> URI Class Initialized
INFO - 2019-11-05 17:05:25 --> Router Class Initialized
INFO - 2019-11-05 17:05:25 --> Output Class Initialized
INFO - 2019-11-05 17:05:25 --> Security Class Initialized
DEBUG - 2019-11-05 17:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:05:25 --> Input Class Initialized
INFO - 2019-11-05 17:05:25 --> Language Class Initialized
INFO - 2019-11-05 17:05:25 --> Language Class Initialized
INFO - 2019-11-05 17:05:25 --> Config Class Initialized
INFO - 2019-11-05 17:05:25 --> Loader Class Initialized
INFO - 2019-11-05 17:05:25 --> Helper loaded: url_helper
INFO - 2019-11-05 17:05:25 --> Helper loaded: common_helper
INFO - 2019-11-05 17:05:25 --> Helper loaded: language_helper
INFO - 2019-11-05 17:05:25 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:05:25 --> Helper loaded: email_helper
INFO - 2019-11-05 17:05:25 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:05:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:05:25 --> Parser Class Initialized
INFO - 2019-11-05 17:05:25 --> User Agent Class Initialized
INFO - 2019-11-05 17:05:25 --> Model Class Initialized
INFO - 2019-11-05 17:05:25 --> Database Driver Class Initialized
INFO - 2019-11-05 17:05:25 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:25 --> Template Class Initialized
INFO - 2019-11-05 17:05:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:05:25 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:05:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:05:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:05:25 --> Encryption Class Initialized
INFO - 2019-11-05 17:05:25 --> Controller Class Initialized
DEBUG - 2019-11-05 17:05:25 --> paytm MX_Controller Initialized
INFO - 2019-11-05 17:05:26 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/paytmapi.php
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/helpers/paytm_helper.php
DEBUG - 2019-11-05 17:05:26 --> orders MX_Controller Initialized
INFO - 2019-11-05 17:05:26 --> Config Class Initialized
INFO - 2019-11-05 17:05:26 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:05:26 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:05:26 --> Utf8 Class Initialized
INFO - 2019-11-05 17:05:26 --> URI Class Initialized
INFO - 2019-11-05 17:05:26 --> Router Class Initialized
INFO - 2019-11-05 17:05:26 --> Output Class Initialized
INFO - 2019-11-05 17:05:26 --> Security Class Initialized
DEBUG - 2019-11-05 17:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:05:26 --> CSRF cookie sent
INFO - 2019-11-05 17:05:26 --> Input Class Initialized
INFO - 2019-11-05 17:05:26 --> Language Class Initialized
INFO - 2019-11-05 17:05:26 --> Language Class Initialized
INFO - 2019-11-05 17:05:26 --> Config Class Initialized
INFO - 2019-11-05 17:05:26 --> Loader Class Initialized
INFO - 2019-11-05 17:05:26 --> Helper loaded: url_helper
INFO - 2019-11-05 17:05:26 --> Helper loaded: common_helper
INFO - 2019-11-05 17:05:26 --> Helper loaded: language_helper
INFO - 2019-11-05 17:05:26 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:05:26 --> Helper loaded: email_helper
INFO - 2019-11-05 17:05:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:05:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:05:26 --> Parser Class Initialized
INFO - 2019-11-05 17:05:26 --> User Agent Class Initialized
INFO - 2019-11-05 17:05:26 --> Model Class Initialized
INFO - 2019-11-05 17:05:26 --> Database Driver Class Initialized
INFO - 2019-11-05 17:05:26 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:26 --> Template Class Initialized
INFO - 2019-11-05 17:05:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:05:26 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:05:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:05:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:05:26 --> Encryption Class Initialized
INFO - 2019-11-05 17:05:26 --> Controller Class Initialized
DEBUG - 2019-11-05 17:05:26 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 17:05:26 --> Model Class Initialized
INFO - 2019-11-05 17:05:26 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:05:26 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:05:26 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:05:26 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 17:05:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 17:05:26 --> Final output sent to browser
DEBUG - 2019-11-05 17:05:26 --> Total execution time: 0.8072
INFO - 2019-11-05 17:05:38 --> Config Class Initialized
INFO - 2019-11-05 17:05:38 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:05:38 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:05:38 --> Utf8 Class Initialized
INFO - 2019-11-05 17:05:38 --> URI Class Initialized
INFO - 2019-11-05 17:05:38 --> Router Class Initialized
INFO - 2019-11-05 17:05:38 --> Output Class Initialized
INFO - 2019-11-05 17:05:38 --> Security Class Initialized
DEBUG - 2019-11-05 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:05:38 --> CSRF cookie sent
INFO - 2019-11-05 17:05:38 --> Input Class Initialized
INFO - 2019-11-05 17:05:38 --> Language Class Initialized
INFO - 2019-11-05 17:05:38 --> Language Class Initialized
INFO - 2019-11-05 17:05:38 --> Config Class Initialized
INFO - 2019-11-05 17:05:38 --> Loader Class Initialized
INFO - 2019-11-05 17:05:38 --> Helper loaded: url_helper
INFO - 2019-11-05 17:05:38 --> Helper loaded: common_helper
INFO - 2019-11-05 17:05:38 --> Helper loaded: language_helper
INFO - 2019-11-05 17:05:38 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:05:38 --> Helper loaded: email_helper
INFO - 2019-11-05 17:05:38 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:05:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:05:38 --> Parser Class Initialized
INFO - 2019-11-05 17:05:38 --> User Agent Class Initialized
INFO - 2019-11-05 17:05:38 --> Model Class Initialized
INFO - 2019-11-05 17:05:38 --> Database Driver Class Initialized
INFO - 2019-11-05 17:05:38 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:39 --> Template Class Initialized
INFO - 2019-11-05 17:05:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:05:39 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:05:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:05:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:05:39 --> Encryption Class Initialized
INFO - 2019-11-05 17:05:39 --> Controller Class Initialized
DEBUG - 2019-11-05 17:05:39 --> order MX_Controller Initialized
DEBUG - 2019-11-05 17:05:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-05 17:05:39 --> Model Class Initialized
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "order_basic_details"
INFO - 2019-11-05 17:05:39 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "Awaiting"
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:05:39 --> Could not find the language line "Pending"
DEBUG - 2019-11-05 17:05:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-05 17:05:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:05:39 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:05:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:05:39 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:05:39 --> Model Class Initialized
DEBUG - 2019-11-05 17:05:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 17:05:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 17:05:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 17:05:39 --> Final output sent to browser
DEBUG - 2019-11-05 17:05:39 --> Total execution time: 1.1879
INFO - 2019-11-05 17:06:04 --> Config Class Initialized
INFO - 2019-11-05 17:06:04 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:04 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:04 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:04 --> URI Class Initialized
INFO - 2019-11-05 17:06:04 --> Router Class Initialized
INFO - 2019-11-05 17:06:04 --> Output Class Initialized
INFO - 2019-11-05 17:06:04 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:04 --> CSRF cookie sent
INFO - 2019-11-05 17:06:04 --> Input Class Initialized
INFO - 2019-11-05 17:06:04 --> Language Class Initialized
INFO - 2019-11-05 17:06:04 --> Language Class Initialized
INFO - 2019-11-05 17:06:04 --> Config Class Initialized
INFO - 2019-11-05 17:06:04 --> Loader Class Initialized
INFO - 2019-11-05 17:06:04 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:04 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:04 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:04 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:04 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:04 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:04 --> Parser Class Initialized
INFO - 2019-11-05 17:06:04 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:04 --> Model Class Initialized
INFO - 2019-11-05 17:06:04 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:04 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:04 --> Template Class Initialized
INFO - 2019-11-05 17:06:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:04 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:04 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:04 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:04 --> transactions MX_Controller Initialized
DEBUG - 2019-11-05 17:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-05 17:06:04 --> Model Class Initialized
ERROR - 2019-11-05 17:06:04 --> Could not find the language line "order_id"
INFO - 2019-11-05 17:06:04 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-05 17:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:06:04 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:06:04 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:06:04 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 17:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 17:06:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 17:06:04 --> Final output sent to browser
DEBUG - 2019-11-05 17:06:04 --> Total execution time: 0.8107
INFO - 2019-11-05 17:06:11 --> Config Class Initialized
INFO - 2019-11-05 17:06:11 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:11 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:11 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:11 --> URI Class Initialized
INFO - 2019-11-05 17:06:11 --> Router Class Initialized
INFO - 2019-11-05 17:06:11 --> Output Class Initialized
INFO - 2019-11-05 17:06:11 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:11 --> CSRF cookie sent
INFO - 2019-11-05 17:06:11 --> CSRF token verified
INFO - 2019-11-05 17:06:11 --> Input Class Initialized
INFO - 2019-11-05 17:06:11 --> Language Class Initialized
INFO - 2019-11-05 17:06:11 --> Language Class Initialized
INFO - 2019-11-05 17:06:11 --> Config Class Initialized
INFO - 2019-11-05 17:06:11 --> Loader Class Initialized
INFO - 2019-11-05 17:06:11 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:11 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:11 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:11 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:11 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:11 --> Parser Class Initialized
INFO - 2019-11-05 17:06:11 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:11 --> Model Class Initialized
INFO - 2019-11-05 17:06:11 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:11 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:11 --> Template Class Initialized
INFO - 2019-11-05 17:06:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:11 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:12 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:12 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:12 --> transactions MX_Controller Initialized
DEBUG - 2019-11-05 17:06:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-05 17:06:12 --> Model Class Initialized
ERROR - 2019-11-05 17:06:12 --> Could not find the language line "order_id"
INFO - 2019-11-05 17:06:15 --> Config Class Initialized
INFO - 2019-11-05 17:06:15 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:15 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:15 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:15 --> URI Class Initialized
INFO - 2019-11-05 17:06:15 --> Router Class Initialized
INFO - 2019-11-05 17:06:15 --> Output Class Initialized
INFO - 2019-11-05 17:06:15 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:15 --> CSRF cookie sent
INFO - 2019-11-05 17:06:15 --> CSRF token verified
INFO - 2019-11-05 17:06:15 --> Input Class Initialized
INFO - 2019-11-05 17:06:15 --> Language Class Initialized
INFO - 2019-11-05 17:06:15 --> Language Class Initialized
INFO - 2019-11-05 17:06:15 --> Config Class Initialized
INFO - 2019-11-05 17:06:15 --> Loader Class Initialized
INFO - 2019-11-05 17:06:15 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:15 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:15 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:15 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:15 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:15 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:16 --> Parser Class Initialized
INFO - 2019-11-05 17:06:16 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:16 --> Model Class Initialized
INFO - 2019-11-05 17:06:16 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:16 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:16 --> Template Class Initialized
INFO - 2019-11-05 17:06:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:16 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:16 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:16 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:16 --> transactions MX_Controller Initialized
DEBUG - 2019-11-05 17:06:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-05 17:06:16 --> Model Class Initialized
ERROR - 2019-11-05 17:06:16 --> Could not find the language line "order_id"
INFO - 2019-11-05 17:06:20 --> Config Class Initialized
INFO - 2019-11-05 17:06:20 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:20 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:20 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:20 --> URI Class Initialized
INFO - 2019-11-05 17:06:20 --> Router Class Initialized
INFO - 2019-11-05 17:06:20 --> Output Class Initialized
INFO - 2019-11-05 17:06:20 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:20 --> CSRF cookie sent
INFO - 2019-11-05 17:06:20 --> CSRF token verified
INFO - 2019-11-05 17:06:20 --> Input Class Initialized
INFO - 2019-11-05 17:06:20 --> Language Class Initialized
INFO - 2019-11-05 17:06:20 --> Language Class Initialized
INFO - 2019-11-05 17:06:20 --> Config Class Initialized
INFO - 2019-11-05 17:06:20 --> Loader Class Initialized
INFO - 2019-11-05 17:06:20 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:20 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:20 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:20 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:20 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:20 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:20 --> Parser Class Initialized
INFO - 2019-11-05 17:06:20 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:20 --> Model Class Initialized
INFO - 2019-11-05 17:06:20 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:20 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:20 --> Template Class Initialized
INFO - 2019-11-05 17:06:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:20 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:20 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:20 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:20 --> transactions MX_Controller Initialized
DEBUG - 2019-11-05 17:06:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-05 17:06:20 --> Model Class Initialized
ERROR - 2019-11-05 17:06:20 --> Could not find the language line "order_id"
INFO - 2019-11-05 17:06:24 --> Config Class Initialized
INFO - 2019-11-05 17:06:24 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:24 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:24 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:24 --> URI Class Initialized
INFO - 2019-11-05 17:06:24 --> Router Class Initialized
INFO - 2019-11-05 17:06:24 --> Output Class Initialized
INFO - 2019-11-05 17:06:24 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:24 --> CSRF cookie sent
INFO - 2019-11-05 17:06:24 --> Input Class Initialized
INFO - 2019-11-05 17:06:24 --> Language Class Initialized
INFO - 2019-11-05 17:06:24 --> Language Class Initialized
INFO - 2019-11-05 17:06:24 --> Config Class Initialized
INFO - 2019-11-05 17:06:24 --> Loader Class Initialized
INFO - 2019-11-05 17:06:24 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:24 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:24 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:24 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:24 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:24 --> Parser Class Initialized
INFO - 2019-11-05 17:06:24 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:24 --> Model Class Initialized
INFO - 2019-11-05 17:06:24 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:24 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:24 --> Template Class Initialized
INFO - 2019-11-05 17:06:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:24 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:24 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:24 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:24 --> transactions MX_Controller Initialized
DEBUG - 2019-11-05 17:06:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-05 17:06:24 --> Model Class Initialized
ERROR - 2019-11-05 17:06:24 --> Could not find the language line "order_id"
INFO - 2019-11-05 17:06:24 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-05 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:06:25 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:06:25 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:06:25 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 17:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 17:06:25 --> Final output sent to browser
DEBUG - 2019-11-05 17:06:25 --> Total execution time: 0.9556
INFO - 2019-11-05 17:06:26 --> Config Class Initialized
INFO - 2019-11-05 17:06:26 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:26 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:26 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:26 --> URI Class Initialized
INFO - 2019-11-05 17:06:26 --> Router Class Initialized
INFO - 2019-11-05 17:06:26 --> Output Class Initialized
INFO - 2019-11-05 17:06:26 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:26 --> CSRF cookie sent
INFO - 2019-11-05 17:06:26 --> Input Class Initialized
INFO - 2019-11-05 17:06:26 --> Language Class Initialized
INFO - 2019-11-05 17:06:26 --> Language Class Initialized
INFO - 2019-11-05 17:06:26 --> Config Class Initialized
INFO - 2019-11-05 17:06:26 --> Loader Class Initialized
INFO - 2019-11-05 17:06:26 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:26 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:26 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:26 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:26 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:27 --> Parser Class Initialized
INFO - 2019-11-05 17:06:27 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:27 --> Model Class Initialized
INFO - 2019-11-05 17:06:27 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:27 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:27 --> Template Class Initialized
INFO - 2019-11-05 17:06:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:27 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:27 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:27 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:27 --> order MX_Controller Initialized
DEBUG - 2019-11-05 17:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-05 17:06:27 --> Model Class Initialized
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "order_basic_details"
INFO - 2019-11-05 17:06:27 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "Awaiting"
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "Pending"
ERROR - 2019-11-05 17:06:27 --> Could not find the language line "Pending"
DEBUG - 2019-11-05 17:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-11-05 17:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:06:27 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:06:27 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:06:27 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 17:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 17:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 17:06:27 --> Final output sent to browser
DEBUG - 2019-11-05 17:06:27 --> Total execution time: 1.0573
INFO - 2019-11-05 17:06:34 --> Config Class Initialized
INFO - 2019-11-05 17:06:34 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:34 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:34 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:34 --> URI Class Initialized
INFO - 2019-11-05 17:06:34 --> Router Class Initialized
INFO - 2019-11-05 17:06:34 --> Output Class Initialized
INFO - 2019-11-05 17:06:34 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:34 --> CSRF cookie sent
INFO - 2019-11-05 17:06:34 --> CSRF token verified
INFO - 2019-11-05 17:06:34 --> Input Class Initialized
INFO - 2019-11-05 17:06:34 --> Language Class Initialized
INFO - 2019-11-05 17:06:34 --> Language Class Initialized
INFO - 2019-11-05 17:06:34 --> Config Class Initialized
INFO - 2019-11-05 17:06:34 --> Loader Class Initialized
INFO - 2019-11-05 17:06:34 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:34 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:34 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:34 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:34 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:34 --> Parser Class Initialized
INFO - 2019-11-05 17:06:34 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:34 --> Model Class Initialized
INFO - 2019-11-05 17:06:34 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:34 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:34 --> Template Class Initialized
INFO - 2019-11-05 17:06:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:34 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:34 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:34 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:34 --> order MX_Controller Initialized
DEBUG - 2019-11-05 17:06:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-05 17:06:34 --> Model Class Initialized
ERROR - 2019-11-05 17:06:34 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:06:34 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-05 17:06:34 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:06:34 --> Could not find the language line "order_basic_details"
INFO - 2019-11-05 17:06:38 --> Config Class Initialized
INFO - 2019-11-05 17:06:38 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:38 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:38 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:38 --> URI Class Initialized
INFO - 2019-11-05 17:06:38 --> Router Class Initialized
INFO - 2019-11-05 17:06:38 --> Output Class Initialized
INFO - 2019-11-05 17:06:38 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:38 --> CSRF cookie sent
INFO - 2019-11-05 17:06:38 --> CSRF token verified
INFO - 2019-11-05 17:06:39 --> Input Class Initialized
INFO - 2019-11-05 17:06:39 --> Language Class Initialized
INFO - 2019-11-05 17:06:39 --> Language Class Initialized
INFO - 2019-11-05 17:06:39 --> Config Class Initialized
INFO - 2019-11-05 17:06:39 --> Loader Class Initialized
INFO - 2019-11-05 17:06:39 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:39 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:39 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:39 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:39 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:39 --> Parser Class Initialized
INFO - 2019-11-05 17:06:39 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:39 --> Model Class Initialized
INFO - 2019-11-05 17:06:39 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:39 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:39 --> Template Class Initialized
INFO - 2019-11-05 17:06:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:39 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:39 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:39 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:39 --> order MX_Controller Initialized
DEBUG - 2019-11-05 17:06:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-05 17:06:39 --> Model Class Initialized
ERROR - 2019-11-05 17:06:39 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:06:39 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-05 17:06:39 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:06:39 --> Could not find the language line "order_basic_details"
INFO - 2019-11-05 17:06:43 --> Config Class Initialized
INFO - 2019-11-05 17:06:43 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:43 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:43 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:43 --> URI Class Initialized
INFO - 2019-11-05 17:06:43 --> Router Class Initialized
INFO - 2019-11-05 17:06:43 --> Output Class Initialized
INFO - 2019-11-05 17:06:43 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:43 --> CSRF cookie sent
INFO - 2019-11-05 17:06:43 --> CSRF token verified
INFO - 2019-11-05 17:06:43 --> Input Class Initialized
INFO - 2019-11-05 17:06:43 --> Language Class Initialized
INFO - 2019-11-05 17:06:43 --> Language Class Initialized
INFO - 2019-11-05 17:06:43 --> Config Class Initialized
INFO - 2019-11-05 17:06:43 --> Loader Class Initialized
INFO - 2019-11-05 17:06:43 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:43 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:44 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:44 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:44 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:44 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:44 --> Parser Class Initialized
INFO - 2019-11-05 17:06:44 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:44 --> Model Class Initialized
INFO - 2019-11-05 17:06:44 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:44 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:44 --> Template Class Initialized
INFO - 2019-11-05 17:06:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:44 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:44 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:44 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:44 --> order MX_Controller Initialized
DEBUG - 2019-11-05 17:06:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-11-05 17:06:44 --> Model Class Initialized
ERROR - 2019-11-05 17:06:44 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:06:44 --> Could not find the language line "order_basic_details"
ERROR - 2019-11-05 17:06:44 --> Could not find the language line "order_id"
ERROR - 2019-11-05 17:06:44 --> Could not find the language line "order_basic_details"
INFO - 2019-11-05 17:06:58 --> Config Class Initialized
INFO - 2019-11-05 17:06:58 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:06:58 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:06:58 --> Utf8 Class Initialized
INFO - 2019-11-05 17:06:58 --> URI Class Initialized
INFO - 2019-11-05 17:06:58 --> Router Class Initialized
INFO - 2019-11-05 17:06:58 --> Output Class Initialized
INFO - 2019-11-05 17:06:58 --> Security Class Initialized
DEBUG - 2019-11-05 17:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:06:58 --> CSRF cookie sent
INFO - 2019-11-05 17:06:58 --> Input Class Initialized
INFO - 2019-11-05 17:06:58 --> Language Class Initialized
INFO - 2019-11-05 17:06:58 --> Language Class Initialized
INFO - 2019-11-05 17:06:58 --> Config Class Initialized
INFO - 2019-11-05 17:06:58 --> Loader Class Initialized
INFO - 2019-11-05 17:06:58 --> Helper loaded: url_helper
INFO - 2019-11-05 17:06:58 --> Helper loaded: common_helper
INFO - 2019-11-05 17:06:58 --> Helper loaded: language_helper
INFO - 2019-11-05 17:06:58 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:06:58 --> Helper loaded: email_helper
INFO - 2019-11-05 17:06:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:06:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:06:58 --> Parser Class Initialized
INFO - 2019-11-05 17:06:58 --> User Agent Class Initialized
INFO - 2019-11-05 17:06:58 --> Model Class Initialized
INFO - 2019-11-05 17:06:58 --> Database Driver Class Initialized
INFO - 2019-11-05 17:06:58 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:58 --> Template Class Initialized
INFO - 2019-11-05 17:06:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:06:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:06:58 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:06:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:06:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:06:58 --> Encryption Class Initialized
INFO - 2019-11-05 17:06:58 --> Controller Class Initialized
DEBUG - 2019-11-05 17:06:58 --> transactions MX_Controller Initialized
DEBUG - 2019-11-05 17:06:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-11-05 17:06:58 --> Model Class Initialized
ERROR - 2019-11-05 17:06:58 --> Could not find the language line "order_id"
INFO - 2019-11-05 17:06:58 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:06:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-11-05 17:06:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:06:58 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:06:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:06:58 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:06:58 --> Model Class Initialized
DEBUG - 2019-11-05 17:06:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 17:06:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 17:06:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 17:06:58 --> Final output sent to browser
DEBUG - 2019-11-05 17:06:58 --> Total execution time: 0.9284
INFO - 2019-11-05 17:07:07 --> Config Class Initialized
INFO - 2019-11-05 17:07:07 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:07:07 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:07:07 --> Utf8 Class Initialized
INFO - 2019-11-05 17:07:07 --> URI Class Initialized
DEBUG - 2019-11-05 17:07:07 --> No URI present. Default controller set.
INFO - 2019-11-05 17:07:07 --> Router Class Initialized
INFO - 2019-11-05 17:07:07 --> Output Class Initialized
INFO - 2019-11-05 17:07:07 --> Security Class Initialized
DEBUG - 2019-11-05 17:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:07:07 --> CSRF cookie sent
INFO - 2019-11-05 17:07:07 --> Input Class Initialized
INFO - 2019-11-05 17:07:07 --> Language Class Initialized
INFO - 2019-11-05 17:07:07 --> Language Class Initialized
INFO - 2019-11-05 17:07:07 --> Config Class Initialized
INFO - 2019-11-05 17:07:07 --> Loader Class Initialized
INFO - 2019-11-05 17:07:07 --> Helper loaded: url_helper
INFO - 2019-11-05 17:07:07 --> Helper loaded: common_helper
INFO - 2019-11-05 17:07:07 --> Helper loaded: language_helper
INFO - 2019-11-05 17:07:07 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:07:07 --> Helper loaded: email_helper
INFO - 2019-11-05 17:07:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:07:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:07:07 --> Parser Class Initialized
INFO - 2019-11-05 17:07:07 --> User Agent Class Initialized
INFO - 2019-11-05 17:07:07 --> Model Class Initialized
INFO - 2019-11-05 17:07:07 --> Database Driver Class Initialized
INFO - 2019-11-05 17:07:07 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:07 --> Template Class Initialized
INFO - 2019-11-05 17:07:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:07:07 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:07:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:07:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:07:07 --> Encryption Class Initialized
DEBUG - 2019-11-05 17:07:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:07:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 17:07:07 --> Controller Class Initialized
DEBUG - 2019-11-05 17:07:07 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 17:07:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:07:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 17:07:07 --> Model Class Initialized
INFO - 2019-11-05 17:07:07 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:07:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 17:07:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 17:07:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 17:07:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 17:07:07 --> Final output sent to browser
DEBUG - 2019-11-05 17:07:07 --> Total execution time: 0.7224
INFO - 2019-11-05 17:07:15 --> Config Class Initialized
INFO - 2019-11-05 17:07:15 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:07:15 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:07:16 --> Utf8 Class Initialized
INFO - 2019-11-05 17:07:16 --> URI Class Initialized
INFO - 2019-11-05 17:07:16 --> Router Class Initialized
INFO - 2019-11-05 17:07:16 --> Output Class Initialized
INFO - 2019-11-05 17:07:16 --> Security Class Initialized
DEBUG - 2019-11-05 17:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:07:16 --> CSRF cookie sent
INFO - 2019-11-05 17:07:16 --> Input Class Initialized
INFO - 2019-11-05 17:07:16 --> Language Class Initialized
INFO - 2019-11-05 17:07:16 --> Language Class Initialized
INFO - 2019-11-05 17:07:16 --> Config Class Initialized
INFO - 2019-11-05 17:07:16 --> Loader Class Initialized
INFO - 2019-11-05 17:07:16 --> Helper loaded: url_helper
INFO - 2019-11-05 17:07:16 --> Helper loaded: common_helper
INFO - 2019-11-05 17:07:16 --> Helper loaded: language_helper
INFO - 2019-11-05 17:07:16 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:07:16 --> Helper loaded: email_helper
INFO - 2019-11-05 17:07:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:07:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:07:16 --> Parser Class Initialized
INFO - 2019-11-05 17:07:16 --> User Agent Class Initialized
INFO - 2019-11-05 17:07:16 --> Model Class Initialized
INFO - 2019-11-05 17:07:16 --> Database Driver Class Initialized
INFO - 2019-11-05 17:07:16 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:16 --> Template Class Initialized
INFO - 2019-11-05 17:07:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:07:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:07:16 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:07:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:07:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:07:16 --> Encryption Class Initialized
INFO - 2019-11-05 17:07:16 --> Controller Class Initialized
DEBUG - 2019-11-05 17:07:16 --> package MX_Controller Initialized
DEBUG - 2019-11-05 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-05 17:07:16 --> Model Class Initialized
INFO - 2019-11-05 17:07:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:07:16 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:07:16 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:07:16 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-05 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-05 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 17:07:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 17:07:16 --> Final output sent to browser
DEBUG - 2019-11-05 17:07:16 --> Total execution time: 0.8012
INFO - 2019-11-05 17:07:23 --> Config Class Initialized
INFO - 2019-11-05 17:07:23 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:07:24 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:07:24 --> Utf8 Class Initialized
INFO - 2019-11-05 17:07:24 --> URI Class Initialized
INFO - 2019-11-05 17:07:24 --> Router Class Initialized
INFO - 2019-11-05 17:07:24 --> Output Class Initialized
INFO - 2019-11-05 17:07:24 --> Security Class Initialized
DEBUG - 2019-11-05 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:07:24 --> CSRF cookie sent
INFO - 2019-11-05 17:07:24 --> CSRF token verified
INFO - 2019-11-05 17:07:24 --> Input Class Initialized
INFO - 2019-11-05 17:07:24 --> Language Class Initialized
INFO - 2019-11-05 17:07:24 --> Language Class Initialized
INFO - 2019-11-05 17:07:24 --> Config Class Initialized
INFO - 2019-11-05 17:07:24 --> Loader Class Initialized
INFO - 2019-11-05 17:07:24 --> Helper loaded: url_helper
INFO - 2019-11-05 17:07:24 --> Helper loaded: common_helper
INFO - 2019-11-05 17:07:24 --> Helper loaded: language_helper
INFO - 2019-11-05 17:07:24 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:07:24 --> Helper loaded: email_helper
INFO - 2019-11-05 17:07:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:07:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:07:24 --> Parser Class Initialized
INFO - 2019-11-05 17:07:24 --> User Agent Class Initialized
INFO - 2019-11-05 17:07:24 --> Model Class Initialized
INFO - 2019-11-05 17:07:24 --> Database Driver Class Initialized
INFO - 2019-11-05 17:07:24 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:24 --> Template Class Initialized
INFO - 2019-11-05 17:07:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:07:24 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:07:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:07:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:07:24 --> Encryption Class Initialized
INFO - 2019-11-05 17:07:24 --> Controller Class Initialized
DEBUG - 2019-11-05 17:07:24 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 17:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 17:07:24 --> Model Class Initialized
INFO - 2019-11-05 17:07:24 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 17:07:24 --> Could not find the language line "dotpay"
ERROR - 2019-11-05 17:07:24 --> Could not find the language line "paytm"
DEBUG - 2019-11-05 17:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-05 17:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:07:24 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:07:24 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:07:24 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-05 17:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-05 17:07:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-05 17:07:24 --> Final output sent to browser
DEBUG - 2019-11-05 17:07:24 --> Total execution time: 0.7837
INFO - 2019-11-05 17:07:34 --> Config Class Initialized
INFO - 2019-11-05 17:07:34 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:07:34 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:07:34 --> Utf8 Class Initialized
INFO - 2019-11-05 17:07:34 --> URI Class Initialized
INFO - 2019-11-05 17:07:34 --> Router Class Initialized
INFO - 2019-11-05 17:07:34 --> Output Class Initialized
INFO - 2019-11-05 17:07:34 --> Security Class Initialized
DEBUG - 2019-11-05 17:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:07:34 --> CSRF cookie sent
INFO - 2019-11-05 17:07:34 --> CSRF token verified
INFO - 2019-11-05 17:07:34 --> Input Class Initialized
INFO - 2019-11-05 17:07:34 --> Language Class Initialized
INFO - 2019-11-05 17:07:34 --> Language Class Initialized
INFO - 2019-11-05 17:07:34 --> Config Class Initialized
INFO - 2019-11-05 17:07:34 --> Loader Class Initialized
INFO - 2019-11-05 17:07:34 --> Helper loaded: url_helper
INFO - 2019-11-05 17:07:34 --> Helper loaded: common_helper
INFO - 2019-11-05 17:07:34 --> Helper loaded: language_helper
INFO - 2019-11-05 17:07:34 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:07:34 --> Helper loaded: email_helper
INFO - 2019-11-05 17:07:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:07:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:07:34 --> Parser Class Initialized
INFO - 2019-11-05 17:07:34 --> User Agent Class Initialized
INFO - 2019-11-05 17:07:34 --> Model Class Initialized
INFO - 2019-11-05 17:07:34 --> Database Driver Class Initialized
INFO - 2019-11-05 17:07:34 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:35 --> Template Class Initialized
INFO - 2019-11-05 17:07:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:07:35 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:07:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:07:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:07:35 --> Encryption Class Initialized
INFO - 2019-11-05 17:07:35 --> Controller Class Initialized
DEBUG - 2019-11-05 17:07:35 --> checkout MX_Controller Initialized
DEBUG - 2019-11-05 17:07:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-05 17:07:35 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/cardinity/index.php
INFO - 2019-11-05 17:07:35 --> Final output sent to browser
DEBUG - 2019-11-05 17:07:35 --> Total execution time: 0.5443
INFO - 2019-11-05 17:07:35 --> Config Class Initialized
INFO - 2019-11-05 17:07:35 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:07:35 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:07:35 --> Utf8 Class Initialized
INFO - 2019-11-05 17:07:35 --> URI Class Initialized
INFO - 2019-11-05 17:07:35 --> Router Class Initialized
INFO - 2019-11-05 17:07:35 --> Output Class Initialized
INFO - 2019-11-05 17:07:35 --> Security Class Initialized
DEBUG - 2019-11-05 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:07:35 --> Input Class Initialized
INFO - 2019-11-05 17:07:35 --> Language Class Initialized
INFO - 2019-11-05 17:07:35 --> Language Class Initialized
INFO - 2019-11-05 17:07:35 --> Config Class Initialized
INFO - 2019-11-05 17:07:35 --> Loader Class Initialized
INFO - 2019-11-05 17:07:35 --> Helper loaded: url_helper
INFO - 2019-11-05 17:07:35 --> Helper loaded: common_helper
INFO - 2019-11-05 17:07:35 --> Helper loaded: language_helper
INFO - 2019-11-05 17:07:35 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:07:35 --> Helper loaded: email_helper
INFO - 2019-11-05 17:07:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:07:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:07:35 --> Parser Class Initialized
INFO - 2019-11-05 17:07:35 --> User Agent Class Initialized
INFO - 2019-11-05 17:07:35 --> Model Class Initialized
INFO - 2019-11-05 17:07:35 --> Database Driver Class Initialized
INFO - 2019-11-05 17:07:35 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:35 --> Template Class Initialized
INFO - 2019-11-05 17:07:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:07:35 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:07:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:07:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:07:35 --> Encryption Class Initialized
INFO - 2019-11-05 17:07:35 --> Controller Class Initialized
DEBUG - 2019-11-05 17:07:35 --> cardinity MX_Controller Initialized
INFO - 2019-11-05 17:07:35 --> Config Class Initialized
INFO - 2019-11-05 17:07:36 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:07:36 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:07:36 --> Utf8 Class Initialized
INFO - 2019-11-05 17:07:36 --> URI Class Initialized
DEBUG - 2019-11-05 17:07:36 --> No URI present. Default controller set.
INFO - 2019-11-05 17:07:36 --> Router Class Initialized
INFO - 2019-11-05 17:07:36 --> Output Class Initialized
INFO - 2019-11-05 17:07:36 --> Security Class Initialized
DEBUG - 2019-11-05 17:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:07:36 --> CSRF cookie sent
INFO - 2019-11-05 17:07:36 --> Input Class Initialized
INFO - 2019-11-05 17:07:36 --> Language Class Initialized
INFO - 2019-11-05 17:07:36 --> Language Class Initialized
INFO - 2019-11-05 17:07:36 --> Config Class Initialized
INFO - 2019-11-05 17:07:36 --> Loader Class Initialized
INFO - 2019-11-05 17:07:36 --> Helper loaded: url_helper
INFO - 2019-11-05 17:07:36 --> Helper loaded: common_helper
INFO - 2019-11-05 17:07:36 --> Helper loaded: language_helper
INFO - 2019-11-05 17:07:36 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:07:36 --> Helper loaded: email_helper
INFO - 2019-11-05 17:07:36 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:07:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:07:36 --> Parser Class Initialized
INFO - 2019-11-05 17:07:36 --> User Agent Class Initialized
INFO - 2019-11-05 17:07:36 --> Model Class Initialized
INFO - 2019-11-05 17:07:36 --> Database Driver Class Initialized
INFO - 2019-11-05 17:07:36 --> Model Class Initialized
DEBUG - 2019-11-05 17:07:36 --> Template Class Initialized
INFO - 2019-11-05 17:07:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:07:36 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:07:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:07:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:07:36 --> Encryption Class Initialized
DEBUG - 2019-11-05 17:07:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:07:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 17:07:36 --> Controller Class Initialized
DEBUG - 2019-11-05 17:07:36 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 17:07:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 17:07:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 17:07:36 --> Model Class Initialized
INFO - 2019-11-05 17:07:36 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:07:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 17:07:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 17:07:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 17:07:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 17:07:36 --> Final output sent to browser
DEBUG - 2019-11-05 17:07:36 --> Total execution time: 0.7377
INFO - 2019-11-05 17:09:18 --> Config Class Initialized
INFO - 2019-11-05 17:09:18 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:09:18 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:09:18 --> Utf8 Class Initialized
INFO - 2019-11-05 17:09:18 --> URI Class Initialized
INFO - 2019-11-05 17:09:18 --> Router Class Initialized
INFO - 2019-11-05 17:09:18 --> Output Class Initialized
INFO - 2019-11-05 17:09:18 --> Security Class Initialized
DEBUG - 2019-11-05 17:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:09:18 --> CSRF cookie sent
INFO - 2019-11-05 17:09:18 --> Input Class Initialized
INFO - 2019-11-05 17:09:18 --> Language Class Initialized
INFO - 2019-11-05 17:09:18 --> Language Class Initialized
INFO - 2019-11-05 17:09:18 --> Config Class Initialized
INFO - 2019-11-05 17:09:18 --> Loader Class Initialized
INFO - 2019-11-05 17:09:18 --> Helper loaded: url_helper
INFO - 2019-11-05 17:09:18 --> Helper loaded: common_helper
INFO - 2019-11-05 17:09:18 --> Helper loaded: language_helper
INFO - 2019-11-05 17:09:18 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:09:18 --> Helper loaded: email_helper
INFO - 2019-11-05 17:09:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:09:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:09:18 --> Parser Class Initialized
INFO - 2019-11-05 17:09:18 --> User Agent Class Initialized
INFO - 2019-11-05 17:09:18 --> Model Class Initialized
INFO - 2019-11-05 17:09:19 --> Database Driver Class Initialized
INFO - 2019-11-05 17:09:19 --> Model Class Initialized
DEBUG - 2019-11-05 17:09:19 --> Template Class Initialized
INFO - 2019-11-05 17:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:09:19 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:09:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:09:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:09:19 --> Encryption Class Initialized
INFO - 2019-11-05 17:09:19 --> Controller Class Initialized
DEBUG - 2019-11-05 17:09:19 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 17:09:19 --> Model Class Initialized
INFO - 2019-11-05 17:09:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:09:19 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:09:19 --> Model Class Initialized
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:09:19 --> Model Class Initialized
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 17:09:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 17:09:19 --> Final output sent to browser
DEBUG - 2019-11-05 17:09:19 --> Total execution time: 0.9067
INFO - 2019-11-05 17:09:22 --> Config Class Initialized
INFO - 2019-11-05 17:09:22 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:09:22 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:09:22 --> Utf8 Class Initialized
INFO - 2019-11-05 17:09:22 --> URI Class Initialized
INFO - 2019-11-05 17:09:22 --> Router Class Initialized
INFO - 2019-11-05 17:09:22 --> Output Class Initialized
INFO - 2019-11-05 17:09:22 --> Security Class Initialized
DEBUG - 2019-11-05 17:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:09:22 --> CSRF cookie sent
INFO - 2019-11-05 17:09:22 --> Input Class Initialized
INFO - 2019-11-05 17:09:22 --> Language Class Initialized
INFO - 2019-11-05 17:09:22 --> Language Class Initialized
INFO - 2019-11-05 17:09:22 --> Config Class Initialized
INFO - 2019-11-05 17:09:22 --> Loader Class Initialized
INFO - 2019-11-05 17:09:22 --> Helper loaded: url_helper
INFO - 2019-11-05 17:09:22 --> Helper loaded: common_helper
INFO - 2019-11-05 17:09:22 --> Helper loaded: language_helper
INFO - 2019-11-05 17:09:22 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:09:22 --> Helper loaded: email_helper
INFO - 2019-11-05 17:09:22 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:09:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:09:22 --> Parser Class Initialized
INFO - 2019-11-05 17:09:22 --> User Agent Class Initialized
INFO - 2019-11-05 17:09:22 --> Model Class Initialized
INFO - 2019-11-05 17:09:22 --> Database Driver Class Initialized
INFO - 2019-11-05 17:09:23 --> Model Class Initialized
DEBUG - 2019-11-05 17:09:23 --> Template Class Initialized
INFO - 2019-11-05 17:09:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:09:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:09:23 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:09:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:09:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:09:23 --> Encryption Class Initialized
INFO - 2019-11-05 17:09:23 --> Controller Class Initialized
DEBUG - 2019-11-05 17:09:23 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 17:09:23 --> Model Class Initialized
INFO - 2019-11-05 17:09:23 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-05 17:09:23 --> Could not find the language line "Paytm_Integration"
ERROR - 2019-11-05 17:09:23 --> Could not find the language line "Paytm_mid_merchant_id"
ERROR - 2019-11-05 17:09:23 --> Could not find the language line "paytm_merchant_key"
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paytm.php
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:09:23 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:09:23 --> Model Class Initialized
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:09:23 --> Model Class Initialized
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 17:09:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 17:09:23 --> Final output sent to browser
DEBUG - 2019-11-05 17:09:23 --> Total execution time: 0.8757
INFO - 2019-11-05 17:10:06 --> Config Class Initialized
INFO - 2019-11-05 17:10:06 --> Hooks Class Initialized
DEBUG - 2019-11-05 17:10:06 --> UTF-8 Support Enabled
INFO - 2019-11-05 17:10:06 --> Utf8 Class Initialized
INFO - 2019-11-05 17:10:06 --> URI Class Initialized
INFO - 2019-11-05 17:10:06 --> Router Class Initialized
INFO - 2019-11-05 17:10:06 --> Output Class Initialized
INFO - 2019-11-05 17:10:06 --> Security Class Initialized
DEBUG - 2019-11-05 17:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 17:10:06 --> CSRF cookie sent
INFO - 2019-11-05 17:10:06 --> Input Class Initialized
INFO - 2019-11-05 17:10:06 --> Language Class Initialized
INFO - 2019-11-05 17:10:06 --> Language Class Initialized
INFO - 2019-11-05 17:10:06 --> Config Class Initialized
INFO - 2019-11-05 17:10:06 --> Loader Class Initialized
INFO - 2019-11-05 17:10:06 --> Helper loaded: url_helper
INFO - 2019-11-05 17:10:07 --> Helper loaded: common_helper
INFO - 2019-11-05 17:10:07 --> Helper loaded: language_helper
INFO - 2019-11-05 17:10:07 --> Helper loaded: cookie_helper
INFO - 2019-11-05 17:10:07 --> Helper loaded: email_helper
INFO - 2019-11-05 17:10:07 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 17:10:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 17:10:07 --> Parser Class Initialized
INFO - 2019-11-05 17:10:07 --> User Agent Class Initialized
INFO - 2019-11-05 17:10:07 --> Model Class Initialized
INFO - 2019-11-05 17:10:07 --> Database Driver Class Initialized
INFO - 2019-11-05 17:10:07 --> Model Class Initialized
DEBUG - 2019-11-05 17:10:07 --> Template Class Initialized
INFO - 2019-11-05 17:10:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 17:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 17:10:07 --> Pagination Class Initialized
DEBUG - 2019-11-05 17:10:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 17:10:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 17:10:07 --> Encryption Class Initialized
INFO - 2019-11-05 17:10:07 --> Controller Class Initialized
DEBUG - 2019-11-05 17:10:07 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 17:10:07 --> Model Class Initialized
INFO - 2019-11-05 17:10:07 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-11-05 17:10:07 --> Could not find the language line "Paytm_Integration"
ERROR - 2019-11-05 17:10:07 --> Could not find the language line "Paytm_mid_merchant_id"
ERROR - 2019-11-05 17:10:07 --> Could not find the language line "paytm_merchant_key"
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/paytm.php
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 17:10:07 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 17:10:07 --> Model Class Initialized
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 17:10:07 --> Model Class Initialized
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 17:10:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 17:10:07 --> Final output sent to browser
DEBUG - 2019-11-05 17:10:07 --> Total execution time: 0.9860
INFO - 2019-11-05 22:54:25 --> Config Class Initialized
INFO - 2019-11-05 22:54:25 --> Hooks Class Initialized
DEBUG - 2019-11-05 22:54:25 --> UTF-8 Support Enabled
INFO - 2019-11-05 22:54:25 --> Utf8 Class Initialized
INFO - 2019-11-05 22:54:25 --> URI Class Initialized
DEBUG - 2019-11-05 22:54:25 --> No URI present. Default controller set.
INFO - 2019-11-05 22:54:25 --> Router Class Initialized
INFO - 2019-11-05 22:54:26 --> Output Class Initialized
INFO - 2019-11-05 22:54:26 --> Security Class Initialized
DEBUG - 2019-11-05 22:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 22:54:26 --> CSRF cookie sent
INFO - 2019-11-05 22:54:26 --> Input Class Initialized
INFO - 2019-11-05 22:54:26 --> Language Class Initialized
INFO - 2019-11-05 22:54:26 --> Language Class Initialized
INFO - 2019-11-05 22:54:26 --> Config Class Initialized
INFO - 2019-11-05 22:54:26 --> Loader Class Initialized
INFO - 2019-11-05 22:54:26 --> Helper loaded: url_helper
INFO - 2019-11-05 22:54:26 --> Helper loaded: common_helper
INFO - 2019-11-05 22:54:26 --> Helper loaded: language_helper
INFO - 2019-11-05 22:54:26 --> Helper loaded: cookie_helper
INFO - 2019-11-05 22:54:26 --> Helper loaded: email_helper
INFO - 2019-11-05 22:54:26 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 22:54:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 22:54:26 --> Parser Class Initialized
INFO - 2019-11-05 22:54:26 --> User Agent Class Initialized
INFO - 2019-11-05 22:54:26 --> Model Class Initialized
INFO - 2019-11-05 22:54:26 --> Database Driver Class Initialized
INFO - 2019-11-05 22:54:26 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:26 --> Template Class Initialized
INFO - 2019-11-05 22:54:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 22:54:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 22:54:27 --> Pagination Class Initialized
DEBUG - 2019-11-05 22:54:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 22:54:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 22:54:27 --> Encryption Class Initialized
DEBUG - 2019-11-05 22:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 22:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-05 22:54:27 --> Controller Class Initialized
DEBUG - 2019-11-05 22:54:27 --> pergo MX_Controller Initialized
DEBUG - 2019-11-05 22:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-05 22:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-05 22:54:27 --> Model Class Initialized
INFO - 2019-11-05 22:54:27 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 22:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-05 22:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-05 22:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-05 22:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-05 22:54:28 --> Final output sent to browser
DEBUG - 2019-11-05 22:54:28 --> Total execution time: 2.2631
INFO - 2019-11-05 22:54:33 --> Config Class Initialized
INFO - 2019-11-05 22:54:33 --> Hooks Class Initialized
DEBUG - 2019-11-05 22:54:33 --> UTF-8 Support Enabled
INFO - 2019-11-05 22:54:33 --> Utf8 Class Initialized
INFO - 2019-11-05 22:54:33 --> URI Class Initialized
INFO - 2019-11-05 22:54:33 --> Router Class Initialized
INFO - 2019-11-05 22:54:33 --> Output Class Initialized
INFO - 2019-11-05 22:54:33 --> Security Class Initialized
DEBUG - 2019-11-05 22:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 22:54:33 --> CSRF cookie sent
INFO - 2019-11-05 22:54:33 --> Input Class Initialized
INFO - 2019-11-05 22:54:33 --> Language Class Initialized
INFO - 2019-11-05 22:54:33 --> Language Class Initialized
INFO - 2019-11-05 22:54:33 --> Config Class Initialized
INFO - 2019-11-05 22:54:33 --> Loader Class Initialized
INFO - 2019-11-05 22:54:33 --> Helper loaded: url_helper
INFO - 2019-11-05 22:54:33 --> Helper loaded: common_helper
INFO - 2019-11-05 22:54:33 --> Helper loaded: language_helper
INFO - 2019-11-05 22:54:33 --> Helper loaded: cookie_helper
INFO - 2019-11-05 22:54:33 --> Helper loaded: email_helper
INFO - 2019-11-05 22:54:33 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 22:54:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 22:54:33 --> Parser Class Initialized
INFO - 2019-11-05 22:54:33 --> User Agent Class Initialized
INFO - 2019-11-05 22:54:33 --> Model Class Initialized
INFO - 2019-11-05 22:54:33 --> Database Driver Class Initialized
INFO - 2019-11-05 22:54:33 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:33 --> Template Class Initialized
INFO - 2019-11-05 22:54:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 22:54:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 22:54:33 --> Pagination Class Initialized
DEBUG - 2019-11-05 22:54:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 22:54:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 22:54:33 --> Encryption Class Initialized
INFO - 2019-11-05 22:54:33 --> Controller Class Initialized
DEBUG - 2019-11-05 22:54:33 --> auth MX_Controller Initialized
DEBUG - 2019-11-05 22:54:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-05 22:54:33 --> Model Class Initialized
INFO - 2019-11-05 22:54:33 --> Config Class Initialized
INFO - 2019-11-05 22:54:33 --> Hooks Class Initialized
DEBUG - 2019-11-05 22:54:33 --> UTF-8 Support Enabled
INFO - 2019-11-05 22:54:33 --> Utf8 Class Initialized
INFO - 2019-11-05 22:54:33 --> URI Class Initialized
INFO - 2019-11-05 22:54:33 --> Router Class Initialized
INFO - 2019-11-05 22:54:34 --> Output Class Initialized
INFO - 2019-11-05 22:54:34 --> Security Class Initialized
DEBUG - 2019-11-05 22:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 22:54:34 --> CSRF cookie sent
INFO - 2019-11-05 22:54:34 --> Input Class Initialized
INFO - 2019-11-05 22:54:34 --> Language Class Initialized
INFO - 2019-11-05 22:54:34 --> Language Class Initialized
INFO - 2019-11-05 22:54:34 --> Config Class Initialized
INFO - 2019-11-05 22:54:34 --> Loader Class Initialized
INFO - 2019-11-05 22:54:34 --> Helper loaded: url_helper
INFO - 2019-11-05 22:54:34 --> Helper loaded: common_helper
INFO - 2019-11-05 22:54:34 --> Helper loaded: language_helper
INFO - 2019-11-05 22:54:34 --> Helper loaded: cookie_helper
INFO - 2019-11-05 22:54:34 --> Helper loaded: email_helper
INFO - 2019-11-05 22:54:34 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 22:54:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 22:54:34 --> Parser Class Initialized
INFO - 2019-11-05 22:54:34 --> User Agent Class Initialized
INFO - 2019-11-05 22:54:34 --> Model Class Initialized
INFO - 2019-11-05 22:54:34 --> Database Driver Class Initialized
INFO - 2019-11-05 22:54:34 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:34 --> Template Class Initialized
INFO - 2019-11-05 22:54:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 22:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 22:54:34 --> Pagination Class Initialized
DEBUG - 2019-11-05 22:54:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 22:54:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 22:54:34 --> Encryption Class Initialized
INFO - 2019-11-05 22:54:34 --> Controller Class Initialized
DEBUG - 2019-11-05 22:54:34 --> statistics MX_Controller Initialized
DEBUG - 2019-11-05 22:54:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-05 22:54:34 --> Model Class Initialized
ERROR - 2019-11-05 22:54:34 --> Could not find the language line "Pending"
ERROR - 2019-11-05 22:54:34 --> Could not find the language line "Pending"
INFO - 2019-11-05 22:54:34 --> Helper loaded: inflector_helper
ERROR - 2019-11-05 22:54:34 --> Could not find the language line "total_orders"
ERROR - 2019-11-05 22:54:34 --> Could not find the language line "total_orders"
ERROR - 2019-11-05 22:54:34 --> Could not find the language line "Pending"
DEBUG - 2019-11-05 22:54:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-05 22:54:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 22:54:35 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 22:54:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 22:54:35 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 22:54:35 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 22:54:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 22:54:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 22:54:35 --> Final output sent to browser
DEBUG - 2019-11-05 22:54:35 --> Total execution time: 1.4850
INFO - 2019-11-05 22:54:43 --> Config Class Initialized
INFO - 2019-11-05 22:54:43 --> Hooks Class Initialized
DEBUG - 2019-11-05 22:54:43 --> UTF-8 Support Enabled
INFO - 2019-11-05 22:54:43 --> Utf8 Class Initialized
INFO - 2019-11-05 22:54:43 --> URI Class Initialized
INFO - 2019-11-05 22:54:43 --> Router Class Initialized
INFO - 2019-11-05 22:54:43 --> Output Class Initialized
INFO - 2019-11-05 22:54:43 --> Security Class Initialized
DEBUG - 2019-11-05 22:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 22:54:43 --> CSRF cookie sent
INFO - 2019-11-05 22:54:43 --> Input Class Initialized
INFO - 2019-11-05 22:54:43 --> Language Class Initialized
INFO - 2019-11-05 22:54:43 --> Language Class Initialized
INFO - 2019-11-05 22:54:43 --> Config Class Initialized
INFO - 2019-11-05 22:54:43 --> Loader Class Initialized
INFO - 2019-11-05 22:54:43 --> Helper loaded: url_helper
INFO - 2019-11-05 22:54:43 --> Helper loaded: common_helper
INFO - 2019-11-05 22:54:43 --> Helper loaded: language_helper
INFO - 2019-11-05 22:54:43 --> Helper loaded: cookie_helper
INFO - 2019-11-05 22:54:43 --> Helper loaded: email_helper
INFO - 2019-11-05 22:54:43 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 22:54:44 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 22:54:44 --> Parser Class Initialized
INFO - 2019-11-05 22:54:44 --> User Agent Class Initialized
INFO - 2019-11-05 22:54:44 --> Model Class Initialized
INFO - 2019-11-05 22:54:44 --> Database Driver Class Initialized
INFO - 2019-11-05 22:54:44 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:44 --> Template Class Initialized
INFO - 2019-11-05 22:54:44 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 22:54:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 22:54:44 --> Pagination Class Initialized
DEBUG - 2019-11-05 22:54:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 22:54:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 22:54:44 --> Encryption Class Initialized
INFO - 2019-11-05 22:54:44 --> Controller Class Initialized
DEBUG - 2019-11-05 22:54:44 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 22:54:44 --> Model Class Initialized
INFO - 2019-11-05 22:54:44 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 22:54:44 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 22:54:44 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 22:54:44 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 22:54:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 22:54:44 --> Final output sent to browser
DEBUG - 2019-11-05 22:54:44 --> Total execution time: 1.3414
INFO - 2019-11-05 22:54:46 --> Config Class Initialized
INFO - 2019-11-05 22:54:46 --> Hooks Class Initialized
DEBUG - 2019-11-05 22:54:46 --> UTF-8 Support Enabled
INFO - 2019-11-05 22:54:46 --> Utf8 Class Initialized
INFO - 2019-11-05 22:54:46 --> URI Class Initialized
INFO - 2019-11-05 22:54:46 --> Router Class Initialized
INFO - 2019-11-05 22:54:46 --> Output Class Initialized
INFO - 2019-11-05 22:54:46 --> Security Class Initialized
DEBUG - 2019-11-05 22:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-05 22:54:46 --> CSRF cookie sent
INFO - 2019-11-05 22:54:46 --> Input Class Initialized
INFO - 2019-11-05 22:54:46 --> Language Class Initialized
INFO - 2019-11-05 22:54:46 --> Language Class Initialized
INFO - 2019-11-05 22:54:46 --> Config Class Initialized
INFO - 2019-11-05 22:54:46 --> Loader Class Initialized
INFO - 2019-11-05 22:54:46 --> Helper loaded: url_helper
INFO - 2019-11-05 22:54:46 --> Helper loaded: common_helper
INFO - 2019-11-05 22:54:46 --> Helper loaded: language_helper
INFO - 2019-11-05 22:54:46 --> Helper loaded: cookie_helper
INFO - 2019-11-05 22:54:46 --> Helper loaded: email_helper
INFO - 2019-11-05 22:54:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-05 22:54:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-05 22:54:46 --> Parser Class Initialized
INFO - 2019-11-05 22:54:46 --> User Agent Class Initialized
INFO - 2019-11-05 22:54:46 --> Model Class Initialized
INFO - 2019-11-05 22:54:46 --> Database Driver Class Initialized
INFO - 2019-11-05 22:54:46 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:46 --> Template Class Initialized
INFO - 2019-11-05 22:54:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-05 22:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-05 22:54:46 --> Pagination Class Initialized
DEBUG - 2019-11-05 22:54:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-05 22:54:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-05 22:54:46 --> Encryption Class Initialized
INFO - 2019-11-05 22:54:46 --> Controller Class Initialized
DEBUG - 2019-11-05 22:54:46 --> setting MX_Controller Initialized
DEBUG - 2019-11-05 22:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-05 22:54:46 --> Model Class Initialized
INFO - 2019-11-05 22:54:46 --> Helper loaded: inflector_helper
DEBUG - 2019-11-05 22:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-05 22:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/payment.php
DEBUG - 2019-11-05 22:54:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-05 22:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-05 22:54:47 --> blocks MX_Controller Initialized
DEBUG - 2019-11-05 22:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-05 22:54:47 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-05 22:54:47 --> Model Class Initialized
DEBUG - 2019-11-05 22:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-05 22:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-05 22:54:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-05 22:54:47 --> Final output sent to browser
DEBUG - 2019-11-05 22:54:47 --> Total execution time: 0.9184
