<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-07 14:56:53 --> Config Class Initialized
INFO - 2020-04-07 14:56:53 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:56:53 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:56:53 --> Utf8 Class Initialized
INFO - 2020-04-07 14:56:53 --> URI Class Initialized
DEBUG - 2020-04-07 14:56:53 --> No URI present. Default controller set.
INFO - 2020-04-07 14:56:53 --> Router Class Initialized
INFO - 2020-04-07 14:56:53 --> Output Class Initialized
INFO - 2020-04-07 14:56:53 --> Security Class Initialized
DEBUG - 2020-04-07 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:56:53 --> CSRF cookie sent
INFO - 2020-04-07 14:56:53 --> Input Class Initialized
INFO - 2020-04-07 14:56:53 --> Language Class Initialized
INFO - 2020-04-07 14:56:53 --> Language Class Initialized
INFO - 2020-04-07 14:56:53 --> Config Class Initialized
INFO - 2020-04-07 14:56:53 --> Loader Class Initialized
INFO - 2020-04-07 14:56:53 --> Helper loaded: url_helper
INFO - 2020-04-07 14:56:53 --> Helper loaded: file_helper
INFO - 2020-04-07 14:56:53 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:56:53 --> Helper loaded: common_helper
INFO - 2020-04-07 14:56:53 --> Helper loaded: language_helper
INFO - 2020-04-07 14:56:53 --> Helper loaded: email_helper
INFO - 2020-04-07 14:56:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:56:53 --> Database Driver Class Initialized
INFO - 2020-04-07 14:56:53 --> Parser Class Initialized
INFO - 2020-04-07 14:56:53 --> User Agent Class Initialized
INFO - 2020-04-07 14:56:53 --> Model Class Initialized
INFO - 2020-04-07 14:56:53 --> Model Class Initialized
DEBUG - 2020-04-07 14:56:54 --> Template Class Initialized
INFO - 2020-04-07 14:56:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:56:54 --> Email Class Initialized
INFO - 2020-04-07 14:56:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:56:54 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:56:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:56:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:56:54 --> Encryption Class Initialized
INFO - 2020-04-07 14:56:54 --> Controller Class Initialized
DEBUG - 2020-04-07 14:56:54 --> home MX_Controller Initialized
INFO - 2020-04-07 14:56:54 --> Model Class Initialized
INFO - 2020-04-07 14:56:54 --> Config Class Initialized
INFO - 2020-04-07 14:56:54 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:56:54 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:56:54 --> Utf8 Class Initialized
INFO - 2020-04-07 14:56:54 --> URI Class Initialized
INFO - 2020-04-07 14:56:54 --> Router Class Initialized
INFO - 2020-04-07 14:56:54 --> Output Class Initialized
INFO - 2020-04-07 14:56:54 --> Security Class Initialized
DEBUG - 2020-04-07 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:56:54 --> CSRF cookie sent
INFO - 2020-04-07 14:56:54 --> Input Class Initialized
INFO - 2020-04-07 14:56:54 --> Language Class Initialized
INFO - 2020-04-07 14:56:54 --> Language Class Initialized
INFO - 2020-04-07 14:56:54 --> Config Class Initialized
INFO - 2020-04-07 14:56:54 --> Loader Class Initialized
INFO - 2020-04-07 14:56:54 --> Helper loaded: url_helper
INFO - 2020-04-07 14:56:54 --> Helper loaded: file_helper
INFO - 2020-04-07 14:56:54 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:56:54 --> Helper loaded: common_helper
INFO - 2020-04-07 14:56:54 --> Helper loaded: language_helper
INFO - 2020-04-07 14:56:54 --> Helper loaded: email_helper
INFO - 2020-04-07 14:56:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:56:54 --> Database Driver Class Initialized
INFO - 2020-04-07 14:56:54 --> Parser Class Initialized
INFO - 2020-04-07 14:56:54 --> User Agent Class Initialized
INFO - 2020-04-07 14:56:54 --> Model Class Initialized
INFO - 2020-04-07 14:56:54 --> Model Class Initialized
DEBUG - 2020-04-07 14:56:54 --> Template Class Initialized
INFO - 2020-04-07 14:56:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:56:54 --> Email Class Initialized
INFO - 2020-04-07 14:56:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:56:54 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:56:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:56:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:56:54 --> Encryption Class Initialized
INFO - 2020-04-07 14:56:54 --> Controller Class Initialized
DEBUG - 2020-04-07 14:56:54 --> twitter MX_Controller Initialized
INFO - 2020-04-07 14:56:54 --> Model Class Initialized
DEBUG - 2020-04-07 14:56:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 14:56:54 --> Model Class Initialized
DEBUG - 2020-04-07 14:56:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-07 14:56:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 14:56:54 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 14:56:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 14:56:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 14:56:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 14:56:54 --> Final output sent to browser
DEBUG - 2020-04-07 14:56:54 --> Total execution time: 0.5920
INFO - 2020-04-07 14:57:02 --> Config Class Initialized
INFO - 2020-04-07 14:57:02 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:57:02 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:57:02 --> Utf8 Class Initialized
INFO - 2020-04-07 14:57:02 --> URI Class Initialized
INFO - 2020-04-07 14:57:02 --> Router Class Initialized
INFO - 2020-04-07 14:57:02 --> Output Class Initialized
INFO - 2020-04-07 14:57:02 --> Security Class Initialized
DEBUG - 2020-04-07 14:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:57:02 --> CSRF cookie sent
INFO - 2020-04-07 14:57:02 --> Input Class Initialized
INFO - 2020-04-07 14:57:02 --> Language Class Initialized
INFO - 2020-04-07 14:57:02 --> Language Class Initialized
INFO - 2020-04-07 14:57:02 --> Config Class Initialized
INFO - 2020-04-07 14:57:02 --> Loader Class Initialized
INFO - 2020-04-07 14:57:02 --> Helper loaded: url_helper
INFO - 2020-04-07 14:57:02 --> Helper loaded: file_helper
INFO - 2020-04-07 14:57:02 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:57:02 --> Helper loaded: common_helper
INFO - 2020-04-07 14:57:02 --> Helper loaded: language_helper
INFO - 2020-04-07 14:57:02 --> Helper loaded: email_helper
INFO - 2020-04-07 14:57:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:57:02 --> Database Driver Class Initialized
INFO - 2020-04-07 14:57:02 --> Parser Class Initialized
INFO - 2020-04-07 14:57:02 --> User Agent Class Initialized
INFO - 2020-04-07 14:57:02 --> Model Class Initialized
INFO - 2020-04-07 14:57:02 --> Model Class Initialized
DEBUG - 2020-04-07 14:57:02 --> Template Class Initialized
INFO - 2020-04-07 14:57:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:57:02 --> Email Class Initialized
INFO - 2020-04-07 14:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:57:02 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:57:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:57:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:57:02 --> Encryption Class Initialized
INFO - 2020-04-07 14:57:02 --> Controller Class Initialized
DEBUG - 2020-04-07 14:57:02 --> post MX_Controller Initialized
INFO - 2020-04-07 14:57:02 --> Model Class Initialized
ERROR - 2020-04-07 14:57:02 --> Could not find the language line ""
ERROR - 2020-04-07 14:57:02 --> Could not find the language line ""
ERROR - 2020-04-07 14:57:02 --> Could not find the language line ""
DEBUG - 2020-04-07 14:57:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-07 14:57:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 14:57:02 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 14:57:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 14:57:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 14:57:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 14:57:02 --> Final output sent to browser
DEBUG - 2020-04-07 14:57:02 --> Total execution time: 0.4733
INFO - 2020-04-07 14:57:28 --> Config Class Initialized
INFO - 2020-04-07 14:57:28 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:57:28 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:57:28 --> Utf8 Class Initialized
INFO - 2020-04-07 14:57:28 --> URI Class Initialized
INFO - 2020-04-07 14:57:28 --> Router Class Initialized
INFO - 2020-04-07 14:57:28 --> Output Class Initialized
INFO - 2020-04-07 14:57:28 --> Security Class Initialized
DEBUG - 2020-04-07 14:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:57:28 --> CSRF cookie sent
INFO - 2020-04-07 14:57:28 --> CSRF token verified
INFO - 2020-04-07 14:57:28 --> Input Class Initialized
INFO - 2020-04-07 14:57:28 --> Language Class Initialized
INFO - 2020-04-07 14:57:28 --> Language Class Initialized
INFO - 2020-04-07 14:57:28 --> Config Class Initialized
INFO - 2020-04-07 14:57:28 --> Loader Class Initialized
INFO - 2020-04-07 14:57:28 --> Helper loaded: url_helper
INFO - 2020-04-07 14:57:28 --> Helper loaded: file_helper
INFO - 2020-04-07 14:57:28 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:57:28 --> Helper loaded: common_helper
INFO - 2020-04-07 14:57:28 --> Helper loaded: language_helper
INFO - 2020-04-07 14:57:28 --> Helper loaded: email_helper
INFO - 2020-04-07 14:57:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:57:28 --> Database Driver Class Initialized
INFO - 2020-04-07 14:57:28 --> Parser Class Initialized
INFO - 2020-04-07 14:57:28 --> User Agent Class Initialized
INFO - 2020-04-07 14:57:28 --> Model Class Initialized
INFO - 2020-04-07 14:57:28 --> Model Class Initialized
DEBUG - 2020-04-07 14:57:28 --> Template Class Initialized
INFO - 2020-04-07 14:57:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:57:28 --> Email Class Initialized
INFO - 2020-04-07 14:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:57:28 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:57:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:57:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:57:28 --> Encryption Class Initialized
INFO - 2020-04-07 14:57:28 --> Controller Class Initialized
DEBUG - 2020-04-07 14:57:28 --> post MX_Controller Initialized
INFO - 2020-04-07 14:57:28 --> Model Class Initialized
INFO - 2020-04-07 14:58:47 --> Config Class Initialized
INFO - 2020-04-07 14:58:47 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:58:47 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:58:47 --> Utf8 Class Initialized
INFO - 2020-04-07 14:58:47 --> URI Class Initialized
INFO - 2020-04-07 14:58:47 --> Router Class Initialized
INFO - 2020-04-07 14:58:47 --> Output Class Initialized
INFO - 2020-04-07 14:58:47 --> Security Class Initialized
DEBUG - 2020-04-07 14:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:58:47 --> CSRF cookie sent
INFO - 2020-04-07 14:58:47 --> Input Class Initialized
INFO - 2020-04-07 14:58:47 --> Language Class Initialized
INFO - 2020-04-07 14:58:47 --> Language Class Initialized
INFO - 2020-04-07 14:58:47 --> Config Class Initialized
INFO - 2020-04-07 14:58:47 --> Loader Class Initialized
INFO - 2020-04-07 14:58:47 --> Helper loaded: url_helper
INFO - 2020-04-07 14:58:47 --> Helper loaded: file_helper
INFO - 2020-04-07 14:58:47 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:58:47 --> Helper loaded: common_helper
INFO - 2020-04-07 14:58:47 --> Helper loaded: language_helper
INFO - 2020-04-07 14:58:47 --> Helper loaded: email_helper
INFO - 2020-04-07 14:58:47 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:58:47 --> Database Driver Class Initialized
INFO - 2020-04-07 14:58:47 --> Parser Class Initialized
INFO - 2020-04-07 14:58:47 --> User Agent Class Initialized
INFO - 2020-04-07 14:58:47 --> Model Class Initialized
INFO - 2020-04-07 14:58:47 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:47 --> Template Class Initialized
INFO - 2020-04-07 14:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:58:47 --> Email Class Initialized
INFO - 2020-04-07 14:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:58:47 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:58:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:58:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:58:47 --> Encryption Class Initialized
INFO - 2020-04-07 14:58:47 --> Controller Class Initialized
DEBUG - 2020-04-07 14:58:47 --> follow MX_Controller Initialized
INFO - 2020-04-07 14:58:47 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-07 14:58:47 --> Model Class Initialized
INFO - 2020-04-07 14:58:47 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 14:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-07 14:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 14:58:47 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 14:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 14:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 14:58:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 14:58:47 --> Final output sent to browser
DEBUG - 2020-04-07 14:58:47 --> Total execution time: 0.4963
INFO - 2020-04-07 14:58:49 --> Config Class Initialized
INFO - 2020-04-07 14:58:49 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:58:49 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:58:49 --> Utf8 Class Initialized
INFO - 2020-04-07 14:58:49 --> URI Class Initialized
INFO - 2020-04-07 14:58:49 --> Router Class Initialized
INFO - 2020-04-07 14:58:49 --> Output Class Initialized
INFO - 2020-04-07 14:58:49 --> Security Class Initialized
DEBUG - 2020-04-07 14:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:58:49 --> CSRF cookie sent
INFO - 2020-04-07 14:58:49 --> Input Class Initialized
INFO - 2020-04-07 14:58:49 --> Language Class Initialized
INFO - 2020-04-07 14:58:49 --> Language Class Initialized
INFO - 2020-04-07 14:58:49 --> Config Class Initialized
INFO - 2020-04-07 14:58:49 --> Loader Class Initialized
INFO - 2020-04-07 14:58:49 --> Helper loaded: url_helper
INFO - 2020-04-07 14:58:49 --> Helper loaded: file_helper
INFO - 2020-04-07 14:58:49 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:58:49 --> Helper loaded: common_helper
INFO - 2020-04-07 14:58:49 --> Helper loaded: language_helper
INFO - 2020-04-07 14:58:49 --> Helper loaded: email_helper
INFO - 2020-04-07 14:58:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:58:49 --> Database Driver Class Initialized
INFO - 2020-04-07 14:58:49 --> Parser Class Initialized
INFO - 2020-04-07 14:58:49 --> User Agent Class Initialized
INFO - 2020-04-07 14:58:49 --> Model Class Initialized
INFO - 2020-04-07 14:58:49 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:49 --> Template Class Initialized
INFO - 2020-04-07 14:58:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:58:49 --> Email Class Initialized
INFO - 2020-04-07 14:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:58:49 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:58:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:58:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:58:49 --> Encryption Class Initialized
INFO - 2020-04-07 14:58:49 --> Controller Class Initialized
DEBUG - 2020-04-07 14:58:49 --> unfollow MX_Controller Initialized
INFO - 2020-04-07 14:58:49 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/unfollow/models/unfollow_model.php
INFO - 2020-04-07 14:58:49 --> Model Class Initialized
INFO - 2020-04-07 14:58:49 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 14:58:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/unfollow/views/index.php
DEBUG - 2020-04-07 14:58:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 14:58:49 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 14:58:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 14:58:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 14:58:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 14:58:49 --> Final output sent to browser
DEBUG - 2020-04-07 14:58:49 --> Total execution time: 0.5070
INFO - 2020-04-07 14:58:50 --> Config Class Initialized
INFO - 2020-04-07 14:58:50 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:58:50 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:58:50 --> Utf8 Class Initialized
INFO - 2020-04-07 14:58:50 --> URI Class Initialized
INFO - 2020-04-07 14:58:50 --> Router Class Initialized
INFO - 2020-04-07 14:58:50 --> Output Class Initialized
INFO - 2020-04-07 14:58:50 --> Security Class Initialized
DEBUG - 2020-04-07 14:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:58:50 --> CSRF cookie sent
INFO - 2020-04-07 14:58:50 --> Input Class Initialized
INFO - 2020-04-07 14:58:50 --> Language Class Initialized
INFO - 2020-04-07 14:58:50 --> Language Class Initialized
INFO - 2020-04-07 14:58:50 --> Config Class Initialized
INFO - 2020-04-07 14:58:50 --> Loader Class Initialized
INFO - 2020-04-07 14:58:50 --> Helper loaded: url_helper
INFO - 2020-04-07 14:58:50 --> Helper loaded: file_helper
INFO - 2020-04-07 14:58:50 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:58:50 --> Helper loaded: common_helper
INFO - 2020-04-07 14:58:50 --> Helper loaded: language_helper
INFO - 2020-04-07 14:58:50 --> Helper loaded: email_helper
INFO - 2020-04-07 14:58:50 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:58:50 --> Database Driver Class Initialized
INFO - 2020-04-07 14:58:50 --> Parser Class Initialized
INFO - 2020-04-07 14:58:50 --> User Agent Class Initialized
INFO - 2020-04-07 14:58:50 --> Model Class Initialized
INFO - 2020-04-07 14:58:50 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:50 --> Template Class Initialized
INFO - 2020-04-07 14:58:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:58:50 --> Email Class Initialized
INFO - 2020-04-07 14:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:58:50 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:58:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:58:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:58:50 --> Encryption Class Initialized
INFO - 2020-04-07 14:58:50 --> Controller Class Initialized
DEBUG - 2020-04-07 14:58:50 --> retweet MX_Controller Initialized
INFO - 2020-04-07 14:58:50 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/retweet/models/retweet_model.php
INFO - 2020-04-07 14:58:50 --> Model Class Initialized
INFO - 2020-04-07 14:58:50 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 14:58:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/retweet/views/index.php
DEBUG - 2020-04-07 14:58:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 14:58:51 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 14:58:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 14:58:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 14:58:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 14:58:51 --> Final output sent to browser
DEBUG - 2020-04-07 14:58:51 --> Total execution time: 0.5017
INFO - 2020-04-07 14:58:52 --> Config Class Initialized
INFO - 2020-04-07 14:58:52 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:58:52 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:58:52 --> Utf8 Class Initialized
INFO - 2020-04-07 14:58:52 --> URI Class Initialized
INFO - 2020-04-07 14:58:52 --> Router Class Initialized
INFO - 2020-04-07 14:58:52 --> Output Class Initialized
INFO - 2020-04-07 14:58:52 --> Security Class Initialized
DEBUG - 2020-04-07 14:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:58:52 --> CSRF cookie sent
INFO - 2020-04-07 14:58:52 --> Input Class Initialized
INFO - 2020-04-07 14:58:52 --> Language Class Initialized
INFO - 2020-04-07 14:58:52 --> Language Class Initialized
INFO - 2020-04-07 14:58:52 --> Config Class Initialized
INFO - 2020-04-07 14:58:52 --> Loader Class Initialized
INFO - 2020-04-07 14:58:52 --> Helper loaded: url_helper
INFO - 2020-04-07 14:58:52 --> Helper loaded: file_helper
INFO - 2020-04-07 14:58:52 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:58:52 --> Helper loaded: common_helper
INFO - 2020-04-07 14:58:52 --> Helper loaded: language_helper
INFO - 2020-04-07 14:58:52 --> Helper loaded: email_helper
INFO - 2020-04-07 14:58:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:58:52 --> Database Driver Class Initialized
INFO - 2020-04-07 14:58:52 --> Parser Class Initialized
INFO - 2020-04-07 14:58:52 --> User Agent Class Initialized
INFO - 2020-04-07 14:58:52 --> Model Class Initialized
INFO - 2020-04-07 14:58:52 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:52 --> Template Class Initialized
INFO - 2020-04-07 14:58:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:58:52 --> Email Class Initialized
INFO - 2020-04-07 14:58:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:58:52 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:58:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:58:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:58:52 --> Encryption Class Initialized
INFO - 2020-04-07 14:58:52 --> Controller Class Initialized
DEBUG - 2020-04-07 14:58:52 --> follow MX_Controller Initialized
INFO - 2020-04-07 14:58:52 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-07 14:58:52 --> Model Class Initialized
INFO - 2020-04-07 14:58:52 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 14:58:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-07 14:58:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 14:58:52 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 14:58:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 14:58:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 14:58:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 14:58:53 --> Final output sent to browser
DEBUG - 2020-04-07 14:58:53 --> Total execution time: 0.4644
INFO - 2020-04-07 14:58:53 --> Config Class Initialized
INFO - 2020-04-07 14:58:53 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:58:53 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:58:53 --> Utf8 Class Initialized
INFO - 2020-04-07 14:58:53 --> URI Class Initialized
INFO - 2020-04-07 14:58:53 --> Router Class Initialized
INFO - 2020-04-07 14:58:53 --> Output Class Initialized
INFO - 2020-04-07 14:58:53 --> Security Class Initialized
DEBUG - 2020-04-07 14:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:58:53 --> CSRF cookie sent
INFO - 2020-04-07 14:58:53 --> Input Class Initialized
INFO - 2020-04-07 14:58:53 --> Language Class Initialized
INFO - 2020-04-07 14:58:53 --> Language Class Initialized
INFO - 2020-04-07 14:58:53 --> Config Class Initialized
INFO - 2020-04-07 14:58:53 --> Loader Class Initialized
INFO - 2020-04-07 14:58:53 --> Helper loaded: url_helper
INFO - 2020-04-07 14:58:53 --> Helper loaded: file_helper
INFO - 2020-04-07 14:58:53 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:58:53 --> Helper loaded: common_helper
INFO - 2020-04-07 14:58:53 --> Helper loaded: language_helper
INFO - 2020-04-07 14:58:53 --> Helper loaded: email_helper
INFO - 2020-04-07 14:58:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:58:53 --> Database Driver Class Initialized
INFO - 2020-04-07 14:58:54 --> Parser Class Initialized
INFO - 2020-04-07 14:58:54 --> User Agent Class Initialized
INFO - 2020-04-07 14:58:54 --> Model Class Initialized
INFO - 2020-04-07 14:58:54 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:54 --> Template Class Initialized
INFO - 2020-04-07 14:58:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:58:54 --> Email Class Initialized
INFO - 2020-04-07 14:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:58:54 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:58:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:58:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:58:54 --> Encryption Class Initialized
INFO - 2020-04-07 14:58:54 --> Controller Class Initialized
DEBUG - 2020-04-07 14:58:54 --> schedule MX_Controller Initialized
INFO - 2020-04-07 14:58:54 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/models/schedule_model.php
INFO - 2020-04-07 14:58:54 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/schedule/views/index.php
DEBUG - 2020-04-07 14:58:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 14:58:54 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 14:58:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 14:58:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 14:58:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 14:58:54 --> Final output sent to browser
DEBUG - 2020-04-07 14:58:54 --> Total execution time: 0.5510
INFO - 2020-04-07 14:58:57 --> Config Class Initialized
INFO - 2020-04-07 14:58:57 --> Hooks Class Initialized
DEBUG - 2020-04-07 14:58:57 --> UTF-8 Support Enabled
INFO - 2020-04-07 14:58:57 --> Utf8 Class Initialized
INFO - 2020-04-07 14:58:57 --> URI Class Initialized
INFO - 2020-04-07 14:58:57 --> Router Class Initialized
INFO - 2020-04-07 14:58:57 --> Output Class Initialized
INFO - 2020-04-07 14:58:57 --> Security Class Initialized
DEBUG - 2020-04-07 14:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 14:58:57 --> CSRF cookie sent
INFO - 2020-04-07 14:58:57 --> Input Class Initialized
INFO - 2020-04-07 14:58:57 --> Language Class Initialized
INFO - 2020-04-07 14:58:57 --> Language Class Initialized
INFO - 2020-04-07 14:58:57 --> Config Class Initialized
INFO - 2020-04-07 14:58:57 --> Loader Class Initialized
INFO - 2020-04-07 14:58:57 --> Helper loaded: url_helper
INFO - 2020-04-07 14:58:57 --> Helper loaded: file_helper
INFO - 2020-04-07 14:58:57 --> Helper loaded: cookie_helper
INFO - 2020-04-07 14:58:57 --> Helper loaded: common_helper
INFO - 2020-04-07 14:58:57 --> Helper loaded: language_helper
INFO - 2020-04-07 14:58:57 --> Helper loaded: email_helper
INFO - 2020-04-07 14:58:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 14:58:57 --> Database Driver Class Initialized
INFO - 2020-04-07 14:58:57 --> Parser Class Initialized
INFO - 2020-04-07 14:58:57 --> User Agent Class Initialized
INFO - 2020-04-07 14:58:57 --> Model Class Initialized
INFO - 2020-04-07 14:58:57 --> Model Class Initialized
DEBUG - 2020-04-07 14:58:57 --> Template Class Initialized
INFO - 2020-04-07 14:58:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 14:58:57 --> Email Class Initialized
INFO - 2020-04-07 14:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 14:58:57 --> Pagination Class Initialized
DEBUG - 2020-04-07 14:58:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 14:58:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 14:58:57 --> Encryption Class Initialized
INFO - 2020-04-07 14:58:57 --> Controller Class Initialized
DEBUG - 2020-04-07 14:58:57 --> post MX_Controller Initialized
INFO - 2020-04-07 14:58:57 --> Model Class Initialized
ERROR - 2020-04-07 14:58:57 --> Could not find the language line ""
ERROR - 2020-04-07 14:58:57 --> Could not find the language line ""
ERROR - 2020-04-07 14:58:57 --> Could not find the language line ""
DEBUG - 2020-04-07 14:58:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-07 14:58:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 14:58:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 14:58:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 14:58:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 14:58:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 14:58:57 --> Final output sent to browser
DEBUG - 2020-04-07 14:58:57 --> Total execution time: 0.5364
INFO - 2020-04-07 15:00:11 --> Config Class Initialized
INFO - 2020-04-07 15:00:11 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:00:11 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:00:11 --> Utf8 Class Initialized
INFO - 2020-04-07 15:00:11 --> URI Class Initialized
INFO - 2020-04-07 15:00:11 --> Router Class Initialized
INFO - 2020-04-07 15:00:11 --> Output Class Initialized
INFO - 2020-04-07 15:00:11 --> Security Class Initialized
DEBUG - 2020-04-07 15:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:00:11 --> CSRF cookie sent
INFO - 2020-04-07 15:00:11 --> Input Class Initialized
INFO - 2020-04-07 15:00:11 --> Language Class Initialized
INFO - 2020-04-07 15:00:11 --> Language Class Initialized
INFO - 2020-04-07 15:00:11 --> Config Class Initialized
INFO - 2020-04-07 15:00:11 --> Loader Class Initialized
INFO - 2020-04-07 15:00:11 --> Helper loaded: url_helper
INFO - 2020-04-07 15:00:11 --> Helper loaded: file_helper
INFO - 2020-04-07 15:00:11 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:00:11 --> Helper loaded: common_helper
INFO - 2020-04-07 15:00:12 --> Helper loaded: language_helper
INFO - 2020-04-07 15:00:12 --> Helper loaded: email_helper
INFO - 2020-04-07 15:00:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:00:12 --> Database Driver Class Initialized
INFO - 2020-04-07 15:00:12 --> Parser Class Initialized
INFO - 2020-04-07 15:00:12 --> User Agent Class Initialized
INFO - 2020-04-07 15:00:12 --> Model Class Initialized
INFO - 2020-04-07 15:00:12 --> Model Class Initialized
DEBUG - 2020-04-07 15:00:12 --> Template Class Initialized
INFO - 2020-04-07 15:00:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:00:12 --> Email Class Initialized
INFO - 2020-04-07 15:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:00:12 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:00:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:00:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:00:12 --> Encryption Class Initialized
INFO - 2020-04-07 15:00:12 --> Controller Class Initialized
DEBUG - 2020-04-07 15:00:12 --> post MX_Controller Initialized
INFO - 2020-04-07 15:00:12 --> Model Class Initialized
ERROR - 2020-04-07 15:00:12 --> Could not find the language line ""
ERROR - 2020-04-07 15:00:12 --> Could not find the language line ""
ERROR - 2020-04-07 15:00:12 --> Could not find the language line ""
DEBUG - 2020-04-07 15:00:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/post/views/index.php
DEBUG - 2020-04-07 15:00:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:00:12 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:00:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:00:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:00:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:00:12 --> Final output sent to browser
DEBUG - 2020-04-07 15:00:12 --> Total execution time: 0.4972
INFO - 2020-04-07 15:00:46 --> Config Class Initialized
INFO - 2020-04-07 15:00:46 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:00:46 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:00:46 --> Utf8 Class Initialized
INFO - 2020-04-07 15:00:46 --> URI Class Initialized
INFO - 2020-04-07 15:00:46 --> Router Class Initialized
INFO - 2020-04-07 15:00:46 --> Output Class Initialized
INFO - 2020-04-07 15:00:46 --> Security Class Initialized
DEBUG - 2020-04-07 15:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:00:46 --> CSRF cookie sent
INFO - 2020-04-07 15:00:46 --> Input Class Initialized
INFO - 2020-04-07 15:00:46 --> Language Class Initialized
INFO - 2020-04-07 15:00:46 --> Language Class Initialized
INFO - 2020-04-07 15:00:46 --> Config Class Initialized
INFO - 2020-04-07 15:00:46 --> Loader Class Initialized
INFO - 2020-04-07 15:00:46 --> Helper loaded: url_helper
INFO - 2020-04-07 15:00:46 --> Helper loaded: file_helper
INFO - 2020-04-07 15:00:46 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:00:46 --> Helper loaded: common_helper
INFO - 2020-04-07 15:00:46 --> Helper loaded: language_helper
INFO - 2020-04-07 15:00:46 --> Helper loaded: email_helper
INFO - 2020-04-07 15:00:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:00:46 --> Database Driver Class Initialized
INFO - 2020-04-07 15:00:46 --> Parser Class Initialized
INFO - 2020-04-07 15:00:46 --> User Agent Class Initialized
INFO - 2020-04-07 15:00:46 --> Model Class Initialized
INFO - 2020-04-07 15:00:46 --> Model Class Initialized
DEBUG - 2020-04-07 15:00:46 --> Template Class Initialized
INFO - 2020-04-07 15:00:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:00:46 --> Email Class Initialized
INFO - 2020-04-07 15:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:00:46 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:00:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:00:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:00:46 --> Encryption Class Initialized
INFO - 2020-04-07 15:00:46 --> Controller Class Initialized
DEBUG - 2020-04-07 15:00:46 --> dashboard MX_Controller Initialized
INFO - 2020-04-07 15:00:46 --> Model Class Initialized
DEBUG - 2020-04-07 15:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-07 15:00:46 --> Model Class Initialized
INFO - 2020-04-07 15:00:46 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 15:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-07 15:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-07 15:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:00:46 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:00:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:00:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:00:47 --> Final output sent to browser
DEBUG - 2020-04-07 15:00:47 --> Total execution time: 0.6474
INFO - 2020-04-07 15:04:38 --> Config Class Initialized
INFO - 2020-04-07 15:04:38 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:04:38 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:04:38 --> Utf8 Class Initialized
INFO - 2020-04-07 15:04:38 --> URI Class Initialized
INFO - 2020-04-07 15:04:38 --> Router Class Initialized
INFO - 2020-04-07 15:04:38 --> Output Class Initialized
INFO - 2020-04-07 15:04:38 --> Security Class Initialized
DEBUG - 2020-04-07 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:04:38 --> CSRF cookie sent
INFO - 2020-04-07 15:04:38 --> Input Class Initialized
INFO - 2020-04-07 15:04:38 --> Language Class Initialized
INFO - 2020-04-07 15:04:38 --> Language Class Initialized
INFO - 2020-04-07 15:04:38 --> Config Class Initialized
INFO - 2020-04-07 15:04:38 --> Loader Class Initialized
INFO - 2020-04-07 15:04:38 --> Helper loaded: url_helper
INFO - 2020-04-07 15:04:38 --> Helper loaded: file_helper
INFO - 2020-04-07 15:04:38 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:04:38 --> Helper loaded: common_helper
INFO - 2020-04-07 15:04:38 --> Helper loaded: language_helper
INFO - 2020-04-07 15:04:38 --> Helper loaded: email_helper
INFO - 2020-04-07 15:04:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:04:38 --> Database Driver Class Initialized
INFO - 2020-04-07 15:04:38 --> Parser Class Initialized
INFO - 2020-04-07 15:04:38 --> User Agent Class Initialized
INFO - 2020-04-07 15:04:38 --> Model Class Initialized
INFO - 2020-04-07 15:04:38 --> Model Class Initialized
DEBUG - 2020-04-07 15:04:38 --> Template Class Initialized
INFO - 2020-04-07 15:04:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:04:38 --> Email Class Initialized
INFO - 2020-04-07 15:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:04:38 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:04:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:04:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:04:38 --> Encryption Class Initialized
INFO - 2020-04-07 15:04:38 --> Controller Class Initialized
DEBUG - 2020-04-07 15:04:38 --> dashboard MX_Controller Initialized
INFO - 2020-04-07 15:04:38 --> Model Class Initialized
DEBUG - 2020-04-07 15:04:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-07 15:04:38 --> Model Class Initialized
INFO - 2020-04-07 15:04:38 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 15:04:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-07 15:04:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-07 15:04:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:04:38 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:04:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:04:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:04:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:04:38 --> Final output sent to browser
DEBUG - 2020-04-07 15:04:38 --> Total execution time: 0.6474
INFO - 2020-04-07 15:06:14 --> Config Class Initialized
INFO - 2020-04-07 15:06:14 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:06:14 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:06:14 --> Utf8 Class Initialized
INFO - 2020-04-07 15:06:14 --> URI Class Initialized
INFO - 2020-04-07 15:06:14 --> Router Class Initialized
INFO - 2020-04-07 15:06:14 --> Output Class Initialized
INFO - 2020-04-07 15:06:14 --> Security Class Initialized
DEBUG - 2020-04-07 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:06:14 --> CSRF cookie sent
INFO - 2020-04-07 15:06:14 --> Input Class Initialized
INFO - 2020-04-07 15:06:14 --> Language Class Initialized
INFO - 2020-04-07 15:06:14 --> Language Class Initialized
INFO - 2020-04-07 15:06:14 --> Config Class Initialized
INFO - 2020-04-07 15:06:14 --> Loader Class Initialized
INFO - 2020-04-07 15:06:14 --> Helper loaded: url_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: file_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: common_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: language_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: email_helper
INFO - 2020-04-07 15:06:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:06:14 --> Database Driver Class Initialized
INFO - 2020-04-07 15:06:14 --> Parser Class Initialized
INFO - 2020-04-07 15:06:14 --> User Agent Class Initialized
INFO - 2020-04-07 15:06:14 --> Model Class Initialized
INFO - 2020-04-07 15:06:14 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:14 --> Template Class Initialized
INFO - 2020-04-07 15:06:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:06:14 --> Email Class Initialized
INFO - 2020-04-07 15:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:06:14 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:06:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:06:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:06:14 --> Encryption Class Initialized
INFO - 2020-04-07 15:06:14 --> Controller Class Initialized
DEBUG - 2020-04-07 15:06:14 --> auth MX_Controller Initialized
INFO - 2020-04-07 15:06:14 --> Model Class Initialized
INFO - 2020-04-07 15:06:14 --> Config Class Initialized
INFO - 2020-04-07 15:06:14 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:06:14 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:06:14 --> Utf8 Class Initialized
INFO - 2020-04-07 15:06:14 --> URI Class Initialized
DEBUG - 2020-04-07 15:06:14 --> No URI present. Default controller set.
INFO - 2020-04-07 15:06:14 --> Router Class Initialized
INFO - 2020-04-07 15:06:14 --> Output Class Initialized
INFO - 2020-04-07 15:06:14 --> Security Class Initialized
DEBUG - 2020-04-07 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:06:14 --> CSRF cookie sent
INFO - 2020-04-07 15:06:14 --> Input Class Initialized
INFO - 2020-04-07 15:06:14 --> Language Class Initialized
INFO - 2020-04-07 15:06:14 --> Language Class Initialized
INFO - 2020-04-07 15:06:14 --> Config Class Initialized
INFO - 2020-04-07 15:06:14 --> Loader Class Initialized
INFO - 2020-04-07 15:06:14 --> Helper loaded: url_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: file_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: common_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: language_helper
INFO - 2020-04-07 15:06:14 --> Helper loaded: email_helper
INFO - 2020-04-07 15:06:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:06:14 --> Database Driver Class Initialized
INFO - 2020-04-07 15:06:14 --> Parser Class Initialized
INFO - 2020-04-07 15:06:14 --> User Agent Class Initialized
INFO - 2020-04-07 15:06:14 --> Model Class Initialized
INFO - 2020-04-07 15:06:14 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:14 --> Template Class Initialized
INFO - 2020-04-07 15:06:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:06:14 --> Email Class Initialized
INFO - 2020-04-07 15:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:06:14 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:06:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:06:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:06:15 --> Encryption Class Initialized
INFO - 2020-04-07 15:06:15 --> Controller Class Initialized
DEBUG - 2020-04-07 15:06:15 --> home MX_Controller Initialized
INFO - 2020-04-07 15:06:15 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 15:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 15:06:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 15:06:15 --> Final output sent to browser
DEBUG - 2020-04-07 15:06:15 --> Total execution time: 0.4984
INFO - 2020-04-07 15:06:17 --> Config Class Initialized
INFO - 2020-04-07 15:06:17 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:06:17 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:06:17 --> Utf8 Class Initialized
INFO - 2020-04-07 15:06:17 --> URI Class Initialized
DEBUG - 2020-04-07 15:06:17 --> No URI present. Default controller set.
INFO - 2020-04-07 15:06:17 --> Router Class Initialized
INFO - 2020-04-07 15:06:17 --> Output Class Initialized
INFO - 2020-04-07 15:06:17 --> Security Class Initialized
DEBUG - 2020-04-07 15:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:06:17 --> CSRF cookie sent
INFO - 2020-04-07 15:06:17 --> Input Class Initialized
INFO - 2020-04-07 15:06:17 --> Language Class Initialized
INFO - 2020-04-07 15:06:17 --> Language Class Initialized
INFO - 2020-04-07 15:06:17 --> Config Class Initialized
INFO - 2020-04-07 15:06:17 --> Loader Class Initialized
INFO - 2020-04-07 15:06:17 --> Helper loaded: url_helper
INFO - 2020-04-07 15:06:17 --> Helper loaded: file_helper
INFO - 2020-04-07 15:06:17 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:06:17 --> Helper loaded: common_helper
INFO - 2020-04-07 15:06:17 --> Helper loaded: language_helper
INFO - 2020-04-07 15:06:17 --> Helper loaded: email_helper
INFO - 2020-04-07 15:06:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:06:17 --> Database Driver Class Initialized
INFO - 2020-04-07 15:06:17 --> Parser Class Initialized
INFO - 2020-04-07 15:06:17 --> User Agent Class Initialized
INFO - 2020-04-07 15:06:17 --> Model Class Initialized
INFO - 2020-04-07 15:06:17 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:17 --> Template Class Initialized
INFO - 2020-04-07 15:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:06:17 --> Email Class Initialized
INFO - 2020-04-07 15:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:06:17 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:06:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:06:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:06:17 --> Encryption Class Initialized
INFO - 2020-04-07 15:06:17 --> Controller Class Initialized
DEBUG - 2020-04-07 15:06:17 --> home MX_Controller Initialized
INFO - 2020-04-07 15:06:17 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 15:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 15:06:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 15:06:17 --> Final output sent to browser
DEBUG - 2020-04-07 15:06:17 --> Total execution time: 0.7594
INFO - 2020-04-07 15:06:24 --> Config Class Initialized
INFO - 2020-04-07 15:06:24 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:06:24 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:06:24 --> Utf8 Class Initialized
INFO - 2020-04-07 15:06:24 --> URI Class Initialized
INFO - 2020-04-07 15:06:24 --> Router Class Initialized
INFO - 2020-04-07 15:06:24 --> Output Class Initialized
INFO - 2020-04-07 15:06:24 --> Security Class Initialized
DEBUG - 2020-04-07 15:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:06:24 --> CSRF cookie sent
INFO - 2020-04-07 15:06:24 --> Input Class Initialized
INFO - 2020-04-07 15:06:24 --> Language Class Initialized
INFO - 2020-04-07 15:06:24 --> Language Class Initialized
INFO - 2020-04-07 15:06:24 --> Config Class Initialized
INFO - 2020-04-07 15:06:25 --> Loader Class Initialized
INFO - 2020-04-07 15:06:25 --> Helper loaded: url_helper
INFO - 2020-04-07 15:06:25 --> Helper loaded: file_helper
INFO - 2020-04-07 15:06:25 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:06:25 --> Helper loaded: common_helper
INFO - 2020-04-07 15:06:25 --> Helper loaded: language_helper
INFO - 2020-04-07 15:06:25 --> Helper loaded: email_helper
INFO - 2020-04-07 15:06:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:06:25 --> Database Driver Class Initialized
INFO - 2020-04-07 15:06:25 --> Parser Class Initialized
INFO - 2020-04-07 15:06:25 --> User Agent Class Initialized
INFO - 2020-04-07 15:06:25 --> Model Class Initialized
INFO - 2020-04-07 15:06:25 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:25 --> Template Class Initialized
INFO - 2020-04-07 15:06:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:06:25 --> Email Class Initialized
INFO - 2020-04-07 15:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:06:25 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:06:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:06:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:06:25 --> Encryption Class Initialized
INFO - 2020-04-07 15:06:25 --> Controller Class Initialized
DEBUG - 2020-04-07 15:06:25 --> auth MX_Controller Initialized
INFO - 2020-04-07 15:06:25 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 15:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-07 15:06:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-07 15:06:25 --> Final output sent to browser
DEBUG - 2020-04-07 15:06:25 --> Total execution time: 1.1465
INFO - 2020-04-07 15:06:27 --> Config Class Initialized
INFO - 2020-04-07 15:06:27 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:06:27 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:06:27 --> Utf8 Class Initialized
INFO - 2020-04-07 15:06:27 --> URI Class Initialized
INFO - 2020-04-07 15:06:27 --> Router Class Initialized
INFO - 2020-04-07 15:06:27 --> Output Class Initialized
INFO - 2020-04-07 15:06:27 --> Security Class Initialized
DEBUG - 2020-04-07 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:06:27 --> CSRF cookie sent
INFO - 2020-04-07 15:06:27 --> CSRF token verified
INFO - 2020-04-07 15:06:27 --> Input Class Initialized
INFO - 2020-04-07 15:06:27 --> Language Class Initialized
INFO - 2020-04-07 15:06:27 --> Language Class Initialized
INFO - 2020-04-07 15:06:27 --> Config Class Initialized
INFO - 2020-04-07 15:06:27 --> Loader Class Initialized
INFO - 2020-04-07 15:06:27 --> Helper loaded: url_helper
INFO - 2020-04-07 15:06:27 --> Helper loaded: file_helper
INFO - 2020-04-07 15:06:27 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:06:27 --> Helper loaded: common_helper
INFO - 2020-04-07 15:06:27 --> Helper loaded: language_helper
INFO - 2020-04-07 15:06:27 --> Helper loaded: email_helper
INFO - 2020-04-07 15:06:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:06:27 --> Database Driver Class Initialized
INFO - 2020-04-07 15:06:27 --> Parser Class Initialized
INFO - 2020-04-07 15:06:27 --> User Agent Class Initialized
INFO - 2020-04-07 15:06:27 --> Model Class Initialized
INFO - 2020-04-07 15:06:27 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:27 --> Template Class Initialized
INFO - 2020-04-07 15:06:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:06:27 --> Email Class Initialized
INFO - 2020-04-07 15:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:06:27 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:06:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:06:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:06:27 --> Encryption Class Initialized
INFO - 2020-04-07 15:06:27 --> Controller Class Initialized
DEBUG - 2020-04-07 15:06:27 --> auth MX_Controller Initialized
INFO - 2020-04-07 15:06:29 --> Config Class Initialized
INFO - 2020-04-07 15:06:29 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:06:29 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:06:29 --> Utf8 Class Initialized
INFO - 2020-04-07 15:06:29 --> URI Class Initialized
INFO - 2020-04-07 15:06:29 --> Router Class Initialized
INFO - 2020-04-07 15:06:29 --> Output Class Initialized
INFO - 2020-04-07 15:06:30 --> Security Class Initialized
DEBUG - 2020-04-07 15:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:06:30 --> CSRF cookie sent
INFO - 2020-04-07 15:06:30 --> Input Class Initialized
INFO - 2020-04-07 15:06:30 --> Language Class Initialized
INFO - 2020-04-07 15:06:30 --> Language Class Initialized
INFO - 2020-04-07 15:06:30 --> Config Class Initialized
INFO - 2020-04-07 15:06:30 --> Loader Class Initialized
INFO - 2020-04-07 15:06:30 --> Helper loaded: url_helper
INFO - 2020-04-07 15:06:30 --> Helper loaded: file_helper
INFO - 2020-04-07 15:06:30 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:06:30 --> Helper loaded: common_helper
INFO - 2020-04-07 15:06:30 --> Helper loaded: language_helper
INFO - 2020-04-07 15:06:30 --> Helper loaded: email_helper
INFO - 2020-04-07 15:06:30 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:06:30 --> Database Driver Class Initialized
INFO - 2020-04-07 15:06:30 --> Parser Class Initialized
INFO - 2020-04-07 15:06:30 --> User Agent Class Initialized
INFO - 2020-04-07 15:06:30 --> Model Class Initialized
INFO - 2020-04-07 15:06:30 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:30 --> Template Class Initialized
INFO - 2020-04-07 15:06:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:06:30 --> Email Class Initialized
INFO - 2020-04-07 15:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:06:30 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:06:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:06:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:06:30 --> Encryption Class Initialized
INFO - 2020-04-07 15:06:30 --> Controller Class Initialized
DEBUG - 2020-04-07 15:06:30 --> dashboard MX_Controller Initialized
INFO - 2020-04-07 15:06:30 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-07 15:06:30 --> Model Class Initialized
INFO - 2020-04-07 15:06:30 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 15:06:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-07 15:06:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-07 15:06:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:06:30 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:06:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:06:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:06:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:06:30 --> Final output sent to browser
DEBUG - 2020-04-07 15:06:30 --> Total execution time: 0.6319
INFO - 2020-04-07 15:06:40 --> Config Class Initialized
INFO - 2020-04-07 15:06:40 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:06:40 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:06:40 --> Utf8 Class Initialized
INFO - 2020-04-07 15:06:40 --> URI Class Initialized
INFO - 2020-04-07 15:06:40 --> Router Class Initialized
INFO - 2020-04-07 15:06:40 --> Output Class Initialized
INFO - 2020-04-07 15:06:40 --> Security Class Initialized
DEBUG - 2020-04-07 15:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:06:40 --> CSRF cookie sent
INFO - 2020-04-07 15:06:40 --> Input Class Initialized
INFO - 2020-04-07 15:06:40 --> Language Class Initialized
INFO - 2020-04-07 15:06:40 --> Language Class Initialized
INFO - 2020-04-07 15:06:40 --> Config Class Initialized
INFO - 2020-04-07 15:06:40 --> Loader Class Initialized
INFO - 2020-04-07 15:06:40 --> Helper loaded: url_helper
INFO - 2020-04-07 15:06:40 --> Helper loaded: file_helper
INFO - 2020-04-07 15:06:40 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:06:40 --> Helper loaded: common_helper
INFO - 2020-04-07 15:06:40 --> Helper loaded: language_helper
INFO - 2020-04-07 15:06:40 --> Helper loaded: email_helper
INFO - 2020-04-07 15:06:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:06:40 --> Database Driver Class Initialized
INFO - 2020-04-07 15:06:40 --> Parser Class Initialized
INFO - 2020-04-07 15:06:40 --> User Agent Class Initialized
INFO - 2020-04-07 15:06:40 --> Model Class Initialized
INFO - 2020-04-07 15:06:40 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:40 --> Template Class Initialized
INFO - 2020-04-07 15:06:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:06:40 --> Email Class Initialized
INFO - 2020-04-07 15:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:06:40 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:06:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:06:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:06:40 --> Encryption Class Initialized
INFO - 2020-04-07 15:06:40 --> Controller Class Initialized
DEBUG - 2020-04-07 15:06:40 --> twitter MX_Controller Initialized
INFO - 2020-04-07 15:06:40 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 15:06:40 --> Model Class Initialized
DEBUG - 2020-04-07 15:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-07 15:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:06:40 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:06:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:06:40 --> Final output sent to browser
DEBUG - 2020-04-07 15:06:40 --> Total execution time: 0.5622
INFO - 2020-04-07 15:10:34 --> Config Class Initialized
INFO - 2020-04-07 15:10:34 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:10:34 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:10:34 --> Utf8 Class Initialized
INFO - 2020-04-07 15:10:34 --> URI Class Initialized
INFO - 2020-04-07 15:10:34 --> Router Class Initialized
INFO - 2020-04-07 15:10:34 --> Output Class Initialized
INFO - 2020-04-07 15:10:34 --> Security Class Initialized
DEBUG - 2020-04-07 15:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:10:34 --> CSRF cookie sent
INFO - 2020-04-07 15:10:34 --> Input Class Initialized
INFO - 2020-04-07 15:10:34 --> Language Class Initialized
INFO - 2020-04-07 15:10:34 --> Language Class Initialized
INFO - 2020-04-07 15:10:34 --> Config Class Initialized
INFO - 2020-04-07 15:10:34 --> Loader Class Initialized
INFO - 2020-04-07 15:10:34 --> Helper loaded: url_helper
INFO - 2020-04-07 15:10:34 --> Helper loaded: file_helper
INFO - 2020-04-07 15:10:34 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:10:34 --> Helper loaded: common_helper
INFO - 2020-04-07 15:10:34 --> Helper loaded: language_helper
INFO - 2020-04-07 15:10:34 --> Helper loaded: email_helper
INFO - 2020-04-07 15:10:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:10:34 --> Database Driver Class Initialized
INFO - 2020-04-07 15:10:34 --> Parser Class Initialized
INFO - 2020-04-07 15:10:34 --> User Agent Class Initialized
INFO - 2020-04-07 15:10:34 --> Model Class Initialized
INFO - 2020-04-07 15:10:34 --> Model Class Initialized
DEBUG - 2020-04-07 15:10:34 --> Template Class Initialized
INFO - 2020-04-07 15:10:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:10:34 --> Email Class Initialized
INFO - 2020-04-07 15:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:10:34 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:10:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:10:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:10:34 --> Encryption Class Initialized
INFO - 2020-04-07 15:10:34 --> Controller Class Initialized
DEBUG - 2020-04-07 15:10:34 --> twitter MX_Controller Initialized
INFO - 2020-04-07 15:10:34 --> Model Class Initialized
DEBUG - 2020-04-07 15:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 15:10:34 --> Model Class Initialized
DEBUG - 2020-04-07 15:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-07 15:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:10:34 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:10:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:10:34 --> Final output sent to browser
DEBUG - 2020-04-07 15:10:34 --> Total execution time: 0.5842
INFO - 2020-04-07 15:11:13 --> Config Class Initialized
INFO - 2020-04-07 15:11:13 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:11:13 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:11:13 --> Utf8 Class Initialized
INFO - 2020-04-07 15:11:13 --> URI Class Initialized
INFO - 2020-04-07 15:11:13 --> Router Class Initialized
INFO - 2020-04-07 15:11:13 --> Output Class Initialized
INFO - 2020-04-07 15:11:13 --> Security Class Initialized
DEBUG - 2020-04-07 15:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:11:13 --> CSRF cookie sent
INFO - 2020-04-07 15:11:13 --> Input Class Initialized
INFO - 2020-04-07 15:11:13 --> Language Class Initialized
INFO - 2020-04-07 15:11:13 --> Language Class Initialized
INFO - 2020-04-07 15:11:13 --> Config Class Initialized
INFO - 2020-04-07 15:11:13 --> Loader Class Initialized
INFO - 2020-04-07 15:11:13 --> Helper loaded: url_helper
INFO - 2020-04-07 15:11:13 --> Helper loaded: file_helper
INFO - 2020-04-07 15:11:13 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:11:13 --> Helper loaded: common_helper
INFO - 2020-04-07 15:11:13 --> Helper loaded: language_helper
INFO - 2020-04-07 15:11:13 --> Helper loaded: email_helper
INFO - 2020-04-07 15:11:13 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:11:13 --> Database Driver Class Initialized
INFO - 2020-04-07 15:11:13 --> Parser Class Initialized
INFO - 2020-04-07 15:11:13 --> User Agent Class Initialized
INFO - 2020-04-07 15:11:13 --> Model Class Initialized
INFO - 2020-04-07 15:11:13 --> Model Class Initialized
DEBUG - 2020-04-07 15:11:13 --> Template Class Initialized
INFO - 2020-04-07 15:11:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:11:14 --> Email Class Initialized
INFO - 2020-04-07 15:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:11:14 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:11:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:11:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:11:14 --> Encryption Class Initialized
INFO - 2020-04-07 15:11:14 --> Controller Class Initialized
DEBUG - 2020-04-07 15:11:14 --> settings MX_Controller Initialized
INFO - 2020-04-07 15:11:14 --> Model Class Initialized
INFO - 2020-04-07 15:11:14 --> Config Class Initialized
INFO - 2020-04-07 15:11:14 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:11:14 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:11:14 --> Utf8 Class Initialized
INFO - 2020-04-07 15:11:14 --> URI Class Initialized
INFO - 2020-04-07 15:11:14 --> Router Class Initialized
INFO - 2020-04-07 15:11:14 --> Output Class Initialized
INFO - 2020-04-07 15:11:14 --> Security Class Initialized
DEBUG - 2020-04-07 15:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:11:14 --> CSRF cookie sent
INFO - 2020-04-07 15:11:14 --> Input Class Initialized
INFO - 2020-04-07 15:11:14 --> Language Class Initialized
INFO - 2020-04-07 15:11:14 --> Language Class Initialized
INFO - 2020-04-07 15:11:14 --> Config Class Initialized
INFO - 2020-04-07 15:11:14 --> Loader Class Initialized
INFO - 2020-04-07 15:11:14 --> Helper loaded: url_helper
INFO - 2020-04-07 15:11:14 --> Helper loaded: file_helper
INFO - 2020-04-07 15:11:14 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:11:14 --> Helper loaded: common_helper
INFO - 2020-04-07 15:11:14 --> Helper loaded: language_helper
INFO - 2020-04-07 15:11:14 --> Helper loaded: email_helper
INFO - 2020-04-07 15:11:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:11:14 --> Database Driver Class Initialized
INFO - 2020-04-07 15:11:14 --> Parser Class Initialized
INFO - 2020-04-07 15:11:14 --> User Agent Class Initialized
INFO - 2020-04-07 15:11:14 --> Model Class Initialized
INFO - 2020-04-07 15:11:14 --> Model Class Initialized
DEBUG - 2020-04-07 15:11:14 --> Template Class Initialized
INFO - 2020-04-07 15:11:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:11:14 --> Email Class Initialized
INFO - 2020-04-07 15:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:11:14 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:11:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:11:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:11:14 --> Encryption Class Initialized
INFO - 2020-04-07 15:11:14 --> Controller Class Initialized
DEBUG - 2020-04-07 15:11:14 --> settings MX_Controller Initialized
INFO - 2020-04-07 15:11:14 --> Model Class Initialized
INFO - 2020-04-07 15:11:14 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 15:11:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-07 15:11:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-07 15:11:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:11:14 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:11:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:11:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:11:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:11:14 --> Final output sent to browser
DEBUG - 2020-04-07 15:11:14 --> Total execution time: 0.6466
INFO - 2020-04-07 15:11:19 --> Config Class Initialized
INFO - 2020-04-07 15:11:19 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:11:19 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:11:19 --> Utf8 Class Initialized
INFO - 2020-04-07 15:11:19 --> URI Class Initialized
INFO - 2020-04-07 15:11:19 --> Router Class Initialized
INFO - 2020-04-07 15:11:19 --> Output Class Initialized
INFO - 2020-04-07 15:11:19 --> Security Class Initialized
DEBUG - 2020-04-07 15:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:11:19 --> CSRF cookie sent
INFO - 2020-04-07 15:11:19 --> Input Class Initialized
INFO - 2020-04-07 15:11:19 --> Language Class Initialized
INFO - 2020-04-07 15:11:19 --> Language Class Initialized
INFO - 2020-04-07 15:11:19 --> Config Class Initialized
INFO - 2020-04-07 15:11:19 --> Loader Class Initialized
INFO - 2020-04-07 15:11:19 --> Helper loaded: url_helper
INFO - 2020-04-07 15:11:19 --> Helper loaded: file_helper
INFO - 2020-04-07 15:11:19 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:11:19 --> Helper loaded: common_helper
INFO - 2020-04-07 15:11:19 --> Helper loaded: language_helper
INFO - 2020-04-07 15:11:19 --> Helper loaded: email_helper
INFO - 2020-04-07 15:11:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:11:19 --> Database Driver Class Initialized
INFO - 2020-04-07 15:11:19 --> Parser Class Initialized
INFO - 2020-04-07 15:11:19 --> User Agent Class Initialized
INFO - 2020-04-07 15:11:19 --> Model Class Initialized
INFO - 2020-04-07 15:11:19 --> Model Class Initialized
DEBUG - 2020-04-07 15:11:19 --> Template Class Initialized
INFO - 2020-04-07 15:11:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:11:19 --> Email Class Initialized
INFO - 2020-04-07 15:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:11:19 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:11:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:11:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:11:19 --> Encryption Class Initialized
INFO - 2020-04-07 15:11:19 --> Controller Class Initialized
DEBUG - 2020-04-07 15:11:19 --> settings MX_Controller Initialized
INFO - 2020-04-07 15:11:19 --> Model Class Initialized
INFO - 2020-04-07 15:11:19 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 15:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/twitter.php
DEBUG - 2020-04-07 15:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-07 15:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:11:19 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:11:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:11:19 --> Final output sent to browser
DEBUG - 2020-04-07 15:11:19 --> Total execution time: 0.6221
INFO - 2020-04-07 15:20:28 --> Config Class Initialized
INFO - 2020-04-07 15:20:28 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:20:28 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:20:28 --> Utf8 Class Initialized
INFO - 2020-04-07 15:20:28 --> URI Class Initialized
INFO - 2020-04-07 15:20:28 --> Router Class Initialized
INFO - 2020-04-07 15:20:28 --> Output Class Initialized
INFO - 2020-04-07 15:20:28 --> Security Class Initialized
DEBUG - 2020-04-07 15:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:20:28 --> CSRF cookie sent
INFO - 2020-04-07 15:20:28 --> Input Class Initialized
INFO - 2020-04-07 15:20:28 --> Language Class Initialized
INFO - 2020-04-07 15:20:28 --> Language Class Initialized
INFO - 2020-04-07 15:20:28 --> Config Class Initialized
INFO - 2020-04-07 15:20:28 --> Loader Class Initialized
INFO - 2020-04-07 15:20:28 --> Helper loaded: url_helper
INFO - 2020-04-07 15:20:28 --> Helper loaded: file_helper
INFO - 2020-04-07 15:20:28 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:20:28 --> Helper loaded: common_helper
INFO - 2020-04-07 15:20:28 --> Helper loaded: language_helper
INFO - 2020-04-07 15:20:28 --> Helper loaded: email_helper
INFO - 2020-04-07 15:20:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:20:28 --> Database Driver Class Initialized
INFO - 2020-04-07 15:20:28 --> Parser Class Initialized
INFO - 2020-04-07 15:20:28 --> User Agent Class Initialized
INFO - 2020-04-07 15:20:29 --> Model Class Initialized
INFO - 2020-04-07 15:20:29 --> Model Class Initialized
DEBUG - 2020-04-07 15:20:29 --> Template Class Initialized
INFO - 2020-04-07 15:20:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:20:29 --> Email Class Initialized
INFO - 2020-04-07 15:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:20:29 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:20:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:20:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:20:29 --> Encryption Class Initialized
INFO - 2020-04-07 15:20:29 --> Controller Class Initialized
DEBUG - 2020-04-07 15:20:29 --> twitter MX_Controller Initialized
INFO - 2020-04-07 15:20:29 --> Model Class Initialized
DEBUG - 2020-04-07 15:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 15:20:29 --> Model Class Initialized
DEBUG - 2020-04-07 15:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-07 15:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:20:29 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:20:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:20:29 --> Final output sent to browser
DEBUG - 2020-04-07 15:20:29 --> Total execution time: 0.6263
INFO - 2020-04-07 15:20:58 --> Config Class Initialized
INFO - 2020-04-07 15:20:58 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:20:58 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:20:58 --> Utf8 Class Initialized
INFO - 2020-04-07 15:20:58 --> URI Class Initialized
INFO - 2020-04-07 15:20:58 --> Router Class Initialized
INFO - 2020-04-07 15:20:58 --> Output Class Initialized
INFO - 2020-04-07 15:20:58 --> Security Class Initialized
DEBUG - 2020-04-07 15:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:20:58 --> CSRF cookie sent
INFO - 2020-04-07 15:20:58 --> Input Class Initialized
INFO - 2020-04-07 15:20:58 --> Language Class Initialized
INFO - 2020-04-07 15:20:58 --> Language Class Initialized
INFO - 2020-04-07 15:20:58 --> Config Class Initialized
INFO - 2020-04-07 15:20:58 --> Loader Class Initialized
INFO - 2020-04-07 15:20:58 --> Helper loaded: url_helper
INFO - 2020-04-07 15:20:58 --> Helper loaded: file_helper
INFO - 2020-04-07 15:20:58 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:20:58 --> Helper loaded: common_helper
INFO - 2020-04-07 15:20:58 --> Helper loaded: language_helper
INFO - 2020-04-07 15:20:58 --> Helper loaded: email_helper
INFO - 2020-04-07 15:20:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:20:58 --> Database Driver Class Initialized
INFO - 2020-04-07 15:20:58 --> Parser Class Initialized
INFO - 2020-04-07 15:20:58 --> User Agent Class Initialized
INFO - 2020-04-07 15:20:58 --> Model Class Initialized
INFO - 2020-04-07 15:20:58 --> Model Class Initialized
DEBUG - 2020-04-07 15:20:58 --> Template Class Initialized
INFO - 2020-04-07 15:20:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:20:58 --> Email Class Initialized
INFO - 2020-04-07 15:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:20:58 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:20:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:20:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:20:58 --> Encryption Class Initialized
INFO - 2020-04-07 15:20:58 --> Controller Class Initialized
DEBUG - 2020-04-07 15:20:58 --> twitter MX_Controller Initialized
INFO - 2020-04-07 15:20:58 --> Model Class Initialized
DEBUG - 2020-04-07 15:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 15:20:58 --> Model Class Initialized
DEBUG - 2020-04-07 15:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-07 15:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:20:58 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:20:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:20:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:20:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:20:59 --> Final output sent to browser
DEBUG - 2020-04-07 15:20:59 --> Total execution time: 0.5586
INFO - 2020-04-07 15:21:06 --> Config Class Initialized
INFO - 2020-04-07 15:21:06 --> Config Class Initialized
INFO - 2020-04-07 15:21:06 --> Hooks Class Initialized
INFO - 2020-04-07 15:21:06 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 15:21:06 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:21:06 --> Utf8 Class Initialized
INFO - 2020-04-07 15:21:06 --> Utf8 Class Initialized
INFO - 2020-04-07 15:21:06 --> URI Class Initialized
INFO - 2020-04-07 15:21:06 --> URI Class Initialized
INFO - 2020-04-07 15:21:06 --> Router Class Initialized
INFO - 2020-04-07 15:21:06 --> Router Class Initialized
INFO - 2020-04-07 15:21:06 --> Output Class Initialized
INFO - 2020-04-07 15:21:06 --> Output Class Initialized
INFO - 2020-04-07 15:21:06 --> Security Class Initialized
INFO - 2020-04-07 15:21:06 --> Security Class Initialized
DEBUG - 2020-04-07 15:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 15:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:21:06 --> CSRF cookie sent
INFO - 2020-04-07 15:21:06 --> CSRF cookie sent
INFO - 2020-04-07 15:21:06 --> Input Class Initialized
INFO - 2020-04-07 15:21:06 --> Input Class Initialized
INFO - 2020-04-07 15:21:06 --> Language Class Initialized
INFO - 2020-04-07 15:21:06 --> Language Class Initialized
ERROR - 2020-04-07 15:21:07 --> 404 Page Not Found: /index
ERROR - 2020-04-07 15:21:07 --> 404 Page Not Found: /index
INFO - 2020-04-07 15:21:56 --> Config Class Initialized
INFO - 2020-04-07 15:21:56 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:21:56 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:21:56 --> Utf8 Class Initialized
INFO - 2020-04-07 15:21:56 --> URI Class Initialized
INFO - 2020-04-07 15:21:56 --> Router Class Initialized
INFO - 2020-04-07 15:21:56 --> Output Class Initialized
INFO - 2020-04-07 15:21:56 --> Security Class Initialized
DEBUG - 2020-04-07 15:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:21:56 --> CSRF cookie sent
INFO - 2020-04-07 15:21:56 --> Input Class Initialized
INFO - 2020-04-07 15:21:56 --> Language Class Initialized
INFO - 2020-04-07 15:21:56 --> Language Class Initialized
INFO - 2020-04-07 15:21:56 --> Config Class Initialized
INFO - 2020-04-07 15:21:56 --> Loader Class Initialized
INFO - 2020-04-07 15:21:56 --> Helper loaded: url_helper
INFO - 2020-04-07 15:21:56 --> Helper loaded: file_helper
INFO - 2020-04-07 15:21:56 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:21:56 --> Helper loaded: common_helper
INFO - 2020-04-07 15:21:56 --> Helper loaded: language_helper
INFO - 2020-04-07 15:21:56 --> Helper loaded: email_helper
INFO - 2020-04-07 15:21:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:21:56 --> Database Driver Class Initialized
INFO - 2020-04-07 15:21:57 --> Parser Class Initialized
INFO - 2020-04-07 15:21:57 --> User Agent Class Initialized
INFO - 2020-04-07 15:21:57 --> Model Class Initialized
INFO - 2020-04-07 15:21:57 --> Model Class Initialized
DEBUG - 2020-04-07 15:21:57 --> Template Class Initialized
INFO - 2020-04-07 15:21:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:21:57 --> Email Class Initialized
INFO - 2020-04-07 15:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:21:57 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:21:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:21:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:21:57 --> Encryption Class Initialized
INFO - 2020-04-07 15:21:57 --> Controller Class Initialized
DEBUG - 2020-04-07 15:21:57 --> twitter MX_Controller Initialized
INFO - 2020-04-07 15:21:57 --> Model Class Initialized
DEBUG - 2020-04-07 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 15:21:57 --> Model Class Initialized
DEBUG - 2020-04-07 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-07 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 15:21:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 15:21:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 15:21:57 --> Final output sent to browser
DEBUG - 2020-04-07 15:21:57 --> Total execution time: 0.7230
INFO - 2020-04-07 15:21:57 --> Config Class Initialized
INFO - 2020-04-07 15:21:57 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:21:57 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:21:57 --> Utf8 Class Initialized
INFO - 2020-04-07 15:21:57 --> URI Class Initialized
INFO - 2020-04-07 15:21:57 --> Router Class Initialized
INFO - 2020-04-07 15:21:57 --> Output Class Initialized
INFO - 2020-04-07 15:21:57 --> Security Class Initialized
DEBUG - 2020-04-07 15:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:21:57 --> CSRF cookie sent
INFO - 2020-04-07 15:21:57 --> Input Class Initialized
INFO - 2020-04-07 15:21:57 --> Config Class Initialized
INFO - 2020-04-07 15:21:57 --> Hooks Class Initialized
INFO - 2020-04-07 15:21:57 --> Language Class Initialized
ERROR - 2020-04-07 15:21:57 --> 404 Page Not Found: /index
DEBUG - 2020-04-07 15:21:57 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:21:57 --> Utf8 Class Initialized
INFO - 2020-04-07 15:21:57 --> URI Class Initialized
INFO - 2020-04-07 15:21:57 --> Router Class Initialized
INFO - 2020-04-07 15:21:57 --> Output Class Initialized
INFO - 2020-04-07 15:21:57 --> Security Class Initialized
DEBUG - 2020-04-07 15:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:21:58 --> CSRF cookie sent
INFO - 2020-04-07 15:21:58 --> Input Class Initialized
INFO - 2020-04-07 15:21:58 --> Language Class Initialized
ERROR - 2020-04-07 15:21:58 --> 404 Page Not Found: /index
INFO - 2020-04-07 15:22:05 --> Config Class Initialized
INFO - 2020-04-07 15:22:05 --> Hooks Class Initialized
DEBUG - 2020-04-07 15:22:05 --> UTF-8 Support Enabled
INFO - 2020-04-07 15:22:05 --> Utf8 Class Initialized
INFO - 2020-04-07 15:22:05 --> URI Class Initialized
INFO - 2020-04-07 15:22:05 --> Router Class Initialized
INFO - 2020-04-07 15:22:05 --> Output Class Initialized
INFO - 2020-04-07 15:22:05 --> Security Class Initialized
DEBUG - 2020-04-07 15:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 15:22:05 --> CSRF cookie sent
INFO - 2020-04-07 15:22:05 --> Input Class Initialized
INFO - 2020-04-07 15:22:05 --> Language Class Initialized
INFO - 2020-04-07 15:22:05 --> Language Class Initialized
INFO - 2020-04-07 15:22:05 --> Config Class Initialized
INFO - 2020-04-07 15:22:05 --> Loader Class Initialized
INFO - 2020-04-07 15:22:05 --> Helper loaded: url_helper
INFO - 2020-04-07 15:22:05 --> Helper loaded: file_helper
INFO - 2020-04-07 15:22:05 --> Helper loaded: cookie_helper
INFO - 2020-04-07 15:22:05 --> Helper loaded: common_helper
INFO - 2020-04-07 15:22:05 --> Helper loaded: language_helper
INFO - 2020-04-07 15:22:05 --> Helper loaded: email_helper
INFO - 2020-04-07 15:22:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 15:22:05 --> Database Driver Class Initialized
INFO - 2020-04-07 15:22:05 --> Parser Class Initialized
INFO - 2020-04-07 15:22:05 --> User Agent Class Initialized
INFO - 2020-04-07 15:22:05 --> Model Class Initialized
INFO - 2020-04-07 15:22:05 --> Model Class Initialized
DEBUG - 2020-04-07 15:22:05 --> Template Class Initialized
INFO - 2020-04-07 15:22:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 15:22:05 --> Email Class Initialized
INFO - 2020-04-07 15:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 15:22:05 --> Pagination Class Initialized
DEBUG - 2020-04-07 15:22:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 15:22:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 15:22:05 --> Encryption Class Initialized
INFO - 2020-04-07 15:22:05 --> Controller Class Initialized
DEBUG - 2020-04-07 15:22:05 --> twitter MX_Controller Initialized
INFO - 2020-04-07 15:22:05 --> Model Class Initialized
DEBUG - 2020-04-07 15:22:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 15:22:05 --> Model Class Initialized
INFO - 2020-04-07 16:47:35 --> Config Class Initialized
INFO - 2020-04-07 16:47:35 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:47:35 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:47:35 --> Utf8 Class Initialized
INFO - 2020-04-07 16:47:35 --> URI Class Initialized
INFO - 2020-04-07 16:47:35 --> Router Class Initialized
INFO - 2020-04-07 16:47:35 --> Output Class Initialized
INFO - 2020-04-07 16:47:35 --> Security Class Initialized
DEBUG - 2020-04-07 16:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:47:35 --> CSRF cookie sent
INFO - 2020-04-07 16:47:35 --> Input Class Initialized
INFO - 2020-04-07 16:47:35 --> Language Class Initialized
INFO - 2020-04-07 16:47:35 --> Language Class Initialized
INFO - 2020-04-07 16:47:35 --> Config Class Initialized
INFO - 2020-04-07 16:47:35 --> Loader Class Initialized
INFO - 2020-04-07 16:47:35 --> Helper loaded: url_helper
INFO - 2020-04-07 16:47:35 --> Helper loaded: file_helper
INFO - 2020-04-07 16:47:35 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:47:35 --> Helper loaded: common_helper
INFO - 2020-04-07 16:47:35 --> Helper loaded: language_helper
INFO - 2020-04-07 16:47:35 --> Helper loaded: email_helper
INFO - 2020-04-07 16:47:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:47:35 --> Database Driver Class Initialized
INFO - 2020-04-07 16:47:35 --> Parser Class Initialized
INFO - 2020-04-07 16:47:35 --> User Agent Class Initialized
INFO - 2020-04-07 16:47:35 --> Model Class Initialized
INFO - 2020-04-07 16:47:35 --> Model Class Initialized
DEBUG - 2020-04-07 16:47:35 --> Template Class Initialized
INFO - 2020-04-07 16:47:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:47:35 --> Email Class Initialized
INFO - 2020-04-07 16:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:47:35 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:47:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:47:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:47:35 --> Encryption Class Initialized
INFO - 2020-04-07 16:47:35 --> Controller Class Initialized
DEBUG - 2020-04-07 16:47:35 --> twitter MX_Controller Initialized
INFO - 2020-04-07 16:47:35 --> Model Class Initialized
DEBUG - 2020-04-07 16:47:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 16:47:35 --> Model Class Initialized
DEBUG - 2020-04-07 16:47:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-07 16:47:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 16:47:35 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 16:47:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 16:47:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 16:47:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 16:47:35 --> Final output sent to browser
DEBUG - 2020-04-07 16:47:35 --> Total execution time: 0.5930
INFO - 2020-04-07 16:50:02 --> Config Class Initialized
INFO - 2020-04-07 16:50:02 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:50:02 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:50:02 --> Utf8 Class Initialized
INFO - 2020-04-07 16:50:02 --> URI Class Initialized
INFO - 2020-04-07 16:50:02 --> Router Class Initialized
INFO - 2020-04-07 16:50:02 --> Output Class Initialized
INFO - 2020-04-07 16:50:02 --> Security Class Initialized
DEBUG - 2020-04-07 16:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:50:02 --> CSRF cookie sent
INFO - 2020-04-07 16:50:02 --> Input Class Initialized
INFO - 2020-04-07 16:50:02 --> Language Class Initialized
ERROR - 2020-04-07 16:50:02 --> 404 Page Not Found: /index
INFO - 2020-04-07 16:50:02 --> Config Class Initialized
INFO - 2020-04-07 16:50:02 --> Config Class Initialized
INFO - 2020-04-07 16:50:02 --> Config Class Initialized
INFO - 2020-04-07 16:50:02 --> Hooks Class Initialized
INFO - 2020-04-07 16:50:02 --> Hooks Class Initialized
INFO - 2020-04-07 16:50:02 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 16:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 16:50:02 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:50:02 --> Utf8 Class Initialized
INFO - 2020-04-07 16:50:02 --> Utf8 Class Initialized
INFO - 2020-04-07 16:50:02 --> Utf8 Class Initialized
INFO - 2020-04-07 16:50:02 --> URI Class Initialized
INFO - 2020-04-07 16:50:02 --> URI Class Initialized
INFO - 2020-04-07 16:50:02 --> URI Class Initialized
INFO - 2020-04-07 16:50:02 --> Router Class Initialized
INFO - 2020-04-07 16:50:02 --> Router Class Initialized
INFO - 2020-04-07 16:50:02 --> Router Class Initialized
INFO - 2020-04-07 16:50:02 --> Output Class Initialized
INFO - 2020-04-07 16:50:02 --> Output Class Initialized
INFO - 2020-04-07 16:50:02 --> Output Class Initialized
INFO - 2020-04-07 16:50:02 --> Security Class Initialized
INFO - 2020-04-07 16:50:02 --> Security Class Initialized
INFO - 2020-04-07 16:50:02 --> Security Class Initialized
DEBUG - 2020-04-07 16:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 16:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 16:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:50:02 --> CSRF cookie sent
INFO - 2020-04-07 16:50:02 --> CSRF cookie sent
INFO - 2020-04-07 16:50:02 --> CSRF cookie sent
INFO - 2020-04-07 16:50:02 --> Input Class Initialized
INFO - 2020-04-07 16:50:02 --> Input Class Initialized
INFO - 2020-04-07 16:50:02 --> Input Class Initialized
INFO - 2020-04-07 16:50:02 --> Language Class Initialized
INFO - 2020-04-07 16:50:02 --> Language Class Initialized
INFO - 2020-04-07 16:50:02 --> Language Class Initialized
ERROR - 2020-04-07 16:50:02 --> 404 Page Not Found: /index
ERROR - 2020-04-07 16:50:02 --> 404 Page Not Found: /index
ERROR - 2020-04-07 16:50:02 --> 404 Page Not Found: /index
INFO - 2020-04-07 16:50:08 --> Config Class Initialized
INFO - 2020-04-07 16:50:08 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:50:08 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:50:08 --> Utf8 Class Initialized
INFO - 2020-04-07 16:50:08 --> URI Class Initialized
INFO - 2020-04-07 16:50:08 --> Router Class Initialized
INFO - 2020-04-07 16:50:08 --> Output Class Initialized
INFO - 2020-04-07 16:50:08 --> Security Class Initialized
DEBUG - 2020-04-07 16:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:50:08 --> CSRF cookie sent
INFO - 2020-04-07 16:50:08 --> Input Class Initialized
INFO - 2020-04-07 16:50:08 --> Language Class Initialized
INFO - 2020-04-07 16:50:08 --> Language Class Initialized
INFO - 2020-04-07 16:50:08 --> Config Class Initialized
INFO - 2020-04-07 16:50:08 --> Loader Class Initialized
INFO - 2020-04-07 16:50:08 --> Helper loaded: url_helper
INFO - 2020-04-07 16:50:08 --> Helper loaded: file_helper
INFO - 2020-04-07 16:50:08 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:50:09 --> Helper loaded: common_helper
INFO - 2020-04-07 16:50:09 --> Helper loaded: language_helper
INFO - 2020-04-07 16:50:09 --> Helper loaded: email_helper
INFO - 2020-04-07 16:50:09 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:50:09 --> Database Driver Class Initialized
INFO - 2020-04-07 16:50:09 --> Parser Class Initialized
INFO - 2020-04-07 16:50:09 --> User Agent Class Initialized
INFO - 2020-04-07 16:50:09 --> Model Class Initialized
INFO - 2020-04-07 16:50:09 --> Model Class Initialized
DEBUG - 2020-04-07 16:50:09 --> Template Class Initialized
INFO - 2020-04-07 16:50:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:50:09 --> Email Class Initialized
INFO - 2020-04-07 16:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:50:09 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:50:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:50:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:50:09 --> Encryption Class Initialized
INFO - 2020-04-07 16:50:09 --> Controller Class Initialized
DEBUG - 2020-04-07 16:50:09 --> follow MX_Controller Initialized
INFO - 2020-04-07 16:50:09 --> Model Class Initialized
DEBUG - 2020-04-07 16:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-07 16:50:09 --> Model Class Initialized
INFO - 2020-04-07 16:50:09 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/views/index.php
DEBUG - 2020-04-07 16:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 16:50:09 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 16:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 16:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 16:50:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 16:50:09 --> Final output sent to browser
DEBUG - 2020-04-07 16:50:09 --> Total execution time: 0.4864
INFO - 2020-04-07 16:50:09 --> Config Class Initialized
INFO - 2020-04-07 16:50:09 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:50:09 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:50:09 --> Utf8 Class Initialized
INFO - 2020-04-07 16:50:09 --> URI Class Initialized
INFO - 2020-04-07 16:50:09 --> Router Class Initialized
INFO - 2020-04-07 16:50:09 --> Output Class Initialized
INFO - 2020-04-07 16:50:09 --> Security Class Initialized
DEBUG - 2020-04-07 16:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:50:10 --> CSRF cookie sent
INFO - 2020-04-07 16:50:10 --> Input Class Initialized
INFO - 2020-04-07 16:50:10 --> Language Class Initialized
INFO - 2020-04-07 16:50:10 --> Language Class Initialized
INFO - 2020-04-07 16:50:10 --> Config Class Initialized
INFO - 2020-04-07 16:50:10 --> Loader Class Initialized
INFO - 2020-04-07 16:50:10 --> Helper loaded: url_helper
INFO - 2020-04-07 16:50:10 --> Helper loaded: file_helper
INFO - 2020-04-07 16:50:10 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:50:10 --> Helper loaded: common_helper
INFO - 2020-04-07 16:50:10 --> Helper loaded: language_helper
INFO - 2020-04-07 16:50:10 --> Helper loaded: email_helper
INFO - 2020-04-07 16:50:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:50:10 --> Database Driver Class Initialized
INFO - 2020-04-07 16:50:10 --> Parser Class Initialized
INFO - 2020-04-07 16:50:10 --> User Agent Class Initialized
DEBUG - 2020-04-07 16:50:10 --> Template Class Initialized
INFO - 2020-04-07 16:50:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:50:10 --> Email Class Initialized
INFO - 2020-04-07 16:50:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:50:10 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:50:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:50:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:50:10 --> Encryption Class Initialized
INFO - 2020-04-07 16:50:10 --> Controller Class Initialized
DEBUG - 2020-04-07 16:50:10 --> follow MX_Controller Initialized
ERROR - 2020-04-07 16:50:10 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-04-07 16:50:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-04-07 16:50:11 --> Config Class Initialized
INFO - 2020-04-07 16:50:11 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:50:11 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:50:11 --> Utf8 Class Initialized
INFO - 2020-04-07 16:50:11 --> URI Class Initialized
INFO - 2020-04-07 16:50:11 --> Router Class Initialized
INFO - 2020-04-07 16:50:11 --> Output Class Initialized
INFO - 2020-04-07 16:50:11 --> Security Class Initialized
DEBUG - 2020-04-07 16:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:50:11 --> CSRF cookie sent
INFO - 2020-04-07 16:50:11 --> Input Class Initialized
INFO - 2020-04-07 16:50:11 --> Language Class Initialized
INFO - 2020-04-07 16:50:11 --> Language Class Initialized
INFO - 2020-04-07 16:50:11 --> Config Class Initialized
INFO - 2020-04-07 16:50:11 --> Loader Class Initialized
INFO - 2020-04-07 16:50:11 --> Helper loaded: url_helper
INFO - 2020-04-07 16:50:11 --> Helper loaded: file_helper
INFO - 2020-04-07 16:50:11 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:50:11 --> Helper loaded: common_helper
INFO - 2020-04-07 16:50:11 --> Helper loaded: language_helper
INFO - 2020-04-07 16:50:11 --> Helper loaded: email_helper
INFO - 2020-04-07 16:50:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:50:11 --> Database Driver Class Initialized
INFO - 2020-04-07 16:50:11 --> Parser Class Initialized
INFO - 2020-04-07 16:50:11 --> User Agent Class Initialized
DEBUG - 2020-04-07 16:50:11 --> Template Class Initialized
INFO - 2020-04-07 16:50:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:50:11 --> Email Class Initialized
INFO - 2020-04-07 16:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:50:11 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:50:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:50:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:50:11 --> Encryption Class Initialized
INFO - 2020-04-07 16:50:11 --> Controller Class Initialized
DEBUG - 2020-04-07 16:50:11 --> follow MX_Controller Initialized
ERROR - 2020-04-07 16:50:11 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-04-07 16:50:11 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-04-07 16:50:37 --> Config Class Initialized
INFO - 2020-04-07 16:50:37 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:50:37 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:50:37 --> Utf8 Class Initialized
INFO - 2020-04-07 16:50:37 --> URI Class Initialized
INFO - 2020-04-07 16:50:37 --> Router Class Initialized
INFO - 2020-04-07 16:50:37 --> Output Class Initialized
INFO - 2020-04-07 16:50:37 --> Security Class Initialized
DEBUG - 2020-04-07 16:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:50:37 --> CSRF cookie sent
INFO - 2020-04-07 16:50:37 --> Input Class Initialized
INFO - 2020-04-07 16:50:37 --> Language Class Initialized
INFO - 2020-04-07 16:50:37 --> Language Class Initialized
INFO - 2020-04-07 16:50:37 --> Config Class Initialized
INFO - 2020-04-07 16:50:37 --> Loader Class Initialized
INFO - 2020-04-07 16:50:38 --> Helper loaded: url_helper
INFO - 2020-04-07 16:50:38 --> Helper loaded: file_helper
INFO - 2020-04-07 16:50:38 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:50:38 --> Helper loaded: common_helper
INFO - 2020-04-07 16:50:38 --> Helper loaded: language_helper
INFO - 2020-04-07 16:50:38 --> Helper loaded: email_helper
INFO - 2020-04-07 16:50:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:50:38 --> Database Driver Class Initialized
INFO - 2020-04-07 16:50:38 --> Parser Class Initialized
INFO - 2020-04-07 16:50:38 --> User Agent Class Initialized
DEBUG - 2020-04-07 16:50:38 --> Template Class Initialized
INFO - 2020-04-07 16:50:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:50:38 --> Email Class Initialized
INFO - 2020-04-07 16:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:50:38 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:50:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:50:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:50:38 --> Encryption Class Initialized
INFO - 2020-04-07 16:50:38 --> Controller Class Initialized
DEBUG - 2020-04-07 16:50:38 --> follow MX_Controller Initialized
INFO - 2020-04-07 16:50:38 --> Model Class Initialized
INFO - 2020-04-07 16:50:38 --> Model Class Initialized
ERROR - 2020-04-07 16:50:38 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-04-07 16:50:38 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-04-07 16:55:00 --> Config Class Initialized
INFO - 2020-04-07 16:55:00 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:55:00 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:55:00 --> Utf8 Class Initialized
INFO - 2020-04-07 16:55:00 --> URI Class Initialized
INFO - 2020-04-07 16:55:00 --> Router Class Initialized
INFO - 2020-04-07 16:55:00 --> Output Class Initialized
INFO - 2020-04-07 16:55:00 --> Security Class Initialized
DEBUG - 2020-04-07 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:55:00 --> CSRF cookie sent
INFO - 2020-04-07 16:55:00 --> Input Class Initialized
INFO - 2020-04-07 16:55:00 --> Language Class Initialized
INFO - 2020-04-07 16:55:00 --> Language Class Initialized
INFO - 2020-04-07 16:55:00 --> Config Class Initialized
INFO - 2020-04-07 16:55:00 --> Loader Class Initialized
INFO - 2020-04-07 16:55:00 --> Helper loaded: url_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: file_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: common_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: language_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: email_helper
INFO - 2020-04-07 16:55:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:55:00 --> Database Driver Class Initialized
INFO - 2020-04-07 16:55:00 --> Parser Class Initialized
INFO - 2020-04-07 16:55:00 --> User Agent Class Initialized
INFO - 2020-04-07 16:55:00 --> Model Class Initialized
INFO - 2020-04-07 16:55:00 --> Model Class Initialized
DEBUG - 2020-04-07 16:55:00 --> Template Class Initialized
INFO - 2020-04-07 16:55:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:55:00 --> Email Class Initialized
INFO - 2020-04-07 16:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:55:00 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:55:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:55:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:55:00 --> Encryption Class Initialized
INFO - 2020-04-07 16:55:00 --> Controller Class Initialized
DEBUG - 2020-04-07 16:55:00 --> auth MX_Controller Initialized
INFO - 2020-04-07 16:55:00 --> Model Class Initialized
INFO - 2020-04-07 16:55:00 --> Config Class Initialized
INFO - 2020-04-07 16:55:00 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:55:00 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:55:00 --> Utf8 Class Initialized
INFO - 2020-04-07 16:55:00 --> URI Class Initialized
DEBUG - 2020-04-07 16:55:00 --> No URI present. Default controller set.
INFO - 2020-04-07 16:55:00 --> Router Class Initialized
INFO - 2020-04-07 16:55:00 --> Output Class Initialized
INFO - 2020-04-07 16:55:00 --> Security Class Initialized
DEBUG - 2020-04-07 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:55:00 --> CSRF cookie sent
INFO - 2020-04-07 16:55:00 --> Input Class Initialized
INFO - 2020-04-07 16:55:00 --> Language Class Initialized
INFO - 2020-04-07 16:55:00 --> Language Class Initialized
INFO - 2020-04-07 16:55:00 --> Config Class Initialized
INFO - 2020-04-07 16:55:00 --> Loader Class Initialized
INFO - 2020-04-07 16:55:00 --> Helper loaded: url_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: file_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: common_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: language_helper
INFO - 2020-04-07 16:55:00 --> Helper loaded: email_helper
INFO - 2020-04-07 16:55:00 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:55:00 --> Database Driver Class Initialized
INFO - 2020-04-07 16:55:00 --> Parser Class Initialized
INFO - 2020-04-07 16:55:00 --> User Agent Class Initialized
INFO - 2020-04-07 16:55:00 --> Model Class Initialized
INFO - 2020-04-07 16:55:00 --> Model Class Initialized
DEBUG - 2020-04-07 16:55:01 --> Template Class Initialized
INFO - 2020-04-07 16:55:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:55:01 --> Email Class Initialized
INFO - 2020-04-07 16:55:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:55:01 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:55:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:55:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:55:01 --> Encryption Class Initialized
INFO - 2020-04-07 16:55:01 --> Controller Class Initialized
DEBUG - 2020-04-07 16:55:01 --> home MX_Controller Initialized
INFO - 2020-04-07 16:55:01 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:55:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 16:55:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 16:55:01 --> Final output sent to browser
DEBUG - 2020-04-07 16:55:01 --> Total execution time: 0.4837
INFO - 2020-04-07 16:55:48 --> Config Class Initialized
INFO - 2020-04-07 16:55:48 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:55:48 --> Utf8 Class Initialized
INFO - 2020-04-07 16:55:48 --> URI Class Initialized
DEBUG - 2020-04-07 16:55:48 --> No URI present. Default controller set.
INFO - 2020-04-07 16:55:48 --> Router Class Initialized
INFO - 2020-04-07 16:55:48 --> Output Class Initialized
INFO - 2020-04-07 16:55:48 --> Security Class Initialized
DEBUG - 2020-04-07 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:55:48 --> CSRF cookie sent
INFO - 2020-04-07 16:55:48 --> Input Class Initialized
INFO - 2020-04-07 16:55:48 --> Language Class Initialized
INFO - 2020-04-07 16:55:48 --> Language Class Initialized
INFO - 2020-04-07 16:55:48 --> Config Class Initialized
INFO - 2020-04-07 16:55:48 --> Loader Class Initialized
INFO - 2020-04-07 16:55:48 --> Helper loaded: url_helper
INFO - 2020-04-07 16:55:48 --> Helper loaded: file_helper
INFO - 2020-04-07 16:55:48 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:55:49 --> Helper loaded: common_helper
INFO - 2020-04-07 16:55:49 --> Helper loaded: language_helper
INFO - 2020-04-07 16:55:49 --> Helper loaded: email_helper
INFO - 2020-04-07 16:55:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:55:49 --> Database Driver Class Initialized
INFO - 2020-04-07 16:55:49 --> Parser Class Initialized
INFO - 2020-04-07 16:55:49 --> User Agent Class Initialized
INFO - 2020-04-07 16:55:49 --> Model Class Initialized
INFO - 2020-04-07 16:55:49 --> Model Class Initialized
DEBUG - 2020-04-07 16:55:49 --> Template Class Initialized
INFO - 2020-04-07 16:55:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:55:49 --> Email Class Initialized
INFO - 2020-04-07 16:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:55:49 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:55:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:55:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:55:49 --> Encryption Class Initialized
INFO - 2020-04-07 16:55:49 --> Controller Class Initialized
DEBUG - 2020-04-07 16:55:49 --> home MX_Controller Initialized
INFO - 2020-04-07 16:55:49 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:55:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 16:55:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 16:55:49 --> Final output sent to browser
DEBUG - 2020-04-07 16:55:49 --> Total execution time: 1.0813
INFO - 2020-04-07 16:55:55 --> Config Class Initialized
INFO - 2020-04-07 16:55:55 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:55:55 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:55:55 --> Utf8 Class Initialized
INFO - 2020-04-07 16:55:55 --> URI Class Initialized
INFO - 2020-04-07 16:55:55 --> Router Class Initialized
INFO - 2020-04-07 16:55:55 --> Output Class Initialized
INFO - 2020-04-07 16:55:55 --> Security Class Initialized
DEBUG - 2020-04-07 16:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:55:55 --> CSRF cookie sent
INFO - 2020-04-07 16:55:55 --> Input Class Initialized
INFO - 2020-04-07 16:55:55 --> Language Class Initialized
INFO - 2020-04-07 16:55:55 --> Language Class Initialized
INFO - 2020-04-07 16:55:55 --> Config Class Initialized
INFO - 2020-04-07 16:55:55 --> Loader Class Initialized
INFO - 2020-04-07 16:55:55 --> Helper loaded: url_helper
INFO - 2020-04-07 16:55:55 --> Helper loaded: file_helper
INFO - 2020-04-07 16:55:55 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:55:55 --> Helper loaded: common_helper
INFO - 2020-04-07 16:55:55 --> Helper loaded: language_helper
INFO - 2020-04-07 16:55:55 --> Helper loaded: email_helper
INFO - 2020-04-07 16:55:55 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:55:55 --> Database Driver Class Initialized
INFO - 2020-04-07 16:55:55 --> Parser Class Initialized
INFO - 2020-04-07 16:55:55 --> User Agent Class Initialized
INFO - 2020-04-07 16:55:55 --> Model Class Initialized
INFO - 2020-04-07 16:55:55 --> Model Class Initialized
DEBUG - 2020-04-07 16:55:55 --> Template Class Initialized
INFO - 2020-04-07 16:55:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:55:55 --> Email Class Initialized
INFO - 2020-04-07 16:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:55:55 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:55:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:55:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:55:55 --> Encryption Class Initialized
INFO - 2020-04-07 16:55:55 --> Controller Class Initialized
DEBUG - 2020-04-07 16:55:55 --> auth MX_Controller Initialized
INFO - 2020-04-07 16:55:55 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:55:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-07 16:55:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-07 16:55:55 --> Final output sent to browser
DEBUG - 2020-04-07 16:55:55 --> Total execution time: 0.9578
INFO - 2020-04-07 16:55:58 --> Config Class Initialized
INFO - 2020-04-07 16:55:58 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:55:58 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:55:58 --> Utf8 Class Initialized
INFO - 2020-04-07 16:55:58 --> URI Class Initialized
INFO - 2020-04-07 16:55:58 --> Router Class Initialized
INFO - 2020-04-07 16:55:58 --> Output Class Initialized
INFO - 2020-04-07 16:55:58 --> Security Class Initialized
DEBUG - 2020-04-07 16:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:55:58 --> CSRF cookie sent
INFO - 2020-04-07 16:55:58 --> Input Class Initialized
INFO - 2020-04-07 16:55:58 --> Language Class Initialized
INFO - 2020-04-07 16:55:58 --> Language Class Initialized
INFO - 2020-04-07 16:55:58 --> Config Class Initialized
INFO - 2020-04-07 16:55:58 --> Loader Class Initialized
INFO - 2020-04-07 16:55:58 --> Helper loaded: url_helper
INFO - 2020-04-07 16:55:58 --> Helper loaded: file_helper
INFO - 2020-04-07 16:55:58 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:55:58 --> Helper loaded: common_helper
INFO - 2020-04-07 16:55:58 --> Helper loaded: language_helper
INFO - 2020-04-07 16:55:58 --> Helper loaded: email_helper
INFO - 2020-04-07 16:55:58 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:55:58 --> Database Driver Class Initialized
INFO - 2020-04-07 16:55:58 --> Parser Class Initialized
INFO - 2020-04-07 16:55:58 --> User Agent Class Initialized
DEBUG - 2020-04-07 16:55:58 --> Template Class Initialized
INFO - 2020-04-07 16:55:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:55:58 --> Email Class Initialized
INFO - 2020-04-07 16:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:55:58 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:55:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:55:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:55:58 --> Encryption Class Initialized
INFO - 2020-04-07 16:55:58 --> Controller Class Initialized
DEBUG - 2020-04-07 16:55:58 --> follow MX_Controller Initialized
INFO - 2020-04-07 16:55:58 --> Model Class Initialized
INFO - 2020-04-07 16:55:58 --> Model Class Initialized
DEBUG - 2020-04-07 16:55:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/follow/models/follow_model.php
INFO - 2020-04-07 16:55:58 --> Model Class Initialized
INFO - 2020-04-07 16:55:58 --> Model Class Initialized
INFO - 2020-04-07 16:56:00 --> Final output sent to browser
DEBUG - 2020-04-07 16:56:00 --> Total execution time: 1.9444
ERROR - 2020-04-07 16:56:00 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-04-07 16:56:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-04-07 16:56:07 --> Config Class Initialized
INFO - 2020-04-07 16:56:07 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:56:07 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:56:07 --> Utf8 Class Initialized
INFO - 2020-04-07 16:56:07 --> URI Class Initialized
INFO - 2020-04-07 16:56:07 --> Router Class Initialized
INFO - 2020-04-07 16:56:07 --> Output Class Initialized
INFO - 2020-04-07 16:56:07 --> Security Class Initialized
DEBUG - 2020-04-07 16:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:56:07 --> CSRF cookie sent
INFO - 2020-04-07 16:56:07 --> CSRF token verified
INFO - 2020-04-07 16:56:07 --> Input Class Initialized
INFO - 2020-04-07 16:56:07 --> Language Class Initialized
INFO - 2020-04-07 16:56:07 --> Language Class Initialized
INFO - 2020-04-07 16:56:07 --> Config Class Initialized
INFO - 2020-04-07 16:56:07 --> Loader Class Initialized
INFO - 2020-04-07 16:56:07 --> Helper loaded: url_helper
INFO - 2020-04-07 16:56:07 --> Helper loaded: file_helper
INFO - 2020-04-07 16:56:07 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:56:07 --> Helper loaded: common_helper
INFO - 2020-04-07 16:56:07 --> Helper loaded: language_helper
INFO - 2020-04-07 16:56:07 --> Helper loaded: email_helper
INFO - 2020-04-07 16:56:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:56:07 --> Database Driver Class Initialized
INFO - 2020-04-07 16:56:07 --> Parser Class Initialized
INFO - 2020-04-07 16:56:07 --> User Agent Class Initialized
INFO - 2020-04-07 16:56:07 --> Model Class Initialized
INFO - 2020-04-07 16:56:07 --> Model Class Initialized
DEBUG - 2020-04-07 16:56:07 --> Template Class Initialized
INFO - 2020-04-07 16:56:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:56:07 --> Email Class Initialized
INFO - 2020-04-07 16:56:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:56:07 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:56:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:56:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:56:07 --> Encryption Class Initialized
INFO - 2020-04-07 16:56:07 --> Controller Class Initialized
DEBUG - 2020-04-07 16:56:07 --> auth MX_Controller Initialized
INFO - 2020-04-07 16:56:09 --> Config Class Initialized
INFO - 2020-04-07 16:56:09 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:56:09 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:56:09 --> Utf8 Class Initialized
INFO - 2020-04-07 16:56:09 --> URI Class Initialized
INFO - 2020-04-07 16:56:09 --> Router Class Initialized
INFO - 2020-04-07 16:56:09 --> Output Class Initialized
INFO - 2020-04-07 16:56:10 --> Security Class Initialized
DEBUG - 2020-04-07 16:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:56:10 --> CSRF cookie sent
INFO - 2020-04-07 16:56:10 --> Input Class Initialized
INFO - 2020-04-07 16:56:10 --> Language Class Initialized
INFO - 2020-04-07 16:56:10 --> Language Class Initialized
INFO - 2020-04-07 16:56:10 --> Config Class Initialized
INFO - 2020-04-07 16:56:10 --> Loader Class Initialized
INFO - 2020-04-07 16:56:10 --> Helper loaded: url_helper
INFO - 2020-04-07 16:56:10 --> Helper loaded: file_helper
INFO - 2020-04-07 16:56:10 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:56:10 --> Helper loaded: common_helper
INFO - 2020-04-07 16:56:10 --> Helper loaded: language_helper
INFO - 2020-04-07 16:56:10 --> Helper loaded: email_helper
INFO - 2020-04-07 16:56:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:56:10 --> Database Driver Class Initialized
INFO - 2020-04-07 16:56:10 --> Parser Class Initialized
INFO - 2020-04-07 16:56:10 --> User Agent Class Initialized
INFO - 2020-04-07 16:56:10 --> Model Class Initialized
INFO - 2020-04-07 16:56:10 --> Model Class Initialized
DEBUG - 2020-04-07 16:56:10 --> Template Class Initialized
INFO - 2020-04-07 16:56:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:56:10 --> Email Class Initialized
INFO - 2020-04-07 16:56:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:56:10 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:56:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:56:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:56:10 --> Encryption Class Initialized
INFO - 2020-04-07 16:56:10 --> Controller Class Initialized
DEBUG - 2020-04-07 16:56:10 --> dashboard MX_Controller Initialized
INFO - 2020-04-07 16:56:10 --> Model Class Initialized
DEBUG - 2020-04-07 16:56:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-07 16:56:10 --> Model Class Initialized
INFO - 2020-04-07 16:56:10 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:56:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-07 16:56:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-07 16:56:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 16:56:10 --> blocks MX_Controller Initialized
INFO - 2020-04-07 16:56:11 --> Config Class Initialized
INFO - 2020-04-07 16:56:11 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:56:11 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:56:11 --> Utf8 Class Initialized
INFO - 2020-04-07 16:56:11 --> URI Class Initialized
DEBUG - 2020-04-07 16:56:11 --> No URI present. Default controller set.
INFO - 2020-04-07 16:56:11 --> Router Class Initialized
INFO - 2020-04-07 16:56:11 --> Output Class Initialized
INFO - 2020-04-07 16:56:11 --> Security Class Initialized
DEBUG - 2020-04-07 16:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:56:11 --> CSRF cookie sent
INFO - 2020-04-07 16:56:11 --> Input Class Initialized
INFO - 2020-04-07 16:56:11 --> Language Class Initialized
INFO - 2020-04-07 16:56:11 --> Language Class Initialized
INFO - 2020-04-07 16:56:11 --> Config Class Initialized
INFO - 2020-04-07 16:56:11 --> Loader Class Initialized
INFO - 2020-04-07 16:56:11 --> Helper loaded: url_helper
INFO - 2020-04-07 16:56:11 --> Helper loaded: file_helper
INFO - 2020-04-07 16:56:12 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:56:12 --> Helper loaded: common_helper
INFO - 2020-04-07 16:56:12 --> Helper loaded: language_helper
INFO - 2020-04-07 16:56:12 --> Helper loaded: email_helper
INFO - 2020-04-07 16:56:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:56:12 --> Database Driver Class Initialized
INFO - 2020-04-07 16:56:12 --> Parser Class Initialized
INFO - 2020-04-07 16:56:12 --> User Agent Class Initialized
INFO - 2020-04-07 16:56:12 --> Model Class Initialized
INFO - 2020-04-07 16:56:12 --> Model Class Initialized
DEBUG - 2020-04-07 16:56:12 --> Template Class Initialized
INFO - 2020-04-07 16:56:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:56:12 --> Email Class Initialized
INFO - 2020-04-07 16:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:56:12 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:56:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:56:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:56:12 --> Encryption Class Initialized
INFO - 2020-04-07 16:56:12 --> Controller Class Initialized
DEBUG - 2020-04-07 16:56:12 --> home MX_Controller Initialized
INFO - 2020-04-07 16:56:12 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:56:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 16:56:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 16:56:12 --> Final output sent to browser
DEBUG - 2020-04-07 16:56:12 --> Total execution time: 0.5356
INFO - 2020-04-07 16:56:52 --> Config Class Initialized
INFO - 2020-04-07 16:56:52 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:56:52 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:56:52 --> Utf8 Class Initialized
INFO - 2020-04-07 16:56:52 --> URI Class Initialized
INFO - 2020-04-07 16:56:52 --> Router Class Initialized
INFO - 2020-04-07 16:56:52 --> Output Class Initialized
INFO - 2020-04-07 16:56:52 --> Security Class Initialized
DEBUG - 2020-04-07 16:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:56:52 --> CSRF cookie sent
INFO - 2020-04-07 16:56:52 --> Input Class Initialized
INFO - 2020-04-07 16:56:52 --> Language Class Initialized
INFO - 2020-04-07 16:56:52 --> Language Class Initialized
INFO - 2020-04-07 16:56:52 --> Config Class Initialized
INFO - 2020-04-07 16:56:52 --> Loader Class Initialized
INFO - 2020-04-07 16:56:52 --> Helper loaded: url_helper
INFO - 2020-04-07 16:56:52 --> Helper loaded: file_helper
INFO - 2020-04-07 16:56:52 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:56:52 --> Helper loaded: common_helper
INFO - 2020-04-07 16:56:52 --> Helper loaded: language_helper
INFO - 2020-04-07 16:56:52 --> Helper loaded: email_helper
INFO - 2020-04-07 16:56:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:56:52 --> Database Driver Class Initialized
INFO - 2020-04-07 16:56:52 --> Parser Class Initialized
INFO - 2020-04-07 16:56:52 --> User Agent Class Initialized
DEBUG - 2020-04-07 16:56:52 --> Template Class Initialized
INFO - 2020-04-07 16:56:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:56:52 --> Email Class Initialized
INFO - 2020-04-07 16:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:56:52 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:56:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:56:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:56:52 --> Encryption Class Initialized
INFO - 2020-04-07 16:56:52 --> Controller Class Initialized
DEBUG - 2020-04-07 16:56:52 --> follow MX_Controller Initialized
INFO - 2020-04-07 16:56:52 --> Model Class Initialized
INFO - 2020-04-07 16:56:52 --> Model Class Initialized
ERROR - 2020-04-07 16:56:52 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2020-04-07 16:56:52 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2020-04-07 16:56:52 --> Config Class Initialized
INFO - 2020-04-07 16:56:52 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:56:52 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:56:52 --> Utf8 Class Initialized
INFO - 2020-04-07 16:56:52 --> URI Class Initialized
DEBUG - 2020-04-07 16:56:52 --> No URI present. Default controller set.
INFO - 2020-04-07 16:56:52 --> Router Class Initialized
INFO - 2020-04-07 16:56:52 --> Output Class Initialized
INFO - 2020-04-07 16:56:52 --> Security Class Initialized
DEBUG - 2020-04-07 16:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:56:52 --> CSRF cookie sent
INFO - 2020-04-07 16:56:52 --> Input Class Initialized
INFO - 2020-04-07 16:56:52 --> Language Class Initialized
INFO - 2020-04-07 16:56:52 --> Language Class Initialized
INFO - 2020-04-07 16:56:52 --> Config Class Initialized
INFO - 2020-04-07 16:56:52 --> Loader Class Initialized
INFO - 2020-04-07 16:56:52 --> Helper loaded: url_helper
INFO - 2020-04-07 16:56:52 --> Helper loaded: file_helper
INFO - 2020-04-07 16:56:52 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:56:53 --> Helper loaded: common_helper
INFO - 2020-04-07 16:56:53 --> Helper loaded: language_helper
INFO - 2020-04-07 16:56:53 --> Helper loaded: email_helper
INFO - 2020-04-07 16:56:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:56:53 --> Database Driver Class Initialized
INFO - 2020-04-07 16:56:53 --> Parser Class Initialized
INFO - 2020-04-07 16:56:53 --> User Agent Class Initialized
INFO - 2020-04-07 16:56:53 --> Model Class Initialized
INFO - 2020-04-07 16:56:53 --> Model Class Initialized
DEBUG - 2020-04-07 16:56:53 --> Template Class Initialized
INFO - 2020-04-07 16:56:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:56:53 --> Email Class Initialized
INFO - 2020-04-07 16:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:56:53 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:56:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:56:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:56:53 --> Encryption Class Initialized
INFO - 2020-04-07 16:56:53 --> Controller Class Initialized
DEBUG - 2020-04-07 16:56:53 --> home MX_Controller Initialized
INFO - 2020-04-07 16:56:53 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 16:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 16:56:53 --> Final output sent to browser
DEBUG - 2020-04-07 16:56:53 --> Total execution time: 0.4805
INFO - 2020-04-07 16:57:12 --> Config Class Initialized
INFO - 2020-04-07 16:57:12 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:57:12 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:57:12 --> Utf8 Class Initialized
INFO - 2020-04-07 16:57:12 --> URI Class Initialized
INFO - 2020-04-07 16:57:12 --> Router Class Initialized
INFO - 2020-04-07 16:57:12 --> Output Class Initialized
INFO - 2020-04-07 16:57:12 --> Security Class Initialized
DEBUG - 2020-04-07 16:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:57:12 --> CSRF cookie sent
INFO - 2020-04-07 16:57:12 --> Input Class Initialized
INFO - 2020-04-07 16:57:12 --> Language Class Initialized
INFO - 2020-04-07 16:57:12 --> Language Class Initialized
INFO - 2020-04-07 16:57:12 --> Config Class Initialized
INFO - 2020-04-07 16:57:12 --> Loader Class Initialized
INFO - 2020-04-07 16:57:12 --> Helper loaded: url_helper
INFO - 2020-04-07 16:57:12 --> Helper loaded: file_helper
INFO - 2020-04-07 16:57:12 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:57:12 --> Helper loaded: common_helper
INFO - 2020-04-07 16:57:12 --> Helper loaded: language_helper
INFO - 2020-04-07 16:57:12 --> Helper loaded: email_helper
INFO - 2020-04-07 16:57:12 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:57:12 --> Database Driver Class Initialized
INFO - 2020-04-07 16:57:12 --> Parser Class Initialized
INFO - 2020-04-07 16:57:12 --> User Agent Class Initialized
INFO - 2020-04-07 16:57:12 --> Model Class Initialized
INFO - 2020-04-07 16:57:12 --> Model Class Initialized
DEBUG - 2020-04-07 16:57:12 --> Template Class Initialized
INFO - 2020-04-07 16:57:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:57:12 --> Email Class Initialized
INFO - 2020-04-07 16:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:57:12 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:57:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:57:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:57:13 --> Encryption Class Initialized
INFO - 2020-04-07 16:57:13 --> Controller Class Initialized
DEBUG - 2020-04-07 16:57:13 --> auth MX_Controller Initialized
INFO - 2020-04-07 16:57:13 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:57:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-07 16:57:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-07 16:57:13 --> Final output sent to browser
DEBUG - 2020-04-07 16:57:13 --> Total execution time: 1.0871
INFO - 2020-04-07 16:57:14 --> Config Class Initialized
INFO - 2020-04-07 16:57:14 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:57:14 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:57:14 --> Utf8 Class Initialized
INFO - 2020-04-07 16:57:14 --> URI Class Initialized
INFO - 2020-04-07 16:57:14 --> Router Class Initialized
INFO - 2020-04-07 16:57:14 --> Output Class Initialized
INFO - 2020-04-07 16:57:14 --> Security Class Initialized
DEBUG - 2020-04-07 16:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:57:14 --> CSRF cookie sent
INFO - 2020-04-07 16:57:14 --> CSRF token verified
INFO - 2020-04-07 16:57:14 --> Input Class Initialized
INFO - 2020-04-07 16:57:14 --> Language Class Initialized
INFO - 2020-04-07 16:57:14 --> Language Class Initialized
INFO - 2020-04-07 16:57:14 --> Config Class Initialized
INFO - 2020-04-07 16:57:14 --> Loader Class Initialized
INFO - 2020-04-07 16:57:14 --> Helper loaded: url_helper
INFO - 2020-04-07 16:57:14 --> Helper loaded: file_helper
INFO - 2020-04-07 16:57:14 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:57:14 --> Helper loaded: common_helper
INFO - 2020-04-07 16:57:14 --> Helper loaded: language_helper
INFO - 2020-04-07 16:57:14 --> Helper loaded: email_helper
INFO - 2020-04-07 16:57:14 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:57:15 --> Database Driver Class Initialized
INFO - 2020-04-07 16:57:15 --> Parser Class Initialized
INFO - 2020-04-07 16:57:15 --> User Agent Class Initialized
INFO - 2020-04-07 16:57:15 --> Model Class Initialized
INFO - 2020-04-07 16:57:15 --> Model Class Initialized
DEBUG - 2020-04-07 16:57:15 --> Template Class Initialized
INFO - 2020-04-07 16:57:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:57:15 --> Email Class Initialized
INFO - 2020-04-07 16:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:57:15 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:57:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:57:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:57:15 --> Encryption Class Initialized
INFO - 2020-04-07 16:57:15 --> Controller Class Initialized
DEBUG - 2020-04-07 16:57:15 --> auth MX_Controller Initialized
INFO - 2020-04-07 16:57:17 --> Config Class Initialized
INFO - 2020-04-07 16:57:17 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:57:17 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:57:17 --> Utf8 Class Initialized
INFO - 2020-04-07 16:57:17 --> URI Class Initialized
INFO - 2020-04-07 16:57:17 --> Router Class Initialized
INFO - 2020-04-07 16:57:17 --> Output Class Initialized
INFO - 2020-04-07 16:57:17 --> Security Class Initialized
DEBUG - 2020-04-07 16:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:57:17 --> CSRF cookie sent
INFO - 2020-04-07 16:57:17 --> Input Class Initialized
INFO - 2020-04-07 16:57:17 --> Language Class Initialized
INFO - 2020-04-07 16:57:17 --> Language Class Initialized
INFO - 2020-04-07 16:57:17 --> Config Class Initialized
INFO - 2020-04-07 16:57:17 --> Loader Class Initialized
INFO - 2020-04-07 16:57:17 --> Helper loaded: url_helper
INFO - 2020-04-07 16:57:17 --> Helper loaded: file_helper
INFO - 2020-04-07 16:57:17 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:57:17 --> Helper loaded: common_helper
INFO - 2020-04-07 16:57:17 --> Helper loaded: language_helper
INFO - 2020-04-07 16:57:17 --> Helper loaded: email_helper
INFO - 2020-04-07 16:57:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:57:17 --> Database Driver Class Initialized
INFO - 2020-04-07 16:57:17 --> Parser Class Initialized
INFO - 2020-04-07 16:57:17 --> User Agent Class Initialized
INFO - 2020-04-07 16:57:17 --> Model Class Initialized
INFO - 2020-04-07 16:57:17 --> Model Class Initialized
DEBUG - 2020-04-07 16:57:17 --> Template Class Initialized
INFO - 2020-04-07 16:57:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:57:17 --> Email Class Initialized
INFO - 2020-04-07 16:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:57:17 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:57:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:57:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:57:17 --> Encryption Class Initialized
INFO - 2020-04-07 16:57:17 --> Controller Class Initialized
DEBUG - 2020-04-07 16:57:17 --> dashboard MX_Controller Initialized
INFO - 2020-04-07 16:57:17 --> Model Class Initialized
DEBUG - 2020-04-07 16:57:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-07 16:57:17 --> Model Class Initialized
INFO - 2020-04-07 16:57:17 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:57:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-07 16:57:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-07 16:57:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 16:57:17 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 16:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 16:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 16:57:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 16:57:19 --> Final output sent to browser
DEBUG - 2020-04-07 16:57:19 --> Total execution time: 1.9820
INFO - 2020-04-07 16:59:45 --> Config Class Initialized
INFO - 2020-04-07 16:59:45 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:59:45 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:59:45 --> Utf8 Class Initialized
INFO - 2020-04-07 16:59:45 --> URI Class Initialized
INFO - 2020-04-07 16:59:45 --> Router Class Initialized
INFO - 2020-04-07 16:59:45 --> Output Class Initialized
INFO - 2020-04-07 16:59:45 --> Security Class Initialized
DEBUG - 2020-04-07 16:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:59:45 --> CSRF cookie sent
INFO - 2020-04-07 16:59:45 --> Input Class Initialized
INFO - 2020-04-07 16:59:45 --> Language Class Initialized
INFO - 2020-04-07 16:59:45 --> Language Class Initialized
INFO - 2020-04-07 16:59:45 --> Config Class Initialized
INFO - 2020-04-07 16:59:45 --> Loader Class Initialized
INFO - 2020-04-07 16:59:45 --> Helper loaded: url_helper
INFO - 2020-04-07 16:59:45 --> Helper loaded: file_helper
INFO - 2020-04-07 16:59:45 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:59:45 --> Helper loaded: common_helper
INFO - 2020-04-07 16:59:45 --> Helper loaded: language_helper
INFO - 2020-04-07 16:59:45 --> Helper loaded: email_helper
INFO - 2020-04-07 16:59:45 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:59:45 --> Database Driver Class Initialized
INFO - 2020-04-07 16:59:45 --> Parser Class Initialized
INFO - 2020-04-07 16:59:45 --> User Agent Class Initialized
INFO - 2020-04-07 16:59:45 --> Model Class Initialized
INFO - 2020-04-07 16:59:45 --> Model Class Initialized
DEBUG - 2020-04-07 16:59:45 --> Template Class Initialized
INFO - 2020-04-07 16:59:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:59:45 --> Email Class Initialized
INFO - 2020-04-07 16:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:59:45 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:59:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:59:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:59:45 --> Encryption Class Initialized
INFO - 2020-04-07 16:59:45 --> Controller Class Initialized
DEBUG - 2020-04-07 16:59:45 --> auth MX_Controller Initialized
INFO - 2020-04-07 16:59:45 --> Model Class Initialized
INFO - 2020-04-07 16:59:46 --> Config Class Initialized
INFO - 2020-04-07 16:59:46 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:59:46 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:59:46 --> Utf8 Class Initialized
INFO - 2020-04-07 16:59:46 --> URI Class Initialized
DEBUG - 2020-04-07 16:59:46 --> No URI present. Default controller set.
INFO - 2020-04-07 16:59:46 --> Router Class Initialized
INFO - 2020-04-07 16:59:46 --> Output Class Initialized
INFO - 2020-04-07 16:59:46 --> Security Class Initialized
DEBUG - 2020-04-07 16:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:59:46 --> CSRF cookie sent
INFO - 2020-04-07 16:59:46 --> Input Class Initialized
INFO - 2020-04-07 16:59:46 --> Language Class Initialized
INFO - 2020-04-07 16:59:46 --> Language Class Initialized
INFO - 2020-04-07 16:59:46 --> Config Class Initialized
INFO - 2020-04-07 16:59:46 --> Loader Class Initialized
INFO - 2020-04-07 16:59:46 --> Helper loaded: url_helper
INFO - 2020-04-07 16:59:46 --> Helper loaded: file_helper
INFO - 2020-04-07 16:59:46 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:59:46 --> Helper loaded: common_helper
INFO - 2020-04-07 16:59:46 --> Helper loaded: language_helper
INFO - 2020-04-07 16:59:46 --> Helper loaded: email_helper
INFO - 2020-04-07 16:59:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:59:46 --> Database Driver Class Initialized
INFO - 2020-04-07 16:59:46 --> Parser Class Initialized
INFO - 2020-04-07 16:59:46 --> User Agent Class Initialized
INFO - 2020-04-07 16:59:46 --> Model Class Initialized
INFO - 2020-04-07 16:59:46 --> Model Class Initialized
DEBUG - 2020-04-07 16:59:46 --> Template Class Initialized
INFO - 2020-04-07 16:59:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:59:46 --> Email Class Initialized
INFO - 2020-04-07 16:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:59:46 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:59:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:59:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:59:46 --> Encryption Class Initialized
INFO - 2020-04-07 16:59:46 --> Controller Class Initialized
DEBUG - 2020-04-07 16:59:46 --> home MX_Controller Initialized
INFO - 2020-04-07 16:59:46 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:59:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 16:59:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 16:59:46 --> Final output sent to browser
DEBUG - 2020-04-07 16:59:46 --> Total execution time: 0.5007
INFO - 2020-04-07 16:59:51 --> Config Class Initialized
INFO - 2020-04-07 16:59:51 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:59:51 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:59:51 --> Utf8 Class Initialized
INFO - 2020-04-07 16:59:51 --> URI Class Initialized
INFO - 2020-04-07 16:59:51 --> Router Class Initialized
INFO - 2020-04-07 16:59:51 --> Output Class Initialized
INFO - 2020-04-07 16:59:51 --> Security Class Initialized
DEBUG - 2020-04-07 16:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:59:51 --> CSRF cookie sent
INFO - 2020-04-07 16:59:51 --> Input Class Initialized
INFO - 2020-04-07 16:59:51 --> Language Class Initialized
INFO - 2020-04-07 16:59:51 --> Language Class Initialized
INFO - 2020-04-07 16:59:51 --> Config Class Initialized
INFO - 2020-04-07 16:59:51 --> Loader Class Initialized
INFO - 2020-04-07 16:59:51 --> Helper loaded: url_helper
INFO - 2020-04-07 16:59:51 --> Helper loaded: file_helper
INFO - 2020-04-07 16:59:51 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:59:51 --> Helper loaded: common_helper
INFO - 2020-04-07 16:59:51 --> Helper loaded: language_helper
INFO - 2020-04-07 16:59:51 --> Helper loaded: email_helper
INFO - 2020-04-07 16:59:52 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:59:52 --> Database Driver Class Initialized
INFO - 2020-04-07 16:59:52 --> Parser Class Initialized
INFO - 2020-04-07 16:59:52 --> User Agent Class Initialized
INFO - 2020-04-07 16:59:52 --> Model Class Initialized
INFO - 2020-04-07 16:59:52 --> Model Class Initialized
DEBUG - 2020-04-07 16:59:52 --> Template Class Initialized
INFO - 2020-04-07 16:59:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:59:52 --> Email Class Initialized
INFO - 2020-04-07 16:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:59:52 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:59:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:59:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:59:52 --> Encryption Class Initialized
INFO - 2020-04-07 16:59:52 --> Controller Class Initialized
DEBUG - 2020-04-07 16:59:52 --> auth MX_Controller Initialized
INFO - 2020-04-07 16:59:52 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-07 16:59:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-07 16:59:52 --> Final output sent to browser
DEBUG - 2020-04-07 16:59:52 --> Total execution time: 1.0230
INFO - 2020-04-07 16:59:54 --> Config Class Initialized
INFO - 2020-04-07 16:59:54 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:59:54 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:59:54 --> Utf8 Class Initialized
INFO - 2020-04-07 16:59:54 --> URI Class Initialized
INFO - 2020-04-07 16:59:54 --> Router Class Initialized
INFO - 2020-04-07 16:59:54 --> Output Class Initialized
INFO - 2020-04-07 16:59:54 --> Security Class Initialized
DEBUG - 2020-04-07 16:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:59:54 --> CSRF cookie sent
INFO - 2020-04-07 16:59:54 --> CSRF token verified
INFO - 2020-04-07 16:59:54 --> Input Class Initialized
INFO - 2020-04-07 16:59:54 --> Language Class Initialized
INFO - 2020-04-07 16:59:54 --> Language Class Initialized
INFO - 2020-04-07 16:59:54 --> Config Class Initialized
INFO - 2020-04-07 16:59:54 --> Loader Class Initialized
INFO - 2020-04-07 16:59:54 --> Helper loaded: url_helper
INFO - 2020-04-07 16:59:54 --> Helper loaded: file_helper
INFO - 2020-04-07 16:59:54 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:59:54 --> Helper loaded: common_helper
INFO - 2020-04-07 16:59:54 --> Helper loaded: language_helper
INFO - 2020-04-07 16:59:54 --> Helper loaded: email_helper
INFO - 2020-04-07 16:59:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:59:54 --> Database Driver Class Initialized
INFO - 2020-04-07 16:59:55 --> Parser Class Initialized
INFO - 2020-04-07 16:59:55 --> User Agent Class Initialized
INFO - 2020-04-07 16:59:55 --> Model Class Initialized
INFO - 2020-04-07 16:59:55 --> Model Class Initialized
DEBUG - 2020-04-07 16:59:55 --> Template Class Initialized
INFO - 2020-04-07 16:59:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:59:55 --> Email Class Initialized
INFO - 2020-04-07 16:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:59:55 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:59:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:59:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:59:55 --> Encryption Class Initialized
INFO - 2020-04-07 16:59:55 --> Controller Class Initialized
DEBUG - 2020-04-07 16:59:55 --> auth MX_Controller Initialized
INFO - 2020-04-07 16:59:57 --> Config Class Initialized
INFO - 2020-04-07 16:59:57 --> Hooks Class Initialized
DEBUG - 2020-04-07 16:59:57 --> UTF-8 Support Enabled
INFO - 2020-04-07 16:59:57 --> Utf8 Class Initialized
INFO - 2020-04-07 16:59:57 --> URI Class Initialized
INFO - 2020-04-07 16:59:57 --> Router Class Initialized
INFO - 2020-04-07 16:59:57 --> Output Class Initialized
INFO - 2020-04-07 16:59:57 --> Security Class Initialized
DEBUG - 2020-04-07 16:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 16:59:57 --> CSRF cookie sent
INFO - 2020-04-07 16:59:57 --> Input Class Initialized
INFO - 2020-04-07 16:59:57 --> Language Class Initialized
INFO - 2020-04-07 16:59:57 --> Language Class Initialized
INFO - 2020-04-07 16:59:57 --> Config Class Initialized
INFO - 2020-04-07 16:59:57 --> Loader Class Initialized
INFO - 2020-04-07 16:59:57 --> Helper loaded: url_helper
INFO - 2020-04-07 16:59:57 --> Helper loaded: file_helper
INFO - 2020-04-07 16:59:57 --> Helper loaded: cookie_helper
INFO - 2020-04-07 16:59:57 --> Helper loaded: common_helper
INFO - 2020-04-07 16:59:57 --> Helper loaded: language_helper
INFO - 2020-04-07 16:59:57 --> Helper loaded: email_helper
INFO - 2020-04-07 16:59:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 16:59:57 --> Database Driver Class Initialized
INFO - 2020-04-07 16:59:57 --> Parser Class Initialized
INFO - 2020-04-07 16:59:57 --> User Agent Class Initialized
INFO - 2020-04-07 16:59:57 --> Model Class Initialized
INFO - 2020-04-07 16:59:57 --> Model Class Initialized
DEBUG - 2020-04-07 16:59:57 --> Template Class Initialized
INFO - 2020-04-07 16:59:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 16:59:57 --> Email Class Initialized
INFO - 2020-04-07 16:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 16:59:57 --> Pagination Class Initialized
DEBUG - 2020-04-07 16:59:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 16:59:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 16:59:57 --> Encryption Class Initialized
INFO - 2020-04-07 16:59:57 --> Controller Class Initialized
DEBUG - 2020-04-07 16:59:57 --> dashboard MX_Controller Initialized
INFO - 2020-04-07 16:59:57 --> Model Class Initialized
DEBUG - 2020-04-07 16:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-07 16:59:57 --> Model Class Initialized
INFO - 2020-04-07 16:59:57 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 16:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-07 16:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-07 16:59:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 16:59:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 16:59:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 16:59:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 16:59:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 16:59:59 --> Final output sent to browser
DEBUG - 2020-04-07 16:59:59 --> Total execution time: 2.2530
INFO - 2020-04-07 17:00:02 --> Config Class Initialized
INFO - 2020-04-07 17:00:02 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:02 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:02 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:02 --> URI Class Initialized
INFO - 2020-04-07 17:00:02 --> Router Class Initialized
INFO - 2020-04-07 17:00:02 --> Output Class Initialized
INFO - 2020-04-07 17:00:02 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:02 --> CSRF cookie sent
INFO - 2020-04-07 17:00:02 --> CSRF token verified
INFO - 2020-04-07 17:00:02 --> Input Class Initialized
INFO - 2020-04-07 17:00:02 --> Language Class Initialized
INFO - 2020-04-07 17:00:02 --> Language Class Initialized
INFO - 2020-04-07 17:00:02 --> Config Class Initialized
INFO - 2020-04-07 17:00:02 --> Loader Class Initialized
INFO - 2020-04-07 17:00:02 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:02 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:02 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:02 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:02 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:02 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:02 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:02 --> Parser Class Initialized
INFO - 2020-04-07 17:00:02 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:02 --> Model Class Initialized
INFO - 2020-04-07 17:00:02 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:02 --> Template Class Initialized
INFO - 2020-04-07 17:00:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:02 --> Email Class Initialized
INFO - 2020-04-07 17:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:02 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:02 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:02 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:02 --> language MX_Controller Initialized
INFO - 2020-04-07 17:00:02 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-07 17:00:02 --> Model Class Initialized
INFO - 2020-04-07 17:00:04 --> Config Class Initialized
INFO - 2020-04-07 17:00:04 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:04 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:05 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:05 --> URI Class Initialized
INFO - 2020-04-07 17:00:05 --> Router Class Initialized
INFO - 2020-04-07 17:00:05 --> Output Class Initialized
INFO - 2020-04-07 17:00:05 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:05 --> CSRF cookie sent
INFO - 2020-04-07 17:00:05 --> Input Class Initialized
INFO - 2020-04-07 17:00:05 --> Language Class Initialized
INFO - 2020-04-07 17:00:05 --> Language Class Initialized
INFO - 2020-04-07 17:00:05 --> Config Class Initialized
INFO - 2020-04-07 17:00:05 --> Loader Class Initialized
INFO - 2020-04-07 17:00:05 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:05 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:05 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:05 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:05 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:05 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:05 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:05 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:05 --> Parser Class Initialized
INFO - 2020-04-07 17:00:05 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:05 --> Model Class Initialized
INFO - 2020-04-07 17:00:05 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:05 --> Template Class Initialized
INFO - 2020-04-07 17:00:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:05 --> Email Class Initialized
INFO - 2020-04-07 17:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:05 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:05 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:05 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:05 --> dashboard MX_Controller Initialized
INFO - 2020-04-07 17:00:05 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-07 17:00:05 --> Model Class Initialized
INFO - 2020-04-07 17:00:05 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:00:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-07 17:00:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-07 17:00:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:00:05 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:00:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:00:06 --> Final output sent to browser
DEBUG - 2020-04-07 17:00:06 --> Total execution time: 1.7424
INFO - 2020-04-07 17:00:10 --> Config Class Initialized
INFO - 2020-04-07 17:00:10 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:10 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:10 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:10 --> URI Class Initialized
INFO - 2020-04-07 17:00:10 --> Router Class Initialized
INFO - 2020-04-07 17:00:10 --> Output Class Initialized
INFO - 2020-04-07 17:00:10 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:10 --> CSRF cookie sent
INFO - 2020-04-07 17:00:10 --> Input Class Initialized
INFO - 2020-04-07 17:00:10 --> Language Class Initialized
INFO - 2020-04-07 17:00:10 --> Language Class Initialized
INFO - 2020-04-07 17:00:10 --> Config Class Initialized
INFO - 2020-04-07 17:00:10 --> Loader Class Initialized
INFO - 2020-04-07 17:00:10 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:10 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:10 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:10 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:10 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:10 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:10 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:10 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:10 --> Parser Class Initialized
INFO - 2020-04-07 17:00:10 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:10 --> Model Class Initialized
INFO - 2020-04-07 17:00:10 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:10 --> Template Class Initialized
INFO - 2020-04-07 17:00:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:10 --> Email Class Initialized
INFO - 2020-04-07 17:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:10 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:11 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:11 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:11 --> auth MX_Controller Initialized
INFO - 2020-04-07 17:00:11 --> Model Class Initialized
INFO - 2020-04-07 17:00:11 --> Config Class Initialized
INFO - 2020-04-07 17:00:11 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:11 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:11 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:11 --> URI Class Initialized
DEBUG - 2020-04-07 17:00:11 --> No URI present. Default controller set.
INFO - 2020-04-07 17:00:11 --> Router Class Initialized
INFO - 2020-04-07 17:00:11 --> Output Class Initialized
INFO - 2020-04-07 17:00:11 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:11 --> CSRF cookie sent
INFO - 2020-04-07 17:00:11 --> Input Class Initialized
INFO - 2020-04-07 17:00:11 --> Language Class Initialized
INFO - 2020-04-07 17:00:11 --> Language Class Initialized
INFO - 2020-04-07 17:00:11 --> Config Class Initialized
INFO - 2020-04-07 17:00:11 --> Loader Class Initialized
INFO - 2020-04-07 17:00:11 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:11 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:11 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:11 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:11 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:11 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:11 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:11 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:11 --> Parser Class Initialized
INFO - 2020-04-07 17:00:11 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:11 --> Model Class Initialized
INFO - 2020-04-07 17:00:11 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:11 --> Template Class Initialized
INFO - 2020-04-07 17:00:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:11 --> Email Class Initialized
INFO - 2020-04-07 17:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:11 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:11 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:11 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:11 --> home MX_Controller Initialized
INFO - 2020-04-07 17:00:11 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:00:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 17:00:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 17:00:11 --> Final output sent to browser
DEBUG - 2020-04-07 17:00:11 --> Total execution time: 0.4938
INFO - 2020-04-07 17:00:16 --> Config Class Initialized
INFO - 2020-04-07 17:00:16 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:16 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:16 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:16 --> URI Class Initialized
DEBUG - 2020-04-07 17:00:16 --> No URI present. Default controller set.
INFO - 2020-04-07 17:00:16 --> Router Class Initialized
INFO - 2020-04-07 17:00:16 --> Output Class Initialized
INFO - 2020-04-07 17:00:16 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:16 --> CSRF cookie sent
INFO - 2020-04-07 17:00:16 --> Input Class Initialized
INFO - 2020-04-07 17:00:16 --> Language Class Initialized
INFO - 2020-04-07 17:00:16 --> Language Class Initialized
INFO - 2020-04-07 17:00:16 --> Config Class Initialized
INFO - 2020-04-07 17:00:16 --> Loader Class Initialized
INFO - 2020-04-07 17:00:16 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:16 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:16 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:16 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:16 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:16 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:16 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:16 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:16 --> Parser Class Initialized
INFO - 2020-04-07 17:00:16 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:16 --> Model Class Initialized
INFO - 2020-04-07 17:00:16 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:17 --> Template Class Initialized
INFO - 2020-04-07 17:00:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:17 --> Email Class Initialized
INFO - 2020-04-07 17:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:17 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:17 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:17 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:17 --> home MX_Controller Initialized
INFO - 2020-04-07 17:00:17 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 17:00:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 17:00:17 --> Final output sent to browser
DEBUG - 2020-04-07 17:00:17 --> Total execution time: 1.1166
INFO - 2020-04-07 17:00:18 --> Config Class Initialized
INFO - 2020-04-07 17:00:18 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:18 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:18 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:18 --> URI Class Initialized
INFO - 2020-04-07 17:00:18 --> Router Class Initialized
INFO - 2020-04-07 17:00:18 --> Output Class Initialized
INFO - 2020-04-07 17:00:18 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:18 --> CSRF cookie sent
INFO - 2020-04-07 17:00:18 --> Input Class Initialized
INFO - 2020-04-07 17:00:18 --> Language Class Initialized
INFO - 2020-04-07 17:00:18 --> Language Class Initialized
INFO - 2020-04-07 17:00:19 --> Config Class Initialized
INFO - 2020-04-07 17:00:19 --> Loader Class Initialized
INFO - 2020-04-07 17:00:19 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:19 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:19 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:19 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:19 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:19 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:19 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:19 --> Parser Class Initialized
INFO - 2020-04-07 17:00:19 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:19 --> Model Class Initialized
INFO - 2020-04-07 17:00:19 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:19 --> Template Class Initialized
INFO - 2020-04-07 17:00:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:19 --> Email Class Initialized
INFO - 2020-04-07 17:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:19 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:19 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:19 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:19 --> auth MX_Controller Initialized
INFO - 2020-04-07 17:00:19 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-07 17:00:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-07 17:00:19 --> Final output sent to browser
DEBUG - 2020-04-07 17:00:19 --> Total execution time: 1.0538
INFO - 2020-04-07 17:00:21 --> Config Class Initialized
INFO - 2020-04-07 17:00:21 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:21 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:21 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:21 --> URI Class Initialized
INFO - 2020-04-07 17:00:21 --> Router Class Initialized
INFO - 2020-04-07 17:00:21 --> Output Class Initialized
INFO - 2020-04-07 17:00:21 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:21 --> CSRF cookie sent
INFO - 2020-04-07 17:00:21 --> CSRF token verified
INFO - 2020-04-07 17:00:21 --> Input Class Initialized
INFO - 2020-04-07 17:00:21 --> Language Class Initialized
INFO - 2020-04-07 17:00:21 --> Language Class Initialized
INFO - 2020-04-07 17:00:21 --> Config Class Initialized
INFO - 2020-04-07 17:00:21 --> Loader Class Initialized
INFO - 2020-04-07 17:00:21 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:21 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:21 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:21 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:21 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:21 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:21 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:21 --> Parser Class Initialized
INFO - 2020-04-07 17:00:21 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:21 --> Model Class Initialized
INFO - 2020-04-07 17:00:21 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:21 --> Template Class Initialized
INFO - 2020-04-07 17:00:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:21 --> Email Class Initialized
INFO - 2020-04-07 17:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:21 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:21 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:21 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:21 --> auth MX_Controller Initialized
INFO - 2020-04-07 17:00:23 --> Config Class Initialized
INFO - 2020-04-07 17:00:23 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:23 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:23 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:23 --> URI Class Initialized
INFO - 2020-04-07 17:00:23 --> Router Class Initialized
INFO - 2020-04-07 17:00:23 --> Output Class Initialized
INFO - 2020-04-07 17:00:23 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:23 --> CSRF cookie sent
INFO - 2020-04-07 17:00:23 --> Input Class Initialized
INFO - 2020-04-07 17:00:23 --> Language Class Initialized
INFO - 2020-04-07 17:00:23 --> Language Class Initialized
INFO - 2020-04-07 17:00:23 --> Config Class Initialized
INFO - 2020-04-07 17:00:23 --> Loader Class Initialized
INFO - 2020-04-07 17:00:23 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:23 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:23 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:23 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:23 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:23 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:24 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:24 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:24 --> Parser Class Initialized
INFO - 2020-04-07 17:00:24 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:24 --> Model Class Initialized
INFO - 2020-04-07 17:00:24 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:24 --> Template Class Initialized
INFO - 2020-04-07 17:00:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:24 --> Email Class Initialized
INFO - 2020-04-07 17:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:24 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:24 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:24 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:24 --> dashboard MX_Controller Initialized
INFO - 2020-04-07 17:00:24 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-07 17:00:24 --> Model Class Initialized
INFO - 2020-04-07 17:00:24 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:00:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-07 17:00:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-07 17:00:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:00:24 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:00:25 --> Final output sent to browser
DEBUG - 2020-04-07 17:00:25 --> Total execution time: 1.8886
INFO - 2020-04-07 17:00:27 --> Config Class Initialized
INFO - 2020-04-07 17:00:27 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:27 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:27 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:27 --> URI Class Initialized
INFO - 2020-04-07 17:00:27 --> Router Class Initialized
INFO - 2020-04-07 17:00:27 --> Output Class Initialized
INFO - 2020-04-07 17:00:27 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:27 --> CSRF cookie sent
INFO - 2020-04-07 17:00:27 --> Input Class Initialized
INFO - 2020-04-07 17:00:27 --> Language Class Initialized
INFO - 2020-04-07 17:00:27 --> Language Class Initialized
INFO - 2020-04-07 17:00:27 --> Config Class Initialized
INFO - 2020-04-07 17:00:27 --> Loader Class Initialized
INFO - 2020-04-07 17:00:27 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:27 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:27 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:28 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:28 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:28 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:28 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:28 --> Parser Class Initialized
INFO - 2020-04-07 17:00:28 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:28 --> Model Class Initialized
INFO - 2020-04-07 17:00:28 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:28 --> Template Class Initialized
INFO - 2020-04-07 17:00:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:28 --> Email Class Initialized
INFO - 2020-04-07 17:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:28 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:28 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:28 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:28 --> settings MX_Controller Initialized
INFO - 2020-04-07 17:00:28 --> Model Class Initialized
INFO - 2020-04-07 17:00:28 --> Config Class Initialized
INFO - 2020-04-07 17:00:28 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:28 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:28 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:28 --> URI Class Initialized
INFO - 2020-04-07 17:00:28 --> Router Class Initialized
INFO - 2020-04-07 17:00:28 --> Output Class Initialized
INFO - 2020-04-07 17:00:28 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:28 --> CSRF cookie sent
INFO - 2020-04-07 17:00:28 --> Input Class Initialized
INFO - 2020-04-07 17:00:28 --> Language Class Initialized
INFO - 2020-04-07 17:00:28 --> Language Class Initialized
INFO - 2020-04-07 17:00:28 --> Config Class Initialized
INFO - 2020-04-07 17:00:28 --> Loader Class Initialized
INFO - 2020-04-07 17:00:28 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:28 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:28 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:28 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:28 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:28 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:28 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:28 --> Parser Class Initialized
INFO - 2020-04-07 17:00:28 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:28 --> Model Class Initialized
INFO - 2020-04-07 17:00:28 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:28 --> Template Class Initialized
INFO - 2020-04-07 17:00:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:28 --> Email Class Initialized
INFO - 2020-04-07 17:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:28 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:28 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:28 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:28 --> settings MX_Controller Initialized
INFO - 2020-04-07 17:00:28 --> Model Class Initialized
INFO - 2020-04-07 17:00:28 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:00:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/website_settings.php
DEBUG - 2020-04-07 17:00:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/settings/views/index.php
DEBUG - 2020-04-07 17:00:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:00:28 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:00:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:00:31 --> Final output sent to browser
DEBUG - 2020-04-07 17:00:32 --> Total execution time: 3.7275
INFO - 2020-04-07 17:00:35 --> Config Class Initialized
INFO - 2020-04-07 17:00:35 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:35 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:35 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:35 --> URI Class Initialized
INFO - 2020-04-07 17:00:35 --> Router Class Initialized
INFO - 2020-04-07 17:00:35 --> Output Class Initialized
INFO - 2020-04-07 17:00:35 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:35 --> CSRF cookie sent
INFO - 2020-04-07 17:00:35 --> Input Class Initialized
INFO - 2020-04-07 17:00:35 --> Language Class Initialized
INFO - 2020-04-07 17:00:35 --> Language Class Initialized
INFO - 2020-04-07 17:00:35 --> Config Class Initialized
INFO - 2020-04-07 17:00:35 --> Loader Class Initialized
INFO - 2020-04-07 17:00:35 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:35 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:35 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:35 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:35 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:35 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:35 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:35 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:35 --> Parser Class Initialized
INFO - 2020-04-07 17:00:35 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:35 --> Model Class Initialized
INFO - 2020-04-07 17:00:35 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:35 --> Template Class Initialized
INFO - 2020-04-07 17:00:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:36 --> Email Class Initialized
INFO - 2020-04-07 17:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:36 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:36 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:36 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:36 --> language MX_Controller Initialized
INFO - 2020-04-07 17:00:36 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-07 17:00:36 --> Model Class Initialized
ERROR - 2020-04-07 17:00:36 --> Could not find the language line ""
DEBUG - 2020-04-07 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/views/index.php
DEBUG - 2020-04-07 17:00:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:00:36 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:00:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:00:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:00:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:00:37 --> Final output sent to browser
DEBUG - 2020-04-07 17:00:37 --> Total execution time: 2.0389
INFO - 2020-04-07 17:00:42 --> Config Class Initialized
INFO - 2020-04-07 17:00:42 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:42 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:42 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:42 --> URI Class Initialized
INFO - 2020-04-07 17:00:42 --> Router Class Initialized
INFO - 2020-04-07 17:00:42 --> Output Class Initialized
INFO - 2020-04-07 17:00:42 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:42 --> CSRF cookie sent
INFO - 2020-04-07 17:00:42 --> Input Class Initialized
INFO - 2020-04-07 17:00:42 --> Language Class Initialized
INFO - 2020-04-07 17:00:42 --> Language Class Initialized
INFO - 2020-04-07 17:00:42 --> Config Class Initialized
INFO - 2020-04-07 17:00:42 --> Loader Class Initialized
INFO - 2020-04-07 17:00:42 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:42 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:42 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:42 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:42 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:42 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:42 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:42 --> Parser Class Initialized
INFO - 2020-04-07 17:00:42 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:42 --> Model Class Initialized
INFO - 2020-04-07 17:00:43 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:43 --> Template Class Initialized
INFO - 2020-04-07 17:00:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:43 --> Email Class Initialized
INFO - 2020-04-07 17:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:43 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:43 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:43 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:43 --> language MX_Controller Initialized
INFO - 2020-04-07 17:00:43 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-07 17:00:43 --> Model Class Initialized
INFO - 2020-04-07 17:00:43 --> Helper loaded: inflector_helper
ERROR - 2020-04-07 17:00:43 --> Could not find the language line ""
DEBUG - 2020-04-07 17:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/views/edit.php
DEBUG - 2020-04-07 17:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:00:43 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:00:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:00:44 --> Final output sent to browser
DEBUG - 2020-04-07 17:00:44 --> Total execution time: 1.7706
INFO - 2020-04-07 17:00:53 --> Config Class Initialized
INFO - 2020-04-07 17:00:53 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:53 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:53 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:53 --> URI Class Initialized
INFO - 2020-04-07 17:00:53 --> Router Class Initialized
INFO - 2020-04-07 17:00:53 --> Output Class Initialized
INFO - 2020-04-07 17:00:53 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:53 --> CSRF cookie sent
INFO - 2020-04-07 17:00:53 --> CSRF token verified
INFO - 2020-04-07 17:00:53 --> Input Class Initialized
INFO - 2020-04-07 17:00:53 --> Language Class Initialized
INFO - 2020-04-07 17:00:53 --> Language Class Initialized
INFO - 2020-04-07 17:00:53 --> Config Class Initialized
INFO - 2020-04-07 17:00:54 --> Loader Class Initialized
INFO - 2020-04-07 17:00:54 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:54 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:54 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:54 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:54 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:54 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:54 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:54 --> Parser Class Initialized
INFO - 2020-04-07 17:00:54 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:54 --> Model Class Initialized
INFO - 2020-04-07 17:00:54 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:54 --> Template Class Initialized
INFO - 2020-04-07 17:00:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:54 --> Email Class Initialized
INFO - 2020-04-07 17:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:54 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:54 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:54 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:54 --> language MX_Controller Initialized
INFO - 2020-04-07 17:00:54 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-07 17:00:54 --> Model Class Initialized
INFO - 2020-04-07 17:00:57 --> Config Class Initialized
INFO - 2020-04-07 17:00:57 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:00:57 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:00:57 --> Utf8 Class Initialized
INFO - 2020-04-07 17:00:57 --> URI Class Initialized
INFO - 2020-04-07 17:00:57 --> Router Class Initialized
INFO - 2020-04-07 17:00:57 --> Output Class Initialized
INFO - 2020-04-07 17:00:57 --> Security Class Initialized
DEBUG - 2020-04-07 17:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:00:57 --> CSRF cookie sent
INFO - 2020-04-07 17:00:57 --> Input Class Initialized
INFO - 2020-04-07 17:00:57 --> Language Class Initialized
INFO - 2020-04-07 17:00:57 --> Language Class Initialized
INFO - 2020-04-07 17:00:57 --> Config Class Initialized
INFO - 2020-04-07 17:00:57 --> Loader Class Initialized
INFO - 2020-04-07 17:00:57 --> Helper loaded: url_helper
INFO - 2020-04-07 17:00:57 --> Helper loaded: file_helper
INFO - 2020-04-07 17:00:57 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:00:57 --> Helper loaded: common_helper
INFO - 2020-04-07 17:00:57 --> Helper loaded: language_helper
INFO - 2020-04-07 17:00:57 --> Helper loaded: email_helper
INFO - 2020-04-07 17:00:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:00:57 --> Database Driver Class Initialized
INFO - 2020-04-07 17:00:57 --> Parser Class Initialized
INFO - 2020-04-07 17:00:58 --> User Agent Class Initialized
INFO - 2020-04-07 17:00:58 --> Model Class Initialized
INFO - 2020-04-07 17:00:58 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:58 --> Template Class Initialized
INFO - 2020-04-07 17:00:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:00:58 --> Email Class Initialized
INFO - 2020-04-07 17:00:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:00:58 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:00:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:00:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:00:58 --> Encryption Class Initialized
INFO - 2020-04-07 17:00:58 --> Controller Class Initialized
DEBUG - 2020-04-07 17:00:58 --> language MX_Controller Initialized
INFO - 2020-04-07 17:00:58 --> Model Class Initialized
DEBUG - 2020-04-07 17:00:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-07 17:00:58 --> Model Class Initialized
ERROR - 2020-04-07 17:00:58 --> Could not find the language line ""
DEBUG - 2020-04-07 17:00:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/views/index.php
DEBUG - 2020-04-07 17:00:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:00:58 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:01:01 --> Final output sent to browser
DEBUG - 2020-04-07 17:01:01 --> Total execution time: 3.5692
INFO - 2020-04-07 17:01:07 --> Config Class Initialized
INFO - 2020-04-07 17:01:07 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:01:07 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:01:07 --> Utf8 Class Initialized
INFO - 2020-04-07 17:01:07 --> URI Class Initialized
INFO - 2020-04-07 17:01:07 --> Router Class Initialized
INFO - 2020-04-07 17:01:07 --> Output Class Initialized
INFO - 2020-04-07 17:01:07 --> Security Class Initialized
DEBUG - 2020-04-07 17:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:01:07 --> CSRF cookie sent
INFO - 2020-04-07 17:01:07 --> Input Class Initialized
INFO - 2020-04-07 17:01:07 --> Language Class Initialized
INFO - 2020-04-07 17:01:07 --> Language Class Initialized
INFO - 2020-04-07 17:01:07 --> Config Class Initialized
INFO - 2020-04-07 17:01:07 --> Loader Class Initialized
INFO - 2020-04-07 17:01:07 --> Helper loaded: url_helper
INFO - 2020-04-07 17:01:07 --> Helper loaded: file_helper
INFO - 2020-04-07 17:01:07 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:01:07 --> Helper loaded: common_helper
INFO - 2020-04-07 17:01:07 --> Helper loaded: language_helper
INFO - 2020-04-07 17:01:07 --> Helper loaded: email_helper
INFO - 2020-04-07 17:01:07 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:01:07 --> Database Driver Class Initialized
INFO - 2020-04-07 17:01:07 --> Parser Class Initialized
INFO - 2020-04-07 17:01:07 --> User Agent Class Initialized
INFO - 2020-04-07 17:01:07 --> Model Class Initialized
INFO - 2020-04-07 17:01:07 --> Model Class Initialized
DEBUG - 2020-04-07 17:01:08 --> Template Class Initialized
INFO - 2020-04-07 17:01:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:01:08 --> Email Class Initialized
INFO - 2020-04-07 17:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:01:08 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:01:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:01:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:01:08 --> Encryption Class Initialized
INFO - 2020-04-07 17:01:08 --> Controller Class Initialized
DEBUG - 2020-04-07 17:01:08 --> language MX_Controller Initialized
INFO - 2020-04-07 17:01:08 --> Model Class Initialized
DEBUG - 2020-04-07 17:01:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-07 17:01:08 --> Model Class Initialized
INFO - 2020-04-07 17:01:08 --> Helper loaded: inflector_helper
ERROR - 2020-04-07 17:01:08 --> Could not find the language line ""
DEBUG - 2020-04-07 17:01:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/views/edit.php
DEBUG - 2020-04-07 17:01:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:01:08 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:01:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:01:10 --> Final output sent to browser
DEBUG - 2020-04-07 17:01:10 --> Total execution time: 2.6635
INFO - 2020-04-07 17:01:27 --> Config Class Initialized
INFO - 2020-04-07 17:01:27 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:01:27 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:01:27 --> Utf8 Class Initialized
INFO - 2020-04-07 17:01:27 --> URI Class Initialized
INFO - 2020-04-07 17:01:27 --> Router Class Initialized
INFO - 2020-04-07 17:01:27 --> Output Class Initialized
INFO - 2020-04-07 17:01:27 --> Security Class Initialized
DEBUG - 2020-04-07 17:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:01:27 --> CSRF cookie sent
INFO - 2020-04-07 17:01:27 --> CSRF token verified
INFO - 2020-04-07 17:01:28 --> Input Class Initialized
INFO - 2020-04-07 17:01:28 --> Language Class Initialized
INFO - 2020-04-07 17:01:28 --> Language Class Initialized
INFO - 2020-04-07 17:01:28 --> Config Class Initialized
INFO - 2020-04-07 17:01:28 --> Loader Class Initialized
INFO - 2020-04-07 17:01:28 --> Helper loaded: url_helper
INFO - 2020-04-07 17:01:28 --> Helper loaded: file_helper
INFO - 2020-04-07 17:01:28 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:01:28 --> Helper loaded: common_helper
INFO - 2020-04-07 17:01:28 --> Helper loaded: language_helper
INFO - 2020-04-07 17:01:28 --> Helper loaded: email_helper
INFO - 2020-04-07 17:01:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:01:28 --> Database Driver Class Initialized
INFO - 2020-04-07 17:01:28 --> Parser Class Initialized
INFO - 2020-04-07 17:01:28 --> User Agent Class Initialized
INFO - 2020-04-07 17:01:28 --> Model Class Initialized
INFO - 2020-04-07 17:01:28 --> Model Class Initialized
DEBUG - 2020-04-07 17:01:28 --> Template Class Initialized
INFO - 2020-04-07 17:01:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:01:28 --> Email Class Initialized
INFO - 2020-04-07 17:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:01:28 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:01:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:01:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:01:28 --> Encryption Class Initialized
INFO - 2020-04-07 17:01:28 --> Controller Class Initialized
DEBUG - 2020-04-07 17:01:28 --> language MX_Controller Initialized
INFO - 2020-04-07 17:01:28 --> Model Class Initialized
DEBUG - 2020-04-07 17:01:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-07 17:01:28 --> Model Class Initialized
INFO - 2020-04-07 17:01:32 --> Config Class Initialized
INFO - 2020-04-07 17:01:32 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:01:32 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:01:32 --> Utf8 Class Initialized
INFO - 2020-04-07 17:01:32 --> URI Class Initialized
INFO - 2020-04-07 17:01:32 --> Router Class Initialized
INFO - 2020-04-07 17:01:32 --> Output Class Initialized
INFO - 2020-04-07 17:01:32 --> Security Class Initialized
DEBUG - 2020-04-07 17:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:01:32 --> CSRF cookie sent
INFO - 2020-04-07 17:01:32 --> Input Class Initialized
INFO - 2020-04-07 17:01:32 --> Language Class Initialized
INFO - 2020-04-07 17:01:32 --> Language Class Initialized
INFO - 2020-04-07 17:01:32 --> Config Class Initialized
INFO - 2020-04-07 17:01:32 --> Loader Class Initialized
INFO - 2020-04-07 17:01:32 --> Helper loaded: url_helper
INFO - 2020-04-07 17:01:32 --> Helper loaded: file_helper
INFO - 2020-04-07 17:01:32 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:01:32 --> Helper loaded: common_helper
INFO - 2020-04-07 17:01:32 --> Helper loaded: language_helper
INFO - 2020-04-07 17:01:32 --> Helper loaded: email_helper
INFO - 2020-04-07 17:01:32 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:01:32 --> Database Driver Class Initialized
INFO - 2020-04-07 17:01:32 --> Parser Class Initialized
INFO - 2020-04-07 17:01:32 --> User Agent Class Initialized
INFO - 2020-04-07 17:01:32 --> Model Class Initialized
INFO - 2020-04-07 17:01:32 --> Model Class Initialized
DEBUG - 2020-04-07 17:01:32 --> Template Class Initialized
INFO - 2020-04-07 17:01:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:01:32 --> Email Class Initialized
INFO - 2020-04-07 17:01:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:01:32 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:01:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:01:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:01:32 --> Encryption Class Initialized
INFO - 2020-04-07 17:01:32 --> Controller Class Initialized
DEBUG - 2020-04-07 17:01:32 --> language MX_Controller Initialized
INFO - 2020-04-07 17:01:32 --> Model Class Initialized
DEBUG - 2020-04-07 17:01:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/models/language_model.php
INFO - 2020-04-07 17:01:32 --> Model Class Initialized
ERROR - 2020-04-07 17:01:32 --> Could not find the language line ""
DEBUG - 2020-04-07 17:01:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/language/views/index.php
DEBUG - 2020-04-07 17:01:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:01:32 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:01:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:01:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:01:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:01:33 --> Final output sent to browser
DEBUG - 2020-04-07 17:01:33 --> Total execution time: 1.8806
INFO - 2020-04-07 17:01:38 --> Config Class Initialized
INFO - 2020-04-07 17:01:39 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:01:39 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:01:39 --> Utf8 Class Initialized
INFO - 2020-04-07 17:01:39 --> URI Class Initialized
INFO - 2020-04-07 17:01:39 --> Router Class Initialized
INFO - 2020-04-07 17:01:39 --> Output Class Initialized
INFO - 2020-04-07 17:01:39 --> Security Class Initialized
DEBUG - 2020-04-07 17:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:01:39 --> CSRF cookie sent
INFO - 2020-04-07 17:01:39 --> Input Class Initialized
INFO - 2020-04-07 17:01:39 --> Language Class Initialized
INFO - 2020-04-07 17:01:39 --> Language Class Initialized
INFO - 2020-04-07 17:01:39 --> Config Class Initialized
INFO - 2020-04-07 17:01:39 --> Loader Class Initialized
INFO - 2020-04-07 17:01:39 --> Helper loaded: url_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: file_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: common_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: language_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: email_helper
INFO - 2020-04-07 17:01:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:01:39 --> Database Driver Class Initialized
INFO - 2020-04-07 17:01:39 --> Parser Class Initialized
INFO - 2020-04-07 17:01:39 --> User Agent Class Initialized
INFO - 2020-04-07 17:01:39 --> Model Class Initialized
INFO - 2020-04-07 17:01:39 --> Model Class Initialized
DEBUG - 2020-04-07 17:01:39 --> Template Class Initialized
INFO - 2020-04-07 17:01:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:01:39 --> Email Class Initialized
INFO - 2020-04-07 17:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:01:39 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:01:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:01:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:01:39 --> Encryption Class Initialized
INFO - 2020-04-07 17:01:39 --> Controller Class Initialized
DEBUG - 2020-04-07 17:01:39 --> auth MX_Controller Initialized
INFO - 2020-04-07 17:01:39 --> Model Class Initialized
INFO - 2020-04-07 17:01:39 --> Config Class Initialized
INFO - 2020-04-07 17:01:39 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:01:39 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:01:39 --> Utf8 Class Initialized
INFO - 2020-04-07 17:01:39 --> URI Class Initialized
DEBUG - 2020-04-07 17:01:39 --> No URI present. Default controller set.
INFO - 2020-04-07 17:01:39 --> Router Class Initialized
INFO - 2020-04-07 17:01:39 --> Output Class Initialized
INFO - 2020-04-07 17:01:39 --> Security Class Initialized
DEBUG - 2020-04-07 17:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:01:39 --> CSRF cookie sent
INFO - 2020-04-07 17:01:39 --> Input Class Initialized
INFO - 2020-04-07 17:01:39 --> Language Class Initialized
INFO - 2020-04-07 17:01:39 --> Language Class Initialized
INFO - 2020-04-07 17:01:39 --> Config Class Initialized
INFO - 2020-04-07 17:01:39 --> Loader Class Initialized
INFO - 2020-04-07 17:01:39 --> Helper loaded: url_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: file_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: common_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: language_helper
INFO - 2020-04-07 17:01:39 --> Helper loaded: email_helper
INFO - 2020-04-07 17:01:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:01:39 --> Database Driver Class Initialized
INFO - 2020-04-07 17:01:39 --> Parser Class Initialized
INFO - 2020-04-07 17:01:39 --> User Agent Class Initialized
INFO - 2020-04-07 17:01:39 --> Model Class Initialized
INFO - 2020-04-07 17:01:39 --> Model Class Initialized
DEBUG - 2020-04-07 17:01:39 --> Template Class Initialized
INFO - 2020-04-07 17:01:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:01:39 --> Email Class Initialized
INFO - 2020-04-07 17:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:01:39 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:01:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:01:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:01:39 --> Encryption Class Initialized
INFO - 2020-04-07 17:01:39 --> Controller Class Initialized
DEBUG - 2020-04-07 17:01:39 --> home MX_Controller Initialized
INFO - 2020-04-07 17:01:39 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:01:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 17:01:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 17:01:40 --> Final output sent to browser
DEBUG - 2020-04-07 17:01:40 --> Total execution time: 0.5380
INFO - 2020-04-07 17:01:53 --> Config Class Initialized
INFO - 2020-04-07 17:01:53 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:01:53 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:01:53 --> Utf8 Class Initialized
INFO - 2020-04-07 17:01:53 --> URI Class Initialized
INFO - 2020-04-07 17:01:53 --> Router Class Initialized
INFO - 2020-04-07 17:01:53 --> Output Class Initialized
INFO - 2020-04-07 17:01:53 --> Security Class Initialized
DEBUG - 2020-04-07 17:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:01:53 --> CSRF cookie sent
INFO - 2020-04-07 17:01:53 --> Input Class Initialized
INFO - 2020-04-07 17:01:53 --> Language Class Initialized
INFO - 2020-04-07 17:01:54 --> Language Class Initialized
INFO - 2020-04-07 17:01:54 --> Config Class Initialized
INFO - 2020-04-07 17:01:54 --> Loader Class Initialized
INFO - 2020-04-07 17:01:54 --> Helper loaded: url_helper
INFO - 2020-04-07 17:01:54 --> Helper loaded: file_helper
INFO - 2020-04-07 17:01:54 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:01:54 --> Helper loaded: common_helper
INFO - 2020-04-07 17:01:54 --> Helper loaded: language_helper
INFO - 2020-04-07 17:01:54 --> Helper loaded: email_helper
INFO - 2020-04-07 17:01:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:01:54 --> Database Driver Class Initialized
INFO - 2020-04-07 17:01:54 --> Parser Class Initialized
INFO - 2020-04-07 17:01:54 --> User Agent Class Initialized
INFO - 2020-04-07 17:01:54 --> Model Class Initialized
INFO - 2020-04-07 17:01:54 --> Model Class Initialized
DEBUG - 2020-04-07 17:01:54 --> Template Class Initialized
INFO - 2020-04-07 17:01:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:01:54 --> Email Class Initialized
INFO - 2020-04-07 17:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:01:54 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:01:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:01:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:01:54 --> Encryption Class Initialized
INFO - 2020-04-07 17:01:54 --> Controller Class Initialized
ERROR - 2020-04-07 17:01:54 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:01:54 --> Config Class Initialized
INFO - 2020-04-07 17:01:54 --> Config Class Initialized
INFO - 2020-04-07 17:01:54 --> Config Class Initialized
INFO - 2020-04-07 17:01:54 --> Hooks Class Initialized
INFO - 2020-04-07 17:01:54 --> Hooks Class Initialized
INFO - 2020-04-07 17:01:54 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:01:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 17:01:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 17:01:54 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:01:54 --> Utf8 Class Initialized
INFO - 2020-04-07 17:01:54 --> Utf8 Class Initialized
INFO - 2020-04-07 17:01:54 --> Utf8 Class Initialized
INFO - 2020-04-07 17:01:54 --> URI Class Initialized
INFO - 2020-04-07 17:01:54 --> URI Class Initialized
INFO - 2020-04-07 17:01:54 --> URI Class Initialized
INFO - 2020-04-07 17:01:54 --> Router Class Initialized
INFO - 2020-04-07 17:01:54 --> Router Class Initialized
INFO - 2020-04-07 17:01:54 --> Router Class Initialized
INFO - 2020-04-07 17:01:54 --> Output Class Initialized
INFO - 2020-04-07 17:01:54 --> Output Class Initialized
INFO - 2020-04-07 17:01:54 --> Output Class Initialized
INFO - 2020-04-07 17:01:54 --> Security Class Initialized
INFO - 2020-04-07 17:01:54 --> Security Class Initialized
INFO - 2020-04-07 17:01:54 --> Security Class Initialized
DEBUG - 2020-04-07 17:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 17:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 17:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:01:54 --> CSRF cookie sent
INFO - 2020-04-07 17:01:54 --> CSRF cookie sent
INFO - 2020-04-07 17:01:54 --> CSRF cookie sent
INFO - 2020-04-07 17:01:54 --> Input Class Initialized
INFO - 2020-04-07 17:01:54 --> Input Class Initialized
INFO - 2020-04-07 17:01:54 --> Input Class Initialized
INFO - 2020-04-07 17:01:54 --> Language Class Initialized
INFO - 2020-04-07 17:01:54 --> Language Class Initialized
INFO - 2020-04-07 17:01:54 --> Language Class Initialized
ERROR - 2020-04-07 17:01:54 --> 404 Page Not Found: /index
ERROR - 2020-04-07 17:01:54 --> 404 Page Not Found: /index
ERROR - 2020-04-07 17:01:54 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:03:38 --> Config Class Initialized
INFO - 2020-04-07 17:03:38 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:03:38 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:03:38 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:38 --> URI Class Initialized
DEBUG - 2020-04-07 17:03:38 --> No URI present. Default controller set.
INFO - 2020-04-07 17:03:38 --> Router Class Initialized
INFO - 2020-04-07 17:03:39 --> Output Class Initialized
INFO - 2020-04-07 17:03:39 --> Security Class Initialized
DEBUG - 2020-04-07 17:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:03:39 --> CSRF cookie sent
INFO - 2020-04-07 17:03:39 --> Input Class Initialized
INFO - 2020-04-07 17:03:39 --> Language Class Initialized
INFO - 2020-04-07 17:03:39 --> Language Class Initialized
INFO - 2020-04-07 17:03:39 --> Config Class Initialized
INFO - 2020-04-07 17:03:39 --> Loader Class Initialized
INFO - 2020-04-07 17:03:39 --> Helper loaded: url_helper
INFO - 2020-04-07 17:03:39 --> Helper loaded: file_helper
INFO - 2020-04-07 17:03:39 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:03:39 --> Helper loaded: common_helper
INFO - 2020-04-07 17:03:39 --> Helper loaded: language_helper
INFO - 2020-04-07 17:03:39 --> Helper loaded: email_helper
INFO - 2020-04-07 17:03:39 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:03:39 --> Database Driver Class Initialized
INFO - 2020-04-07 17:03:39 --> Parser Class Initialized
INFO - 2020-04-07 17:03:39 --> User Agent Class Initialized
INFO - 2020-04-07 17:03:39 --> Model Class Initialized
INFO - 2020-04-07 17:03:39 --> Model Class Initialized
DEBUG - 2020-04-07 17:03:39 --> Template Class Initialized
INFO - 2020-04-07 17:03:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:03:39 --> Email Class Initialized
INFO - 2020-04-07 17:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:03:39 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:03:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:03:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:03:39 --> Encryption Class Initialized
INFO - 2020-04-07 17:03:39 --> Controller Class Initialized
DEBUG - 2020-04-07 17:03:39 --> home MX_Controller Initialized
INFO - 2020-04-07 17:03:39 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:03:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 17:03:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 17:03:40 --> Final output sent to browser
DEBUG - 2020-04-07 17:03:40 --> Total execution time: 1.2921
INFO - 2020-04-07 17:03:41 --> Config Class Initialized
INFO - 2020-04-07 17:03:41 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:03:42 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:03:42 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:42 --> URI Class Initialized
INFO - 2020-04-07 17:03:42 --> Router Class Initialized
INFO - 2020-04-07 17:03:42 --> Output Class Initialized
INFO - 2020-04-07 17:03:42 --> Security Class Initialized
DEBUG - 2020-04-07 17:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:03:42 --> CSRF cookie sent
INFO - 2020-04-07 17:03:42 --> Input Class Initialized
INFO - 2020-04-07 17:03:42 --> Language Class Initialized
INFO - 2020-04-07 17:03:42 --> Language Class Initialized
INFO - 2020-04-07 17:03:42 --> Config Class Initialized
INFO - 2020-04-07 17:03:42 --> Loader Class Initialized
INFO - 2020-04-07 17:03:42 --> Helper loaded: url_helper
INFO - 2020-04-07 17:03:42 --> Helper loaded: file_helper
INFO - 2020-04-07 17:03:42 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:03:42 --> Helper loaded: common_helper
INFO - 2020-04-07 17:03:42 --> Helper loaded: language_helper
INFO - 2020-04-07 17:03:42 --> Helper loaded: email_helper
INFO - 2020-04-07 17:03:42 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:03:42 --> Database Driver Class Initialized
INFO - 2020-04-07 17:03:42 --> Parser Class Initialized
INFO - 2020-04-07 17:03:42 --> User Agent Class Initialized
INFO - 2020-04-07 17:03:42 --> Model Class Initialized
INFO - 2020-04-07 17:03:42 --> Model Class Initialized
DEBUG - 2020-04-07 17:03:42 --> Template Class Initialized
INFO - 2020-04-07 17:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:03:42 --> Email Class Initialized
INFO - 2020-04-07 17:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:03:42 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:03:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:03:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:03:42 --> Encryption Class Initialized
INFO - 2020-04-07 17:03:42 --> Controller Class Initialized
ERROR - 2020-04-07 17:03:42 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:03:43 --> Config Class Initialized
INFO - 2020-04-07 17:03:43 --> Config Class Initialized
INFO - 2020-04-07 17:03:43 --> Config Class Initialized
INFO - 2020-04-07 17:03:43 --> Hooks Class Initialized
INFO - 2020-04-07 17:03:43 --> Hooks Class Initialized
INFO - 2020-04-07 17:03:43 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:03:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 17:03:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 17:03:43 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:03:43 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:43 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:43 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:43 --> URI Class Initialized
INFO - 2020-04-07 17:03:43 --> URI Class Initialized
INFO - 2020-04-07 17:03:43 --> URI Class Initialized
INFO - 2020-04-07 17:03:43 --> Router Class Initialized
INFO - 2020-04-07 17:03:43 --> Router Class Initialized
INFO - 2020-04-07 17:03:43 --> Router Class Initialized
INFO - 2020-04-07 17:03:43 --> Output Class Initialized
INFO - 2020-04-07 17:03:43 --> Output Class Initialized
INFO - 2020-04-07 17:03:43 --> Output Class Initialized
INFO - 2020-04-07 17:03:43 --> Security Class Initialized
INFO - 2020-04-07 17:03:43 --> Security Class Initialized
INFO - 2020-04-07 17:03:43 --> Security Class Initialized
DEBUG - 2020-04-07 17:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 17:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 17:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:03:43 --> CSRF cookie sent
INFO - 2020-04-07 17:03:43 --> CSRF cookie sent
INFO - 2020-04-07 17:03:43 --> CSRF cookie sent
INFO - 2020-04-07 17:03:43 --> Input Class Initialized
INFO - 2020-04-07 17:03:43 --> Input Class Initialized
INFO - 2020-04-07 17:03:43 --> Input Class Initialized
INFO - 2020-04-07 17:03:43 --> Language Class Initialized
INFO - 2020-04-07 17:03:43 --> Language Class Initialized
INFO - 2020-04-07 17:03:43 --> Language Class Initialized
ERROR - 2020-04-07 17:03:43 --> 404 Page Not Found: /index
ERROR - 2020-04-07 17:03:43 --> 404 Page Not Found: /index
ERROR - 2020-04-07 17:03:43 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:03:47 --> Config Class Initialized
INFO - 2020-04-07 17:03:47 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:03:47 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:03:47 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:47 --> URI Class Initialized
DEBUG - 2020-04-07 17:03:47 --> No URI present. Default controller set.
INFO - 2020-04-07 17:03:47 --> Router Class Initialized
INFO - 2020-04-07 17:03:48 --> Output Class Initialized
INFO - 2020-04-07 17:03:48 --> Security Class Initialized
DEBUG - 2020-04-07 17:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:03:48 --> CSRF cookie sent
INFO - 2020-04-07 17:03:48 --> Input Class Initialized
INFO - 2020-04-07 17:03:48 --> Language Class Initialized
INFO - 2020-04-07 17:03:48 --> Language Class Initialized
INFO - 2020-04-07 17:03:48 --> Config Class Initialized
INFO - 2020-04-07 17:03:48 --> Loader Class Initialized
INFO - 2020-04-07 17:03:48 --> Helper loaded: url_helper
INFO - 2020-04-07 17:03:48 --> Helper loaded: file_helper
INFO - 2020-04-07 17:03:48 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:03:48 --> Helper loaded: common_helper
INFO - 2020-04-07 17:03:48 --> Helper loaded: language_helper
INFO - 2020-04-07 17:03:48 --> Helper loaded: email_helper
INFO - 2020-04-07 17:03:48 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:03:48 --> Database Driver Class Initialized
INFO - 2020-04-07 17:03:48 --> Parser Class Initialized
INFO - 2020-04-07 17:03:48 --> User Agent Class Initialized
INFO - 2020-04-07 17:03:48 --> Model Class Initialized
INFO - 2020-04-07 17:03:48 --> Model Class Initialized
DEBUG - 2020-04-07 17:03:48 --> Template Class Initialized
INFO - 2020-04-07 17:03:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:03:48 --> Email Class Initialized
INFO - 2020-04-07 17:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:03:48 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:03:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:03:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:03:48 --> Encryption Class Initialized
INFO - 2020-04-07 17:03:48 --> Controller Class Initialized
DEBUG - 2020-04-07 17:03:48 --> home MX_Controller Initialized
INFO - 2020-04-07 17:03:48 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:03:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 17:03:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 17:03:48 --> Final output sent to browser
DEBUG - 2020-04-07 17:03:48 --> Total execution time: 0.6093
INFO - 2020-04-07 17:03:50 --> Config Class Initialized
INFO - 2020-04-07 17:03:50 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:03:50 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:03:50 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:50 --> URI Class Initialized
INFO - 2020-04-07 17:03:50 --> Router Class Initialized
INFO - 2020-04-07 17:03:51 --> Output Class Initialized
INFO - 2020-04-07 17:03:51 --> Security Class Initialized
DEBUG - 2020-04-07 17:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:03:51 --> CSRF cookie sent
INFO - 2020-04-07 17:03:51 --> Input Class Initialized
INFO - 2020-04-07 17:03:51 --> Language Class Initialized
INFO - 2020-04-07 17:03:51 --> Language Class Initialized
INFO - 2020-04-07 17:03:51 --> Config Class Initialized
INFO - 2020-04-07 17:03:51 --> Loader Class Initialized
INFO - 2020-04-07 17:03:51 --> Helper loaded: url_helper
INFO - 2020-04-07 17:03:51 --> Helper loaded: file_helper
INFO - 2020-04-07 17:03:51 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:03:51 --> Helper loaded: common_helper
INFO - 2020-04-07 17:03:51 --> Helper loaded: language_helper
INFO - 2020-04-07 17:03:51 --> Helper loaded: email_helper
INFO - 2020-04-07 17:03:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:03:51 --> Database Driver Class Initialized
INFO - 2020-04-07 17:03:51 --> Parser Class Initialized
INFO - 2020-04-07 17:03:51 --> User Agent Class Initialized
INFO - 2020-04-07 17:03:51 --> Model Class Initialized
INFO - 2020-04-07 17:03:51 --> Model Class Initialized
DEBUG - 2020-04-07 17:03:51 --> Template Class Initialized
INFO - 2020-04-07 17:03:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:03:51 --> Email Class Initialized
INFO - 2020-04-07 17:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:03:51 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:03:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:03:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:03:51 --> Encryption Class Initialized
INFO - 2020-04-07 17:03:51 --> Controller Class Initialized
ERROR - 2020-04-07 17:03:51 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:03:51 --> Config Class Initialized
INFO - 2020-04-07 17:03:51 --> Config Class Initialized
INFO - 2020-04-07 17:03:51 --> Config Class Initialized
INFO - 2020-04-07 17:03:51 --> Hooks Class Initialized
INFO - 2020-04-07 17:03:51 --> Hooks Class Initialized
INFO - 2020-04-07 17:03:51 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:03:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 17:03:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 17:03:51 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:03:51 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:51 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:51 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:51 --> URI Class Initialized
INFO - 2020-04-07 17:03:51 --> URI Class Initialized
INFO - 2020-04-07 17:03:51 --> URI Class Initialized
INFO - 2020-04-07 17:03:52 --> Router Class Initialized
INFO - 2020-04-07 17:03:52 --> Router Class Initialized
INFO - 2020-04-07 17:03:52 --> Router Class Initialized
INFO - 2020-04-07 17:03:52 --> Output Class Initialized
INFO - 2020-04-07 17:03:52 --> Output Class Initialized
INFO - 2020-04-07 17:03:52 --> Output Class Initialized
INFO - 2020-04-07 17:03:52 --> Security Class Initialized
INFO - 2020-04-07 17:03:52 --> Security Class Initialized
INFO - 2020-04-07 17:03:52 --> Security Class Initialized
DEBUG - 2020-04-07 17:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 17:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 17:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:03:52 --> CSRF cookie sent
INFO - 2020-04-07 17:03:52 --> CSRF cookie sent
INFO - 2020-04-07 17:03:52 --> CSRF cookie sent
INFO - 2020-04-07 17:03:52 --> Input Class Initialized
INFO - 2020-04-07 17:03:52 --> Input Class Initialized
INFO - 2020-04-07 17:03:52 --> Input Class Initialized
INFO - 2020-04-07 17:03:52 --> Language Class Initialized
INFO - 2020-04-07 17:03:52 --> Language Class Initialized
INFO - 2020-04-07 17:03:52 --> Language Class Initialized
ERROR - 2020-04-07 17:03:52 --> 404 Page Not Found: /index
ERROR - 2020-04-07 17:03:52 --> 404 Page Not Found: /index
ERROR - 2020-04-07 17:03:52 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:03:53 --> Config Class Initialized
INFO - 2020-04-07 17:03:53 --> Config Class Initialized
INFO - 2020-04-07 17:03:53 --> Hooks Class Initialized
INFO - 2020-04-07 17:03:53 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:03:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 17:03:53 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:03:53 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:53 --> Utf8 Class Initialized
INFO - 2020-04-07 17:03:53 --> URI Class Initialized
INFO - 2020-04-07 17:03:53 --> URI Class Initialized
INFO - 2020-04-07 17:03:53 --> Router Class Initialized
INFO - 2020-04-07 17:03:53 --> Router Class Initialized
INFO - 2020-04-07 17:03:53 --> Output Class Initialized
INFO - 2020-04-07 17:03:53 --> Output Class Initialized
INFO - 2020-04-07 17:03:53 --> Security Class Initialized
INFO - 2020-04-07 17:03:53 --> Security Class Initialized
DEBUG - 2020-04-07 17:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 17:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:03:53 --> CSRF cookie sent
INFO - 2020-04-07 17:03:53 --> CSRF cookie sent
INFO - 2020-04-07 17:03:53 --> Input Class Initialized
INFO - 2020-04-07 17:03:53 --> Input Class Initialized
INFO - 2020-04-07 17:03:53 --> Language Class Initialized
INFO - 2020-04-07 17:03:53 --> Language Class Initialized
ERROR - 2020-04-07 17:03:53 --> 404 Page Not Found: /index
ERROR - 2020-04-07 17:03:53 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:04:01 --> Config Class Initialized
INFO - 2020-04-07 17:04:01 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:04:01 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:04:01 --> Utf8 Class Initialized
INFO - 2020-04-07 17:04:01 --> URI Class Initialized
INFO - 2020-04-07 17:04:01 --> Router Class Initialized
INFO - 2020-04-07 17:04:01 --> Output Class Initialized
INFO - 2020-04-07 17:04:01 --> Security Class Initialized
DEBUG - 2020-04-07 17:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:04:01 --> CSRF cookie sent
INFO - 2020-04-07 17:04:01 --> Input Class Initialized
INFO - 2020-04-07 17:04:01 --> Language Class Initialized
INFO - 2020-04-07 17:04:01 --> Language Class Initialized
INFO - 2020-04-07 17:04:01 --> Config Class Initialized
INFO - 2020-04-07 17:04:01 --> Loader Class Initialized
INFO - 2020-04-07 17:04:01 --> Helper loaded: url_helper
INFO - 2020-04-07 17:04:01 --> Helper loaded: file_helper
INFO - 2020-04-07 17:04:01 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:04:01 --> Helper loaded: common_helper
INFO - 2020-04-07 17:04:01 --> Helper loaded: language_helper
INFO - 2020-04-07 17:04:01 --> Helper loaded: email_helper
INFO - 2020-04-07 17:04:01 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:04:01 --> Database Driver Class Initialized
INFO - 2020-04-07 17:04:01 --> Parser Class Initialized
INFO - 2020-04-07 17:04:01 --> User Agent Class Initialized
INFO - 2020-04-07 17:04:01 --> Model Class Initialized
INFO - 2020-04-07 17:04:01 --> Model Class Initialized
DEBUG - 2020-04-07 17:04:01 --> Template Class Initialized
INFO - 2020-04-07 17:04:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:04:01 --> Email Class Initialized
INFO - 2020-04-07 17:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:04:01 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:04:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:04:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:04:01 --> Encryption Class Initialized
INFO - 2020-04-07 17:04:01 --> Controller Class Initialized
ERROR - 2020-04-07 17:04:01 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:04:01 --> Config Class Initialized
INFO - 2020-04-07 17:04:01 --> Config Class Initialized
INFO - 2020-04-07 17:04:01 --> Config Class Initialized
INFO - 2020-04-07 17:04:01 --> Hooks Class Initialized
INFO - 2020-04-07 17:04:01 --> Hooks Class Initialized
INFO - 2020-04-07 17:04:01 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:04:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 17:04:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-07 17:04:01 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:04:01 --> Utf8 Class Initialized
INFO - 2020-04-07 17:04:01 --> Utf8 Class Initialized
INFO - 2020-04-07 17:04:01 --> Utf8 Class Initialized
INFO - 2020-04-07 17:04:02 --> URI Class Initialized
INFO - 2020-04-07 17:04:02 --> URI Class Initialized
INFO - 2020-04-07 17:04:02 --> URI Class Initialized
INFO - 2020-04-07 17:04:02 --> Router Class Initialized
INFO - 2020-04-07 17:04:02 --> Router Class Initialized
INFO - 2020-04-07 17:04:02 --> Router Class Initialized
INFO - 2020-04-07 17:04:02 --> Output Class Initialized
INFO - 2020-04-07 17:04:02 --> Output Class Initialized
INFO - 2020-04-07 17:04:02 --> Output Class Initialized
INFO - 2020-04-07 17:04:02 --> Security Class Initialized
INFO - 2020-04-07 17:04:02 --> Security Class Initialized
INFO - 2020-04-07 17:04:02 --> Security Class Initialized
DEBUG - 2020-04-07 17:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 17:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-07 17:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:04:02 --> CSRF cookie sent
INFO - 2020-04-07 17:04:02 --> CSRF cookie sent
INFO - 2020-04-07 17:04:02 --> CSRF cookie sent
INFO - 2020-04-07 17:04:02 --> Input Class Initialized
INFO - 2020-04-07 17:04:02 --> Input Class Initialized
INFO - 2020-04-07 17:04:02 --> Input Class Initialized
INFO - 2020-04-07 17:04:02 --> Language Class Initialized
INFO - 2020-04-07 17:04:02 --> Language Class Initialized
INFO - 2020-04-07 17:04:02 --> Language Class Initialized
ERROR - 2020-04-07 17:04:02 --> 404 Page Not Found: /index
ERROR - 2020-04-07 17:04:02 --> 404 Page Not Found: /index
ERROR - 2020-04-07 17:04:02 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:04:37 --> Config Class Initialized
INFO - 2020-04-07 17:04:37 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:04:37 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:04:37 --> Utf8 Class Initialized
INFO - 2020-04-07 17:04:37 --> URI Class Initialized
INFO - 2020-04-07 17:04:37 --> Router Class Initialized
INFO - 2020-04-07 17:04:37 --> Output Class Initialized
INFO - 2020-04-07 17:04:38 --> Security Class Initialized
DEBUG - 2020-04-07 17:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:04:38 --> CSRF cookie sent
INFO - 2020-04-07 17:04:38 --> Input Class Initialized
INFO - 2020-04-07 17:04:38 --> Language Class Initialized
INFO - 2020-04-07 17:04:38 --> Language Class Initialized
INFO - 2020-04-07 17:04:38 --> Config Class Initialized
INFO - 2020-04-07 17:04:38 --> Loader Class Initialized
INFO - 2020-04-07 17:04:38 --> Helper loaded: url_helper
INFO - 2020-04-07 17:04:38 --> Helper loaded: file_helper
INFO - 2020-04-07 17:04:38 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:04:38 --> Helper loaded: common_helper
INFO - 2020-04-07 17:04:38 --> Helper loaded: language_helper
INFO - 2020-04-07 17:04:38 --> Helper loaded: email_helper
INFO - 2020-04-07 17:04:38 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:04:38 --> Database Driver Class Initialized
INFO - 2020-04-07 17:04:38 --> Parser Class Initialized
INFO - 2020-04-07 17:04:38 --> User Agent Class Initialized
INFO - 2020-04-07 17:04:38 --> Model Class Initialized
INFO - 2020-04-07 17:04:38 --> Model Class Initialized
DEBUG - 2020-04-07 17:04:38 --> Template Class Initialized
INFO - 2020-04-07 17:04:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:04:38 --> Email Class Initialized
INFO - 2020-04-07 17:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:04:38 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:04:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:04:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:04:38 --> Encryption Class Initialized
INFO - 2020-04-07 17:04:38 --> Controller Class Initialized
ERROR - 2020-04-07 17:04:38 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:04:38 --> Config Class Initialized
INFO - 2020-04-07 17:04:38 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:04:38 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:04:38 --> Utf8 Class Initialized
INFO - 2020-04-07 17:04:38 --> URI Class Initialized
INFO - 2020-04-07 17:04:38 --> Router Class Initialized
INFO - 2020-04-07 17:04:38 --> Output Class Initialized
INFO - 2020-04-07 17:04:38 --> Security Class Initialized
DEBUG - 2020-04-07 17:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:04:38 --> CSRF cookie sent
INFO - 2020-04-07 17:04:38 --> Input Class Initialized
INFO - 2020-04-07 17:04:38 --> Language Class Initialized
ERROR - 2020-04-07 17:04:38 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:04:38 --> Config Class Initialized
INFO - 2020-04-07 17:04:38 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:04:38 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:04:38 --> Utf8 Class Initialized
INFO - 2020-04-07 17:04:38 --> URI Class Initialized
INFO - 2020-04-07 17:04:38 --> Router Class Initialized
INFO - 2020-04-07 17:04:38 --> Output Class Initialized
INFO - 2020-04-07 17:04:38 --> Security Class Initialized
DEBUG - 2020-04-07 17:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:04:39 --> CSRF cookie sent
INFO - 2020-04-07 17:04:39 --> Input Class Initialized
INFO - 2020-04-07 17:04:39 --> Language Class Initialized
ERROR - 2020-04-07 17:04:39 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:05:21 --> Config Class Initialized
INFO - 2020-04-07 17:05:21 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:05:21 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:05:21 --> Utf8 Class Initialized
INFO - 2020-04-07 17:05:21 --> URI Class Initialized
INFO - 2020-04-07 17:05:21 --> Router Class Initialized
INFO - 2020-04-07 17:05:21 --> Output Class Initialized
INFO - 2020-04-07 17:05:21 --> Security Class Initialized
DEBUG - 2020-04-07 17:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:05:21 --> CSRF cookie sent
INFO - 2020-04-07 17:05:21 --> Input Class Initialized
INFO - 2020-04-07 17:05:21 --> Language Class Initialized
INFO - 2020-04-07 17:05:21 --> Language Class Initialized
INFO - 2020-04-07 17:05:21 --> Config Class Initialized
INFO - 2020-04-07 17:05:21 --> Loader Class Initialized
INFO - 2020-04-07 17:05:21 --> Helper loaded: url_helper
INFO - 2020-04-07 17:05:21 --> Helper loaded: file_helper
INFO - 2020-04-07 17:05:21 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:05:21 --> Helper loaded: common_helper
INFO - 2020-04-07 17:05:21 --> Helper loaded: language_helper
INFO - 2020-04-07 17:05:21 --> Helper loaded: email_helper
INFO - 2020-04-07 17:05:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:05:21 --> Database Driver Class Initialized
INFO - 2020-04-07 17:05:21 --> Parser Class Initialized
INFO - 2020-04-07 17:05:21 --> User Agent Class Initialized
INFO - 2020-04-07 17:05:21 --> Model Class Initialized
INFO - 2020-04-07 17:05:21 --> Model Class Initialized
DEBUG - 2020-04-07 17:05:21 --> Template Class Initialized
INFO - 2020-04-07 17:05:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:05:21 --> Email Class Initialized
INFO - 2020-04-07 17:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:05:21 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:05:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:05:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:05:21 --> Encryption Class Initialized
INFO - 2020-04-07 17:05:21 --> Controller Class Initialized
ERROR - 2020-04-07 17:05:22 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:05:22 --> Config Class Initialized
INFO - 2020-04-07 17:05:22 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:05:22 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:05:22 --> Utf8 Class Initialized
INFO - 2020-04-07 17:05:22 --> URI Class Initialized
INFO - 2020-04-07 17:05:22 --> Router Class Initialized
INFO - 2020-04-07 17:05:22 --> Output Class Initialized
INFO - 2020-04-07 17:05:22 --> Security Class Initialized
DEBUG - 2020-04-07 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:05:22 --> CSRF cookie sent
INFO - 2020-04-07 17:05:22 --> Input Class Initialized
INFO - 2020-04-07 17:05:22 --> Language Class Initialized
ERROR - 2020-04-07 17:05:22 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:05:22 --> Config Class Initialized
INFO - 2020-04-07 17:05:22 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:05:22 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:05:22 --> Utf8 Class Initialized
INFO - 2020-04-07 17:05:22 --> URI Class Initialized
INFO - 2020-04-07 17:05:22 --> Router Class Initialized
INFO - 2020-04-07 17:05:22 --> Output Class Initialized
INFO - 2020-04-07 17:05:22 --> Security Class Initialized
DEBUG - 2020-04-07 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:05:22 --> CSRF cookie sent
INFO - 2020-04-07 17:05:22 --> Input Class Initialized
INFO - 2020-04-07 17:05:22 --> Language Class Initialized
ERROR - 2020-04-07 17:05:22 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:05:33 --> Config Class Initialized
INFO - 2020-04-07 17:05:33 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:05:33 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:05:33 --> Utf8 Class Initialized
INFO - 2020-04-07 17:05:33 --> URI Class Initialized
INFO - 2020-04-07 17:05:33 --> Router Class Initialized
INFO - 2020-04-07 17:05:33 --> Output Class Initialized
INFO - 2020-04-07 17:05:33 --> Security Class Initialized
DEBUG - 2020-04-07 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:05:33 --> CSRF cookie sent
INFO - 2020-04-07 17:05:33 --> Input Class Initialized
INFO - 2020-04-07 17:05:33 --> Language Class Initialized
INFO - 2020-04-07 17:05:33 --> Language Class Initialized
INFO - 2020-04-07 17:05:33 --> Config Class Initialized
INFO - 2020-04-07 17:05:34 --> Loader Class Initialized
INFO - 2020-04-07 17:05:34 --> Helper loaded: url_helper
INFO - 2020-04-07 17:05:34 --> Helper loaded: file_helper
INFO - 2020-04-07 17:05:34 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:05:34 --> Helper loaded: common_helper
INFO - 2020-04-07 17:05:34 --> Helper loaded: language_helper
INFO - 2020-04-07 17:05:34 --> Helper loaded: email_helper
INFO - 2020-04-07 17:05:34 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:05:34 --> Database Driver Class Initialized
INFO - 2020-04-07 17:05:34 --> Parser Class Initialized
INFO - 2020-04-07 17:05:34 --> User Agent Class Initialized
INFO - 2020-04-07 17:05:34 --> Model Class Initialized
INFO - 2020-04-07 17:05:34 --> Model Class Initialized
DEBUG - 2020-04-07 17:05:34 --> Template Class Initialized
INFO - 2020-04-07 17:05:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:05:34 --> Email Class Initialized
INFO - 2020-04-07 17:05:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:05:34 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:05:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:05:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:05:34 --> Encryption Class Initialized
INFO - 2020-04-07 17:05:34 --> Controller Class Initialized
ERROR - 2020-04-07 17:05:34 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:05:34 --> Config Class Initialized
INFO - 2020-04-07 17:05:34 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:05:34 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:05:34 --> Utf8 Class Initialized
INFO - 2020-04-07 17:05:34 --> URI Class Initialized
INFO - 2020-04-07 17:05:34 --> Router Class Initialized
INFO - 2020-04-07 17:05:34 --> Output Class Initialized
INFO - 2020-04-07 17:05:34 --> Security Class Initialized
DEBUG - 2020-04-07 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:05:34 --> CSRF cookie sent
INFO - 2020-04-07 17:05:34 --> Input Class Initialized
INFO - 2020-04-07 17:05:34 --> Language Class Initialized
ERROR - 2020-04-07 17:05:34 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:05:34 --> Config Class Initialized
INFO - 2020-04-07 17:05:34 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:05:34 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:05:34 --> Utf8 Class Initialized
INFO - 2020-04-07 17:05:34 --> URI Class Initialized
INFO - 2020-04-07 17:05:34 --> Router Class Initialized
INFO - 2020-04-07 17:05:34 --> Output Class Initialized
INFO - 2020-04-07 17:05:34 --> Security Class Initialized
DEBUG - 2020-04-07 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:05:35 --> CSRF cookie sent
INFO - 2020-04-07 17:05:35 --> Input Class Initialized
INFO - 2020-04-07 17:05:35 --> Language Class Initialized
ERROR - 2020-04-07 17:05:35 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:06:52 --> Config Class Initialized
INFO - 2020-04-07 17:06:52 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:06:52 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:06:52 --> Utf8 Class Initialized
INFO - 2020-04-07 17:06:52 --> URI Class Initialized
INFO - 2020-04-07 17:06:52 --> Router Class Initialized
INFO - 2020-04-07 17:06:52 --> Output Class Initialized
INFO - 2020-04-07 17:06:52 --> Security Class Initialized
DEBUG - 2020-04-07 17:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:06:52 --> CSRF cookie sent
INFO - 2020-04-07 17:06:52 --> Input Class Initialized
INFO - 2020-04-07 17:06:52 --> Language Class Initialized
INFO - 2020-04-07 17:06:52 --> Language Class Initialized
INFO - 2020-04-07 17:06:52 --> Config Class Initialized
INFO - 2020-04-07 17:06:52 --> Loader Class Initialized
INFO - 2020-04-07 17:06:52 --> Helper loaded: url_helper
INFO - 2020-04-07 17:06:52 --> Helper loaded: file_helper
INFO - 2020-04-07 17:06:52 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:06:52 --> Helper loaded: common_helper
INFO - 2020-04-07 17:06:53 --> Helper loaded: language_helper
INFO - 2020-04-07 17:06:53 --> Helper loaded: email_helper
INFO - 2020-04-07 17:06:53 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:06:53 --> Database Driver Class Initialized
INFO - 2020-04-07 17:06:53 --> Parser Class Initialized
INFO - 2020-04-07 17:06:53 --> User Agent Class Initialized
INFO - 2020-04-07 17:06:53 --> Model Class Initialized
INFO - 2020-04-07 17:06:53 --> Model Class Initialized
DEBUG - 2020-04-07 17:06:53 --> Template Class Initialized
INFO - 2020-04-07 17:06:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:06:53 --> Email Class Initialized
INFO - 2020-04-07 17:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:06:53 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:06:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:06:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:06:53 --> Encryption Class Initialized
INFO - 2020-04-07 17:06:53 --> Controller Class Initialized
ERROR - 2020-04-07 17:06:53 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:06:53 --> Config Class Initialized
INFO - 2020-04-07 17:06:53 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:06:53 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:06:53 --> Utf8 Class Initialized
INFO - 2020-04-07 17:06:53 --> URI Class Initialized
INFO - 2020-04-07 17:06:53 --> Router Class Initialized
INFO - 2020-04-07 17:06:53 --> Output Class Initialized
INFO - 2020-04-07 17:06:53 --> Security Class Initialized
DEBUG - 2020-04-07 17:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:06:53 --> CSRF cookie sent
INFO - 2020-04-07 17:06:53 --> Input Class Initialized
INFO - 2020-04-07 17:06:53 --> Language Class Initialized
ERROR - 2020-04-07 17:06:53 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:06:59 --> Config Class Initialized
INFO - 2020-04-07 17:06:59 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:06:59 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:06:59 --> Utf8 Class Initialized
INFO - 2020-04-07 17:06:59 --> URI Class Initialized
INFO - 2020-04-07 17:06:59 --> Router Class Initialized
INFO - 2020-04-07 17:06:59 --> Output Class Initialized
INFO - 2020-04-07 17:06:59 --> Security Class Initialized
DEBUG - 2020-04-07 17:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:06:59 --> CSRF cookie sent
INFO - 2020-04-07 17:06:59 --> Input Class Initialized
INFO - 2020-04-07 17:06:59 --> Language Class Initialized
ERROR - 2020-04-07 17:06:59 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:08:50 --> Config Class Initialized
INFO - 2020-04-07 17:08:50 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:08:50 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:08:50 --> Utf8 Class Initialized
INFO - 2020-04-07 17:08:50 --> URI Class Initialized
INFO - 2020-04-07 17:08:50 --> Router Class Initialized
INFO - 2020-04-07 17:08:51 --> Output Class Initialized
INFO - 2020-04-07 17:08:51 --> Security Class Initialized
DEBUG - 2020-04-07 17:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:08:51 --> CSRF cookie sent
INFO - 2020-04-07 17:08:51 --> Input Class Initialized
INFO - 2020-04-07 17:08:51 --> Language Class Initialized
INFO - 2020-04-07 17:08:51 --> Language Class Initialized
INFO - 2020-04-07 17:08:51 --> Config Class Initialized
INFO - 2020-04-07 17:08:51 --> Loader Class Initialized
INFO - 2020-04-07 17:08:51 --> Helper loaded: url_helper
INFO - 2020-04-07 17:08:51 --> Helper loaded: file_helper
INFO - 2020-04-07 17:08:51 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:08:51 --> Helper loaded: common_helper
INFO - 2020-04-07 17:08:51 --> Helper loaded: language_helper
INFO - 2020-04-07 17:08:51 --> Helper loaded: email_helper
INFO - 2020-04-07 17:08:51 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:08:51 --> Database Driver Class Initialized
INFO - 2020-04-07 17:08:51 --> Parser Class Initialized
INFO - 2020-04-07 17:08:51 --> User Agent Class Initialized
INFO - 2020-04-07 17:08:51 --> Model Class Initialized
INFO - 2020-04-07 17:08:51 --> Model Class Initialized
DEBUG - 2020-04-07 17:08:51 --> Template Class Initialized
INFO - 2020-04-07 17:08:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:08:51 --> Email Class Initialized
INFO - 2020-04-07 17:08:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:08:51 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:08:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:08:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:08:51 --> Encryption Class Initialized
INFO - 2020-04-07 17:08:51 --> Controller Class Initialized
ERROR - 2020-04-07 17:08:51 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:08:51 --> Config Class Initialized
INFO - 2020-04-07 17:08:51 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:08:51 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:08:51 --> Utf8 Class Initialized
INFO - 2020-04-07 17:08:51 --> URI Class Initialized
INFO - 2020-04-07 17:08:51 --> Router Class Initialized
INFO - 2020-04-07 17:08:51 --> Output Class Initialized
INFO - 2020-04-07 17:08:51 --> Security Class Initialized
DEBUG - 2020-04-07 17:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:08:51 --> CSRF cookie sent
INFO - 2020-04-07 17:08:51 --> Input Class Initialized
INFO - 2020-04-07 17:08:51 --> Language Class Initialized
ERROR - 2020-04-07 17:08:51 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:09:26 --> Config Class Initialized
INFO - 2020-04-07 17:09:26 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:09:26 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:09:26 --> Utf8 Class Initialized
INFO - 2020-04-07 17:09:26 --> URI Class Initialized
INFO - 2020-04-07 17:09:26 --> Router Class Initialized
INFO - 2020-04-07 17:09:26 --> Output Class Initialized
INFO - 2020-04-07 17:09:26 --> Security Class Initialized
DEBUG - 2020-04-07 17:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:09:27 --> CSRF cookie sent
INFO - 2020-04-07 17:09:27 --> Input Class Initialized
INFO - 2020-04-07 17:09:27 --> Language Class Initialized
INFO - 2020-04-07 17:09:27 --> Language Class Initialized
INFO - 2020-04-07 17:09:27 --> Config Class Initialized
INFO - 2020-04-07 17:09:27 --> Loader Class Initialized
INFO - 2020-04-07 17:09:27 --> Helper loaded: url_helper
INFO - 2020-04-07 17:09:27 --> Helper loaded: file_helper
INFO - 2020-04-07 17:09:27 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:09:27 --> Helper loaded: common_helper
INFO - 2020-04-07 17:09:27 --> Helper loaded: language_helper
INFO - 2020-04-07 17:09:27 --> Helper loaded: email_helper
INFO - 2020-04-07 17:09:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:09:27 --> Database Driver Class Initialized
INFO - 2020-04-07 17:09:27 --> Parser Class Initialized
INFO - 2020-04-07 17:09:27 --> User Agent Class Initialized
INFO - 2020-04-07 17:09:27 --> Model Class Initialized
INFO - 2020-04-07 17:09:27 --> Model Class Initialized
DEBUG - 2020-04-07 17:09:27 --> Template Class Initialized
INFO - 2020-04-07 17:09:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:09:27 --> Email Class Initialized
INFO - 2020-04-07 17:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:09:27 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:09:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:09:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:09:27 --> Encryption Class Initialized
INFO - 2020-04-07 17:09:27 --> Controller Class Initialized
ERROR - 2020-04-07 17:09:27 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:09:27 --> Config Class Initialized
INFO - 2020-04-07 17:09:27 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:09:27 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:09:27 --> Utf8 Class Initialized
INFO - 2020-04-07 17:09:27 --> URI Class Initialized
INFO - 2020-04-07 17:09:27 --> Router Class Initialized
INFO - 2020-04-07 17:09:27 --> Output Class Initialized
INFO - 2020-04-07 17:09:27 --> Security Class Initialized
DEBUG - 2020-04-07 17:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:09:27 --> CSRF cookie sent
INFO - 2020-04-07 17:09:27 --> Input Class Initialized
INFO - 2020-04-07 17:09:27 --> Language Class Initialized
ERROR - 2020-04-07 17:09:27 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:09:54 --> Config Class Initialized
INFO - 2020-04-07 17:09:54 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:09:54 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:09:54 --> Utf8 Class Initialized
INFO - 2020-04-07 17:09:54 --> URI Class Initialized
INFO - 2020-04-07 17:09:54 --> Router Class Initialized
INFO - 2020-04-07 17:09:54 --> Output Class Initialized
INFO - 2020-04-07 17:09:54 --> Security Class Initialized
DEBUG - 2020-04-07 17:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:09:54 --> CSRF cookie sent
INFO - 2020-04-07 17:09:54 --> Input Class Initialized
INFO - 2020-04-07 17:09:54 --> Language Class Initialized
INFO - 2020-04-07 17:09:54 --> Language Class Initialized
INFO - 2020-04-07 17:09:54 --> Config Class Initialized
INFO - 2020-04-07 17:09:54 --> Loader Class Initialized
INFO - 2020-04-07 17:09:54 --> Helper loaded: url_helper
INFO - 2020-04-07 17:09:54 --> Helper loaded: file_helper
INFO - 2020-04-07 17:09:54 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:09:54 --> Helper loaded: common_helper
INFO - 2020-04-07 17:09:54 --> Helper loaded: language_helper
INFO - 2020-04-07 17:09:54 --> Helper loaded: email_helper
INFO - 2020-04-07 17:09:54 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:09:54 --> Database Driver Class Initialized
INFO - 2020-04-07 17:09:54 --> Parser Class Initialized
INFO - 2020-04-07 17:09:54 --> User Agent Class Initialized
INFO - 2020-04-07 17:09:54 --> Model Class Initialized
INFO - 2020-04-07 17:09:54 --> Model Class Initialized
DEBUG - 2020-04-07 17:09:54 --> Template Class Initialized
INFO - 2020-04-07 17:09:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:09:54 --> Email Class Initialized
INFO - 2020-04-07 17:09:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:09:54 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:09:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:09:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:09:54 --> Encryption Class Initialized
INFO - 2020-04-07 17:09:54 --> Controller Class Initialized
ERROR - 2020-04-07 17:09:54 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:09:55 --> Config Class Initialized
INFO - 2020-04-07 17:09:55 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:09:55 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:09:55 --> Utf8 Class Initialized
INFO - 2020-04-07 17:09:55 --> URI Class Initialized
INFO - 2020-04-07 17:09:55 --> Router Class Initialized
INFO - 2020-04-07 17:09:55 --> Output Class Initialized
INFO - 2020-04-07 17:09:55 --> Security Class Initialized
DEBUG - 2020-04-07 17:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:09:55 --> CSRF cookie sent
INFO - 2020-04-07 17:09:55 --> Input Class Initialized
INFO - 2020-04-07 17:09:55 --> Language Class Initialized
ERROR - 2020-04-07 17:09:55 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:10:20 --> Config Class Initialized
INFO - 2020-04-07 17:10:21 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:10:21 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:10:21 --> Utf8 Class Initialized
INFO - 2020-04-07 17:10:21 --> URI Class Initialized
INFO - 2020-04-07 17:10:21 --> Router Class Initialized
INFO - 2020-04-07 17:10:21 --> Output Class Initialized
INFO - 2020-04-07 17:10:21 --> Security Class Initialized
DEBUG - 2020-04-07 17:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:10:21 --> CSRF cookie sent
INFO - 2020-04-07 17:10:21 --> Input Class Initialized
INFO - 2020-04-07 17:10:21 --> Language Class Initialized
INFO - 2020-04-07 17:10:21 --> Language Class Initialized
INFO - 2020-04-07 17:10:21 --> Config Class Initialized
INFO - 2020-04-07 17:10:21 --> Loader Class Initialized
INFO - 2020-04-07 17:10:21 --> Helper loaded: url_helper
INFO - 2020-04-07 17:10:21 --> Helper loaded: file_helper
INFO - 2020-04-07 17:10:21 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:10:21 --> Helper loaded: common_helper
INFO - 2020-04-07 17:10:21 --> Helper loaded: language_helper
INFO - 2020-04-07 17:10:21 --> Helper loaded: email_helper
INFO - 2020-04-07 17:10:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:10:21 --> Database Driver Class Initialized
INFO - 2020-04-07 17:10:21 --> Parser Class Initialized
INFO - 2020-04-07 17:10:21 --> User Agent Class Initialized
INFO - 2020-04-07 17:10:21 --> Model Class Initialized
INFO - 2020-04-07 17:10:21 --> Model Class Initialized
DEBUG - 2020-04-07 17:10:21 --> Template Class Initialized
INFO - 2020-04-07 17:10:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:10:21 --> Email Class Initialized
INFO - 2020-04-07 17:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:10:21 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:10:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:10:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:10:21 --> Encryption Class Initialized
INFO - 2020-04-07 17:10:21 --> Controller Class Initialized
ERROR - 2020-04-07 17:10:21 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:10:21 --> Config Class Initialized
INFO - 2020-04-07 17:10:21 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:10:21 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:10:21 --> Utf8 Class Initialized
INFO - 2020-04-07 17:10:21 --> URI Class Initialized
INFO - 2020-04-07 17:10:21 --> Router Class Initialized
INFO - 2020-04-07 17:10:21 --> Output Class Initialized
INFO - 2020-04-07 17:10:21 --> Security Class Initialized
DEBUG - 2020-04-07 17:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:10:21 --> CSRF cookie sent
INFO - 2020-04-07 17:10:21 --> Input Class Initialized
INFO - 2020-04-07 17:10:21 --> Language Class Initialized
ERROR - 2020-04-07 17:10:22 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:11:02 --> Config Class Initialized
INFO - 2020-04-07 17:11:02 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:11:02 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:11:02 --> Utf8 Class Initialized
INFO - 2020-04-07 17:11:02 --> URI Class Initialized
INFO - 2020-04-07 17:11:02 --> Router Class Initialized
INFO - 2020-04-07 17:11:02 --> Output Class Initialized
INFO - 2020-04-07 17:11:02 --> Security Class Initialized
DEBUG - 2020-04-07 17:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:11:02 --> CSRF cookie sent
INFO - 2020-04-07 17:11:02 --> Input Class Initialized
INFO - 2020-04-07 17:11:02 --> Language Class Initialized
INFO - 2020-04-07 17:11:02 --> Language Class Initialized
INFO - 2020-04-07 17:11:02 --> Config Class Initialized
INFO - 2020-04-07 17:11:02 --> Loader Class Initialized
INFO - 2020-04-07 17:11:02 --> Helper loaded: url_helper
INFO - 2020-04-07 17:11:02 --> Helper loaded: file_helper
INFO - 2020-04-07 17:11:02 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:11:02 --> Helper loaded: common_helper
INFO - 2020-04-07 17:11:02 --> Helper loaded: language_helper
INFO - 2020-04-07 17:11:02 --> Helper loaded: email_helper
INFO - 2020-04-07 17:11:02 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:11:02 --> Database Driver Class Initialized
INFO - 2020-04-07 17:11:02 --> Parser Class Initialized
INFO - 2020-04-07 17:11:02 --> User Agent Class Initialized
INFO - 2020-04-07 17:11:02 --> Model Class Initialized
INFO - 2020-04-07 17:11:02 --> Model Class Initialized
DEBUG - 2020-04-07 17:11:02 --> Template Class Initialized
INFO - 2020-04-07 17:11:02 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:11:02 --> Email Class Initialized
INFO - 2020-04-07 17:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:11:02 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:11:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:11:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:11:02 --> Encryption Class Initialized
INFO - 2020-04-07 17:11:02 --> Controller Class Initialized
ERROR - 2020-04-07 17:11:02 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:11:03 --> Config Class Initialized
INFO - 2020-04-07 17:11:03 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:11:03 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:11:03 --> Utf8 Class Initialized
INFO - 2020-04-07 17:11:03 --> URI Class Initialized
INFO - 2020-04-07 17:11:03 --> Router Class Initialized
INFO - 2020-04-07 17:11:03 --> Output Class Initialized
INFO - 2020-04-07 17:11:03 --> Security Class Initialized
DEBUG - 2020-04-07 17:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:11:03 --> CSRF cookie sent
INFO - 2020-04-07 17:11:03 --> Input Class Initialized
INFO - 2020-04-07 17:11:03 --> Language Class Initialized
ERROR - 2020-04-07 17:11:03 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:11:17 --> Config Class Initialized
INFO - 2020-04-07 17:11:17 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:11:17 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:11:17 --> Utf8 Class Initialized
INFO - 2020-04-07 17:11:17 --> URI Class Initialized
INFO - 2020-04-07 17:11:17 --> Router Class Initialized
INFO - 2020-04-07 17:11:17 --> Output Class Initialized
INFO - 2020-04-07 17:11:17 --> Security Class Initialized
DEBUG - 2020-04-07 17:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:11:17 --> CSRF cookie sent
INFO - 2020-04-07 17:11:17 --> Input Class Initialized
INFO - 2020-04-07 17:11:17 --> Language Class Initialized
INFO - 2020-04-07 17:11:17 --> Language Class Initialized
INFO - 2020-04-07 17:11:17 --> Config Class Initialized
INFO - 2020-04-07 17:11:17 --> Loader Class Initialized
INFO - 2020-04-07 17:11:17 --> Helper loaded: url_helper
INFO - 2020-04-07 17:11:17 --> Helper loaded: file_helper
INFO - 2020-04-07 17:11:17 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:11:17 --> Helper loaded: common_helper
INFO - 2020-04-07 17:11:17 --> Helper loaded: language_helper
INFO - 2020-04-07 17:11:17 --> Helper loaded: email_helper
INFO - 2020-04-07 17:11:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:11:17 --> Database Driver Class Initialized
INFO - 2020-04-07 17:11:17 --> Parser Class Initialized
INFO - 2020-04-07 17:11:17 --> User Agent Class Initialized
INFO - 2020-04-07 17:11:17 --> Model Class Initialized
INFO - 2020-04-07 17:11:17 --> Model Class Initialized
DEBUG - 2020-04-07 17:11:17 --> Template Class Initialized
INFO - 2020-04-07 17:11:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:11:17 --> Email Class Initialized
INFO - 2020-04-07 17:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:11:17 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:11:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:11:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:11:17 --> Encryption Class Initialized
INFO - 2020-04-07 17:11:17 --> Controller Class Initialized
ERROR - 2020-04-07 17:11:18 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:11:18 --> Config Class Initialized
INFO - 2020-04-07 17:11:18 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:11:18 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:11:18 --> Utf8 Class Initialized
INFO - 2020-04-07 17:11:18 --> URI Class Initialized
INFO - 2020-04-07 17:11:18 --> Router Class Initialized
INFO - 2020-04-07 17:11:18 --> Output Class Initialized
INFO - 2020-04-07 17:11:18 --> Security Class Initialized
DEBUG - 2020-04-07 17:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:11:18 --> CSRF cookie sent
INFO - 2020-04-07 17:11:18 --> Input Class Initialized
INFO - 2020-04-07 17:11:18 --> Language Class Initialized
ERROR - 2020-04-07 17:11:18 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:12:19 --> Config Class Initialized
INFO - 2020-04-07 17:12:19 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:12:19 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:12:20 --> Utf8 Class Initialized
INFO - 2020-04-07 17:12:20 --> URI Class Initialized
INFO - 2020-04-07 17:12:20 --> Router Class Initialized
INFO - 2020-04-07 17:12:20 --> Output Class Initialized
INFO - 2020-04-07 17:12:20 --> Security Class Initialized
DEBUG - 2020-04-07 17:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:12:20 --> CSRF cookie sent
INFO - 2020-04-07 17:12:20 --> Input Class Initialized
INFO - 2020-04-07 17:12:20 --> Language Class Initialized
INFO - 2020-04-07 17:12:20 --> Language Class Initialized
INFO - 2020-04-07 17:12:20 --> Config Class Initialized
INFO - 2020-04-07 17:12:20 --> Loader Class Initialized
INFO - 2020-04-07 17:12:20 --> Helper loaded: url_helper
INFO - 2020-04-07 17:12:20 --> Helper loaded: file_helper
INFO - 2020-04-07 17:12:20 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:12:20 --> Helper loaded: common_helper
INFO - 2020-04-07 17:12:20 --> Helper loaded: language_helper
INFO - 2020-04-07 17:12:20 --> Helper loaded: email_helper
INFO - 2020-04-07 17:12:20 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:12:20 --> Database Driver Class Initialized
INFO - 2020-04-07 17:12:20 --> Parser Class Initialized
INFO - 2020-04-07 17:12:20 --> User Agent Class Initialized
INFO - 2020-04-07 17:12:20 --> Model Class Initialized
INFO - 2020-04-07 17:12:20 --> Model Class Initialized
DEBUG - 2020-04-07 17:12:20 --> Template Class Initialized
INFO - 2020-04-07 17:12:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:12:20 --> Email Class Initialized
INFO - 2020-04-07 17:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:12:20 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:12:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:12:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:12:20 --> Encryption Class Initialized
INFO - 2020-04-07 17:12:20 --> Controller Class Initialized
ERROR - 2020-04-07 17:12:20 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:12:20 --> Config Class Initialized
INFO - 2020-04-07 17:12:20 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:12:20 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:12:20 --> Utf8 Class Initialized
INFO - 2020-04-07 17:12:20 --> URI Class Initialized
INFO - 2020-04-07 17:12:20 --> Router Class Initialized
INFO - 2020-04-07 17:12:20 --> Output Class Initialized
INFO - 2020-04-07 17:12:20 --> Security Class Initialized
DEBUG - 2020-04-07 17:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:12:20 --> CSRF cookie sent
INFO - 2020-04-07 17:12:20 --> Input Class Initialized
INFO - 2020-04-07 17:12:20 --> Language Class Initialized
ERROR - 2020-04-07 17:12:20 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:13:25 --> Config Class Initialized
INFO - 2020-04-07 17:13:25 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:13:25 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:13:25 --> Utf8 Class Initialized
INFO - 2020-04-07 17:13:25 --> URI Class Initialized
DEBUG - 2020-04-07 17:13:25 --> No URI present. Default controller set.
INFO - 2020-04-07 17:13:25 --> Router Class Initialized
INFO - 2020-04-07 17:13:25 --> Output Class Initialized
INFO - 2020-04-07 17:13:25 --> Security Class Initialized
DEBUG - 2020-04-07 17:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:13:25 --> CSRF cookie sent
INFO - 2020-04-07 17:13:25 --> Input Class Initialized
INFO - 2020-04-07 17:13:25 --> Language Class Initialized
INFO - 2020-04-07 17:13:25 --> Language Class Initialized
INFO - 2020-04-07 17:13:25 --> Config Class Initialized
INFO - 2020-04-07 17:13:25 --> Loader Class Initialized
INFO - 2020-04-07 17:13:25 --> Helper loaded: url_helper
INFO - 2020-04-07 17:13:25 --> Helper loaded: file_helper
INFO - 2020-04-07 17:13:25 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:13:25 --> Helper loaded: common_helper
INFO - 2020-04-07 17:13:25 --> Helper loaded: language_helper
INFO - 2020-04-07 17:13:25 --> Helper loaded: email_helper
INFO - 2020-04-07 17:13:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:13:25 --> Database Driver Class Initialized
INFO - 2020-04-07 17:13:25 --> Parser Class Initialized
INFO - 2020-04-07 17:13:25 --> User Agent Class Initialized
INFO - 2020-04-07 17:13:25 --> Model Class Initialized
INFO - 2020-04-07 17:13:25 --> Model Class Initialized
DEBUG - 2020-04-07 17:13:25 --> Template Class Initialized
INFO - 2020-04-07 17:13:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:13:25 --> Email Class Initialized
INFO - 2020-04-07 17:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:13:25 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:13:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:13:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:13:25 --> Encryption Class Initialized
INFO - 2020-04-07 17:13:25 --> Controller Class Initialized
DEBUG - 2020-04-07 17:13:25 --> home MX_Controller Initialized
INFO - 2020-04-07 17:13:25 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:13:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 17:13:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 17:13:26 --> Final output sent to browser
DEBUG - 2020-04-07 17:13:26 --> Total execution time: 0.6600
INFO - 2020-04-07 17:13:29 --> Config Class Initialized
INFO - 2020-04-07 17:13:29 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:13:29 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:13:29 --> Utf8 Class Initialized
INFO - 2020-04-07 17:13:29 --> URI Class Initialized
INFO - 2020-04-07 17:13:29 --> Router Class Initialized
INFO - 2020-04-07 17:13:29 --> Output Class Initialized
INFO - 2020-04-07 17:13:29 --> Security Class Initialized
DEBUG - 2020-04-07 17:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:13:29 --> CSRF cookie sent
INFO - 2020-04-07 17:13:29 --> Input Class Initialized
INFO - 2020-04-07 17:13:29 --> Language Class Initialized
INFO - 2020-04-07 17:13:29 --> Language Class Initialized
INFO - 2020-04-07 17:13:29 --> Config Class Initialized
INFO - 2020-04-07 17:13:29 --> Loader Class Initialized
INFO - 2020-04-07 17:13:29 --> Helper loaded: url_helper
INFO - 2020-04-07 17:13:29 --> Helper loaded: file_helper
INFO - 2020-04-07 17:13:29 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:13:29 --> Helper loaded: common_helper
INFO - 2020-04-07 17:13:29 --> Helper loaded: language_helper
INFO - 2020-04-07 17:13:29 --> Helper loaded: email_helper
INFO - 2020-04-07 17:13:29 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:13:29 --> Database Driver Class Initialized
INFO - 2020-04-07 17:13:29 --> Parser Class Initialized
INFO - 2020-04-07 17:13:29 --> User Agent Class Initialized
INFO - 2020-04-07 17:13:29 --> Model Class Initialized
INFO - 2020-04-07 17:13:29 --> Model Class Initialized
DEBUG - 2020-04-07 17:13:30 --> Template Class Initialized
INFO - 2020-04-07 17:13:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:13:30 --> Email Class Initialized
INFO - 2020-04-07 17:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:13:30 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:13:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:13:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:13:30 --> Encryption Class Initialized
INFO - 2020-04-07 17:13:30 --> Controller Class Initialized
ERROR - 2020-04-07 17:13:30 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:13:30 --> Config Class Initialized
INFO - 2020-04-07 17:13:30 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:13:30 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:13:30 --> Utf8 Class Initialized
INFO - 2020-04-07 17:13:30 --> URI Class Initialized
INFO - 2020-04-07 17:13:30 --> Router Class Initialized
INFO - 2020-04-07 17:13:30 --> Output Class Initialized
INFO - 2020-04-07 17:13:30 --> Security Class Initialized
DEBUG - 2020-04-07 17:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:13:30 --> CSRF cookie sent
INFO - 2020-04-07 17:13:30 --> Input Class Initialized
INFO - 2020-04-07 17:13:30 --> Language Class Initialized
ERROR - 2020-04-07 17:13:30 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:13:49 --> Config Class Initialized
INFO - 2020-04-07 17:13:49 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:13:49 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:13:49 --> Utf8 Class Initialized
INFO - 2020-04-07 17:13:49 --> URI Class Initialized
INFO - 2020-04-07 17:13:49 --> Router Class Initialized
INFO - 2020-04-07 17:13:49 --> Output Class Initialized
INFO - 2020-04-07 17:13:49 --> Security Class Initialized
DEBUG - 2020-04-07 17:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:13:49 --> CSRF cookie sent
INFO - 2020-04-07 17:13:49 --> Input Class Initialized
INFO - 2020-04-07 17:13:49 --> Language Class Initialized
INFO - 2020-04-07 17:13:49 --> Language Class Initialized
INFO - 2020-04-07 17:13:49 --> Config Class Initialized
INFO - 2020-04-07 17:13:49 --> Loader Class Initialized
INFO - 2020-04-07 17:13:49 --> Helper loaded: url_helper
INFO - 2020-04-07 17:13:49 --> Helper loaded: file_helper
INFO - 2020-04-07 17:13:49 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:13:49 --> Helper loaded: common_helper
INFO - 2020-04-07 17:13:49 --> Helper loaded: language_helper
INFO - 2020-04-07 17:13:49 --> Helper loaded: email_helper
INFO - 2020-04-07 17:13:49 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:13:49 --> Database Driver Class Initialized
INFO - 2020-04-07 17:13:49 --> Parser Class Initialized
INFO - 2020-04-07 17:13:49 --> User Agent Class Initialized
INFO - 2020-04-07 17:13:50 --> Model Class Initialized
INFO - 2020-04-07 17:13:50 --> Model Class Initialized
DEBUG - 2020-04-07 17:13:50 --> Template Class Initialized
INFO - 2020-04-07 17:13:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:13:50 --> Email Class Initialized
INFO - 2020-04-07 17:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:13:50 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:13:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:13:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:13:50 --> Encryption Class Initialized
INFO - 2020-04-07 17:13:50 --> Controller Class Initialized
ERROR - 2020-04-07 17:13:50 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:13:50 --> Config Class Initialized
INFO - 2020-04-07 17:13:50 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:13:50 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:13:50 --> Utf8 Class Initialized
INFO - 2020-04-07 17:13:50 --> URI Class Initialized
INFO - 2020-04-07 17:13:50 --> Router Class Initialized
INFO - 2020-04-07 17:13:50 --> Output Class Initialized
INFO - 2020-04-07 17:13:50 --> Security Class Initialized
DEBUG - 2020-04-07 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:13:50 --> CSRF cookie sent
INFO - 2020-04-07 17:13:50 --> Input Class Initialized
INFO - 2020-04-07 17:13:50 --> Language Class Initialized
ERROR - 2020-04-07 17:13:50 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:15:17 --> Config Class Initialized
INFO - 2020-04-07 17:15:17 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:15:17 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:15:17 --> Utf8 Class Initialized
INFO - 2020-04-07 17:15:17 --> URI Class Initialized
INFO - 2020-04-07 17:15:17 --> Router Class Initialized
INFO - 2020-04-07 17:15:17 --> Output Class Initialized
INFO - 2020-04-07 17:15:17 --> Security Class Initialized
DEBUG - 2020-04-07 17:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:15:17 --> CSRF cookie sent
INFO - 2020-04-07 17:15:17 --> Input Class Initialized
INFO - 2020-04-07 17:15:17 --> Language Class Initialized
INFO - 2020-04-07 17:15:17 --> Language Class Initialized
INFO - 2020-04-07 17:15:17 --> Config Class Initialized
INFO - 2020-04-07 17:15:17 --> Loader Class Initialized
INFO - 2020-04-07 17:15:17 --> Helper loaded: url_helper
INFO - 2020-04-07 17:15:17 --> Helper loaded: file_helper
INFO - 2020-04-07 17:15:17 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:15:17 --> Helper loaded: common_helper
INFO - 2020-04-07 17:15:17 --> Helper loaded: language_helper
INFO - 2020-04-07 17:15:17 --> Helper loaded: email_helper
INFO - 2020-04-07 17:15:17 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:15:17 --> Database Driver Class Initialized
INFO - 2020-04-07 17:15:17 --> Parser Class Initialized
INFO - 2020-04-07 17:15:17 --> User Agent Class Initialized
INFO - 2020-04-07 17:15:17 --> Model Class Initialized
INFO - 2020-04-07 17:15:17 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:18 --> Template Class Initialized
INFO - 2020-04-07 17:15:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:15:18 --> Email Class Initialized
INFO - 2020-04-07 17:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:15:18 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:15:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:15:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:15:18 --> Encryption Class Initialized
INFO - 2020-04-07 17:15:18 --> Controller Class Initialized
ERROR - 2020-04-07 17:15:18 --> 404 Page Not Found: ../modules/users/controllers/users/login
INFO - 2020-04-07 17:15:18 --> Config Class Initialized
INFO - 2020-04-07 17:15:18 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:15:18 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:15:18 --> Utf8 Class Initialized
INFO - 2020-04-07 17:15:18 --> URI Class Initialized
INFO - 2020-04-07 17:15:18 --> Router Class Initialized
INFO - 2020-04-07 17:15:18 --> Output Class Initialized
INFO - 2020-04-07 17:15:18 --> Security Class Initialized
DEBUG - 2020-04-07 17:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:15:18 --> CSRF cookie sent
INFO - 2020-04-07 17:15:18 --> Input Class Initialized
INFO - 2020-04-07 17:15:18 --> Language Class Initialized
ERROR - 2020-04-07 17:15:18 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:15:24 --> Config Class Initialized
INFO - 2020-04-07 17:15:24 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:15:24 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:15:24 --> Utf8 Class Initialized
INFO - 2020-04-07 17:15:24 --> URI Class Initialized
DEBUG - 2020-04-07 17:15:24 --> No URI present. Default controller set.
INFO - 2020-04-07 17:15:24 --> Router Class Initialized
INFO - 2020-04-07 17:15:24 --> Output Class Initialized
INFO - 2020-04-07 17:15:24 --> Security Class Initialized
DEBUG - 2020-04-07 17:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:15:24 --> CSRF cookie sent
INFO - 2020-04-07 17:15:24 --> Input Class Initialized
INFO - 2020-04-07 17:15:24 --> Language Class Initialized
INFO - 2020-04-07 17:15:24 --> Language Class Initialized
INFO - 2020-04-07 17:15:24 --> Config Class Initialized
INFO - 2020-04-07 17:15:24 --> Loader Class Initialized
INFO - 2020-04-07 17:15:24 --> Helper loaded: url_helper
INFO - 2020-04-07 17:15:25 --> Helper loaded: file_helper
INFO - 2020-04-07 17:15:25 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:15:25 --> Helper loaded: common_helper
INFO - 2020-04-07 17:15:25 --> Helper loaded: language_helper
INFO - 2020-04-07 17:15:25 --> Helper loaded: email_helper
INFO - 2020-04-07 17:15:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:15:25 --> Database Driver Class Initialized
INFO - 2020-04-07 17:15:25 --> Parser Class Initialized
INFO - 2020-04-07 17:15:25 --> User Agent Class Initialized
INFO - 2020-04-07 17:15:25 --> Model Class Initialized
INFO - 2020-04-07 17:15:25 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:25 --> Template Class Initialized
INFO - 2020-04-07 17:15:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:15:25 --> Email Class Initialized
INFO - 2020-04-07 17:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:15:25 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:15:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:15:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:15:25 --> Encryption Class Initialized
INFO - 2020-04-07 17:15:25 --> Controller Class Initialized
DEBUG - 2020-04-07 17:15:25 --> home MX_Controller Initialized
INFO - 2020-04-07 17:15:25 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:15:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 17:15:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 17:15:25 --> Final output sent to browser
DEBUG - 2020-04-07 17:15:25 --> Total execution time: 0.6509
INFO - 2020-04-07 17:15:28 --> Config Class Initialized
INFO - 2020-04-07 17:15:28 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:15:28 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:15:28 --> Utf8 Class Initialized
INFO - 2020-04-07 17:15:28 --> URI Class Initialized
INFO - 2020-04-07 17:15:28 --> Router Class Initialized
INFO - 2020-04-07 17:15:28 --> Output Class Initialized
INFO - 2020-04-07 17:15:28 --> Security Class Initialized
DEBUG - 2020-04-07 17:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:15:28 --> CSRF cookie sent
INFO - 2020-04-07 17:15:28 --> Input Class Initialized
INFO - 2020-04-07 17:15:28 --> Language Class Initialized
INFO - 2020-04-07 17:15:28 --> Language Class Initialized
INFO - 2020-04-07 17:15:28 --> Config Class Initialized
INFO - 2020-04-07 17:15:28 --> Loader Class Initialized
INFO - 2020-04-07 17:15:28 --> Helper loaded: url_helper
INFO - 2020-04-07 17:15:28 --> Helper loaded: file_helper
INFO - 2020-04-07 17:15:28 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:15:28 --> Helper loaded: common_helper
INFO - 2020-04-07 17:15:28 --> Helper loaded: language_helper
INFO - 2020-04-07 17:15:28 --> Helper loaded: email_helper
INFO - 2020-04-07 17:15:28 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:15:28 --> Database Driver Class Initialized
INFO - 2020-04-07 17:15:28 --> Parser Class Initialized
INFO - 2020-04-07 17:15:28 --> User Agent Class Initialized
INFO - 2020-04-07 17:15:28 --> Model Class Initialized
INFO - 2020-04-07 17:15:28 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:28 --> Template Class Initialized
INFO - 2020-04-07 17:15:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:15:28 --> Email Class Initialized
INFO - 2020-04-07 17:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:15:28 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:15:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:15:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:15:29 --> Encryption Class Initialized
INFO - 2020-04-07 17:15:29 --> Controller Class Initialized
DEBUG - 2020-04-07 17:15:29 --> auth MX_Controller Initialized
INFO - 2020-04-07 17:15:29 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-07 17:15:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-07 17:15:29 --> Final output sent to browser
DEBUG - 2020-04-07 17:15:29 --> Total execution time: 1.1867
INFO - 2020-04-07 17:15:30 --> Config Class Initialized
INFO - 2020-04-07 17:15:30 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:15:31 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:15:31 --> Utf8 Class Initialized
INFO - 2020-04-07 17:15:31 --> URI Class Initialized
INFO - 2020-04-07 17:15:31 --> Router Class Initialized
INFO - 2020-04-07 17:15:31 --> Output Class Initialized
INFO - 2020-04-07 17:15:31 --> Security Class Initialized
DEBUG - 2020-04-07 17:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:15:31 --> CSRF cookie sent
INFO - 2020-04-07 17:15:31 --> CSRF token verified
INFO - 2020-04-07 17:15:31 --> Input Class Initialized
INFO - 2020-04-07 17:15:31 --> Language Class Initialized
INFO - 2020-04-07 17:15:31 --> Language Class Initialized
INFO - 2020-04-07 17:15:31 --> Config Class Initialized
INFO - 2020-04-07 17:15:31 --> Loader Class Initialized
INFO - 2020-04-07 17:15:31 --> Helper loaded: url_helper
INFO - 2020-04-07 17:15:31 --> Helper loaded: file_helper
INFO - 2020-04-07 17:15:31 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:15:31 --> Helper loaded: common_helper
INFO - 2020-04-07 17:15:31 --> Helper loaded: language_helper
INFO - 2020-04-07 17:15:31 --> Helper loaded: email_helper
INFO - 2020-04-07 17:15:31 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:15:31 --> Database Driver Class Initialized
INFO - 2020-04-07 17:15:31 --> Parser Class Initialized
INFO - 2020-04-07 17:15:31 --> User Agent Class Initialized
INFO - 2020-04-07 17:15:31 --> Model Class Initialized
INFO - 2020-04-07 17:15:31 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:31 --> Template Class Initialized
INFO - 2020-04-07 17:15:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:15:31 --> Email Class Initialized
INFO - 2020-04-07 17:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:15:31 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:15:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:15:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:15:31 --> Encryption Class Initialized
INFO - 2020-04-07 17:15:31 --> Controller Class Initialized
DEBUG - 2020-04-07 17:15:31 --> auth MX_Controller Initialized
INFO - 2020-04-07 17:15:33 --> Config Class Initialized
INFO - 2020-04-07 17:15:33 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:15:33 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:15:33 --> Utf8 Class Initialized
INFO - 2020-04-07 17:15:33 --> URI Class Initialized
INFO - 2020-04-07 17:15:33 --> Router Class Initialized
INFO - 2020-04-07 17:15:33 --> Output Class Initialized
INFO - 2020-04-07 17:15:33 --> Security Class Initialized
DEBUG - 2020-04-07 17:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:15:33 --> CSRF cookie sent
INFO - 2020-04-07 17:15:33 --> Input Class Initialized
INFO - 2020-04-07 17:15:33 --> Language Class Initialized
INFO - 2020-04-07 17:15:33 --> Language Class Initialized
INFO - 2020-04-07 17:15:33 --> Config Class Initialized
INFO - 2020-04-07 17:15:33 --> Loader Class Initialized
INFO - 2020-04-07 17:15:33 --> Helper loaded: url_helper
INFO - 2020-04-07 17:15:33 --> Helper loaded: file_helper
INFO - 2020-04-07 17:15:33 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:15:33 --> Helper loaded: common_helper
INFO - 2020-04-07 17:15:33 --> Helper loaded: language_helper
INFO - 2020-04-07 17:15:33 --> Helper loaded: email_helper
INFO - 2020-04-07 17:15:33 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:15:33 --> Database Driver Class Initialized
INFO - 2020-04-07 17:15:33 --> Parser Class Initialized
INFO - 2020-04-07 17:15:33 --> User Agent Class Initialized
INFO - 2020-04-07 17:15:33 --> Model Class Initialized
INFO - 2020-04-07 17:15:33 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:34 --> Template Class Initialized
INFO - 2020-04-07 17:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:15:34 --> Email Class Initialized
INFO - 2020-04-07 17:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:15:34 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:15:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:15:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:15:34 --> Encryption Class Initialized
INFO - 2020-04-07 17:15:34 --> Controller Class Initialized
DEBUG - 2020-04-07 17:15:34 --> dashboard MX_Controller Initialized
INFO - 2020-04-07 17:15:34 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-07 17:15:34 --> Model Class Initialized
INFO - 2020-04-07 17:15:34 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/content.php
DEBUG - 2020-04-07 17:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/dashboard/views/index.php
DEBUG - 2020-04-07 17:15:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:15:34 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:15:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:15:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:15:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:15:35 --> Final output sent to browser
DEBUG - 2020-04-07 17:15:35 --> Total execution time: 2.3681
INFO - 2020-04-07 17:15:38 --> Config Class Initialized
INFO - 2020-04-07 17:15:38 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:15:38 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:15:38 --> Utf8 Class Initialized
INFO - 2020-04-07 17:15:38 --> URI Class Initialized
INFO - 2020-04-07 17:15:38 --> Router Class Initialized
INFO - 2020-04-07 17:15:38 --> Output Class Initialized
INFO - 2020-04-07 17:15:38 --> Security Class Initialized
DEBUG - 2020-04-07 17:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:15:38 --> CSRF cookie sent
INFO - 2020-04-07 17:15:38 --> Input Class Initialized
INFO - 2020-04-07 17:15:38 --> Language Class Initialized
ERROR - 2020-04-07 17:15:38 --> 404 Page Not Found: /index
INFO - 2020-04-07 17:15:56 --> Config Class Initialized
INFO - 2020-04-07 17:15:56 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:15:56 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:15:56 --> Utf8 Class Initialized
INFO - 2020-04-07 17:15:56 --> URI Class Initialized
DEBUG - 2020-04-07 17:15:56 --> No URI present. Default controller set.
INFO - 2020-04-07 17:15:56 --> Router Class Initialized
INFO - 2020-04-07 17:15:56 --> Output Class Initialized
INFO - 2020-04-07 17:15:56 --> Security Class Initialized
DEBUG - 2020-04-07 17:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:15:56 --> CSRF cookie sent
INFO - 2020-04-07 17:15:56 --> Input Class Initialized
INFO - 2020-04-07 17:15:56 --> Language Class Initialized
INFO - 2020-04-07 17:15:56 --> Language Class Initialized
INFO - 2020-04-07 17:15:56 --> Config Class Initialized
INFO - 2020-04-07 17:15:56 --> Loader Class Initialized
INFO - 2020-04-07 17:15:56 --> Helper loaded: url_helper
INFO - 2020-04-07 17:15:56 --> Helper loaded: file_helper
INFO - 2020-04-07 17:15:56 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:15:56 --> Helper loaded: common_helper
INFO - 2020-04-07 17:15:56 --> Helper loaded: language_helper
INFO - 2020-04-07 17:15:56 --> Helper loaded: email_helper
INFO - 2020-04-07 17:15:56 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:15:56 --> Database Driver Class Initialized
INFO - 2020-04-07 17:15:56 --> Parser Class Initialized
INFO - 2020-04-07 17:15:56 --> User Agent Class Initialized
INFO - 2020-04-07 17:15:56 --> Model Class Initialized
INFO - 2020-04-07 17:15:56 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:56 --> Template Class Initialized
INFO - 2020-04-07 17:15:56 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:15:57 --> Email Class Initialized
INFO - 2020-04-07 17:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:15:57 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:15:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:15:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:15:57 --> Encryption Class Initialized
INFO - 2020-04-07 17:15:57 --> Controller Class Initialized
DEBUG - 2020-04-07 17:15:57 --> home MX_Controller Initialized
INFO - 2020-04-07 17:15:57 --> Model Class Initialized
INFO - 2020-04-07 17:15:57 --> Config Class Initialized
INFO - 2020-04-07 17:15:57 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:15:57 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:15:57 --> Utf8 Class Initialized
INFO - 2020-04-07 17:15:57 --> URI Class Initialized
INFO - 2020-04-07 17:15:57 --> Router Class Initialized
INFO - 2020-04-07 17:15:57 --> Output Class Initialized
INFO - 2020-04-07 17:15:57 --> Security Class Initialized
DEBUG - 2020-04-07 17:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:15:57 --> CSRF cookie sent
INFO - 2020-04-07 17:15:57 --> Input Class Initialized
INFO - 2020-04-07 17:15:57 --> Language Class Initialized
INFO - 2020-04-07 17:15:57 --> Language Class Initialized
INFO - 2020-04-07 17:15:57 --> Config Class Initialized
INFO - 2020-04-07 17:15:57 --> Loader Class Initialized
INFO - 2020-04-07 17:15:57 --> Helper loaded: url_helper
INFO - 2020-04-07 17:15:57 --> Helper loaded: file_helper
INFO - 2020-04-07 17:15:57 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:15:57 --> Helper loaded: common_helper
INFO - 2020-04-07 17:15:57 --> Helper loaded: language_helper
INFO - 2020-04-07 17:15:57 --> Helper loaded: email_helper
INFO - 2020-04-07 17:15:57 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:15:57 --> Database Driver Class Initialized
INFO - 2020-04-07 17:15:57 --> Parser Class Initialized
INFO - 2020-04-07 17:15:57 --> User Agent Class Initialized
INFO - 2020-04-07 17:15:57 --> Model Class Initialized
INFO - 2020-04-07 17:15:57 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:57 --> Template Class Initialized
INFO - 2020-04-07 17:15:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:15:57 --> Email Class Initialized
INFO - 2020-04-07 17:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:15:57 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:15:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:15:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:15:57 --> Encryption Class Initialized
INFO - 2020-04-07 17:15:57 --> Controller Class Initialized
DEBUG - 2020-04-07 17:15:57 --> twitter MX_Controller Initialized
INFO - 2020-04-07 17:15:57 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 17:15:57 --> Model Class Initialized
DEBUG - 2020-04-07 17:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-07 17:15:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:15:57 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:15:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:15:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:15:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:15:59 --> Final output sent to browser
DEBUG - 2020-04-07 17:15:59 --> Total execution time: 1.9528
INFO - 2020-04-07 17:20:14 --> Config Class Initialized
INFO - 2020-04-07 17:20:14 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:20:14 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:20:14 --> Utf8 Class Initialized
INFO - 2020-04-07 17:20:14 --> URI Class Initialized
INFO - 2020-04-07 17:20:14 --> Router Class Initialized
INFO - 2020-04-07 17:20:14 --> Output Class Initialized
INFO - 2020-04-07 17:20:14 --> Security Class Initialized
DEBUG - 2020-04-07 17:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:20:14 --> CSRF cookie sent
INFO - 2020-04-07 17:20:14 --> Input Class Initialized
INFO - 2020-04-07 17:20:14 --> Language Class Initialized
INFO - 2020-04-07 17:20:14 --> Language Class Initialized
INFO - 2020-04-07 17:20:14 --> Config Class Initialized
INFO - 2020-04-07 17:20:15 --> Loader Class Initialized
INFO - 2020-04-07 17:20:15 --> Helper loaded: url_helper
INFO - 2020-04-07 17:20:15 --> Helper loaded: file_helper
INFO - 2020-04-07 17:20:15 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:20:15 --> Helper loaded: common_helper
INFO - 2020-04-07 17:20:15 --> Helper loaded: language_helper
INFO - 2020-04-07 17:20:15 --> Helper loaded: email_helper
INFO - 2020-04-07 17:20:15 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:20:15 --> Database Driver Class Initialized
INFO - 2020-04-07 17:20:15 --> Parser Class Initialized
INFO - 2020-04-07 17:20:15 --> User Agent Class Initialized
INFO - 2020-04-07 17:20:15 --> Model Class Initialized
INFO - 2020-04-07 17:20:15 --> Model Class Initialized
DEBUG - 2020-04-07 17:20:15 --> Template Class Initialized
INFO - 2020-04-07 17:20:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:20:15 --> Email Class Initialized
INFO - 2020-04-07 17:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:20:15 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:20:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:20:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:20:15 --> Encryption Class Initialized
INFO - 2020-04-07 17:20:15 --> Controller Class Initialized
DEBUG - 2020-04-07 17:20:15 --> twitter MX_Controller Initialized
INFO - 2020-04-07 17:20:15 --> Model Class Initialized
DEBUG - 2020-04-07 17:20:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/models/twitter_model.php
INFO - 2020-04-07 17:20:15 --> Model Class Initialized
DEBUG - 2020-04-07 17:20:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/twitter/views/index.php
DEBUG - 2020-04-07 17:20:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-07 17:20:15 --> blocks MX_Controller Initialized
DEBUG - 2020-04-07 17:20:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/header.php
DEBUG - 2020-04-07 17:20:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-07 17:20:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/template.php
INFO - 2020-04-07 17:20:16 --> Final output sent to browser
DEBUG - 2020-04-07 17:20:16 --> Total execution time: 1.7981
INFO - 2020-04-07 17:20:18 --> Config Class Initialized
INFO - 2020-04-07 17:20:18 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:20:18 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:20:18 --> Utf8 Class Initialized
INFO - 2020-04-07 17:20:18 --> URI Class Initialized
INFO - 2020-04-07 17:20:18 --> Router Class Initialized
INFO - 2020-04-07 17:20:18 --> Output Class Initialized
INFO - 2020-04-07 17:20:18 --> Security Class Initialized
DEBUG - 2020-04-07 17:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:20:18 --> CSRF cookie sent
INFO - 2020-04-07 17:20:19 --> Input Class Initialized
INFO - 2020-04-07 17:20:19 --> Language Class Initialized
INFO - 2020-04-07 17:20:19 --> Language Class Initialized
INFO - 2020-04-07 17:20:19 --> Config Class Initialized
INFO - 2020-04-07 17:20:19 --> Loader Class Initialized
INFO - 2020-04-07 17:20:19 --> Helper loaded: url_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: file_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: common_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: language_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: email_helper
INFO - 2020-04-07 17:20:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:20:19 --> Database Driver Class Initialized
INFO - 2020-04-07 17:20:19 --> Parser Class Initialized
INFO - 2020-04-07 17:20:19 --> User Agent Class Initialized
INFO - 2020-04-07 17:20:19 --> Model Class Initialized
INFO - 2020-04-07 17:20:19 --> Model Class Initialized
DEBUG - 2020-04-07 17:20:19 --> Template Class Initialized
INFO - 2020-04-07 17:20:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:20:19 --> Email Class Initialized
INFO - 2020-04-07 17:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:20:19 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:20:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:20:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:20:19 --> Encryption Class Initialized
INFO - 2020-04-07 17:20:19 --> Controller Class Initialized
DEBUG - 2020-04-07 17:20:19 --> auth MX_Controller Initialized
INFO - 2020-04-07 17:20:19 --> Model Class Initialized
INFO - 2020-04-07 17:20:19 --> Config Class Initialized
INFO - 2020-04-07 17:20:19 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:20:19 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:20:19 --> Utf8 Class Initialized
INFO - 2020-04-07 17:20:19 --> URI Class Initialized
DEBUG - 2020-04-07 17:20:19 --> No URI present. Default controller set.
INFO - 2020-04-07 17:20:19 --> Router Class Initialized
INFO - 2020-04-07 17:20:19 --> Output Class Initialized
INFO - 2020-04-07 17:20:19 --> Security Class Initialized
DEBUG - 2020-04-07 17:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:20:19 --> CSRF cookie sent
INFO - 2020-04-07 17:20:19 --> Input Class Initialized
INFO - 2020-04-07 17:20:19 --> Language Class Initialized
INFO - 2020-04-07 17:20:19 --> Language Class Initialized
INFO - 2020-04-07 17:20:19 --> Config Class Initialized
INFO - 2020-04-07 17:20:19 --> Loader Class Initialized
INFO - 2020-04-07 17:20:19 --> Helper loaded: url_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: file_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: common_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: language_helper
INFO - 2020-04-07 17:20:19 --> Helper loaded: email_helper
INFO - 2020-04-07 17:20:19 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:20:19 --> Database Driver Class Initialized
INFO - 2020-04-07 17:20:19 --> Parser Class Initialized
INFO - 2020-04-07 17:20:19 --> User Agent Class Initialized
INFO - 2020-04-07 17:20:19 --> Model Class Initialized
INFO - 2020-04-07 17:20:19 --> Model Class Initialized
DEBUG - 2020-04-07 17:20:19 --> Template Class Initialized
INFO - 2020-04-07 17:20:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:20:19 --> Email Class Initialized
INFO - 2020-04-07 17:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:20:19 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:20:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:20:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:20:19 --> Encryption Class Initialized
INFO - 2020-04-07 17:20:19 --> Controller Class Initialized
DEBUG - 2020-04-07 17:20:20 --> home MX_Controller Initialized
INFO - 2020-04-07 17:20:20 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:20:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/home/views/index.php
DEBUG - 2020-04-07 17:20:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/landing_page.php
INFO - 2020-04-07 17:20:20 --> Final output sent to browser
DEBUG - 2020-04-07 17:20:20 --> Total execution time: 0.6526
INFO - 2020-04-07 17:20:22 --> Config Class Initialized
INFO - 2020-04-07 17:20:22 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:20:23 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:20:23 --> Utf8 Class Initialized
INFO - 2020-04-07 17:20:23 --> URI Class Initialized
INFO - 2020-04-07 17:20:23 --> Router Class Initialized
INFO - 2020-04-07 17:20:23 --> Output Class Initialized
INFO - 2020-04-07 17:20:23 --> Security Class Initialized
DEBUG - 2020-04-07 17:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:20:23 --> CSRF cookie sent
INFO - 2020-04-07 17:20:23 --> Input Class Initialized
INFO - 2020-04-07 17:20:23 --> Language Class Initialized
INFO - 2020-04-07 17:20:23 --> Language Class Initialized
INFO - 2020-04-07 17:20:23 --> Config Class Initialized
INFO - 2020-04-07 17:20:23 --> Loader Class Initialized
INFO - 2020-04-07 17:20:23 --> Helper loaded: url_helper
INFO - 2020-04-07 17:20:23 --> Helper loaded: file_helper
INFO - 2020-04-07 17:20:23 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:20:23 --> Helper loaded: common_helper
INFO - 2020-04-07 17:20:23 --> Helper loaded: language_helper
INFO - 2020-04-07 17:20:23 --> Helper loaded: email_helper
INFO - 2020-04-07 17:20:23 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:20:23 --> Database Driver Class Initialized
INFO - 2020-04-07 17:20:23 --> Parser Class Initialized
INFO - 2020-04-07 17:20:23 --> User Agent Class Initialized
INFO - 2020-04-07 17:20:23 --> Model Class Initialized
INFO - 2020-04-07 17:20:23 --> Model Class Initialized
DEBUG - 2020-04-07 17:20:23 --> Template Class Initialized
INFO - 2020-04-07 17:20:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:20:23 --> Email Class Initialized
INFO - 2020-04-07 17:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:20:23 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:20:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:20:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:20:24 --> Encryption Class Initialized
INFO - 2020-04-07 17:20:24 --> Controller Class Initialized
DEBUG - 2020-04-07 17:20:24 --> auth MX_Controller Initialized
INFO - 2020-04-07 17:20:24 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/login.php
DEBUG - 2020-04-07 17:20:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-07 17:20:24 --> Final output sent to browser
DEBUG - 2020-04-07 17:20:24 --> Total execution time: 1.2568
INFO - 2020-04-07 17:20:27 --> Config Class Initialized
INFO - 2020-04-07 17:20:27 --> Hooks Class Initialized
DEBUG - 2020-04-07 17:20:27 --> UTF-8 Support Enabled
INFO - 2020-04-07 17:20:27 --> Utf8 Class Initialized
INFO - 2020-04-07 17:20:27 --> URI Class Initialized
INFO - 2020-04-07 17:20:27 --> Router Class Initialized
INFO - 2020-04-07 17:20:27 --> Output Class Initialized
INFO - 2020-04-07 17:20:27 --> Security Class Initialized
DEBUG - 2020-04-07 17:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-07 17:20:27 --> CSRF cookie sent
INFO - 2020-04-07 17:20:27 --> Input Class Initialized
INFO - 2020-04-07 17:20:27 --> Language Class Initialized
INFO - 2020-04-07 17:20:27 --> Language Class Initialized
INFO - 2020-04-07 17:20:27 --> Config Class Initialized
INFO - 2020-04-07 17:20:27 --> Loader Class Initialized
INFO - 2020-04-07 17:20:27 --> Helper loaded: url_helper
INFO - 2020-04-07 17:20:27 --> Helper loaded: file_helper
INFO - 2020-04-07 17:20:27 --> Helper loaded: cookie_helper
INFO - 2020-04-07 17:20:27 --> Helper loaded: common_helper
INFO - 2020-04-07 17:20:27 --> Helper loaded: language_helper
INFO - 2020-04-07 17:20:27 --> Helper loaded: email_helper
INFO - 2020-04-07 17:20:27 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-07 17:20:27 --> Database Driver Class Initialized
INFO - 2020-04-07 17:20:27 --> Parser Class Initialized
INFO - 2020-04-07 17:20:27 --> User Agent Class Initialized
INFO - 2020-04-07 17:20:27 --> Model Class Initialized
INFO - 2020-04-07 17:20:27 --> Model Class Initialized
DEBUG - 2020-04-07 17:20:27 --> Template Class Initialized
INFO - 2020-04-07 17:20:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-07 17:20:27 --> Email Class Initialized
INFO - 2020-04-07 17:20:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-07 17:20:27 --> Pagination Class Initialized
DEBUG - 2020-04-07 17:20:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-07 17:20:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-07 17:20:27 --> Encryption Class Initialized
INFO - 2020-04-07 17:20:27 --> Controller Class Initialized
DEBUG - 2020-04-07 17:20:27 --> auth MX_Controller Initialized
INFO - 2020-04-07 17:20:27 --> Helper loaded: inflector_helper
DEBUG - 2020-04-07 17:20:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\modules/auth/views/register.php
DEBUG - 2020-04-07 17:20:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\code\app\views/layouts/oauth.php
INFO - 2020-04-07 17:20:28 --> Final output sent to browser
DEBUG - 2020-04-07 17:20:28 --> Total execution time: 1.3623
